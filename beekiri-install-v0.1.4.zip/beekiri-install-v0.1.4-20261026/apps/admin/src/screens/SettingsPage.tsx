import { FormEvent, useEffect, useState } from 'react';
import { api, ApiError } from '../api/client';
import { useCoreUpdate } from '../core/CoreUpdateContext';

type Tab = 'core' | 'general' | 'reading' | 'writing' | 'advanced' | 'permalinks' | 'media';

type SiteSettings = {
  id: string;
  title: string;
  tagline: string;
  language: string;
  blogPublic: boolean;
  timezone: string;
  dateFormat: string;
  timeFormat: string;
};

type SystemStatus = {
  api: { ok: boolean; label: string };
  database: { ok: boolean; label: string };
  uptimeSeconds: number;
  nodeVersion: string;
  environment: string;
  coreVersion: string;
  channel: string;
  checkedAt: string;
};

const TABS: { id: Tab; label: string }[] = [
  { id: 'core', label: 'Beekiri Core' },
  { id: 'general', label: 'General' },
  { id: 'reading', label: 'Reading' },
  { id: 'writing', label: 'Writing' },
  { id: 'advanced', label: 'Advanced' },
  { id: 'permalinks', label: 'Permalinks' },
  { id: 'media', label: 'Media' },
];

function formatUptime(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  if (m < 60) return `${m}m ${s}s`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  if (h < 24) return `${h}h ${rm}m`;
  const d = Math.floor(h / 24);
  return `${d}d ${h % 24}h`;
}

function StatusValue({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span className={`bk-status ${ok ? 'is-ok' : 'is-down'}`}>
      <span className="bk-status__dot" aria-hidden />
      {label}
    </span>
  );
}

export function SettingsPage() {
  const coreUpdate = useCoreUpdate();
  const [tab, setTab] = useState<Tab>('core');
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const updates = coreUpdate.updates;
  const updateAvailable = coreUpdate.updateAvailable;
  const updateCount = coreUpdate.updateCount;

  const loadSettings = async () => {
    const s = await api<SiteSettings>('/api/site/settings');
    setSettings(s);
  };

  const loadCore = async () => {
    const s = await api<SystemStatus>('/api/system/status');
    setStatus(s);
  };

  useEffect(() => {
    setError(null);
    setNotice(null);
    if (tab === 'core') {
      loadCore().catch((e) =>
        setError(e instanceof ApiError ? e.message : 'Could not load core status'),
      );
      void coreUpdate.refresh();
    } else if (tab === 'permalinks' || tab === 'media') {
      // informational only
    } else {
      loadSettings().catch((e) =>
        setError(e instanceof ApiError ? e.message : 'Could not load settings'),
      );
    }
  }, [tab]);

  const refreshStatus = async () => {
    setRefreshing(true);
    setError(null);
    try {
      await loadCore();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Could not refresh status');
    } finally {
      setRefreshing(false);
    }
  };

  const saveSettings = async (e: FormEvent, patch: Partial<SiteSettings>) => {
    e.preventDefault();
    if (!settings) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const saved = await api<SiteSettings>('/api/site/settings', {
        method: 'PATCH',
        json: patch,
      });
      setSettings(saved);
      setNotice('Settings saved.');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Save failed');
    } finally {
      setBusy(false);
    }
  };

  const checkUpdates = async () => {
    setError(null);
    setNotice(null);
    const u = await coreUpdate.refresh();
    if (!u) {
      setError('Update check failed');
      return;
    }
    if (!u.updateAvailable) setNotice(null);
  };

  return (
    <div className="wrap">
      <h1>
        Settings
        {updateCount > 0 ? (
          <span className="bk-count" aria-label={`${updateCount} update available`}>
            +{updateCount}
          </span>
        ) : null}
      </h1>

      <nav className="bk-tabs" aria-label="Settings sections">
        {TABS.map(({ id, label }) => (
          <button
            key={id}
            type="button"
            className={`bk-tabs__item${tab === id ? ' is-active' : ''}`}
            onClick={() => setTab(id)}
          >
            {label}
            {id === 'core' && updateCount > 0 ? (
              <span className="bk-count">+{updateCount}</span>
            ) : null}
          </button>
        ))}
      </nav>

      {error && (
        <div className="beekiri-notice is-error">
          <p>{error}</p>
        </div>
      )}
      {notice && (
        <div className="beekiri-notice is-success">
          <p>{notice}</p>
        </div>
      )}

      {tab === 'general' && settings && (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">General</h2>
          </div>
          <div className="bk-panel__body">
            <form
              onSubmit={(e) =>
                void saveSettings(e, {
                  title: settings.title,
                  tagline: settings.tagline,
                })
              }
            >
              <table className="form-table">
                <tbody>
                  <tr>
                    <th scope="row">
                      <label htmlFor="blogname">Site title</label>
                    </th>
                    <td>
                      <input
                        id="blogname"
                        className="regular-text"
                        value={settings.title}
                        onChange={(e) => setSettings({ ...settings, title: e.target.value })}
                        required
                      />
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="blogdescription">Tagline</label>
                    </th>
                    <td>
                      <input
                        id="blogdescription"
                        className="regular-text"
                        value={settings.tagline}
                        onChange={(e) => setSettings({ ...settings, tagline: e.target.value })}
                      />
                      <p className="description">Shown on the public landing page.</p>
                    </td>
                  </tr>
                </tbody>
              </table>
              <p className="submit">
                <button type="submit" className="button button-primary" disabled={busy}>
                  {busy ? 'Saving…' : 'Save changes'}
                </button>
              </p>
            </form>
          </div>
        </div>
      )}

      {tab === 'reading' && settings && (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Reading</h2>
          </div>
          <div className="bk-panel__body">
            <form
              onSubmit={(e) => void saveSettings(e, { blogPublic: settings.blogPublic })}
            >
              <table className="form-table">
                <tbody>
                  <tr>
                    <th scope="row">Search visibility</th>
                    <td>
                      <label>
                        <input
                          type="checkbox"
                          checked={settings.blogPublic}
                          onChange={(e) =>
                            setSettings({ ...settings, blogPublic: e.target.checked })
                          }
                        />{' '}
                        Allow search engines to index this site
                      </label>
                      <p className="description">
                        When unchecked, the public site asks crawlers not to index pages.
                      </p>
                    </td>
                  </tr>
                </tbody>
              </table>
              <p className="submit">
                <button type="submit" className="button button-primary" disabled={busy}>
                  {busy ? 'Saving…' : 'Save changes'}
                </button>
              </p>
            </form>
          </div>
        </div>
      )}

      {tab === 'writing' && settings && (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Writing</h2>
          </div>
          <div className="bk-panel__body">
            <form
              onSubmit={(e) =>
                void saveSettings(e, {
                  dateFormat: settings.dateFormat,
                  timeFormat: settings.timeFormat,
                })
              }
            >
              <table className="form-table">
                <tbody>
                  <tr>
                    <th scope="row">
                      <label htmlFor="date_format">Date format</label>
                    </th>
                    <td>
                      <input
                        id="date_format"
                        className="regular-text"
                        value={settings.dateFormat}
                        onChange={(e) =>
                          setSettings({ ...settings, dateFormat: e.target.value })
                        }
                      />
                      <p className="description">Used when dates are shown in admin and themes.</p>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="time_format">Time format</label>
                    </th>
                    <td>
                      <input
                        id="time_format"
                        className="regular-text"
                        value={settings.timeFormat}
                        onChange={(e) =>
                          setSettings({ ...settings, timeFormat: e.target.value })
                        }
                      />
                    </td>
                  </tr>
                </tbody>
              </table>
              <p className="submit">
                <button type="submit" className="button button-primary" disabled={busy}>
                  {busy ? 'Saving…' : 'Save changes'}
                </button>
              </p>
            </form>
          </div>
        </div>
      )}

      {tab === 'advanced' && settings && (
        <div className="bk-stack">
          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Advanced</h2>
            </div>
            <div className="bk-panel__body">
              <form
                onSubmit={(e) =>
                  void saveSettings(e, {
                    language: settings.language,
                    timezone: settings.timezone,
                  })
                }
              >
                <table className="form-table">
                  <tbody>
                    <tr>
                      <th scope="row">
                        <label htmlFor="site_language">Site language</label>
                      </th>
                      <td>
                        <select
                          id="site_language"
                          value={settings.language}
                          onChange={(e) =>
                            setSettings({ ...settings, language: e.target.value })
                          }
                        >
                          <option value="en_US">English (United States)</option>
                          <option value="en_GB">English (UK)</option>
                          <option value="sq">Albanian</option>
                          <option value="de_DE">German</option>
                          <option value="fr_FR">French</option>
                          <option value="it_IT">Italian</option>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">
                        <label htmlFor="timezone_string">Timezone</label>
                      </th>
                      <td>
                        <select
                          id="timezone_string"
                          value={settings.timezone}
                          onChange={(e) =>
                            setSettings({ ...settings, timezone: e.target.value })
                          }
                        >
                          <option value="UTC">UTC</option>
                          <option value="Europe/London">Europe/London</option>
                          <option value="Europe/Berlin">Europe/Berlin</option>
                          <option value="Europe/Tirane">Europe/Tirane</option>
                          <option value="America/New_York">America/New_York</option>
                          <option value="America/Los_Angeles">America/Los_Angeles</option>
                        </select>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <p className="submit">
                  <button type="submit" className="button button-primary" disabled={busy}>
                    {busy ? 'Saving…' : 'Save changes'}
                  </button>
                </p>
              </form>
            </div>
          </div>
          <div className="bk-help">
            <strong>Tip:</strong> Changing language or timezone does not rewrite your content. It
            only affects how the admin and public site format dates and labels going forward.
          </div>
        </div>
      )}

      {tab === 'permalinks' && (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Permalinks</h2>
          </div>
          <div className="bk-panel__body">
            <p className="bk-muted" style={{ marginTop: 0 }}>
              Pretty URL structures arrive with posts and pages (Phase 2). Until then, public
              routes use Beekiri defaults.
            </p>
            <div className="bk-help">
              <strong>Coming next:</strong> post name, day and name, custom structure — saved here
              without changing your content.
            </div>
          </div>
        </div>
      )}

      {tab === 'media' && (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Media</h2>
          </div>
          <div className="bk-panel__body">
            <p className="bk-muted" style={{ marginTop: 0 }}>
              Image sizes, uploads path, and library settings land with the Media phase.
            </p>
            <div className="bk-help">
              <strong>Today:</strong> uploads stay on this server under your configured media path
              in <code>.env</code>. Your files are never overwritten by a core update.
            </div>
          </div>
        </div>
      )}

      {tab === 'core' && status && (
        <div className="bk-stack">
          {updateAvailable && updates?.latestVersion ? (
            <div className="beekiri-notice is-update" role="status">
              <p>
                You have a new update — Beekiri Core{' '}
                <strong>v{updates.latestVersion}</strong> is available. You are on{' '}
                <strong>v{updates.currentVersion}</strong>.
              </p>
            </div>
          ) : null}

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Status</h2>
              <button
                type="button"
                className="button button-primary"
                onClick={() => void refreshStatus()}
                disabled={refreshing}
              >
                {refreshing ? 'Refreshing…' : 'Refresh'}
              </button>
            </div>
            <div className="bk-panel__body">
              <ul className="bk-rows">
                <li className="bk-row">
                  <span className="bk-row__label">API server</span>
                  <span className="bk-row__value">
                    <StatusValue ok={status.api.ok} label={status.api.label} />
                  </span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Database</span>
                  <span className="bk-row__value">
                    <StatusValue ok={status.database.ok} label={status.database.label} />
                  </span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Uptime</span>
                  <span className="bk-row__value">{formatUptime(status.uptimeSeconds)}</span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Environment</span>
                  <span className="bk-row__value">{status.environment}</span>
                </li>
              </ul>
            </div>
          </section>

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Version</h2>
              {updateAvailable ? <span className="bk-count">+{updateCount}</span> : null}
            </div>
            <div className="bk-panel__body">
              <ul className="bk-rows">
                <li className="bk-row">
                  <span className="bk-row__label">Beekiri Core</span>
                  <span className="bk-row__value">
                    <strong>v{status.coreVersion}</strong>
                    <span className="bk-badge">{status.channel}</span>
                    {updateAvailable && updates?.latestVersion ? (
                      <span className="bk-badge is-update">
                        → v{updates.latestVersion}
                      </span>
                    ) : null}
                  </span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Node.js</span>
                  <span className="bk-row__value">{status.nodeVersion}</span>
                </li>
              </ul>

              <div className="bk-actions">
                <button
                  type="button"
                  className="button button-primary"
                  onClick={() => void checkUpdates()}
                  disabled={coreUpdate.checking}
                >
                  {coreUpdate.checking ? 'Checking…' : 'Check for updates'}
                </button>
              </div>

              {updates && !updateAvailable ? (
                <div className="bk-help">
                  <p style={{ margin: 0 }}>
                    <strong>Up to date (v{updates.currentVersion}).</strong> This site is running
                    the latest known Beekiri Core.
                  </p>
                  <ol>
                    <li>
                      When 996agency publishes a new release, a <strong>+1</strong> badge appears
                      on Settings and Beekiri Core.
                    </li>
                    <li>
                      Update safely: back up the database and <code>.env</code>, then pull or
                      download the install ZIP from{' '}
                      <a
                        href="https://github.com/996agency/beekiri-install"
                        target="_blank"
                        rel="noreferrer"
                      >
                        996agency/beekiri-install
                      </a>
                      .
                    </li>
                    <li>
                      Run <code>pnpm install</code>, <code>pnpm db:migrate</code>, rebuild, and
                      restart — your content and media stay on this site.
                    </li>
                    <li>Come back here and confirm the new core version.</li>
                  </ol>
                </div>
              ) : null}

              {updates && updateAvailable ? (
                <div style={{ marginTop: 14 }}>
                  {updates.releaseUrl && (
                    <p style={{ margin: '0 0 8px' }}>
                      <a href={updates.releaseUrl} target="_blank" rel="noreferrer">
                        View release v{updates.latestVersion}
                      </a>
                    </p>
                  )}
                  <ol className="bk-steps">
                    {updates.updateSteps.map((step) => (
                      <li key={step}>{step}</li>
                    ))}
                  </ol>
                </div>
              ) : null}
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
