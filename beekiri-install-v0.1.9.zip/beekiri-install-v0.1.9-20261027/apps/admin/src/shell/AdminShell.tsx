import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import type { Icon } from '@phosphor-icons/react';
import {
  ArrowSquareOut,
  FileText,
  GearSix,
  Images,
  List,
  NotePencil,
  PaintBrush,
  PuzzlePiece,
  SquaresFour,
  Stack,
  Users,
  X,
} from '@phosphor-icons/react';
import '../styles/wp/admin.css';
import './admin-shell.css';
import { useAuth } from '../auth/AuthContext';
import { useCoreUpdate } from '../core/CoreUpdateContext';
import { BrandMark } from '../components/BrandMark';
import { AdminSpotlightSearch } from '../components/AdminSpotlightSearch';
import { LighthouseToolbar } from '../components/LighthouseToolbar';
import { SiteFavicon } from '../components/SiteFavicon';

const LIVE_SITE = import.meta.env.VITE_APP_URL ?? 'http://127.0.0.1:8789';
/** Fallback if updates API has not loaded yet — keep in sync with root package.json. */
const FALLBACK_VERSION = '0.1.9';

type MenuChild = {
  label: string;
  to: string;
};

type MenuItem = {
  label: string;
  to: string;
  icon: Icon;
  disabled?: boolean;
  children?: MenuChild[];
};

type MenuGroup = {
  /** Section label shown above the group. Omit for unlabeled top items. */
  label?: string;
  items: MenuItem[];
};

const FIELDS_CHILDREN: MenuChild[] = [
  { label: 'Field Groups', to: '/admin/fields' },
  { label: 'Post Types', to: '/admin/fields/post-types' },
  { label: 'Taxonomies', to: '/admin/fields/taxonomies' },
  { label: 'Options Pages', to: '/admin/fields/options-pages' },
  { label: 'Settings', to: '/admin/fields/settings' },
  { label: 'Tools', to: '/admin/fields/tools' },
];

const APPEARANCE_CHILDREN: MenuChild[] = [
  { label: 'Themes', to: '/admin/appearance' },
  { label: 'Header', to: '/admin/appearance/header' },
  { label: 'Footer', to: '/admin/appearance/footer' },
  { label: 'Templates', to: '/admin/appearance/templates' },
];

const MENU_GROUPS: MenuGroup[] = [
  {
    items: [{ label: 'Dashboard', to: '/admin', icon: SquaresFour }],
  },
  {
    label: 'Content',
    items: [
      { label: 'Posts', to: '/admin/posts', icon: NotePencil },
      { label: 'Pages', to: '/admin/pages', icon: FileText },
      { label: 'Media', to: '/admin/media', icon: Images },
    ],
  },
  {
    label: 'Admin',
    items: [
      {
        label: 'Backend Fields',
        to: '/admin/fields',
        icon: Stack,
        children: FIELDS_CHILDREN,
      },
      { label: 'Users', to: '/admin/users', icon: Users },
      {
        label: 'Appearance',
        to: '/admin/appearance',
        icon: PaintBrush,
        children: APPEARANCE_CHILDREN,
      },
      { label: 'Extensions', to: '/admin/extensions', icon: PuzzlePiece, disabled: true },
      { label: 'Settings', to: '/admin/settings', icon: GearSix },
    ],
  },
];

function pathMatches(pathname: string, to: string) {
  if (to === '/admin') return pathname === '/admin';
  if (to === '/admin/fields') {
    if (pathname === '/admin/fields' || pathname === '/admin/fields/') return true;
    // Field group editor: /admin/fields/new, /admin/fields/:id
    const sub = pathname.match(/^\/admin\/fields\/([^/]+)\/?$/)?.[1];
    return !!sub && !['post-types', 'taxonomies', 'options-pages', 'settings', 'tools'].includes(sub);
  }
  if (to === '/admin/appearance') {
    return pathname === '/admin/appearance' || pathname === '/admin/appearance/';
  }
  return pathname === to || pathname.startsWith(`${to}/`);
}

function sectionOpen(pathname: string, item: MenuItem) {
  if (!item.children?.length) return false;
  return pathname === item.to || pathname.startsWith(`${item.to}/`);
}

export function AdminShell({ children }: { children: React.ReactNode }) {
  const auth = useAuth();
  const location = useLocation();
  const { updateCount, updateAvailable, updates } = useCoreUpdate();
  const version = updates?.currentVersion ?? FALLBACK_VERSION;
  const [menuOpen, setMenuOpen] = useState(false);
  const [isNarrow, setIsNarrow] = useState(
    () => typeof window !== 'undefined' && window.matchMedia('(max-width: 960px)').matches,
  );

  useEffect(() => {
    document.body.classList.add('beekiri-admin');
    return () => document.body.classList.remove('beekiri-admin');
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const mq = window.matchMedia('(max-width: 960px)');
    const onChange = () => {
      setIsNarrow(mq.matches);
      if (!mq.matches) setMenuOpen(false);
    };
    onChange();
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenuOpen(false);
    };
    document.addEventListener('keydown', onKey);
    document.body.classList.add('bk-menu-open');
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.classList.remove('bk-menu-open');
    };
  }, [menuOpen]);

  return (
    <div className="beekiri-admin" style={{ minHeight: '100%' }}>
      <SiteFavicon />
      <div id="beekiri-admin" className={menuOpen ? 'is-menu-open' : undefined}>
        <button
          type="button"
          className="bk-menu-backdrop"
          aria-label="Close menu"
          tabIndex={menuOpen ? 0 : -1}
          onClick={() => setMenuOpen(false)}
        />
        <div
          id="adminmenumain"
          role="navigation"
          aria-label="Main menu"
          {...(isNarrow && !menuOpen ? { inert: true } : {})}
        >
          <div className="bk-menu-drawer-head">
            <Link
              to="/admin"
              className="bk-menu-drawer-brand"
              title="Beekiri"
              onClick={() => setMenuOpen(false)}
            >
              <BrandMark size={22} />
              <span className="bk-menu-name">Beekiri</span>
            </Link>
            <button
              type="button"
              className="bk-menu-close"
              aria-label="Close menu"
              onClick={() => setMenuOpen(false)}
            >
              <X size={20} weight="regular" aria-hidden />
            </button>
          </div>
          <ul id="adminmenu">
            <li className="bk-menu-brand">
              <Link to="/admin" className="ab-item" title="Beekiri">
                <BrandMark size={22} />
                <span className="bk-menu-name">Beekiri</span>
              </Link>
            </li>
            <li>
              <a
                className="ab-item"
                href={LIVE_SITE}
                target="_blank"
                rel="noreferrer"
                title="Open live public site"
              >
                <ArrowSquareOut size={18} weight="regular" className="bk-menu-icon" aria-hidden />
                <span className="bk-menu-name">View site</span>
              </a>
            </li>
            <li className="bk-menu-sep" aria-hidden="true" />
            {MENU_GROUPS.map((group, groupIndex) => (
              <li key={group.label ?? `group-${groupIndex}`} className="bk-menu-group">
                {group.label ? (
                  <p className="bk-menu-label" id={`bk-menu-${group.label.toLowerCase()}`}>
                    {group.label}
                  </p>
                ) : null}
                <ul
                  className="bk-menu-group__list"
                  aria-labelledby={
                    group.label ? `bk-menu-${group.label.toLowerCase()}` : undefined
                  }
                >
                  {group.items.map((item) => {
                    const open = sectionOpen(location.pathname, item);
                    const current = item.children?.length
                      ? open
                      : pathMatches(location.pathname, item.to);
                    const showUpdateBadge = item.to === '/admin/settings' && updateAvailable;
                    const Icon = item.icon;
                    return (
                      <li
                        key={item.to}
                        className={[
                          current ? 'current' : '',
                          open ? 'wp-has-current-submenu' : '',
                          item.children?.length ? 'wp-has-submenu' : '',
                        ]
                          .filter(Boolean)
                          .join(' ') || undefined}
                      >
                        {item.disabled ? (
                          <a
                            className="disabled"
                            href={item.to}
                            title="Extensions coming later"
                            onClick={(e) => e.preventDefault()}
                          >
                            <Icon
                              size={18}
                              weight="regular"
                              className="bk-menu-icon"
                              aria-hidden
                            />
                            <span className="bk-menu-name">{item.label}</span>
                          </a>
                        ) : (
                          <Link
                            to={item.to}
                            aria-current={
                              item.children?.length
                                ? pathMatches(location.pathname, item.to)
                                  ? 'page'
                                  : undefined
                                : current
                                  ? 'page'
                                  : undefined
                            }
                            title={
                              showUpdateBadge && updates?.latestVersion
                                ? `Beekiri Core v${updates.latestVersion} available`
                                : undefined
                            }
                          >
                            <Icon
                              size={18}
                              weight="regular"
                              className="bk-menu-icon"
                              aria-hidden
                            />
                            <span className="bk-menu-name">{item.label}</span>
                            {showUpdateBadge ? (
                              <span className="bk-count">+{updateCount}</span>
                            ) : null}
                          </Link>
                        )}
                        {item.children?.length && open ? (
                          <ul className="bk-menu-submenu" aria-label={`${item.label} submenu`}>
                            {item.children.map((child) => {
                              const childCurrent = pathMatches(location.pathname, child.to);
                              return (
                                <li
                                  key={child.to}
                                  className={childCurrent ? 'current' : undefined}
                                >
                                  <Link
                                    to={child.to}
                                    aria-current={childCurrent ? 'page' : undefined}
                                  >
                                    <span className="bk-menu-name">{child.label}</span>
                                  </Link>
                                </li>
                              );
                            })}
                          </ul>
                        ) : null}
                      </li>
                    );
                  })}
                </ul>
              </li>
            ))}
          </ul>

          <div className="bk-menu-version" aria-label="Beekiri version">
            <span className="bk-menu-version__label">Beekiri Core</span>
            <span className="bk-menu-version__value">v{version}</span>
            <span className="bk-menu-version__meta">
              by 996agency · proprietary · licensed use only
            </span>
          </div>
        </div>
        <div id="bk-content">
          <div id="bk-toolbar" role="navigation" aria-label="Toolbar">
            <button
              type="button"
              className="bk-menu-toggle"
              aria-label={menuOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={menuOpen}
              aria-controls="adminmenumain"
              onClick={() => setMenuOpen((open) => !open)}
            >
              {menuOpen ? (
                <X size={20} weight="regular" aria-hidden />
              ) : (
                <List size={20} weight="regular" aria-hidden />
              )}
            </button>
            <LighthouseToolbar />
            <AdminSpotlightSearch />
            <span className="spacer" />
            <span className="ab-item bk-toolbar-user">
              <BrandMark size={20} title={auth.user?.displayName ?? 'User'} />
              <span className="bk-toolbar-user__name">{auth.user?.displayName}</span>
            </span>
            <button
              type="button"
              className="ab-item bk-toolbar-logout"
              onClick={() => void auth.logout()}
            >
              Sign out
            </button>
          </div>
          <div id="bk-body">{children}</div>
        </div>
      </div>
    </div>
  );
}
