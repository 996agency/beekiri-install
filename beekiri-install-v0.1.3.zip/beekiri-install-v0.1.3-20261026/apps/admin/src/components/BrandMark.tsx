type Props = {
  size?: number;
  className?: string;
  title?: string;
};

/** Default Beekiri bee mark (from BeeManagement brand assets). */
export function BrandMark({ size = 56, className, title = 'Beekiri' }: Props) {
  return (
    <img
      src="/beekiri-logo.png"
      alt={title}
      width={size}
      height={size}
      className={className}
      decoding="async"
      style={{
        width: size,
        height: size,
        borderRadius: Math.round(size * 0.22),
        objectFit: 'cover',
        display: 'block',
      }}
    />
  );
}
