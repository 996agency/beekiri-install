import { FormEvent, useEffect, useState } from 'react';
import { api, ApiError } from '../api/client';
import { useCoreUpdate } from '../core/CoreUpdateContext';

type Tab = 'general' | 'core';

type SiteSettings = {
  id: string;
  title: string;
  tagline: string;
  language: string;
  blogPublic: boolean;
};

type SystemStatus = {
  api: { ok: boolean; label: string };
  database: { ok: boolean; label: string };
  uptimeSeconds: number;
  nodeVersion: string;
  environment: string;
  coreVersion: string;
  channel: string;
  checkedAt: string;
};

function formatUptime(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  if (m < 60) return `${m}m ${s}s`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  if (h < 24) return `${h}h ${rm}m`;
  const d = Math.floor(h / 24);
  return `${d}d ${h % 24}h`;
}

function StatusValue({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span className={`bk-status ${ok ? 'is-ok' : 'is-down'}`}>
      <span className="bk-status__dot" aria-hidden />
      {label}
    </span>
  );
}

export function SettingsPage() {
  const coreUpdate = useCoreUpdate();
  const [tab, setTab] = useState<Tab>('core');
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const updates = coreUpdate.updates;
  const updateAvailable = coreUpdate.updateAvailable;
  const updateCount = coreUpdate.updateCount;

  const loadGeneral = async () => {
    const s = await api<SiteSettings>('/api/site/settings');
    setSettings(s);
  };

  const loadCore = async () => {
    const s = await api<SystemStatus>('/api/system/status');
    setStatus(s);
  };

  useEffect(() => {
    setError(null);
    setNotice(null);
    if (tab === 'general') {
      loadGeneral().catch((e) =>
        setError(e instanceof ApiError ? e.message : 'Could not load settings'),
      );
    } else {
      loadCore().catch((e) =>
        setError(e instanceof ApiError ? e.message : 'Could not load core status'),
      );
      // Real-time check whenever Core tab opens
      void coreUpdate.refresh();
    }
  }, [tab]);

  const refreshStatus = async () => {
    setRefreshing(true);
    setError(null);
    try {
      await loadCore();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Could not refresh status');
    } finally {
      setRefreshing(false);
    }
  };

  const saveGeneral = async (e: FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const saved = await api<SiteSettings>('/api/site/settings', {
        method: 'PATCH',
        json: {
          title: settings.title,
          tagline: settings.tagline,
          blogPublic: settings.blogPublic,
        },
      });
      setSettings(saved);
      setNotice('Settings saved.');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Save failed');
    } finally {
      setBusy(false);
    }
  };

  const checkUpdates = async () => {
    setError(null);
    setNotice(null);
    const u = await coreUpdate.refresh();
    if (!u) {
      setError('Update check failed');
      return;
    }
    setNotice(u.message);
  };

  return (
    <div className="wrap">
      <h1>
        Settings
        {updateCount > 0 ? (
          <span className="bk-count" aria-label={`${updateCount} update available`}>
            +{updateCount}
          </span>
        ) : null}
      </h1>

      <nav className="bk-tabs" aria-label="Settings sections">
        {(
          [
            ['core', 'Beekiri Core'],
            ['general', 'General'],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            className={`bk-tabs__item${tab === id ? ' is-active' : ''}`}
            onClick={() => setTab(id)}
          >
            {label}
            {id === 'core' && updateCount > 0 ? (
              <span className="bk-count">+{updateCount}</span>
            ) : null}
          </button>
        ))}
      </nav>

      {error && (
        <div className="beekiri-notice is-error">
          <p>{error}</p>
        </div>
      )}
      {notice && !updateAvailable && (
        <div className="beekiri-notice is-success">
          <p>{notice}</p>
        </div>
      )}

      {tab === 'general' && settings && (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">General</h2>
          </div>
          <div className="bk-panel__body">
            <form onSubmit={saveGeneral}>
              <table className="form-table">
                <tbody>
                  <tr>
                    <th scope="row">
                      <label htmlFor="blogname">Site title</label>
                    </th>
                    <td>
                      <input
                        id="blogname"
                        className="regular-text"
                        value={settings.title}
                        onChange={(e) => setSettings({ ...settings, title: e.target.value })}
                        required
                      />
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="blogdescription">Tagline</label>
                    </th>
                    <td>
                      <input
                        id="blogdescription"
                        className="regular-text"
                        value={settings.tagline}
                        onChange={(e) => setSettings({ ...settings, tagline: e.target.value })}
                      />
                      <p className="description">Shown on the public landing page.</p>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">Search visibility</th>
                    <td>
                      <label>
                        <input
                          type="checkbox"
                          checked={settings.blogPublic}
                          onChange={(e) =>
                            setSettings({ ...settings, blogPublic: e.target.checked })
                          }
                        />{' '}
                        Allow search engines to index this site
                      </label>
                    </td>
                  </tr>
                </tbody>
              </table>
              <p className="submit">
                <button type="submit" className="button button-primary" disabled={busy}>
                  {busy ? 'Saving…' : 'Save changes'}
                </button>
              </p>
            </form>
          </div>
        </div>
      )}

      {tab === 'core' && status && (
        <div className="bk-stack">
          {updateAvailable && updates?.latestVersion ? (
            <div className="beekiri-notice is-update" role="status">
              <p>
                You have a new update — Beekiri Core{' '}
                <strong>v{updates.latestVersion}</strong> is available. You are on{' '}
                <strong>v{updates.currentVersion}</strong>.
              </p>
            </div>
          ) : null}

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Status</h2>
              <button
                type="button"
                className="button"
                onClick={() => void refreshStatus()}
                disabled={refreshing}
              >
                {refreshing ? 'Refreshing…' : 'Refresh'}
              </button>
            </div>
            <div className="bk-panel__body">
              <ul className="bk-rows">
                <li className="bk-row">
                  <span className="bk-row__label">API server</span>
                  <span className="bk-row__value">
                    <StatusValue ok={status.api.ok} label={status.api.label} />
                  </span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Database</span>
                  <span className="bk-row__value">
                    <StatusValue ok={status.database.ok} label={status.database.label} />
                  </span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Uptime</span>
                  <span className="bk-row__value">{formatUptime(status.uptimeSeconds)}</span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Environment</span>
                  <span className="bk-row__value">{status.environment}</span>
                </li>
              </ul>
            </div>
          </section>

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Version</h2>
              {updateAvailable ? <span className="bk-count">+{updateCount}</span> : null}
            </div>
            <div className="bk-panel__body">
              <ul className="bk-rows">
                <li className="bk-row">
                  <span className="bk-row__label">Beekiri Core</span>
                  <span className="bk-row__value">
                    <strong>v{status.coreVersion}</strong>
                    <span className="bk-badge">{status.channel}</span>
                    {updateAvailable && updates?.latestVersion ? (
                      <span className="bk-badge is-update">
                        → v{updates.latestVersion}
                      </span>
                    ) : null}
                  </span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Node.js</span>
                  <span className="bk-row__value">{status.nodeVersion}</span>
                </li>
              </ul>

              <div className="bk-actions">
                <button
                  type="button"
                  className="button button-primary"
                  onClick={() => void checkUpdates()}
                  disabled={coreUpdate.checking}
                >
                  {coreUpdate.checking ? 'Checking…' : 'Check for updates'}
                </button>
              </div>

              {updates && (
                <div style={{ marginTop: 14 }}>
                  {!updateAvailable ? (
                    <p className="bk-muted">{updates.message}</p>
                  ) : (
                    <>
                      {updates.releaseUrl && (
                        <p style={{ margin: '0 0 8px' }}>
                          <a href={updates.releaseUrl} target="_blank" rel="noreferrer">
                            View release v{updates.latestVersion}
                          </a>
                        </p>
                      )}
                      <ol className="bk-steps">
                        {updates.updateSteps.map((step) => (
                          <li key={step}>{step}</li>
                        ))}
                      </ol>
                    </>
                  )}
                </div>
              )}
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
