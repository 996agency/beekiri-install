import { FormEvent, useState } from 'react';
import { Link } from 'react-router-dom';
import '@beekiri/ui-wp/install.css';
import { api, ApiError } from '../api/client';
import { BrandMark } from '../components/BrandMark';

export function LostPasswordScreen() {
  const [userLogin, setUserLogin] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const [devLink, setDevLink] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setMessage(null);
    setDevLink(null);
    try {
      const res = await api<{ message: string; devResetLink?: string }>('/api/auth/lost-password', {
        json: { userLogin },
      });
      setMessage(res.message);
      if (res.devResetLink) setDevLink(res.devResetLink);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Request failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bk-install">
      <div className="bk-install__shell">
        <header className="bk-install__brand">
          <Link to="/login" className="bk-install__mark">
            <BrandMark size={64} />
          </Link>
          <p className="bk-install__product">Beekiri</p>
        </header>

        <main className="bk-install__card">
          <h1 className="bk-install__title">Reset password</h1>
          <p className="bk-install__subtitle">
            Enter your username or email. If an account exists, we&apos;ll send reset instructions.
          </p>

          {error && (
            <div className="bk-install__alert" role="alert">
              {error}
            </div>
          )}
          {message && (
            <div className="bk-install__status is-ok" role="status">
              <span className="bk-install__status-dot" />
              <span>
                {message}
                {devLink && (
                  <>
                    <br />
                    <a href={devLink}>Open reset link (development)</a>
                  </>
                )}
              </span>
            </div>
          )}

          <form onSubmit={onSubmit}>
            <div className="bk-install__field">
              <label htmlFor="user_login">Username or email</label>
              <input
                type="text"
                id="user_login"
                required
                value={userLogin}
                onChange={(e) => setUserLogin(e.target.value)}
              />
            </div>
            <div className="bk-install__actions bk-install__actions--spread">
              <Link to="/login" className="bk-install__btn bk-install__btn--ghost">
                Back to sign in
              </Link>
              <button
                type="submit"
                className="bk-install__btn bk-install__btn--primary"
                disabled={busy}
              >
                {busy ? 'Sending…' : 'Send link'}
              </button>
            </div>
          </form>
        </main>
      </div>
    </div>
  );
}
