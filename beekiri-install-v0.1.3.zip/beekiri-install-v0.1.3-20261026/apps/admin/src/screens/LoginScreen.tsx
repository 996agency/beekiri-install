import { FormEvent, useState } from 'react';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import '@beekiri/ui-wp/install.css';
import { useAuth } from '../auth/AuthContext';
import { ApiError } from '../api/client';
import { BrandMark } from '../components/BrandMark';
import { ResetPasswordScreen } from './ResetPasswordScreen';
import { LostPasswordScreen } from './LostPasswordScreen';

export function LoginScreen() {
  const auth = useAuth();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const action = params.get('action');
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (action === 'lostpassword') return <LostPasswordScreen />;
  if (action === 'rp' || action === 'reset') return <ResetPasswordScreen />;

  if (auth.authenticated) {
    const redirect = params.get('redirect_to') || '/admin';
    return <Navigate to={redirect.startsWith('/') ? redirect : '/admin'} replace />;
  }

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await auth.login(login, password, remember);
      const raw = params.get('redirect_to') || '/admin';
      const redirect = raw.startsWith('/') ? raw : '/admin';
      navigate(redirect, { replace: true });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Invalid username or password.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bk-install">
      <div className="bk-install__shell">
        <header className="bk-install__brand">
          <a
            href="/"
            className="bk-install__mark"
            title="Beekiri"
            onClick={(e) => e.preventDefault()}
          >
            <BrandMark size={64} />
          </a>
          <p className="bk-install__product">Beekiri</p>
        </header>

        <main className="bk-install__card">
          <h1 className="bk-install__title">Sign in</h1>
          <p className="bk-install__subtitle">Access your Beekiri admin workspace.</p>

          {error && (
            <div className="bk-install__alert" role="alert">
              {error}
            </div>
          )}

          <form onSubmit={onSubmit}>
            <div className="bk-install__field">
              <label htmlFor="user_login">Username or email</label>
              <input
                type="text"
                id="user_login"
                autoComplete="username"
                required
                value={login}
                onChange={(e) => setLogin(e.target.value)}
              />
            </div>
            <div className="bk-install__field">
              <label htmlFor="user_pass">Password</label>
              <div className="bk-install__pw">
                <input
                  type={showPw ? 'text' : 'password'}
                  id="user_pass"
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <button
                  type="button"
                  className="bk-install__pw-toggle"
                  onClick={() => setShowPw((v) => !v)}
                >
                  {showPw ? 'Hide' : 'Show'}
                </button>
              </div>
            </div>
            <label className="bk-install__check">
              <input
                type="checkbox"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
              />
              <span>Keep me signed in</span>
            </label>
            <div className="bk-install__actions bk-install__actions--spread">
              <Link to="/lost-password" className="bk-install__btn bk-install__btn--ghost">
                Forgot password?
              </Link>
              <button
                type="submit"
                className="bk-install__btn bk-install__btn--primary"
                disabled={busy}
              >
                {busy ? 'Signing in…' : 'Sign in'}
              </button>
            </div>
          </form>
        </main>

        <p className="bk-install__footer">
          <a href={import.meta.env.VITE_APP_URL ?? 'http://127.0.0.1:8789'}>← Back to site</a>
        </p>
      </div>
    </div>
  );
}
