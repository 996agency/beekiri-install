export function PlaceholderScreen({
  title,
  phase,
  note,
}: {
  title: string;
  phase: string;
  note?: string;
}) {
  return (
    <div className="wrap">
      <h1>{title}</h1>
      <div className="beekiri-notice is-info">
        <p>
          {phase ? (
            <>
              This screen is scheduled for <strong>{phase}</strong>. Navigation is ready so you can
              explore the Beekiri admin layout while features land.
            </>
          ) : (
            'This page is not available.'
          )}
        </p>
        {note && <p>{note}</p>}
      </div>
    </div>
  );
}
