import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import '@beekiri/ui-wp/install.css';
import { api } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { BrandMark } from '../components/BrandMark';

type SitePublic = {
  installed: boolean;
  title?: string;
  tagline?: string;
  blogPublic?: boolean;
};

const LIVE_SITE = import.meta.env.VITE_APP_URL ?? 'http://127.0.0.1:8789';

export function SiteLanding() {
  const auth = useAuth();
  const [site, setSite] = useState<SitePublic | null>(null);

  useEffect(() => {
    api<SitePublic>('/api/site/public')
      .then(setSite)
      .catch(() => setSite({ installed: false }));
  }, []);

  const title = site?.title || 'Beekiri';
  const tagline =
    site?.tagline ||
    'Your site is live in preview. Publish pages, manage content, and grow from the admin.';

  return (
    <div className="bk-install" style={{ justifyContent: 'flex-start', paddingTop: 40 }}>
      <div className="bk-install__shell" style={{ maxWidth: 720 }}>
        <header
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 16,
            marginBottom: 48,
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <BrandMark size={40} />
            <span
              style={{
                fontWeight: 600,
                fontSize: 15,
                letterSpacing: '-0.02em',
                color: '#1d1d1f',
              }}
            >
              {title}
            </span>
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
            <a
              href={LIVE_SITE}
              target="_blank"
              rel="noreferrer"
              className="bk-install__btn bk-install__btn--ghost"
            >
              View site
            </a>
            {auth.authenticated ? (
              <Link to="/admin" className="bk-install__btn bk-install__btn--primary">
                Open admin
              </Link>
            ) : (
              <Link to="/login" className="bk-install__btn bk-install__btn--primary">
                Sign in
              </Link>
            )}
          </div>
        </header>

        <main className="bk-install__card" style={{ padding: '48px 40px' }}>
          <p className="bk-install__product" style={{ marginBottom: 12 }}>
            Site preview
          </p>
          <h1 className="bk-install__title" style={{ fontSize: 40, maxWidth: 520 }}>
            {title}
          </h1>
          <p className="bk-install__subtitle" style={{ fontSize: 17, maxWidth: 480, marginBottom: 32 }}>
            {tagline}
          </p>

          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
            <a
              href={LIVE_SITE}
              target="_blank"
              rel="noreferrer"
              className="bk-install__btn bk-install__btn--primary"
            >
              Open live preview
            </a>
            {auth.authenticated ? (
              <Link to="/admin" className="bk-install__btn bk-install__btn--secondary">
                Go to admin
              </Link>
            ) : (
              <Link to="/login?redirect_to=%2Fadmin" className="bk-install__btn bk-install__btn--secondary">
                Admin sign in
              </Link>
            )}
          </div>

          <div
            className="bk-install__status is-ok"
            style={{ marginTop: 36, marginBottom: 0 }}
          >
            <span className="bk-install__status-dot" />
            <span>
              <strong style={{ color: '#1d1d1f', fontWeight: 600 }}>Public site</strong>
              <br />
              Preview URL: {LIVE_SITE}
              {site?.blogPublic === false
                ? ' · Search indexing is off for this site.'
                : ' · Visible for visitors when deployed.'}
            </span>
          </div>
        </main>

        <p className="bk-install__footer">Beekiri · Landing &amp; preview</p>
      </div>
    </div>
  );
}
