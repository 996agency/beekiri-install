import { FormEvent, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import '@beekiri/ui-wp/install.css';
import { api, ApiError } from '../api/client';
import { BrandMark } from '../components/BrandMark';
import { passwordStrength } from '../util/password';

export function ResetPasswordScreen() {
  const [params] = useSearchParams();
  const token = params.get('key') ?? params.get('token') ?? '';
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const strength = passwordStrength(password);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ message: string }>('/api/auth/reset-password', {
        json: { token, password },
      });
      setMessage(res.message);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Reset failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bk-install">
      <div className="bk-install__shell">
        <header className="bk-install__brand">
          <Link to="/login" className="bk-install__mark">
            <BrandMark size={64} />
          </Link>
          <p className="bk-install__product">Beekiri</p>
        </header>

        <main className="bk-install__card">
          <h1 className="bk-install__title">New password</h1>
          <p className="bk-install__subtitle">Choose a strong password for your account.</p>

          {error && (
            <div className="bk-install__alert" role="alert">
              {error}
            </div>
          )}

          {message ? (
            <div className="bk-install__success">
              <div className="bk-install__success-icon" aria-hidden="true">
                ✓
              </div>
              <p className="bk-install__subtitle">{message}</p>
              <div className="bk-install__actions" style={{ justifyContent: 'center' }}>
                <Link to="/login" className="bk-install__btn bk-install__btn--primary">
                  Sign in
                </Link>
              </div>
            </div>
          ) : (
            <form onSubmit={onSubmit}>
              <div className="bk-install__field">
                <label htmlFor="pass1">Password</label>
                <div className="bk-install__pw">
                  <input
                    id="pass1"
                    type={showPw ? 'text' : 'password'}
                    required
                    minLength={8}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    className="bk-install__pw-toggle"
                    onClick={() => setShowPw((v) => !v)}
                  >
                    {showPw ? 'Hide' : 'Show'}
                  </button>
                </div>
              </div>
              <div className="bk-install__meta">
                <span className={`bk-install__strength ${strength}`}>
                  {password ? `Strength · ${strength}` : 'Use at least 8 characters'}
                </span>
              </div>
              <div className="bk-install__actions">
                <button
                  type="submit"
                  className="bk-install__btn bk-install__btn--primary"
                  disabled={busy || strength === 'weak' || !token}
                >
                  {busy ? 'Saving…' : 'Save password'}
                </button>
              </div>
            </form>
          )}
        </main>
      </div>
    </div>
  );
}
