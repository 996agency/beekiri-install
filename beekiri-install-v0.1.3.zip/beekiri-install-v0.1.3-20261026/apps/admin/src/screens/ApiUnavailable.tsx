type Props = {
  onRetry: () => void;
  detail?: string | null;
};

/** Shown when Admin cannot reach the API — never treated as “not installed”. */
export function ApiUnavailable({ onRetry, detail }: Props) {
  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'grid',
        placeItems: 'center',
        padding: 24,
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
        background: '#f0f0f1',
        color: '#1d2327',
      }}
    >
      <div
        style={{
          width: '100%',
          maxWidth: 440,
          background: '#fff',
          border: '1px solid #c3c4c7',
          borderRadius: 4,
          padding: '28px 24px',
        }}
      >
        <h1 style={{ margin: '0 0 8px', fontSize: 22, fontWeight: 600 }}>API not running</h1>
        <p style={{ margin: '0 0 16px', color: '#646970', fontSize: 14, lineHeight: 1.5 }}>
          Your site data is fine. Admin needs the Beekiri API on port <strong>8788</strong>. Start
          the API in this project, then retry — you do not need to reinstall.
        </p>
        {detail ? (
          <p
            style={{
              margin: '0 0 16px',
              padding: '10px 12px',
              background: '#fcf0f1',
              borderLeft: '4px solid #d63638',
              fontSize: 13,
              color: '#1d2327',
            }}
          >
            {detail}
          </p>
        ) : null}
        <p style={{ margin: '0 0 16px', fontSize: 13, color: '#646970', lineHeight: 1.5 }}>
          From the project root:
          <br />
          <code style={{ fontSize: 12 }}>pnpm --filter @beekiri/api dev</code>
          <br />
          Or start all apps: <code style={{ fontSize: 12 }}>pnpm dev</code>
        </p>
        <button
          type="button"
          className="button button-primary"
          onClick={onRetry}
          style={{
            appearance: 'none',
            border: '1px solid #ff9500',
            background: '#ff9500',
            color: '#1d1d1f',
            borderRadius: 3,
            padding: '8px 14px',
            fontSize: 13,
            fontWeight: 600,
            cursor: 'pointer',
          }}
        >
          Retry connection
        </button>
      </div>
    </div>
  );
}
