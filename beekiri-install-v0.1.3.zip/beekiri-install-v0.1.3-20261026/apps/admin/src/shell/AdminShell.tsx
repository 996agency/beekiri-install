import { useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import '@beekiri/ui-wp/admin.css';
import { useAuth } from '../auth/AuthContext';
import { useCoreUpdate } from '../core/CoreUpdateContext';
import { BrandMark } from '../components/BrandMark';

const LIVE_SITE = import.meta.env.VITE_APP_URL ?? 'http://127.0.0.1:8789';

const MENU: { label: string; to: string; disabled?: boolean }[] = [
  { label: 'Dashboard', to: '/admin' },
  { label: 'Posts', to: '/admin/posts' },
  { label: 'Media', to: '/admin/media' },
  { label: 'Pages', to: '/admin/pages' },
  { label: 'Comments', to: '/admin/comments' },
  { label: 'Appearance', to: '/admin/appearance' },
  { label: 'Extensions', to: '/admin/extensions', disabled: true },
  { label: 'Users', to: '/admin/users' },
  { label: 'Tools', to: '/admin/tools' },
  { label: 'Settings', to: '/admin/settings' },
];

export function AdminShell({ children }: { children: React.ReactNode }) {
  const auth = useAuth();
  const location = useLocation();
  const { updateCount, updateAvailable, updates } = useCoreUpdate();

  useEffect(() => {
    document.body.classList.add('beekiri-admin');
    return () => document.body.classList.remove('beekiri-admin');
  }, []);

  return (
    <div className="beekiri-admin" style={{ minHeight: '100%' }}>
      <div id="beekiri-admin">
        <div id="adminmenumain" role="navigation" aria-label="Main menu">
          <ul id="adminmenu">
            <li className="bk-menu-brand">
              <Link to="/admin" className="ab-item" title="Beekiri">
                <BrandMark size={22} />
                <span className="bk-menu-name">Beekiri</span>
              </Link>
            </li>
            <li>
              <a className="ab-item" href="/" title="Site landing / preview">
                <span className="bk-menu-name">Site</span>
              </a>
            </li>
            <li>
              <a
                className="ab-item"
                href={LIVE_SITE}
                target="_blank"
                rel="noreferrer"
                title="Open live public site"
              >
                <span className="bk-menu-name">View site</span>
              </a>
            </li>
            <li className="bk-menu-sep" aria-hidden="true" />
            {MENU.map((item) => {
              const current =
                item.to === '/admin'
                  ? location.pathname === '/admin'
                  : location.pathname.startsWith(item.to);
              const showUpdateBadge = item.to === '/admin/settings' && updateAvailable;
              return (
                <li key={item.to} className={current ? 'current' : undefined}>
                  {item.disabled ? (
                    <a
                      className="disabled"
                      href={item.to}
                      title="Extensions coming later"
                      onClick={(e) => e.preventDefault()}
                    >
                      <span className="bk-menu-name">{item.label}</span>
                    </a>
                  ) : (
                    <Link
                      to={item.to}
                      aria-current={current ? 'page' : undefined}
                      title={
                        showUpdateBadge && updates?.latestVersion
                          ? `Beekiri Core v${updates.latestVersion} available`
                          : undefined
                      }
                    >
                      <span className="bk-menu-name">{item.label}</span>
                      {showUpdateBadge ? (
                        <span className="bk-count">+{updateCount}</span>
                      ) : null}
                    </Link>
                  )}
                </li>
              );
            })}
          </ul>
        </div>
        <div id="bk-content">
          <div id="bk-toolbar" role="navigation" aria-label="Toolbar">
            <span className="spacer" />
            <span
              className="ab-item"
              style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}
            >
              <BrandMark size={20} title={auth.user?.displayName ?? 'User'} />
              {auth.user?.displayName}
            </span>
            <button
              type="button"
              className="ab-item"
              style={{ background: 'transparent', border: 'none', cursor: 'pointer' }}
              onClick={() => void auth.logout()}
            >
              Sign out
            </button>
          </div>
          <div id="bk-body">{children}</div>
          <div id="bk-footer">
            <p>
              Thank you for creating with <strong>Beekiri</strong>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
