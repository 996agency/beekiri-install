import { Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { useCallback, useEffect, useState } from 'react';
import { api, ApiError } from './api/client';
import { useAuth } from './auth/AuthContext';
import { InstallWizard } from './screens/InstallWizard';
import { LoginScreen } from './screens/LoginScreen';
import { LostPasswordScreen } from './screens/LostPasswordScreen';
import { ResetPasswordScreen } from './screens/ResetPasswordScreen';
import { SiteLanding } from './screens/SiteLanding';
import { ApiUnavailable } from './screens/ApiUnavailable';
import { AdminShell } from './shell/AdminShell';
import { Dashboard } from './screens/Dashboard';
import { PlaceholderScreen } from './screens/PlaceholderScreen';
import { SettingsPage } from './screens/SettingsPage';

/** Kill any .php / wp-* URL immediately — product has zero PHP routes. */
function StripLegacyPaths({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const path = location.pathname.toLowerCase();

  if (path.includes('.php') || path.startsWith('/wp-') || path === '/wp-admin') {
    const toAdmin = path.includes('admin') || path.includes('upload') || path.includes('edit');
    return <Navigate to={toAdmin ? '/admin' : '/login'} replace />;
  }

  return <>{children}</>;
}

type InstallState = 'loading' | 'installed' | 'not_installed' | 'api_down';

/**
 * Fresh DB → /install.
 * Installed → public landing at /, auth only for /admin.
 * API down → never treat as “not installed” (would falsely force the installer).
 */
function Gate({ children }: { children: React.ReactNode }) {
  const auth = useAuth();
  const [state, setState] = useState<InstallState>('loading');
  const [apiDetail, setApiDetail] = useState<string | null>(null);
  const [tick, setTick] = useState(0);
  const location = useLocation();

  const checkInstall = useCallback(() => {
    setState('loading');
    setApiDetail(null);
    api<{ installed: boolean }>('/api/install/status')
      .then((s) => setState(s.installed ? 'installed' : 'not_installed'))
      .catch((e) => {
        setState('api_down');
        setApiDetail(
          e instanceof ApiError
            ? e.message
            : e instanceof Error
              ? e.message
              : 'Could not reach the Beekiri API.',
        );
      });
  }, []);

  useEffect(() => {
    checkInstall();
  }, [checkInstall, location.pathname, tick]);

  if (auth.loading || state === 'loading') {
    return (
      <p style={{ padding: 40, fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif' }}>
        Loading…
      </p>
    );
  }

  if (state === 'api_down') {
    return (
      <ApiUnavailable
        detail={apiDetail}
        onRetry={() => setTick((n) => n + 1)}
      />
    );
  }

  if (state === 'not_installed' && !location.pathname.startsWith('/install')) {
    return <Navigate to="/install" replace />;
  }

  if (state === 'installed' && location.pathname.startsWith('/install')) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}

function RequireAuth() {
  const auth = useAuth();
  const location = useLocation();
  if (auth.loading) return <p style={{ padding: 40 }}>Loading…</p>;
  if (!auth.authenticated) {
    const next = encodeURIComponent(location.pathname + location.search);
    return <Navigate to={`/login?redirect_to=${next}`} replace />;
  }
  return (
    <AdminShell>
      <Outlet />
    </AdminShell>
  );
}

export function App() {
  return (
    <StripLegacyPaths>
      <Gate>
        <Routes>
          <Route path="/install/*" element={<InstallWizard />} />
          <Route path="/login" element={<LoginScreen />} />
          <Route path="/lost-password" element={<LostPasswordScreen />} />
          <Route path="/lostpassword" element={<Navigate to="/lost-password" replace />} />
          <Route path="/reset-password" element={<ResetPasswordScreen />} />

          {/* Public landing / preview — no login */}
          <Route path="/" element={<SiteLanding />} />

          <Route path="/admin" element={<RequireAuth />}>
            <Route index element={<Dashboard />} />
            <Route path="posts" element={<PlaceholderScreen title="Posts" phase="Phase 2" />} />
            <Route path="media" element={<PlaceholderScreen title="Media" phase="Phase 2" />} />
            <Route path="pages" element={<PlaceholderScreen title="Pages" phase="Phase 2" />} />
            <Route
              path="comments"
              element={<PlaceholderScreen title="Comments" phase="Phase 2" />}
            />
            <Route
              path="appearance"
              element={<PlaceholderScreen title="Appearance" phase="Phase 5" />}
            />
            <Route
              path="extensions"
              element={
                <PlaceholderScreen
                  title="Extensions"
                  phase="Not available"
                  note="Extensions are not available yet. A Beekiri add-on system may land in a later release."
                />
              }
            />
            <Route path="users" element={<PlaceholderScreen title="Users" phase="Phase 2+" />} />
            <Route path="tools" element={<PlaceholderScreen title="Tools" phase="Later" />} />
            <Route path="settings" element={<SettingsPage />} />
            <Route path="*" element={<PlaceholderScreen title="Not Found" phase="" />} />
          </Route>

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Gate>
    </StripLegacyPaths>
  );
}
