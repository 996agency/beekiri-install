import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { api } from '../api/client';
import { useAuth } from '../auth/AuthContext';

export type UpdateInfo = {
  currentVersion: string;
  latestVersion: string | null;
  updateAvailable: boolean;
  updateCount: number;
  releaseUrl: string | null;
  releaseName: string | null;
  publishedAt: string | null;
  checkedAt: string;
  source: string;
  message: string;
  updateSteps: string[];
};

type CoreUpdateContextValue = {
  updates: UpdateInfo | null;
  checking: boolean;
  updateAvailable: boolean;
  updateCount: number;
  refresh: () => Promise<UpdateInfo | null>;
};

const CoreUpdateContext = createContext<CoreUpdateContextValue | null>(null);

const POLL_MS = 5 * 60 * 1000;

export function CoreUpdateProvider({ children }: { children: React.ReactNode }) {
  const auth = useAuth();
  const [updates, setUpdates] = useState<UpdateInfo | null>(null);
  const [checking, setChecking] = useState(false);

  const refresh = useCallback(async () => {
    if (!auth.authenticated) {
      setUpdates(null);
      return null;
    }
    setChecking(true);
    try {
      const u = await api<UpdateInfo>('/api/system/updates');
      setUpdates(u);
      return u;
    } catch {
      return null;
    } finally {
      setChecking(false);
    }
  }, [auth.authenticated]);

  useEffect(() => {
    if (!auth.authenticated) {
      setUpdates(null);
      return;
    }

    void refresh();
    const id = window.setInterval(() => void refresh(), POLL_MS);
    const onFocus = () => void refresh();
    const onVisibility = () => {
      if (document.visibilityState === 'visible') void refresh();
    };
    window.addEventListener('focus', onFocus);
    document.addEventListener('visibilitychange', onVisibility);

    return () => {
      window.clearInterval(id);
      window.removeEventListener('focus', onFocus);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [auth.authenticated, refresh]);

  const value = useMemo<CoreUpdateContextValue>(
    () => ({
      updates,
      checking,
      updateAvailable: Boolean(updates?.updateAvailable),
      updateCount: updates?.updateCount ?? (updates?.updateAvailable ? 1 : 0),
      refresh,
    }),
    [updates, checking, refresh],
  );

  return (
    <CoreUpdateContext.Provider value={value}>{children}</CoreUpdateContext.Provider>
  );
}

export function useCoreUpdate() {
  const ctx = useContext(CoreUpdateContext);
  if (!ctx) {
    throw new Error('useCoreUpdate must be used within CoreUpdateProvider');
  }
  return ctx;
}
