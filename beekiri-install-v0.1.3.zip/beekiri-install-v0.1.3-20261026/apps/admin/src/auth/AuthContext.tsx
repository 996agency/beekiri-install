import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { PublicUser } from '@beekiri/cms-types';
import { api, setCsrfToken } from '../api/client';

type AuthState = {
  loading: boolean;
  authenticated: boolean;
  user: PublicUser | null;
  refresh: () => Promise<void>;
  login: (login: string, password: string, remember: boolean) => Promise<void>;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [loading, setLoading] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);
  const [user, setUser] = useState<PublicUser | null>(null);

  const refresh = useCallback(async () => {
    const me = await api<{
      authenticated: boolean;
      user?: PublicUser;
      csrfToken?: string;
    }>('/api/auth/me');
    setAuthenticated(me.authenticated);
    setUser(me.user ?? null);
    setCsrfToken(me.csrfToken ?? null);
  }, []);

  useEffect(() => {
    refresh()
      .catch(() => {
        setAuthenticated(false);
        setUser(null);
        setCsrfToken(null);
      })
      .finally(() => setLoading(false));
  }, [refresh]);

  const login = useCallback(async (loginName: string, password: string, remember: boolean) => {
    const res = await api<{ user: PublicUser; csrfToken: string }>('/api/auth/login', {
      json: { login: loginName, password, remember },
    });
    setCsrfToken(res.csrfToken);
    setUser(res.user);
    setAuthenticated(true);
  }, []);

  const logout = useCallback(async () => {
    await api('/api/auth/logout', { method: 'POST' });
    setCsrfToken(null);
    setUser(null);
    setAuthenticated(false);
  }, []);

  return (
    <AuthContext.Provider value={{ loading, authenticated, user, refresh, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth outside provider');
  return ctx;
}
