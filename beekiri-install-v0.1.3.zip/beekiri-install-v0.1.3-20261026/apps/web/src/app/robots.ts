import type { MetadataRoute } from 'next';

const API = process.env.API_URL ?? 'http://127.0.0.1:8788';

export default async function robots(): Promise<MetadataRoute.Robots> {
  let blogPublic = true;
  try {
    const res = await fetch(`${API}/api/site/public`, { next: { revalidate: 60 } });
    if (res.ok) {
      const data = (await res.json()) as { blogPublic?: boolean; installed?: boolean };
      if (data.installed) blogPublic = data.blogPublic !== false;
      else blogPublic = false;
    }
  } catch {
    blogPublic = false;
  }

  if (!blogPublic) {
    return { rules: { userAgent: '*', disallow: '/' } };
  }
  return { rules: { userAgent: '*', allow: '/' } };
}
