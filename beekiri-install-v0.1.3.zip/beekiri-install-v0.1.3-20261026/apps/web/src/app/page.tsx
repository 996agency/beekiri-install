const API = process.env.API_URL ?? 'http://127.0.0.1:8788';

async function getSite() {
  try {
    const res = await fetch(`${API}/api/site/public`, { next: { revalidate: 30 } });
    if (!res.ok) return null;
    return (await res.json()) as {
      installed: boolean;
      title?: string;
      tagline?: string;
      blogPublic?: boolean;
    };
  } catch {
    return null;
  }
}

export default async function HomePage() {
  const site = await getSite();
  const admin = process.env.ADMIN_URL ?? 'http://127.0.0.1:8787';

  return (
    <main style={{ maxWidth: 720, margin: '0 auto', padding: '64px 24px' }}>
      <h1 style={{ fontSize: 48, fontWeight: 400, marginBottom: 8 }}>
        {site?.installed ? site.title : 'Beekiri'}
      </h1>
      <p style={{ fontSize: 18, color: '#444' }}>
        {site?.installed
          ? site.tagline || 'Welcome to your Beekiri site.'
          : 'Your site is almost ready. Open the Beekiri installer to finish setup.'}
      </p>
      <p>
        <a href={admin}>{site?.installed ? 'Open admin' : 'Start installer'}</a>
      </p>
    </main>
  );
}
