import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: {
    default: 'Beekiri',
    template: '%s · Beekiri',
  },
  description:
    'Beekiri helps you publish pages, manage media, and grow your website with a fast, secure content management system.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: 'Georgia, serif', margin: 0, background: '#fff', color: '#111' }}>
        {children}
      </body>
    </html>
  );
}
