import 'reflect-metadata';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  FastifyAdapter,
  NestFastifyApplication,
} from '@nestjs/platform-fastify';
import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import cookie from '@fastify/cookie';
import { AppModule } from '../src/app.module';
import { PrismaClient } from '@prisma/client';
import { clearRateLimits } from '../src/common/rate-limit';

const prisma = new PrismaClient();

async function resetDb() {
  await prisma.passwordResetToken.deleteMany();
  await prisma.session.deleteMany();
  await prisma.auditLog.deleteMany();
  await prisma.user.deleteMany();
  await prisma.siteSettings.deleteMany();
  await prisma.site.deleteMany();
  await prisma.capability.deleteMany();
  await prisma.role.deleteMany();
  await prisma.installationState.deleteMany();
  await prisma.installationState.create({ data: { id: 1, installed: false } });
}

describe('Phase 1 install + auth', () => {
  let app: NestFastifyApplication;

  beforeAll(async () => {
    process.env.NODE_ENV = 'test';
    process.env.SESSION_SECRET = 'test-session-secret-32-characters!!';
    process.env.ADMIN_URL = 'http://127.0.0.1:8787';
    process.env.APP_URL = 'http://127.0.0.1:8789';
    process.env.COOKIE_SECURE = 'false';
    clearRateLimits();
    await resetDb();

    app = await NestFactory.create<NestFastifyApplication>(
      AppModule,
      new FastifyAdapter(),
      { logger: false },
    );
    await app.register(cookie, { secret: process.env.SESSION_SECRET });
    app.setGlobalPrefix('api');
    app.useGlobalPipes(
      new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }),
    );
    await app.init();
    await app.getHttpAdapter().getInstance().ready();
  });

  afterAll(async () => {
    await app.close();
    await prisma.$disconnect();
  });

  it('reports not installed then installs owner', async () => {
    const statusRes = await app.inject({ method: 'GET', url: '/api/install/status' });
    expect(statusRes.statusCode).toBe(200);
    const status = statusRes.json();
    expect(status.installed).toBe(false);
    expect(status.databaseOk).toBe(true);

    const installRes = await app.inject({
      method: 'POST',
      url: '/api/install',
      payload: {
        language: 'en_US',
        siteTitle: 'Test Site',
        username: 'owner',
        password: 'Str0ng!Passw0rd',
        email: 'owner@example.com',
        blogPublic: false,
      },
    });
    expect([200, 201]).toContain(installRes.statusCode);
    expect(installRes.json().ok).toBe(true);

    const again = await app.inject({
      method: 'POST',
      url: '/api/install',
      payload: {
        language: 'en_US',
        siteTitle: 'Other',
        username: 'owner2',
        password: 'Str0ng!Passw0rd',
        email: 'owner2@example.com',
        blogPublic: true,
      },
    });
    expect(again.statusCode).toBeGreaterThanOrEqual(400);

    const concurrent = await Promise.all(
      [1, 2, 3].map((n) =>
        app.inject({
          method: 'POST',
          url: '/api/install',
          payload: {
            language: 'en_US',
            siteTitle: `Race ${n}`,
            username: `race${n}`,
            password: 'Str0ng!Passw0rd',
            email: `race${n}@example.com`,
            blogPublic: true,
          },
        }),
      ),
    );
    expect(concurrent.every((r) => r.statusCode >= 400)).toBe(true);

    const owners = await prisma.user.count({ where: { isOwner: true } });
    expect(owners).toBe(1);
  });

  it('logs in, reaches dashboard, logout invalidates session', async () => {
    clearRateLimits();
    const login = await app.inject({
      method: 'POST',
      url: '/api/auth/login',
      headers: { origin: 'http://127.0.0.1:8787' },
      payload: { login: 'owner', password: 'Str0ng!Passw0rd', remember: false },
    });
    expect([200, 201]).toContain(login.statusCode);
    const setCookie = login.headers['set-cookie'];
    expect(setCookie).toBeTruthy();
    const cookieHeader = Array.isArray(setCookie) ? setCookie[0] : setCookie;
    const sessionPair = String(cookieHeader).split(';')[0]!;
    const csrfToken = login.json().csrfToken as string;

    const dash = await app.inject({
      method: 'GET',
      url: '/api/site/dashboard',
      headers: { cookie: sessionPair },
    });
    expect(dash.statusCode).toBe(200);
    expect(dash.json().title).toBe('Test Site');

    const unauth = await app.inject({ method: 'GET', url: '/api/site/dashboard' });
    expect(unauth.statusCode).toBe(401);

    const logout = await app.inject({
      method: 'POST',
      url: '/api/auth/logout',
      headers: {
        cookie: sessionPair,
        origin: 'http://127.0.0.1:8787',
        'x-csrf-token': csrfToken,
      },
    });
    expect([200, 201]).toContain(logout.statusCode);

    const after = await app.inject({
      method: 'GET',
      url: '/api/site/dashboard',
      headers: { cookie: sessionPair },
    });
    expect(after.statusCode).toBe(401);
  });

  it('rejects bad login with generic error', async () => {
    clearRateLimits();
    const bad = await app.inject({
      method: 'POST',
      url: '/api/auth/login',
      payload: { login: 'owner', password: 'wrong-password-here' },
    });
    expect(bad.statusCode).toBe(401);
    expect(String(bad.json().message)).toMatch(/Invalid username or password/i);
  });
});
