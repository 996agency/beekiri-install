import { Injectable, Logger } from '@nestjs/common';
import { readFileSync, existsSync } from 'fs';
import { join } from 'path';
import { PrismaService } from '../prisma/prisma.service';

export type CoreManifest = {
  name: string;
  coreVersion: string;
  releaseRepo: string;
  minNode: string;
  channel: string;
  notes?: string;
};

export type UpdateCheck = {
  currentVersion: string;
  latestVersion: string | null;
  updateAvailable: boolean;
  updateCount: number;
  releaseUrl: string | null;
  releaseName: string | null;
  publishedAt: string | null;
  checkedAt: string;
  source: 'github' | 'github-tags' | 'manifest-only' | 'error';
  message: string;
  updateSteps: string[];
};

export type SystemStatus = {
  api: { ok: boolean; label: string };
  database: { ok: boolean; label: string };
  uptimeSeconds: number;
  nodeVersion: string;
  environment: string;
  coreVersion: string;
  channel: string;
  checkedAt: string;
};

@Injectable()
export class SystemService {
  private readonly logger = new Logger(SystemService.name);

  constructor(private readonly prisma: PrismaService) {}

  getManifest(): CoreManifest {
    const candidates = [
      join(process.cwd(), 'beekiri.manifest.json'),
      join(process.cwd(), '..', '..', 'beekiri.manifest.json'),
      join(__dirname, '..', '..', '..', '..', 'beekiri.manifest.json'),
    ];
    for (const path of candidates) {
      if (existsSync(path)) {
        try {
          return JSON.parse(readFileSync(path, 'utf8')) as CoreManifest;
        } catch (e) {
          this.logger.warn(`Failed to read manifest at ${path}`);
        }
      }
    }
    return {
      name: 'beekiri-cms',
      coreVersion: process.env.BEEKIRI_CORE_VERSION ?? '0.1.3',
      releaseRepo: process.env.BEEKIRI_RELEASE_REPO ?? '996agency/Beekiri',
      minNode: '20',
      channel: 'stable',
    };
  }

  getVersionInfo() {
    const manifest = this.getManifest();
    return {
      coreVersion: manifest.coreVersion,
      name: manifest.name,
      channel: manifest.channel,
      releaseRepo: manifest.releaseRepo,
      minNode: manifest.minNode,
      nodeVersion: process.version,
      notes: manifest.notes ?? null,
      environment: process.env.NODE_ENV ?? 'development',
    };
  }

  async getStatus(): Promise<SystemStatus> {
    const manifest = this.getManifest();
    let databaseOk = false;
    try {
      await this.prisma.$queryRaw`SELECT 1`;
      databaseOk = true;
    } catch {
      databaseOk = false;
    }

    return {
      api: { ok: true, label: 'Running' },
      database: {
        ok: databaseOk,
        label: databaseOk ? 'Connected' : 'Unavailable',
      },
      uptimeSeconds: Math.floor(process.uptime()),
      nodeVersion: process.version,
      environment: process.env.NODE_ENV ?? 'development',
      coreVersion: manifest.coreVersion,
      channel: manifest.channel,
      checkedAt: new Date().toISOString(),
    };
  }

  private compareSemver(a: string, b: string): number {
    const pa = a.replace(/^v/, '').split('.').map((n) => Number(n) || 0);
    const pb = b.replace(/^v/, '').split('.').map((n) => Number(n) || 0);
    const len = Math.max(pa.length, pb.length);
    for (let i = 0; i < len; i++) {
      const da = pa[i] ?? 0;
      const db = pb[i] ?? 0;
      if (da > db) return 1;
      if (da < db) return -1;
    }
    return 0;
  }

  private githubHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      Accept: 'application/vnd.github+json',
      'User-Agent': 'Beekiri-CMS-Update-Check',
    };
    const token = process.env.BEEKIRI_GITHUB_TOKEN || process.env.GITHUB_TOKEN;
    if (token) headers.Authorization = `Bearer ${token}`;
    return headers;
  }

  private buildResult(opts: {
    currentVersion: string;
    latestVersion: string | null;
    releaseUrl: string | null;
    releaseName: string | null;
    publishedAt: string | null;
    checkedAt: string;
    source: UpdateCheck['source'];
    updateSteps: string[];
    fallbackMessage?: string;
  }): UpdateCheck {
    const updateAvailable = opts.latestVersion
      ? this.compareSemver(opts.latestVersion, opts.currentVersion) > 0
      : false;
    const updateCount = updateAvailable ? 1 : 0;

    let message = opts.fallbackMessage ?? `Up to date (v${opts.currentVersion}).`;
    if (updateAvailable && opts.latestVersion) {
      message = `You have a new update — Beekiri Core v${opts.latestVersion} is available (you are on v${opts.currentVersion}).`;
    }

    return {
      currentVersion: opts.currentVersion,
      latestVersion: opts.latestVersion,
      updateAvailable,
      updateCount,
      releaseUrl: opts.releaseUrl,
      releaseName: opts.releaseName,
      publishedAt: opts.publishedAt,
      checkedAt: opts.checkedAt,
      source: opts.source,
      message,
      updateSteps: opts.updateSteps,
    };
  }

  async checkUpdates(): Promise<UpdateCheck> {
    const manifest = this.getManifest();
    const currentVersion = manifest.coreVersion;
    const repo = manifest.releaseRepo;
    const releasesPage = `https://github.com/${repo}/releases`;
    const updateSteps = [
      'Back up the database and .env file.',
      'Stop the apps briefly.',
      `Pull the latest core (git pull or ZIP from ${releasesPage}).`,
      'Run pnpm install, then pnpm db:migrate.',
      'Build and restart API, admin, and web.',
      'Confirm the new version on this page.',
    ];
    const checkedAt = new Date().toISOString();
    const headers = this.githubHeaders();

    try {
      const res = await fetch(`https://api.github.com/repos/${repo}/releases/latest`, {
        headers,
      });

      if (res.ok) {
        const data = (await res.json()) as {
          tag_name?: string;
          name?: string;
          html_url?: string;
          published_at?: string;
        };
        const latestVersion = (data.tag_name || '').replace(/^v/, '') || null;
        return this.buildResult({
          currentVersion,
          latestVersion,
          releaseUrl: data.html_url ?? releasesPage,
          releaseName: data.name ?? data.tag_name ?? null,
          publishedAt: data.published_at ?? null,
          checkedAt,
          source: 'github',
          updateSteps,
        });
      }

      // No formal Release yet — fall back to newest semver tag.
      const tagsRes = await fetch(
        `https://api.github.com/repos/${repo}/tags?per_page=30`,
        { headers },
      );
      if (tagsRes.ok) {
        const tags = (await tagsRes.json()) as { name?: string }[];
        let latestVersion: string | null = null;
        for (const tag of tags) {
          const ver = (tag.name || '').replace(/^v/, '');
          if (!/^\d+\.\d+/.test(ver)) continue;
          if (!latestVersion || this.compareSemver(ver, latestVersion) > 0) {
            latestVersion = ver;
          }
        }
        return this.buildResult({
          currentVersion,
          latestVersion,
          releaseUrl: latestVersion
            ? `https://github.com/${repo}/releases/tag/v${latestVersion}`
            : releasesPage,
          releaseName: latestVersion ? `v${latestVersion}` : null,
          publishedAt: null,
          checkedAt,
          source: 'github-tags',
          updateSteps,
          fallbackMessage: latestVersion
            ? undefined
            : 'No newer release found. This install is on the current core.',
        });
      }

      return this.buildResult({
        currentVersion,
        latestVersion: null,
        releaseUrl: releasesPage,
        releaseName: null,
        publishedAt: null,
        checkedAt,
        source: 'manifest-only',
        updateSteps,
        fallbackMessage:
          res.status === 404
            ? 'No newer release found. This install is on the current core.'
            : `Update check unavailable (${res.status}).`,
      });
    } catch (e) {
      this.logger.warn(`Update check failed: ${e instanceof Error ? e.message : e}`);
      return this.buildResult({
        currentVersion,
        latestVersion: null,
        releaseUrl: releasesPage,
        releaseName: null,
        publishedAt: null,
        checkedAt,
        source: 'error',
        updateSteps,
        fallbackMessage: 'Could not check for updates right now.',
      });
    }
  }
}
