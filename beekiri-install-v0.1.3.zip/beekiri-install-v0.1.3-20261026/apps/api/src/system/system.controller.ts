import { Controller, Get, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { AuthGuard } from '../auth/auth.guard';
import { CapabilitiesGuard } from '../auth/capabilities.guard';
import { RequireCapabilities } from '../auth/capabilities.decorator';
import { SystemService } from './system.service';

@ApiTags('system')
@Controller('system')
export class SystemController {
  constructor(private readonly system: SystemService) {}

  @Get('version')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  version() {
    return this.system.getVersionInfo();
  }

  @Get('status')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  status() {
    return this.system.getStatus();
  }

  @Get('updates')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  updates() {
    return this.system.checkUpdates();
  }
}
