import { ApiProperty } from '@nestjs/swagger';
import {
  IsBoolean,
  IsEmail,
  IsString,
  Matches,
  MaxLength,
  MinLength,
} from 'class-validator';

export class InstallDto {
  @ApiProperty({ example: 'en_US' })
  @IsString()
  @MinLength(2)
  @MaxLength(20)
  language!: string;

  @ApiProperty({ example: 'My Beekiri Site' })
  @IsString()
  @MinLength(1)
  @MaxLength(200)
  siteTitle!: string;

  @ApiProperty({ example: 'admin' })
  @IsString()
  @MinLength(3)
  @MaxLength(60)
  @Matches(/^[a-zA-Z0-9._-]+$/, {
    message: 'Username may only contain letters, numbers, ., -, _',
  })
  username!: string;

  @ApiProperty()
  @IsString()
  @MinLength(8)
  @MaxLength(128)
  password!: string;

  @ApiProperty()
  @IsEmail()
  email!: string;

  @ApiProperty({ description: 'Allow search engines to index' })
  @IsBoolean()
  blogPublic!: boolean;
}
