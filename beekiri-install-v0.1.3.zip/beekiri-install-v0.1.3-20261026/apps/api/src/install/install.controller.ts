import { Body, Controller, Get, Post, Req } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import type { FastifyRequest } from 'fastify';
import { InstallService } from './install.service';
import { InstallDto } from './install.dto';

@ApiTags('install')
@Controller('install')
export class InstallController {
  constructor(private readonly install: InstallService) {}

  @Get('status')
  getStatus() {
    return this.install.getStatus();
  }

  @Post()
  async run(@Body() body: InstallDto, @Req() req: FastifyRequest) {
    return this.install.install(body, {
      ip: req.ip,
      userAgent: req.headers['user-agent'],
    });
  }
}
