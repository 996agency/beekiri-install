import { Module } from '@nestjs/common';
import { SiteController } from './site.controller';
import { AuthModule } from '../auth/auth.module';

@Module({
  imports: [AuthModule],
  controllers: [SiteController],
})
export class SiteModule {}
