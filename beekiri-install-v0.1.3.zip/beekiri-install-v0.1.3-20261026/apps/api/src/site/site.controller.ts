import { Body, Controller, Get, NotFoundException, Patch, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { PrismaService } from '../prisma/prisma.service';
import { AuthGuard } from '../auth/auth.guard';
import { CapabilitiesGuard } from '../auth/capabilities.guard';
import { RequireCapabilities } from '../auth/capabilities.decorator';
import { UpdateSiteSettingsDto } from './site.dto';

@ApiTags('site')
@Controller('site')
export class SiteController {
  constructor(private readonly prisma: PrismaService) {}

  @Get('public')
  async publicSite() {
    const site = await this.prisma.site.findFirst({
      include: { settings: true },
      orderBy: { createdAt: 'asc' },
    });
    if (!site) {
      return { installed: false };
    }
    return {
      installed: true,
      id: site.id,
      title: site.title,
      tagline: site.tagline,
      language: site.language,
      blogPublic: site.settings?.blogPublic ?? true,
    };
  }

  @Get('dashboard')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('read')
  async dashboard() {
    const site = await this.prisma.site.findFirst({
      include: { settings: true, _count: { select: { users: true } } },
    });
    return {
      title: site?.title ?? 'Beekiri',
      atAGlance: {
        users: site?._count.users ?? 0,
        posts: 0,
        pages: 0,
        comments: 0,
      },
      note: 'Content counts will populate in Phase 2.',
    };
  }

  @Get('settings')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  async getSettings() {
    const site = await this.prisma.site.findFirst({
      include: { settings: true },
      orderBy: { createdAt: 'asc' },
    });
    if (!site) throw new NotFoundException('Site not found');
    return {
      id: site.id,
      title: site.title,
      tagline: site.tagline,
      language: site.language,
      blogPublic: site.settings?.blogPublic ?? true,
    };
  }

  @Patch('settings')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  async updateSettings(@Body() body: UpdateSiteSettingsDto) {
    const site = await this.prisma.site.findFirst({
      include: { settings: true },
      orderBy: { createdAt: 'asc' },
    });
    if (!site) throw new NotFoundException('Site not found');

    const updated = await this.prisma.site.update({
      where: { id: site.id },
      data: {
        title: body.title ?? undefined,
        tagline: body.tagline ?? undefined,
        settings: {
          upsert: {
            create: {
              blogPublic: body.blogPublic ?? true,
            },
            update: {
              blogPublic: body.blogPublic ?? undefined,
            },
          },
        },
      },
      include: { settings: true },
    });

    return {
      id: updated.id,
      title: updated.title,
      tagline: updated.tagline,
      language: updated.language,
      blogPublic: updated.settings?.blogPublic ?? true,
    };
  }
}
