import { Injectable, Logger } from '@nestjs/common';
import nodemailer from 'nodemailer';

@Injectable()
export class MailService {
  private readonly logger = new Logger(MailService.name);
  private lastDevLink: string | null = null;

  getLastDevLink(): string | null {
    return this.lastDevLink;
  }

  async sendMail(opts: { to: string; subject: string; text: string; html?: string }) {
    const host = process.env.SMTP_HOST;
    if (!host) {
      this.logger.warn(`[dev-mail-sink] to=${opts.to} subject=${opts.subject}`);
      this.logger.warn(opts.text);
      const match = opts.text.match(/https?:\/\/\S+/);
      this.lastDevLink = match?.[0] ?? null;
      return { mode: 'dev-sink' as const, previewLink: this.lastDevLink };
    }

    const transporter = nodemailer.createTransport({
      host,
      port: Number(process.env.SMTP_PORT ?? 587),
      secure: false,
      auth:
        process.env.SMTP_USER && process.env.SMTP_PASS
          ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
          : undefined,
    });

    await transporter.sendMail({
      from: process.env.SMTP_FROM ?? 'noreply@localhost',
      to: opts.to,
      subject: opts.subject,
      text: opts.text,
      html: opts.html,
    });
    return { mode: 'smtp' as const };
  }
}
