import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from './prisma/prisma.module';
import { HealthModule } from './health/health.module';
import { InstallModule } from './install/install.module';
import { AuthModule } from './auth/auth.module';
import { SiteModule } from './site/site.module';
import { MailModule } from './mail/mail.module';
import { SystemModule } from './system/system.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    MailModule,
    HealthModule,
    InstallModule,
    AuthModule,
    SiteModule,
    SystemModule,
  ],
})
export class AppModule {}
