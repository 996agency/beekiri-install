import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import {
  FastifyAdapter,
  NestFastifyApplication,
} from '@nestjs/platform-fastify';
import { ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import cookie from '@fastify/cookie';
import cors from '@fastify/cors';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create<NestFastifyApplication>(
    AppModule,
    new FastifyAdapter({ logger: true }),
  );

  const adminUrl = process.env.ADMIN_URL ?? 'http://127.0.0.1:8787';
  const appUrl = process.env.APP_URL ?? 'http://127.0.0.1:8789';

  await app.register(cors, {
    origin: [adminUrl, appUrl],
    credentials: true,
  });
  await app.register(cookie, {
    secret: process.env.SESSION_SECRET ?? 'dev-insecure-session-secret',
  });

  app.setGlobalPrefix('api');
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  const config = new DocumentBuilder()
    .setTitle('Beekiri CMS API')
    .setDescription('Beekiri content management API')
    .setVersion('0.1.0')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document);

  // Default 8788 — never 4000 (LocalWP / Local by Flywheel conflict)
  const port = Number(process.env.PORT ?? 8788);
  await app.listen(port, '0.0.0.0');
}

bootstrap();
