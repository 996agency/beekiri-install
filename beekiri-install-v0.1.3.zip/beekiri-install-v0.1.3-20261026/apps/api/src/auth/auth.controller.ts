import {
  Body,
  Controller,
  Get,
  Post,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import type { FastifyReply, FastifyRequest } from 'fastify';
import { AuthService } from './auth.service';
import {
  LoginDto,
  LostPasswordDto,
  ResetPasswordDto,
} from './auth.dto';
import { AuthGuard, type AuthedRequest } from './auth.guard';

@ApiTags('auth')
@Controller('auth')
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  private setSessionCookie(
    reply: FastifyReply,
    value: string,
    maxAge: number,
  ) {
    const secure = (process.env.COOKIE_SECURE ?? 'false') === 'true';
    reply.setCookie(this.auth.cookieName(), value, {
      path: '/',
      httpOnly: true,
      sameSite: 'lax',
      secure,
      maxAge,
      domain: process.env.COOKIE_DOMAIN || undefined,
    });
  }

  private clearSessionCookie(reply: FastifyReply) {
    reply.clearCookie(this.auth.cookieName(), { path: '/' });
  }

  @Post('login')
  async login(
    @Body() body: LoginDto,
    @Req() req: FastifyRequest,
    @Res({ passthrough: true }) reply: FastifyReply,
  ) {
    const result = await this.auth.login(body, {
      ip: req.ip,
      userAgent: req.headers['user-agent'],
    });
    this.setSessionCookie(reply, result.cookieValue, result.maxAge);
    return {
      user: result.user,
      csrfToken: result.csrfToken,
    };
  }

  @Post('logout')
  @UseGuards(AuthGuard)
  async logout(
    @Req() req: AuthedRequest,
    @Res({ passthrough: true }) reply: FastifyReply,
  ) {
    const raw = req.cookies?.[this.auth.cookieName()];
    await this.auth.logout(raw, { ip: req.ip });
    this.clearSessionCookie(reply);
    return { ok: true };
  }

  @Get('me')
  async me(@Req() req: FastifyRequest) {
    const raw = req.cookies?.[this.auth.cookieName()];
    const session = await this.auth.resolveSession(raw);
    if (!session) return { authenticated: false };
    return {
      authenticated: true,
      user: session.user,
      csrfToken: session.csrfToken,
    };
  }

  @Get('csrf')
  async csrf(@Req() req: FastifyRequest) {
    const raw = req.cookies?.[this.auth.cookieName()];
    const session = await this.auth.resolveSession(raw);
    if (!session) return { csrfToken: null };
    return { csrfToken: session.csrfToken };
  }

  @Post('lost-password')
  lostPassword(@Body() body: LostPasswordDto, @Req() req: FastifyRequest) {
    return this.auth.requestPasswordReset(body, { ip: req.ip });
  }

  @Post('reset-password')
  resetPassword(@Body() body: ResetPasswordDto) {
    return this.auth.resetPassword(body);
  }
}
