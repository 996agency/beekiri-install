import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import type { FastifyReply, FastifyRequest } from 'fastify';
import { AuthService } from './auth.service';
import type { AuthSessionContext } from './auth.types';

export type AuthedRequest = FastifyRequest & {
  auth?: AuthSessionContext;
};

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private readonly auth: AuthService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest<AuthedRequest>();
    const reply = context.switchToHttp().getResponse<FastifyReply>();
    const raw = req.cookies?.[this.auth.cookieName()];
    const session = await this.auth.resolveSession(raw);
    if (!session) {
      throw new UnauthorizedException('You must be logged in.');
    }

    const method = req.method.toUpperCase();
    if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) {
      this.auth.assertOrigin(
        req.headers.origin as string | undefined,
        req.headers.referer as string | undefined,
      );
      const csrf = req.headers[this.auth.csrfHeader()] as string | undefined;
      this.auth.assertCsrf(session, csrf);
    }

    req.auth = session;
    // Touch cookie refresh is handled via idle update in resolveSession
    void reply;
    return true;
  }
}
