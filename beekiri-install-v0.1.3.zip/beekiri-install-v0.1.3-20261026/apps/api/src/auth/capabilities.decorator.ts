import { SetMetadata } from '@nestjs/common';
import type { CapabilitySlug } from '@beekiri/cms-types';

export const CAPABILITIES_KEY = 'capabilities';
export const RequireCapabilities = (...caps: CapabilitySlug[]) =>
  SetMetadata(CAPABILITIES_KEY, caps);
