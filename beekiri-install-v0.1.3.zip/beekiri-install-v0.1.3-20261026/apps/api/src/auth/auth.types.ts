import type { CapabilitySlug, RoleSlug } from '@beekiri/cms-types';

export interface AuthUser {
  id: string;
  username: string;
  email: string;
  displayName: string;
  role: RoleSlug;
  capabilities: CapabilitySlug[];
  isOwner: boolean;
  siteId: string;
}

export interface AuthSessionContext {
  sessionId: string;
  csrfToken: string;
  user: AuthUser;
}
