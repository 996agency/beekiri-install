import { Module } from '@nestjs/common';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { AuthGuard } from './auth.guard';
import { CapabilitiesGuard } from './capabilities.guard';

@Module({
  controllers: [AuthController],
  providers: [AuthService, AuthGuard, CapabilitiesGuard],
  exports: [AuthService, AuthGuard, CapabilitiesGuard],
})
export class AuthModule {}
