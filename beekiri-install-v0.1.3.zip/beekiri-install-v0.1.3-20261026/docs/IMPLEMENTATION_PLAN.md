# Implementation plan

## Goal

WordPress-experience CMS (Beekiri): Node/TypeScript backend, React admin with wp-admin-like UX, Next.js public site. No PHP, no Docker, no WordPress runtime.

## Phases

| Phase | Scope | Status |
|-------|--------|--------|
| 0 | Audit, docs, monorepo, doctor, env | in progress |
| 1 | Schema, installer, auth, sessions, RBAC, admin shell, dashboard | in progress |
| 2 | Posts/pages, taxonomies, media, list/edit screens | not started |
| 3 | Field groups, core fields, location rules | not started |
| 4 | Repeaters, flexible content, advanced fields | not started |
| 5 | Block editor, Next.js rendering, menus, SEO | not started |
| 6 | AI structured generation | not started |
| 7 | Full parity verification, hardening | not started |

## Phase 1 vertical slice (runnable milestone)

1. Prisma models: Site, SiteSettings, User, Role, Capability, Session, AuditLog, PasswordResetToken, InstallationLock.
2. NestJS API: health, install status/run, login/logout/me, CSRF, password reset scaffold, capability guards.
3. Admin SPA: install wizard, login, lost password UI, fixed admin shell + dashboard.
4. Next.js stub reading robots/indexing flag.
5. Automated API tests for install → login → dashboard gate; concurrent install safety.
6. `pnpm doctor`, README, `.env.example`.

## Licensing (summary)

| Component | License notes |
|-----------|----------------|
| WordPress core / Gutenberg packages | GPL-2.0-or-later — usable with compliance |
| ACF / ACF Extended | Proprietary — **do not copy** code/assets; independent reimplementation of UX concepts only |
| Beekiri product branding | Avoid WordPress trademarks; no official affiliation claim |

Full threat model: `SECURITY.md`.

## Next actions after Phase 1

See `PROGRESS.md`. Phase 2 starts with Posts/Pages CRUD and list screens.
