# Reference release pin

## Pinned WordPress reference

| Item | Value | Source |
|------|-------|--------|
| WordPress | **7.1.3** (7.1 branch, 2026-10-06) | https://wordpress.org/download/releases/ |
| Bundled Gutenberg base | **23.6** | https://developer.wordpress.org/block-editor/contributors/versions-in-wordpress/ |
| Standalone Gutenberg plugin (not required) | 24.2.0+ | wordpress.org/plugins/gutenberg |

Admin UX/UI parity targets `wp-admin` / `wp-login.php` / install flow as shipped in WordPress **7.1.3**.

## Local reference instance

No local WordPress PHP instance is bundled in this repository. Visual parity verification (Phase 7) requires either:

1. A local WordPress 7.1.3 install provided by the team, or
2. Reference screenshots at 1440×900, 1280×800, 768×1024, 390×844 for each screen listed in `SCREEN_PARITY.md`.

Until those exist, screens are marked **unverified** for pixel parity even when functionally implemented.

## Package strategy for `@wordpress/*`

Gutenberg packages are GPL-2.0-or-later and may be used. Running the block editor **outside** WordPress requires custom data stores, REST adapters, block registry, and save/render bridges. Phase 1 does **not** load Gutenberg. Phase 5 evaluates `@wordpress/block-editor` against this pin; if blocked, an honest MVP editor ships with gaps tracked in `FEATURE_MATRIX.md`.

## Branding

Product name: **Beekiri CMS**. Do not use WordPress trademarks in product branding or imply official affiliation. Admin chrome may visually echo familiar wp-admin patterns for client continuity; logos and copy use Beekiri / neutral marks unless trademark use is separately authorized.
