# Architecture decisions

## ADR-001: Stack as specified

**Decision:** pnpm workspaces + Turborepo; NestJS (Fastify); React+Vite admin; Next.js App Router web; PostgreSQL + Prisma; no Docker.

**Rationale:** Spec §2. Non-negotiable for this project.

## ADR-002: WordPress reference pin 7.1.3 / Gutenberg 23.6

**Decision:** Pin UX parity to WordPress 7.1.3. See `REFERENCE.md`.

**Rationale:** Spec §1; latest maintained 7.1 series as of 2026-10-26.

## ADR-003: Independent field engine (not ACF Pro)

**Decision:** Implement schema-driven custom fields inspired by ACF UX patterns. Do not copy ACF/ACF Extended proprietary code. Do not brand as “ACF Pro” / “ACF Extended Pro”.

**Rationale:** Licensing and honesty requirements (spec §0, §10).

## ADR-004: Opaque server sessions, not JWTs in localStorage

**Decision:** HttpOnly cookie + DB-backed opaque session tokens; Argon2id passwords; CSRF double-submit/header for state-changing requests.

**Rationale:** Spec §6, §13.

## ADR-005: Installer never collects DB credentials in browser

**Decision:** `DATABASE_URL` comes from `.env`. Installer diagnoses connectivity only.

**Rationale:** Spec §5.

## ADR-006: Content format

**Decision:** Versioned block document JSON for post body + separately typed field values for ACF-style structured data. No unvalidated HTML+config mash.

**Rationale:** Spec §11. Full block editor deferred to Phase 5; Phase 1 uses placeholder content storage on `Post` for future use.

## ADR-007: Plugins menu

**Decision:** Show Plugins menu item disabled with clear copy that PHP WordPress plugins are not supported; JS extension system is future work.

**Rationale:** Spec §7 honesty.

## ADR-008: Redis optional

**Decision:** No Redis required for local Phase 1. Rate limiting uses in-memory store with note for multi-instance production.

**Rationale:** Spec §2.

## ADR-009: Prisma lives under apps/api

**Decision:** Schema/migrations live in `apps/api/prisma` (not a top-level `prisma/` folder). Root scripts delegate via `pnpm --filter @beekiri/api`.

**Rationale:** Keeps Nest + Prisma co-located; matches common Nest monorepo practice while preserving root `pnpm db:migrate` UX from the spec.

## ADR-010: Ports avoid LocalWP

**Decision:** Default ports are Admin **8787**, API **8788**, Web **8789**. Never bind 80, 443, or 4000. `pnpm doctor` fails if those are configured.

**Rationale:** Local by Flywheel (LocalWP) uses nginx on 80/443 and commonly occupies 4000; earlier Beekiri binds on 4000 collided with Local and broke the API.
