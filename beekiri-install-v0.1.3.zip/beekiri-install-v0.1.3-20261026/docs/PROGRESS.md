# Progress ledger

**Last updated:** 2026-10-26  
**Current phase:** Phase 1 milestone **runnable**  
**Next phase:** Phase 2 (Posts/Pages CRUD, media, list/edit screens)

## Completed

### Phase 0
- Environment audit: macOS arm64, Node v24.19.0, pnpm 9.15.0, PostgreSQL 16.14 (Homebrew).
- Pinned WordPress **7.1.3** / Gutenberg **23.6** (`docs/REFERENCE.md`).
- Docs: IMPLEMENTATION_PLAN, FEATURE_MATRIX, SCREEN_PARITY, DECISIONS, SECURITY, PROGRESS.
- Monorepo: pnpm workspaces + Turborepo; apps `admin`, `api`, `web`; packages `cms-types`, `auth`, `ui-wp`, `field-engine`, `layout-engine`, `cms-sdk`, `config`.
- `.env.example`, README (macOS/Windows/Linux), `pnpm doctor` (passed).

### Phase 1
- Prisma schema + migration `20261026090542_init` (Site, settings, User, Role, Capability, Session, PasswordResetToken, AuditLog, InstallationState).
- NestJS (Fastify) API: health, install status/run (transactional lock, single owner), login/logout/me/csrf, lost/reset password (dev mail sink), capability guards, dashboard.
- Security: Argon2id, opaque HttpOnly sessions, CSRF on mutating auth routes, origin checks, in-memory rate limits, generic login errors.
- Admin SPA: WordPress-like installer, login, lost/reset password, fixed admin menu + top bar, dashboard; Plugins disabled with honesty note.
- Next.js public stub + `robots.ts` respecting `blogPublic`.
- Automated tests: `apps/api/test/phase1.install-auth.test.ts` (install, concurrent install blocked, login → dashboard, logout invalidates, bad login) — **passing**.

## Not implemented (honest)

- Phase 2+: posts/pages/media/comments/users/settings CRUD.
- Field engine batches A–D, repeaters, flexible content.
- Gutenberg-like editor; full Next.js templates/preview/menus/SEO.
- AI integration.
- Playwright E2E / visual parity screenshots (no local WP reference captures yet — screens remain **unverified**).
- MFA, Redis, production S3, production SMTP hardening.

## How to run now

```bash
brew services start postgresql@16   # if needed
cp .env.example .env                # if needed
pnpm install
pnpm db:migrate
pnpm doctor
pnpm test
pnpm dev
```

Open http://127.0.0.1:8787 → installer (fresh DB) → login → Dashboard.
(Ports 8787/8788/8789 — not LocalWP’s 80/443/4000.)

## Exact next actions (Phase 2)

1. Extend Prisma: Post, PostRevision, Taxonomy, Term, MediaAsset, etc.
2. Posts/Pages list + edit screens matching WP 7.1.3 columns/actions.
3. Media upload via storage abstraction (local driver).
4. Expand FEATURE_MATRIX / SCREEN_PARITY as screens land.
