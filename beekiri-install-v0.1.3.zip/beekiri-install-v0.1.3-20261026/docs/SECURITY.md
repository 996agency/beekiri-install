# Security model

## Threat model (Phase 1+)

| Threat | Mitigation |
|--------|------------|
| Credential stuffing / brute force | Rate limits on login/reset; generic errors |
| Session fixation | New session id after login; opaque tokens hashed at rest |
| CSRF | SameSite cookies + CSRF token header for mutating requests; origin checks |
| XSS | React escaping; CSP headers; sanitize HTML when rich text lands |
| Authz bypass | Capability checks on API (deny by default), not only UI |
| Installer race | DB advisory/transactional lock; single owner |
| Enumeration | Identical responses for unknown users on login/reset |
| Secret leakage | No passwords in logs; reset tokens hashed; no localStorage auth |
| Upload abuse | Deferred to Phase 2: MIME sniff, size limits, path traversal guards |
| SSRF | Deferred with oEmbed/maps providers |
| AI misuse | Phase 6: no auto-publish, no arbitrary code/SQL, audited proposals |

## Password hashing

Argon2id via `argon2` package with memory/time parameters suitable for interactive login.

## Sessions

- Cookie: `HttpOnly`, `SameSite=Lax` (Strict where feasible), `Secure` in production
- Idle + absolute expiry
- Server-side `Session` rows; logout deletes row

## Capabilities (initial)

Roles: `administrator` (owner bootstrap), `editor`, `author`, `contributor`, `subscriber` — WordPress-equivalent capability sets enforced in API guards.

## Reporting

Document production HTTPS, reverse proxy, backups, and dependency audit before Phase 7 release.
