# Client / site first-run setup

The **installer** (`/install`) is the official first step for **every** Beekiri site — local development, staging, and live client servers. It is not a local-only tool.

## How clients get the code

### A) GitHub (best for updates)

1. Put this project in a **private** GitHub repo (Beekiri-only — not your whole Desktop).
2. Invite the client (or deploy from that repo yourself).
3. They run: `git clone …` then follow root **`INSTALL.md`**.
4. Open admin URL → browser **/install** once.

### B) Install ZIP

On your machine:

```bash
pnpm pack:release
```

This creates `releases/beekiri-install-v….zip` (no `.env`, no `node_modules`).  
Send the zip → client unzips → follows **`START_HERE.txt`** / **`INSTALL.md`** → same browser installer.

Full client steps: **`INSTALL.md`**.

## How it works

1. Deploy Beekiri with an **empty** PostgreSQL database (migrations applied).
2. Open the admin URL (any host you configured in `ADMIN_URL`).
3. Beekiri detects `installed = false` (server-side) and redirects to **`/install`**.
4. Complete language → welcome → site title + owner account → success → login.
5. After install, `/install` is blocked. Login and the admin dashboard are the entry points.

One database = one site install. Each new client should get their **own** database (and usually their own env / host).

## New client checklist

```bash
# 1) New empty database (example name)
createdb beekiri_client_acme

# 2) Point this deployment at that database
#    DATABASE_URL=postgresql://USER@HOST:5432/beekiri_client_acme?schema=public
#    ADMIN_URL=https://admin.acme.example
#    APP_URL=https://www.acme.example
#    API_URL=https://api.acme.example
#    SESSION_SECRET=...   # unique per client
#    CSRF_SECRET=...

# 3) Migrate + start
pnpm db:migrate
pnpm doctor
pnpm build && pnpm --filter @beekiri/api start   # or your process manager

# 4) Client opens ADMIN_URL → installer runs once
```

Helper (local/agency machines with Homebrew Postgres):

```bash
pnpm client:prep acme
```

This creates `beekiri_client_acme` (if missing) and prints the `DATABASE_URL` to use.

## Rules

- Do **not** skip the installer by seeding an owner by hand unless you know why.
- Do **not** reuse one installed database for a second client — create a new DB / deploy.
- Database credentials stay in server env; the browser wizard never asks for them.
- Re-running install on an already-installed DB is rejected by the API (safe for all clients).
