# Feature matrix

Statuses: `not started` | `in progress` | `implemented` | `tested` | `parity verified`

| Area | Feature | Status | Notes |
|------|---------|--------|-------|
| Setup | First-run installer | tested | Phase 1 API + UI |
| Setup | Installer idempotency / lock | tested | Concurrent install blocked |
| Auth | Login username/email | tested | Phase 1 |
| Auth | Argon2id + sessions | tested | Phase 1 |
| Auth | CSRF + rate limit | tested | Phase 1 |
| Auth | Lost password email | implemented | Dev sink; SMTP when configured |
| Auth | MFA TOTP | not started | Later |
| Admin | Shell (menu + top bar) | implemented | Visual parity unverified |
| Admin | Dashboard | implemented | Visual parity unverified |
| Content | Posts/Pages CRUD | not started | Phase 2 |
| Content | Revisions / autosave / lock | not started | Phase 2 |
| Media | Library upload | not started | Phase 2 |
| Fields | Batch A core types | not started | Phase 3 |
| Fields | Repeaters / flexible | not started | Phase 4 |
| Editor | Gutenberg-like | not started | Phase 5 |
| Web | Next.js SSR / preview | not started | Phase 5 stub Phase 1 |
| AI | Structured proposals | not started | Phase 6 |
| Parity | Screenshot program | not started | Phase 7 |
