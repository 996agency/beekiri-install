# Screen parity ledger

Reference: WordPress **7.1.3**. Captures: pending until local WP or screenshots provided (`REFERENCE.md`).

Statuses: `not started` | `implemented` | `tested` | `parity verified` | `unverified`

| Screen | Impl | Visual delta | Interaction | a11y | Status |
|--------|------|--------------|-------------|------|--------|
| Install — language | Phase 1 | — | — | — | unverified |
| Install — welcome / site info | Phase 1 | — | — | — | unverified |
| Install — success | Phase 1 | — | — | — | unverified |
| Login (`wp-login`) | Phase 1 | — | — | — | unverified |
| Lost password | Phase 1 | — | — | — | unverified |
| Admin shell | Phase 1 | — | — | — | unverified |
| Dashboard | Phase 1 | — | — | — | unverified |
| Posts list | Phase 2 | — | — | — | not started |
| Post edit | Phase 2 | — | — | — | not started |
| Pages list/edit | Phase 2 | — | — | — | not started |
| Media library | Phase 2 | — | — | — | not started |
| Users | Phase 2+ | — | — | — | not started |
| Settings | Phase 2+ | — | — | — | not started |
| Field groups | Phase 3 | — | — | — | not started |

**Do not claim 100% parity** until reference captures exist and diffs are within documented threshold.
