/** Field engine scaffold — implemented in Phase 3+. */
export type FieldType = 'text' | 'textarea' | 'number' | 'true_false' | 'select';

export interface FieldDefinitionDraft {
  key: string;
  name: string;
  label: string;
  type: FieldType;
  required?: boolean;
}
