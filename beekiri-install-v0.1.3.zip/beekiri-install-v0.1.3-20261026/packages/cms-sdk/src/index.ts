/** Typed API client scaffold — expand from OpenAPI in later phases. */
export function createCmsClient(baseUrl: string) {
  return {
    baseUrl,
    async getInstallStatus() {
      const res = await fetch(`${baseUrl}/api/install/status`);
      return res.json();
    },
  };
}
