export type CapabilitySlug =
  | 'manage_options'
  | 'edit_users'
  | 'list_users'
  | 'create_users'
  | 'delete_users'
  | 'edit_posts'
  | 'edit_others_posts'
  | 'publish_posts'
  | 'delete_posts'
  | 'edit_pages'
  | 'edit_others_pages'
  | 'publish_pages'
  | 'delete_pages'
  | 'upload_files'
  | 'moderate_comments'
  | 'manage_categories'
  | 'edit_theme_options'
  | 'read';

export type RoleSlug =
  | 'administrator'
  | 'editor'
  | 'author'
  | 'contributor'
  | 'subscriber';

export interface PublicUser {
  id: string;
  username: string;
  email: string;
  displayName: string;
  role: RoleSlug;
  capabilities: CapabilitySlug[];
}

export interface SitePublic {
  id: string;
  title: string;
  tagline: string;
  language: string;
  installed: boolean;
  blogPublic: boolean;
}

export interface InstallStatusResponse {
  installed: boolean;
  databaseOk: boolean;
  databaseMessage: string;
  canInstall: boolean;
}

export interface InstallRequest {
  language: string;
  siteTitle: string;
  username: string;
  password: string;
  email: string;
  blogPublic: boolean;
}

export interface LoginRequest {
  login: string;
  password: string;
  remember?: boolean;
}

export interface ApiErrorBody {
  statusCode: number;
  message: string;
  error?: string;
  code?: string;
}
