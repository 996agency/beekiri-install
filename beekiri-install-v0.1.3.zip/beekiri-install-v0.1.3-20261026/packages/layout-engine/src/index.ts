/** Flexible layout registry scaffold — Phase 4/5. */
export interface LayoutDefinition {
  key: string;
  label: string;
  fieldKeys: string[];
}

export const EMPTY_LAYOUT_REGISTRY: Record<string, LayoutDefinition> = {};
