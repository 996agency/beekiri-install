#!/usr/bin/env bash
# Pack install ZIP and publish to the public beekiri-install GitHub Releases repo.
# Usage: pnpm publish:release
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

RELEASE_REPO="${BEEKIRI_INSTALL_REPO:-996agency/beekiri-install}"
version="$(node -p "require('./package.json').version")"
tag="v${version}"
stable_zip="${ROOT}/releases/beekiri-install-v${version}.zip"
latest_zip="${ROOT}/releases/beekiri-install.zip"

echo "→ Building install ZIP for ${tag}…"
bash "${ROOT}/scripts/pack-release.sh"

if [[ ! -f "$stable_zip" ]]; then
  echo "Missing ${stable_zip}"
  exit 1
fi

if ! gh repo view "$RELEASE_REPO" >/dev/null 2>&1; then
  echo "→ Creating public repo ${RELEASE_REPO}…"
  gh repo create "$RELEASE_REPO" \
    --public \
    --description "Public Beekiri CMS install ZIPs (releases only — unzip → START_HERE.txt → /install)" \
    --add-readme
  # Minimal README so the repo is clearly install-only
  tmp="$(mktemp -d)"
  cat > "${tmp}/README.md" <<EOF
# Beekiri install packages

Public **install ZIP** releases for [Beekiri CMS](https://github.com/996agency/Beekiri).

1. Download **beekiri-install.zip** from the latest [Release](https://github.com/${RELEASE_REPO}/releases/latest)
2. Unzip → open \`START_HERE.txt\` / \`INSTALL.md\`
3. Open your admin URL → complete **/install** once

Do not put secrets in this repo. Each ZIP is source + docs only (no \`.env\`, no \`node_modules\`).
EOF
  gh repo edit "$RELEASE_REPO" --homepage "https://github.com/${RELEASE_REPO}/releases"
  # Seed readme via API if empty clone awkward — use release notes primarily
fi

notes="$(cat <<EOF
## Beekiri Core ${tag}

Install ZIP for new sites and updates.

1. Download **beekiri-install.zip** (or **beekiri-install-v${version}.zip**)
2. Unzip → follow \`START_HERE.txt\`
3. \`pnpm install\` → configure \`.env\` → \`pnpm db:migrate\` → start apps
4. Open **ADMIN_URL** → **/install** (first run only)

Existing sites: pull/update carefully, then confirm **Settings → Beekiri Core**.

Content, media, and \`.env\` stay on the site — this package does not overwrite them automatically.
EOF
)"

if gh release view "$tag" --repo "$RELEASE_REPO" >/dev/null 2>&1; then
  echo "→ Release ${tag} exists — uploading assets…"
  gh release upload "$tag" "$stable_zip" "$latest_zip" --repo "$RELEASE_REPO" --clobber
  gh release edit "$tag" --repo "$RELEASE_REPO" --title "Beekiri Core ${tag}" --notes "$notes"
else
  echo "→ Creating release ${tag} on ${RELEASE_REPO}…"
  gh release create "$tag" "$stable_zip" "$latest_zip" \
    --repo "$RELEASE_REPO" \
    --title "Beekiri Core ${tag}" \
    --notes "$notes"
fi

echo
echo "Published: https://github.com/${RELEASE_REPO}/releases/tag/${tag}"
echo "Latest ZIP: https://github.com/${RELEASE_REPO}/releases/latest/download/beekiri-install.zip"
