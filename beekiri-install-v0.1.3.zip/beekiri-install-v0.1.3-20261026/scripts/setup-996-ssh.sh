#!/usr/bin/env bash
# Adds a GitHub SSH host for the 996agency key WITHOUT touching AgencyUK.
# Run once in your own terminal (may ask for password if ~/.ssh/config is root-owned):
#   bash scripts/setup-996-ssh.sh
set -euo pipefail

CONFIG="${HOME}/.ssh/config"
PUB="${HOME}/.ssh/996.pub"
KEY="${HOME}/.ssh/996"

if [[ ! -f "$PUB" || ! -f "$KEY" ]]; then
  echo "Missing ~/.ssh/996 or ~/.ssh/996.pub"
  exit 1
fi

echo "Your 996 public key (add on https://github.com/settings/keys while logged in as 996agency):"
echo
cat "$PUB"
echo

# Fix root-owned config if needed
if [[ -f "$CONFIG" ]] && [[ "$(stat -f '%Su' "$CONFIG")" != "$(whoami)" ]]; then
  echo "~/.ssh/config is owned by $(stat -f '%Su' "$CONFIG"). Fixing ownership…"
  sudo chown "$(whoami):staff" "$CONFIG"
fi

if grep -q 'Host github.com-996' "$CONFIG" 2>/dev/null; then
  echo "Host github.com-996 already present in ~/.ssh/config"
else
  cat >> "$CONFIG" <<'EOF'

# 996agency — do not use for AgencyUK (that stays on github-agencyuk)
Host github.com-996
  HostName github.com
  User git
  IdentityFile ~/.ssh/996
  IdentitiesOnly yes
EOF
  echo "Added Host github.com-996 to ~/.ssh/config"
fi

echo
echo "Testing GitHub auth with 996 key…"
ssh -T git@github.com-996 2>&1 || true
echo
echo "If you see a username greeting, set remotes with:"
echo "  git remote set-url origin git@github.com-996:996agency/Beekiri.git"
echo "  git push -u origin main"
