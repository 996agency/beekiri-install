#!/usr/bin/env bash
# Prepare a fresh PostgreSQL database for a new Beekiri client site.
# Usage: ./scripts/client-prep.sh <client-slug>
# Example: ./scripts/client-prep.sh acme
set -euo pipefail

slug="${1:-}"
if [[ -z "$slug" ]]; then
  echo "Usage: pnpm client:prep <client-slug>"
  echo "Example: pnpm client:prep acme"
  exit 1
fi

if ! [[ "$slug" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?$ ]]; then
  echo "Client slug must be lowercase letters, numbers, and hyphens."
  exit 1
fi

db="beekiri_client_${slug//-/_}"
user="${USER:-beekiri}"

if ! command -v createdb >/dev/null 2>&1; then
  echo "createdb not found. Install PostgreSQL client tools, then retry."
  exit 1
fi

if psql -lqt | cut -d \| -f 1 | grep -qw "$db"; then
  echo "Database already exists: $db"
  echo "Use a new slug, or point DATABASE_URL at this DB only if it is empty/uninstalled."
else
  createdb "$db"
  echo "Created database: $db"
fi

echo
echo "Next:"
echo "  1. Set DATABASE_URL=\"postgresql://${user}@localhost:5432/${db}?schema=public\""
echo "  2. Set unique SESSION_SECRET / CSRF_SECRET and this client's ADMIN_URL / APP_URL / API_URL"
echo "  3. pnpm db:migrate && pnpm doctor && pnpm dev   # or production start"
echo "  4. Open ADMIN_URL — the shared /install wizard runs once for this site"
