# Beekiri CMS

WordPress-experience CMS built with **React + NestJS + PostgreSQL + Next.js**. No PHP. No Docker. No WordPress runtime.

Admin UX targets WordPress **7.1.3** (Gutenberg base **23.6**) — see `docs/REFERENCE.md`. This is an independent implementation; it is not affiliated with WordPress or Automattic.

## Current milestone

**Phase 1 (runnable):** first-run installer → login/logout/reset → secure sessions → RBAC foundation → wp-admin-like shell → dashboard.

Phases 2–7 (posts, media, field engine, block editor, AI, full visual parity) are **not** claimed complete. Track status in `docs/PROGRESS.md` and `docs/FEATURE_MATRIX.md`.

## Prerequisites (native)

| Tool | Notes |
|------|--------|
| Node.js 20+ LTS | Tested on Node 24 |
| pnpm 9+ | `npm i -g pnpm@9` |
| PostgreSQL 14+ | Homebrew / Windows installer / apt — **not Docker** |

### macOS

```bash
brew install node pnpm postgresql@16
brew services start postgresql@16
createdb beekiri_cms
```

### Windows

1. Install Node LTS from nodejs.org and enable Corepack / install pnpm.
2. Install PostgreSQL from https://www.postgresql.org/download/windows/
3. Create database `beekiri_cms` in pgAdmin or `createdb`.

### Linux

```bash
sudo apt install postgresql postgresql-contrib
sudo -u postgres createuser -s "$USER"
createdb beekiri_cms
# Node via nvm or distro; then: npm i -g pnpm@9
```

## Setup

```bash
cp .env.example .env
# Edit DATABASE_URL, SESSION_SECRET (openssl rand -hex 32), URLs

pnpm install
pnpm db:migrate:dev   # first time: creates migration + client
# or after migrations exist:
pnpm db:migrate

pnpm doctor
pnpm dev
```

| App | URL |
|-----|-----|
| Admin | http://127.0.0.1:8787 |
| API + OpenAPI | http://127.0.0.1:8788/api/docs |
| Public site | http://127.0.0.1:8789 |

**LocalWP / Local by Flywheel:** Beekiri deliberately avoids ports **80**, **443**, and **4000** (and does not bind Local site ports in the 10000+ range). Do not change `PORT` back to 4000.

On a fresh database, open the admin URL — you are redirected to the **installer** (`/install`). That wizard is the first-run for **every** site (local and each client). Create the owner account (no default password), then log in.

**Hand off to a client**

| Method | What you do | What they do |
|--------|-------------|--------------|
| GitHub | Push Beekiri to a private repo | `git clone` → follow `INSTALL.md` → open admin → `/install` |
| ZIP | Public releases: [beekiri-install](https://github.com/abAltinBekjiri/beekiri-install/releases) (`pnpm publish:release`) | Unzip → `START_HERE.txt` → same installer |

Also: `pnpm client:prep acme` (empty DB helper) · `docs/CLIENT_SETUP.md`

## Scripts

```bash
pnpm doctor        # env / DB / permissions
pnpm dev           # api + admin + web
pnpm test          # includes Phase 1 API install/auth tests
pnpm lint
pnpm typecheck
pnpm build
```

## Security notes

- Passwords: Argon2id
- Sessions: HttpOnly cookies, server-side opaque tokens, CSRF on mutating requests
- Installer does **not** collect database credentials in the browser
- Never commit `.env`

## Docs

- `docs/IMPLEMENTATION_PLAN.md`
- `docs/FEATURE_MATRIX.md`
- `docs/SCREEN_PARITY.md`
- `docs/SECURITY.md`
- `docs/DECISIONS.md`
- `docs/PROGRESS.md`
