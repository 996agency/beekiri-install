# Install Beekiri (for clients)

You can install from **GitHub** or from an **install ZIP**. Both end the same way: open the admin URL and complete the **first-run installer** in the browser.

## What you need

| Requirement | Notes |
|-------------|--------|
| Node.js **20+** | https://nodejs.org |
| **pnpm 9+** | `npm install -g pnpm@9` |
| **PostgreSQL 14+** | Local install or a hosted database URL |
| A domain or localhost URLs | Admin, API, and public site |

No Docker. No PHP.

---

## Option A — Install from GitHub

```bash
git clone git@github.com:996agency/Beekiri.git beekiri
# or: git clone https://github.com/996agency/Beekiri.git beekiri
cd beekiri
pnpm install
cp .env.example .env
```

Edit `.env` (see **Environment** below), then:

```bash
# Create an empty database first, e.g. createdb beekiri_cms
pnpm db:migrate
pnpm doctor
pnpm build
pnpm --filter @beekiri/api start
```

In other terminals (or your process manager), also run the admin and public apps for production, or use `pnpm dev` on a staging machine.

Open **ADMIN_URL** in the browser → complete **/install** once → sign in.

---

## Option B — Install from ZIP (public Releases)

1. Download the latest installer ZIP (public):  
   **https://github.com/abAltinBekjiri/beekiri-install/releases/latest/download/beekiri-install.zip**
2. Unzip the package.
3. Open a terminal in that folder.
4. Run the same commands as Option A starting from `pnpm install`.

Agency: build + publish a new public ZIP anytime:

```bash
pnpm publish:release
# packs releases/beekiri-install.zip and uploads to
# github.com/abAltinBekjiri/beekiri-install/releases
```

```bash
cd beekiri-install-*   # or the folder name inside the zip
pnpm install
cp .env.example .env
# edit .env
pnpm db:migrate
pnpm doctor
pnpm build
pnpm --filter @beekiri/api start
```

Open **ADMIN_URL** → **/install** → create the site and owner account.

---

## Environment (`.env`)

Copy `.env.example` to `.env` and set at least:

```env
DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/DATABASE_NAME?schema=public"
APP_URL="https://www.your-domain.com"
ADMIN_URL="https://admin.your-domain.com"
API_URL="https://api.your-domain.com"
SESSION_SECRET="paste-a-long-random-secret"
CSRF_SECRET="paste-another-long-random-secret"
PORT=8788
COOKIE_SECURE="true"
```

Generate secrets:

```bash
openssl rand -hex 32
```

**Important**

- Use a **new empty database** for each site.
- Never commit `.env` or share secrets in chat/email if you can use a password manager.
- The browser installer never asks for database passwords — only site title and the owner login.

---

## First-run installer

After the API is running with migrations applied:

1. Visit `ADMIN_URL` (example locally: `http://127.0.0.1:8787`).
2. You are redirected to **/install**.
3. Choose language → confirm database → create site + owner → **Sign in**.

That wizard runs **once per database**. It is the same for every client site.

---

## Local quick start (agency / testing)

Ports avoid common conflicts (Admin **8787**, API **8788**, Web **8789**):

```bash
pnpm install
cp .env.example .env
# DATABASE_URL for local Postgres
pnpm db:migrate
pnpm doctor
pnpm dev
```

Then open http://127.0.0.1:8787/install

---

## Help

- Environment check: `pnpm doctor`
- Agency notes: `docs/CLIENT_SETUP.md`
- Project overview: `README.md`

If install fails, check `DATABASE_URL`, that Postgres is reachable, and that migrations ran (`pnpm db:migrate`).
