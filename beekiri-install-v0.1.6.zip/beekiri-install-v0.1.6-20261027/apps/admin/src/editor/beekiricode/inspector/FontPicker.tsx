import { useCallback, useMemo, useRef, useState } from 'react';
import { CaretDown, Check, MagnifyingGlass } from '@phosphor-icons/react';
import { Popover } from './Popover';

export const FONT_FAMILIES: { label: string; stack: string }[] = [
  { label: 'Inter', stack: 'Inter, system-ui, sans-serif' },
  { label: 'DM Sans', stack: '"DM Sans", system-ui, sans-serif' },
  { label: 'System UI', stack: 'system-ui, -apple-system, sans-serif' },
  { label: 'Helvetica Neue', stack: '"Helvetica Neue", Helvetica, Arial, sans-serif' },
  { label: 'Arial', stack: 'Arial, Helvetica, sans-serif' },
  { label: 'Avenir', stack: 'Avenir, "Avenir Next", sans-serif' },
  { label: 'Futura', stack: 'Futura, "Trebuchet MS", sans-serif' },
  { label: 'Gill Sans', stack: '"Gill Sans", "Gill Sans MT", sans-serif' },
  { label: 'Josefin Sans', stack: '"Josefin Sans", sans-serif' },
  { label: 'Verdana', stack: 'Verdana, Geneva, sans-serif' },
  { label: 'Georgia', stack: 'Georgia, "Times New Roman", serif' },
  { label: 'Times New Roman', stack: '"Times New Roman", Times, serif' },
  { label: 'Baskerville', stack: 'Baskerville, "Libre Baskerville", serif' },
  { label: 'Didot', stack: 'Didot, "Bodoni 72", serif' },
  { label: 'Palatino', stack: 'Palatino, "Palatino Linotype", serif' },
  { label: 'Menlo', stack: 'Menlo, Monaco, monospace' },
  { label: 'Courier New', stack: '"Courier New", Courier, monospace' },
];

function labelFor(value: string): string {
  if (!value) return '';
  const hit = FONT_FAMILIES.find((f) => f.stack === value);
  if (hit) return hit.label;
  return value.split(',')[0].replace(/["']/g, '').trim();
}

export function FontPicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const anchorRef = useRef<HTMLButtonElement>(null);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const close = useCallback(() => {
    setOpen(false);
    setQuery('');
  }, []);

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q ? FONT_FAMILIES.filter((f) => f.label.toLowerCase().includes(q)) : FONT_FAMILIES;
  }, [query]);

  const custom = query.trim() && !list.some((f) => f.label.toLowerCase() === query.trim().toLowerCase());
  const current = labelFor(value);

  return (
    <>
      <button
        ref={anchorRef}
        type="button"
        className={`bk-insp-input bk-insp-font${open ? ' is-open' : ''}`}
        onClick={() => setOpen((o) => !o)}
        style={value ? { fontFamily: value } : undefined}
      >
        <span className={current ? '' : 'is-placeholder'}>{current || 'Inherit'}</span>
        <CaretDown size={11} weight="bold" />
      </button>
      <Popover anchorRef={anchorRef} open={open} onClose={close} width={232}>
        <div className="bk-insp-fonts">
          <label className="bk-insp-fonts__search">
            <MagnifyingGlass size={13} />
            <input
              autoFocus
              value={query}
              placeholder="Search fonts"
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  const pick = list[0]?.stack ?? (query.trim() ? `"${query.trim()}", sans-serif` : '');
                  if (pick) onChange(pick);
                  close();
                }
              }}
            />
          </label>
          <div className="bk-insp-fonts__list">
            <button
              type="button"
              className={`bk-insp-fonts__item${!value ? ' is-active' : ''}`}
              onClick={() => {
                onChange('');
                close();
              }}
            >
              <span className="is-muted">Inherit</span>
              {!value ? <Check size={12} weight="bold" /> : null}
            </button>
            {list.map((f) => (
              <button
                key={f.label}
                type="button"
                className={`bk-insp-fonts__item${value === f.stack ? ' is-active' : ''}`}
                style={{ fontFamily: f.stack }}
                onClick={() => {
                  onChange(f.stack);
                  close();
                }}
              >
                <span>{f.label}</span>
                {value === f.stack ? <Check size={12} weight="bold" /> : null}
              </button>
            ))}
            {custom ? (
              <button
                type="button"
                className="bk-insp-fonts__item"
                onClick={() => {
                  onChange(`"${query.trim()}", sans-serif`);
                  close();
                }}
              >
                <span>Use “{query.trim()}”</span>
              </button>
            ) : null}
          </div>
        </div>
      </Popover>
    </>
  );
}
