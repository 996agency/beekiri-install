import { useEffect, useState } from 'react';
import { api } from '../api/client';
import { useAuth } from '../auth/AuthContext';

type Dash = {
  title: string;
  atAGlance: { users: number; posts: number; pages: number; fieldGroups: number };
  note?: string;
};

export function Dashboard() {
  const auth = useAuth();
  const [data, setData] = useState<Dash | null>(null);

  useEffect(() => {
    api<Dash>('/api/site/dashboard').then(setData).catch(() => setData(null));
  }, []);

  return (
    <div className="wrap">
      <h1>Dashboard</h1>

      <div className="beekiri-notice is-info">
        <p>
          Welcome to Beekiri. Site: <strong>{data?.title ?? '…'}</strong> · signed in as{' '}
          {auth.user?.username}.
        </p>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">At a glance</h2>
        </div>
        <div className="bk-panel__body">
          <ul className="bk-rows">
            <li className="bk-row">
              <span className="bk-row__label">Posts</span>
              <span className="bk-row__value">{data?.atAGlance.posts ?? 0}</span>
            </li>
            <li className="bk-row">
              <span className="bk-row__label">Pages</span>
              <span className="bk-row__value">{data?.atAGlance.pages ?? 0}</span>
            </li>
            <li className="bk-row">
              <span className="bk-row__label">Backend fields</span>
              <span className="bk-row__value">{data?.atAGlance.fieldGroups ?? 0}</span>
            </li>
            <li className="bk-row">
              <span className="bk-row__label">Users</span>
              <span className="bk-row__value">{data?.atAGlance.users ?? 0}</span>
            </li>
          </ul>
          {data?.note ? <p className="bk-muted" style={{ marginTop: 12 }}>{data.note}</p> : null}
        </div>
      </div>
    </div>
  );
}
