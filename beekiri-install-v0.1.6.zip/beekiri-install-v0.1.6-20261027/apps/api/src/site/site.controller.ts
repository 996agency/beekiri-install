import { Body, Controller, Get, NotFoundException, Patch, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthGuard } from '../auth/auth.guard';
import { CapabilitiesGuard } from '../auth/capabilities.guard';
import { RequireCapabilities } from '../auth/capabilities.decorator';
import { UpdateSiteSettingsDto } from './site.dto';
import { listLinkTargets } from './link-targets';
import { LayoutSyncService } from '../layouts/layout-sync.service';
import { PagesService } from '../pages/pages.service';
import { DEFAULT_THEME_SLUG, getThemeManifest } from '../themes/theme-registry';
import {
  DEFAULT_FAVICON_PATH,
  defaultMediaSettings,
  defaultMenuItems,
  mergeSiteOptions,
  parseMediaSettings,
  readOptions,
  resolveFaviconUrl,
} from './site-options';

function resolveActiveTheme(raw?: string): string {
  const slug = (raw ?? '').trim() || DEFAULT_THEME_SLUG;
  return getThemeManifest(slug) ? slug : DEFAULT_THEME_SLUG;
}

@ApiTags('site')
@Controller('site')
export class SiteController {
  constructor(
    private readonly prisma: PrismaService,
    private readonly pages: PagesService,
    private readonly layouts: LayoutSyncService,
  ) {}

  @Get('link-targets')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  async linkTargets() {
    const base = listLinkTargets();
    const site = await this.prisma.site.findFirst({ orderBy: { createdAt: 'asc' } });
    if (!site) return base;
    const pages = await this.pages.listPublishedTargets(site.id);
    return { ...base, pages };
  }

  private serializeSettings(site: {
    id: string;
    title: string;
    tagline: string;
    language: string;
    settings: {
      blogPublic: boolean;
      timezone: string;
      dateFormat: string;
      timeFormat: string;
      options: unknown;
    } | null;
  }) {
    const opts = readOptions(site.settings?.options);
    return {
      id: site.id,
      title: site.title,
      tagline: site.tagline,
      language: site.language,
      blogPublic: site.settings?.blogPublic ?? true,
      timezone: site.settings?.timezone ?? 'UTC',
      dateFormat: site.settings?.dateFormat ?? 'F j, Y',
      timeFormat: site.settings?.timeFormat ?? 'g:i a',
      businessName: opts.businessName ?? '',
      businessCategory: opts.businessCategory ?? '',
      businessPhone: opts.businessPhone ?? '',
      businessAddress: opts.businessAddress ?? '',
      businessHours: opts.businessHours ?? '',
      businessImageUrl: opts.businessImageUrl ?? '',
      faviconUrl: opts.faviconUrl ?? '',
      faviconResolved: resolveFaviconUrl(opts.faviconUrl),
      faviconDefault: DEFAULT_FAVICON_PATH,
      permalinkStructure: opts.permalinkStructure ?? 'postname',
      permalinkCustom: opts.permalinkCustom ?? '/%postname%/',
      menuItems: opts.menuItems?.length ? opts.menuItems : defaultMenuItems(),
      media: opts.media ? parseMediaSettings(opts.media) : defaultMediaSettings(),
      activeTheme: resolveActiveTheme(opts.activeTheme),
      pageEditorStyle: 'beekiricode' as const,
      frontendRuntime: opts.frontendRuntime === 'react' ? 'react' : 'php',
    };
  }

  /** Lightweight preference for the page editor (editors + admins). */
  @Get('page-editor')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_pages')
  async pageEditor() {
    const site = await this.prisma.site.findFirst({
      include: { settings: true },
      orderBy: { createdAt: 'asc' },
    });
    const opts = readOptions(site?.settings?.options);
    return {
      pageEditorStyle: 'beekiricode' as const,
      frontendRuntime: opts.frontendRuntime === 'react' ? 'react' : 'php',
    };
  }

  @Get('public')
  async publicSite() {
    const site = await this.prisma.site.findFirst({
      include: { settings: true },
      orderBy: { createdAt: 'asc' },
    });
    if (!site) {
      return { installed: false };
    }
    const opts = readOptions(site.settings?.options);
    const prune = (
      items: ReturnType<typeof defaultMenuItems>,
    ): ReturnType<typeof defaultMenuItems> =>
      items
        .filter((m) => m.enabled)
        .map((m) => ({
          ...m,
          children: m.children?.length ? prune(m.children) : undefined,
        }));
    const menu = prune(opts.menuItems?.length ? opts.menuItems : defaultMenuItems());
    return {
      installed: true,
      id: site.id,
      title: site.title,
      tagline: site.tagline,
      language: site.language,
      blogPublic: site.settings?.blogPublic ?? true,
      business: {
        name: (opts.businessName || site.title).trim(),
        category: opts.businessCategory ?? '',
        phone: opts.businessPhone ?? '',
        address: opts.businessAddress ?? '',
        hours: opts.businessHours ?? '',
        imageUrl: opts.businessImageUrl ?? '',
      },
      faviconUrl: resolveFaviconUrl(opts.faviconUrl),
      permalinkStructure: opts.permalinkStructure ?? 'postname',
      theme: resolveActiveTheme(opts.activeTheme),
      menu,
    };
  }

  @Get('dashboard')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('read')
  async dashboard() {
    const site = await this.prisma.site.findFirst({
      include: {
        settings: true,
        _count: { select: { users: true, fieldGroups: true } },
      },
    });
    const pages = site ? await this.pages.countForSite(site.id) : 0;
    return {
      title: site?.title ?? 'Beekiri',
      atAGlance: {
        users: site?._count.users ?? 0,
        posts: 0,
        pages,
        fieldGroups: site?._count.fieldGroups ?? 0,
      },
      note: pages
        ? undefined
        : 'Create your first page under Pages to start building the site.',
    };
  }

  @Get('settings')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  async getSettings() {
    const site = await this.prisma.site.findFirst({
      include: { settings: true },
      orderBy: { createdAt: 'asc' },
    });
    if (!site) throw new NotFoundException('Site not found');
    return this.serializeSettings(site);
  }

  @Patch('settings')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  async updateSettings(@Body() body: UpdateSiteSettingsDto) {
    const site = await this.prisma.site.findFirst({
      include: { settings: true },
      orderBy: { createdAt: 'asc' },
    });
    if (!site) throw new NotFoundException('Site not found');

    const nextOptions = mergeSiteOptions(site.settings?.options, {
      businessName: body.businessName,
      businessCategory: body.businessCategory,
      businessPhone: body.businessPhone,
      businessAddress: body.businessAddress,
      businessHours: body.businessHours,
      businessImageUrl: body.businessImageUrl,
      faviconUrl: body.faviconUrl,
      permalinkStructure: body.permalinkStructure,
      permalinkCustom: body.permalinkCustom,
      menuItems: body.menuItems,
      media: body.media ? parseMediaSettings(body.media) : undefined,
      pageEditorStyle: body.pageEditorStyle,
      frontendRuntime: body.frontendRuntime,
    });

    const updated = await this.prisma.site.update({
      where: { id: site.id },
      data: {
        title: body.title ?? undefined,
        tagline: body.tagline ?? undefined,
        language: body.language ?? undefined,
        settings: {
          upsert: {
            create: {
              blogPublic: body.blogPublic ?? true,
              timezone: body.timezone ?? 'UTC',
              dateFormat: body.dateFormat ?? 'F j, Y',
              timeFormat: body.timeFormat ?? 'g:i a',
              options: nextOptions as Prisma.InputJsonValue,
            },
            update: {
              blogPublic: body.blogPublic ?? undefined,
              timezone: body.timezone ?? undefined,
              dateFormat: body.dateFormat ?? undefined,
              timeFormat: body.timeFormat ?? undefined,
              options: nextOptions as Prisma.InputJsonValue,
            },
          },
        },
      },
      include: { settings: true },
    });

    if (body.frontendRuntime !== undefined) {
      try {
        await this.layouts.syncAllActive();
      } catch {
        /* layout rewrite is best-effort after runtime switch */
      }
    }

    return this.serializeSettings(updated);
  }
}
