import { Module } from '@nestjs/common';
import { SiteController } from './site.controller';
import { AuthModule } from '../auth/auth.module';
import { LayoutsModule } from '../layouts/layouts.module';
import { PagesModule } from '../pages/pages.module';

@Module({
  imports: [AuthModule, PagesModule, LayoutsModule],
  controllers: [SiteController],
})
export class SiteModule {}
