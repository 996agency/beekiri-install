# Beekiri CMS

**Beekiri** is a modern content management system for agencies and client sites — structured fields, visual page editing, media, and a public site, delivered as a self-hosted product by **996agency**.

| | |
|---|---|
| **Version** | 0.1.14 |
| **Stack** | React (admin) · NestJS (API) · PostgreSQL · Next.js (public site) |
| **Install packages** | [996agency/beekiri-install](https://github.com/996agency/beekiri-install) |

---

## Highlights

- **Admin** — pages, media, users, settings, and Backend Fields (ACF-style groups with repeater, group, and flexible content)
- **Overview dashboard** — customizable status blocks for storage, content, activity, and publish lineup
- **Visual editor** — BeekiriCode layouts driven by Backend Fields, with live PHP or React output
- **Public site** — theme layouts under `apps/web/themes`, rendered from the same field values
- **Security** — Argon2id passwords, HttpOnly sessions, CSRF on mutating requests

---

## Requirements

| Requirement | Notes |
|-------------|--------|
| Node.js 20+ | LTS recommended |
| pnpm 9+ | `npm install -g pnpm@9` |
| PostgreSQL 14+ | Local or managed database |

---

## Quick start

```bash
git clone git@github.com:996agency/Beekiri.git beekiri
cd beekiri
cp .env.example .env
# Set DATABASE_URL, SESSION_SECRET, and app URLs

pnpm install
pnpm db:migrate
pnpm doctor
pnpm dev
```

| Application | Default URL |
|-------------|-------------|
| Admin | http://127.0.0.1:8787 |
| API (OpenAPI) | http://127.0.0.1:8788/api/docs |
| Public site | http://127.0.0.1:8789 |

On a fresh database, open the admin URL and complete the **first-run installer** (`/install`) to create the site and owner account.

**Client handoff:** download the latest install ZIP from [beekiri-install](https://github.com/996agency/beekiri-install/raw/main/beekiri-install.zip), or share this repository under license. Full steps: [`INSTALL.md`](./INSTALL.md) · [`docs/CLIENT_SETUP.md`](./docs/CLIENT_SETUP.md).

---

## Repository layout

```
apps/
  admin/     # CMS UI and media uploads
  api/       # NestJS API and Prisma
  web/       # Public site, themes, and shared editor modules
```

---

## Scripts

```bash
pnpm doctor        # Environment and database checks
pnpm dev           # Admin + API + public site
pnpm build         # Production builds
pnpm test
pnpm lint
pnpm typecheck
pnpm pack:release  # Build install ZIP
pnpm publish:release
```

---

## Security

- Passwords hashed with **Argon2id**
- Sessions stored server-side; cookies are **HttpOnly**
- CSRF protection on state-changing requests
- Never commit `.env` or production secrets

See [`docs/SECURITY.md`](./docs/SECURITY.md).

---

## Documentation

| Document | Description |
|----------|-------------|
| [`INSTALL.md`](./INSTALL.md) | Client and production install |
| [`docs/CLIENT_SETUP.md`](./docs/CLIENT_SETUP.md) | Agency handoff checklist |
| [`docs/SECURITY.md`](./docs/SECURITY.md) | Security model |
| [`docs/IMPLEMENTATION_PLAN.md`](./docs/IMPLEMENTATION_PLAN.md) | Product roadmap |
| [`docs/FEATURE_MATRIX.md`](./docs/FEATURE_MATRIX.md) | Feature status |

---

## License

**Proprietary — All rights reserved © 996agency.**

Beekiri is **not** open source. Possession of this repository or an install ZIP does not grant rights to modify, redistribute, rebrand, or resell the software. Authorized client use only under agreement with 996agency. See [`LICENSE`](./LICENSE).
