import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import {
  FastifyAdapter,
  NestFastifyApplication,
} from '@nestjs/platform-fastify';
import { ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import cookie from '@fastify/cookie';
import cors from '@fastify/cors';
import multipart from '@fastify/multipart';
import fastifyStatic from '@fastify/static';
import { mkdir } from 'fs/promises';
import { AppModule } from './app.module';
import { CORE_BUILD } from './core-build';
import { resolveUploadsRoot } from './media/media.paths';

async function bootstrap() {
  const app = await NestFactory.create<NestFastifyApplication>(
    AppModule,
    new FastifyAdapter({ logger: true }),
  );

  const adminUrl = process.env.ADMIN_URL ?? 'http://127.0.0.1:8787';
  const appUrl = process.env.APP_URL ?? 'http://127.0.0.1:8789';

  await app.register(cors, {
    origin: [adminUrl, appUrl],
    credentials: true,
  });
  await app.register(cookie, {
    secret: process.env.SESSION_SECRET ?? 'dev-insecure-session-secret',
  });
  await app.register(multipart, {
    limits: { fileSize: 20 * 1024 * 1024, files: 1 },
  });

  const uploadsRoot = resolveUploadsRoot();
  await mkdir(uploadsRoot, { recursive: true });
  // Served outside /api so public sites and admin can use /uploads/...
  await app.register(fastifyStatic, {
    root: uploadsRoot,
    prefix: '/uploads/',
    decorateReply: false,
  });

  app.setGlobalPrefix('api');
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );

  const config = new DocumentBuilder()
    .setTitle('Beekiri CMS API')
    .setDescription('Beekiri content management API')
    .setVersion('0.1.0')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document);

  // Default 8788 — never 4000 (LocalWP / Local by Flywheel conflict)
  const port = Number(process.env.PORT ?? 8788);
  try {
    await app.listen(port, '0.0.0.0');
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === 'EADDRINUSE') {
      console.error(
        `\nBeekiri API: port ${port} is already used by another process (often an older Beekiri still running).\n` +
          `Close that window or run: npx kill-port ${port}  then start Beekiri again.\n`,
      );
      process.exit(1);
    }
    throw e;
  }
  console.log(`Beekiri API ready on port ${port} (build ${CORE_BUILD})`);
}

bootstrap();
