import { Injectable } from '@nestjs/common';
import { existsSync, readFileSync, statSync } from 'fs';
import { join } from 'path';
import { PrismaService } from '../prisma/prisma.service';

export type DashboardRange = 'today' | '7d' | '30d' | 'all';

function rangeStart(range: DashboardRange): Date | null {
  const now = new Date();
  if (range === 'all') return null;
  if (range === 'today') {
    const d = new Date(now);
    d.setHours(0, 0, 0, 0);
    return d;
  }
  const days = range === '7d' ? 7 : 30;
  return new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
}

function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
  if (n < 1024 * 1024 * 1024) return `${Math.round(n / (1024 * 1024))} MB`;
  return `${(n / (1024 * 1024 * 1024)).toFixed(1)} GB`;
}

function readCoreVersion(): string {
  const candidates = [
    join(process.cwd(), 'beekiri.manifest.json'),
    join(process.cwd(), '..', '..', 'beekiri.manifest.json'),
    join(__dirname, '..', '..', '..', '..', 'beekiri.manifest.json'),
  ];
  for (const path of candidates) {
    try {
      if (!existsSync(path)) continue;
      const j = JSON.parse(readFileSync(path, 'utf8')) as { coreVersion?: string };
      if (j.coreVersion) return j.coreVersion;
    } catch {
      /* ignore */
    }
  }
  return process.env.BEEKIRI_CORE_VERSION ?? '0.1.15';
}

@Injectable()
export class DashboardService {
  constructor(private readonly prisma: PrismaService) {}

  async overview(range: DashboardRange = 'today') {
    const site = await this.prisma.site.findFirst({
      include: { _count: { select: { users: true, fieldGroups: true } } },
      orderBy: { createdAt: 'asc' },
    });
    if (!site) {
      return this.emptyOverview();
    }

    const since = rangeStart(range);
    const siteId = site.id;

    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const [
      pagePublished,
      pageDraft,
      pagesThisWeek,
      postPublished,
      postDraft,
      postsThisWeek,
      postTotal,
      mediaAgg,
      mediaByMime,
      recentMedia,
      activity,
      draftsReady,
      latestPublish,
    ] = await Promise.all([
      this.prisma.post.count({
        where: { siteId, type: 'page', status: 'publish' },
      }),
      this.prisma.post.count({
        where: { siteId, type: 'page', status: 'draft' },
      }),
      this.prisma.post.count({
        where: {
          siteId,
          type: 'page',
          status: 'publish',
          publishedAt: { gte: weekAgo },
        },
      }),
      this.prisma.post.count({
        where: { siteId, type: 'post', status: 'publish' },
      }),
      this.prisma.post.count({
        where: { siteId, type: 'post', status: 'draft' },
      }),
      this.prisma.post.count({
        where: {
          siteId,
          type: 'post',
          status: 'publish',
          publishedAt: { gte: weekAgo },
        },
      }),
      this.prisma.post.count({
        where: { siteId, type: 'post', NOT: { status: 'auto-draft' } },
      }),
      this.prisma.mediaAsset.aggregate({
        where: { siteId },
        _sum: { size: true },
        _count: true,
      }),
      this.prisma.mediaAsset.groupBy({
        by: ['mimeType'],
        where: { siteId },
        _sum: { size: true },
        _count: true,
      }),
      this.prisma.mediaAsset.findMany({
        where: { siteId, mimeType: { startsWith: 'image/' } },
        orderBy: { createdAt: 'desc' },
        take: 8,
        select: { id: true, url: true, mimeType: true, size: true },
      }),
      this.prisma.auditLog.findMany({
        where: {
          OR: [{ siteId }, { siteId: null }],
          ...(since ? { createdAt: { gte: since } } : {}),
        },
        orderBy: { createdAt: 'desc' },
        take: 8,
        include: { user: { select: { username: true, displayName: true } } },
      }),
      this.prisma.post.findMany({
        where: { siteId, type: { in: ['page', 'post'] }, status: 'draft' },
        orderBy: { updatedAt: 'desc' },
        take: 6,
        select: { id: true, title: true, slug: true, updatedAt: true, type: true },
      }),
      this.prisma.post.findFirst({
        where: { siteId, type: 'page', status: 'publish' },
        orderBy: { publishedAt: 'desc' },
        select: { publishedAt: true, updatedAt: true },
      }),
    ]);

    let imageBytes = 0;
    let videoBytes = 0;
    let documentBytes = 0;
    for (const row of mediaByMime) {
      const bytes = row._sum.size ?? 0;
      const mime = row.mimeType.toLowerCase();
      if (mime.startsWith('image/')) imageBytes += bytes;
      else if (mime.startsWith('video/')) videoBytes += bytes;
      else documentBytes += bytes;
    }

    const mediaBytes = mediaAgg._sum.size ?? 0;
    const dialect = this.detectDialect();
    const databaseBytes = this.estimateDatabaseBytes();
    const totalBytes = mediaBytes + databaseBytes;

    const coreVersion = readCoreVersion();

    return {
      title: site.title,
      range,
      coreVersion,
      atAGlance: {
        users: site._count.users,
        posts: postTotal,
        pages: pagePublished + pageDraft,
        fieldGroups: site._count.fieldGroups,
      },
      storage: {
        totalBytes,
        totalLabel: formatBytes(totalBytes),
        dialect,
        imageBytes,
        videoBytes,
        documentBytes,
        databaseBytes,
        mediaBytes,
      },
      pages: {
        published: pagePublished,
        drafts: pageDraft,
        scheduled: 0,
        publishedThisWeek: pagesThisWeek,
      },
      posts: {
        total: postTotal,
        published: postPublished,
        drafts: postDraft,
        scheduled: 0,
        publishedThisWeek: postsThisWeek,
        categories: 0,
      },
      media: {
        files: mediaAgg._count,
        bytes: mediaBytes,
        bytesLabel: formatBytes(mediaBytes),
        previews: recentMedia.map((m) => ({
          id: m.id,
          url: m.url,
          mimeType: m.mimeType,
        })),
      },
      status: {
        site: 'live' as const,
        lastPublishAt: latestPublish?.publishedAt?.toISOString() ?? null,
        lastUpdateAt: latestPublish?.updatedAt?.toISOString() ?? null,
        coreVersion,
        fieldGroups: site._count.fieldGroups,
      },
      activity: activity.map((a) => ({
        id: a.id,
        action: a.action,
        at: a.createdAt.toISOString(),
        actor: a.user?.displayName || a.user?.username || 'System',
      })),
      publishLineup: draftsReady.map((p) => ({
        id: p.id,
        title: p.title || '(no title)',
        slug: p.slug,
        type: p.type === 'post' ? 'post' : 'page',
        updatedAt: p.updatedAt.toISOString(),
      })),
      users: site._count.users,
      fieldGroups: site._count.fieldGroups,
    };
  }

  private emptyOverview() {
    return {
      title: 'Beekiri',
      range: 'today' as const,
      coreVersion: readCoreVersion(),
      atAGlance: { users: 0, posts: 0, pages: 0, fieldGroups: 0 },
      storage: {
        totalBytes: 0,
        totalLabel: '0 B',
        dialect: 'postgres' as const,
        imageBytes: 0,
        videoBytes: 0,
        documentBytes: 0,
        databaseBytes: 0,
        mediaBytes: 0,
      },
      pages: { published: 0, drafts: 0, scheduled: 0, publishedThisWeek: 0 },
      posts: {
        total: 0,
        published: 0,
        drafts: 0,
        scheduled: 0,
        publishedThisWeek: 0,
        categories: 0,
      },
      media: { files: 0, bytes: 0, bytesLabel: '0 B', previews: [] as { id: string; url: string; mimeType: string }[] },
      status: {
        site: 'live' as const,
        lastPublishAt: null as string | null,
        lastUpdateAt: null as string | null,
        coreVersion: readCoreVersion(),
        fieldGroups: 0,
      },
      activity: [] as { id: string; action: string; at: string; actor: string }[],
      publishLineup: [] as {
        id: string;
        title: string;
        slug: string;
        type: 'page' | 'post';
        updatedAt: string;
      }[],
      users: 0,
      fieldGroups: 0,
    };
  }

  private detectDialect(): 'postgres' | 'sqlite' {
    const url = process.env.DATABASE_URL ?? '';
    if (url.startsWith('file:') || url.includes('sqlite')) return 'sqlite';
    return 'postgres';
  }

  private estimateDatabaseBytes(): number {
    const url = process.env.DATABASE_URL ?? '';
    if (url.startsWith('file:')) {
      const path = url.replace(/^file:/, '');
      try {
        return statSync(path).size;
      } catch {
        return 0;
      }
    }
    // Postgres size needs a raw query — soft-fail to 0 for hosted DBs we can't stat.
    return 0;
  }
}
