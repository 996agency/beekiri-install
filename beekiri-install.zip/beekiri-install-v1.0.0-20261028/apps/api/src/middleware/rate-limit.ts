import rateLimit from 'express-rate-limit';

const tooMany = (message: string) => ({ statusCode: 429, message, error: 'Too Many Requests' });

/** Coarse flood guard for the whole API (admin polling stays far below this). */
export const apiRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 1_200,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests. Please slow down and try again shortly.'),
});

/** Unauthenticated auth endpoints (password reset, lost password). */
export const authRateLimit = rateLimit({
  windowMs: 15 * 60_000,
  limit: 30,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many attempts. Please try again later.'),
});
