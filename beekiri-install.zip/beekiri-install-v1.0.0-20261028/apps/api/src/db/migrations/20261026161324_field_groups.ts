import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

/** ACF-style field groups for the admin (Backend Fields). */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.createTable(
      'FieldGroup',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        title: { type: DataTypes.TEXT, allowNull: false },
        /** Unique machine key within the site, e.g. group_hero */
        key: { type: DataTypes.TEXT, allowNull: false },
        description: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        active: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
        /** Where this group appears: ["post","page","user","media"] */
        location: { type: DataTypes.JSONB, allowNull: false, defaultValue: [] },
        /** Field definitions: [{ id, type, label, name, required, instructions, choices? }] */
        fields: { type: DataTypes.JSONB, allowNull: false, defaultValue: [] },
        menuOrder: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false },
      },
      { transaction },
    );

    await queryInterface.addIndex('FieldGroup', ['siteId'], {
      name: 'FieldGroup_siteId_idx',
      transaction,
    });
    await queryInterface.addIndex('FieldGroup', ['menuOrder'], {
      name: 'FieldGroup_menuOrder_idx',
      transaction,
    });
    await queryInterface.addIndex('FieldGroup', ['siteId', 'key'], {
      name: 'FieldGroup_siteId_key_key',
      unique: true,
      transaction,
    });

    await queryInterface.addConstraint('FieldGroup', {
      type: 'foreign key',
      name: 'FieldGroup_siteId_fkey',
      fields: ['siteId'],
      references: { table: 'Site', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.dropTable('FieldGroup');
}
