/**
 * ACF Pro–shaped field definitions (camelCase keys; see acf-json.ts for ACF snake_case mapping).
 * Values are stored raw (like ACF post meta) and formatted at render time (acf-format.ts).
 */

export const FIELD_TYPES = [
  // Basic
  'text',
  'textarea',
  'number',
  'range',
  'email',
  'url',
  'password',
  // Content
  'image',
  'file',
  'wysiwyg',
  'oembed',
  'gallery',
  // Choice
  'select',
  'checkbox',
  'radio',
  'button_group',
  'true_false',
  // Relational
  'link',
  'post_object',
  'page_link',
  'relationship',
  'user',
  // Advanced
  'date_picker',
  'date_time_picker',
  'time_picker',
  'color_picker',
  // Layout
  'message',
  'accordion',
  'tab',
  'group',
  'repeater',
  'flexible_content',
] as const;

export type FieldType = (typeof FIELD_TYPES)[number];

/** Old Beekiri type names → current. */
const TYPE_ALIASES: Record<string, FieldType> = {
  date: 'date_picker',
  datetime: 'date_time_picker',
  time: 'time_picker',
  color: 'color_picker',
  boolean: 'true_false',
};

/** Types that hold no value (presentation only). */
export const NO_VALUE_TYPES: ReadonlySet<FieldType> = new Set(['message', 'accordion', 'tab']);

export const LOCATION_TARGETS = ['post', 'page', 'user', 'media'] as const;

export type LocationTarget = (typeof LOCATION_TARGETS)[number];

export type FlexibleLayout = {
  id: string;
  name: string;
  label: string;
  display: 'block' | 'table' | 'row';
  min?: number;
  max?: number;
  subFields: BackendField[];
};

export type BackendField = {
  id: string;
  type: FieldType;
  label: string;
  name: string;
  required: boolean;
  instructions: string;
  /** ACF-style lines: "value : Label" or just "value". */
  choices: string[];
  defaultValue: string;

  placeholder?: string;
  prepend?: string;
  append?: string;
  maxLength?: number;
  rows?: number;
  /** textarea: 'wpautop' | 'br' | '' */
  newLines?: string;
  min?: number;
  max?: number;
  step?: number;
  /** image/file/gallery: array|url|id · choice: value|label|array · link: array|url · post: object|id · date: PHP format */
  returnFormat?: string;
  /** date/time pickers: how the editor shows it (PHP format). */
  displayFormat?: string;
  multiple?: boolean;
  allowNull?: boolean;
  /** radio/checkbox: vertical|horizontal · repeater/group: table|block|row */
  layout?: string;
  ui?: boolean;
  onText?: string;
  offText?: string;
  message?: string;
  /** post_object / page_link / relationship */
  postTypes?: string[];
  /** user: role slugs */
  roles?: string[];
  /** image/file: comma list e.g. "jpg, png" */
  mimeTypes?: string;
  previewSize?: string;
  /** wysiwyg */
  toolbar?: string;
  mediaUpload?: boolean;
  /** Admin column width % (ACF wrapper.width). */
  width?: number;

  /** repeater / group */
  subFields?: BackendField[];
  minRows?: number;
  maxRows?: number;
  buttonLabel?: string;
  /** repeater: sub field name shown when a row is collapsed */
  collapsed?: string;
  /** flexible_content */
  layouts?: FlexibleLayout[];
};

export function emptyField(partial?: Partial<BackendField>): BackendField {
  return {
    id: partial?.id ?? `field_${Math.random().toString(36).slice(2, 9)}`,
    type: partial?.type ?? 'text',
    label: partial?.label ?? '',
    name: partial?.name ?? '',
    required: partial?.required ?? false,
    instructions: partial?.instructions ?? '',
    choices: partial?.choices ?? [],
    defaultValue: partial?.defaultValue ?? '',
  };
}

export function toSlugKey(input: string, prefix = 'group'): string {
  const base = input
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .replace(/_{2,}/g, '_')
    .slice(0, 48);
  return `${prefix}_${base || Math.random().toString(36).slice(2, 8)}`;
}

/** "red : Red" → { value: 'red', label: 'Red' } (ACF choices syntax). */
export function parseChoice(line: string): { value: string; label: string } {
  const idx = line.indexOf(' : ');
  if (idx === -1) return { value: line.trim(), label: line.trim() };
  return { value: line.slice(0, idx).trim(), label: line.slice(idx + 3).trim() };
}

const MAX_DEPTH = 5;
const rid = (p = 'field') => `${p}_${Math.random().toString(36).slice(2, 9)}`;

const str = (v: unknown, max = 500) => (typeof v === 'string' ? v.slice(0, max) : undefined);
const num = (v: unknown) => {
  const n = typeof v === 'number' ? v : typeof v === 'string' && v.trim() !== '' ? Number(v) : NaN;
  return Number.isFinite(n) ? n : undefined;
};
const bool = (v: unknown) =>
  typeof v === 'boolean'
    ? v
    : v === 1 || v === '1'
      ? true
      : v === 0 || v === '0'
        ? false
        : undefined;
const slugList = (v: unknown) =>
  Array.isArray(v)
    ? v
        .filter((x): x is string => typeof x === 'string' && /^[a-z][a-z0-9_-]*$/.test(x))
        .slice(0, 20)
    : undefined;

function cleanName(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/[^a-z0-9_]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 60);
}

function parseLayouts(raw: unknown, depth: number): FlexibleLayout[] {
  if (!Array.isArray(raw)) return [];
  const out: FlexibleLayout[] = [];
  for (const row of raw) {
    if (!row || typeof row !== 'object') continue;
    const r = row as Record<string, unknown>;
    const label = str(r.label, 120)?.trim() ?? '';
    const name = cleanName(str(r.name, 60) || label);
    if (!label || !name) continue;
    const display = r.display === 'table' || r.display === 'row' ? r.display : 'block';
    out.push({
      id: typeof r.id === 'string' && r.id ? r.id.slice(0, 40) : rid('layout'),
      name,
      label,
      display,
      min: num(r.min),
      max: num(r.max),
      subFields: parseFields(r.subFields ?? r.sub_fields, depth + 1),
    });
  }
  return out.slice(0, 30);
}

/** Sanitise untrusted field definitions (recursive for repeater / group / flexible content). */
export function parseFields(raw: unknown, depth = 0): BackendField[] {
  if (!Array.isArray(raw) || depth > MAX_DEPTH) return [];
  const out: BackendField[] = [];
  for (const row of raw) {
    if (!row || typeof row !== 'object') continue;
    const r = row as Record<string, unknown>;
    const rawType = typeof r.type === 'string' ? r.type : 'text';
    const type: FieldType = FIELD_TYPES.includes(rawType as FieldType)
      ? (rawType as FieldType)
      : (TYPE_ALIASES[rawType] ?? 'text');
    const label = (str(r.label, 120) ?? '').trim();
    if (!label) continue;
    const id = typeof r.id === 'string' && r.id ? r.id.slice(0, 40) : rid();
    // Presentational fields don't need a name; give them a stable one from the id.
    const name =
      cleanName(str(r.name, 60) || '') || (NO_VALUE_TYPES.has(type) ? cleanName(id) : '');
    if (!name) continue;

    const choices = Array.isArray(r.choices)
      ? r.choices
          .filter((c): c is string => typeof c === 'string')
          .map((c) => c.trim())
          .filter(Boolean)
      : typeof r.choices === 'string'
        ? r.choices
            .split('\n')
            .map((c) => c.trim())
            .filter(Boolean)
        : [];

    const field: BackendField = {
      id,
      type,
      label,
      name,
      required: Boolean(r.required),
      instructions: str(r.instructions) ?? '',
      choices: choices.slice(0, 100).map((c) => c.slice(0, 200)),
      defaultValue: str(r.defaultValue) ?? '',
    };

    const opt = <K extends keyof BackendField>(k: K, v: BackendField[K] | undefined) => {
      if (v !== undefined && v !== '') field[k] = v;
    };
    opt('placeholder', str(r.placeholder, 200));
    opt('prepend', str(r.prepend, 40));
    opt('append', str(r.append, 40));
    opt('maxLength', num(r.maxLength));
    opt('rows', num(r.rows));
    opt('newLines', str(r.newLines, 10));
    opt('min', num(r.min));
    opt('max', num(r.max));
    opt('step', num(r.step));
    opt('returnFormat', str(r.returnFormat, 40));
    opt('displayFormat', str(r.displayFormat, 40));
    opt('multiple', bool(r.multiple));
    opt('allowNull', bool(r.allowNull));
    opt('layout', str(r.layout, 20));
    opt('ui', bool(r.ui));
    opt('onText', str(r.onText, 40));
    opt('offText', str(r.offText, 40));
    opt('message', str(r.message, 2000));
    opt('postTypes', slugList(r.postTypes));
    opt('roles', slugList(r.roles));
    opt('mimeTypes', str(r.mimeTypes, 120));
    opt('previewSize', str(r.previewSize, 20));
    opt('toolbar', str(r.toolbar, 20));
    opt('mediaUpload', bool(r.mediaUpload));
    opt('width', num(r.width));

    if (type === 'repeater' || type === 'group') {
      field.subFields = parseFields(r.subFields ?? r.sub_fields, depth + 1);
    }
    if (type === 'repeater') {
      opt('minRows', num(r.minRows));
      opt('maxRows', num(r.maxRows));
      opt('buttonLabel', str(r.buttonLabel, 60));
      opt('collapsed', str(r.collapsed, 60));
    }
    if (type === 'flexible_content') {
      field.layouts = parseLayouts(r.layouts, depth);
      opt('buttonLabel', str(r.buttonLabel, 60));
    }

    out.push(field);
  }
  return out.slice(0, 80);
}

/** Built-in targets plus custom post type slugs. */
export function parseLocation(raw: unknown): string[] {
  if (!Array.isArray(raw)) return [];
  const out: string[] = [];
  for (const v of raw) {
    if (typeof v !== 'string') continue;
    const slug = v.trim().toLowerCase();
    if (!/^[a-z][a-z0-9_-]*$/.test(slug)) continue;
    if (!out.includes(slug)) out.push(slug);
  }
  return out.slice(0, 20);
}
