import express, { type Express, type NextFunction, type Request, type Response } from 'express';
import { existsSync, readFileSync } from 'fs';
import type { IncomingMessage, Server, ServerResponse } from 'http';
import { createRequire } from 'module';
import { join } from 'path';
import { pathToFileURL } from 'url';
import { config } from '../config/env';
import { REPO_ROOT } from '../config/paths';

const ADMIN_DIR = join(REPO_ROOT, 'apps/admin');
const WEB_DIR = join(REPO_ROOT, 'apps/web');
/** Admin pages (the admin is a single-page app; its router handles the rest). */
const ADMIN_PAGE = /^\/admin(\/.*)?$/;
const BUILD_HINT = 'Run "npm run build" (npm start does this automatically).';

type Handler = (req: IncomingMessage, res: ServerResponse) => unknown;

export type SiteHost = {
  /** Adds /admin and (when enabled) the website to the Express app, after /api. */
  mount(app: Express): void;
  close(): Promise<void>;
};

type Options = {
  /** Development: live admin (Vite) and website (next dev). Otherwise the production builds. */
  dev: boolean;
  /** The HTTP server, for hot-reload websockets in development. */
  server: Server;
  /** Address of this server, used by the website to call the API in-process. */
  selfUrl: string;
  /** False in setup mode: without a database there is no website to show yet. */
  website: boolean;
};

/** Native ESM import that survives compilation to CommonJS (Vite's Node API is ESM-only). */
const importEsm = new Function('specifier', 'return import(specifier)') as (
  specifier: string,
) => Promise<Record<string, unknown>>;

async function adminMiddleware(dev: boolean, server: Server) {
  if (!dev) {
    const dist = join(ADMIN_DIR, 'dist');
    const indexFile = join(dist, 'index.html');
    if (!existsSync(indexFile)) throw new Error(`The admin is not built. ${BUILD_HINT}`);
    const indexHtml = readFileSync(indexFile, 'utf8');

    // Mounted at /admin so /admin/assets/x.js resolves to dist/assets/x.js.
    const assets = express.Router();
    assets.use(
      '/admin',
      express.static(dist, {
        index: false,
        // Built file names carry a content hash, so they never change.
        setHeaders(res, path) {
          if (path.includes(`${join(dist, 'assets')}`)) {
            res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
          }
        },
      }),
    );
    return {
      assets: (req: Request, res: Response, next: NextFunction) => assets(req, res, next),
      page: (_req: Request, res: Response) => {
        res.setHeader('Cache-Control', 'no-store');
        res.type('html').send(indexHtml);
      },
      close: async () => undefined,
    };
  }

  const viteDir = join(
    createRequire(join(ADMIN_DIR, 'package.json')).resolve('vite/package.json'),
    '..',
  );
  const { createServer } = (await importEsm(
    pathToFileURL(join(viteDir, 'dist/node/index.js')).href,
  )) as { createServer: (options: object) => Promise<ViteDevServer> };
  const vite = await createServer({
    root: ADMIN_DIR,
    configFile: join(ADMIN_DIR, 'vite.config.ts'),
    appType: 'custom',
    server: { middlewareMode: true, hmr: { server } },
  });
  return {
    assets: (req: Request, res: Response, next: NextFunction) => vite.middlewares(req, res, next),
    page: async (req: Request, res: Response, next: NextFunction) => {
      try {
        const html = readFileSync(join(ADMIN_DIR, 'index.html'), 'utf8');
        res.type('html').send(await vite.transformIndexHtml(req.originalUrl, html));
      } catch (error) {
        next(error);
      }
    },
    close: () => vite.close(),
  };
}

type ViteDevServer = {
  middlewares: (req: IncomingMessage, res: ServerResponse, next: (err?: unknown) => void) => void;
  transformIndexHtml(url: string, html: string): Promise<string>;
  close(): Promise<void>;
};

type NextApp = {
  prepare(): Promise<void>;
  getRequestHandler(): Handler;
  close?(): Promise<void>;
};

async function websiteHandler(dev: boolean, server: Server, selfUrl: string) {
  const distDir = dev ? '.next-dev' : '.next';
  if (!dev && !existsSync(join(WEB_DIR, distDir, 'BUILD_ID'))) {
    throw new Error(`The website is not built. ${BUILD_HINT}`);
  }

  // The website reads these from its own environment (apps/web/src/lib/env.ts).
  process.env.API_URL = selfUrl;
  process.env.APP_URL = config.urls.app ?? selfUrl;
  process.env.NEXT_DIST_DIR = distDir;

  const webRequire = createRequire(join(WEB_DIR, 'package.json'));
  const nextModule = webRequire('next') as { default?: unknown };
  const createNext = (nextModule.default ?? nextModule) as (options: object) => NextApp;
  const port = Number(new URL(selfUrl).port);
  const nextApp = createNext({
    dev,
    dir: WEB_DIR,
    hostname: 'localhost',
    port,
    httpServer: server,
  });
  await nextApp.prepare();
  return { handle: nextApp.getRequestHandler(), close: async () => nextApp.close?.() };
}

/** The admin at /admin and the website at every other path, on the API's own server. */
export async function createSiteHost({
  dev,
  server,
  selfUrl,
  website,
}: Options): Promise<SiteHost> {
  const admin = await adminMiddleware(dev, server);
  const site = website ? await websiteHandler(dev, server, selfUrl) : null;

  return {
    mount(app) {
      app.use((req, res, next) =>
        req.path.startsWith('/admin/') ? admin.assets(req, res, next) : next(),
      );
      app.get(ADMIN_PAGE, admin.page);

      if (site) {
        app.use((req, res) => site.handle(req, res));
      } else {
        // Setup mode: everything leads to the setup wizard.
        app.get('/', (_req, res) => res.redirect('/admin/install'));
      }
    },
    async close() {
      await Promise.allSettled([admin.close(), site?.close()]);
    },
  };
}
