import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, int, jsonb, text, type Json } from './_shared';
import type { Site } from './site.model';

/** ACF-style field groups (Backend Fields). */
export class FieldGroup extends Model<
  InferAttributes<FieldGroup>,
  InferCreationAttributes<FieldGroup>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare title: string;
  /** Unique machine key within the site, e.g. group_hero */
  declare key: string;
  declare description: CreationOptional<string>;
  declare active: CreationOptional<boolean>;
  declare location: CreationOptional<Json>;
  declare fields: CreationOptional<Json>;
  declare menuOrder: CreationOptional<number>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    FieldGroup.init(
      {
        id: idColumn(),
        siteId: text(),
        title: text(),
        key: text(),
        description: text({ defaultValue: '' }),
        active: bool(true),
        location: jsonb([]),
        fields: jsonb([]),
        menuOrder: int(0),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'FieldGroup',
        modelName: 'FieldGroup',
        timestamps: true,
        indexes: [
          { name: 'FieldGroup_siteId_key_key', unique: true, fields: ['siteId', 'key'] },
          { name: 'FieldGroup_siteId_idx', fields: ['siteId'] },
          { name: 'FieldGroup_menuOrder_idx', fields: ['menuOrder'] },
        ],
      },
    );
  }
}
