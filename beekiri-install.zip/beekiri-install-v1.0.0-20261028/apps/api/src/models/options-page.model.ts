import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, int, text } from './_shared';
import type { Site } from './site.model';

/** ACF-style options pages (site-wide field screens). */
export class OptionsPage extends Model<
  InferAttributes<OptionsPage>,
  InferCreationAttributes<OptionsPage>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare title: string;
  declare slug: string;
  declare menuTitle: CreationOptional<string>;
  declare description: CreationOptional<string>;
  /** Parent options page slug, or empty for top-level */
  declare parentSlug: CreationOptional<string>;
  declare active: CreationOptional<boolean>;
  declare menuOrder: CreationOptional<number>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    OptionsPage.init(
      {
        id: idColumn(),
        siteId: text(),
        title: text(),
        slug: text(),
        menuTitle: text({ defaultValue: '' }),
        description: text({ defaultValue: '' }),
        parentSlug: text({ defaultValue: '' }),
        active: bool(true),
        menuOrder: int(0),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'OptionsPage',
        modelName: 'OptionsPage',
        timestamps: true,
        indexes: [
          { name: 'OptionsPage_siteId_slug_key', unique: true, fields: ['siteId', 'slug'] },
          { name: 'OptionsPage_siteId_idx', fields: ['siteId'] },
        ],
      },
    );
  }
}
