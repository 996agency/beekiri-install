import type { Model, ModelStatic } from 'sequelize';
import { sequelize } from '../db/sequelize';
import { AuditLog } from './audit-log.model';
import { Capability } from './capability.model';
import { FieldGroup } from './field-group.model';
import { InstallationState } from './installation-state.model';
import { MediaAsset } from './media-asset.model';
import { OptionsPage } from './options-page.model';
import { PasswordResetToken } from './password-reset-token.model';
import { PostRevision } from './post-revision.model';
import { PostType } from './post-type.model';
import { Post } from './post.model';
import { RoleCapability } from './role-capability.model';
import { Role } from './role.model';
import { Session } from './session.model';
import { SiteSettings } from './site-settings.model';
import { Site } from './site.model';
import { Taxonomy } from './taxonomy.model';
import { User } from './user.model';

const models = [
  Site,
  SiteSettings,
  Role,
  Capability,
  RoleCapability,
  User,
  Session,
  PasswordResetToken,
  AuditLog,
  InstallationState,
  MediaAsset,
  FieldGroup,
  PostType,
  Taxonomy,
  OptionsPage,
  Post,
  PostRevision,
];

for (const model of models) model.initModel(sequelize);

const cascade = { onDelete: 'CASCADE', onUpdate: 'CASCADE' } as const;
// Soft references: ids are kept for display but the schema has no FK (user deletes must not cascade).
const soft = { constraints: false } as const;

// Site owns everything; deleting a site cascades.
Site.hasOne(SiteSettings, { foreignKey: 'siteId', as: 'settings', ...cascade });
SiteSettings.belongsTo(Site, { foreignKey: 'siteId', as: 'site' });
Site.hasMany(User, { foreignKey: 'siteId', as: 'users', ...cascade });
User.belongsTo(Site, { foreignKey: 'siteId', as: 'site' });
const siteOwned: [ModelStatic<Model>, string][] = [
  [MediaAsset, 'mediaAssets'],
  [FieldGroup, 'fieldGroups'],
  [PostType, 'postTypes'],
  [Taxonomy, 'taxonomies'],
  [OptionsPage, 'optionsPages'],
  [Post, 'posts'],
];
for (const [model, as] of siteOwned) {
  Site.hasMany(model, { foreignKey: 'siteId', as, ...cascade });
  model.belongsTo(Site, { foreignKey: 'siteId', as: 'site' });
}
Site.hasMany(AuditLog, {
  foreignKey: 'siteId',
  as: 'auditLogs',
  onDelete: 'SET NULL',
  onUpdate: 'CASCADE',
});
AuditLog.belongsTo(Site, { foreignKey: 'siteId', as: 'site' });

// Roles & capabilities (many-to-many through the legacy _CapabilityToRole table).
Role.hasMany(User, {
  foreignKey: 'roleId',
  as: 'users',
  onDelete: 'RESTRICT',
  onUpdate: 'CASCADE',
});
User.belongsTo(Role, { foreignKey: 'roleId', as: 'role' });
Role.belongsToMany(Capability, {
  through: RoleCapability,
  foreignKey: 'B',
  otherKey: 'A',
  as: 'capabilities',
  timestamps: false,
});
Capability.belongsToMany(Role, {
  through: RoleCapability,
  foreignKey: 'A',
  otherKey: 'B',
  as: 'roles',
  timestamps: false,
});

// Auth.
User.hasMany(Session, { foreignKey: 'userId', as: 'sessions', ...cascade });
Session.belongsTo(User, { foreignKey: 'userId', as: 'user' });
User.hasMany(PasswordResetToken, { foreignKey: 'userId', as: 'resetTokens', ...cascade });
PasswordResetToken.belongsTo(User, { foreignKey: 'userId', as: 'user' });
User.hasMany(AuditLog, {
  foreignKey: 'userId',
  as: 'auditLogs',
  onDelete: 'SET NULL',
  onUpdate: 'CASCADE',
});
AuditLog.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// Content.
Post.hasMany(PostRevision, { foreignKey: 'postId', as: 'revisions', ...cascade });
PostRevision.belongsTo(Post, { foreignKey: 'postId', as: 'post' });
Post.belongsTo(User, { foreignKey: 'authorId', as: 'author', ...soft });
Post.belongsTo(User, { foreignKey: 'updatedById', as: 'updatedBy', ...soft });
Post.belongsTo(Post, { foreignKey: 'parentId', as: 'parent', ...soft });
Post.hasMany(Post, { foreignKey: 'parentId', as: 'children', ...soft });
PostRevision.belongsTo(User, { foreignKey: 'authorId', as: 'author', ...soft });
MediaAsset.belongsTo(User, { foreignKey: 'uploadedById', as: 'uploadedBy', ...soft });

export {
  sequelize,
  AuditLog,
  Capability,
  FieldGroup,
  InstallationState,
  MediaAsset,
  OptionsPage,
  PasswordResetToken,
  Post,
  PostRevision,
  PostType,
  Role,
  RoleCapability,
  Session,
  Site,
  SiteSettings,
  Taxonomy,
  User,
};
