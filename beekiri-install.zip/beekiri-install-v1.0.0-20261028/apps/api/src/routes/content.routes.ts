import { Router } from 'express';
import { createContentController } from '../controllers/pages.controller';
import type { ContentKind } from '../lib/pages/content-kind';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import { validate } from '../middleware/validate';
import { idParams } from '../validators/common';
import {
  createPageSchema,
  presenceLeaveQuery,
  presenceSchema,
  previewPageSchema,
  publicPageQuery,
  revisionParams,
  updatePageSchema,
} from '../validators/pages.schema';

/** /pages and /posts share one router shape; capabilities follow the content kind. */
function contentRoutes(kind: ContentKind) {
  const c = createContentController(kind);
  const edit = kind === 'post' ? 'edit_posts' : 'edit_pages';
  const del = kind === 'post' ? 'delete_posts' : 'delete_pages';
  const router = Router();
  const canEdit = [requireAuth, requireCapabilities(edit)];
  const withId = validate({ params: idParams });

  // Public (front-end) routes first so ":id" never shadows them.
  if (kind === 'page')
    router.get('/public/front', validate({ query: publicPageQuery }), c.publicFront);
  if (kind === 'post') router.get('/public', c.publicList);
  router.get('/public/:slug', validate({ query: publicPageQuery }), c.publicBySlug);

  router.get('/', ...canEdit, c.list);
  router.get('/:id/revisions', ...canEdit, withId, c.listRevisions);
  router.post(
    '/:id/revisions/:revisionId/restore',
    ...canEdit,
    validate({ params: revisionParams }),
    c.restoreRevision,
  );
  router.post(
    '/:id/preview',
    ...canEdit,
    validate({ params: idParams, body: previewPageSchema }),
    c.preview,
  );
  router.get('/:id/presence', ...canEdit, withId, c.getPresence);
  router.post(
    '/:id/presence',
    ...canEdit,
    validate({ params: idParams, body: presenceSchema }),
    c.postPresence,
  );
  router.delete(
    '/:id/presence',
    ...canEdit,
    validate({ params: idParams, query: presenceLeaveQuery }),
    c.deletePresence,
  );
  router.get('/:id', ...canEdit, withId, c.get);
  router.post('/', ...canEdit, validate({ body: createPageSchema }), c.create);
  router.patch(
    '/:id',
    ...canEdit,
    validate({ params: idParams, body: updatePageSchema }),
    c.update,
  );
  router.delete('/:id', requireAuth, requireCapabilities(del), withId, c.remove);
  return router;
}

export const pagesRoutes = contentRoutes('page');
export const postsRoutes = contentRoutes('post');
