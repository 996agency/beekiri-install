import { Router } from 'express';
import { authRoutes } from './auth.routes';
import { pagesRoutes, postsRoutes } from './content.routes';
import { fieldsRoutes } from './fields.routes';
import { healthRoutes } from './health.routes';
import { installRoutes } from './install.routes';
import { layoutsRoutes } from './layouts.routes';
import { mediaRoutes } from './media.routes';
import { siteRoutes } from './site.routes';
import { systemRoutes } from './system.routes';
import { themesRoutes } from './themes.routes';
import { usersRoutes } from './users.routes';

/** Every API module and where it is mounted under `/api` (also drives the OpenAPI document). */
export const apiModules: ReadonlyArray<readonly [path: string, router: Router]> = [
  ['/health', healthRoutes],
  ['/install', installRoutes],
  ['/auth', authRoutes],
  ['/users', usersRoutes],
  ['/media', mediaRoutes],
  ['/pages', pagesRoutes],
  ['/posts', postsRoutes],
  ['/fields', fieldsRoutes],
  ['/site', siteRoutes],
  ['/themes', themesRoutes],
  ['/layouts', layoutsRoutes],
  ['/system', systemRoutes],
];

export const apiRoutes = Router();
for (const [path, router] of apiModules) apiRoutes.use(path, router);
