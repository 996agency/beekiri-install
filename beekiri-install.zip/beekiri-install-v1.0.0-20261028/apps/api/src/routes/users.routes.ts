import { Router } from 'express';
import { usersController } from '../controllers/users.controller';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import { validate } from '../middleware/validate';
import { idParams } from '../validators/common';
import { createUserSchema, updateUserSchema } from '../validators/users.schema';

export const usersRoutes = Router();

usersRoutes.use(requireAuth);

usersRoutes.get('/roles', requireCapabilities('list_users'), usersController.roles);
usersRoutes.get('/', requireCapabilities('list_users'), usersController.list);
usersRoutes.get(
  '/:id',
  requireCapabilities('list_users'),
  validate({ params: idParams }),
  usersController.get,
);
usersRoutes.post(
  '/',
  requireCapabilities('create_users'),
  validate({ body: createUserSchema }),
  usersController.create,
);
usersRoutes.patch(
  '/:id',
  requireCapabilities('edit_users'),
  validate({ params: idParams, body: updateUserSchema }),
  usersController.update,
);
usersRoutes.delete(
  '/:id',
  requireCapabilities('delete_users'),
  validate({ params: idParams }),
  usersController.remove,
);
