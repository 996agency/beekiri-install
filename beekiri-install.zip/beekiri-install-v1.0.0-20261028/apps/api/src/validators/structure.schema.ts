import { z } from 'zod';
import { opt } from './common';

const SLUG = z
  .string()
  .min(1)
  .regex(/^[a-z][a-z0-9_-]*$/, 'Slug must start with a letter and use a-z, 0-9, _, -');

const uniqueStrings = (name: string) =>
  z
    .array(z.string().max(200))
    .max(200)
    .refine((v) => new Set(v).size === v.length, `All ${name}'s elements must be unique`);

const label = z.string().min(1).max(80);
const description = opt(z.string().max(500));
const flag = opt(z.boolean());

export const createPostTypeSchema = z
  .object({
    slug: SLUG.max(40),
    singular: label,
    plural: label,
    description,
    public: flag,
    hierarchical: flag,
    hasArchive: flag,
    showInMenu: flag,
    supports: opt(uniqueStrings('supports')),
    active: flag,
  })
  .strict();

export const updatePostTypeSchema = createPostTypeSchema
  .extend({ slug: opt(SLUG.max(40)), singular: opt(label), plural: opt(label) })
  .strict();

export const createTaxonomySchema = z
  .object({
    slug: SLUG.max(40),
    singular: label,
    plural: label,
    description,
    hierarchical: flag,
    public: flag,
    objectTypes: opt(uniqueStrings('objectTypes')),
    active: flag,
  })
  .strict();

export const updateTaxonomySchema = createTaxonomySchema
  .extend({ slug: opt(SLUG.max(40)), singular: opt(label), plural: opt(label) })
  .strict();

export const createOptionsPageSchema = z
  .object({
    title: z.string().min(1).max(120),
    slug: SLUG.max(60),
    menuTitle: opt(z.string().max(80)),
    description,
    parentSlug: opt(z.string().max(60)),
    active: flag,
  })
  .strict();

export const updateOptionsPageSchema = createOptionsPageSchema
  .extend({ title: opt(z.string().min(1).max(120)), slug: opt(SLUG.max(60)) })
  .strict();

export const fieldsSettingsSchema = z
  .object({
    showAdminBar: flag,
    exportFormat: opt(z.enum(['php', 'json'])),
    deleteWithContent: flag,
  })
  .strict();

export type CreatePostTypeInput = z.infer<typeof createPostTypeSchema>;
export type UpdatePostTypeInput = z.infer<typeof updatePostTypeSchema>;
export type CreateTaxonomyInput = z.infer<typeof createTaxonomySchema>;
export type UpdateTaxonomyInput = z.infer<typeof updateTaxonomySchema>;
export type CreateOptionsPageInput = z.infer<typeof createOptionsPageSchema>;
export type UpdateOptionsPageInput = z.infer<typeof updateOptionsPageSchema>;
export type FieldsSettingsInput = z.infer<typeof fieldsSettingsSchema>;
