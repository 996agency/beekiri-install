import { z } from 'zod';
import { opt } from './common';

type MenuItemInput = {
  id: string;
  label: string;
  path: string;
  enabled: boolean;
  source?: string;
  refId?: string;
  children?: MenuItemInput[];
};

const menuItem: z.ZodType<MenuItemInput> = z.lazy(() =>
  z
    .object({
      id: z.string().max(64),
      label: z.string().max(80),
      path: z.string().max(200),
      enabled: z.boolean(),
      source: opt(z.string().max(32)),
      refId: opt(z.string().max(64)),
      children: opt(z.array(menuItem).max(100)),
    })
    .strict(),
);

const mediaFolder = z
  .object({
    id: z.string().max(64),
    name: z.string().max(80),
    slug: z.string().max(80),
    /** null = top-level. Optional for older saved settings. */
    parentId: z.string().max(64).nullable().optional(),
  })
  .strict();

const mediaSettings = z
  .object({
    convertToWebp: opt(z.boolean()),
    webpLossless: opt(z.boolean()),
    webpQuality: opt(z.number().int().min(1).max(100)),
    maxWidth: opt(z.number().int().min(320).max(7680)),
    maxHeight: opt(z.number().int().min(320).max(7680)),
    stripMetadata: opt(z.boolean()),
    keepOriginal: opt(z.boolean()),
    folders: opt(z.array(mediaFolder).max(500)),
  })
  .strict();

const str = (max: number) => opt(z.string().max(max));

export const updateSiteSettingsSchema = z
  .object({
    title: opt(z.string().min(1).max(200)),
    tagline: str(300),
    language: str(32),
    blogPublic: opt(z.boolean()),
    timezone: str(64),
    dateFormat: str(32),
    timeFormat: str(32),
    businessName: str(200),
    businessCategory: str(120),
    businessPhone: str(64),
    businessAddress: str(500),
    businessHours: str(200),
    businessImageUrl: str(2000),
    faviconUrl: str(2000),
    permalinkStructure: opt(z.enum(['plain', 'postname', 'dayname', 'custom'])),
    permalinkCustom: str(120),
    menuItems: opt(z.array(menuItem).max(200)),
    frontPageId: str(64),
    frontPageSlug: str(180),
    media: opt(mediaSettings),
    pageEditorStyle: opt(z.enum(['beekiricode'])),
    /** Read-only after install; a different value returns frontend_runtime_locked. */
    frontendRuntime: opt(z.enum(['react', 'php'])),
  })
  .strict();

export const dashboardQuery = z
  .object({ range: z.enum(['today', '7d', '30d', 'all']).optional().catch(undefined) })
  .passthrough();

export type UpdateSiteSettingsInput = z.infer<typeof updateSiteSettingsSchema>;
