import { existsSync } from 'fs';
import { join } from 'path';
import { config as loadDotenv } from 'dotenv';
import { API_ROOT, REPO_ROOT } from './paths';
import { parseConfig } from './schema';

export type { AppConfig, DatabaseSettings, DbSslMode } from './schema';

// apps/api/.env is the API's own file. Sites installed before it existed keep their
// settings in the repo-root .env, which fills anything apps/api/.env leaves unset.
// Variables already present in the process environment always win over both files.
for (const file of [join(API_ROOT, '.env'), join(REPO_ROOT, '.env')]) {
  if (existsSync(file)) loadDotenv({ path: file, override: false });
}

const result = parseConfig(process.env);
if (!result.ok) {
  // Fail fast: a half-configured API is worse than one that refuses to start.
  const lines = result.problems.map((p) => `  - ${p}`).join('\n');
  console.error(`\nBeekiri API: invalid environment configuration (apps/api/.env)\n${lines}\n`);
  process.exit(1);
}

export const config = result.config;

/** Risky-but-working production settings; the server logs them at startup. */
export const configWarnings: readonly string[] = result.warnings;
