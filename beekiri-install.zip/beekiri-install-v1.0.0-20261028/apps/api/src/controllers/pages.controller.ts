import type { NextFunction, Request, Response } from 'express';
import type { ContentKind } from '../lib/pages/content-kind';
import { heartbeatPresence, leavePresence, listPresence } from '../lib/pages/pages.presence';
import { authUser } from '../middleware/authenticate';
import { pagesService } from '../services/pages.service';

function previewToken(req: Request): string | undefined {
  const { preview, token } = req.query as { preview?: unknown; token?: string };
  const wantPreview =
    preview === true || preview === '1' || preview === 'true' || Boolean(token?.trim());
  return wantPreview ? token : undefined;
}

const id = (req: Request) => req.params.id as string;

/** Same handlers serve /pages and /posts; only the content kind differs. */
export function createContentController(kind: ContentKind) {
  return {
    async publicFront(req: Request, res: Response, next: NextFunction) {
      try {
        res.json(await pagesService.getPublishedFrontPage(previewToken(req)));
      } catch (error) {
        next(error);
      }
    },

    async publicList(_req: Request, res: Response, next: NextFunction) {
      try {
        res.json(await pagesService.listPublishedPublic(kind));
      } catch (error) {
        next(error);
      }
    },

    async publicBySlug(req: Request, res: Response, next: NextFunction) {
      try {
        res.json(
          await pagesService.getPublishedBySlug(req.params.slug as string, previewToken(req), kind),
        );
      } catch (error) {
        next(error);
      }
    },

    async list(req: Request, res: Response, next: NextFunction) {
      try {
        res.json(await pagesService.list(authUser(req), kind));
      } catch (error) {
        next(error);
      }
    },

    async listRevisions(req: Request, res: Response, next: NextFunction) {
      try {
        res.json(await pagesService.listRevisions(authUser(req), id(req), kind));
      } catch (error) {
        next(error);
      }
    },

    async restoreRevision(req: Request, res: Response, next: NextFunction) {
      try {
        const revisionId = req.params.revisionId as string;
        res
          .status(201)
          .json(await pagesService.restoreRevision(authUser(req), id(req), revisionId, kind));
      } catch (error) {
        next(error);
      }
    },

    async preview(req: Request, res: Response, next: NextFunction) {
      try {
        res
          .status(201)
          .json(await pagesService.createPreview(authUser(req), id(req), req.body, kind));
      } catch (error) {
        next(error);
      }
    },

    getPresence(req: Request, res: Response, next: NextFunction) {
      try {
        res.json({ peers: listPresence(id(req)) });
      } catch (error) {
        next(error);
      }
    },

    async postPresence(req: Request, res: Response, next: NextFunction) {
      try {
        const user = authUser(req);
        // Only documents of this site can carry presence.
        await pagesService.get(user, id(req), kind);
        const peers = heartbeatPresence({
          pageId: id(req),
          userId: user.id,
          name: user.displayName?.trim() || user.username,
          clientId: req.body.clientId,
        });
        res.status(201).json({ peers });
      } catch (error) {
        next(error);
      }
    },

    deletePresence(req: Request, res: Response, next: NextFunction) {
      try {
        const clientId = (req.query.clientId as string | undefined)?.trim();
        if (clientId) leavePresence(id(req), clientId);
        res.json({ ok: true });
      } catch (error) {
        next(error);
      }
    },

    async get(req: Request, res: Response, next: NextFunction) {
      try {
        res.json(await pagesService.get(authUser(req), id(req), kind));
      } catch (error) {
        next(error);
      }
    },

    async create(req: Request, res: Response, next: NextFunction) {
      try {
        res.status(201).json(await pagesService.create(authUser(req), req.body, kind));
      } catch (error) {
        next(error);
      }
    },

    async update(req: Request, res: Response, next: NextFunction) {
      try {
        res.json(await pagesService.update(authUser(req), id(req), req.body, kind));
      } catch (error) {
        next(error);
      }
    },

    async remove(req: Request, res: Response, next: NextFunction) {
      try {
        res.json(await pagesService.remove(authUser(req), id(req), kind));
      } catch (error) {
        next(error);
      }
    },
  };
}
