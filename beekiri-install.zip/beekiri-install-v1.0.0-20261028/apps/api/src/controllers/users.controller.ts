import type { NextFunction, Request, Response } from 'express';
import { authUser } from '../middleware/authenticate';
import { usersService } from '../services/users.service';

const id = (req: Request) => req.params.id as string;

export const usersController = {
  roles(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json({ roles: usersService.roles() });
    } catch (error) {
      next(error);
    }
  },

  async list(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await usersService.list(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  async get(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await usersService.get(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await usersService.create(authUser(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await usersService.update(authUser(req), id(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async remove(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await usersService.remove(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },
};
