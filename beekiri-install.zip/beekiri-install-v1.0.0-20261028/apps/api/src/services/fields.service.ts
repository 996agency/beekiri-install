import { Op } from 'sequelize';
import {
  parseFields,
  parseLocation,
  toSlugKey,
  type BackendField,
} from '../lib/fields/fields.types';
import { AuditLog, FieldGroup, Post, Role, User } from '../models';
import type { AuthUser } from '../types/auth';
import { uniqueViolation } from '../utils/db-errors';
import { Conflict, NotFound, toHttpError } from '../utils/http-error';
import { iContains } from '../utils/sql';
import type { CreateFieldGroupInput, UpdateFieldGroupInput } from '../validators/fields.schema';
import { layoutSyncService } from './layout-sync.service';

const SLUGLIKE = /^[a-z][a-z0-9_-]*$/;

type FieldGroupChanges = Partial<{
  title: string;
  key: string;
  description: string;
  active: boolean;
  location: string[];
  fields: BackendField[];
}>;

function serialize(group: FieldGroup) {
  const fields = parseFields(group.fields);
  return {
    id: group.id,
    title: group.title,
    key: group.key,
    description: group.description,
    active: group.active,
    location: parseLocation(group.location),
    fields,
    menuOrder: group.menuOrder,
    fieldCount: fields.length,
    createdAt: group.createdAt.toISOString(),
    updatedAt: group.updatedAt.toISOString(),
  };
}

/** A friendly 409 for a duplicate key, otherwise the error unchanged. */
function duplicateKeyError(error: unknown): unknown {
  return uniqueViolation(error) !== null
    ? Conflict('A field group with this key already exists.')
    : error;
}

export class FieldsService {
  async list(actor: AuthUser) {
    try {
      const groups = await FieldGroup.findAll({
        where: { siteId: actor.siteId },
        order: [
          ['menuOrder', 'ASC'],
          ['createdAt', 'ASC'],
        ],
      });
      return { groups: groups.map(serialize) };
    } catch (error) {
      throw toHttpError(error, 'Could not load field groups.');
    }
  }

  async get(actor: AuthUser, id: string) {
    try {
      return serialize(await this.findOwned(actor, id));
    } catch (error) {
      throw toHttpError(error, 'Could not load the field group.');
    }
  }

  async create(actor: AuthUser, dto: CreateFieldGroupInput) {
    try {
      const title = dto.title.trim();
      const maxOrder = await FieldGroup.max<number | null, FieldGroup>('menuOrder', {
        where: { siteId: actor.siteId },
      });

      const group = await FieldGroup.create({
        siteId: actor.siteId,
        title,
        key: (dto.key?.trim() || toSlugKey(title)).slice(0, 60),
        description: (dto.description ?? '').trim(),
        active: dto.active ?? true,
        location: parseLocation(dto.location ?? ['post', 'page']),
        fields: parseFields(dto.fields ?? []),
        menuOrder: (maxOrder ?? -1) + 1,
      });

      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'field_group.created',
        meta: { groupId: group.id, key: group.key },
      });

      await layoutSyncService.syncGroupForSite(group);
      return serialize(group);
    } catch (error) {
      throw toHttpError(duplicateKeyError(error), 'Could not create the field group.');
    }
  }

  async update(actor: AuthUser, id: string, dto: UpdateFieldGroupInput) {
    try {
      const existing = await this.findOwned(actor, id);
      const previousKey = existing.key;

      const data: FieldGroupChanges = {};
      if (dto.title !== undefined) data.title = dto.title.trim();
      if (dto.key !== undefined) data.key = dto.key.trim();
      if (dto.description !== undefined) data.description = dto.description.trim();
      if (dto.active !== undefined) data.active = dto.active;
      if (dto.location !== undefined) data.location = parseLocation(dto.location);
      if (dto.fields !== undefined) data.fields = parseFields(dto.fields);

      const [, [group]] = await FieldGroup.update(data, {
        where: { id: existing.id },
        returning: true,
      });

      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'field_group.updated',
        meta: { groupId: group.id, key: group.key },
      });

      if (previousKey !== group.key) layoutSyncService.removeByGroupKey(previousKey);
      if (group.active) await layoutSyncService.syncGroupForSite(group);
      else layoutSyncService.removeByGroupKey(group.key);
      return serialize(group);
    } catch (error) {
      throw toHttpError(duplicateKeyError(error), 'Could not update the field group.');
    }
  }

  async remove(actor: AuthUser, id: string) {
    try {
      const existing = await this.findOwned(actor, id);
      await existing.destroy();

      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'field_group.deleted',
        meta: { groupId: existing.id, key: existing.key },
      });

      layoutSyncService.removeByGroupKey(existing.key);
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not delete the field group.');
    }
  }

  /** Relational field pickers (post_object / page_link / relationship). */
  async lookupPosts(actor: AuthUser, opts: { types: string[]; q: string; ids: string[] }) {
    try {
      const types = opts.types.filter((t) => SLUGLIKE.test(t)).slice(0, 20);
      const ids = opts.ids.filter(Boolean).slice(0, 100);
      const q = opts.q.trim().slice(0, 100);
      const items = await Post.findAll({
        where: {
          siteId: actor.siteId,
          status: { [Op.ne]: 'trash' },
          ...(ids.length ? { id: { [Op.in]: ids } } : {}),
          ...(types.length ? { type: { [Op.in]: types } } : {}),
          ...(q ? { title: iContains(q) } : {}),
        },
        attributes: ['id', 'title', 'slug', 'type', 'status'],
        order: [
          ['type', 'ASC'],
          ['title', 'ASC'],
        ],
        limit: ids.length ? ids.length : 50,
        raw: true,
      });
      return { items };
    } catch (error) {
      throw toHttpError(error, 'Could not search posts.');
    }
  }

  async lookupUsers(actor: AuthUser, opts: { q: string; ids: string[]; roles: string[] }) {
    try {
      const ids = opts.ids.filter(Boolean).slice(0, 100);
      const roles = opts.roles.filter((r) => SLUGLIKE.test(r)).slice(0, 20);
      const q = opts.q.trim().slice(0, 100);
      const items = await User.findAll({
        where: {
          siteId: actor.siteId,
          ...(ids.length ? { id: { [Op.in]: ids } } : {}),
          ...(q ? { [Op.or]: [{ displayName: iContains(q) }, { username: iContains(q) }] } : {}),
        },
        include: roles.length
          ? [{ model: Role, as: 'role', where: { slug: { [Op.in]: roles } }, attributes: [] }]
          : [],
        attributes: ['id', 'username', 'displayName'],
        order: [['displayName', 'ASC']],
        limit: ids.length ? ids.length : 50,
        raw: true,
      });
      return { items };
    } catch (error) {
      throw toHttpError(error, 'Could not search users.');
    }
  }

  private async findOwned(actor: AuthUser, id: string): Promise<FieldGroup> {
    const group = await FieldGroup.findOne({ where: { id, siteId: actor.siteId } });
    if (!group) throw NotFound('Field group not found.');
    return group;
  }
}

export const fieldsService = new FieldsService();
