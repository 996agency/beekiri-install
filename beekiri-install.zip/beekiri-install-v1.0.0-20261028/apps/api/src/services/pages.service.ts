import { randomBytes } from 'crypto';
import { Op } from 'sequelize';
import { contentKindConfig, type ContentKind } from '../lib/pages/content-kind';
import {
  contentFromBeekiricanva,
  contentFromBeekiriCode,
  contentFromHtml,
  parseContent,
  toSlug,
  type PageContentDoc,
} from '../lib/pages/pages.content';
import { readOptions } from '../lib/site/site-options';
import { Post, PostRevision, User } from '../models';
import type { Json } from '../models/_shared';
import type { AuthUser } from '../types/auth';
import { safeEqual } from '../utils/crypto';
import { uniqueViolation } from '../utils/db-errors';
import { BadRequest, Conflict, Forbidden, NotFound, toHttpError } from '../utils/http-error';
import type {
  CreatePageInput,
  PreviewPageInput,
  UpdatePageInput,
} from '../validators/pages.schema';
import { findPrimarySite } from './site-context';

const PREVIEW_TTL_MS = 24 * 60 * 60 * 1000;
const MAX_REVISIONS = 25;

type PostStatus = 'auto-draft' | 'draft' | 'publish';

type PostPatch = Partial<{
  title: string;
  slug: string;
  status: string;
  content: Json;
  excerpt: string;
  updatedById: string;
  publishedAt: Date;
}>;

function bodyBeekiriCode(body: { beekiricode?: unknown; instatic?: unknown }): unknown | undefined {
  if (body.beekiricode !== undefined) return body.beekiricode;
  if (body.instatic !== undefined) return body.instatic;
  return undefined;
}

function displayName(user: { displayName: string; username: string } | null | undefined) {
  return user?.displayName?.trim() || user?.username || null;
}

export class PagesService {
  private cfg(kind: ContentKind = 'page') {
    return contentKindConfig(kind);
  }

  private serialize(row: Post) {
    const doc = parseContent(row.content);
    const kind: ContentKind = row.type === 'post' ? 'post' : 'page';
    return {
      id: row.id,
      type: row.type,
      title: row.title,
      slug: row.slug,
      status: row.status as PostStatus,
      content: doc.html,
      beekiricanva: doc.beekiricanva,
      beekiricode: doc.beekiricode,
      /** @deprecated Alias of beekiricode */
      instatic: doc.beekiricode,
      excerpt: row.excerpt,
      authorId: row.authorId,
      updatedById: row.updatedById,
      parentId: row.parentId ?? null,
      menuOrder: row.menuOrder,
      path: this.cfg(kind).pathOf(row.slug),
      publishedAt: row.publishedAt?.toISOString() ?? null,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    };
  }

  private async resolveUserName(userId: string | null | undefined) {
    if (!userId) return null;
    const user = await User.findByPk(userId, { attributes: ['displayName', 'username'] });
    return displayName(user);
  }

  private async withAuthor<
    T extends { id: string; authorId: string | null; updatedById?: string | null },
  >(data: T) {
    const [authorName, updatedByName, revisionCount] = await Promise.all([
      this.resolveUserName(data.authorId),
      this.resolveUserName(data.updatedById ?? data.authorId),
      PostRevision.count({ where: { postId: data.id } }),
    ]);
    return { ...data, authorName, updatedByName, revisionCount };
  }

  private contentChanged(a: unknown, b: unknown) {
    return JSON.stringify(a ?? null) !== JSON.stringify(b ?? null);
  }

  private shouldSnapshot(existing: Post, next: PostPatch) {
    // Skip empty auto-drafts that never held real content.
    if (existing.status === 'auto-draft' && !existing.title.trim() && !existing.excerpt.trim()) {
      const doc = parseContent(existing.content);
      const canvas = doc.beekiricanva as { content?: unknown } | null | undefined;
      const emptyCanvas =
        !canvas ||
        (typeof canvas === 'object' &&
          Array.isArray(canvas.content) &&
          canvas.content.length === 0);
      if (emptyCanvas && !doc.html.trim()) return false;
    }

    if (next.title !== undefined && next.title !== existing.title) return true;
    if (next.slug !== undefined && next.slug !== existing.slug) return true;
    if (next.excerpt !== undefined && next.excerpt !== existing.excerpt) return true;
    if (next.status !== undefined && next.status !== existing.status) return true;
    return next.content !== undefined && this.contentChanged(next.content, existing.content);
  }

  private async createRevisionFrom(existing: Post) {
    await PostRevision.create({
      postId: existing.id,
      siteId: existing.siteId,
      title: existing.title,
      slug: existing.slug,
      status: existing.status,
      content: existing.content,
      excerpt: existing.excerpt,
      authorId: existing.updatedById ?? existing.authorId,
    });

    const old = await PostRevision.findAll({
      where: { postId: existing.id },
      order: [['createdAt', 'DESC']],
      attributes: ['id'],
      offset: MAX_REVISIONS,
    });
    if (old.length) {
      await PostRevision.destroy({ where: { id: { [Op.in]: old.map((r) => r.id) } } });
    }
  }

  private async uniqueSlug(
    siteId: string,
    base: string,
    kind: ContentKind = 'page',
    excludeId?: string,
  ) {
    const cfg = this.cfg(kind);
    const root = toSlug(base) || cfg.defaultSlugBase;
    let slug = root;
    for (let n = 2; ; n++) {
      const existing = await Post.findOne({
        where: {
          siteId,
          type: cfg.type,
          slug,
          ...(excludeId ? { id: { [Op.ne]: excludeId } } : {}),
        },
        attributes: ['id'],
      });
      if (!existing) return slug;
      slug = `${root}-${n}`;
      if (n >= 200) throw Conflict('Could not generate a unique slug.');
    }
  }

  private async findOwned(actor: AuthUser, id: string, kind: ContentKind) {
    const cfg = this.cfg(kind);
    const row = await Post.findOne({ where: { id, siteId: actor.siteId, type: cfg.type } });
    if (!row) throw NotFound(cfg.notFound);
    return row;
  }

  /** Static update (always bumps updatedAt) and return the fresh row. */
  private async applyUpdate(id: string, data: PostPatch, kind: ContentKind) {
    try {
      const [, rows] = await Post.update(data, { where: { id }, returning: true });
      return rows[0];
    } catch (e) {
      if (uniqueViolation(e) !== null) throw Conflict(this.cfg(kind).conflictSlug);
      throw e;
    }
  }

  async list(actor: AuthUser, kind: ContentKind = 'page') {
    try {
      const cfg = this.cfg(kind);
      const rows = await Post.findAll({
        where: {
          siteId: actor.siteId,
          type: cfg.type,
          // Hide abandoned auto-drafts from the main list (WordPress-style).
          status: { [Op.ne]: 'auto-draft' },
        },
        order: [['updatedAt', 'DESC']],
      });
      return { [cfg.listKey]: rows.map((r) => this.serialize(r)) };
    } catch (error) {
      throw toHttpError(error, 'Could not load content.');
    }
  }

  async get(actor: AuthUser, id: string, kind: ContentKind = 'page') {
    try {
      return await this.withAuthor(this.serialize(await this.findOwned(actor, id, kind)));
    } catch (error) {
      throw toHttpError(error, 'Could not load this item.');
    }
  }

  async create(actor: AuthUser, body: CreatePageInput, kind: ContentKind = 'page') {
    try {
      const cfg = this.cfg(kind);
      const autoDraft = body.autoDraft === true || body.status === 'auto-draft';
      const title = (body.title ?? '').trim();

      let status: PostStatus = 'draft';
      if (autoDraft) status = 'auto-draft';
      else if (body.status === 'publish') status = 'publish';

      if (status === 'publish' && !actor.capabilities.includes(cfg.publishCap)) {
        throw Forbidden(cfg.cannotPublish);
      }
      if (!autoDraft && !title) throw BadRequest('Title is required.');

      const slugBase = (body.slug?.trim() || title || `auto-draft-${Date.now()}`).trim();
      const slug = await this.uniqueSlug(actor.siteId, slugBase, kind);

      const canvasIn = body.beekiricanva;
      const codeIn = bodyBeekiriCode(body);
      let contentDoc: PageContentDoc;
      if (codeIn !== undefined) {
        contentDoc = contentFromBeekiriCode(codeIn, body.content ?? '', canvasIn ?? null);
      } else if (canvasIn !== undefined) {
        contentDoc = contentFromBeekiricanva(canvasIn, body.content ?? '', null);
      } else {
        contentDoc = contentFromHtml(body.content ?? '');
      }

      try {
        const row = await Post.create({
          siteId: actor.siteId,
          type: cfg.type,
          title: title || '',
          slug,
          status,
          content: contentDoc,
          excerpt: (body.excerpt ?? '').trim(),
          authorId: actor.id,
          updatedById: actor.id,
          publishedAt: status === 'publish' ? new Date() : null,
        });
        return await this.withAuthor(this.serialize(row));
      } catch (e) {
        if (uniqueViolation(e) !== null) throw Conflict(cfg.conflictSlug);
        throw e;
      }
    } catch (error) {
      throw toHttpError(error, 'Could not create this item.');
    }
  }

  async update(actor: AuthUser, id: string, body: UpdatePageInput, kind: ContentKind = 'page') {
    try {
      const cfg = this.cfg(kind);
      const existing = await this.findOwned(actor, id, kind);
      const data: PostPatch = { updatedById: actor.id };

      if (body.title !== undefined) data.title = body.title.trim();

      if (body.slug !== undefined) {
        const base =
          body.slug.trim() ||
          (data.title !== undefined ? data.title : existing.title) ||
          cfg.defaultSlugBase;
        data.slug = await this.uniqueSlug(actor.siteId, base, kind, id);
      } else if (
        body.title !== undefined &&
        existing.status === 'auto-draft' &&
        body.title.trim() &&
        existing.slug.startsWith('auto-draft-')
      ) {
        // First real title on an auto-draft refreshes the slug (WordPress permalink style).
        data.slug = await this.uniqueSlug(actor.siteId, body.title.trim(), kind, id);
      }

      const canvasIn = body.beekiricanva;
      const codeIn = bodyBeekiriCode(body);
      if (codeIn !== undefined || canvasIn !== undefined) {
        const existingDoc = parseContent(existing.content);
        const html = body.content !== undefined ? body.content : existingDoc.html;
        data.content =
          codeIn !== undefined
            ? contentFromBeekiriCode(
                codeIn,
                html,
                canvasIn !== undefined ? canvasIn : existingDoc.beekiricanva,
              )
            : contentFromBeekiricanva(canvasIn, html, existingDoc.beekiricode);
      } else if (body.content !== undefined) {
        const existingDoc = parseContent(existing.content);
        data.content = {
          ...contentFromHtml(body.content),
          beekiricanva: existingDoc.beekiricanva,
          beekiricode: existingDoc.beekiricode,
          version: existingDoc.beekiricanva || existingDoc.beekiricode ? 2 : 1,
          preview: null,
        };
      }

      if (body.excerpt !== undefined) data.excerpt = body.excerpt.trim();

      if (body.status !== undefined) {
        if (body.status === 'publish' && !actor.capabilities.includes(cfg.publishCap)) {
          throw Forbidden(cfg.cannotPublish);
        }
        data.status = body.status;
        if (body.status === 'publish' && !existing.publishedAt) data.publishedAt = new Date();
      } else if (existing.status === 'auto-draft') {
        // Saving an auto-draft without an explicit status promotes it to draft.
        data.status = 'draft';
      }

      if (this.shouldSnapshot(existing, data)) await this.createRevisionFrom(existing);
      const row = await this.applyUpdate(id, data, kind);
      return await this.withAuthor(this.serialize(row));
    } catch (error) {
      throw toHttpError(error, 'Could not save this item.');
    }
  }

  async listRevisions(actor: AuthUser, id: string, kind: ContentKind = 'page') {
    try {
      await this.findOwned(actor, id, kind);

      const rows = await PostRevision.findAll({
        where: { postId: id, siteId: actor.siteId },
        order: [['createdAt', 'DESC']],
        limit: MAX_REVISIONS,
      });

      const authorIds = [...new Set(rows.map((r) => r.authorId).filter(Boolean))] as string[];
      const users = authorIds.length
        ? await User.findAll({
            where: { id: { [Op.in]: authorIds } },
            attributes: ['id', 'displayName', 'username'],
          })
        : [];
      const nameById = new Map(users.map((u) => [u.id, displayName(u)]));

      return {
        revisions: rows.map((r) => ({
          id: r.id,
          title: r.title,
          slug: r.slug,
          status: r.status,
          authorId: r.authorId,
          authorName: r.authorId ? (nameById.get(r.authorId) ?? null) : null,
          createdAt: r.createdAt.toISOString(),
        })),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load revisions.');
    }
  }

  async restoreRevision(
    actor: AuthUser,
    id: string,
    revisionId: string,
    kind: ContentKind = 'page',
  ) {
    try {
      const cfg = this.cfg(kind);
      const existing = await this.findOwned(actor, id, kind);

      const revision = await PostRevision.findOne({
        where: { id: revisionId, postId: id, siteId: actor.siteId },
      });
      if (!revision) throw NotFound('Revision not found.');

      if (revision.status === 'publish' && !actor.capabilities.includes(cfg.publishCap)) {
        throw Forbidden(cfg.cannotRestorePublish);
      }

      await this.createRevisionFrom(existing);

      const row = await this.applyUpdate(
        id,
        {
          title: revision.title,
          slug: await this.uniqueSlug(
            actor.siteId,
            revision.slug || revision.title || cfg.defaultSlugBase,
            kind,
            id,
          ),
          status: revision.status === 'auto-draft' ? 'draft' : revision.status,
          content: revision.content,
          excerpt: revision.excerpt,
          updatedById: actor.id,
          ...(revision.status === 'publish' && !existing.publishedAt
            ? { publishedAt: new Date() }
            : {}),
        },
        kind,
      );
      return await this.withAuthor(this.serialize(row));
    } catch (error) {
      throw toHttpError(error, 'Could not restore the revision.');
    }
  }

  async remove(actor: AuthUser, id: string, kind: ContentKind = 'page') {
    try {
      const existing = await this.findOwned(actor, id, kind);
      await Post.destroy({ where: { id: existing.id } });
      return { ok: true, id: existing.id, title: existing.title };
    } catch (error) {
      throw toHttpError(error, 'Could not delete this item.');
    }
  }

  /** Published documents for menus / link picker. */
  async listPublishedTargets(siteId: string, kind: ContentKind = 'page') {
    try {
      const cfg = this.cfg(kind);
      const rows = await Post.findAll({
        where: { siteId, type: cfg.type, status: 'publish' },
        order: [['title', 'ASC']],
        attributes: ['id', 'title', 'slug'],
      });
      return rows.map((r) => ({
        id: r.id,
        label: r.title,
        path: cfg.pathOf(r.slug),
        source: cfg.kind,
      }));
    } catch (error) {
      throw toHttpError(error, 'Could not load published content.');
    }
  }

  async countForSite(siteId: string, kind: ContentKind = 'page') {
    try {
      const cfg = this.cfg(kind);
      return await Post.count({
        where: { siteId, type: cfg.type, status: { [Op.ne]: 'auto-draft' } },
      });
    } catch (error) {
      throw toHttpError(error, 'Could not count content.');
    }
  }

  /**
   * WordPress-style preview: store the current editor state as a tokenized snapshot.
   * Published documents keep live content untouched; drafts are saved as draft.
   */
  async createPreview(
    actor: AuthUser,
    id: string,
    body: PreviewPageInput,
    kind: ContentKind = 'page',
  ) {
    try {
      const cfg = this.cfg(kind);
      const existing = await this.findOwned(actor, id, kind);

      const title = body.title !== undefined ? body.title.trim() : existing.title;
      const excerpt = body.excerpt !== undefined ? body.excerpt.trim() : existing.excerpt;
      const existingDoc = parseContent(existing.content);
      const canvasDoc = body.beekiricanva ?? existingDoc.beekiricanva;
      const codeBody = bodyBeekiriCode(body);
      const codeDoc = codeBody !== undefined ? codeBody : existingDoc.beekiricode;
      const htmlDoc =
        codeBody !== undefined
          ? contentFromBeekiriCode(codeDoc, existingDoc.html, canvasDoc)
          : contentFromBeekiricanva(canvasDoc, existingDoc.html, existingDoc.beekiricode);

      let slug = existing.slug;
      if (body.slug !== undefined) {
        slug = await this.uniqueSlug(
          actor.siteId,
          body.slug.trim() || title || cfg.defaultSlugBase,
          kind,
          id,
        );
      } else if (
        existing.status === 'auto-draft' &&
        title &&
        existing.slug.startsWith('auto-draft-')
      ) {
        slug = await this.uniqueSlug(actor.siteId, title, kind, id);
      }

      const token = randomBytes(24).toString('hex');
      const expiresAt = new Date(Date.now() + PREVIEW_TTL_MS).toISOString();
      const preview = {
        token,
        expiresAt,
        title,
        excerpt,
        html: htmlDoc.html,
        beekiricanva: htmlDoc.beekiricanva,
        beekiricode: htmlDoc.beekiricode,
      };

      const isLive = existing.status === 'publish';
      // Published: keep the live body and only attach the preview snapshot.
      const nextDoc: PageContentDoc = isLive
        ? { ...existingDoc, preview }
        : { ...htmlDoc, preview };

      const data: PostPatch = { content: nextDoc, updatedById: actor.id };
      if (!isLive) {
        data.title = title;
        data.slug = slug;
        data.excerpt = excerpt;
        if (existing.status === 'auto-draft') data.status = 'draft';
        if (this.shouldSnapshot(existing, data)) await this.createRevisionFrom(existing);
      }

      const row = await this.applyUpdate(id, data, kind);
      const serialized = await this.withAuthor(this.serialize(row));
      return {
        [cfg.itemKey]: serialized,
        // Aliases so shared admin chrome can read either key.
        page: serialized,
        post: serialized,
        previewPath: `${serialized.path}?preview=1&token=${encodeURIComponent(token)}`,
        previewToken: token,
        expiresAt,
      };
    } catch (error) {
      throw toHttpError(error, 'Could not create a preview link.');
    }
  }

  /** Public archive listing (blog index). */
  async listPublishedPublic(kind: ContentKind = 'post') {
    try {
      const cfg = this.cfg(kind);
      const site = await findPrimarySite();
      if (!site) return { [cfg.listKey]: [] };
      const rows = await Post.findAll({
        where: { siteId: site.id, type: cfg.type, status: 'publish' },
        order: [
          ['publishedAt', 'DESC NULLS FIRST'],
          ['updatedAt', 'DESC'],
        ],
        attributes: ['title', 'slug', 'excerpt', 'publishedAt', 'updatedAt'],
      });
      return {
        [cfg.listKey]: rows.map((r) => ({
          title: r.title,
          slug: r.slug,
          path: cfg.pathOf(r.slug),
          excerpt: r.excerpt,
          publishedAt: r.publishedAt?.toISOString() ?? null,
          updatedAt: r.updatedAt.toISOString(),
        })),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load published posts.');
    }
  }

  /** Published page for `/`: frontPageId / frontPageSlug / menu `/` / slug `home`. */
  async getPublishedFrontPage(previewToken?: string) {
    try {
      const cfg = this.cfg('page');
      const site = await findPrimarySite();
      if (!site) throw NotFound(cfg.notFound);

      const opts = readOptions(site.settings?.options);
      const frontMenu = (opts.menuItems ?? []).find((m) => ((m.path || '/').trim() || '/') === '/');
      const pageById = (id?: string | null) =>
        id ? Post.findOne({ where: { siteId: site.id, type: 'page', id } }) : Promise.resolve(null);

      let row = (await pageById(opts.frontPageId)) ?? (await pageById(frontMenu?.refId));

      const slugCandidates = [
        opts.frontPageSlug,
        frontMenu?.label
          ? frontMenu.label
              .toLowerCase()
              .trim()
              .replace(/[^a-z0-9]+/g, '-')
              .replace(/^-+|-+$/g, '')
              .slice(0, 180)
          : '',
        'home',
        'index',
      ]
        .map((s) => toSlug(s || ''))
        .filter(Boolean);

      for (const slug of slugCandidates) {
        if (row) break;
        row = await Post.findOne({ where: { siteId: site.id, type: 'page', slug } });
      }

      if (!row) throw NotFound(cfg.notFound);
      return await this.getPublishedBySlug(row.slug, previewToken, 'page');
    } catch (error) {
      throw toHttpError(error, 'Could not load the front page.');
    }
  }

  async getPublishedBySlug(slug: string, previewToken?: string, kind: ContentKind = 'page') {
    try {
      const cfg = this.cfg(kind);
      const clean = toSlug(slug);
      if (!clean) throw NotFound(cfg.notFound);
      const site = await findPrimarySite();
      if (!site) throw NotFound(cfg.notFound);
      const row = await Post.findOne({ where: { siteId: site.id, type: cfg.type, slug: clean } });
      if (!row) throw NotFound(cfg.notFound);

      const doc = parseContent(row.content);
      const token = previewToken?.trim();
      if (token && doc.preview?.token && safeEqual(doc.preview.token, token)) {
        const exp = Date.parse(doc.preview.expiresAt);
        if (!Number.isFinite(exp) || exp < Date.now()) throw NotFound('Preview link has expired.');
        return {
          title: doc.preview.title || row.title,
          slug: row.slug,
          path: cfg.pathOf(row.slug),
          content: doc.preview.html,
          beekiricanva: doc.preview.beekiricanva,
          beekiricode: doc.preview.beekiricode,
          instatic: doc.preview.beekiricode,
          excerpt: doc.preview.excerpt,
          publishedAt: row.publishedAt?.toISOString() ?? null,
          updatedAt: row.updatedAt.toISOString(),
          preview: true as const,
        };
      }

      if (row.status !== 'publish') throw NotFound(cfg.notFound);

      const data = this.serialize(row);
      return {
        title: data.title,
        slug: data.slug,
        path: data.path,
        content: data.content,
        beekiricanva: data.beekiricanva,
        beekiricode: data.beekiricode,
        instatic: data.beekiricode,
        excerpt: data.excerpt,
        publishedAt: data.publishedAt,
        updatedAt: data.updatedAt,
        preview: false as const,
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load this page.');
    }
  }
}

export const pagesService = new PagesService();
