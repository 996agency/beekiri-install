import { Op } from 'sequelize';
import type { RoleSlug } from '../lib/cms-types';
import { normalizeProfileInput, parseProfile } from '../lib/users/users.profile';
import { AuditLog, Role, Session, User, sequelize } from '../models';
import type { Json } from '../models/_shared';
import type { AuthUser } from '../types/auth';
import { hashPassword } from '../utils/crypto';
import { uniqueViolation } from '../utils/db-errors';
import { BadRequest, Conflict, Forbidden, NotFound, toHttpError } from '../utils/http-error';
import type { CreateUserInput, UpdateUserInput } from '../validators/users.schema';

const ROLE_LABELS: Record<RoleSlug, string> = {
  administrator: 'Administrator',
  editor: 'Editor',
  author: 'Author',
  contributor: 'Contributor',
  subscriber: 'Subscriber',
};

const withRole = [{ model: Role, as: 'role' }];

type UserChanges = Partial<{
  username: string;
  email: string;
  displayName: string;
  roleId: string;
  profile: Json;
  passwordHash: string;
}>;

/** A friendly 409 for a duplicate username/email, otherwise the error unchanged. */
function duplicateUserError(error: unknown): unknown {
  const target = uniqueViolation(error);
  if (target === null) return error;
  if (target.includes('email')) return Conflict('That email is already registered on this site.');
  if (target.includes('username')) return Conflict('That username is already taken on this site.');
  return Conflict('Username or email is already in use on this site.');
}

export class UsersService {
  roles() {
    return (Object.keys(ROLE_LABELS) as RoleSlug[]).map((slug) => ({
      slug,
      label: ROLE_LABELS[slug],
    }));
  }

  async list(actor: AuthUser) {
    try {
      const users = await User.findAll({
        where: { siteId: actor.siteId },
        include: withRole,
        order: [
          ['isOwner', 'DESC'],
          ['username', 'ASC'],
        ],
      });
      return { users: users.map((u) => this.serialize(u)) };
    } catch (error) {
      throw toHttpError(error, 'Could not load users.');
    }
  }

  async get(actor: AuthUser, id: string) {
    try {
      return this.serialize(await this.findForSite(actor, id));
    } catch (error) {
      throw toHttpError(error, 'Could not load the user.');
    }
  }

  async create(actor: AuthUser, dto: CreateUserInput) {
    try {
      const roleSlug = dto.role as RoleSlug;
      const roleId = await this.resolveRoleId(roleSlug);
      const passwordHash = await hashPassword(dto.password);
      const profile = normalizeProfileInput({
        jobDescription: dto.jobDescription,
        customFields: dto.customFields,
      });

      const created = await User.create({
        siteId: actor.siteId,
        username: dto.username.trim(),
        email: dto.email.trim().toLowerCase(),
        displayName: dto.displayName?.trim() || dto.username,
        passwordHash,
        roleId,
        isOwner: false,
        profile,
      });

      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'user.created',
        meta: { targetUserId: created.id, username: created.username, role: roleSlug },
      });

      return this.serialize(await this.findForSite(actor, created.id));
    } catch (error) {
      throw toHttpError(duplicateUserError(error), 'Could not create the user.');
    }
  }

  async update(actor: AuthUser, id: string, dto: UpdateUserInput) {
    try {
      const existing = await this.findForSite(actor, id);
      const currentRole = (existing.role?.slug ?? 'subscriber') as RoleSlug;

      if (existing.isOwner && dto.role && dto.role !== 'administrator') {
        throw Forbidden('The site owner must remain an administrator.');
      }

      const nextRole = (existing.isOwner ? 'administrator' : (dto.role ?? currentRole)) as RoleSlug;
      if (currentRole === 'administrator' && nextRole !== 'administrator') {
        const remaining = await this.countAdministrators(actor.siteId, existing.id);
        if (remaining < 1) {
          throw BadRequest('You cannot remove the last administrator. Promote another user first.');
        }
        if (existing.id === actor.id) {
          throw Forbidden('You cannot demote your own administrator account.');
        }
      }

      const data: UserChanges = {};
      if (dto.username !== undefined) data.username = dto.username.trim();
      if (dto.email !== undefined) data.email = dto.email.trim().toLowerCase();
      if (dto.displayName !== undefined) data.displayName = dto.displayName.trim();
      if (dto.role !== undefined) data.roleId = await this.resolveRoleId(nextRole);
      if (dto.jobDescription !== undefined || dto.customFields !== undefined) {
        const current = parseProfile(existing.profile);
        data.profile = normalizeProfileInput({
          jobDescription: dto.jobDescription ?? current.jobDescription,
          customFields: dto.customFields ?? current.customFields,
        });
      }

      const passwordChanged = Boolean(dto.password);
      if (dto.password) data.passwordHash = await hashPassword(dto.password);

      await sequelize.transaction(async (transaction) => {
        await User.update(data, { where: { id: existing.id }, transaction });
        if (passwordChanged) await Session.destroy({ where: { userId: existing.id }, transaction });
      });
      const user = await this.findForSite(actor, existing.id);

      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'user.updated',
        meta: { targetUserId: user.id, passwordChanged, role: user.role?.slug },
      });

      return this.serialize(user);
    } catch (error) {
      throw toHttpError(duplicateUserError(error), 'Could not update the user.');
    }
  }

  async remove(actor: AuthUser, id: string) {
    try {
      if (actor.id === id) throw Forbidden('You cannot delete your own account.');

      const existing = await this.findForSite(actor, id);
      if (existing.isOwner) throw Forbidden('The site owner account cannot be deleted.');

      if (existing.role?.slug === 'administrator') {
        const remaining = await this.countAdministrators(actor.siteId, existing.id);
        if (remaining < 1) {
          throw BadRequest('You cannot delete the last administrator. Promote another user first.');
        }
      }

      await sequelize.transaction(async (transaction) => {
        await Session.destroy({ where: { userId: existing.id }, transaction });
        await User.destroy({ where: { id: existing.id }, transaction });
      });

      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'user.deleted',
        meta: { targetUserId: existing.id, username: existing.username },
      });

      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not delete the user.');
    }
  }

  private serialize(user: User) {
    const role = (user.role?.slug ?? 'subscriber') as RoleSlug;
    const profile = parseProfile(user.profile);
    return {
      id: user.id,
      username: user.username,
      email: user.email,
      displayName: user.displayName,
      role,
      roleLabel: ROLE_LABELS[role] ?? user.role?.name ?? role,
      isOwner: user.isOwner,
      jobDescription: profile.jobDescription,
      customFields: profile.customFields,
      createdAt: user.createdAt.toISOString(),
      updatedAt: user.updatedAt.toISOString(),
    };
  }

  private async findForSite(actor: AuthUser, id: string): Promise<User> {
    const user = await User.findOne({ where: { id, siteId: actor.siteId }, include: withRole });
    if (!user) throw NotFound('User not found.');
    return user;
  }

  private countAdministrators(siteId: string, excludeUserId?: string): Promise<number> {
    return User.count({
      where: { siteId, ...(excludeUserId ? { id: { [Op.ne]: excludeUserId } } : {}) },
      include: [{ model: Role, as: 'role', where: { slug: 'administrator' }, attributes: [] }],
    });
  }

  private async resolveRoleId(slug: RoleSlug): Promise<string> {
    const role = await Role.findOne({ where: { slug } });
    if (!role) throw BadRequest(`Unknown role “${slug}”.`);
    return role.id;
  }
}

export const usersService = new UsersService();
