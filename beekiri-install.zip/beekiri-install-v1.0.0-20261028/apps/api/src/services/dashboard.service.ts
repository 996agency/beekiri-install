import { Op, QueryTypes, col, fn, type WhereOptions } from 'sequelize';
import { readCoreManifest } from '../lib/system/core-manifest';
import { AuditLog, FieldGroup, MediaAsset, Post, Site, User, sequelize } from '../models';
import { toHttpError } from '../utils/http-error';

export type DashboardRange = 'today' | '7d' | '30d' | 'all';

type MediaTotalsRow = { mimeType: string; bytes: string | number; files: string | number };

const DAY_MS = 24 * 60 * 60 * 1000;

function rangeStart(range: DashboardRange): Date | null {
  if (range === 'all') return null;
  if (range === 'today') {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    return start;
  }
  return new Date(Date.now() - (range === '7d' ? 7 : 30) * DAY_MS);
}

function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
  if (n < 1024 * 1024 * 1024) return `${Math.round(n / (1024 * 1024))} MB`;
  return `${(n / (1024 * 1024 * 1024)).toFixed(1)} GB`;
}

/** On-disk size of the database; 0 when the role may not read it (some hosted plans). */
async function databaseBytes(): Promise<number> {
  try {
    const [row] = await sequelize.query<{ bytes: string }>(
      'SELECT pg_database_size(current_database()) AS "bytes"',
      { type: QueryTypes.SELECT },
    );
    return Number(row?.bytes) || 0;
  } catch {
    return 0;
  }
}

function emptyOverview() {
  const coreVersion = readCoreManifest().coreVersion;
  return {
    title: 'Beekiri',
    range: 'today' as const,
    coreVersion,
    atAGlance: { users: 0, posts: 0, pages: 0, fieldGroups: 0 },
    storage: {
      totalBytes: 0,
      totalLabel: '0 B',
      dialect: 'postgres' as const,
      imageBytes: 0,
      videoBytes: 0,
      documentBytes: 0,
      databaseBytes: 0,
      mediaBytes: 0,
    },
    pages: { published: 0, drafts: 0, scheduled: 0, publishedThisWeek: 0 },
    posts: { total: 0, published: 0, drafts: 0, scheduled: 0, publishedThisWeek: 0, categories: 0 },
    media: {
      files: 0,
      bytes: 0,
      bytesLabel: '0 B',
      previews: [] as { id: string; url: string; mimeType: string }[],
    },
    status: {
      site: 'live' as const,
      lastPublishAt: null as string | null,
      lastUpdateAt: null as string | null,
      coreVersion,
      fieldGroups: 0,
    },
    activity: [] as { id: string; action: string; at: string; actor: string }[],
    publishLineup: [] as {
      id: string;
      title: string;
      slug: string;
      type: 'page' | 'post';
      updatedAt: string;
    }[],
    users: 0,
    fieldGroups: 0,
  };
}

export class DashboardService {
  async overview(range: DashboardRange = 'today') {
    try {
      const site = await Site.findOne({ order: [['createdAt', 'ASC']] });
      if (!site) return emptyOverview();

      const since = rangeStart(range);
      const siteId = site.id;
      const countPosts = (where: WhereOptions<Post>) => Post.count({ where: { siteId, ...where } });
      const weekAgo = new Date(Date.now() - 7 * DAY_MS);

      const [
        userCount,
        fieldGroupCount,
        pagePublished,
        pageDraft,
        pagesThisWeek,
        postPublished,
        postDraft,
        postsThisWeek,
        postTotal,
        mediaByMime,
        recentMedia,
        activity,
        draftsReady,
        latestPublish,
        dbBytes,
      ] = await Promise.all([
        User.count({ where: { siteId } }),
        FieldGroup.count({ where: { siteId } }),
        countPosts({ type: 'page', status: 'publish' }),
        countPosts({ type: 'page', status: 'draft' }),
        countPosts({ type: 'page', status: 'publish', publishedAt: { [Op.gte]: weekAgo } }),
        countPosts({ type: 'post', status: 'publish' }),
        countPosts({ type: 'post', status: 'draft' }),
        countPosts({ type: 'post', status: 'publish', publishedAt: { [Op.gte]: weekAgo } }),
        countPosts({ type: 'post', status: { [Op.ne]: 'auto-draft' } }),
        MediaAsset.findAll({
          where: { siteId },
          attributes: [
            'mimeType',
            [fn('COALESCE', fn('SUM', col('size')), 0), 'bytes'],
            [fn('COUNT', col('id')), 'files'],
          ],
          group: ['mimeType'],
          raw: true,
        }) as unknown as Promise<MediaTotalsRow[]>,
        MediaAsset.findAll({
          where: { siteId, mimeType: { [Op.startsWith]: 'image/' } },
          order: [['createdAt', 'DESC']],
          limit: 8,
          attributes: ['id', 'url', 'mimeType', 'size'],
        }),
        AuditLog.findAll({
          where: {
            [Op.or]: [{ siteId }, { siteId: null }],
            ...(since ? { createdAt: { [Op.gte]: since } } : {}),
          },
          order: [['createdAt', 'DESC']],
          limit: 8,
          include: [{ model: User, as: 'user', attributes: ['username', 'displayName'] }],
        }),
        Post.findAll({
          where: { siteId, type: { [Op.in]: ['page', 'post'] }, status: 'draft' },
          order: [['updatedAt', 'DESC']],
          limit: 6,
          attributes: ['id', 'title', 'slug', 'updatedAt', 'type'],
        }),
        Post.findOne({
          where: { siteId, type: 'page', status: 'publish' },
          order: [['publishedAt', 'DESC NULLS FIRST']],
          attributes: ['publishedAt', 'updatedAt'],
        }),
        databaseBytes(),
      ]);

      let imageBytes = 0;
      let videoBytes = 0;
      let documentBytes = 0;
      let mediaBytes = 0;
      let mediaFiles = 0;
      for (const row of mediaByMime) {
        const bytes = Number(row.bytes) || 0;
        mediaBytes += bytes;
        mediaFiles += Number(row.files) || 0;
        const mime = row.mimeType.toLowerCase();
        if (mime.startsWith('image/')) imageBytes += bytes;
        else if (mime.startsWith('video/')) videoBytes += bytes;
        else documentBytes += bytes;
      }
      const totalBytes = mediaBytes + dbBytes;
      const coreVersion = readCoreManifest().coreVersion;

      return {
        title: site.title,
        range,
        coreVersion,
        atAGlance: {
          users: userCount,
          posts: postTotal,
          pages: pagePublished + pageDraft,
          fieldGroups: fieldGroupCount,
        },
        storage: {
          totalBytes,
          totalLabel: formatBytes(totalBytes),
          dialect: 'postgres' as const,
          imageBytes,
          videoBytes,
          documentBytes,
          databaseBytes: dbBytes,
          mediaBytes,
        },
        pages: {
          published: pagePublished,
          drafts: pageDraft,
          scheduled: 0,
          publishedThisWeek: pagesThisWeek,
        },
        posts: {
          total: postTotal,
          published: postPublished,
          drafts: postDraft,
          scheduled: 0,
          publishedThisWeek: postsThisWeek,
          categories: 0,
        },
        media: {
          files: mediaFiles,
          bytes: mediaBytes,
          bytesLabel: formatBytes(mediaBytes),
          previews: recentMedia.map((m) => ({ id: m.id, url: m.url, mimeType: m.mimeType })),
        },
        status: {
          site: 'live' as const,
          lastPublishAt: latestPublish?.publishedAt?.toISOString() ?? null,
          lastUpdateAt: latestPublish?.updatedAt?.toISOString() ?? null,
          coreVersion,
          fieldGroups: fieldGroupCount,
        },
        activity: activity.map((a) => ({
          id: a.id,
          action: a.action,
          at: a.createdAt.toISOString(),
          actor: a.user?.displayName || a.user?.username || 'System',
        })),
        publishLineup: draftsReady.map((p) => ({
          id: p.id,
          title: p.title || '(no title)',
          slug: p.slug,
          type: p.type === 'post' ? ('post' as const) : ('page' as const),
          updatedAt: p.updatedAt.toISOString(),
        })),
        users: userCount,
        fieldGroups: fieldGroupCount,
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load the dashboard.');
    }
  }
}

export const dashboardService = new DashboardService();
