// `npm start`: build what is missing, then run Beekiri and restart it when it asks to
// (after the setup wizard saves the database settings, or after a core update).
import { spawn, spawnSync } from 'node:child_process';
import { existsSync, readdirSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const API_DIR = join(dirname(fileURLToPath(import.meta.url)), '..');
const ROOT = join(API_DIR, '..', '..');
/** Must match RESTART_EXIT_CODE in src/utils/restart.ts. */
const RESTART_EXIT_CODE = 75;
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';

const SKIP_DIRS = new Set(['node_modules', 'dist', '.next', '.next-dev']);

/** Newest modification time among these files and folders (recursively). */
function newest(paths) {
  let latest = 0;
  for (const path of paths) {
    if (!existsSync(path)) continue;
    const stat = statSync(path);
    if (!stat.isDirectory()) {
      latest = Math.max(latest, stat.mtimeMs);
      continue;
    }
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      if (entry.isDirectory() && SKIP_DIRS.has(entry.name)) continue;
      latest = Math.max(latest, newest([join(path, entry.name)]));
    }
  }
  return latest;
}

const ADMIN = join(ROOT, 'apps/admin');
const WEB = join(ROOT, 'apps/web');
const builds = [
  {
    workspace: '@beekiri/admin',
    output: join(ADMIN, 'dist/index.html'),
    sources: ['src', 'public', 'index.html', 'vite.config.ts', 'package.json'].map((p) => join(ADMIN, p)),
  },
  {
    workspace: '@beekiri/web',
    // Written only by a completed build (BUILD_ID also exists after a failed one).
    output: join(WEB, '.next/prerender-manifest.json'),
    sources: ['src', 'modules', 'public', 'next.config.ts', 'package.json'].map((p) => join(WEB, p)),
  },
  {
    workspace: '@beekiri/api',
    output: join(API_DIR, 'dist/server.js'),
    sources: ['src', 'package.json'].map((p) => join(API_DIR, p)),
  },
];

for (const { workspace, output, sources } of builds) {
  const missing = !existsSync(output);
  if (!missing && statSync(output).mtimeMs >= newest(sources)) continue;
  console.log(`\nBuilding ${workspace} (${missing ? 'first start' : 'code changed since the last build'})…`);
  const result = spawnSync(npm, ['run', 'build', '-w', workspace], {
    cwd: ROOT,
    stdio: 'inherit',
    shell: process.platform === 'win32',
  });
  if (result.status !== 0) process.exit(result.status ?? 1);
}

let child;
let stopping = false;

function run() {
  child = spawn(process.execPath, [join(API_DIR, 'dist/server.js')], {
    cwd: API_DIR,
    stdio: 'inherit',
    env: { ...process.env, NODE_ENV: process.env.NODE_ENV || 'production', BEEKIRI_SUPERVISED: '1' },
  });
  child.on('exit', (code, signal) => {
    if (!stopping && code === RESTART_EXIT_CODE) return run();
    process.exit(code ?? (signal ? 1 : 0));
  });
}

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    stopping = true;
    child?.kill(signal);
  });
}

run();
