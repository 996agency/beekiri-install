import { PageHeader } from '../components/PageHeader';

import { SITE_URL as LIVE_SITE } from '../config';

export function AppearanceTemplatesPage() {
  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Templates"
        actions={
          <a className="button" href={LIVE_SITE} target="_blank" rel="noreferrer">
            View site
          </a>
        }
      />
      <p className="bk-muted">
        Theme templates and page layouts (hero, sections, and more) will be managed here.
      </p>
      <div className="beekiri-notice is-info">
        <p>
          Templates are not selectable yet. Layout sections already ship under each theme’s{' '}
          <code>layouts/</code> folder and appear in the page editor via Backend Fields.
        </p>
      </div>
    </div>
  );
}