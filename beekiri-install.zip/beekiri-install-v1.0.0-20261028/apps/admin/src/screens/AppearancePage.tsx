import { ChangeEvent, DragEvent, useCallback, useEffect, useRef, useState } from 'react';
import { api, apiUpload, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';

type ThemeItem = {
  slug: string;
  name: string;
  version: string;
  description: string;
  author: string;
  tags: string[];
  active: boolean;
  builtin: boolean;
  deletable: boolean;
  screenshotUrl: string;
};

type ThemesResponse = {
  themes: ThemeItem[];
  active: string;
  installed?: string;
};

import { SITE_URL as LIVE_SITE } from '../config';

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

export function AppearancePage() {
  const auth = useAuth();
  const canEdit = auth.user?.capabilities.includes('edit_theme_options') ?? false;
  const fileRef = useRef<HTMLInputElement>(null);
  const [themes, setThemes] = useState<ThemeItem[]>([]);
  const [activeSlug, setActiveSlug] = useState('beekiri');
  const [selectedSlug, setSelectedSlug] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const selected = selectedSlug
    ? themes.find((t) => t.slug === selectedSlug) ?? null
    : null;

  const applyList = (data: ThemesResponse) => {
    setThemes(data.themes);
    setActiveSlug(data.active);
    if (selectedSlug && !data.themes.some((t) => t.slug === selectedSlug)) {
      setSelectedSlug(null);
    }
  };

  const load = useCallback(async () => {
    setError('');
    try {
      const data = await api<ThemesResponse>('/api/themes');
      applyList(data);
    } catch (e) {
      setError(formatError(e));
    } finally {
      setLoading(false);
    }
  }, [selectedSlug]);

  useEffect(() => {
    void load();
  }, []);

  useEffect(() => {
    if (!selectedSlug) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelectedSlug(null);
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [selectedSlug]);

  const activate = async (slug: string) => {
    if (!canEdit || busy || slug === activeSlug) return;
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const data = await api<ThemesResponse>('/api/themes/activate', {
        method: 'POST',
        json: { slug },
      });
      applyList(data);
      setNotice(`“${data.themes.find((t) => t.slug === data.active)?.name ?? slug}” is now active.`);
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const deactivate = async (slug: string) => {
    if (!canEdit || busy) return;
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const data = await api<ThemesResponse>('/api/themes/deactivate', {
        method: 'POST',
        json: { slug },
      });
      applyList(data);
      setNotice('Theme deactivated. Beekiri starter is active again.');
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const remove = async (theme: ThemeItem) => {
    if (!canEdit || busy || !theme.deletable) return;
    if (
      !window.confirm(
        `Delete “${theme.name}”? This removes the theme files. You can’t undo this.`,
      )
    ) {
      return;
    }
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const data = await api<ThemesResponse>(`/api/themes/${encodeURIComponent(theme.slug)}`, {
        method: 'DELETE',
      });
      applyList(data);
      setSelectedSlug(null);
      setNotice(`“${theme.name}” was deleted.`);
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const uploadFile = async (file: File | null | undefined) => {
    if (!canEdit || busy || !file) return;
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const form = new FormData();
      form.append('file', file);
      const data = await apiUpload<ThemesResponse>('/api/themes/upload', form);
      applyList(data);
      const installed = data.themes.find((t) => t.slug === data.installed);
      setNotice(
        installed
          ? `“${installed.name}” uploaded. Activate it when you’re ready.`
          : 'Theme uploaded.',
      );
      if (data.installed) setSelectedSlug(data.installed);
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const onPick = (e: ChangeEvent<HTMLInputElement>) => {
    void uploadFile(e.target.files?.[0]);
  };

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files?.[0];
    void uploadFile(file);
  };

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Themes"
        actions={
          <>
            {canEdit ? (
              <button
                type="button"
                className="button button-primary"
                disabled={busy}
                onClick={() => fileRef.current?.click()}
              >
                {busy ? 'Working…' : 'Upload theme'}
              </button>
            ) : null}
            <a className="button" href={LIVE_SITE} target="_blank" rel="noreferrer">
              View site
            </a>
            <input
              ref={fileRef}
              type="file"
              accept=".zip,application/zip"
              hidden
              onChange={onPick}
            />
          </>
        }
      />
      <p className="bk-muted">
        Manage themes for your public site. Click a theme for details. Upload a ZIP with a{' '}
        <code>theme.json</code> to add more.
      </p>

      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice('')} />
      ) : null}

      {!canEdit ? (
        <div className="beekiri-notice is-info">
          <p>You need the edit_theme_options capability to manage themes.</p>
        </div>
      ) : (
        <div
          className={`bk-media-drop${dragging ? ' is-dragging' : ''}`}
          onDragEnter={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragOver={(e) => e.preventDefault()}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
        >
          <p>
            Drop a theme <strong>.zip</strong> here, or use <strong>Upload theme</strong>. Packages
            need a <code>theme.json</code> (name, slug, version). Built-in themes can’t be deleted.
          </p>
        </div>
      )}

      {loading ? (
        <p className="bk-muted">Loading themes…</p>
      ) : (
        <div className="bk-themes">
          {themes.map((theme) => (
            <button
              key={theme.slug}
              type="button"
              className="bk-theme-card"
              onClick={() => setSelectedSlug(theme.slug)}
            >
              <div className="bk-theme-card__shot">
                <img
                  src={theme.screenshotUrl}
                  alt=""
                  width={600}
                  height={450}
                  loading="lazy"
                />
              </div>
              <div className="bk-theme-card__body">
                <div className="bk-theme-card__meta">
                  <span className="bk-theme-card__name">
                    {theme.name}
                    {theme.active ? (
                      <span className="bk-theme-card__status">Active</span>
                    ) : null}
                    {theme.builtin ? (
                      <span className="bk-theme-card__status is-muted">Built-in</span>
                    ) : null}
                  </span>
                  <span className="bk-theme-card__by">
                    v{theme.version}
                    {theme.author ? ` · ${theme.author}` : ''}
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}

      {selected ? (
        <div
          className="bk-media-modal"
          role="dialog"
          aria-modal="true"
          aria-labelledby="bk-theme-modal-title"
          onClick={(e) => {
            if (e.target === e.currentTarget) setSelectedSlug(null);
          }}
        >
          <div className="bk-media-modal__panel">
            <div className="bk-media-modal__head">
              <h2 id="bk-theme-modal-title" className="bk-media-modal__title">
                {selected.name}
              </h2>
              <button
                type="button"
                className="button"
                onClick={() => setSelectedSlug(null)}
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            <div className="bk-media-modal__body">
              <div className="bk-media-modal__preview">
                <img src={selected.screenshotUrl} alt="" />
              </div>

              <div className="bk-media-modal__details">
                <div className="bk-theme-modal__headline">
                  <p className="bk-theme-modal__title-row">
                    <strong>{selected.name}</strong>
                    {selected.active ? (
                      <span className="bk-theme-card__status">Active</span>
                    ) : null}
                    {selected.builtin ? (
                      <span className="bk-theme-card__status is-muted">Built-in</span>
                    ) : null}
                  </p>
                  {selected.description ? (
                    <p className="bk-theme-card__desc">{selected.description}</p>
                  ) : null}
                </div>

                {selected.tags.length ? (
                  <ul className="bk-theme-card__tags">
                    {selected.tags.map((tag) => (
                      <li key={tag}>{tag}</li>
                    ))}
                  </ul>
                ) : null}

                <dl className="bk-media-meta">
                  <div>
                    <dt>Slug</dt>
                    <dd>{selected.slug}</dd>
                  </div>
                  <div>
                    <dt>Version</dt>
                    <dd>{selected.version}</dd>
                  </div>
                  <div>
                    <dt>Author</dt>
                    <dd>{selected.author || '—'}</dd>
                  </div>
                  <div>
                    <dt>Type</dt>
                    <dd>{selected.builtin ? 'Built-in' : 'Uploaded'}</dd>
                  </div>
                  <div>
                    <dt>Status</dt>
                    <dd>{selected.active ? 'Active' : 'Inactive'}</dd>
                  </div>
                </dl>

                <div className="bk-media-modal__actions">
                  {canEdit ? (
                    selected.active ? (
                      selected.slug === 'beekiri' ? null : (
                        <button
                          type="button"
                          className="button"
                          disabled={busy}
                          onClick={() => void deactivate(selected.slug)}
                        >
                          Deactivate
                        </button>
                      )
                    ) : (
                      <button
                        type="button"
                        className="button button-primary"
                        disabled={busy}
                        onClick={() => void activate(selected.slug)}
                      >
                        {busy ? 'Activating…' : 'Activate'}
                      </button>
                    )
                  ) : null}
                  <a className="button" href={LIVE_SITE} target="_blank" rel="noreferrer">
                    View site
                  </a>
                  {canEdit && selected.deletable ? (
                    <button
                      type="button"
                      className="button"
                      disabled={busy}
                      onClick={() => void remove(selected)}
                    >
                      Delete
                    </button>
                  ) : null}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
