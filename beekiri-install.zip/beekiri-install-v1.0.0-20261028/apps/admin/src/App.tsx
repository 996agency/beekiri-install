import { Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { useCallback, useEffect, useState } from 'react';
import { api, ApiError } from './api/client';
import { useAuth } from './auth/AuthContext';
import { InstallWizard } from './screens/InstallWizard';
import { LoginScreen } from './screens/LoginScreen';
import { LostPasswordScreen } from './screens/LostPasswordScreen';
import { ResetPasswordScreen } from './screens/ResetPasswordScreen';
import { ApiUnavailable } from './screens/ApiUnavailable';
import { AdminShell } from './shell/AdminShell';
import { Dashboard } from './screens/Dashboard';
import { PlaceholderScreen } from './screens/PlaceholderScreen';
import { SettingsPage } from './screens/SettingsPage';
import { UsersPage } from './screens/UsersPage';
import { MediaPage } from './screens/MediaPage';
import { AppearancePage } from './screens/AppearancePage';
import { AppearanceHeaderPage } from './screens/AppearanceHeaderPage';
import { AppearanceFooterPage } from './screens/AppearanceFooterPage';
import { AppearanceTemplatesPage } from './screens/AppearanceTemplatesPage';
import { PagesPage, PostsPage } from './screens/PagesPage';
import {
  PageEditorPage,
  PageNewRedirect,
  PostEditorPage,
  PostNewRedirect,
} from './screens/PageEditorPage';
import { BackendFieldsPage } from './screens/BackendFieldsPage';
import { PostTypesPage } from './screens/fields/PostTypesPage';
import { TaxonomiesPage } from './screens/fields/TaxonomiesPage';
import { OptionsPagesPage } from './screens/fields/OptionsPagesPage';
import { FieldsSettingsPage } from './screens/fields/FieldsSettingsPage';
import { FieldsToolsPage } from './screens/fields/FieldsToolsPage';
import { FieldGroupEditPage } from './screens/fields/FieldGroupEditPage';

/** Kill any .php / wp-* URL immediately — product has zero PHP routes. */
function StripLegacyPaths({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const path = location.pathname.toLowerCase();

  if (path.includes('.php') || path.startsWith('/wp-') || path === '/wp-admin') {
    const toAdmin = path.includes('admin') || path.includes('upload') || path.includes('edit');
    return <Navigate to={toAdmin ? '/admin' : '/admin/login'} replace />;
  }

  return <>{children}</>;
}

type InstallState = 'loading' | 'installed' | 'not_installed' | 'api_down';

/**
 * Fresh DB → /install.
 * Installed → /login or /admin (no separate preview landing on the admin host).
 * API down → never treat as “not installed” (would falsely force the installer).
 */
function Gate({ children }: { children: React.ReactNode }) {
  const auth = useAuth();
  const [state, setState] = useState<InstallState>('loading');
  const [apiDetail, setApiDetail] = useState<string | null>(null);
  const [tick, setTick] = useState(0);
  const location = useLocation();

  const checkInstall = useCallback(() => {
    setState('loading');
    setApiDetail(null);
    api<{ installed: boolean }>('/api/install/status')
      .then((s) => setState(s.installed ? 'installed' : 'not_installed'))
      .catch((e) => {
        setState('api_down');
        // Technical detail is DEV-only (collapsed on the downtime screen).
        // Never surface ports, paths, or CLI commands to clients.
        const raw =
          e instanceof ApiError
            ? e.message
            : e instanceof Error
              ? e.message
              : null;
        const looksTechnical =
          Boolean(raw) &&
          (/port\s*\d+/i.test(raw!) ||
            /pnpm|npx|npm |yarn |docker/i.test(raw!) ||
            /127\.0\.0\.1|localhost:\d+/i.test(raw!));
        setApiDetail(looksTechnical ? null : raw);
      });
  }, []);

  useEffect(() => {
    checkInstall();
  }, [checkInstall, location.pathname, tick]);

  if (auth.loading || state === 'loading') {
    return (
      <p
        style={{
          padding: 40,
          fontFamily:
            "'SF Pro Text', 'SF Pro Display', -apple-system, BlinkMacSystemFont, 'Helvetica Neue', Helvetica, Arial, sans-serif",
        }}
      >
        Loading…
      </p>
    );
  }

  if (state === 'api_down') {
    return (
      <ApiUnavailable
        detail={apiDetail}
        onRetry={() => setTick((n) => n + 1)}
      />
    );
  }

  if (state === 'not_installed' && !location.pathname.startsWith('/admin/install')) {
    return <Navigate to="/admin/install" replace />;
  }

  if (state === 'installed' && location.pathname.startsWith('/admin/install')) {
    return <Navigate to="/admin" replace />;
  }

  return <>{children}</>;
}

function RequireAuth() {
  const auth = useAuth();
  const location = useLocation();
  if (auth.loading) return <p style={{ padding: 40 }}>Loading…</p>;
  if (!auth.authenticated) {
    const next = encodeURIComponent(location.pathname + location.search);
    return <Navigate to={`/admin/login?redirect_to=${next}`} replace />;
  }
  return (
    <AdminShell>
      <Outlet />
    </AdminShell>
  );
}

/** Admin host root → dashboard when signed in, otherwise login. Public site lives on the web app. */
function HomeRedirect() {
  const auth = useAuth();
  if (auth.loading) return <p style={{ padding: 40 }}>Loading…</p>;
  if (auth.authenticated) return <Navigate to="/admin" replace />;
  return <Navigate to="/admin/login" replace />;
}

export function App() {
  return (
    <StripLegacyPaths>
      <Gate>
        <Routes>
          <Route path="/admin/install/*" element={<InstallWizard />} />
          <Route path="/admin/login" element={<LoginScreen />} />
          <Route path="/admin/lost-password" element={<LostPasswordScreen />} />
          <Route path="/admin/lostpassword" element={<Navigate to="/admin/lost-password" replace />} />
          <Route path="/admin/reset-password" element={<ResetPasswordScreen />} />

          <Route path="/" element={<HomeRedirect />} />

          <Route path="/admin" element={<RequireAuth />}>
            <Route index element={<Dashboard />} />
            <Route path="posts" element={<PostsPage />} />
            <Route path="posts/new" element={<PostNewRedirect />} />
            <Route path="posts/:id" element={<PostEditorPage />} />
            <Route path="media" element={<MediaPage />} />
            <Route path="pages" element={<PagesPage />} />
            <Route path="pages/new" element={<PageNewRedirect />} />
            <Route path="pages/:id" element={<PageEditorPage />} />
            <Route path="fields" element={<BackendFieldsPage />} />
            <Route path="fields/post-types" element={<PostTypesPage />} />
            <Route path="fields/taxonomies" element={<TaxonomiesPage />} />
            <Route path="fields/options-pages" element={<OptionsPagesPage />} />
            <Route path="fields/settings" element={<FieldsSettingsPage />} />
            <Route path="fields/tools" element={<FieldsToolsPage />} />
            <Route path="fields/new" element={<FieldGroupEditPage key="new" />} />
            <Route path="fields/:id" element={<FieldGroupEditPage />} />
            <Route path="appearance" element={<AppearancePage />} />
            <Route path="appearance/header" element={<AppearanceHeaderPage />} />
            <Route path="appearance/footer" element={<AppearanceFooterPage />} />
            <Route path="appearance/templates" element={<AppearanceTemplatesPage />} />
            <Route
              path="extensions"
              element={
                <PlaceholderScreen
                  title="Extensions"
                  phase="Not available"
                  note="Extensions are not available yet. A Beekiri add-on system may land in a later release."
                />
              }
            />
            <Route path="users" element={<UsersPage />} />
            <Route path="settings" element={<SettingsPage />} />
            <Route path="*" element={<PlaceholderScreen title="Not Found" phase="" />} />
          </Route>

          <Route path="*" element={<Navigate to="/admin" replace />} />
        </Routes>
      </Gate>
    </StripLegacyPaths>
  );
}
