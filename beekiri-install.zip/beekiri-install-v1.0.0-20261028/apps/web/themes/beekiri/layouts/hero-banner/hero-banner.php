<?php
/* @beekiri-managed — remove this line to keep your custom file */
/**
 * Hero Banner
 * Field group: group_hero_banner · slug: hero-banner
 *
 * Beekiri layout: get_bee_field(), have_bee_rows(), the_bee_row(), get_bee_row_layout().
 * Classes: one short name per field — bk-{name} (e.g. bk-title). Prefer Bee API names.
 */
$classes = array(
  'hero-banner',
  'section',
);
?>
<section class="<?php echo esc_attr(implode(' ', $classes)); ?>" data-layout="hero-banner" <?php get_Section_Override(); ?>>
  <div class="wrapper">
    <div class="inner">
      <?php $title = get_bee_field('title'); ?>
      <?php if ($title !== null && $title !== '') : ?>
        <h2 class="bk-title"><?php echo esc_html($title); ?></h2>
      <?php endif; ?>

      <?php if (get_bee_field('options')) : ?>
        <div class="bk-options"><?php /* options is enabled */ ?></div>
      <?php endif; ?>
    </div>
  </div>
</section>
