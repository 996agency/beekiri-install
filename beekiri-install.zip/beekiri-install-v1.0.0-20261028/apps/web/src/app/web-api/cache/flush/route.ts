import { revalidatePath } from 'next/cache';
import { NextResponse } from 'next/server';

/**
 * Full public-site cache flush — called from Admin → Settings → Advanced.
 * Called by the Beekiri server (same process) with CACHE_FLUSH_SECRET via Bearer / x-beekiri-flush.
 */
export async function POST(req: Request) {
  const secret =
    process.env.CACHE_FLUSH_SECRET?.trim() ||
    process.env.SESSION_SECRET?.trim() ||
    '';
  const auth = req.headers.get('authorization') || '';
  const header = req.headers.get('x-beekiri-flush') || '';
  const token = auth.toLowerCase().startsWith('bearer ')
    ? auth.slice(7).trim()
    : header.trim();

  if (!secret || token !== secret) {
    return NextResponse.json({ ok: false, message: 'Unauthorized' }, { status: 401 });
  }

  // Bust every public route segment (layout hosts header/footer).
  revalidatePath('/', 'layout');
  revalidatePath('/');
  revalidatePath('/blog');
  revalidatePath('/blog/[slug]', 'page');
  revalidatePath('/[slug]', 'page');

  return NextResponse.json({
    ok: true,
    flushedAt: new Date().toISOString(),
    paths: ['/', '/blog', '/[slug]', 'layout'],
  });
}
