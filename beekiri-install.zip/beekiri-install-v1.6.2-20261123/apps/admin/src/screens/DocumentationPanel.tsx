import { useEffect, useMemo, useRef, useState } from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, MagnifyingGlass, X } from '@phosphor-icons/react';
import { DOC_GROUPS, DOCS, findDoc, type DocArticle } from '../docs';
import { docHeadings, Markdown, plainText } from '../docs/Markdown';
import '../docs/documentation.css';

/**
 * Settings → Documentation: how every part of Beekiri works, for site owners and developers.
 * The article is in the address (`?tab=documentation&doc=pages-and-editor#layers`), so a link
 * opens the right page and section.
 */

type Hit = { doc: DocArticle; score: number; snippet: string };

const MIN_QUERY = 2;

/** The words around the first match, with the match marked. */
function snippetOf(text: string, query: string): string {
  const at = text.toLowerCase().indexOf(query.toLowerCase());
  if (at < 0) return '';
  const start = Math.max(0, text.lastIndexOf(' ', Math.max(0, at - 70)) + 1);
  const end = Math.min(text.length, at + query.length + 110);
  return `${start > 0 ? '…' : ''}${text.slice(start, end).trim()}${end < text.length ? '…' : ''}`;
}

export function DocumentationPanel() {
  const [params] = useSearchParams();
  const location = useLocation();
  const navigate = useNavigate();
  const doc = findDoc(params.get('doc'));
  const [query, setQuery] = useState('');
  const topRef = useRef<HTMLDivElement>(null);

  const index = useMemo(() => DOCS.map((d) => ({ doc: d, text: plainText(d.body) })), []);

  const hits: Hit[] | null = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (q.length < MIN_QUERY) return null;
    const words = q.split(/\s+/).filter(Boolean);
    return index
      .map(({ doc: d, text }) => {
        const lower = text.toLowerCase();
        let score = 0;
        for (const w of words) {
          if (d.title.toLowerCase().includes(w)) score += 6;
          if ((d.keywords ?? '').toLowerCase().includes(w)) score += 4;
          if (d.summary.toLowerCase().includes(w)) score += 3;
          if (lower.includes(w)) score += 1 + Math.min(4, lower.split(w).length - 2);
        }
        if (!words.every((w) => `${d.title} ${d.keywords ?? ''} ${d.summary} ${lower}`.toLowerCase().includes(w))) score = 0;
        return { doc: d, score, snippet: snippetOf(text, words[0]) || d.summary };
      })
      .filter((h) => h.score > 0)
      .sort((a, b) => b.score - a.score);
  }, [index, query]);

  /** Opens an article (and a section of it); the address changes too, so Back returns. */
  const open = (id: string, anchor?: string) => {
    setQuery('');
    const next = new URLSearchParams(params);
    next.set('tab', 'documentation');
    if (id) next.set('doc', id);
    else next.delete('doc');
    navigate({ search: `?${next.toString()}`, hash: anchor ? `#${anchor}` : '' });
    if (!anchor) requestAnimationFrame(() => topRef.current?.scrollIntoView({ block: 'start' }));
  };

  /** A section of the open article (looked up inside it, never elsewhere on the screen). */
  const sectionOf = (anchor: string) => topRef.current?.querySelector<HTMLElement>(`[id="${CSS.escape(anchor)}"]`) ?? null;

  // A link with a section (#layers) lands on it once the article is there.
  useEffect(() => {
    const anchor = location.hash.slice(1);
    if (!anchor) return;
    const id = window.requestAnimationFrame(() => sectionOf(decodeURIComponent(anchor))?.scrollIntoView({ block: 'start' }));
    return () => window.cancelAnimationFrame(id);
  }, [doc?.id, location.hash]);

  const at = doc ? DOCS.indexOf(doc) : -1;
  const prev = at > 0 ? DOCS[at - 1] : null;
  const next = at >= 0 && at < DOCS.length - 1 ? DOCS[at + 1] : null;
  const headings = doc ? docHeadings(doc.body).filter((h) => h.level === 2) : [];
  const group = doc ? DOC_GROUPS.find((g) => g.id === doc.group) : null;

  return (
    <div className="bk-docs" ref={topRef}>
      <div className="bk-panel">
        <div className="bk-panel__head bk-docs__head">
          <div>
            <h2 className="bk-panel__title">Documentation</h2>
            <p className="bk-panel__lead">How every part of Beekiri works: step-by-step guides for running your site, and a reference for developers.</p>
          </div>
          <div className="bk-docs__search">
            <MagnifyingGlass size={16} aria-hidden />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search the documentation"
              aria-label="Search the documentation"
            />
            {query ? (
              <button type="button" className="bk-docs__search-clear" onClick={() => setQuery('')} aria-label="Clear the search">
                <X size={14} aria-hidden />
              </button>
            ) : null}
          </div>
        </div>

        <div className="bk-panel__body">
          <div className="bk-docs__layout">
            <nav className="bk-docs__nav" aria-label="Documentation">
              <a
                href="?tab=documentation"
                className={`bk-docs__nav-home${!doc && !hits ? ' is-active' : ''}`}
                aria-current={!doc && !hits ? 'page' : undefined}
                onClick={(e) => {
                  e.preventDefault();
                  open('');
                }}
              >
                All topics
              </a>
              {DOC_GROUPS.map((g) => (
                <div key={g.id} className="bk-docs__nav-group">
                  <p className="bk-docs__nav-title">{g.title}</p>
                  {DOCS.filter((d) => d.group === g.id).map((d) => (
                    <a
                      key={d.id}
                      href={`?tab=documentation&doc=${d.id}`}
                      className={`bk-docs__nav-link${doc?.id === d.id && !hits ? ' is-active' : ''}`}
                      aria-current={doc?.id === d.id && !hits ? 'page' : undefined}
                      onClick={(e) => {
                        e.preventDefault();
                        open(d.id);
                      }}
                    >
                      {d.title}
                    </a>
                  ))}
                </div>
              ))}
            </nav>

            <div className="bk-docs__main">
              {hits ? (
                <section aria-live="polite">
                  <h2 className="bk-docs__title">
                    {hits.length ? `${hits.length} ${hits.length === 1 ? 'result' : 'results'} for “${query.trim()}”` : `Nothing found for “${query.trim()}”`}
                  </h2>
                  {hits.length ? (
                    <ul className="bk-docs__results">
                      {hits.map((h) => (
                        <li key={h.doc.id}>
                          <a
                            href={`?tab=documentation&doc=${h.doc.id}`}
                            onClick={(e) => {
                              e.preventDefault();
                              open(h.doc.id);
                            }}
                          >
                            <strong>{h.doc.title}</strong>
                            <small>{DOC_GROUPS.find((g) => g.id === h.doc.group)?.title}</small>
                          </a>
                          <p>{h.snippet}</p>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="bk-docs__summary">Try other words, or browse the topics on the left. Something missing? Tell us with Feedback at the bottom of the menu.</p>
                  )}
                </section>
              ) : doc ? (
                <article>
                  <p className="bk-docs__crumb">
                    <a
                      href="?tab=documentation"
                      onClick={(e) => {
                        e.preventDefault();
                        open('');
                      }}
                    >
                      Documentation
                    </a>
                    <span aria-hidden> / </span>
                    {group?.title}
                  </p>
                  <h2 className="bk-docs__title">{doc.title}</h2>
                  <p className="bk-docs__summary">{doc.summary}</p>
                  {headings.length >= 3 ? (
                    <nav className="bk-docs__toc" aria-label="On this page">
                      <p>On this page</p>
                      <ul>
                        {headings.map((h) => (
                          <li key={h.id}>
                            <a href={`#${h.id}`}>{h.text}</a>
                          </li>
                        ))}
                      </ul>
                    </nav>
                  ) : null}
                  <Markdown source={doc.body} onOpenDoc={open} />
                  <nav className="bk-docs__pager" aria-label="More documentation">
                    {prev ? (
                      <a
                        href={`?tab=documentation&doc=${prev.id}`}
                        onClick={(e) => {
                          e.preventDefault();
                          open(prev.id);
                        }}
                      >
                        <small>
                          <ArrowLeft size={12} aria-hidden /> Previous
                        </small>
                        <strong>{prev.title}</strong>
                      </a>
                    ) : (
                      <span />
                    )}
                    {next ? (
                      <a
                        className="is-next"
                        href={`?tab=documentation&doc=${next.id}`}
                        onClick={(e) => {
                          e.preventDefault();
                          open(next.id);
                        }}
                      >
                        <small>
                          Next <ArrowRight size={12} aria-hidden />
                        </small>
                        <strong>{next.title}</strong>
                      </a>
                    ) : null}
                  </nav>
                </article>
              ) : (
                <section>
                  <h2 className="bk-docs__title">All topics</h2>
                  <p className="bk-docs__summary">
                    New to Beekiri? Start with{' '}
                    <a
                      href="?tab=documentation&doc=welcome"
                      onClick={(e) => {
                        e.preventDefault();
                        open('welcome');
                      }}
                    >
                      Welcome to Beekiri
                    </a>
                    . Or open the part of the site you are working on.
                  </p>
                  <div className="bk-docs__cards">
                    {DOC_GROUPS.map((g) => (
                      <section key={g.id} className="bk-docs__card">
                        <h3>{g.title}</h3>
                        <p>{g.description}</p>
                        <ul>
                          {DOCS.filter((d) => d.group === g.id).map((d) => (
                            <li key={d.id}>
                              <a
                                href={`?tab=documentation&doc=${d.id}`}
                                onClick={(e) => {
                                  e.preventDefault();
                                  open(d.id);
                                }}
                              >
                                {d.title}
                              </a>
                            </li>
                          ))}
                        </ul>
                      </section>
                    ))}
                  </div>
                </section>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
