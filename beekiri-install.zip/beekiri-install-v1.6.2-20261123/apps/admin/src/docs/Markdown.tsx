import { Fragment, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { useAdminHref } from '../lib/AdminEntryContext';

/**
 * The documentation's Markdown, drawn as React elements (never as HTML from the text): headings with
 * anchors, paragraphs, lists, tables, code, callouts ("> **Tip:** …") and links. Link targets:
 * `doc:page-editor#layers` (another article), `admin:settings?tab=email` (an admin screen),
 * `#section` (this article) and https addresses (a new tab).
 */

export type DocHeading = { id: string; text: string; level: number };

/** "Pages & the editor" → "pages-the-editor": the anchor of a heading. */
export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/`/g, '')
    .replace(/&/g, ' ')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/** The article's sections (## headings), for "On this page". */
export function docHeadings(markdown: string): DocHeading[] {
  const out: DocHeading[] = [];
  let fenced = false;
  for (const line of markdown.split('\n')) {
    if (line.trimStart().startsWith('```')) fenced = !fenced;
    const m = !fenced && line.match(/^(#{2,3})\s+(.+?)\s*$/);
    if (m) out.push({ id: slugify(m[2]), text: plainText(m[2]), level: m[1].length });
  }
  return out;
}

/** Text without inline Markdown (for search and headings). */
export function plainText(markdown: string): string {
  return markdown
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/!?\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/[*_`>#|]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

type Props = {
  source: string;
  /** Opens another article (and a section of it). */
  onOpenDoc: (id: string, anchor?: string) => void;
};

const CALLOUTS: Record<string, 'tip' | 'note' | 'important' | 'warning'> = {
  tip: 'tip',
  note: 'note',
  important: 'important',
  warning: 'warning',
  caution: 'warning',
};

export function Markdown({ source, onOpenDoc }: Props) {
  const href = useAdminHref();

  const link = (label: ReactNode, target: string, key: number): ReactNode => {
    if (target.startsWith('doc:')) {
      const [id, anchor] = target.slice(4).split('#');
      return (
        <a key={key} href={`?tab=documentation&doc=${encodeURIComponent(id)}${anchor ? `#${anchor}` : ''}`} onClick={(e) => { e.preventDefault(); onOpenDoc(id, anchor); }}>
          {label}
        </a>
      );
    }
    if (target.startsWith('admin:')) {
      return (
        <Link key={key} to={href(target.slice(6))}>
          {label}
        </Link>
      );
    }
    if (target.startsWith('#')) {
      return (
        <a key={key} href={target}>
          {label}
        </a>
      );
    }
    if (/^https:\/\//.test(target)) {
      return (
        <a key={key} href={target} target="_blank" rel="noopener noreferrer">
          {label}
        </a>
      );
    }
    return <Fragment key={key}>{label}</Fragment>;
  };

  /** **bold**, *italic*, `code`, [links](target). */
  const inline = (text: string): ReactNode[] => {
    const out: ReactNode[] = [];
    const re = /(`[^`]+`)|(\*\*[^*]+\*\*)|(\*[^*\s][^*]*\*)|(\[[^\]]+\]\([^)\s]+\))/g;
    let last = 0;
    let m: RegExpExecArray | null;
    let key = 0;
    while ((m = re.exec(text))) {
      if (m.index > last) out.push(text.slice(last, m.index));
      const token = m[0];
      if (m[1]) out.push(<code key={key++}>{token.slice(1, -1)}</code>);
      else if (m[2]) out.push(<strong key={key++}>{inline(token.slice(2, -2))}</strong>);
      else if (m[3]) out.push(<em key={key++}>{inline(token.slice(1, -1))}</em>);
      else {
        const l = token.match(/^\[([^\]]+)\]\(([^)\s]+)\)$/)!;
        out.push(link(inline(l[1]), l[2], key++));
      }
      last = m.index + token.length;
    }
    if (last < text.length) out.push(text.slice(last));
    return out;
  };

  const blocks: ReactNode[] = [];
  const lines = source.replace(/\r/g, '').split('\n');
  let i = 0;
  const isBlockStart = (line: string) =>
    /^(#{2,4})\s/.test(line) || /^\s*([-*]|\d+[.)])\s+/.test(line) || line.startsWith('```') || line.startsWith('>') || /^\|.*\|\s*$/.test(line) || /^---+\s*$/.test(line);

  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) {
      i++;
      continue;
    }

    // Fenced code.
    if (line.startsWith('```')) {
      const code: string[] = [];
      i++;
      while (i < lines.length && !lines[i].startsWith('```')) code.push(lines[i++]);
      i++;
      blocks.push(
        <pre key={blocks.length} className="bk-docs__code">
          <code>{code.join('\n')}</code>
        </pre>,
      );
      continue;
    }

    // Headings: ## is a section (h3 under the article title), ### and #### below it.
    const heading = line.match(/^(#{2,4})\s+(.+?)\s*$/);
    if (heading) {
      const level = heading[1].length;
      const id = slugify(heading[2]);
      const Tag = (level === 2 ? 'h3' : level === 3 ? 'h4' : 'h5') as 'h3' | 'h4' | 'h5';
      blocks.push(
        <Tag key={blocks.length} id={id} className={`bk-docs__h${level}`}>
          {inline(heading[2])}
        </Tag>,
      );
      i++;
      continue;
    }

    if (/^---+\s*$/.test(line)) {
      blocks.push(<hr key={blocks.length} className="bk-docs__rule" />);
      i++;
      continue;
    }

    // Callouts: > **Tip:** … (Tip, Note, Important, Warning).
    if (line.startsWith('>')) {
      const quoted: string[] = [];
      while (i < lines.length && lines[i].startsWith('>')) quoted.push(lines[i++].replace(/^>\s?/, ''));
      const text = quoted.join(' ').trim();
      const label = text.match(/^\*\*([A-Za-z]+):\*\*\s*/);
      const kind = label ? CALLOUTS[label[1].toLowerCase()] : undefined;
      blocks.push(
        <div key={blocks.length} className={`bk-docs__callout is-${kind ?? 'note'}`} role="note">
          {label ? <strong className="bk-docs__callout-label">{label[1]}</strong> : null}
          <p>{inline(label ? text.slice(label[0].length) : text)}</p>
        </div>,
      );
      continue;
    }

    // Tables: | a | b | with a |---| row under the head.
    if (/^\|.*\|\s*$/.test(line) && i + 1 < lines.length && /^\|[\s:|-]+\|\s*$/.test(lines[i + 1])) {
      const cells = (row: string) => row.trim().replace(/^\||\|$/g, '').split('|').map((c) => c.trim());
      const head = cells(line);
      i += 2;
      const rows: string[][] = [];
      while (i < lines.length && /^\|.*\|\s*$/.test(lines[i])) rows.push(cells(lines[i++]));
      blocks.push(
        <div key={blocks.length} className="bk-docs__table-wrap">
          <table className="bk-docs__table">
            <thead>
              <tr>
                {head.map((c, k) => (
                  <th key={k} scope="col">
                    {inline(c)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, k) => (
                <tr key={k}>
                  {r.map((c, n) => (
                    <td key={n}>{inline(c)}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>,
      );
      continue;
    }

    // Lists, with one level of nesting (indented two or more spaces).
    const item = line.match(/^(\s*)([-*]|\d+[.)])\s+(.*)$/);
    if (item) {
      const ordered = /\d/.test(item[2]);
      const entries: { text: string; children: string[]; childOrdered: boolean }[] = [];
      while (i < lines.length) {
        const m = lines[i].match(/^(\s*)([-*]|\d+[.)])\s+(.*)$/);
        if (!m) {
          // A wrapped line continues the item above.
          if (lines[i].trim() && /^\s{2,}\S/.test(lines[i]) && entries.length) {
            const last = entries[entries.length - 1];
            if (last.children.length) last.children[last.children.length - 1] += ` ${lines[i].trim()}`;
            else last.text += ` ${lines[i].trim()}`;
            i++;
            continue;
          }
          break;
        }
        if (m[1].length >= 2 && entries.length) {
          entries[entries.length - 1].children.push(m[3]);
          entries[entries.length - 1].childOrdered = /\d/.test(m[2]);
        } else {
          entries.push({ text: m[3], children: [], childOrdered: false });
        }
        i++;
      }
      const ListTag = ordered ? 'ol' : 'ul';
      blocks.push(
        <ListTag key={blocks.length} className={ordered ? 'bk-docs__steps' : 'bk-docs__list'}>
          {entries.map((e, k) => {
            const Child = e.childOrdered ? 'ol' : 'ul';
            return (
              <li key={k}>
                {inline(e.text)}
                {e.children.length ? (
                  <Child>
                    {e.children.map((c, n) => (
                      <li key={n}>{inline(c)}</li>
                    ))}
                  </Child>
                ) : null}
              </li>
            );
          })}
        </ListTag>,
      );
      continue;
    }

    // A paragraph: lines until a blank line or the next block.
    const para: string[] = [];
    while (i < lines.length && lines[i].trim() && !isBlockStart(lines[i])) para.push(lines[i++].trim());
    if (!para.length) {
      // A line that looked like a block start but wasn't one (e.g. a lone "|"): show it as text.
      para.push(lines[i++].trim());
    }
    blocks.push(<p key={blocks.length}>{inline(para.join(' '))}</p>);
  }

  return <div className="bk-docs__article">{blocks}</div>;
}
