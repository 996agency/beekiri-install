/**
 * Beekiri's documentation (Settings → Documentation): the articles, grouped as in the sidebar.
 * Each article is a Markdown file in ./content (see Markdown.tsx for what it may use).
 */
import welcome from './content/welcome.md?raw';
import adminTour from './content/admin-tour.md?raw';
import pagesEditor from './content/pages-and-editor.md?raw';
import elements from './content/elements.md?raw';
import dynamicContent from './content/dynamic-content.md?raw';
import appearance from './content/appearance.md?raw';
import beekiriAi from './content/beekiri-ai.md?raw';
import fullWebsiteDesign from './content/full-website-design.md?raw';
import beekiriAccount from './content/beekiri-account.md?raw';
import blog from './content/blog.md?raw';
import media from './content/media.md?raw';
import backendFields from './content/backend-fields.md?raw';
import extensions from './content/extensions.md?raw';
import shop from './content/shop.md?raw';
import shopSettings from './content/shop-settings.md?raw';
import forms from './content/forms.md?raw';
import bookings from './content/bookings.md?raw';
import analyticsSeo from './content/analytics-seo.md?raw';
import settings from './content/settings.md?raw';
import users from './content/users-permissions.md?raw';
import security from './content/security.md?raw';
import migration from './content/migration-backups.md?raw';
import multisite from './content/multisite.md?raw';
import updates from './content/updates.md?raw';
import troubleshooting from './content/troubleshooting.md?raw';
import devThemes from './content/dev-themes.md?raw';
import devLayouts from './content/dev-layouts.md?raw';
import devRuntime from './content/dev-runtime.md?raw';
import devShopApi from './content/dev-shop-api.md?raw';
import devReference from './content/dev-reference.md?raw';

export type DocGroupId = 'start' | 'build' | 'ai' | 'content' | 'extensions' | 'settings' | 'maintain' | 'developers';

export type DocArticle = {
  id: string;
  group: DocGroupId;
  title: string;
  /** One line under the title and in search results. */
  summary: string;
  /** Extra words people may search for. */
  keywords?: string;
  body: string;
};

export const DOC_GROUPS: { id: DocGroupId; title: string; description: string }[] = [
  { id: 'start', title: 'Getting started', description: 'What Beekiri is and how to find your way around the admin.' },
  { id: 'build', title: 'Building your site', description: 'Pages, the page editor, elements, themes, headers and footers.' },
  { id: 'ai', title: 'Beekiri AI', description: 'Building and running your site by asking in plain words.' },
  { id: 'content', title: 'Content', description: 'Blog posts, photos and files, and your own types of content.' },
  { id: 'extensions', title: 'Extensions', description: 'Shop, forms, bookings, cookies, analytics and SEO.' },
  { id: 'settings', title: 'Settings & security', description: 'Site settings, people and permissions, security, moving sites.' },
  { id: 'maintain', title: 'Updates & help', description: 'Keeping Beekiri up to date, and what to do when something is off.' },
  { id: 'developers', title: 'For developers', description: 'Themes, layouts, the field API, scripts and the APIs.' },
];

export const DOCS: DocArticle[] = [
  { id: 'welcome', group: 'start', title: 'Welcome to Beekiri', summary: 'What Beekiri is, how your site is put together, and a first-day checklist.', keywords: 'introduction overview quick start begin', body: welcome },
  { id: 'admin-tour', group: 'start', title: 'Finding your way around', summary: 'The menu, the top bar, search, notifications and the dashboard.', keywords: 'sidebar toolbar spotlight search shortcut notifications bell dashboard feedback', body: adminTour },

  { id: 'pages-and-editor', group: 'build', title: 'Pages and the page editor', summary: 'Create pages, edit them visually, preview, publish and set the homepage.', keywords: 'page editor beekiricode layers props publish draft preview homepage seo undo', body: pagesEditor },
  { id: 'elements', group: 'build', title: 'Elements and theme layouts', summary: 'Every building block you can add to a page, and how theme layouts work.', keywords: 'section container heading text button image video icon accordion tabs map rating form booking layout', body: elements },
  { id: 'dynamic-content', group: 'build', title: 'Dynamic content', summary: 'Repeat a design for every product, post or list item, with live data.', keywords: 'loop repeat bindings lightning products posts repeater', body: dynamicContent },
  { id: 'appearance', group: 'build', title: 'Themes, headers, footers and menus', summary: 'Choose a theme, buy store templates, pick a header and footer, edit menus and site-wide sections.', keywords: 'theme templates store licence header footer menu popup banner site sections', body: appearance },

  { id: 'beekiri-ai', group: 'ai', title: 'Working with Beekiri', summary: 'What the assistant can build and do for you, and how to ask for it.', keywords: 'chat assistant ai claude ask ideas screenshot picture reference link keep undo', body: beekiriAi },
  { id: 'full-website-design', group: 'ai', title: 'Full website design and the design brief', summary: 'Answer four questions and let Beekiri design your whole site in one look.', keywords: 'design brief questionnaire colours fonts look starter theme', body: fullWebsiteDesign },
  { id: 'beekiri-account', group: 'ai', title: 'Balance, costs and change history', summary: 'How Beekiri is paid for, adding money, and undoing what it changed.', keywords: 'connector balance top up cost billing change history revert', body: beekiriAccount },

  { id: 'blog', group: 'content', title: 'Blog posts', summary: 'Write posts, add a cover photo and topics, and how the blog is shown.', keywords: 'posts blog articles topics categories featured image excerpt', body: blog },
  { id: 'media', group: 'content', title: 'Media library', summary: 'Upload photos and files, sort them into folders and write good alt text.', keywords: 'media images photos files folders upload alt text webp', body: media },
  { id: 'backend-fields', group: 'content', title: 'Backend Fields and your own content types', summary: 'Custom fields, content types, taxonomies and options pages.', keywords: 'fields field groups custom post types taxonomies options pages acf', body: backendFields },

  { id: 'extensions', group: 'extensions', title: 'Extensions', summary: 'Install, turn on and keep extensions up to date.', keywords: 'extensions install activate update automatic', body: extensions },
  { id: 'shop', group: 'extensions', title: 'Bee Shopping: products and orders', summary: 'Sell products: variations, stock, orders, customers and coupons.', keywords: 'shop store products variations stock orders customers coupons ecommerce', body: shop },
  { id: 'shop-settings', group: 'extensions', title: 'Bee Shopping: payments, shipping and settings', summary: 'Payments, shipping zones, couriers, taxes, emails and importing from WooCommerce.', keywords: 'stripe paypal payments shipping couriers dhl taxes emails woocommerce import api keys', body: shopSettings },
  { id: 'forms', group: 'extensions', title: 'Bee Forms', summary: 'Build forms, read entries, export them and design the emails they send.', keywords: 'forms contact entries export email notifications hubspot spam', body: forms },
  { id: 'bookings', group: 'extensions', title: 'Bee Bookings', summary: 'Let customers book appointments: services, staff, hours and the calendar.', keywords: 'bookings appointments calendar services staff hours reminders', body: bookings },
  { id: 'analytics-seo', group: 'extensions', title: 'Cookies, analytics and SEO', summary: 'The cookie notice, visitor analytics, heatmaps and the SEO tools.', keywords: 'cookies consent gdpr analytics heatmap seo audit keywords', body: analyticsSeo },

  { id: 'settings', group: 'settings', title: 'Site settings', summary: 'Every tab in Settings, from your site name to email delivery.', keywords: 'settings general page editor advanced translation permalinks media email site code', body: settings },
  { id: 'users-permissions', group: 'settings', title: 'Users, roles and permissions', summary: 'Invite people, give them a role, and decide what each role may do.', keywords: 'users roles permissions capabilities owner administrator editor', body: users },
  { id: 'security', group: 'settings', title: 'Security', summary: 'Firewall, bot checks, two-step sign-in, activity log and the rescue command.', keywords: 'security shield firewall turnstile recaptcha cloudflare two factor 2fa activity rescue', body: security },
  { id: 'migration-backups', group: 'settings', title: 'Migration and backups', summary: 'Copy a site between computers and servers, back it up, and move to a new server.', keywords: 'migration push pull staging production backup restore deploy package', body: migration },
  { id: 'multisite', group: 'settings', title: 'Several sites in one Beekiri', summary: 'Run a network of sites on sub-domains with one sign-in.', keywords: 'multisite network subdomain sites', body: multisite },

  { id: 'updates', group: 'maintain', title: 'Updates, cache and speed', summary: 'How Beekiri updates itself, clearing the cache, and keeping pages fast.', keywords: 'updates core version automatic cache lighthouse performance speed', body: updates },
  { id: 'troubleshooting', group: 'maintain', title: 'Troubleshooting and questions', summary: 'Answers to common questions and what to do when something looks wrong.', keywords: 'help faq problem error not working support feedback', body: troubleshooting },

  { id: 'dev-themes', group: 'developers', title: 'Theme structure', summary: 'Parent and child themes, theme.json, headers and footers, blog templates and stylesheets.', keywords: 'theme json child parent chrome header footer blog templates tokens css variables', body: devThemes },
  { id: 'dev-layouts', group: 'developers', title: 'Layouts and the PHP field API', summary: 'Write layout templates: get_bee_field, loops, escaping and the template rules.', keywords: 'layouts php get_bee_field the_bee_field have_bee_rows escaping template guard scss script', body: devLayouts },
  { id: 'dev-runtime', group: 'developers', title: 'React layouts, animation and dynamic data', summary: 'The React runtime, GSAP and Three.js in layouts, and the dynamic content API.', keywords: 'react tsx gsap scrolltrigger three webgl animation dynamic api', body: devRuntime },
  { id: 'dev-shop-api', group: 'developers', title: 'Shop REST API', summary: 'Read and manage products, orders and customers from other systems.', keywords: 'rest api shop keys bk_shop endpoints products orders', body: devShopApi },
  { id: 'dev-reference', group: 'developers', title: 'Commands, settings files and limits', summary: 'npm scripts, environment settings, the security rescue command and useful limits.', keywords: 'cli npm scripts env environment variables rescue command', body: devReference },
];

export function findDoc(id: string | null | undefined): DocArticle | undefined {
  return id ? DOCS.find((d) => d.id === id) : undefined;
}
