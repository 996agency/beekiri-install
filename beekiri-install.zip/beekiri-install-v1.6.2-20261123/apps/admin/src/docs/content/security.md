Beekiri protects your site against break-in attempts, bots and stolen passwords. Most of it works on its own; the owner can tune it in [Settings → Security](admin:settings?tab=security).

At the top of the Security tab, the overview shows how you are protected now: the firewall level, how many addresses are banned, wrong passwords in the last 24 hours, the bot check, and how many people use two-step sign-in.

## Beekiri Shield (firewall)

Beekiri Shield watches every visit and bans addresses that behave like attackers.

**Protection level:**

| Level | What it does |
|---|---|
| **Off** | Only your block list applies. |
| **Balanced** (default) | Recommended for almost every site. |
| **Strict** | Bans sooner, and allows fewer requests per minute. For sites under attack. |

**Watch for** (all on by default):

- **Hacking tools** that scan sites for weaknesses: banned at once.
- **Scanners and break-in attempts**, such as visits to WordPress sign-in pages or hidden server files.
- **Request floods:** more than 300 requests a minute from one address (120 on Strict).

A first ban lasts 15 minutes; repeat offenders are banned for 1, 6 and then 24 hours. A browser that has signed in to your admin before is never locked out, so you can't ban yourself by accident. Switch on the notification option to hear about bans in the bell.

**Banned right now** lists the banned addresses with the reason. Use **Lift ban** to let one back in, or **Block permanently**.

**Block list** and **Never block** take addresses or address ranges (for example `203.0.113.0/24`) with a note, up to 500 each. Changes apply at once. **Add my address** puts your current address on the Never block list, useful for an office.

## Bot check

A bot check stops automated sign-in attempts and spam in your forms. It is off until you set it up.

1. Choose a **Service**: **Cloudflare Turnstile** (free, no puzzles for visitors), **reCAPTCHA v2** or **reCAPTCHA v3**. The screen links to where you get the keys.
2. Create a site in that service for your domain and copy the **Site key** and **Secret key** into Beekiri.
3. For reCAPTCHA v3, choose a **Minimum score** (0.5 is a good start; higher is stricter).
4. Under **Use it on**, choose the admin sign-in and "Forgot password" page, your Bee Forms forms, or both.
5. Click **Test the keys**. The bot check can only be switched on after a successful test, so a wrong key can never lock anyone out.

## Cloudflare

If your site runs behind Cloudflare, Beekiri can work together with it:

- **Your visit** shows whether your own visit comes through Cloudflare.
- **Refuse visits that skip Cloudflare** blocks attackers who go around Cloudflare to reach your server directly. You can only switch it on while your own visit comes through Cloudflare.
- **Cloudflare API** (optional): paste an API token (with the Zone Settings:Edit and Firewall Services:Edit permissions) and click **Connect Cloudflare**. Then:
  - **Send every Shield ban to Cloudflare too** blocks attackers before they reach your server.
  - **Under Attack mode** turns on Cloudflare's extra check for every visitor, for when your site is under heavy attack.

## Two-step sign-in

Everyone can turn on two-step sign-in for their own account (see [Users, roles and permissions](doc:users-permissions#two-step-sign-in)). Here the owner decides who must use it:

| Required for | Who must use it |
|---|---|
| **Optional** (default) | Nobody; each person decides. |
| **Administrators** | The owner and administrators. |
| **Everyone** | Every account. |

Turn it on for your own account first. People who are now required to use it but haven't set it up are signed out and set it up the next time they sign in. The table **People on this site** shows who has it **On**, **Off**, or **Required, not set up**.

## Activity

The **Activity** tab lists what happened, newest first: Shield bans and warnings, sign-ins and failed sign-ins, two-step sign-in changes and changes to settings, with the address each came from. Use **Block** on a suspicious row to block that address. Search and **Refresh** help you find something.

## Good habits

- Turn on two-step sign-in for every administrator.
- Change the admin and sign-in addresses in [Settings → General](admin:settings?tab=general), so fewer bots find your sign-in page.
- Give people the lowest role that lets them do their work. See [Users, roles and permissions](doc:users-permissions).
- Give **Raw HTML and scripts** only to people you fully trust.
- Keep Beekiri up to date. See [Updates, cache and speed](doc:updates).

## If you are locked out

If nobody can sign in (a lost phone without recovery codes, a wrong bot check, or your own address banned), whoever manages your server can run these commands in the Beekiri folder on the server:

| Command | What it does |
|---|---|
| `npm run security -- reset-2fa <email or username>` | Turns off two-step sign-in for that account and signs it out everywhere. |
| `npm run security -- unban <address>` | Lifts one Shield ban. |
| `npm run security -- rescue` | Lifts every ban, and switches off **Refuse visits that skip Cloudflare** and the sign-in bot check on every site. |

After `rescue`, restart Beekiri or wait about a minute.

## Warnings you may see

- **Visitor addresses are hidden behind a proxy:** your server setup hides visitors' real addresses, so Shield can't ban the right ones. Whoever manages your server sets `TRUST_PROXY` in Beekiri's settings file.
- **Saved keys will be lost on restart:** Beekiri needs a secret (`CACHE_FLUSH_SECRET`, at least 32 characters) in its settings file to keep bot check keys, Cloudflare tokens, mail passwords and two-step sign-in secrets after a restart. Ask whoever manages your server to add it. See [Commands, settings files and limits](doc:dev-reference).
