Answers to the questions people ask most, and what to do when something doesn't look right. If your question isn't here, ask Beekiri in the chat, or send us a message with **Feedback** at the bottom of the menu.

## My change doesn't show on the website

1. Check that you clicked **Publish** in the page editor. **Save draft** keeps the change private.
2. Click **Clear cache** in the top bar.
3. Reload the page in your browser with **Ctrl + Shift + R** (**⌘ + Shift + R** on a Mac).

New sections Beekiri added to a published page stay hidden until you click **Keep**. See [Working with Beekiri](doc:beekiri-ai#keep-or-undo).

## Emails don't arrive

Order confirmations, form notifications, booking emails and password resets all need a working email account.

1. Open [Settings → Email](admin:settings?tab=email). The line at the top says how your site sends email now.
2. Set up your mail server and click **Send a test email**.
3. Gmail and Microsoft accounts with two-step sign-in need an **app password**.
4. Ask the recipient to check their spam folder.

For a form, also check that its notification is switched on and the address is right. See [Site settings](doc:settings#email).

## I can't sign in

- **Forgot your password?** Use **Forgot your password?** on the sign-in page. The reset email needs working email settings.
- **Lost your phone for two-step sign-in?** Click **Lost your phone? Use a recovery code**. Without recovery codes, ask the owner or an administrator to turn two-step sign-in off for your account.
- **The admin address doesn't work?** It may have been changed in Settings → General. Ask the owner for the new address.
- **Nobody can sign in?** Whoever manages your server can run the rescue commands. See [Security](doc:security#if-you-are-locked-out).

## I was signed out

You are signed out after 20 minutes without activity in the admin, to protect your account. Tick **Keep me signed in** on the sign-in page to stay signed in on your own computer. Unsaved changes in the page editor are lost when you are signed out, so save regularly.

## A menu item or screen is missing

- Your role may not include it. Ask the owner; permissions are set in [User Permissions](admin:users/permissions).
- **Shop**, **Forms** and **Bookings** appear only while their extension is on. See [Extensions](doc:extensions).
- **Security**, **Email**, **Migration** and **Sites** in Settings are for the owner alone.
- The Beekiri chat appears only when Beekiri is turned on in Connector, there is money in the balance, and you may use it. See [Working with Beekiri](doc:beekiri-ai#before-you-start).

## Beekiri says the balance is empty

Beekiri pauses when the balance reaches zero. An administrator adds money in [Connector](admin:connector). See [Balance, costs and change history](doc:beekiri-account).

## Beekiri stopped in the middle

If the connection dropped, what Beekiri finished is kept. Send "continue" and it carries on. Very big jobs stop after many steps; send "keep going". To undo what it did, use **Undo** under its reply, or [Connector → Change history](admin:connector?tab=changes).

## Customers can't check out

- **"We cannot ship to that address":** add the customer's country to a shipping zone, or add a zone for everywhere else. See [Bee Shopping: payments, shipping and settings](doc:shop-settings#shipping).
- **Card payments stay "Pending payment":** add the Stripe webhook. See [Payments](doc:shop-settings#payments).
- **No payment methods:** turn on at least one in Shop → Settings → Payments.

## A form doesn't appear on the page

Check that the form is **Active**, Bee Forms is on, and the page was saved after adding the form. See [Bee Forms](doc:forms).

## Photos look blurry or load slowly

- Upload photos at full quality; Beekiri makes the smaller versions.
- Keep **Convert all images to WebP on upload** on, with a maximum size of 1920 px, in [Settings → Media](admin:settings?tab=media).
- The settings apply to new uploads. Upload a photo again after changing them.

## The page looks different on phones

Open the page in the editor and switch to **Mobile**. Changes made while viewing Mobile apply to phones only. Or ask Beekiri: "Check how my website looks on phones." See [Pages and the page editor](doc:pages-and-editor#phones-tablets-and-desktop).

## My site doesn't appear in Google

1. In [Settings → Advanced](admin:settings?tab=advanced), turn on **Let search engines list this site**.
2. Add your site to Google Search Console, and give it your sitemap (`/sitemap.xml`).
3. Fill in the **SEO** tab of your important pages.

New sites take days to weeks to appear. See [Cookies, analytics and SEO](doc:analytics-seo).

## Analytics shows no visitors

Visitors are counted only after they accept analytics cookies. Turn on BeeCookies with **Count visits in Analytics once a visitor accepts analytics cookies**, and visit your site in a private window to test. Visits from local copies and drafts are hidden when **Hide test visits** is on.

## An update failed

Beekiri puts the previous version back automatically, and your site keeps running. Try again later from [Settings → Beekiri Core](admin:settings). If it keeps failing, send us **Feedback** with what the bell says. See [Updates, cache and speed](doc:updates).

## Saved keys or passwords disappeared after a restart

Payment keys, the email password, bot check keys and two-step sign-in need a secret in Beekiri's settings file on the server to survive a restart. Ask whoever manages your server to add `CACHE_FLUSH_SECRET`, then enter the keys again. See [Commands, settings files and limits](doc:dev-reference).

## Something else

- **Ask Beekiri.** It knows your site and can look at the page you are on.
- **Send Feedback** (bottom of the menu): choose **Problem**, describe what you did and what happened. Tick **Reply** if you'd like an answer by email.
