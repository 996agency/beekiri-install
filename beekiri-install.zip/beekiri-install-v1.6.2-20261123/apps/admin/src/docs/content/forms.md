Bee Forms lets you build forms (contact, quote request, job application, sign-up…), put them on any page, and read everything visitors send in one inbox. There are no outside services or keys to set up.

## Turn it on

Go to [Extensions → Add New](admin:extensions/new) and install **Bee Forms**. A **Forms** menu appears with **All Forms**, **Entries** and **Integrations**.

Turning Bee Forms off hides the menu and the forms on your website; nothing is deleted. See [Extensions](doc:extensions).

## Build a form

1. Go to [Forms → All Forms](admin:forms) and click **Add New**. You start with a ready-made contact form (name, email, message).
2. **Add fields:** click a field type in the left panel (it goes after the selected field) or drag it into place.
3. **Reorder:** drag a field by its card.
4. **Change a field:** select it and use the right panel: label, placeholder, help text, required, width (full, half or third), default value, the options of dropdowns and choices, and the file types allowed for uploads.
5. Save.

**Field types:** Text, Email, Phone, Website, Message, Number, Date, Dropdown, Choice, Checkboxes, Consent, File upload, Hidden, Section and Page break.

- **Conditional logic** shows or hides a field depending on another answer (for example "Company name" only when "I am a business" is ticked). Hidden fields are never required.
- **Page break** splits a long form into steps with **Next** and **Back** buttons, with a progress bar, numbered steps or nothing (**Settings → Steps**).
- The **Active** switch at the top takes a form off your website without deleting it.

> **Tip:** Ask Beekiri: "Make a quote request form with name, email, phone, type of project (dropdown) and budget." Then fine-tune it here.

## Form settings

On the form's **Settings** tab:

- **Submit button:** its text.
- **After sending:** show a thank-you message (answers can be used in it, such as `Thanks {field:name}!`), or send the visitor to a page.
- **Keep entries in the admin:** turn it off for forms that should only send email.
- **Minimum fill time:** forms sent faster than this are treated as bots.

## Emails

On the **Notifications** tab:

- **Notification email:** who receives each entry. Separate several addresses with commas. `{admin_email}` is the site owner's address. **Reply to** set to `{field:email}` makes "Reply" in your mail app answer the visitor.
- **Auto-reply:** a confirmation sent to the visitor.
- **Insert an answer** puts a visitor's answer into the message. Also available: `{all_fields}` (every answer), `{form_title}`, `{site_title}`, `{entry_id}`, `{date}` and `{page_url}`.
- **Formatting:** the buttons above each message add **bold**, links, headings and a dividing line.
- **Email design:** your **logo**, its size and position, an **accent colour**, the **background** around the message, and a **footer** line. One design for both emails.
- **Preview** shows the email as it will arrive, on desktop and phone, and updates as you type. **Send me a test** sends it to your own address.

> **Important:** Emails need your site's email settings. If notifications don't arrive, set up [Settings → Email](admin:settings?tab=email) first. See [Site settings](doc:settings#email).

## Put a form on a page

1. Open the page in the editor.
2. In **Add**, drag **Form** onto the page.
3. In **Props → Content**, pick the form.
4. Save or publish the page.

The editor shows a preview; the working form appears on your website. Forms use your theme's colours, borders and rounding, so they match your site.

Theme layouts can also include a form: their **Form (Bee Forms)** field shows a list to choose the form. See [Layouts and the PHP field API](doc:dev-layouts).

## Entries

[Forms → Entries](admin:forms/entries) lists everything visitors sent, newest first, with the number of unread entries.

- Click an entry to read it in full, download uploaded files, mark it unread, or move it to spam or the trash. Deleting an entry also deletes its files.
- Choose a form in the filter and click **Export CSV** for a spreadsheet.
- Ask Beekiri: "Export last month's entries" or "How many came from Instagram?". See [Working with Beekiri](doc:beekiri-ai).

Each entry also shows **where the visitor came from**:

| Part | Shows |
|---|---|
| **Source of this visit** | The channel and source (for example *Paid social · LinkedIn Ads*, *Organic search · Google*, *Email · Newsletter*, *Direct*), the campaign, the page they landed on and the site they came from. It is kept for the whole visit, so a visitor who clicks an ad, reads three pages and then fills in the form still shows the ad. |
| **First visit** | How they found your site the very first time, if different (only for visitors who accepted analytics or marketing cookies). |
| **Visitor** | Country, device, browser, language and screen. |
| **Submission** | The page the form was sent from, pages viewed, time on site and time to fill in. |

The Entries list has **Source** and **Country** columns and a **Where entries come from** panel; click a channel or source there to filter. Add UTM tags (`utm_source`, `utm_medium`, `utm_campaign`) to your ad and newsletter links for the most precise names. Google, Microsoft, LinkedIn, TikTok, X, Pinterest and Snapchat ads are recognised even without them.

Uploaded files are private: only signed-in people with the **Entries** permission can download them.

## Send entries to HubSpot

[Forms → Integrations](admin:forms/integrations) connects your CRM. HubSpot is available now.

1. In HubSpot, open **Settings → Integrations → Private Apps → Create a private app** (newer accounts: **Development → Legacy apps → Create → Private**). It works on every plan, including free.
2. Name it *Beekiri*, and add the scopes `crm.objects.contacts.read`, `crm.objects.contacts.write` and `crm.schemas.contacts.read`.
3. Create the app, copy the access token (it starts with `pat-`) and paste it into Beekiri.

Then open a form, go to its **Integrations** tab, switch HubSpot on and check the suggested mapping (email, name, phone, company, message…). Each HubSpot property can take a form field, part of a name, where the visitor came from, or a fixed value. You can send only when a consent box is ticked, and add the whole entry as a note.

- The entry is always saved first; a HubSpot problem never stops the form.
- Contacts are matched by email, so an existing contact is updated, not duplicated.
- If HubSpot is down, Beekiri tries again automatically over the next hours. Each entry shows the HubSpot status, with **Retry now** and **Send again**.

## Spam protection

Every form has hidden bot traps, a timing check and limits per visitor. Bots get a normal "thanks" but nothing is stored or emailed. Files that could run as code are always refused. For extra protection, turn on the bot check for forms in [Settings → Security](admin:settings?tab=security&section=bot-check). See [Security](doc:security#bot-check).

## Who can do what

- **Forms:** build and edit forms.
- **Entries:** read, export and delete entries.

Administrators and editors have both by default. See [Users, roles and permissions](doc:users-permissions).

## If something doesn't work

- **The form doesn't show on the site:** check the form is **Active**, Bee Forms is on, and the page was saved after adding the form.
- **No emails arrive:** set up [Settings → Email](admin:settings?tab=email) and send a test. Check that the notification is switched on and the address is correct.
- **"This form took too long to send":** the page was open for more than a day. Reloading it fixes this.
