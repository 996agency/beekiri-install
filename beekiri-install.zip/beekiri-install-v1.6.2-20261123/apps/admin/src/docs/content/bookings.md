Bee Bookings lets your customers book appointments on your website: a haircut, a consultation, a lesson. They choose a service, a person and a free time; you see everything in a calendar, and both of you get emails.

## Turn it on

Go to [Extensions → Add New](admin:extensions/new) and install **Bee Bookings**. A **Bookings** menu appears with **Calendar**, **Appointments**, **Services**, **Staff** and **Settings**.

## Set up in four steps

The [Calendar](admin:bookings) shows **Two things before customers can book** until a service and a staff member exist.

### 1. Settings

In [Bookings → Settings](admin:bookings/settings):

| Section | What to set |
|---|---|
| **Location, currency and time zone** | **Where appointments happen**, the **Currency** for prices, and your **Time zone**. Check the time zone: all times are shown in it. |
| **Business hours** | Your opening hours per day. Staff follow these unless they have their own. |
| **Holidays and closed days** | Days nobody can be booked. |
| **Booking rules** | **Start times every** (for example every 15 or 30 minutes), **Book at least … hours ahead**, **Book at most … days ahead**, **Customers can cancel until … hours before**, and **Confirm website bookings straight away**. |
| **Emails** | **Send new bookings to** (your address), **Remind the customer … hours before**, and an **Extra line in the confirmation** (what to bring, where to park…). |

With **Confirm website bookings straight away** on, the time is the customer's as soon as they book. With it off, each booking waits under **Appointments → Waiting for you** until you confirm it.

Click **Save changes**.

### 2. Services

In [Bookings → Services](admin:bookings/services), click **New service** and enter its **Name**, **Length**, **Price**, **Free time after** (time to tidy up before the next customer), an optional **Short description**, and a **Colour on the calendar**.

### 3. Staff

In [Bookings → Staff](admin:bookings/staff), click **New staff member**: their **Name**, **Email**, optional **Phone**, which **Services** they do, their **Working hours** (or the business hours) and their **Days off**. Bookings need at least one person: add yourself if you work alone.

### 4. Put the booking calendar on your website

In the page editor, add the **Booking** element where the calendar should appear. Or type `[bee_booking]` in any text on a page. To show one service only, use `[bee_booking service="Service name"]`.

> **Tip:** Ask Beekiri: "Set up bookings for a 30-minute free consultation, Monday to Friday 9 to 5, and add a booking page." It creates the service, the hours and the page for you.

## How customers book

On your website, a customer chooses the service, the person (or **Everyone**, which takes the first free person), the day and a free time, then fills in their name, email, phone and an optional message. A time can never be booked twice.

They receive a confirmation email with a link to their booking, where they can cancel up to the time you allowed. They also get a reminder before the appointment.

## The calendar

[Bookings → Calendar](admin:bookings) shows appointments by day, week or month. Choose a person under **Staff** or **Everyone**, and move between periods with the arrows. Click a day to open it.

- **Add appointment** books a customer yourself, for example after a phone call. Beekiri shows the **Free times that day**; you can also type any time.
- **Block time** keeps a period free of bookings (a meeting, a lunch break). **Remove blocked time** opens it again.

## Appointments

[Bookings → Appointments](admin:bookings/appointments) lists appointments in tabs: **Waiting for you**, **Upcoming**, **Past** and **Cancelled**. Search by customer. Open one to see the customer, the service, when and with whom, their message, and **Your note (only you see it)**. From there you can confirm, change, cancel or delete it.

Ask Beekiri: "Show me this week's appointments, day by day" or "Export November's appointments."

## Notifications

New and cancelled bookings appear in the bell for people who manage bookings, and are emailed to the address in **Send new bookings to**.

> **Important:** Booking emails need your site's email settings. Set up [Settings → Email](admin:settings?tab=email) and send a test before you take bookings.

## Who can manage bookings

People with the **Bookings** permission (administrators and editors by default). See [Users, roles and permissions](doc:users-permissions).

## Not available yet

Online payment for bookings, text-message reminders, repeating appointments, customers moving their own booking, and group classes.
