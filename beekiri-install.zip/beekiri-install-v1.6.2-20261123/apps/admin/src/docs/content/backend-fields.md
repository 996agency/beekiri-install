**Backend Fields** shapes the content of your site: the fields of your sections, your own types of content (team members, projects, events…), the ways to group them, and pages of site-wide options. If you have used Advanced Custom Fields in WordPress, this will feel familiar.

You need the **Backend Fields** permission (administrators have it).

> **Tip:** You rarely need to set this up by hand. Ask Beekiri: "Add a Projects section to the admin with a title, client, year, photos and a description, and a page that lists them." It creates the content type, the fields and the templates.

## The four parts

| Part | What it is | Example |
|---|---|---|
| [Field Groups](admin:fields) | A set of fields, shown where you choose. A field group also defines a section design (layout) for the page editor. | A "Hero" with title, text, photo and button. |
| [Post Types](admin:fields/post-types) | Your own kind of content, with its own menu item and list. | Team, Projects, Events, Services. |
| [Taxonomies](admin:fields/taxonomies) | A way to group content, like categories or tags. | Project type, Event city. |
| [Options Pages](admin:fields/options-pages) | An admin page for site-wide settings, filled once. | Opening hours, social links. |

## Field groups

1. Go to [Backend Fields → Field Groups](admin:fields) and click **Add New Field Group**.
2. Enter a title and, if you like, a short **Description**.
3. Under **Fields**, add the fields (below).
4. Under **Location Rules**, choose where the group applies: pages, posts, or one of your post types.
5. Click **Save Changes**.

When the group is a section design, saving also creates or updates the section in your theme, ready in the page editor's **Add** tab under **Layouts**. Switch **Active** off to hide a group without deleting it.

### Field types

| Group | Types |
|---|---|
| **Basic** | Text, Text Area, Number, Range, Email, URL, Password |
| **Content** | Image, File, WYSIWYG Editor (rich text), oEmbed (a video or post from a link), Gallery |
| **Choice** | Select, Checkbox, Radio Button, Button Group, True / False |
| **Relational** | Link, Post Object, Page Link, Relationship, User, Form (Bee Forms) |
| **Advanced** | Date Picker, Date Time Picker, Time Picker, Color Picker |
| **Layout** | Message, Accordion, Tab (to organise long groups), Group, Repeater (a list of rows), Flexible Content (rows of different kinds) |

Each field has a **label** (what people see), a **name** (used by the template, for example `button_text`), and settings such as required, a default value, help text and, for some types, a **return format** (for example whether an image gives its full details or only its address).

> **Warning:** Renaming a field's name or removing a field on a group that is already used means the content entered in it is no longer shown. Change names before you fill in content.

## Post types

A post type is your own kind of content, for example **Team** or **Projects**. Each has its own item in the menu (under Content), a list, and an editor like pages.

1. Go to [Post Types](admin:fields/post-types) and click **Add post type**.
2. Give it a singular and plural name (Project, Projects) and an icon for the menu.
3. Choose its options:
   - **Public (shown on the website)**: each entry gets its own page.
   - **Has a list page**: a page listing all entries.
   - **Hierarchical (like pages)**: entries can have parent entries.
   - **Show in admin menu**.
   - Which parts the editor shows: **Featured image**, **Excerpt**, **Custom fields**.
4. Save. Then create a field group with **Location Rules** set to this post type to give it fields.

**Deactivate** hides a post type without deleting anything; **Activate** brings it back. **Move to trash** removes it, and you can restore it from the trash or **Delete permanently**.

> **Note:** Pop-ups and banners use a built-in post type called **Site sections**. See [Themes, headers, footers and menus](doc:appearance#pop-ups-banners-and-bars-site-sections).

## Taxonomies

A taxonomy groups entries, like categories group posts. Go to [Taxonomies](admin:fields/taxonomies), click **Add taxonomy**, give it a singular and plural name, choose what it is **Attached to** (posts, or your post types), and whether it is **Hierarchical (like categories)** or flat like tags. Its terms are then chosen in the editor's **Page** tab.

## Options pages

An options page is an admin page with fields that apply to the whole site, such as opening hours or social media links shown in the footer. Go to [Options Pages](admin:fields/options-pages), click **Add options page**, give it a **Page title** and **Menu title**, and optionally a **Parent page**. Then create a field group with its **Location Rules** set to this options page.

## Bringing in updates from your theme

When your theme contains field groups that are new or newer than on your site (for example after installing or updating a theme), [Field Groups](admin:fields) shows a panel called **Updates from your theme**. Click **Sync all**, or **Sync** next to one group.

## Tools and settings

- [Tools](admin:fields/tools) exports your field groups, post types, taxonomies and options pages, to move them to another site.
- [Settings](admin:fields/settings) sets the export format (**JSON (recommended)** or **PHP (for older themes)**) and whether the admin bar shows Backend Fields shortcuts.

## For developers

How templates read these fields, what each field type returns, and the layout folder: [Layouts and the PHP field API](doc:dev-layouts).
