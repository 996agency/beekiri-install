A layout is one reusable section of a page, such as a hero, a price table or a team grid. Its fields are defined in Backend Fields; its markup is a small template in the active theme. Editors fill in the fields in the page editor, and the website prints the template with their values.

## How a layout is made

1. Open [Backend Fields](admin:fields) and create a field group (or edit one). Set **Location** to the content it belongs to (pages, posts or one of your own content types) and add the fields.
2. Save. Beekiri writes the layout folder in the theme: the template, a stylesheet, a script and the field definitions.
3. Open the template and write the markup, using the field API below.
4. Add the layout to a page in the page editor, fill in the fields and publish.

The group's key becomes the folder name: `group_hero_banner` becomes `hero-banner`, and the files are `hero-banner/hero-banner.php` and so on.

> **Tip:** You can also ask Beekiri in the chat to build a layout. It creates the field group and the template together, in your theme's look. See [Working with Beekiri](doc:beekiri-ai).

## The layout folder

```
themes/{theme}/layouts/{slug}/
  {slug}.php          PHP template (sites set up with PHP templates)
  {slug}.tsx          React template (sites set up with React templates)
  styles.scss         your styles
  styles.css          compiled from styles.scss (do not edit)
  styles.min.css      compiled and minified (what the website loads)
  script.js           the layout's browser script (optional)
  {slug}.meta.json    the field group: what the editor shows and what Sync reads
```

Only one template type is written for a site. **Settings → Page editor → Theme templates** shows whether the site uses PHP or React. It is chosen when the site is set up and does not change afterwards, so all of a theme's templates work together.

### Where Beekiri looks for a layout

When a page shows a layout, Beekiri uses the first folder it finds, in this order:

1. The site's own copy, for a site in a network: `themes/{theme}/sites/{siteId}/layouts/{slug}/`
2. The active theme, then its parent: `themes/beekiri-child/layouts/{slug}/`, then `themes/beekiri/layouts/{slug}/`
3. Network layouts, shared by every site: `themes/_network/layouts/{slug}/`

Put a site's own work in the child theme. Beekiri updates replace the parent theme's files but never touch a child theme or the layouts a site has made.

### Files Beekiri keeps in step

Files Beekiri creates start with this line:

```
@beekiri-managed — remove this line to keep your custom file
```

While the line is there, saving the field group writes the file again, so it always matches the fields. When you start customizing a file, delete that line first. Beekiri then never overwrites it, and you keep the file in step with the field group yourself.

> **Important:** If you rename or remove a field in Backend Fields, update every template that reads it. A field the template asks for but the group no longer has simply returns nothing.

### Bringing in layouts from another theme

Copy layout folders into the child theme's `layouts` folder, then open [Backend Fields](admin:fields). A panel called **Updates from your theme** lists the field groups that are new or newer in the theme files; click **Sync all**, or **Sync** next to one. Beekiri reads each `{slug}.meta.json` and creates or updates the field group, so the layout appears in the page editor.

## Styles and scripts

**Styles.** Write your styles in `styles.scss`. No build tool is needed: when the website asks for a layout's styles and `styles.scss` is newer than the compiled file, Beekiri compiles it again (into `styles.css` and the minified `styles.min.css`). Save, refresh the page, and the change is there. If the SCSS has an error, the last good CSS keeps being served and the error is written to the server log.

Keep a layout's styles under its own class so they never leak into other sections:

```scss
.hero-banner {
  .bk-title {
    font-size: clamp(2rem, 5vw, 3.5rem);
  }
}
```

**Scripts.** `script.js` is optional. It is served, minified, from `/api/layouts/{slug}/js`, only on pages that use the layout. There is no build step, so save the file and refresh the page. Scripts can use GSAP and Three.js without bundling them; see [React layouts, animation and dynamic data](doc:dev-runtime).

> **Note:** The site-wide look (colours, fonts, spacing) lives in the theme header's `styles.scss`, not in a layout. See [Theme structure](doc:dev-themes).

## Writing a PHP template

A template is a PHP file that prints HTML. Each field's value arrives already formatted, so you read it, check it and print it.

```php
<?php
$title = get_bee_field('title');
$text = get_bee_field('text');
?>
<section class="section hero-banner" data-layout="hero-banner">
  <div class="wrapper">
    <?php if ($title) : ?>
      <h2 class="bk-title"><?php echo esc_html($title); ?></h2>
    <?php endif; ?>
    <?php if ($text) : ?>
      <div class="bk-text"><?php echo bee_esc_html($text); ?></div>
    <?php endif; ?>
  </div>
</section>
```

Conventions that keep layouts consistent with each other and with what Beekiri builds:

- The outer element is `<section class="section {slug}" data-layout="{slug}">`. Keep `data-layout`: the website looks for it to decide which layout styles and scripts to load, and Beekiri refuses a layout without it.
- Each field gets one short class, `bk-{field-name}` in kebab case: the field `title` becomes `bk-title`, `button_text` becomes `bk-button-text`.
- Print nothing for an empty field: wrap optional parts in `if`.
- Escape every value you print (see [Escaping](#escaping)).

## The field API

| Function | What it does |
|---|---|
| `get_bee_field('name')` | Returns a field's value: the layout's own field, or, inside a loop, the current row's field. `null` when there is none. |
| `the_bee_field('name')` | Prints a field's value **as stored, without escaping**. Arrays print their `url` or `label`. Prefer `echo esc_html(get_bee_field('name'))` for text. |
| `get_bee_fields()` | All of the layout's own fields, as an array. |
| `have_bee_rows('name')` | Starts or continues a loop over a repeater, group or flexible content field. Returns `false` when there are no more rows. |
| `the_bee_row()` | Moves to the next row. Call it once at the top of each turn of the loop. |
| `get_bee_row()` | The current row, as an array (does not move on). |
| `get_bee_row_index()` | The current row's number, starting at 1. |
| `get_bee_row_layout()` | In flexible content: the name of the current row's layout. |
| `reset_bee_rows()` | Leaves the current loop, back to the outer one. Use it after a `break`. |
| `bee_esc_html($html)` | Cleans rich text for printing: keeps formatting, removes scripts. |
| `bee_form()` / `the_bee_form()` | Returns or prints a Bee Forms form chosen in a Form field. With no argument, the layout's first Form field. |
| `bee_language_switcher()` | Prints the language switcher (for headers). Options: `id`, `class`. |
| `bee_search_modal()` | Prints the site's search dialog (for headers). Open it from any element with `data-bk-search-open`. Option: `placeholder`. |

Templates written for ACF keep working (Beekiri itself only writes the `bee` names): `get_field`, `the_field`, `get_fields`, `get_sub_field`, `the_sub_field`, `have_rows`, `the_row`, `get_row`, `get_row_index`, `get_row_layout`, `reset_rows` and `acf_esc_html` map to the functions above. One difference: `get_field()` always reads the layout's own fields, even inside a loop. Use `get_sub_field()` or `get_bee_field()` for row values.

## What each field type gives you

| Field type | Value in the template |
|---|---|
| Text, Email, URL, Password, Color Picker | A string (empty string when blank). |
| Text Area | A string; depending on the field's new lines setting, with paragraphs (`<p>`) or line breaks (`<br />`) added. |
| WYSIWYG Editor | HTML with paragraphs. Print it with `bee_esc_html()`. |
| Number, Range | A number, or an empty string when blank. |
| True / False | `true` or `false`. |
| Select, Checkbox, Radio Button, Button Group | The chosen value (or label, or `['value' => …, 'label' => …]`, as set in the field's return format). Checkbox and multiple select give a list. |
| Image, File | An array with `ID`, `url`, `alt`, `title`, `width`, `height`, `mime_type`, `filename`, `filesize` and `sizes`, unless the return format is URL or ID. |
| Gallery | A list of image arrays (or URLs or IDs). |
| Link | `['title' => …, 'url' => …, 'target' => …]`, or only the URL if that is the return format. |
| Post Object, Relationship | A post array (`ID`, `post_title`, `post_name`, `post_type`, `post_excerpt`, `post_date`, `permalink`, `url`), or a list of them; or IDs. |
| Page Link | The page's address. |
| User | `['ID' => …, 'display_name' => …]` (the sign-in name is never given to templates). |
| Date Picker, Date Time Picker, Time Picker | The date formatted with the field's return format (PHP `date()` letters, for example `d/m/Y`). |
| Group | An array of its fields. Read it with `have_bee_rows()` or as an array. |
| Repeater | A list of rows. |
| Flexible Content | A list of rows; each row's layout name is in `get_bee_row_layout()`. |
| Form (Bee Forms) | `['ID' => …, 'title' => …, 'html' => …]`. Print it with `the_bee_form($form)`. |
| oEmbed | The embed HTML. |

## Examples

### Image

```php
<?php $image = get_bee_field('image'); ?>
<?php if ($image) : ?>
  <figure class="bk-image">
    <img
      src="<?php echo esc_url($image['url']); ?>"
      alt="<?php echo esc_attr($image['alt'] ?? ''); ?>"
      <?php if (!empty($image['width'])) : ?>
        width="<?php echo esc_attr($image['width']); ?>"
        height="<?php echo esc_attr($image['height']); ?>"
      <?php endif; ?>
      loading="lazy"
      decoding="async"
    />
  </figure>
<?php endif; ?>
```

Always print `width` and `height`: the browser then keeps the space for the photo and the page does not jump while it loads. Use `loading="lazy"` for photos below the first screen, and leave it off for the main photo at the top.

### Repeater

```php
<?php if (have_bee_rows('items')) : ?>
  <ul class="bk-items">
    <?php while (have_bee_rows('items')) : the_bee_row(); ?>
      <?php $label = get_bee_field('label'); ?>
      <?php if ($label) : ?>
        <li class="bk-item"><?php echo esc_html($label); ?></li>
      <?php endif; ?>
    <?php endwhile; ?>
  </ul>
<?php endif; ?>
```

### Group

A group is a loop with exactly one row:

```php
<?php if (have_bee_rows('card')) : while (have_bee_rows('card')) : the_bee_row(); ?>
  <div class="bk-card">
    <h3 class="bk-heading"><?php echo esc_html(get_bee_field('heading')); ?></h3>
  </div>
<?php endwhile; endif; ?>
```

### Flexible content

```php
<?php if (have_bee_rows('sections')) : ?>
  <div class="bk-sections">
    <?php while (have_bee_rows('sections')) : the_bee_row(); ?>
      <?php if (get_bee_row_layout() === 'text') : ?>
        <div class="bk-text"><?php echo bee_esc_html(get_bee_field('body')); ?></div>
      <?php elseif (get_bee_row_layout() === 'quote') : ?>
        <blockquote class="bk-quote"><?php echo esc_html(get_bee_field('quote')); ?></blockquote>
      <?php endif; ?>
    <?php endwhile; ?>
  </div>
<?php endif; ?>
```

### Link button

```php
<?php $link = get_bee_field('button'); ?>
<?php if ($link && $link['url']) : ?>
  <a class="bk-button button" href="<?php echo esc_url($link['url']); ?>"
    <?php if ($link['target'] === '_blank') : ?>target="_blank" rel="noopener"<?php endif; ?>>
    <?php echo esc_html($link['title'] ?: 'Read more'); ?>
  </a>
<?php endif; ?>
```

### Nested loops

Loops can sit inside each other. Each `have_bee_rows()` reads from the row around it:

```php
<?php while (have_bee_rows('plans')) : the_bee_row(); ?>
  <article class="bk-plan">
    <h3><?php echo esc_html(get_bee_field('name')); ?></h3>
    <?php if (have_bee_rows('features')) : ?>
      <ul>
        <?php while (have_bee_rows('features')) : the_bee_row(); ?>
          <li><?php echo esc_html(get_bee_field('feature')); ?></li>
        <?php endwhile; ?>
      </ul>
    <?php endif; ?>
  </article>
<?php endwhile; ?>
```

## Escaping

Escape every value at the moment you print it, with the helper that fits the place:

| Helper | Use it for |
|---|---|
| `esc_html($text)` | Text between tags. |
| `esc_attr($text)` | Values inside attributes (`alt`, `title`, `data-*`, `class`). |
| `esc_url($url)` | `href` and `src`. Relative addresses and `http`, `https`, `mailto` and `tel` links are kept; anything else (such as `javascript:`) prints nothing. |
| `esc_textarea($text)` | Text inside a `<textarea>`. |
| `bee_esc_html($html)` / `wp_kses_post($html)` | Rich text from the editor: keeps formatting, removes scripts. |
| `wp_get_attachment_image($id, 'large')` | A complete `<img>` tag for an image the layout's fields include. |

Other helpers you can use: `wpautop()`, `nl2br()`, `wp_trim_words()`, `sanitize_title()`, `get_permalink($post)`, `get_the_title($post)`, `wp_get_attachment_url()`, `wp_get_attachment_image_url()` and `wp_get_attachment_image_src()`.

> **Note:** People whose role does not have **Raw HTML and scripts** cannot save scripts in any field: Beekiri cleans the markup in their values when they save. Escaping still matters, because a value can contain characters such as `<` or `&` that must show as text.

## How templates run

Templates run in a restricted PHP process. They receive the field values and print HTML; that is all they can do.

- Functions that start programs, open network connections, send mail, change settings or read and write files by name are switched off.
- The process gets no server settings or secrets (no database password, no payment keys).
- Templates cannot fetch data themselves. Everything they show comes from their fields, which Beekiri prepares, including posts, images and forms chosen in those fields.

When Beekiri (the AI) writes or changes a PHP template, it is held to stricter rules: plain template code only (`if`, `foreach`, `echo`, variables and arrays) and only an approved list of formatting functions; no `include`, classes, closures or other code. Your own templates may go further, but keeping to the same style means Beekiri can safely work on them later.

## React templates

On a site set up with **React** templates, the website and the page editor render `{slug}.tsx`. Props receive the same formatted values as `get_bee_field()` (the website gets them from `POST /api/layouts/{slug}/fields`).

```tsx
export default function HeroBanner(props: {
  title?: string;
  image?: { url: string; alt: string; width: number; height: number } | null;
}) {
  return (
    <section className="section hero-banner" data-layout="hero-banner">
      {props.title ? <h2 className="bk-title">{props.title}</h2> : null}
      {props.image ? (
        <figure className="bk-image">
          <img src={props.image.url} alt={props.image.alt} width={props.image.width} height={props.image.height} />
        </figure>
      ) : null}
    </section>
  );
}
```

React escapes text for you. Rich text needs to be printed as HTML on purpose, so only do that with values from the WYSIWYG field. More in [React layouts, animation and dynamic data](doc:dev-runtime).

## Addresses on the website

- Pages: `/about`, or the structure set in **Settings → Permalinks**.
- The blog: `/blog`, and each post at `/blog/{slug}`.
- A layout's styles: `/api/layouts/{slug}/css`; its script: `/api/layouts/{slug}/js`.
