Beekiri has built-in tools to ask visitors for cookie consent, count your visitors, see where they click, and get found in search engines. They are under **Analytics** and **SEO** in the menu, and need the **Analytics & connectors** permission.

## BeeCookies: the cookie banner

[Analytics → BeeCookies](admin:analytics/cookies) shows a cookie banner on your website, so visitors can accept or refuse cookies, as privacy laws such as the GDPR require.

1. Switch on **Show the cookie banner on your website**.
2. Under **Banner**, write the **Title** and **Message**, set the **Buttons** text, choose the **Position**, and link your **Privacy policy** (it appears as a "Privacy policy" link under the message).
3. Under **Cookie categories**, choose which categories visitors are asked about (for example Analytics), with **Ask visitors about this category**. Necessary cookies are **Always on**.
4. Check the **Live preview** on desktop and phone, then save.

BeeCookies also reports **Choices**: how many visitors accepted or refused, per day.

> **Important:** Visitor counts, the heatmap and the "first visit" source of form entries only include visitors who accepted analytics cookies. Turn BeeCookies on first, with **Count visits in Analytics once a visitor accepts analytics cookies**.

## Analytics

[Analytics → Overview](admin:analytics) shows how many people visit your site and how they find it:

- **Live:** visitors in the last 5 minutes.
- **Traffic:** visitors, page views, new visitors, engaged visits, average visit length, pages per visit and bounce rate, over the **Date range** you choose, with a trend chart.
- Where visitors come from (**Channels**, **Referring sites**), **Landing pages** and **Exit pages**, and their devices and **Operating system**.

Under **Data source** you choose between Beekiri's own counts and **Google Analytics 4**. To show Google Analytics figures here:

1. In Google Cloud, create a service account with access to your Google Analytics property, and download its key file (JSON).
2. In Google Analytics, add the service account's email as a viewer of the property.
3. In Beekiri, under **Google Analytics**, paste the key file's contents, enter the **Property ID** (the property number, digits only, not the G- measurement ID) and the **Measurement ID**, and click **Save connection**.

**Hide test visits** leaves out visits from local copies of the site and unpublished drafts, so your own testing doesn't count.

## Heatmap

[Analytics → Heatmap](admin:analytics/heatmap) shows where visitors click, drawn over a picture of each page: warm colours mean many clicks.

- Pick a page from **Pages with clicks**, and a **Screen size** (desktop or phone).
- Change the **Heat intensity** to see more or less detail.
- **Total clicks** and **Visitors who clicked** show how busy the page is. **Refresh screenshot** takes a new picture after you change the page.

Use it to see whether visitors find your buttons, and which parts of a page they ignore.

## SEO: the site audit and tools

[SEO](admin:seo) helps you get found in search engines.

- **Site audit** checks every page of your site and gives your **Site SEO health** score. It lists issues by **Severity** (**Critical**, **Warnings**, **Info**) for each page: missing titles, headings (H1), images without alt text, slow pages, broken links and redirects.
- **Keyword research** shows how often people search for words (**Monthly searches**), how competitive they are, and who ranks for them, so you can choose the words to write about.
- **Domain overview** estimates the visits your site gets from search results and the keywords it ranks for.
- **Backlinks** lists other sites that link to yours.

The figures in Keyword research, Domain overview and Backlinks are estimates.

## SEO for each page

In the page editor, the **SEO** tab sets how a page appears in Google and when shared:

- **Search appearance:** the focus keyword, the title and description shown in search results, with a preview.
- **Social:** the share image (1200 × 630 recommended; without one, the featured image is used), and the title and description for social media.
- **Technical:** options for search engines, such as no snippet, no cached copy, don't index images or no translation.
- **Checklist:** what is good and what to improve on this page.

Click the ✦ helper and Beekiri reads the page, fills in the focus keyword, title and description, and suggests **Fixes for the page** (for example a better heading, a shorter web address or a share image). Click **Fix** or **Fix all**, then save the page.

## The whole site

- **Search visibility:** let search engines list your site only when it is ready, in [Settings → Advanced](admin:settings?tab=advanced). Your sitemap is listed there too.
- **Verification and tracking codes** (Google Search Console, Bing, Google Tag Manager) go in [Settings → General → SEO](admin:settings?tab=general). See [Site settings](doc:settings#seo-and-site-code).
- **Speed** matters for search: see [Updates, cache and speed](doc:updates#keep-your-site-fast).
