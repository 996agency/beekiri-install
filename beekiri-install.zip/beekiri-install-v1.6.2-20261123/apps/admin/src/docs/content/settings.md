[Settings](admin:settings) holds everything that applies to the whole site. Each tab is described below. You only see the tabs your role allows; **Security**, **Email**, **Migration** and **Sites** are for the owner alone.

## Beekiri Core

The first tab shows whether everything is running and which version you have.

- **Status:** the server, the website, the admin and the database, with how long Beekiri has been running. **Refresh** checks again.
- **Version:** your version of Beekiri Core. **Check for updates** asks whether a newer version exists; if one does, **Update to …** installs it. See [Updates, cache and speed](doc:updates).

When an update is available, a **+1** appears next to Settings in the menu.

## General

The basics of your site. One **Save changes** button saves the whole tab.

### Site

| Setting | What it does |
|---|---|
| **Site title** | Your site's name, used in the browser tab and search results. |
| **Tagline** | A short line about your site, shown on your home page. |
| **Favicon** | The small icon in the browser tab. Paste an address or click **Upload** (PNG, JPEG, WebP, GIF, SVG or ICO), then **Save changes**. **Reset to default** brings back the Beekiri icon. |
| **Admin URL** | The address of your admin, `/admin` by default. Changing it hides your admin from people guessing the usual address. |
| **Sign-in address** | The last part of the sign-in page's address, `login` by default (so `/admin/login`). |

> **Warning:** After you change the **Admin URL** or **Sign-in address**, the old addresses stop working at once. Beekiri reloads at the new address and shows both new addresses: bookmark them. Only people allowed to change Advanced settings can change these two.

### SEO and site code

The **SEO** panel adds code to every page of your site, for example a Google Analytics or Tag Manager snippet, a verification tag, or a chat widget. It has four tabs; a dot on a tab means it has content.

- **Header editor:** code added inside `<head>`. Beekiri already adds the title, description, favicon and sharing tags itself. **Load SEO starter** fills in a ready-made set (search engine rules, sharing tags, and your business details for Google). **Google verification** and **Bing verification** add the tag those services ask for.
- **Body editor:** code added at the start of the page, such as the second part of a Google Tag Manager snippet.
- **Footer editor:** code added at the end of the page. Scripts should use `defer` or `async` so the page stays fast.
- **Google Business:** your business name, category, phone, address, hours and a photo, used to describe your business to Google. This does not create a Google Business Profile; use **Open Google Business Profile** for that.

Each editor takes up to 50,000 characters. Only paste code from sources you trust: it runs on every page.

> **Note:** Only people with both **Analytics & connectors** and **Raw HTML and scripts** may change the site code.

## Page editor

Shows the editor your site uses (the Beekiri visual editor) and the **Theme templates** your site was set up with: **PHP** or **React**. This was chosen when the site was set up and does not change. It doesn't change how you edit pages, media or content.

## Advanced

### Reading

- **Search visibility:** **Let search engines list this site.** Turn it on when your site is ready for visitors; leave it off while you are still building, so half-finished pages don't appear in Google.
- **Sitemap:** links to your sitemap (`/sitemap.xml`) and `robots.txt`, with the list of addresses in the sitemap. Give the sitemap address to Google Search Console. Your admin address never appears in it.

### Writing

**Date format** and **Time format** decide how dates and times are written. They use letters that stand for parts of the date:

| Format | Example |
|---|---|
| `F j, Y` (default) | November 23, 2026 |
| `j F Y` | 23 November 2026 |
| `d/m/Y` | 23/11/2026 |
| `g:i a` (default) | 6:30 pm |
| `H:i` | 18:30 |

### Language and timezone

The **Site language** and **Timezone** decide how dates and labels appear. Changing them does not change your content. To show your site in several languages, use **Translation**.

## Translation

Show your website in more than one language. Your **primary language** is shown at the normal addresses (`/about`); each other language gets its own prefix (`/de/about`).

1. Under **Languages**, search **Add a language** and pick one (up to 60).
2. Under **Texts**, click **Scan site**. Beekiri collects the headings, buttons, menu labels and paragraphs from your published pages.
3. Translate each text in the language's tab, or click **Auto-translate missing** for a first draft (a free translation service; check the result). **Stop** cancels it.
4. Click **Save translations**. Your website shows them within a few seconds.

More:

- The filter **All / Missing / Translated** helps you find what is left. **Add text** adds a text by hand.
- **Make primary** changes the primary language. Turning a language off keeps its translations.
- To let visitors switch language, add a language switcher to the menu: **Settings → Permalinks → Languages → Add language switcher**. In text you can also use the shortcode `[beekiri_language_switcher]` (or `[beekiri_language_switcher style="list"]`).
- To keep a word from being translated (a brand name, for example), it must sit in an element marked `translate="no"`.

## Permalinks: menu and home page

This tab is where you build your site's **menu** and choose your **home page**.

1. On the left, choose what to add: **Pages**, **Posts**, **Custom link** (any address, also to other sites) or **Languages** (a language switcher).
2. Tick the items and click **Add … to the menu**.
3. On the right, under **Menu structure**, drag items to change their order. Drop an item onto another to make it a sub-item (up to three levels).
4. Click an item to change its **Menu label** or **URL**.
5. Click **Save menu**.

Each item also has **Hide from menu** (it keeps its place but isn't shown), **Make home page** (for top-level pages), **Indent**, **Outdent**, **Open** and **Remove**. To remove your home page from the menu, make another item the home page first.

> **Tip:** With an item selected, the arrow keys move it up and down, and **Alt + →** / **Alt + ←** indent and outdent it.

## Media

How new uploads are prepared. These settings apply to photos you upload from now on.

| Setting | Default | What it does |
|---|---|---|
| Convert all images to WebP on upload | On | WebP photos are much smaller, so pages load faster. |
| Best quality (recommended) | On | Turn it off to choose a **WebP quality** (1–100) for smaller files. |
| Remove hidden photo details | On | Removes camera details and the location where a photo was taken. |
| Also keep the original file | Off | Keeps the uploaded original too (uses more storage). |
| Max width / Max height | 1920 × 1920 px | Larger photos are scaled down; smaller ones are never enlarged. |

Folders for your media are made on the [Media](admin:media) page itself. See [Media library](doc:media).

## Email

Order confirmations, form notifications, booking emails and password resets all need a way to send email. Set it up here (owner only).

The line at the top tells you how your site sends email right now: through your own mail server, through the server's default sender, or **Email isn't set up**, in which case nothing can be sent.

1. Switch on **Use this server**.
2. Choose your **Provider** (Gmail / Google Workspace, Microsoft 365 / Outlook, Hostinger, Brevo, Mailgun, SendGrid) to fill in the server details, or **Other / fill in myself**.
3. Enter the **Username** and **Password** of the email account. The password is stored encrypted and never shown again.
4. Under **Sender**, enter the **From address** (usually the same account), a **From name** and, if you like, a **Reply-to address**.
5. Click **Send a test email**. It goes to your own email address, using what is on the form even before you save.
6. When the test arrives, click **Save changes**.

| Provider | Server | Port | Encryption |
|---|---|---|---|
| Gmail / Google Workspace | smtp.gmail.com | 587 | STARTTLS |
| Microsoft 365 / Outlook | smtp.office365.com | 587 | STARTTLS |
| Hostinger | smtp.hostinger.com | 465 | SSL/TLS |
| Brevo | smtp-relay.brevo.com | 587 | STARTTLS |
| Mailgun | smtp.mailgun.org | 587 | STARTTLS |
| SendGrid | smtp.sendgrid.net | 587 | STARTTLS |

> **Tip:** Gmail and Microsoft accounts with two-step sign-in need an **app password** instead of your normal password. Create one in your Google or Microsoft account's security settings.

If you change the server or the username, enter the password again. Changes to email settings are written to the activity log (never the password).

## Security, Migration and Sites

These owner-only tabs have their own articles:

- **Security:** firewall, bot check, Cloudflare, two-step sign-in and the activity log. See [Security](doc:security).
- **Migration:** copying your site to or from another computer or server, and backups. See [Migration and backups](doc:migration-backups).
- **Sites:** running several websites in one Beekiri. See [Several sites in one Beekiri](doc:multisite).

## Documentation

This documentation. It is always here, under the last tab of Settings.
