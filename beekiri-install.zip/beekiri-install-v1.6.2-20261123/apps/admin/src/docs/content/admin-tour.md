The admin is where you run your site. It has three parts: the **menu** on the left, the **top bar**, and the screen you are working on. This article shows where everything is.

## The menu

The menu is grouped by what you do. You only see the parts your role allows, and the groups for extensions only appear while those extensions are on.

| Group | Items |
|---|---|
| (top) | **Dashboard**, **Analytics** (Overview, Heatmap, BeeCookies) |
| **Content** | **Posts**, **Pages**, your own content types (for example Team or Projects), **Media**, **SEO** |
| **Shop** | Overview, Products, Categories, Tags, Orders, Customers, Coupons, Shop Editor and Settings (with Bee Shopping) |
| **Forms** | All Forms, Entries and Integrations (with Bee Forms) |
| **Bookings** | Calendar, Appointments, Services, Staff and Settings (with Bee Bookings) |
| **Admin** | **Backend Fields**, **Users**, **Appearance**, **Connector**, **Extensions**, **Settings** |

At the bottom of the menu you see your Beekiri version and the **Feedback** button.

## The top bar

From left to right, depending on your role:

- **PageSpeed scores** (P, A, B, S) show how fast and healthy your site is. See [Updates, cache and speed](doc:updates#page-speed-scores).
- **Search** opens a search of every admin screen (see below).
- **My sites** switches between your sites, when there are two or more.
- **Balance** shows Beekiri's balance and opens the Beekiri chat. While Beekiri works, it shows what it is doing and the cost so far.
- **Clear cache** makes sure visitors see your latest changes.
- **The bell** shows notifications.
- **Your name** opens your profile.
- **Sign out**.

The top bar stays at the top of the screen while you scroll.

## Search the admin

Press **Ctrl + K** (or **⌘ K** on a Mac), or click **Search**, and type what you are looking for: "shipping", "favicon", "new page", "two-step". Press **Enter** to open the first result, or **Esc** to close.

Search finds admin screens and settings, not your content. To find a page or a product, use the search on the Pages or Products list.

## Notifications

The bell shows what happened on your site while you were working, as it happens. A new notification also appears briefly in the corner of the screen. You get the ones that concern your work:

| Notification | Who gets it |
|---|---|
| New orders and parcel updates | People who manage orders |
| New and cancelled bookings | People who manage bookings |
| New form entries | People who can read entries |
| Changed settings | Administrators |
| Beekiri and extension updates | People who can update Beekiri, administrators |
| New people added | People who can see the list of users |
| Security alerts (banned addresses, two-step sign-in turned off) | Administrators |

Opening the list marks everything as read. You are never notified about your own actions.

## The dashboard

The [Dashboard](admin:) is your home screen. It shows blocks such as **Storage**, **Date & time**, **Pages**, **Posts**, **Media**, **Status** (whether the site is live), **Activity** (recent changes by your team), **Publish lineup** (drafts waiting to go live), **Fields**, **Users** and, with Bee Shopping, **Shop** (this week's sales and recent orders).

Click **Customize** to arrange it your way: drag blocks to move them, add or remove blocks, and click **Done**. **Reset layout** brings back the standard arrangement. Each person's dashboard is their own.

## Signing out

You are signed out automatically after 20 minutes without activity anywhere in the admin. Two minutes before, a message asks **Are you still there?**; click **Stay signed in** to continue. When you sign in again, you return to the screen you were on.

## Feedback

Have an idea, found a problem, or something you love? Click **Feedback** at the bottom of the menu, choose what it is about, optionally rate Beekiri, write your message and click **Send feedback**. It goes straight to the Beekiri team. Tick **Reply** if you'd like an answer by email.
