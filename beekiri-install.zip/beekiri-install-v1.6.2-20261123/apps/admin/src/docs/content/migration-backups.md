[Settings → Migration](admin:settings?tab=migration) copies your site between places: from your computer to a test site (staging), from staging to the live site (production), or the other way round. It also makes backups and moves a site to a new server. Only the owner can use it.

## The five ways to migrate

| Mode | Use it to |
|---|---|
| **Push** | Send this site to another site. |
| **Pull** | Bring another site here. |
| **Deploy package** | Put the whole site in one zip, to start it on a new server. |
| **Export file** | Download the site as a `.beekiri` file. |
| **Import file** | Upload a `.beekiri` file into this site. |

## Connect two sites

Push and pull need the two sites to be connected once.

1. On the **other** site, open Settings → Migration. Under **Connect other sites to this one**:
   - Set **This site is** to Local, Staging or Production (or let Beekiri detect it from the address).
   - Switch on **Allow push** (to let sites send to it) and/or **Allow pull** (to let sites copy from it). Both are off by default.
   - Copy the **Connection info** with **Copy**.
2. On **this** site, choose **Push** or **Pull**, paste the other site's connection info, give it a **Name** if you like, and click **Connect**.

**Check connection** tests it later; **Remove** forgets the other site.

> **Warning:** The connection info works like a password: anyone who has it can copy your site or overwrite it (if you allowed that). Keep it private. **Reset key** makes a new one and disconnects everyone using the old one.

## What to copy

**Theme code:** your theme files, section designs (layouts) and their Backend Fields. Pages, posts, users and settings stay as they are on the other site. Use this to bring design work from staging to the live site without touching its content. You can also make the copied theme the active theme there.

**Full database:** pages, posts, menus, settings, users and shop data, optionally with **Include theme files** and **Include media files** (only new or changed files are sent).

- **Find & replace** pairs change the site's address inside the content, for example `http://localhost:8788` to `https://example.com`. Beekiri suggests them.
- **Advanced options** choose what the other site keeps of its own: analytics, heatmaps and cookie consents; orders, customers and carts; the activity log. When you push to a live shop, keep its orders and customers. **Delete media files on … that are not on …** cleans out old files (they are backed up first).

A confirmation shows before anything is overwritten. While it runs you see each step and a progress bar; **Cancel** stops it.

> **Important:** A full database copy replaces the people on the receiving site, so you are signed out there. Click **Sign in again** and sign in with an account from the site you copied from.

## What each site always keeps

Whatever you copy, each site keeps its own: sign-ins, connection key, Beekiri connection, admin address, search visibility setting, payment keys and courier connections. So a test site never takes payments with the live site's keys, and the live site never becomes hidden from Google because staging was.

## Backups

Before every push, pull, import or restore that changes a site, Beekiri makes a backup of it automatically. The newest 5 are kept, under **Backups**, with when each was made, what it contains and its size.

- **Restore** puts the site back as it was in that backup.
- **Download** saves the backup on your computer. Keep a copy somewhere safe from time to time.
- **Delete** removes it.

To make a backup yourself at any time, use **Export file**: the downloaded `.beekiri` file can later be brought back with **Import file**.

## Move to a new server

A **Deploy package** is one zip with everything needed to start your site on a new server: Beekiri, your database, all themes and every media file.

1. Click **Prepare deploy package** and download the zip.
2. On the new server (Node.js 20 or newer), unzip it, run `npm install`, then `npm start` (or point your host's Node.js app at `server.js`). The zip contains `START_HERE.txt` with the same steps.
3. Open the setup link that appears and create an account.
4. Sign in, and click **Restore this site** in the banner on Settings → Migration.

Payment keys and email passwords are not in the package, for safety. Enter them again on the new server: [Shop → Settings → Payments](admin:shop/settings?tab=payments) and [Settings → Email](admin:settings?tab=email).

## Several sites in one Beekiri

With more than one site, Migration copies the theme code and media of the site you are on; a full database copy is only possible while there is a single site. See [Several sites in one Beekiri](doc:multisite).
