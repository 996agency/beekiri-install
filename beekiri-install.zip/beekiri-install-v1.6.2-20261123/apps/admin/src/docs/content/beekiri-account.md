Beekiri is paid for with a prepaid balance: you add money, and each request uses a little of it. Everything about the balance and about Beekiri's changes is on the [Connector](admin:connector) page, which administrators can open.

## Turn Beekiri on or off

At the top of the Connector page:

- **Turn on / Turn off** switches Beekiri for the whole site. When it is off, the chat is hidden for everyone until you turn it on again.
- The status shows **Connected to 996Agency** once your site is connected. This happens automatically; there are no keys to enter.

## The balance

The **Balance** tab shows:

- **Added − Spent = Left to spend.** Money you add never expires.
- **This month:** what was spent and how many messages were sent.
- **A message costs about:** the average cost of a message, so you can plan.
- **On its way:** payments that are made but not yet confirmed.

When the balance reaches zero, Beekiri pauses until money is added. The **Balance** button in the top bar then says "add money".

## Add money

1. Open [Connector](admin:connector).
2. Under **Added**, choose an amount, or **Other amount** for your own amount in whole dollars.
3. Pay by card on the secure 996Agency checkout.

The money is added as soon as the payment is confirmed. If you cancel the checkout, nothing is charged. A list under **Added** shows each top-up as **Waiting for payment**, **Added** or **Declined**.

## What a message costs

Each message is priced by the work it took: a short question costs little, while designing a whole homepage with many steps costs more.

- While Beekiri works, the **Balance** button shows the cost so far, and the reply shows the final cost.
- The **Spent** panel lists every message with its time, the request, who sent it, the number of steps and the cost. Switch between **Today**, **This week**, **This month** and **All time**.
- Short replies like "thanks" or "ok" are answered for free.
- Each click on a ✦ helper (alt text, SEO) is also paid from the balance.

> **Tip:** Bigger, clearer requests are usually cheaper than many small corrections. Give Beekiri the full picture in one message: the content, the look and an example.

## Change history

The **Change history** tab lists every request that changed something, newest first: what was asked, who asked and when, and every change it made (theme, sections, pages, posts, products, photos, folders).

- Requests whose new sections are still hidden from visitors are listed first, under **Waiting for you**. Use **Preview** to see them privately (the link works for 24 hours, only for you), then **Keep** or **Revert**.
- Open a request to revert one change, or revert the whole request.
- Reverting goes back in order, newest change first. Pages, sections and products Beekiri created go to the trash; photos it imported are removed from the Media library.
- If someone edited the same thing after Beekiri, you are warned (**Edited after Beekiri changed it**) and can choose **Revert anyway**.

Changes Beekiri makes inside the page editor are not in this list: undo them in the editor itself.

> **Note:** Not recorded here: changes to bookings setup, form entries marked as read or spam, and the design brief. Change those back on their own screens or ask Beekiri.

## Who can do what

| Person | Can |
|---|---|
| Owner | Everything on this page, and use the chat. |
| People with **Analytics & connectors** | Open Connector: turn Beekiri on or off, add money, keep and revert changes. |
| People with **Use the Beekiri agent** | Use the chat and the ✦ helpers. Each message is paid from the site's balance. |

Set these in [User Permissions](admin:users/permissions). See [Users, roles and permissions](doc:users-permissions).
