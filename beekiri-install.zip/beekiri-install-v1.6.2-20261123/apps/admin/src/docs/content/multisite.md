One Beekiri can run several websites, for example your main site, a shop on `shop.example.com` and a site for each location. Each site has its own address, pages, menus, media, settings, forms, shop and analytics. People sign in once and switch between the sites they may use.

Only the **owner** manages the network, in [Settings → Sites](admin:settings?tab=sites).

## Add a site

1. Open [Settings → Sites](admin:settings?tab=sites).
2. Click **Add site**.
3. Enter a **Site name** and a **Sub-domain** (lowercase letters, numbers and dashes, for example `shop`), and choose a **Theme**.
4. Click **Create site**.

The new site is live at once at `shop.yourdomain.com`, with the theme's ready-made pages if it has any.

## Manage your sites

Each site in the list shows its theme, number of pages and number of people, with tags such as **Main site**, **You are here**, **Archived** and **Password protected**. The buttons on each row:

| Button | What it does |
|---|---|
| **Open admin** | Opens that site's admin, already signed in. |
| **Password** | Hides the site behind a password while you build it (see below). |
| **Edit** | Changes the name, and for other sites the sub-domain and **Your own domain**. |
| **Archive** / **Turn on** | Takes a site offline without deleting anything, and brings it back. |
| **Delete** | Deletes the site for good: its pages, media, forms, shop data and analytics. You type the site's sub-domain to confirm. Accounts are kept. |

The main site can't be archived or deleted, and you can't delete the site you are on.

## Hide a site behind a password

Useful while you build a site or show it to a client:

1. Click **Password** on the site's row, then **Turn on password** (at least 4 characters).
2. Send the site's address and the password to the people who should see it.

Visitors and search engines see a password page instead of the site. After typing the password once, a browser remembers it for 30 days. **Change password** asks everyone to type the new one; **Remove password** opens the site to everyone. People signed in to that site's admin always see it normally.

## Addresses and domains

| Site | Address |
|---|---|
| Main site | Your main address, for example `https://example.com` |
| Other sites | `https://<sub-domain>.<network domain>`, for example `https://shop.example.com` |
| A site with its own domain | That domain, for example `https://myshop.com` (the sub-domain keeps working too) |

The network domain is your main site's domain unless you change it under **Network domain → Change**.

> **Important:** For sub-domains to work on a server, whoever manages your server adds one wildcard DNS record (`*.example.com` pointing to the server) and a certificate that covers every sub-domain. For your own domain, point its DNS to the server first, then enter it under **Edit**. On your own computer, addresses like `http://shop.localhost:8788` work without any set-up.

An address that doesn't belong to any site answers "There is no site at this address", so a typo never shows another site.

## People on several sites

- Everyone has **one account** for the whole network.
- The owner decides who may use which site: in [User Permissions → People](admin:users/permissions), pick a person and set, in the **Sites** card, their role on each site or **No access**. Each site needs at least one administrator.
- Someone added on a site gets access to that site only.
- Removing someone on a site only takes away their access to that site.
- The owner can use every site as an administrator.

To switch sites, use the **My sites** menu in the top bar. It appears when there are two or more sites and opens the other site's admin already signed in.

## Section designs on several sites

- A section design (layout) made in Backend Fields belongs to the site it was made on.
- The owner can **Share with all sites**: it becomes a global design every site can use, whatever its theme.
- On any site, **Customise for this site** makes that site's own copy, which you can then change freely; other sites keep the global version. **Use global design** removes the copy again.

## Good to know

- A theme bought in the Beekiri store is licensed for the whole network: one licence covers every site.
- [Settings → Migration](admin:settings?tab=migration) copies the theme code and media of the site you are on. A full database copy is only possible while there is a single site.
- Each site has its own email settings (Settings → Email) and its own shop settings.
