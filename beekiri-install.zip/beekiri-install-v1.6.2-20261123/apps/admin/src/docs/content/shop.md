Bee Shopping turns your site into a shop: products with sizes and colours, a cart, checkout, card and cash payments, shipping, orders, customer accounts and coupons. This article covers running the shop day to day. For payments, shipping and the other settings, see [Bee Shopping: payments, shipping and settings](doc:shop-settings).

## Turn it on

Go to [Extensions → Add New](admin:extensions/new) and install **Bee Shopping**. A **Shop** menu appears, and your website gets the shop, cart and checkout pages, with a cart icon in the header.

Before you sell, go through the settings: your address and currency, at least one payment method and a shipping zone. See [Bee Shopping: payments, shipping and settings](doc:shop-settings#before-you-sell).

## Add a product

1. Go to [Shop → Products](admin:shop/products) and add a product.
2. Enter the **Product name**, a **Description** and a **Short description** (shown next to the photos).
3. Under **Price**, enter the **Regular price**. For a sale, add a **Sale price**, and if you like **Sale starts** and **Sale ends** dates.
4. Add photos: the large one is the main photo, the others make the gallery.
5. Choose **Categories** and **Tags** in the sidebar.
6. Click **Publish**, or **Save draft** to finish later.

More settings sit in folding sections ("All optional. Open what you need."):

| Section | What you set |
|---|---|
| **Inventory** | **SKU** (your product code), **Stock** counting with **Quantity** and a **Low stock threshold**, what happens **When it runs out** (**Do not allow orders** or **Allow backorders**), and **Sold individually: limit to one per order**. |
| **Shipping** | Whether it is a physical product, its **Weight (g)** and size in millimetres. Choose **No shipping needed** for a service, a download or a booking. |
| **Tax, visibility and notes** | Whether to charge tax, **Catalog visibility** (**Shop and search results**, **Shop only**, **Search results only** or **Hidden (direct link only)**), **Featured product**, and a **Purchase note** sent to the buyer after payment. |

Only published products appear on your website.

> **Tip:** Ask Beekiri: "Add a product called Linen Shirt, 49.90, in S, M and L, white and navy, with this photo." Or "Write descriptions for the products that have none."

## Sizes, colours and other options

For a product that comes in versions, open **Options and variations**:

1. Add an option, such as **Size**, and its **Values** (S, M, L). Tick **Customers choose this (makes variations)**. Untick it for details that are only shown, such as material, with **Visible on the product page**.
2. Add more options if needed (Colour: White, Navy).
3. Click **Create all variations**: one variation for every combination.
4. Open a variation to set its own price (or **Same price for all**), SKU, stock and photo.

A variation can be switched off so customers can't buy it. **Update the list** adds variations for new values later.

## The products list

[Shop → Products](admin:shop/products) lists every product. Search by name or SKU, filter by status, category, stock and type, and sort. Select several products to publish, unpublish or trash them at once. Products can be duplicated, and trashed products can be restored.

[Categories](admin:shop/categories) and [Tags](admin:shop/tags) have their own screens. Categories can be nested: a category page also shows the products of its sub-categories.

## Orders

[Shop → Orders](admin:shop/orders) lists every order with its status:

| Status | Meaning |
|---|---|
| **Pending payment** | A card payment has started but isn't confirmed yet. The stock is held for a while; if the payment never arrives, the order is cancelled automatically. |
| **On hold** | Waiting for a bank transfer. |
| **Processing** | Paid, or cash on delivery: prepare and ship it. |
| **Completed** | Done. Cash on delivery orders are marked paid here. |
| **Cancelled** | Cancelled by you, by an expired payment, or by the customer abandoning a card payment. |
| **Refunded** | Fully refunded. |
| **Failed** | The payment failed. |

A new order appears in the bell, and the shop owner receives an email.

Open an order to see the items, totals, addresses, payment and notes, and to:

- **Change the status**, with an optional note that goes into the customer's email. Moving an order to **Processing** marks a bank transfer as paid; **Cancelled** or **Refunded** puts the items back in stock.
- **Add a note**: a private note for your team, or a note to the customer (emailed).
- **Refund** all or part of the order. For card orders, tick the option to refund the card through Stripe; for other payment methods, return the money yourself and record it here. Items can go back into stock.
- **Resend** any of the order emails.
- Change the customer's email, phone or addresses.

Customers can always open their order from the link in their emails, without signing in.

## Shipping and tracking

Every order has a **Shipping & tracking** panel. Mark it **Packed**, then **Shipped** (with the carrier, tracking number and tracking link), then **Delivered**, which completes the order. Shipped and Delivered can email the customer.

Customers see the progress (Order placed → Payment → Packed → Shipped → Delivered) on their order page and in their account, with a **Track parcel** button when you added a link.

With a connected courier, **Send to courier** creates the shipment and fills in the tracking for you, and the order then moves to Shipped and Delivered by itself. See [Couriers](doc:shop-settings#couriers).

## Customers and accounts

[Shop → Customers](admin:shop/customers) lists everyone who has ordered, with what they spent and their last order.

Customers can create an account on your website (at `/account`, or by ticking "Create an account" at checkout). In their account they see their orders with tracking, their saved addresses and their details. Order history appears once they have confirmed their email address.

Your own admin sign-in also works in the shop: while you're signed in to the admin, the shop shows your orders under your admin email.

## Coupons

[Shop → Coupons](admin:shop/coupons) makes discount codes that customers enter in the cart:

- **Type:** a percentage, a fixed amount off the cart, or a fixed amount off each product.
- **Restrictions:** a minimum or maximum spend, only certain products or categories, excluded products, and free shipping.
- **Limits:** total uses, uses per email address, and an expiry date.

A use is counted when the order is placed (for card payments: when the payment is confirmed).

## Shop overview

[Shop → Overview](admin:shop) shows revenue, orders, average order value, items sold and new customers for today, 7, 30 or 90 days or a year, with a daily revenue chart, orders by status, top products, low-stock warnings and recent orders. The **Shop** block on the Dashboard shows the last seven days.

## Design the shop pages (Shop Editor)

[Shop → Shop Editor](admin:shop/pages) lists the shop's pages: the shop, the product page, the cart, the checkout and the order received page. Each one is a page you edit in the page editor, with one special block in the middle, **Shop content**, where the live products, cart or checkout appear.

- Add anything above and below it: a banner on the shop page, a trust bar on the checkout, a "you may also like" section under the product.
- Switch parts of the shop content on or off per page: products per row, the category sidebar, the search box, the sorting dropdown, breadcrumbs, gallery thumbnails, related products, the coupon form and more.
- **Reset page** returns a page to the default design.

## Your shop on the website

| Page | Address |
|---|---|
| Shop | `/shop` |
| A category | `/shop/category/<category>` |
| A product | `/product/<product>` |
| Cart and checkout | `/cart`, `/checkout` |
| Customer account | `/account` |

Add the shop to your menu in [Settings → Permalinks](admin:settings?tab=permalinks). Texts on the shop pages can be translated in [Settings → Translation](admin:settings?tab=translation).

## Who can do what

| Permission | Lets someone | By default |
|---|---|---|
| **Products** | Create, edit and delete products, categories and tags. | Administrator, Shop manager |
| **Orders & customers** | Manage orders, refunds, customers and coupons. | Administrator, Shop manager |
| **Shop settings** | Change payments, shipping, taxes and emails. | Administrator, Shop manager |
| **Shop reports** | See sales figures. | Administrator, Shop manager |

The **Shop manager** role is made for people who only run the shop. See [Users, roles and permissions](doc:users-permissions).
