Dynamic content repeats one design for every item in a list: every product, every blog post, or every row of a list you fill in. Design one card, and Beekiri repeats it for each item, filling in titles, prices, photos and links from your real content. When you add a product or publish a post, the page updates by itself.

## Make a repeating grid

1. Add a box that will hold the cards, for example a **Grid** or **3 columns**, and select it.
2. In **Props**, find **Repeat for** and choose what to repeat:
   - **Shop products** (with Bee Shopping on)
   - **Journal posts** (your blog)
   - **Backend Fields (repeater)**: the rows of a list field in one of your layouts
3. Make sure the box has exactly **one element inside**: this becomes the card that repeats. If the box had several, Beekiri asks to keep the first one as the card (**Use it as the card**).
4. Design the card like any other element: a photo, a title, a price, a button.
5. Connect each part of the card to the item's data (next section).

The canvas immediately shows a card for each item. Only the first card can be edited; the others are copies.

## Connect the card to the data

Select an element inside the card. Next to its content in Props, the ⚡ button (**Use dynamic content**) lets you pick which piece of the item it shows:

| Source | Fields you can use |
|---|---|
| **Shop products** | Product name, Price, Regular price, Short description, Category, SKU, Stock status, Product page, Add to cart, Category page, Product photo |
| **Journal posts** | Title, Excerpt, Date, Author, Reading time, Story page, Featured photo |
| **Backend Fields** | The fields of the chosen repeater |

Connect texts to text fields (a heading to **Product name**), links and buttons to pages (**Product page**, **Story page**), and photos to photo fields (**Product photo**). A button connected to **Add to cart** adds the product to the cart in one click; products with options (such as sizes) open their page instead.

To stop using the data, choose **Type a value instead**.

## Choose which items appear

With the box selected, under **Repeat for**:

| Setting | What it does |
|---|---|
| **Show up to** | How many items (up to 60). |
| **Sort by** | Products: **Shop order**, **Newest first**, **Name A–Z**, **Price: low to high**, **Price: high to low**, **Best sellers**. Posts: **Newest first**, **Oldest first**, **Title A–Z**. |
| **Category** | Only items from one category (sub-categories included). |
| **Only featured products** | Only products marked as featured. |
| **Hand-pick products** | Choose exact products, in your own order. This replaces the filters above. |

For **Backend Fields**, choose the **Field group** and the **Repeater**, then add, edit and reorder the rows right there in Props.

## Examples

- **Home page "Best sellers":** a 4-column grid repeating **Shop products**, sorted by **Best sellers**, showing up to 4.
- **"Latest from the blog":** a 3-column grid repeating **Journal posts**, newest first, showing 3.
- **A collection page:** a grid repeating products from one **Category**.
- **A featured trio:** **Hand-pick products** to show exactly the three you want.

> **Tip:** Ask Beekiri: "Add a section with my four newest products, each with photo, name, price and an Add to cart button." It builds the grid and connects every field for you.

## Good to know

- Only published products and posts appear. For a product that is out of stock, an **Add to cart** button opens the product's page instead.
- Changes to products and posts show on the page by themselves; you don't need to edit the page again.
- Developers can read the same data from their own scripts. See [React layouts, animation and dynamic data](doc:dev-runtime#dynamic-content-api).
