**Appearance** is where you choose the look of the whole site: the theme, the header and footer, and themes from the Beekiri store. Your menu lives in Settings, and pop-ups and banners are site sections. All of it is covered below.

You need the **Appearance** permission (administrators have it).

## Themes

[Appearance → Themes](admin:appearance) lists the themes installed on your site. The active one is marked **Active**.

- **Activate** switches your site to another theme. A theme can bring its own pages; Beekiri offers to add them (**Add its pages**). Your existing pages are untouched.
- **Reset its pages** puts a theme's own pages back as the theme made them, if you'd like to start over. **Keep my edits** leaves your changes.
- **Theme details** shows the theme's version, type and ID.
- **Upload theme** installs a theme from a zip file.
- **Delete theme** removes a theme you don't use.

The **Beekiri starter theme** works as a pair: a parent (built in) and a **child theme** where everything made for your site is kept. Beekiri updates never change the child, so your work is always kept.

> **Tip:** On the starter theme, ask Beekiri for a **Full website design**: it designs the colours, fonts, header, footer and homepage from a few questions. See [Full website design and the design brief](doc:full-website-design).

## Theme store (Templates)

[Appearance → Templates](admin:appearance/templates) shows professional themes made by 996Agency.

1. Open a theme to read **About this theme** and see its price.
2. Click **Buy** and pay on the secure checkout. Your licence key appears, and the theme is yours.
3. Click **Install**, then activate it in **Themes**.

Bought it already, for another site? Use **Already bought it? Enter licence key**. A licence covers one local, one staging and one production site of yours, or a whole network of sites.

When a new version of an installed theme is available, an **Update** button appears. Your own changes are kept, because they live in the theme's child.

> **Note:** Some themes need an extension, such as Bee Shopping for a shop theme. Such a theme can only be activated once that extension is on; see [Extensions](doc:extensions).

## Header and footer

[Appearance → Header](admin:appearance/header) and [Appearance → Footer](admin:appearance/footer) show the designs your active theme offers. Click **Activate** on the one you want; **View site** shows the result.

The header shows your site title or logo and the **menu**. Edit the menu in [Settings → Permalinks](admin:settings?tab=permalinks). See [Site settings](doc:settings#permalinks-menu-and-home-page).

To change a header's look (colours, a sticky header, a different layout of the logo and menu), ask Beekiri: "Make the header dark with the menu centred" or "Make the header stay at the top when scrolling."

## Your logo and icon

The small icon in the browser tab (favicon) is set in [Settings → General](admin:settings?tab=general). For a logo in the header, upload it to the Media library and ask Beekiri: "Use my logo in the header."

## Pop-ups, banners and bars (Site sections)

**Site sections** are pieces that appear on many pages at once: an announcement bar, a newsletter pop-up, a banner about a sale. Each one is built in the normal page editor.

1. Open **Site sections** in the menu (under Content) and add one, or ask Beekiri: "Show a bar at the top of every page: Free shipping over €50."
2. Build it in the editor.
3. In the **Page** tab, under **Where it shows**, choose **Top of the page** or **Bottom of the page**, and on every page or only the pages you choose.
4. **Publish** to show it on your website. Switch it to draft to hide it again.

Pop-ups and sticky bars position themselves.

## Fonts and colours

The theme's colours, fonts and buttons apply everywhere. On the starter theme, the quickest way to change them is the design brief: see [Full website design and the design brief](doc:full-website-design). You can also ask Beekiri directly: "Use Inter for all text and make the buttons dark green." Fonts are stored on your own site, so visitors never load them from Google.

For developers: the site-wide styles live in the active header's `styles.scss` in the child theme. See [Theme structure](doc:dev-themes).
