Extensions add bigger features to your site when you need them. They are made by the Beekiri team, kept up to date automatically, and can be turned off at any time without losing anything.

## The extensions

| Extension | What it adds | Read more |
|---|---|---|
| **Bee Shopping** | A complete shop: products with sizes and colours, cart, checkout, payments, shipping, orders, customers and coupons. | [Bee Shopping: products and orders](doc:shop) |
| **Bee Forms** | Forms you build by dragging fields (contact, quote, sign-up…), an inbox of entries, exports and email notifications. | [Bee Forms](doc:forms) |
| **Bee Bookings** | Online appointments: services, staff, opening hours, a booking calendar and email confirmations. | [Bee Bookings](doc:bookings) |

Managing extensions needs the **Analytics & connectors** permission (administrators have it).

## Install and turn on

1. Go to [Extensions → Add New](admin:extensions/new).
2. Find the extension and click **Install now**. It is installed and turned on in one step.
3. Its menu appears in the sidebar (for example **Shop**), and **Open …** takes you there.

## Turn off or uninstall

On [Extensions → Installed](admin:extensions):

- **Deactivate** turns an extension off. Its menu and its parts of the website are hidden, but **nothing is deleted**. **Activate** brings everything back as it was.
- **Uninstall** removes it. Beekiri then asks whether to delete its data too:
  - **Keep data** keeps everything (for example all products and orders), in case you install it again.
  - **Delete data** removes it for good.

If your theme needs an extension (a shop theme needs Bee Shopping, for example), it can't be turned off or uninstalled while that theme is active. Switch to another theme first.

## Updates

Each installed extension has an **Automatic updates** switch, on by default.

- **On:** new versions install themselves at night (between 1 and 5 o'clock, server time), one extension at a time. Each new version is prepared next to the working one; if your site doesn't start properly with it, or key pages fail, Beekiri goes back to the previous version on its own. It tries at most three nights in a row.
- **Off**, or if you don't want to wait: a notice under the extension says a new version is available, with **See what's new** and **update now**.

Click **View details** on an extension to read its description and the list of changes in each version (**Changelog**).

> **Note:** Sometimes a new extension version needs a newer Beekiri. The notice then says to update Beekiri first in [Settings → Beekiri Core](admin:settings). See [Updates, cache and speed](doc:updates).

Every update comes from the Beekiri team and is signed. Your site checks the signature and refuses anything else.

On a network of several sites, an extension updates automatically only if every site that uses it has automatic updates on.

## Filters and search

The Installed list can be filtered by **All**, **Active**, **Inactive** and **Update available**, and searched. **Check for updates** asks for new versions right away.
