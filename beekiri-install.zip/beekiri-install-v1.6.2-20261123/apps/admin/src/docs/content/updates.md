Beekiri gets regular updates with new features and fixes. This article explains how to install them safely, how to clear the cache, and how to keep your pages fast.

## Update Beekiri Core

1. Open [Settings → Beekiri Core](admin:settings). When an update exists, the menu shows **+1** next to Settings and a notice names the new version.
2. Click **What's new** to read about it, if you like.
3. Click **Update to …** and confirm with **Update Beekiri**.

Beekiri then works through these steps on its own, and you can leave the page while it does:

1. Downloading the update
2. Checking that it really comes from Beekiri (an update that isn't signed by the Beekiri team is refused, and nothing changes)
3. Backing up the current version
4. Installing the new files
5. Installing what the new version needs
6. Updating the database safely
7. Building
8. Restarting

At the end the page reloads on the new version, and the bell confirms "Beekiri was updated".

**If something goes wrong,** Beekiri puts the previous version back automatically, and the bell tells you the update couldn't be installed. Your site keeps running on the old version.

> **Note:** Only people with **Beekiri Core — check for updates** can update. On a network of several sites, only the owner can, because the update changes every site.

### What an update never touches

- Your content, settings, users and orders (the database is only extended, never emptied).
- Your uploaded photos and files, and backups.
- Your child theme and every theme you installed or made, including all section designs (layouts) Beekiri or you created.
- Beekiri's settings file on the server.

Only the Beekiri starter theme's own parent files are replaced.

> **Important:** Beekiri restarts itself after an update when it runs with `npm start` or `server.js` (also under pm2). If your server starts it another way, the update is installed but only goes live after whoever manages the server restarts Beekiri; the update screen tells you so.

## Extension updates

Extensions (Bee Shopping, Bee Forms, Bee Bookings) update **automatically at night**, one at a time, when **Automatic updates** is on for them (it is by default). If a new version doesn't start properly, Beekiri goes back to the previous one by itself. You can also update right away. See [Extensions](doc:extensions#updates).

## Clear the cache

Beekiri stores ready-made copies of your pages so visitors get them fast. After you change the theme's files, or when a change doesn't show on the website, click **Clear cache** in the top bar.

It gives your styles and scripts new addresses (so browsers download the new versions) and refreshes the stored copies of your pages. The message "Cache cleared. Visitors now see the latest version of your website." confirms it.

> **Tip:** Still seeing the old version in your own browser? Reload with **Ctrl + Shift + R** (**⌘ + Shift + R** on a Mac).

## Page speed scores

The four badges in the top bar are your site's **PageSpeed** (Lighthouse) scores, the same test Google uses:

| Badge | Measures |
|---|---|
| **P** | Page speed: how fast the page appears and responds. |
| **A** | Accessibility: whether everyone, including people using screen readers, can use it. |
| **B** | Best practices: secure and modern techniques. |
| **S** | SEO: whether search engines can read and list it. |

Green is 90 or more, amber 50 or more, red below 50. The test runs once per browser session; click the badges' refresh button to test again after a change.

## Keep your site fast

- **Photos:** keep **Convert all images to WebP on upload** on and the maximum size at 1920 px in [Settings → Media](admin:settings?tab=media). Beekiri then makes photos small enough on its own.
- **Alt text:** give every photo a short description. It helps the Accessibility and SEO scores. The ✦ helper in the Media library writes them for you.
- **Site code:** every script pasted into **Settings → General → SEO** loads on every page. Remove what you no longer use, and add `defer` or `async` to scripts.
- **Videos:** use a video element with a poster image, rather than a huge animated image.
- **Ask Beekiri:** "Check how my website looks on phones" makes Beekiri look at the real page on a phone screen and fix what it finds.
