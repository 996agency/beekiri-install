The [Media](admin:media) library holds every photo, video and file on your site. Upload once, then use it on any page, post or product.

## Upload

- Click **Upload** and choose files, or **drag files from your computer** anywhere onto the Media page.
- Files go into the folder that is open. Drop files on a folder to put them straight into it.

Beekiri prepares photos as they arrive: they are converted to WebP (much smaller, so pages load faster), scaled down to at most 1920 px, and hidden details such as the camera and the location are removed. Change this in [Settings → Media](admin:settings?tab=media).

> **Tip:** Upload photos at their full quality. Beekiri makes the smaller versions your website needs, so phones never download more than they show.

## Grid and list

Switch between **Grid** (large thumbnails) and **List** (a table with name, type, size and date). Sort by **Newest first**, **Oldest first**, **Name A–Z** or **Largest first**. The search looks in every folder and tells you where each file is.

## Folders

Folders work like the folders on your computer:

- **New folder** creates a folder in the one that is open.
- Click a folder to open it. The path at the top (**Media › Folder › Folder**) takes you back up, and so does your browser's Back button.
- **Move files:** drag a file onto a folder or onto a step of the path. Tick several files to move them together, or use **Move to folder**.
- **Delete folder** removes the folder and the folders inside it. The files are never deleted: they move up to the folder above.

Creating folders needs a Settings permission (administrators have it).

> **Tip:** Ask Beekiri: "Sort my photos into folders by what they show." It looks at the photos and does it for you, and you can undo it in Connector → Change history.

## File details and alt text

Click a file to see its details: **Filename**, **Type**, **Size**, **Dimensions**, **Folder** and when it was **Uploaded**, plus a link you can copy.

**Alt text** describes the photo for people who can't see it (and for search engines). Write what the photo shows, in one short sentence: "Two chairs in a sunny living room", not "IMG_2381".

- Click the ✦ button next to Alt text and Beekiri looks at the photo and suggests a description. Check it, then click **Save details**.
- Or ask in the chat: "Write alt text for every photo that has none."

## Delete files

Select files and choose **Delete files**, or open a file and click **Delete file**. A deleted file disappears from every page that used it, so check first.

## Using media on your site

- **Pages:** add an **Image**, **Gallery** or **Video** element and pick the file in **Props → Content**.
- **Posts:** set a **Featured image** and add photos in the text.
- **Products:** add the main photo and gallery in the product editor.
- **Photos from the internet:** give Beekiri the address of a photo (for example on Unsplash) and it imports the photo with alt text. Use only photos you are allowed to use.

## Several sites

On a network of sites, each site has its own media library.
