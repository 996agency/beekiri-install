This article covers what runs in the visitor's browser: layout and header scripts, the GSAP and Three.js libraries Beekiri ships, the dynamic content API that loops use, and the React template option.

## Layout scripts

A layout's `script.js` loads only on pages that use the layout, minified and with `defer`. Pages change without a full reload, so a script must:

- Start on load **and** on the `bk:navigate` event.
- Mark each section it has set up (for example with `data-bk-ready`) so it never sets one up twice.
- Leave content visible when the script hasn't run (yet). Never hide content in CSS to reveal it from the script.
- Clean up when its section is gone (on `bk:navigate`, when `root.isConnected` is false): revert animations, stop `requestAnimationFrame` loops, disconnect observers, dispose Three.js objects.

Scripts also run in the page editor, so keep them harmless there (see below).

## GSAP and Three.js

Beekiri ships GSAP with all its plugins and Three.js, served from your own server. A script asks for them with `Beekiri.use()`, which returns a promise. Each file loads once per visit, and pages that don't ask download nothing.

```js
Beekiri.use('gsap', 'ScrollTrigger').then(function (lib) {
  lib.gsap.from('.bk-item', { y: 40, autoAlpha: 0 });
});

Beekiri.use('three').then(function (lib) {
  var THREE = lib.THREE;
});
```

| Name | What you get |
|---|---|
| `gsap` | GSAP core, as `lib.gsap`. |
| `ScrollTrigger`, `ScrollSmoother`, `ScrollToPlugin`, `SplitText`, `Flip`, `Observer`, `Draggable`, `InertiaPlugin`, `MotionPathPlugin`, `DrawSVGPlugin`, `MorphSVGPlugin`, `TextPlugin`, `ScrambleTextPlugin`, `CustomEase` | That plugin, already registered. |
| `three` | The Three.js core module, as `lib.THREE` (no add-ons such as OrbitControls or GLTFLoader). |

`Beekiri.libs` holds the versions that ship (for example `{ gsap: "3.15.1", three: "0.187.0" }`). An unknown name rejects the promise.

### A scroll animation, the right way

```js
(function () {
  function init() {
    document.querySelectorAll('[data-layout="my-layout"]:not([data-bk-ready])').forEach(function (root) {
      root.setAttribute('data-bk-ready', '');
      if (!window.Beekiri || !Beekiri.use) return;
      Beekiri.use('gsap', 'ScrollTrigger').then(function (lib) {
        var mm = lib.gsap.matchMedia(root);
        mm.add('(prefers-reduced-motion: no-preference)', function () {
          lib.gsap.from(root.querySelectorAll('.bk-item'), {
            y: 40,
            autoAlpha: 0,
            duration: 0.8,
            stagger: 0.08,
            ease: 'power3.out',
            scrollTrigger: { trigger: root, start: 'top 80%' },
          });
        });
        window.addEventListener('bk:navigate', function gone() {
          if (root.isConnected) return;
          mm.revert();
          window.removeEventListener('bk:navigate', gone);
        });
      });
    });
  }
  init();
  window.addEventListener('bk:navigate', init);
})();
```

### Rules that keep pages fast and editable

- **Visible without the script.** Set start states with `gsap.from()`, `gsap.fromTo()` or `gsap.set()`, never with CSS. In the page editor, `Beekiri.use()` never answers, so nothing being edited moves or hides; Preview and the live site play the motion.
- **The first screen uses CSS.** A hero's entrance is a CSS `@keyframes` animation. A script starts later and would make the content flash.
- **Respect reduced motion.** Wrap motion in `gsap.matchMedia()` as above. A Three.js scene draws one still frame.
- **No CSS transition on what GSAP moves.** An element with `transition: transform` fights GSAP. Animate a wrapper, or put the hover effect on an inner element.
- **Three.js:** put the `<canvas>` in a box sized by CSS (`aspect-ratio` or a height), with a photo or background behind it as the fallback. Ask for `three` when the box comes near the screen, cap the pixel ratio at 2, and stop the loop while the box is off screen or the tab is hidden.

> **Note:** GSAP is used under its standard license, which allows commercial sites at no charge. It does not allow building a visual, no-code animation builder on top of GSAP. Three.js is MIT licensed.

## Dynamic content API

Loops in the page editor (see [Dynamic content](doc:dynamic-content)) get their items from a public, read-only endpoint. You can call it from your own scripts too (up to 300 requests a minute).

`POST /api/dynamic/items` with a JSON body `{ "loop": { … } }`:

| Key | Meaning |
|---|---|
| `source` | `products`, `posts` or `fields` (rows of a repeater). |
| `limit` | 1 to 60 items, 6 by default. |
| `sort` | Products: `menu_order`, `newest`, `title`, `price`, `price-desc`, `popularity`. Posts: `newest` (default), `oldest`, `title`. |
| `category`, `featured`, `ids` | Filters (up to 60 ids). |
| `layout`, `repeater`, `rows` | For `fields`: which layout's repeater, and its rows (up to 200). |

It returns `{ "items": [ … ] }`, each item a flat map of strings:

- **Products** (Bee Shopping on): `id`, `title`, `price`, `regularPrice`, `priceRange`, `shortDescription`, `category`, `categoryUrl`, `sku`, `stock`, `url`, `addToCart`, `addToCartId`, `image`, `imageAlt`, `image2`, `image3`, `details`.
- **Posts:** `id`, `title`, `excerpt`, `date`, `author`, `readingTime`, `url`, `image`, `imageAlt`.
- **Fields:** each row's values, formatted as in `get_bee_field()` and flattened (links give their address, true/false gives "Yes" or nothing).

```js
fetch('/api/dynamic/items', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ loop: { source: 'posts', limit: 3 } }),
})
  .then(function (r) { return r.json(); })
  .then(function (data) { console.log(data.items); });
```

## Layout endpoints

| Endpoint | Returns |
|---|---|
| `GET /api/layouts` | Every layout, with versioned `cssUrl` and `jsUrl`. |
| `GET /api/layouts/{slug}/css` | The layout's compiled, minified CSS. |
| `GET /api/layouts/{slug}/js` | The layout's minified script. |
| `GET` or `POST /api/layouts/{slug}/render` | The layout rendered to HTML with the given values. |
| `POST /api/layouts/{slug}/fields` | The formatted field values (what React templates receive). |

## React templates

A site set up with **React** templates renders `{slug}.tsx` for layouts and headers and footers, instead of PHP. This is chosen when the site is set up and can't be changed afterwards (Settings → Page editor shows which one a site uses).

- A layout's `{slug}.tsx` default-exports a component whose props are the formatted field values, the same values `get_bee_field()` returns.
- A header or footer `.tsx` receives the same data as the PHP template, plus `siteTitle`, `tagline`, `blogPublic` and `menu`. Header and footer `script.js` files are not used.
- Beekiri (the AI) never writes `.tsx` files; templates made from Backend Fields stay as generated until you change them.

See [Layouts and the PHP field API](doc:dev-layouts#react-templates) for an example.
