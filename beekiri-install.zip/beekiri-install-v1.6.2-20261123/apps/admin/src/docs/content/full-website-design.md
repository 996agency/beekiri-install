On the Beekiri starter theme, Beekiri can design your whole website for you: the colours, fonts, buttons, header and footer first, then the homepage. It starts by asking you four short questions. Your answers become your **design brief**, and every later request follows it, so new pages and sections always match.

## Start a full website design

1. Open the Beekiri chat (the **Balance** button in the top bar).
2. In the row of ideas under the chat, click **Full website design**.
3. Answer the four steps (below), then click **Start designing**.

Beekiri then works for a few minutes. You can keep working in the admin meanwhile, or leave the page: the work carries on. When it is done, look at your homepage, and use **Keep** or **Undo** under the reply. See [Working with Beekiri](doc:beekiri-ai#keep-or-undo).

> **Note:** The **Full website design** idea appears on the starter theme for people who may change the site's design (the **Appearance** permission). Store themes come with their own design; on those, ask Beekiri for specific changes instead.

## The four questions

| Step | What to tell Beekiri |
|---|---|
| **Your business** | What you do, for whom, and what visitors should do on the site (book, buy, call…). This one is required. |
| **Colours** | Up to four colours (main colour first, then an accent and two extras), or **Let Beekiri choose**. Also light, dark, or let Beekiri choose. |
| **Lettering and feel** | A style of lettering: **Modern & clean**, **Elegant & classic**, **Bold & strong** or **Friendly & soft**, or the name of a font you like. Then up to four words for the feel: Premium, Minimal, Warm, Playful, Bold, Calm, Natural, Trustworthy. |
| **Examples you like** | Up to three links to websites you like, pictures of designs, and anything else Beekiri should know. Nothing is copied from these: they show the direction. |

Your answers stay in the form if you close the chat before sending, until the page reloads.

## How the brief is used

- The brief is saved for your theme. Every later request to Beekiri in that theme follows it: a new page, a new section or a pop-up uses the same colours, fonts and style of buttons.
- While designing, Beekiri also writes down the choices it made (for example the exact palette, fonts and corner rounding), so later work matches what is already on the site.
- Fonts are downloaded into your theme, so your visitors never load them from another company's servers.

## Change the brief later

Open the chat; the first idea is now **Your design brief**. Click it, change your answers, and click **Save and restyle**. Beekiri then brings your website in line with the new brief.

You can also just ask in the chat: "Make the main colour dark green from now on" or "Use rounder buttons everywhere". Beekiri updates the brief, and later requests follow the change.

## Tips

- Be specific about your visitors: "families with young children looking for a weekend activity" helps more than "everyone".
- Links to two or three sites you like say more than many adjectives.
- If you already have a logo, upload it to the Media library first and mention it.
- Not happy with a part? Select it in the page editor and ask Beekiri to change just that. See [Working with Beekiri](doc:beekiri-ai#working-on-one-element-or-one-page).
