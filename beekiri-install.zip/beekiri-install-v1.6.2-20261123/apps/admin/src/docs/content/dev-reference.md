Everything a developer or server administrator needs to install and run Beekiri: requirements, setup, commands, the settings file and useful limits.

## Requirements

| Needed | Version | Notes |
|---|---|---|
| Node.js | 20 or newer | Required. |
| PostgreSQL | 14 or newer | Optional: the setup wizard can install a built-in database for you. |
| PHP (command line) | 8 or newer | For PHP theme templates and the shop's storefront. |
| Google Chrome | Any recent | Optional: for PageSpeed scores and for Beekiri looking at pages. |

## Install

1. Download `beekiri-install.zip` from the latest release and unzip it.
2. Run `npm install`, then `npm start`.
3. The terminal prints a setup link that carries a one-time setup key (also saved in `apps/api/.setup-token`). Open it.

The setup wizard then asks for:

1. **A language** for the wizard.
2. **The database:** **Set it up for me** downloads PostgreSQL once (about 100 MB) into `database/`. It only listens on this computer, on a free port between 54320 and 54399, with a random password, and `npm start` starts and stops it. Or **Use my own PostgreSQL** with its name, user, password, host and port. The settings are saved to `apps/api/.env` and Beekiri restarts.
3. **How the theme is built:** **PHP** (recommended) or **React**. This can't be changed later.
4. **Your site:** site title, your username, password and email, and whether search engines may list the site.

The first account is the **owner**.

## Running Beekiri

`npm start` is all you need. On every start it installs missing packages and builds what is missing, then serves the website, the admin and the API on one port. It restarts itself after setup and after updates.

- **On a server:** run it under pm2 (or your host's Node.js app pointing at `server.js`, which does the same as `npm start`), behind Nginx or Caddy with HTTPS.
- The admin is at `/admin` (unless changed in Settings → General). The API reference is at `/api/docs`, for signed-in administrators.

## npm scripts

| Command | What it does |
|---|---|
| `npm start` | Install what is missing, build, run, restart after updates; starts the built-in database if used. |
| `npm run dev` | Development mode with automatic reloads of the API. |
| `npm run build` | Build everything (admin, website, API). |
| `npm run typecheck` | Type-check every part. |
| `npm test` | Run the API tests. |
| `npm run db:migrate` | Apply database migrations (`db:migrate:status` lists them, `db:migrate:create` makes a new one). |
| `npm run security -- …` | The security rescue commands (below). |

## Security rescue commands

Run these in the Beekiri folder on the server when nobody can sign in:

| Command | What it does |
|---|---|
| `npm run security -- reset-2fa <email or username>` | Turns off two-step sign-in for that account and ends its sessions. |
| `npm run security -- unban <address>` | Lifts one Beekiri Shield ban. |
| `npm run security -- rescue` | Lifts every ban, and switches off "Refuse visits that skip Cloudflare" and the sign-in bot check on every site. Restart Beekiri or wait about a minute. |

## The settings file (apps/api/.env)

Without `DB_NAME`, Beekiri starts in setup mode. An invalid value stops the start, with every problem listed.

| Variable | Meaning |
|---|---|
| `PORT` | The one port for the website, admin and API. Chosen and saved by the wizard if not set. |
| `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT` | The database connection. |
| `DB_SSL` | `disable`, `require` or `verify-full` (with `DB_SSL_CA`). |
| `DB_SCHEMA`, `DB_POOL_MAX`, `DB_LOG` | Other database options. |
| `DB_BUILTIN` | Set by the wizard when the built-in database is used. |
| `NODE_ENV` | `production` on a live server. |
| `APP_URL` | The site's public address, for example `https://example.com`. Password-reset links are always built from it. |
| `CACHE_FLUSH_SECRET` | At least 32 characters (`openssl rand -hex 32`). Needed so saved mail passwords, bot check and Cloudflare keys and two-step sign-in secrets survive restarts. |
| `HOST` | The network interface to listen on; `127.0.0.1` behind a proxy on the same machine. |
| `TRUST_PROXY` | The address of a proxy on another machine, so visitors' real addresses are seen. |
| `CORS_ORIGINS` | Extra browser origins allowed to call the API. |
| `LOG_LEVEL` | How much the server logs. |
| `JSON_BODY_LIMIT` | Largest request body, `2mb` by default. |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM` | Server-wide default email, for sites without their own mail settings. Without either, emails are only written to the log. |
| `MEDIA_LOCAL_PATH` | Where uploaded files are stored. |
| `LIGHTHOUSE_URL` | The address the PageSpeed scores test. |
| `BEEKIRI_HUB_URL` | The Beekiri Hub address (996agency.com by default). |
| `BEEKIRI_HUB_DISABLED=1` | Turns off the daily check-in with the Hub. |
| `BEEKIRI_AUTO_UPDATE_HOURS` | The night window for automatic extension updates, for example `2-4` (default `1-5`). |
| `BEEKIRI_EXTENSION_UPDATES=0` | Turns off extension updates. |
| `BEEKIRI_THEMES_DIR` | Moves the themes folder. |

> **Warning:** Never share or commit `.env`. It holds the database password and the secret that protects saved keys.

## What updates keep

Core updates replace Beekiri's own files and the `beekiri` parent theme. They never touch: `.env` files, `uploads/`, `backups/`, the database and the built-in `database/` folder, child themes (`*-child`), the `layouts/`, `sites/` and `cpts/` folders of any theme, and every theme other than `beekiri`. The previous version is kept in `backups/core-v<version>-<time>/`, and files a new version no longer needs are moved there instead of being deleted.

## Useful limits

| What | Limit |
|---|---|
| Session | 24 hours without activity; 7 days with **Keep me signed in**. The admin signs out after 20 minutes without activity. |
| Shop REST API | 300 requests a minute per key. |
| Dynamic content API | 300 requests a minute; 60 items per request. |
| Template run time | 8 seconds for layouts, headers and footers; 10 seconds for blog templates. |
| Site code (SEO editors) | 50,000 characters per editor. |
| Beekiri chat | 8,000 characters per message, 6 pictures per message, one request at a time per person and three per site. |
| Menu | Three levels; 200 items per level. |
| Languages | 60 languages; 5,000 texts. |
| Backups | The newest 5 automatic backups are kept. |
