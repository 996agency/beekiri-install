Every page of your site (Home, About, Contact…) is built in the **page editor**: you see the page as visitors will, and you change it right where it appears.

## The Pages list

[Pages](admin:pages) lists all your pages with their status, theme and last update. Search by title or filter by status.

- **Add new** creates a page and opens it in the editor.
- **Edit** opens a page in the editor.
- **View** opens a published page on your website; **Preview** opens a private preview of a draft.
- **Trash** moves a page to the trash. In the trash you can restore it, or **Delete permanently**.

> **Tip:** Pages are drafts until you publish them. Drafts are never shown to visitors or search engines.

## The editor at a glance

| Part | Where | What it does |
|---|---|---|
| **Top bar** | Across the top | Back, the page's address, undo and redo, zoom, the save status, **Publish** and page settings. |
| **Canvas** | The middle | Your page, exactly as it will look. Click anything to select it. |
| **Explorer** | The panel at the side | Five tabs: **Layers**, **Add**, **Props**, **Page** and **SEO**. |

The explorer tabs:

- **Layers:** the structure of the page as a list. Click to select, drag to reorder, search by name.
- **Add:** every element and section you can add. See [Elements and theme layouts](doc:elements).
- **Props:** the content and style of the selected element.
- **Page:** categories, tags and other settings of this page.
- **SEO:** how the page appears in Google and when shared. See [Cookies, analytics and SEO](doc:analytics-seo).

## Add and arrange content

1. Open the **Add** tab.
2. Drag an element or a section onto the page, or click it to add it below what you selected.
3. Click the new element to select it, and change it in **Props**.

To move something, drag it on the canvas or in **Layers**, or use **Move up** and **Move down** in the bar above the selected element. That bar also has **Duplicate**, **Delete** and **Select parent**. Boxes (sections, containers and columns) show **Add element inside**.

**Type straight onto the page.** Click a heading or text to edit it in place. Highlight words and pick a colour in Props to colour only those words.

## Props: content and style

With an element selected, **Props** shows everything you can change about it, in this order:

| Section | What you set there |
|---|---|
| **Content** | The text, link, photo, video address and other content. |
| **Layout** | Width and height, how items inside a box line up (the 3 × 3 alignment picker), gaps, and columns for grids. |
| **Spacing** | Padding (space inside) and margin (space outside), for all sides or each side. |
| **Appearance** | Opacity and corner rounding. |
| **Typography** | Font, size (with separate sizes for phones and desktop), weight, line height and colour. |
| **Background** | A colour or a photo. |
| **Border** | Lines around the element. |
| **Effects** | Shadows and similar effects. |
| **Position** | Pinning an element or placing it over others. |
| **Responsive** | Hiding the element on some screen sizes. |
| **Advanced** | Extra settings, such as a class name. |

Switch on **Hover** at the top of a section to set how an element looks when the mouse is over it.

## Phones, tablets and desktop

Use the screen-size buttons to see the page as **Desktop**, **Tablet** or **Mobile**, or **Show all screen sizes side by side**. A change you make while viewing Tablet or Mobile applies only to that size and smaller; the desktop design stays as it is. This is how you make a page look right on every screen.

> **Tip:** Check every page on Mobile before publishing. Most visitors arrive on a phone.

## Preview, save and publish

The status in the top bar says **Saved**, **Unsaved changes** or **Saving…**. Your changes are stored when you save:

- **Publish** saves and puts the page on your website (or updates it, when it is already published).
- The arrow next to it opens **Save draft** (save without publishing), **Preview page** (a private preview in a new tab) and **Version history…**.
- **View page** opens the published page on your website.

The **Preview** mode button next to the screen sizes shows the page without editing tools, so you can click through it as a visitor would.

> **Important:** Close the editor only after saving. Unsaved changes are lost when you leave.

## Undo and history

**Undo** and **Redo** in the top bar step back and forward through your changes (up to 100 steps). Quick changes close together, such as typing a word, count as one step.

Each time you save, Beekiri keeps the previous version. Open **Version history…** to see them and **Restore revision** to go back to one. Your current version is saved as a revision first, so you can always switch back. The latest 25 versions are kept.

## Keyboard shortcuts

| Keys | Does |
|---|---|
| **Ctrl + Z** / **⌘ Z** | Undo |
| **Ctrl + Shift + Z** / **⌘ ⇧ Z** | Redo |
| **Ctrl + D** / **⌘ D** | Duplicate the selected element |
| **Delete** or **Backspace** | Delete the selected element |
| **Esc** | Select the parent of the selected element |
| **Ctrl + +** / **Ctrl + −** | Zoom in or out (**⌘** on a Mac) |
| **Ctrl + 0** / **⌘ 0** | Fit the page to the screen |
| **Shift + 0** | Zoom to 100% |

## Page settings

Click the page settings button at the top right to change the page's **Title**, **Excerpt** (a short summary for search results and link previews) and **Featured image** (used when the page is shared). You also see its status, when it was created and last edited, and by whom.

Change a page's web address with **Edit web address** next to the address in the top bar.

## The home page

Your home page is the page chosen in [Settings → Permalinks](admin:settings?tab=permalinks) with **Make home page**. Edit it like any other page from the Pages list. See [Site settings](doc:settings#permalinks-menu-and-home-page).

## Several people at once

When someone else has the same page open, their picture appears in the top bar, so you know not to work on the same page at the same time.

## Let Beekiri help

Select any element and click **Ask Beekiri to change this**: describe the change ("make this section more premium", "add a fourth card") and Beekiri changes just that element in the editor. See [Working with Beekiri](doc:beekiri-ai#working-on-one-element-or-one-page).
