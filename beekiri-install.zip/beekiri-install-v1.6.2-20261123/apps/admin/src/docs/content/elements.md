Pages are built from two kinds of building blocks, both in the editor's **Add** tab:

- **Elements:** single pieces such as a heading, a button or a photo, and ready-made blocks built from them. You style each one yourself in Props.
- **Theme layouts:** finished sections designed for your theme, such as a hero or a team grid. You fill in their fields; the design comes from the theme.

Search the Add tab ("Search elements, sections and layouts…") to find anything quickly. Drag an item onto the page, or click it to add it below the selected element.

## Structure

Boxes that hold and arrange other elements.

| Element | Use it for |
|---|---|
| **Section** | A full-width row of the page. Most pages are a stack of sections. |
| **Container** | Groups elements, for example a card's photo, title and text. |
| **2 columns**, **3 columns**, **4 columns** | Elements side by side. On phones, columns stack. |
| **Grid** | Rows of equal cells, for galleries of cards. |
| **Spacer** | Empty space between elements. |
| **Divider** | A thin line. |
| **Shop content** | The shop's products or cart, on shop pages (with Bee Shopping). |

Only boxes (sections, containers, columns and grid cells) can hold other elements. Use **Add element inside** on a selected box.

## Basic

| Element | Use it for |
|---|---|
| **Heading** | A title. Choose its **Level** (H1 to H6) in Props → Content: one H1 per page, for the main title. |
| **Text** | A paragraph. |
| **Button** | A link to click, for example "Book now". |
| **List** | Bullets or numbers. |
| **Icon** | One of 145 icons, with an optional link. |
| **Icon list** | Points with ticks or other icons. |
| **Quote** | Words and the name of who said them. |
| **Star rating** | 0 to 5 stars, halves included. |
| **Form** | A form made in Bee Forms (with Bee Forms on). See [Bee Forms](doc:forms). |
| **Booking** | The booking calendar (with Bee Bookings on). See [Bee Bookings](doc:bookings). |

## Media

| Element | Use it for |
|---|---|
| **Image** | One photo from the Media library. Give it alt text in Props. |
| **Video** | A YouTube or Vimeo link, or an MP4 file. |
| **Gallery** | A grid of photos. |
| **Slider** | Photos or cards that visitors swipe sideways. |
| **Map** | A Google map of an address. No key or account needed. |

## Interactive

| Element | Use it for |
|---|---|
| **Accordion** | Questions and answers that open and close, ideal for FAQs. |
| **Tabs** | Content that visitors switch between, one tab at a time. |

## Blocks

Ready-made pieces built from the elements above. Once added, you can change anything in them.

**Hero** (a big opening with title, text and buttons), **Features** (three icon boxes), **Icon box**, **Image box**, **Card**, **Call to action**, **Testimonial**, **Pricing**, **Team member**, **Stats** (big numbers), **Progress bar**, **Notice** and **Social icons**.

Blocks follow your theme's colours and fonts, so they fit your site from the start.

## Theme layouts

Under **Layouts** in the Add tab you find the sections your theme offers, and the ones you or Beekiri made for your site.

1. Add a layout to the page like any other element.
2. Select it. **Props → Content** shows its fields: texts, photos, links, lists of items.
3. Fill them in. The canvas shows the result straight away.

The design of a layout is the same everywhere it is used, so your site stays consistent; only its content differs per page. To change the design itself, ask Beekiri ("make the team section's photos round"), or a developer can edit the layout's files. See [Layouts and the PHP field API](doc:dev-layouts).

> **Tip:** Need a section your theme doesn't have, which you want to fill in again and again (for example a new team member every month)? Ask Beekiri to make it as a layout with fields: "Add a team section I can fill in from the admin."

## Repeating content automatically

A section, container or grid can repeat its first element for every product, blog post or list item, with live data: prices, photos and links fill themselves in. See [Dynamic content](doc:dynamic-content).

## Good practice

- **One idea per section.** A section about your services, one with reviews, one with a call to action.
- **Use headings in order.** Heading 1 for the page title, Heading 2 for each section, Heading 3 inside it. This helps visitors and search engines.
- **Write alt text for every photo,** describing what it shows. The ✦ helper in the Media library can write it for you.
- **Check on Mobile** before publishing.
