Beekiri is where you build and run your website: pages you design visually, a blog, your photos and files, and extensions for selling, taking bookings and collecting form entries. Beekiri, the assistant built into the admin, can do much of the work for you when you ask in plain words.

This documentation explains every part of it. Use the search box at the top, or the topics on the left.

## How your site is put together

| Part | What it is | Where you manage it |
|---|---|---|
| **Theme** | The look of the whole site: colours, fonts, the header and the footer. | [Appearance](admin:appearance) |
| **Pages** | The pages of your site (Home, About, Contact…), each built from sections. | [Pages](admin:pages) |
| **Sections and elements** | The building blocks of a page: ready-made sections from your theme, and single elements such as headings, text, buttons, photos and maps. | The page editor |
| **Posts** | Blog articles, listed on your blog. | [Posts](admin:posts) |
| **Media** | Your photos, videos and files. | [Media](admin:media) |
| **Your own content types** | Things your site lists, such as team members, projects or properties, with the fields you choose. | [Backend Fields](admin:fields) |
| **Extensions** | Extra features you turn on when you need them: a shop, forms, bookings. | [Extensions](admin:extensions) |
| **Beekiri** | The assistant that builds pages, writes content and does admin work for you. | The chat bar at the bottom of the admin |

## Your first day

Work through these once, in this order. Each step links to the screen and to the article that explains it.

1. **Name your site.** In [Settings → General](admin:settings?tab=general), set the site title, a short tagline and the favicon (the small icon in the browser tab). See [Site settings](doc:settings).
2. **Choose the look.** Pick a theme in [Appearance → Themes](admin:appearance), then a header and footer. See [Themes, headers, footers and menus](doc:appearance).
3. **Let Beekiri design it, if you like.** Ask Beekiri for a full website design: it asks about your colours, fonts and the sites you like, then designs your pages in one consistent look. See [Full website design and the design brief](doc:full-website-design).
4. **Build your pages.** Create your pages and fill them in the page editor. See [Pages and the page editor](doc:pages-and-editor).
5. **Set the menu and the home page.** In [Settings → Permalinks](admin:settings?tab=permalinks), arrange the menu and choose which page is your home page.
6. **Make sure emails arrive.** Order confirmations, form messages and password resets need a working email account. Set it up in [Settings → Email](admin:settings?tab=email). See [Site settings](doc:settings#email).
7. **Protect your sign-in.** Turn on two-step sign-in for your account in [Settings → Security](admin:settings?tab=security). See [Security](doc:security).
8. **Invite your team.** Add the people who work on the site and give each one a role. See [Users, roles and permissions](doc:users-permissions).
9. **Go live.** When the site is ready for visitors, let search engines find it (**Settings → Advanced → Search visibility**) and check the pages on a phone.

> **Tip:** Not sure where something is? Press **Ctrl + K** (or **⌘ K** on a Mac) anywhere in the admin and type what you are looking for, such as "shipping" or "favicon". See [Finding your way around](doc:admin-tour).

## Who can do what

Everyone who signs in has a role, and the role decides which parts of the admin they see. The **owner**, the person who set up the site, can do everything, including the settings that affect the whole site: email, security, migration and the sites in a network. Read more in [Users, roles and permissions](doc:users-permissions).

## Getting help

- Search this documentation with the box at the top of the page.
- Ask Beekiri in the chat bar: "How do I add a product with sizes?" It knows your site and can often do it for you.
- Something missing, or an idea? Use **Feedback** at the bottom of the menu. It goes straight to the Beekiri team.
