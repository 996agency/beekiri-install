The Shop REST API lets an app, another website, or a stock, accounting or shipping tool read and manage a Bee Shopping shop. Every address below starts with `https://your-site/api/shop/v1`.

## Keys

The shop owner creates keys in [Shop → Settings → REST API](admin:shop/settings?tab=api). A key looks like `bk_shop_…` (51 characters). It is shown once, when it is made; Beekiri keeps only a fingerprint of it, so a lost key cannot be shown again. Make a new one and revoke the old one.

Send the key with every request:

```
Authorization: Bearer bk_shop_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

Each key has one of three permissions:

| Permission | Can do |
|---|---|
| **Products only** (`catalog`) | Read published products that are not hidden from the catalogue, plus categories and tags. Safe to ship inside an app or a web page. |
| **Read** (`read`) | Every read: products in any status, orders, customers and coupons. |
| **Read and write** (`read_write`) | Everything above, plus creating and changing products, stock, orders and coupons. Keep it on a server. |

A key acts as the person who created it, with the rights that person has **at the moment of each request**. If they are removed from the site, or lose the right to manage the shop, their keys stop working. Writes follow the same rules as the admin: a key cannot do what its creator cannot do there, descriptions are cleaned as in the product editor, and stock changes and order emails behave exactly as when someone makes the change by hand.

> **Important:** Keys only work on the site they were made on. A network site, a staging copy and the live site each have their own keys, and copying a database between sites never carries keys along.

## Conventions

- **JSON** in and out. Send `Content-Type: application/json` with a body.
- **Money** is a whole number in the currency's smallest unit: with EUR, `1250` is €12.50. `GET /` returns `currency` and `currencyDecimals`; divide by 10 to the power of `currencyDecimals`.
- **Dates** are ISO 8601 in UTC, such as `2026-11-18T09:30:00.000Z`.
- **Lists** return `{ items, total, page, perPage, pages }`. Coupons, categories and tags return `{ items }`. Use `page` (from 1) and `perPage` (1 to 100; 20 by default for products, 25 for orders and customers).
- **Ids** are strings. Product ids are the same ids the admin shows in product links.
- **Weight** is in grams and **dimensions** in millimetres, as in the product editor.

## Errors and limits

Errors return a status code and `{ statusCode, message, error }`. Validation errors carry a list of messages.

| Status | Meaning |
|---|---|
| 400 | The body or query is not valid (see `message`). |
| 401 | No key, or the key is not valid (revoked, or made on another site). |
| 403 | The key's permission is too low, or its creator lacks the right. |
| 404 | Not found, or the shop extension is turned off. |
| 409 | Conflict, for example a coupon code that is already in use. |
| 429 | Too many requests: wait the number of seconds in `Retry-After`. |

**Limits:** 300 requests per minute per key. Thirty requests with a key that does not work within 15 minutes block that address for a while. The site's firewall also counts requests per address, so spread large syncs over time instead of sending everything at once.

**From a browser:** the API answers any origin (CORS `*`, no cookies). Only put a **Products only** key in front-end code.

## Shop

`GET /`, with any key:

```json
{
  "name": "Be Clothing",
  "url": "https://shop.example",
  "currency": "EUR",
  "currencyDecimals": 2,
  "apiVersion": "v1",
  "key": { "name": "Mobile app", "permission": "catalog" }
}
```

## Products

### List products

`GET /products`, with any key.

| Query | Meaning |
|---|---|
| `q` | Search in names and SKUs. |
| `sku` | The SKU of the product or of one of its variants (not case-sensitive). |
| `slug` | The exact slug. |
| `status` | `publish` (default), `draft`, `trash` or `any` (everything but the trash). Products only keys always get `publish`. |
| `category` | A category id or slug; sub-categories are included. |
| `tag` | A tag id or slug. |
| `type` | `simple` or `variable`. |
| `stock` | `instock`, `outofstock` or `onbackorder`. |
| `featured` | `true` or `false`. |
| `updatedAfter` | An ISO date: products whose content, price, stock or any variant changed since then. Use it to sync. |
| `sort` | `menu_order` (default, the shop's own order), `newest`, `updated`, `title`, `price`, `price-desc` or `popularity`. |
| `page`, `perPage` | Pagination. |

### One product

`GET /products/{id or slug}`, with any key.

```json
{
  "id": "cmw…", "name": "Oversized Tee", "slug": "oversized-tee", "status": "publish",
  "url": "https://shop.example/product/oversized-tee",
  "type": "variable", "sku": "TEE",
  "description": "<p>…</p>", "shortDescription": "<p>…</p>",
  "currency": "EUR", "price": 5200, "priceMax": 5600, "priceFormatted": "€52.00 – €56.00", "onSale": false,
  "regularPrice": null, "salePrice": null, "saleFrom": null, "saleTo": null,
  "inStock": true, "stockStatus": "instock", "manageStock": false, "stockQty": null,
  "soldIndividually": false, "virtual": false, "taxable": true, "featured": false,
  "weight": 200, "dimensions": { "length": null, "width": null, "height": null },
  "image": { "id": "…", "url": "https://shop.example/uploads/….webp", "alt": "", "width": 1200, "height": 1500 },
  "gallery": [],
  "categories": [{ "id": "…", "name": "T-shirts", "slug": "t-shirts" }],
  "tags": [],
  "attributes": [{ "name": "Size", "options": ["S", "M"], "visible": true, "variation": true }],
  "variants": [
    { "id": "…", "sku": "TEE-S", "attributes": { "Size": "S" }, "price": 5200, "onSale": false,
      "regularPrice": 5200, "salePrice": null, "saleFrom": null, "saleTo": null,
      "inStock": true, "stockStatus": "instock", "manageStock": true, "stockQty": 4,
      "weight": null, "image": null, "enabled": true, "menuOrder": 0 }
  ],
  "createdAt": "…", "updatedAt": "…", "publishedAt": "…"
}
```

- `price` is what a customer pays now, sale included. For a variable product it is the lowest variant price, and `priceMax` the highest.
- `inStock` says whether it can be bought right now; `stockStatus` is the stored setting.
- `updatedAt` is the latest change to the product, its price and stock, or any variant.
- With a **Read** or **Read and write** key, the product also has `catalogVisibility`, `lowStockThreshold`, `purchaseNote` (sent to buyers after payment) and `totalSales`, and `variants` include disabled ones (`enabled: false`).

### Create a product

`POST /products`, with a **Read and write** key whose creator may edit products. Send at least `name`. New products are drafts unless you send `"status": "publish"`.

```bash
curl -X POST https://shop.example/api/shop/v1/products \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{ "name": "Mug", "status": "publish", "sku": "MUG-1", "regularPrice": 1200,
        "manageStock": true, "stockQty": 25, "categoryIds": ["…"] }'
```

If any detail is refused (for example a sale price above the regular price), nothing is created.

### Change a product

`PATCH /products/{id}`, with a **Read and write** key. Send only what changes. Every field is optional:

`name`, `slug`, `status` (`draft` or `publish`), `description` (HTML), `shortDescription`, `type` (`simple` or `variable`), `sku`, `regularPrice`, `salePrice` (`null` removes it), `saleFrom`, `saleTo`, `manageStock`, `stockQty`, `stockStatus`, `lowStockThreshold`, `soldIndividually`, `virtual`, `taxable`, `featured`, `catalogVisibility` (`visible`, `catalog`, `search` or `hidden`), `weight`, `length`, `width`, `height`, `imageId` (`null` removes it), `galleryIds`, `attributes`, `variants`, `categoryIds`, `tagIds` and `purchaseNote`.

- `imageId` and `galleryIds` are ids from the site's Media library. Upload photos there first.
- `categoryIds` and `tagIds` replace the product's categories and tags. Get the ids from `GET /categories` and `GET /tags`.
- `variants` **replaces the whole list**: variants you leave out are deleted. Send `id` to keep an existing one. To change one variant, use the variant address below instead.
- A sale price is checked against the stored regular price when you send only one of them.

Setting the stock of a simple product:

```bash
curl -X PATCH https://shop.example/api/shop/v1/products/$ID \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{ "manageStock": true, "stockQty": 12 }'
```

### Change one variant

`PATCH /products/{id}/variants/{variantId}`, with a **Read and write** key. Only this variant is written, so stock the shop has just sold on the other variants is never overwritten. Fields: `sku`, `attributes`, `regularPrice`, `salePrice`, `saleFrom`, `saleTo`, `manageStock`, `stockQty`, `stockStatus`, `weight`, `imageId`, `enabled` and `menuOrder`. It returns the whole product.

### Delete a product

`DELETE /products/{id}`, with a **Read and write** key. The product moves to the trash: `{ "id": "…", "trashed": true, "deleted": false }`. Add `?force=true` to delete it for good.

## Categories and tags

With any key:

- `GET /categories` returns `{ items: [{ id, name, slug, parentId, description, count, url, image }] }`. `count` is the number of published products; use `parentId` to build the tree.
- `GET /tags` returns `{ items: [{ id, name, slug, description, count }] }`.

## Orders

Reading orders needs a **Read** key whose creator may manage orders.

### List orders

`GET /orders`, newest first.

| Query | Meaning |
|---|---|
| `status` | `pending`, `on-hold`, `processing`, `completed`, `cancelled`, `refunded`, `failed` or `all`. |
| `q` | Order number, email, name, address text or payment reference. |
| `customerId` | The orders of one customer. |
| `payment` | `stripe`, `bank_transfer` or `cod`. |
| `from`, `to` | Placed between these dates. |
| `page`, `perPage` | Pagination. |

### One order

`GET /orders/{id}`:

```json
{
  "id": "…", "number": 1001, "numberLabel": "#1001", "status": "processing", "statusLabel": "Processing",
  "currency": "EUR", "subtotal": 2400, "discountTotal": 0, "shippingTotal": 300, "taxTotal": 0,
  "total": 2700, "refundedTotal": 0, "couponCode": null,
  "customerId": "…", "customerName": "Ana Berisha", "email": "ana@example.com", "phone": "",
  "billing": { "firstName": "Ana", "lastName": "Berisha", "line1": "…", "city": "…", "postcode": "…", "country": "XK" },
  "shipping": { … }, "shipToDifferent": false,
  "shippingMethod": { … }, "paymentMethod": "cod", "paymentMethodTitle": "Cash on delivery",
  "paymentStatus": "unpaid", "transactionId": "",
  "customerNote": "", "customFields": [{ "key": "gift", "label": "Gift wrap", "value": "Yes" }],
  "fulfillment": { "status": "unfulfilled", "carrier": "", "trackingNumber": "", "trackingUrl": "" },
  "items": [{ "id": "…", "productId": "…", "variantId": null, "name": "Mug", "sku": "MUG-1",
              "qty": 2, "unitPrice": 1200, "subtotal": 2400, "total": 2400, "taxTotal": 0,
              "attributes": {}, "image": "https://…", "virtual": false }],
  "notes": [{ "id": "…", "note": "…", "isCustomerNote": false, "author": "System", "createdAt": "…" }],
  "placedAt": "…", "paidAt": null, "completedAt": null, "updatedAt": "…"
}
```

`items[].productId` is the id used by `/products` (`null` when the product has been deleted). `notes` appear only in a single order, not in the list.

### Change an order

`PATCH /orders/{id}`, with a **Read and write** key: `status` (with an optional `statusNote`, added to the customer's email), `email`, `phone`, `billing`, `shipping` and `customerNote`. A status change behaves as in the admin: stock is held or released, and the customer gets the status email.

### Fulfilment

`POST /orders/{id}/fulfillment`, with a **Read and write** key:

```json
{ "status": "shipped", "carrier": "DHL", "trackingNumber": "…", "trackingUrl": "https://…", "notify": true }
```

`status` is `unfulfilled`, `packed`, `shipped` or `delivered`; delivered also completes the order. Add `"courierId": "…"` (a courier connection from **Shop → Settings → Shipping → Couriers**) to have that courier follow the parcel and fill in its tracking link; `"courierId": ""` stops following it. Orders then carry `fulfillment.courier`, with the parcel's state, stage and the courier's latest events.

### Add a note

`POST /orders/{id}/notes`, with a **Read and write** key:

```json
{ "note": "Booked in accounting", "isCustomerNote": false }
```

A customer note is also emailed to the customer.

## Customers

With a **Read** key whose creator may manage orders: `GET /customers?q=&page=&perPage=` and `GET /customers/{id}`. Each customer has `id`, `email`, `firstName`, `lastName`, `name`, `phone`, `billing`, `shipping`, `ordersCount`, `totalSpent`, `lastOrderAt`, `hasAccount`, `emailVerified`, `lastLoginAt` and `createdAt`.

## Coupons

`GET /coupons` and `GET /coupons/{id}` with a **Read** key; `POST /coupons`, `PATCH /coupons/{id}` and `DELETE /coupons/{id}` with a **Read and write** key. The creator needs the right to manage orders.

```json
{
  "code": "SUMMER10", "type": "percent", "amount": 1000, "description": "",
  "minSpend": null, "maxSpend": null, "usageLimit": null, "usageLimitPerEmail": null,
  "expiresAt": null, "productIds": [], "excludeProductIds": [], "categoryIds": [],
  "freeShipping": false, "active": true
}
```

`type` is `percent` (the amount times 100, so 10% is `1000`), `fixed_cart` or `fixed_product` (the amount in cents). Codes are stored in capitals.

## Not in this version

Placing orders, refunds, uploading photos, and creating categories or tags are done in the admin for now. Webhooks (the shop calling your system when something changes) are not available yet: ask `GET /products?updatedAfter=…` and `GET /orders?from=…` at regular times instead.

> **Tip:** For a nightly stock sync, store the time of your last run and ask for `GET /products?updatedAfter=<that time>&status=any`, page by page. Then change stock one variant at a time with the variant address, so sales made in between are never overwritten.
