Your blog is where you publish articles: news, tips, stories, case studies. Posts are listed on your blog page and each one gets its own page.

## Write a post

1. Go to [Posts](admin:posts) and click **Add new**. The post opens in the page editor.
2. Give it a title and write it, using the same elements as on pages: headings, text, photos, quotes, videos, buttons. See [Pages and the page editor](doc:pages-and-editor).
3. In the editor's **Page** tab, choose its **categories** and **tags**. Start typing to find one, or create a new one by typing its name. These changes save automatically.
4. Open the page settings (top right) to add a **Featured image** and an **Excerpt**.
5. Click **Publish**, or **Save draft** to finish later.

> **Tip:** Ask Beekiri: "Write a blog post with a featured photo about how to choose a sofa, for people furnishing their first flat." It writes the post as a draft, with topics and a cover photo, for you to check and publish.

## The parts of a post

| Part | Where it shows |
|---|---|
| **Title** | At the top of the post, in the blog list and in search results. |
| **Featured image** | On the post's card in the blog list, at the top of the post, and when the post is shared on social media. |
| **Excerpt** | The short summary on the post's card and in search results. Without one, the start of the text is used. |
| **Categories** | The main topics, for grouping posts. |
| **Tags** | Smaller keywords. |
| **Author** | The person who wrote it, shown on the post. |

Each post also shows its date and an estimated reading time.

## Where the blog appears

- The blog list is at `/blog`, with the newest posts first and pages of posts.
- Each post has its own address: `/blog/your-post-title`. Change it with **Edit web address** in the editor.
- Add the blog to your menu in [Settings → Permalinks](admin:settings?tab=permalinks) (**Posts** or a **Custom link** to `/blog`).
- To show your latest posts on another page (for example the homepage), use a grid that repeats **Journal posts**. See [Dynamic content](doc:dynamic-content).

The look of the blog list and the post pages comes from your theme. Ask Beekiri to change it: "Make the blog list show two posts per row with large photos."

## Drafts, previews and changes

- Drafts are never shown to visitors. Click **Preview** in the Posts list (or **Preview page** in the editor) for a private preview.
- After publishing, you can keep editing; click **Publish** again to update the live post.
- **Version history…** in the editor's publish menu brings back an earlier version.

## Who can write

| Role | Can |
|---|---|
| **Contributor** | Write their own posts; an editor publishes them. |
| **Author** | Write, publish and delete their own posts. |
| **Editor** and **Administrator** | Work on everyone's posts. |

See [Users, roles and permissions](doc:users-permissions).

## Search engines

Fill in the editor's **SEO** tab for each post: a focus keyword, a title and a description for search results, and a share image. The ✦ helper there fills them in for you. See [Cookies, analytics and SEO](doc:analytics-seo).
