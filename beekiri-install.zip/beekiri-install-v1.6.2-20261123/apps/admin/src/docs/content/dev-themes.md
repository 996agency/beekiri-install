A theme decides how the whole website looks: the header and footer, the site-wide styles, the blog templates, the shop templates and the section designs (layouts). This article describes how a theme is built.

## Where themes live

Themes are folders in `apps/web/themes/<slug>/`. Beekiri ships two:

| Theme | Role |
|---|---|
| `beekiri` | The parent theme. Beekiri updates replace it, so don't edit it. |
| `beekiri-child` | The default active theme. Put every change for your site here; updates never touch it. |

A theme can have a parent (up to 5 levels). For every file, Beekiri looks in the child first, then in its parents. To change a parent's file, copy it to the same path in the child and edit the copy.

Themes bought in the Beekiri store get their own child automatically (`<slug>-child`). That child holds your site's own layouts and Beekiri's changes, so a theme update never removes them. The child can't be activated on its own.

## Folder structure

```
themes/my-theme/
  theme.json            name, version, parent, headers and footers…
  screenshot.svg        picture in Appearance → Themes
  header/               header templates, site-wide styles, fonts, script
  footer/               footer templates and styles
  layouts/{slug}/       section designs (see "Layouts and the PHP field API")
  blog/                 archive.php and single.php for the blog
  shop/                 storefront templates (Bee Shopping)
  cpts/{type}/          single.php and meta.json for your own content types
  content/              demo content and the editor's section library
```

## theme.json

```json
{
  "name": "My Theme",
  "slug": "my-theme",
  "version": "1.0.0",
  "description": "A calm theme for clinics.",
  "author": "Your studio",
  "tags": ["health", "booking"],
  "parent": "beekiri",
  "requires": "1.6.0",
  "requiresExtensions": ["bee-bookings"],
  "screenshot": "screenshot.svg",
  "headers": [
    { "slug": "classic", "title": "Classic", "path": "header/classic", "description": "Logo left, menu right", "default": true }
  ],
  "footers": [
    { "slug": "simple", "title": "Simple", "path": "footer/simple", "default": true }
  ]
}
```

| Field | Meaning |
|---|---|
| `name` | Required. Shown in Appearance → Themes. |
| `version` | Defaults to `1.0.0`. |
| `parent` | The theme this one builds on. |
| `requires` | The oldest Beekiri version it works with. Activation is refused on an older Beekiri. |
| `requiresExtensions` | Extensions that must be active first, for example `["shopping"]`. |
| `headers`, `footers` | The header and footer designs the owner can choose in Appearance. The one with `default: true` is used until another is chosen. |
| `licence` | `"beekiri-hub"` marks a store theme that needs a licence. |

## Headers and footers

Each header or footer design is a folder (its `path`) with:

| File | Purpose |
|---|---|
| `{slug}.php` (or `header.php`) | The template, on sites with PHP templates. |
| `{slug}.tsx` | The template, on sites with React templates. |
| `{slug}.meta.json` | Title, description, fields (`name`, `type`, `defaultValue`) and `preloadFonts`. |
| `styles.scss` (or `styles.css`) | Styles, compiled and minified automatically. |
| `script.js` | Behaviour (menus, sticky header…), loaded with `defer`. |
| `*.woff2` | Font files used by the styles. |

The header's styles are inlined in the page's `<head>`, so they apply before anything is drawn.

> **Important:** The website does **not** load a theme's `style.css`. Put site-wide styles (colours, fonts, buttons, spacing) in the active header's `styles.scss`.

The template gets these values through `get_bee_field()` (or as React props): `site_title`, `site_tagline`, `home_url`, `logo_url` (the favicon), `menu` (items with `id`, `label`, `url`, `children`), `languages`, `search_pages`, `shop` (whether the shop is on, and the shop, cart, checkout and account addresses), `year`, and the default values of its own fields. Use `bee_language_switcher()` and `bee_search_modal()` to print the language switcher and the search dialog.

```php
<?php $menu = get_bee_field('menu'); ?>
<header class="site-header">
  <a class="site-header__logo" href="<?php echo esc_url(get_bee_field('home_url')); ?>">
    <?php echo esc_html(get_bee_field('site_title')); ?>
  </a>
  <nav aria-label="Main">
    <ul>
      <?php foreach ((array) $menu as $item) : ?>
        <li><a href="<?php echo esc_url($item['url']); ?>"><?php echo esc_html($item['label']); ?></a></li>
      <?php endforeach; ?>
    </ul>
  </nav>
  <button type="button" data-bk-search-open aria-label="Search">Search</button>
  <?php echo bee_search_modal(['placeholder' => 'Search the site…']); ?>
</header>
```

## Design tokens

The website's base stylesheet defines these custom properties. Override them in the header's `styles.scss` to restyle everything that uses them:

| Token | Default |
|---|---|
| `--bk-bg` / `--bk-fg` | `#ffffff` / `#202734` |
| `--bk-muted` | `#50575e` |
| `--bk-link` / `--bk-link-hover` | `#A9531A` / `#8A4214` |
| `--bk-accent` / `--bk-accent-hover` / `--bk-accent-fg` | `#F2842F` / `#F4954A` / `#202734` |
| `--bk-btn-primary` / `--bk-btn-primary-hover` / `--bk-btn-primary-fg` | `#202734` / `#2f3849` / `#ffffff` |
| `--bk-surface` / `--bk-border` | `#f6f7f7` / `#c3c4c7` |
| `--bk-focus` | `#F2842F` |
| `--bk-font` | The system font stack |
| `--bk-radius` | `6px` |

The `<html>` element carries `data-theme="<active theme slug>"`.

## Blog templates

- `blog/archive.php`: the blog list at `/blog` (and `/blog?page=2`…).
- `blog/single.php`: one post at `/blog/{slug}`.

Without them, the website's default blog pages are used. The `beekiri` parent ships `single.php` only.

`blog/blog.meta.json` sets `perPage` (1–48, default 9), the archive's `title` (default "Journal") and `intro`, and fields with default values. Both templates receive `site_title`, `blog_url`, `fields` and `newsletter_html`.

- **Archive** also receives `posts` and `pagination` (`page`, `pages`, `total`, `prev_url`, `next_url`, `links`).
- **Single** receives `post`, `older`, `newer`, `related` (the 3 latest) and `body_marker`.

Each post has `title`, `path`, `excerpt`, `date`, `date_iso`, `reading_minutes`, `author`, `categories` and `image` (`src`, `srcset`, `alt`, `width`, `height`, or `null`).

> **Important:** `single.php` must print `get_bee_field('body_marker')` exactly where the post's content goes. The website puts the post body there.

## Your own content types

For a content type made in Backend Fields (for example `team`), `cpts/team/single.php` with `meta.json` is the template for one entry. Beekiri creates these in the writable (child) theme.

## Demo content

`content/manifest.json` describes the pages, menu, images, products, forms and posts a theme installs, with placeholders such as `{{image:hero}}`, `{{page:about}}`, `{{product:mug}}`, `{{price:mug}}` and `{{form:contact}}` that are replaced with the real ids and addresses. `content/sections.json` fills the page editor's section library.

## Store themes

Themes sold in the Beekiri store are installed from Appearance → Templates. Each licence covers one local, one staging and one production site (or a whole network). When a theme updates, the previous version is kept in `themes/.backups/` (the three newest), and if the new version can't be read, the old one is restored.
