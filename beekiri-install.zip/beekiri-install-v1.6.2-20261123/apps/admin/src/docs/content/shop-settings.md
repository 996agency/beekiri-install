[Shop → Settings](admin:shop/settings) holds everything about how your shop sells: your address and currency, payments, shipping and couriers, taxes, the checkout form, customer accounts, emails, importing from WooCommerce and connecting other systems. You need the **Shop settings** permission.

## Before you sell

Do these once, before your first order:

1. **General:** your store's name and address (it decides the default country at checkout), the countries you sell to, and your **currency** with its number format.
2. **Payments:** turn on at least one payment method.
3. **Shipping:** add at least one shipping zone with a method, or customers can't check out.
4. **Emails:** check who receives the "new order" email.
5. Make sure email works at all: [Settings → Email](admin:settings?tab=email).
6. Place a test order yourself.

## General and Products

- **General:** store name and address, where you sell, currency and number format.
- **Products:** how the shop lists products, such as the default sorting (custom order, popularity, latest, price or name) and whether out-of-stock products are hidden.

## Payments

| Method | How it works |
|---|---|
| **Cash on delivery** | On by default. The order is created as **Processing**, and marked paid when you complete it. |
| **Direct bank transfer** | Add your bank details; they appear on the thank-you page and in the email. The order waits **On hold** until you move it to **Processing** when the money arrives. |
| **Stripe** (card payments) | Paste your publishable key and secret key from your Stripe dashboard. Start in **Test** mode. |

**Setting up Stripe for live payments:**

1. In your Stripe dashboard, copy the live publishable key and secret key into Beekiri.
2. In Stripe, create a webhook pointing at the address shown on the **Payments** tab, and subscribe it to the events listed there.
3. Paste the webhook's signing secret into Beekiri and save.

The webhook makes sure a payment is confirmed even if the customer closes the browser right after paying.

> **Warning:** Use test keys while you build, and switch to live keys only when the shop is ready. Copying your site to a test site never takes the payment keys along, so a test site can't charge real cards.

## Shipping

### Shipping zones

A zone is a group of countries or regions with its own shipping methods.

1. On the **Shipping** tab, add a zone, for example "North Macedonia" or "Europe". Leave the regions empty for a zone that covers **everywhere else**.
2. Add one or more methods: **Flat rate**, **Free shipping** (optionally from a minimum order amount) or **Local pickup**.
3. For each method, choose who delivers it (**Delivered by**), if you use couriers.
4. Click **Save changes**.

If a customer's country matches no zone and there is no "everywhere else" zone, they can't check out.

### Couriers

Under **Shipping → Couriers** you connect the companies that deliver your orders. A connected courier can receive your orders (Beekiri creates the shipment with the address, items, weight and any cash to collect, and keeps the tracking number and label), and keep everyone up to date: the order moves to **Shipped** when the courier has the parcel and to **Delivered** when it arrives, and the customer gets the emails.

- **DHL:** create a free key at developer.dhl.com (an app with the **Shipment Tracking – Unified** API), then **Add courier → DHL**, paste the key and **Connect courier**. Create labels in your DHL account as usual; on the order, choose DHL as the carrier and enter the tracking number. Beekiri follows the parcel from there.
- **Any other courier with an online system:** ask them for their API documentation, the API address and your key. Then **Add courier → Other courier** and fill in what they gave you. A courier without an API can still be added with just its **Tracking page**, so customers get the right tracking link.
- **Send automatically** sends orders delivered by that courier on their own: cash on delivery orders at once, card and bank transfer orders once paid.
- **Check a parcel** with a real tracking number tests the settings.

Problems the courier reports (a failed delivery, a returned parcel) appear in the bell. A courier marked **Needs attention** shows its last error at the top of its settings.

## Tax

Turn taxes on, say whether your prices already include tax, and add rates by country. Products are taxed by default; switch a product to **No tax** in its **Tax, visibility and notes** section.

## Checkout

The checkout form itself. Every field (name, company, phone, address lines…) can be renamed, reordered, made optional or hidden. You can also **add your own fields**: a delivery time, a gift message, a "how did you hear about us" question, or a consent checkbox. Answers are stored with the order and shown in the order emails and on the order page.

Also here: the links to your terms and privacy pages, and the text on the thank-you page.

## Accounts

Turn customer accounts on or off, allow customers to register, offer "Create an account" at checkout, or require an account to buy.

## Emails

The emails your shop sends, each with its own subject:

| Email | Goes to |
|---|---|
| New order | The shop owner (or the addresses you enter) |
| Order received, Order on hold, Processing order | The customer |
| Order shipped, Order delivered, Completed order | The customer |
| Cancelled order, Refunded order | The customer |
| Customer note | The customer |

## Advanced

The number your order numbers start from (1000 by default, shown as `#1000`), how long stock is held for an unpaid card order, and whether uninstalling Bee Shopping also removes its data.

## Import from WooCommerce

Moving from WooCommerce? Bring your shop over on the **Import** tab; nothing needs to be installed on the old site.

1. In WordPress, export **Tools → Export → All content** (the `.xml` file). Optionally also the products CSV (**Products → Export**) and a ZIP of `wp-content/uploads` for the photos. Without the ZIP, photos are downloaded from the old site, which must then be online.
2. Upload the files and click **Check the files**. Beekiri shows what they contain and anything it will leave out.
3. **Prepare preview:** photos go into the Media library (folder "WooCommerce import"), and categories, tags and products are created **as drafts**.
4. **Preview the shop:** see the imported products in your real shop, in your own browser only. Visitors don't see them.
5. **Publish:** products go live, then coupons, customers and orders are added, **without sending any emails** and without changing stock. Or **Discard** to remove everything the import created.

You can import again later (for example just before switching over), and only what is new comes in.

> **Note:** A WordPress export doesn't say which products were in each order, so imported orders show the customer, addresses, totals and payment, but not the items. Customer passwords can't be moved; customers who register with the same email get their past orders. Reviews, subscriptions and add-on data are not imported.

## REST API

The **REST API** tab creates keys that let an app, another website or a stock, accounting or shipping tool work with your shop:

- **Products only:** reads your published products, categories and tags. For an app or website that shows your products.
- **Read:** also reads orders, customers and coupons. Nothing can be changed.
- **Read and write:** also changes products, stock, orders and coupons.

Give each key a description. The key is shown once: copy it and give it to your developer, with the details under **For your developer**. A key works with the access of the person who created it. **Revoke** stops it at once. Developers: see [Shop REST API](doc:dev-shop-api).

## If something doesn't work

- **"We cannot ship to that address":** no shipping zone matches the customer's country. Add the country to a zone, or add an "everywhere else" zone.
- **Card payments stay "Pending payment":** add the Stripe webhook (see Payments above).
- **Stripe keys disappear after a restart:** the server is missing a setting that protects saved keys; the Payments tab shows a warning. Ask whoever manages your server to add `CACHE_FLUSH_SECRET` (see [Commands, settings files and limits](doc:dev-reference)), then enter the keys again.
- **Customers don't see their orders in their account:** they haven't confirmed their email yet. Their account page shows a "Send it again" link.
- **A parcel stays "Packed" although the courier has it:** the courier used a status Beekiri doesn't know yet. The courier's settings list such statuses under **Courier statuses**, with a button to add a rule.
- **No emails:** set up [Settings → Email](admin:settings?tab=email).
