Everyone who works on your site signs in with their own account. Each account has a **role**, such as Editor or Shop manager, and the role decides what that person sees and may do.

## The roles

| Role | Made for | Can do by default |
|---|---|---|
| **Administrator** | People who run the site with you | Everything, except the owner-only settings. |
| **Editor** | Content managers | All pages and posts (also other people's), media, categories, forms, form entries and bookings. |
| **Author** | Writers | Write, publish and delete their own posts; upload media. |
| **Contributor** | Guest writers | Write their own posts; an editor publishes them. |
| **Subscriber** | People who only need to sign in | Sign in and see their dashboard. |
| **Shop manager** | People who run the shop | Products, orders, customers, coupons, shop settings and reports; media and categories. |

The **owner** is the person who set up the site. The owner can do everything and is the only one who can change Security, Email, Migration and Sites, and the permissions of roles.

You can change what each role may do, and make your own roles: see [Change what a role can do](#change-what-a-role-can-do).

## Add a person

1. Go to [Users → All Users](admin:users) and click **Add user**.
2. Enter a **Username** (3 to 60 characters: letters, numbers, `.`, `-` and `_`), their **Email**, and if you like a **Display name** and **Job description**.
3. Choose their **Role**.
4. A strong password is filled in for you. Copy it to give to them, or type your own (at least 8 characters; weak passwords are refused).
5. Click **Add user**.

> **Tip:** **Custom fields** on a person's page let you note anything extra, such as a phone number or department (up to 50 fields).

## Change a person or your own profile

Click a name in [All Users](admin:users) (or **Edit profile** on your own row). The page shows a summary card at the top, then **Profile**, **Custom fields**, **Role** and **Password**. Click **Save changes** when you are done.

- To change your own email or password, enter your **Current password** too.
- **Generate a strong password** makes a 16-character password.
- Changing a password signs that account out everywhere.
- You can't change your own role.

## Remove a person

In [All Users](admin:users), click **Delete** on their row and confirm. They lose access straight away. Their pages and posts stay on the site. You can't delete yourself or the owner.

On a network of sites, removing someone only takes away their access to this site; their account stays for the other sites they use.

## Two-step sign-in

Two-step sign-in asks for a 6-digit code from an app on your phone after your password, so a stolen password alone is not enough.

**Turn it on for your own account:**

1. Open your profile (your name in [All Users](admin:users)).
2. In **Two-step sign-in**, click **Set up two-step sign-in** and enter your password.
3. Scan the QR code with an authenticator app (such as Google Authenticator, Microsoft Authenticator or 1Password), or type the key into it.
4. Enter the 6-digit code from the app and click **Turn on**.
5. Save the 10 **recovery codes** somewhere safe, then click **I saved them**. Each code works once if you lose your phone.

When you sign in, enter the code from the app. Tick **Don't ask again on this browser for 30 days** on your own computer. Lost your phone? Click **Lost your phone? Use a recovery code**.

The owner can require two-step sign-in for administrators or for everyone in [Settings → Security](admin:settings?tab=security&section=two-factor). See [Security](doc:security#two-step-sign-in).

## Change what a role can do

The owner manages roles in [Users → User Permissions](admin:users/permissions).

1. On the **Roles** tab, select a role.
2. Switch permissions on or off. They are grouped by area (Pages, Posts, Media, Shopping, Settings…); **Turn all on** and **Turn all off** work per group, and **Search permissions…** finds one quickly.
3. Click **Save role**. Everyone with that role gets the change at once.

**Make a new role:** click **New role**, give it a **Name**, choose which role's permissions it **starts with** (or **No permissions**), and click **Create role**. Then adjust it as above.

**Rename or delete a role:** change the **Name** field, or delete it. If people have the role, you choose which role they move to.

> **Note:** **Administrator** is fixed: it always has every permission. To limit one administrator, change that person on the **People** tab instead.

## Give one person more or fewer rights

On the **People** tab of [User Permissions](admin:users/permissions), choose a person. Their permissions come from their role; switch single permissions on or off for this person only. They are marked **Added** or **Removed**. **Reset to role defaults** removes the exceptions; **Save permissions** saves them.

On a network of sites, the **Sites** card on this tab sets the person's role on each site, or **No access**. See [Several sites in one Beekiri](doc:multisite#people-on-several-sites).

## Rules that keep your site safe

- Nobody can give out more rights than they have: you can't give someone a role with permissions you don't have yourself.
- Only administrators can manage administrator accounts, and only the owner can change the owner.
- The last administrator can't be removed or demoted.
- People are signed out after 20 minutes without activity in the admin. Two minutes before, **Are you still there?** lets them stay signed in. **Keep me signed in** on the sign-in page keeps them signed in on that browser for up to 7 days.

## The permissions

| Permission | Lets someone |
|---|---|
| **Sign in** | Sign in to the admin (everyone has it). |
| **Customize dashboard** | Arrange their own dashboard. |
| Pages: **Edit pages**, **Edit others' pages**, **Publish pages**, **Delete pages** | Work on pages. |
| **Raw HTML and scripts** | Save scripts and embeds in pages, posts and fields. Without it, scripts are removed on save. Give it only to people you fully trust. |
| Posts: **Edit**, **Edit others'**, **Publish**, **Delete** | Work on blog posts. |
| **Upload media** | Upload and manage photos and files. |
| **Manage categories**, **Moderate comments** | Manage topics and comments. |
| **Backend Fields** | Create field groups, content types and taxonomies. |
| **Appearance** | Change the theme, header, footer and site sections. |
| **Analytics & connectors** | Analytics, SEO, Connector (Beekiri's balance), Extensions and every Settings tab that isn't owner-only. |
| **Use the Beekiri agent** | Use the Beekiri chat. Each message is paid from the site's balance. |
| **Beekiri Core — check for updates** | Check for and install Beekiri updates. |
| **Settings — …** | Open one Settings tab (General, Reading, Writing, Page editor, Advanced, Permalinks, Media, Documentation), and **Settings — Cache** for the **Clear cache** button. |
| **List users**, **Create users**, **Edit users**, **Delete users** | Manage people. |
| Shopping: **Shop settings**, **Products**, **Orders & customers**, **Shop reports** | Run the shop (when Bee Shopping is on). |
| Bee Forms: **Forms**, **Entries** | Build forms; read entries. |
| Bee Bookings: **Bookings** | Manage services, staff and appointments. |
