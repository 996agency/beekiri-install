Beekiri is the assistant built into your admin. Tell it what you want in plain words, such as "add a testimonials section to the homepage" or "export last month's form entries", and it does the work on your site: it builds pages and sections, writes posts and product descriptions, sorts your photos and finds what you are looking for.

## Before you start

Three things need to be in place:

1. **Beekiri is turned on.** An administrator turns it on in [Connector](admin:connector) with **Turn on**. It is off on a new site.
2. **There is money in the balance.** Every request is paid from your site's prepaid balance. See [Balance, costs and change history](doc:beekiri-account).
3. **You may use it.** The owner always can. Other people need the permission **Use the Beekiri agent**; administrators have it by default. See [Users, roles and permissions](doc:users-permissions).

There are no keys, models or other technical settings to choose. Beekiri runs on Claude through 996Agency, and your site is connected automatically.

## Opening the chat

- **From any admin page:** click the **Balance** button in the top bar (it shows your balance, for example "Balance $18.40"). The chat opens as a bar at the bottom of the screen.
- **From the page editor:** select an element and click **Ask Beekiri to change this** in the toolbar above it, or the Beekiri button at the top of the Properties panel. The chat then works on that element only.

Type your request and press **Enter** (**Shift + Enter** starts a new line). While Beekiri works, the send button becomes **Stop**. **Esc** or the **−** button tucks the chat away. Beekiri keeps working when you minimize the chat, open another page or even reload: come back to any admin page and you see it continue. Only **Stop** ends a request early.

## What Beekiri can do

| Area | Examples |
|---|---|
| Pages | "Create an About us page with our story, the team and a contact button." New pages are saved as drafts. |
| Sections | "Add a pricing section with three plans side by side." Beekiri builds new sections in your theme's look and can add fields so you can edit them later. |
| Look and feel | "Make the buttons rounder and the header darker." "Use the Playfair Display font for headings." |
| Blog | "Write a blog post with a featured photo about caring for leather chairs." |
| Shop | "Write descriptions for the products that have none." "Add a product called Linen Shirt in S, M and L for 49.90." |
| Photos | "Use this photo on the About page: (a link to the photo, for example on Unsplash)." "Sort my photos into folders by what they show." "Write alt text for the photos that have none." |
| Your own content | "Add a Team section that I can fill in from the admin." Beekiri creates the content type and the fields. |
| Pop-ups and bars | "Show a bar at the top of every page about free shipping over €50." |
| Form entries | "How many contact form messages came from Instagram this month?" "Export last month's entries as a spreadsheet." |
| Orders | "Which orders from this week haven't shipped yet?" "Export October's orders." |
| Bookings | "Show me this week's appointments, day by day." "Set up bookings for a 30-minute consultation, Monday to Friday, 9 to 5." |

Spreadsheet exports appear as a **Download** link in the reply. Only you can download them, and they are removed after 24 hours.

Beekiri can only do what you may do yourself: if your role can't edit products, Beekiri can't edit products for you either.

## What Beekiri does not do

To keep your site safe, Beekiri never:

- Changes users, roles, passwords, payment settings, email settings or security settings.
- Changes or refunds orders, or moves appointments.
- Deletes anything for good. It removes elements only when you ask for it, and things it removes go to the trash.
- Shows passwords, keys or other secrets. Anything that looks like one is hidden as `[hidden]`.
- Changes Beekiri itself, the admin, theme licences or billing.

For those, use the admin screens. They are covered in this documentation.

## Show Beekiri what you mean

Pictures and examples get you better results than long descriptions:

- **Screenshot:** click the screenshot button in the chat and drag over any part of the screen. In the page editor, dragging over the page also selects that element.
- **Pictures of designs:** click the paperclip, paste a picture, or drop a file into the chat. Long pictures (a whole page) are cut into parts so Beekiri can read them. Up to 6 parts per message.
- **A link to a site you like:** paste the address and say what you like about it. Beekiri reads that site's structure and styles to understand the effect, then builds its own version for you. It never copies the other site's text, photos or logos. Some sites block this; Beekiri then asks you for a screenshot instead.

## Ideas to get started

When the chat is empty, a row of ideas appears under it, with the ones for the screen you are on first (for example, blog ideas on Posts). Click one to fill in the request, finish it if needed, and send it. On the starter theme, the first idea is **Full website design**; see [Full website design and the design brief](doc:full-website-design).

## Working on one element or one page

In the page editor, the chat follows what you select:

- With an element selected, the chat shows **Editing … only**, and Beekiri changes only that element.
- With nothing selected (or the page itself), it works on the whole page you are editing.
- Click the **×** on that label to give Beekiri the whole site again.

In this mode, the change appears straight away in the editor as one step you can undo. Beekiri's cursor shows you each part it changed. Nothing is published until you save or update the page yourself. Beekiri may also create a brand-new section design here, but it never changes a section design that other pages use.

## Keep or undo

On a page visitors can already see, new sections Beekiri adds stay **hidden from visitors** until you keep them. Changes to existing text and images show at once.

Under Beekiri's reply, a **Waiting for you** card shows:

- **Preview**: opens a private preview with the changes, only for you.
- **Keep**: makes the new sections visible.
- **Undo**: puts everything from that request back as it was.

You can also keep or revert any change later in [Connector → Change history](admin:connector?tab=changes). See [Balance, costs and change history](doc:beekiri-account#change-history).

> **Note:** Only the owner and people with **Analytics & connectors** see the Keep and Undo card. Others can still ask Beekiri for changes; an administrator reviews them.

## Chats

Your chats are saved, and only you see them. Use the chat list to go back to an earlier one, or the **New chat** button to start fresh. If the last change in a chat was kept or undone, opening the chat starts a new conversation.

If a long request is interrupted (for example by a dropped connection), what Beekiri finished is kept. Send "continue" and it carries on from there. Very big jobs may stop after many steps; send "keep going" to continue.

## Quick helpers (✦)

Small buttons with a ✦ sparkle do one job in one click. Each click is paid from the balance, like a short message:

- **Alt text:** in the Media library, next to a photo's alt text, Beekiri writes a short description of the photo. Check it, then save.
- **SEO:** in the page editor's SEO panel, Beekiri fills in the focus keyword, meta title and description, and suggests fixes (for example a better slug or a share image). Click **Fix** or **Fix all**, then save the page.

## Tips for good results

- Say what the result should do, not only how it should look: "a section that makes people book a free call" works better than "a blue box".
- Give the real content when you have it: prices, opening hours, names.
- One request at a time: Beekiri works on one request per person at a time.
- Use the design brief so every page follows the same look. See [Full website design and the design brief](doc:full-website-design).
- Say "thanks" or "ok" freely: short replies like these are answered for free.
