import { describe, expect, it } from 'vitest';
import { parseConfig } from '../src/config/schema';
import { isLoopbackOrigin } from '../src/utils/loopback';

const base = { DB_NAME: 'beekiri_test' };
const production = {
  ...base,
  NODE_ENV: 'production',
  APP_URL: 'https://www.example.com/',
  CACHE_FLUSH_SECRET: 'f'.repeat(64),
  SMTP_HOST: 'smtp.example.com',
  SMTP_FROM: 'noreply@example.com',
};

function parse(env: Record<string, string | undefined>) {
  const result = parseConfig(env);
  if (!result.ok) throw new Error(result.problems.join('\n'));
  return result;
}

describe('parseConfig', () => {
  it('starts in setup mode when no database is configured yet', () => {
    const { config } = parse({});
    expect(config.databaseConfigured).toBe(false);
    expect(config.server.port).toBeUndefined();
  });

  it('runs in development with nothing but the database name, and no built-in addresses', () => {
    const { config, warnings } = parse(base);
    expect(config.databaseConfigured).toBe(true);
    expect(config.urls).toEqual({ app: undefined });
    expect(config.server).toMatchObject({ host: undefined, port: undefined });
    expect(config.db).toMatchObject({ host: undefined, port: undefined, name: 'beekiri_test' });
    expect(config.corsOrigins).toEqual([]);
    expect(config.allowLoopbackOrigins).toBe(true);
    expect(config.auth.cookieSecure).toBe(false);
    expect(warnings).toEqual([]);
  });

  it('treats any origin on this machine, on any port, as local', () => {
    for (const origin of ['http://localhost:5173', 'http://127.0.0.1:3000', 'http://[::1]:8080']) {
      expect(isLoopbackOrigin(origin)).toBe(true);
    }
    for (const origin of [
      'https://example.com',
      'http://192.168.1.20:3000',
      'http://localhost.evil.com',
    ]) {
      expect(isLoopbackOrigin(origin)).toBe(false);
    }
  });

  it('starts in production without APP_URL, but warns about it', () => {
    const { warnings } = parse({ ...production, APP_URL: undefined });
    expect(warnings).toEqual([expect.stringMatching(/^APP_URL is not set/)]);
  });

  it('derives secure cookies and a strict origin list from the production addresses', () => {
    const { config, warnings } = parse({
      ...production,
      CORS_ORIGINS: 'https://preview.example.com/',
    });
    expect(config.urls.app).toBe('https://www.example.com');
    expect(config.auth.cookieSecure).toBe(true);
    expect(config.corsOrigins).toEqual([
      'https://www.example.com',
      'https://preview.example.com',
    ]);
    expect(config.allowLoopbackOrigins).toBe(false);
    expect(warnings).toEqual([]);
  });

  it('warns about settings that work but are risky on a live site', () => {
    const { warnings } = parse({
      ...production,
      APP_URL: 'http://www.example.com',
      DB_HOST: 'db.example.com',
      SMTP_HOST: '',
      CACHE_FLUSH_SECRET: undefined,
    });
    expect(warnings).toEqual([
      expect.stringMatching(/^APP_URL uses http:\/\//),
      expect.stringMatching(/DB_SSL=disable/),
      expect.stringMatching(/^SMTP_HOST is not set/),
      expect.stringMatching(/^CACHE_FLUSH_SECRET is not set/),
    ]);
  });

  it('treats empty values as unset and still reads a legacy DATABASE_URL', () => {
    const { config } = parse({
      DB_NAME: '',
      DATABASE_URL:
        'postgresql://site:p%40ss@db.example.com:6543/client_site?schema=cms&sslmode=require',
      SESSION_SECRET: 's'.repeat(40),
    });
    expect(config.db).toMatchObject({
      host: 'db.example.com',
      port: 6543,
      name: 'client_site',
      user: 'site',
      password: 'p@ss',
      schema: 'cms',
      ssl: 'require',
    });
    // Older sites named the cache flush secret SESSION_SECRET.
    expect(config.core.cacheFlushSecret).toBe('s'.repeat(40));
  });

  it('reports every invalid value at once, by name', () => {
    const result = parseConfig({
      APP_URL: 'www.example.com',
      PORT: 'eighty',
      CORS_ORIGINS: 'example.com',
      SMTP_HOST: 'smtp.example.com',
    });
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.problems).toEqual(
      expect.arrayContaining([
        expect.stringMatching(/^APP_URL: must be a full http/),
        expect.stringMatching(/^PORT: /),
        expect.stringMatching(/^CORS_ORIGINS: "example.com"/),
        expect.stringMatching(/^SMTP_FROM: required when SMTP_HOST is set/),
      ]),
    );
  });
});
