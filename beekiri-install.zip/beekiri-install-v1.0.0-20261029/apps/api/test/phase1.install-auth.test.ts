import type { Express } from 'express';
import request from 'supertest';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

/**
 * Runs against a throwaway database only: every table is emptied before the suite.
 * Example: createdb beekiri_test && TEST_DB_NAME=beekiri_test pnpm test
 * (DB_HOST / DB_USER / DB_PASSWORD come from apps/api/.env or the shell, as for the API.)
 */
const TEST_DB_NAME = process.env.TEST_DB_NAME;
const ORIGIN = 'http://localhost';

const OWNER = {
  language: 'en_US',
  siteTitle: 'Test Site',
  username: 'owner',
  password: 'Str0ng!Passw0rd',
  email: 'owner@example.com',
  blogPublic: false,
  frontendRuntime: 'php',
};

describe.skipIf(!TEST_DB_NAME)('Phase 1 install + auth', () => {
  let app: Express;
  let models: typeof import('../src/models');
  let db: typeof import('../src/db/sequelize');
  let clearRateLimits: () => void;

  beforeAll(async () => {
    Object.assign(process.env, {
      NODE_ENV: 'test',
      DB_NAME: TEST_DB_NAME,
      APP_URL: ORIGIN,
      MEDIA_LOCAL_PATH: '/tmp/beekiri-test-uploads',
    });

    const { runMigrations } = await import('../src/db/migrator');
    db = await import('../src/db/sequelize');
    models = await import('../src/models');
    ({ clearRateLimits } = await import('../src/utils/rate-limit'));
    const { createApp } = await import('../src/app');

    await runMigrations();
    const tables = Object.values(db.sequelize.models)
      .map((m) => m.getTableName() as string)
      .filter((t) => t !== 'SequelizeMeta')
      .map((t) => `"${t}"`)
      .join(', ');
    await db.sequelize.query(`TRUNCATE ${tables} CASCADE`);
    await models.InstallationState.create({ id: 1, installed: false });
    clearRateLimits();
    app = createApp();
  });

  afterAll(async () => {
    await db?.closeDatabase();
  });

  it('reports not installed then installs exactly one owner', async () => {
    const status = await request(app).get('/api/install/status');
    expect(status.status).toBe(200);
    expect(status.body.installed).toBe(false);
    expect(status.body.databaseOk).toBe(true);

    const install = await request(app).post('/api/install').send(OWNER);
    expect(install.status).toBe(201);
    expect(install.body.ok).toBe(true);

    const again = await request(app)
      .post('/api/install')
      .send({ ...OWNER, siteTitle: 'Other', username: 'owner2', email: 'owner2@example.com' });
    expect(again.status).toBeGreaterThanOrEqual(400);

    const concurrent = await Promise.all(
      [1, 2, 3].map((n) =>
        request(app)
          .post('/api/install')
          .send({
            ...OWNER,
            siteTitle: `Race ${n}`,
            username: `race${n}`,
            email: `race${n}@example.com`,
          }),
      ),
    );
    expect(concurrent.every((r) => r.status >= 400)).toBe(true);

    expect(await models.User.count({ where: { isOwner: true } })).toBe(1);
  });

  it('logs in, reaches the dashboard, and logout invalidates the session', async () => {
    clearRateLimits();
    const login = await request(app)
      .post('/api/auth/login')
      .set('Origin', ORIGIN)
      .send({ login: 'owner', password: OWNER.password, remember: false });
    expect(login.status).toBe(201);
    const setCookie = ([] as string[]).concat(login.headers['set-cookie'] ?? []);
    expect(setCookie[0]).toMatch(/HttpOnly/);
    const sessionPair = setCookie[0]!.split(';')[0]!;
    const csrfToken = login.body.csrfToken as string;

    const dash = await request(app).get('/api/site/dashboard').set('Cookie', sessionPair);
    expect(dash.status).toBe(200);
    expect(dash.body.title).toBe('Test Site');

    expect((await request(app).get('/api/site/dashboard')).status).toBe(401);

    const noCsrf = await request(app)
      .post('/api/auth/logout')
      .set('Cookie', sessionPair)
      .set('Origin', ORIGIN);
    expect(noCsrf.status).toBe(403);

    const foreign = await request(app)
      .post('/api/auth/logout')
      .set('Cookie', sessionPair)
      .set('Origin', 'https://evil.example')
      .set('X-CSRF-Token', csrfToken);
    expect(foreign.status).toBe(403);

    const logout = await request(app)
      .post('/api/auth/logout')
      .set('Cookie', sessionPair)
      .set('Origin', ORIGIN)
      .set('X-CSRF-Token', csrfToken);
    expect(logout.status).toBe(201);

    expect((await request(app).get('/api/site/dashboard').set('Cookie', sessionPair)).status).toBe(
      401,
    );
  });

  it('rejects a bad login with a generic error', async () => {
    clearRateLimits();
    const bad = await request(app)
      .post('/api/auth/login')
      .send({ login: 'owner', password: 'wrong-password-here' });
    expect(bad.status).toBe(401);
    expect(String(bad.body.message)).toMatch(/Invalid username or password/i);
  });

  it('rejects unknown body properties and unknown routes', async () => {
    const extra = await request(app)
      .post('/api/auth/login')
      .send({ login: 'a', password: 'b', admin: true });
    expect(extra.status).toBe(400);
    expect(extra.body.message).toContain('property admin should not exist');

    const missing = await request(app).get('/api/nope');
    expect(missing.status).toBe(404);
    expect(missing.body.message).toBe('Cannot GET /api/nope');
  });

  it('serves an OpenAPI document generated from the routers', async () => {
    const res = await request(app).get('/api/docs/openapi.json');
    expect(res.status).toBe(200);
    expect(res.body.openapi).toBe('3.0.3');

    const login = res.body.paths['/api/auth/login'].post;
    expect(login.requestBody.content['application/json'].schema.properties).toHaveProperty('login');
    expect(login.security).toEqual([]);

    const updatePage = res.body.paths['/api/pages/{id}'].patch;
    expect(updatePage.security).toEqual([{ session: [], csrf: [] }]);
    expect(updatePage.description).toContain('edit_pages');
    expect(updatePage.parameters).toContainEqual(
      expect.objectContaining({ name: 'id', in: 'path' }),
    );

    const upload = res.body.paths['/api/media/upload'].post;
    expect(upload.requestBody.content).toHaveProperty('multipart/form-data');

    const ui = await request(app).get('/api/docs/');
    expect(ui.status).toBe(200);
    expect(ui.text).toContain('swagger-ui');
  });
});
