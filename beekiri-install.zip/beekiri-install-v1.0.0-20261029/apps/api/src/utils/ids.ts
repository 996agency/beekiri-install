import { randomBytes } from 'crypto';

let counter = randomBytes(2).readUInt16BE(0);

const pad = (value: string, size: number) => value.padStart(size, '0').slice(-size);

/**
 * Collision-resistant, sortable-ish ids in the same 25-char `c…` shape Prisma's cuid()
 * produced, so new rows look exactly like existing ones.
 */
export function createId(): string {
  counter = (counter + 1) % 1_679_616; // 36^4
  const time = pad(Date.now().toString(36), 8);
  const count = pad(counter.toString(36), 4);
  const random = Array.from(randomBytes(12))
    .map((b) => (b % 36).toString(36))
    .join('');
  return `c${time}${count}${random}`;
}
