import { Op } from 'sequelize';

/** Escape LIKE wildcards so user input is matched literally. */
export function escapeLike(value: string): string {
  return value.replace(/[\\%_]/g, (c) => `\\${c}`);
}

/** Case-insensitive "contains" filter (parameterized). */
export function iContains(value: string) {
  return { [Op.iLike]: `%${escapeLike(value)}%` };
}
