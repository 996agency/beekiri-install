import { isIP } from 'net';

/**
 * True for names that always mean "this machine": `localhost` (and `*.localhost`),
 * the 127.0.0.0/8 range and ::1. A rule, not a list of configured addresses.
 */
export function isLoopbackHost(hostname: string): boolean {
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (host === 'localhost' || host.endsWith('.localhost')) return true;
  if (isIP(host) === 4) return host.startsWith('127.');
  return host === '::1';
}

/** A browser origin served from this machine, on any port. */
export function isLoopbackOrigin(origin: string): boolean {
  try {
    const url = new URL(origin);
    return ['http:', 'https:'].includes(url.protocol) && isLoopbackHost(url.hostname);
  } catch {
    return false;
  }
}
