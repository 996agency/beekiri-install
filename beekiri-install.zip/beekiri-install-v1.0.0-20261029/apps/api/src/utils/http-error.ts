import { STATUS_CODES } from 'http';
import {
  ConnectionError,
  ForeignKeyConstraintError,
  UniqueConstraintError,
  ValidationError,
} from 'sequelize';

export type HttpErrorBody = string | Record<string, unknown>;

/**
 * Throw from services/controllers; the error middleware turns it into JSON.
 * String bodies become `{ statusCode, message, error }`; object bodies
 * (e.g. `{ message, code }`) are sent as-is so the admin can branch on `code`.
 */
export class HttpError extends Error {
  readonly status: number;
  readonly body: HttpErrorBody;

  constructor(status: number, body: HttpErrorBody, options?: { cause?: unknown }) {
    super(typeof body === 'string' ? body : String(body.message ?? STATUS_CODES[status]), options);
    this.name = 'HttpError';
    this.status = status;
    this.body = body;
  }

  toJSON(): Record<string, unknown> {
    if (typeof this.body === 'object') return this.body;
    return {
      message: this.body,
      error: STATUS_CODES[this.status] ?? 'Error',
      statusCode: this.status,
    };
  }
}

const make =
  (status: number, fallback: string) =>
  (body: HttpErrorBody = fallback) =>
    new HttpError(status, body);

export const BadRequest = make(400, 'Bad Request');
export const Unauthorized = make(401, 'Unauthorized');
export const Forbidden = make(403, 'Forbidden');
export const NotFound = make(404, 'Not Found');
export const Conflict = make(409, 'Conflict');
export const PayloadTooLarge = make(413, 'Payload Too Large');
export const UnprocessableEntity = make(422, 'Unprocessable Entity');
export const TooManyRequests = make(429, 'Too Many Requests');
export const InternalServerError = make(500, 'Internal server error');
export const BadGateway = make(502, 'Bad Gateway');
export const ServiceUnavailable = make(503, 'Service Unavailable');

/**
 * Normalize anything thrown into an HttpError. Errors that already carry an HTTP
 * status pass through untouched, database errors become the matching 4xx/503, and
 * everything else becomes a 500 with `fallbackMessage` (the original is kept as
 * `cause` so it is logged, never sent to the client).
 */
export function toHttpError(error: unknown, fallbackMessage = 'Internal server error'): HttpError {
  if (error instanceof HttpError) return error;
  // UniqueConstraintError extends ValidationError, so it must be checked first.
  if (error instanceof UniqueConstraintError) {
    return new HttpError(409, 'That value is already in use.', { cause: error });
  }
  if (error instanceof ForeignKeyConstraintError) {
    return new HttpError(409, 'This item is still linked to other content.', { cause: error });
  }
  if (error instanceof ValidationError)
    return new HttpError(400, 'Invalid data.', { cause: error });
  if (error instanceof ConnectionError) {
    return new HttpError(503, 'Database is unavailable. Please try again in a moment.', {
      cause: error,
    });
  }
  return new HttpError(500, fallbackMessage, { cause: error });
}
