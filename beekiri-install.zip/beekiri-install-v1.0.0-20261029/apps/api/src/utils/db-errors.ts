import { UniqueConstraintError } from 'sequelize';

/**
 * Name of the violated unique index (e.g. `User_siteId_email_key`) plus its columns,
 * or null when the error is not a unique violation.
 */
export function uniqueViolation(e: unknown): string | null {
  if (!(e instanceof UniqueConstraintError)) return null;
  const parent = e.parent as { constraint?: string } | undefined;
  const fields = Object.keys(e.fields ?? {}).join(',');
  return [parent?.constraint ?? '', fields].filter(Boolean).join(' ') || 'unique';
}
