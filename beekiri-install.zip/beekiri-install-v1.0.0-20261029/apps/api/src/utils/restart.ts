import { existsSync, utimesSync } from 'fs';
import { join } from 'path';
import { createLogger } from './logger';

const log = createLogger('server');

/** Exit code that tells scripts/start.mjs to start the server again. */
export const RESTART_EXIT_CODE = 75;

/**
 * Restart the server so it reloads apps/api/.env (after the setup wizard) or new code
 * (after a core update). Under `npm start` the launcher restarts it; under `npm run dev`
 * the file watcher does, once an imported file changes.
 */
export function requestRestart(reason: string): boolean {
  if (process.env.BEEKIRI_SUPERVISED === '1') {
    log.info(`Restarting: ${reason}`);
    // Let the current response finish first.
    setTimeout(() => process.exit(RESTART_EXIT_CODE), 300).unref();
    return true;
  }

  const watchedSource = join(__dirname, '..', 'core-build.ts');
  if (existsSync(watchedSource)) {
    log.info(`Reloading: ${reason}`);
    const now = new Date();
    utimesSync(watchedSource, now, now);
    return true;
  }

  log.warn(`Restart Beekiri to finish: ${reason}`);
  return false;
}
