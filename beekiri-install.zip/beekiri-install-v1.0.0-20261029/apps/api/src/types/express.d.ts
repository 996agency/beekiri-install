import type { AuthSessionContext } from './auth';

declare global {
  namespace Express {
    interface Request {
      /** Set by `requireAuth` once the session cookie, origin and CSRF token check out. */
      auth?: AuthSessionContext;
    }
  }
}

export {};
