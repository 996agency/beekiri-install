import type { NextFunction, Request, Response } from 'express';
import { selfOrigin } from '../middleware/security';
import { installService } from '../services/install.service';
import { setupService } from '../services/setup.service';

export const installController = {
  async status(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await installService.getStatus());
    } catch (error) {
      next(error);
    }
  },

  /** Setup wizard: save the database settings (only before one is configured). */
  async database(req: Request, res: Response, next: NextFunction) {
    try {
      res
        .status(201)
        .json(await setupService.configureDatabase(req.body, { siteUrl: selfOrigin(req) }));
    } catch (error) {
      next(error);
    }
  },

  async install(req: Request, res: Response, next: NextFunction) {
    try {
      const result = await installService.install(req.body, {
        ip: req.ip,
        userAgent: req.get('user-agent'),
      });
      res.status(201).json(result);
    } catch (error) {
      next(error);
    }
  },
};
