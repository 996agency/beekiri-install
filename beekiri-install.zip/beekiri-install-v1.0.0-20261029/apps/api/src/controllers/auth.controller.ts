import type { CookieOptions, NextFunction, Request, Response } from 'express';
import { config } from '../config/env';
import { sessionToken } from '../middleware/authenticate';
import { isAllowedOrigin, selfOrigin } from '../middleware/security';
import { authService, SESSION_COOKIE } from '../services/auth.service';

/** Host-only, HttpOnly session cookie; Secure whenever the admin runs on https. */
function cookieOptions(): CookieOptions {
  return { path: '/', httpOnly: true, sameSite: 'lax', secure: config.auth.cookieSecure };
}

export const authController = {
  async login(req: Request, res: Response, next: NextFunction) {
    try {
      const result = await authService.login(req.body, {
        ip: req.ip,
        userAgent: req.get('user-agent'),
      });
      res.cookie(SESSION_COOKIE, result.cookieValue, {
        ...cookieOptions(),
        maxAge: result.maxAgeSeconds * 1000,
      });
      res.status(201).json({ user: result.user, csrfToken: result.csrfToken });
    } catch (error) {
      next(error);
    }
  },

  async logout(req: Request, res: Response, next: NextFunction) {
    try {
      await authService.logout(sessionToken(req), { ip: req.ip });
      res.clearCookie(SESSION_COOKIE, cookieOptions());
      res.status(201).json({ ok: true });
    } catch (error) {
      next(error);
    }
  },

  async me(req: Request, res: Response, next: NextFunction) {
    try {
      const session = await authService.resolveSession(sessionToken(req));
      if (!session) {
        res.json({ authenticated: false });
        return;
      }
      res.json({ authenticated: true, user: session.user, csrfToken: session.csrfToken });
    } catch (error) {
      next(error);
    }
  },

  async csrf(req: Request, res: Response, next: NextFunction) {
    try {
      const session = await authService.resolveSession(sessionToken(req));
      res.json({ csrfToken: session?.csrfToken ?? null });
    } catch (error) {
      next(error);
    }
  },

  async lostPassword(req: Request, res: Response, next: NextFunction) {
    try {
      // Reset links are only ever built for our own sites, never an arbitrary Origin header.
      const header = req.get('origin');
      const origin =
        header && (header === selfOrigin(req) || isAllowedOrigin(header)) ? header : undefined;
      res
        .status(201)
        .json(await authService.requestPasswordReset(req.body, { ip: req.ip, origin }));
    } catch (error) {
      next(error);
    }
  },

  async resetPassword(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await authService.resetPassword(req.body));
    } catch (error) {
      next(error);
    }
  },
};
