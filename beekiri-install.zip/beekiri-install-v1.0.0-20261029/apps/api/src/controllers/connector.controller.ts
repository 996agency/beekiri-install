import type { NextFunction, Request, Response } from 'express';
import { authUser } from '../middleware/authenticate';
import { beeQueenAgentService } from '../services/beequeen-agent.service';
import { connectorService } from '../services/connector.service';

export const connectorController = {
  async get(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await connectorService.get());
    } catch (error) {
      next(error);
    }
  },

  async getProvider(req: Request, res: Response, next: NextFunction) {
    try {
      const providerId = String((req.params as { providerId?: string }).providerId || '');
      res.json(await connectorService.getProvider(providerId));
    } catch (error) {
      next(error);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await connectorService.update(req.body));
    } catch (error) {
      next(error);
    }
  },

  async runAgent(req: Request, res: Response, next: NextFunction) {
    try {
      const prompt = String((req.body as { prompt?: string }).prompt || '');
      res.json(await beeQueenAgentService.run(authUser(req), prompt));
    } catch (error) {
      next(error);
    }
  },
};
