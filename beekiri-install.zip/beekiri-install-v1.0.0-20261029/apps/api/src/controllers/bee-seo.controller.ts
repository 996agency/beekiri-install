import type { NextFunction, Request, Response } from 'express';
import { beeSeoBacklinksService } from '../services/bee-seo-backlinks.service';
import { beeSeoKeywordsService } from '../services/bee-seo-keywords.service';
import { beeSeoOverviewService } from '../services/bee-seo-overview.service';
import { beeSeoService } from '../services/bee-seo.service';

export const beeSeoController = {
  async report(req: Request, res: Response, next: NextFunction) {
    try {
      const q = req.query as { path?: string; refresh?: boolean };
      res.json(await beeSeoService.report({ path: q.path ?? '/', refresh: Boolean(q.refresh) }));
    } catch (error) {
      next(error);
    }
  },

  async audit(req: Request, res: Response, next: NextFunction) {
    try {
      const path = typeof req.body?.path === 'string' ? req.body.path : '/';
      res.json(await beeSeoService.audit(path));
    } catch (error) {
      next(error);
    }
  },

  async keywords(req: Request, res: Response, next: NextFunction) {
    try {
      const body = req.body as { query?: string; country?: string; city?: string };
      res.json(
        await beeSeoKeywordsService.research({
          query: body.query ?? '',
          country: body.country,
          city: body.city,
        }),
      );
    } catch (error) {
      next(error);
    }
  },

  async overview(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await beeSeoOverviewService.overview());
    } catch (error) {
      next(error);
    }
  },

  async backlinks(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await beeSeoBacklinksService.backlinks());
    } catch (error) {
      next(error);
    }
  },
};
