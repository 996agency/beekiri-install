import type { NextFunction, Request, Response } from 'express';
import { analyticsService } from '../services/analytics.service';
import type { AnalyticsRange } from '../validators/analytics.schema';

export const analyticsController = {
  async settings(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await analyticsService.settings());
    } catch (error) {
      next(error);
    }
  },

  async updateSettings(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await analyticsService.updateSettings(req.body));
    } catch (error) {
      next(error);
    }
  },

  async report(req: Request, res: Response, next: NextFunction) {
    try {
      const range = (req.query.range as AnalyticsRange | undefined) ?? '30d';
      const source = req.query.source === 'google' ? 'google' : 'beekiri';
      res.json(await analyticsService.report(range, source));
    } catch (error) {
      next(error);
    }
  },

  async live(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await analyticsService.live());
    } catch (error) {
      next(error);
    }
  },

  async heatmap(req: Request, res: Response, next: NextFunction) {
    try {
      const range = (req.query.range as AnalyticsRange | undefined) ?? '30d';
      const path = typeof req.query.path === 'string' ? req.query.path : undefined;
      res.json(await analyticsService.heatmap(range, path));
    } catch (error) {
      next(error);
    }
  },
};
