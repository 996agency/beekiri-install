import type { NextFunction, Request, Response } from 'express';
import { beeCookiesService, type BeeCookieRange } from '../services/bee-cookies.service';

export const beeCookiesController = {
  async publicConfig(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await beeCookiesService.publicConfig());
    } catch (error) {
      next(error);
    }
  },

  async consent(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await beeCookiesService.recordConsent(req, req.body));
    } catch (error) {
      next(error);
    }
  },

  async visit(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await beeCookiesService.recordVisit(req, req.body));
    } catch (error) {
      next(error);
    }
  },

  async heartbeat(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await beeCookiesService.heartbeat(req, req.body));
    } catch (error) {
      next(error);
    }
  },

  async clicks(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await beeCookiesService.recordClicks(req, req.body));
    } catch (error) {
      next(error);
    }
  },

  async getSettings(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await beeCookiesService.getSettings());
    } catch (error) {
      next(error);
    }
  },

  async updateSettings(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await beeCookiesService.updateSettings(req.body));
    } catch (error) {
      next(error);
    }
  },

  async analytics(req: Request, res: Response, next: NextFunction) {
    try {
      const range = (req.query.range as BeeCookieRange | undefined) ?? '30d';
      res.json(await beeCookiesService.analytics(range));
    } catch (error) {
      next(error);
    }
  },
};
