import type { NextFunction, Request, Response } from 'express';
import { authUser } from '../middleware/authenticate';
import { usersService } from '../services/users.service';

const id = (req: Request) => req.params.id as string;

export const usersController = {
  roles(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json({ roles: usersService.roles() });
    } catch (error) {
      next(error);
    }
  },

  async rolesManage(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await usersService.rolesManage(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  async updateRole(req: Request, res: Response, next: NextFunction) {
    try {
      const slug = String(req.params.slug ?? '');
      res.json(await usersService.updateRole(authUser(req), slug, req.body));
    } catch (error) {
      next(error);
    }
  },

  async list(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await usersService.list(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  async get(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await usersService.get(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await usersService.create(authUser(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await usersService.update(authUser(req), id(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async getDashboardLayout(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await usersService.getDashboardLayout(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  async setDashboardLayout(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await usersService.setDashboardLayout(authUser(req), req.body.layout ?? []));
    } catch (error) {
      next(error);
    }
  },

  async remove(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await usersService.remove(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  permissionsCatalog(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(usersService.permissionsCatalog());
    } catch (error) {
      next(error);
    }
  },

  async permissionsOverview(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await usersService.permissionsOverview(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  async updatePermissions(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await usersService.updatePermissions(authUser(req), id(req), req.body));
    } catch (error) {
      next(error);
    }
  },
};
