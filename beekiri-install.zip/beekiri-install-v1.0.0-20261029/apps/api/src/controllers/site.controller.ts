import type { NextFunction, Request, Response } from 'express';
import { dashboardService, type DashboardRange } from '../services/dashboard.service';
import { siteService } from '../services/site.service';

export const siteController = {
  async linkTargets(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await siteService.linkTargets());
    } catch (error) {
      next(error);
    }
  },

  async pageEditor(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await siteService.pageEditor());
    } catch (error) {
      next(error);
    }
  },

  async publicSite(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await siteService.publicSite());
    } catch (error) {
      next(error);
    }
  },

  async dashboard(req: Request, res: Response, next: NextFunction) {
    try {
      const range = (req.query.range as DashboardRange | undefined) ?? 'today';
      res.json(await dashboardService.overview(range));
    } catch (error) {
      next(error);
    }
  },

  async getSettings(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await siteService.getSettings());
    } catch (error) {
      next(error);
    }
  },

  async updateSettings(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await siteService.updateSettings(req.body));
    } catch (error) {
      next(error);
    }
  },
};
