import type { NextFunction, Request, Response } from 'express';
import { systemService } from '../services/system.service';

export const systemController = {
  version(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(systemService.getVersionInfo());
    } catch (error) {
      next(error);
    }
  },

  async status(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await systemService.getStatus());
    } catch (error) {
      next(error);
    }
  },

  async updates(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await systemService.checkUpdates());
    } catch (error) {
      next(error);
    }
  },

  /** Download and apply the latest core in place (database, .env and uploads are kept). */
  async applyUpdate(_req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await systemService.startCoreUpdate());
    } catch (error) {
      next(error);
    }
  },

  updateProgress(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(systemService.getUpdateProgress());
    } catch (error) {
      next(error);
    }
  },

  /** Live Lighthouse scores for the public site (cached ~5 minutes). */
  async lighthouse(req: Request, res: Response, next: NextFunction) {
    try {
      const refresh = req.query.refresh;
      res.json(
        await systemService.getLighthouseScores({ force: refresh === '1' || refresh === 'true' }),
      );
    } catch (error) {
      next(error);
    }
  },

  /** Busts theme/layout asset URLs, Next.js ISR, the Lighthouse cache and the web build. */
  async flushCache(_req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await systemService.flushCache());
    } catch (error) {
      next(error);
    }
  },
};
