import type { NextFunction, Request, Response } from 'express';
import type { ContentKind } from '../lib/pages/content-kind';
import { heartbeatPresence, leavePresence, listPresence } from '../lib/pages/pages.presence';
import { authUser } from '../middleware/authenticate';
import { pagesService } from '../services/pages.service';

function previewToken(req: Request): string | undefined {
  const { preview, token } = req.query as { preview?: unknown; token?: string };
  const wantPreview =
    preview === true || preview === '1' || preview === 'true' || Boolean(token?.trim());
  return wantPreview ? token : undefined;
}

const id = (req: Request) => req.params.id as string;

function handlersFor(kindOf: (req: Request) => ContentKind) {
  return {
    async publicFront(req: Request, res: Response, next: NextFunction) {
      try {
        res.json(await pagesService.getPublishedFrontPage(previewToken(req)));
      } catch (error) {
        next(error);
      }
    },

    async publicList(req: Request, res: Response, next: NextFunction) {
      try {
        res.json(await pagesService.listPublishedPublic(kindOf(req)));
      } catch (error) {
        next(error);
      }
    },

    async publicBySlug(req: Request, res: Response, next: NextFunction) {
      try {
        res.json(
          await pagesService.getPublishedBySlug(
            req.params.slug as string,
            previewToken(req),
            kindOf(req),
          ),
        );
      } catch (error) {
        next(error);
      }
    },

    async list(req: Request, res: Response, next: NextFunction) {
      try {
        const status = String(req.query.status || '') === 'trash' ? 'trash' : 'all';
        res.json(await pagesService.list(authUser(req), kindOf(req), { status }));
      } catch (error) {
        next(error);
      }
    },

    async listRevisions(req: Request, res: Response, next: NextFunction) {
      try {
        res.json(await pagesService.listRevisions(authUser(req), id(req), kindOf(req)));
      } catch (error) {
        next(error);
      }
    },

    async restoreRevision(req: Request, res: Response, next: NextFunction) {
      try {
        const revisionId = req.params.revisionId as string;
        res
          .status(201)
          .json(
            await pagesService.restoreRevision(authUser(req), id(req), revisionId, kindOf(req)),
          );
      } catch (error) {
        next(error);
      }
    },

    async preview(req: Request, res: Response, next: NextFunction) {
      try {
        res
          .status(201)
          .json(await pagesService.createPreview(authUser(req), id(req), req.body, kindOf(req)));
      } catch (error) {
        next(error);
      }
    },

    getPresence(req: Request, res: Response, next: NextFunction) {
      try {
        res.json({ peers: listPresence(id(req)) });
      } catch (error) {
        next(error);
      }
    },

    async postPresence(req: Request, res: Response, next: NextFunction) {
      try {
        const user = authUser(req);
        // Only documents of this site can carry presence.
        await pagesService.get(user, id(req), kindOf(req));
        const peers = heartbeatPresence({
          pageId: id(req),
          userId: user.id,
          name: user.displayName?.trim() || user.username,
          clientId: req.body.clientId,
        });
        res.status(201).json({ peers });
      } catch (error) {
        next(error);
      }
    },

    deletePresence(req: Request, res: Response, next: NextFunction) {
      try {
        const clientId = (req.query.clientId as string | undefined)?.trim();
        if (clientId) leavePresence(id(req), clientId);
        res.json({ ok: true });
      } catch (error) {
        next(error);
      }
    },

    async get(req: Request, res: Response, next: NextFunction) {
      try {
        res.json(await pagesService.get(authUser(req), id(req), kindOf(req)));
      } catch (error) {
        next(error);
      }
    },

    async create(req: Request, res: Response, next: NextFunction) {
      try {
        res.status(201).json(await pagesService.create(authUser(req), req.body, kindOf(req)));
      } catch (error) {
        next(error);
      }
    },

    async update(req: Request, res: Response, next: NextFunction) {
      try {
        res.json(await pagesService.update(authUser(req), id(req), req.body, kindOf(req)));
      } catch (error) {
        next(error);
      }
    },

    async remove(req: Request, res: Response, next: NextFunction) {
      try {
        const force =
          String(req.query.force || '') === '1' ||
          String(req.query.force || '').toLowerCase() === 'true';
        res.json(await pagesService.remove(authUser(req), id(req), kindOf(req), { force }));
      } catch (error) {
        next(error);
      }
    },

    async restore(req: Request, res: Response, next: NextFunction) {
      try {
        res.json(await pagesService.restore(authUser(req), id(req), kindOf(req)));
      } catch (error) {
        next(error);
      }
    },
  };
}

/** Same handlers serve /pages and /posts; only the content kind differs. */
export function createContentController(kind: ContentKind) {
  return handlersFor(() => kind);
}

/** Custom post types: kind comes from `/api/content/:type`. */
export function createParamContentController() {
  return handlersFor((req) =>
    String((req.params as { type?: string }).type || '')
      .trim()
      .toLowerCase(),
  );
}
