import type { NextFunction, Request, Response } from 'express';
import { pingDatabase } from '../db/sequelize';
import { ServiceUnavailable } from '../utils/http-error';

export const healthController = {
  async health(_req: Request, res: Response, next: NextFunction) {
    try {
      const database = await pingDatabase();
      res.json({ status: database ? 'ok' : 'degraded', database, uptime: process.uptime() });
    } catch (error) {
      next(error);
    }
  },

  async ready(_req: Request, res: Response, next: NextFunction) {
    try {
      if (!(await pingDatabase())) throw ServiceUnavailable('Database is not reachable.');
      res.json({ ready: true });
    } catch (error) {
      next(error);
    }
  },
};
