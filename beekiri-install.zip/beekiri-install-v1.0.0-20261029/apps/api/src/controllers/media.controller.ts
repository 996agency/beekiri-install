import type { NextFunction, Request, Response } from 'express';
import { authUser } from '../middleware/authenticate';
import { formField } from '../middleware/upload';
import { mediaService } from '../services/media.service';
import { BadRequest } from '../utils/http-error';

export const mediaController = {
  async list(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await mediaService.list(req.query.folderId as string | undefined));
    } catch (error) {
      next(error);
    }
  },

  async upload(req: Request, res: Response, next: NextFunction) {
    try {
      const user = authUser(req);
      const file = req.file;
      if (!file) throw BadRequest('No file uploaded. Use field name "file".');

      const query = req.query as { purpose?: string; folderId?: string; alt?: string };
      const purpose = query.purpose || formField(req, 'purpose');
      const result = await mediaService.upload({
        buffer: file.buffer,
        filename: file.originalname || 'upload',
        mimeType: file.mimetype || 'application/octet-stream',
        folderId: query.folderId || formField(req, 'folderId') || null,
        alt: (query.alt || formField(req, 'alt'))?.slice(0, 500),
        purpose: purpose === 'favicon' ? 'favicon' : 'media',
        uploadedById: user.id,
      });
      res.status(201).json(result);
    } catch (error) {
      next(error);
    }
  },

  async bulkMove(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await mediaService.bulkMove(req.body.ids, req.body.folderId));
    } catch (error) {
      next(error);
    }
  },

  async bulkDelete(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await mediaService.bulkRemove(req.body.ids));
    } catch (error) {
      next(error);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await mediaService.update(req.params.id as string, req.body));
    } catch (error) {
      next(error);
    }
  },

  async remove(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await mediaService.remove(req.params.id as string));
    } catch (error) {
      next(error);
    }
  },
};
