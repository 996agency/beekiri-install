import { getSelfUrl } from '../config/runtime';
import { config } from '../config/env';
import { toHttpError } from '../utils/http-error';
import { requirePrimarySite } from './site-context';

export type BacklinkRow = {
  sourceHost: string;
  sourceUrl: string;
  targetPath: string;
  anchor: string;
  flags: string[];
  linkCount: number | null;
  da: number | null;
  spam: number | null;
  firstSeen: string | null;
};

export type ReferringDomainRow = {
  host: string;
  backlinks: number | null;
  da: number | null;
  spam: number | null;
  firstSeen: string | null;
};

export type TopPageRow = {
  path: string;
  backlinks: number | null;
  referringDomains: number | null;
};

export type SeriesPoint = {
  date: string;
  label: string;
  value: number;
};

export type BacklinksResponse = {
  domain: string;
  metrics: {
    backlinks: number | null;
    referringDomains: number | null;
    referringPages: number | null;
    rank: number | null;
    backlinkSpamScore: number | null;
    brokenBacklinks: number | null;
    brokenPages: number | null;
    targetSpamScore: number | null;
  };
  growth: {
    backlinks: SeriesPoint[];
    referringDomains: SeriesPoint[];
  };
  attrition: {
    newBacklinks: SeriesPoint[];
    lostBacklinks: SeriesPoint[];
  };
  links: BacklinkRow[];
  referringDomains: ReferringDomainRow[];
  topPages: TopPageRow[];
};

function siteBaseUrl(): string {
  return (config.urls.app ?? getSelfUrl() ?? `http://127.0.0.1:${config.server.port}`).replace(
    /\/$/,
    '',
  );
}

function emptyYearSeries(): SeriesPoint[] {
  const out: SeriesPoint[] = [];
  const now = new Date();
  for (let i = 11; i >= 0; i -= 1) {
    const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
    const label = d.toLocaleString('en-US', { month: 'short', year: '2-digit', timeZone: 'UTC' });
    out.push({
      date: d.toISOString().slice(0, 10),
      label,
      value: 0,
    });
  }
  return out;
}

export class BeeSeoBacklinksService {
  async backlinks() {
    try {
      await requirePrimarySite();
      const base = siteBaseUrl();
      let domain = base;
      try {
        domain = new URL(base).host;
      } catch {
        /* keep */
      }

      const empty = emptyYearSeries();

      // No paid backlink index — shell matches OpenSEO layout with empty metrics/tables.
      return {
        domain,
        metrics: {
          backlinks: null,
          referringDomains: null,
          referringPages: null,
          rank: null,
          backlinkSpamScore: null,
          brokenBacklinks: null,
          brokenPages: null,
          targetSpamScore: null,
        },
        growth: {
          backlinks: empty,
          referringDomains: empty,
        },
        attrition: {
          newBacklinks: empty,
          lostBacklinks: empty,
        },
        links: [],
        referringDomains: [],
        topPages: [],
      } satisfies BacklinksResponse;
    } catch (error) {
      throw toHttpError(error, 'Could not load backlinks.');
    }
  }
}

export const beeSeoBacklinksService = new BeeSeoBacklinksService();
