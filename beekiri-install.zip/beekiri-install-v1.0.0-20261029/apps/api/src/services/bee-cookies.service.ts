import type { Request } from 'express';
import { QueryTypes } from 'sequelize';
import {
  parseBeeCookies,
  publicBeeCookies,
  type BeeCookiesOptions,
} from '../lib/site/bee-cookies';
import { channelOf, pathOnly, utmSourceFromPath } from '../lib/site/bee-cookies-channel';
import { isLikelyBot } from '../lib/site/bee-cookies-bots';
import { countryFromRequest } from '../lib/site/bee-cookies-geo';
import { touchLive } from '../lib/site/bee-cookies-live';
import { browserOf, osOf } from '../lib/site/bee-cookies-ua';
import { mergeSiteOptions, readOptions } from '../lib/site/site-options';
import { BeeCookieClick, BeeCookieConsent, BeeCookieVisit, sequelize } from '../models';
import type { BeeCookieDevice, BeeCookieStatus } from '../models/bee-cookie-consent.model';
import { BadRequest, toHttpError } from '../utils/http-error';
import type {
  BeeCookieClicksInput,
  BeeCookieConsentInput,
  BeeCookieHeartbeatInput,
  BeeCookieVisitInput,
  BeeCookiesSettingsInput,
} from '../validators/bee-cookies.schema';
import { findPrimarySite, requirePrimarySite, saveSiteOptions } from './site-context';

export type BeeCookieRange = 'today' | '7d' | '30d' | 'all';

/**
 * Same visitor + path within a session window does not create another page-view row.
 * Matches analytics session gap (30 minutes) so refreshes by the same user are not extra views.
 */
const VISIT_DEDUPE_MS = 30 * 60 * 1000;

type CountRow = { key: string; n: string | number };
type TrendRow = { day: string; accepted: string | number; rejected: string | number; custom: string | number };

function num(v: string | number | undefined): number {
  return Number(v) || 0;
}

function deviceOf(ua: string | undefined): BeeCookieDevice {
  const s = ua ?? '';
  if (/iPad|Tablet|PlayBook/i.test(s)) return 'tablet';
  if (/Mobi|Android|iPhone|iPod|webOS|BlackBerry/i.test(s)) return 'mobile';
  if (!s) return 'unknown';
  return 'desktop';
}

function countryOf(
  req: Request,
  hint?: { timeZone?: string; locale?: string },
): string | null {
  return countryFromRequest({ get: (name) => req.get(name) }, hint);
}

function cleanPath(raw: unknown): string {
  const s = typeof raw === 'string' ? raw.trim() : '';
  if (!s) return '/';
  try {
    const u = s.startsWith('http') ? new URL(s) : new URL(s, 'https://beekiri.local');
    const path = (u.pathname || '/').slice(0, 500);
    return path.startsWith('/') ? path : `/${path}`;
  } catch {
    return s.startsWith('/') ? s.slice(0, 500) : `/${s.slice(0, 499)}`;
  }
}

function referrerHost(raw: unknown, req: Request): string | null {
  if (typeof raw !== 'string' || !raw.trim()) return null;
  try {
    const host = new URL(raw).hostname.replace(/^www\./, '').toLowerCase();
    const self = (req.get('host') ?? '').replace(/^www\./, '').toLowerCase();
    if (!host || host === self) return null;
    return host.slice(0, 120);
  } catch {
    return null;
  }
}

function consentStatus(
  opts: BeeCookiesOptions,
  choices: { functional: boolean; analytics: boolean; marketing: boolean },
): BeeCookieStatus {
  const offered = (['functional', 'analytics', 'marketing'] as const).filter(
    (key) => opts.categories[key].enabled,
  );
  if (!offered.length) return 'accepted';
  const all = offered.every((key) => choices[key]);
  const none = offered.every((key) => !choices[key]);
  if (all) return 'accepted';
  if (none) return 'rejected';
  return 'custom';
}

function clampChoices(opts: BeeCookiesOptions, input: BeeCookieConsentInput) {
  const cats = opts.categories;
  return {
    functional: cats.functional.enabled ? input.functional : false,
    analytics: cats.analytics.enabled ? input.analytics : false,
    marketing: cats.marketing.enabled ? input.marketing : false,
  };
}

function rangeStart(range: BeeCookieRange): Date | null {
  if (range === 'all') return null;
  const now = new Date();
  if (range === 'today') {
    return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  }
  const days = range === '7d' ? 7 : 30;
  return new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
}

function sinceSql(range: BeeCookieRange): { sql: string; replacements: Record<string, unknown> } {
  const start = rangeStart(range);
  if (!start) return { sql: '', replacements: {} };
  return { sql: 'AND "createdAt" >= :since', replacements: { since: start } };
}

export class BeeCookiesService {
  async publicConfig() {
    try {
      const site = await findPrimarySite();
      if (!site) return { enabled: false };
      const opts = readOptions(site.settings?.options);
      const ga = opts.googleAnalytics?.measurementId ?? '';
      return {
        ...publicBeeCookies(parseBeeCookies(opts.beeCookies)),
        googleMeasurementId: ga || undefined,
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load BeeCookies.');
    }
  }

  async getSettings() {
    try {
      const site = await requirePrimarySite();
      return parseBeeCookies(readOptions(site.settings?.options).beeCookies);
    } catch (error) {
      throw toHttpError(error, 'Could not load BeeCookies settings.');
    }
  }

  async updateSettings(body: BeeCookiesSettingsInput) {
    try {
      const site = await requirePrimarySite();
      const current = parseBeeCookies(readOptions(site.settings?.options).beeCookies);
      const next = parseBeeCookies({
        ...current,
        ...body,
        categories: {
          ...current.categories,
          ...(body.categories ?? {}),
          essential: { ...current.categories.essential, ...body.categories?.essential, enabled: true },
        },
      });
      await saveSiteOptions(site.id, mergeSiteOptions(site.settings?.options, { beeCookies: next }));
      return next;
    } catch (error) {
      throw toHttpError(error, 'Could not save BeeCookies settings.');
    }
  }

  async recordConsent(req: Request, body: BeeCookieConsentInput) {
    try {
      if (isLikelyBot(req.get('user-agent'))) return { ok: true };
      const site = await findPrimarySite();
      if (!site) throw BadRequest('This site is not installed.');
      const opts = parseBeeCookies(readOptions(site.settings?.options).beeCookies);
      if (!opts.enabled) throw BadRequest('BeeCookies is turned off.');
      const choices = clampChoices(opts, body);
      const status = consentStatus(opts, choices);
      await BeeCookieConsent.create({
        siteId: site.id,
        visitorId: body.visitorId,
        status,
        essential: true,
        functional: choices.functional,
        analytics: choices.analytics,
        marketing: choices.marketing,
        device: deviceOf(req.get('user-agent')),
        country: countryOf(req, body),
        path: cleanPath(body.path),
      });
      if (choices.analytics) {
        touchLive(site.id, body.visitorId, cleanPath(body.path));
      }
      return { ok: true, status, ...choices, essential: true };
    } catch (error) {
      throw toHttpError(error, 'Could not save cookie consent.');
    }
  }

  async recordVisit(req: Request, body: BeeCookieVisitInput) {
    try {
      if (isLikelyBot(req.get('user-agent'))) return { ok: true };
      const site = await findPrimarySite();
      if (!site) return { ok: true };
      const opts = parseBeeCookies(readOptions(site.settings?.options).beeCookies);
      if (!opts.enabled || !opts.trackPageViews) return { ok: true };
      const latest = await BeeCookieConsent.findOne({
        where: { siteId: site.id, visitorId: body.visitorId },
        order: [['createdAt', 'DESC']],
      });
      if (!latest?.analytics) return { ok: true };
      const rawPath = typeof body.path === 'string' ? body.path.trim() : '/';
      const path = cleanPath(pathOnly(rawPath));
      touchLive(site.id, body.visitorId, path);
      const country = countryOf(req, body);
      if (country && !latest.country) {
        await latest.update({ country });
      }
      const recent = await BeeCookieVisit.findOne({
        where: { siteId: site.id, visitorId: body.visitorId, path },
        order: [['createdAt', 'DESC']],
      });
      if (recent && Date.now() - recent.createdAt.getTime() < VISIT_DEDUPE_MS) {
        return { ok: true, deduped: true };
      }
      const ua = req.get('user-agent');
      const refHost = referrerHost(body.referrer, req);
      const utmSource = utmSourceFromPath(rawPath);
      await BeeCookieVisit.create({
        siteId: site.id,
        visitorId: body.visitorId,
        path,
        referrerHost: refHost,
        device: deviceOf(ua),
        country: country ?? latest.country,
        browser: browserOf(ua),
        os: osOf(ua),
        language: (body.language || body.locale || '').trim().slice(0, 40) || null,
        screen: (body.screen || '').trim().slice(0, 32) || null,
        title: (body.title || '').trim().slice(0, 200) || null,
        channel: channelOf(refHost, utmSource),
        utmSource,
      });
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not record visit.');
    }
  }

  /** Presence only — does not write page-view rows. */
  async heartbeat(req: Request, body: BeeCookieHeartbeatInput) {
    try {
      if (isLikelyBot(req.get('user-agent'))) return { ok: true };
      const site = await findPrimarySite();
      if (!site) return { ok: true };
      const opts = parseBeeCookies(readOptions(site.settings?.options).beeCookies);
      if (!opts.enabled || !opts.trackPageViews) return { ok: true };
      const latest = await BeeCookieConsent.findOne({
        where: { siteId: site.id, visitorId: body.visitorId },
        order: [['createdAt', 'DESC']],
        attributes: ['analytics'],
      });
      if (!latest?.analytics) return { ok: true };
      touchLive(site.id, body.visitorId, cleanPath(body.path));
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not record heartbeat.');
    }
  }

  /** Click points for heatmaps — analytics consent required. */
  async recordClicks(req: Request, body: BeeCookieClicksInput) {
    try {
      if (isLikelyBot(req.get('user-agent'))) return { ok: true };
      const site = await findPrimarySite();
      if (!site) return { ok: true };
      const opts = parseBeeCookies(readOptions(site.settings?.options).beeCookies);
      if (!opts.enabled || !opts.trackPageViews) return { ok: true };
      const latest = await BeeCookieConsent.findOne({
        where: { siteId: site.id, visitorId: body.visitorId },
        order: [['createdAt', 'DESC']],
        attributes: ['analytics'],
      });
      if (!latest?.analytics) return { ok: true };
      const path = cleanPath(pathOnly(body.path));
      if (path.startsWith('/admin')) return { ok: true };
      const device = deviceOf(req.get('user-agent'));
      const viewportW =
        typeof body.viewportW === 'number' && Number.isFinite(body.viewportW)
          ? Math.round(body.viewportW)
          : null;
      const rows = body.clicks.slice(0, 40).map((c) => ({
        siteId: site.id,
        visitorId: body.visitorId,
        path,
        xPct: Math.round(Math.min(100, Math.max(0, c.x)) * 10) / 10,
        yPct: Math.round(Math.min(100, Math.max(0, c.y)) * 10) / 10,
        device,
        viewportW,
      }));
      if (!rows.length) return { ok: true };
      await BeeCookieClick.bulkCreate(rows);
      return { ok: true, n: rows.length };
    } catch (error) {
      throw toHttpError(error, 'Could not record clicks.');
    }
  }

  async analytics(range: BeeCookieRange = '30d') {
    try {
      const site = await requirePrimarySite();
      const { sql, replacements } = sinceSql(range);
      const params = { siteId: site.id, ...replacements };

      const [snapshot, trend, visits, topPages, visitDevices, visitCountries, sources] =
        await Promise.all([
          sequelize.query<{
            decisions: string | number;
            visitors: string | number;
            accepted: string | number;
            rejected: string | number;
            custom: string | number;
            functional: string | number;
            analytics: string | number;
            marketing: string | number;
          }>(
            `SELECT
               COUNT(*)::int AS decisions,
               COUNT(DISTINCT "visitorId")::int AS visitors,
               COUNT(*) FILTER (WHERE status = 'accepted')::int AS accepted,
               COUNT(*) FILTER (WHERE status = 'rejected')::int AS rejected,
               COUNT(*) FILTER (WHERE status = 'custom')::int AS custom,
               COUNT(*) FILTER (WHERE functional)::int AS functional,
               COUNT(*) FILTER (WHERE analytics)::int AS analytics,
               COUNT(*) FILTER (WHERE marketing)::int AS marketing
             FROM (
               SELECT DISTINCT ON ("visitorId") *
               FROM "BeeCookieConsent"
               WHERE "siteId" = :siteId ${sql}
               ORDER BY "visitorId", "createdAt" DESC
             ) latest`,
            { replacements: params, type: QueryTypes.SELECT },
          ),
          sequelize.query<TrendRow>(
            `SELECT
               to_char(date_trunc('day', "createdAt"), 'YYYY-MM-DD') AS day,
               COUNT(*) FILTER (WHERE status = 'accepted')::int AS accepted,
               COUNT(*) FILTER (WHERE status = 'rejected')::int AS rejected,
               COUNT(*) FILTER (WHERE status = 'custom')::int AS custom
             FROM "BeeCookieConsent"
             WHERE "siteId" = :siteId ${sql}
             GROUP BY 1
             ORDER BY 1`,
            { replacements: params, type: QueryTypes.SELECT },
          ),
          sequelize.query<{ views: string | number; visitors: string | number }>(
            `SELECT COUNT(*)::int AS views, COUNT(DISTINCT "visitorId")::int AS visitors
             FROM "BeeCookieVisit"
             WHERE "siteId" = :siteId ${sql}`,
            { replacements: params, type: QueryTypes.SELECT },
          ),
          sequelize.query<CountRow>(
            `SELECT path AS key, COUNT(DISTINCT "visitorId")::int AS n
             FROM "BeeCookieVisit"
             WHERE "siteId" = :siteId ${sql}
             GROUP BY path
             ORDER BY n DESC
             LIMIT 8`,
            { replacements: params, type: QueryTypes.SELECT },
          ),
          sequelize.query<CountRow>(
            `SELECT device AS key, COUNT(*)::int AS n
             FROM "BeeCookieVisit"
             WHERE "siteId" = :siteId ${sql}
             GROUP BY device
             ORDER BY n DESC`,
            { replacements: params, type: QueryTypes.SELECT },
          ),
          sequelize.query<CountRow>(
            `SELECT COALESCE(country, 'Unknown') AS key, COUNT(*)::int AS n
             FROM "BeeCookieVisit"
             WHERE "siteId" = :siteId ${sql}
             GROUP BY 1
             ORDER BY n DESC
             LIMIT 8`,
            { replacements: params, type: QueryTypes.SELECT },
          ),
          sequelize.query<CountRow>(
            `SELECT COALESCE("referrerHost", 'Direct') AS key, COUNT(*)::int AS n
             FROM "BeeCookieVisit"
             WHERE "siteId" = :siteId ${sql}
             GROUP BY 1
             ORDER BY n DESC
             LIMIT 8`,
            { replacements: params, type: QueryTypes.SELECT },
          ),
        ]);

      const snap = snapshot[0] ?? {
        decisions: 0,
        visitors: 0,
        accepted: 0,
        rejected: 0,
        custom: 0,
        functional: 0,
        analytics: 0,
        marketing: 0,
      };
      const decisions = num(snap.decisions);
      const devices = await sequelize.query<CountRow>(
        `SELECT device AS key, COUNT(*)::int AS n
         FROM (
           SELECT DISTINCT ON ("visitorId") device
           FROM "BeeCookieConsent"
           WHERE "siteId" = :siteId ${sql}
           ORDER BY "visitorId", "createdAt" DESC
         ) latest
         GROUP BY device`,
        { replacements: params, type: QueryTypes.SELECT },
      );
      const countries = await sequelize.query<CountRow>(
        `SELECT COALESCE(country, 'Unknown') AS key, COUNT(*)::int AS n
         FROM (
           SELECT DISTINCT ON ("visitorId") country
           FROM "BeeCookieConsent"
           WHERE "siteId" = :siteId ${sql}
           ORDER BY "visitorId", "createdAt" DESC
         ) latest
         GROUP BY 1
         ORDER BY n DESC
         LIMIT 8`,
        { replacements: params, type: QueryTypes.SELECT },
      );

      return {
        range,
        consent: {
          decisions,
          uniqueVisitors: num(snap.visitors),
          accepted: num(snap.accepted),
          rejected: num(snap.rejected),
          custom: num(snap.custom),
          consentRate: decisions ? Math.round((num(snap.accepted) / decisions) * 100) : 0,
          categories: {
            functional: num(snap.functional),
            analytics: num(snap.analytics),
            marketing: num(snap.marketing),
          },
          devices: Object.fromEntries(devices.map((r) => [r.key, num(r.n)])),
          countries: countries.map((r) => ({ code: r.key, count: num(r.n) })),
          trend: trend.map((r) => ({
            date: r.day,
            accepted: num(r.accepted),
            rejected: num(r.rejected),
            custom: num(r.custom),
          })),
        },
        traffic: {
          pageViews: num(visits[0]?.views),
          uniqueVisitors: num(visits[0]?.visitors),
          topPages: topPages.map((r) => ({ path: r.key, views: num(r.n) })),
          devices: Object.fromEntries(visitDevices.map((r) => [r.key, num(r.n)])),
          countries: visitCountries.map((r) => ({ code: r.key, count: num(r.n) })),
          sources: sources.map((r) => ({ host: r.key, views: num(r.n) })),
        },
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load BeeCookies analytics.');
    }
  }
}

export const beeCookiesService = new BeeCookiesService();
