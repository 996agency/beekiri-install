import type { Transaction } from 'sequelize';
import { Site, SiteSettings } from '../models';
import type { Json } from '../models/_shared';
import { NotFound } from '../utils/http-error';

/** The installed site (single-site install: the oldest row), with its settings row. */
export async function findPrimarySite(transaction?: Transaction) {
  return Site.findOne({
    include: [{ model: SiteSettings, as: 'settings' }],
    order: [['createdAt', 'ASC']],
    transaction,
  });
}

export async function requirePrimarySite(transaction?: Transaction) {
  const site = await findPrimarySite(transaction);
  if (!site) throw NotFound('Site not found');
  return site;
}

/** Create-or-update the site's settings row with a new options bag. */
export async function saveSiteOptions(siteId: string, options: Json, transaction?: Transaction) {
  const existing = await SiteSettings.findOne({ where: { siteId }, transaction });
  if (existing) {
    await SiteSettings.update({ options }, { where: { id: existing.id }, transaction });
  } else {
    await SiteSettings.create({ siteId, options }, { transaction });
  }
}
