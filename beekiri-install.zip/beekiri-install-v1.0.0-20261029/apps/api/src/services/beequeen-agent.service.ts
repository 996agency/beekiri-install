import { parseConnector } from '../lib/site/connector';
import { readOptions } from '../lib/site/site-options';
import type { AuthUser } from '../types/auth';
import { BadRequest, toHttpError } from '../utils/http-error';
import { requirePrimarySite } from './site-context';

export type BeeQueenAgentResult = {
  ok: true;
  reply: string;
  action: 'layout_created' | 'layout_updated' | 'noop';
  group?: {
    id: string;
    title: string;
    key: string;
    slug: string;
    theme: string;
    path: string;
  };
};

/**
 * BeeQueen layout agent — stub until Claude (or another real API) is wired.
 * Connector enable/UI stays; inference is intentionally empty.
 */
class BeeQueenAgentService {
  async run(_actor: AuthUser, promptRaw: string): Promise<BeeQueenAgentResult> {
    try {
      const prompt = promptRaw.trim();
      if (!prompt) throw BadRequest('Ask BeeQueen for a theme layout change.');

      const site = await requirePrimarySite();
      const connector = parseConnector(readOptions(site.settings?.options).connector);
      if (!connector.providers.beequeen?.enabled) {
        throw BadRequest('Enable BeeQueen under Connector first.');
      }

      return {
        ok: true,
        action: 'noop',
        reply:
          'BeeQueen is ready in Connector, but the layout agent isn’t connected to a model yet. ' +
          'We’ll wire a real API (Claude) next.',
      };
    } catch (error) {
      throw toHttpError(error, 'BeeQueen could not complete that.');
    }
  }
}

export const beeQueenAgentService = new BeeQueenAgentService();
