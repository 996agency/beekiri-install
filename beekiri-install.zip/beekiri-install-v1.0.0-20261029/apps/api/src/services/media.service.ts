import { mkdir, unlink, writeFile } from 'fs/promises';
import { dirname, extname, join, resolve, sep } from 'path';
import { Op } from 'sequelize';
import sharp from 'sharp';
import { createId } from '../lib/media/media.id';
import { resolveUploadsRoot } from '../lib/media/media.paths';
import {
  defaultMediaSettings,
  parseMediaSettings,
  readOptions,
  type MediaSettingsOption,
} from '../lib/site/site-options';
import { MediaAsset } from '../models';
import { BadRequest, NotFound, toHttpError } from '../utils/http-error';
import { requirePrimarySite } from './site-context';

export const MAX_UPLOAD_BYTES = 20 * 1024 * 1024;

const ALLOWED_MIME = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
  'image/gif',
  'image/svg+xml',
  'image/x-icon',
  'image/vnd.microsoft.icon',
]);

/** Non-image uploads (file fields). Extension comes from this map, never the client filename. */
const FILE_EXT: Record<string, string> = {
  'application/pdf': '.pdf',
  'application/zip': '.zip',
  'text/plain': '.txt',
  'text/csv': '.csv',
  'application/msword': '.doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
  'application/vnd.ms-excel': '.xls',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx',
  'application/vnd.ms-powerpoint': '.ppt',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': '.pptx',
  'video/mp4': '.mp4',
  'video/webm': '.webm',
  'audio/mpeg': '.mp3',
  'audio/wav': '.wav',
};

for (const mime of Object.keys(FILE_EXT)) ALLOWED_MIME.add(mime);

const PASS_THROUGH = new Set(['image/svg+xml', 'image/x-icon', 'image/vnd.microsoft.icon']);

export type UploadPurpose = 'media' | 'favicon';

export type UploadInput = {
  buffer: Buffer;
  filename: string;
  mimeType: string;
  folderId?: string | null;
  alt?: string;
  purpose?: UploadPurpose;
  uploadedById?: string | null;
};

function sanitizeBaseName(name: string): string {
  const base = name.replace(/\.[^.]+$/, '').toLowerCase();
  const cleaned = base
    .replace(/[^a-z0-9._-]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
  return cleaned.slice(0, 80) || 'file';
}

function extForMime(mime: string, original: string): string {
  if (mime === 'image/jpeg') return '.jpg';
  if (mime === 'image/png') return '.png';
  if (mime === 'image/webp') return '.webp';
  if (mime === 'image/gif') return '.gif';
  if (mime === 'image/svg+xml') return '.svg';
  if (mime === 'image/x-icon' || mime === 'image/vnd.microsoft.icon') return '.ico';
  if (FILE_EXT[mime]) return FILE_EXT[mime];
  const e = extname(original).toLowerCase();
  return e || '.bin';
}

/** Absolute path inside the uploads root, or null if a stored path tries to escape it. */
function uploadsPath(storagePath: string): string | null {
  const root = resolve(resolveUploadsRoot());
  const abs = resolve(root, storagePath);
  return abs.startsWith(root + sep) ? abs : null;
}

async function removeStoredFile(storagePath: string) {
  const abs = uploadsPath(storagePath);
  if (!abs) return;
  try {
    await unlink(abs);
  } catch {
    // File may already be gone; the DB row is the source of truth for the library.
  }
}

function serialize(row: MediaAsset) {
  return {
    id: row.id,
    filename: row.filename,
    originalName: row.originalName,
    mimeType: row.mimeType,
    size: row.size,
    width: row.width,
    height: row.height,
    url: row.url,
    folderId: row.folderId,
    alt: row.alt,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function uniqueIds(ids: string[]) {
  return [...new Set(ids.map((id) => id.trim()).filter(Boolean))].slice(0, 200);
}

export class MediaService {
  private async siteAndMediaSettings() {
    const site = await requirePrimarySite();
    const opts = readOptions(site.settings?.options);
    const media = opts.media ? parseMediaSettings(opts.media) : defaultMediaSettings();
    return { site, media };
  }

  private assertFolder(media: MediaSettingsOption, folderId: string) {
    if (!media.folders.some((f) => f.id === folderId)) throw BadRequest('Unknown media folder.');
  }

  async list(folderId?: string | null) {
    try {
      const { site, media } = await this.siteAndMediaSettings();
      const where =
        folderId === undefined
          ? { siteId: site.id }
          : folderId === '' || folderId === 'null' || folderId === null
            ? { siteId: site.id, folderId: null }
            : { siteId: site.id, folderId };
      const rows = await MediaAsset.findAll({ where, order: [['createdAt', 'DESC']] });
      return { items: rows.map(serialize), folders: media.folders };
    } catch (error) {
      throw toHttpError(error, 'Could not load the media library.');
    }
  }

  async upload(input: UploadInput) {
    try {
      const mime = (input.mimeType || '').toLowerCase().split(';')[0].trim();
      if (!ALLOWED_MIME.has(mime)) {
        throw BadRequest(
          'Unsupported file type. Use an image (JPEG, PNG, WebP, GIF, SVG, ICO), PDF, Office document, ZIP, CSV/TXT, MP4/WebM or MP3/WAV.',
        );
      }
      if (!input.buffer?.length) throw BadRequest('Empty file.');
      if (input.buffer.length > MAX_UPLOAD_BYTES) throw BadRequest('File too large (max 20 MB).');

      const { site, media } = await this.siteAndMediaSettings();
      const purpose: UploadPurpose = input.purpose === 'favicon' ? 'favicon' : 'media';
      if (input.folderId) this.assertFolder(media, input.folderId);

      const processed = await this.processBuffer(input.buffer, mime, purpose, media);
      const now = new Date();
      const yyyy = String(now.getFullYear());
      const mm = String(now.getMonth() + 1).padStart(2, '0');
      const filename = `${sanitizeBaseName(input.filename)}-${createId()}${processed.ext}`;
      const storagePath = join(yyyy, mm, filename);
      const abs = uploadsPath(storagePath);
      if (!abs) throw BadRequest('Invalid upload path.');
      await mkdir(dirname(abs), { recursive: true });
      await writeFile(abs, processed.buffer, { flag: 'wx' });

      try {
        const row = await MediaAsset.create({
          siteId: site.id,
          filename,
          originalName: input.filename.slice(0, 255),
          mimeType: processed.mimeType,
          size: processed.buffer.length,
          width: processed.width,
          height: processed.height,
          url: `/uploads/${yyyy}/${mm}/${filename}`,
          storagePath: storagePath.replace(/\\/g, '/'),
          folderId: input.folderId || null,
          alt: (input.alt ?? '').slice(0, 500),
          uploadedById: input.uploadedById || null,
        });
        return { item: serialize(row) };
      } catch (e) {
        await removeStoredFile(storagePath);
        throw e;
      }
    } catch (error) {
      throw toHttpError(error, 'Could not upload the file.');
    }
  }

  private async processBuffer(
    buffer: Buffer,
    mime: string,
    purpose: UploadPurpose,
    media: MediaSettingsOption,
  ): Promise<{
    buffer: Buffer;
    mimeType: string;
    ext: string;
    width: number | null;
    height: number | null;
  }> {
    if (PASS_THROUGH.has(mime) || FILE_EXT[mime]) {
      if (
        mime === 'image/svg+xml' &&
        !/<svg[\s>]/i.test(buffer.subarray(0, 4096).toString('utf8'))
      ) {
        throw BadRequest('File content does not match its type.');
      }
      return { buffer, mimeType: mime, ext: extForMime(mime, ''), width: null, height: null };
    }

    try {
      let pipeline = sharp(buffer, { animated: mime === 'image/gif' }).rotate();
      const meta = await pipeline.metadata();
      const width = meta.width ?? null;
      const height = meta.height ?? null;

      const maxW = purpose === 'favicon' ? 512 : media.maxWidth;
      const maxH = purpose === 'favicon' ? 512 : media.maxHeight;
      if (width && height && (width > maxW || height > maxH)) {
        pipeline = pipeline.resize({
          width: maxW,
          height: maxH,
          fit: 'inside',
          withoutEnlargement: true,
        });
      }

      // Re-encoding via sharp strips EXIF/IPTC (stripMetadata is on by default).
      void media.stripMetadata;

      // Favicons stay PNG: browsers prefer PNG/ICO over WebP for tab icons.
      if (purpose === 'favicon') {
        const out = await pipeline
          .png({ compressionLevel: 9 })
          .toBuffer({ resolveWithObject: true });
        return {
          buffer: out.data,
          mimeType: 'image/png',
          ext: '.png',
          width: out.info.width,
          height: out.info.height,
        };
      }

      if (media.convertToWebp) {
        const out = await pipeline
          .webp(media.webpLossless ? { lossless: true } : { quality: media.webpQuality, effort: 4 })
          .toBuffer({ resolveWithObject: true });
        return {
          buffer: out.data,
          mimeType: 'image/webp',
          ext: '.webp',
          width: out.info.width,
          height: out.info.height,
        };
      }

      const out = await pipeline.toBuffer({ resolveWithObject: true });
      return {
        buffer: out.data,
        mimeType: mime,
        ext: extForMime(mime, ''),
        width: out.info.width ?? width,
        height: out.info.height ?? height,
      };
    } catch {
      throw BadRequest('File content does not match its type.');
    }
  }

  async update(id: string, data: { alt?: string; folderId?: string | null }) {
    try {
      const { site, media } = await this.siteAndMediaSettings();
      const existing = await MediaAsset.findOne({ where: { id, siteId: site.id } });
      if (!existing) throw NotFound('Media not found');

      if (data.folderId) this.assertFolder(media, data.folderId);

      const patch: { alt?: string; folderId?: string | null } = {};
      if (data.alt !== undefined) patch.alt = data.alt.slice(0, 500);
      if (data.folderId !== undefined) patch.folderId = data.folderId || null;

      await MediaAsset.update(patch, { where: { id: existing.id } });
      await existing.reload();
      return { item: serialize(existing) };
    } catch (error) {
      throw toHttpError(error, 'Could not update the media item.');
    }
  }

  async remove(id: string) {
    try {
      const { site } = await this.siteAndMediaSettings();
      const existing = await MediaAsset.findOne({ where: { id, siteId: site.id } });
      if (!existing) throw NotFound('Media not found');

      await existing.destroy();
      await removeStoredFile(existing.storagePath);
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not delete the media item.');
    }
  }

  async bulkMove(ids: string[], folderId: string | null | undefined) {
    try {
      const { site, media } = await this.siteAndMediaSettings();
      const selected = uniqueIds(ids);
      if (!selected.length) throw BadRequest('No media selected.');

      let nextFolder: string | null = null;
      if (folderId) {
        this.assertFolder(media, folderId);
        nextFolder = folderId;
      }

      const [updated] = await MediaAsset.update(
        { folderId: nextFolder },
        { where: { siteId: site.id, id: { [Op.in]: selected } } },
      );
      return { ok: true, updated };
    } catch (error) {
      throw toHttpError(error, 'Could not move the selected media.');
    }
  }

  async bulkRemove(ids: string[]) {
    try {
      const { site } = await this.siteAndMediaSettings();
      const selected = uniqueIds(ids);
      if (!selected.length) throw BadRequest('No media selected.');

      const rows = await MediaAsset.findAll({
        where: { siteId: site.id, id: { [Op.in]: selected } },
      });
      await MediaAsset.destroy({
        where: { siteId: site.id, id: { [Op.in]: rows.map((r) => r.id) } },
      });
      for (const row of rows) await removeStoredFile(row.storagePath);
      return { ok: true, deleted: rows.length };
    } catch (error) {
      throw toHttpError(error, 'Could not delete the selected media.');
    }
  }
}

export const mediaService = new MediaService();
