import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { config } from '../config/env';
import { getSelfUrl } from '../config/runtime';
import { resolveUploadsRoot } from '../lib/media/media.paths';
import { BadRequest, toHttpError } from '../utils/http-error';
import { requirePrimarySite } from './site-context';

export type BeeSeoIssueSeverity = 'critical' | 'warning' | 'info';

export type BeeSeoIssueGroup = {
  severity: BeeSeoIssueSeverity;
  ruleId: string;
  title: string;
  message: string;
  pageCount: number;
  pages: string[];
};

export type BeeSeoPageRow = {
  url: string;
  path: string;
  status: number;
  title: string;
  h1: number;
  words: number;
  imagesWithAlt: number;
  imagesTotal: number;
  speedMs: number;
  redirectTo?: string;
};

export type BeeSeoAuditResponse = {
  /** Cache/payload shape version — bump when fields change. */
  version: 2;
  url: string;
  path: string;
  overallScore: number;
  crawledPages: number;
  timestamp: string;
  summary: {
    pass: number;
    warn: number;
    fail: number;
    notMeasured: number;
    issues: number;
    critical: number;
    warning: number;
    info: number;
  };
  issueGroups: BeeSeoIssueGroup[];
  pages: BeeSeoPageRow[];
  cached: boolean;
};

const CACHE_VERSION = 2 as const;
const STALE_MS = 12 * 60 * 60 * 1000;
const MAX_PAGES = 30;
const CRAWL_CONCURRENCY = 3;

type BeeSeoModule = typeof import('@beekiri/beeseo');

let memoryCache: BeeSeoAuditResponse | null = null;
let inFlight: Promise<BeeSeoAuditResponse> | null = null;

function siteBaseUrl(): string {
  const base = (config.urls.app ?? getSelfUrl())?.replace(/\/$/, '');
  if (!base) throw BadRequest('The site is not running yet.');
  return base;
}

function cacheFilePath(): string {
  return join(resolveUploadsRoot(), '..', 'cache', 'bee-seo-audit.json');
}

function loadBeeSeo(): Promise<BeeSeoModule> {
  // eslint-disable-next-line @typescript-eslint/no-implied-eval -- intentional: preserve ESM import under CJS emit
  return new Function('return import("@beekiri/beeseo")')() as Promise<BeeSeoModule>;
}

function normalizePath(path = '/'): string {
  const clean = (path || '/').trim() || '/';
  return clean.startsWith('/') ? clean : `/${clean}`;
}

function isFresh(report: BeeSeoAuditResponse): boolean {
  if (report.version !== CACHE_VERSION) return false;
  const t = Date.parse(report.timestamp);
  if (!Number.isFinite(t)) return false;
  return Date.now() - t < STALE_MS;
}

function pathOf(url: string, base: string): string {
  try {
    const u = new URL(url);
    const b = new URL(base);
    if (u.origin !== b.origin) return u.pathname || '/';
    return `${u.pathname}${u.search}` || '/';
  } catch {
    return url;
  }
}

function normalizeMessage(message: string): string {
  return message.replace(/(?<![A-Za-z0-9])\d+(?:\.\d+)?/g, 'N');
}

function pageOf(details?: Record<string, unknown>): string | null {
  if (!details) return null;
  for (const field of ['pageUrl', 'url'] as const) {
    const value = details[field];
    if (typeof value === 'string' && value.startsWith('http')) return value;
  }
  return null;
}

async function readDiskCache(): Promise<BeeSeoAuditResponse | null> {
  try {
    const raw = await readFile(cacheFilePath(), 'utf8');
    const parsed = JSON.parse(raw) as BeeSeoAuditResponse;
    if (parsed?.version !== CACHE_VERSION || typeof parsed.overallScore !== 'number') return null;
    return { ...parsed, cached: true };
  } catch {
    return null;
  }
}

async function writeDiskCache(report: BeeSeoAuditResponse): Promise<void> {
  const file = cacheFilePath();
  await mkdir(dirname(file), { recursive: true });
  const { cached: _c, ...payload } = report;
  await writeFile(file, JSON.stringify({ ...payload, cached: true }), 'utf8');
}

async function inventoryPages(urls: string[], base: string): Promise<BeeSeoPageRow[]> {
  const cheerio = await import('cheerio');
  const rows: BeeSeoPageRow[] = [];

  await Promise.all(
    urls.map(async (url) => {
      const started = Date.now();
      try {
        const res = await fetch(url, {
          redirect: 'manual',
          signal: AbortSignal.timeout(15_000),
          headers: { 'user-agent': 'BeekiriBeeSeo/1.0' },
        });
        const speedMs = Date.now() - started;
        const status = res.status;
        const path = pathOf(url, base);

        if (status >= 300 && status < 400) {
          const loc = res.headers.get('location') || '';
          let redirectTo = loc;
          try {
            redirectTo = pathOf(new URL(loc, url).href, base);
          } catch {
            /* keep raw */
          }
          rows.push({
            url,
            path,
            status,
            title: redirectTo ? `→ ${redirectTo}` : '-',
            h1: 0,
            words: 0,
            imagesWithAlt: 0,
            imagesTotal: 0,
            speedMs,
            redirectTo,
          });
          return;
        }

        if (status >= 400 || !res.headers.get('content-type')?.includes('html')) {
          rows.push({
            url,
            path,
            status,
            title: '-',
            h1: 0,
            words: 0,
            imagesWithAlt: 0,
            imagesTotal: 0,
            speedMs,
          });
          return;
        }

        const html = await res.text();
        const $ = cheerio.load(html);
        const title = ($('title').first().text() || '').replace(/\s+/g, ' ').trim() || '-';
        const h1 = $('h1').length;
        const text = $('body').text().replace(/\s+/g, ' ').trim();
        const words = text ? text.split(' ').filter(Boolean).length : 0;
        const images = $('img').toArray();
        const imagesTotal = images.length;
        const imagesWithAlt = images.filter((el) => {
          const alt = $(el).attr('alt');
          return typeof alt === 'string' && alt.trim().length > 0;
        }).length;

        rows.push({
          url,
          path,
          status,
          title,
          h1,
          words,
          imagesWithAlt,
          imagesTotal,
          speedMs,
        });
      } catch {
        rows.push({
          url,
          path: pathOf(url, base),
          status: 0,
          title: '-',
          h1: 0,
          words: 0,
          imagesWithAlt: 0,
          imagesTotal: 0,
          speedMs: Date.now() - started,
        });
      }
    }),
  );

  rows.sort((a, b) => a.path.localeCompare(b.path));
  return rows;
}

async function runAudit(path: string): Promise<BeeSeoAuditResponse> {
  await requirePrimarySite();
  const base = siteBaseUrl();
  const cleanPath = normalizePath(path);
  const url = `${base}${cleanPath === '/' ? '' : cleanPath}` || base;

  const { createAuditor, getRuleById } = await loadBeeSeo();
  const auditor = createAuditor({ measureCwv: false });
  const result = await auditor.auditWithCrawl(url, MAX_PAGES, CRAWL_CONCURRENCY);

  type Agg = {
    severity: BeeSeoIssueSeverity;
    ruleId: string;
    title: string;
    message: string;
    pages: Set<string>;
  };
  const byKey = new Map<string, Agg>();

  let pass = 0;
  let warn = 0;
  let fail = 0;
  let notMeasured = 0;

  for (const cat of result.categoryResults) {
    for (const row of cat.results) {
      if (row.status === 'pass') {
        pass += 1;
        continue;
      }
      if (row.status === 'not-measured') {
        notMeasured += 1;
        continue;
      }
      if (row.status === 'warn') warn += 1;
      if (row.status === 'fail') fail += 1;

      const weight = getRuleById(row.ruleId)?.weight ?? 1;
      const severity: BeeSeoIssueSeverity =
        row.status === 'fail' ? 'critical' : weight >= 8 ? 'warning' : 'info';
      const title = getRuleById(row.ruleId)?.name ?? row.ruleId;
      const key = `${severity}:${row.ruleId}:${normalizeMessage(row.message)}`;
      let group = byKey.get(key);
      if (!group) {
        group = { severity, ruleId: row.ruleId, title, message: row.message, pages: new Set() };
        byKey.set(key, group);
      }
      const page = pageOf(row.details as Record<string, unknown> | undefined);
      if (page) group.pages.add(page);
      else group.pages.add(result.url);
    }
  }

  const rank: Record<BeeSeoIssueSeverity, number> = { critical: 0, warning: 1, info: 2 };
  const issueGroups: BeeSeoIssueGroup[] = [...byKey.values()]
    .map((g) => ({
      severity: g.severity,
      ruleId: g.ruleId,
      title: g.title,
      message: g.message,
      pageCount: Math.max(1, g.pages.size),
      pages: [...g.pages],
    }))
    .sort((a, b) => rank[a.severity] - rank[b.severity] || b.pageCount - a.pageCount);

  const pageUrls = result.coverage?.pages?.length
    ? result.coverage.pages
    : [result.url];
  const pages = await inventoryPages(pageUrls, base);

  const critical = issueGroups.filter((i) => i.severity === 'critical').length;
  const warning = issueGroups.filter((i) => i.severity === 'warning').length;
  const info = issueGroups.filter((i) => i.severity === 'info').length;

  const report: BeeSeoAuditResponse = {
    version: CACHE_VERSION,
    url: result.url,
    path: cleanPath,
    overallScore: result.overallScore,
    crawledPages: result.crawledPages || pages.length,
    timestamp: result.timestamp,
    summary: {
      pass,
      warn,
      fail,
      notMeasured,
      issues: issueGroups.length,
      critical,
      warning,
      info,
    },
    issueGroups,
    pages,
    cached: false,
  };

  memoryCache = { ...report, cached: true };
  void writeDiskCache(report).catch(() => undefined);
  return report;
}

export class BeeSeoService {
  async audit(path = '/') {
    try {
      if (inFlight) return inFlight;
      inFlight = runAudit(normalizePath(path)).finally(() => {
        inFlight = null;
      });
      return await inFlight;
    } catch (error) {
      if ((error as Error)?.name === 'AuditError' || (error as Error)?.name === 'AuditAbortedError') {
        throw BadRequest((error as Error).message || 'Audit failed.');
      }
      throw toHttpError(error, 'Could not run BeeSeo audit.');
    }
  }

  async report(opts: { path?: string; refresh?: boolean } = {}) {
    try {
      const path = normalizePath(opts.path ?? '/');

      if (!opts.refresh) {
        if (memoryCache && memoryCache.path === path && isFresh(memoryCache)) {
          return memoryCache;
        }
        const disk = await readDiskCache();
        if (disk && disk.path === path && isFresh(disk)) {
          memoryCache = disk;
          return disk;
        }
      }

      return await this.audit(path);
    } catch (error) {
      if ((error as Error)?.name === 'AuditError' || (error as Error)?.name === 'AuditAbortedError') {
        throw BadRequest((error as Error).message || 'Audit failed.');
      }
      throw toHttpError(error, 'Could not load BeeSeo report.');
    }
  }

  /** Cached audit only — never starts a crawl (for Domain Overview, etc.). */
  async peekCached(): Promise<BeeSeoAuditResponse | null> {
    if (memoryCache) return memoryCache;
    const disk = await readDiskCache();
    if (disk) memoryCache = disk;
    return disk;
  }
}

export const beeSeoService = new BeeSeoService();
