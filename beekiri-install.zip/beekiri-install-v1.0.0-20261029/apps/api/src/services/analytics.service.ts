import { QueryTypes } from 'sequelize';
import { fetchGa4Bundle } from '../lib/analytics/ga4';
import { parseBeeCookies } from '../lib/site/bee-cookies';
import { countLive, listLive } from '../lib/site/bee-cookies-live';
import {
  parseGoogleAnalytics,
  publicGoogleAnalytics,
  type GoogleAnalyticsOptions,
} from '../lib/site/google-analytics';
import { mergeSiteOptions, readOptions } from '../lib/site/site-options';
import { sequelize } from '../models';
import { BadRequest, toHttpError } from '../utils/http-error';
import type { AnalyticsRange, GoogleAnalyticsSettingsInput } from '../validators/analytics.schema';
import { requirePrimarySite, saveSiteOptions } from './site-context';

export type AnalyticsKpi = {
  value: number;
  prev: number;
  deltaPct: number | null;
};

export type AnalyticsReport = {
  source: 'beekiri' | 'google';
  range: AnalyticsRange;
  tracking: { enabled: boolean; pageViews: boolean };
  /** Users with a heartbeat in the last ~5 minutes (Beekiri only). */
  live: number;
  generatedAt: string;
  kpis: {
    users: AnalyticsKpi;
    newUsers: AnalyticsKpi;
    sessions: AnalyticsKpi;
    views: AnalyticsKpi;
    viewsPerSession: AnalyticsKpi;
    bounceRate: AnalyticsKpi;
    avgDurationSec: AnalyticsKpi;
    engagedSessions: AnalyticsKpi;
  };
  trend: { date: string; users: number; sessions: number; views: number }[];
  pages: { path: string; views: number; users: number }[];
  landing: { path: string; sessions: number }[];
  exits: { path: string; sessions: number }[];
  sources: { name: string; sessions: number }[];
  channels: { name: string; sessions: number }[];
  countries: { code: string; users: number }[];
  devices: { key: string; users: number }[];
  browsers: { name: string; users: number }[];
  os: { name: string; users: number }[];
};

type CountRow = { key: string; n: string | number; extra?: string | number };
type TrendRow = { day: string; users: string | number; sessions: string | number; views: string | number };
type KpiRow = {
  users: string | number;
  newUsers: string | number;
  sessions: string | number;
  views: string | number;
  bounces: string | number;
  engaged: string | number;
  duration: string | number;
};

function num(v: string | number | undefined): number {
  return Number(v) || 0;
}

function delta(curr: number, prev: number): number | null {
  if (prev <= 0) return curr > 0 ? 100 : null;
  return Math.round(((curr - prev) / prev) * 1000) / 10;
}

function kpi(value: number, prev: number): AnalyticsKpi {
  return { value, prev, deltaPct: delta(value, prev) };
}

function rangeWindow(range: AnalyticsRange): { start: Date | null; end: Date; prevStart: Date | null } {
  const end = new Date();
  if (range === 'all') return { start: null, end, prevStart: null };
  const now = new Date();
  let start: Date;
  if (range === 'today') {
    start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  } else {
    const days = range === '7d' ? 7 : range === '90d' ? 90 : 30;
    start = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
  }
  const span = end.getTime() - start.getTime();
  return { start, end, prevStart: new Date(start.getTime() - span) };
}

function gaDates(range: AnalyticsRange): { startDate: string; endDate: string } {
  if (range === 'today') return { startDate: 'today', endDate: 'today' };
  if (range === '7d') return { startDate: '7daysAgo', endDate: 'today' };
  if (range === '90d') return { startDate: '90daysAgo', endDate: 'today' };
  if (range === 'all') return { startDate: '2015-01-01', endDate: 'today' };
  return { startDate: '30daysAgo', endDate: 'today' };
}

function emptyKpis(): AnalyticsReport['kpis'] {
  const z = kpi(0, 0);
  return {
    users: z,
    newUsers: z,
    sessions: z,
    views: z,
    viewsPerSession: z,
    bounceRate: z,
    avgDurationSec: z,
    engagedSessions: z,
  };
}

function emptyReport(
  range: AnalyticsRange,
  source: 'beekiri' | 'google',
  tracking: AnalyticsReport['tracking'],
  live = 0,
): AnalyticsReport {
  return {
    source,
    range,
    tracking,
    live,
    generatedAt: new Date().toISOString(),
    kpis: emptyKpis(),
    trend: [],
    pages: [],
    landing: [],
    exits: [],
    sources: [],
    channels: [],
    countries: [],
    devices: [],
    browsers: [],
    os: [],
  };
}

const SESSION_SQL = `
  WITH ordered AS (
    SELECT
      v.*,
      LAG(v."createdAt") OVER (PARTITION BY v."visitorId" ORDER BY v."createdAt") AS prev_at
    FROM "BeeCookieVisit" v
    WHERE v."siteId" = :siteId
      AND (:since::timestamptz IS NULL OR v."createdAt" >= :since)
      AND (:until::timestamptz IS NULL OR v."createdAt" < :until)
  ),
  flagged AS (
    SELECT
      o.*,
      CASE
        WHEN o.prev_at IS NULL OR EXTRACT(EPOCH FROM (o."createdAt" - o.prev_at)) > 1800 THEN 1
        ELSE 0
      END AS is_start
    FROM ordered o
  ),
  sessed AS (
    SELECT
      f.*,
      SUM(f.is_start) OVER (PARTITION BY f."visitorId" ORDER BY f."createdAt") AS sess_n
    FROM flagged f
  ),
  sessions AS (
    SELECT
      "visitorId",
      sess_n,
      MIN("createdAt") AS started_at,
      MAX("createdAt") AS ended_at,
      COUNT(*)::int AS views,
      EXTRACT(EPOCH FROM (MAX("createdAt") - MIN("createdAt"))) AS duration,
      (ARRAY_AGG(path ORDER BY "createdAt"))[1] AS landing,
      (ARRAY_AGG(path ORDER BY "createdAt" DESC))[1] AS exit,
      COALESCE((ARRAY_AGG("referrerHost" ORDER BY "createdAt"))[1], 'Direct') AS source,
      COALESCE((ARRAY_AGG(channel ORDER BY "createdAt"))[1], 'Direct') AS channel,
      (ARRAY_AGG(device ORDER BY "createdAt"))[1] AS device,
      COALESCE((ARRAY_AGG(country ORDER BY "createdAt"))[1], 'Unknown') AS country,
      COALESCE((ARRAY_AGG(browser ORDER BY "createdAt"))[1], 'Unknown') AS browser,
      COALESCE((ARRAY_AGG(os ORDER BY "createdAt"))[1], 'Unknown') AS os
    FROM sessed
    GROUP BY "visitorId", sess_n
  )
`;

async function sliceReport(
  siteId: string,
  since: Date | null,
  until: Date | null,
  hourly: boolean,
): Promise<
  Omit<AnalyticsReport, 'source' | 'range' | 'tracking' | 'kpis' | 'live' | 'generatedAt'> & {
    raw: KpiRow | null;
  }
> {
  const params = { siteId, since, until };
  const trunc = hourly ? 'hour' : 'day';
  const [
    kpiRows,
    trend,
    pages,
    landing,
    exits,
    sources,
    channels,
    countries,
    devices,
    browsers,
    os,
  ] = await Promise.all([
    sequelize.query<KpiRow>(
      `${SESSION_SQL}
       SELECT
         (SELECT COUNT(DISTINCT "visitorId") FROM sessions)::int AS users,
         (SELECT COUNT(DISTINCT s."visitorId")
            FROM sessions s
            WHERE NOT EXISTS (
              SELECT 1 FROM "BeeCookieVisit" p
              WHERE p."siteId" = :siteId
                AND p."visitorId" = s."visitorId"
                AND :since::timestamptz IS NOT NULL
                AND p."createdAt" < :since
            )
         )::int AS "newUsers",
         (SELECT COUNT(*) FROM sessions)::int AS sessions,
         (SELECT COALESCE(SUM(views), 0) FROM sessions)::int AS views,
         (SELECT COUNT(*) FROM sessions WHERE views = 1)::int AS bounces,
         (SELECT COUNT(*) FROM sessions WHERE views >= 2 OR duration >= 10)::int AS engaged,
         (SELECT COALESCE(AVG(duration), 0) FROM sessions) AS duration`,
      { replacements: params, type: QueryTypes.SELECT },
    ),
    sequelize.query<TrendRow>(
      `${SESSION_SQL}
       SELECT
         to_char(date_trunc('${trunc}', started_at), CASE WHEN '${trunc}' = 'hour' THEN 'YYYY-MM-DD HH24:00' ELSE 'YYYY-MM-DD' END) AS day,
         COUNT(DISTINCT "visitorId")::int AS users,
         COUNT(*)::int AS sessions,
         COALESCE(SUM(views), 0)::int AS views
       FROM sessions
       GROUP BY 1
       ORDER BY 1`,
      { replacements: params, type: QueryTypes.SELECT },
    ),
    sequelize.query<CountRow>(
      // One view per visitor per page — refreshes / revisits by the same user do not stack.
      `SELECT path AS key,
              COUNT(DISTINCT "visitorId")::int AS n,
              COUNT(DISTINCT "visitorId")::int AS extra
       FROM "BeeCookieVisit"
       WHERE "siteId" = :siteId
         AND (:since::timestamptz IS NULL OR "createdAt" >= :since)
         AND (:until::timestamptz IS NULL OR "createdAt" < :until)
       GROUP BY path
       ORDER BY n DESC
       LIMIT 12`,
      { replacements: params, type: QueryTypes.SELECT },
    ),
    sequelize.query<CountRow>(
      `${SESSION_SQL}
       SELECT landing AS key, COUNT(*)::int AS n
       FROM sessions
       GROUP BY 1
       ORDER BY n DESC
       LIMIT 8`,
      { replacements: params, type: QueryTypes.SELECT },
    ),
    sequelize.query<CountRow>(
      `${SESSION_SQL}
       SELECT exit AS key, COUNT(*)::int AS n
       FROM sessions
       GROUP BY 1
       ORDER BY n DESC
       LIMIT 8`,
      { replacements: params, type: QueryTypes.SELECT },
    ),
    sequelize.query<CountRow>(
      `${SESSION_SQL}
       SELECT source AS key, COUNT(*)::int AS n
       FROM sessions
       GROUP BY 1
       ORDER BY n DESC
       LIMIT 8`,
      { replacements: params, type: QueryTypes.SELECT },
    ),
    sequelize.query<CountRow>(
      `${SESSION_SQL}
       SELECT channel AS key, COUNT(*)::int AS n
       FROM sessions
       GROUP BY 1
       ORDER BY n DESC
       LIMIT 8`,
      { replacements: params, type: QueryTypes.SELECT },
    ),
    sequelize.query<CountRow>(
      `${SESSION_SQL}
       SELECT country AS key, COUNT(DISTINCT "visitorId")::int AS n
       FROM sessions
       GROUP BY 1
       ORDER BY n DESC
       LIMIT 8`,
      { replacements: params, type: QueryTypes.SELECT },
    ),
    sequelize.query<CountRow>(
      `${SESSION_SQL}
       SELECT device AS key, COUNT(DISTINCT "visitorId")::int AS n
       FROM sessions
       GROUP BY 1
       ORDER BY n DESC`,
      { replacements: params, type: QueryTypes.SELECT },
    ),
    sequelize.query<CountRow>(
      `${SESSION_SQL}
       SELECT browser AS key, COUNT(DISTINCT "visitorId")::int AS n
       FROM sessions
       GROUP BY 1
       ORDER BY n DESC
       LIMIT 8`,
      { replacements: params, type: QueryTypes.SELECT },
    ),
    sequelize.query<CountRow>(
      `${SESSION_SQL}
       SELECT os AS key, COUNT(DISTINCT "visitorId")::int AS n
       FROM sessions
       GROUP BY 1
       ORDER BY n DESC
       LIMIT 8`,
      { replacements: params, type: QueryTypes.SELECT },
    ),
  ]);

  return {
    raw: kpiRows[0] ?? null,
    trend: trend.map((r) => ({
      date: r.day,
      users: num(r.users),
      sessions: num(r.sessions),
      views: num(r.views),
    })),
    pages: pages.map((r) => ({ path: r.key, views: num(r.n), users: num(r.extra) })),
    landing: landing.map((r) => ({ path: r.key, sessions: num(r.n) })),
    exits: exits.map((r) => ({ path: r.key, sessions: num(r.n) })),
    sources: sources.map((r) => ({ name: r.key === '(direct)' ? 'Direct' : r.key, sessions: num(r.n) })),
    channels: channels.map((r) => ({ name: r.key || 'Direct', sessions: num(r.n) })),
    countries: countries.map((r) => ({ code: r.key, users: num(r.n) })),
    devices: devices.map((r) => ({ key: r.key, users: num(r.n) })),
    browsers: browsers.map((r) => ({ name: r.key, users: num(r.n) })),
    os: os.map((r) => ({ name: r.key, users: num(r.n) })),
  };
}

function packKpis(curr: KpiRow | null, prev: KpiRow | null): AnalyticsReport['kpis'] {
  const c = {
    users: num(curr?.users),
    newUsers: num(curr?.newUsers),
    sessions: num(curr?.sessions),
    views: num(curr?.views),
    bounces: num(curr?.bounces),
    engaged: num(curr?.engaged),
    duration: num(curr?.duration),
  };
  const p = {
    users: num(prev?.users),
    newUsers: num(prev?.newUsers),
    sessions: num(prev?.sessions),
    views: num(prev?.views),
    bounces: num(prev?.bounces),
    engaged: num(prev?.engaged),
    duration: num(prev?.duration),
  };
  const bounce = c.sessions ? (c.bounces / c.sessions) * 100 : 0;
  const bouncePrev = p.sessions ? (p.bounces / p.sessions) * 100 : 0;
  const vps = c.sessions ? c.views / c.sessions : 0;
  const vpsPrev = p.sessions ? p.views / p.sessions : 0;
  return {
    users: kpi(c.users, p.users),
    newUsers: kpi(c.newUsers, p.newUsers),
    sessions: kpi(c.sessions, p.sessions),
    views: kpi(c.views, p.views),
    viewsPerSession: kpi(Math.round(vps * 10) / 10, Math.round(vpsPrev * 10) / 10),
    bounceRate: kpi(Math.round(bounce * 10) / 10, Math.round(bouncePrev * 10) / 10),
    avgDurationSec: kpi(Math.round(c.duration), Math.round(p.duration)),
    engagedSessions: kpi(c.engaged, p.engaged),
  };
}

function gaKpi(totals: number[], prev: number[]): AnalyticsReport['kpis'] {
  const [users, newUsers, sessions, views, bounceRate, avgDuration, engaged] = totals;
  const [pUsers, pNew, pSess, pViews, pBounce, pDur, pEng] = prev;
  const vps = sessions ? views / sessions : 0;
  const pVps = pSess ? pViews / pSess : 0;
  return {
    users: kpi(users ?? 0, pUsers ?? 0),
    newUsers: kpi(newUsers ?? 0, pNew ?? 0),
    sessions: kpi(sessions ?? 0, pSess ?? 0),
    views: kpi(views ?? 0, pViews ?? 0),
    viewsPerSession: kpi(Math.round(vps * 10) / 10, Math.round(pVps * 10) / 10),
    bounceRate: kpi(Math.round((bounceRate ?? 0) * 1000) / 10, Math.round((pBounce ?? 0) * 1000) / 10),
    avgDurationSec: kpi(Math.round(avgDuration ?? 0), Math.round(pDur ?? 0)),
    engagedSessions: kpi(engaged ?? 0, pEng ?? 0),
  };
}

function formatGaDate(raw: string): string {
  if (/^\d{8}$/.test(raw)) return `${raw.slice(0, 4)}-${raw.slice(4, 6)}-${raw.slice(6, 8)}`;
  return raw;
}

export class AnalyticsService {
  async settings() {
    try {
      const site = await requirePrimarySite();
      return publicGoogleAnalytics(parseGoogleAnalytics(readOptions(site.settings?.options).googleAnalytics));
    } catch (error) {
      throw toHttpError(error, 'Could not load Analytics settings.');
    }
  }

  async updateSettings(body: GoogleAnalyticsSettingsInput) {
    try {
      const site = await requirePrimarySite();
      const current = parseGoogleAnalytics(readOptions(site.settings?.options).googleAnalytics);
      const next: GoogleAnalyticsOptions = parseGoogleAnalytics({
        measurementId: body.measurementId ?? current.measurementId,
        propertyId: body.propertyId ?? current.propertyId,
        serviceAccountJson:
          body.serviceAccountJson && body.serviceAccountJson.trim()
            ? body.serviceAccountJson
            : current.serviceAccountJson,
      });
      await saveSiteOptions(
        site.id,
        mergeSiteOptions(site.settings?.options, { googleAnalytics: next }),
      );
      return publicGoogleAnalytics(next);
    } catch (error) {
      throw toHttpError(error, 'Could not save Analytics settings.');
    }
  }

  async live() {
    try {
      const site = await requirePrimarySite();
      return {
        live: countLive(site.id),
        paths: listLive(site.id),
        generatedAt: new Date().toISOString(),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load live users.');
    }
  }

  /** Aggregated click heatmap for a path (or page list when path omitted). */
  async heatmap(range: AnalyticsRange = '30d', path?: string) {
    try {
      const site = await requirePrimarySite();
      const cookies = parseBeeCookies(readOptions(site.settings?.options).beeCookies);
      const tracking = { enabled: cookies.enabled, pageViews: cookies.trackPageViews };
      const { start } = rangeWindow(range);
      const params = { siteId: site.id, since: start, path: path?.trim() || null };

      const pages = await sequelize.query<{
        path: string;
        clicks: string | number;
        users: string | number;
      }>(
        `SELECT path,
                COUNT(*)::int AS clicks,
                COUNT(DISTINCT "visitorId")::int AS users
         FROM "BeeCookieClick"
         WHERE "siteId" = :siteId
           AND (:since::timestamptz IS NULL OR "createdAt" >= :since)
         GROUP BY path
         ORDER BY clicks DESC
         LIMIT 40`,
        { replacements: params, type: QueryTypes.SELECT },
      );

      const selected = (params.path && params.path.length > 0 ? params.path : null) || pages[0]?.path || '/';

      const points = await sequelize.query<{
        x: string | number;
        y: string | number;
        n: string | number;
      }>(
        `SELECT
           (ROUND(("xPct" / 2.0)::numeric) * 2)::float AS x,
           (ROUND(("yPct" / 2.0)::numeric) * 2)::float AS y,
           COUNT(*)::int AS n
         FROM "BeeCookieClick"
         WHERE "siteId" = :siteId
           AND path = :selected
           AND (:since::timestamptz IS NULL OR "createdAt" >= :since)
         GROUP BY 1, 2
         ORDER BY n DESC
         LIMIT 2500`,
        {
          replacements: { ...params, selected },
          type: QueryTypes.SELECT,
        },
      );

      const total = points.reduce((sum, p) => sum + num(p.n), 0);
      return {
        range,
        tracking,
        path: selected,
        total,
        pages: pages.map((p) => ({
          path: p.path,
          clicks: num(p.clicks),
          users: num(p.users),
        })),
        points: points.map((p) => ({
          x: num(p.x),
          y: num(p.y),
          n: num(p.n),
        })),
        generatedAt: new Date().toISOString(),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load heatmap.');
    }
  }

  async report(range: AnalyticsRange = '30d', source: 'beekiri' | 'google' = 'beekiri') {
    try {
      const site = await requirePrimarySite();
      const opts = readOptions(site.settings?.options);
      const cookies = parseBeeCookies(opts.beeCookies);
      const tracking = { enabled: cookies.enabled, pageViews: cookies.trackPageViews };
      if (source === 'google') {
        return this.googleReport(range, tracking, parseGoogleAnalytics(opts.googleAnalytics), site.id);
      }
      return this.beekiriReport(site.id, range, tracking);
    } catch (error) {
      throw toHttpError(error, 'Could not load analytics.');
    }
  }

  private async beekiriReport(
    siteId: string,
    range: AnalyticsRange,
    tracking: AnalyticsReport['tracking'],
  ): Promise<AnalyticsReport> {
    const { start, end, prevStart } = rangeWindow(range);
    const hourly = range === 'today';
    const curr = await sliceReport(siteId, start, end, hourly);
    const prev =
      prevStart && start ? await sliceReport(siteId, prevStart, start, false) : { raw: null };
    return {
      source: 'beekiri',
      range,
      tracking,
      live: countLive(siteId),
      generatedAt: new Date().toISOString(),
      kpis: packKpis(curr.raw, prev.raw),
      trend: curr.trend,
      pages: curr.pages,
      landing: curr.landing,
      exits: curr.exits,
      sources: curr.sources,
      channels: curr.channels,
      countries: curr.countries,
      devices: curr.devices,
      browsers: curr.browsers,
      os: curr.os,
    };
  }

  private async googleReport(
    range: AnalyticsRange,
    tracking: AnalyticsReport['tracking'],
    ga: GoogleAnalyticsOptions,
    siteId: string,
  ): Promise<AnalyticsReport> {
    if (!ga.propertyId || !ga.serviceAccountJson) {
      throw BadRequest('Connect a GA4 property and service account first.');
    }
    const { startDate, endDate } = gaDates(range);
    const bundle = await fetchGa4Bundle(ga.propertyId, ga.serviceAccountJson, startDate, endDate);
    const empty = emptyReport(range, 'google', tracking, countLive(siteId));
    return {
      ...empty,
      kpis: gaKpi(bundle.kpis.totals.length ? bundle.kpis.totals : bundle.kpis.rows[0]?.metrics ?? [], []),
      trend: bundle.trend.rows
        .map((r) => ({
          date: formatGaDate(r.dims[0] ?? ''),
          users: r.metrics[0] ?? 0,
          sessions: r.metrics[1] ?? 0,
          views: r.metrics[2] ?? 0,
        }))
        .sort((a, b) => a.date.localeCompare(b.date)),
      pages: bundle.pages.rows.map((r) => ({
        path: r.dims[0] || '/',
        views: r.metrics[0] ?? 0,
        users: r.metrics[1] ?? 0,
      })),
      landing: bundle.landing.rows.map((r) => ({
        path: r.dims[0] || '/',
        sessions: r.metrics[0] ?? 0,
      })),
      sources: bundle.sources.rows.map((r) => ({
        name: !r.dims[0] || r.dims[0] === '(direct)' ? 'Direct' : r.dims[0],
        sessions: r.metrics[0] ?? 0,
      })),
      countries: bundle.countries.rows.map((r) => ({
        code: r.dims[0] || 'Unknown',
        users: r.metrics[0] ?? 0,
      })),
      devices: bundle.devices.rows.map((r) => ({
        key: r.dims[0] || 'unknown',
        users: r.metrics[0] ?? 0,
      })),
    };
  }
}

export const analyticsService = new AnalyticsService();
