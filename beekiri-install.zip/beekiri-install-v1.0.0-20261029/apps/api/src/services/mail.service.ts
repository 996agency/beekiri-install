import nodemailer from 'nodemailer';
import { config } from '../config/env';
import { toHttpError } from '../utils/http-error';
import { createLogger } from '../utils/logger';

const log = createLogger('mail');

export type MailMessage = { to: string; subject: string; text: string; html?: string };
export type MailResult = { mode: 'dev-sink'; previewLink: string | null } | { mode: 'smtp' };

export class MailService {
  private lastDevLink: string | null = null;

  getLastDevLink(): string | null {
    return this.lastDevLink;
  }

  async sendMail(message: MailMessage): Promise<MailResult> {
    try {
      const { host, port, user, pass, from } = config.mail;
      if (!host) {
        // No SMTP configured: log the message so the link can be copied from the console.
        log.warn(`[dev-mail-sink] to=${message.to} subject=${message.subject}`);
        log.warn(message.text);
        this.lastDevLink = message.text.match(/https?:\/\/\S+/)?.[0] ?? null;
        return { mode: 'dev-sink', previewLink: this.lastDevLink };
      }

      // Port 465 is TLS from the first byte; the submission port (nodemailer's default when
      // SMTP_PORT is unset) must upgrade with STARTTLS.
      const implicitTls = port === 465;
      const transporter = nodemailer.createTransport({
        host,
        port,
        secure: implicitTls,
        requireTLS: !implicitTls && (port ?? 587) === 587,
        auth: user && pass ? { user, pass } : undefined,
      });
      await transporter.sendMail({ from, ...message });
      return { mode: 'smtp' };
    } catch (error) {
      throw toHttpError(error, 'Could not send the email.');
    }
  }
}

export const mailService = new MailService();
