import { listLinkTargets } from '../lib/site/link-targets';
import {
  DEFAULT_FAVICON_PATH,
  defaultMediaSettings,
  defaultMenuItems,
  mergeSiteOptions,
  parseMediaSettings,
  publicMenuItems,
  readOptions,
  resolveFaviconUrl,
} from '../lib/site/site-options';
import {
  DEFAULT_THEME_SLUG,
  getThemeManifest,
  resolveActiveChrome,
} from '../lib/themes/theme-registry';
import { Site, SiteSettings, sequelize } from '../models';
import type { Json } from '../models/_shared';
import { BadRequest, toHttpError } from '../utils/http-error';
import type { UpdateSiteSettingsInput } from '../validators/site.schema';
import { pagesService } from './pages.service';
import { findPrimarySite, requirePrimarySite } from './site-context';

type SitePatch = Partial<{ title: string; tagline: string; language: string }>;
type SettingsPatch = Partial<{
  blogPublic: boolean;
  timezone: string;
  dateFormat: string;
  timeFormat: string;
  options: Json;
}>;

function resolveActiveTheme(raw?: string): string {
  const slug = (raw ?? '').trim() || DEFAULT_THEME_SLUG;
  return getThemeManifest(slug) ? slug : DEFAULT_THEME_SLUG;
}

const runtimeOf = (opts: { frontendRuntime?: string }) =>
  opts.frontendRuntime === 'react' ? ('react' as const) : ('php' as const);

function slugFromLabel(label: string) {
  return label
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 180);
}

function serializeSettings(site: Site) {
  const settings = site.settings ?? null;
  const opts = readOptions(settings?.options);
  return {
    id: site.id,
    title: site.title,
    tagline: site.tagline,
    language: site.language,
    blogPublic: settings?.blogPublic ?? true,
    timezone: settings?.timezone ?? 'UTC',
    dateFormat: settings?.dateFormat ?? 'F j, Y',
    timeFormat: settings?.timeFormat ?? 'g:i a',
    businessName: opts.businessName ?? '',
    businessCategory: opts.businessCategory ?? '',
    businessPhone: opts.businessPhone ?? '',
    businessAddress: opts.businessAddress ?? '',
    businessHours: opts.businessHours ?? '',
    businessImageUrl: opts.businessImageUrl ?? '',
    faviconUrl: opts.faviconUrl ?? '',
    faviconResolved: resolveFaviconUrl(opts.faviconUrl),
    faviconDefault: DEFAULT_FAVICON_PATH,
    permalinkStructure: opts.permalinkStructure ?? 'postname',
    permalinkCustom: opts.permalinkCustom ?? '/%postname%/',
    menuItems: opts.menuItems?.length ? opts.menuItems : defaultMenuItems(),
    frontPageId: opts.frontPageId ?? '',
    frontPageSlug: opts.frontPageSlug ?? '',
    media: opts.media ? parseMediaSettings(opts.media) : defaultMediaSettings(),
    activeTheme: resolveActiveTheme(opts.activeTheme),
    pageEditorStyle: 'beekiricode' as const,
    frontendRuntime: runtimeOf(opts),
  };
}

export class SiteService {
  async linkTargets() {
    try {
      const base = listLinkTargets();
      const site = await Site.findOne({ order: [['createdAt', 'ASC']] });
      if (!site) return base;
      const [pages, posts] = await Promise.all([
        pagesService.listPublishedTargets(site.id, 'page'),
        pagesService.listPublishedTargets(site.id, 'post'),
      ]);
      return { ...base, pages, posts };
    } catch (error) {
      throw toHttpError(error, 'Could not load link targets.');
    }
  }

  /** Lightweight preference for the page editor (editors + admins). */
  async pageEditor() {
    try {
      const site = await findPrimarySite();
      return {
        pageEditorStyle: 'beekiricode' as const,
        frontendRuntime: runtimeOf(readOptions(site?.settings?.options)),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load page editor settings.');
    }
  }

  async publicSite() {
    try {
      const site = await findPrimarySite();
      if (!site) return { installed: false };
      const opts = readOptions(site.settings?.options);
      const theme = resolveActiveTheme(opts.activeTheme);
      return {
        installed: true,
        id: site.id,
        title: site.title,
        tagline: site.tagline,
        language: site.language,
        blogPublic: site.settings?.blogPublic ?? true,
        business: {
          name: (opts.businessName || site.title).trim(),
          category: opts.businessCategory ?? '',
          phone: opts.businessPhone ?? '',
          address: opts.businessAddress ?? '',
          hours: opts.businessHours ?? '',
          imageUrl: opts.businessImageUrl ?? '',
        },
        faviconUrl: resolveFaviconUrl(opts.faviconUrl),
        permalinkStructure: opts.permalinkStructure ?? 'postname',
        theme,
        header: resolveActiveChrome(theme, 'header', opts.activeHeader)?.slug ?? null,
        footer: resolveActiveChrome(theme, 'footer', opts.activeFooter)?.slug ?? null,
        frontendRuntime: runtimeOf(opts),
        frontPageId: opts.frontPageId ?? null,
        frontPageSlug: opts.frontPageSlug ?? null,
        menu: publicMenuItems(opts),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load the site.');
    }
  }

  async getSettings() {
    try {
      return serializeSettings(await requirePrimarySite());
    } catch (error) {
      throw toHttpError(error, 'Could not load site settings.');
    }
  }

  async updateSettings(body: UpdateSiteSettingsInput) {
    try {
      const site = await requirePrimarySite();

      const currentRuntime = readOptions(site.settings?.options).frontendRuntime ?? 'php';
      if (body.frontendRuntime !== undefined && body.frontendRuntime !== currentRuntime) {
        throw BadRequest({
          message:
            `This site was installed with the ${currentRuntime.toUpperCase()} frontend. ` +
            'The frontend runtime is locked after install. To use a different one, install a new site into an empty database.',
          code: 'frontend_runtime_locked',
        });
      }

      const nextOptions = mergeSiteOptions(site.settings?.options, {
        businessName: body.businessName,
        businessCategory: body.businessCategory,
        businessPhone: body.businessPhone,
        businessAddress: body.businessAddress,
        businessHours: body.businessHours,
        businessImageUrl: body.businessImageUrl,
        faviconUrl: body.faviconUrl,
        permalinkStructure: body.permalinkStructure,
        permalinkCustom: body.permalinkCustom,
        menuItems: body.menuItems,
        frontPageId: body.frontPageId,
        frontPageSlug: body.frontPageSlug,
        media: body.media ? parseMediaSettings(body.media) : undefined,
        pageEditorStyle: body.pageEditorStyle,
      });

      // Keep the front-page pointer in sync with the menu item that owns `/`.
      if (body.menuItems?.length) {
        const front = body.menuItems.find((m) => ((m.path || '').trim() || '/') === '/');
        if (front?.refId) nextOptions.frontPageId = front.refId;
        if (body.frontPageSlug?.trim()) {
          nextOptions.frontPageSlug = body.frontPageSlug.trim();
        } else if (front?.label && !nextOptions.frontPageSlug) {
          nextOptions.frontPageSlug = slugFromLabel(front.label);
        }
      }

      await sequelize.transaction(async (transaction) => {
        const sitePatch: SitePatch = {};
        if (body.title !== undefined) sitePatch.title = body.title;
        if (body.tagline !== undefined) sitePatch.tagline = body.tagline;
        if (body.language !== undefined) sitePatch.language = body.language;
        await Site.update(sitePatch, { where: { id: site.id }, transaction });

        if (site.settings) {
          const patch: SettingsPatch = { options: nextOptions };
          if (body.blogPublic !== undefined) patch.blogPublic = body.blogPublic;
          if (body.timezone !== undefined) patch.timezone = body.timezone;
          if (body.dateFormat !== undefined) patch.dateFormat = body.dateFormat;
          if (body.timeFormat !== undefined) patch.timeFormat = body.timeFormat;
          await SiteSettings.update(patch, { where: { id: site.settings.id }, transaction });
        } else {
          await SiteSettings.create(
            {
              siteId: site.id,
              blogPublic: body.blogPublic ?? true,
              timezone: body.timezone ?? 'UTC',
              dateFormat: body.dateFormat ?? 'F j, Y',
              timeFormat: body.timeFormat ?? 'g:i a',
              options: nextOptions,
            },
            { transaction },
          );
        }
      });

      return serializeSettings(await requirePrimarySite());
    } catch (error) {
      throw toHttpError(error, 'Could not save site settings.');
    }
  }
}

export const siteService = new SiteService();
