import * as cheerio from 'cheerio';
import { BadRequest, toHttpError } from '../utils/http-error';

export type KeywordIntent = 'nav' | 'info' | 'comm' | 'trans';

export type KeywordRow = {
  keyword: string;
  volume: number | null;
  cpc: number | null;
  competition: number | null;
  score: number;
  intent: KeywordIntent;
};

export type SerpRow = {
  position: number;
  title: string;
  url: string;
  domain: string;
};

export type KeywordResearchResponse = {
  query: string;
  country: string;
  city: string;
  seed: KeywordRow;
  keywords: KeywordRow[];
  trends: { label: string; values: number[] };
  serp: SerpRow[];
};

const COUNTRY_GL: Record<string, string> = {
  US: 'us',
  GB: 'gb',
  DE: 'de',
  FR: 'fr',
  CA: 'ca',
  AU: 'au',
  NL: 'nl',
  ES: 'es',
  IT: 'it',
};

function guessIntent(keyword: string): KeywordIntent {
  const k = keyword.toLowerCase();
  if (/\b(login|log in|sign[\s-]?in|signin|account|dashboard|app)\b/.test(k)) return 'nav';
  if (/\b(buy|price|pricing|cost|cheap|deal|order|discount|coupon)\b/.test(k)) return 'trans';
  if (/\b(best|vs|versus|review|compare|alternative|top)\b/.test(k)) return 'comm';
  if (/\b(how|what|why|guide|tutorial|meaning|definition|examples)\b/.test(k)) return 'info';
  return 'info';
}

/** Difficulty-ish 1–100 from length / word count (not real KD). */
function guessScore(keyword: string): number {
  const words = keyword.trim().split(/\s+/).filter(Boolean).length;
  const len = keyword.trim().length;
  const base = Math.min(92, 18 + words * 12 + Math.floor(len / 3));
  return Math.max(8, Math.min(95, base));
}

function toRow(keyword: string): KeywordRow {
  return {
    keyword,
    volume: null,
    cpc: null,
    competition: null,
    score: guessScore(keyword),
    intent: guessIntent(keyword),
  };
}

function trendLabels(): string[] {
  const out: string[] = [];
  const now = new Date();
  for (let i = 11; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    out.push(d.toLocaleString('en', { month: 'short', year: '2-digit' }));
  }
  return out;
}

/** Soft synthetic trend shape so the chart matches the UI (not real search volume). */
function syntheticTrend(seed: string): number[] {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  const mid = 40 + (h % 40);
  return Array.from({ length: 12 }, (_, i) => {
    const wave = Math.sin((i / 11) * Math.PI * 2 + (h % 7)) * 12;
    return Math.max(8, Math.round(mid + wave - i * 0.8));
  });
}

async function googleSuggestions(query: string, gl: string): Promise<string[]> {
  const url = new URL('https://suggestqueries.google.com/complete/search');
  url.searchParams.set('client', 'firefox');
  url.searchParams.set('hl', 'en');
  url.searchParams.set('gl', gl);
  url.searchParams.set('q', query);

  const res = await fetch(url, {
    signal: AbortSignal.timeout(12_000),
    headers: { 'user-agent': 'BeekiriBeeSeo/1.0' },
  });
  if (!res.ok) throw new Error(`Suggest failed (${res.status})`);
  const data = (await res.json()) as unknown;
  if (!Array.isArray(data) || !Array.isArray(data[1])) return [];
  return (data[1] as unknown[])
    .filter((x): x is string => typeof x === 'string' && x.trim().length > 0)
    .map((x) => x.trim());
}

async function duckDuckGoSerp(query: string): Promise<SerpRow[]> {
  const url = new URL('https://html.duckduckgo.com/html/');
  url.searchParams.set('q', query);
  const res = await fetch(url, {
    signal: AbortSignal.timeout(15_000),
    headers: {
      'user-agent':
        'Mozilla/5.0 (compatible; BeekiriBeeSeo/1.0; +https://beekiri.com)',
      accept: 'text/html',
    },
  });
  if (!res.ok) return [];
  const html = await res.text();
  const $ = cheerio.load(html);
  const rows: SerpRow[] = [];
  $('.result').each((_, el) => {
    if (rows.length >= 20) return;
    const a = $(el).find('a.result__a').first();
    const href = a.attr('href') || '';
    const title = a.text().replace(/\s+/g, ' ').trim();
    if (!title || !href) return;
    let finalUrl = href;
    try {
      const u = new URL(href, 'https://duckduckgo.com');
      const uddg = u.searchParams.get('uddg');
      if (uddg) finalUrl = decodeURIComponent(uddg);
    } catch {
      /* keep */
    }
    let domain = finalUrl;
    try {
      domain = new URL(finalUrl).hostname.replace(/^www\./, '');
    } catch {
      /* keep */
    }
    rows.push({ position: rows.length + 1, title, url: finalUrl, domain });
  });
  return rows;
}

export class BeeSeoKeywordsService {
  async research(input: { query: string; country?: string; city?: string }) {
    try {
      const query = input.query.trim();
      if (!query) throw BadRequest('Enter a keyword to research.');
      const country = (input.country || 'US').toUpperCase();
      const gl = COUNTRY_GL[country] ?? 'us';
      const city = (input.city || '').trim();
      const suggestQ = city ? `${query} ${city}` : query;

      const [suggestions, serp] = await Promise.all([
        googleSuggestions(suggestQ, gl).catch(() => [] as string[]),
        duckDuckGoSerp(query).catch(() => [] as SerpRow[]),
      ]);

      const seen = new Set<string>();
      const keywords: KeywordRow[] = [];
      const push = (kw: string) => {
        const key = kw.toLowerCase();
        if (seen.has(key)) return;
        seen.add(key);
        keywords.push(toRow(kw));
      };
      push(query);
      for (const s of suggestions) push(s);

      // Expand with a few “modifier” ideas when suggest returns little.
      if (keywords.length < 12) {
        for (const mod of ['login', 'pricing', 'vs', 'review', 'app', 'template', 'guide']) {
          push(`${query} ${mod}`);
        }
      }

      const seed = keywords[0] ?? toRow(query);

      return {
        query,
        country,
        city,
        seed,
        keywords,
        trends: { label: trendLabels().join(' · '), values: syntheticTrend(query) },
        serp,
      } satisfies KeywordResearchResponse;
    } catch (error) {
      throw toHttpError(error, 'Could not run keyword research.');
    }
  }
}

export const beeSeoKeywordsService = new BeeSeoKeywordsService();
