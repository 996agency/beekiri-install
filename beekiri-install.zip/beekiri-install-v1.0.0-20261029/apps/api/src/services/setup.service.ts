import { chmodSync, existsSync, readFileSync, writeFileSync } from 'fs';
import { join } from 'path';
import { Client, type ClientConfig } from 'pg';
import { config } from '../config/env';
import { API_ROOT } from '../config/paths';
import { getSelfUrl } from '../config/runtime';
import { randomToken } from '../utils/crypto';
import { BadRequest, Conflict, toHttpError } from '../utils/http-error';
import { isLoopbackOrigin } from '../utils/loopback';
import { requestRestart } from '../utils/restart';
import type { DatabaseSetupInput } from '../validators/install.schema';

const ENV_FILE = join(API_ROOT, '.env');
const SAFE_VALUE = /^[A-Za-z0-9_.,:@/+=-]*$/;

/** A value dotenv reads back exactly: bare when simple, otherwise in a quote it doesn't contain. */
function envValue(value: string): string {
  if (SAFE_VALUE.test(value)) return value;
  for (const quote of ["'", '`', '"']) {
    if (!value.includes(quote) && !(quote === '"' && /\\[nr]/.test(value))) {
      return `${quote}${value}${quote}`;
    }
  }
  throw BadRequest('That password uses a mix of quote characters the settings file cannot store.');
}

/** Set keys in apps/api/.env, keeping every other line (and comment) as it is. */
function writeEnv(values: Record<string, string | undefined>): void {
  const lines = existsSync(ENV_FILE) ? readFileSync(ENV_FILE, 'utf8').split('\n') : [];
  const pending = new Map(Object.entries(values).filter(([, v]) => v !== undefined));
  const out = lines.map((line) => {
    const key = /^\s*([A-Z0-9_]+)\s*=/.exec(line)?.[1];
    if (!key || !pending.has(key)) return line;
    const value = pending.get(key)!;
    pending.delete(key);
    return `${key}=${envValue(value)}`;
  });
  if (pending.size) {
    if (out.length && out[out.length - 1].trim()) out.push('');
    out.push('# Saved by the Beekiri setup wizard.');
    for (const [key, value] of pending) out.push(`${key}=${envValue(value!)}`);
  }
  writeFileSync(ENV_FILE, `${out.join('\n').replace(/\n*$/, '')}\n`);
  chmodSync(ENV_FILE, 0o600);
}

/** Plain-language reasons for the connection errors people actually hit. */
function explain(error: unknown, input: DatabaseSetupInput): string {
  const e = error as { code?: string; message?: string };
  const where = `${input.host || 'the local server'}${input.port ? `:${input.port}` : ''}`;
  switch (e.code) {
    case 'ECONNREFUSED':
    case 'ENOENT':
      return `PostgreSQL is not answering at ${where}. Is it installed and running?`;
    case 'ENOTFOUND':
    case 'EAI_AGAIN':
      return `The database host "${input.host}" could not be found.`;
    case 'ETIMEDOUT':
      return `Timed out reaching ${where}. Check the host, port and any firewall.`;
    case '28P01':
      return 'The database password is wrong.';
    case '28000':
      return `PostgreSQL refused user "${input.user}". Check the user name.`;
    case '42501':
      return `User "${input.user}" may not create databases. Create "${input.name}" first, or use another user.`;
    default:
      return `Could not connect to the database: ${e.message ?? 'unknown error'}`;
  }
}

function clientConfig(input: DatabaseSetupInput, database: string): ClientConfig {
  return {
    host: input.host || undefined,
    port: input.port,
    database,
    user: input.user,
    password: input.password || undefined,
    ssl:
      !input.ssl || input.ssl === 'disable'
        ? undefined
        : { rejectUnauthorized: input.ssl === 'verify-full' },
    connectionTimeoutMillis: 8_000,
  };
}

async function tryConnect(input: DatabaseSetupInput, database: string): Promise<void> {
  const client = new Client(clientConfig(input, database));
  try {
    await client.connect();
    await client.query('SELECT 1');
  } finally {
    await client.end().catch(() => undefined);
  }
}

/** Create the database through the always-present "postgres" database. */
async function createDatabase(input: DatabaseSetupInput): Promise<void> {
  const client = new Client(clientConfig(input, 'postgres'));
  try {
    await client.connect();
    // The name was validated as a plain identifier, so quoting it is safe.
    await client.query(`CREATE DATABASE "${input.name}"`);
  } finally {
    await client.end().catch(() => undefined);
  }
}

export class SetupService {
  /**
   * Setup wizard, database step: test the details, create the database if needed, save
   * apps/api/.env and restart so the server comes back with the database connected.
   */
  async configureDatabase(input: DatabaseSetupInput, meta: { siteUrl: string }) {
    if (config.databaseConfigured) {
      throw Conflict({
        message: 'The database is already configured.',
        code: 'database_configured',
      });
    }
    try {
      let created = false;
      try {
        await tryConnect(input, input.name);
      } catch (error) {
        if ((error as { code?: string }).code !== '3D000') throw BadRequest(explain(error, input));
        // 3D000: the database does not exist yet.
        try {
          await createDatabase(input);
          await tryConnect(input, input.name);
          created = true;
        } catch (createError) {
          throw BadRequest(explain(createError, input));
        }
      }

      const selfPort = getSelfUrl() ? new URL(getSelfUrl()!).port : undefined;
      writeEnv({
        DB_HOST: input.host || undefined,
        DB_PORT: input.port ? String(input.port) : undefined,
        DB_NAME: input.name,
        DB_USER: input.user,
        DB_PASSWORD: input.password ?? '',
        DB_SSL: input.ssl && input.ssl !== 'disable' ? input.ssl : undefined,
        // Keep today's address: same port after the restart, and the site URL for links.
        // A local address is not saved: unset, Beekiri follows whatever port it runs on.
        PORT: config.server.port ? undefined : selfPort,
        APP_URL: config.urls.app || isLoopbackOrigin(meta.siteUrl) ? undefined : meta.siteUrl,
        CACHE_FLUSH_SECRET: config.core.cacheFlushSecret ? undefined : randomToken(32),
      });

      const restarting = requestRestart('database settings saved');
      return { ok: true, created, restarting };
    } catch (error) {
      throw toHttpError(error, 'Could not save the database settings.');
    }
  }
}

export const setupService = new SetupService();
