import { execFile } from 'child_process';
import { existsSync, readFileSync, statSync, writeFileSync } from 'fs';
import { join } from 'path';
import { compile as compileSass } from 'sass';
import { promisify } from 'util';
import { readCacheEpoch } from '../lib/cache-epoch';
import { resolveLayoutRunnerPath } from '../lib/layouts/php/runner-path';
import { minifyJs } from '../lib/minify-assets';
import {
  mergeSiteOptions,
  publicMenuItems,
  readOptions,
  resolveFaviconUrl,
  type MenuItemOption,
  type SiteOptions,
} from '../lib/site/site-options';
import { renderChromeFallbackHtml } from '../lib/themes/chrome-fallback';
import {
  DEFAULT_THEME_SLUG,
  chromeEntryFile,
  getThemeManifest,
  listThemeChrome,
  resolveActiveChrome,
  sanitizeThemeSlug,
  themeOwningPath,
  type ThemeChromeKind,
  type ThemeChromeOption,
} from '../lib/themes/theme-registry';
import { BadRequest, NotFound, toHttpError } from '../utils/http-error';
import { createLogger } from '../utils/logger';
import { findPrimarySite, saveSiteOptions } from './site-context';

const execFileAsync = promisify(execFile);

const CHROME_ASSETS = {
  'styles.css': 'text/css; charset=utf-8',
  'script.js': 'application/javascript; charset=utf-8',
} as const;

export type ChromeAssetName = keyof typeof CHROME_ASSETS;

export function isChromeAssetName(raw: string): raw is ChromeAssetName {
  return raw in CHROME_ASSETS;
}

/** Client-safe shape (no absolute paths). */
export type ChromeOptionDto = Omit<ThemeChromeOption, 'dir'> & { active: boolean };

export type ChromeListDto = {
  kind: ThemeChromeKind;
  theme: string;
  themeName: string;
  runtime: 'php' | 'react';
  options: ChromeOptionDto[];
  active: string | null;
};

export type ChromeRenderDto = {
  kind: ThemeChromeKind;
  theme: string;
  slug: string | null;
  runtime: 'php' | 'react';
  /** Folder under the theme (React runtime imports `{theme}/{path}/{slug}.tsx`). */
  path: string | null;
  /** PHP runtime only. */
  html: string | null;
  cssUrl: string | null;
  jsUrl: string | null;
  /** Values the template receives (React props / PHP get_bee_field). */
  data: Record<string, unknown>;
};

const OPTION_KEY: Record<ThemeChromeKind, 'activeHeader' | 'activeFooter'> = {
  header: 'activeHeader',
  footer: 'activeFooter',
};

type SiteRow = {
  id: string;
  title: string;
  tagline: string;
  settings: { blogPublic: boolean; options: unknown } | null;
};

/**
 * Theme chrome = header / footer around every public page.
 * The installed frontend runtime decides which entry file runs:
 *   php   → themes/{theme}/{path}/{slug}.php (Bee field API, rendered here)
 *   react → themes/{theme}/{path}/{slug}.tsx (rendered by the Next.js app)
 */
export class ThemeChromeService {
  private readonly log = createLogger('theme-chrome');

  private async getSite(): Promise<SiteRow | null> {
    const site = await findPrimarySite();
    if (!site) return null;
    return {
      id: site.id,
      title: site.title,
      tagline: site.tagline,
      settings: site.settings
        ? { blogPublic: site.settings.blogPublic, options: site.settings.options }
        : null,
    };
  }

  private themeFor(opts: SiteOptions): string {
    const slug = (opts.activeTheme ?? '').trim() || DEFAULT_THEME_SLUG;
    return getThemeManifest(slug) ? slug : DEFAULT_THEME_SLUG;
  }

  private toDto(option: ThemeChromeOption, active: string | null): ChromeOptionDto {
    const { dir: _dir, ...rest } = option;
    return { ...rest, active: option.slug === active };
  }

  async list(kind: ThemeChromeKind): Promise<ChromeListDto> {
    try {
      const site = await this.getSite();
      const opts = readOptions(site?.settings?.options);
      const theme = this.themeFor(opts);
      const active = resolveActiveChrome(theme, kind, opts[OPTION_KEY[kind]]);
      return {
        kind,
        theme,
        themeName: getThemeManifest(theme)?.name ?? theme,
        runtime: opts.frontendRuntime === 'react' ? 'react' : 'php',
        options: listThemeChrome(theme, kind).map((o) => this.toDto(o, active?.slug ?? null)),
        active: active?.slug ?? null,
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load header/footer options.');
    }
  }

  async activate(kind: ThemeChromeKind, slug: string): Promise<ChromeListDto> {
    try {
      const site = await this.getSite();
      if (!site) throw NotFound('Site not found');
      const opts = readOptions(site.settings?.options);
      const theme = this.themeFor(opts);
      const clean = sanitizeThemeSlug(slug);
      const match = listThemeChrome(theme, kind).find((o) => o.slug === clean);
      if (!match) {
        throw BadRequest(`That ${kind} is not part of the active theme.`);
      }
      const runtime = opts.frontendRuntime === 'react' ? 'react' : 'php';
      if ((runtime === 'php' && !match.hasPhp) || (runtime === 'react' && !match.hasReact)) {
        throw BadRequest(
          `“${match.title}” has no ${runtime === 'php' ? '.php' : '.tsx'} file for this site’s ${runtime.toUpperCase()} frontend.`,
        );
      }

      const nextOptions = mergeSiteOptions(site.settings?.options, {
        [OPTION_KEY[kind]]: match.slug,
      });
      await saveSiteOptions(site.id, nextOptions);
      return await this.list(kind);
    } catch (error) {
      throw toHttpError(error, 'Could not activate the header/footer.');
    }
  }

  /** Data every chrome template receives — fields defaults + site values. */
  private templateData(
    kind: ThemeChromeKind,
    option: ThemeChromeOption,
    site: SiteRow | null,
    opts: SiteOptions,
  ): Record<string, unknown> {
    const defaults: Record<string, unknown> = {};
    for (const field of option.fields) {
      if (field.defaultValue !== undefined) defaults[field.name] = field.defaultValue;
    }
    const toRows = (items: MenuItemOption[]): Record<string, unknown>[] =>
      items.map((m) => ({
        id: m.id,
        label: m.label,
        url: (m.path || '').trim() || '/',
        children: m.children?.length ? toRows(m.children) : [],
      }));
    return {
      ...defaults,
      kind,
      site_title: site?.title?.trim() || 'Beekiri',
      site_tagline: site?.tagline?.trim() || '',
      home_url: '/',
      /** Same asset as the browser tab favicon (Settings → General). */
      logo_url: resolveFaviconUrl(opts.faviconUrl),
      blog_public: site?.settings?.blogPublic ?? true,
      year: new Date().getFullYear(),
      menu: toRows(publicMenuItems(opts)),
    };
  }

  private assetUrl(
    kind: ThemeChromeKind,
    option: ThemeChromeOption,
    file: ChromeAssetName,
    cacheEpoch = 0,
  ) {
    if (!option.dir) return null;
    const sources = file === 'styles.css' ? ['styles.scss', 'styles.css'] : [file];
    const mtimes = sources
      .map((name) => join(option.dir as string, name))
      .filter((p) => existsSync(p))
      .map((p) => Math.floor(statSync(p).mtimeMs));
    if (!mtimes.length) return null;
    const v = Math.max(...mtimes, cacheEpoch > 0 ? cacheEpoch : 0);
    return `/api/themes/chrome/${kind}/asset/${file}?v=${v}`;
  }

  async render(kind: ThemeChromeKind): Promise<ChromeRenderDto> {
    try {
      const site = await this.getSite();
      const opts = readOptions(site?.settings?.options);
      const theme = this.themeFor(opts);
      const runtime = opts.frontendRuntime === 'react' ? 'react' : 'php';
      const option = resolveActiveChrome(theme, kind, opts[OPTION_KEY[kind]]);
      const empty: ChromeRenderDto = {
        kind,
        theme,
        slug: null,
        runtime,
        path: null,
        html: null,
        cssUrl: null,
        jsUrl: null,
        data: {},
      };
      if (!option) return empty;

      const data = this.templateData(kind, option, site, opts);
      const base: ChromeRenderDto = {
        ...empty,
        slug: option.slug,
        path: option.path,
        cssUrl: this.assetUrl(
          kind,
          option,
          'styles.css',
          Math.max(Number(opts.cacheEpoch) || 0, readCacheEpoch()),
        ),
        // React chrome bundles its own behaviour; script.js is the PHP counterpart.
        jsUrl:
          runtime === 'php'
            ? this.assetUrl(
                kind,
                option,
                'script.js',
                Math.max(Number(opts.cacheEpoch) || 0, readCacheEpoch()),
              )
            : null,
        data,
      };
      if (runtime === 'react') {
        const source =
          themeOwningPath(theme, `${option.path}/${option.slug}.tsx`) ||
          themeOwningPath(theme, `${option.path}/${option.kind}.tsx`) ||
          theme;
        return { ...base, theme: source };
      }

      const entry = chromeEntryFile(option, 'php');
      if (!entry) {
        this.log.warn(`No ${kind}.php in ${theme}/${option.path} — using Node chrome fallback.`);
        return { ...base, html: renderChromeFallbackHtml(kind, data) };
      }
      const html = await this.runPhp(entry, data, option.slug);
      if (html && html.trim()) return { ...base, html };
      this.log.warn(`PHP chrome unavailable for ${kind} — using Node fallback.`);
      return { ...base, html: renderChromeFallbackHtml(kind, data) };
    } catch (error) {
      throw toHttpError(error, 'Could not render the header/footer.');
    }
  }

  private async runPhp(
    entry: string,
    data: Record<string, unknown>,
    slug: string,
  ): Promise<string | null> {
    const runner = resolveLayoutRunnerPath();
    if (!runner) {
      this.log.warn('layout-runner.php not found — cannot render PHP theme chrome.');
      return null;
    }
    try {
      const { stdout } = await execFileAsync('php', [runner, entry, JSON.stringify(data), slug], {
        timeout: 8000,
        maxBuffer: 2 * 1024 * 1024,
        env: process.env,
      });
      return typeof stdout === 'string' ? stdout : String(stdout);
    } catch (e) {
      this.log.warn(`PHP chrome render failed for ${entry}: ${(e as Error).message}`);
      return null;
    }
  }

  /** styles.css (recompiled + minified) or script.js (minified) of the active option. */
  async readAsset(
    kind: ThemeChromeKind,
    file: ChromeAssetName,
  ): Promise<{ body: string; contentType: string }> {
    try {
      const site = await this.getSite();
      const opts = readOptions(site?.settings?.options);
      const option = resolveActiveChrome(this.themeFor(opts), kind, opts[OPTION_KEY[kind]]);
      if (!option?.dir) throw NotFound('Asset not found');

      const target = join(option.dir, file);
      if (file === 'styles.css') {
        const scss = join(option.dir, 'styles.scss');
        const minPath = join(option.dir, 'styles.min.css');
        const stale =
          existsSync(scss) &&
          (!existsSync(minPath) ||
            !existsSync(target) ||
            statSync(scss).mtimeMs > statSync(minPath).mtimeMs);
        if (stale && existsSync(scss)) {
          try {
            const expanded = compileSass(scss, { style: 'expanded', charset: false });
            writeFileSync(
              target,
              `/* Compiled from styles.scss — do not edit */\n${expanded.css}`,
              'utf8',
            );
            const min = compileSass(scss, { style: 'compressed', charset: false });
            writeFileSync(minPath, min.css, 'utf8');
          } catch (e) {
            this.log.warn(`SCSS compile failed for ${scss}: ${(e as Error).message}`);
          }
        }
        if (existsSync(minPath)) {
          return { body: readFileSync(minPath, 'utf8'), contentType: CHROME_ASSETS[file] };
        }
      }
      if (!existsSync(target)) throw NotFound('Asset not found');
      const raw = readFileSync(target, 'utf8');
      const body = file === 'script.js' ? minifyJs(raw) : raw;
      return { body, contentType: CHROME_ASSETS[file] };
    } catch (error) {
      throw toHttpError(error, 'Could not read the header/footer asset.');
    }
  }
}

export const themeChromeService = new ThemeChromeService();
