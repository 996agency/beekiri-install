import { mergeSiteOptions, readOptions } from '../lib/site/site-options';
import {
  CONNECTOR_PROVIDER_CATALOG,
  CONNECTOR_PROVIDER_IDS,
  isConnectorProviderId,
  maskApiKey,
  parseConnector,
  type ConnectorOptions,
  type ConnectorProviderId,
} from '../lib/site/connector';
import { BadRequest, NotFound, toHttpError } from '../utils/http-error';
import type { UpdateConnectorInput } from '../validators/connector.schema';
import { requirePrimarySite, saveSiteOptions } from './site-context';

/** BeeQueen: for now, enabling counts as configured (key optional until billing/keys ship). */
function isConfigured(id: ConnectorProviderId, state: ConnectorOptions['providers'][ConnectorProviderId] | undefined) {
  if (id === 'beequeen') {
    return Boolean(state?.enabled) || Boolean(state?.apiKey?.trim());
  }
  return Boolean(state?.apiKey?.trim());
}

function listPublic(opts: ConnectorOptions) {
  return {
    providers: CONNECTOR_PROVIDER_CATALOG.map((p) => {
      const state = opts.providers[p.id];
      return {
        id: p.id,
        name: p.name,
        vendor: p.vendor,
        blurb: p.blurb,
        badge: p.badge,
        enabled: state?.enabled ?? false,
        configured: isConfigured(p.id, state),
        defaultModel: state?.defaultModel ?? p.models[0]?.id ?? '',
      };
    }),
  };
}

function detailPublic(id: ConnectorProviderId, opts: ConnectorOptions) {
  const meta = CONNECTOR_PROVIDER_CATALOG.find((p) => p.id === id);
  if (!meta) throw NotFound('Provider not found.');
  const state = opts.providers[id];
  return {
    id: meta.id,
    name: meta.name,
    vendor: meta.vendor,
    blurb: meta.blurb,
    badge: meta.badge,
    docsUrl: meta.docsUrl,
    apiKeyLabel: meta.apiKeyLabel,
    apiKeyPlaceholder: meta.apiKeyPlaceholder,
    models: meta.models,
    enabled: state?.enabled ?? false,
    configured: isConfigured(id, state),
    apiKeyMasked: maskApiKey(state?.apiKey ?? '') ?? (id === 'beequeen' && state?.enabled ? 'bq-…active' : null),
    defaultModel: state?.defaultModel ?? meta.models[0]?.id ?? '',
  };
}

class ConnectorService {
  async get() {
    try {
      const site = await requirePrimarySite();
      const opts = parseConnector(readOptions(site.settings?.options).connector);
      return listPublic(opts);
    } catch (error) {
      throw toHttpError(error, 'Could not load Connector.');
    }
  }

  async getProvider(providerId: string) {
    try {
      if (!isConnectorProviderId(providerId)) throw NotFound('Provider not found.');
      const site = await requirePrimarySite();
      const opts = parseConnector(readOptions(site.settings?.options).connector);
      return detailPublic(providerId, opts);
    } catch (error) {
      throw toHttpError(error, 'Could not load provider.');
    }
  }

  async update(dto: UpdateConnectorInput) {
    try {
      const site = await requirePrimarySite();
      const current = parseConnector(readOptions(site.settings?.options).connector);
      const next: ConnectorOptions = {
        providers: { ...current.providers },
      };
      for (const id of CONNECTOR_PROVIDER_IDS) {
        next.providers[id] = { ...current.providers[id] };
      }

      const row = { ...next.providers[dto.providerId] };
      if (dto.enabled !== undefined) row.enabled = dto.enabled;
      if (dto.apiKey !== undefined) row.apiKey = dto.apiKey.trim();
      if (dto.defaultModel !== undefined) {
        const allowed = CONNECTOR_PROVIDER_CATALOG.find((p) => p.id === dto.providerId)?.models ?? [];
        if (!allowed.some((m) => m.id === dto.defaultModel)) {
          throw BadRequest('That model is not available for this provider.');
        }
        row.defaultModel = dto.defaultModel;
      }
      // Preview: seed a stub BeeQueen key when turning it on so setup looks active.
      if (
        dto.providerId === 'beequeen' &&
        row.enabled &&
        !row.apiKey.trim()
      ) {
        row.apiKey = 'bq-dev-active';
      }
      next.providers[dto.providerId] = row;

      await saveSiteOptions(
        site.id,
        mergeSiteOptions(site.settings?.options, { connector: next }),
      );

      // List response when only toggling from the grid; detail when setup fields present.
      if (dto.apiKey !== undefined || dto.defaultModel !== undefined) {
        return detailPublic(dto.providerId, next);
      }
      return listPublic(next);
    } catch (error) {
      throw toHttpError(error, 'Could not update Connector.');
    }
  }
}

export const connectorService = new ConnectorService();
