import { Op } from 'sequelize';
import {
  parseFields,
  parseLocation,
  toSlugKey,
  type BackendField,
} from '../lib/fields/fields.types';
import { AuditLog, FieldGroup, Post, Role, User } from '../models';
import type { AuthUser } from '../types/auth';
import { uniqueViolation } from '../utils/db-errors';
import { BadRequest, Conflict, NotFound, toHttpError } from '../utils/http-error';
import { iContains } from '../utils/sql';
import type { CreateFieldGroupInput, UpdateFieldGroupInput } from '../validators/fields.schema';
import { layoutSyncService } from './layout-sync.service';

export type FieldGroupSyncItem = {
  key: string;
  title: string;
  slug: string;
  theme: string;
  updatedAt: string | null;
  /** Not in the database yet. */
  status: 'available' | 'sync';
};

const SLUGLIKE = /^[a-z][a-z0-9_-]*$/;

type FieldGroupChanges = Partial<{
  title: string;
  key: string;
  description: string;
  active: boolean;
  location: string[];
  fields: BackendField[];
}>;

function serialize(group: FieldGroup) {
  const fields = parseFields(group.fields);
  return {
    id: group.id,
    title: group.title,
    key: group.key,
    description: group.description,
    active: group.active,
    location: parseLocation(group.location),
    fields,
    menuOrder: group.menuOrder,
    fieldCount: fields.length,
    trashedAt: group.trashedAt ? group.trashedAt.toISOString() : null,
    createdAt: group.createdAt.toISOString(),
    updatedAt: group.updatedAt.toISOString(),
  };
}

/** A friendly 409 for a duplicate key, otherwise the error unchanged. */
function duplicateKeyError(error: unknown): unknown {
  return uniqueViolation(error) !== null
    ? Conflict('A field group with this key already exists.')
    : error;
}

export class FieldsService {
  async list(actor: AuthUser, opts: { status?: 'all' | 'trash' } = {}) {
    try {
      const trash = opts.status === 'trash';
      const [groups, counts] = await Promise.all([
        FieldGroup.findAll({
          where: {
            siteId: actor.siteId,
            trashedAt: trash ? { [Op.ne]: null } : null,
          },
          order: trash
            ? [['trashedAt', 'DESC']]
            : [
                ['menuOrder', 'ASC'],
                ['createdAt', 'ASC'],
              ],
        }),
        FieldGroup.findAll({
          where: { siteId: actor.siteId },
          attributes: ['id', 'trashedAt'],
        }),
      ]);
      const live = counts.filter((g) => !g.trashedAt).length;
      const trashed = counts.length - live;
      return { groups: groups.map(serialize), counts: { all: live, trash: trashed } };
    } catch (error) {
      throw toHttpError(error, 'Could not load field groups.');
    }
  }

  async get(actor: AuthUser, id: string) {
    try {
      return serialize(await this.findOwned(actor, id));
    } catch (error) {
      throw toHttpError(error, 'Could not load the field group.');
    }
  }

  async create(actor: AuthUser, dto: CreateFieldGroupInput) {
    try {
      const title = dto.title.trim();
      const maxOrder = await FieldGroup.max<number | null, FieldGroup>('menuOrder', {
        where: { siteId: actor.siteId, trashedAt: null },
      });

      const group = await FieldGroup.create({
        siteId: actor.siteId,
        title,
        key: (dto.key?.trim() || toSlugKey(title)).slice(0, 60),
        description: (dto.description ?? '').trim(),
        active: dto.active ?? true,
        location: parseLocation(dto.location ?? ['post', 'page']),
        fields: parseFields(dto.fields ?? []),
        menuOrder: (maxOrder ?? -1) + 1,
        trashedAt: null,
      });

      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'field_group.created',
        meta: { groupId: group.id, key: group.key },
      });

      await layoutSyncService.syncGroupForSite(group);
      return serialize(group);
    } catch (error) {
      throw toHttpError(duplicateKeyError(error), 'Could not create the field group.');
    }
  }

  async update(actor: AuthUser, id: string, dto: UpdateFieldGroupInput) {
    try {
      const existing = await this.findOwned(actor, id);
      if (existing.trashedAt) {
        throw BadRequest('Restore this field group from trash before editing.');
      }
      const previousKey = existing.key;

      const data: FieldGroupChanges = {};
      if (dto.title !== undefined) data.title = dto.title.trim();
      if (dto.key !== undefined) data.key = dto.key.trim();
      if (dto.description !== undefined) data.description = dto.description.trim();
      if (dto.active !== undefined) data.active = dto.active;
      if (dto.location !== undefined) data.location = parseLocation(dto.location);
      if (dto.fields !== undefined) data.fields = parseFields(dto.fields);

      const [, [group]] = await FieldGroup.update(data, {
        where: { id: existing.id },
        returning: true,
      });

      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'field_group.updated',
        meta: { groupId: group.id, key: group.key },
      });

      if (previousKey !== group.key) layoutSyncService.removeByGroupKey(previousKey);
      if (group.active) await layoutSyncService.syncGroupForSite(group);
      else layoutSyncService.removeByGroupKey(group.key);
      return serialize(group);
    } catch (error) {
      throw toHttpError(duplicateKeyError(error), 'Could not update the field group.');
    }
  }

  /** Move to trash (keeps DB row + theme files under layouts/.trash/). */
  async remove(actor: AuthUser, id: string, opts: { force?: boolean } = {}) {
    try {
      const existing = await this.findOwned(actor, id);
      if (opts.force || existing.trashedAt) {
        const key = existing.key;
        await existing.destroy();
        await AuditLog.create({
          siteId: actor.siteId,
          userId: actor.id,
          action: 'field_group.deleted',
          meta: { groupId: existing.id, key, permanent: true },
        });
        layoutSyncService.purgeByGroupKey(key);
        return { ok: true, permanent: true as const };
      }

      await existing.update({ trashedAt: new Date(), active: false });
      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'field_group.trashed',
        meta: { groupId: existing.id, key: existing.key },
      });
      layoutSyncService.trashByGroupKey(existing.key);
      return { ok: true, permanent: false as const };
    } catch (error) {
      throw toHttpError(error, 'Could not move the field group to trash.');
    }
  }

  async restore(actor: AuthUser, id: string) {
    try {
      const existing = await this.findOwned(actor, id);
      if (!existing.trashedAt) {
        throw BadRequest('That field group is not in the trash.');
      }
      await existing.update({ trashedAt: null, active: true });
      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'field_group.restored',
        meta: { groupId: existing.id, key: existing.key },
      });
      layoutSyncService.restoreByGroupKey(existing.key);
      await layoutSyncService.syncGroupForSite(existing);
      return serialize(await this.findOwned(actor, id));
    } catch (error) {
      throw toHttpError(error, 'Could not restore the field group.');
    }
  }

  /** Relational field pickers (post_object / page_link / relationship). */
  async lookupPosts(actor: AuthUser, opts: { types: string[]; q: string; ids: string[] }) {
    try {
      const types = opts.types.filter((t) => SLUGLIKE.test(t)).slice(0, 20);
      const ids = opts.ids.filter(Boolean).slice(0, 100);
      const q = opts.q.trim().slice(0, 100);
      const items = await Post.findAll({
        where: {
          siteId: actor.siteId,
          status: { [Op.ne]: 'trash' },
          ...(ids.length ? { id: { [Op.in]: ids } } : {}),
          ...(types.length ? { type: { [Op.in]: types } } : {}),
          ...(q ? { title: iContains(q) } : {}),
        },
        attributes: ['id', 'title', 'slug', 'type', 'status'],
        order: [
          ['type', 'ASC'],
          ['title', 'ASC'],
        ],
        limit: ids.length ? ids.length : 50,
        raw: true,
      });
      return { items };
    } catch (error) {
      throw toHttpError(error, 'Could not search posts.');
    }
  }

  async lookupUsers(actor: AuthUser, opts: { q: string; ids: string[]; roles: string[] }) {
    try {
      const ids = opts.ids.filter(Boolean).slice(0, 100);
      const roles = opts.roles.filter((r) => SLUGLIKE.test(r)).slice(0, 20);
      const q = opts.q.trim().slice(0, 100);
      const items = await User.findAll({
        where: {
          siteId: actor.siteId,
          ...(ids.length ? { id: { [Op.in]: ids } } : {}),
          ...(q ? { [Op.or]: [{ displayName: iContains(q) }, { username: iContains(q) }] } : {}),
        },
        include: roles.length
          ? [{ model: Role, as: 'role', where: { slug: { [Op.in]: roles } }, attributes: [] }]
          : [],
        attributes: ['id', 'username', 'displayName'],
        order: [['displayName', 'ASC']],
        limit: ids.length ? ids.length : 50,
        raw: true,
      });
      return { items };
    } catch (error) {
      throw toHttpError(error, 'Could not search users.');
    }
  }

  /**
   * Theme layout JSON that is missing from this site, or newer than the saved group.
   */
  async listSync(actor: AuthUser): Promise<{ items: FieldGroupSyncItem[] }> {
    try {
      const [disk, groups] = await Promise.all([
        layoutSyncService.listThemeFieldGroups(),
        FieldGroup.findAll({
          where: { siteId: actor.siteId },
          attributes: ['key', 'updatedAt', 'trashedAt'],
        }),
      ]);
      const byKey = new Map(
        groups.filter((g) => !g.trashedAt).map((g) => [g.key, g.updatedAt.getTime()]),
      );
      const trashedKeys = new Set(groups.filter((g) => g.trashedAt).map((g) => g.key));
      const items: FieldGroupSyncItem[] = [];
      for (const file of disk) {
        if (trashedKeys.has(file.key)) continue;
        const saved = byKey.get(file.key);
        if (saved === undefined) {
          items.push({ ...pickSync(file), status: 'available' });
          continue;
        }
        const diskTime = file.updatedAt ? Date.parse(file.updatedAt) : NaN;
        if (Number.isFinite(diskTime) && diskTime > saved) {
          items.push({ ...pickSync(file), status: 'sync' });
        }
      }
      return { items };
    } catch (error) {
      throw toHttpError(error, 'Could not list field groups waiting to sync.');
    }
  }

  /** Import selected (or all pending) theme field groups into this site. */
  async applySync(actor: AuthUser, keys?: string[]) {
    try {
      const { items } = await this.listSync(actor);
      const wanted = keys?.length ? new Set(keys) : null;
      const pending = items.filter((item) => !wanted || wanted.has(item.key));
      if (!pending.length) return { synced: [] as string[], groups: (await this.list(actor)).groups };

      const disk = await layoutSyncService.listThemeFieldGroups();
      const byKey = new Map(disk.map((file) => [file.key, file]));
      const synced: string[] = [];

      for (const item of pending) {
        const file = byKey.get(item.key);
        if (!file) continue;
        const existing = await FieldGroup.findOne({
          where: { siteId: actor.siteId, key: file.key },
        });
        const fields = parseFields(file.fields);
        const location = parseLocation(file.location);
        if (existing) {
          await existing.update({
            title: file.title,
            description: existing.description,
            active: file.active,
            location,
            fields,
          });
        } else {
          const maxOrder = await FieldGroup.max<number | null, FieldGroup>('menuOrder', {
            where: { siteId: actor.siteId },
          });
          await FieldGroup.create({
            siteId: actor.siteId,
            title: file.title,
            key: file.key,
            description: '',
            active: file.active,
            location,
            fields,
            menuOrder: (maxOrder ?? -1) + 1,
          });
        }
        synced.push(file.key);
      }

      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'field_group.synced',
        meta: { keys: synced },
      });

      return { synced, groups: (await this.list(actor)).groups };
    } catch (error) {
      throw toHttpError(error, 'Could not sync field groups from the theme.');
    }
  }

  private async findOwned(actor: AuthUser, id: string): Promise<FieldGroup> {
    const group = await FieldGroup.findOne({ where: { id, siteId: actor.siteId } });
    if (!group) throw NotFound('Field group not found.');
    return group;
  }
}

function pickSync(file: {
  key: string;
  title: string;
  slug: string;
  theme: string;
  updatedAt: string | null;
}) {
  return {
    key: file.key,
    title: file.title,
    slug: file.slug,
    theme: file.theme,
    updatedAt: file.updatedAt,
  };
}

export const fieldsService = new FieldsService();
