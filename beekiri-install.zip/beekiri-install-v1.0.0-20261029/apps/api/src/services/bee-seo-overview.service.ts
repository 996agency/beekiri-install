import { getSelfUrl } from '../config/runtime';
import { config } from '../config/env';
import { toHttpError } from '../utils/http-error';
import { beeSeoService } from './bee-seo.service';
import { requirePrimarySite } from './site-context';

export type DomainOverviewRow = {
  keyword: string;
  rank: number | null;
  volume: number | null;
  traffic: number | null;
  cpc: number | null;
  url: string;
  score: number | null;
};

export type DomainOverviewResponse = {
  domain: string;
  metrics: {
    organicTraffic: number | null;
    organicKeywords: number | null;
  };
  topKeywords: DomainOverviewRow[];
  topPages: DomainOverviewRow[];
};

function siteBaseUrl(): string {
  return (config.urls.app ?? getSelfUrl() ?? `http://127.0.0.1:${config.server.port}`).replace(
    /\/$/,
    '',
  );
}

export class BeeSeoOverviewService {
  async overview() {
    try {
      await requirePrimarySite();
      const base = siteBaseUrl();
      let domain = base;
      try {
        domain = new URL(base).host;
      } catch {
        /* keep */
      }

      const cached = await beeSeoService.peekCached();
      const topPages: DomainOverviewRow[] = (cached?.pages ?? []).map((p) => ({
        keyword: p.title && p.title !== '-' ? p.title : p.path,
        rank: null,
        volume: null,
        traffic: null,
        cpc: null,
        url: p.path || '/',
        score: null,
      }));

      return {
        domain,
        metrics: {
          organicTraffic: null,
          organicKeywords: null,
        },
        topKeywords: [],
        topPages,
      } satisfies DomainOverviewResponse;
    } catch (error) {
      throw toHttpError(error, 'Could not load domain overview.');
    }
  }
}

export const beeSeoOverviewService = new BeeSeoOverviewService();
