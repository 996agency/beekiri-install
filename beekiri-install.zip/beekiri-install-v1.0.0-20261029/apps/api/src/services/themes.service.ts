import AdmZip from 'adm-zip';
import { existsSync, mkdirSync, rmSync, writeFileSync } from 'fs';
import { basename, dirname, isAbsolute, join, relative, sep } from 'path';
import { mergeSiteOptions, readOptions } from '../lib/site/site-options';
import {
  BUILTIN_THEME_SLUGS,
  DEFAULT_THEME_SLUG,
  getThemeManifest,
  listThemeManifests,
  resolveThemeDir,
  resolveThemeFile,
  resolveThemesRoot,
  sanitizeThemeSlug,
  type ThemeManifest,
} from '../lib/themes/theme-registry';
import { BadRequest, toHttpError } from '../utils/http-error';
import { findPrimarySite, requirePrimarySite, saveSiteOptions } from './site-context';

/** Zip-bomb guards for theme packages. */
const MAX_ZIP_ENTRIES = 2_000;
const MAX_UNPACKED_BYTES = 200 * 1024 * 1024;

export type ThemeListItem = ThemeManifest & {
  parentName?: string;
  active: boolean;
  deletable: boolean;
  screenshotUrl: string;
};

export class ThemesService {
  private async setActiveSlug(slug: string) {
    const site = await requirePrimarySite();
    await saveSiteOptions(site.id, mergeSiteOptions(site.settings?.options, { activeTheme: slug }));
  }

  async getActiveSlug(): Promise<string> {
    try {
      const site = await findPrimarySite();
      if (!site) return DEFAULT_THEME_SLUG;
      const opts = readOptions(site.settings?.options);
      const slug = (opts.activeTheme ?? '').trim() || DEFAULT_THEME_SLUG;
      return getThemeManifest(slug) ? slug : DEFAULT_THEME_SLUG;
    } catch (error) {
      throw toHttpError(error, 'Could not read the active theme.');
    }
  }

  async list(): Promise<{ themes: ThemeListItem[]; active: string }> {
    try {
      const active = await this.getActiveSlug();
      const themes = listThemeManifests().map((theme) => ({
        ...theme,
        parentName: theme.parent ? (getThemeManifest(theme.parent)?.name ?? theme.parent) : undefined,
        active: theme.slug === active,
        deletable: !theme.builtin,
        screenshotUrl: `/api/themes/${encodeURIComponent(theme.slug)}/screenshot`,
      }));
      return { themes, active };
    } catch (error) {
      throw toHttpError(error, 'Could not load themes.');
    }
  }

  async activate(slug: string): Promise<{ themes: ThemeListItem[]; active: string }> {
    try {
      const theme = getThemeManifest(slug);
      if (!theme) throw BadRequest('Theme not found.');
      await this.setActiveSlug(theme.slug);
      return await this.list();
    } catch (error) {
      throw toHttpError(error, 'Could not activate the theme.');
    }
  }

  /** Deactivate current theme → fall back to the Beekiri starter. */
  async deactivate(slug: string): Promise<{ themes: ThemeListItem[]; active: string }> {
    try {
      const theme = getThemeManifest(slug);
      if (!theme) throw BadRequest('Theme not found.');

      const active = await this.getActiveSlug();
      if (theme.slug !== active) {
        throw BadRequest('Only the active theme can be deactivated.');
      }
      if (theme.slug === DEFAULT_THEME_SLUG) {
        throw BadRequest('Beekiri Child stays available as the default theme.');
      }

      await this.setActiveSlug(DEFAULT_THEME_SLUG);
      return await this.list();
    } catch (error) {
      throw toHttpError(error, 'Could not deactivate the theme.');
    }
  }

  async remove(slug: string): Promise<{ themes: ThemeListItem[]; active: string }> {
    try {
      const theme = getThemeManifest(slug);
      if (!theme) throw BadRequest('Theme not found.');
      if (theme.builtin || BUILTIN_THEME_SLUGS.has(theme.slug)) {
        throw BadRequest('Built-in themes cannot be deleted.');
      }

      const dir = resolveThemeDir(theme.slug);
      if (!dir) throw BadRequest('Theme files were not found on disk.');

      const active = await this.getActiveSlug();
      if (active === theme.slug) {
        await this.setActiveSlug(DEFAULT_THEME_SLUG);
      }

      rmSync(dir, { recursive: true, force: true });
      return await this.list();
    } catch (error) {
      throw toHttpError(error, 'Could not delete the theme.');
    }
  }

  async uploadZip(
    buffer: Buffer,
    originalName: string,
  ): Promise<{ themes: ThemeListItem[]; active: string; installed: string }> {
    try {
      if (!buffer?.length) throw BadRequest('Empty upload.');
      if (!/\.zip$/i.test(originalName || '')) {
        throw BadRequest('Upload a .zip theme package.');
      }

      let zip: AdmZip;
      try {
        zip = new AdmZip(buffer);
      } catch {
        throw BadRequest('Could not read that ZIP file.');
      }

      const entries = zip.getEntries().filter((e) => !e.isDirectory);
      if (!entries.length) throw BadRequest('ZIP is empty.');
      if (entries.length > MAX_ZIP_ENTRIES) {
        throw BadRequest('That theme package has too many files.');
      }
      const unpacked = entries.reduce((sum, e) => sum + (e.header.size || 0), 0);
      if (unpacked > MAX_UNPACKED_BYTES) {
        throw BadRequest('That theme package is too large once unpacked.');
      }

      const manifestEntry =
        entries.find((e) => /(^|\/)theme\.json$/i.test(e.entryName.replace(/\\/g, '/'))) ?? null;
      if (!manifestEntry) {
        throw BadRequest('theme.json is required inside the ZIP.');
      }

      let manifestRaw: Partial<ThemeManifest>;
      try {
        manifestRaw = JSON.parse(
          manifestEntry.getData().toString('utf8'),
        ) as Partial<ThemeManifest>;
      } catch {
        throw BadRequest('theme.json is not valid JSON.');
      }

      const folderHint = dirname(manifestEntry.entryName.replace(/\\/g, '/'));
      const fromName = basename(originalName, '.zip');
      const slug = sanitizeThemeSlug(
        (typeof manifestRaw.slug === 'string' && manifestRaw.slug) ||
          (folderHint && folderHint !== '.' ? basename(folderHint) : fromName),
      );
      if (!slug) throw BadRequest('Could not determine a theme slug.');
      if (BUILTIN_THEME_SLUGS.has(slug)) {
        throw BadRequest('That slug is reserved for a built-in theme.');
      }

      const name = typeof manifestRaw.name === 'string' ? manifestRaw.name.trim() : '';
      if (!name) throw BadRequest('theme.json must include a name.');

      const root = resolveThemesRoot();
      mkdirSync(root, { recursive: true });
      const target = join(root, slug);
      if (existsSync(target)) {
        rmSync(target, { recursive: true, force: true });
      }
      mkdirSync(target, { recursive: true });

      const prefix = folderHint === '.' ? '' : `${folderHint}/`;
      for (const entry of entries) {
        const normalized = entry.entryName.replace(/\\/g, '/');
        if (normalized.includes('..')) continue;
        if (prefix && !normalized.startsWith(prefix)) continue;
        const rel = prefix ? normalized.slice(prefix.length) : normalized;
        if (!rel || rel.endsWith('/') || isAbsolute(rel)) continue;
        const dest = join(target, rel);
        const relCheck = relative(target, dest);
        if (relCheck.startsWith('..') || relCheck.includes(`..${sep}`)) continue;
        mkdirSync(dirname(dest), { recursive: true });
        writeFileSync(dest, entry.getData());
      }

      // Ensure theme.json slug matches folder
      const ensured = {
        ...manifestRaw,
        slug,
        name,
      };
      writeFileSync(join(target, 'theme.json'), `${JSON.stringify(ensured, null, 2)}\n`, 'utf8');

      if (!getThemeManifest(slug)) {
        rmSync(target, { recursive: true, force: true });
        throw BadRequest('Theme installed but could not be read. Check theme.json.');
      }

      const listed = await this.list();
      return { ...listed, installed: slug };
    } catch (error) {
      throw toHttpError(error, 'Could not install the theme.');
    }
  }

  resolveScreenshotPath(slug: string): string | null {
    const theme = getThemeManifest(slug);
    if (!theme) return null;
    const file = theme.screenshot || 'screenshot.svg';
    return resolveThemeFile(theme.slug, file);
  }
}

export const themesService = new ThemesService();
