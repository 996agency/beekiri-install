import type { Router } from 'express';
import { ZodObject, type ZodTypeAny } from 'zod';
import { ignoreOverride, zodToJsonSchema } from 'zod-to-json-schema';
import { readCoreManifest } from '../lib/system/core-manifest';
import { requireAuth } from '../middleware/authenticate';
import type { RequestSchemas } from '../middleware/validate';
import { CSRF_HEADER, SESSION_COOKIE } from '../services/auth.service';

/** Metadata that validate(), requireCapabilities() and singleUpload() attach to their middleware. */
type Handler = ((...args: never[]) => unknown) & {
  schemas?: RequestSchemas;
  capabilities?: string[];
  upload?: { field: string; maxBytes: number };
};
type Layer = {
  handle: Handler;
  route?: { path: string; methods: Record<string, boolean>; stack: { handle: Handler }[] };
};

type JsonSchema = Record<string, unknown>;

const UNSAFE_METHODS = new Set(['post', 'put', 'patch', 'delete']);

// zod-to-json-schema's generic signature trips "type instantiation is excessively deep".
const toJsonSchema = zodToJsonSchema as unknown as (schema: ZodTypeAny, options: object) => unknown;

type Seen = { path: string[] } | undefined;

/** Recursive schemas (nested menu items) cannot be inlined: describe the repeat as "any object". */
function stopRecursion(_def: unknown, refs: { currentPath: string[] }, seen: Seen) {
  const recursive =
    seen !== undefined &&
    seen.path.length < refs.currentPath.length &&
    seen.path.every((segment, i) => refs.currentPath[i] === segment);
  return recursive ? { type: 'object', description: 'Same shape as its parent.' } : ignoreOverride;
}

function jsonSchema(schema: ZodTypeAny): JsonSchema {
  return toJsonSchema(schema, {
    target: 'openApi3',
    $refStrategy: 'none',
    override: stopRecursion,
  }) as JsonSchema;
}

/** Query/path parameters from an object schema. */
function parameters(schema: ZodTypeAny | undefined, location: 'query' | 'path'): JsonSchema[] {
  if (!schema) return [];
  const object = jsonSchema(schema) as {
    properties?: Record<string, JsonSchema>;
    required?: string[];
  };
  return Object.entries(object.properties ?? {}).map(([name, property]) => ({
    name,
    in: location,
    required: location === 'path' || Boolean(object.required?.includes(name)),
    schema: property,
  }));
}

/** Path parameters the route declares but no params schema describes. */
function implicitPathParameters(path: string, schema: ZodTypeAny | undefined): JsonSchema[] {
  const described = schema instanceof ZodObject ? Object.keys(schema.shape) : [];
  return [...path.matchAll(/:(\w+)/g)]
    .map((m) => m[1])
    .filter((name) => !described.includes(name))
    .map((name) => ({ name, in: 'path', required: true, schema: { type: 'string' } }));
}

function humanize(name: string): string {
  const words = name.replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase();
  return words.charAt(0).toUpperCase() + words.slice(1);
}

function operation(tag: string, method: string, path: string, handlers: Handler[]): JsonSchema {
  const schemas = handlers.find((h) => h.schemas)?.schemas ?? {};
  const upload = handlers.find((h) => h.upload)?.upload;
  const capabilities = [...new Set(handlers.flatMap((h) => h.capabilities ?? []))];
  const secured = handlers.includes(requireAuth as Handler);
  const action = handlers[handlers.length - 1]?.name || method;

  const requestBody = upload
    ? {
        required: true,
        content: {
          'multipart/form-data': {
            schema: {
              type: 'object',
              required: [upload.field],
              properties: { [upload.field]: { type: 'string', format: 'binary' } },
            },
          },
        },
      }
    : schemas.body
      ? { required: true, content: { 'application/json': { schema: jsonSchema(schemas.body) } } }
      : undefined;

  return {
    tags: [tag],
    operationId: `${tag}.${action}`,
    summary: humanize(action),
    ...(capabilities.length
      ? { description: `Requires capability: ${capabilities.join(', ')}` }
      : {}),
    parameters: [
      ...parameters(schemas.params, 'path'),
      ...implicitPathParameters(path, schemas.params),
      ...parameters(schemas.query, 'query'),
    ],
    ...(requestBody ? { requestBody } : {}),
    security: secured
      ? [UNSAFE_METHODS.has(method) ? { session: [], csrf: [] } : { session: [] }]
      : [],
    responses: {
      '2XX': { description: 'Success' },
      ...(schemas.body || schemas.query || schemas.params
        ? { 400: { description: 'Invalid input' } }
        : {}),
      ...(secured
        ? { 401: { description: 'Not logged in' }, 403: { description: 'Not allowed' } }
        : {}),
    },
  };
}

/** OpenAPI 3 description of every route in `modules`, read from the routers themselves. */
export function buildOpenApiDocument(
  modules: ReadonlyArray<readonly [string, Router]>,
): JsonSchema {
  const paths: Record<string, Record<string, JsonSchema>> = {};

  for (const [mount, router] of modules) {
    const tag = mount.replace(/^\//, '');
    // router.use(...) middleware applies to every route declared after it.
    const inherited: Handler[] = [];
    for (const layer of router.stack as unknown as Layer[]) {
      if (!layer.route) {
        inherited.push(layer.handle);
        continue;
      }
      const { route } = layer;
      const handlers = [...inherited, ...route.stack.map((l) => l.handle)];
      const fullPath = `/api${mount}${route.path === '/' ? '' : route.path}`.replace(
        /:(\w+)/g,
        '{$1}',
      );
      for (const method of Object.keys(route.methods)) {
        paths[fullPath] ??= {};
        paths[fullPath][method] = operation(tag, method, route.path, handlers);
      }
    }
  }

  const manifest = readCoreManifest();
  return {
    openapi: '3.0.3',
    info: {
      title: 'Beekiri CMS API',
      description: 'Beekiri content management API',
      version: manifest.coreVersion,
    },
    servers: [{ url: '/' }],
    tags: modules.map(([mount]) => ({ name: mount.replace(/^\//, '') })),
    paths,
    components: {
      securitySchemes: {
        session: { type: 'apiKey', in: 'cookie', name: SESSION_COOKIE },
        csrf: { type: 'apiKey', in: 'header', name: CSRF_HEADER },
      },
    },
  };
}
