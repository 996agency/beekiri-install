import { z } from 'zod';

const runtime = z.enum(['php', 'react']).optional().catch(undefined);

export const layoutSlugParams = z.object({ slug: z.string().min(1).max(80) }).passthrough();

export const renderLayoutQuery = z
  .object({ fields: z.string().max(200_000).optional(), runtime })
  .passthrough();

export const renderLayoutBody = z
  .object({ fields: z.record(z.unknown()).optional(), runtime })
  .passthrough();

export const formatFieldsBody = z
  .object({ fields: z.record(z.unknown()).optional() })
  .passthrough();
