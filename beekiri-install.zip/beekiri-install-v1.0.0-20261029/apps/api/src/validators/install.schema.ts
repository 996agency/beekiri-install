import { z } from 'zod';
import { AVAILABLE_FRONTEND_RUNTIMES, type FrontendRuntime } from '../lib/site/site-options';

export const installSchema = z
  .object({
    language: z.string().min(2).max(20),
    siteTitle: z.string().min(1).max(200),
    username: z
      .string()
      .min(3)
      .max(60)
      .regex(/^[a-zA-Z0-9._-]+$/, 'Username may only contain letters, numbers, ., -, _'),
    password: z.string().min(8).max(128),
    email: z.string().email().max(320),
    blogPublic: z.boolean(),
    frontendRuntime: z.custom<FrontendRuntime>(
      (v) =>
        typeof v === 'string' && (AVAILABLE_FRONTEND_RUNTIMES as readonly string[]).includes(v),
      `frontendRuntime must be one of: ${AVAILABLE_FRONTEND_RUNTIMES.join(', ')}`,
    ),
  })
  .strict();

export type InstallInput = z.infer<typeof installSchema>;

/** The setup wizard's database step (only accepted before a database is configured). */
export const databaseSetupSchema = z
  .object({
    host: z.string().trim().max(255).optional(),
    port: z.coerce.number().int().min(1).max(65_535).optional(),
    name: z
      .string()
      .trim()
      .regex(
        /^[A-Za-z_][A-Za-z0-9_]{0,62}$/,
        'Use letters, numbers and _ only (e.g. beekiri_site)',
      ),
    user: z.string().trim().min(1).max(63),
    password: z.string().max(256).optional(),
    ssl: z.enum(['disable', 'require', 'verify-full']).optional(),
  })
  .strict();

export type DatabaseSetupInput = z.infer<typeof databaseSetupSchema>;
