import { z } from 'zod';
import { CONNECTOR_PROVIDER_IDS } from '../lib/site/connector';
import { opt } from './common';

export const connectorProviderParams = z.object({
  providerId: z.enum(CONNECTOR_PROVIDER_IDS),
});

export const updateConnectorSchema = z
  .object({
    providerId: z.enum(CONNECTOR_PROVIDER_IDS),
    enabled: opt(z.boolean()),
    /** Empty string clears; omit to leave unchanged. */
    apiKey: opt(z.string().max(500)),
    defaultModel: opt(z.string().min(1).max(120)),
  })
  .strict()
  .refine(
    (v) => v.enabled !== undefined || v.apiKey !== undefined || v.defaultModel !== undefined,
    { message: 'Provide at least one field to update.' },
  );

/** BeeQueen agent prompt — theme/layout actions only. */
export const beeQueenAgentSchema = z
  .object({
    prompt: z.string().min(1).max(2000),
  })
  .strict();

export type UpdateConnectorInput = z.infer<typeof updateConnectorSchema>;
export type BeeQueenAgentInput = z.infer<typeof beeQueenAgentSchema>;
