import { z } from 'zod';
import { opt } from './common';

const ids = z.array(z.string().max(128)).min(1).max(500);
/** A folder id, or null / "" for "no folder". */
const folderId = z.string().max(128).nullable().optional();

export const updateMediaSchema = z
  .object({
    alt: opt(z.string().max(500)),
    folderId,
  })
  .strict();

export const bulkMoveMediaSchema = z.object({ ids, folderId }).strict();

export const bulkDeleteMediaSchema = z.object({ ids }).strict();

export const listMediaQuery = z.object({ folderId: z.string().max(128).optional() }).passthrough();

export const uploadMediaQuery = z
  .object({
    purpose: z.enum(['media', 'favicon']).optional(),
    folderId: z.string().max(128).optional(),
    alt: z.string().max(500).optional(),
  })
  .passthrough();
