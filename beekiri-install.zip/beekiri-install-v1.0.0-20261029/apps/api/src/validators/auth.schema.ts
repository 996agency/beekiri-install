import { z } from 'zod';

export const loginSchema = z
  .object({
    login: z.string().min(1).max(320),
    password: z.string().min(1).max(1024),
    remember: z.boolean().optional(),
  })
  .strict();

export const lostPasswordSchema = z
  .object({
    userLogin: z.string().min(1).max(320),
  })
  .strict();

export const resetPasswordSchema = z
  .object({
    token: z.string().max(256),
    password: z.string().min(8).max(128),
  })
  .strict();

export type LoginInput = z.infer<typeof loginSchema>;
export type LostPasswordInput = z.infer<typeof lostPasswordSchema>;
export type ResetPasswordInput = z.infer<typeof resetPasswordSchema>;
