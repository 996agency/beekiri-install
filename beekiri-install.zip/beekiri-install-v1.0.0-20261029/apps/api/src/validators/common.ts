import { z, type ZodTypeAny } from 'zod';

/**
 * Optional field: missing, `undefined` and `null` all mean "not provided"
 * (the same leniency the admin UI has always relied on).
 */
export const opt = <T extends ZodTypeAny>(schema: T) =>
  schema.nullish().transform((v) => (v === null ? undefined : v)) as unknown as z.ZodOptional<T>;

/** Route ids are cuids or slugs: short, URL-safe strings only. */
export const idParam = z
  .string()
  .min(1)
  .max(128)
  .regex(/^[A-Za-z0-9_.:-]+$/, 'id is invalid');

export const idParams = z.object({ id: idParam }).passthrough();

/** Free-form JSON object (contents validated by the service). */
export const jsonObject = z.record(z.unknown());

export const queryString = (max = 200) => z.string().max(max).optional();

export const booleanish = z
  .union([z.boolean(), z.enum(['true', 'false', '1', '0'])])
  .transform((v) => v === true || v === 'true' || v === '1');
