import { z } from 'zod';
import { opt } from './common';

export const analyticsRangeSchema = z.enum(['today', '7d', '30d', '90d', 'all']);

export const analyticsQuery = z
  .object({
    range: analyticsRangeSchema.optional().catch(undefined),
    source: z.enum(['beekiri', 'google']).optional().catch(undefined),
  })
  .passthrough();

export const heatmapQuery = z
  .object({
    range: analyticsRangeSchema.optional().catch(undefined),
    path: opt(z.string().max(500)),
  })
  .passthrough();

export const googleAnalyticsSettingsSchema = z
  .object({
    measurementId: opt(z.string().max(20)),
    propertyId: opt(z.string().max(20)),
    serviceAccountJson: opt(z.string().max(20_000)),
  })
  .strict();

export type AnalyticsRange = z.infer<typeof analyticsRangeSchema>;
export type GoogleAnalyticsSettingsInput = z.infer<typeof googleAnalyticsSettingsSchema>;
