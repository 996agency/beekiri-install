import { z } from 'zod';
import { opt } from './common';

const category = z
  .object({
    enabled: opt(z.boolean()),
    label: opt(z.string().max(80)),
    description: opt(z.string().max(400)),
  })
  .strict();

export const beeCookiesSettingsSchema = z
  .object({
    enabled: opt(z.boolean()),
    position: opt(z.enum(['bottom', 'bottom-left', 'bottom-right'])),
    bannerTitle: opt(z.string().max(120)),
    bannerMessage: opt(z.string().max(800)),
    acceptLabel: opt(z.string().max(40)),
    rejectLabel: opt(z.string().max(40)),
    preferencesLabel: opt(z.string().max(40)),
    saveLabel: opt(z.string().max(40)),
    privacyPolicyUrl: opt(z.string().max(500)),
    trackPageViews: opt(z.boolean()),
    categories: opt(
      z
        .object({
          essential: opt(category),
          functional: opt(category),
          analytics: opt(category),
          marketing: opt(category),
        })
        .strict(),
    ),
  })
  .strict();

const visitorId = z
  .string()
  .min(8)
  .max(64)
  .regex(/^[A-Za-z0-9_-]+$/, 'visitorId has an invalid format');

const timeZone = opt(z.string().max(80).regex(/^[A-Za-z0-9_+\-/]*$/, 'timeZone has an invalid format'));
const locale = opt(z.string().max(40));

export const beeCookieConsentSchema = z
  .object({
    visitorId,
    functional: z.boolean(),
    analytics: z.boolean(),
    marketing: z.boolean(),
    path: opt(z.string().max(500)),
    timeZone,
    locale,
  })
  .strict();

export const beeCookieVisitSchema = z
  .object({
    visitorId,
    path: z.string().min(1).max(500),
    referrer: opt(z.string().max(500)),
    title: opt(z.string().max(200)),
    screen: opt(z.string().max(32).regex(/^[0-9]{2,5}x[0-9]{2,5}$|^$/, 'screen has an invalid format')),
    language: opt(z.string().max(40)),
    timeZone,
    locale,
  })
  .strict();

export const beeCookieHeartbeatSchema = z
  .object({
    visitorId,
    path: z.string().min(1).max(500),
  })
  .strict();

const clickPoint = z
  .object({
    x: z.number().min(0).max(100),
    y: z.number().min(0).max(100),
  })
  .strict();

export const beeCookieClicksSchema = z
  .object({
    visitorId,
    path: z.string().min(1).max(500),
    viewportW: opt(z.number().int().min(0).max(10_000)),
    clicks: z.array(clickPoint).min(1).max(40),
  })
  .strict();

export const beeCookieAnalyticsQuery = z
  .object({ range: z.enum(['today', '7d', '30d', 'all']).optional().catch(undefined) })
  .passthrough();

export type BeeCookiesSettingsInput = z.infer<typeof beeCookiesSettingsSchema>;
export type BeeCookieConsentInput = z.infer<typeof beeCookieConsentSchema>;
export type BeeCookieVisitInput = z.infer<typeof beeCookieVisitSchema>;
export type BeeCookieHeartbeatInput = z.infer<typeof beeCookieHeartbeatSchema>;
export type BeeCookieClicksInput = z.infer<typeof beeCookieClicksSchema>;
