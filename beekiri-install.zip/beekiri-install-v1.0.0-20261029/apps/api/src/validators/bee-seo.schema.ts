import { z } from 'zod';
import { booleanish, opt } from './common';

export const beeSeoAuditSchema = z
  .object({
    path: opt(z.string().max(500)),
  })
  .strict();

export const beeSeoReportQuerySchema = z
  .object({
    path: opt(z.string().max(500)),
    refresh: opt(booleanish),
  })
  .passthrough();

export const beeSeoKeywordsSchema = z
  .object({
    query: z.string().min(1).max(200),
    country: opt(z.string().max(8)),
    city: opt(z.string().max(120)),
  })
  .strict();
