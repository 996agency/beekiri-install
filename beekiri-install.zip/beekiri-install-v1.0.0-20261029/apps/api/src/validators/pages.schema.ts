import { z } from 'zod';
import { booleanish, jsonObject, opt } from './common';

const STATUS = z.enum(['auto-draft', 'draft', 'publish']);

const editable = {
  title: opt(z.string().max(200)),
  slug: opt(z.string().max(200)),
  /** Visual editor document. */
  beekiricanva: opt(jsonObject),
  /** BeekiriCode page tree document. */
  beekiricode: opt(jsonObject),
  /** @deprecated Alias for beekiricode */
  instatic: opt(jsonObject),
  excerpt: opt(z.string().max(2000)),
  /** Media library id, or empty string to clear. */
  featuredImageId: opt(z.union([z.string().max(128), z.literal('')])),
};

export const createPageSchema = z
  .object({
    ...editable,
    status: opt(STATUS),
    content: opt(z.string().max(200_000)),
    /** WordPress-style: create an empty auto-draft immediately. */
    autoDraft: opt(z.boolean()),
  })
  .strict();

export const updatePageSchema = z
  .object({
    ...editable,
    status: opt(STATUS),
    content: opt(z.string().max(200_000)),
  })
  .strict();

export const previewPageSchema = z.object(editable).strict();

export const presenceSchema = z.object({ clientId: z.string().max(80) }).strict();

export const presenceLeaveQuery = z
  .object({ clientId: z.string().max(80).optional() })
  .passthrough();

export const publicPageQuery = z
  .object({
    preview: z.union([booleanish, z.string().max(10)]).optional(),
    token: z.string().max(200).optional(),
  })
  .passthrough();

export const revisionParams = z
  .object({
    id: z.string().min(1).max(128),
    revisionId: z.string().min(1).max(128),
  })
  .passthrough();

export type CreatePageInput = z.infer<typeof createPageSchema>;
export type UpdatePageInput = z.infer<typeof updatePageSchema>;
export type PreviewPageInput = z.infer<typeof previewPageSchema>;
