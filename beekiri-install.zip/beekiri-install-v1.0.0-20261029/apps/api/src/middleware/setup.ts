import type { NextFunction, Request, Response } from 'express';
import { config } from '../config/env';

/** API areas that work before a database is configured. */
const OPEN_IN_SETUP = /^\/(install|health)(\/|$)/;

/** Until the setup wizard saved the database settings, only the wizard's API answers. */
export function requireConfiguredDatabase(req: Request, res: Response, next: NextFunction) {
  if (config.databaseConfigured || OPEN_IN_SETUP.test(req.path)) return next();
  res.status(503).json({
    statusCode: 503,
    message: 'Finish setting up Beekiri first.',
    code: 'setup_required',
  });
}
