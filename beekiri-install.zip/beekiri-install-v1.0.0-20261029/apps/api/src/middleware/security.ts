import cors from 'cors';
import type { Request } from 'express';
import helmet from 'helmet';
import { config } from '../config/env';
import { isLoopbackOrigin } from '../utils/loopback';

const allowed = new Set(config.corsOrigins);

/** The configured site addresses, plus (outside production) anything on this machine. */
export function isAllowedOrigin(origin: string): boolean {
  return allowed.has(origin) || (config.allowLoopbackOrigins && isLoopbackOrigin(origin));
}

/** Origin of this API as the browser sees it (same-origin calls are always fine). */
export function selfOrigin(req: Request): string {
  return `${req.protocol}://${req.get('host') ?? ''}`;
}

/**
 * Only allow-listed browser origins get CORS headers (with cookies). Requests without
 * an Origin (server-side fetches from the public site, curl) are not affected by CORS.
 */
export const corsMiddleware = cors({
  origin(origin, callback) {
    callback(null, !origin || isAllowedOrigin(origin));
  },
  credentials: true,
  methods: ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'X-CSRF-Token', 'Authorization'],
  maxAge: 600,
});

/** Every response: the usual hardening headers, without a page CSP (pages set their own). */
export const siteSecurityHeaders = helmet({
  // Theme/layout assets and uploads may be embedded by other pages.
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
  hsts: config.isProduction ? { maxAge: 15_552_000, includeSubDomains: true } : false,
});

/** JSON API responses: nothing in them may run as a page or be framed. */
export const apiContentSecurityPolicy = helmet.contentSecurityPolicy({
  useDefaults: false,
  directives: { defaultSrc: ["'none'"], frameAncestors: ["'none'"] },
});
