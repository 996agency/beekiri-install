import { DataTypes, type ModelAttributeColumnOptions } from 'sequelize';
import { createId } from '../utils/ids';

/** Primary key matching the existing TEXT cuid ids. */
export const idColumn = (): ModelAttributeColumnOptions => ({
  type: DataTypes.TEXT,
  primaryKey: true,
  allowNull: false,
  defaultValue: () => createId(),
});

export const text = (
  opts: Partial<ModelAttributeColumnOptions> = {},
): ModelAttributeColumnOptions => ({
  type: DataTypes.TEXT,
  allowNull: false,
  ...opts,
});

export const optionalText = (): ModelAttributeColumnOptions => ({
  type: DataTypes.TEXT,
  allowNull: true,
});

export const bool = (defaultValue: boolean): ModelAttributeColumnOptions => ({
  type: DataTypes.BOOLEAN,
  allowNull: false,
  defaultValue,
});

export const int = (defaultValue?: number): ModelAttributeColumnOptions => ({
  type: DataTypes.INTEGER,
  allowNull: false,
  ...(defaultValue === undefined ? {} : { defaultValue }),
});

export const jsonb = (defaultValue: unknown): ModelAttributeColumnOptions => ({
  type: DataTypes.JSONB,
  allowNull: false,
  defaultValue,
});

export const date = (
  opts: Partial<ModelAttributeColumnOptions> = {},
): ModelAttributeColumnOptions => ({
  type: DataTypes.DATE(3),
  allowNull: false,
  ...opts,
});

export const optionalDate = (): ModelAttributeColumnOptions => ({
  type: DataTypes.DATE(3),
  allowNull: true,
});

/** JSON column payloads are untyped at the DB layer; services narrow them. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- index type `any` lets typed interfaces (SiteOptions, UserProfile…) be stored without casts.
export type Json = Record<string, any> | unknown[] | string | number | boolean | null;
