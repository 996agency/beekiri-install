import {
  Model,
  type CreationOptional,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { idColumn, text } from './_shared';

export class Capability extends Model<
  InferAttributes<Capability>,
  InferCreationAttributes<Capability>
> {
  declare id: CreationOptional<string>;
  declare slug: string;
  declare name: string;

  static initModel(sequelize: Sequelize) {
    Capability.init(
      {
        id: idColumn(),
        slug: text({ unique: 'Capability_slug_key' }),
        name: text(),
      },
      { sequelize, tableName: 'Capability', modelName: 'Capability', timestamps: false },
    );
  }
}
