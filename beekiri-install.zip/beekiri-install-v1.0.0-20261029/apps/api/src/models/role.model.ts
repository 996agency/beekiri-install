import {
  Model,
  type CreationOptional,
  type InferAttributes,
  type InferCreationAttributes,
  type NonAttribute,
  type Sequelize,
} from 'sequelize';
import { idColumn, text } from './_shared';
import type { Capability } from './capability.model';

export class Role extends Model<InferAttributes<Role>, InferCreationAttributes<Role>> {
  declare id: CreationOptional<string>;
  declare slug: string;
  declare name: string;

  declare capabilities?: NonAttribute<Capability[]>;

  static initModel(sequelize: Sequelize) {
    Role.init(
      {
        id: idColumn(),
        slug: text({ unique: 'Role_slug_key' }),
        name: text(),
      },
      { sequelize, tableName: 'Role', modelName: 'Role', timestamps: false },
    );
  }
}
