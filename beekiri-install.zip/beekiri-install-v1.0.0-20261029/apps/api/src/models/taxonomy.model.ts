import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, int, jsonb, text, type Json } from './_shared';
import type { Site } from './site.model';

/** Custom taxonomies (categories/tags style). */
export class Taxonomy extends Model<InferAttributes<Taxonomy>, InferCreationAttributes<Taxonomy>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare slug: string;
  declare singular: string;
  declare plural: string;
  declare description: CreationOptional<string>;
  declare hierarchical: CreationOptional<boolean>;
  declare public: CreationOptional<boolean>;
  declare objectTypes: CreationOptional<Json>;
  declare active: CreationOptional<boolean>;
  declare menuOrder: CreationOptional<number>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    Taxonomy.init(
      {
        id: idColumn(),
        siteId: text(),
        slug: text(),
        singular: text(),
        plural: text(),
        description: text({ defaultValue: '' }),
        hierarchical: bool(true),
        public: bool(true),
        objectTypes: jsonb(['post']),
        active: bool(true),
        menuOrder: int(0),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'Taxonomy',
        modelName: 'Taxonomy',
        timestamps: true,
        indexes: [
          { name: 'Taxonomy_siteId_slug_key', unique: true, fields: ['siteId', 'slug'] },
          { name: 'Taxonomy_siteId_idx', fields: ['siteId'] },
        ],
      },
    );
  }
}
