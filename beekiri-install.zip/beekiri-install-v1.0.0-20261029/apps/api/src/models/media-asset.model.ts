import {
  DataTypes,
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, int, optionalText, text } from './_shared';
import type { Site } from './site.model';

export class MediaAsset extends Model<
  InferAttributes<MediaAsset>,
  InferCreationAttributes<MediaAsset>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare filename: string;
  declare originalName: string;
  declare mimeType: string;
  declare size: number;
  declare width: number | null;
  declare height: number | null;
  /** Public URL path, e.g. /uploads/2026/10/abc.webp */
  declare url: string;
  /** Path relative to MEDIA_LOCAL_PATH */
  declare storagePath: string;
  declare folderId: CreationOptional<string | null>;
  declare alt: CreationOptional<string>;
  declare uploadedById: CreationOptional<string | null>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    MediaAsset.init(
      {
        id: idColumn(),
        siteId: text(),
        filename: text(),
        originalName: text(),
        mimeType: text(),
        size: int(),
        width: { type: DataTypes.INTEGER, allowNull: true },
        height: { type: DataTypes.INTEGER, allowNull: true },
        url: text(),
        storagePath: text(),
        folderId: optionalText(),
        alt: text({ defaultValue: '' }),
        uploadedById: optionalText(),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'MediaAsset',
        modelName: 'MediaAsset',
        timestamps: true,
        indexes: [
          { name: 'MediaAsset_siteId_idx', fields: ['siteId'] },
          { name: 'MediaAsset_folderId_idx', fields: ['folderId'] },
          { name: 'MediaAsset_createdAt_idx', fields: ['createdAt'] },
        ],
      },
    );
  }
}
