import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, optionalText, text } from './_shared';
import type { Site } from './site.model';
import type { BeeCookieDevice } from './bee-cookie-consent.model';

export class BeeCookieVisit extends Model<
  InferAttributes<BeeCookieVisit>,
  InferCreationAttributes<BeeCookieVisit>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare visitorId: string;
  declare path: string;
  declare referrerHost: CreationOptional<string | null>;
  declare device: CreationOptional<BeeCookieDevice>;
  declare country: CreationOptional<string | null>;
  declare browser: CreationOptional<string | null>;
  declare os: CreationOptional<string | null>;
  declare language: CreationOptional<string | null>;
  declare screen: CreationOptional<string | null>;
  declare title: CreationOptional<string | null>;
  declare channel: CreationOptional<string | null>;
  declare utmSource: CreationOptional<string | null>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    BeeCookieVisit.init(
      {
        id: idColumn(),
        siteId: text(),
        visitorId: text(),
        path: text(),
        referrerHost: optionalText(),
        device: text({ defaultValue: 'unknown' }),
        country: optionalText(),
        browser: optionalText(),
        os: optionalText(),
        language: optionalText(),
        screen: optionalText(),
        title: optionalText(),
        channel: optionalText(),
        utmSource: optionalText(),
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'BeeCookieVisit',
        modelName: 'BeeCookieVisit',
        timestamps: true,
        updatedAt: false,
        indexes: [
          { name: 'BeeCookieVisit_siteId_createdAt_idx', fields: ['siteId', 'createdAt'] },
          { name: 'BeeCookieVisit_siteId_path_idx', fields: ['siteId', 'path'] },
        ],
      },
    );
  }
}
