import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, optionalText, text } from './_shared';
import type { Site } from './site.model';

export type BeeCookieStatus = 'accepted' | 'rejected' | 'custom';
export type BeeCookieDevice = 'desktop' | 'mobile' | 'tablet' | 'unknown';

export class BeeCookieConsent extends Model<
  InferAttributes<BeeCookieConsent>,
  InferCreationAttributes<BeeCookieConsent>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare visitorId: string;
  declare status: BeeCookieStatus;
  declare essential: CreationOptional<boolean>;
  declare functional: CreationOptional<boolean>;
  declare analytics: CreationOptional<boolean>;
  declare marketing: CreationOptional<boolean>;
  declare device: CreationOptional<BeeCookieDevice>;
  declare country: CreationOptional<string | null>;
  declare path: CreationOptional<string>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    BeeCookieConsent.init(
      {
        id: idColumn(),
        siteId: text(),
        visitorId: text(),
        status: text(),
        essential: bool(true),
        functional: bool(false),
        analytics: bool(false),
        marketing: bool(false),
        device: text({ defaultValue: 'unknown' }),
        country: optionalText(),
        path: text({ defaultValue: '/' }),
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'BeeCookieConsent',
        modelName: 'BeeCookieConsent',
        timestamps: true,
        updatedAt: false,
        indexes: [
          { name: 'BeeCookieConsent_siteId_createdAt_idx', fields: ['siteId', 'createdAt'] },
          {
            name: 'BeeCookieConsent_siteId_visitorId_createdAt_idx',
            fields: ['siteId', 'visitorId', 'createdAt'],
          },
        ],
      },
    );
  }
}
