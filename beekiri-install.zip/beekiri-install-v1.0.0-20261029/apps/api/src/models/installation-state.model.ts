import {
  DataTypes,
  Model,
  type CreationOptional,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { bool, optionalDate, optionalText } from './_shared';

/** Single row (id = 1) so concurrent installers contend on one lock. */
export class InstallationState extends Model<
  InferAttributes<InstallationState>,
  InferCreationAttributes<InstallationState>
> {
  declare id: CreationOptional<number>;
  declare installed: CreationOptional<boolean>;
  declare installedAt: CreationOptional<Date | null>;
  declare lockedAt: CreationOptional<Date | null>;
  declare lockOwner: CreationOptional<string | null>;

  static initModel(sequelize: Sequelize) {
    InstallationState.init(
      {
        id: { type: DataTypes.INTEGER, primaryKey: true, allowNull: false, defaultValue: 1 },
        installed: bool(false),
        installedAt: optionalDate(),
        lockedAt: optionalDate(),
        lockOwner: optionalText(),
      },
      {
        sequelize,
        tableName: 'InstallationState',
        modelName: 'InstallationState',
        timestamps: false,
      },
    );
  }
}
