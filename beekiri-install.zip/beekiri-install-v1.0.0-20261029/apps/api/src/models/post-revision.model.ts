import {
  DataTypes,
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, optionalText, text, type Json } from './_shared';
import type { Post } from './post.model';

/** WordPress-style content revisions for pages/posts. */
export class PostRevision extends Model<
  InferAttributes<PostRevision>,
  InferCreationAttributes<PostRevision>
> {
  declare id: CreationOptional<string>;
  declare postId: ForeignKey<Post['id']>;
  declare siteId: string;
  declare title: string;
  declare slug: string;
  declare status: string;
  declare content: Json;
  declare excerpt: CreationOptional<string>;
  /** User who authored this snapshot (editor at the time it was current). */
  declare authorId: CreationOptional<string | null>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    PostRevision.init(
      {
        id: idColumn(),
        postId: text(),
        siteId: text(),
        title: text(),
        slug: text(),
        status: text(),
        content: { type: DataTypes.JSONB, allowNull: false },
        excerpt: text({ defaultValue: '' }),
        authorId: optionalText(),
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'PostRevision',
        modelName: 'PostRevision',
        timestamps: true,
        updatedAt: false,
        indexes: [
          { name: 'PostRevision_postId_createdAt_idx', fields: ['postId', 'createdAt'] },
          { name: 'PostRevision_siteId_idx', fields: ['siteId'] },
        ],
      },
    );
  }
}
