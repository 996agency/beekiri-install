import {
  Model,
  type CreationOptional,
  type InferAttributes,
  type InferCreationAttributes,
  type NonAttribute,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, jsonb, optionalText, text, type Json } from './_shared';
import type { User } from './user.model';

export class AuditLog extends Model<InferAttributes<AuditLog>, InferCreationAttributes<AuditLog>> {
  declare id: CreationOptional<string>;
  declare siteId: CreationOptional<string | null>;
  declare userId: CreationOptional<string | null>;
  declare action: string;
  declare meta: CreationOptional<Json>;
  declare ip: CreationOptional<string | null>;
  declare createdAt: CreationOptional<Date>;

  declare user?: NonAttribute<User | null>;

  static initModel(sequelize: Sequelize) {
    AuditLog.init(
      {
        id: idColumn(),
        siteId: optionalText(),
        userId: optionalText(),
        action: text(),
        meta: jsonb({}),
        ip: optionalText(),
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'AuditLog',
        modelName: 'AuditLog',
        timestamps: true,
        updatedAt: false,
        indexes: [
          { name: 'AuditLog_action_idx', fields: ['action'] },
          { name: 'AuditLog_createdAt_idx', fields: ['createdAt'] },
        ],
      },
    );
  }
}
