import {
  DataTypes,
  Model,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';

/**
 * Join table Role ⇄ Capability. Name and A/B columns are kept from the original
 * schema (A = Capability.id, B = Role.id) so existing installs need no data move.
 */
export class RoleCapability extends Model<
  InferAttributes<RoleCapability>,
  InferCreationAttributes<RoleCapability>
> {
  declare A: string;
  declare B: string;

  static initModel(sequelize: Sequelize) {
    RoleCapability.init(
      {
        A: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        B: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
      },
      { sequelize, tableName: '_CapabilityToRole', modelName: 'RoleCapability', timestamps: false },
    );
  }
}
