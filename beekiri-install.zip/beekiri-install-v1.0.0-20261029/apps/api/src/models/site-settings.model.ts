import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { bool, idColumn, jsonb, text, type Json } from './_shared';
import type { Site } from './site.model';

export class SiteSettings extends Model<
  InferAttributes<SiteSettings>,
  InferCreationAttributes<SiteSettings>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare blogPublic: CreationOptional<boolean>;
  declare timezone: CreationOptional<string>;
  declare dateFormat: CreationOptional<string>;
  declare timeFormat: CreationOptional<string>;
  /** Opaque JSON bag (active theme, frontend runtime, cache epoch, …). */
  declare options: CreationOptional<Json>;

  static initModel(sequelize: Sequelize) {
    SiteSettings.init(
      {
        id: idColumn(),
        siteId: text({ unique: 'SiteSettings_siteId_key' }),
        blogPublic: bool(true),
        timezone: text({ defaultValue: 'UTC' }),
        dateFormat: text({ defaultValue: 'F j, Y' }),
        timeFormat: text({ defaultValue: 'g:i a' }),
        options: jsonb({}),
      },
      { sequelize, tableName: 'SiteSettings', modelName: 'SiteSettings', timestamps: false },
    );
  }
}
