import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, int, jsonb, text, type Json } from './_shared';
import type { Site } from './site.model';

/** Custom post types registered via Backend Fields. */
export class PostType extends Model<InferAttributes<PostType>, InferCreationAttributes<PostType>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare slug: string;
  declare singular: string;
  declare plural: string;
  declare description: CreationOptional<string>;
  declare public: CreationOptional<boolean>;
  declare hierarchical: CreationOptional<boolean>;
  declare hasArchive: CreationOptional<boolean>;
  declare showInMenu: CreationOptional<boolean>;
  declare supports: CreationOptional<Json>;
  declare active: CreationOptional<boolean>;
  declare menuOrder: CreationOptional<number>;
  /** Phosphor icon component name for the admin sidebar (e.g. "Cube"). */
  declare menuIcon: CreationOptional<string>;
  /** Archive listing layout: list | cards | grid */
  declare archiveDesign: CreationOptional<string>;
  /** Single entry layout: default | full | compact */
  declare singleDesign: CreationOptional<string>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    PostType.init(
      {
        id: idColumn(),
        siteId: text(),
        slug: text(),
        singular: text(),
        plural: text(),
        description: text({ defaultValue: '' }),
        public: bool(true),
        hierarchical: bool(false),
        hasArchive: bool(true),
        showInMenu: bool(true),
        supports: jsonb(['title', 'editor']),
        active: bool(true),
        menuOrder: int(0),
        menuIcon: text({ defaultValue: 'Cube' }),
        archiveDesign: text({ defaultValue: 'list' }),
        singleDesign: text({ defaultValue: 'default' }),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'PostType',
        modelName: 'PostType',
        timestamps: true,
        indexes: [
          { name: 'PostType_siteId_slug_key', unique: true, fields: ['siteId', 'slug'] },
          { name: 'PostType_siteId_idx', fields: ['siteId'] },
        ],
      },
    );
  }
}
