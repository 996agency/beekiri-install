import {
  DataTypes,
  Model,
  type CreationOptional,
  type InferAttributes,
  type InferCreationAttributes,
  type NonAttribute,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, text } from './_shared';
import type { SiteSettings } from './site-settings.model';
import type { User } from './user.model';

export class Site extends Model<InferAttributes<Site>, InferCreationAttributes<Site>> {
  declare id: CreationOptional<string>;
  declare title: string;
  declare tagline: CreationOptional<string>;
  declare language: CreationOptional<string>;
  declare installedAt: CreationOptional<Date>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  declare settings?: NonAttribute<SiteSettings | null>;
  declare users?: NonAttribute<User[]>;

  static initModel(sequelize: Sequelize) {
    Site.init(
      {
        id: idColumn(),
        title: text(),
        tagline: text({ defaultValue: '' }),
        language: text({ defaultValue: 'en_US' }),
        installedAt: date({ defaultValue: DataTypes.NOW }),
        createdAt: date(),
        updatedAt: date(),
      },
      { sequelize, tableName: 'Site', modelName: 'Site', timestamps: true },
    );
  }
}
