import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, optionalDate, text } from './_shared';
import type { User } from './user.model';

export class PasswordResetToken extends Model<
  InferAttributes<PasswordResetToken>,
  InferCreationAttributes<PasswordResetToken>
> {
  declare id: CreationOptional<string>;
  declare userId: ForeignKey<User['id']>;
  declare tokenHash: string;
  declare expiresAt: Date;
  declare usedAt: CreationOptional<Date | null>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    PasswordResetToken.init(
      {
        id: idColumn(),
        userId: text(),
        tokenHash: text({ unique: 'PasswordResetToken_tokenHash_key' }),
        expiresAt: date(),
        usedAt: optionalDate(),
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'PasswordResetToken',
        modelName: 'PasswordResetToken',
        timestamps: true,
        updatedAt: false,
        indexes: [{ name: 'PasswordResetToken_userId_idx', fields: ['userId'] }],
      },
    );
  }
}
