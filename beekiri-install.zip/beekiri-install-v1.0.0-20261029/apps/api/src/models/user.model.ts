import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type NonAttribute,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, jsonb, text, type Json } from './_shared';
import type { Role } from './role.model';
import type { Site } from './site.model';

export class User extends Model<InferAttributes<User>, InferCreationAttributes<User>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare username: string;
  declare email: string;
  declare displayName: string;
  declare passwordHash: string;
  declare roleId: ForeignKey<Role['id']>;
  declare isOwner: CreationOptional<boolean>;
  /** { jobDescription?: string, customFields?: { id, label, value }[] } */
  declare profile: CreationOptional<Json>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  declare role?: NonAttribute<Role>;
  declare site?: NonAttribute<Site>;

  static initModel(sequelize: Sequelize) {
    User.init(
      {
        id: idColumn(),
        siteId: text(),
        username: text(),
        email: text(),
        displayName: text(),
        passwordHash: text(),
        roleId: text(),
        isOwner: bool(false),
        profile: jsonb({}),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'User',
        modelName: 'User',
        timestamps: true,
        defaultScope: { attributes: { exclude: ['passwordHash'] } },
        scopes: { withPassword: { attributes: { include: ['passwordHash'] } } },
        indexes: [
          { name: 'User_siteId_username_key', unique: true, fields: ['siteId', 'username'] },
          { name: 'User_siteId_email_key', unique: true, fields: ['siteId', 'email'] },
          { name: 'User_email_idx', fields: ['email'] },
          { name: 'User_username_idx', fields: ['username'] },
        ],
      },
    );
  }
}
