import { Router } from 'express';
import { themesController as c } from '../controllers/themes.controller';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import { singleUpload } from '../middleware/upload';
import { validate } from '../middleware/validate';
import { MAX_UPLOAD_BYTES } from '../services/media.service';
import {
  chromeAssetParams,
  chromeKindParams,
  themeSlugParams,
  themeSlugSchema,
} from '../validators/themes.schema';

export const themesRoutes = Router();

const canEdit = [requireAuth, requireCapabilities('edit_theme_options')];

// Public (rendered into every page of the site).
themesRoutes.get('/chrome/:kind/render', validate({ params: chromeKindParams }), c.renderChrome);
themesRoutes.get(
  '/chrome/:kind/asset/:file',
  validate({ params: chromeAssetParams }),
  c.chromeAsset,
);
themesRoutes.get('/:slug/screenshot', validate({ params: themeSlugParams }), c.screenshot);

themesRoutes.get('/', ...canEdit, c.list);
themesRoutes.get(
  '/chrome/:kind/options',
  ...canEdit,
  validate({ params: chromeKindParams }),
  c.listChrome,
);
themesRoutes.post(
  '/chrome/:kind/activate',
  ...canEdit,
  validate({ params: chromeKindParams, body: themeSlugSchema }),
  c.activateChrome,
);
themesRoutes.post('/activate', ...canEdit, validate({ body: themeSlugSchema }), c.activate);
themesRoutes.post('/deactivate', ...canEdit, validate({ body: themeSlugSchema }), c.deactivate);
themesRoutes.post('/upload', ...canEdit, singleUpload(MAX_UPLOAD_BYTES), c.upload);
themesRoutes.delete('/:slug', ...canEdit, validate({ params: themeSlugParams }), c.remove);
