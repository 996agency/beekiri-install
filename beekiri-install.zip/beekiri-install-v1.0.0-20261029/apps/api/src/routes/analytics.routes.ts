import { Router } from 'express';
import { analyticsController as c } from '../controllers/analytics.controller';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import { validate } from '../middleware/validate';
import {
  analyticsQuery,
  googleAnalyticsSettingsSchema,
  heatmapQuery,
} from '../validators/analytics.schema';

export const analyticsRoutes = Router();

const admin = [requireAuth, requireCapabilities('manage_options')];

analyticsRoutes.get('/settings', ...admin, c.settings);
analyticsRoutes.patch(
  '/settings',
  ...admin,
  validate({ body: googleAnalyticsSettingsSchema }),
  c.updateSettings,
);
analyticsRoutes.get('/report', ...admin, validate({ query: analyticsQuery }), c.report);
analyticsRoutes.get('/live', ...admin, c.live);
analyticsRoutes.get('/heatmap', ...admin, validate({ query: heatmapQuery }), c.heatmap);
