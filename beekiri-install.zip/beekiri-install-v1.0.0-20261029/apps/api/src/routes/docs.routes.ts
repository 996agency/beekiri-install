import { Router, type NextFunction, type Request, type Response } from 'express';
import swaggerUi from 'swagger-ui-express';
import { buildOpenApiDocument } from '../docs/openapi';
import { apiModules } from './index';

const SPEC_PATH = '/api/docs/openapi.json';

let spec: Record<string, unknown> | null = null;

/** The Swagger UI page needs its own scripts/styles; the API default CSP blocks everything. */
function swaggerCsp(_req: Request, res: Response, next: NextFunction) {
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'none'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'",
  );
  next();
}

/** Swagger UI at /api/docs and the raw OpenAPI document at /api/docs/openapi.json. */
export const docsRoutes = Router();

docsRoutes.get('/openapi.json', (_req, res, next) => {
  try {
    spec ??= buildOpenApiDocument(apiModules);
    res.json(spec);
  } catch (error) {
    next(error);
  }
});

docsRoutes.use(
  '/',
  swaggerCsp,
  swaggerUi.serve,
  swaggerUi.setup(undefined, {
    customSiteTitle: 'Beekiri CMS API',
    swaggerOptions: { url: SPEC_PATH, validatorUrl: null },
  }),
);
