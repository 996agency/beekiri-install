import { Router } from 'express';
import { connectorController as c } from '../controllers/connector.controller';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import { validate } from '../middleware/validate';
import {
  beeQueenAgentSchema,
  connectorProviderParams,
  updateConnectorSchema,
} from '../validators/connector.schema';

export const connectorRoutes = Router();

const admin = [requireAuth, requireCapabilities('manage_options')];

connectorRoutes.get('/', ...admin, c.get);
connectorRoutes.patch('/', ...admin, validate({ body: updateConnectorSchema }), c.update);
/** Must be before /:providerId so “agent” is not treated as a provider id. */
connectorRoutes.post('/agent', ...admin, validate({ body: beeQueenAgentSchema }), c.runAgent);
connectorRoutes.get(
  '/:providerId',
  ...admin,
  validate({ params: connectorProviderParams }),
  c.getProvider,
);
