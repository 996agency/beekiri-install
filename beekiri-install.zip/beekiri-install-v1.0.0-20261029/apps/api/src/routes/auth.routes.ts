import { Router } from 'express';
import { authController } from '../controllers/auth.controller';
import { requireAuth } from '../middleware/authenticate';
import { authRateLimit } from '../middleware/rate-limit';
import { validate } from '../middleware/validate';
import { loginSchema, lostPasswordSchema, resetPasswordSchema } from '../validators/auth.schema';

export const authRoutes = Router();

authRoutes.post('/login', validate({ body: loginSchema }), authController.login);
authRoutes.post('/logout', requireAuth, authController.logout);
authRoutes.get('/me', authController.me);
authRoutes.get('/csrf', authController.csrf);
authRoutes.post(
  '/lost-password',
  authRateLimit,
  validate({ body: lostPasswordSchema }),
  authController.lostPassword,
);
authRoutes.post(
  '/reset-password',
  authRateLimit,
  validate({ body: resetPasswordSchema }),
  authController.resetPassword,
);
