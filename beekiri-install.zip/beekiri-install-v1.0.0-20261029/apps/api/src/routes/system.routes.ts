import { Router } from 'express';
import { systemController as c } from '../controllers/system.controller';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';

export const systemRoutes = Router();

systemRoutes.use(requireAuth, requireCapabilities('manage_options'));

systemRoutes.get('/version', c.version);
systemRoutes.get('/status', c.status);
systemRoutes.get('/updates', c.updates);
systemRoutes.post('/updates/apply', c.applyUpdate);
systemRoutes.get('/updates/progress', c.updateProgress);
systemRoutes.get('/lighthouse', c.lighthouse);
systemRoutes.post('/cache/flush', c.flushCache);
