import { Router } from 'express';
import { mediaController } from '../controllers/media.controller';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import { singleUpload } from '../middleware/upload';
import { validate } from '../middleware/validate';
import { MAX_UPLOAD_BYTES } from '../services/media.service';
import { idParams } from '../validators/common';
import {
  bulkDeleteMediaSchema,
  bulkMoveMediaSchema,
  listMediaQuery,
  updateMediaSchema,
  uploadMediaQuery,
} from '../validators/media.schema';

export const mediaRoutes = Router();

mediaRoutes.use(requireAuth, requireCapabilities('upload_files'));

mediaRoutes.get('/', validate({ query: listMediaQuery }), mediaController.list);
mediaRoutes.post(
  '/upload',
  validate({ query: uploadMediaQuery }),
  singleUpload(MAX_UPLOAD_BYTES),
  mediaController.upload,
);
mediaRoutes.post('/bulk-move', validate({ body: bulkMoveMediaSchema }), mediaController.bulkMove);
mediaRoutes.post(
  '/bulk-delete',
  validate({ body: bulkDeleteMediaSchema }),
  mediaController.bulkDelete,
);
mediaRoutes.patch(
  '/:id',
  validate({ params: idParams, body: updateMediaSchema }),
  mediaController.update,
);
mediaRoutes.delete('/:id', validate({ params: idParams }), mediaController.remove);
