import { Router, type NextFunction, type Request, type Response } from 'express';
import {
  createContentController,
  createParamContentController,
} from '../controllers/pages.controller';
import {
  isBuiltinContentKind,
  RESERVED_CONTENT_SLUGS,
  type ContentKind,
} from '../lib/pages/content-kind';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import { PostType } from '../models';
import { findPrimarySite } from '../services/site-context';
import { NotFound } from '../utils/http-error';
import { validate } from '../middleware/validate';
import { idParams } from '../validators/common';
import {
  createPageSchema,
  presenceLeaveQuery,
  presenceSchema,
  previewPageSchema,
  publicPageQuery,
  revisionParams,
  updatePageSchema,
} from '../validators/pages.schema';

/** /pages and /posts share one router shape; capabilities follow the content kind. */
function contentRoutes(kind: ContentKind) {
  const c = createContentController(kind);
  const edit = kind === 'page' ? 'edit_pages' : 'edit_posts';
  const del = kind === 'page' ? 'delete_pages' : 'delete_posts';
  const router = Router();
  const canEdit = [requireAuth, requireCapabilities(edit)];
  const withId = validate({ params: idParams });

  // Public (front-end) routes first so ":id" never shadows them.
  if (kind === 'page')
    router.get('/public/front', validate({ query: publicPageQuery }), c.publicFront);
  if (kind !== 'page') router.get('/public', c.publicList);
  router.get('/public/:slug', validate({ query: publicPageQuery }), c.publicBySlug);

  router.get('/', ...canEdit, c.list);
  router.get('/:id/revisions', ...canEdit, withId, c.listRevisions);
  router.post(
    '/:id/revisions/:revisionId/restore',
    ...canEdit,
    validate({ params: revisionParams }),
    c.restoreRevision,
  );
  router.post(
    '/:id/preview',
    ...canEdit,
    validate({ params: idParams, body: previewPageSchema }),
    c.preview,
  );
  router.get('/:id/presence', ...canEdit, withId, c.getPresence);
  router.post(
    '/:id/presence',
    ...canEdit,
    validate({ params: idParams, body: presenceSchema }),
    c.postPresence,
  );
  router.delete(
    '/:id/presence',
    ...canEdit,
    validate({ params: idParams, query: presenceLeaveQuery }),
    c.deletePresence,
  );
  router.get('/:id', ...canEdit, withId, c.get);
  router.post('/', ...canEdit, validate({ body: createPageSchema }), c.create);
  router.patch(
    '/:id',
    ...canEdit,
    validate({ params: idParams, body: updatePageSchema }),
    c.update,
  );
  router.post(
    '/:id/restore',
    requireAuth,
    requireCapabilities(del),
    withId,
    c.restore,
  );
  router.delete('/:id', requireAuth, requireCapabilities(del), withId, c.remove);
  return router;
}

function paramType(req: Request): string {
  return String((req.params as { type?: string }).type || '')
    .trim()
    .toLowerCase();
}

async function requireActiveCpt(req: Request, _res: Response, next: NextFunction) {
  try {
    const type = paramType(req);
    if (!type || isBuiltinContentKind(type) || RESERVED_CONTENT_SLUGS.has(type)) {
      throw NotFound('Post type not found.');
    }
    const site = await findPrimarySite();
    if (!site) throw NotFound('Post type not found.');
    const row = await PostType.findOne({
      where: { siteId: site.id, slug: type, active: true },
    });
    if (!row) throw NotFound('Post type not found.');
    next();
  } catch (error) {
    next(error);
  }
}

/** Custom post types: /api/content/:type — same editor API as posts. */
function cptContentRoutes() {
  const c = createParamContentController();
  const router = Router({ mergeParams: true });
  const canEdit = [requireAuth, requireCapabilities('edit_posts')];
  const withId = validate({ params: idParams });

  router.get('/meta', async (req, res, next) => {
    try {
      const type = paramType(req);
      if (!type || isBuiltinContentKind(type) || RESERVED_CONTENT_SLUGS.has(type)) {
        throw NotFound('Post type not found.');
      }
      const site = await findPrimarySite();
      if (!site) throw NotFound('Post type not found.');
      const row = await PostType.findOne({
        where: { siteId: site.id, slug: type, active: true, public: true },
      });
      if (!row) throw NotFound('Post type not found.');
      res.json({
        slug: row.slug,
        singular: row.singular,
        plural: row.plural,
        hasArchive: row.hasArchive,
        archiveDesign: row.archiveDesign || 'list',
        singleDesign: row.singleDesign || 'default',
      });
    } catch (error) {
      next(error);
    }
  });

  router.use(requireActiveCpt);

  router.get('/public', c.publicList);
  router.get('/public/:slug', validate({ query: publicPageQuery }), c.publicBySlug);

  router.get('/', ...canEdit, c.list);
  router.get('/:id/revisions', ...canEdit, withId, c.listRevisions);
  router.post(
    '/:id/revisions/:revisionId/restore',
    ...canEdit,
    validate({ params: revisionParams }),
    c.restoreRevision,
  );
  router.post(
    '/:id/preview',
    ...canEdit,
    validate({ params: idParams, body: previewPageSchema }),
    c.preview,
  );
  router.get('/:id/presence', ...canEdit, withId, c.getPresence);
  router.post(
    '/:id/presence',
    ...canEdit,
    validate({ params: idParams, body: presenceSchema }),
    c.postPresence,
  );
  router.delete(
    '/:id/presence',
    ...canEdit,
    validate({ params: idParams, query: presenceLeaveQuery }),
    c.deletePresence,
  );
  router.get('/:id', ...canEdit, withId, c.get);
  router.post('/', ...canEdit, validate({ body: createPageSchema }), c.create);
  router.patch(
    '/:id',
    ...canEdit,
    validate({ params: idParams, body: updatePageSchema }),
    c.update,
  );
  router.post(
    '/:id/restore',
    requireAuth,
    requireCapabilities('delete_posts'),
    withId,
    c.restore,
  );
  router.delete(
    '/:id',
    requireAuth,
    requireCapabilities('delete_posts'),
    withId,
    c.remove,
  );
  return router;
}

export const pagesRoutes = contentRoutes('page');
export const postsRoutes = contentRoutes('post');
export const contentTypeRoutes = cptContentRoutes();
