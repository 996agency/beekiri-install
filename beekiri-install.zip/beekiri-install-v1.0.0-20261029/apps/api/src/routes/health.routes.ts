import { Router } from 'express';
import { healthController } from '../controllers/health.controller';

export const healthRoutes = Router();

healthRoutes.get('/', healthController.health);
healthRoutes.get('/ready', healthController.ready);
