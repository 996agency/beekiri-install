import { Router } from 'express';
import { beeSeoController as c } from '../controllers/bee-seo.controller';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import { validate } from '../middleware/validate';
import {
  beeSeoAuditSchema,
  beeSeoKeywordsSchema,
  beeSeoReportQuerySchema,
} from '../validators/bee-seo.schema';

export const beeSeoRoutes = Router();

const admin = [requireAuth, requireCapabilities('manage_options')];

beeSeoRoutes.get('/report', ...admin, validate({ query: beeSeoReportQuerySchema }), c.report);
beeSeoRoutes.get('/overview', ...admin, c.overview);
beeSeoRoutes.get('/backlinks', ...admin, c.backlinks);
beeSeoRoutes.post('/audit', ...admin, validate({ body: beeSeoAuditSchema }), c.audit);
beeSeoRoutes.post('/keywords', ...admin, validate({ body: beeSeoKeywordsSchema }), c.keywords);
