import { Router } from 'express';
import { beeCookiesController as c } from '../controllers/bee-cookies.controller';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import {
  beeCookiesClicksRateLimit,
  beeCookiesHeartbeatRateLimit,
  beeCookiesRateLimit,
  beeCookiesVisitRateLimit,
} from '../middleware/rate-limit';
import { validate } from '../middleware/validate';
import {
  beeCookieAnalyticsQuery,
  beeCookieClicksSchema,
  beeCookieConsentSchema,
  beeCookieHeartbeatSchema,
  beeCookieVisitSchema,
  beeCookiesSettingsSchema,
} from '../validators/bee-cookies.schema';

export const beeCookiesRoutes = Router();

const admin = [requireAuth, requireCapabilities('manage_options')];

beeCookiesRoutes.get('/config', c.publicConfig);
beeCookiesRoutes.post(
  '/consent',
  beeCookiesRateLimit,
  validate({ body: beeCookieConsentSchema }),
  c.consent,
);
beeCookiesRoutes.post(
  '/visit',
  beeCookiesVisitRateLimit,
  validate({ body: beeCookieVisitSchema }),
  c.visit,
);
beeCookiesRoutes.post(
  '/heartbeat',
  beeCookiesHeartbeatRateLimit,
  validate({ body: beeCookieHeartbeatSchema }),
  c.heartbeat,
);
beeCookiesRoutes.post(
  '/clicks',
  beeCookiesClicksRateLimit,
  validate({ body: beeCookieClicksSchema }),
  c.clicks,
);
beeCookiesRoutes.get('/settings', ...admin, c.getSettings);
beeCookiesRoutes.patch(
  '/settings',
  ...admin,
  validate({ body: beeCookiesSettingsSchema }),
  c.updateSettings,
);
beeCookiesRoutes.get(
  '/analytics',
  ...admin,
  validate({ query: beeCookieAnalyticsQuery }),
  c.analytics,
);
