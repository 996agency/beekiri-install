import { Router } from 'express';
import { usersController } from '../controllers/users.controller';
import {
  requireAuth,
  requireCapabilities,
  requireOwner,
  requireSelfOrCapability,
} from '../middleware/authenticate';
import { validate } from '../middleware/validate';
import { idParams } from '../validators/common';
import {
  createUserSchema,
  roleSlugParams,
  updateRoleSchema,
  updateUserPermissionsSchema,
  updateUserSchema,
} from '../validators/users.schema';

export const usersRoutes = Router();

usersRoutes.use(requireAuth);

usersRoutes.get('/roles', requireCapabilities('list_users'), usersController.roles);
usersRoutes.get('/roles/manage', requireOwner, usersController.rolesManage);
usersRoutes.patch(
  '/roles/:slug',
  requireOwner,
  validate({ params: roleSlugParams, body: updateRoleSchema }),
  usersController.updateRole,
);
usersRoutes.get('/permissions/catalog', requireOwner, usersController.permissionsCatalog);
usersRoutes.get('/permissions', requireOwner, usersController.permissionsOverview);
usersRoutes.patch(
  '/:id/permissions',
  requireOwner,
  validate({ params: idParams, body: updateUserPermissionsSchema }),
  usersController.updatePermissions,
);
usersRoutes.get('/', requireCapabilities('list_users'), usersController.list);
usersRoutes.get(
  '/:id',
  requireSelfOrCapability('list_users'),
  validate({ params: idParams }),
  usersController.get,
);
usersRoutes.post(
  '/',
  requireCapabilities('create_users'),
  validate({ body: createUserSchema }),
  usersController.create,
);
usersRoutes.patch(
  '/:id',
  requireSelfOrCapability('edit_users'),
  validate({ params: idParams, body: updateUserSchema }),
  usersController.update,
);
usersRoutes.delete(
  '/:id',
  requireCapabilities('delete_users'),
  validate({ params: idParams }),
  usersController.remove,
);
