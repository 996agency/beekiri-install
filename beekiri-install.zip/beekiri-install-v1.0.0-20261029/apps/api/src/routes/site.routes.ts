import { Router } from 'express';
import { siteController as c } from '../controllers/site.controller';
import { usersController } from '../controllers/users.controller';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import { validate } from '../middleware/validate';
import {
  dashboardLayoutBody,
  dashboardQuery,
  updateSiteSettingsSchema,
} from '../validators/site.schema';

export const siteRoutes = Router();

const admin = [requireAuth, requireCapabilities('manage_options')];

siteRoutes.get('/public', c.publicSite);
siteRoutes.get('/link-targets', ...admin, c.linkTargets);
siteRoutes.get('/page-editor', requireAuth, requireCapabilities('edit_pages'), c.pageEditor);
siteRoutes.get(
  '/dashboard',
  requireAuth,
  requireCapabilities('read'),
  validate({ query: dashboardQuery }),
  c.dashboard,
);
/** Per-user Overview layout — any signed-in user manages their own only. */
siteRoutes.get('/dashboard-layout', requireAuth, usersController.getDashboardLayout);
siteRoutes.put(
  '/dashboard-layout',
  requireAuth,
  validate({ body: dashboardLayoutBody }),
  usersController.setDashboardLayout,
);
siteRoutes.get('/settings', ...admin, c.getSettings);
siteRoutes.patch(
  '/settings',
  ...admin,
  validate({ body: updateSiteSettingsSchema }),
  c.updateSettings,
);
