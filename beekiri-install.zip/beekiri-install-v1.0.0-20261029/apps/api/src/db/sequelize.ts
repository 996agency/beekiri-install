import pg from 'pg';
import { Sequelize } from 'sequelize';
import { sequelizeOptions } from '../config/database';
import { config } from '../config/env';
import { createLogger } from '../utils/logger';

const log = createLogger('db');
const TIMESTAMP_WITHOUT_TZ_OID = 1114;

// pg reads TIMESTAMP WITHOUT TIME ZONE as server-local time; the stored values are UTC.
pg.types.setTypeParser(
  TIMESTAMP_WITHOUT_TZ_OID,
  (value: string) => new Date(`${value.replace(' ', 'T')}Z`),
);

export const sequelize = new Sequelize(sequelizeOptions());

/** Human-readable target for log lines (never includes credentials). */
export function databaseLabel(): string {
  const { name, host, port } = config.db;
  return `${name} on ${host ?? 'the local server'}${port ? `:${port}` : ''}`;
}

export async function connectDatabase({
  attempts = config.isTest ? 1 : 10,
  delayMs = 1_500,
}: { attempts?: number; delayMs?: number } = {}): Promise<void> {
  for (let attempt = 1; ; attempt++) {
    try {
      await sequelize.authenticate();
      return;
    } catch (error) {
      if (attempt >= attempts) throw error;
      log.warn(
        `Database not reachable (attempt ${attempt}/${attempts}): ${(error as Error).message}`,
      );
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }
}

export async function closeDatabase(): Promise<void> {
  await sequelize.close();
}

export async function pingDatabase(): Promise<boolean> {
  try {
    await sequelize.query('SELECT 1');
    return true;
  } catch {
    return false;
  }
}
