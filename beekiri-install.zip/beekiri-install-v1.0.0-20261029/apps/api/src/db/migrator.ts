import { readdirSync } from 'fs';
import { join } from 'path';
import { Client } from 'pg';
import { QueryTypes, type QueryInterface } from 'sequelize';
import { SequelizeStorage, Umzug } from 'umzug';
import { sslOptions } from '../config/database';
import { config } from '../config/env';
import { sequelize } from './sequelize';

/** Shape of every file in ./migrations (same as a sequelize-cli migration). */
export interface Migration {
  up(queryInterface: QueryInterface): Promise<void>;
  down(queryInterface: QueryInterface): Promise<void>;
}

const MIGRATIONS_DIR = join(__dirname, 'migrations');
const META_TABLE = 'SequelizeMeta';
/** Arbitrary constant: only one migrator may run against a database at a time. */
const MIGRATION_LOCK_KEY = 7_311_984_211;

function migrationFiles(): { name: string; path: string }[] {
  return readdirSync(MIGRATIONS_DIR)
    .filter((file) => /\.(ts|js)$/.test(file) && !file.endsWith('.d.ts'))
    .sort()
    .map((file) => ({
      // Same name whether running from src (.ts) or dist (.js).
      name: file.replace(/\.(ts|js)$/, ''),
      path: join(MIGRATIONS_DIR, file),
    }));
}

const storage = new SequelizeStorage({ sequelize, tableName: META_TABLE });

function createMigrator() {
  return new Umzug<QueryInterface>({
    migrations: migrationFiles().map(({ name, path }) => ({
      name,
      path,
      up: async ({ context }) => ((await import(path)) as Migration).up(context),
      down: async ({ context }) => ((await import(path)) as Migration).down(context),
    })),
    context: sequelize.getQueryInterface(),
    storage,
    logger: undefined,
  });
}

/**
 * Sites installed before the move to Sequelize were migrated by Prisma. Their finished
 * Prisma migrations carry the same names as ours, so they are recorded as executed
 * instead of being run a second time.
 */
async function adoptPrismaHistory(): Promise<string[]> {
  const [{ exists }] = await sequelize.query<{ exists: boolean }>(
    `SELECT to_regclass('"_prisma_migrations"') IS NOT NULL AS "exists"`,
    { type: QueryTypes.SELECT },
  );
  if (!exists) return [];

  const finished = await sequelize.query<{ name: string }>(
    `SELECT migration_name AS "name" FROM "_prisma_migrations"
     WHERE finished_at IS NOT NULL AND rolled_back_at IS NULL`,
    { type: QueryTypes.SELECT },
  );
  const known = new Set(migrationFiles().map((m) => m.name));
  const executed = new Set(await storage.executed());
  const adopted = finished
    .map((row) => row.name)
    .filter((name) => known.has(name) && !executed.has(name));
  for (const name of adopted) await storage.logMigration({ name });
  return adopted.sort();
}

/** Hold a Postgres advisory lock (on its own connection) so parallel deploys never migrate twice. */
async function withMigrationLock<T>(fn: () => Promise<T>): Promise<T> {
  const { db } = config;
  const ssl = sslOptions(db);
  const client = new Client({
    host: db.host,
    port: db.port,
    database: db.name,
    user: db.user,
    password: db.password,
    ...(ssl ? { ssl } : {}),
    application_name: 'beekiri-migrate',
  });
  await client.connect();
  try {
    await client.query('SELECT pg_advisory_lock($1)', [MIGRATION_LOCK_KEY]);
    return await fn();
  } finally {
    await client
      .query('SELECT pg_advisory_unlock($1)', [MIGRATION_LOCK_KEY])
      .catch(() => undefined);
    await client.end().catch(() => undefined);
  }
}

export type MigrationRun = { adopted: string[]; applied: string[] };

export async function runMigrations(): Promise<MigrationRun> {
  return withMigrationLock(async () => {
    const adopted = await adoptPrismaHistory();
    const applied = await createMigrator().up();
    return { adopted, applied: applied.map((m) => m.name) };
  });
}

export async function rollbackLastMigration(): Promise<string[]> {
  return withMigrationLock(async () => {
    const reverted = await createMigrator().down();
    return reverted.map((m) => m.name);
  });
}

export async function migrationStatus(): Promise<{ executed: string[]; pending: string[] }> {
  const migrator = createMigrator();
  // Sequential: each call creates the meta table on first use, and parallel CREATEs race.
  const executed = await migrator.executed();
  const pending = await migrator.pending();
  return { executed: executed.map((m) => m.name), pending: pending.map((m) => m.name) };
}
