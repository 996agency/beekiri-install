import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

/** WordPress-style revisions, plus who last saved each post. */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.addColumn(
      'Post',
      'updatedById',
      { type: DataTypes.TEXT, allowNull: true },
      { transaction },
    );

    await queryInterface.createTable(
      'PostRevision',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        postId: { type: DataTypes.TEXT, allowNull: false },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        title: { type: DataTypes.TEXT, allowNull: false },
        slug: { type: DataTypes.TEXT, allowNull: false },
        status: { type: DataTypes.TEXT, allowNull: false },
        content: { type: DataTypes.JSONB, allowNull: false },
        excerpt: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        /** User who authored this snapshot (editor at the time it was current). */
        authorId: { type: DataTypes.TEXT, allowNull: true },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );

    await queryInterface.addIndex('PostRevision', ['postId', 'createdAt'], {
      name: 'PostRevision_postId_createdAt_idx',
      transaction,
    });
    await queryInterface.addIndex('PostRevision', ['siteId'], {
      name: 'PostRevision_siteId_idx',
      transaction,
    });

    await queryInterface.addConstraint('PostRevision', {
      type: 'foreign key',
      name: 'PostRevision_postId_fkey',
      fields: ['postId'],
      references: { table: 'Post', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.dropTable('PostRevision', { transaction });
    await queryInterface.removeColumn('Post', 'updatedById', { transaction });
  });
}
