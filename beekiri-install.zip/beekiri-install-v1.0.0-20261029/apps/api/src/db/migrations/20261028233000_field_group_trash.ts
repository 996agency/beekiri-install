import { DataTypes, type QueryInterface } from 'sequelize';

/** Soft-delete field groups (Backend Fields trash). */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.addColumn('FieldGroup', 'trashedAt', {
    type: DataTypes.DATE(3),
    allowNull: true,
  });
  await queryInterface.addIndex('FieldGroup', ['siteId', 'trashedAt'], {
    name: 'FieldGroup_siteId_trashedAt_idx',
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.removeIndex('FieldGroup', 'FieldGroup_siteId_trashedAt_idx');
  await queryInterface.removeColumn('FieldGroup', 'trashedAt');
}
