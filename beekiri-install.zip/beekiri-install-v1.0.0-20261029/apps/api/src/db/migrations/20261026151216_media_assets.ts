import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.createTable(
      'MediaAsset',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        filename: { type: DataTypes.TEXT, allowNull: false },
        originalName: { type: DataTypes.TEXT, allowNull: false },
        mimeType: { type: DataTypes.TEXT, allowNull: false },
        size: { type: DataTypes.INTEGER, allowNull: false },
        width: { type: DataTypes.INTEGER, allowNull: true },
        height: { type: DataTypes.INTEGER, allowNull: true },
        /** Public URL path, e.g. /uploads/2026/10/abc.webp */
        url: { type: DataTypes.TEXT, allowNull: false },
        /** Path relative to MEDIA_LOCAL_PATH */
        storagePath: { type: DataTypes.TEXT, allowNull: false },
        folderId: { type: DataTypes.TEXT, allowNull: true },
        alt: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        uploadedById: { type: DataTypes.TEXT, allowNull: true },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false },
      },
      { transaction },
    );

    await queryInterface.addIndex('MediaAsset', ['siteId'], {
      name: 'MediaAsset_siteId_idx',
      transaction,
    });
    await queryInterface.addIndex('MediaAsset', ['folderId'], {
      name: 'MediaAsset_folderId_idx',
      transaction,
    });
    await queryInterface.addIndex('MediaAsset', ['createdAt'], {
      name: 'MediaAsset_createdAt_idx',
      transaction,
    });

    await queryInterface.addConstraint('MediaAsset', {
      type: 'foreign key',
      name: 'MediaAsset_siteId_fkey',
      fields: ['siteId'],
      references: { table: 'Site', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.dropTable('MediaAsset');
}
