import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

/** Custom post types, taxonomies and options pages registered via Backend Fields. */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.createTable(
      'PostType',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        slug: { type: DataTypes.TEXT, allowNull: false },
        singular: { type: DataTypes.TEXT, allowNull: false },
        plural: { type: DataTypes.TEXT, allowNull: false },
        description: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        public: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
        hierarchical: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
        hasArchive: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
        showInMenu: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
        /** title, editor, thumbnail, excerpt, custom-fields… */
        supports: { type: DataTypes.JSONB, allowNull: false, defaultValue: ['title', 'editor'] },
        active: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
        menuOrder: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false },
      },
      { transaction },
    );

    await queryInterface.createTable(
      'Taxonomy',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        slug: { type: DataTypes.TEXT, allowNull: false },
        singular: { type: DataTypes.TEXT, allowNull: false },
        plural: { type: DataTypes.TEXT, allowNull: false },
        description: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        hierarchical: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
        public: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
        /** Which post types this taxonomy attaches to: ["post","page","product"] */
        objectTypes: { type: DataTypes.JSONB, allowNull: false, defaultValue: ['post'] },
        active: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
        menuOrder: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false },
      },
      { transaction },
    );

    await queryInterface.createTable(
      'OptionsPage',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        title: { type: DataTypes.TEXT, allowNull: false },
        slug: { type: DataTypes.TEXT, allowNull: false },
        menuTitle: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        description: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        /** Parent options page slug, or empty for top-level */
        parentSlug: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        active: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
        menuOrder: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false },
      },
      { transaction },
    );

    for (const table of ['PostType', 'Taxonomy', 'OptionsPage']) {
      await queryInterface.addIndex(table, ['siteId'], {
        name: `${table}_siteId_idx`,
        transaction,
      });
      await queryInterface.addIndex(table, ['siteId', 'slug'], {
        name: `${table}_siteId_slug_key`,
        unique: true,
        transaction,
      });
    }

    for (const table of ['PostType', 'Taxonomy', 'OptionsPage']) {
      await queryInterface.addConstraint(table, {
        type: 'foreign key',
        name: `${table}_siteId_fkey`,
        fields: ['siteId'],
        references: { table: 'Site', field: 'id' },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
        transaction,
      });
    }
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    for (const table of ['OptionsPage', 'Taxonomy', 'PostType']) {
      await queryInterface.dropTable(table, { transaction });
    }
  });
}
