import { DataTypes, type QueryInterface } from 'sequelize';

export async function up(queryInterface: QueryInterface): Promise<void> {
  /** { jobDescription?: string, customFields?: { id, label, value }[] } */
  await queryInterface.addColumn('User', 'profile', {
    type: DataTypes.JSONB,
    allowNull: false,
    defaultValue: {},
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.removeColumn('User', 'profile');
}
