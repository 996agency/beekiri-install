import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

/** BeeCookies consent decisions and optional first-party page views. */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.createTable(
      'BeeCookieConsent',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        visitorId: { type: DataTypes.TEXT, allowNull: false },
        status: { type: DataTypes.TEXT, allowNull: false },
        essential: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
        functional: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
        analytics: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
        marketing: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
        device: { type: DataTypes.TEXT, allowNull: false, defaultValue: 'unknown' },
        country: { type: DataTypes.TEXT, allowNull: true },
        path: { type: DataTypes.TEXT, allowNull: false, defaultValue: '/' },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.addIndex('BeeCookieConsent', ['siteId', 'createdAt'], {
      name: 'BeeCookieConsent_siteId_createdAt_idx',
      transaction,
    });
    await queryInterface.addIndex('BeeCookieConsent', ['siteId', 'visitorId', 'createdAt'], {
      name: 'BeeCookieConsent_siteId_visitorId_createdAt_idx',
      transaction,
    });
    await queryInterface.addConstraint('BeeCookieConsent', {
      type: 'foreign key',
      name: 'BeeCookieConsent_siteId_fkey',
      fields: ['siteId'],
      references: { table: 'Site', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });

    await queryInterface.createTable(
      'BeeCookieVisit',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        visitorId: { type: DataTypes.TEXT, allowNull: false },
        path: { type: DataTypes.TEXT, allowNull: false },
        referrerHost: { type: DataTypes.TEXT, allowNull: true },
        device: { type: DataTypes.TEXT, allowNull: false, defaultValue: 'unknown' },
        country: { type: DataTypes.TEXT, allowNull: true },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.addIndex('BeeCookieVisit', ['siteId', 'createdAt'], {
      name: 'BeeCookieVisit_siteId_createdAt_idx',
      transaction,
    });
    await queryInterface.addIndex('BeeCookieVisit', ['siteId', 'path'], {
      name: 'BeeCookieVisit_siteId_path_idx',
      transaction,
    });
    await queryInterface.addConstraint('BeeCookieVisit', {
      type: 'foreign key',
      name: 'BeeCookieVisit_siteId_fkey',
      fields: ['siteId'],
      references: { table: 'Site', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.dropTable('BeeCookieVisit');
  await queryInterface.dropTable('BeeCookieConsent');
}
