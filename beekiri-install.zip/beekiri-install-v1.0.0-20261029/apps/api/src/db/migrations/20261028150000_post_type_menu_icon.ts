import { DataTypes, type QueryInterface } from 'sequelize';

/** Menu icon + archive/single design choices for custom post types. */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.addColumn(
      'PostType',
      'menuIcon',
      { type: DataTypes.TEXT, allowNull: false, defaultValue: 'Cube' },
      { transaction },
    );
    await queryInterface.addColumn(
      'PostType',
      'archiveDesign',
      { type: DataTypes.TEXT, allowNull: false, defaultValue: 'list' },
      { transaction },
    );
    await queryInterface.addColumn(
      'PostType',
      'singleDesign',
      { type: DataTypes.TEXT, allowNull: false, defaultValue: 'default' },
      { transaction },
    );
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.removeColumn('PostType', 'singleDesign', { transaction });
    await queryInterface.removeColumn('PostType', 'archiveDesign', { transaction });
    await queryInterface.removeColumn('PostType', 'menuIcon', { transaction });
  });
}
