import { DataTypes, type QueryInterface } from 'sequelize';

/** Featured image media id for pages, posts, and custom post types. */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.addColumn('Post', 'featuredImageId', {
    type: DataTypes.TEXT,
    allowNull: true,
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.removeColumn('Post', 'featuredImageId');
}
