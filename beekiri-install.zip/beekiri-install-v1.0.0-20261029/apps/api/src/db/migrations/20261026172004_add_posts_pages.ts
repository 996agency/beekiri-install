import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

/** Content documents: pages and posts. */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.createTable(
      'Post',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        /** "page" | "post" (and later custom post type slugs) */
        type: { type: DataTypes.TEXT, allowNull: false, defaultValue: 'page' },
        title: { type: DataTypes.TEXT, allowNull: false },
        slug: { type: DataTypes.TEXT, allowNull: false },
        /** "draft" | "publish" */
        status: { type: DataTypes.TEXT, allowNull: false, defaultValue: 'draft' },
        content: {
          type: DataTypes.JSONB,
          allowNull: false,
          defaultValue: { version: 1, html: '' },
        },
        excerpt: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        authorId: { type: DataTypes.TEXT, allowNull: true },
        parentId: { type: DataTypes.TEXT, allowNull: true },
        menuOrder: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        publishedAt: { type: TIMESTAMP, allowNull: true },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false },
      },
      { transaction },
    );

    await queryInterface.addIndex('Post', ['siteId', 'type', 'status'], {
      name: 'Post_siteId_type_status_idx',
      transaction,
    });
    await queryInterface.addIndex('Post', ['siteId', 'type', 'updatedAt'], {
      name: 'Post_siteId_type_updatedAt_idx',
      transaction,
    });
    await queryInterface.addIndex('Post', ['siteId', 'type', 'slug'], {
      name: 'Post_siteId_type_slug_key',
      unique: true,
      transaction,
    });

    await queryInterface.addConstraint('Post', {
      type: 'foreign key',
      name: 'Post_siteId_fkey',
      fields: ['siteId'],
      references: { table: 'Site', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.dropTable('Post');
}
