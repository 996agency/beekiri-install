import { DataTypes, literal, type QueryInterface } from 'sequelize';

/** Millisecond-precision UTC timestamps (TIMESTAMP(3) WITHOUT TIME ZONE). */
const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.createTable(
      'Site',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        title: { type: DataTypes.TEXT, allowNull: false },
        tagline: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        language: { type: DataTypes.TEXT, allowNull: false, defaultValue: 'en_US' },
        installedAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false },
      },
      { transaction },
    );

    await queryInterface.createTable(
      'SiteSettings',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        blogPublic: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
        timezone: { type: DataTypes.TEXT, allowNull: false, defaultValue: 'UTC' },
        dateFormat: { type: DataTypes.TEXT, allowNull: false, defaultValue: 'F j, Y' },
        timeFormat: { type: DataTypes.TEXT, allowNull: false, defaultValue: 'g:i a' },
        options: { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },
      },
      { transaction },
    );

    await queryInterface.createTable(
      'Role',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        slug: { type: DataTypes.TEXT, allowNull: false },
        name: { type: DataTypes.TEXT, allowNull: false },
      },
      { transaction },
    );

    await queryInterface.createTable(
      'Capability',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        slug: { type: DataTypes.TEXT, allowNull: false },
        name: { type: DataTypes.TEXT, allowNull: false },
      },
      { transaction },
    );

    await queryInterface.createTable(
      'User',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        username: { type: DataTypes.TEXT, allowNull: false },
        email: { type: DataTypes.TEXT, allowNull: false },
        displayName: { type: DataTypes.TEXT, allowNull: false },
        passwordHash: { type: DataTypes.TEXT, allowNull: false },
        roleId: { type: DataTypes.TEXT, allowNull: false },
        isOwner: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false },
      },
      { transaction },
    );

    await queryInterface.createTable(
      'Session',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        userId: { type: DataTypes.TEXT, allowNull: false },
        tokenHash: { type: DataTypes.TEXT, allowNull: false },
        csrfSecret: { type: DataTypes.TEXT, allowNull: false },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        lastSeenAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        absoluteExpiresAt: { type: TIMESTAMP, allowNull: false },
        idleExpiresAt: { type: TIMESTAMP, allowNull: false },
        userAgent: { type: DataTypes.TEXT, allowNull: true },
        ip: { type: DataTypes.TEXT, allowNull: true },
      },
      { transaction },
    );

    await queryInterface.createTable(
      'PasswordResetToken',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        userId: { type: DataTypes.TEXT, allowNull: false },
        tokenHash: { type: DataTypes.TEXT, allowNull: false },
        expiresAt: { type: TIMESTAMP, allowNull: false },
        usedAt: { type: TIMESTAMP, allowNull: true },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );

    await queryInterface.createTable(
      'AuditLog',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: true },
        userId: { type: DataTypes.TEXT, allowNull: true },
        action: { type: DataTypes.TEXT, allowNull: false },
        meta: { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },
        ip: { type: DataTypes.TEXT, allowNull: true },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );

    // Single row (id = 1) that concurrent installs contend on.
    await queryInterface.createTable(
      'InstallationState',
      {
        id: { type: DataTypes.INTEGER, allowNull: false, primaryKey: true, defaultValue: 1 },
        installed: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
        installedAt: { type: TIMESTAMP, allowNull: true },
        lockedAt: { type: TIMESTAMP, allowNull: true },
        lockOwner: { type: DataTypes.TEXT, allowNull: true },
      },
      { transaction },
    );

    // Role <-> Capability join table: A = Capability.id, B = Role.id.
    await queryInterface.createTable(
      '_CapabilityToRole',
      {
        A: { type: DataTypes.TEXT, allowNull: false },
        B: { type: DataTypes.TEXT, allowNull: false },
      },
      { transaction },
    );
    await queryInterface.addConstraint('_CapabilityToRole', {
      type: 'primary key',
      name: '_CapabilityToRole_AB_pkey',
      fields: ['A', 'B'],
      transaction,
    });

    await queryInterface.addIndex('SiteSettings', ['siteId'], {
      name: 'SiteSettings_siteId_key',
      unique: true,
      transaction,
    });
    await queryInterface.addIndex('Role', ['slug'], {
      name: 'Role_slug_key',
      unique: true,
      transaction,
    });
    await queryInterface.addIndex('Capability', ['slug'], {
      name: 'Capability_slug_key',
      unique: true,
      transaction,
    });
    await queryInterface.addIndex('User', ['email'], { name: 'User_email_idx', transaction });
    await queryInterface.addIndex('User', ['username'], { name: 'User_username_idx', transaction });
    await queryInterface.addIndex('User', ['siteId', 'username'], {
      name: 'User_siteId_username_key',
      unique: true,
      transaction,
    });
    await queryInterface.addIndex('User', ['siteId', 'email'], {
      name: 'User_siteId_email_key',
      unique: true,
      transaction,
    });
    await queryInterface.addIndex('Session', ['tokenHash'], {
      name: 'Session_tokenHash_key',
      unique: true,
      transaction,
    });
    await queryInterface.addIndex('Session', ['userId'], {
      name: 'Session_userId_idx',
      transaction,
    });
    await queryInterface.addIndex('PasswordResetToken', ['tokenHash'], {
      name: 'PasswordResetToken_tokenHash_key',
      unique: true,
      transaction,
    });
    await queryInterface.addIndex('PasswordResetToken', ['userId'], {
      name: 'PasswordResetToken_userId_idx',
      transaction,
    });
    await queryInterface.addIndex('AuditLog', ['action'], {
      name: 'AuditLog_action_idx',
      transaction,
    });
    await queryInterface.addIndex('AuditLog', ['createdAt'], {
      name: 'AuditLog_createdAt_idx',
      transaction,
    });
    await queryInterface.addIndex('_CapabilityToRole', ['B'], {
      name: '_CapabilityToRole_B_index',
      transaction,
    });

    await queryInterface.addConstraint('SiteSettings', {
      type: 'foreign key',
      name: 'SiteSettings_siteId_fkey',
      fields: ['siteId'],
      references: { table: 'Site', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
    await queryInterface.addConstraint('User', {
      type: 'foreign key',
      name: 'User_siteId_fkey',
      fields: ['siteId'],
      references: { table: 'Site', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
    await queryInterface.addConstraint('User', {
      type: 'foreign key',
      name: 'User_roleId_fkey',
      fields: ['roleId'],
      references: { table: 'Role', field: 'id' },
      onDelete: 'RESTRICT',
      onUpdate: 'CASCADE',
      transaction,
    });
    await queryInterface.addConstraint('Session', {
      type: 'foreign key',
      name: 'Session_userId_fkey',
      fields: ['userId'],
      references: { table: 'User', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
    await queryInterface.addConstraint('PasswordResetToken', {
      type: 'foreign key',
      name: 'PasswordResetToken_userId_fkey',
      fields: ['userId'],
      references: { table: 'User', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
    await queryInterface.addConstraint('AuditLog', {
      type: 'foreign key',
      name: 'AuditLog_siteId_fkey',
      fields: ['siteId'],
      references: { table: 'Site', field: 'id' },
      onDelete: 'SET NULL',
      onUpdate: 'CASCADE',
      transaction,
    });
    await queryInterface.addConstraint('AuditLog', {
      type: 'foreign key',
      name: 'AuditLog_userId_fkey',
      fields: ['userId'],
      references: { table: 'User', field: 'id' },
      onDelete: 'SET NULL',
      onUpdate: 'CASCADE',
      transaction,
    });
    await queryInterface.addConstraint('_CapabilityToRole', {
      type: 'foreign key',
      name: '_CapabilityToRole_A_fkey',
      fields: ['A'],
      references: { table: 'Capability', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
    await queryInterface.addConstraint('_CapabilityToRole', {
      type: 'foreign key',
      name: '_CapabilityToRole_B_fkey',
      fields: ['B'],
      references: { table: 'Role', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    for (const table of [
      '_CapabilityToRole',
      'InstallationState',
      'AuditLog',
      'PasswordResetToken',
      'Session',
      'User',
      'Capability',
      'Role',
      'SiteSettings',
      'Site',
    ]) {
      await queryInterface.dropTable(table, { transaction });
    }
  });
}
