import { DataTypes, type QueryInterface } from 'sequelize';

/** Extra visit dimensions for Umami-style analytics breakdowns. */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.addColumn(
      'BeeCookieVisit',
      'browser',
      { type: DataTypes.TEXT, allowNull: true },
      { transaction },
    );
    await queryInterface.addColumn(
      'BeeCookieVisit',
      'os',
      { type: DataTypes.TEXT, allowNull: true },
      { transaction },
    );
    await queryInterface.addColumn(
      'BeeCookieVisit',
      'language',
      { type: DataTypes.TEXT, allowNull: true },
      { transaction },
    );
    await queryInterface.addColumn(
      'BeeCookieVisit',
      'screen',
      { type: DataTypes.TEXT, allowNull: true },
      { transaction },
    );
    await queryInterface.addColumn(
      'BeeCookieVisit',
      'title',
      { type: DataTypes.TEXT, allowNull: true },
      { transaction },
    );
    await queryInterface.addColumn(
      'BeeCookieVisit',
      'channel',
      { type: DataTypes.TEXT, allowNull: true },
      { transaction },
    );
    await queryInterface.addColumn(
      'BeeCookieVisit',
      'utmSource',
      { type: DataTypes.TEXT, allowNull: true },
      { transaction },
    );
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    for (const col of ['browser', 'os', 'language', 'screen', 'title', 'channel', 'utmSource']) {
      await queryInterface.removeColumn('BeeCookieVisit', col, { transaction });
    }
  });
}
