import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

/** First-party click points for page heatmaps (consent-gated). */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.createTable(
      'BeeCookieClick',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        visitorId: { type: DataTypes.TEXT, allowNull: false },
        path: { type: DataTypes.TEXT, allowNull: false },
        xPct: { type: DataTypes.DOUBLE, allowNull: false },
        yPct: { type: DataTypes.DOUBLE, allowNull: false },
        device: { type: DataTypes.TEXT, allowNull: false, defaultValue: 'unknown' },
        viewportW: { type: DataTypes.INTEGER, allowNull: true },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.addIndex('BeeCookieClick', ['siteId', 'path', 'createdAt'], {
      name: 'BeeCookieClick_siteId_path_createdAt_idx',
      transaction,
    });
    await queryInterface.addIndex('BeeCookieClick', ['siteId', 'createdAt'], {
      name: 'BeeCookieClick_siteId_createdAt_idx',
      transaction,
    });
    await queryInterface.addConstraint('BeeCookieClick', {
      type: 'foreign key',
      name: 'BeeCookieClick_siteId_fkey',
      fields: ['siteId'],
      references: { table: 'Site', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.dropTable('BeeCookieClick');
}
