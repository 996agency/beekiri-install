import { existsSync, writeFileSync } from 'fs';
import { join } from 'path';
import { closeDatabase, connectDatabase, databaseLabel } from './sequelize';
import { migrationStatus, rollbackLastMigration, runMigrations } from './migrator';

const USAGE = 'Usage: db:migrate [up | status | down | create <name>]';

const TEMPLATE = `import { DataTypes, type QueryInterface } from 'sequelize';

export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    // await queryInterface.addColumn('Post', 'newColumn', { type: DataTypes.TEXT, allowNull: true }, { transaction });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    // await queryInterface.removeColumn('Post', 'newColumn', { transaction });
  });
}
`;

/** 20261027143000 — same timestamp prefix as the existing migrations. */
function timestamp(): string {
  return new Date().toISOString().replace(/\D/g, '').slice(0, 14);
}

function createMigration(name: string | undefined): void {
  const slug = (name ?? '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_|_$/g, '');
  if (!slug) throw new Error('Usage: db:migrate:create <name>');

  const file = join(__dirname, 'migrations', `${timestamp()}_${slug}.ts`);
  if (existsSync(file)) throw new Error(`${file} already exists.`);
  writeFileSync(file, TEMPLATE);
  console.log(`Created ${file}`);
}

async function up(): Promise<void> {
  const { adopted, applied } = await runMigrations();
  if (adopted.length) {
    console.log(
      `Recorded ${adopted.length} migration(s) already applied by Prisma:\n  ${adopted.join('\n  ')}`,
    );
  }
  console.log(
    applied.length
      ? `Applied ${applied.length} migration(s):\n  ${applied.join('\n  ')}`
      : 'Database is up to date.',
  );
}

async function status(): Promise<void> {
  const { executed, pending } = await migrationStatus();
  for (const name of executed) console.log(`  [x] ${name}`);
  for (const name of pending) console.log(`  [ ] ${name}`);
  console.log(
    pending.length ? `${pending.length} pending. Run: pnpm db:migrate` : 'Database is up to date.',
  );
}

async function down(): Promise<void> {
  const reverted = await rollbackLastMigration();
  console.log(reverted.length ? `Reverted ${reverted.join(', ')}` : 'Nothing to revert.');
}

async function main(): Promise<void> {
  const [command = 'up', arg] = process.argv.slice(2);
  if (command === 'create') return createMigration(arg);

  const commands: Record<string, () => Promise<void>> = { up, status, down };
  const run = commands[command];
  if (!run) throw new Error(`Unknown command "${command}". ${USAGE}`);

  await connectDatabase({ attempts: 3 });
  console.log(`Database ${databaseLabel()}`);
  await run();
}

main()
  .catch((error: unknown) => {
    console.error(`Migration failed: ${error instanceof Error ? error.message : String(error)}`);
    process.exitCode = 1;
  })
  .finally(() => closeDatabase().catch(() => undefined));
