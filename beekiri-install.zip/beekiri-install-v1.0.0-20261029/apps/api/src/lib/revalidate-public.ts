import { config } from '../config/env';
import { getSelfUrl } from '../config/runtime';
import { createLogger } from '../utils/logger';

const log = createLogger('cache');

/**
 * Ask the public Next.js app to drop ISR for specific paths (best-effort).
 * Used after saving a published page so "View page" matches the editor immediately.
 */
export async function revalidatePublicPaths(paths: string[]): Promise<void> {
  const unique = [
    ...new Set(
      paths
        .map((p) => (typeof p === 'string' ? p.trim() : ''))
        .filter((p) => p.startsWith('/')),
    ),
  ];
  if (!unique.length) return;

  const webUrl = getSelfUrl();
  const secret = config.core.cacheFlushSecret?.trim() ?? '';
  if (!webUrl || !secret) return;

  try {
    const res = await fetch(`${webUrl}/web-api/cache/flush`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${secret}`,
        'x-beekiri-flush': secret,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ paths: unique }),
    });
    if (!res.ok) {
      log.warn(`Path revalidate failed (${res.status}) for ${unique.join(', ')}`);
    }
  } catch (e) {
    log.warn(
      `Path revalidate request failed: ${e instanceof Error ? e.message : 'unknown error'}`,
    );
  }
}
