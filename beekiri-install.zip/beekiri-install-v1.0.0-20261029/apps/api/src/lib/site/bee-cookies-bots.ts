/** Quiet reject for crawlers and scripted clients — no IP stored. */

const BOT_UA =
  /bot|crawler|spider|slurp|headless|phantom|selenium|puppeteer|playwright|curl\/|wget|python-requests|go-http|java\/|libwww|httpclient|scrapy|ahrefs|semrush|mj12|dotbot|petalbot|bytespider|gptbot|claudebot|amazonbot|yandex|baidu|duckduck|facebookexternalhit|ia_archiver|pingdom|uptimerobot|statuscake|monitor|preview/i;

export function isLikelyBot(userAgent: string | undefined): boolean {
  const ua = (userAgent ?? '').trim();
  if (!ua || ua.length < 12) return true;
  if (BOT_UA.test(ua)) return true;
  return false;
}
