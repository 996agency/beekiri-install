import { parseBeeCookies, type BeeCookiesOptions } from './bee-cookies';
import { parseConnector, type ConnectorOptions } from './connector';
import { parseGoogleAnalytics, type GoogleAnalyticsOptions } from './google-analytics';

/** SiteSettings.options JSON — General / Google Business / Permalinks / menu / media. */

export type MenuItemOption = {
  id: string;
  label: string;
  path: string;
  enabled: boolean;
  source?: string;
  refId?: string;
  children?: MenuItemOption[];
};

export type MediaFolderOption = {
  id: string;
  name: string;
  slug: string;
  /** null = top-level folder */
  parentId: string | null;
};

/** Upload pipeline defaults: Full HD, WebP. */
export type MediaSettingsOption = {
  convertToWebp: boolean;
  /** Lossless WebP (no quality loss). Prefer this for “full quality”. */
  webpLossless: boolean;
  /** Used when webpLossless is false (1–100). */
  webpQuality: number;
  /** Longest edge max — Full HD = 1920 */
  maxWidth: number;
  maxHeight: number;
  stripMetadata: boolean;
  keepOriginal: boolean;
  folders: MediaFolderOption[];
};

/** Default site favicon (admin + public) when none is configured. */
export const DEFAULT_FAVICON_PATH = '/beekiri-logo.png';

export type SiteOptions = {
  businessName?: string;
  businessCategory?: string;
  businessPhone?: string;
  businessAddress?: string;
  businessHours?: string;
  businessImageUrl?: string;
  /** Absolute URL or site-relative path. Empty → DEFAULT_FAVICON_PATH. */
  faviconUrl?: string;
  permalinkStructure?: 'plain' | 'postname' | 'dayname' | 'custom';
  permalinkCustom?: string;
  menuItems?: MenuItemOption[];
  /** Published page id used as the site home (`/`). */
  frontPageId?: string;
  /** Fallback slug when frontPageId is missing (e.g. `home`). */
  frontPageSlug?: string;
  media?: MediaSettingsOption;
  /** Backend Fields module settings */
  backendFields?: {
    showAdminBar?: boolean;
    exportFormat?: 'php' | 'json';
    deleteWithContent?: boolean;
  };
  /** Active public theme slug (filesystem under /themes). */
  activeTheme?: string;
  /** Active theme header chrome slug (from theme.json headers). */
  activeHeader?: string;
  /** Active theme footer chrome slug (from theme.json footers). */
  activeFooter?: string;
  /** Page editor surface — BeekiriCode only. */
  pageEditorStyle?: 'beekiricode';
  /**
   * Which theme entry files the public site runs (layouts, header, footer):
   * - php — `{slug}.php`
   * - react — `{slug}.tsx`
   * Chosen once in the installer and locked; changing it requires a site reset.
   */
  frontendRuntime?: FrontendRuntime;
  /**
   * Bumped by Settings → Cache full flush so theme/layout asset URLs
   * (`?v=`) change and browsers + CDNs refetch minified CSS/JS.
   */
  cacheEpoch?: number;
  /** Settings → BeeCookies */
  beeCookies?: BeeCookiesOptions;
  /** Analytics → Google Analytics connection */
  googleAnalytics?: GoogleAnalyticsOptions;
  /** Admin → Connector (pay-as-you-go + AI agents) */
  connector?: ConnectorOptions;
};

/** Frontend runtimes the installer can offer. `available: false` = shown as coming soon. */
export const FRONTEND_RUNTIMES = [
  { id: 'php', label: 'PHP', available: true },
  { id: 'react', label: 'React', available: true },
  { id: 'vue', label: 'Vue', available: false },
] as const;

export type FrontendRuntime = 'php' | 'react';

export const AVAILABLE_FRONTEND_RUNTIMES: FrontendRuntime[] = ['php', 'react'];

const DEFAULT_MENU: MenuItemOption[] = [
  { id: 'home', label: 'Home', path: '/', enabled: true, source: 'home' },
  { id: 'blog', label: 'Blog', path: '/blog', enabled: true, source: 'home' },
  {
    id: 'about',
    label: 'About',
    path: '/about',
    enabled: true,
    source: 'custom',
    children: [
      { id: 'about-team', label: 'Team', path: '/about/team', enabled: true, source: 'custom' },
    ],
  },
  { id: 'contact', label: 'Contact', path: '/contact', enabled: false, source: 'custom' },
];

export const DEFAULT_MEDIA: MediaSettingsOption = {
  convertToWebp: true,
  webpLossless: true,
  webpQuality: 100,
  maxWidth: 1920,
  maxHeight: 1920,
  stripMetadata: true,
  keepOriginal: false,
  folders: [
    { id: 'general', name: 'General', slug: 'general', parentId: null },
    { id: 'heroes', name: 'Heroes', slug: 'heroes', parentId: null },
    { id: 'blog', name: 'Blog', slug: 'blog', parentId: null },
  ],
};

function asString(v: unknown): string | undefined {
  return typeof v === 'string' ? v : undefined;
}

function asBool(v: unknown, fallback: boolean): boolean {
  return typeof v === 'boolean' ? v : fallback;
}

function asInt(v: unknown, fallback: number, min: number, max: number): number {
  const n = typeof v === 'number' ? v : Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
}

function parseMenuItem(row: unknown): MenuItemOption | null {
  if (!row || typeof row !== 'object') return null;
  const r = row as Record<string, unknown>;
  const id = asString(r.id);
  const label = asString(r.label);
  const path = asString(r.path);
  if (!id || !label || path === undefined) return null;
  const childrenRaw = Array.isArray(r.children) ? r.children : [];
  const children = childrenRaw.map(parseMenuItem).filter((c): c is MenuItemOption => Boolean(c));
  return {
    id,
    label,
    path,
    enabled: Boolean(r.enabled),
    source: asString(r.source),
    refId: asString(r.refId),
    children: children.length ? children : undefined,
  };
}

function parseMenuItems(raw: unknown): MenuItemOption[] | undefined {
  if (!Array.isArray(raw)) return undefined;
  const items = raw.map(parseMenuItem).filter((c): c is MenuItemOption => Boolean(c));
  return items.length ? items : undefined;
}

function parseFolders(raw: unknown): MediaFolderOption[] {
  if (!Array.isArray(raw)) return [...DEFAULT_MEDIA.folders];
  const out: MediaFolderOption[] = [];
  const ids = new Set<string>();
  for (const row of raw) {
    if (!row || typeof row !== 'object') continue;
    const r = row as Record<string, unknown>;
    const id = asString(r.id);
    const name = asString(r.name);
    const slug = asString(r.slug);
    if (!id || !name || !slug) continue;
    ids.add(id);
    const parentRaw = r.parentId;
    const parentId =
      parentRaw === null || parentRaw === undefined || parentRaw === ''
        ? null
        : (asString(parentRaw) ?? null);
    out.push({ id, name, slug, parentId });
  }
  // Drop broken parent links (orphan → promote to root)
  for (const f of out) {
    if (f.parentId && !ids.has(f.parentId)) f.parentId = null;
  }
  return out.length ? out : [...DEFAULT_MEDIA.folders];
}

export function parseMediaSettings(raw: unknown): MediaSettingsOption {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return { ...DEFAULT_MEDIA, folders: [...DEFAULT_MEDIA.folders] };
  }
  const o = raw as Record<string, unknown>;
  return {
    convertToWebp: asBool(o.convertToWebp, DEFAULT_MEDIA.convertToWebp),
    webpLossless: asBool(o.webpLossless, DEFAULT_MEDIA.webpLossless),
    webpQuality: asInt(o.webpQuality, DEFAULT_MEDIA.webpQuality, 1, 100),
    maxWidth: asInt(o.maxWidth, DEFAULT_MEDIA.maxWidth, 320, 7680),
    maxHeight: asInt(o.maxHeight, DEFAULT_MEDIA.maxHeight, 320, 7680),
    stripMetadata: asBool(o.stripMetadata, DEFAULT_MEDIA.stripMetadata),
    keepOriginal: asBool(o.keepOriginal, DEFAULT_MEDIA.keepOriginal),
    folders: parseFolders(o.folders),
  };
}

export function readOptions(raw: unknown): SiteOptions {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const o = raw as Record<string, unknown>;
  const structure = asString(o.permalinkStructure);
  const permalinkStructure =
    structure === 'plain' ||
    structure === 'postname' ||
    structure === 'dayname' ||
    structure === 'custom'
      ? structure
      : undefined;

  return {
    businessName: asString(o.businessName),
    businessCategory: asString(o.businessCategory),
    businessPhone: asString(o.businessPhone),
    businessAddress: asString(o.businessAddress),
    businessHours: asString(o.businessHours),
    businessImageUrl: asString(o.businessImageUrl),
    faviconUrl: asString(o.faviconUrl),
    permalinkStructure,
    permalinkCustom: asString(o.permalinkCustom),
    menuItems: parseMenuItems(o.menuItems),
    frontPageId: asString(o.frontPageId),
    frontPageSlug: asString(o.frontPageSlug),
    media: o.media !== undefined ? parseMediaSettings(o.media) : undefined,
    backendFields:
      o.backendFields && typeof o.backendFields === 'object' && !Array.isArray(o.backendFields)
        ? {
            showAdminBar: asBool((o.backendFields as Record<string, unknown>).showAdminBar, true),
            exportFormat:
              (o.backendFields as Record<string, unknown>).exportFormat === 'php' ? 'php' : 'json',
            deleteWithContent: asBool(
              (o.backendFields as Record<string, unknown>).deleteWithContent,
              false,
            ),
          }
        : undefined,
    activeTheme: asString(o.activeTheme),
    activeHeader: asString(o.activeHeader),
    activeFooter: asString(o.activeFooter),
    pageEditorStyle: 'beekiricode',
    // Default PHP. React only when explicitly set.
    frontendRuntime: o.frontendRuntime === 'react' ? 'react' : 'php',
    cacheEpoch: typeof o.cacheEpoch === 'number' && o.cacheEpoch > 0 ? o.cacheEpoch : undefined,
    beeCookies: o.beeCookies !== undefined ? parseBeeCookies(o.beeCookies) : undefined,
    googleAnalytics:
      o.googleAnalytics !== undefined ? parseGoogleAnalytics(o.googleAnalytics) : undefined,
    connector: o.connector !== undefined ? parseConnector(o.connector) : undefined,
  };
}

export function resolveFaviconUrl(raw?: string | null): string {
  const v = (raw ?? '').trim();
  return v || DEFAULT_FAVICON_PATH;
}

export function defaultMenuItems(): MenuItemOption[] {
  return JSON.parse(JSON.stringify(DEFAULT_MENU)) as MenuItemOption[];
}

/** Enabled menu items only (recursive) — what the public site renders. */
export function publicMenuItems(opts: SiteOptions): MenuItemOption[] {
  const prune = (items: MenuItemOption[]): MenuItemOption[] =>
    items
      .filter((m) => m.enabled)
      .map((m) => ({
        ...m,
        children: m.children?.length ? prune(m.children) : undefined,
      }));
  return prune(opts.menuItems?.length ? opts.menuItems : defaultMenuItems());
}

export function defaultMediaSettings(): MediaSettingsOption {
  return JSON.parse(JSON.stringify(DEFAULT_MEDIA)) as MediaSettingsOption;
}

export function mergeSiteOptions(existing: unknown, patch: Partial<SiteOptions>): SiteOptions {
  const base = { ...readOptions(existing) };
  for (const key of Object.keys(patch) as (keyof SiteOptions)[]) {
    if (patch[key] !== undefined) {
      (base as Record<string, unknown>)[key] = patch[key];
    }
  }
  return base;
}
