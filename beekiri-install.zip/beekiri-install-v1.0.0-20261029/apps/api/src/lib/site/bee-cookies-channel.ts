/** Traffic channel + UTM helpers — Umami-style referrer grouping. */

const SEARCH_HOSTS = new Set([
  'google.com',
  'google.co.uk',
  'bing.com',
  'yahoo.com',
  'duckduckgo.com',
  'yandex.com',
  'yandex.ru',
  'baidu.com',
  'ecosia.org',
]);

const SOCIAL_HOSTS = new Set([
  'facebook.com',
  'fb.com',
  'instagram.com',
  'twitter.com',
  'x.com',
  'linkedin.com',
  't.co',
  'reddit.com',
  'pinterest.com',
  'tiktok.com',
  'youtube.com',
  'whatsapp.com',
  'telegram.org',
  'threads.net',
]);

function rootHost(host: string): string {
  const h = host.toLowerCase().replace(/^www\./, '');
  const parts = h.split('.');
  if (parts.length <= 2) return h;
  // google.co.uk → keep last 3
  if (parts[parts.length - 2] === 'co' || parts[parts.length - 2] === 'com') {
    return parts.slice(-3).join('.');
  }
  return parts.slice(-2).join('.');
}

export function channelOf(referrerHost: string | null | undefined, utmSource?: string | null): string {
  if (utmSource?.trim()) return 'Campaign';
  if (!referrerHost) return 'Direct';
  const host = rootHost(referrerHost);
  if (SEARCH_HOSTS.has(host) || host.startsWith('google.')) return 'Search';
  if (SOCIAL_HOSTS.has(host)) return 'Social';
  return 'Referral';
}

export function utmSourceFromPath(pathWithQuery: string): string | null {
  const q = pathWithQuery.includes('?') ? pathWithQuery.slice(pathWithQuery.indexOf('?') + 1) : '';
  if (!q) return null;
  try {
    const params = new URLSearchParams(q);
    const src = (params.get('utm_source') || '').trim().slice(0, 120);
    return src || null;
  } catch {
    return null;
  }
}

export function pathOnly(pathWithQuery: string): string {
  const i = pathWithQuery.indexOf('?');
  const p = (i >= 0 ? pathWithQuery.slice(0, i) : pathWithQuery).trim() || '/';
  return p.startsWith('/') ? p.slice(0, 500) : `/${p.slice(0, 499)}`;
}
