/** Optional Google Analytics 4 connection (Settings on Analytics). */

export type GoogleAnalyticsOptions = {
  /** Public measurement ID, e.g. G-XXXXXXXX. Injected only after analytics consent. */
  measurementId: string;
  /** GA4 numeric property id for the Data API. */
  propertyId: string;
  /** Service-account JSON. Never returned to the admin UI. */
  serviceAccountJson: string;
};

export const DEFAULT_GOOGLE_ANALYTICS: GoogleAnalyticsOptions = {
  measurementId: '',
  propertyId: '',
  serviceAccountJson: '',
};

function asString(v: unknown, fallback = ''): string {
  return typeof v === 'string' ? v : fallback;
}

export function parseGoogleAnalytics(raw: unknown): GoogleAnalyticsOptions {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return { ...DEFAULT_GOOGLE_ANALYTICS };
  }
  const o = raw as Record<string, unknown>;
  const measurementId = asString(o.measurementId).trim().toUpperCase().slice(0, 20);
  const propertyId = asString(o.propertyId).replace(/\D/g, '').slice(0, 20);
  return {
    measurementId: /^G-[A-Z0-9]+$/.test(measurementId) ? measurementId : '',
    propertyId,
    serviceAccountJson: asString(o.serviceAccountJson).slice(0, 20_000),
  };
}

export function googleAccountEmail(json: string): string {
  try {
    const parsed = JSON.parse(json) as { client_email?: unknown };
    return typeof parsed.client_email === 'string' ? parsed.client_email : '';
  } catch {
    return '';
  }
}

export function publicGoogleAnalytics(opts: GoogleAnalyticsOptions) {
  const email = googleAccountEmail(opts.serviceAccountJson);
  return {
    measurementId: opts.measurementId,
    propertyId: opts.propertyId,
    connected: Boolean(opts.propertyId && opts.serviceAccountJson && email),
    clientEmail: email,
  };
}
