/** Lightweight UA parse — inspired by Umami-style browser/OS breakdowns. No IP. */

export function browserOf(ua: string | undefined): string {
  const s = ua ?? '';
  if (!s) return 'Unknown';
  if (/Edg\//i.test(s)) return 'Edge';
  if (/OPR\/|Opera/i.test(s)) return 'Opera';
  if (/SamsungBrowser/i.test(s)) return 'Samsung Internet';
  if (/Firefox\//i.test(s)) return 'Firefox';
  if (/Chrome\//i.test(s) && !/Chromium/i.test(s)) return 'Chrome';
  if (/CriOS\//i.test(s)) return 'Chrome';
  if (/Safari\//i.test(s) && !/Chrome|Chromium|CriOS/i.test(s)) return 'Safari';
  if (/MSIE |Trident\//i.test(s)) return 'IE';
  return 'Other';
}

export function osOf(ua: string | undefined): string {
  const s = ua ?? '';
  if (!s) return 'Unknown';
  if (/Android/i.test(s)) return 'Android';
  if (/iPhone|iPad|iPod/i.test(s)) return 'iOS';
  if (/Windows NT/i.test(s)) return 'Windows';
  if (/Mac OS X|Macintosh/i.test(s)) return 'macOS';
  if (/CrOS/i.test(s)) return 'Chrome OS';
  if (/Linux/i.test(s)) return 'Linux';
  return 'Other';
}
