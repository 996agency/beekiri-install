/** BeeCookies: consent banner + first-party analytics (Settings → BeeCookies). */

export const BEE_COOKIE_CATEGORIES = ['essential', 'functional', 'analytics', 'marketing'] as const;
export type BeeCookieCategory = (typeof BEE_COOKIE_CATEGORIES)[number];

export const BEE_COOKIE_POSITIONS = ['bottom', 'bottom-left', 'bottom-right'] as const;
export type BeeCookiePosition = (typeof BEE_COOKIE_POSITIONS)[number];

export type BeeCookieCategoryCopy = {
  enabled: boolean;
  label: string;
  description: string;
};

export type BeeCookiesOptions = {
  enabled: boolean;
  position: BeeCookiePosition;
  bannerTitle: string;
  bannerMessage: string;
  acceptLabel: string;
  rejectLabel: string;
  preferencesLabel: string;
  saveLabel: string;
  privacyPolicyUrl: string;
  /** Record page views only after analytics consent. */
  trackPageViews: boolean;
  categories: Record<BeeCookieCategory, BeeCookieCategoryCopy>;
};

const CATEGORY_DEFAULTS: Record<BeeCookieCategory, BeeCookieCategoryCopy> = {
  essential: {
    enabled: true,
    label: 'Essential',
    description: 'Required for the site to work, including remembering your cookie choice.',
  },
  functional: {
    enabled: true,
    label: 'Functional',
    description: 'Remember preferences such as language or layout.',
  },
  analytics: {
    enabled: true,
    label: 'Analytics',
    description: 'Help us understand how visitors use the site. No advertising profiles.',
  },
  marketing: {
    enabled: false,
    label: 'Marketing',
    description: 'Measure campaigns. Off until you turn this category on.',
  },
};

export const DEFAULT_BEE_COOKIES: BeeCookiesOptions = {
  enabled: false,
  position: 'bottom-left',
  bannerTitle: 'We use cookies',
  bannerMessage:
    'Cookies help this website remember your preferences and understand how it is used. Essential cookies are always on. You can accept or reject optional cookies.',
  acceptLabel: 'Accept all',
  rejectLabel: 'Reject optional',
  preferencesLabel: 'Preferences',
  saveLabel: 'Save preferences',
  privacyPolicyUrl: '',
  trackPageViews: true,
  categories: {
    essential: { ...CATEGORY_DEFAULTS.essential },
    functional: { ...CATEGORY_DEFAULTS.functional },
    analytics: { ...CATEGORY_DEFAULTS.analytics },
    marketing: { ...CATEGORY_DEFAULTS.marketing },
  },
};

function asString(v: unknown, fallback = ''): string {
  return typeof v === 'string' ? v : fallback;
}

function asBool(v: unknown, fallback: boolean): boolean {
  return typeof v === 'boolean' ? v : fallback;
}

function parseCategory(
  raw: unknown,
  key: BeeCookieCategory,
): BeeCookieCategoryCopy {
  const fallback = CATEGORY_DEFAULTS[key];
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return { ...fallback };
  const o = raw as Record<string, unknown>;
  return {
    enabled: key === 'essential' ? true : asBool(o.enabled, fallback.enabled),
    label: asString(o.label, fallback.label).slice(0, 80) || fallback.label,
    description: asString(o.description, fallback.description).slice(0, 400) || fallback.description,
  };
}

export function parseBeeCookies(raw: unknown): BeeCookiesOptions {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return structuredClone(DEFAULT_BEE_COOKIES);
  }
  const o = raw as Record<string, unknown>;
  const cats =
    o.categories && typeof o.categories === 'object' && !Array.isArray(o.categories)
      ? (o.categories as Record<string, unknown>)
      : {};
  const position = BEE_COOKIE_POSITIONS.includes(o.position as BeeCookiePosition)
    ? (o.position as BeeCookiePosition)
    : DEFAULT_BEE_COOKIES.position;
  return {
    enabled: asBool(o.enabled, false),
    position,
    bannerTitle: asString(o.bannerTitle, DEFAULT_BEE_COOKIES.bannerTitle).slice(0, 120),
    bannerMessage: asString(o.bannerMessage, DEFAULT_BEE_COOKIES.bannerMessage).slice(0, 800),
    acceptLabel: asString(o.acceptLabel, DEFAULT_BEE_COOKIES.acceptLabel).slice(0, 40),
    rejectLabel: asString(o.rejectLabel, DEFAULT_BEE_COOKIES.rejectLabel).slice(0, 40),
    preferencesLabel: asString(o.preferencesLabel, DEFAULT_BEE_COOKIES.preferencesLabel).slice(0, 40),
    saveLabel: asString(o.saveLabel, DEFAULT_BEE_COOKIES.saveLabel).slice(0, 40),
    privacyPolicyUrl: asString(o.privacyPolicyUrl).slice(0, 500),
    trackPageViews: asBool(o.trackPageViews, true),
    categories: {
      essential: parseCategory(cats.essential, 'essential'),
      functional: parseCategory(cats.functional, 'functional'),
      analytics: parseCategory(cats.analytics, 'analytics'),
      marketing: parseCategory(cats.marketing, 'marketing'),
    },
  };
}

/** Public config: no admin-only fields. */
export function publicBeeCookies(opts: BeeCookiesOptions) {
  return {
    enabled: opts.enabled,
    position: opts.position,
    bannerTitle: opts.bannerTitle,
    bannerMessage: opts.bannerMessage,
    acceptLabel: opts.acceptLabel,
    rejectLabel: opts.rejectLabel,
    preferencesLabel: opts.preferencesLabel,
    saveLabel: opts.saveLabel,
    privacyPolicyUrl: opts.privacyPolicyUrl,
    trackPageViews: opts.trackPageViews,
    categories: opts.categories,
  };
}
