/** In-memory presence for “users live now”. Heartbeats only; no IP. */

type Presence = { siteId: string; at: number; path: string };

/** Active visitors window — Umami uses ~5 minutes. */
export const LIVE_TTL_MS = 5 * 60_000;

const presence = new Map<string, Presence>();

function key(siteId: string, visitorId: string) {
  return `${siteId}:${visitorId}`;
}

function prune(now = Date.now()) {
  for (const [k, v] of presence) {
    if (v.at + LIVE_TTL_MS < now) presence.delete(k);
  }
}

export function touchLive(siteId: string, visitorId: string, path: string) {
  presence.set(key(siteId, visitorId), { siteId, at: Date.now(), path: path.slice(0, 500) });
}

export function countLive(siteId: string): number {
  const now = Date.now();
  prune(now);
  let n = 0;
  for (const v of presence.values()) {
    if (v.siteId === siteId && v.at + LIVE_TTL_MS >= now) n += 1;
  }
  return n;
}

/** Last path + age for admin peek (optional). */
export function listLive(siteId: string): { path: string; secondsAgo: number }[] {
  const now = Date.now();
  prune(now);
  const rows: { path: string; secondsAgo: number }[] = [];
  for (const v of presence.values()) {
    if (v.siteId !== siteId || v.at + LIVE_TTL_MS < now) continue;
    rows.push({ path: v.path, secondsAgo: Math.max(0, Math.round((now - v.at) / 1000)) });
  }
  rows.sort((a, b) => a.secondsAgo - b.secondsAgo);
  return rows.slice(0, 40);
}
