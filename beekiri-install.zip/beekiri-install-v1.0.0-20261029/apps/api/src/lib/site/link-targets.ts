/** Link targets for the Permalinks menu picker. */

export type LinkTarget = {
  id: string;
  label: string;
  path: string;
  source: 'home' | 'page' | 'post' | 'taxonomy' | 'custom';
  kind?: string;
};

/** System + content targets. Content lists fill in when Posts/Pages/Taxonomies ship. */
export function listLinkTargets(): {
  system: LinkTarget[];
  pages: LinkTarget[];
  posts: LinkTarget[];
  taxonomies: LinkTarget[];
} {
  return {
    system: [
      { id: 'home', label: 'Home', path: '/', source: 'home' },
      { id: 'blog', label: 'Blog', path: '/blog', source: 'home', kind: 'archive' },
    ],
    // Phase 2: query Page / Post / Term models here
    pages: [],
    posts: [],
    taxonomies: [],
  };
}
