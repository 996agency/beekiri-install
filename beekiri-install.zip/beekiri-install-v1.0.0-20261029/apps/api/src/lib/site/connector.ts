/** Connector: AI providers the site can use. */

export const CONNECTOR_PROVIDER_IDS = [
  'beequeen',
  'claude',
  'openai',
  'gemini',
  'grok',
] as const;

export type ConnectorProviderId = (typeof CONNECTOR_PROVIDER_IDS)[number];

export type ConnectorProviderState = {
  id: ConnectorProviderId;
  enabled: boolean;
  /** Provider API key (never returned in full to the client). */
  apiKey: string;
  /** Preferred model id for this provider. */
  defaultModel: string;
};

export type ConnectorOptions = {
  providers: Record<ConnectorProviderId, ConnectorProviderState>;
};

export type ConnectorProviderCatalog = {
  id: ConnectorProviderId;
  name: string;
  vendor: string;
  blurb: string;
  badge?: string;
  docsUrl: string;
  apiKeyLabel: string;
  apiKeyPlaceholder: string;
  models: { id: string; label: string }[];
};

/** Catalog order = Beekiri agent first, then third-party providers. */
export const CONNECTOR_PROVIDER_CATALOG: ConnectorProviderCatalog[] = [
  {
    id: 'beequeen',
    name: 'BeeQueen',
    vendor: 'Beekiri',
    blurb: 'Beekiri’s theme layout agent — model API wiring coming soon.',
    docsUrl: 'https://beekiri.com',
    apiKeyLabel: 'BeeQueen access key',
    apiKeyPlaceholder: 'bq-…',
    models: [
      { id: 'beequeen', label: 'BeeQueen' },
      { id: 'beequeen-fast', label: 'BeeQueen Fast' },
    ],
  },
  {
    id: 'claude',
    name: 'Claude',
    vendor: 'Anthropic',
    blurb: 'Strongest for long writing, editing, and careful site work.',
    docsUrl: 'https://console.anthropic.com/settings/keys',
    apiKeyLabel: 'Anthropic API key',
    apiKeyPlaceholder: 'sk-ant-…',
    models: [
      { id: 'claude-sonnet-4-5', label: 'Claude Sonnet 4.5' },
      { id: 'claude-opus-4-5', label: 'Claude Opus 4.5' },
      { id: 'claude-haiku-4-5', label: 'Claude Haiku 4.5' },
    ],
  },
  {
    id: 'openai',
    name: 'ChatGPT',
    vendor: 'OpenAI',
    blurb: 'Versatile models for drafts, ideas, and everyday assistance.',
    docsUrl: 'https://platform.openai.com/api-keys',
    apiKeyLabel: 'OpenAI API key',
    apiKeyPlaceholder: 'sk-…',
    models: [
      { id: 'gpt-5.2', label: 'GPT-5.2' },
      { id: 'gpt-5-mini', label: 'GPT-5 mini' },
      { id: 'gpt-4.1', label: 'GPT-4.1' },
    ],
  },
  {
    id: 'gemini',
    name: 'Gemini',
    vendor: 'Google',
    blurb: 'Fast multimodal models with strong research-style answers.',
    docsUrl: 'https://aistudio.google.com/apikey',
    apiKeyLabel: 'Google AI API key',
    apiKeyPlaceholder: 'AIza…',
    models: [
      { id: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro' },
      { id: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash' },
      { id: 'gemini-2.0-flash', label: 'Gemini 2.0 Flash' },
    ],
  },
  {
    id: 'grok',
    name: 'Grok',
    vendor: 'xAI',
    blurb: 'Realtime-flavored answers with a bold, conversational style.',
    docsUrl: 'https://console.x.ai/',
    apiKeyLabel: 'xAI API key',
    apiKeyPlaceholder: 'xai-…',
    models: [
      { id: 'grok-3', label: 'Grok 3' },
      { id: 'grok-3-mini', label: 'Grok 3 mini' },
      { id: 'grok-2', label: 'Grok 2' },
    ],
  },
];

function defaultModelFor(id: ConnectorProviderId): string {
  return CONNECTOR_PROVIDER_CATALOG.find((p) => p.id === id)?.models[0]?.id ?? '';
}

export const DEFAULT_CONNECTOR: ConnectorOptions = {
  providers: {
    beequeen: {
      id: 'beequeen',
      enabled: false,
      apiKey: '',
      defaultModel: defaultModelFor('beequeen'),
    },
    claude: { id: 'claude', enabled: false, apiKey: '', defaultModel: defaultModelFor('claude') },
    openai: { id: 'openai', enabled: false, apiKey: '', defaultModel: defaultModelFor('openai') },
    gemini: { id: 'gemini', enabled: false, apiKey: '', defaultModel: defaultModelFor('gemini') },
    grok: { id: 'grok', enabled: false, apiKey: '', defaultModel: defaultModelFor('grok') },
  },
};

function asBool(v: unknown, fallback: boolean): boolean {
  return typeof v === 'boolean' ? v : fallback;
}

function asString(v: unknown, fallback = ''): string {
  return typeof v === 'string' ? v : fallback;
}

export function isConnectorProviderId(v: string): v is ConnectorProviderId {
  return (CONNECTOR_PROVIDER_IDS as readonly string[]).includes(v);
}

export function maskApiKey(key: string): string | null {
  const k = key.trim();
  if (!k) return null;
  if (k.length <= 8) return '••••••••';
  return `${k.slice(0, 4)}…${k.slice(-4)}`;
}

export function parseConnector(raw: unknown): ConnectorOptions {
  const o = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
  const providersRaw =
    o.providers && typeof o.providers === 'object'
      ? (o.providers as Record<string, unknown>)
      : {};

  const providers = { ...DEFAULT_CONNECTOR.providers };
  for (const id of CONNECTOR_PROVIDER_IDS) {
    const row = providersRaw[id];
    const r = row && typeof row === 'object' ? (row as Record<string, unknown>) : {};
    const models = CONNECTOR_PROVIDER_CATALOG.find((p) => p.id === id)?.models ?? [];
    const model = asString(r.defaultModel, defaultModelFor(id));
    providers[id] = {
      id,
      enabled: asBool(r.enabled, false),
      apiKey: asString(r.apiKey, ''),
      defaultModel: models.some((m) => m.id === model) ? model : defaultModelFor(id),
    };
  }

  return { providers };
}
