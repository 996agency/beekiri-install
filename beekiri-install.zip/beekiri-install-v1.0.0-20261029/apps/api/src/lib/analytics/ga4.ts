import { createSign } from 'node:crypto';
import { googleAccountEmail } from '../site/google-analytics';

type ServiceAccount = { client_email: string; private_key: string };

type TokenCache = { email: string; token: string; exp: number };

let cache: TokenCache | null = null;

function parseAccount(json: string): ServiceAccount {
  let parsed: unknown;
  try {
    parsed = JSON.parse(json);
  } catch {
    throw new Error('The service account file is not valid JSON.');
  }
  if (!parsed || typeof parsed !== 'object') {
    throw new Error('The service account file is not valid JSON.');
  }
  const o = parsed as Record<string, unknown>;
  if (typeof o.client_email !== 'string' || typeof o.private_key !== 'string') {
    throw new Error('The service account must include client_email and private_key.');
  }
  return { client_email: o.client_email, private_key: o.private_key.replace(/\\n/g, '\n') };
}

function jwtFor(sa: ServiceAccount): string {
  const now = Math.floor(Date.now() / 1000);
  const header = Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })).toString('base64url');
  const payload = Buffer.from(
    JSON.stringify({
      iss: sa.client_email,
      scope: 'https://www.googleapis.com/auth/analytics.readonly',
      aud: 'https://oauth2.googleapis.com/token',
      iat: now,
      exp: now + 3600,
    }),
  ).toString('base64url');
  const sign = createSign('RSA-SHA256');
  sign.update(`${header}.${payload}`);
  const sig = sign.sign(sa.private_key, 'base64url');
  return `${header}.${payload}.${sig}`;
}

async function accessToken(json: string): Promise<string> {
  const email = googleAccountEmail(json);
  if (cache && cache.email === email && cache.exp > Date.now() + 30_000) return cache.token;
  const sa = parseAccount(json);
  const body = new URLSearchParams({
    grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
    assertion: jwtFor(sa),
  });
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  });
  const data = (await res.json()) as { access_token?: string; expires_in?: number; error?: string };
  if (!res.ok || !data.access_token) {
    throw new Error('Google could not sign in that service account.');
  }
  const exp = Date.now() + Math.max(60, Number(data.expires_in) || 3600) * 1000;
  cache = { email: sa.client_email, token: data.access_token, exp };
  return data.access_token;
}

export type Ga4Row = { dims: string[]; metrics: number[] };

export type Ga4Report = {
  rows: Ga4Row[];
  totals: number[];
};

async function runReport(
  token: string,
  propertyId: string,
  spec: {
    dimensions?: string[];
    metrics: string[];
    startDate: string;
    endDate: string;
    limit?: number;
    orderByMetric?: string;
  },
): Promise<Ga4Report> {
  const res = await fetch(
    `https://analyticsdata.googleapis.com/v1beta/properties/${propertyId}:runReport`,
    {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        dateRanges: [{ startDate: spec.startDate, endDate: spec.endDate }],
        dimensions: (spec.dimensions ?? []).map((name) => ({ name })),
        metrics: spec.metrics.map((name) => ({ name })),
        limit: spec.limit ?? '10',
        orderBys: spec.orderByMetric
          ? [{ metric: { metricName: spec.orderByMetric }, desc: true }]
          : undefined,
      }),
    },
  );
  const data = (await res.json()) as {
    error?: { message?: string };
    rows?: Array<{ dimensionValues?: { value?: string }[]; metricValues?: { value?: string }[] }>;
    totals?: Array<{ metricValues?: { value?: string }[] }>;
  };
  if (!res.ok) {
    throw new Error(data.error?.message || 'Google Analytics did not return a report.');
  }
  const num = (v: string | undefined) => Number(v) || 0;
  return {
    rows: (data.rows ?? []).map((row) => ({
      dims: (row.dimensionValues ?? []).map((d) => d.value ?? ''),
      metrics: (row.metricValues ?? []).map((m) => num(m.value)),
    })),
    totals: (data.totals?.[0]?.metricValues ?? []).map((m) => num(m.value)),
  };
}

export async function fetchGa4Bundle(
  propertyId: string,
  serviceAccountJson: string,
  startDate: string,
  endDate: string,
) {
  const token = await accessToken(serviceAccountJson);
  const metrics = [
    'totalUsers',
    'newUsers',
    'sessions',
    'screenPageViews',
    'bounceRate',
    'averageSessionDuration',
    'engagedSessions',
  ];
  const [kpis, trend, pages, landing, sources, countries, devices] = await Promise.all([
    runReport(token, propertyId, { metrics, startDate, endDate, limit: 1 }),
    runReport(token, propertyId, {
      dimensions: ['date'],
      metrics: ['totalUsers', 'sessions', 'screenPageViews'],
      startDate,
      endDate,
      limit: 120,
    }),
    runReport(token, propertyId, {
      dimensions: ['pagePath'],
      metrics: ['screenPageViews', 'totalUsers'],
      startDate,
      endDate,
      limit: 12,
      orderByMetric: 'screenPageViews',
    }),
    runReport(token, propertyId, {
      dimensions: ['landingPage'],
      metrics: ['sessions'],
      startDate,
      endDate,
      limit: 8,
      orderByMetric: 'sessions',
    }),
    runReport(token, propertyId, {
      dimensions: ['sessionSource'],
      metrics: ['sessions'],
      startDate,
      endDate,
      limit: 8,
      orderByMetric: 'sessions',
    }),
    runReport(token, propertyId, {
      dimensions: ['countryId'],
      metrics: ['totalUsers'],
      startDate,
      endDate,
      limit: 8,
      orderByMetric: 'totalUsers',
    }),
    runReport(token, propertyId, {
      dimensions: ['deviceCategory'],
      metrics: ['totalUsers'],
      startDate,
      endDate,
      limit: 6,
      orderByMetric: 'totalUsers',
    }),
  ]);
  return { kpis, trend, pages, landing, sources, countries, devices };
}
