import { randomBytes } from 'crypto';

/** Short opaque id for filenames (not a DB primary key). */
export function createId(bytes = 6): string {
  return randomBytes(bytes).toString('hex');
}
