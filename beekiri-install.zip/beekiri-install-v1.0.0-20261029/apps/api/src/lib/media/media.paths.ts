import { config } from '../../config/env';

/** Media library files (MEDIA_LOCAL_PATH), served at /uploads. */
export function resolveUploadsRoot(): string {
  return config.media.root;
}
