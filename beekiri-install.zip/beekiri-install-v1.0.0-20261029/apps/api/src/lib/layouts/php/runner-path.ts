import { existsSync } from 'fs';
import { join } from 'path';

/** Locate layout-runner.php for both `tsx` (src) and compiled dist builds. */
export function resolveLayoutRunnerPath(): string | null {
  const candidates = [
    join(__dirname, 'layout-runner.php'),
    join(process.cwd(), 'apps/api/src/lib/layouts/php/layout-runner.php'),
    join(process.cwd(), 'src/lib/layouts/php/layout-runner.php'),
  ];
  return candidates.find((p) => existsSync(p)) ?? null;
}
