import { readFileSync } from 'fs';
import { join } from 'path';
import { config } from '../../config/env';
import { API_ROOT, REPO_ROOT } from '../../config/paths';

export type CoreManifest = {
  name: string;
  coreVersion: string;
  releaseRepo: string;
  minNode: string;
  channel: string;
  notes?: string;
};

/** The repo-root manifest is authoritative (core updates replace it); apps/api keeps a copy. */
const MANIFEST_PATHS = [
  join(REPO_ROOT, 'beekiri.manifest.json'),
  join(API_ROOT, 'beekiri.manifest.json'),
];

/** Installed Beekiri Core version and release channel. */
export function readCoreManifest(): CoreManifest {
  for (const path of MANIFEST_PATHS) {
    try {
      const manifest = JSON.parse(readFileSync(path, 'utf8')) as Partial<CoreManifest>;
      if (manifest.coreVersion) {
        return {
          name: manifest.name ?? 'beekiri-cms',
          coreVersion: manifest.coreVersion,
          releaseRepo: manifest.releaseRepo ?? config.core.releaseRepo,
          minNode: manifest.minNode ?? '20',
          channel: manifest.channel ?? 'stable',
          notes: manifest.notes,
        };
      }
    } catch {
      // Missing or unreadable: try the next location.
    }
  }
  return {
    name: 'beekiri-cms',
    coreVersion: config.core.fallbackVersion,
    releaseRepo: config.core.releaseRepo,
    minNode: '20',
    channel: 'stable',
  };
}
