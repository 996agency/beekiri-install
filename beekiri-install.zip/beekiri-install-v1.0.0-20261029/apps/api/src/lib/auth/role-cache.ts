import { Capability, Role } from '../../models';
import { createLogger } from '../../utils/logger';
import type { CapabilitySlug } from '../cms-types';
import { applyRoleCache, isCapabilitySlug } from './role-capabilities';

const log = createLogger('role-cache');

/** Load Role.name + linked Capability slugs from the DB into the request-time cache. */
export async function refreshRoleCapabilityCache(): Promise<void> {
  const roles = await Role.findAll({
    include: [{ model: Capability, as: 'capabilities' }],
    order: [['slug', 'ASC']],
  });
  applyRoleCache(
    roles.map((role) => ({
      slug: role.slug,
      name: role.name,
      capabilities: (role.capabilities ?? [])
        .map((c) => c.slug)
        .filter(isCapabilitySlug) as CapabilitySlug[],
    })),
  );
  log.info(`Loaded ${roles.length} role definition(s) into cache.`);
}
