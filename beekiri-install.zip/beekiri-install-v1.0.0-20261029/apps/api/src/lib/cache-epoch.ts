import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'fs';
import { dirname, join } from 'path';
import { API_ROOT } from '../config/paths';

/** Tiny on-disk epoch so sync listPublic() can bust asset URLs without async DB. */
export function cacheEpochPath(): string {
  return join(API_ROOT, '.cache-epoch');
}

export function readCacheEpoch(): number {
  try {
    const raw = readFileSync(cacheEpochPath(), 'utf8').trim();
    const n = Number(raw);
    return Number.isFinite(n) && n > 0 ? Math.floor(n) : 0;
  } catch {
    return 0;
  }
}

export function bumpCacheEpoch(): number {
  const next = Date.now();
  const path = cacheEpochPath();
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, String(next), 'utf8');
  return next;
}

export function cacheEpochExists(): boolean {
  return existsSync(cacheEpochPath());
}
