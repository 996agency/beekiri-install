import { existsSync, readFileSync, readdirSync } from 'fs';
import { join } from 'path';
import { REPO_ROOT } from '../../config/paths';

/** Official parent theme. Core updates replace files in this folder. */
export const PARENT_THEME_SLUG = 'beekiri';
/** Default active theme. Site-specific overrides; never overwritten by core updates. */
export const DEFAULT_THEME_SLUG = 'beekiri-child';

/** Themes that ship with the CMS — cannot be deleted. */
export const BUILTIN_THEME_SLUGS = new Set([PARENT_THEME_SLUG, DEFAULT_THEME_SLUG]);

export function resolveThemeSlug(raw: string): string {
  return sanitizeThemeSlug(raw);
}

/** Site-wide theme parts rendered around every page. */
export type ThemeChromeKind = 'header' | 'footer';

export const THEME_CHROME_KINDS: ThemeChromeKind[] = ['header', 'footer'];

export type ThemeChromeEntry = {
  slug: string;
  title: string;
  /** Folder inside the theme, e.g. `header` → themes/{theme}/header/ */
  path: string;
  description?: string;
  default?: boolean;
};

/** @deprecated Use ThemeChromeEntry */
export type ThemeChromeHeader = ThemeChromeEntry;

export type ThemeManifest = {
  slug: string;
  name: string;
  version: string;
  description: string;
  author: string;
  tags: string[];
  /** Parent theme slug (WordPress-style child theme). */
  parent?: string;
  requires?: string;
  screenshot?: string;
  stylesheet?: string;
  chrome?: Partial<Record<ThemeChromeKind, string>>;
  headers?: ThemeChromeEntry[];
  footers?: ThemeChromeEntry[];
  builtin: boolean;
};

/** Built-in fallback when the themes folder is missing. */
const BUILTIN: ThemeManifest[] = [
  {
    slug: PARENT_THEME_SLUG,
    name: 'Beekiri',
    version: '1.0.0',
    description:
      'Official parent theme. Copy a file into Beekiri Child to override it.',
    author: '996agency',
    tags: ['starter', 'parent', 'blog', 'business'],
    requires: '1.0.0',
    screenshot: 'screenshot.svg',
    stylesheet: 'style.css',
    builtin: true,
  },
  {
    slug: DEFAULT_THEME_SLUG,
    name: 'Beekiri Child',
    parent: PARENT_THEME_SLUG,
    version: '1.0.0',
    description:
      'Default theme. Edit files here so core updates do not overwrite your work.',
    author: '996agency',
    tags: ['child', 'custom'],
    requires: '1.0.0',
    screenshot: 'screenshot.svg',
    stylesheet: 'style.css',
    builtin: true,
  },
];

export function resolveThemesRoot(): string {
  // Frontend themes live with the public web app.
  return join(REPO_ROOT, 'apps/web/themes');
}

export function sanitizeThemeSlug(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/[^a-z0-9-_]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
}

export function isThemeChromeKind(raw: string): raw is ThemeChromeKind {
  return (THEME_CHROME_KINDS as string[]).includes(raw);
}

function parseChromeEntries(raw: unknown): ThemeChromeEntry[] | undefined {
  if (!Array.isArray(raw)) return undefined;
  const out: ThemeChromeEntry[] = [];
  for (const row of raw) {
    if (!row || typeof row !== 'object' || Array.isArray(row)) continue;
    const r = row as Record<string, unknown>;
    const slug = typeof r.slug === 'string' ? sanitizeThemeSlug(r.slug) : '';
    if (!slug) continue;
    const path =
      typeof r.path === 'string' && r.path.trim() ? r.path.trim().replace(/^\/+|\/+$/g, '') : slug;
    if (path.includes('..') || path.includes('\\')) continue;
    out.push({
      slug,
      title: typeof r.title === 'string' && r.title.trim() ? r.title.trim() : slug,
      path,
      description: typeof r.description === 'string' ? r.description.trim() : undefined,
      default: r.default === true,
    });
  }
  return out.length ? out : undefined;
}

function parseChrome(raw: unknown): ThemeManifest['chrome'] {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return undefined;
  const r = raw as Record<string, unknown>;
  const chrome: ThemeManifest['chrome'] = {};
  for (const kind of THEME_CHROME_KINDS) {
    if (typeof r[kind] === 'string') chrome[kind] = sanitizeThemeSlug(r[kind] as string);
  }
  return chrome;
}

function readManifest(dir: string, slug: string): ThemeManifest | null {
  const file = join(dir, 'theme.json');
  if (!existsSync(file)) return null;
  try {
    const raw = JSON.parse(readFileSync(file, 'utf8')) as Record<string, unknown>;
    const name = typeof raw.name === 'string' ? raw.name.trim() : '';
    if (!name) return null;
    const resolvedSlug =
      typeof raw.slug === 'string' && raw.slug.trim()
        ? sanitizeThemeSlug(raw.slug)
        : sanitizeThemeSlug(slug);
    if (!resolvedSlug) return null;
    const parentRaw = typeof raw.parent === 'string' ? resolveThemeSlug(raw.parent) : '';
    const parent = parentRaw && parentRaw !== resolvedSlug ? parentRaw : undefined;
    return {
      slug: resolvedSlug,
      name,
      version: typeof raw.version === 'string' ? raw.version : '1.0.0',
      description: typeof raw.description === 'string' ? raw.description : '',
      author: typeof raw.author === 'string' ? raw.author : '',
      tags: Array.isArray(raw.tags)
        ? raw.tags.filter((t): t is string => typeof t === 'string')
        : [],
      parent,
      requires: typeof raw.requires === 'string' ? raw.requires : undefined,
      screenshot: typeof raw.screenshot === 'string' ? raw.screenshot : 'screenshot.svg',
      stylesheet: typeof raw.stylesheet === 'string' ? raw.stylesheet : 'style.css',
      chrome: parseChrome(raw.chrome),
      headers: parseChromeEntries(raw.headers),
      footers: parseChromeEntries(raw.footers),
      builtin: BUILTIN_THEME_SLUGS.has(resolvedSlug),
    };
  } catch {
    return null;
  }
}

export function listThemeManifests(): ThemeManifest[] {
  const root = resolveThemesRoot();
  const bySlug = new Map<string, ThemeManifest>();

  for (const theme of BUILTIN) bySlug.set(theme.slug, theme);

  if (existsSync(root)) {
    for (const entry of readdirSync(root, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      if (entry.name.startsWith('.')) continue;
      const manifest = readManifest(join(root, entry.name), entry.name);
      if (!manifest) continue;
      // Prefer filesystem copy for builtins (local edits), keep builtin flag.
      bySlug.set(manifest.slug, {
        ...manifest,
        builtin: BUILTIN_THEME_SLUGS.has(manifest.slug),
      });
    }
  }

  return [...bySlug.values()].sort((a, b) => {
    if (a.slug === DEFAULT_THEME_SLUG) return -1;
    if (b.slug === DEFAULT_THEME_SLUG) return 1;
    return a.name.localeCompare(b.name);
  });
}

export function getThemeManifest(slug: string): ThemeManifest | null {
  const clean = resolveThemeSlug(slug);
  return listThemeManifests().find((t) => t.slug === clean) ?? null;
}

/** Active theme first, then each parent. Used to locate a file the child did not override. */
export function themeAncestry(slug: string): string[] {
  const seen = new Set<string>();
  const chain: string[] = [];
  let current = resolveThemeSlug(slug);
  while (current && !seen.has(current) && chain.length < 4) {
    seen.add(current);
    const manifest = listThemeManifests().find((t) => t.slug === current);
    if (!manifest) break;
    chain.push(manifest.slug);
    current = manifest.parent ? resolveThemeSlug(manifest.parent) : '';
  }
  return chain;
}

function isSafeRel(rel: string): boolean {
  return Boolean(rel) && !rel.includes('..') && !rel.includes('\\') && !rel.startsWith('/');
}

/** First existing file along the child → parent chain. */
export function resolveThemePath(slug: string, rel: string): string | null {
  if (!isSafeRel(rel)) return null;
  const root = resolveThemesRoot();
  for (const theme of themeAncestry(slug)) {
    const abs = join(root, theme, rel);
    if (existsSync(abs)) return abs;
  }
  return null;
}

/** Theme folder that contains `rel`, or null. */
export function themeOwningPath(slug: string, rel: string): string | null {
  if (!isSafeRel(rel)) return null;
  const root = resolveThemesRoot();
  for (const theme of themeAncestry(slug)) {
    if (existsSync(join(root, theme, rel))) return theme;
  }
  return null;
}

export function resolveThemeFile(slug: string, file: string): string | null {
  if (!file || file.includes('/') || file.includes('\\') || file.includes('..')) return null;
  return resolveThemePath(slug, file);
}

export function resolveThemeDir(slug: string): string | null {
  const clean = resolveThemeSlug(slug);
  if (!clean) return null;
  const abs = join(resolveThemesRoot(), clean);
  return existsSync(abs) ? abs : null;
}

/**
 * Theme folder for site-specific writes (layouts, CPT stubs, chrome overrides).
 * Never the parent `beekiri` theme — core updates own that tree.
 * Prefer the active theme when it is a child; otherwise `beekiri-child`.
 */
export function resolveClientThemeSlug(activeSlug?: string | null): string {
  const active = resolveThemeSlug((activeSlug ?? '').trim());
  if (active && active !== PARENT_THEME_SLUG) return active;
  return DEFAULT_THEME_SLUG;
}

/** Absolute path for client writes; creates the theme folder if missing. */
export function resolveClientThemeDir(activeSlug?: string | null): string {
  const slug = resolveClientThemeSlug(activeSlug);
  const abs = join(resolveThemesRoot(), slug);
  if (!existsSync(abs)) {
    // Lazy import avoided — callers mkdir as needed; return intended path.
  }
  return abs;
}

export type ThemeChromeField = {
  name: string;
  type: string;
  defaultValue?: unknown;
};

export type ThemeChromeOption = ThemeChromeEntry & {
  kind: ThemeChromeKind;
  theme: string;
  description: string;
  /** Absolute folder on disk (API only — strip before sending to clients). */
  dir: string | null;
  fields: ThemeChromeField[];
  hasPhp: boolean;
  hasReact: boolean;
};

/** @deprecated Use ThemeChromeOption */
export type ThemeHeaderOption = ThemeChromeOption;

function readChromeMeta(
  dir: string,
  entry: ThemeChromeEntry,
  kind: ThemeChromeKind,
): { title?: string; description?: string; fields: ThemeChromeField[] } {
  const candidates = [join(dir, `${entry.slug}.meta.json`), join(dir, `${kind}.meta.json`)];
  const file = candidates.find((p) => existsSync(p));
  if (!file) return { fields: [] };
  try {
    const meta = JSON.parse(readFileSync(file, 'utf8')) as {
      title?: unknown;
      description?: unknown;
      fields?: unknown;
    };
    const fields = Array.isArray(meta.fields)
      ? meta.fields
          .filter(
            (f): f is { name: string; type?: unknown; defaultValue?: unknown } =>
              !!f && typeof f === 'object' && typeof (f as { name?: unknown }).name === 'string',
          )
          .map((f) => ({
            name: f.name,
            type: typeof f.type === 'string' ? f.type : 'text',
            defaultValue: f.defaultValue,
          }))
      : [];
    return {
      title: typeof meta.title === 'string' && meta.title.trim() ? meta.title.trim() : undefined,
      description:
        typeof meta.description === 'string' && meta.description.trim()
          ? meta.description.trim()
          : undefined,
      fields,
    };
  } catch {
    return { fields: [] };
  }
}

/** Entry file for one runtime, e.g. header/header.php or header/header.tsx. */
export function chromeEntryFile(
  option: Pick<ThemeChromeOption, 'dir' | 'slug' | 'kind'>,
  ext: 'php' | 'tsx',
): string | null {
  if (!option.dir) return null;
  const candidates = [
    join(option.dir, `${option.slug}.${ext}`),
    join(option.dir, `${option.kind}.${ext}`),
  ];
  return candidates.find((p) => existsSync(p)) ?? null;
}

function declaredChrome(theme: ThemeManifest, kind: ThemeChromeKind): ThemeChromeEntry[] {
  const listed = kind === 'header' ? theme.headers : theme.footers;
  if (listed?.length) return listed;
  const fallbackSlug = theme.chrome?.[kind];
  return fallbackSlug
    ? [
        {
          slug: fallbackSlug,
          title: kind === 'header' ? 'Site header' : 'Site footer',
          path: fallbackSlug,
          default: true,
        },
      ]
    : [];
}

/** Headers / footers from the child, then the parent when the child does not declare them. */
export function listThemeChrome(themeSlug: string, kind: ThemeChromeKind): ThemeChromeOption[] {
  const bySlug = new Map<string, ThemeChromeEntry>();
  for (const slug of [...themeAncestry(themeSlug)].reverse()) {
    const theme = getThemeManifest(slug);
    if (!theme) continue;
    for (const entry of declaredChrome(theme, kind)) bySlug.set(entry.slug, entry);
  }
  if (!bySlug.size) return [];

  return [...bySlug.values()].map((entry) => {
    const dir = resolveThemePath(themeSlug, entry.path);
    const meta = dir && existsSync(dir) ? readChromeMeta(dir, entry, kind) : { fields: [] };
    const option: ThemeChromeOption = {
      ...entry,
      kind,
      title: meta.title ?? entry.title,
      description: meta.description ?? entry.description ?? '',
      theme: resolveThemeSlug(themeSlug),
      dir: dir && existsSync(dir) ? dir : null,
      fields: meta.fields,
      hasPhp: false,
      hasReact: false,
    };
    option.hasPhp = Boolean(chromeEntryFile(option, 'php'));
    option.hasReact = Boolean(chromeEntryFile(option, 'tsx'));
    return option;
  });
}

export function resolveDefaultChromeSlug(themeSlug: string, kind: ThemeChromeKind): string | null {
  const options = listThemeChrome(themeSlug, kind);
  if (!options.length) return null;
  return options.find((o) => o.default)?.slug ?? options[0]?.slug ?? null;
}

/** Active option for a kind — honours the saved slug when it still exists in the theme. */
export function resolveActiveChrome(
  themeSlug: string,
  kind: ThemeChromeKind,
  savedSlug?: string | null,
): ThemeChromeOption | null {
  const options = listThemeChrome(themeSlug, kind);
  if (!options.length) return null;
  const wanted = (savedSlug ?? '').trim();
  return (
    (wanted && options.find((o) => o.slug === wanted)) ||
    options.find((o) => o.default) ||
    options[0] ||
    null
  );
}

export function listThemeHeaders(themeSlug: string): ThemeChromeOption[] {
  return listThemeChrome(themeSlug, 'header');
}

export function resolveDefaultHeaderSlug(themeSlug: string): string | null {
  return resolveDefaultChromeSlug(themeSlug, 'header');
}
