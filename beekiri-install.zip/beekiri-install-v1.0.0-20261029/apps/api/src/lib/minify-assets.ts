/**
 * Lightweight JS minify for theme / layout public assets (no extra deps).
 * Strips comments and blank lines; leaves tokens intact so string literals stay safe.
 * CSS minification is handled by sass `{ style: 'compressed' }` at call sites.
 */

export function minifyJs(source: string): string {
  const withoutBlocks = source.replace(/\/\*[\s\S]*?\*\//g, '');
  const lines = withoutBlocks.split('\n').map((line) => {
    // Drop // comments that are not part of a URL (https://…)
    let out = '';
    let inSingle = false;
    let inDouble = false;
    let inTemplate = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      const prev = line[i - 1];
      if (ch === "'" && !inDouble && !inTemplate && prev !== '\\') inSingle = !inSingle;
      else if (ch === '"' && !inSingle && !inTemplate && prev !== '\\') inDouble = !inDouble;
      else if (ch === '`' && !inSingle && !inDouble && prev !== '\\') inTemplate = !inTemplate;
      if (
        !inSingle &&
        !inDouble &&
        !inTemplate &&
        ch === '/' &&
        line[i + 1] === '/' &&
        prev !== ':'
      ) {
        break;
      }
      out += ch;
    }
    return out.replace(/[ \t]+$/g, '');
  });
  return (
    lines
      .filter((l) => l.trim().length > 0)
      .join('\n')
      .replace(/[ \t]{2,}/g, ' ') + '\n'
  );
}
