/** Shared page/post/CPT document kinds on the `Post` model (`type` column). */

export type BuiltinContentKind = 'page' | 'post';
export type ContentKind = BuiltinContentKind | (string & {});

export type ContentKindConfig = {
  kind: ContentKind;
  type: string;
  publishCap: 'publish_pages' | 'publish_posts';
  listKey: string;
  itemKey: string;
  label: string;
  labelPlural: string;
  notFound: string;
  conflictSlug: string;
  cannotPublish: string;
  cannotRestorePublish: string;
  defaultSlugBase: string;
  pathOf: (slug: string) => string;
};

export const CONTENT_KINDS: Record<BuiltinContentKind, ContentKindConfig> = {
  page: {
    kind: 'page',
    type: 'page',
    publishCap: 'publish_pages',
    listKey: 'pages',
    itemKey: 'page',
    label: 'Page',
    labelPlural: 'Pages',
    notFound: 'Page not found.',
    conflictSlug: 'A page with that slug already exists.',
    cannotPublish: 'You cannot publish pages.',
    cannotRestorePublish: 'You cannot restore a published revision.',
    defaultSlugBase: 'page',
    pathOf: (slug) => `/${slug}`,
  },
  post: {
    kind: 'post',
    type: 'post',
    publishCap: 'publish_posts',
    listKey: 'posts',
    itemKey: 'post',
    label: 'Post',
    labelPlural: 'Posts',
    notFound: 'Post not found.',
    conflictSlug: 'A post with that slug already exists.',
    cannotPublish: 'You cannot publish posts.',
    cannotRestorePublish: 'You cannot restore a published revision.',
    defaultSlugBase: 'post',
    pathOf: (slug) => `/blog/${slug}`,
  },
};

/** Slugs that cannot be registered as custom post types. */
export const RESERVED_CONTENT_SLUGS = new Set([
  'page',
  'pages',
  'post',
  'posts',
  'blog',
  'admin',
  'api',
  'media',
  'login',
  'install',
  'fields',
  'users',
  'settings',
  'analytics',
  'seo',
  'appearance',
  'wp-admin',
  'wp-json',
  'assets',
  'uploads',
  'health',
  'new',
]);

export type CptLabels = { singular?: string; plural?: string };

export function contentKindConfig(kind: ContentKind = 'page', labels?: CptLabels): ContentKindConfig {
  if (kind === 'page') return CONTENT_KINDS.page;
  if (kind === 'post') return CONTENT_KINDS.post;

  const singular = (labels?.singular || kind).trim() || kind;
  const plural = (labels?.plural || `${singular}s`).trim() || `${singular}s`;
  return {
    kind,
    type: kind,
    publishCap: 'publish_posts',
    listKey: 'items',
    itemKey: 'item',
    label: singular,
    labelPlural: plural,
    notFound: `${singular} not found.`,
    conflictSlug: `A ${singular.toLowerCase()} with that slug already exists.`,
    cannotPublish: `You cannot publish ${plural.toLowerCase()}.`,
    cannotRestorePublish: 'You cannot restore a published revision.',
    defaultSlugBase: kind,
    pathOf: (slug) => `/${kind}/${slug}`,
  };
}

export function isBuiltinContentKind(kind: string): kind is BuiltinContentKind {
  return kind === 'page' || kind === 'post';
}
