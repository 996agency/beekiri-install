/** In-memory live presence for BeekiriCode page editors (who’s on this page). */

export type PagePresencePeer = {
  userId: string;
  name: string;
  color: string;
  clientId: string;
  seenAt: number;
};

const TTL_MS = 12_000;

/** pageId → clientId → peer */
const rooms = new Map<string, Map<string, PagePresencePeer>>();

export function peerColor(userId: string): string {
  let hash = 0;
  for (let i = 0; i < userId.length; i++) {
    hash = (hash * 31 + userId.charCodeAt(i)) | 0;
  }
  const hue = ((hash % 360) + 360) % 360;
  return `hsl(${hue} 70% 45%)`;
}

function prune(pageId: string, now = Date.now()) {
  const room = rooms.get(pageId);
  if (!room) return;
  for (const [cid, peer] of room) {
    if (now - peer.seenAt > TTL_MS) room.delete(cid);
  }
  if (room.size === 0) rooms.delete(pageId);
}

export function heartbeatPresence(input: {
  pageId: string;
  userId: string;
  name: string;
  clientId: string;
}): PagePresencePeer[] {
  const now = Date.now();
  prune(input.pageId, now);
  let room = rooms.get(input.pageId);
  if (!room) {
    room = new Map();
    rooms.set(input.pageId, room);
  }
  room.set(input.clientId, {
    userId: input.userId,
    name: input.name,
    color: peerColor(input.userId),
    clientId: input.clientId,
    seenAt: now,
  });
  return listPresence(input.pageId);
}

export function listPresence(pageId: string): PagePresencePeer[] {
  prune(pageId);
  const room = rooms.get(pageId);
  if (!room) return [];
  // One chip per user (multi-tab → keep most recent client).
  const byUser = new Map<string, PagePresencePeer>();
  for (const peer of room.values()) {
    const prev = byUser.get(peer.userId);
    if (!prev || peer.seenAt > prev.seenAt) byUser.set(peer.userId, peer);
  }
  return [...byUser.values()].sort((a, b) => a.name.localeCompare(b.name));
}

export function leavePresence(pageId: string, clientId: string) {
  const room = rooms.get(pageId);
  if (!room) return;
  room.delete(clientId);
  if (room.size === 0) rooms.delete(pageId);
}
