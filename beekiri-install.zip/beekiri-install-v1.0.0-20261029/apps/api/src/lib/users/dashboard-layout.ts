/** Shared shape for per-user Overview layouts (admin dashboard). */

export type DashboardLayoutItem = {
  id: string;
  span: number;
};

const ALLOWED_IDS = new Set([
  'storage',
  'clock',
  'pages',
  'posts',
  'media',
  'status',
  'activity',
  'publish',
  'fields',
  'users',
]);

const ALLOWED_SPANS = new Set([2, 3, 4, 6, 8, 12]);

export function parseDashboardLayout(raw: unknown): DashboardLayoutItem[] | null {
  if (!Array.isArray(raw) || raw.length === 0) return null;
  const items: DashboardLayoutItem[] = [];
  const seen = new Set<string>();
  for (const row of raw) {
    if (!row || typeof row !== 'object') continue;
    const id = (row as { id?: unknown }).id;
    const span = (row as { span?: unknown }).span;
    if (typeof id !== 'string' || !ALLOWED_IDS.has(id) || seen.has(id)) continue;
    if (typeof span !== 'number' || !ALLOWED_SPANS.has(span)) continue;
    items.push({ id, span });
    seen.add(id);
  }
  return items.length ? items : null;
}
