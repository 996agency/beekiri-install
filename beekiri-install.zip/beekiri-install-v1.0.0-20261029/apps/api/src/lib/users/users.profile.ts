import { isCapabilitySlug } from '../auth/role-capabilities';
import type { CapabilitySlug } from '../cms-types';
import {
  parseDashboardLayout,
  type DashboardLayoutItem,
} from './dashboard-layout';

export type UserCustomField = {
  id: string;
  label: string;
  value: string;
};

export type UserProfile = {
  jobDescription: string;
  customFields: UserCustomField[];
  /** Extra capabilities beyond the role defaults. */
  capabilityGrants: CapabilitySlug[];
  /** Capabilities removed from the role defaults (Owner ignores these). */
  capabilityDenies: CapabilitySlug[];
  /** Per-user Overview widget layout (null = use product default). */
  dashboardLayout: DashboardLayoutItem[] | null;
};

export function emptyProfile(): UserProfile {
  return {
    jobDescription: '',
    customFields: [],
    capabilityGrants: [],
    capabilityDenies: [],
    dashboardLayout: null,
  };
}

function parseCapList(raw: unknown): CapabilitySlug[] {
  if (!Array.isArray(raw)) return [];
  const out: CapabilitySlug[] = [];
  const seen = new Set<string>();
  for (const item of raw) {
    if (!isCapabilitySlug(item) || seen.has(item)) continue;
    seen.add(item);
    out.push(item);
  }
  return out;
}

export function parseProfile(raw: unknown): UserProfile {
  if (!raw || typeof raw !== 'object') return emptyProfile();
  const o = raw as Record<string, unknown>;
  const jobDescription = typeof o.jobDescription === 'string' ? o.jobDescription : '';
  const customFields: UserCustomField[] = [];
  if (Array.isArray(o.customFields)) {
    for (const row of o.customFields) {
      if (!row || typeof row !== 'object') continue;
      const r = row as Record<string, unknown>;
      const id = typeof r.id === 'string' ? r.id : '';
      const label = typeof r.label === 'string' ? r.label.trim() : '';
      const value = typeof r.value === 'string' ? r.value : '';
      if (!id || !label) continue;
      customFields.push({
        id,
        label: label.slice(0, 80),
        value: value.slice(0, 500),
      });
    }
  }
  return {
    jobDescription: jobDescription.slice(0, 2000),
    customFields: customFields.slice(0, 20),
    capabilityGrants: parseCapList(o.capabilityGrants),
    capabilityDenies: parseCapList(o.capabilityDenies),
    dashboardLayout: parseDashboardLayout(o.dashboardLayout),
  };
}

export function normalizeProfileInput(input: {
  jobDescription?: string;
  customFields?: { id?: string; label?: string; value?: string }[];
  capabilityGrants?: string[];
  capabilityDenies?: string[];
  dashboardLayout?: DashboardLayoutItem[] | null;
}): UserProfile {
  const customFields: UserCustomField[] = [];
  for (const row of input.customFields ?? []) {
    const label = (row.label ?? '').trim();
    if (!label) continue;
    customFields.push({
      id: (row.id ?? '').trim() || `cf-${Math.random().toString(36).slice(2, 9)}`,
      label: label.slice(0, 80),
      value: (row.value ?? '').slice(0, 500),
    });
  }
  return {
    jobDescription: (input.jobDescription ?? '').trim().slice(0, 2000),
    customFields: customFields.slice(0, 20),
    capabilityGrants: parseCapList(input.capabilityGrants),
    capabilityDenies: parseCapList(input.capabilityDenies),
    dashboardLayout:
      input.dashboardLayout === undefined
        ? null
        : parseDashboardLayout(input.dashboardLayout),
  };
}

/** Keep existing grants/denies / layout when only job/custom fields are being edited. */
export function mergeProfileInput(
  existing: UserProfile,
  input: {
    jobDescription?: string;
    customFields?: { id?: string; label?: string; value?: string }[];
    capabilityGrants?: string[];
    capabilityDenies?: string[];
    dashboardLayout?: DashboardLayoutItem[] | null;
  },
): UserProfile {
  const next = normalizeProfileInput({
    jobDescription: input.jobDescription ?? existing.jobDescription,
    customFields: input.customFields ?? existing.customFields,
    capabilityGrants: input.capabilityGrants ?? existing.capabilityGrants,
    capabilityDenies: input.capabilityDenies ?? existing.capabilityDenies,
    dashboardLayout:
      input.dashboardLayout !== undefined
        ? input.dashboardLayout
        : existing.dashboardLayout,
  });
  return next;
}
