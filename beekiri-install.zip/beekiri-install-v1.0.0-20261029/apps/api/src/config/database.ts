import { readFileSync } from 'fs';
import type { Options } from 'sequelize';
import type { ConnectionOptions } from 'tls';
import { config, type DatabaseSettings } from './env';

export function sslOptions(db: DatabaseSettings = config.db): ConnectionOptions | false {
  if (db.ssl === 'disable') return false;
  if (db.ssl === 'require') return { rejectUnauthorized: false };
  return {
    rejectUnauthorized: true,
    ...(db.sslCa ? { ca: readFileSync(db.sslCa, 'utf8') } : {}),
  };
}

export function sequelizeOptions(db: DatabaseSettings = config.db): Options {
  const ssl = sslOptions(db);
  return {
    dialect: 'postgres',
    host: db.host,
    port: db.port,
    database: db.name,
    username: db.user,
    password: db.password,
    // Timestamp columns are TIMESTAMP(3) WITHOUT TIME ZONE holding UTC.
    timezone: '+00:00',
    logging: db.logging ? (sql) => console.log(`[db] ${sql}`) : false,
    benchmark: db.logging,
    pool: { max: db.poolMax, min: 0, idle: 10_000, acquire: 30_000, evict: 1_000 },
    dialectOptions: {
      application_name: 'beekiri-api',
      statement_timeout: 30_000,
      idle_in_transaction_session_timeout: 60_000,
      options: `-c search_path=${db.schema}`,
      ...(ssl ? { ssl } : {}),
    },
    define: { freezeTableName: true, underscored: false },
    retry: { max: 0 },
  };
}
