import { resolve } from 'path';

/** apps/api — the same from src/config (tsx) and dist/config (node). */
export const API_ROOT = resolve(__dirname, '..', '..');

/** Monorepo root (holds apps/, scripts/, beekiri.manifest.json). */
export const REPO_ROOT = resolve(API_ROOT, '..', '..');
