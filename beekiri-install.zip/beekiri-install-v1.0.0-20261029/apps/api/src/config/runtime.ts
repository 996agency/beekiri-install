/**
 * Facts only known once the server is listening (the port may be chosen at start).
 * Everything else comes from config/env.ts.
 */
let selfUrl: string | undefined;

/** Called by the server once it listens. */
export function setSelfUrl(url: string): void {
  selfUrl = url.replace(/\/+$/, '');
}

/** This server's own address on this machine, for calls between the API and the website. */
export function getSelfUrl(): string | undefined {
  return selfUrl;
}
