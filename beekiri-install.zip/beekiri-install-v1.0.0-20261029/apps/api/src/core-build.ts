// Rewritten by scripts/core-update.mjs after each update so the dev server reloads.
export const CORE_BUILD = 'release';
