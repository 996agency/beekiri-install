import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
    include: ['test/**/*.test.ts', 'src/**/*.spec.ts'],
    fileParallelism: false,
    hookTimeout: 60000,
    testTimeout: 60000,
  },
});
