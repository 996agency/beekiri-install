# Layouts

This folder starts empty. Layouts are created when you save a field group in
**Backend Fields**, or when you copy a layout pack into a theme and click
**Sync** in Field Groups.

```
layouts/{slug}/
  {slug}.php          — PHP template
  {slug}.tsx          — React template
  styles.scss
  script.js
  {slug}.meta.json    — field group definition (this is what Sync reads)
```

On a client site, files in the parent theme (`beekiri`) are imported with
**Field Groups → Sync**. Site-specific copies belong in `../beekiri-child/layouts/`.
