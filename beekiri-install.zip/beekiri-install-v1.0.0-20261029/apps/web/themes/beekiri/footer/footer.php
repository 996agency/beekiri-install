<?php
/**
 * Beekiri theme footer (PHP frontend) — same markup as footer.tsx.
 *
 * Fields: copyright, showPoweredBy (footer.meta.json)
 * Site:   site_title, site_tagline, home_url, menu, blog_public, year
 */

$site_title = get_bee_field('site_title') ?: 'Beekiri';
$tagline    = get_bee_field('site_tagline');
$home_url   = get_bee_field('home_url') ?: '/';
$year       = get_bee_field('year') ?: date('Y');
$copyright  = trim((string) get_bee_field('copyright'));
$powered    = get_bee_field('showPoweredBy') !== false;
$blog_public = get_bee_field('blog_public') !== false;

$menu  = get_bee_field('menu');
$links = is_array($menu) ? array_slice($menu, 0, 8) : [];

if ($copyright === '') {
  $copyright = '© ' . $year . ' ' . $site_title . '. All rights reserved.';
}
?>
<footer class="bk-site-footer" data-theme-footer="footer">
  <div class="bk-site-footer__inner">
    <div class="bk-site-footer__top">
      <div class="bk-site-footer__brand">
        <a href="<?php echo esc_url($home_url); ?>"><?php echo esc_html($site_title); ?></a>
        <?php if (!empty($tagline)) : ?>
          <p><?php echo esc_html($tagline); ?></p>
        <?php endif; ?>
      </div>

      <?php if ($links) : ?>
        <nav class="bk-site-footer__nav" aria-label="Footer">
          <ul>
            <?php foreach ($links as $item) : ?>
              <li><a href="<?php echo esc_url($item['url'] ?? '/'); ?>"><?php echo esc_html($item['label'] ?? ''); ?></a></li>
            <?php endforeach; ?>
          </ul>
        </nav>
      <?php endif; ?>
    </div>

    <div class="bk-site-footer__bottom">
      <p><?php echo esc_html($copyright); ?></p>
      <?php if ($powered || !$blog_public) : ?>
        <p class="bk-site-footer__meta">
          <?php if ($powered) : ?><span>Powered by Beekiri</span><?php endif; ?>
          <?php if (!$blog_public) : ?><span>Search engines are asked not to index this site</span><?php endif; ?>
        </p>
      <?php endif; ?>
    </div>
  </div>
</footer>
