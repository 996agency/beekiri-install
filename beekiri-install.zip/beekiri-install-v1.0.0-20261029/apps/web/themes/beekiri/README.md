# Beekiri

Official **parent** theme for Beekiri CMS. Core updates replace files in this folder.

Do not edit this theme on a client site. Activate **Beekiri Child** (`../beekiri-child`) and copy any template you need to change into the matching path there. The child file wins; everything else still comes from this parent.

- Header and footer: `header/`, `footer/`
- Layouts: `layouts/{slug}/` (Backend Fields also write here when this theme is active)
- Activate from **Appearance → Themes**
