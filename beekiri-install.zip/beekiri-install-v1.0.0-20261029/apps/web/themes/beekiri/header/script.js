/**
 * Beekiri theme header — behaviour for the PHP frontend (header.php).
 * Search dialog (⌘K / Ctrl+K), mobile menu, and active-link state.
 * Uses document-level delegation so it keeps working across client-side
 * navigations (the site dispatches `bk:navigate` after each route change).
 */
(function () {
  if (window.__bkThemeHeader) return;
  window.__bkThemeHeader = true;

  var $ = function (sel) {
    return document.querySelector(sel);
  };

  function normalizePath(p) {
    if (!p) return '/';
    var clean = p.split('#')[0].split('?')[0] || '/';
    return clean.length > 1 ? clean.replace(/\/+$/, '') : clean;
  }

  function setMenu(open) {
    var menu = $('[data-bk-menu]');
    var toggle = $('[data-bk-menu-toggle]');
    if (!menu || !toggle) return;
    menu.hidden = !open;
    toggle.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  var lastOverflow = '';
  function setSearch(open) {
    var dialog = $('[data-bk-search]');
    if (!dialog) return;
    if (open === !dialog.hidden) return;
    dialog.hidden = !open;
    if (open) {
      lastOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      var input = $('[data-bk-search-input]');
      if (input) {
        input.value = '';
        filter('');
        input.focus();
      }
    } else {
      document.body.style.overflow = lastOverflow;
    }
  }

  function filter(raw) {
    var q = String(raw || '').trim().toLowerCase();
    var items = document.querySelectorAll('[data-bk-search-item]');
    var visible = 0;
    items.forEach(function (li) {
      var match = !q || (li.getAttribute('data-q') || '').indexOf(q) !== -1;
      li.hidden = !match;
      if (match) visible++;
    });
    var empty = $('[data-bk-search-empty]');
    if (empty) empty.hidden = visible > 0;
  }

  function markActive() {
    var here = normalizePath(window.location.pathname);
    document.querySelectorAll('.bk-nav__links a, .bk-nav__mobile a').forEach(function (a) {
      var href = a.getAttribute('href') || '';
      if (href.charAt(0) !== '/' || href.indexOf('#') !== -1) {
        a.removeAttribute('aria-current');
        return;
      }
      if (normalizePath(href) === here) a.setAttribute('aria-current', 'page');
      else a.removeAttribute('aria-current');
    });
  }

  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!(t instanceof Element)) return;

    if (t.closest('[data-bk-search-open]')) {
      e.preventDefault();
      setSearch(true);
      return;
    }
    if (t.closest('[data-bk-menu-toggle]')) {
      var menu = $('[data-bk-menu]');
      setMenu(!!menu && menu.hidden);
      return;
    }
    var dialog = $('[data-bk-search]');
    if (dialog && t === dialog) {
      setSearch(false);
      return;
    }
    if (t.closest('[data-bk-search] a')) setSearch(false);
    if (t.closest('[data-bk-menu] a')) setMenu(false);
  });

  document.addEventListener('input', function (e) {
    var t = e.target;
    if (t instanceof Element && t.matches('[data-bk-search-input]')) filter(t.value);
  });

  function openFirstResult() {
    var first = document.querySelector('[data-bk-search-item]:not([hidden]) a');
    if (first) first.click();
  }

  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!(form instanceof Element) || !form.matches('[data-bk-search-form]')) return;
    e.preventDefault();
    openFirstResult();
  });

  document.addEventListener('keydown', function (e) {
    var t = e.target;
    if (e.key === 'Enter' && t instanceof Element && t.matches('[data-bk-search-input]')) {
      e.preventDefault();
      openFirstResult();
      return;
    }
    if ((e.metaKey || e.ctrlKey) && String(e.key).toLowerCase() === 'k' && $('[data-bk-search]')) {
      e.preventDefault();
      setSearch(true);
    }
    if (e.key === 'Escape') {
      setSearch(false);
      setMenu(false);
    }
  });

  window.addEventListener('bk:navigate', function () {
    setSearch(false);
    setMenu(false);
    markActive();
  });
  window.addEventListener('popstate', markActive);

  // After paint / hydrate — avoid mutating the PHP header before React hydrates.
  function scheduleMark() {
    if (typeof requestAnimationFrame === 'function') {
      requestAnimationFrame(function () {
        setTimeout(markActive, 0);
      });
    } else {
      setTimeout(markActive, 0);
    }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scheduleMark);
  } else {
    scheduleMark();
  }
})();
