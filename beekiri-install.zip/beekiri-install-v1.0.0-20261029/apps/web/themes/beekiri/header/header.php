<?php
/**
 * Beekiri theme header (PHP frontend) — same markup as header.tsx.
 *
 * Fields: githubUrl, showSearch, showGithub (header.meta.json)
 * Site:   site_title, home_url, menu (rows: label, url, children)
 * Behaviour (search ⌘K, mobile menu, active link) lives in script.js.
 */

$site_title  = get_bee_field('site_title') ?: 'Beekiri';
$home_url    = get_bee_field('home_url') ?: '/';
$logo_url    = get_bee_field('logo_url') ?: '/beekiri-logo.png';
$github_url  = get_bee_field('githubUrl');
$show_search = get_bee_field('showSearch') !== false;
$show_github = get_bee_field('showGithub') !== false && !empty($github_url);

$menu = get_bee_field('menu');
if (!is_array($menu) || !$menu) {
  $menu = [
    ['id' => 'features', 'label' => 'Features', 'url' => '/#features', 'children' => []],
    ['id' => 'testimonials', 'label' => 'Testimonials', 'url' => '/#testimonials', 'children' => []],
    ['id' => 'faq', 'label' => 'FAQ', 'url' => '/#faq', 'children' => []],
    ['id' => 'contact', 'label' => 'Contact', 'url' => '/contact', 'children' => []],
  ];
}
$links = array_slice($menu, 0, 8);

$searchable = [];
$flatten = function (array $items) use (&$flatten, &$searchable) {
  foreach ($items as $item) {
    if (!is_array($item)) continue;
    $searchable[] = $item;
    if (!empty($item['children']) && is_array($item['children'])) $flatten($item['children']);
  }
};
$flatten($menu);

$icon_search = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>';
?>
<header class="bk-nav" aria-label="Main" data-theme-header="header">
  <div class="bk-nav__bar">
    <a class="bk-nav__brand" href="<?php echo esc_url($home_url); ?>">
      <span class="bk-nav__mark" aria-hidden="true">
        <img src="<?php echo esc_url($logo_url); ?>" alt="" width="28" height="28" decoding="async" />
      </span>
      <span class="bk-nav__wordmark"><?php echo esc_html($site_title); ?></span>
    </a>

    <nav class="bk-nav__links" aria-label="Primary">
      <ul>
        <?php foreach ($links as $item) : ?>
          <li><a href="<?php echo esc_url($item['url'] ?? '/'); ?>"><?php echo esc_html($item['label'] ?? ''); ?></a></li>
        <?php endforeach; ?>
      </ul>
    </nav>

    <div class="bk-nav__actions">
      <?php if ($show_search) : ?>
        <button type="button" class="bk-nav__icon-btn bk-nav__search-mobile" aria-label="Open Search" data-bk-search-open>
          <?php echo $icon_search; ?>
        </button>
        <button type="button" class="bk-nav__search" data-search-full="" data-bk-search-open>
          <?php echo $icon_search; ?>
          <span>Search</span>
          <span class="bk-nav__kbds" aria-hidden="true"><kbd>⌘</kbd><kbd>K</kbd></span>
        </button>
      <?php endif; ?>

      <?php if ($show_github) : ?>
        <a class="bk-nav__icon-btn bk-nav__github" href="<?php echo esc_url($github_url); ?>" target="_blank" rel="noreferrer noopener" aria-label="GitHub">
          <svg role="img" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/></svg>
        </a>
      <?php endif; ?>

      <button type="button" class="bk-nav__icon-btn bk-nav__menu-toggle" aria-label="Menu" aria-expanded="false" data-bk-menu-toggle>
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>
      </button>
    </div>
  </div>

  <div class="bk-nav__mobile" data-bk-menu hidden>
    <ul>
      <?php foreach ($links as $item) : ?>
        <li><a href="<?php echo esc_url($item['url'] ?? '/'); ?>"><?php echo esc_html($item['label'] ?? ''); ?></a></li>
      <?php endforeach; ?>
    </ul>
  </div>
</header>

<?php if ($show_search) : ?>
<div class="bk-search" role="dialog" aria-modal="true" aria-labelledby="bk-search-input" data-bk-search hidden>
  <form class="bk-search__panel" data-bk-search-form>
    <div class="bk-search__head">
      <?php echo $icon_search; ?>
      <input id="bk-search-input" type="search" placeholder="Search pages…" autocomplete="off" data-bk-search-input />
      <kbd>esc</kbd>
    </div>
    <ul class="bk-search__results">
      <?php foreach ($searchable as $item) : ?>
        <li data-bk-search-item data-q="<?php echo esc_attr(strtolower(($item['label'] ?? '') . ' ' . ($item['url'] ?? ''))); ?>">
          <a href="<?php echo esc_url($item['url'] ?? '/'); ?>">
            <span><?php echo esc_html($item['label'] ?? ''); ?></span>
            <code><?php echo esc_html($item['url'] ?? '/'); ?></code>
          </a>
        </li>
      <?php endforeach; ?>
      <li class="bk-search__empty" data-bk-search-empty hidden>No matches</li>
    </ul>
  </form>
</div>
<?php endif; ?>
