# Header (theme chrome)

Site-wide header for the Beekiri theme. Not a page layout — rendered by the
public shell from the installed frontend’s entry file.

```
header/
  header.php         — PHP header (PHP frontend)
  header.tsx         — React header (React frontend)
  header.meta.json   — header option fields
  styles.scss        — source styles (always white)
  styles.css         — compiled CSS
  script.js          — search ⌘K, mobile menu (PHP frontend)
```
