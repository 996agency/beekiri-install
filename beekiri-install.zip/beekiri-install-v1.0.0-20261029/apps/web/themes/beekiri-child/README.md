# Beekiri Child

Default theme on a new install. This is where site-specific changes belong.

Beekiri looks in this folder first, then in **Beekiri** (`../beekiri`). Core updates replace the parent only; this folder is left alone.

## Override a template

1. Copy the file from `../beekiri/` into the same path here.
2. Edit the copy.

Examples:

```
header/header.php
footer/footer.php
layouts/hero-banner/hero-banner.php
style.css
```

Activate from **Appearance → Themes**.
