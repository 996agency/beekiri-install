<?php
/* @beekiri-managed — remove this line to keep your custom file */
$title = get_bee_field('title');
$options = get_bee_field('options');
?>
<section class="section hero-banner" data-layout="hero-banner">
  <div class="wrapper">
    <div class="inner">
      <?php if ($title !== null && $title !== '') : ?>
        <h2 class="bk-title"><?php echo esc_html($title); ?></h2>
      <?php endif; ?>

      <?php if ($options) : ?>
        <div class="bk-options"></div>
      <?php endif; ?>
    </div>
  </div>
</section>
