/* @beekiri-managed — remove this line to keep your custom file */
/*
 * Hero Banner Layout
 * Served at /api/layouts/hero-banner/js — edit + save + refresh (no gulp for JS).
 * Gulp only compiles styles.scss → styles.css.
 * Pages change without a full reload, so init runs on load and on `bk:navigate`.
 */
(function () {
  function init() {
    document
      .querySelectorAll('[data-layout="hero-banner"]:not([data-bk-ready])')
      .forEach(function (root) {
        root.setAttribute('data-bk-ready', '');
        // hero-banner
      });
  }
  init();
  window.addEventListener('bk:navigate', init);
})();
