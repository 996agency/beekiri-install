import { revalidatePath } from 'next/cache';
import { NextResponse } from 'next/server';

/**
 * Public-site cache flush — full site or specific paths.
 * Called by the Beekiri server with CACHE_FLUSH_SECRET via Bearer / x-beekiri-flush.
 *
 * Body (optional): `{ "paths": ["/hometest", "/"] }` — only those routes.
 * No body / empty paths — bust every public route segment.
 */
export async function POST(req: Request) {
  const secret =
    process.env.CACHE_FLUSH_SECRET?.trim() ||
    process.env.SESSION_SECRET?.trim() ||
    '';
  const auth = req.headers.get('authorization') || '';
  const header = req.headers.get('x-beekiri-flush') || '';
  const token = auth.toLowerCase().startsWith('bearer ')
    ? auth.slice(7).trim()
    : header.trim();

  if (!secret || token !== secret) {
    return NextResponse.json({ ok: false, message: 'Unauthorized' }, { status: 401 });
  }

  let paths: string[] | null = null;
  try {
    const body = (await req.json()) as { paths?: unknown };
    if (Array.isArray(body?.paths)) {
      paths = body.paths
        .filter((p): p is string => typeof p === 'string')
        .map((p) => p.trim())
        .filter((p) => p.startsWith('/') && !p.includes('..'));
    }
  } catch {
    paths = null;
  }

  // Layout hosts header/footer — always refresh chrome with any flush.
  revalidatePath('/', 'layout');

  if (paths?.length) {
    for (const p of paths) {
      revalidatePath(p);
    }
    return NextResponse.json({
      ok: true,
      flushedAt: new Date().toISOString(),
      paths,
    });
  }

  revalidatePath('/');
  revalidatePath('/blog');
  revalidatePath('/blog/[slug]', 'page');
  revalidatePath('/[slug]', 'page');

  return NextResponse.json({
    ok: true,
    flushedAt: new Date().toISOString(),
    paths: ['/', '/blog', '/[slug]', 'layout'],
  });
}
