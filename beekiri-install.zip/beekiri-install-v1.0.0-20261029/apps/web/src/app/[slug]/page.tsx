import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { PageBody, resolveBeekiriCodePage } from '../../components/PageBody';
import { API_URL as API } from '@/lib/env';

export const revalidate = 10;

type PublicPage = {
  title: string;
  slug: string;
  path: string;
  content: string;
  beekiricanva?: unknown | null;
  beekiricode?: unknown | null;
  instatic?: unknown | null;
  excerpt: string;
};

type CptMeta = {
  slug: string;
  singular: string;
  plural: string;
  hasArchive: boolean;
  archiveDesign: string;
};

type PublicEntry = {
  title: string;
  slug: string;
  path: string;
  excerpt: string;
  publishedAt: string | null;
};

async function getPage(slug: string): Promise<PublicPage | null> {
  try {
    const res = await fetch(`${API}/api/pages/public/${encodeURIComponent(slug)}`, {
      next: { revalidate: 30 },
    });
    if (res.status === 404) return null;
    if (!res.ok) return null;
    return (await res.json()) as PublicPage;
  } catch {
    return null;
  }
}

async function getCptMeta(slug: string): Promise<CptMeta | null> {
  try {
    const res = await fetch(`${API}/api/content/${encodeURIComponent(slug)}/meta`, {
      next: { revalidate: 30 },
    });
    if (!res.ok) return null;
    return (await res.json()) as CptMeta;
  } catch {
    return null;
  }
}

async function listCpt(slug: string): Promise<PublicEntry[]> {
  try {
    const res = await fetch(`${API}/api/content/${encodeURIComponent(slug)}/public`, {
      next: { revalidate: 30 },
    });
    if (!res.ok) return [];
    const data = (await res.json()) as { items?: PublicEntry[]; posts?: PublicEntry[] };
    return data.items ?? data.posts ?? [];
  } catch {
    return [];
  }
}

type Props = {
  params: Promise<{ slug: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const page = await getPage(slug);
  if (page) {
    const description = (page.excerpt || '').trim() || `${page.title} — published with Beekiri.`;
    return { title: page.title, description };
  }
  const meta = await getCptMeta(slug);
  if (meta?.hasArchive) return { title: meta.plural, description: `${meta.plural} archive` };
  return { title: 'Not found' };
}

export default async function ContentPage({ params }: Props) {
  const { slug } = await params;
  const page = await getPage(slug);
  if (page) {
    const codeDoc = page.beekiricode ?? page.instatic;
    const codePage = codeDoc ? await resolveBeekiriCodePage(codeDoc) : null;

    return (
      <>
        {codePage?.cssHrefs.map((href) => (
          <link key={href} rel="stylesheet" href={href} precedence="beekiri-layouts" />
        ))}
        {codePage?.css ? (
          <style href={`bk-page-${page.slug}`} precedence="beekiri-page">
            {codePage.css}
          </style>
        ) : null}
        {codePage?.jsHrefs.map((href) => (
          <script key={href} src={href} defer />
        ))}
        {codePage ? (
          <main
            id="main"
            className="bk-main"
            dangerouslySetInnerHTML={{ __html: codePage.html }}
          />
        ) : (
          <main id="main" className="bk-main">
            <h1>{page.title}</h1>
            <PageBody content={page.content} beekiricanva={page.beekiricanva} beekiricode={null} />
          </main>
        )}
      </>
    );
  }

  const meta = await getCptMeta(slug);
  if (!meta?.hasArchive) notFound();
  const entries = await listCpt(slug);
  const design = meta.archiveDesign || 'list';

  return (
    <main id="main" className={`bk-main bk-cpt-archive bk-cpt-archive--${design}`}>
      <h1>{meta.plural}</h1>
      {entries.length === 0 ? (
        <p className="bk-lead">No {meta.plural.toLowerCase()} published yet.</p>
      ) : (
        <ul className={`bk-cpt-archive__list bk-cpt-archive__list--${design}`}>
          {entries.map((e) => (
            <li key={e.slug}>
              <Link href={`/${slug}/${e.slug}`}>{e.title}</Link>
              {e.excerpt ? <p>{e.excerpt}</p> : null}
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
