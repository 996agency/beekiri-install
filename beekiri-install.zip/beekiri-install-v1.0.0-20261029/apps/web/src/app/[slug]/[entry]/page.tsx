import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { PageBody, resolveBeekiriCodePage } from '../../../components/PageBody';
import { API_URL as API } from '@/lib/env';

export const revalidate = 30;

type CptMeta = {
  slug: string;
  singular: string;
  plural: string;
  singleDesign: string;
};

type PublicEntry = {
  title: string;
  slug: string;
  path: string;
  content: string;
  beekiricanva?: unknown | null;
  beekiricode?: unknown | null;
  instatic?: unknown | null;
  excerpt: string;
};

async function getMeta(type: string): Promise<CptMeta | null> {
  try {
    const res = await fetch(`${API}/api/content/${encodeURIComponent(type)}/meta`, {
      next: { revalidate: 30 },
    });
    if (!res.ok) return null;
    return (await res.json()) as CptMeta;
  } catch {
    return null;
  }
}

async function getEntry(type: string, entry: string): Promise<PublicEntry | null> {
  try {
    const res = await fetch(
      `${API}/api/content/${encodeURIComponent(type)}/public/${encodeURIComponent(entry)}`,
      { next: { revalidate: 30 } },
    );
    if (res.status === 404) return null;
    if (!res.ok) return null;
    return (await res.json()) as PublicEntry;
  } catch {
    return null;
  }
}

type Props = {
  params: Promise<{ slug: string; entry: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug, entry } = await params;
  const item = await getEntry(slug, entry);
  if (!item) return { title: 'Not found' };
  const description = (item.excerpt || '').trim() || `${item.title} — published with Beekiri.`;
  return { title: item.title, description };
}

export default async function CptSinglePage({ params }: Props) {
  const { slug, entry } = await params;
  const [meta, item] = await Promise.all([getMeta(slug), getEntry(slug, entry)]);
  if (!meta || !item) notFound();

  const codeDoc = item.beekiricode ?? item.instatic;
  const codePage = codeDoc ? await resolveBeekiriCodePage(codeDoc) : null;
  const design = meta.singleDesign || 'default';

  return (
    <>
      {codePage?.cssHrefs.map((href) => (
        <link key={href} rel="stylesheet" href={href} precedence="beekiri-layouts" />
      ))}
      {codePage?.css ? (
        <style href={`bk-cpt-${slug}-${item.slug}`} precedence="beekiri-page">
          {codePage.css}
        </style>
      ) : null}
      {codePage?.jsHrefs.map((href) => (
        <script key={href} src={href} defer />
      ))}
      {codePage ? (
        <main
          id="main"
          className={`bk-main bk-cpt-single bk-cpt-single--${design}`}
          dangerouslySetInnerHTML={{ __html: codePage.html }}
        />
      ) : (
        <main id="main" className={`bk-main bk-cpt-single bk-cpt-single--${design}`}>
          <article>
            <h1>{item.title}</h1>
            <PageBody content={item.content} beekiricanva={item.beekiricanva} beekiricode={null} />
          </article>
        </main>
      )}
    </>
  );
}
