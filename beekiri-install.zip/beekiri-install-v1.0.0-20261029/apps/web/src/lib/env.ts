/**
 * Addresses the Beekiri server gives the website when it starts it (same process).
 * During `next build` no API runs yet: pages fall back to their built-in defaults and
 * refresh themselves once the site is live.
 */
const building = process.env.NEXT_PHASE === 'phase-production-build';

function fromServer(name: 'API_URL' | 'APP_URL'): string {
  const value = process.env[name]?.trim();
  if (value) return value.replace(/\/+$/, '');
  if (building) return '';
  throw new Error(`${name} is not set: start the website through the Beekiri server (npm start).`);
}

/** The Beekiri API this site reads its content from. */
export const API_URL = fromServer('API_URL');

/** This website's own public address (canonical URLs, sitemap, robots.txt). */
export const SITE_URL = fromServer('APP_URL');
