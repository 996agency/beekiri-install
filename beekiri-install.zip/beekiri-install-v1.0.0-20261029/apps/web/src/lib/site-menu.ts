/** Public menu shape shared by the shell and (when present) React theme chrome. */
export type SiteMenuItem = {
  id: string;
  label: string;
  path: string;
  enabled?: boolean;
  children?: SiteMenuItem[];
};
