import { Render } from '@beekiri/beekiricanva/rsc';
import {
  isBeekiricanvaData,
  beekiricanvaConfig,
  withLayouts,
  renderBeekiriCodePage,
  isBeekiriCodePublishDoc,
  type LayoutDef,
} from '@beekiri/page-blocks';
import '@beekiri/page-blocks/blocks.css';
import { renderLayout } from '../lib/render-layout';

import { API_URL as API } from '@/lib/env';

type Props = {
  content: string;
  beekiricanva?: unknown | null;
  /** BeekiriCode page tree — preferred source for public HTML. */
  beekiricode?: unknown | null;
  /** @deprecated Alias for beekiricode */
  instatic?: unknown | null;
};

async function getLayouts(): Promise<LayoutDef[]> {
  try {
    const res = await fetch(`${API}/api/layouts`, { next: { revalidate: 30 } });
    if (!res.ok) return [];
    const data = (await res.json()) as { layouts?: LayoutDef[] };
    return data.layouts ?? [];
  } catch {
    return [];
  }
}

function absoluteLayoutAsset(url: string): string {
  return url.startsWith('http') ? url : `${API.replace(/\/$/, '')}${url}`;
}

function layoutCssHref(layout: LayoutDef): string {
  return absoluteLayoutAsset(layout.cssUrl);
}

function layoutJsHref(layout: LayoutDef): string | null {
  if (!layout.jsUrl) return null;
  return absoluteLayoutAsset(layout.jsUrl);
}

function layoutStylesheet(layout: LayoutDef) {
  // `precedence` makes React/Next hoist the stylesheet into <head>.
  return (
    <link
      key={layout.slug}
      rel="stylesheet"
      href={layoutCssHref(layout)}
      precedence="beekiri-layouts"
    />
  );
}

/** Resolve BeekiriCode → HTML + layout CSS/JS asset hrefs + page CSS for <head>. */
export async function resolveBeekiriCodePage(beekiricode: unknown): Promise<{
  html: string;
  css: string;
  cssHrefs: string[];
  jsHrefs: string[];
} | null> {
  if (!isBeekiriCodePublishDoc(beekiricode)) return null;
  const { html, css } = await renderBeekiriCodePage(beekiricode, renderLayout);
  if (!html.trim()) return { html: '', css: '', cssHrefs: [], jsHrefs: [] };
  const layouts = await getLayouts();
  const used = new Set(
    [...html.matchAll(/data-layout="([^"]+)"/g)].map((m) => m[1]),
  );
  const usedLayouts = layouts.filter((l) => used.has(l.slug));
  return {
    html,
    css,
    cssHrefs: usedLayouts.map(layoutCssHref),
    jsHrefs: usedLayouts
      .map(layoutJsHref)
      .filter((href): href is string => Boolean(href)),
  };
}

/** Public page body — server Render only (no editor JS bundle). */
export async function PageBody({ content, beekiricanva, beekiricode, instatic }: Props) {
  const layouts = await getLayouts();
  const config = withLayouts(beekiricanvaConfig, layouts);
  const codeDoc = beekiricode ?? instatic;

  // BeekiriCode is handled by the page shell (sections inject into <main>).
  if (isBeekiriCodePublishDoc(codeDoc)) {
    return null;
  }

  const styleLinks = layouts.map(layoutStylesheet);

  if (isBeekiricanvaData(beekiricanva) && beekiricanva.content.length > 0) {
    return (
      <div className="bk-page-body">
        {styleLinks}
        <Render config={config} data={beekiricanva} />
      </div>
    );
  }

  if (content.trim() && /<[a-z][\s\S]*>/i.test(content)) {
    return (
      <div
        className="bk-page-body"
        dangerouslySetInnerHTML={{ __html: content }}
      />
    );
  }

  if (content.trim()) {
    return (
      <div className="bk-page-body">
        <p>{content}</p>
      </div>
    );
  }

  if (isBeekiricanvaData(beekiricanva)) {
    return (
      <div className="bk-page-body">
        {styleLinks}
        <Render config={config} data={beekiricanva} />
      </div>
    );
  }

  return null;
}
