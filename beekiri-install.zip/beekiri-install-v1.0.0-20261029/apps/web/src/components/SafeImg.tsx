import type { ImgHTMLAttributes } from 'react';

type Props = Omit<ImgHTMLAttributes<HTMLImageElement>, 'alt'> & {
  /** Decorative when empty/missing — always emits an alt attribute for a11y. */
  alt?: string | null;
  /** When true, mark decorative (empty alt + aria-hidden). */
  decorative?: boolean;
};

/**
 * Image with hard a11y fallbacks: never omit `alt`.
 * Missing/blank alt → decorative (`alt=""`); optional aria-hidden.
 */
export function SafeImg({
  alt,
  decorative,
  loading,
  decoding,
  width,
  height,
  ...rest
}: Props) {
  const trimmed = typeof alt === 'string' ? alt.trim() : '';
  const isDecorative = decorative || !trimmed;
  return (
    // eslint-disable-next-line @next/next/no-img-element -- CMS-served / static paths; next/image optional later
    <img
      {...rest}
      width={width ?? 1200}
      height={height ?? 675}
      alt={isDecorative ? '' : trimmed}
      aria-hidden={isDecorative ? true : undefined}
      loading={loading ?? 'lazy'}
      decoding={decoding ?? 'async'}
      style={{
        maxWidth: '100%',
        height: 'auto',
        ...(typeof rest.style === 'object' && rest.style ? rest.style : {}),
      }}
    />
  );
}
