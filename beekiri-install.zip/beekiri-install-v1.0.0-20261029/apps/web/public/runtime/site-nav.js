(function () {
 if (window.__bkSiteNav) return;
 window.__bkSiteNav = true;
 var PASSTHROUGH = ['/api/', '/uploads/', '/_next/', '/admin/'];
 var FILE_EXT = /\.[a-z0-9]{1,8}$/i;
 var prefetched = Object.create(null);
 var busy = false;
 function routable(anchor) {
 if (!anchor || anchor.hasAttribute('download') || anchor.hasAttribute('data-bk-reload')) {
 return null;
 }
 var target = anchor.getAttribute('target');
 if (target && target !== '_self') return null;
 var raw = anchor.getAttribute('href');
 if (!raw || raw.charAt(0) === '#' || /^(mailto|tel|javascript):/i.test(raw)) return null;
 var url;
 try {
 url = new URL(anchor.href, location.href);
 } catch (e) {
 return null;
 }
 if (url.origin !== location.origin) return null;
 for (var i = 0; i < PASSTHROUGH.length; i++) {
 var p = PASSTHROUGH[i];
 if (url.pathname === p.slice(0, -1) || url.pathname.indexOf(p) === 0) return null;
 }
 if (FILE_EXT.test(url.pathname)) return null;
 if (url.hash && url.pathname === location.pathname && url.search === location.search) {
 return null;
 }
 return url.pathname + url.search + url.hash;
 }
 function prefetch(href) {
 var path = href.split('#')[0] || '/';
 if (prefetched[path]) return;
 prefetched[path] = true;
 var link = document.createElement('link');
 link.rel = 'prefetch';
 link.as = 'document';
 link.href = path;
 document.head.appendChild(link);
 }
 function adoptStyles(doc) {
 doc.head.querySelectorAll('link[rel="stylesheet"]').forEach(function (node) {
 var href = node.getAttribute('href');
 if (!href) return;
 var abs = new URL(href, location.href).href;
 var found = false;
 document.head.querySelectorAll('link[rel="stylesheet"]').forEach(function (cur) {
 if (cur.href === abs) found = true;
 });
 if (!found) document.head.appendChild(document.importNode(node, true));
 });
 doc.head.querySelectorAll('style[precedence], style[href]').forEach(function (node) {
 var key = node.getAttribute('href') || '';
 if (!key) return;
 if (document.head.querySelector('style[href="' + key.replace(/"/g, '') + '"]')) return;
 document.head.appendChild(document.importNode(node, true));
 });
 }
 function applyDocument(html, href, push) {
 var doc = new DOMParser().parseFromString(html, 'text/html');
 var nextShell = doc.querySelector('.bk-shell');
 var curShell = document.querySelector('.bk-shell');
 if (!nextShell || !curShell) {
 location.assign(href);
 return;
 }
 document.title = doc.title || document.title;
 var lang = doc.documentElement.getAttribute('lang');
 if (lang) document.documentElement.lang = lang;
 var theme = doc.documentElement.getAttribute('data-theme');
 if (theme) document.documentElement.setAttribute('data-theme', theme);
 adoptStyles(doc);
 curShell.replaceWith(document.importNode(nextShell, true));
 if (push) history.pushState({ bk: 1 }, '', href);
 window.dispatchEvent(
 new CustomEvent('bk:navigate', { detail: { pathname: location.pathname } }),
 );
 if (location.hash) {
 var el = document.getElementById(location.hash.slice(1));
 if (el) el.scrollIntoView();
 } else {
 window.scrollTo(0, 0);
 }
 }
 function load(href, push) {
 if (busy) return;
 busy = true;
 var path = href.split('#')[0] || '/';
 var run = function () {
 return fetch(path, {
 credentials: 'same-origin',
 headers: { Accept: 'text/html' },
 })
 .then(function (res) {
 if (!res.ok) throw new Error(String(res.status));
 var ct = res.headers.get('content-type') || '';
 if (ct.indexOf('text/html') === -1) throw new Error('not-html');
 return res.text();
 })
 .then(function (html) {
 applyDocument(html, href, push);
 })
 .catch(function () {
 if (push) location.assign(href);
 else location.reload();
 })
 .finally(function () {
 busy = false;
 });
 };
 if (push && document.startViewTransition) document.startViewTransition(run);
 else run();
 }
 document.addEventListener('click', function (e) {
 if (e.defaultPrevented || e.button !== 0) return;
 if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
 var anchor = e.target && e.target.closest ? e.target.closest('a[href]') : null;
 var href = routable(anchor);
 if (!href) return;
 e.preventDefault();
 load(href, true);
 });
 document.addEventListener(
 'mouseover',
 function (e) {
 var anchor = e.target && e.target.closest ? e.target.closest('a[href]') : null;
 var href = routable(anchor);
 if (href) prefetch(href);
 },
 { passive: true },
 );
 document.addEventListener('focusin', function (e) {
 var anchor = e.target && e.target.closest ? e.target.closest('a[href]') : null;
 var href = routable(anchor);
 if (href) prefetch(href);
 });
 window.addEventListener('popstate', function () {
 load(location.pathname + location.search + location.hash, false);
 });
})();
