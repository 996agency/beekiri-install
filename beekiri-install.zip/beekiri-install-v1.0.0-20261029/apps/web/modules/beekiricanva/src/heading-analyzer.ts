export { default } from '@beekiri/beekiricanva-heading';
