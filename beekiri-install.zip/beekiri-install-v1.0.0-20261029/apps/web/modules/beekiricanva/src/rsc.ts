/** Lightweight Render for the public site — no editor chrome. */
export { Render } from '@beekiri/beekiricanva-engine/rsc';
export type { Config, Data } from '@beekiri/beekiricanva-engine';
