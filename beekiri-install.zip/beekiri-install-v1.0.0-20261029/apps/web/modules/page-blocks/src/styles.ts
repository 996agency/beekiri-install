import type { CSSProperties } from 'react';

export type BoxSides = {
  top: number;
  right: number;
  bottom: number;
  left: number;
};

export type BlockTypography = {
  fontFamily: string;
  weight: string;
  size: number;
  sizeUnit: 'px' | 'rem' | 'em';
  lineHeight: number | 'auto';
  color: string;
  align: 'left' | 'center' | 'right' | 'justify';
  italic: boolean;
  bold: boolean;
  underline: boolean;
  strike: boolean;
  uppercase: boolean;
};

export type BlockLayout = {
  display: 'block' | 'flex' | 'grid' | 'inline-flex' | 'none';
};

export type BlockSpacing = {
  margin: BoxSides;
  padding: BoxSides;
};

export type BlockBackground = {
  color: string;
  image: string;
  clip: 'none' | 'padding-box' | 'content-box' | 'text';
};

export type BlockBorder = {
  radius: number;
  width: number;
  style: 'none' | 'solid' | 'dashed' | 'dotted';
  color: string;
  side: 'all' | 'top' | 'right' | 'bottom' | 'left';
};

export type BlockEffects = {
  opacity: number;
};

export const defaultTypography = (): BlockTypography => ({
  fontFamily: 'inherit',
  weight: '600',
  size: 28,
  sizeUnit: 'px',
  lineHeight: 'auto',
  color: '#1d2327',
  align: 'left',
  italic: false,
  bold: false,
  underline: false,
  strike: false,
  uppercase: false,
});

export const defaultLayout = (): BlockLayout => ({
  display: 'block',
});

export const zeroBox = (): BoxSides => ({
  top: 0,
  right: 0,
  bottom: 0,
  left: 0,
});

export const defaultSpacing = (): BlockSpacing => ({
  margin: { top: 0, right: 0, bottom: 16, left: 0 },
  padding: { top: 0, right: 0, bottom: 0, left: 0 },
});

export const defaultBackground = (): BlockBackground => ({
  color: 'transparent',
  image: '',
  clip: 'none',
});

export const defaultBorder = (): BlockBorder => ({
  radius: 0,
  width: 0,
  style: 'none',
  color: '#c3c4c7',
  side: 'all',
});

export const defaultEffects = (): BlockEffects => ({
  opacity: 100,
});

function boxCss(prefix: 'margin' | 'padding', box: BoxSides | undefined): CSSProperties {
  if (!box) return {};
  return {
    [`${prefix}Top`]: box.top,
    [`${prefix}Right`]: box.right,
    [`${prefix}Bottom`]: box.bottom,
    [`${prefix}Left`]: box.left,
  } as CSSProperties;
}

export function typographyToCss(t?: Partial<BlockTypography> | null): CSSProperties {
  if (!t) return {};
  const deco: string[] = [];
  if (t.underline) deco.push('underline');
  if (t.strike) deco.push('line-through');
  return {
    fontFamily: t.fontFamily && t.fontFamily !== 'inherit' ? t.fontFamily : undefined,
    fontWeight: t.bold ? 700 : t.weight ? Number(t.weight) || (t.weight as CSSProperties['fontWeight']) : undefined,
    fontSize: t.size != null ? `${t.size}${t.sizeUnit || 'px'}` : undefined,
    lineHeight: t.lineHeight === 'auto' || t.lineHeight == null ? undefined : t.lineHeight,
    color: t.color || undefined,
    textAlign: t.align || undefined,
    fontStyle: t.italic ? 'italic' : undefined,
    textDecoration: deco.length ? deco.join(' ') : undefined,
    textTransform: t.uppercase ? 'uppercase' : undefined,
  };
}

export function layoutToCss(l?: Partial<BlockLayout> | null): CSSProperties {
  if (!l?.display) return {};
  return { display: l.display };
}

export function spacingToCss(s?: Partial<BlockSpacing> | null): CSSProperties {
  if (!s) return {};
  return { ...boxCss('margin', s.margin), ...boxCss('padding', s.padding) };
}

export function backgroundToCss(b?: Partial<BlockBackground> | null): CSSProperties {
  if (!b) return {};
  return {
    backgroundColor: b.color && b.color !== 'transparent' ? b.color : undefined,
    backgroundImage: b.image ? `url(${b.image})` : undefined,
    backgroundSize: b.image ? 'cover' : undefined,
    backgroundPosition: b.image ? 'center' : undefined,
    backgroundClip: b.clip && b.clip !== 'none' ? b.clip : undefined,
  };
}

export function borderToCss(b?: Partial<BlockBorder> | null): CSSProperties {
  if (!b) return {};
  const width = b.width ?? 0;
  const style = b.style && b.style !== 'none' ? b.style : width > 0 ? 'solid' : 'none';
  const color = b.color || '#c3c4c7';
  const side = b.side || 'all';
  const border: CSSProperties = { borderRadius: b.radius ?? 0 };
  if (style === 'none' || width <= 0) {
    border.border = 'none';
    return border;
  }
  const value = `${width}px ${style} ${color}`;
  if (side === 'all') border.border = value;
  else if (side === 'top') border.borderTop = value;
  else if (side === 'right') border.borderRight = value;
  else if (side === 'bottom') border.borderBottom = value;
  else if (side === 'left') border.borderLeft = value;
  return border;
}

export function effectsToCss(e?: Partial<BlockEffects> | null): CSSProperties {
  if (!e || e.opacity == null || e.opacity >= 100) return {};
  return { opacity: Math.max(0, Math.min(100, e.opacity)) / 100 };
}

export function sectionStyle(props: {
  layout?: Partial<BlockLayout> | null;
  spacing?: Partial<BlockSpacing> | null;
  background?: Partial<BlockBackground> | null;
  border?: Partial<BlockBorder> | null;
  effects?: Partial<BlockEffects> | null;
}): CSSProperties {
  return {
    ...layoutToCss(props.layout),
    ...spacingToCss(props.spacing),
    ...backgroundToCss(props.background),
    ...borderToCss(props.border),
    ...effectsToCss(props.effects),
  };
}
