import type { Config, Data } from '@beekiri/beekiricanva';

/** Block prop map — empty until we rebuild blocks from scratch. */
export type BeekiriBlocks = Record<string, never>;

export const beekiricanvaConfig: Config<BeekiriBlocks> = {
  // Explicit empty root fields — otherwise Beekiricanva injects a default Page "title".
  root: { fields: {} },
  categories: {},
  components: {},
};

export const emptyBeekiricanvaData: Data = {
  root: { props: {} },
  content: [],
};

/** Legacy HTML is no longer lifted into blocks — keep canvas empty. */
export function beekiricanvaDataFromLegacyHtml(_html: string): Data {
  return emptyBeekiricanvaData;
}

export function isBeekiricanvaData(value: unknown): value is Data {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const o = value as Record<string, unknown>;
  return Array.isArray(o.content);
}
