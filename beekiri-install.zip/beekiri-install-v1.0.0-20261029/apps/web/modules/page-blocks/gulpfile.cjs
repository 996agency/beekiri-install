const { src, dest, watch, series } = require('gulp');
const sass = require('gulp-sass')(require('sass'));
const path = require('path');

const ROOT = __dirname;
const SCSS_ENTRY = path.join(ROOT, 'scss/blocks.scss');
const SCSS_GLOB = path.join(ROOT, 'scss/**/*.scss');
const CSS_OUT = path.join(ROOT, 'src');

function styles() {
  return src(SCSS_ENTRY)
    .pipe(
      sass({
        outputStyle: 'expanded',
        sourceMap: false,
      }).on('error', sass.logError),
    )
    .pipe(dest(CSS_OUT));
}

function stylesWatch() {
  watch(SCSS_GLOB, styles);
}

exports.styles = styles;
exports.watch = series(styles, stylesWatch);
exports.default = styles;
