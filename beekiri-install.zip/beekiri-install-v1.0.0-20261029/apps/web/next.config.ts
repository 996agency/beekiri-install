import type { NextConfig } from 'next';
import { join } from 'path';

// The Beekiri server runs this website in its own process and serves /uploads itself,
// so no addresses are configured here.

const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  compress: true,
  // Hide the Next.js “N” badge in local/dev.
  devIndicators: false,
  // Block streaming metadata for all UAs so <meta description> is always in first HTML (SEO/LH).
  htmlLimitedBots: /.*/,
  transpilePackages: [
    '@beekiri/page-blocks',
    '@beekiri/beekiricanva',
    '@beekiri/beekiricanva-engine',
    '@beekiri/beekiricanva-heading',
  ],
  // Keep `next dev` from overwriting production `.next` (breaks Lighthouse Perf).
  distDir: process.env.NEXT_DIST_DIR || '.next',
  // Monorepo: stop Next picking a parent lockfile as workspace root.
  outputFileTracingRoot: join(__dirname, '../..'),
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
          // Allow bfcache — do not send no-store on HTML.
          {
            key: 'Cache-Control',
            value: 'public, max-age=0, must-revalidate',
          },
        ],
      },
      {
        source: '/:path*(svg|png|jpg|jpeg|gif|webp|ico|woff2)',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=31536000, immutable',
          },
        ],
      },
    ];
  },
};

export default nextConfig;
