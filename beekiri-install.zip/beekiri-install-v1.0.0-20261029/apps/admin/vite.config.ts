import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The admin is served by the Beekiri server at /admin (built files in production, this
// config as middleware in development), on the same address as the API and website.
export default defineConfig({
  base: '/admin/',
  plugins: [react()],
  server: {
    fs: {
      // Shared editor packages (page-blocks / beekiricanva) live in apps/web/modules.
      allow: ['../..', '../web/modules'],
    },
  },
});
