/** The API shares the admin's address (it lives at /api). */
export const API_BASE = '';

/** Absolute URL for API paths (layout CSS, uploads, …). */
export function apiUrl(path: string): string {
  if (!path) return API_BASE || '';
  if (/^https?:\/\//i.test(path)) return path;
  const base = (API_BASE || '').replace(/\/$/, '');
  const p = path.startsWith('/') ? path : `/${path}`;
  return `${base}${p}`;
}

let csrfToken: string | null = null;

export function setCsrfToken(token: string | null) {
  csrfToken = token;
}

export function getCsrfToken() {
  return csrfToken;
}

export class ApiError extends Error {
  status: number;
  body: unknown;
  constructor(status: number, message: string, body?: unknown) {
    super(message);
    this.status = status;
    this.body = body;
  }
}

export async function api<T>(
  path: string,
  options: RequestInit & { json?: unknown } = {},
): Promise<T> {
  const headers = new Headers(options.headers);
  if (options.json !== undefined) {
    headers.set('Content-Type', 'application/json');
  }
  const method = (options.method ?? (options.json !== undefined ? 'POST' : 'GET')).toUpperCase();
  if (!['GET', 'HEAD', 'OPTIONS'].includes(method) && csrfToken) {
    headers.set('X-CSRF-Token', csrfToken);
  }

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    method,
    headers,
    credentials: 'include',
    body: options.json !== undefined ? JSON.stringify(options.json) : options.body,
  });

  const text = await res.text();
  let data: unknown = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
  }

  if (!res.ok) {
    let message = res.statusText;
    if (typeof data === 'object' && data && 'message' in data) {
      const raw = (data as { message: unknown }).message;
      if (Array.isArray(raw)) message = raw.map(String).join(' ');
      else if (raw != null) message = String(raw);
    }
    throw new ApiError(res.status, message, data);
  }
  return data as T;
}

/** Multipart upload — do not set Content-Type (browser sets boundary). */
export async function apiUpload<T>(
  path: string,
  form: FormData,
  options: { method?: string } = {},
): Promise<T> {
  const headers = new Headers();
  const method = (options.method ?? 'POST').toUpperCase();
  if (!['GET', 'HEAD', 'OPTIONS'].includes(method) && csrfToken) {
    headers.set('X-CSRF-Token', csrfToken);
  }

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    credentials: 'include',
    body: form,
  });

  const text = await res.text();
  let data: unknown = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
  }

  if (!res.ok) {
    let message = res.statusText;
    if (typeof data === 'object' && data && 'message' in data) {
      const raw = (data as { message: unknown }).message;
      if (Array.isArray(raw)) message = raw.map(String).join(' ');
      else if (raw != null) message = String(raw);
    }
    throw new ApiError(res.status, message, data);
  }
  return data as T;
}
