/** Cross-screen signals so the shell can refresh without a full page reload. */

export const POST_TYPES_CHANGED = 'beekiri:post-types-changed';
export const CONNECTOR_CHANGED = 'beekiri:connector-changed';

export function notifyPostTypesChanged() {
  window.dispatchEvent(new Event(POST_TYPES_CHANGED));
}

export function notifyConnectorChanged() {
  window.dispatchEvent(new Event(CONNECTOR_CHANGED));
}
