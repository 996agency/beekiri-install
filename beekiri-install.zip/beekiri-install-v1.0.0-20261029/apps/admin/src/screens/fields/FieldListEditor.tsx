import { createContext, useContext, useState, type ReactNode } from 'react';
import {
  DATE_DEFAULTS,
  FIELD_CATEGORIES,
  FIELD_TYPE_DEFS,
  cloneField,
  newField,
  newLayout,
  toFieldName,
  typeDef,
  type BackendField,
  type FieldType,
  type FlexibleLayout,
  type Option,
  type SettingKey,
} from '../../fields/acf-types';

export type FieldEditorContext = {
  postTypes: Option[];
  roles: Option[];
};

const Ctx = createContext<FieldEditorContext>({ postTypes: [], roles: [] });

export function FieldEditorProvider({ value, children }: { value: FieldEditorContext; children: ReactNode }) {
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

type Tab = 'general' | 'validation' | 'presentation';

const SETTING_META: Partial<Record<SettingKey, { label: string; help?: string }>> = {
  defaultValue: { label: 'Default Value', help: 'Appears when creating a new layout' },
  placeholder: { label: 'Placeholder Text', help: 'Appears within the input' },
  prepend: { label: 'Prepend', help: 'Appears before the input' },
  append: { label: 'Append', help: 'Appears after the input' },
  maxLength: { label: 'Character Limit', help: 'Leave blank for no limit' },
  rows: { label: 'Rows', help: 'Sets the textarea height' },
  newLines: { label: 'New Lines', help: 'Controls how new lines are rendered' },
  min: { label: 'Minimum' },
  max: { label: 'Maximum' },
  step: { label: 'Step Size' },
  choices: { label: 'Choices', help: 'Enter each choice on a new line. For more control, specify both a value and label like: red : Red' },
  returnFormat: { label: 'Return Format', help: 'Specify the value returned by get_bee_field()' },
  multiple: { label: 'Select Multiple', help: 'Allow content editors to select multiple values' },
  allowNull: { label: 'Allow Null', help: 'Allow an empty value' },
  layout: { label: 'Layout' },
  ui: { label: 'Stylized UI', help: 'Use a stylised toggle / searchable select' },
  onText: { label: 'On Text', help: 'Text shown when active' },
  offText: { label: 'Off Text', help: 'Text shown when inactive' },
  message: { label: 'Message' },
  displayFormat: { label: 'Display Format', help: 'The format displayed when editing (PHP date format)' },
  postTypes: { label: 'Filter by Post Type', help: 'Leave empty for all post types' },
  roles: { label: 'Filter by Role', help: 'Leave empty for all roles' },
  mimeTypes: { label: 'Allowed File Types', help: 'Comma separated list. Leave blank for all types (e.g. jpg, png, webp)' },
  previewSize: { label: 'Preview Size' },
  toolbar: { label: 'Toolbar' },
  mediaUpload: { label: 'Show Media Upload Buttons' },
  minRows: { label: 'Minimum Rows' },
  maxRows: { label: 'Maximum Rows' },
  buttonLabel: { label: 'Button Label' },
  collapsed: { label: 'Collapsed', help: 'Sub field shown when a row is collapsed' },
  required: { label: 'Required', help: 'Content editors must fill this field' },
};

/* —— small controls —— */

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      className={`bk-acf-toggle${checked ? ' is-on' : ''}`}
      onClick={() => onChange(!checked)}
    >
      <span />
    </button>
  );
}

function SettingRow({ label, help, children }: { label: string; help?: string; children: ReactNode }) {
  return (
    <div className="bk-acf-setting">
      <div className="bk-acf-setting__label">
        <span>{label}</span>
        {help ? <p>{help}</p> : null}
      </div>
      <div className="bk-acf-setting__control">{children}</div>
    </div>
  );
}

function NumInput({ value, onChange }: { value?: number; onChange: (v: number | undefined) => void }) {
  return (
    <input
      type="number"
      className="regular-text"
      value={value ?? ''}
      onChange={(e) => onChange(e.target.value === '' ? undefined : Number(e.target.value))}
    />
  );
}

function TypeSelect({ value, onChange }: { value: FieldType; onChange: (t: FieldType) => void }) {
  return (
    <select value={value} onChange={(e) => onChange(e.target.value as FieldType)}>
      {FIELD_CATEGORIES.map((cat) => (
        <optgroup key={cat} label={cat}>
          {FIELD_TYPE_DEFS.filter((d) => d.category === cat).map((d) => (
            <option key={d.type} value={d.type}>
              {d.label}
            </option>
          ))}
        </optgroup>
      ))}
    </select>
  );
}

/* —— one type-specific setting —— */

function Setting({
  k,
  field,
  patch,
}: {
  k: SettingKey;
  field: BackendField;
  patch: (p: Partial<BackendField>) => void;
}) {
  const ctx = useContext(Ctx);
  const def = typeDef(field.type);
  const meta = SETTING_META[k] ?? { label: k };
  const text = (key: keyof BackendField, placeholder?: string) => (
    <input
      type="text"
      className="regular-text"
      value={(field[key] as string | undefined) ?? ''}
      placeholder={placeholder}
      onChange={(e) => patch({ [key]: e.target.value } as Partial<BackendField>)}
    />
  );

  switch (k) {
    case 'required':
      return (
        <SettingRow {...meta}>
          <Toggle checked={field.required} onChange={(v) => patch({ required: v })} />
        </SettingRow>
      );
    case 'defaultValue':
      if (field.type === 'true_false') {
        return (
          <SettingRow label="Default Value">
            <Toggle checked={field.defaultValue === '1'} onChange={(v) => patch({ defaultValue: v ? '1' : '' })} />
          </SettingRow>
        );
      }
      if (field.type === 'textarea' || field.type === 'wysiwyg' || field.type === 'checkbox') {
        return (
          <SettingRow {...meta} help={field.type === 'checkbox' ? 'Enter each default value on a new line' : meta.help}>
            <textarea rows={3} value={field.defaultValue} onChange={(e) => patch({ defaultValue: e.target.value })} />
          </SettingRow>
        );
      }
      if (field.type === 'color_picker') {
        return (
          <SettingRow {...meta}>
            <div className="bk-acf-inline">
              <input
                type="color"
                value={/^#[0-9a-f]{6}$/i.test(field.defaultValue) ? field.defaultValue : '#000000'}
                onChange={(e) => patch({ defaultValue: e.target.value })}
              />
              {text('defaultValue', '#000000')}
            </div>
          </SettingRow>
        );
      }
      return <SettingRow {...meta}>{text('defaultValue')}</SettingRow>;
    case 'placeholder':
    case 'prepend':
    case 'append':
    case 'onText':
    case 'offText':
    case 'buttonLabel':
    case 'mimeTypes':
      return (
        <SettingRow {...meta}>
          {text(k, k === 'buttonLabel' ? 'Add Row' : undefined)}
        </SettingRow>
      );
    case 'maxLength':
    case 'rows':
    case 'min':
    case 'max':
    case 'step':
    case 'minRows':
    case 'maxRows': {
      const label =
        field.type === 'gallery' && (k === 'min' || k === 'max')
          ? `${k === 'min' ? 'Minimum' : 'Maximum'} Selection`
          : (field.type === 'relationship' || field.type === 'flexible_content') && (k === 'min' || k === 'max')
            ? `${k === 'min' ? 'Minimum' : 'Maximum'} ${field.type === 'flexible_content' ? 'Layouts' : 'Posts'}`
            : meta.label;
      return (
        <SettingRow label={label} help={meta.help}>
          <NumInput value={field[k] as number | undefined} onChange={(v) => patch({ [k]: v } as Partial<BackendField>)} />
        </SettingRow>
      );
    }
    case 'newLines':
      return (
        <SettingRow {...meta}>
          <select value={field.newLines ?? ''} onChange={(e) => patch({ newLines: e.target.value })}>
            <option value="wpautop">Automatically add paragraphs</option>
            <option value="br">Automatically add &lt;br&gt;</option>
            <option value="">No Formatting</option>
          </select>
        </SettingRow>
      );
    case 'choices':
      return (
        <SettingRow {...meta}>
          <textarea
            rows={5}
            value={field.choices.join('\n')}
            placeholder={'red : Red\nblue : Blue'}
            onChange={(e) => patch({ choices: e.target.value.split('\n') })}
            onBlur={(e) => patch({ choices: e.target.value.split('\n').map((c) => c.trim()).filter(Boolean) })}
          />
        </SettingRow>
      );
    case 'returnFormat': {
      if (field.type === 'date_picker' || field.type === 'date_time_picker' || field.type === 'time_picker') {
        const d = DATE_DEFAULTS[field.type];
        return (
          <SettingRow label="Return Format" help="The format returned via template functions (PHP date format)">
            {text('returnFormat', d.ret)}
          </SettingRow>
        );
      }
      const opts = def.returnFormats ?? [];
      const current = field.returnFormat ?? opts[0]?.value ?? '';
      return (
        <SettingRow {...meta}>
          <div className="bk-acf-radios">
            {opts.map((o) => (
              <label key={o.value}>
                <input type="radio" checked={current === o.value} onChange={() => patch({ returnFormat: o.value })} />
                {o.label}
              </label>
            ))}
          </div>
        </SettingRow>
      );
    }
    case 'displayFormat': {
      const d = DATE_DEFAULTS[field.type];
      return <SettingRow {...meta}>{text('displayFormat', d?.display)}</SettingRow>;
    }
    case 'multiple':
    case 'allowNull':
    case 'ui':
    case 'mediaUpload':
      return (
        <SettingRow {...meta}>
          <Toggle
            checked={Boolean(field[k] ?? (k === 'mediaUpload'))}
            onChange={(v) => patch({ [k]: v } as Partial<BackendField>)}
          />
        </SettingRow>
      );
    case 'layout': {
      const opts = def.layouts ?? [];
      const current = field.layout ?? opts[0]?.value ?? '';
      return (
        <SettingRow {...meta}>
          <div className="bk-acf-radios">
            {opts.map((o) => (
              <label key={o.value}>
                <input type="radio" checked={current === o.value} onChange={() => patch({ layout: o.value })} />
                {o.label}
              </label>
            ))}
          </div>
        </SettingRow>
      );
    }
    case 'message':
      return (
        <SettingRow label="Message" help={field.type === 'true_false' ? 'Displays text alongside the checkbox' : undefined}>
          <textarea rows={3} value={field.message ?? ''} onChange={(e) => patch({ message: e.target.value })} />
        </SettingRow>
      );
    case 'postTypes':
    case 'roles': {
      const opts = k === 'postTypes' ? ctx.postTypes : ctx.roles;
      const sel = field[k] ?? [];
      return (
        <SettingRow {...meta}>
          <div className="bk-acf-checks">
            {opts.map((o) => (
              <label key={o.value}>
                <input
                  type="checkbox"
                  checked={sel.includes(o.value)}
                  onChange={(e) =>
                    patch({
                      [k]: e.target.checked ? [...sel, o.value] : sel.filter((v) => v !== o.value),
                    } as Partial<BackendField>)
                  }
                />
                {o.label}
              </label>
            ))}
          </div>
        </SettingRow>
      );
    }
    case 'previewSize':
      return (
        <SettingRow {...meta}>
          <select value={field.previewSize ?? 'medium'} onChange={(e) => patch({ previewSize: e.target.value })}>
            <option value="thumbnail">Thumbnail</option>
            <option value="medium">Medium</option>
            <option value="large">Large</option>
            <option value="full">Full Size</option>
          </select>
        </SettingRow>
      );
    case 'toolbar':
      return (
        <SettingRow {...meta}>
          <div className="bk-acf-radios">
            {['full', 'basic'].map((t) => (
              <label key={t}>
                <input type="radio" checked={(field.toolbar ?? 'full') === t} onChange={() => patch({ toolbar: t })} />
                {t === 'full' ? 'Full' : 'Basic'}
              </label>
            ))}
          </div>
        </SettingRow>
      );
    case 'collapsed':
      return (
        <SettingRow {...meta}>
          <select value={field.collapsed ?? ''} onChange={(e) => patch({ collapsed: e.target.value })}>
            <option value="">Select</option>
            {(field.subFields ?? []).map((sf) => (
              <option key={sf.id} value={sf.name}>
                {sf.label || sf.name}
              </option>
            ))}
          </select>
        </SettingRow>
      );
    default:
      return null;
  }
}

/* —— flexible content layouts —— */

function LayoutsEditor({
  layouts,
  onChange,
}: {
  layouts: FlexibleLayout[];
  onChange: (next: FlexibleLayout[]) => void;
}) {
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const update = (id: string, p: Partial<FlexibleLayout>) =>
    onChange(layouts.map((l) => (l.id === id ? { ...l, ...p } : l)));
  const move = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= layouts.length) return;
    const next = [...layouts];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };

  return (
    <div className="bk-acf-layouts">
      {layouts.map((l, i) => {
        const isOpen = open[l.id] ?? !l.label;
        return (
          <div key={l.id} className="bk-acf-layout">
            <div className="bk-acf-layout__head">
              <button type="button" className="bk-acf-layout__toggle" onClick={() => setOpen((o) => ({ ...o, [l.id]: !isOpen }))}>
                <span className={`bk-acf-caret${isOpen ? ' is-open' : ''}`} aria-hidden />
                <strong>{l.label || '(no label)'}</strong>
                <code>{l.name || 'layout_name'}</code>
                <span className="bk-acf-muted">{l.subFields.length} fields</span>
              </button>
              <div className="bk-acf-layout__actions">
                <button type="button" className="button-link" onClick={() => move(i, -1)} disabled={i === 0} aria-label="Move up">↑</button>
                <button type="button" className="button-link" onClick={() => move(i, 1)} disabled={i === layouts.length - 1} aria-label="Move down">↓</button>
                <button
                  type="button"
                  className="button-link"
                  onClick={() => {
                    const copy = { ...l, id: `layout_${Math.random().toString(36).slice(2, 11)}`, name: `${l.name}_copy`, label: `${l.label} (copy)`, subFields: l.subFields.map(cloneField) };
                    const next = [...layouts];
                    next.splice(i + 1, 0, copy);
                    onChange(next);
                  }}
                >
                  Duplicate
                </button>
                <button type="button" className="button-link is-danger" onClick={() => onChange(layouts.filter((x) => x.id !== l.id))}>
                  Delete
                </button>
              </div>
            </div>
            {isOpen ? (
              <div className="bk-acf-layout__body">
                <div className="bk-acf-layout__meta">
                  <label>
                    <span>Label</span>
                    <input
                      type="text"
                      className="regular-text"
                      value={l.label}
                      onChange={(e) => {
                        const label = e.target.value;
                        update(l.id, {
                          label,
                          name: !l.name || l.name === toFieldName(l.label) ? toFieldName(label) : l.name,
                        });
                      }}
                    />
                  </label>
                  <label>
                    <span>Name</span>
                    <input type="text" className="regular-text" value={l.name} onChange={(e) => update(l.id, { name: toFieldName(e.target.value) })} />
                  </label>
                  <label>
                    <span>Layout</span>
                    <select value={l.display} onChange={(e) => update(l.id, { display: e.target.value as FlexibleLayout['display'] })}>
                      <option value="block">Block</option>
                      <option value="table">Table</option>
                      <option value="row">Row</option>
                    </select>
                  </label>
                  <label>
                    <span>Min</span>
                    <NumInput value={l.min} onChange={(v) => update(l.id, { min: v })} />
                  </label>
                  <label>
                    <span>Max</span>
                    <NumInput value={l.max} onChange={(v) => update(l.id, { max: v })} />
                  </label>
                </div>
                <FieldListEditor fields={l.subFields} onChange={(subFields) => update(l.id, { subFields })} nested />
              </div>
            ) : null}
          </div>
        );
      })}
      <button type="button" className="button" onClick={() => onChange([...layouts, newLayout()])}>
        + Add Layout
      </button>
    </div>
  );
}

/* —— one field row (collapsed header + settings) —— */

function FieldRow({
  field,
  index,
  open,
  onToggle,
  onChange,
  onDuplicate,
  onDelete,
  dragProps,
}: {
  field: BackendField;
  index: number;
  open: boolean;
  onToggle: () => void;
  onChange: (f: BackendField) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  dragProps: React.HTMLAttributes<HTMLSpanElement> & { draggable: boolean };
}) {
  const [tab, setTab] = useState<Tab>('general');
  const def = typeDef(field.type);
  const patch = (p: Partial<BackendField>) => onChange({ ...field, ...p });

  const changeType = (type: FieldType) => {
    const next: BackendField = { ...field, type, returnFormat: undefined, layout: undefined, displayFormat: undefined };
    if ((type === 'repeater' || type === 'group') && !next.subFields) next.subFields = [];
    if (type === 'flexible_content' && !next.layouts) next.layouts = [newLayout()];
    onChange(next);
  };

  const hasSub = field.type === 'repeater' || field.type === 'group';
  const isFlex = field.type === 'flexible_content';
  const tabs: Tab[] = def.noValue ? ['general', 'presentation'] : ['general', 'validation', 'presentation'];

  return (
    <div className={`bk-acf-field${open ? ' is-open' : ''}`}>
      <div className="bk-acf-field__row" onClick={onToggle}>
        <span className="bk-acf-field__order" {...dragProps} onClick={(e) => e.stopPropagation()} title="Drag to reorder">
          <span className="bk-acf-grip" aria-hidden />
          {index + 1}
        </span>
        <span className="bk-acf-field__label">
          <span className="bk-acf-field__title">
            <strong>{field.label || '(no label)'}</strong>
            {field.required ? <span className="bk-acf-required">*</span> : null}
          </span>
          <span className="bk-acf-field__actions" onClick={(e) => e.stopPropagation()}>
            <button type="button" className="button-link" onClick={onToggle}>{open ? 'Close' : 'Edit'}</button>
            <span>|</span>
            <button type="button" className="button-link" onClick={onDuplicate}>Duplicate</button>
            <span>|</span>
            <button type="button" className="button-link is-danger" onClick={onDelete}>Delete</button>
          </span>
        </span>
        <code className="bk-acf-field__name">{def.noValue ? '—' : field.name || '—'}</code>
        <span className="bk-acf-field__type">
          <span className={`bk-acf-type-icon bk-acf-type-icon--${def.category.toLowerCase()}`} aria-hidden />
          {def.label}
        </span>
      </div>

      {open ? (
        <div className="bk-acf-field__settings">
          <div className="bk-acf-tabs" role="tablist">
            {tabs.map((t) => (
              <button key={t} type="button" role="tab" aria-selected={tab === t} className={tab === t ? 'is-active' : ''} onClick={() => setTab(t)}>
                {t === 'general' ? 'General' : t === 'validation' ? 'Validation' : 'Presentation'}
              </button>
            ))}
          </div>

          {tab === 'general' ? (
            <>
              <SettingRow label="Field Type">
                <TypeSelect value={field.type} onChange={changeType} />
              </SettingRow>
              <SettingRow label="Field Label" help="This is the name which will appear on the EDIT page">
                <input
                  type="text"
                  className="regular-text"
                  value={field.label}
                  autoFocus={!field.label}
                  onChange={(e) => {
                    const label = e.target.value;
                    patch({
                      label,
                      name: !field.name || field.name === toFieldName(field.label) ? toFieldName(label) : field.name,
                    });
                  }}
                />
              </SettingRow>
              {!def.noValue ? (
                <SettingRow label="Field Name" help="Single word, no spaces. Underscores allowed">
                  <input
                    type="text"
                    className="regular-text"
                    value={field.name}
                    onChange={(e) => patch({ name: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '_') })}
                  />
                </SettingRow>
              ) : null}
              {def.general.map((k) => (
                <Setting key={k} k={k} field={field} patch={patch} />
              ))}
              {hasSub ? (
                <div className="bk-acf-subfields">
                  <div className="bk-acf-subfields__label">Sub Fields</div>
                  <FieldListEditor fields={field.subFields ?? []} onChange={(subFields) => patch({ subFields })} nested />
                </div>
              ) : null}
              {isFlex ? (
                <div className="bk-acf-subfields">
                  <div className="bk-acf-subfields__label">Layouts</div>
                  <LayoutsEditor layouts={field.layouts ?? []} onChange={(layouts) => patch({ layouts })} />
                </div>
              ) : null}
            </>
          ) : null}

          {tab === 'validation'
            ? def.validation.map((k) => <Setting key={k} k={k} field={field} patch={patch} />)
            : null}

          {tab === 'presentation' ? (
            <>
              <SettingRow label="Instructions" help="Instructions for content editors. Shown when editing">
                <textarea rows={2} value={field.instructions} onChange={(e) => patch({ instructions: e.target.value })} />
              </SettingRow>
              {def.presentation.map((k) => (
                <Setting key={k} k={k} field={field} patch={patch} />
              ))}
              <SettingRow label="Wrapper Width" help="Percentage of the editor row this field takes">
                <div className="bk-acf-inline">
                  <NumInput value={field.width} onChange={(v) => patch({ width: v })} />
                  <span>%</span>
                </div>
              </SettingRow>
            </>
          ) : null}

          <div className="bk-acf-field__foot">
            <button type="button" className="button" onClick={onToggle}>
              Close Field
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

/* —— list (recursive) —— */

export function FieldListEditor({
  fields,
  onChange,
  nested = false,
}: {
  fields: BackendField[];
  onChange: (next: BackendField[]) => void;
  nested?: boolean;
}) {
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [dragFrom, setDragFrom] = useState<number | null>(null);
  const [dragOver, setDragOver] = useState<number | null>(null);

  const add = () => {
    const f = newField();
    onChange([...fields, f]);
    setOpen((o) => ({ ...o, [f.id]: true }));
  };

  const drop = (to: number) => {
    if (dragFrom == null || dragFrom === to) return;
    const next = [...fields];
    const [m] = next.splice(dragFrom, 1);
    next.splice(to > dragFrom ? to - 1 : to, 0, m);
    onChange(next);
  };

  return (
    <div className={`bk-acf-fields${nested ? ' is-nested' : ''}`}>
      <div className="bk-acf-fields__head">
        <span>#</span>
        <span>Label</span>
        <span>Name</span>
        <span>Type</span>
      </div>
      {fields.length === 0 ? (
        <div className="bk-acf-fields__empty">
          No fields. Click the <strong>+ Add Field</strong> button to create your first field.
        </div>
      ) : (
        <div
          className="bk-acf-fields__list"
          onDragOver={(e) => {
            if (dragFrom != null) e.preventDefault();
          }}
        >
          {fields.map((f, i) => (
            <div
              key={f.id}
              className={`bk-acf-drop${dragOver === i && dragFrom != null && dragFrom !== i ? ' is-over' : ''}`}
              onDragOver={(e) => {
                if (dragFrom == null) return;
                e.preventDefault();
                e.stopPropagation();
                const r = e.currentTarget.getBoundingClientRect();
                setDragOver(e.clientY > r.top + r.height / 2 ? i + 1 : i);
              }}
              onDrop={(e) => {
                e.preventDefault();
                e.stopPropagation();
                if (dragOver != null) drop(dragOver);
                setDragFrom(null);
                setDragOver(null);
              }}
            >
              {dragOver === i && dragFrom != null && dragFrom !== i && dragFrom !== i - 1 ? <div className="bk-acf-drop__line" /> : null}
              <FieldRow
                field={f}
                index={i}
                open={Boolean(open[f.id])}
                onToggle={() => setOpen((o) => ({ ...o, [f.id]: !o[f.id] }))}
                onChange={(nf) => onChange(fields.map((x) => (x.id === f.id ? nf : x)))}
                onDuplicate={() => {
                  const copy = cloneField(f);
                  copy.label = `${f.label} (copy)`;
                  copy.name = `${f.name}_copy`;
                  const next = [...fields];
                  next.splice(i + 1, 0, copy);
                  onChange(next);
                }}
                onDelete={() => onChange(fields.filter((x) => x.id !== f.id))}
                dragProps={{
                  draggable: true,
                  onDragStart: (e) => {
                    e.stopPropagation();
                    e.dataTransfer.effectAllowed = 'move';
                    setDragFrom(i);
                  },
                  onDragEnd: () => {
                    setDragFrom(null);
                    setDragOver(null);
                  },
                }}
              />
              {dragOver === i + 1 && i === fields.length - 1 && dragFrom != null && dragFrom !== i ? (
                <div className="bk-acf-drop__line" />
              ) : null}
            </div>
          ))}
        </div>
      )}
      <div className="bk-acf-fields__foot">
        <button type="button" className={nested ? 'button' : 'button button-primary'} onClick={add}>
          + Add Field
        </button>
      </div>
    </div>
  );
}
