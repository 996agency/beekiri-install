import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, Navigate, useNavigate, useParams } from 'react-router-dom';
import { emptyBeekiricanvaData } from '@beekiri/page-blocks';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { confirmDialog } from '../components/ConfirmDialog';
import { SuccessNotice } from '../components/SuccessNotice';
import {
  contentKindConfig,
  type ContentKind,
  type CptLabels,
} from '../content/contentKind';
import { useCptMeta } from '../content/useCptMeta';
import { PageEditorChromeProvider } from '../editor/PageEditorChrome';
import { PageSettingsModal } from '../editor/PageSettingsModal';
import { BeekiriCodeCanvas } from '../editor/beekiricode/BeekiriCodeCanvas';
import {
  emptyBeekiriCodeDoc,
  parseBeekiriCodeDoc,
  renderBeekiriCodeHtml,
  type BeekiriCodePageDoc,
} from '../editor/beekiricode/document';
import type { PageRow } from './PagesPage';

import { SITE_URL as LIVE_SITE } from '../config';

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

function toSlug(v: string) {
  return v
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 180);
}

/** Prefer beekiricode; fall back to legacy instatic key. */
function docFromPage(row: PageRow): BeekiriCodePageDoc {
  return parseBeekiriCodeDoc(row.beekiricode ?? row.instatic);
}

type SavedSnapshot = {
  title: string;
  slug: string;
  excerpt: string;
  featuredImageId: string | null;
  status: string;
  beekiricodeJson: string;
};

function snapshotFrom(
  title: string,
  slug: string,
  excerpt: string,
  featuredImageId: string | null,
  status: string,
  doc: BeekiriCodePageDoc,
): SavedSnapshot {
  return {
    title,
    slug,
    excerpt,
    featuredImageId,
    status,
    beekiricodeJson: JSON.stringify(doc),
  };
}

function ContentEditorPage({ kind, labels }: { kind: ContentKind; labels?: CptLabels }) {
  const cfg = contentKindConfig(kind, labels);
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const auth = useAuth();
  const canEdit = auth.user?.capabilities.includes(cfg.editCap) ?? false;
  const canPublish = auth.user?.capabilities.includes(cfg.publishCap) ?? false;
  const canDelete = auth.user?.capabilities.includes(cfg.deleteCap) ?? false;

  const [page, setPage] = useState<PageRow | null>(null);
  const [title, setTitle] = useState('');
  const [slug, setSlug] = useState('');
  const [slugEditing, setSlugEditing] = useState(false);
  const [slugTouched, setSlugTouched] = useState(false);
  const [status, setStatus] = useState<'auto-draft' | 'draft' | 'publish'>('draft');
  const [excerpt, setExcerpt] = useState('');
  const [featuredImageId, setFeaturedImageId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [busyAction, setBusyAction] = useState<'publish' | 'draft' | 'preview' | null>(
    null,
  );
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [beekiricodeData, setBeekiricodeData] = useState<BeekiriCodePageDoc>(() =>
    emptyBeekiriCodeDoc(),
  );
  const [canvasKey, setCanvasKey] = useState(0);
  const beekiricodeRef = useRef<BeekiriCodePageDoc>(emptyBeekiriCodeDoc());
  const savedRef = useRef<SavedSnapshot | null>(null);

  const applySaved = useCallback((row: PageRow, doc: BeekiriCodePageDoc) => {
    const editorStatus = row.status === 'auto-draft' || row.status === 'trash' ? 'draft' : row.status;
    setPage(row);
    setTitle(row.title);
    setSlug(row.slug);
    setStatus(editorStatus);
    setExcerpt(row.excerpt);
    setFeaturedImageId(row.featuredImageId ?? null);
    beekiricodeRef.current = doc;
    setBeekiricodeData(doc);
    savedRef.current = snapshotFrom(
      row.title,
      row.slug,
      row.excerpt,
      row.featuredImageId ?? null,
      editorStatus,
      doc,
    );
  }, []);

  const load = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setError(null);
    try {
      const row = await api<PageRow>(`${cfg.apiBase}/${id}`);
      if (row.status === 'trash') {
        navigate(cfg.listPath, {
          replace: true,
          state: { notice: `“${row.title || '(no title)'}” is in the trash — restore it from the list first.` },
        });
        return;
      }
      applySaved(row, docFromPage(row));
      setSlugTouched(!row.slug.startsWith('auto-draft-'));
    } catch (e) {
      setError(formatError(e));
      setPage(null);
    } finally {
      setLoading(false);
    }
  }, [id, applySaved, cfg.apiBase, cfg.listPath, navigate]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (!fullscreen && !settingsOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      if (settingsOpen) setSettingsOpen(false);
      else if (fullscreen) setFullscreen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [fullscreen, settingsOpen]);

  const onTitleChange = (value: string) => {
    setTitle(value);
    if (!slugTouched || slug.startsWith('auto-draft-')) {
      const next = toSlug(value);
      if (next) setSlug(next);
    }
  };

  const onBeekiriCodeChange = useCallback((data: BeekiriCodePageDoc) => {
    beekiricodeRef.current = data;
    setBeekiricodeData(data);
  }, []);

  const isDirty = useMemo(() => {
    const saved = savedRef.current;
    if (!saved) return false;
    return (
      title !== saved.title ||
      slug !== saved.slug ||
      excerpt !== saved.excerpt ||
      featuredImageId !== saved.featuredImageId ||
      status !== saved.status ||
      JSON.stringify(beekiricodeData) !== saved.beekiricodeJson
    );
  }, [title, slug, excerpt, featuredImageId, status, beekiricodeData]);

  const save = async (nextStatus?: 'draft' | 'publish') => {
    if (!id || !canEdit || busy) return;
    const resolvedStatus = nextStatus ?? (status === 'publish' ? 'publish' : 'draft');
    if (resolvedStatus === 'publish' && !canPublish) {
      setError(`You do not have permission to publish ${cfg.labelPlural.toLowerCase()}.`);
      return;
    }
    setBusy(true);
    setBusyAction(resolvedStatus === 'publish' ? 'publish' : 'draft');
    setError(null);
    setNotice(null);
    try {
      const updated = await api<PageRow>(`${cfg.apiBase}/${id}`, {
        method: 'PATCH',
        json: {
          title,
          slug: slug || toSlug(title) || undefined,
          status: resolvedStatus,
          excerpt,
          featuredImageId: featuredImageId ?? '',
          beekiricode: beekiricodeRef.current,
          content: renderBeekiriCodeHtml(beekiricodeRef.current),
        },
      });
      applySaved(updated, docFromPage(updated));
      setSlugTouched(true);
      setSlugEditing(false);
      setNotice(
        resolvedStatus === 'publish'
          ? `${cfg.label} published.`
          : `${cfg.label} saved as draft.`,
      );
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
      setBusyAction(null);
    }
  };

  const previewChanges = async () => {
    if (!id || !canEdit || busy || !isDirty) return;
    setBusy(true);
    setBusyAction('preview');
    setError(null);
    setNotice(null);
    try {
      const result = await api<Record<string, unknown>>(`${cfg.apiBase}/${id}/preview`, {
        method: 'POST',
        json: {
          title,
          slug: slug || toSlug(title) || undefined,
          excerpt,
          beekiricode: beekiricodeRef.current,
        },
      });

      const savedRow = (result[cfg.itemKey] ?? result.page ?? result.post ?? result.item) as
        | PageRow
        | undefined;
      const previewPath = typeof result.previewPath === 'string' ? result.previewPath : '';
      if (savedRow) {
        if (savedRow.status !== 'publish') {
          applySaved(savedRow, docFromPage(savedRow));
          setSlugTouched(true);
          setSlugEditing(false);
        } else {
          setPage(savedRow);
        }
      }

      if (previewPath) {
        const href = `${LIVE_SITE.replace(/\/$/, '')}${previewPath}`;
        window.open(href, '_blank', 'noopener,noreferrer');
      }
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
      setBusyAction(null);
    }
  };

  const onDelete = async () => {
    if (!id || !canDelete || !page) return;
    const ok = await confirmDialog({
      title: `Delete ${cfg.labelLower}`,
      message: `Delete this ${cfg.labelLower} permanently?`,
      confirmLabel: 'Delete',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    setBusyAction(null);
    try {
      await api(`${cfg.apiBase}/${id}`, { method: 'DELETE' });
      navigate(cfg.listPath);
    } catch (e) {
      setError(formatError(e));
      setBusy(false);
      setBusyAction(null);
    }
  };

  if (!canEdit) {
    return (
      <div className="wrap wrap--wide">
        <div className="beekiri-notice is-info">
          <p>
            You need the {cfg.editCap} capability to edit {cfg.labelPlural.toLowerCase()}.
          </p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="wrap wrap--wide wrap--page-editor">
        <p className="bk-muted">Loading {cfg.labelLower}…</p>
      </div>
    );
  }

  if (!page) {
    return (
      <div className="wrap wrap--wide wrap--page-editor">
        <div className="beekiri-notice is-error" role="alert">
          <p>{error || `${cfg.label} not found.`}</p>
        </div>
        <p>
          <Link to={cfg.listPath}>← Back to {cfg.labelPlural}</Link>
        </p>
      </div>
    );
  }

  const permalinkBase = LIVE_SITE.replace(/\/$/, '');
  const isPublished = page.status === 'publish';
  const publicPath = page.path || `${cfg.pathPrefix}${page.slug}`.replace(/\/{2,}/g, '/');
  const viewHref = isPublished ? `${permalinkBase}${publicPath}` : null;
  const isPublishing = busy && busyAction === 'publish';

  const chrome = {
    title,
    onTitleChange,
    slug,
    slugEditing,
    setSlugEditing,
    onSlugChange: (value: string) => {
      setSlugTouched(true);
      setSlug(toSlug(value) || value);
    },
    commitSlug: () => {
      setSlugTouched(true);
      setSlugEditing(false);
    },
    cancelSlug: () => {
      setSlug(page.slug);
      setSlugEditing(false);
    },
    permalinkBase,
    publicPath,
    pageStatus: page.status === 'publish' || page.status === 'draft' || page.status === 'auto-draft'
      ? page.status
      : 'draft',
    visibility: status,
    setVisibility: setStatus,
    excerpt,
    setExcerpt,
    featuredImageId,
    setFeaturedImageId,
    updatedAt: page.updatedAt,
    publishedAt: page.publishedAt,
    createdAt: page.createdAt,
    authorName: page.authorName ?? null,
    updatedByName: page.updatedByName ?? page.authorName ?? null,
    revisionCount: page.revisionCount ?? 0,
    parentId: page.parentId ?? null,
    pageId: page.id,
    apiBase: cfg.apiBase,
    listPath: cfg.listPath,
    singularLabel: cfg.labelLower,
    pluralLabel: cfg.labelPlural,
    beekiricanvaData: emptyBeekiricanvaData,
    beekiricodeData,
    isPublished,
    busy,
    canPublish,
    canDelete,
    viewHref,
    isDirty,
    fullscreen,
    toggleFullscreen: () => setFullscreen((v) => !v),
    settingsOpen,
    openSettings: () => setSettingsOpen(true),
    closeSettings: () => setSettingsOpen(false),
    previewChanges: () => void previewChanges(),
    saveDraft: () => void save('draft'),
    publish: () => void save('publish'),
    update: () => void save(status === 'publish' ? 'publish' : 'draft'),
    switchToDraft: () => void save('draft'),
    onDelete: () => void onDelete(),
    applyRestoredPage: (row: PageRow) => {
      applySaved(row, docFromPage(row));
      setSlugTouched(true);
      setSlugEditing(false);
      setCanvasKey((k) => k + 1);
      setNotice('Revision restored.');
    },
  };

  return (
    <div className="wrap wrap--wide wrap--page-editor">
      <PageEditorChromeProvider value={chrome}>
        <div className="bk-page-editor is-fullscreen">
          {error ? (
            <div className="beekiri-notice is-error" role="alert">
              <p>{error}</p>
            </div>
          ) : null}
          {notice ? (
            <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
          ) : null}

          <div className="bk-page-editor__main bk-page-editor__main--full bk-page-editor__main--beekiricode">
            <BeekiriCodeCanvas
              key={`${page.id}-${canvasKey}-beekiricode`}
              pageId={page.id}
              title={title || 'Untitled'}
              slug={slug}
              publicPath={publicPath}
              permalinkBase={permalinkBase}
              isPublished={isPublished}
              doc={beekiricodeData}
              onChange={onBeekiriCodeChange}
              busy={busy}
              isPublishing={isPublishing}
              canPublish={canPublish}
              isDirty={isDirty}
              viewHref={viewHref}
              onSaveDraft={() => void save('draft')}
              onPublish={() => void save('publish')}
              onOpenSettings={() => setSettingsOpen(true)}
              onPreview={() => void previewChanges()}
            />
            <PageSettingsModal />
          </div>
        </div>
      </PageEditorChromeProvider>
    </div>
  );
}

function ContentNewRedirect({ kind, labels }: { kind: ContentKind; labels?: CptLabels }) {
  const cfg = contentKindConfig(kind, labels);
  const navigate = useNavigate();
  const auth = useAuth();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (!auth.user?.capabilities.includes(cfg.editCap)) {
          setError(
            `You need the ${cfg.editCap} capability to create ${cfg.labelPlural.toLowerCase()}.`,
          );
          return;
        }
        const created = await api<PageRow>(cfg.apiBase, {
          method: 'POST',
          json: { title: 'Auto Draft', status: 'auto-draft' },
        });
        if (!cancelled) navigate(`${cfg.listPath}/${created.id}`, { replace: true });
      } catch (e) {
        if (!cancelled) setError(formatError(e));
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [auth.user, navigate, cfg.apiBase, cfg.editCap, cfg.labelPlural, cfg.listPath]);

  if (error) {
    return (
      <div className="wrap wrap--wide">
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
        <p>
          <Link to={cfg.listPath}>← Back to {cfg.labelPlural}</Link>
        </p>
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide">
      <p className="bk-muted">Creating {cfg.labelLower}…</p>
    </div>
  );
}

export function PageEditorPage() {
  return <ContentEditorPage kind="page" />;
}

export function PageNewRedirect() {
  return <ContentNewRedirect kind="page" />;
}

export function PostEditorPage() {
  return <ContentEditorPage kind="post" />;
}

export function PostNewRedirect() {
  return <ContentNewRedirect kind="post" />;
}

export function CptEditorPage() {
  const { type } = useParams<{ type: string }>();
  const slug = (type || '').trim().toLowerCase();
  const resolved = useCptMeta(slug);
  if (!slug) return null;
  if (resolved.status === 'loading') {
    return (
      <div className="wrap wrap--wide">
        <p className="bk-muted">Loading…</p>
      </div>
    );
  }
  if (resolved.status === 'missing') {
    return <Navigate to={`/admin/content/${slug}`} replace />;
  }
  return <ContentEditorPage kind={slug} labels={resolved.labels} />;
}

export function CptNewRedirect() {
  const { type } = useParams<{ type: string }>();
  const slug = (type || '').trim().toLowerCase();
  const resolved = useCptMeta(slug);
  if (!slug) return null;
  if (resolved.status === 'loading') {
    return (
      <div className="wrap wrap--wide">
        <p className="bk-muted">Loading…</p>
      </div>
    );
  }
  if (resolved.status === 'missing') {
    return <Navigate to={`/admin/content/${slug}`} replace />;
  }
  return <ContentNewRedirect kind={slug} labels={resolved.labels} />;
}
