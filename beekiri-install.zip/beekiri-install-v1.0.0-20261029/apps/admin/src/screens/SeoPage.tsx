import { useEffect, useMemo, useState } from 'react';
import {
  ArrowSquareOut,
  CaretRight,
  DownloadSimple,
  Faders,
  FileText,
  Globe,
  Info,
  LinkSimple,
  MagnifyingGlass,
  Warning,
  WarningCircle,
  type Icon,
} from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { PageHeader } from '../components/PageHeader';
import { BacklinksPanel } from './BacklinksPanel';
import { DomainOverviewPanel } from './DomainOverviewPanel';
import { KeywordResearchPanel } from './KeywordResearchPanel';
import './seo-page.css';

type IssueSeverity = 'critical' | 'warning' | 'info';

type IssueGroup = {
  severity: IssueSeverity;
  ruleId: string;
  title: string;
  message: string;
  pageCount: number;
  pages: string[];
};

type PageRow = {
  url: string;
  path: string;
  status: number;
  title: string;
  h1: number;
  words: number;
  imagesWithAlt: number;
  imagesTotal: number;
  speedMs: number;
  redirectTo?: string;
};

type AuditResult = {
  version: number;
  url: string;
  path: string;
  overallScore: number;
  crawledPages: number;
  timestamp: string;
  summary: {
    pass: number;
    warn: number;
    fail: number;
    notMeasured: number;
    issues: number;
    critical: number;
    warning: number;
    info: number;
  };
  issueGroups: IssueGroup[];
  pages: PageRow[];
  cached: boolean;
};

type SeoSection = 'site-audit' | 'keywords' | 'domain' | 'backlinks';

type NavItem = { id: SeoSection; label: string; icon: Icon };

const SEO_NAV: NavItem[] = [
  { id: 'site-audit', label: 'Site Audit', icon: FileText },
  { id: 'keywords', label: 'Keyword Research', icon: MagnifyingGlass },
  { id: 'domain', label: 'Domain Overview', icon: Globe },
  { id: 'backlinks', label: 'Backlinks', icon: LinkSimple },
];

type AuditTab = 'issues' | 'pages';

const ISSUES_PER_PAGE = 25;

function scoreTone(score: number): 'ok' | 'warn' | 'fail' {
  if (score >= 80) return 'ok';
  if (score >= 50) return 'warn';
  return 'fail';
}

function scoreVerdict(score: number): string {
  if (score >= 90) return 'Excellent';
  if (score >= 80) return 'Good';
  if (score >= 50) return 'Needs work';
  return 'Critical';
}

function statusTone(status: number): string {
  if (status >= 200 && status < 300) return 'is-ok';
  if (status >= 300 && status < 400) return 'is-warn';
  if (status >= 400 || status === 0) return 'is-fail';
  return '';
}

function ScoreRing({ score }: { score: number }) {
  const tone = scoreTone(score);
  const size = 148;
  const r = 62;
  const c = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(100, score));
  const offset = c - (clamped / 100) * c;
  return (
    <div className={`bk-seo__ring is-${tone}`} aria-label={`SEO score ${Math.round(score)}`}>
      <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size} aria-hidden>
        <circle className="bk-seo__ring-track" cx={size / 2} cy={size / 2} r={r} />
        <circle
          className="bk-seo__ring-progress"
          cx={size / 2}
          cy={size / 2}
          r={r}
          strokeDasharray={c}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="bk-seo__ring-label">
        <strong>{Math.round(score)}</strong>
        <span>/ 100</span>
      </div>
    </div>
  );
}

function exportCsv(filename: string, headers: string[], rows: string[][]) {
  const esc = (v: string) => `"${v.replace(/"/g, '""')}"`;
  const body = [headers, ...rows].map((r) => r.map(esc).join(',')).join('\n');
  const blob = new Blob([body], { type: 'text/csv;charset=utf-8' });
  const href = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = href;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(href);
}

const SEVERITY_META: Record<
  IssueSeverity,
  { label: string; Icon: Icon }
> = {
  critical: { label: 'Critical', Icon: WarningCircle },
  warning: { label: 'Warning', Icon: Warning },
  info: { label: 'Info', Icon: Info },
};

export function SeoPage() {
  const [section, setSection] = useState<SeoSection>('site-audit');
  const [busy, setBusy] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AuditResult | null>(null);
  const [tab, setTab] = useState<AuditTab>('issues');
  const [expandedIssue, setExpandedIssue] = useState<string | null>(null);
  const [issuePage, setIssuePage] = useState(1);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [issueSeverity, setIssueSeverity] = useState<'all' | IssueSeverity>('all');
  const [pageStatus, setPageStatus] = useState<'all' | '2xx' | '3xx' | '4xx'>('all');

  async function loadReport(refresh: boolean) {
    if (refresh) setRefreshing(true);
    else setBusy(true);
    setError(null);
    try {
      const q = refresh ? '?refresh=1' : '';
      const data = await api<AuditResult>(`/api/bee-seo/report${q}`);
      setResult(data);
      setTab('issues');
      setExpandedIssue(null);
      setIssuePage(1);
      setIssueSeverity('all');
      setPageStatus('all');
    } catch (err) {
      setError(err instanceof ApiError || err instanceof Error ? err.message : 'Could not load SEO.');
    } finally {
      setBusy(false);
      setRefreshing(false);
    }
  }

  useEffect(() => {
    void loadReport(false);
  }, []);

  const allPages = result?.pages ?? [];

  const pages = useMemo(() => {
    if (pageStatus === 'all') return allPages;
    if (pageStatus === '2xx') return allPages.filter((p) => p.status >= 200 && p.status < 300);
    if (pageStatus === '3xx') return allPages.filter((p) => p.status >= 300 && p.status < 400);
    return allPages.filter((p) => p.status >= 400 || p.status === 0);
  }, [allPages, pageStatus]);

  const flatIssues = useMemo(() => {
    if (!result) return [] as IssueGroup[];
    const order: IssueSeverity[] = ['critical', 'warning', 'info'];
    const all = order.flatMap((severity) => result.issueGroups.filter((i) => i.severity === severity));
    if (issueSeverity === 'all') return all;
    return all.filter((i) => i.severity === issueSeverity);
  }, [result, issueSeverity]);

  const severityTotals = useMemo(() => {
    const totals: Record<IssueSeverity, number> = { critical: 0, warning: 0, info: 0 };
    if (!result) return totals;
    for (const item of result.issueGroups) totals[item.severity] += item.pageCount;
    return totals;
  }, [result]);

  const issueTotalPages = Math.max(1, Math.ceil(flatIssues.length / ISSUES_PER_PAGE));
  const safeIssuePage = Math.min(issuePage, issueTotalPages);
  const pagedIssues = useMemo(() => {
    const start = (safeIssuePage - 1) * ISSUES_PER_PAGE;
    return flatIssues.slice(start, start + ISSUES_PER_PAGE);
  }, [flatIssues, safeIssuePage]);
  const issueFrom = flatIssues.length === 0 ? 0 : (safeIssuePage - 1) * ISSUES_PER_PAGE + 1;
  const issueTo = Math.min(safeIssuePage * ISSUES_PER_PAGE, flatIssues.length);

  useEffect(() => {
    if (issuePage !== safeIssuePage) setIssuePage(safeIssuePage);
  }, [issuePage, safeIssuePage]);

  useEffect(() => {
    setIssuePage(1);
  }, [issueSeverity]);

  const isAudit = section === 'site-audit';
  const filterActive = tab === 'issues' ? issueSeverity !== 'all' : pageStatus !== 'all';

  function onExport() {
    if (!result) return;
    if (tab === 'issues') {
      exportCsv(
        'beekiri-seo-issues.csv',
        ['Severity', 'Issue', 'Pages', 'Message'],
        flatIssues.map((i) => [i.severity, i.title, String(i.pageCount), i.message]),
      );
      return;
    }
    exportCsv(
      'beekiri-seo-pages.csv',
      ['URL', 'Status', 'Title', 'H1', 'Words', 'Images', 'Speed'],
      pages.map((p) => [
        p.path,
        String(p.status || '-'),
        p.title,
        String(p.h1),
        String(p.words),
        `${p.imagesWithAlt}/${p.imagesTotal}`,
        `${p.speedMs}ms`,
      ]),
    );
  }

  return (
    <div className="bk-seo">
      <PageHeader
        title="SEO"
        actions={
          isAudit ? (
            <div className="bk-seo__tools">
              {result ? (
                <span className="bk-seo__checked">
                  Checked {new Date(result.timestamp).toLocaleString()}
                  {result.cached ? ' · cached' : ''}
                </span>
              ) : null}
              <button
                type="button"
                className="button"
                disabled={busy || refreshing}
                onClick={() => void loadReport(true)}
              >
                {refreshing ? 'Refreshing…' : 'Refresh'}
              </button>
            </div>
          ) : null
        }
      />

      <div className="bk-seo__layout">
        <nav className="bk-seo-nav" aria-label="SEO tools">
          <ul className="bk-seo-nav__list">
            {SEO_NAV.map((item) => {
              const IconCmp = item.icon;
              const active = section === item.id;
              return (
                <li key={item.id}>
                  <button
                    type="button"
                    className={`bk-seo-nav__item${active ? ' is-active' : ''}`}
                    aria-current={active ? 'page' : undefined}
                    onClick={() => setSection(item.id)}
                  >
                    <IconCmp size={18} weight="regular" className="bk-menu-icon" aria-hidden />
                    <span>{item.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="bk-seo__main">
          {section === 'keywords' ? <KeywordResearchPanel /> : null}
          {section === 'domain' ? <DomainOverviewPanel /> : null}
          {section === 'backlinks' ? <BacklinksPanel /> : null}

          {isAudit && error ? <p className="bk-seo__banner is-error">{error}</p> : null}

          {isAudit && busy && !result ? (
            <div className="bk-seo__loading">
              <div className="bk-seo__spinner" aria-hidden />
              <p>Crawling your theme and auditing pages…</p>
            </div>
          ) : null}

          {isAudit && result ? (
            <>
              <section className={`bk-seo__hero is-${scoreTone(result.overallScore)}`}>
                <div className="bk-seo__hero-main">
                  <ScoreRing score={result.overallScore} />
                  <div className="bk-seo__hero-copy">
                    <div className="bk-seo__hero-top">
                      <h2 className="bk-seo__hero-title">Site SEO health</h2>
                      <span className={`bk-seo__verdict is-${scoreTone(result.overallScore)}`}>
                        {scoreVerdict(result.overallScore)}
                      </span>
                    </div>
                    <p className="bk-seo__hero-desc">
                      Theme crawl · {result.pages.length} pages · {result.summary.issues} issues
                    </p>
                    <a className="bk-seo__hero-url" href={result.url} target="_blank" rel="noreferrer">
                      {result.url.replace(/^https?:\/\//, '')}
                    </a>
                  </div>
                </div>
                <div className="bk-seo__kpis" role="group" aria-label="Score breakdown">
                  <button type="button" className="bk-seo__kpi is-fail" onClick={() => setTab('issues')}>
                    <strong>{result.summary.critical}</strong>
                    <span>Critical</span>
                  </button>
                  <button type="button" className="bk-seo__kpi is-warn" onClick={() => setTab('issues')}>
                    <strong>{result.summary.warning}</strong>
                    <span>Warnings</span>
                  </button>
                  <button type="button" className="bk-seo__kpi" onClick={() => setTab('issues')}>
                    <strong>{result.summary.info}</strong>
                    <span>Info</span>
                  </button>
                  <button type="button" className="bk-seo__kpi is-ok" onClick={() => setTab('pages')}>
                    <strong>{result.pages.length}</strong>
                    <span>Pages</span>
                  </button>
                </div>
              </section>

              <div className="bk-seo-board">
                <div className="bk-seo-board__top">
                  <div className="bk-seo-board__tabs" role="tablist" aria-label="Site audit views">
                    <button
                      type="button"
                      role="tab"
                      aria-selected={tab === 'issues'}
                      className={`bk-seo-board__tab${tab === 'issues' ? ' is-active' : ''}`}
                      onClick={() => setTab('issues')}
                    >
                      Issues ({result.summary.issues})
                    </button>
                    <button
                      type="button"
                      role="tab"
                      aria-selected={tab === 'pages'}
                      className={`bk-seo-board__tab${tab === 'pages' ? ' is-active' : ''}`}
                      onClick={() => setTab('pages')}
                    >
                      Pages ({result.pages.length})
                    </button>
                  </div>
                  <button type="button" className="button bk-seo-board__export" onClick={onExport}>
                    <DownloadSimple size={16} weight="regular" aria-hidden />
                    Export
                  </button>
                </div>

                <div className="bk-seo-board__toolbar">
                  <button
                    type="button"
                    className={`button bk-seo-board__filters-btn${filtersOpen || filterActive ? ' button-primary' : ''}`}
                    onClick={() => setFiltersOpen((v) => !v)}
                  >
                    <Faders size={16} weight="regular" aria-hidden />
                    Filters
                    {filterActive ? <span className="bk-seo-board__filter-dot" aria-hidden /> : null}
                  </button>
                  <span className="bk-seo-board__count">
                    {tab === 'issues'
                      ? flatIssues.length === 0
                        ? '0 of 0'
                        : `${issueFrom}–${issueTo} of ${flatIssues.length}`
                      : `${pages.length} of ${allPages.length}`}
                  </span>
                </div>

                {filtersOpen ? (
                  <div className="bk-seo-board__filters" role="group" aria-label="Filters">
                    {tab === 'issues'
                      ? (
                          [
                            ['all', 'All'],
                            ['critical', 'Critical'],
                            ['warning', 'Warning'],
                            ['info', 'Info'],
                          ] as const
                        ).map(([id, label]) => (
                          <button
                            key={id}
                            type="button"
                            className={`button${issueSeverity === id ? ' button-primary' : ''}`}
                            onClick={() => setIssueSeverity(id)}
                          >
                            {label}
                          </button>
                        ))
                      : (
                          [
                            ['all', 'All'],
                            ['2xx', '2xx'],
                            ['3xx', '3xx'],
                            ['4xx', '4xx / errors'],
                          ] as const
                        ).map(([id, label]) => (
                          <button
                            key={id}
                            type="button"
                            className={`button${pageStatus === id ? ' button-primary' : ''}`}
                            onClick={() => setPageStatus(id)}
                          >
                            {label}
                          </button>
                        ))}
                  </div>
                ) : null}

                {tab === 'issues' ? (
                  <div className="bk-seo-issues">
                    {flatIssues.length === 0 ? (
                      <p className="bk-seo__empty-block">No issues found — looking good.</p>
                    ) : (
                      <>
                        <ul className="bk-seo-issues__list">
                          {pagedIssues.map((item, index) => {
                            const key = `${item.severity}-${item.ruleId}-${item.title}`;
                            const open = expandedIssue === key;
                            const prev = index > 0 ? pagedIssues[index - 1] : null;
                            const showBadge = !prev || prev.severity !== item.severity;
                            const meta = SEVERITY_META[item.severity];
                            const SevIcon = meta.Icon;
                            return (
                              <li key={key}>
                                {showBadge ? (
                                  <span className={`bk-seo-issues__badge is-${item.severity}`}>
                                    <SevIcon size={14} weight="fill" aria-hidden />
                                    {meta.label} {severityTotals[item.severity]}
                                  </span>
                                ) : null}
                                <button
                                  type="button"
                                  className={`bk-seo-issues__row${open ? ' is-open' : ''}`}
                                  onClick={() => setExpandedIssue(open ? null : key)}
                                >
                                  <span className="bk-seo-issues__title">{item.title}</span>
                                  <span className="bk-seo-issues__meta">
                                    {item.pageCount} {item.pageCount === 1 ? 'page' : 'pages'}
                                    <CaretRight size={16} weight="bold" aria-hidden />
                                  </span>
                                </button>
                                {open ? (
                                  <div className="bk-seo-issues__detail">
                                    <p>{item.message}</p>
                                    <ul>
                                      {item.pages.slice(0, 12).map((p) => (
                                        <li key={p}>
                                          <a href={p} target="_blank" rel="noreferrer">
                                            {p.replace(/^https?:\/\//, '')}
                                          </a>
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                ) : null}
                              </li>
                            );
                          })}
                        </ul>

                        {issueTotalPages > 1 ? (
                          <div className="bk-seo-issues__pager bk-table__pager">
                            <span className="bk-table__page-label">
                              Page {safeIssuePage} of {issueTotalPages}
                            </span>
                            <div className="bk-table__pages" role="navigation" aria-label="Issues pagination">
                              <button
                                type="button"
                                className="button"
                                disabled={safeIssuePage <= 1}
                                onClick={() => setIssuePage(1)}
                                aria-label="First page"
                              >
                                «
                              </button>
                              <button
                                type="button"
                                className="button"
                                disabled={safeIssuePage <= 1}
                                onClick={() => setIssuePage((p) => Math.max(1, p - 1))}
                                aria-label="Previous page"
                              >
                                ‹
                              </button>
                              <button
                                type="button"
                                className="button"
                                disabled={safeIssuePage >= issueTotalPages}
                                onClick={() => setIssuePage((p) => Math.min(issueTotalPages, p + 1))}
                                aria-label="Next page"
                              >
                                ›
                              </button>
                              <button
                                type="button"
                                className="button"
                                disabled={safeIssuePage >= issueTotalPages}
                                onClick={() => setIssuePage(issueTotalPages)}
                                aria-label="Last page"
                              >
                                »
                              </button>
                            </div>
                          </div>
                        ) : null}
                      </>
                    )}
                  </div>
                ) : (
                  <div className="bk-seo-pages">
                    <table className="bk-seo-pages__table">
                      <thead>
                        <tr>
                          <th>URL</th>
                          <th>Status</th>
                          <th>Title</th>
                          <th>H1</th>
                          <th>Words</th>
                          <th>Images</th>
                          <th>Speed</th>
                        </tr>
                      </thead>
                      <tbody>
                        {pages.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="bk-seo__empty">
                              No pages for this filter.
                            </td>
                          </tr>
                        ) : (
                          pages.map((p) => (
                            <tr key={p.url}>
                              <td>
                                <a className="bk-seo-pages__url" href={p.url} target="_blank" rel="noreferrer">
                                  {p.path || '/'}
                                  <ArrowSquareOut size={14} weight="regular" aria-hidden />
                                </a>
                              </td>
                              <td>
                                <span className={`bk-seo-pages__status ${statusTone(p.status)}`}>
                                  {p.status || '—'}
                                </span>
                              </td>
                              <td className="bk-seo-pages__title">{p.title}</td>
                              <td>{p.h1}</td>
                              <td>{p.words || '—'}</td>
                              <td
                                className={
                                  p.imagesTotal > 0 && p.imagesWithAlt < p.imagesTotal
                                    ? 'is-accent'
                                    : undefined
                                }
                              >
                                {p.imagesTotal ? `${p.imagesWithAlt}/${p.imagesTotal}` : '—'}
                              </td>
                              <td>{p.speedMs}ms</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
}
