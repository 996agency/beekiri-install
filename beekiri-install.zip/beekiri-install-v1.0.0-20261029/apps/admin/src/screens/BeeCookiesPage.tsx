import { useState } from 'react';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import { BeeCookiesPanel } from './BeeCookiesPanel';

export function BeeCookiesPage() {
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  return (
    <div className="bk-stack">
      <PageHeader title="BeeCookies" />
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}
      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      <BeeCookiesPanel
        busy={busy}
        onBusy={setBusy}
        onNotice={setNotice}
        onError={setError}
      />
    </div>
  );
}
