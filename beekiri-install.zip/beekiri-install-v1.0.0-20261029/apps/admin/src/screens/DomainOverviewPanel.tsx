import { useEffect, useMemo, useState } from 'react';
import { CaretLeft, CaretRight, DownloadSimple, Faders, FolderSimple } from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';

type OverviewRow = {
  keyword: string;
  rank: number | null;
  volume: number | null;
  traffic: number | null;
  cpc: number | null;
  url: string;
  score: number | null;
};

type OverviewResult = {
  domain: string;
  metrics: {
    organicTraffic: number | null;
    organicKeywords: number | null;
  };
  topKeywords: OverviewRow[];
  topPages: OverviewRow[];
};

type Tab = 'keywords' | 'pages';

const PAGE_SIZES = [25, 50, 100];

function dash(n: number | null | undefined): string {
  if (n == null) return '—';
  return Intl.NumberFormat('en-US').format(n);
}

function exportCsv(filename: string, headers: string[], rows: string[][]) {
  const esc = (v: string) => `"${v.replace(/"/g, '""')}"`;
  const body = [headers, ...rows].map((r) => r.map(esc).join(',')).join('\n');
  const blob = new Blob([body], { type: 'text/csv;charset=utf-8' });
  const href = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = href;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(href);
}

export function DomainOverviewPanel() {
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<OverviewResult | null>(null);
  const [tab, setTab] = useState<Tab>('keywords');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  useEffect(() => {
    let cancelled = false;
    setBusy(true);
    setError(null);
    api<OverviewResult>('/api/bee-seo/overview')
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch((err) => {
        if (!cancelled) {
          setError(err instanceof ApiError || err instanceof Error ? err.message : 'Could not load overview.');
        }
      })
      .finally(() => {
        if (!cancelled) setBusy(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const source = tab === 'keywords' ? data?.topKeywords ?? [] : data?.topPages ?? [];

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return source;
    return source.filter(
      (r) => r.keyword.toLowerCase().includes(q) || r.url.toLowerCase().includes(q),
    );
  }, [source, query]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const paged = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, safePage, pageSize]);
  const from = filtered.length === 0 ? 0 : (safePage - 1) * pageSize + 1;
  const to = Math.min(safePage * pageSize, filtered.length);

  useEffect(() => {
    setPage(1);
    setSelected(new Set());
  }, [tab, query, pageSize]);

  useEffect(() => {
    if (page !== safePage) setPage(safePage);
  }, [page, safePage]);

  function rowKey(r: OverviewRow, i: number) {
    return `${r.url}::${r.keyword}::${i}`;
  }

  function toggleAll() {
    if (!paged.length) return;
    if (selected.size === paged.length) setSelected(new Set());
    else setSelected(new Set(paged.map((r, i) => rowKey(r, i))));
  }

  function onExport() {
    exportCsv(
      tab === 'keywords' ? 'beekiri-domain-keywords.csv' : 'beekiri-domain-pages.csv',
      ['Keyword', 'Rank', 'Volume', 'Traffic', 'CPC', 'URL', 'Score'],
      filtered.map((r) => [
        r.keyword,
        r.rank == null ? '' : String(r.rank),
        r.volume == null ? '' : String(r.volume),
        r.traffic == null ? '' : String(r.traffic),
        r.cpc == null ? '' : String(r.cpc),
        r.url,
        r.score == null ? '' : String(r.score),
      ]),
    );
  }

  if (busy && !data) {
    return (
      <div className="bk-seo__loading">
        <div className="bk-seo__spinner" aria-hidden />
        <p>Loading domain overview…</p>
      </div>
    );
  }

  if (error && !data) {
    return <p className="bk-seo__banner is-error">{error}</p>;
  }

  if (!data) return null;

  const emptyLabel =
    tab === 'keywords' ? 'No keywords match this search.' : 'No pages match this search.';
  const countLabel =
    tab === 'keywords'
      ? `${filtered.length} keywords · Select keywords to save`
      : `${filtered.length} pages · Select rows to export`;

  return (
    <div className="bk-dom">
      <header className="bk-dom__head">
        <h2 className="bk-dom__domain">{data.domain}</h2>
        <span className="bk-dom__badge">Subdomains</span>
      </header>

      <div className="bk-dom__metrics">
        <table>
          <thead>
            <tr>
              <th>Metric</th>
              <th>Value</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Estimated organic traffic</td>
              <td>{dash(data.metrics.organicTraffic)}</td>
            </tr>
            <tr>
              <td>Organic keywords</td>
              <td>{dash(data.metrics.organicKeywords)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="bk-dom__board">
        <div className="bk-dom__tabs" role="tablist" aria-label="Domain overview views">
          <button
            type="button"
            role="tab"
            aria-selected={tab === 'keywords'}
            className={`bk-dom__tab${tab === 'keywords' ? ' is-active' : ''}`}
            onClick={() => setTab('keywords')}
          >
            Top Keywords
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={tab === 'pages'}
            className={`bk-dom__tab${tab === 'pages' ? ' is-active' : ''}`}
            onClick={() => setTab('pages')}
          >
            Top Pages
          </button>
        </div>

        <div className="bk-dom__toolbar">
          <div className="bk-dom__toolbar-left">
            <button
              type="button"
              className={`button${filtersOpen || query ? ' button-primary' : ''}`}
              onClick={() => setFiltersOpen((v) => !v)}
            >
              <Faders size={16} weight="regular" aria-hidden />
              Filters
            </button>
            <span className="bk-dom__count">{countLabel}</span>
          </div>
          <button type="button" className="button" onClick={onExport} disabled={!filtered.length}>
            <DownloadSimple size={16} weight="regular" aria-hidden />
            Export
          </button>
        </div>

        {filtersOpen ? (
          <div className="bk-dom__filters">
            <input
              type="search"
              className="bk-dom__filter-input"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={tab === 'keywords' ? 'Filter keywords…' : 'Filter pages…'}
            />
          </div>
        ) : null}

        <div className="bk-dom__table-wrap">
          <table className="bk-dom__table">
            <thead>
              <tr>
                <th className="bk-dom__check">
                  <input
                    type="checkbox"
                    checked={paged.length > 0 && selected.size === paged.length}
                    onChange={toggleAll}
                    aria-label="Select all"
                    disabled={!paged.length}
                  />
                </th>
                <th>{tab === 'keywords' ? 'Keyword' : 'Page'}</th>
                <th>Rank</th>
                <th>Volume</th>
                <th>
                  Traffic <span aria-hidden>↓</span>
                </th>
                <th>CPC</th>
                <th>URL</th>
                <th>Score</th>
              </tr>
            </thead>
            <tbody>
              {paged.length === 0 ? (
                <tr>
                  <td colSpan={8}>
                    <div className="bk-dom__empty">
                      <FolderSimple size={28} weight="regular" aria-hidden />
                      <p>{emptyLabel}</p>
                    </div>
                  </td>
                </tr>
              ) : (
                paged.map((r, i) => {
                  const key = rowKey(r, (safePage - 1) * pageSize + i);
                  return (
                    <tr key={key}>
                      <td className="bk-dom__check">
                        <input
                          type="checkbox"
                          checked={selected.has(key)}
                          onChange={() => {
                            setSelected((prev) => {
                              const next = new Set(prev);
                              if (next.has(key)) next.delete(key);
                              else next.add(key);
                              return next;
                            });
                          }}
                          aria-label={`Select ${r.keyword}`}
                        />
                      </td>
                      <td className="bk-dom__kw">{r.keyword}</td>
                      <td>{dash(r.rank)}</td>
                      <td>{dash(r.volume)}</td>
                      <td>{dash(r.traffic)}</td>
                      <td>{r.cpc == null ? '—' : `$${r.cpc.toFixed(2)}`}</td>
                      <td>
                        <span className="bk-dom__url">{r.url}</span>
                      </td>
                      <td>{dash(r.score)}</td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <div className="bk-dom__pager">
          <span>{filtered.length === 0 ? `1–${pageSize}` : `${from}–${to}`}</span>
          <div className="bk-dom__pager-right">
            <label className="bk-dom__pagesize">
              Rows per page
              <select value={pageSize} onChange={(e) => setPageSize(Number(e.target.value))}>
                {PAGE_SIZES.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </label>
            <span>Page {safePage}</span>
            <button
              type="button"
              className="button"
              disabled={safePage <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              aria-label="Previous page"
            >
              <CaretLeft size={14} weight="bold" />
            </button>
            <button
              type="button"
              className="button"
              disabled={safePage >= totalPages}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              aria-label="Next page"
            >
              <CaretRight size={14} weight="bold" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
