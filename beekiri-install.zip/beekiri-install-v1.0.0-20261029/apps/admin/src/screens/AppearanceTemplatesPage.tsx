import { PageHeader } from '../components/PageHeader';

import { SITE_URL as LIVE_SITE } from '../config';

export function AppearanceTemplatesPage() {
  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Templates"
        actions={
          <a className="button" href={LIVE_SITE} target="_blank" rel="noreferrer">
            View site
          </a>
        }
      />
      <p className="bk-muted">
        Theme templates and page layouts (hero, sections, and more) will be managed here.
      </p>
      <div className="beekiri-notice is-info">
        <p>
          Layouts are created from Backend Fields. If a theme includes layout files, open{' '}
          <strong>Field Groups</strong> and use <strong>Sync</strong> to import them.
        </p>
      </div>
    </div>
  );
}