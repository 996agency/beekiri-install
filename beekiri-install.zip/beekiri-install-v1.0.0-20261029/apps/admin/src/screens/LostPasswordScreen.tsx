import { FormEvent, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import { AuthShell } from './AuthShell';

export function LostPasswordScreen() {
  const [userLogin, setUserLogin] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const [devLink, setDevLink] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setMessage(null);
    setDevLink(null);
    try {
      const res = await api<{ message: string; devResetLink?: string }>('/api/auth/lost-password', {
        json: { userLogin },
      });
      setMessage(res.message);
      if (res.devResetLink) setDevLink(res.devResetLink);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Request failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell
      title="Reset password"
      subtitle="Enter your username or email. If an account exists, we’ll send reset instructions."
    >
      {error ? (
        <div className="bk-auth__alert" role="alert">
          {error}
        </div>
      ) : null}
      {message ? (
        <div className="bk-auth__ok" role="status">
          {message}
          {devLink ? (
            <>
              <br />
              <a href={devLink}>Open reset link (development)</a>
            </>
          ) : null}
        </div>
      ) : null}

      <form onSubmit={onSubmit}>
        <div className="bk-install__field">
          <label htmlFor="user_login">Username or email</label>
          <input
            type="text"
            id="user_login"
            required
            value={userLogin}
            onChange={(e) => setUserLogin(e.target.value)}
          />
        </div>
        <div className="bk-auth__actions">
          <button
            type="submit"
            className="bk-install__btn bk-install__btn--primary"
            disabled={busy}
          >
            {busy ? 'Sending…' : 'Send link'}
          </button>
          <Link to="/admin/login" className="bk-install__btn bk-install__btn--ghost">
            Back to sign in
          </Link>
        </div>
      </form>
    </AuthShell>
  );
}
