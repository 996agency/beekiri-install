import {
  ChangeEvent,
  DragEvent,
  FormEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { api, apiUpload, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import {
  AdminDataTable,
  hasActiveAdminFilters,
  type AdminTableColumn,
  type AdminTableFilter,
} from '../components/AdminDataTable';
import { confirmDialog } from '../components/ConfirmDialog';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';

type MediaItem = {
  id: string;
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  width: number | null;
  height: number | null;
  url: string;
  folderId: string | null;
  alt: string;
  createdAt: string;
  updatedAt?: string;
};

type MediaFolder = { id: string; name: string; slug: string; parentId: string | null };

const EMPTY_FILTERS = { name: '', folderId: '' };
import { SITE_URL as PUBLIC_SITE } from '../config';

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function absoluteUrl(path: string) {
  if (/^https?:\/\//i.test(path)) return path;
  const base = PUBLIC_SITE.replace(/\/$/, '');
  return `${base}${path.startsWith('/') ? path : `/${path}`}`;
}

export function MediaPage() {
  const auth = useAuth();
  const canUpload = auth.user?.capabilities.includes('upload_files') ?? false;
  const fileRef = useRef<HTMLInputElement>(null);

  const [items, setItems] = useState<MediaItem[]>([]);
  const [folders, setFolders] = useState<MediaFolder[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [filterValues, setFilterValues] = useState(EMPTY_FILTERS);
  const [uploadFolderId, setUploadFolderId] = useState('');
  const [dragging, setDragging] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [bulkFolderId, setBulkFolderId] = useState('');
  const [active, setActive] = useState<MediaItem | null>(null);
  const [editAlt, setEditAlt] = useState('');
  const [editFolderId, setEditFolderId] = useState('');
  const [copied, setCopied] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    const listRes = await api<{ items: MediaItem[]; folders?: MediaFolder[] }>('/api/media');
    setItems(listRes.items);
    setFolders(listRes.folders ?? []);
  }, []);

  useEffect(() => {
    setLoading(true);
    load()
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [load]);

  useEffect(() => {
    if (!active) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setActive(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [active]);

  const openItem = (item: MediaItem) => {
    setActive(item);
    setEditAlt(item.alt ?? '');
    setEditFolderId(item.folderId ?? '');
    setCopied(false);
    setError(null);
  };

  const uploadFiles = async (files: FileList | File[]) => {
    if (!canUpload) return;
    const list = Array.from(files);
    if (!list.length) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      let lastUrl = '';
      for (const file of list) {
        const form = new FormData();
        form.append('file', file);
        if (uploadFolderId) form.append('folderId', uploadFolderId);
        const res = await apiUpload<{ item: MediaItem }>('/api/media/upload', form);
        lastUrl = res.item.url;
      }
      await load();
      setNotice(
        list.length === 1
          ? `Uploaded — available at ${lastUrl}`
          : `Uploaded ${list.length} files.`,
      );
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const onPick = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.length) void uploadFiles(e.target.files);
  };

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setDragging(false);
    if (e.dataTransfer.files?.length) void uploadFiles(e.dataTransfer.files);
  };

  const remove = async (item: MediaItem) => {
    if (!canUpload) return;
    const ok = await confirmDialog({
      title: 'Delete file',
      message: `Delete “${item.originalName}”? This cannot be undone.`,
      confirmLabel: 'Delete',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    setError(null);
    try {
      await api(`/api/media/${item.id}`, { method: 'DELETE' });
      setSelected((prev) => {
        const next = new Set(prev);
        next.delete(item.id);
        return next;
      });
      if (active?.id === item.id) setActive(null);
      await load();
      setNotice('File deleted.');
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const saveActive = async (e: FormEvent) => {
    e.preventDefault();
    if (!active || !canUpload) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ item: MediaItem }>(`/api/media/${active.id}`, {
        method: 'PATCH',
        json: { alt: editAlt.trim() },
      });
      setItems((prev) => prev.map((row) => (row.id === res.item.id ? res.item : row)));
      setActive(res.item);
      setEditFolderId(res.item.folderId ?? '');
      setNotice('Media details saved.');
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const moveActive = async () => {
    if (!active || !canUpload) return;
    const current = active.folderId ?? '';
    if (editFolderId === current) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ item: MediaItem }>(`/api/media/${active.id}`, {
        method: 'PATCH',
        json: { folderId: editFolderId || null },
      });
      setItems((prev) => prev.map((row) => (row.id === res.item.id ? res.item : row)));
      setActive(res.item);
      setEditFolderId(res.item.folderId ?? '');
      const dest =
        folders.find((f) => f.id === (res.item.folderId ?? ''))?.name ?? 'No folder';
      setNotice(`Moved to ${dest}.`);
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const copyUrl = async (path: string) => {
    const url = absoluteUrl(path);
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      window.prompt('Copy URL:', url);
    }
  };

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const clearSelection = () => setSelected(new Set());

  const bulkMove = async () => {
    if (!canUpload || selected.size === 0) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ updated: number }>('/api/media/bulk-move', {
        method: 'POST',
        json: {
          ids: [...selected],
          folderId: bulkFolderId || null,
        },
      });
      await load();
      clearSelection();
      setNotice(
        `Moved ${res.updated} file${res.updated === 1 ? '' : 's'} to ${
          bulkFolderId
            ? folders.find((f) => f.id === bulkFolderId)?.name ?? 'folder'
            : 'No folder'
        }.`,
      );
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const bulkDelete = async () => {
    if (!canUpload || selected.size === 0) return;
    const count = selected.size;
    const ok = await confirmDialog({
      title: 'Delete files',
      message: `Delete ${count} selected file${count === 1 ? '' : 's'}? This cannot be undone.`,
      confirmLabel: 'Delete',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ deleted: number }>('/api/media/bulk-delete', {
        method: 'POST',
        json: { ids: [...selected] },
      });
      if (active && selected.has(active.id)) setActive(null);
      clearSelection();
      await load();
      setNotice(`Deleted ${res.deleted} file${res.deleted === 1 ? '' : 's'}.`);
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const folderName = useCallback(
    (id: string | null) => {
      if (!id) return '—';
      return folders.find((f) => f.id === id)?.name ?? id;
    },
    [folders],
  );

  const filters: AdminTableFilter[] = useMemo(
    () => [
      { key: 'name', label: 'Name', type: 'text', placeholder: 'Search filename…' },
      {
        key: 'folderId',
        label: 'Folder',
        type: 'select',
        allLabel: 'All folders',
        options: folders.map((f) => ({ value: f.id, label: f.name })),
      },
    ],
    [folders],
  );

  const visibleIds = useMemo(() => {
    const q = filterValues.name.trim().toLowerCase();
    return items
      .filter((row) => {
        if (
          q &&
          !row.originalName.toLowerCase().includes(q) &&
          !row.filename.toLowerCase().includes(q) &&
          !row.url.toLowerCase().includes(q)
        ) {
          return false;
        }
        if (filterValues.folderId && row.folderId !== filterValues.folderId) return false;
        return true;
      })
      .map((r) => r.id);
  }, [items, filterValues]);

  const allVisibleSelected =
    visibleIds.length > 0 && visibleIds.every((id) => selected.has(id));

  const toggleSelectAllVisible = () => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (allVisibleSelected) {
        for (const id of visibleIds) next.delete(id);
      } else {
        for (const id of visibleIds) next.add(id);
      }
      return next;
    });
  };

  const columns: AdminTableColumn<MediaItem>[] = useMemo(
    () => [
      {
        key: 'select',
        header: '',
        className: 'bk-media-col-select',
        render: (row) => (
          <label className="bk-check bk-media-check" onClick={(e) => e.stopPropagation()}>
            <input
              type="checkbox"
              checked={selected.has(row.id)}
              onChange={() => toggleSelect(row.id)}
              aria-label={`Select ${row.originalName}`}
            />
            <span className="bk-check__box" aria-hidden />
          </label>
        ),
      },
      {
        key: 'preview',
        header: '',
        className: 'bk-media-col-preview',
        render: (row) => (
          <button
            type="button"
            className="bk-media-thumb-btn"
            onClick={() => openItem(row)}
            aria-label={`Open ${row.originalName}`}
          >
            <img className="bk-media-thumb" src={row.url} alt="" width={40} height={40} />
          </button>
        ),
      },
      {
        key: 'name',
        header: 'File',
        render: (row) => (
          <button type="button" className="bk-media-file-btn" onClick={() => openItem(row)}>
            <span className="bk-media-file">
              <strong>{row.originalName}</strong>
              <span className="bk-muted">{row.url}</span>
              {row.alt ? <span className="bk-muted">Alt: {row.alt}</span> : null}
            </span>
          </button>
        ),
      },
      {
        key: 'folder',
        header: 'Folder',
        className: 'bk-media-col-folder',
        render: (row) => folderName(row.folderId),
      },
      {
        key: 'size',
        header: 'Size',
        className: 'bk-media-col-size',
        render: (row) => (
          <span>
            {formatBytes(row.size)}
            {row.width && row.height ? (
              <span className="bk-muted">
                {' '}
                · {row.width}×{row.height}
              </span>
            ) : null}
          </span>
        ),
      },
      {
        key: 'actions',
        header: '',
        render: (row) => (
          <div className="bk-table__row-actions" onClick={(e) => e.stopPropagation()}>
            <button type="button" className="button-link" onClick={() => openItem(row)}>
              Edit
            </button>
            {canUpload ? (
              <>
                <span className="bk-table__sep">|</span>
                <button
                  type="button"
                  className="button-link is-danger"
                  disabled={busy}
                  onClick={() => void remove(row)}
                >
                  Delete
                </button>
              </>
            ) : null}
          </div>
        ),
      },
    ],
    [busy, canUpload, folderName, selected],
  );

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Media"
        actions={
          <>
            {hasActiveAdminFilters(filterValues) ? (
              <button
                type="button"
                className="button"
                onClick={() => setFilterValues(EMPTY_FILTERS)}
              >
                Clear filters
              </button>
            ) : null}
            {canUpload ? (
              <>
                <label className="bk-media-folder-select">
                  <span className="screen-reader-text">Upload folder</span>
                  <select
                    value={uploadFolderId}
                    onChange={(e) => setUploadFolderId(e.target.value)}
                    disabled={busy}
                  >
                    <option value="">No folder</option>
                    {folders.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.name}
                      </option>
                    ))}
                  </select>
                </label>
                <button
                  type="button"
                  className="button button-primary"
                  disabled={busy}
                  onClick={() => fileRef.current?.click()}
                >
                  {busy ? 'Uploading…' : 'Upload'}
                </button>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp,image/gif,image/svg+xml,image/x-icon,.ico"
                  multiple
                  hidden
                  onChange={onPick}
                />
              </>
            ) : null}
          </>
        }
      />
      <p className="bk-muted">
        Images and files for your site. Click a file to edit details. {items.length} total.
      </p>

      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}

      {canUpload ? (
        <div
          className={`bk-media-drop${dragging ? ' is-dragging' : ''}`}
          onDragEnter={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragOver={(e) => e.preventDefault()}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
        >
          <p>
            Drop images here, or use <strong>Upload</strong>. JPEG, PNG, WebP, GIF, SVG, or ICO
            (max 20&nbsp;MB). Files follow your Media settings (WebP / size limits).
          </p>
        </div>
      ) : (
        <p className="bk-muted">You need the upload_files capability to manage media.</p>
      )}

      {selected.size > 0 ? (
        <div className="bk-media-bulk" role="region" aria-label="Bulk actions">
          <label className="bk-check">
            <input
              type="checkbox"
              checked={allVisibleSelected}
              onChange={toggleSelectAllVisible}
            />
            <span className="bk-check__box" aria-hidden />
            <span className="bk-check__label">
              {selected.size} selected
              {visibleIds.length ? ` · ${visibleIds.length} on this filter` : ''}
            </span>
          </label>
          <div className="bk-media-bulk__actions">
            <label className="bk-media-folder-select">
              <span className="screen-reader-text">Move to folder</span>
              <select
                value={bulkFolderId}
                onChange={(e) => setBulkFolderId(e.target.value)}
                disabled={busy}
              >
                <option value="">No folder</option>
                {folders.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
            </label>
            <button
              type="button"
              className="button"
              disabled={busy || !canUpload}
              onClick={() => void bulkMove()}
            >
              Move to folder
            </button>
            <button
              type="button"
              className="button"
              disabled={busy || !canUpload}
              onClick={() => void bulkDelete()}
            >
              Delete selected
            </button>
            <button type="button" className="button-link" onClick={clearSelection}>
              Clear
            </button>
          </div>
        </div>
      ) : visibleIds.length > 0 ? (
        <div className="bk-media-bulk is-idle">
          <label className="bk-check">
            <input
              type="checkbox"
              checked={false}
              onChange={toggleSelectAllVisible}
            />
            <span className="bk-check__box" aria-hidden />
            <span className="bk-check__label">Select all on this page filter</span>
          </label>
        </div>
      ) : null}

      <AdminDataTable
        rows={items}
        columns={columns}
        getRowId={(r) => r.id}
        filters={filters}
        filterValues={filterValues}
        onFilterChange={(v) => setFilterValues({ name: v.name ?? '', folderId: v.folderId ?? '' })}
        filterFn={(row, values) => {
          const q = values.name.trim().toLowerCase();
          if (
            q &&
            !row.originalName.toLowerCase().includes(q) &&
            !row.filename.toLowerCase().includes(q) &&
            !row.url.toLowerCase().includes(q)
          ) {
            return false;
          }
          if (values.folderId && row.folderId !== values.folderId) return false;
          return true;
        }}
        onRowClick={(row) => openItem(row)}
        loading={loading}
        emptyTitle="No media yet. Upload your first file."
        emptyFilteredTitle="No media matches these filters."
      />

      {active ? (
        <div
          className="bk-media-modal"
          role="dialog"
          aria-modal="true"
          aria-labelledby="bk-media-modal-title"
          onClick={(e) => {
            if (e.target === e.currentTarget) setActive(null);
          }}
        >
          <div className="bk-media-modal__panel">
            <div className="bk-media-modal__head">
              <h2 id="bk-media-modal-title" className="bk-media-modal__title">
                {active.originalName}
              </h2>
              <button
                type="button"
                className="button"
                onClick={() => setActive(null)}
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            <div className="bk-media-modal__body">
              <div className="bk-media-modal__preview">
                <img src={active.url} alt={editAlt || active.originalName} />
              </div>

              <form className="bk-media-modal__details" onSubmit={saveActive}>
                <div className="bk-field">
                  <label htmlFor="media_alt">Alt text</label>
                  <input
                    id="media_alt"
                    type="text"
                    maxLength={500}
                    value={editAlt}
                    disabled={!canUpload || busy}
                    placeholder="Describe the image for accessibility"
                    onChange={(e) => setEditAlt(e.target.value)}
                  />
                </div>

                <div className="bk-field">
                  <label htmlFor="media_folder">Folder</label>
                  <div className="bk-media-url-row">
                    <select
                      id="media_folder"
                      value={editFolderId}
                      disabled={!canUpload || busy}
                      onChange={(e) => setEditFolderId(e.target.value)}
                    >
                      <option value="">No folder</option>
                      {folders.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.name}
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      className="button"
                      disabled={
                        !canUpload ||
                        busy ||
                        editFolderId === (active.folderId ?? '')
                      }
                      onClick={() => void moveActive()}
                    >
                      Move
                    </button>
                  </div>
                  <p className="description" style={{ marginTop: 6 }}>
                    Choose a folder, then click Move. Selecting alone does not move the file.
                  </p>
                </div>

                <div className="bk-field">
                  <label htmlFor="media_url">URL</label>
                  <div className="bk-media-url-row">
                    <input
                      id="media_url"
                      type="text"
                      readOnly
                      value={absoluteUrl(active.url)}
                    />
                    <button
                      type="button"
                      className="button"
                      onClick={() => void copyUrl(active.url)}
                    >
                      {copied ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                </div>

                <dl className="bk-media-meta">
                  <div>
                    <dt>Type</dt>
                    <dd>{active.mimeType}</dd>
                  </div>
                  <div>
                    <dt>Size</dt>
                    <dd>{formatBytes(active.size)}</dd>
                  </div>
                  <div>
                    <dt>Dimensions</dt>
                    <dd>
                      {active.width && active.height
                        ? `${active.width} × ${active.height}`
                        : '—'}
                    </dd>
                  </div>
                  <div>
                    <dt>Filename</dt>
                    <dd>{active.filename}</dd>
                  </div>
                  <div>
                    <dt>Uploaded</dt>
                    <dd>{new Date(active.createdAt).toLocaleString()}</dd>
                  </div>
                </dl>

                <div className="bk-media-modal__actions">
                  {canUpload ? (
                    <button type="submit" className="button button-primary" disabled={busy}>
                      {busy ? 'Saving…' : 'Save details'}
                    </button>
                  ) : null}
                  <a
                    className="button"
                    href={active.url}
                    target="_blank"
                    rel="noreferrer"
                  >
                    Open file
                  </a>
                  {canUpload ? (
                    <button
                      type="button"
                      className="button"
                      disabled={busy}
                      onClick={() => void remove(active)}
                    >
                      Delete
                    </button>
                  ) : null}
                </div>
              </form>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
