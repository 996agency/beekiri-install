import { AppearanceChromePage } from './AppearanceChromePage';

export function AppearanceFooterPage() {
  return <AppearanceChromePage kind="footer" />;
}
