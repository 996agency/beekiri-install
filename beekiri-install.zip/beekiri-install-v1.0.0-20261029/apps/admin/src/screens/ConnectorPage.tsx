import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import { notifyConnectorChanged } from '../lib/admin-events';
import './connector-page.css';

type ProviderId = 'beequeen' | 'claude' | 'openai' | 'gemini' | 'grok';

type Provider = {
  id: ProviderId;
  name: string;
  vendor: string;
  blurb: string;
  badge?: string;
  enabled: boolean;
  configured: boolean;
  defaultModel: string;
};

type ConnectorState = {
  providers: Provider[];
};

const LOGO: Record<ProviderId, string> = {
  beequeen: '/admin/beekiri-logo.png',
  claude: '/admin/connector/claude.svg',
  openai: '/admin/connector/openai.svg',
  gemini: '/admin/connector/gemini.svg',
  grok: '/admin/connector/grok.svg',
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

export function ConnectorPage() {
  const navigate = useNavigate();
  const [data, setData] = useState<ConnectorState | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(async () => {
    const res = await api<ConnectorState>('/api/connector');
    setData(res);
  }, []);

  useEffect(() => {
    load().catch((e) => setError(formatError(e)));
  }, [load]);

  const toggle = async (provider: Provider) => {
    const turningOn = !provider.enabled;
    setBusyId(provider.id);
    setError(null);
    setNotice(null);
    try {
      const res = await api<ConnectorState>('/api/connector', {
        method: 'PATCH',
        json: { providerId: provider.id, enabled: turningOn },
      });
      // List payload when only toggling.
      if ('providers' in res && Array.isArray((res as ConnectorState).providers)) {
        setData(res as ConnectorState);
      } else {
        await load();
      }
      notifyConnectorChanged();
      setNotice(
        turningOn
          ? `${provider.name} enabled. Open it anytime under Connector in the sidebar.`
          : `${provider.name} turned off.`,
      );
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusyId(null);
    }
  };

  const openSetup = (provider: Provider) => {
    if (provider.enabled) navigate(`/admin/connector/${provider.id}`);
  };

  if (!data) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title="Connector" />
        {error ? (
          <div className="beekiri-notice is-error" role="alert">
            <p>{error}</p>
          </div>
        ) : (
          <p className="bk-muted">Loading…</p>
        )}
      </div>
    );
  }

  const onCount = data.providers.filter((p) => p.enabled).length;

  return (
    <div className="wrap wrap--wide bk-conn">
      <PageHeader title="Connector" />
      <p className="bk-muted" style={{ marginTop: 0 }}>
        Choose which AI providers Beekiri agents can use. Setup is under Connector in the sidebar after you turn one on.
        {onCount ? ` ${onCount} selected.` : ''}
      </p>

      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}
      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}

      <div className="bk-conn__grid" role="list">
        {data.providers.map((p) => {
          const busy = busyId === p.id;
          return (
            <div
              key={p.id}
              role="listitem"
              className={`bk-conn-card${p.enabled ? ' is-on' : ''}${p.enabled ? ' is-linkable' : ''}`}
              onClick={() => openSetup(p)}
              onKeyDown={(e) => {
                if (p.enabled && (e.key === 'Enter' || e.key === ' ')) {
                  e.preventDefault();
                  openSetup(p);
                }
              }}
              tabIndex={p.enabled ? 0 : undefined}
            >
              <div className="bk-conn-card__top">
                <div className="bk-conn-card__brand">
                  <span className={`bk-conn-card__mark is-${p.id}`} aria-hidden>
                    <img src={LOGO[p.id]} alt="" width={22} height={22} draggable={false} />
                  </span>
                  <div className="bk-conn-card__titles">
                    <h3>{p.name}</h3>
                    <span>{p.vendor}</span>
                  </div>
                </div>
              </div>
              <p className="bk-conn-card__blurb">{p.blurb}</p>
              <div className="bk-conn-card__foot">
                <span className="bk-conn-card__status">
                  {busy
                    ? 'Saving…'
                    : p.enabled
                      ? p.configured
                        ? 'Connected · Open setup'
                        : 'On · Finish setup'
                      : 'Not selected'}
                </span>
                <button
                  type="button"
                  className={`bk-conn-card__switch${p.enabled ? ' is-on' : ''}`}
                  role="switch"
                  aria-checked={p.enabled}
                  aria-label={`${p.enabled ? 'Disable' : 'Enable'} ${p.name}`}
                  disabled={busy || Boolean(busyId)}
                  onClick={(e) => {
                    e.stopPropagation();
                    void toggle(p);
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
