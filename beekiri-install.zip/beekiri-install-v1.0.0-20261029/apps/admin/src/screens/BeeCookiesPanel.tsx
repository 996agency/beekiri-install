import { FormEvent, type ReactNode, useEffect, useState } from 'react';
import { api, ApiError } from '../api/client';
import './bee-cookies-panel.css';

type Category = {
  enabled: boolean;
  label: string;
  description: string;
};

export type BeeCookiesSettings = {
  enabled: boolean;
  position: 'bottom' | 'bottom-left' | 'bottom-right';
  bannerTitle: string;
  bannerMessage: string;
  acceptLabel: string;
  rejectLabel: string;
  preferencesLabel: string;
  saveLabel: string;
  privacyPolicyUrl: string;
  trackPageViews: boolean;
  categories: {
    essential: Category;
    functional: Category;
    analytics: Category;
    marketing: Category;
  };
};

type Range = 'today' | '7d' | '30d' | 'all';

type Analytics = {
  range: Range;
  consent: {
    decisions: number;
    uniqueVisitors: number;
    accepted: number;
    rejected: number;
    custom: number;
    consentRate: number;
    categories: { functional: number; analytics: number; marketing: number };
    devices: Record<string, number>;
    countries: { code: string; count: number }[];
    trend: { date: string; accepted: number; rejected: number; custom: number }[];
  };
};

type Props = {
  busy: boolean;
  onBusy: (busy: boolean) => void;
  onNotice: (message: string | null) => void;
  onError: (message: string | null) => void;
};

const RANGES: { value: Range; label: string }[] = [
  { value: 'today', label: 'Today' },
  { value: '7d', label: '7 days' },
  { value: '30d', label: '30 days' },
  { value: 'all', label: 'All' },
];

const OPTIONAL: Array<keyof BeeCookiesSettings['categories']> = [
  'functional',
  'analytics',
  'marketing',
];

function Stat({ value, label }: { value: string | number; label: string }) {
  return (
    <div className="bk-bee-stat">
      <strong>{value}</strong>
      <span>{label}</span>
    </div>
  );
}

function titleCase(key: string) {
  return key ? key[0].toUpperCase() + key.slice(1) : key;
}

function flagEmoji(code: string) {
  return String.fromCodePoint(...[...code].map((c) => 127397 + c.charCodeAt(0)));
}

function countryLabel(code: string) {
  if (!code || code === 'Unknown' || code === 'XX') return { flag: '', name: 'Not detected' };
  if (!/^[A-Z]{2}$/.test(code)) return { flag: '', name: code };
  try {
    const name = new Intl.DisplayNames(['en'], { type: 'region' }).of(code);
    return { flag: flagEmoji(code), name: name || code };
  } catch {
    return { flag: flagEmoji(code), name: code };
  }
}

function shortDate(iso: string) {
  const [y, m, d] = iso.split('-').map(Number);
  if (!y || !m || !d) return iso;
  return new Date(Date.UTC(y, m - 1, d)).toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
  });
}

type RankRow = { key: string; label: ReactNode; n: number };

function Rank({ rows }: { rows: RankRow[] }) {
  const max = Math.max(1, ...rows.map((r) => r.n));
  const total = rows.reduce((sum, r) => sum + r.n, 0) || 1;
  if (!rows.length) return <p className="bk-muted">No data in this range.</p>;
  return (
    <ul className="bk-bee-rank">
      {rows.map((r) => (
        <li key={r.key}>
          <div className="bk-bee-rank__row">
            <span className="bk-bee-rank__label">{r.label}</span>
            <span className="bk-bee-rank__meta">
              <b>{r.n}</b>
              <em>{Math.round((r.n / total) * 100)}%</em>
            </span>
          </div>
          <span className="bk-bee-rank__track">
            <span style={{ width: `${(r.n / max) * 100}%` }} />
          </span>
        </li>
      ))}
    </ul>
  );
}

function Mix({
  parts,
}: {
  parts: { key: string; n: number; tone: 'ink' | 'mid' | 'faint' }[];
}) {
  const total = parts.reduce((sum, p) => sum + p.n, 0);
  if (!total) return <p className="bk-muted">No data in this range.</p>;
  return (
    <div className="bk-bee-mix">
      <div className="bk-bee-mix__bar" aria-hidden>
        {parts
          .filter((p) => p.n > 0)
          .map((p) => (
            <i key={p.key} className={`is-${p.tone}`} style={{ width: `${(p.n / total) * 100}%` }} />
          ))}
      </div>
      <ul className="bk-bee-mix__legend">
        {parts.map((p) => (
          <li key={p.key}>
            <i className={`is-${p.tone}`} aria-hidden />
            {p.key}
            <strong>{p.n}</strong>
            <em>{Math.round((p.n / total) * 100)}%</em>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function BeeCookiesPanel({ busy, onBusy, onNotice, onError }: Props) {
  const [settings, setSettings] = useState<BeeCookiesSettings | null>(null);
  const [pane, setPane] = useState<'setup' | 'consent'>('setup');
  const [range, setRange] = useState<Range>('30d');
  const [analytics, setAnalytics] = useState<Analytics | null>(null);

  const loadSettings = async () => {
    const s = await api<BeeCookiesSettings>('/api/bee-cookies/settings');
    setSettings(s);
  };

  const loadAnalytics = async (next = range) => {
    const data = await api<Analytics>(`/api/bee-cookies/analytics?range=${next}`);
    setAnalytics(data);
  };

  useEffect(() => {
    loadSettings().catch((e) =>
      onError(e instanceof ApiError ? e.message : 'Could not load BeeCookies.'),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (pane === 'setup') return;
    loadAnalytics(range).catch((e) =>
      onError(e instanceof ApiError ? e.message : 'Could not load analytics.'),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pane, range]);

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    onBusy(true);
    onError(null);
    onNotice(null);
    try {
      const saved = await api<BeeCookiesSettings>('/api/bee-cookies/settings', {
        method: 'PATCH',
        json: settings,
      });
      setSettings(saved);
      onNotice('BeeCookies saved.');
    } catch (err) {
      onError(err instanceof ApiError ? err.message : 'Save failed');
    } finally {
      onBusy(false);
    }
  };

  if (!settings) {
    return (
      <div className="bk-settings-panel__loading" role="status">
        <span className="bk-settings-panel__spinner" aria-hidden />
        <span>Loading…</span>
      </div>
    );
  }

  const c = analytics?.consent;

  return (
    <div className="bk-stack bk-bee">
      <nav className="bk-bee__sub" aria-label="BeeCookies sections">
        {(
          [
            ['setup', 'Setup'],
            ['consent', 'Consent'],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            className={pane === id ? 'is-active' : ''}
            onClick={() => setPane(id)}
          >
            {label}
          </button>
        ))}
      </nav>

      {pane === 'setup' ? (
        <form className="bk-stack" onSubmit={(e) => void save(e)}>
          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">BeeCookies</h2>
            </div>
            <div className="bk-panel__body">
              <p className="bk-muted" style={{ marginTop: 0 }}>
                Ask visitors for cookie consent before optional cookies run. Essential cookies
                (your visitors&apos; choice) stay on. Analytics and marketing stay off until
                accepted.
              </p>
              <table className="form-table">
                <tbody>
                  <tr>
                    <th scope="row">Status</th>
                    <td>
                      <label className="bk-check">
                        <input
                          type="checkbox"
                          checked={settings.enabled}
                          onChange={(e) => setSettings({ ...settings, enabled: e.target.checked })}
                        />
                        <span className="bk-check__box" aria-hidden />
                        <span className="bk-check__label">Show the consent banner on the public site</span>
                      </label>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="bee-title">Banner title</label>
                    </th>
                    <td>
                      <input
                        id="bee-title"
                        className="regular-text"
                        value={settings.bannerTitle}
                        onChange={(e) => setSettings({ ...settings, bannerTitle: e.target.value })}
                      />
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="bee-message">Message</label>
                    </th>
                    <td>
                      <textarea
                        id="bee-message"
                        className="large-text"
                        rows={4}
                        value={settings.bannerMessage}
                        onChange={(e) => setSettings({ ...settings, bannerMessage: e.target.value })}
                      />
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">Buttons</th>
                    <td className="bk-bee-inline">
                      <label>
                        Accept
                        <input
                          className="regular-text"
                          value={settings.acceptLabel}
                          onChange={(e) => setSettings({ ...settings, acceptLabel: e.target.value })}
                        />
                      </label>
                      <label>
                        Reject
                        <input
                          className="regular-text"
                          value={settings.rejectLabel}
                          onChange={(e) => setSettings({ ...settings, rejectLabel: e.target.value })}
                        />
                      </label>
                      <label>
                        Preferences
                        <input
                          className="regular-text"
                          value={settings.preferencesLabel}
                          onChange={(e) =>
                            setSettings({ ...settings, preferencesLabel: e.target.value })
                          }
                        />
                      </label>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="bee-position">Position</label>
                    </th>
                    <td>
                      <select
                        id="bee-position"
                        value={settings.position}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            position: e.target.value as BeeCookiesSettings['position'],
                          })
                        }
                      >
                        <option value="bottom">Bottom bar</option>
                        <option value="bottom-left">Bottom left</option>
                        <option value="bottom-right">Bottom right</option>
                      </select>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="bee-privacy">Privacy policy URL</label>
                    </th>
                    <td>
                      <input
                        id="bee-privacy"
                        className="regular-text"
                        placeholder="/privacy"
                        value={settings.privacyPolicyUrl}
                        onChange={(e) =>
                          setSettings({ ...settings, privacyPolicyUrl: e.target.value })
                        }
                      />
                      <p className="description">Optional. Shown as a link on the banner.</p>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">Analytics</th>
                    <td>
                      <label className="bk-check">
                        <input
                          type="checkbox"
                          checked={settings.trackPageViews}
                          onChange={(e) =>
                            setSettings({ ...settings, trackPageViews: e.target.checked })
                          }
                        />
                        <span className="bk-check__box" aria-hidden />
                        <span className="bk-check__label">
                          Feed Analytics Overview after analytics cookies are accepted
                        </span>
                      </label>
                      <p className="description">
                        First-party only. Page views, sources, and devices show under Analytics →
                        Overview. IP addresses are not stored.
                      </p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Categories</h2>
            </div>
            <div className="bk-panel__body">
              <table className="form-table">
                <tbody>
                  <tr>
                    <th scope="row">{settings.categories.essential.label}</th>
                    <td>
                      <p className="description" style={{ marginTop: 0 }}>
                        Always on. Stores the visitor&apos;s cookie choice.
                      </p>
                      <input
                        className="regular-text"
                        value={settings.categories.essential.description}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            categories: {
                              ...settings.categories,
                              essential: {
                                ...settings.categories.essential,
                                description: e.target.value,
                              },
                            },
                          })
                        }
                      />
                    </td>
                  </tr>
                  {OPTIONAL.map((key) => {
                    const cat = settings.categories[key];
                    return (
                      <tr key={key}>
                        <th scope="row">{cat.label}</th>
                        <td>
                          <label className="bk-check">
                            <input
                              type="checkbox"
                              checked={cat.enabled}
                              onChange={(e) =>
                                setSettings({
                                  ...settings,
                                  categories: {
                                    ...settings.categories,
                                    [key]: { ...cat, enabled: e.target.checked },
                                  },
                                })
                              }
                            />
                            <span className="bk-check__box" aria-hidden />
                            <span className="bk-check__label">Offer this category</span>
                          </label>
                          <input
                            className="regular-text"
                            style={{ marginTop: 8 }}
                            value={cat.description}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                categories: {
                                  ...settings.categories,
                                  [key]: { ...cat, description: e.target.value },
                                },
                              })
                            }
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <p className="submit">
                <button type="submit" className="button button-primary" disabled={busy}>
                  {busy ? 'Saving…' : 'Save changes'}
                </button>
              </p>
            </div>
          </div>
        </form>
      ) : null}

      {pane === 'consent' ? (
        <div className="bk-stack">
          <div className="bk-bee__range" role="group" aria-label="Date range">
            {RANGES.map((r) => (
              <button
                key={r.value}
                type="button"
                className={range === r.value ? 'is-active' : ''}
                onClick={() => setRange(r.value)}
              >
                {r.label}
              </button>
            ))}
          </div>

          {!analytics ? <p className="bk-muted">Loading consent…</p> : null}

          {c ? (
            <>
              <div className="bk-bee-stats">
                <Stat value={c.uniqueVisitors} label="Visitors" />
                <Stat value={c.decisions} label="Decisions" />
                <Stat value={`${c.consentRate}%`} label="Accepted all" />
                <Stat value={c.rejected} label="Rejected optional" />
              </div>
              <div className="bk-panel">
                <div className="bk-panel__head">
                  <h2 className="bk-panel__title">Choices</h2>
                </div>
                <div className="bk-panel__body">
                  <Mix
                    parts={[
                      { key: 'Accepted all', n: c.accepted, tone: 'ink' },
                      { key: 'Custom', n: c.custom, tone: 'mid' },
                      { key: 'Rejected optional', n: c.rejected, tone: 'faint' },
                    ]}
                  />
                </div>
              </div>
              <div className="bk-bee-grid">
                <div className="bk-panel">
                  <div className="bk-panel__head">
                    <h2 className="bk-panel__title">Optional categories</h2>
                  </div>
                  <div className="bk-panel__body">
                    <Rank
                      rows={[
                        { key: 'functional', label: 'Functional', n: c.categories.functional },
                        { key: 'analytics', label: 'Analytics', n: c.categories.analytics },
                        { key: 'marketing', label: 'Marketing', n: c.categories.marketing },
                      ]}
                    />
                  </div>
                </div>
                <div className="bk-panel">
                  <div className="bk-panel__head">
                    <h2 className="bk-panel__title">Devices</h2>
                  </div>
                  <div className="bk-panel__body">
                    <Rank
                      rows={Object.entries(c.devices).map(([key, n]) => ({
                        key,
                        label: titleCase(key),
                        n,
                      }))}
                    />
                  </div>
                </div>
              </div>
              <div className="bk-bee-grid">
                <div className="bk-panel">
                  <div className="bk-panel__head">
                    <h2 className="bk-panel__title">Country</h2>
                  </div>
                  <div className="bk-panel__body">
                    <Rank
                      rows={c.countries.map((r) => {
                        const { flag, name } = countryLabel(r.code);
                        return {
                          key: r.code,
                          n: r.count,
                          label: (
                            <>
                              {flag ? <span className="bk-bee-rank__flag">{flag}</span> : null}
                              {name}
                            </>
                          ),
                        };
                      })}
                    />
                  </div>
                </div>
                <div className="bk-panel">
                  <div className="bk-panel__head">
                    <h2 className="bk-panel__title">Trend</h2>
                  </div>
                  <div className="bk-panel__body">
                    {c.trend.length ? (
                      <div className="bk-bee-mix">
                        <ul className="bk-bee-trend">
                          {c.trend.map((d) => {
                            const total = d.accepted + d.rejected + d.custom || 1;
                            return (
                              <li key={d.date}>
                                <span>{shortDate(d.date)}</span>
                                <span className="bk-bee-trend__bar">
                                  <i
                                    style={{ width: `${(d.accepted / total) * 100}%` }}
                                    className="is-ink"
                                  />
                                  <i
                                    style={{ width: `${(d.custom / total) * 100}%` }}
                                    className="is-mid"
                                  />
                                  <i
                                    style={{ width: `${(d.rejected / total) * 100}%` }}
                                    className="is-faint"
                                  />
                                </span>
                              </li>
                            );
                          })}
                        </ul>
                        <ul className="bk-bee-mix__legend">
                          <li>
                            <i className="is-ink" aria-hidden />
                            Accepted
                          </li>
                          <li>
                            <i className="is-mid" aria-hidden />
                            Custom
                          </li>
                          <li>
                            <i className="is-faint" aria-hidden />
                            Rejected
                          </li>
                        </ul>
                      </div>
                    ) : (
                      <p className="bk-muted">No consent decisions in this range.</p>
                    )}
                  </div>
                </div>
              </div>
            </>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
