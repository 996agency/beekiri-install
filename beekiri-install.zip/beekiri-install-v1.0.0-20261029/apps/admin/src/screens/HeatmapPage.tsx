import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import { PageHeader } from '../components/PageHeader';
import './analytics-page.css';
import './heatmap-page.css';

type Range = 'today' | '7d' | '30d' | '90d' | 'all';

type HeatmapPayload = {
  range: Range;
  tracking: { enabled: boolean; pageViews: boolean };
  path: string;
  total: number;
  pages: { path: string; clicks: number; users: number }[];
  points: { x: number; y: number; n: number }[];
  generatedAt: string;
};

const RANGES: { value: Range; label: string }[] = [
  { value: 'today', label: 'Today' },
  { value: '7d', label: '7 days' },
  { value: '30d', label: '30 days' },
  { value: '90d', label: '90 days' },
  { value: 'all', label: 'All time' },
];

function pageLabel(path: string) {
  if (!path || path === '/') return 'Home';
  return path;
}

function heatColor(t: number): string {
  // cool → warm (charcoal → orange → yellow)
  const c = Math.min(1, Math.max(0, t));
  if (c < 0.5) {
    const k = c / 0.5;
    return `rgba(${80 + Math.round(175 * k)}, ${87 - Math.round(20 * k)}, ${94 - Math.round(94 * k)}, ${0.35 + 0.35 * k})`;
  }
  const k = (c - 0.5) / 0.5;
  return `rgba(${255}, ${149 + Math.round(70 * k)}, ${Math.round(40 * (1 - k))}, ${0.7 + 0.25 * k})`;
}

function HeatOverlay({
  points,
  height,
}: {
  points: HeatmapPayload['points'];
  height: number;
}) {
  const max = Math.max(1, ...points.map((p) => p.n));
  if (!points.length) {
    return <p className="bk-an__empty bk-hm__empty">No clicks on this page in the selected range.</p>;
  }
  return (
    <div className="bk-hm__layer" style={{ height }} aria-hidden>
      {points.map((p) => {
        const t = p.n / max;
        const size = 28 + Math.round(t * 52);
        return (
          <span
            key={`${p.x}-${p.y}`}
            className="bk-hm__blob"
            title={`${p.n} click${p.n === 1 ? '' : 's'}`}
            style={{
              left: `${p.x}%`,
              top: `${p.y}%`,
              width: size,
              height: size,
              background: `radial-gradient(circle, ${heatColor(t)} 0%, transparent 70%)`,
            }}
          />
        );
      })}
    </div>
  );
}

export function HeatmapPage() {
  const [range, setRange] = useState<Range>('30d');
  const [path, setPath] = useState<string | null>(null);
  const [data, setData] = useState<HeatmapPayload | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [frameH, setFrameH] = useState(900);
  const frameRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    let cancelled = false;
    setError(null);
    const q = new URLSearchParams({ range });
    if (path) q.set('path', path);
    api<HeatmapPayload>(`/api/analytics/heatmap?${q}`)
      .then((payload) => {
        if (cancelled) return;
        setData(payload);
        if (!path) setPath(payload.path);
      })
      .catch((e) => {
        if (cancelled) return;
        setData(null);
        setError(e instanceof ApiError ? e.message : 'Could not load heatmap.');
      });
    return () => {
      cancelled = true;
    };
  }, [range, path]);

  const trackingOff = data && (!data.tracking.enabled || !data.tracking.pageViews);

  const previewSrc = useMemo(() => {
    const p = path || data?.path || '/';
    return p.startsWith('/') ? p : `/${p}`;
  }, [path, data?.path]);

  const measureFrame = () => {
    const frame = frameRef.current;
    try {
      const doc = frame?.contentDocument;
      if (!doc) return;
      const h = Math.max(
        doc.documentElement?.scrollHeight ?? 0,
        doc.body?.scrollHeight ?? 0,
        600,
      );
      setFrameH(Math.min(Math.max(h, 600), 8_000));
    } catch {
      /* cross-origin — keep default */
    }
  };

  return (
    <div className="bk-an bk-hm">
      <PageHeader
        title="Heatmap"
        actions={
          <div className="bk-an__tools">
            <div className="bk-an__seg" role="group" aria-label="Date range">
              {RANGES.map((r) => (
                <button
                  key={r.value}
                  type="button"
                  className={range === r.value ? 'is-active' : ''}
                  onClick={() => setRange(r.value)}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>
        }
      />

      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}

      {trackingOff ? (
        <p className="bk-an__banner">
          Clicks are recorded only after a visitor accepts analytics cookies.{' '}
          <Link to="/admin/analytics/cookies">Turn on BeeCookies</Link> to collect heatmaps.
        </p>
      ) : null}

      <div className="bk-hm__layout">
        <aside className="bk-panel bk-hm__pages">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Pages</h2>
            {data ? (
              <span className="bk-hm__meta">{data.total.toLocaleString('en-GB')} clicks</span>
            ) : null}
          </div>
          <div className="bk-panel__body">
            {!data ? (
              <p className="bk-an__empty">Loading…</p>
            ) : data.pages.length === 0 ? (
              <p className="bk-an__empty">
                No clicks yet. Open the public site after accepting analytics cookies and click
                around — heat will appear here.
              </p>
            ) : (
              <ul className="bk-hm__list">
                {data.pages.map((p) => (
                  <li key={p.path}>
                    <button
                      type="button"
                      className={path === p.path ? 'is-active' : ''}
                      onClick={() => setPath(p.path)}
                    >
                      <span>{pageLabel(p.path)}</span>
                      <em>
                        {p.clicks.toLocaleString('en-GB')}
                        <small>{p.users} users</small>
                      </em>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </aside>

        <section className="bk-panel bk-hm__preview">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">{pageLabel(previewSrc)}</h2>
            <span className="bk-hm__meta">Live page + click heat</span>
          </div>
          <div className="bk-panel__body bk-hm__stage">
            <div className="bk-hm__frame-wrap" style={{ height: frameH }}>
              <iframe
                ref={frameRef}
                className="bk-hm__frame"
                title={`Heatmap preview ${previewSrc}`}
                src={previewSrc}
                onLoad={measureFrame}
              />
              {data && path === data.path ? (
                <HeatOverlay points={data.points} height={frameH} />
              ) : null}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
