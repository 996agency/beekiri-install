import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import type { RoleSlug } from '../cms-types';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import {
  AdminDataTable,
  hasActiveAdminFilters,
  type AdminTableColumn,
  type AdminTableFilter,
} from '../components/AdminDataTable';
import { confirmDialog } from '../components/ConfirmDialog';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';

const EMPTY_FILTERS = { username: '', name: '', role: '' };

type RoleOption = { slug: RoleSlug; label: string };

type SiteUser = {
  id: string;
  username: string;
  email: string;
  displayName: string;
  role: RoleSlug;
  roleLabel: string;
  isOwner: boolean;
  createdAt: string;
  updatedAt: string;
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

export function UsersPage() {
  const auth = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [users, setUsers] = useState<SiteUser[]>([]);
  const [roles, setRoles] = useState<RoleOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [filterValues, setFilterValues] = useState(EMPTY_FILTERS);

  const canList = auth.user?.capabilities.includes('list_users') ?? false;
  const canCreate = auth.user?.capabilities.includes('create_users') ?? false;
  const canEdit = auth.user?.capabilities.includes('edit_users') ?? false;
  const canDelete = auth.user?.capabilities.includes('delete_users') ?? false;

  const load = useCallback(async () => {
    setError(null);
    const [listRes, rolesRes] = await Promise.all([
      api<{ users: SiteUser[] }>('/api/users'),
      api<{ roles: RoleOption[] }>('/api/users/roles'),
    ]);
    setUsers(listRes.users);
    setRoles(rolesRes.roles);
  }, []);

  useEffect(() => {
    if (!canList) {
      setLoading(false);
      return;
    }
    setLoading(true);
    load()
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [load, canList]);

  useEffect(() => {
    const state = location.state as { notice?: string } | null;
    if (state?.notice) {
      setNotice(state.notice);
      navigate(location.pathname, { replace: true, state: null });
    }
  }, [location.pathname, location.state, navigate]);

  const onDelete = async (user: SiteUser) => {
    if (user.id === auth.user?.id) return;
    if (user.isOwner) return;
    const ok = await confirmDialog({
      title: 'Delete user',
      message: `Delete user “${user.username}”? They will lose access immediately. This cannot be undone.`,
      confirmLabel: 'Delete',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await api(`/api/users/${user.id}`, { method: 'DELETE' });
      setNotice(`User “${user.username}” deleted.`);
      await load();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const tableFilters: AdminTableFilter[] = useMemo(
    () => [
      {
        key: 'username',
        label: 'Username',
        type: 'text',
        placeholder: 'Filter username…',
      },
      {
        key: 'name',
        label: 'Name',
        type: 'text',
        placeholder: 'Filter name…',
      },
      {
        key: 'role',
        label: 'Role',
        type: 'select',
        allLabel: 'All roles',
        options: roles.map((r) => ({ value: r.slug, label: r.label })),
      },
    ],
    [roles],
  );

  const columns: AdminTableColumn<SiteUser>[] = useMemo(
    () => [
      {
        key: 'username',
        header: 'Username',
        render: (user) => {
          const isYou = user.id === auth.user?.id;
          const canOpen = canEdit || isYou;
          return (
            <>
              {canOpen ? (
                <Link to={`/admin/users/${user.id}`} className="bk-table__primary">
                  {user.username}
                </Link>
              ) : (
                <strong className="bk-table__primary">{user.username}</strong>
              )}
              {isYou ? <span className="bk-table__badge">You</span> : null}
              {user.isOwner ? (
                <span className="bk-table__badge is-accent">Owner</span>
              ) : null}
              <div className="bk-table__row-actions">
                {canOpen ? (
                  <Link to={`/admin/users/${user.id}`} className="button-link">
                    {isYou && !canEdit ? 'Edit profile' : 'Edit'}
                  </Link>
                ) : null}
                {canDelete && !isYou && !user.isOwner ? (
                  <>
                    {canOpen ? <span className="bk-table__sep">|</span> : null}
                    <button
                      type="button"
                      className="button-link is-danger"
                      disabled={busy}
                      onClick={() => onDelete(user)}
                    >
                      Delete
                    </button>
                  </>
                ) : null}
              </div>
            </>
          );
        },
      },
      {
        key: 'name',
        header: 'Name',
        render: (user) => {
          const isYou = user.id === auth.user?.id;
          if (canEdit || isYou) {
            return (
              <Link to={`/admin/users/${user.id}`} className="button-link">
                {user.displayName}
              </Link>
            );
          }
          return user.displayName;
        },
      },
      {
        key: 'email',
        header: 'Email',
        render: (user) => <a href={`mailto:${user.email}`}>{user.email}</a>,
      },
      {
        key: 'role',
        header: 'Role',
        render: (user) => user.roleLabel,
      },
    ],
    [auth.user?.id, busy, canDelete, canEdit],
  );

  const filterUsers = useCallback((row: SiteUser, values: Record<string, string>) => {
    const username = values.username?.trim().toLowerCase() ?? '';
    const name = values.name?.trim().toLowerCase() ?? '';
    const role = values.role?.trim() ?? '';
    if (username && !row.username.toLowerCase().includes(username)) return false;
    if (name && !row.displayName.toLowerCase().includes(name)) return false;
    if (role && row.role !== role) return false;
    return true;
  }, []);

  const canClearFilters = hasActiveAdminFilters(filterValues);

  if (!canList) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title="Users" />
        <div className="beekiri-notice is-error" role="alert">
          <p>You do not have permission to view users.</p>
        </div>
        {auth.user ? (
          <p>
            <Link to={`/admin/users/${auth.user.id}`} className="button">
              Edit your profile
            </Link>
          </p>
        ) : null}
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Users"
        actions={
          <>
            {canClearFilters ? (
              <button
                type="button"
                className="button"
                onClick={() => setFilterValues(EMPTY_FILTERS)}
              >
                Clear filters
              </button>
            ) : null}
            {canCreate ? (
              <Link to="/admin/users/new" className="button button-primary">
                Add user
              </Link>
            ) : null}
          </>
        }
      />
      <p className="bk-muted">
        People who can sign in to this Beekiri site. {users.length} total.
      </p>

      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}

      <AdminDataTable
        rows={users}
        columns={columns}
        getRowId={(u) => u.id}
        filters={tableFilters}
        filterValues={filterValues}
        onFilterChange={(values) =>
          setFilterValues({
            username: values.username ?? '',
            name: values.name ?? '',
            role: values.role ?? '',
          })
        }
        filterFn={filterUsers}
        loading={loading}
        defaultPageSize={10}
        pageSizeOptions={[10, 25, 50]}
        emptyTitle="No users yet. Add the first account to get started."
        emptyFilteredTitle="No users match these filters."
      />
    </div>
  );
}
