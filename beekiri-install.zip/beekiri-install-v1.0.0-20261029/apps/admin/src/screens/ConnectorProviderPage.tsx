import { FormEvent, useCallback, useEffect, useState } from 'react';
import { Link, Navigate, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import { notifyConnectorChanged } from '../lib/admin-events';
import './connector-page.css';

type ProviderId = 'beequeen' | 'claude' | 'openai' | 'gemini' | 'grok';

type ProviderDetail = {
  id: ProviderId;
  name: string;
  vendor: string;
  blurb: string;
  badge?: string;
  docsUrl: string;
  apiKeyLabel: string;
  apiKeyPlaceholder: string;
  models: { id: string; label: string }[];
  enabled: boolean;
  configured: boolean;
  apiKeyMasked: string | null;
  defaultModel: string;
};

const LOGO: Record<ProviderId, string> = {
  beequeen: '/admin/beekiri-logo.png',
  claude: '/admin/connector/claude.svg',
  openai: '/admin/connector/openai.svg',
  gemini: '/admin/connector/gemini.svg',
  grok: '/admin/connector/grok.svg',
};

const IDS: ProviderId[] = ['beequeen', 'claude', 'openai', 'gemini', 'grok'];

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

export function ConnectorProviderPage() {
  const { providerId: rawId } = useParams<{ providerId: string }>();
  const providerId = (rawId || '').toLowerCase() as ProviderId;
  const navigate = useNavigate();
  const valid = IDS.includes(providerId);

  const [data, setData] = useState<ProviderDetail | null>(null);
  const [apiKey, setApiKey] = useState('');
  const [defaultModel, setDefaultModel] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(async () => {
    const res = await api<ProviderDetail>(`/api/connector/${providerId}`);
    setData(res);
    setDefaultModel(res.defaultModel);
    setApiKey('');
  }, [providerId]);

  useEffect(() => {
    if (!valid) return;
    load().catch((e) => setError(formatError(e)));
  }, [load, valid]);

  if (!valid) return <Navigate to="/admin/connector" replace />;

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!data) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const body: Record<string, unknown> = {
        providerId,
        enabled: true,
        defaultModel,
      };
      if (apiKey.trim()) body.apiKey = apiKey.trim();
      const res = await api<ProviderDetail>('/api/connector', { method: 'PATCH', json: body });
      setData(res);
      setApiKey('');
      notifyConnectorChanged();
      setNotice(`${res.name} setup saved.`);
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const disable = async () => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await api('/api/connector', {
        method: 'PATCH',
        json: { providerId, enabled: false },
      });
      notifyConnectorChanged();
      navigate('/admin/connector');
    } catch (err) {
      setError(formatError(err));
      setBusy(false);
    }
  };

  if (!data && !error) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title="Connector" />
        <p className="bk-muted">Loading…</p>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title="Connector" />
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
        <p>
          <Link className="button" to="/admin/connector">
            Back to Connector
          </Link>
        </p>
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide bk-conn">
      <p className="bk-conn-back">
        <Link className="bk-conn-back__link" to="/admin/connector">
          <ArrowLeft size={16} weight="bold" aria-hidden />
          <span>Connector</span>
        </Link>
      </p>
      <PageHeader
        title={data.name}
        actions={
          <button type="button" className="button" disabled={busy} onClick={() => void disable()}>
            Turn off
          </button>
        }
      />
      <p className="bk-muted" style={{ marginTop: 0 }}>
        {data.blurb}
      </p>

      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}
      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}

      <form className="bk-panel" onSubmit={(e) => void save(e)}>
        <div className="bk-panel__head">
          <div className="bk-conn-setup__head">
            <span className={`bk-conn-card__mark is-${data.id}`} aria-hidden>
              <img src={LOGO[data.id]} alt="" width={22} height={22} draggable={false} />
            </span>
            <div>
              <h2 className="bk-panel__title" style={{ margin: 0 }}>
                Setup {data.name}
              </h2>
              <p className="bk-muted" style={{ margin: '2px 0 0', fontSize: 12 }}>
                {data.vendor}
                {data.configured ? ' · Key saved' : ' · No key yet'}
              </p>
            </div>
          </div>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <tr>
                <th scope="row">
                  <label htmlFor="conn-key">{data.apiKeyLabel}</label>
                </th>
                <td>
                  <input
                    id="conn-key"
                    className="regular-text"
                    type="password"
                    autoComplete="off"
                    placeholder={
                      data.apiKeyMasked
                        ? `Saved: ${data.apiKeyMasked} — enter a new key to replace`
                        : data.apiKeyPlaceholder
                    }
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                  />
                  <p className="description">
                    Stored on this site for Beekiri agents.{' '}
                    <a href={data.docsUrl} target="_blank" rel="noreferrer">
                      Get an API key
                    </a>
                  </p>
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="conn-model">Default model</label>
                </th>
                <td>
                  <select
                    id="conn-model"
                    value={defaultModel}
                    onChange={(e) => setDefaultModel(e.target.value)}
                  >
                    {data.models.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.label}
                      </option>
                    ))}
                  </select>
                  <p className="description">Used when BeeQuens and other agents call {data.name}.</p>
                </td>
              </tr>
            </tbody>
          </table>
          <p className="submit">
            <button type="submit" className="button button-primary" disabled={busy}>
              {busy ? 'Saving…' : 'Save setup'}
            </button>
          </p>
        </div>
      </form>
    </div>
  );
}
