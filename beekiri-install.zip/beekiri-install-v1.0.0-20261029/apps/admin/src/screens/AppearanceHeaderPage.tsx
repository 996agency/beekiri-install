import { AppearanceChromePage } from './AppearanceChromePage';

export function AppearanceHeaderPage() {
  return <AppearanceChromePage kind="header" />;
}
