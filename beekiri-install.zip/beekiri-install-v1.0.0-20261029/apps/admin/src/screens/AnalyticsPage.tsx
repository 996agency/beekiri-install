import { FormEvent, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import './analytics-page.css';

type Range = 'today' | '7d' | '30d' | '90d' | 'all';
type Source = 'beekiri' | 'google';

type Kpi = { value: number; prev: number; deltaPct: number | null };

type Report = {
  source: Source;
  range: Range;
  tracking: { enabled: boolean; pageViews: boolean };
  live: number;
  generatedAt: string;
  kpis: {
    users: Kpi;
    newUsers: Kpi;
    sessions: Kpi;
    views: Kpi;
    viewsPerSession: Kpi;
    bounceRate: Kpi;
    avgDurationSec: Kpi;
    engagedSessions: Kpi;
  };
  trend: { date: string; users: number; sessions: number; views: number }[];
  pages: { path: string; views: number; users: number }[];
  landing: { path: string; sessions: number }[];
  exits: { path: string; sessions: number }[];
  sources: { name: string; sessions: number }[];
  channels: { name: string; sessions: number }[];
  countries: { code: string; users: number }[];
  devices: { key: string; users: number }[];
  browsers: { name: string; users: number }[];
  os: { name: string; users: number }[];
};

type LivePayload = {
  live: number;
  paths: { path: string; secondsAgo: number }[];
  generatedAt: string;
};

const LIVE_POLL_MS = 8_000;
const REPORT_POLL_MS = 20_000;

type GaSettings = {
  measurementId: string;
  propertyId: string;
  connected: boolean;
  clientEmail: string;
};

const RANGES: { value: Range; label: string }[] = [
  { value: 'today', label: 'Today' },
  { value: '7d', label: '7 days' },
  { value: '30d', label: '30 days' },
  { value: '90d', label: '90 days' },
  { value: 'all', label: 'All time' },
];

function pageLabel(path: string) {
  if (!path || path === '/' || path === '(not set)') return 'Home';
  return path;
}

function titleCase(key: string) {
  return key ? key[0].toUpperCase() + key.slice(1) : key;
}

function flagEmoji(code: string) {
  if (!/^[A-Z]{2}$/.test(code)) return '';
  return String.fromCodePoint(...[...code].map((c) => 127397 + c.charCodeAt(0)));
}

function countryName(code: string) {
  if (!code || code === 'Unknown' || code === '(not set)') return 'Not detected';
  if (!/^[A-Z]{2}$/.test(code)) return code;
  try {
    return new Intl.DisplayNames(['en'], { type: 'region' }).of(code) || code;
  } catch {
    return code;
  }
}

function formatDuration(sec: number) {
  if (!sec) return '0s';
  const m = Math.floor(sec / 60);
  const s = Math.round(sec % 60);
  if (m >= 60) return `${Math.floor(m / 60)}h ${m % 60}m`;
  if (m) return `${m}m ${s}s`;
  return `${s}s`;
}

function formatKpi(key: keyof Report['kpis'], value: number) {
  if (key === 'bounceRate') return `${value}%`;
  if (key === 'avgDurationSec') return formatDuration(value);
  if (key === 'viewsPerSession') return value.toFixed(1);
  return Intl.NumberFormat('en-GB').format(value);
}

type LiveSample = { at: number; users: number };

const LIVE_WINDOW_MS = 30 * 60_000;
const LIVE_STEP_MS = 60_000;
const LIVE_CHART_BLUE = '#1a73e8';
const LIVE_CHART_FILL = 'rgba(26, 115, 232, 0.16)';

function formatClock(at: number) {
  return new Date(at).toLocaleTimeString(undefined, {
    hour: 'numeric',
    minute: '2-digit',
  });
}

function niceCeiling(n: number) {
  if (n <= 2) return 2;
  if (n <= 4) return 4;
  if (n <= 6) return 6;
  if (n <= 8) return 8;
  if (n <= 10) return 10;
  const pow = Math.pow(10, Math.floor(Math.log10(n)));
  return Math.ceil(n / pow) * pow;
}

/** One point per minute for the last 30 minutes; carry forward last known live count. */
function minuteSeries(samples: LiveSample[], now = Date.now()): LiveSample[] {
  const start = now - LIVE_WINDOW_MS;
  const sorted = [...samples].sort((a, b) => a.at - b.at);
  let si = 0;
  let last = 0;
  const out: LiveSample[] = [];
  for (let i = 0; i <= 30; i++) {
    const at = start + i * LIVE_STEP_MS;
    while (si < sorted.length && sorted[si]!.at <= at) {
      last = sorted[si]!.users;
      si += 1;
    }
    out.push({ at, users: last });
  }
  return out;
}

function LiveUsersChart({ samples }: { samples: LiveSample[] }) {
  const now = Date.now();
  const series = minuteSeries(samples, now);
  const w = 960;
  const h = 220;
  const pad = { t: 12, r: 16, b: 28, l: 36 };
  const innerW = w - pad.l - pad.r;
  const innerH = h - pad.t - pad.b;
  const maxUsers = Math.max(0, ...series.map((p) => p.users));
  const max = niceCeiling(maxUsers);
  const x = (i: number) => pad.l + (innerW * i) / Math.max(1, series.length - 1);
  const y = (v: number) => pad.t + innerH - (v / max) * innerH;
  const line = series.map((p, i) => `${i === 0 ? 'M' : 'L'}${x(i)} ${y(p.users)}`).join(' ');
  const area =
    series.length > 0
      ? `${line} L${x(series.length - 1)} ${y(0)} L${x(0)} ${y(0)} Z`
      : '';
  const yTicks = [max, Math.round(max * 0.75), Math.round(max * 0.5), Math.round(max * 0.25)].filter(
    (v, i, arr) => v > 0 && arr.indexOf(v) === i,
  );
  const xTicks = series.filter((_, i) => i % 5 === 0);

  return (
    <svg
      className="bk-an__svg"
      viewBox={`0 0 ${w} ${h}`}
      role="img"
      aria-label="Active users in last 30 minutes"
    >
      {yTicks.map((tick) => (
        <text
          key={`y-${tick}`}
          x={pad.l - 10}
          y={y(tick) + 4}
          textAnchor="end"
          fontSize="11"
          fill="#8c8f94"
        >
          {tick}
        </text>
      ))}
      <path d={area} fill={LIVE_CHART_FILL} />
      <path
        d={line}
        fill="none"
        stroke={LIVE_CHART_BLUE}
        strokeWidth="2"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
      {xTicks.map((p) => {
        const i = series.indexOf(p);
        return (
          <text key={p.at} x={x(i)} y={h - 6} textAnchor="middle" fontSize="11" fill="#8c8f94">
            {formatClock(p.at)}
          </text>
        );
      })}
    </svg>
  );
}

const RANK_PREVIEW = 5;
const EXCLUDE_INTERNAL_KEY = 'beekiri.analytics.excludeInternal';

function isInternalTraffic(value: string) {
  const v = value.toLowerCase();
  return (
    v.includes('localhost') ||
    v.includes('127.0.0.1') ||
    v.includes('0.0.0.0') ||
    v.includes('auto-draft') ||
    v.includes('/draft') ||
    v.includes('preview=true') ||
    /[?&]preview=/.test(v)
  );
}

function liveAgo(secondsAgo: number) {
  if (secondsAgo < 5) return 'just now';
  if (secondsAgo < 60) return `${secondsAgo}s ago`;
  return `${Math.floor(secondsAgo / 60)}m ago`;
}

type RankRow = { key: string; label: string; n: number; share?: string };

type RankTab = {
  id: string;
  label: string;
  dim: string;
  metric: string;
  noun: string;
  rows: RankRow[];
  empty?: string;
};

function AnalyticsRankCard({
  tabs,
  ariaLabel,
}: {
  tabs: RankTab[];
  ariaLabel: string;
}) {
  const [tabId, setTabId] = useState(tabs[0]?.id ?? '');
  const [expanded, setExpanded] = useState(false);
  const active = tabs.find((t) => t.id === tabId) ?? tabs[0];
  if (!active) return null;
  const rows = active.rows;
  const total = rows.reduce((sum, r) => sum + r.n, 0);
  const visible = expanded ? rows : rows.slice(0, RANK_PREVIEW);
  const hidden = Math.max(0, rows.length - RANK_PREVIEW);

  return (
    <section className="bk-an-pages">
      <div className="bk-an-pages__tabs" role="tablist" aria-label={ariaLabel}>
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={active.id === t.id}
            className={active.id === t.id ? 'is-active' : undefined}
            onClick={() => {
              setTabId(t.id);
              setExpanded(false);
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="bk-an-pages__cols" aria-hidden>
        <span>{active.dim}</span>
        <span>
          {active.metric} · Share
        </span>
      </div>

      {rows.length ? (
        <ul className="bk-an-pages__list" role="tabpanel">
          {visible.map((r) => {
            const share =
              r.share ??
              (total > 0 ? `${Math.round((r.n / total) * 100)}%` : '0%');
            return (
              <li key={r.key}>
                <span className="bk-an-pages__label">{r.label}</span>
                <span className="bk-an-pages__meta">
                  <b>{r.n}</b>
                  <em>{share}</em>
                </span>
              </li>
            );
          })}
        </ul>
      ) : (
        <p className="bk-an__empty bk-an-pages__empty">
          {active.empty ?? 'No data in this range.'}
        </p>
      )}

      {hidden > 0 ? (
        <button
          type="button"
          className="bk-an-pages__more"
          onClick={() => setExpanded((v) => !v)}
        >
          {expanded ? 'Show less' : `View all ${rows.length} ${active.noun}`}
        </button>
      ) : null}
    </section>
  );
}

const KPI_ORDER: Array<{ key: keyof Report['kpis']; label: string }> = [
  { key: 'users', label: 'Users' },
  { key: 'newUsers', label: 'New users' },
  { key: 'sessions', label: 'Sessions' },
  { key: 'views', label: 'Views' },
  { key: 'viewsPerSession', label: 'Views per session' },
  { key: 'bounceRate', label: 'Bounce rate' },
  { key: 'avgDurationSec', label: 'Avg. session duration' },
  { key: 'engagedSessions', label: 'Engaged sessions' },
];

export function AnalyticsPage() {
  const [range, setRange] = useState<Range>('30d');
  const [source, setSource] = useState<Source>('beekiri');
  const [report, setReport] = useState<Report | null>(null);
  const [live, setLive] = useState(0);
  const [livePaths, setLivePaths] = useState<LivePayload['paths']>([]);
  const [liveSeries, setLiveSeries] = useState<LiveSample[]>([]);
  const [updatedAt, setUpdatedAt] = useState<string | null>(null);
  const [ga, setGa] = useState<GaSettings | null>(null);
  const [connectOpen, setConnectOpen] = useState(false);
  const [form, setForm] = useState({ measurementId: '', propertyId: '', serviceAccountJson: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [excludeInternal, setExcludeInternal] = useState(() => {
    try {
      return window.localStorage.getItem(EXCLUDE_INTERNAL_KEY) === '1';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    api<GaSettings>('/api/analytics/settings')
      .then((s) => {
        setGa(s);
        setForm({
          measurementId: s.measurementId,
          propertyId: s.propertyId,
          serviceAccountJson: '',
        });
      })
      .catch((e) => setError(e instanceof ApiError ? e.message : 'Could not load Analytics.'));
  }, []);

  useEffect(() => {
    let cancelled = false;
    const loadReport = (soft: boolean) => {
      if (!soft) setError(null);
      api<Report>(`/api/analytics/report?range=${range}&source=${source}`)
        .then((data) => {
          if (cancelled) return;
          setReport(data);
          setLive(data.live ?? 0);
          setUpdatedAt(data.generatedAt);
          setLiveSeries((prev) =>
            prev.length ? prev : [{ at: Date.now(), users: data.live ?? 0 }],
          );
        })
        .catch((e) => {
          if (cancelled || soft) return;
          setReport(null);
          setError(e instanceof ApiError ? e.message : 'Could not load analytics.');
        });
    };
    loadReport(false);
    const onTick = () => {
      if (document.visibilityState === 'hidden') return;
      loadReport(true);
    };
    const id = window.setInterval(onTick, REPORT_POLL_MS);
    document.addEventListener('visibilitychange', onTick);
    return () => {
      cancelled = true;
      window.clearInterval(id);
      document.removeEventListener('visibilitychange', onTick);
    };
  }, [range, source]);

  useEffect(() => {
    let cancelled = false;
    const loadLive = () => {
      if (document.visibilityState === 'hidden') return;
      api<LivePayload>('/api/analytics/live')
        .then((data) => {
          if (cancelled) return;
          const at = Date.now();
          setLive(data.live);
          setLivePaths(data.paths);
          setUpdatedAt(data.generatedAt);
          setLiveSeries((prev) => {
            const next = [...prev, { at, users: data.live }];
            const cutoff = at - LIVE_WINDOW_MS;
            return next.filter((s) => s.at >= cutoff);
          });
        })
        .catch(() => {
          /* keep last live count */
        });
    };
    loadLive();
    const id = window.setInterval(loadLive, LIVE_POLL_MS);
    document.addEventListener('visibilitychange', loadLive);
    return () => {
      cancelled = true;
      window.clearInterval(id);
      document.removeEventListener('visibilitychange', loadLive);
    };
  }, []);

  const saveConnect = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const saved = await api<GaSettings>('/api/analytics/settings', {
        method: 'PATCH',
        json: form,
      });
      setGa(saved);
      setForm((f) => ({ ...f, serviceAccountJson: '' }));
      setNotice('Google Analytics connection saved.');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Save failed');
    } finally {
      setBusy(false);
    }
  };

  const trackingOff = report && (!report.tracking.enabled || !report.tracking.pageViews);

  const kpis = useMemo(() => report?.kpis, [report]);

  const filtered = useMemo(() => {
    if (!report) return null;
    const keepPath = (path: string) => !excludeInternal || !isInternalTraffic(path);
    const keepName = (name: string) => !excludeInternal || !isInternalTraffic(name);
    return {
      pages: report.pages.filter((r) => keepPath(r.path)),
      landing: report.landing.filter((r) => keepPath(r.path)),
      exits: (report.exits ?? []).filter((r) => keepPath(r.path)),
      channels: report.channels ?? [],
      sources: report.sources.filter((r) => keepName(r.name)),
      countries: report.countries,
      browsers: report.browsers ?? [],
      os: report.os ?? [],
      devices: report.devices,
      livePaths: livePaths.filter((r) => keepPath(r.path)),
    };
  }, [report, livePaths, excludeInternal]);

  function toggleExcludeInternal() {
    setExcludeInternal((prev) => {
      const next = !prev;
      try {
        window.localStorage.setItem(EXCLUDE_INTERNAL_KEY, next ? '1' : '0');
      } catch {
        /* ignore */
      }
      return next;
    });
  }

  return (
    <div className="bk-an">
      <PageHeader
        title="Analytics"
        actions={
          <div className="bk-an__tools">
            <div className="bk-an__seg" role="group" aria-label="Data source">
              <button
                type="button"
                className={source === 'beekiri' ? 'is-active' : ''}
                onClick={() => setSource('beekiri')}
              >
                Beekiri
              </button>
              <button
                type="button"
                className={source === 'google' ? 'is-active' : ''}
                onClick={() => setSource('google')}
                disabled={!ga?.connected}
                title={ga?.connected ? 'Google Analytics 4' : 'Connect Google Analytics first'}
              >
                Google Analytics
              </button>
            </div>
            <div className="bk-an__seg" role="group" aria-label="Date range">
              {RANGES.map((r) => (
                <button
                  key={r.value}
                  type="button"
                  className={range === r.value ? 'is-active' : ''}
                  onClick={() => setRange(r.value)}
                >
                  {r.label}
                </button>
              ))}
            </div>
            <button type="button" className="button" onClick={() => setConnectOpen((open) => !open)}>
              {ga?.connected ? 'Google connection' : 'Connect Google Analytics'}
            </button>
          </div>
        }
      />

      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}
      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}

      <div className="bk-an__live" aria-live="polite">
        <span className={`bk-an__live-dot${live > 0 ? ' is-on' : ''}`} aria-hidden />
        <strong>{live}</strong>
        <span>{live === 1 ? 'user live now' : 'users live now'}</span>
        {updatedAt ? (
          <em>
            Updates live
            {source === 'beekiri' ? ' · Beekiri' : ' · Google report + Beekiri live'}
          </em>
        ) : null}
      </div>

      {trackingOff && source === 'beekiri' ? (
        <p className="bk-an__banner">
          Beekiri records visits only after a visitor accepts analytics cookies.{' '}
          <Link to="/admin/analytics/cookies">Turn on BeeCookies</Link> to collect this
          report.
        </p>
      ) : null}

      {connectOpen ? (
        <form className="bk-an-connect" onSubmit={(e) => void saveConnect(e)}>
          <h2>Google Analytics</h2>
          <p>
            Optional. Add a GA4 measurement ID to send consented visits to Google, and a property
            plus service account if you want Google’s numbers in this report.
          </p>
          <table className="form-table">
            <tbody>
              <tr>
                <th scope="row">
                  <label htmlFor="ga-mid">Measurement ID</label>
                </th>
                <td>
                  <input
                    id="ga-mid"
                    className="regular-text"
                    placeholder="G-XXXXXXXX"
                    value={form.measurementId}
                    onChange={(e) => setForm({ ...form, measurementId: e.target.value })}
                  />
                  <p className="description">
                    Loaded on the public site only after analytics cookies are accepted.
                  </p>
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="ga-prop">Property ID</label>
                </th>
                <td>
                  <input
                    id="ga-prop"
                    className="regular-text"
                    placeholder="123456789"
                    value={form.propertyId}
                    onChange={(e) => setForm({ ...form, propertyId: e.target.value })}
                  />
                  <p className="description">Numeric GA4 property ID, not the G- measurement ID.</p>
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="ga-sa">Service account</label>
                </th>
                <td>
                  <textarea
                    id="ga-sa"
                    className="large-text"
                    placeholder={
                      ga?.clientEmail
                        ? `Connected as ${ga.clientEmail}. Paste a new JSON key to replace it.`
                        : 'Paste the service account JSON key'
                    }
                    value={form.serviceAccountJson}
                    onChange={(e) => setForm({ ...form, serviceAccountJson: e.target.value })}
                  />
                  <p className="description">
                    Create a service account in Google Cloud, download its JSON key, and add it as a
                    Viewer on the GA4 property. The key is stored on this site and never shown
                    again.
                  </p>
                </td>
              </tr>
            </tbody>
          </table>
          <p className="submit">
            <button type="submit" className="button button-primary" disabled={busy}>
              {busy ? 'Saving…' : 'Save connection'}
            </button>
          </p>
        </form>
      ) : null}

      {kpis ? (
        <div className="bk-an__kpis">
          {KPI_ORDER.map(({ key, label }) => {
            const item = kpis[key];
            const delta = item.deltaPct;
            const deltaClass =
              delta === null || delta === 0 ? 'is-flat' : delta > 0 ? 'is-up' : 'is-down';
            const deltaLabel =
              delta === null ? 'No prior period' : `${delta > 0 ? '+' : ''}${delta}%`;
            return (
              <div key={key} className="bk-an__kpi">
                <span>{label}</span>
                <strong>{formatKpi(key, item.value)}</strong>
                {range !== 'all' ? <em className={deltaClass}>{deltaLabel}</em> : null}
              </div>
            );
          })}
        </div>
      ) : (
        <p className="bk-an__empty">Loading analytics…</p>
      )}

      {report ? (
        <>
          <div className="bk-an__chart">
            <div className="bk-an__chart-head">
              <h2>Active users in last 30 minutes</h2>
            </div>
            <LiveUsersChart samples={liveSeries} />
          </div>

          {filtered ? (
            <div className="bk-an__pair">
              <AnalyticsRankCard
                ariaLabel="Page traffic"
                tabs={[
                  {
                    id: 'pages',
                    label: 'Pages',
                    dim: 'Page',
                    metric: 'Views',
                    noun: 'pages',
                    rows: filtered.pages.map((r) => ({
                      key: r.path,
                      label: pageLabel(r.path),
                      n: r.views,
                    })),
                  },
                  {
                    id: 'landing',
                    label: 'Landing',
                    dim: 'Page',
                    metric: 'Sessions',
                    noun: 'landing pages',
                    rows: filtered.landing.map((r) => ({
                      key: r.path,
                      label: pageLabel(r.path),
                      n: r.sessions,
                    })),
                  },
                  {
                    id: 'exits',
                    label: 'Exit pages',
                    dim: 'Page',
                    metric: 'Sessions',
                    noun: 'exit pages',
                    rows: filtered.exits.map((r) => ({
                      key: r.path,
                      label: pageLabel(r.path),
                      n: r.sessions,
                    })),
                  },
                ]}
              />

              <div className="bk-an__pair-stack">
                <AnalyticsRankCard
                  ariaLabel="Acquisition"
                  tabs={[
                    {
                      id: 'channels',
                      label: 'Channels',
                      dim: 'Channel',
                      metric: 'Sessions',
                      noun: 'channels',
                      rows: filtered.channels.map((r) => ({
                        key: r.name,
                        label: r.name,
                        n: r.sessions,
                      })),
                    },
                    {
                      id: 'referrers',
                      label: 'Referrers',
                      dim: 'Referrer',
                      metric: 'Sessions',
                      noun: 'referrers',
                      rows: filtered.sources.map((r) => ({
                        key: r.name,
                        label: r.name,
                        n: r.sessions,
                      })),
                    },
                  ]}
                />

                <AnalyticsRankCard
                  ariaLabel="Audience"
                  tabs={[
                    {
                      id: 'country',
                      label: 'Country',
                      dim: 'Country',
                      metric: 'Users',
                      noun: 'countries',
                      rows: filtered.countries.map((r) => ({
                        key: r.code,
                        label: `${flagEmoji(r.code) ? `${flagEmoji(r.code)} ` : ''}${countryName(r.code)}`,
                        n: r.users,
                      })),
                    },
                    {
                      id: 'browser',
                      label: 'Browser',
                      dim: 'Browser',
                      metric: 'Users',
                      noun: 'browsers',
                      rows: filtered.browsers.map((r) => ({
                        key: r.name,
                        label: r.name,
                        n: r.users,
                      })),
                    },
                    {
                      id: 'os',
                      label: 'OS',
                      dim: 'OS',
                      metric: 'Users',
                      noun: 'operating systems',
                      rows: filtered.os.map((r) => ({
                        key: r.name,
                        label: r.name,
                        n: r.users,
                      })),
                    },
                    {
                      id: 'device',
                      label: 'Device',
                      dim: 'Device',
                      metric: 'Users',
                      noun: 'devices',
                      rows: filtered.devices.map((r) => ({
                        key: r.key,
                        label: titleCase(r.key),
                        n: r.users,
                      })),
                    },
                    {
                      id: 'live',
                      label: 'Live right now',
                      dim: 'Page',
                      metric: 'Active',
                      noun: 'visitors',
                      empty: 'No active visitors in the last 5 minutes.',
                      rows: filtered.livePaths.map((r, i) => ({
                        key: `${r.path}-${i}`,
                        label: pageLabel(r.path),
                        n: Math.max(1, 300 - r.secondsAgo),
                        share: liveAgo(r.secondsAgo),
                      })),
                    },
                  ]}
                />
              </div>
            </div>
          ) : null}

          <label className="bk-an__exclude">
            <input
              type="checkbox"
              checked={excludeInternal}
              onChange={toggleExcludeInternal}
            />
            <span>Exclude internal traffic (localhost, auto-draft pages)</span>
          </label>
        </>
      ) : null}
    </div>
  );
}
