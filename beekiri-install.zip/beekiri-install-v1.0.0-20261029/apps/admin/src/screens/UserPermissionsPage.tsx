import { useCallback, useEffect, useMemo, useState } from 'react';
import type { CapabilitySlug, RoleSlug } from '../cms-types';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import './user-permissions-page.css';

type CatalogItem = {
  slug: CapabilitySlug;
  label: string;
  description: string;
  group: string;
};

type PermUser = {
  id: string;
  username: string;
  displayName: string;
  email: string;
  role: RoleSlug;
  roleLabel: string;
  isOwner: boolean;
  roleDefaults: CapabilitySlug[];
  grants: CapabilitySlug[];
  denies: CapabilitySlug[];
  capabilities: CapabilitySlug[];
};

type RoleDef = {
  slug: RoleSlug;
  name: string;
  capabilities: CapabilitySlug[];
  userCount: number;
  locked: boolean;
};

type Tab = 'people' | 'roles';

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

function groupCatalog(catalog: CatalogItem[]) {
  const order: string[] = [];
  const map = new Map<string, CatalogItem[]>();
  for (const item of catalog) {
    if (!map.has(item.group)) {
      map.set(item.group, []);
      order.push(item.group);
    }
    map.get(item.group)!.push(item);
  }
  return order.map((group) => ({ group, items: map.get(group)! }));
}

export function UserPermissionsPage() {
  const auth = useAuth();
  const isOwner = auth.user?.isOwner ?? false;
  const canEdit = isOwner;

  const [tab, setTab] = useState<Tab>('people');
  const [catalog, setCatalog] = useState<CatalogItem[]>([]);
  const [users, setUsers] = useState<PermUser[]>([]);
  const [roles, setRoles] = useState<RoleDef[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedRoleSlug, setSelectedRoleSlug] = useState<RoleSlug | null>(null);
  const [draft, setDraft] = useState<Set<CapabilitySlug>>(new Set());
  const [roleDraftCaps, setRoleDraftCaps] = useState<Set<CapabilitySlug>>(new Set());
  const [roleName, setRoleName] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const loadPeople = useCallback(async () => {
    const res = await api<{ catalog: CatalogItem[]; users: PermUser[] }>(
      '/api/users/permissions',
    );
    setCatalog(res.catalog);
    setUsers(res.users);
    return res.users;
  }, []);

  const loadRoles = useCallback(async () => {
    const res = await api<{ catalog: CatalogItem[]; roles: RoleDef[] }>(
      '/api/users/roles/manage',
    );
    setCatalog(res.catalog);
    setRoles(res.roles);
    return res.roles;
  }, []);

  useEffect(() => {
    if (!isOwner) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    Promise.all([loadPeople(), loadRoles()])
      .then(([people, roleList]) => {
        setSelectedId((prev) => {
          if (prev && people.some((u) => u.id === prev)) return prev;
          return people[0]?.id ?? null;
        });
        setSelectedRoleSlug((prev) => {
          if (prev && roleList.some((r) => r.slug === prev)) return prev;
          return roleList[0]?.slug ?? null;
        });
      })
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [isOwner, loadPeople, loadRoles]);

  const selected = useMemo(
    () => users.find((u) => u.id === selectedId) ?? null,
    [users, selectedId],
  );

  const selectedRole = useMemo(
    () => roles.find((r) => r.slug === selectedRoleSlug) ?? null,
    [roles, selectedRoleSlug],
  );

  useEffect(() => {
    if (!selected) {
      setDraft(new Set());
      return;
    }
    setDraft(new Set(selected.capabilities));
  }, [selected]);

  useEffect(() => {
    if (!selectedRole) {
      setRoleDraftCaps(new Set());
      setRoleName('');
      return;
    }
    setRoleDraftCaps(new Set(selectedRole.capabilities));
    setRoleName(selectedRole.name);
  }, [selectedRole]);

  const groups = useMemo(() => groupCatalog(catalog), [catalog]);

  const peopleDirty = useMemo(() => {
    if (!selected || selected.isOwner) return false;
    const a = [...draft].sort().join(',');
    const b = [...selected.capabilities].sort().join(',');
    return a !== b;
  }, [draft, selected]);

  const roleDirty = useMemo(() => {
    if (!selectedRole) return false;
    const nameChanged = roleName.trim() !== selectedRole.name;
    const a = [...roleDraftCaps].sort().join(',');
    const b = [...selectedRole.capabilities].sort().join(',');
    return nameChanged || a !== b;
  }, [roleDraftCaps, roleName, selectedRole]);

  const switchTab = (next: Tab) => {
    if (next === tab) return;
    const dirty = tab === 'people' ? peopleDirty : roleDirty;
    if (dirty && !window.confirm('Discard unsaved changes?')) return;
    setTab(next);
    setNotice(null);
    setError(null);
  };

  const selectUser = (id: string) => {
    if (peopleDirty && !window.confirm('Discard unsaved permission changes?')) return;
    setSelectedId(id);
    setNotice(null);
    setError(null);
  };

  const selectRole = (slug: RoleSlug) => {
    if (roleDirty && !window.confirm('Discard unsaved role changes?')) return;
    setSelectedRoleSlug(slug);
    setNotice(null);
    setError(null);
  };

  const toggleCap = (slug: CapabilitySlug) => {
    if (!selected || selected.isOwner || !canEdit || slug === 'read') return;
    setDraft((prev) => {
      const next = new Set(prev);
      if (next.has(slug)) next.delete(slug);
      else next.add(slug);
      next.add('read');
      return next;
    });
  };

  const toggleRoleCap = (slug: CapabilitySlug) => {
    if (!selectedRole || !canEdit || slug === 'read') return;
    if (
      selectedRole.slug === 'administrator' &&
      (slug === 'manage_options' ||
        slug === 'list_users' ||
        slug === 'edit_users' ||
        slug === 'create_users')
    ) {
      return;
    }
    setRoleDraftCaps((prev) => {
      const next = new Set(prev);
      if (next.has(slug)) next.delete(slug);
      else next.add(slug);
      next.add('read');
      return next;
    });
  };

  const resetToRole = () => {
    if (!selected || selected.isOwner) return;
    setDraft(new Set(selected.roleDefaults));
  };

  const resetRoleCaps = () => {
    if (!selectedRole) return;
    setRoleDraftCaps(new Set(selectedRole.capabilities));
    setRoleName(selectedRole.name);
  };

  const savePeople = async () => {
    if (!selected || selected.isOwner || !canEdit) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const updated = await api<PermUser>(`/api/users/${selected.id}/permissions`, {
        method: 'PATCH',
        json: { capabilities: [...draft] },
      });
      setUsers((list) => list.map((u) => (u.id === updated.id ? updated : u)));
      setNotice(`Permissions saved for ${updated.username}.`);
      if (updated.id === auth.user?.id) await auth.refresh();
      await loadRoles();
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const saveRole = async () => {
    if (!selectedRole || !canEdit) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const updated = await api<{ slug: RoleSlug; name: string; capabilities: CapabilitySlug[] }>(
        `/api/users/roles/${selectedRole.slug}`,
        {
          method: 'PATCH',
          json: {
            name: roleName.trim(),
            capabilities: [...roleDraftCaps],
          },
        },
      );
      setRoles((list) =>
        list.map((r) =>
          r.slug === updated.slug
            ? { ...r, name: updated.name, capabilities: updated.capabilities }
            : r,
        ),
      );
      setNotice(`Role “${updated.name}” saved. Applies to everyone with that role.`);
      const people = await loadPeople();
      setUsers(people);
      if (auth.user?.role === updated.slug) await auth.refresh();
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  if (!isOwner) {
    return (
      <div className="wrap">
        <PageHeader title="User Permissions" />
        <div className="beekiri-notice is-error" role="alert">
          <p>Only the site Owner can manage user permissions.</p>
        </div>
      </div>
    );
  }

  const headerActions =
    tab === 'people' && selected && !selected.isOwner && canEdit ? (
      <>
        <button type="button" className="button" disabled={busy} onClick={resetToRole}>
          Reset to role defaults
        </button>
        <button
          type="button"
          className="button button-primary"
          disabled={busy || !peopleDirty}
          onClick={() => void savePeople()}
        >
          {busy ? 'Saving…' : 'Save permissions'}
        </button>
      </>
    ) : tab === 'roles' && selectedRole && canEdit ? (
      <>
        <button type="button" className="button" disabled={busy} onClick={resetRoleCaps}>
          Discard changes
        </button>
        <button
          type="button"
          className="button button-primary"
          disabled={busy || !roleDirty || !roleName.trim()}
          onClick={() => void saveRole()}
        >
          {busy ? 'Saving…' : 'Save role'}
        </button>
      </>
    ) : null;

  return (
    <div className="wrap wrap--wide bk-perm">
      <PageHeader title="User Permissions" actions={headerActions} />
      <p className="bk-muted">
        Set what each <strong>role</strong> can do globally, then override individual people when
        needed. The site Owner always has full privileges.
      </p>

      <nav className="bk-perm__tabs" aria-label="Permissions sections">
        <button
          type="button"
          className={`bk-perm__tab${tab === 'people' ? ' is-active' : ''}`}
          aria-current={tab === 'people' ? 'page' : undefined}
          onClick={() => switchTab('people')}
        >
          People
        </button>
        <button
          type="button"
          className={`bk-perm__tab${tab === 'roles' ? ' is-active' : ''}`}
          aria-current={tab === 'roles' ? 'page' : undefined}
          onClick={() => switchTab('roles')}
        >
          Roles
        </button>
      </nav>

      {error ? (
        <div className="beekiri-notice is-error bk-perm__notice" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      {loading ? <p className="bk-muted bk-perm__empty">Loading permissions…</p> : null}

      {!loading && tab === 'people' && users.length === 0 ? (
        <p className="bk-muted bk-perm__empty">No users to manage yet. Add a user first.</p>
      ) : null}

      {!loading && tab === 'people' && users.length > 0 ? (
        <div className="bk-perm__layout">
          <aside className="bk-perm__users" aria-label="Users">
            <h2 className="bk-perm__side-title">People</h2>
            <ul className="bk-perm__user-list">
              {users.map((u) => {
                const active = u.id === selectedId;
                return (
                  <li key={u.id}>
                    <button
                      type="button"
                      className={`bk-perm__user${active ? ' is-active' : ''}`}
                      onClick={() => selectUser(u.id)}
                    >
                      <span className="bk-perm__user-name">
                        {u.displayName || u.username}
                        {u.id === auth.user?.id ? (
                          <span className="bk-table__badge">You</span>
                        ) : null}
                        {u.isOwner ? (
                          <span className="bk-table__badge is-accent">Owner</span>
                        ) : null}
                      </span>
                      <span className="bk-perm__user-meta">
                        @{u.username} · {u.roleLabel}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </aside>

          <section className="bk-perm__detail" aria-live="polite">
            {!selected ? (
              <p className="bk-muted bk-perm__empty">Select a user to manage permissions.</p>
            ) : (
              <>
                <header className="bk-perm__detail-head">
                  <div>
                    <h2>
                      {selected.displayName || selected.username}
                      {selected.isOwner ? (
                        <span className="bk-table__badge is-accent">Owner</span>
                      ) : null}
                    </h2>
                    <p>
                      Role: <strong>{selected.roleLabel}</strong>
                      {selected.isOwner
                        ? ' — full privileges (locked)'
                        : ' — toggles below override that role’s defaults'}
                    </p>
                  </div>
                </header>

                {selected.isOwner ? (
                  <p className="bk-perm__banner" role="status">
                    Owner accounts always have every capability. These switches stay on.
                  </p>
                ) : null}

                <div className="bk-perm__groups">
                  {groups.map(({ group, items }) => (
                    <section key={group} className="bk-perm__group">
                      <h3>{group}</h3>
                      <ul className="bk-perm__list">
                        {items.map((item) => {
                          const checked = draft.has(item.slug);
                          const fromRole = selected.roleDefaults.includes(item.slug);
                          const locked =
                            selected.isOwner || !canEdit || item.slug === 'read';
                          const override =
                            !selected.isOwner && fromRole !== checked
                              ? checked
                                ? 'Added'
                                : 'Removed'
                              : null;
                          return (
                            <li key={item.slug}>
                              <div
                                className={`bk-perm__row${locked ? ' is-locked' : ''}${
                                  checked ? ' is-on' : ''
                                }`}
                              >
                                <div className="bk-perm__row-text">
                                  <strong>
                                    {item.label}
                                    {override ? (
                                      <span className="bk-perm__override">{override}</span>
                                    ) : null}
                                  </strong>
                                  <em>{item.description}</em>
                                </div>
                                <button
                                  type="button"
                                  role="switch"
                                  aria-checked={checked}
                                  aria-label={item.label}
                                  disabled={locked}
                                  className={`bk-acf-toggle${checked ? ' is-on' : ''}`}
                                  onClick={() => toggleCap(item.slug)}
                                >
                                  <span />
                                </button>
                              </div>
                            </li>
                          );
                        })}
                      </ul>
                    </section>
                  ))}
                </div>
              </>
            )}
          </section>
        </div>
      ) : null}

      {!loading && tab === 'roles' ? (
        <div className="bk-perm__layout">
          <aside className="bk-perm__users" aria-label="Roles">
            <h2 className="bk-perm__side-title">Roles</h2>
            <ul className="bk-perm__user-list">
              {roles.map((r) => {
                const active = r.slug === selectedRoleSlug;
                return (
                  <li key={r.slug}>
                    <button
                      type="button"
                      className={`bk-perm__user${active ? ' is-active' : ''}`}
                      onClick={() => selectRole(r.slug)}
                    >
                      <span className="bk-perm__user-name">{r.name}</span>
                      <span className="bk-perm__user-meta">
                        {r.slug}
                        {' · '}
                        {r.userCount} {r.userCount === 1 ? 'user' : 'users'}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </aside>

          <section className="bk-perm__detail" aria-live="polite">
            {!selectedRole ? (
              <p className="bk-muted bk-perm__empty">Select a role to edit.</p>
            ) : (
              <>
                <header className="bk-perm__detail-head">
                  <div>
                    <h2>{selectedRole.name}</h2>
                    <p>
                      Slug <code>{selectedRole.slug}</code> stays the same — change the display name
                      below. Defaults apply to every user with this role; People tab can still
                      override one person.
                    </p>
                  </div>
                </header>

                <div className="bk-perm__role-name">
                  <label htmlFor="role_display_name">Display name</label>
                  <input
                    id="role_display_name"
                    className="regular-text"
                    type="text"
                    maxLength={80}
                    value={roleName}
                    disabled={!canEdit || busy}
                    onChange={(e) => setRoleName(e.target.value)}
                    placeholder="e.g. Writer"
                  />
                  <p className="description">
                    Shown in user forms and the people list — e.g. rename Contributor to Writer.
                  </p>
                </div>

                {selectedRole.locked ? (
                  <p className="bk-perm__banner" role="status">
                    Administrator keeps core site-management capabilities so the site stays
                    manageable. You can still rename it and adjust optional caps.
                  </p>
                ) : null}

                <div className="bk-perm__groups">
                  {groups.map(({ group, items }) => (
                    <section key={group} className="bk-perm__group">
                      <h3>{group}</h3>
                      <ul className="bk-perm__list">
                        {items.map((item) => {
                          const checked = roleDraftCaps.has(item.slug);
                          const adminLocked =
                            selectedRole.slug === 'administrator' &&
                            (item.slug === 'read' ||
                              item.slug === 'manage_options' ||
                              item.slug === 'list_users' ||
                              item.slug === 'edit_users' ||
                              item.slug === 'create_users');
                          const locked = !canEdit || item.slug === 'read' || adminLocked;
                          return (
                            <li key={item.slug}>
                              <div
                                className={`bk-perm__row${locked ? ' is-locked' : ''}${
                                  checked ? ' is-on' : ''
                                }`}
                              >
                                <div className="bk-perm__row-text">
                                  <strong>{item.label}</strong>
                                  <em>{item.description}</em>
                                </div>
                                <button
                                  type="button"
                                  role="switch"
                                  aria-checked={checked}
                                  aria-label={item.label}
                                  disabled={locked}
                                  className={`bk-acf-toggle${checked ? ' is-on' : ''}`}
                                  onClick={() => toggleRoleCap(item.slug)}
                                >
                                  <span />
                                </button>
                              </div>
                            </li>
                          );
                        })}
                      </ul>
                    </section>
                  ))}
                </div>
              </>
            )}
          </section>
        </div>
      ) : null}
    </div>
  );
}
