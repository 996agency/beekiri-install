import { useMemo, useState } from 'react';

export type MediaFolder = {
  id: string;
  name: string;
  /** Auto-generated; unique among siblings. Not shown in the UI. */
  slug: string;
  /** null = top-level folder */
  parentId: string | null;
};

export type MediaSettings = {
  convertToWebp: boolean;
  webpLossless: boolean;
  webpQuality: number;
  maxWidth: number;
  maxHeight: number;
  stripMetadata: boolean;
  keepOriginal: boolean;
  folders: MediaFolder[];
};

type Props = {
  media: MediaSettings;
  busy: boolean;
  onSave: (media: MediaSettings) => void;
};

function uid() {
  return `folder-${Math.random().toString(36).slice(2, 9)}`;
}

function toSlug(label: string): string {
  return label
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .replace(/-{2,}/g, '-');
}

/** Unique slug among siblings so nested paths never collide. */
function uniqueSlug(name: string, siblings: MediaFolder[]): string {
  const base = toSlug(name) || 'folder';
  const taken = new Set(siblings.map((s) => s.slug));
  if (!taken.has(base)) return base;
  let n = 2;
  while (taken.has(`${base}-${n}`)) n += 1;
  return `${base}-${n}`;
}

function normalizeFolders(folders: MediaFolder[]): MediaFolder[] {
  return folders.map((f) => ({
    ...f,
    parentId: f.parentId ?? null,
  }));
}

type TreeNode = MediaFolder & { children: TreeNode[] };

function buildTree(folders: MediaFolder[]): TreeNode[] {
  const byParent = new Map<string | null, MediaFolder[]>();
  for (const f of folders) {
    const key = f.parentId;
    const list = byParent.get(key) ?? [];
    list.push(f);
    byParent.set(key, list);
  }
  const walk = (parentId: string | null): TreeNode[] =>
    (byParent.get(parentId) ?? []).map((f) => ({
      ...f,
      children: walk(f.id),
    }));
  return walk(null);
}

/** Collect id + all descendant ids (for cascade remove). */
function collectDescendants(folders: MediaFolder[], rootId: string): Set<string> {
  const out = new Set<string>([rootId]);
  let grew = true;
  while (grew) {
    grew = false;
    for (const f of folders) {
      if (f.parentId && out.has(f.parentId) && !out.has(f.id)) {
        out.add(f.id);
        grew = true;
      }
    }
  }
  return out;
}

function FolderIcon() {
  return (
    <svg
      className="bk-ftree__icon"
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden
    >
      <path
        d="M3.5 7.5A1.5 1.5 0 0 1 5 6h4.2l1.4 1.6H19a1.5 1.5 0 0 1 1.5 1.5V18A1.5 1.5 0 0 1 19 19.5H5A1.5 1.5 0 0 1 3.5 18V7.5Z"
        fill="currentColor"
        opacity="0.88"
      />
    </svg>
  );
}

export function MediaSettingsPanel({ media: initial, busy, onSave }: Props) {
  const [media, setMedia] = useState<MediaSettings>(() => ({
    ...initial,
    folders: normalizeFolders(initial.folders),
  }));
  const [newName, setNewName] = useState('');
  /** When set, the next add goes under this parent. */
  const [addingUnder, setAddingUnder] = useState<string | null>(null);
  const [childName, setChildName] = useState('');
  const [collapsed, setCollapsed] = useState<Set<string>>(() => new Set());

  const patch = (partial: Partial<MediaSettings>) =>
    setMedia((m) => ({ ...m, ...partial }));

  const tree = useMemo(() => buildTree(media.folders), [media.folders]);

  const addFolder = (nameRaw: string, parentId: string | null) => {
    const name = nameRaw.trim();
    if (!name) return;
    const siblings = media.folders.filter((f) => f.parentId === parentId);
    const slug = uniqueSlug(name, siblings);
    patch({
      folders: [...media.folders, { id: uid(), name, slug, parentId }],
    });
  };

  const addRoot = () => {
    addFolder(newName, null);
    setNewName('');
  };

  const addChild = () => {
    if (!addingUnder) return;
    addFolder(childName, addingUnder);
    setChildName('');
    setAddingUnder(null);
  };

  const removeFolder = (id: string) => {
    const drop = collectDescendants(media.folders, id);
    patch({ folders: media.folders.filter((f) => !drop.has(f.id)) });
    if (addingUnder && drop.has(addingUnder)) {
      setAddingUnder(null);
      setChildName('');
    }
  };

  const toggleCollapse = (id: string) => {
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const renderNode = (node: TreeNode, depth: number) => {
    const hasKids = node.children.length > 0;
    const isCollapsed = collapsed.has(node.id);
    const isAdding = addingUnder === node.id;

    return (
      <li key={node.id} className="bk-ftree__item">
        <div
          className="bk-ftree__row"
          style={{ paddingLeft: 12 + depth * 18 }}
        >
          <button
            type="button"
            className="bk-ftree__twist"
            disabled={!hasKids}
            aria-label={isCollapsed ? 'Expand' : 'Collapse'}
            aria-expanded={hasKids ? !isCollapsed : undefined}
            onClick={() => hasKids && toggleCollapse(node.id)}
          >
            {hasKids ? (isCollapsed ? '▸' : '▾') : ''}
          </button>
          <FolderIcon />
          <div className="bk-ftree__main">
            <strong>{node.name}</strong>
            {hasKids ? (
              <span className="bk-ftree__meta">
                {node.children.length} subfolder{node.children.length === 1 ? '' : 's'}
              </span>
            ) : null}
          </div>
          <div className="bk-ftree__actions">
            <button
              type="button"
              className="button"
              onClick={() => {
                setAddingUnder(node.id);
                setChildName('');
              }}
            >
              Add inside
            </button>
            <button
              type="button"
              className="button"
              onClick={() => removeFolder(node.id)}
              aria-label={`Remove ${node.name}`}
            >
              Remove
            </button>
          </div>
        </div>

        {isAdding ? (
          <div
            className="bk-ftree__inline-add"
            style={{ paddingLeft: 12 + (depth + 1) * 18 }}
          >
            <FolderIcon />
            <input
              type="text"
              value={childName}
              placeholder={`Subfolder in ${node.name}`}
              autoFocus
              onChange={(e) => setChildName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  addChild();
                }
                if (e.key === 'Escape') {
                  setAddingUnder(null);
                  setChildName('');
                }
              }}
            />
            <button type="button" className="button button-primary" onClick={addChild}>
              Add
            </button>
            <button
              type="button"
              className="button"
              onClick={() => {
                setAddingUnder(null);
                setChildName('');
              }}
            >
              Cancel
            </button>
          </div>
        ) : null}

        {hasKids && !isCollapsed ? (
          <ul className="bk-ftree__list bk-ftree__list--nested">
            {node.children.map((child) => renderNode(child, depth + 1))}
          </ul>
        ) : null}
      </li>
    );
  };

  return (
    <div className="bk-stack">
      <section className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Image optimization</h2>
        </div>
        <div className="bk-panel__body">
          <p className="bk-muted" style={{ marginTop: 0 }}>
            Every upload is optimized automatically — resized to Full HD and converted to{' '}
            <strong>WebP</strong>, quality preserved. The Media library will use these rules.
          </p>

          <div className="bk-media-opts">
            <label className="bk-check">
              <input
                type="checkbox"
                checked={media.convertToWebp}
                onChange={(e) => patch({ convertToWebp: e.target.checked })}
              />
              <span className="bk-check__box" aria-hidden />
              <span className="bk-check__label">Convert all images to WebP on upload</span>
            </label>

            <label className="bk-check">
              <input
                type="checkbox"
                checked={media.webpLossless}
                disabled={!media.convertToWebp}
                onChange={(e) => patch({ webpLossless: e.target.checked })}
              />
              <span className="bk-check__box" aria-hidden />
              <span className="bk-check__label">
                Lossless WebP (no quality loss — recommended)
              </span>
            </label>

            {!media.webpLossless && media.convertToWebp ? (
              <div className="bk-field" style={{ maxWidth: 220 }}>
                <label htmlFor="webp_quality">WebP quality</label>
                <input
                  id="webp_quality"
                  type="number"
                  min={1}
                  max={100}
                  value={media.webpQuality}
                  onChange={(e) =>
                    patch({
                      webpQuality: Math.min(100, Math.max(1, Number(e.target.value) || 100)),
                    })
                  }
                />
                <p className="description">100 = highest quality when not using lossless.</p>
              </div>
            ) : null}

            <label className="bk-check">
              <input
                type="checkbox"
                checked={media.stripMetadata}
                onChange={(e) => patch({ stripMetadata: e.target.checked })}
              />
              <span className="bk-check__box" aria-hidden />
              <span className="bk-check__label">
                Strip EXIF / GPS metadata (smaller, more private)
              </span>
            </label>

            <label className="bk-check">
              <input
                type="checkbox"
                checked={media.keepOriginal}
                onChange={(e) => patch({ keepOriginal: e.target.checked })}
              />
              <span className="bk-check__box" aria-hidden />
              <span className="bk-check__label">Also keep the original file (uses more disk)</span>
            </label>
          </div>

          <div className="bk-media-dims">
            <div className="bk-field">
              <label htmlFor="media_max_w">Max width (px)</label>
              <input
                id="media_max_w"
                type="number"
                min={320}
                max={7680}
                value={media.maxWidth}
                onChange={(e) =>
                  patch({
                    maxWidth: Math.min(7680, Math.max(320, Number(e.target.value) || 1920)),
                  })
                }
              />
            </div>
            <div className="bk-field">
              <label htmlFor="media_max_h">Max height (px)</label>
              <input
                id="media_max_h"
                type="number"
                min={320}
                max={7680}
                value={media.maxHeight}
                onChange={(e) =>
                  patch({
                    maxHeight: Math.min(7680, Math.max(320, Number(e.target.value) || 1920)),
                  })
                }
              />
            </div>
          </div>
          <p className="description" style={{ marginTop: 8 }}>
            Default <strong>1920 × 1920</strong> = Full HD longest edge. Larger uploads are scaled
            down; smaller ones stay as-is. Never upscaled.
          </p>

          <div className="bk-help" style={{ marginTop: 16 }}>
            <strong>Pipeline:</strong> upload → resize to max Full HD → convert to WebP
            {media.webpLossless ? ' (lossless)' : ` (quality ${media.webpQuality})`}
            {media.stripMetadata ? ' → strip metadata' : ''} → store in a media folder.
          </div>
        </div>
      </section>

      <section className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Media folders</h2>
        </div>
        <div className="bk-panel__body">
          <p className="bk-muted" style={{ marginTop: 0 }}>
            Organize uploads in folders and subfolders. Paths are created automatically from the
            folder names — no slugs to manage.
          </p>

          {tree.length === 0 ? (
            <p className="bk-muted">No folders yet. Add one below.</p>
          ) : (
            <ul className="bk-ftree__list">{tree.map((node) => renderNode(node, 0))}</ul>
          )}

          <div className="bk-ftree__root-add">
            <FolderIcon />
            <div className="bk-field" style={{ flex: 1, margin: 0 }}>
              <label htmlFor="folder_name">New folder</label>
              <input
                id="folder_name"
                type="text"
                value={newName}
                placeholder="Products"
                onChange={(e) => setNewName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addRoot();
                  }
                }}
              />
            </div>
            <button type="button" className="button button-primary" onClick={addRoot}>
              Add folder
            </button>
          </div>
        </div>
      </section>

      <p className="submit" style={{ margin: 0 }}>
        <button
          type="button"
          className="button button-primary"
          disabled={busy}
          onClick={() => onSave(media)}
        >
          {busy ? 'Saving…' : 'Save media settings'}
        </button>
      </p>
    </div>
  );
}
