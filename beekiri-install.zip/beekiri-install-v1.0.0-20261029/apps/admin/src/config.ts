/** The website shares the admin's address (the admin lives at /admin). */
export const SITE_URL = window.location.origin;
