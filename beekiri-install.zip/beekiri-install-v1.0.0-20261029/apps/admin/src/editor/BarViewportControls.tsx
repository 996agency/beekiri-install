import { useEffect } from 'react';
import { createUseBeekiricanva } from '@beekiri/beekiricanva';
import { BEEKIRI_VIEWPORTS, viewportIcon } from './viewports';

const useBeekiricanva = createUseBeekiricanva();

/** Responsive viewport switcher for the Beekiri editor bar. */
export function BarViewportControls() {
  const dispatch = useBeekiricanva((s) => s.dispatch);
  const currentWidth = useBeekiricanva((s) => s.appState.ui.viewports.current.width);

  useEffect(() => {
    dispatch({
      type: 'setUi',
      ui: (ui) => ({
        viewports: {
          ...ui.viewports,
          controlsVisible: false,
        },
      }),
    });
  }, [dispatch]);

  const setViewport = (width: number | '100%', height: number | 'auto' = 'auto') => {
    dispatch({
      type: 'setUi',
      ui: (ui) => ({
        viewports: {
          ...ui.viewports,
          current: { width, height },
          controlsVisible: false,
        },
      }),
    });
  };

  return (
    <div className="bk-page-editor__viewports" role="group" aria-label="Viewport">
      {BEEKIRI_VIEWPORTS.map((vp) => {
        const active = currentWidth === vp.width;
        return (
          <button
            key={String(vp.width)}
            type="button"
            className={`bk-page-editor__icon-btn${active ? ' is-active' : ''}`}
            title={vp.label}
            aria-pressed={active}
            onClick={() => setViewport(vp.width, vp.height)}
          >
            {viewportIcon(vp.icon)}
          </button>
        );
      })}
    </div>
  );
}
