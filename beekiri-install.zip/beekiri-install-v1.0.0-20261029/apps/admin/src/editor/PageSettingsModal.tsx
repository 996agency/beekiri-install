import { useCallback, useEffect, useMemo, useState } from 'react';
import { api, ApiError } from '../api/client';
import { confirmDialog } from '../components/ConfirmDialog';
import type { PageRevisionRow, PageRow } from '../screens/PagesPage';
import { usePageEditorChrome } from './PageEditorChrome';
import {
  MediaPicker,
  useMediaItem,
  type MediaItem,
} from './beekiricode/inspector/MediaPicker';
import { formatRelative, textFromBeekiriCode, wordStats } from './pageStats';
import './beekiricanva.css';

function formatDate(iso: string | null) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

const REVISIONS_PER_PAGE = 5;

/** Page details in the same modal UI as Media (Elementor-style meta). */
export function PageSettingsModal() {
  const chrome = usePageEditorChrome();
  const { settingsOpen, closeSettings } = chrome;

  const [revisions, setRevisions] = useState<PageRevisionRow[]>([]);
  const [revisionsLoading, setRevisionsLoading] = useState(false);
  const [revisionsError, setRevisionsError] = useState<string | null>(null);
  const [restoringId, setRestoringId] = useState<string | null>(null);
  const [revisionPage, setRevisionPage] = useState(0);
  const [featuredPickerOpen, setFeaturedPickerOpen] = useState(false);
  const featured = useMediaItem(chrome.featuredImageId ?? '');

  const stats = useMemo(
    () => wordStats(textFromBeekiriCode(chrome.beekiricodeData)),
    [chrome.beekiricodeData],
  );

  const loadRevisions = useCallback(async () => {
    if (!chrome.pageId) return;
    setRevisionsLoading(true);
    setRevisionsError(null);
    try {
      const res = await api<{ revisions: PageRevisionRow[] }>(
        `${chrome.apiBase}/${chrome.pageId}/revisions`,
      );
      setRevisions(res.revisions);
      setRevisionPage(0);
    } catch (e) {
      setRevisionsError(formatError(e));
      setRevisions([]);
      setRevisionPage(0);
    } finally {
      setRevisionsLoading(false);
    }
  }, [chrome.pageId, chrome.apiBase]);

  useEffect(() => {
    if (!settingsOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      closeSettings();
    };
    window.addEventListener('keydown', onKey);
    void loadRevisions();
    return () => window.removeEventListener('keydown', onKey);
  }, [settingsOpen, closeSettings, loadRevisions]);

  const revisionPageCount = Math.max(1, Math.ceil(revisions.length / REVISIONS_PER_PAGE));
  const safeRevisionPage = Math.min(revisionPage, revisionPageCount - 1);
  const revisionSlice = useMemo(() => {
    const start = safeRevisionPage * REVISIONS_PER_PAGE;
    return revisions.slice(start, start + REVISIONS_PER_PAGE);
  }, [revisions, safeRevisionPage]);

  const onRestore = async (revisionId: string) => {
    if (!chrome.pageId || chrome.busy || restoringId) return;
    const ok = await confirmDialog({
      title: 'Restore revision',
      message: 'Restore this revision? Your current version will be saved as a revision first.',
      confirmLabel: 'Restore',
    });
    if (!ok) return;
    setRestoringId(revisionId);
    setRevisionsError(null);
    try {
      const page = await api<PageRow>(
        `${chrome.apiBase}/${chrome.pageId}/revisions/${revisionId}/restore`,
        { method: 'POST' },
      );
      chrome.applyRestoredPage(page);
      await loadRevisions();
      closeSettings();
    } catch (e) {
      setRevisionsError(formatError(e));
    } finally {
      setRestoringId(null);
    }
  };

  if (!settingsOpen) return null;

  const statusLabel =
    chrome.pageStatus === 'publish'
      ? 'Published'
      : chrome.pageStatus === 'auto-draft'
        ? 'Auto Draft'
        : 'Draft';

  const editedBy = chrome.updatedByName || chrome.authorName;
  const revisionCount = Math.max(chrome.revisionCount, revisions.length);

  return (
    <>
    <div
      className="bk-media-modal"
      role="dialog"
      aria-modal="true"
      aria-labelledby="bk-page-settings-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeSettings();
      }}
    >
      <div className="bk-media-modal__panel bk-page-settings-modal">
        <div className="bk-media-modal__head">
          <h2 id="bk-page-settings-title" className="bk-media-modal__title">
            {chrome.title.trim() || `${chrome.singularLabel} settings`}
          </h2>
          <button
            type="button"
            className="button"
            onClick={closeSettings}
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        <div className="bk-media-modal__body bk-page-settings-modal__body">
          <div className="bk-media-modal__details">
            <section className="bk-page-settings-modal__section">
              <div className="bk-field">
                <label htmlFor="page_title_modal">Title</label>
                <input
                  id="page_title_modal"
                  type="text"
                  maxLength={200}
                  value={chrome.title}
                  onChange={(e) => chrome.onTitleChange(e.target.value)}
                  placeholder="Add title"
                />
              </div>

              <div className="bk-field">
                <label htmlFor="page_slug_modal">Slug</label>
                <p className="bk-page-settings-modal__slug-prefix">
                  {chrome.permalinkBase}
                  {chrome.publicPath.replace(/[^/]+$/, '') || '/'}
                </p>
                <input
                  id="page_slug_modal"
                  type="text"
                  value={chrome.slug}
                  onChange={(e) => chrome.onSlugChange(e.target.value)}
                  aria-label="Edit slug"
                />
              </div>

              <div className="bk-page-settings-modal__featured-wrap">
                {featured?.url ? (
                  <div className="bk-page-settings-modal__featured-preview">
                    <img src={featured.url} alt={featured.alt || 'Featured image'} />
                    <div className="bk-page-settings-modal__featured-actions">
                      <button
                        type="button"
                        className="button"
                        onClick={() => setFeaturedPickerOpen(true)}
                      >
                        Replace
                      </button>
                      <button
                        type="button"
                        className="button-link is-danger"
                        onClick={() => chrome.setFeaturedImageId(null)}
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    className="button bk-page-settings-modal__featured"
                    onClick={() => setFeaturedPickerOpen(true)}
                  >
                    Set featured image
                  </button>
                )}
              </div>

              <p className="bk-page-settings-modal__stats">{stats.readLabel}.</p>
              <p className="bk-page-settings-modal__stats is-muted">
                Last edited {formatRelative(chrome.updatedAt)}
                {editedBy ? ` by ${editedBy}` : ''}.
              </p>
            </section>

            <section className="bk-page-settings-modal__section">
              <h3 className="bk-page-settings-modal__heading">Details</h3>
              <dl className="bk-page-settings-modal__meta">
                <div>
                  <dt>Status</dt>
                  <dd>{statusLabel}</dd>
                </div>
                <div>
                  <dt>Publish</dt>
                  <dd>{formatDate(chrome.publishedAt)}</dd>
                </div>
                <div>
                  <dt>Slug</dt>
                  <dd>
                    <code>{chrome.slug || '—'}</code>
                  </dd>
                </div>
                <div>
                  <dt>Author</dt>
                  <dd>{chrome.authorName || '—'}</dd>
                </div>
                <div>
                  <dt>Last edited by</dt>
                  <dd>{editedBy || '—'}</dd>
                </div>
                <div>
                  <dt>Template</dt>
                  <dd>Default</dd>
                </div>
                <div>
                  <dt>Discussion</dt>
                  <dd>Closed</dd>
                </div>
                <div>
                  <dt>Revisions</dt>
                  <dd>{revisionCount > 0 ? revisionCount : '—'}</dd>
                </div>
                <div>
                  <dt>Parent</dt>
                  <dd>{chrome.parentId ? chrome.parentId : 'None'}</dd>
                </div>
              </dl>

              <div className="bk-field bk-page-settings-modal__visibility">
                <label htmlFor="page_status_modal">Visibility</label>
                <select
                  id="page_status_modal"
                  value={
                    chrome.visibility === 'auto-draft' ? 'draft' : chrome.visibility
                  }
                  disabled={!chrome.canPublish && chrome.visibility === 'publish'}
                  onChange={(e) =>
                    chrome.setVisibility(e.target.value as 'draft' | 'publish')
                  }
                >
                  <option value="draft">Draft</option>
                  <option value="publish" disabled={!chrome.canPublish}>
                    Published
                  </option>
                </select>
              </div>
            </section>

            <section className="bk-page-settings-modal__section">
              <h3 className="bk-page-settings-modal__heading">Revisions</h3>
              <p className="description">
                Each Update saves the previous version here so you can undo mistakes.
              </p>
              {revisionsError ? (
                <p className="bk-page-settings-modal__stats" role="alert">
                  {revisionsError}
                </p>
              ) : null}
              {revisionsLoading ? (
                <p className="bk-page-settings-modal__stats is-muted">Loading revisions…</p>
              ) : revisions.length === 0 ? (
                <p className="bk-page-settings-modal__stats is-muted">
                  No revisions yet. Save or update the page to create one.
                </p>
              ) : (
                <>
                  <div className="bk-page-settings-modal__revisions-scroll">
                    <ul className="bk-page-settings-modal__revisions">
                      {revisionSlice.map((rev) => (
                        <li key={rev.id} className="bk-page-settings-modal__revision">
                          <div className="bk-page-settings-modal__revision-meta">
                            <strong>{formatDate(rev.createdAt)}</strong>
                            <span>
                              {rev.authorName || 'Unknown'}
                              {rev.title ? ` · ${rev.title}` : ''}
                            </span>
                          </div>
                          <button
                            type="button"
                            className="button"
                            disabled={Boolean(restoringId) || chrome.busy}
                            onClick={() => void onRestore(rev.id)}
                          >
                            {restoringId === rev.id ? 'Restoring…' : 'Restore'}
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                  {revisions.length > REVISIONS_PER_PAGE ? (
                    <div className="bk-page-settings-modal__revisions-pager">
                      <span className="bk-page-settings-modal__revisions-pager-meta">
                        {safeRevisionPage * REVISIONS_PER_PAGE + 1}–
                        {Math.min(
                          (safeRevisionPage + 1) * REVISIONS_PER_PAGE,
                          revisions.length,
                        )}{' '}
                        of {revisions.length}
                      </span>
                      <div className="bk-page-settings-modal__revisions-pager-actions">
                        <button
                          type="button"
                          className="button"
                          disabled={safeRevisionPage <= 0}
                          onClick={() => setRevisionPage(Math.max(0, safeRevisionPage - 1))}
                        >
                          Previous
                        </button>
                        <button
                          type="button"
                          className="button"
                          disabled={safeRevisionPage >= revisionPageCount - 1}
                          onClick={() =>
                            setRevisionPage(
                              Math.min(revisionPageCount - 1, safeRevisionPage + 1),
                            )
                          }
                        >
                          Next
                        </button>
                      </div>
                    </div>
                  ) : null}
                </>
              )}
            </section>

            <section className="bk-page-settings-modal__section">
              <h3 className="bk-page-settings-modal__heading">Excerpt</h3>
              <div className="bk-field">
                <label htmlFor="page_excerpt_modal">Summary</label>
                <textarea
                  id="page_excerpt_modal"
                  className="bk-page-editor__excerpt"
                  rows={4}
                  maxLength={2000}
                  value={chrome.excerpt}
                  onChange={(e) => chrome.setExcerpt(e.target.value)}
                  placeholder="Write an excerpt (optional)"
                />
              </div>
            </section>

            <div className="bk-media-modal__actions bk-page-settings-modal__actions">
              {chrome.canDelete ? (
                <button
                  type="button"
                  className="button"
                  disabled={chrome.busy}
                  onClick={chrome.onDelete}
                >
                  Delete
                </button>
              ) : (
                <span />
              )}
              <div className="bk-page-settings-modal__actions-end">
                <button type="button" className="button" onClick={closeSettings}>
                  Close
                </button>
                <button
                  type="button"
                  className="button button-primary"
                  disabled={chrome.busy}
                  onClick={() => {
                    chrome.update();
                    closeSettings();
                  }}
                >
                  {chrome.busy ? 'Updating…' : 'Update'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <MediaPicker
      open={featuredPickerOpen}
      title="Featured image"
      kind="image"
      selected={chrome.featuredImageId ? [chrome.featuredImageId] : []}
      onClose={() => setFeaturedPickerOpen(false)}
      onSelect={(items: MediaItem[]) => {
        chrome.setFeaturedImageId(items[0]?.id ?? null);
        setFeaturedPickerOpen(false);
      }}
    />
    </>
  );
}
