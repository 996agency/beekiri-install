import { useCallback, useEffect, useState } from 'react';
import { Image as ImageIcon, X } from '@phosphor-icons/react';
import { api, apiUpload } from '../../api/client';

type MediaItem = {
  id: string;
  filename: string;
  originalName: string;
  mimeType: string;
  url: string;
  alt: string;
};

import { SITE_URL as PUBLIC_SITE } from '../../config';

function absoluteUrl(path: string) {
  if (!path) return '';
  if (/^https?:\/\//i.test(path) || path.startsWith('data:')) return path;
  const base = PUBLIC_SITE.replace(/\/$/, '');
  return `${base}${path.startsWith('/') ? path : `/${path}`}`;
}

type Props = {
  value: string;
  onChange: (url: string) => void;
  label?: string;
  readOnly?: boolean;
};

/** Image field — preview + media library picker. */
export function ImageFieldControl({ value, onChange, label = 'Image', readOnly }: Props) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api<{ items: MediaItem[] }>('/api/media');
      setItems(
        (res.items ?? []).filter((i) => (i.mimeType || '').startsWith('image/')),
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load media.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!open) return;
    void load();
  }, [open, load]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  const filtered = query.trim()
    ? items.filter((i) =>
        `${i.originalName} ${i.filename} ${i.alt}`
          .toLowerCase()
          .includes(query.trim().toLowerCase()),
      )
    : items;

  const onUpload = async (files: FileList | null) => {
    if (!files?.length || readOnly) return;
    setUploading(true);
    setError(null);
    try {
      let last = '';
      for (const file of Array.from(files)) {
        const form = new FormData();
        form.append('file', file);
        const res = await apiUpload<{ item: MediaItem }>('/api/media/upload', form);
        last = res.item.url;
        setItems((prev) => [res.item, ...prev]);
      }
      if (last) {
        onChange(last);
        setOpen(false);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Upload failed.');
    } finally {
      setUploading(false);
    }
  };

  const preview = value ? absoluteUrl(value) : '';

  return (
    <div className="bk-image-field">
      <div className={`bk-image-field__frame${preview ? ' has-image' : ''}`}>
        {preview ? (
          <img src={preview} alt="" className="bk-image-field__preview" />
        ) : (
          <button
            type="button"
            className="bk-image-field__empty"
            onClick={() => !readOnly && setOpen(true)}
            disabled={readOnly}
          >
            <ImageIcon size={28} weight="regular" aria-hidden />
            <span>Select image</span>
          </button>
        )}
      </div>

      <div className="bk-image-field__actions">
        <button
          type="button"
          className="button"
          onClick={() => setOpen(true)}
          disabled={readOnly}
        >
          {preview ? 'Replace image' : 'Select image'}
        </button>
        {preview ? (
          <button
            type="button"
            className="button-link delete"
            onClick={() => onChange('')}
            disabled={readOnly}
          >
            Remove
          </button>
        ) : null}
      </div>

      {open ? (
        <div
          className="bk-media-modal"
          role="dialog"
          aria-modal="true"
          aria-labelledby="bk-image-picker-title"
          onClick={(e) => {
            if (e.target === e.currentTarget) setOpen(false);
          }}
        >
          <div className="bk-media-modal__panel bk-image-picker">
            <div className="bk-media-modal__head">
              <h2 id="bk-image-picker-title" className="bk-media-modal__title">
                Select {label}
              </h2>
              <button
                type="button"
                className="button-link"
                aria-label="Close"
                onClick={() => setOpen(false)}
              >
                <X size={18} weight="bold" />
              </button>
            </div>

            <div className="bk-image-picker__toolbar">
              <input
                type="search"
                className="bk-image-picker__search"
                placeholder="Search images…"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
              <label className="button">
                {uploading ? 'Uploading…' : 'Upload'}
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  hidden
                  disabled={uploading || readOnly}
                  onChange={(e) => {
                    void onUpload(e.target.files);
                    e.target.value = '';
                  }}
                />
              </label>
            </div>

            <div className="bk-image-picker__grid-wrap">
              {error ? <p className="beekiri-notice">{error}</p> : null}
              {loading ? (
                <p className="bk-image-picker__hint">Loading media…</p>
              ) : filtered.length === 0 ? (
                <p className="bk-image-picker__hint">
                  No images yet. Upload one to get started.
                </p>
              ) : (
                <ul className="bk-image-picker__grid">
                  {filtered.map((item) => {
                    const selected = value === item.url;
                    return (
                      <li key={item.id}>
                        <button
                          type="button"
                          className={`bk-image-picker__item${selected ? ' is-selected' : ''}`}
                          onClick={() => {
                            onChange(item.url);
                            setOpen(false);
                          }}
                          title={item.originalName || item.filename}
                        >
                          <img src={absoluteUrl(item.url)} alt={item.alt || ''} />
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>

            <div className="bk-media-modal__actions bk-image-picker__footer">
              <button type="button" className="button" onClick={() => setOpen(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
