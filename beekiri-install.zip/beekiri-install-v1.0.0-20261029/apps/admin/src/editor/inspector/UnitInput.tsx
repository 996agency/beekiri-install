type Props = {
  label?: string;
  value: number | string;
  unit?: string;
  min?: number;
  max?: number;
  step?: number;
  onChange: (value: number | 'auto') => void;
  onUnitChange?: (unit: string) => void;
  units?: string[];
  placeholder?: string;
  allowAuto?: boolean;
};

export function UnitInput({
  label,
  value,
  unit = 'px',
  min,
  max,
  onChange,
  onUnitChange,
  units,
  placeholder,
  allowAuto = false,
}: Props) {
  const isAuto = value === 'auto' || value === '' || value == null;
  const display = isAuto ? '' : String(value);

  return (
    <label className="bk-unit">
      {label ? <span className="bk-inspector-label">{label}</span> : null}
      <span className="bk-unit__control">
        <input
          type="text"
          inputMode="decimal"
          className="bk-unit__input"
          value={display}
          placeholder={placeholder || (allowAuto ? 'Auto' : '0')}
          onChange={(e) => {
            const raw = e.target.value.trim().toLowerCase();
            if (raw === '' || raw === 'auto') {
              onChange(allowAuto ? 'auto' : 0);
              return;
            }
            const n = Number(raw);
            if (Number.isNaN(n)) return;
            let next = n;
            if (min != null) next = Math.max(min, next);
            if (max != null) next = Math.min(max, next);
            onChange(next);
          }}
          onBlur={(e) => {
            const raw = e.target.value.trim();
            if (raw === '' && !allowAuto) onChange(0);
          }}
        />
        {units && onUnitChange ? (
          <select
            className="bk-unit__unit"
            value={unit}
            onChange={(e) => onUnitChange(e.target.value)}
            aria-label="Unit"
          >
            {units.map((u) => (
              <option key={u} value={u}>
                {u}
              </option>
            ))}
          </select>
        ) : (
          <span className="bk-unit__unit is-static">{unit}</span>
        )}
      </span>
    </label>
  );
}
