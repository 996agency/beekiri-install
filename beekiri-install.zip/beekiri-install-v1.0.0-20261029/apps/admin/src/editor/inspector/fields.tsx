import type { Config, CustomField, Field } from '@beekiri/beekiricanva';
import { Image as ImageIcon } from '@phosphor-icons/react';
import {
  defaultBackground,
  defaultBorder,
  defaultEffects,
  defaultLayout,
  defaultSpacing,
  defaultTypography,
  type BlockBackground,
  type BlockBorder,
  type BlockEffects,
  type BlockLayout,
  type BlockSpacing,
  type BlockTypography,
} from '@beekiri/page-blocks';
import { ImageFieldControl } from './ImageField';
import {
  BackgroundPanel,
  BorderPanel,
  EffectsPanel,
  LayoutPanel,
  SpacingPanel,
  TypographyPanel,
} from './panels';

function asTypography(value: unknown): BlockTypography {
  return { ...defaultTypography(), ...(value && typeof value === 'object' ? value : {}) };
}

function asLayout(value: unknown): BlockLayout {
  return { ...defaultLayout(), ...(value && typeof value === 'object' ? value : {}) };
}

function asSpacing(value: unknown): BlockSpacing {
  const base = defaultSpacing();
  if (!value || typeof value !== 'object') return base;
  const v = value as Partial<BlockSpacing>;
  return {
    margin: { ...base.margin, ...(v.margin || {}) },
    padding: { ...base.padding, ...(v.padding || {}) },
  };
}

function asBackground(value: unknown): BlockBackground {
  return { ...defaultBackground(), ...(value && typeof value === 'object' ? value : {}) };
}

function asBorder(value: unknown): BlockBorder {
  return { ...defaultBorder(), ...(value && typeof value === 'object' ? value : {}) };
}

function asEffects(value: unknown): BlockEffects {
  return { ...defaultEffects(), ...(value && typeof value === 'object' ? value : {}) };
}

export const typographyField: CustomField<BlockTypography> = {
  type: 'custom',
  label: 'Typography',
  render: ({ value, onChange }: { value: BlockTypography; onChange: (v: BlockTypography) => void }) => (
    <TypographyPanel value={asTypography(value)} onChange={onChange} />
  ),
};

export const layoutField: CustomField<BlockLayout> = {
  type: 'custom',
  label: 'Layout',
  render: ({ value, onChange }: { value: BlockLayout; onChange: (v: BlockLayout) => void }) => (
    <LayoutPanel value={asLayout(value)} onChange={onChange} />
  ),
};

export const spacingField: CustomField<BlockSpacing> = {
  type: 'custom',
  label: 'Spacing',
  render: ({ value, onChange }: { value: BlockSpacing; onChange: (v: BlockSpacing) => void }) => (
    <SpacingPanel value={asSpacing(value)} onChange={onChange} />
  ),
};

export const backgroundField: CustomField<BlockBackground> = {
  type: 'custom',
  label: 'Background',
  render: ({ value, onChange }: { value: BlockBackground; onChange: (v: BlockBackground) => void }) => (
    <BackgroundPanel value={asBackground(value)} onChange={onChange} />
  ),
};

export const borderField: CustomField<BlockBorder> = {
  type: 'custom',
  label: 'Border',
  render: ({ value, onChange }: { value: BlockBorder; onChange: (v: BlockBorder) => void }) => (
    <BorderPanel value={asBorder(value)} onChange={onChange} />
  ),
};

export const effectsField: CustomField<BlockEffects> = {
  type: 'custom',
  label: 'Effects',
  render: ({ value, onChange }: { value: BlockEffects; onChange: (v: BlockEffects) => void }) => (
    <EffectsPanel value={asEffects(value)} onChange={onChange} />
  ),
};

export function imageField(label = 'Image'): CustomField<string> {
  return {
    type: 'custom',
    label,
    labelIcon: <ImageIcon size={14} weight="regular" aria-hidden />,
    render: ({ value, onChange, readOnly }) => (
      <ImageFieldControl
        value={typeof value === 'string' ? value : ''}
        onChange={onChange}
        label={label}
        readOnly={readOnly}
      />
    ),
  };
}

const INSPECTOR_KEYS = new Set([
  'typography',
  'layout',
  'spacing',
  'background',
  'border',
  'effects',
]);

const inspectorFieldMap: Record<string, Field> = {
  typography: typographyField,
  layout: layoutField,
  spacing: spacingField,
  background: backgroundField,
  border: borderField,
  effects: effectsField,
};

function isImageField(field: Field): boolean {
  const meta = (field as { metadata?: { beekiriKind?: string } }).metadata;
  return meta?.beekiriKind === 'image';
}

/** Swap style panels and image pickers into the config. */
export function withInspectorFields(config: Config): Config {
  const components = { ...config.components };
  for (const [name, component] of Object.entries(components)) {
    if (!component?.fields) continue;
    const nextFields: Record<string, Field> = {};
    for (const [key, field] of Object.entries(component.fields)) {
      if (INSPECTOR_KEYS.has(key) && inspectorFieldMap[key]) {
        nextFields[key] = inspectorFieldMap[key];
      } else if (isImageField(field as Field)) {
        nextFields[key] = imageField((field as Field).label || key);
      } else {
        nextFields[key] = field as Field;
      }
    }
    components[name] = { ...component, fields: nextFields };
  }
  return { ...config, components };
}
