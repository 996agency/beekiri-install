import { useState, type ReactNode } from 'react';
import { CaretDown, type Icon } from '@phosphor-icons/react';

type Props = {
  title: string;
  icon: Icon;
  defaultOpen?: boolean;
  children: ReactNode;
  trailing?: ReactNode;
};

export function InspectorCard({
  title,
  icon: IconCmp,
  defaultOpen = true,
  children,
  trailing,
}: Props) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <section className={`bk-inspector-card${open ? ' is-open' : ''}`}>
      <button
        type="button"
        className="bk-inspector-card__head"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
      >
        <span className="bk-inspector-card__title">
          <IconCmp size={16} weight="regular" aria-hidden />
          {title}
        </span>
        <span className="bk-inspector-card__meta">
          {trailing}
          <CaretDown
            size={14}
            weight="bold"
            className="bk-inspector-card__caret"
            aria-hidden
          />
        </span>
      </button>
      {open ? <div className="bk-inspector-card__body">{children}</div> : null}
    </section>
  );
}
