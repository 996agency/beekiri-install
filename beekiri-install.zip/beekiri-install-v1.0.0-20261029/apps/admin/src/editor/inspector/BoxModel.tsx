import { useState } from 'react';
import type { BoxSides } from '@beekiri/page-blocks';

type Layer = 'margin' | 'padding';
type Side = keyof BoxSides;

type Props = {
  margin: BoxSides;
  padding: BoxSides;
  onChange: (next: { margin: BoxSides; padding: BoxSides }) => void;
};

const SIDES: Side[] = ['top', 'right', 'bottom', 'left'];

export function BoxModel({ margin, padding, onChange }: Props) {
  const [active, setActive] = useState<{ layer: Layer; side: Side }>({
    layer: 'margin',
    side: 'top',
  });

  const activeValue =
    active.layer === 'margin' ? margin[active.side] : padding[active.side];

  const setSide = (layer: Layer, side: Side, n: number) => {
    if (layer === 'margin') {
      onChange({ margin: { ...margin, [side]: n }, padding });
    } else {
      onChange({ margin, padding: { ...padding, [side]: n } });
    }
  };

  const setAll = (layer: Layer, n: number) => {
    const box = { top: n, right: n, bottom: n, left: n };
    if (layer === 'margin') onChange({ margin: box, padding });
    else onChange({ margin, padding: box });
  };

  return (
    <div className="bk-boxmodel">
      <div className="bk-boxmodel__diagram" aria-label="Spacing box model">
        <div className="bk-boxmodel__margin">
          <span className="bk-boxmodel__tag">Margin</span>
          {SIDES.map((side) => (
            <button
              key={`m-${side}`}
              type="button"
              className={`bk-boxmodel__pill is-${side}${
                active.layer === 'margin' && active.side === side ? ' is-active' : ''
              }`}
              aria-label={`Margin ${side}`}
              aria-pressed={active.layer === 'margin' && active.side === side}
              onClick={() => setActive({ layer: 'margin', side })}
            >
              {margin[side]}
            </button>
          ))}

          <div className="bk-boxmodel__padding">
            <span className="bk-boxmodel__tag">Padding</span>
            {SIDES.map((side) => (
              <button
                key={`p-${side}`}
                type="button"
                className={`bk-boxmodel__pill is-${side}${
                  active.layer === 'padding' && active.side === side ? ' is-active' : ''
                }`}
                aria-label={`Padding ${side}`}
                aria-pressed={active.layer === 'padding' && active.side === side}
                onClick={() => setActive({ layer: 'padding', side })}
              >
                {padding[side]}
              </button>
            ))}
            <div className="bk-boxmodel__core" aria-hidden />
          </div>
        </div>
      </div>

      <div className="bk-boxmodel__edit">
        <span className="bk-boxmodel__edit-label">
          {active.layer} · {active.side}
        </span>
        <div className="bk-boxmodel__edit-row">
          <input
            type="number"
            className="bk-boxmodel__edit-input"
            value={activeValue}
            min={0}
            step={1}
            onChange={(e) =>
              setSide(active.layer, active.side, Number(e.target.value) || 0)
            }
            aria-label={`Edit ${active.layer} ${active.side}`}
          />
          <span className="bk-boxmodel__edit-unit">px</span>
          <button
            type="button"
            className="bk-boxmodel__edit-all"
            title={`Set all ${active.layer} sides`}
            onClick={() => setAll(active.layer, activeValue)}
          >
            All
          </button>
        </div>
      </div>
    </div>
  );
}
