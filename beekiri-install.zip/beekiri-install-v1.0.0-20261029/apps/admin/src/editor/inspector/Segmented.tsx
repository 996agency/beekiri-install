import type { Icon } from '@phosphor-icons/react';
import type { ReactNode } from 'react';

export type SegmentOption<T extends string> = {
  value: T;
  label?: string;
  icon?: Icon;
  title?: string;
};

type Props<T extends string> = {
  value: T;
  options: SegmentOption<T>[];
  onChange: (value: T) => void;
  ariaLabel?: string;
};

export function Segmented<T extends string>({
  value,
  options,
  onChange,
  ariaLabel,
}: Props<T>) {
  return (
    <div className="bk-seg" role="group" aria-label={ariaLabel}>
      {options.map((opt) => {
        const IconCmp = opt.icon;
        const active = opt.value === value;
        return (
          <button
            key={opt.value}
            type="button"
            className={`bk-seg__btn${active ? ' is-active' : ''}`}
            aria-pressed={active}
            title={opt.title || opt.label || opt.value}
            onClick={() => onChange(opt.value)}
          >
            {IconCmp ? <IconCmp size={16} weight={active ? 'bold' : 'regular'} aria-hidden /> : null}
            {opt.label ? <span>{opt.label}</span> : null}
          </button>
        );
      })}
    </div>
  );
}

type FormatProps = {
  children: ReactNode;
};

export function FormatRow({ children }: FormatProps) {
  return <div className="bk-seg bk-seg--format">{children}</div>;
}

type FormatBtnProps = {
  active?: boolean;
  title: string;
  onClick: () => void;
  children: ReactNode;
};

export function FormatBtn({ active, title, onClick, children }: FormatBtnProps) {
  return (
    <button
      type="button"
      className={`bk-seg__btn${active ? ' is-active' : ''}`}
      aria-pressed={!!active}
      title={title}
      onClick={onClick}
    >
      {children}
    </button>
  );
}
