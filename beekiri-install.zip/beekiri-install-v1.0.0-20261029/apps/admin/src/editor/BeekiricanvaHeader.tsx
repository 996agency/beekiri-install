import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import type { ReactNode } from 'react';
import { GearSix } from '@phosphor-icons/react';
import { createUseBeekiricanva } from '@beekiri/beekiricanva';
import { BarViewportControls } from './BarViewportControls';
import { usePageEditorChrome } from './PageEditorChrome';

const useBeekiricanva = createUseBeekiricanva();

function IconMaximize() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function IconMinimize() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M8 3v5H3M16 3v5h5M8 21v-5H3M16 21v-5h5"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

/** Open Fields tab when a block is selected. */
function FieldsAutoFocus() {
  const selectedId = useBeekiricanva((s) => s.selectedItem?.props?.id as string | undefined);
  const dispatch = useBeekiricanva((s) => s.dispatch);

  useEffect(() => {
    if (!selectedId) return;
    dispatch({
      type: 'setUi',
      ui: {
        plugin: { current: 'fields' },
        leftSideBarVisible: true,
      },
    });
  }, [selectedId, dispatch]);

  return null;
}

/** Beekiricanva header override — Beekiri bar + title/permalink + preview flow. */
export function BeekiricanvaHeader({ actions }: { actions: ReactNode; children?: ReactNode }) {
  const chrome = usePageEditorChrome();

  return (
    <div className="bk-page-editor__chrome">
      <FieldsAutoFocus />

      <div className="bk-page-editor__bar bk-page-editor__bar--beekiricanva">
        <div className="bk-page-editor__bar-left">
          <Link to="/admin/pages" className="bk-page-editor__back">
            ← Pages
          </Link>
          <span className="bk-page-editor__bar-title">
            {chrome.title.trim() || 'Add new page'}
          </span>
        </div>

        <div className="bk-page-editor__bar-actions">
          <BarViewportControls />

          <button
            type="button"
            className="bk-page-editor__icon-btn"
            title={chrome.fullscreen ? 'Exit full screen (Esc)' : 'Full screen'}
            aria-pressed={chrome.fullscreen}
            onClick={chrome.toggleFullscreen}
          >
            {chrome.fullscreen ? <IconMinimize /> : <IconMaximize />}
          </button>

          <button
            type="button"
            className="bk-page-editor__icon-btn"
            title="Page settings"
            aria-pressed={chrome.settingsOpen}
            onClick={chrome.openSettings}
          >
            <GearSix size={16} weight="regular" aria-hidden />
          </button>

          {chrome.viewHref ? (
            <a
              className="button"
              href={chrome.viewHref}
              target="_blank"
              rel="noreferrer"
            >
              View page
            </a>
          ) : null}

          {!chrome.isPublished ? (
            <button
              type="button"
              className="button"
              disabled={chrome.busy}
              onClick={chrome.saveDraft}
            >
              Save draft
            </button>
          ) : null}

          {chrome.isDirty ? (
            <button
              type="button"
              className="button"
              disabled={chrome.busy}
              onClick={chrome.previewChanges}
            >
              Preview changes
            </button>
          ) : null}

          {chrome.isPublished ? (
            <button
              type="button"
              className="button button-primary"
              disabled={chrome.busy || !chrome.isDirty}
              onClick={chrome.update}
            >
              {chrome.busy ? 'Updating…' : 'Update'}
            </button>
          ) : chrome.canPublish ? (
            <button
              type="button"
              className="button button-primary"
              disabled={chrome.busy}
              onClick={chrome.publish}
            >
              {chrome.busy ? 'Publishing…' : 'Publish'}
            </button>
          ) : null}

          <span className="bk-page-editor__beekiricanva-actions" hidden>
            {actions}
          </span>
        </div>
      </div>
    </div>
  );
}
