import type { Data } from '@beekiri/beekiricanva';
import type { BeekiriCodePageDoc } from './beekiricode/document';

/** Pull plain text out of a BeekiriCode document for word-count stats. */
export function textFromBeekiriCode(doc: BeekiriCodePageDoc | null | undefined): string {
  if (!doc?.nodes) return '';
  const chunks: string[] = [];
  for (const node of Object.values(doc.nodes)) {
    if (node.text) chunks.push(node.text);
  }
  return chunks.join(' ');
}

/** @deprecated Prefer textFromBeekiriCode */
export function textFromBeekiricanva(data: Data | null | undefined): string {
  if (!data?.content?.length) return '';
  const chunks: string[] = [];

  const walk = (value: unknown) => {
    if (value == null) return;
    if (typeof value === 'string') {
      chunks.push(value);
      return;
    }
    if (Array.isArray(value)) {
      value.forEach(walk);
      return;
    }
    if (typeof value === 'object') {
      for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
        if (k === 'id' || k === 'type') continue;
        walk(v);
      }
    }
  };

  walk(data.content);
  if (data.zones) walk(data.zones);
  return chunks.join(' ');
}

export function wordStats(text: string) {
  const words = text
    .replace(/<[^>]+>/g, ' ')
    .trim()
    .split(/\s+/)
    .filter(Boolean).length;
  const minutes = Math.max(1, Math.ceil(words / 200));
  return {
    words,
    readLabel: words === 0 ? 'No content yet' : `${words} words, ${minutes} minute read time`,
  };
}

export function formatRelative(iso: string | null) {
  if (!iso) return '—';
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return iso;
  const sec = Math.round((Date.now() - then) / 1000);
  if (sec < 60) return 'just now';
  const min = Math.round(sec / 60);
  if (min < 60) return `${min} minute${min === 1 ? '' : 's'} ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr} hour${hr === 1 ? '' : 's'} ago`;
  const day = Math.round(hr / 24);
  if (day < 30) return `${day} day${day === 1 ? '' : 's'} ago`;
  const mo = Math.round(day / 30);
  if (mo < 12) return `${mo} month${mo === 1 ? '' : 's'} ago`;
  const yr = Math.round(mo / 12);
  return `${yr} year${yr === 1 ? '' : 's'} ago`;
}
