import { useMemo, useRef, useState, type DragEvent, type MouseEvent } from 'react';
import {
  CaretDown,
  CaretRight,
  DotsSixVertical,
  FrameCorners,
  Image as ImageIcon,
  LinkSimple,
  Square,
  TextAlignLeft,
  TextT,
  Browser,
  Trash,
} from '@phosphor-icons/react';
import {
  canAcceptChildren,
  type BeekiriCodeNode,
  type BeekiriCodeNodeType,
  type BeekiriCodePageDoc,
  type MovePosition,
} from './document';

type Props = {
  doc: BeekiriCodePageDoc;
  selectedId: string | null;
  onSelect: (id: string) => void;
  onRemove: (id: string) => void;
  onMove: (dragId: string, targetId: string, position: MovePosition) => void;
};

type LayerMeta = {
  tagTone: 'blue' | 'amber' | 'purple' | 'teal' | 'rose';
  label: string;
  Icon: typeof Square;
};

function layerMeta(node: BeekiriCodeNode, isRoot: boolean): LayerMeta {
  if (isRoot) {
    return { tagTone: 'blue', label: 'Body', Icon: Browser };
  }
  switch (node.type as BeekiriCodeNodeType) {
    case 'section':
      return { tagTone: 'amber', label: 'Section', Icon: FrameCorners };
    case 'container':
      return { tagTone: 'amber', label: 'Container', Icon: Square };
    case 'heading':
      return {
        tagTone: 'blue',
        label: (node.text || 'Text').trim().slice(0, 24) || 'Text',
        Icon: TextT,
      };
    case 'text':
      return {
        tagTone: 'blue',
        label: (node.text || 'Text').trim().slice(0, 24) || 'Text',
        Icon: TextAlignLeft,
      };
    case 'image':
      return { tagTone: 'teal', label: 'Image', Icon: ImageIcon };
    case 'button':
      return {
        tagTone: 'rose',
        label: (node.text || 'Button').trim().slice(0, 24) || 'Button',
        Icon: LinkSimple,
      };
    case 'layout':
      return {
        tagTone: 'purple',
        label: (node.layoutTitle || node.layoutSlug || 'Layout').trim().slice(0, 28),
        Icon: FrameCorners,
      };
    default:
      return { tagTone: 'amber', label: node.type, Icon: Square };
  }
}

function displayTag(node: BeekiriCodeNode, isRoot: boolean): string {
  if (isRoot) return 'body';
  if (node.type === 'layout') return node.layoutSlug || 'layout';
  return (node.tag || node.type).toLowerCase();
}

type FlatRow = {
  id: string;
  depth: number;
  hasChildren: boolean;
};

type DropHint = { id: string; position: MovePosition } | null;

const DRAG_MIME = 'application/x-beekiri-layer';

export function LayersTree({ doc, selectedId, onSelect, onRemove, onMove }: Props) {
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const draggingRef = useRef<string | null>(null);
  const [dropHint, setDropHint] = useState<DropHint>(null);

  const rows = useMemo(() => {
    const out: FlatRow[] = [];
    const walk = (id: string, depth: number) => {
      const n = doc.nodes[id];
      if (!n) return;
      const hasChildren = n.children.length > 0;
      out.push({ id, depth, hasChildren });
      if (hasChildren && !collapsed[id]) {
        n.children.forEach((c) => walk(c, depth + 1));
      }
    };
    walk(doc.rootId, 0);
    return out;
  }, [doc, collapsed]);

  const toggle = (e: MouseEvent, id: string) => {
    e.stopPropagation();
    setCollapsed((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const resolveDrop = (
    dragId: string | null,
    targetId: string,
    clientY: number,
    el: HTMLElement,
  ): MovePosition | null => {
    if (!dragId || dragId === targetId) return null;
    const isRoot = targetId === doc.rootId;
    const target = doc.nodes[targetId];
    const rect = el.getBoundingClientRect();
    const y = (clientY - rect.top) / Math.max(rect.height, 1);

    if (isRoot || canAcceptChildren(target, isRoot)) {
      if (y < 0.28 && !isRoot) return 'before';
      if (y > 0.72 && !isRoot) return 'after';
      return 'inside';
    }
    return y < 0.5 ? 'before' : 'after';
  };

  const onDragStart = (e: DragEvent, id: string) => {
    if (id === doc.rootId) {
      e.preventDefault();
      return;
    }
    e.dataTransfer.setData(DRAG_MIME, id);
    e.dataTransfer.effectAllowed = 'move';
    draggingRef.current = id;
    setDraggingId(id);
    onSelect(id);
  };

  const onDragEnd = () => {
    draggingRef.current = null;
    setDraggingId(null);
    setDropHint(null);
  };

  const onDragOverRow = (e: DragEvent, id: string) => {
    const dragId = draggingRef.current;
    if (!dragId) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    const el = e.currentTarget as HTMLElement;
    const position = resolveDrop(dragId, id, e.clientY, el);
    if (!position) {
      setDropHint(null);
      return;
    }
    setDropHint({ id, position });
  };

  const onDropRow = (e: DragEvent, id: string) => {
    e.preventDefault();
    const dragId = e.dataTransfer.getData(DRAG_MIME) || draggingRef.current;
    const el = e.currentTarget as HTMLElement;
    const position = dragId ? resolveDrop(dragId, id, e.clientY, el) : null;
    draggingRef.current = null;
    setDraggingId(null);
    setDropHint(null);
    if (!dragId || !position) return;
    onMove(dragId, id, position);
  };

  return (
    <div className="bk-beekiricode__tree" role="tree" aria-label="Layers">
      {rows.map((row) => {
        const node = doc.nodes[row.id];
        if (!node) return null;
        const isRoot = row.id === doc.rootId;
        const meta = layerMeta(node, isRoot);
        const tag = displayTag(node, isRoot);
        const isOpen = row.hasChildren && !collapsed[row.id];
        const Icon = meta.Icon;
        const selected = selectedId === row.id;
        const hint = dropHint?.id === row.id ? dropHint.position : null;

        return (
          <div
            key={row.id}
            role="treeitem"
            tabIndex={0}
            aria-selected={selected}
            aria-expanded={row.hasChildren ? isOpen : undefined}
            draggable={!isRoot}
            className={[
              'bk-beekiricode__tree-item',
              selected ? 'is-selected' : '',
              draggingId === row.id ? 'is-dragging' : '',
              hint === 'before' ? 'is-drop-before' : '',
              hint === 'after' ? 'is-drop-after' : '',
              hint === 'inside' ? 'is-drop-inside' : '',
            ]
              .filter(Boolean)
              .join(' ')}
            style={{ paddingLeft: 6 + row.depth * 14 }}
            onClick={() => onSelect(row.id)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onSelect(row.id);
              }
              if ((e.key === 'Delete' || e.key === 'Backspace') && !isRoot) {
                e.preventDefault();
                onRemove(row.id);
              }
            }}
            onDragStart={(e) => onDragStart(e, row.id)}
            onDragEnd={onDragEnd}
            onDragOver={(e) => onDragOverRow(e, row.id)}
            onDragLeave={() => {
              if (dropHint?.id === row.id) setDropHint(null);
            }}
            onDrop={(e) => onDropRow(e, row.id)}
          >
            {!isRoot ? (
              <span
                className="bk-beekiricode__tree-drag"
                title="Drag to reorder"
                aria-hidden
                onMouseDown={(e) => e.stopPropagation()}
              >
                <DotsSixVertical size={12} weight="bold" />
              </span>
            ) : (
              <span className="bk-beekiricode__tree-drag-spacer" aria-hidden />
            )}

            <span className="bk-beekiricode__tree-caret-slot">
              {row.hasChildren ? (
                <button
                  type="button"
                  className="bk-beekiricode__tree-caret"
                  onClick={(e) => toggle(e, row.id)}
                  aria-label={isOpen ? 'Collapse' : 'Expand'}
                >
                  {isOpen ? (
                    <CaretDown size={10} weight="bold" aria-hidden />
                  ) : (
                    <CaretRight size={10} weight="bold" aria-hidden />
                  )}
                </button>
              ) : (
                <span className="bk-beekiricode__tree-caret-spacer" aria-hidden />
              )}
            </span>

            <span className="bk-beekiricode__tree-type-icon" aria-hidden>
              <Icon size={13} weight="regular" />
            </span>

            <span
              className={`bk-beekiricode__tree-tag bk-beekiricode__tree-tag--${meta.tagTone}`}
            >
              {tag}
            </span>

            <span className="bk-beekiricode__tree-label">{meta.label}</span>

            {!isRoot ? (
              <button
                type="button"
                className="bk-beekiricode__tree-remove"
                title="Remove"
                aria-label={`Remove ${meta.label}`}
                onClick={(e) => {
                  e.stopPropagation();
                  onRemove(row.id);
                }}
              >
                <Trash size={12} weight="bold" aria-hidden />
              </button>
            ) : null}
          </div>
        );
      })}
    </div>
  );
}
