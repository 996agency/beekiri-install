import { useEffect, useLayoutEffect, useRef, useState, type ReactNode, type RefObject } from 'react';
import { createPortal } from 'react-dom';

/**
 * Floating panel anchored beside the inspector (fixed position, portalled to body)
 * so it is never clipped by the Explorer's scroll container.
 */
export function Popover({
  anchorRef,
  open,
  onClose,
  width = 248,
  className,
  children,
}: {
  anchorRef: RefObject<HTMLElement | null>;
  open: boolean;
  onClose: () => void;
  width?: number;
  className?: string;
  children: ReactNode;
}) {
  const panelRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);

  useLayoutEffect(() => {
    if (!open) return;
    const place = () => {
      const anchor = anchorRef.current;
      const panel = panelRef.current;
      if (!anchor) return;
      const a = anchor.getBoundingClientRect();
      const host = anchor.closest('.bk-insp')?.getBoundingClientRect();
      const h = panel?.offsetHeight ?? 360;
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      // Prefer just outside the Props column (works for left explorer + right panel).
      const preferRight = (host?.right ?? a.right) + 10;
      const preferLeft = Math.max(8, (host?.left ?? a.left) - width - 10);
      let left = preferRight;
      if (preferRight + width > vw - 8) {
        left = preferLeft + width <= a.left ? preferLeft : Math.max(8, Math.min(preferRight, vw - width - 8));
      }
      const top = Math.max(8, Math.min(a.top - 12, vh - h - 8));
      setPos({ top, left });
    };
    place();
    const raf = requestAnimationFrame(place);
    window.addEventListener('resize', place);
    window.addEventListener('scroll', place, true);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', place);
      window.removeEventListener('scroll', place, true);
    };
  }, [open, anchorRef, width]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      const t = e.target as Node;
      if (panelRef.current?.contains(t) || anchorRef.current?.contains(t)) return;
      onClose();
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('pointerdown', onDown, true);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('pointerdown', onDown, true);
      document.removeEventListener('keydown', onKey);
    };
  }, [open, onClose, anchorRef]);

  if (!open) return null;
  return createPortal(
    <div
      ref={panelRef}
      className={`bk-insp-pop${className ? ` ${className}` : ''}`}
      style={{ width, top: pos?.top ?? -9999, left: pos?.left ?? -9999 }}
      onKeyDown={(e) => e.stopPropagation()}
    >
      {children}
    </div>,
    document.body,
  );
}
