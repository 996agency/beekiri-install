import { Minus } from '@phosphor-icons/react';
import { ColorField } from './ColorPicker';
import { NumberField, SelectField, SubHead, TextField } from './controls';
import { parseColor, parseFunctionList, parseNumUnit, splitSpaces, splitTopLevel } from './css-values';

/* ── Box shadows ────────────────────────────────────────────────────────── */

type Shadow = { x: string; y: string; blur: string; spread: string; color: string; inset: boolean };

function parseShadows(value: string): Shadow[] {
  if (!value || value === 'none') return [];
  return splitTopLevel(value).map((part) => {
    const tokens = splitSpaces(part);
    const inset = tokens.includes('inset');
    const color = tokens.find((t) => parseColor(t)) ?? 'rgba(0, 0, 0, 0.25)';
    const lens = tokens.filter((t) => t !== 'inset' && t !== color);
    return { x: lens[0] ?? '0px', y: lens[1] ?? '0px', blur: lens[2] ?? '0px', spread: lens[3] ?? '0px', color, inset };
  });
}

const formatShadows = (list: Shadow[]) =>
  list.map((s) => [s.inset ? 'inset' : '', s.x || '0', s.y || '0', s.blur || '0', s.spread || '0', s.color].filter(Boolean).join(' ')).join(', ');

export function ShadowList({ value, onChange, documentColors }: { value: string; onChange: (v: string) => void; documentColors: string[] }) {
  const list = parseShadows(value);
  const set = (next: Shadow[]) => onChange(next.length ? formatShadows(next) : '');
  const update = (i: number, patch: Partial<Shadow>) => set(list.map((s, j) => (j === i ? { ...s, ...patch } : s)));
  return (
    <div className="bk-insp-list">
      <SubHead onAdd={() => set([...list, { x: '0px', y: '4px', blur: '12px', spread: '0px', color: 'rgba(0, 0, 0, 0.25)', inset: false }])}>
        Box Shadows
      </SubHead>
      {list.map((s, i) => (
        <div key={i} className="bk-insp-list__card">
          <div className="bk-insp-list__row">
            <button
              type="button"
              className={`bk-insp-chip${s.inset ? ' is-active' : ''}`}
              onClick={() => update(i, { inset: !s.inset })}
            >
              {s.inset ? 'Inner' : 'Drop'}
            </button>
            <RemoveBtn onClick={() => set(list.filter((_, j) => j !== i))} />
          </div>
          <div className="bk-insp-grid4">
            <NumberField value={s.x} onChange={(v) => update(i, { x: v })} suffix="X" placeholder="0" />
            <NumberField value={s.y} onChange={(v) => update(i, { y: v })} suffix="Y" placeholder="0" />
            <NumberField value={s.blur} onChange={(v) => update(i, { blur: v })} suffix="B" placeholder="0" min={0} />
            <NumberField value={s.spread} onChange={(v) => update(i, { spread: v })} suffix="S" placeholder="0" />
          </div>
          <ColorField value={s.color} onChange={(v) => update(i, { color: v || 'rgba(0, 0, 0, 0.25)' })} documentColors={documentColors} />
        </div>
      ))}
    </div>
  );
}

/* ── Transforms / Filters (function lists) ──────────────────────────────── */

type FnDef = { fn: string; label: string; unit: string; def: string };

const TRANSFORMS: FnDef[] = [
  { fn: 'translateX', label: 'Move X', unit: 'px', def: '0px' },
  { fn: 'translateY', label: 'Move Y', unit: 'px', def: '0px' },
  { fn: 'rotate', label: 'Rotate', unit: 'deg', def: '0deg' },
  { fn: 'scale', label: 'Scale', unit: '', def: '1' },
  { fn: 'skewX', label: 'Skew X', unit: 'deg', def: '0deg' },
  { fn: 'skewY', label: 'Skew Y', unit: 'deg', def: '0deg' },
];

const FILTERS: FnDef[] = [
  { fn: 'blur', label: 'Blur', unit: 'px', def: '4px' },
  { fn: 'brightness', label: 'Brightness', unit: '%', def: '100%' },
  { fn: 'contrast', label: 'Contrast', unit: '%', def: '100%' },
  { fn: 'grayscale', label: 'Grayscale', unit: '%', def: '100%' },
  { fn: 'saturate', label: 'Saturate', unit: '%', def: '100%' },
  { fn: 'hue-rotate', label: 'Hue', unit: 'deg', def: '0deg' },
  { fn: 'invert', label: 'Invert', unit: '%', def: '100%' },
  { fn: 'sepia', label: 'Sepia', unit: '%', def: '100%' },
];

function FunctionList({
  title,
  defs,
  value,
  onChange,
}: {
  title: string;
  defs: FnDef[];
  value: string;
  onChange: (v: string) => void;
}) {
  const list = value && value !== 'none' ? parseFunctionList(value) : [];
  const set = (next: { fn: string; args: string }[]) => onChange(next.map((f) => `${f.fn}(${f.args})`).join(' '));
  const used = new Set(list.map((f) => f.fn));
  const nextDef = defs.find((d) => !used.has(d.fn)) ?? defs[0];
  return (
    <div className="bk-insp-list">
      <SubHead onAdd={() => set([...list, { fn: nextDef.fn, args: nextDef.def }])}>{title}</SubHead>
      {list.map((f, i) => {
        const def = defs.find((d) => d.fn === f.fn);
        return (
          <div key={i} className="bk-insp-list__inline">
            <SelectField
              value={f.fn}
              placeholder="Type"
              options={defs.map((d) => ({ value: d.fn, label: d.label }))}
              onChange={(fn) => {
                const d = defs.find((x) => x.fn === fn);
                if (!d) return;
                set(list.map((x, j) => (j === i ? { fn: d.fn, args: d.def } : x)));
              }}
            />
            <NumberField
              value={f.args}
              unit={def?.unit ?? ''}
              suffix={def?.unit ? def.unit.toUpperCase() : undefined}
              placeholder={def?.def ?? ''}
              step={def?.fn === 'scale' ? 0.05 : 1}
              onChange={(v) => set(list.map((x, j) => (j === i ? { ...x, args: v || def?.def || '0' } : x)))}
            />
            <RemoveBtn onClick={() => set(list.filter((_, j) => j !== i))} />
          </div>
        );
      })}
    </div>
  );
}

export const TransformList = (p: { value: string; onChange: (v: string) => void }) => (
  <FunctionList title="Transforms" defs={TRANSFORMS} {...p} />
);

export const FilterList = (p: { value: string; onChange: (v: string) => void }) => (
  <FunctionList title="Filters" defs={FILTERS} {...p} />
);

/* ── Transitions ────────────────────────────────────────────────────────── */

type Transition = { prop: string; duration: string; easing: string };

const EASINGS = ['ease', 'ease-in', 'ease-out', 'ease-in-out', 'linear', 'cubic-bezier(0.2, 0.8, 0.2, 1)'];

function parseTransitions(value: string): Transition[] {
  if (!value || value === 'none') return [];
  return splitTopLevel(value).map((part) => {
    const t = splitSpaces(part);
    const duration = t.find((x) => /^\d*\.?\d+m?s$/.test(x)) ?? '200ms';
    const easing = t.find((x) => EASINGS.includes(x) || x.startsWith('cubic-bezier') || x.startsWith('steps')) ?? 'ease';
    const prop = t.find((x) => x !== duration && x !== easing) ?? 'all';
    return { prop, duration, easing };
  });
}

export function TransitionList({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const list = parseTransitions(value);
  const set = (next: Transition[]) => onChange(next.map((t) => `${t.prop} ${t.duration} ${t.easing}`).join(', '));
  const update = (i: number, patch: Partial<Transition>) => set(list.map((t, j) => (j === i ? { ...t, ...patch } : t)));
  return (
    <div className="bk-insp-list">
      <SubHead onAdd={() => set([...list, { prop: 'all', duration: '200ms', easing: 'ease' }])}>Transitions</SubHead>
      {list.map((t, i) => (
        <div key={i} className="bk-insp-list__card">
          <div className="bk-insp-list__row">
            <TextField value={t.prop} onChange={(v) => update(i, { prop: v.trim() || 'all' })} placeholder="all" mono />
            <RemoveBtn onClick={() => set(list.filter((_, j) => j !== i))} />
          </div>
          <div className="bk-insp-grid2">
            <NumberField
              value={t.duration}
              unit="ms"
              suffix="MS"
              step={50}
              min={0}
              onChange={(v) => {
                const p = parseNumUnit(v, 'ms');
                update(i, { duration: p.num == null ? '200ms' : `${p.num}${p.unit || 'ms'}` });
              }}
            />
            <SelectField value={t.easing} options={EASINGS} placeholder="ease" onChange={(v) => update(i, { easing: v || 'ease' })} />
          </div>
        </div>
      ))}
    </div>
  );
}

function RemoveBtn({ onClick }: { onClick: () => void }) {
  return (
    <button type="button" className="bk-insp-icon-btn is-danger" onClick={onClick} aria-label="Remove">
      <Minus size={12} weight="bold" />
    </button>
  );
}
