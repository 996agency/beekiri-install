/** Small CSS value helpers for the inspector (parse / format, no deps). */

export type NumUnit = { num: number | null; unit: string; raw: string };

const UNIT_RE = /^(-?\d*\.?\d+)\s*(px|%|em|rem|vh|vw|vmin|vmax|ch|ex|deg|s|ms|fr)?$/i;

export function parseNumUnit(raw: string | undefined, fallbackUnit = 'px'): NumUnit {
  const v = (raw ?? '').trim();
  const m = v.match(UNIT_RE);
  if (!m) return { num: null, unit: fallbackUnit, raw: v };
  return { num: Number(m[1]), unit: (m[2] || '').toLowerCase(), raw: v };
}

/** "12" → "12px" for length props; keeps keywords (auto, fit-content…) untouched. */
export function normalizeLength(input: string, defaultUnit = 'px'): string {
  const v = input.trim();
  if (!v) return '';
  if (/^-?\d*\.?\d+$/.test(v)) return defaultUnit ? `${v}${defaultUnit}` : v;
  return v;
}

const LENGTH_KEYWORDS = /^(auto|none|normal|inherit|initial|unset|fit-content|min-content|max-content|thin|medium|thick)$/i;
const CSS_FN = /^(calc|min|max|clamp|var)\(.*\)$/i;

/** Accepts numbers with units, common keywords and calc()/var() — rejects typos like "80px64". */
export function isValidLength(v: string): boolean {
  const t = v.trim();
  if (!t) return true;
  return UNIT_RE.test(t) || LENGTH_KEYWORDS.test(t) || CSS_FN.test(t);
}

export function stepValue(raw: string, delta: number, defaultUnit = 'px'): string {
  const { num, unit } = parseNumUnit(raw, defaultUnit);
  const base = num ?? 0;
  const next = Math.round((base + delta) * 100) / 100;
  return `${next}${unit || (defaultUnit && raw.trim() === '' ? defaultUnit : unit)}`;
}

/** Split on commas that are not inside parentheses — for box-shadow, transition, etc. */
export function splitTopLevel(value: string, sep = ','): string[] {
  const out: string[] = [];
  let depth = 0;
  let cur = '';
  for (const ch of value) {
    if (ch === '(') depth += 1;
    if (ch === ')') depth = Math.max(0, depth - 1);
    if (ch === sep && depth === 0) {
      if (cur.trim()) out.push(cur.trim());
      cur = '';
      continue;
    }
    cur += ch;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

/** Split on whitespace outside parentheses — "0 4px 12px rgba(0,0,0,.2)". */
export function splitSpaces(value: string): string[] {
  const out: string[] = [];
  let depth = 0;
  let cur = '';
  for (const ch of value) {
    if (ch === '(') depth += 1;
    if (ch === ')') depth = Math.max(0, depth - 1);
    if (/\s/.test(ch) && depth === 0) {
      if (cur) out.push(cur);
      cur = '';
      continue;
    }
    cur += ch;
  }
  if (cur) out.push(cur);
  return out;
}

/** "translateX(10px) rotate(5deg)" → [{fn, args}] */
export function parseFunctionList(value: string): { fn: string; args: string }[] {
  const out: { fn: string; args: string }[] = [];
  const re = /([a-zA-Z-]+)\(([^)]*)\)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(value))) out.push({ fn: m[1], args: m[2].trim() });
  return out;
}

/* ── Colors ─────────────────────────────────────────────────────────────── */

export type RGBA = { r: number; g: number; b: number; a: number };
export type HSVA = { h: number; s: number; v: number; a: number };

const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n));

const NAMED: Record<string, string> = {
  black: '#000000',
  white: '#ffffff',
  red: '#ff0000',
  green: '#008000',
  blue: '#0000ff',
  yellow: '#ffff00',
  orange: '#ffa500',
  purple: '#800080',
  gray: '#808080',
  grey: '#808080',
  tomato: '#ff6347',
};

export function parseColor(raw: string | undefined): RGBA | null {
  if (!raw) return null;
  let v = raw.trim().toLowerCase();
  if (!v) return null;
  if (v === 'transparent') return { r: 0, g: 0, b: 0, a: 0 };
  if (NAMED[v]) v = NAMED[v];

  const hex = v.match(/^#([0-9a-f]{3,8})$/i);
  if (hex) {
    let h = hex[1];
    if (h.length === 3 || h.length === 4) h = h.split('').map((c) => c + c).join('');
    if (h.length !== 6 && h.length !== 8) return null;
    return {
      r: parseInt(h.slice(0, 2), 16),
      g: parseInt(h.slice(2, 4), 16),
      b: parseInt(h.slice(4, 6), 16),
      a: h.length === 8 ? Math.round((parseInt(h.slice(6, 8), 16) / 255) * 100) / 100 : 1,
    };
  }

  const rgb = v.match(/^rgba?\(([^)]+)\)$/);
  if (rgb) {
    const parts = rgb[1].split(/[\s,/]+/).filter(Boolean);
    if (parts.length < 3) return null;
    const ch = (p: string) => (p.endsWith('%') ? (parseFloat(p) / 100) * 255 : parseFloat(p));
    const a = parts[3] == null ? 1 : parts[3].endsWith('%') ? parseFloat(parts[3]) / 100 : parseFloat(parts[3]);
    return {
      r: clamp(Math.round(ch(parts[0])), 0, 255),
      g: clamp(Math.round(ch(parts[1])), 0, 255),
      b: clamp(Math.round(ch(parts[2])), 0, 255),
      a: clamp(Number.isFinite(a) ? a : 1, 0, 1),
    };
  }
  return null;
}

const hex2 = (n: number) => clamp(Math.round(n), 0, 255).toString(16).padStart(2, '0');

export function toHex({ r, g, b }: RGBA): string {
  return `#${hex2(r)}${hex2(g)}${hex2(b)}`.toUpperCase();
}

/** Hex when opaque, rgba() otherwise — what we write into styles. */
export function formatColor(c: RGBA): string {
  if (c.a >= 1) return toHex(c);
  const a = Math.round(c.a * 100) / 100;
  return `rgba(${Math.round(c.r)}, ${Math.round(c.g)}, ${Math.round(c.b)}, ${a})`;
}

export function rgbToHsv({ r, g, b, a }: RGBA): HSVA {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const d = max - min;
  let h = 0;
  if (d) {
    if (max === rn) h = ((gn - bn) / d) % 6;
    else if (max === gn) h = (bn - rn) / d + 2;
    else h = (rn - gn) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
  }
  return { h, s: max ? d / max : 0, v: max, a };
}

export function hsvToRgb({ h, s, v, a }: HSVA): RGBA {
  const c = v * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = v - c;
  let rp = 0;
  let gp = 0;
  let bp = 0;
  if (h < 60) [rp, gp, bp] = [c, x, 0];
  else if (h < 120) [rp, gp, bp] = [x, c, 0];
  else if (h < 180) [rp, gp, bp] = [0, c, x];
  else if (h < 240) [rp, gp, bp] = [0, x, c];
  else if (h < 300) [rp, gp, bp] = [x, 0, c];
  else [rp, gp, bp] = [c, 0, x];
  return { r: (rp + m) * 255, g: (gp + m) * 255, b: (bp + m) * 255, a };
}

const COLOR_KEYS = new Set([
  'color',
  'backgroundColor',
  'background',
  'borderColor',
  'borderTopColor',
  'borderRightColor',
  'borderBottomColor',
  'borderLeftColor',
]);

/** Distinct solid colors already used on the page — "Document" swatches. */
export function collectDocumentColors(
  styles: (Record<string, string> | undefined)[],
  limit = 12,
): string[] {
  const seen = new Set<string>();
  for (const bag of styles) {
    if (!bag) continue;
    for (const [k, v] of Object.entries(bag)) {
      if (!COLOR_KEYS.has(k)) continue;
      const c = parseColor(v);
      if (!c || c.a === 0) continue;
      seen.add(formatColor(c));
      if (seen.size >= limit) return [...seen];
    }
  }
  return [...seen];
}
