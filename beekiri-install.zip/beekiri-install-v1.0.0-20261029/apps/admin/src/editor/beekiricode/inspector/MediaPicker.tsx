import { useCallback, useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { Check, File as FileIcon, MagnifyingGlass, UploadSimple, X } from '@phosphor-icons/react';
import { api, apiUpload } from '../../../api/client';

export type MediaItem = {
  id: string;
  filename: string;
  originalName: string;
  mimeType: string;
  url: string;
  alt: string;
  width?: number | null;
  height?: number | null;
  size?: number;
};

/* —— shared media cache so previews resolve ids without refetching —— */

const cache = new Map<string, MediaItem>();
let inflight: Promise<MediaItem[]> | null = null;
const listeners = new Set<() => void>();

export function loadMedia(force = false): Promise<MediaItem[]> {
  if (!inflight || force) {
    inflight = api<{ items: MediaItem[] }>('/api/media')
      .then((r) => {
        for (const it of r.items ?? []) cache.set(it.id, it);
        listeners.forEach((l) => l());
        return r.items ?? [];
      })
      .catch((e) => {
        inflight = null;
        throw e;
      });
  }
  return inflight;
}

function remember(item: MediaItem) {
  cache.set(item.id, item);
  listeners.forEach((l) => l());
}

const looksLikeUrl = (s: string) => /^(https?:)?\/\//.test(s) || s.startsWith('/');

/** Resolve a stored value (media id, or a legacy URL) to something previewable. */
export function useMediaItem(value: string): MediaItem | null {
  const [, tick] = useState(0);
  useEffect(() => {
    const l = () => tick((n) => n + 1);
    listeners.add(l);
    if (value && !looksLikeUrl(value) && !cache.has(value)) void loadMedia().catch(() => {});
    return () => {
      listeners.delete(l);
    };
  }, [value]);
  if (!value) return null;
  if (looksLikeUrl(value)) {
    const name = value.split('/').pop() || value;
    return { id: value, filename: name, originalName: name, mimeType: /\.(png|jpe?g|webp|gif|svg|avif)$/i.test(value) ? 'image/*' : '', url: value, alt: '' };
  }
  return cache.get(value) ?? null;
}

export function formatBytes(n?: number) {
  if (!n) return '';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

const isImage = (m: MediaItem) => (m.mimeType || '').startsWith('image/');

/* —— modal —— */

export function MediaPicker({
  open,
  onClose,
  onSelect,
  kind = 'image',
  multiple = false,
  selected = [],
  title,
}: {
  open: boolean;
  onClose: () => void;
  onSelect: (items: MediaItem[]) => void;
  kind?: 'image' | 'file';
  multiple?: boolean;
  selected?: string[];
  title?: string;
}) {
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [picked, setPicked] = useState<string[]>([]);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setItems(await loadMedia(true));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load media.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!open) return;
    setPicked(multiple ? [] : selected.slice(0, 1));
    void refresh();
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items
      .filter((i) => (kind === 'image' ? isImage(i) : true))
      .filter((i) => !q || `${i.originalName} ${i.filename} ${i.alt}`.toLowerCase().includes(q));
  }, [items, kind, query]);

  const upload = async (files: FileList | null) => {
    if (!files?.length) return;
    setUploading(true);
    setError(null);
    const added: MediaItem[] = [];
    try {
      for (const file of Array.from(files)) {
        const form = new FormData();
        form.append('file', file);
        const res = await apiUpload<{ item: MediaItem }>('/api/media/upload', form);
        remember(res.item);
        added.push(res.item);
      }
      setItems((prev) => [...added, ...prev]);
      if (!multiple && added[0]) {
        onSelect([added[0]]);
        onClose();
      } else {
        setPicked((p) => [...p, ...added.map((a) => a.id)]);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Upload failed.');
    } finally {
      setUploading(false);
    }
  };

  const toggle = (it: MediaItem) => {
    if (!multiple) {
      onSelect([it]);
      onClose();
      return;
    }
    setPicked((p) => (p.includes(it.id) ? p.filter((x) => x !== it.id) : [...p, it.id]));
  };

  if (!open) return null;

  return createPortal(
    <div
      className="bk-insp-pop bk-mp"
      role="dialog"
      aria-modal="true"
      aria-label={title ?? 'Media library'}
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="bk-mp__panel">
        <div className="bk-mp__head">
          <h2>{title ?? (kind === 'image' ? (multiple ? 'Add to gallery' : 'Select image') : 'Select file')}</h2>
          <button type="button" className="bk-mp__icon" onClick={onClose} aria-label="Close">
            <X size={16} weight="bold" />
          </button>
        </div>
        <div className="bk-mp__toolbar">
          <label className="bk-mp__search">
            <MagnifyingGlass size={14} />
            <input type="search" placeholder="Search media…" value={query} onChange={(e) => setQuery(e.target.value)} />
          </label>
          <label className="bk-mp__upload">
            <UploadSimple size={14} weight="bold" />
            {uploading ? 'Uploading…' : 'Upload files'}
            <input
              type="file"
              hidden
              multiple={multiple}
              accept={kind === 'image' ? 'image/*' : undefined}
              disabled={uploading}
              onChange={(e) => {
                void upload(e.target.files);
                e.target.value = '';
              }}
            />
          </label>
        </div>
        <div
          className="bk-mp__body"
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            void upload(e.dataTransfer.files);
          }}
        >
          {error ? <p className="bk-mp__error">{error}</p> : null}
          {loading && !items.length ? (
            <p className="bk-mp__hint">Loading media…</p>
          ) : visible.length === 0 ? (
            <p className="bk-mp__hint">No {kind === 'image' ? 'images' : 'files'} yet. Upload or drop files here.</p>
          ) : (
            <ul className="bk-mp__grid">
              {visible.map((it) => {
                const on = picked.includes(it.id) || (!multiple && selected.includes(it.id));
                return (
                  <li key={it.id}>
                    <button type="button" className={`bk-mp__item${on ? ' is-selected' : ''}`} onClick={() => toggle(it)} title={it.originalName}>
                      {isImage(it) ? (
                        <img src={it.url} alt={it.alt} loading="lazy" />
                      ) : (
                        <span className="bk-mp__file">
                          <FileIcon size={28} />
                          <small>{it.originalName}</small>
                        </span>
                      )}
                      {on ? (
                        <span className="bk-mp__check">
                          <Check size={11} weight="bold" />
                        </span>
                      ) : null}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
        {multiple ? (
          <div className="bk-mp__foot">
            <span>{picked.length} selected</span>
            <button type="button" className="bk-mp__btn" onClick={onClose}>
              Cancel
            </button>
            <button
              type="button"
              className="bk-mp__btn is-primary"
              disabled={!picked.length}
              onClick={() => {
                onSelect(picked.map((id) => cache.get(id)).filter((x): x is MediaItem => !!x));
                onClose();
              }}
            >
              Add {picked.length ? picked.length : ''}
            </button>
          </div>
        ) : null}
      </div>
    </div>,
    document.body,
  );
}
