import { useEffect, useRef, useState, type ReactNode, type PointerEvent as ReactPointerEvent } from 'react';
import { CaretDown, Plus } from '@phosphor-icons/react';
import { isValidLength, normalizeLength, parseNumUnit, stepValue } from './css-values';

/* ── Section ────────────────────────────────────────────────────────────── */

const openState = new Map<string, boolean>();

export function Section({
  id,
  title,
  defaultOpen = true,
  active,
  actions,
  children,
}: {
  id: string;
  title: string;
  defaultOpen?: boolean;
  /** Shows a dot when the section has values set. */
  active?: boolean;
  actions?: ReactNode;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(() => openState.get(id) ?? defaultOpen);
  const toggle = () => {
    setOpen((o) => {
      openState.set(id, !o);
      return !o;
    });
  };
  return (
    <section className={`bk-insp-section${open ? ' is-open' : ''}`}>
      <header className="bk-insp-section__head">
        <button type="button" className="bk-insp-section__toggle" onClick={toggle} aria-expanded={open}>
          <span className="bk-insp-section__title">{title}</span>
          {active ? <span className="bk-insp-section__dot" aria-label="Has values" /> : null}
        </button>
        <div className="bk-insp-section__actions">
          {actions}
          <button type="button" className="bk-insp-section__caret" onClick={toggle} aria-label={open ? 'Collapse' : 'Expand'}>
            <CaretDown size={12} weight="bold" />
          </button>
        </div>
      </header>
      {open ? <div className="bk-insp-section__body">{children}</div> : null}
    </section>
  );
}

/* ── Layout helpers ─────────────────────────────────────────────────────── */

export function Field({ label, children, wide }: { label: string; children: ReactNode; wide?: boolean }) {
  return (
    <div className={`bk-insp-field${wide ? ' is-wide' : ''}`}>
      <span className="bk-insp-field__label">{label}</span>
      <div className="bk-insp-field__control">{children}</div>
    </div>
  );
}

export function Grid2({ children }: { children: ReactNode }) {
  return <div className="bk-insp-grid2">{children}</div>;
}

export function SubHead({ children, onAdd }: { children: ReactNode; onAdd?: () => void }) {
  return (
    <div className="bk-insp-subhead">
      <span>{children}</span>
      {onAdd ? (
        <button type="button" className="bk-insp-icon-btn" onClick={onAdd} aria-label={`Add ${String(children)}`}>
          <Plus size={13} weight="bold" />
        </button>
      ) : null}
    </div>
  );
}

/* ── Inputs ─────────────────────────────────────────────────────────────── */

/** Commit-on-blur/Enter text input that resyncs when the external value changes. */
function useDraft(value: string) {
  const [draft, setDraft] = useState(value);
  const focused = useRef(false);
  useEffect(() => {
    if (!focused.current) setDraft(value);
  }, [value]);
  return { draft, setDraft, focused };
}

export function TextField({
  value,
  onChange,
  placeholder,
  live,
  mono,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  /** Commit on every keystroke instead of blur. */
  live?: boolean;
  mono?: boolean;
}) {
  const { draft, setDraft, focused } = useDraft(value);
  return (
    <input
      className={`bk-insp-input${mono ? ' is-mono' : ''}`}
      value={draft}
      placeholder={placeholder}
      spellCheck={false}
      onFocus={() => (focused.current = true)}
      onChange={(e) => {
        setDraft(e.target.value);
        if (live) onChange(e.target.value);
      }}
      onBlur={() => {
        focused.current = false;
        if (draft !== value) onChange(draft);
      }}
      onKeyDown={(e) => {
        if (e.key === 'Enter') {
          if (draft !== value) onChange(draft);
          (e.target as HTMLInputElement).blur();
        }
        if (e.key === 'Escape') {
          setDraft(value);
          (e.target as HTMLInputElement).blur();
        }
      }}
    />
  );
}

export function TextArea({ value, onChange, placeholder, rows = 3 }: { value: string; onChange: (v: string) => void; placeholder?: string; rows?: number }) {
  return (
    <textarea
      className="bk-insp-input bk-insp-textarea"
      value={value}
      rows={rows}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}

/**
 * Number/length input with a suffix label (WIDTH, PX, …).
 * Arrow keys step (Shift ×10), drag the suffix to scrub, bare numbers get `unit`.
 */
export function NumberField({
  value,
  onChange,
  suffix,
  unit = 'px',
  placeholder = 'Auto',
  step = 1,
  min,
  icon,
}: {
  value: string;
  onChange: (v: string) => void;
  suffix?: string;
  unit?: string;
  placeholder?: string;
  step?: number;
  min?: number;
  icon?: ReactNode;
}) {
  const { draft, setDraft, focused } = useDraft(value);

  const commit = (v: string) => {
    if (!isValidLength(v)) {
      setDraft(value);
      return;
    }
    let next = normalizeLength(v, unit);
    if (min != null) {
      const p = parseNumUnit(next, unit);
      if (p.num != null && p.num < min) next = `${min}${p.unit}`;
    }
    if (next !== value) onChange(next);
  };

  const bump = (delta: number) => {
    let next = stepValue(draft, delta, unit);
    if (min != null) {
      const p = parseNumUnit(next, unit);
      if (p.num != null && p.num < min) next = `${min}${p.unit}`;
    }
    setDraft(next);
    onChange(next);
  };

  const scrub = (e: ReactPointerEvent<HTMLSpanElement>) => {
    const start = parseNumUnit(draft, unit);
    if (draft && start.num == null) return;
    e.preventDefault();
    const startX = e.clientX;
    const base = start.num ?? 0;
    const u = draft ? start.unit : unit;
    const el = e.currentTarget;
    el.setPointerCapture(e.pointerId);
    const move = (ev: PointerEvent) => {
      const mult = ev.shiftKey ? 10 : 1;
      let n = Math.round((base + Math.round((ev.clientX - startX) / 2) * step * mult) * 100) / 100;
      if (min != null) n = Math.max(min, n);
      const next = `${n}${u}`;
      setDraft(next);
      onChange(next);
    };
    const up = () => {
      el.removeEventListener('pointermove', move);
      el.removeEventListener('pointerup', up);
    };
    el.addEventListener('pointermove', move);
    el.addEventListener('pointerup', up);
  };

  return (
    <label className="bk-insp-num">
      {icon ? <span className="bk-insp-num__icon">{icon}</span> : null}
      <input
        className="bk-insp-num__input"
        value={draft}
        placeholder={placeholder}
        spellCheck={false}
        onFocus={(e) => {
          focused.current = true;
          e.target.select();
        }}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={() => {
          focused.current = false;
          commit(draft);
        }}
        onKeyDown={(e) => {
          if (e.key === 'Enter') {
            commit(draft);
            (e.target as HTMLInputElement).blur();
          }
          if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
            e.preventDefault();
            bump((e.key === 'ArrowUp' ? step : -step) * (e.shiftKey ? 10 : 1));
          }
          if (e.key === 'Escape') {
            setDraft(value);
            (e.target as HTMLInputElement).blur();
          }
        }}
      />
      {suffix ? (
        <span className="bk-insp-num__suffix" onPointerDown={scrub} title="Drag to adjust">
          {suffix}
        </span>
      ) : null}
    </label>
  );
}

export function SelectField({
  value,
  onChange,
  options,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  options: (string | { value: string; label: string })[];
  placeholder?: string;
}) {
  const opts = options.map((o) => (typeof o === 'string' ? { value: o, label: o } : o));
  const known = opts.some((o) => o.value === value);
  return (
    <select className="bk-insp-input bk-insp-select" value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="">{placeholder ?? 'Default'}</option>
      {!known && value ? <option value={value}>{value}</option> : null}
      {opts.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}

/* ── Segmented icon group ───────────────────────────────────────────────── */

export type SegOption = { value: string; label: string; icon?: ReactNode };

export function Segmented({
  value,
  onChange,
  options,
  allowEmpty = true,
  compact,
}: {
  value: string;
  onChange: (v: string) => void;
  options: SegOption[];
  /** Clicking the active option clears it. */
  allowEmpty?: boolean;
  compact?: boolean;
}) {
  return (
    <div className={`bk-insp-seg${compact ? ' is-compact' : ''}`} role="radiogroup">
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            type="button"
            role="radio"
            aria-checked={active}
            title={o.label}
            aria-label={o.label}
            className={`bk-insp-seg__btn${active ? ' is-active' : ''}`}
            onClick={() => onChange(active && allowEmpty ? '' : o.value)}
          >
            {o.icon ?? o.label}
          </button>
        );
      })}
    </div>
  );
}

/* ── Slider + number ────────────────────────────────────────────────────── */

export function SliderField({
  value,
  onChange,
  min = 0,
  max = 100,
  step = 1,
  unit = 'px',
  suffix,
  leading,
  fallback,
}: {
  value: string;
  onChange: (v: string) => void;
  min?: number;
  max?: number;
  step?: number;
  /** Unit written to the style ('' for unitless like opacity). */
  unit?: string;
  suffix?: string;
  leading?: ReactNode;
  /** Shown when unset (e.g. opacity 100). */
  fallback?: number;
}) {
  const parsed = parseNumUnit(value, unit);
  const num = parsed.num ?? fallback ?? min;
  const pct = ((Math.min(max, Math.max(min, num)) - min) / (max - min)) * 100;
  return (
    <div className="bk-insp-slider">
      {leading ? <span className="bk-insp-slider__lead">{leading}</span> : null}
      <input
        type="range"
        className="bk-insp-slider__range"
        min={min}
        max={max}
        step={step}
        value={num}
        style={{ ['--bk-fill' as string]: `${pct}%` }}
        onChange={(e) => onChange(`${e.target.value}${unit}`)}
      />
      <div className="bk-insp-slider__num">
        <NumberField
          value={value}
          onChange={onChange}
          unit={unit}
          suffix={suffix ?? (unit || undefined)}
          placeholder={String(fallback ?? 0)}
          step={step}
          min={min}
        />
      </div>
    </div>
  );
}

/* ── Toggle switch ──────────────────────────────────────────────────────── */

export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      className={`bk-insp-switch${checked ? ' is-on' : ''}`}
      onClick={() => onChange(!checked)}
    >
      <span className="bk-insp-switch__label">{label}</span>
      <span className="bk-insp-switch__track">
        <span className="bk-insp-switch__thumb" />
      </span>
    </button>
  );
}
