import { useState } from 'react';
import { LinkSimple, LinkBreak } from '@phosphor-icons/react';
import { readBoxSide, type StyleBag } from '../styleHelpers';
import { isValidLength, normalizeLength, stepValue } from './css-values';

type Box = 'margin' | 'padding';
type Side = 'Top' | 'Right' | 'Bottom' | 'Left';
const SIDES: Side[] = ['Top', 'Right', 'Bottom', 'Left'];

/**
 * Figma-style box model: dashed margin ring, blue padding ring, link toggle in the middle.
 * Emits a patch of longhands (shorthand removed) so breakpoint bags stay explicit.
 */
export function BoxModel({
  style,
  onPatch,
}: {
  style: StyleBag;
  onPatch: (patch: Record<string, string | undefined>) => void;
}) {
  const [linked, setLinked] = useState(false);

  const write = (box: Box, side: Side, raw: string) => {
    if (!isValidLength(raw)) return;
    const v = normalizeLength(raw);
    const patch: Record<string, string | undefined> = { [box]: undefined };
    const sides = linked && box === 'padding' ? SIDES : [side];
    for (const s of SIDES) {
      const key = `${box}${s}`;
      patch[key] = sides.includes(s) ? v || undefined : readBoxSide(style, box, s) || undefined;
    }
    onPatch(patch);
  };

  const input = (box: Box, side: Side) => (
    <SideInput
      key={`${box}-${side}`}
      className={`bk-insp-box__in is-${side.toLowerCase()}`}
      value={readBoxSide(style, box, side)}
      onCommit={(v) => write(box, side, v)}
      label={`${box} ${side.toLowerCase()}`}
    />
  );

  return (
    <div className="bk-insp-box">
      <div className="bk-insp-box__margin">
        <span className="bk-insp-box__tag">Margin</span>
        {SIDES.map((s) => input('margin', s))}
        <div className="bk-insp-box__padding">
          <span className="bk-insp-box__tag is-padding">Padding</span>
          {SIDES.map((s) => input('padding', s))}
          <button
            type="button"
            className={`bk-insp-box__link${linked ? ' is-on' : ''}`}
            onClick={() => setLinked((l) => !l)}
            title={linked ? 'Padding sides linked' : 'Link padding sides'}
            aria-pressed={linked}
          >
            {linked ? <LinkSimple size={13} weight="bold" /> : <LinkBreak size={13} weight="bold" />}
          </button>
        </div>
      </div>
    </div>
  );
}

function SideInput({
  value,
  onCommit,
  className,
  label,
}: {
  value: string;
  onCommit: (v: string) => void;
  className: string;
  label: string;
}) {
  const [draft, setDraft] = useState<string | null>(null);
  const shown = draft ?? value;
  return (
    <input
      className={className}
      value={shown}
      placeholder="0"
      aria-label={label}
      spellCheck={false}
      onFocus={(e) => {
        setDraft(value);
        e.target.select();
      }}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={() => {
        if (draft !== null && draft !== value) onCommit(draft);
        setDraft(null);
      }}
      onKeyDown={(e) => {
        if (e.key === 'Enter') {
          if (draft !== null && draft !== value) onCommit(draft);
          setDraft(null);
          (e.target as HTMLInputElement).blur();
        }
        if (e.key === 'Escape') {
          setDraft(null);
          (e.target as HTMLInputElement).blur();
        }
        if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
          e.preventDefault();
          const next = stepValue(shown, (e.key === 'ArrowUp' ? 1 : -1) * (e.shiftKey ? 10 : 1));
          setDraft(next);
          onCommit(next);
        }
      }}
    />
  );
}
