import { useMemo, useState, type ReactNode } from 'react';
import {
  AlignBottom,
  AlignCenterHorizontal,
  AlignCenterVertical,
  AlignLeft,
  AlignRight,
  AlignTop,
  ArrowDown,
  ArrowRight,
  Desktop,
  DeviceMobile,
  DeviceTablet,
  Eye,
  FileText,
  TextAlignCenter,
  TextAlignJustify,
  TextAlignLeft,
  TextAlignRight,
  TextItalic,
  TextStrikethrough,
  TextUnderline,
  X,
} from '@phosphor-icons/react';
import { MODULES, type BeekiriCodeNode, type BeekiriCodeNodeType, type HiddenBreakpoint } from './document';
import {
  applyBreakpointStylePatch,
  getOverrideBag,
  resolveStyleForBreakpoint,
  type StyleBreakpoint,
} from './responsiveStyles';
import {
  BG_KEYS,
  BORDER_KEYS,
  EFFECT_KEYS,
  LAYOUT_KEYS,
  SIZE_KEYS,
  SPACING_KEYS,
  TYPE_KEYS,
  countSetKeys,
  type StyleBag,
} from './styleHelpers';
import {
  Field,
  Grid2,
  NumberField,
  Section,
  Segmented,
  SelectField,
  SliderField,
  Switch,
  TextArea,
  TextField,
} from './inspector/controls';
import { ColorField } from './inspector/ColorPicker';
import { FontPicker } from './inspector/FontPicker';
import { BoxModel } from './inspector/BoxModel';
import { FilterList, ShadowList, TransformList, TransitionList } from './inspector/EffectLists';
import { parseColor, splitSpaces } from './inspector/css-values';
import { AcfFieldList } from './inspector/AcfFieldInputs';
import type { BackendField } from '../../fields/acf-types';
import './inspector/inspector.css';

export type LayoutFieldDef = BackendField;

type Props = {
  node: BeekiriCodeNode | null;
  /** True when the selected node is the page root (whole page). */
  isPageRoot?: boolean;
  onUpdate: (patch: Partial<BeekiriCodeNode>) => void;
  /** Floating overlay (legacy) or bare body for left Explorer tab. */
  variant?: 'floating' | 'embedded';
  onClose?: () => void;
  /** Where style edits write: base = all breakpoints, or tablet/mobile only. */
  editTarget?: StyleBreakpoint;
  onSelectPage?: () => void;
  /** Backend Fields defs for the selected layout (labels / types). */
  layoutFieldDefs?: LayoutFieldDef[];
  /** Colors already used on the page — shown as "Document" swatches. */
  documentColors?: string[];
  showHidden?: boolean;
  onShowHiddenChange?: (v: boolean) => void;
};

const POSITION_KEYS = ['position', 'top', 'right', 'bottom', 'left', 'zIndex'];

const TYPE_LABEL: Record<BeekiriCodeNodeType, string> = {
  section: 'Section',
  container: 'Container',
  heading: 'Heading',
  text: 'Text',
  image: 'Image',
  button: 'Button',
  layout: 'Layout',
};

function defaultsForType(type: BeekiriCodeNodeType): Partial<BeekiriCodeNode> {
  const def = MODULES.find((m) => m.type === type)?.create();
  if (!def) return { type };
  return { type: def.type, tag: def.tag, text: def.text, src: def.src, alt: def.alt, href: def.href };
}

/** Split legacy `border: 1px solid #ccc` into longhands so side/width edits compose. */
function expandBorderShorthand(bag: StyleBag): Record<string, string | undefined> {
  const raw = bag.border;
  if (!raw) return {};
  const out: Record<string, string | undefined> = { border: undefined };
  for (const t of splitSpaces(raw)) {
    if (/^(none|solid|dashed|dotted|double|groove|ridge|inset|outset)$/.test(t)) out.borderStyle ??= t;
    else if (parseColor(t)) out.borderColor ??= t;
    else if (/^-?\d/.test(t) || /^(thin|medium|thick)$/.test(t)) out.borderWidth ??= t;
  }
  return out;
}

export function PropertiesPanel({
  node,
  isPageRoot = false,
  onUpdate,
  variant = 'floating',
  onClose,
  editTarget = 'base',
  onSelectPage,
  layoutFieldDefs,
  documentColors = [],
  showHidden = false,
  onShowHiddenChange,
}: Props) {
  const embedded = variant === 'embedded';

  const body = !node ? (
    <div className="bk-insp-empty">
      <div className="bk-insp-empty__icon">
        <FileText size={20} />
      </div>
      <p className="bk-insp-empty__title">Nothing selected</p>
      <p className="bk-insp-empty__text">Click an element on the canvas or in Layers to edit its properties.</p>
      {onSelectPage ? (
        <button type="button" className="bk-insp-btn" onClick={onSelectPage}>
          Edit page body
        </button>
      ) : null}
    </div>
  ) : (
    <Inspector
      key={node.id}
      node={node}
      isPageRoot={isPageRoot}
      onUpdate={onUpdate}
      editTarget={editTarget}
      onSelectPage={onSelectPage}
      layoutFieldDefs={layoutFieldDefs}
      documentColors={documentColors}
      showHidden={showHidden}
      onShowHiddenChange={onShowHiddenChange}
    />
  );

  if (embedded) return <div className="bk-insp" aria-label="Properties">{body}</div>;

  return (
    <aside className="bk-beekiricode__panel bk-beekiricode__panel--right bk-beekiricode__panel--props" aria-label="Properties">
      <div className="bk-beekiricode__panel-head">
        <span>Properties</span>
        {onClose ? (
          <button type="button" className="bk-beekiricode__btn" onClick={onClose} aria-label="Close">
            <X size={12} weight="bold" />
          </button>
        ) : null}
      </div>
      <div className="bk-insp">{body}</div>
    </aside>
  );
}

/* ── Inspector body ─────────────────────────────────────────────────────── */

function Inspector({
  node,
  isPageRoot,
  onUpdate,
  editTarget,
  onSelectPage,
  layoutFieldDefs,
  documentColors,
  showHidden,
  onShowHiddenChange,
}: Required<Pick<Props, 'onUpdate' | 'editTarget' | 'documentColors' | 'showHidden'>> &
  Pick<Props, 'onSelectPage' | 'layoutFieldDefs' | 'onShowHiddenChange'> & {
    node: BeekiriCodeNode;
    isPageRoot: boolean;
  }) {
  const bag = getOverrideBag(node, editTarget);
  const effective = resolveStyleForBreakpoint(node, editTarget === 'base' ? 'desktop' : editTarget);
  const isOverride = editTarget !== 'base';

  const val = (k: string) => bag[k] ?? '';
  /** In tablet/mobile mode show the inherited value as a placeholder. */
  const ph = (k: string, fallback = '') => (isOverride ? effective[k] || fallback : fallback);
  const set = (patch: Record<string, string | undefined>) => onUpdate(applyBreakpointStylePatch(node, editTarget, patch));
  const setKey = (k: string) => (v: string) => set({ [k]: v });

  const isBox = isPageRoot || node.type === 'section' || node.type === 'container' || node.type === 'layout';
  const count = (keys: string[]) => countSetKeys(bag, keys) > 0;

  const title = isPageRoot ? 'Page body' : node.type === 'layout' ? node.layoutTitle || node.layoutSlug || 'Layout' : TYPE_LABEL[node.type];

  return (
    <>
      <div className="bk-insp-head">
        <div className="bk-insp-head__main">
          <span className="bk-insp-head__kind">{isPageRoot ? 'Page' : TYPE_LABEL[node.type]}</span>
          <span className="bk-insp-head__title">{title}</span>
        </div>
        <span className={`bk-insp-scope${isOverride ? ' is-override' : ''}`} title={isOverride ? 'Only this breakpoint' : 'Applies to every breakpoint'}>
          {editTarget === 'tablet' ? <DeviceTablet size={12} /> : editTarget === 'mobile' ? <DeviceMobile size={12} /> : <Desktop size={12} />}
          {editTarget === 'base' ? 'All' : editTarget === 'tablet' ? 'Tablet' : 'Mobile'}
        </span>
      </div>

      <AlignBar node={node} isBox={isBox} bag={bag} effective={effective} set={set} />

      {!isPageRoot && onSelectPage ? (
        <button type="button" className="bk-insp-link" onClick={onSelectPage}>
          Edit page body →
        </button>
      ) : null}

      {!isPageRoot ? (
        <Section id="content" title={node.type === 'layout' ? 'Backend Fields' : 'Content'}>
          <ContentFields node={node} onUpdate={onUpdate} layoutFieldDefs={layoutFieldDefs} documentColors={documentColors} />
        </Section>
      ) : null}

      {isBox ? (
        <Section id="layout" title="Layout" active={count(LAYOUT_KEYS)}>
          <LayoutFields val={val} ph={ph} set={set} effective={effective} />
        </Section>
      ) : null}

      <Section id="size" title="Size" active={count(SIZE_KEYS)}>
        <Grid2>
          <NumberField value={val('width')} onChange={setKey('width')} suffix="W" placeholder={ph('width', 'Auto')} />
          <NumberField value={val('height')} onChange={setKey('height')} suffix="H" placeholder={ph('height', 'Auto')} />
          <NumberField value={val('minWidth')} onChange={setKey('minWidth')} suffix="Min W" placeholder={ph('minWidth', '—')} min={0} />
          <NumberField value={val('minHeight')} onChange={setKey('minHeight')} suffix="Min H" placeholder={ph('minHeight', '—')} min={0} />
          <NumberField value={val('maxWidth')} onChange={setKey('maxWidth')} suffix="Max W" placeholder={ph('maxWidth', '—')} min={0} />
          <NumberField value={val('maxHeight')} onChange={setKey('maxHeight')} suffix="Max H" placeholder={ph('maxHeight', '—')} min={0} />
        </Grid2>
        <Field label="Overflow">
          <SelectField value={val('overflow')} onChange={setKey('overflow')} options={['visible', 'hidden', 'clip', 'scroll', 'auto']} placeholder={ph('overflow', 'Default')} />
        </Field>
        {node.type === 'image' ? (
          <Field label="Fit">
            <SelectField value={val('objectFit')} onChange={setKey('objectFit')} options={['cover', 'contain', 'fill', 'none', 'scale-down']} placeholder={ph('objectFit', 'Default')} />
          </Field>
        ) : null}
        <Field label="Aspect">
          <TextField value={val('aspectRatio')} onChange={setKey('aspectRatio')} placeholder={ph('aspectRatio', 'Auto · e.g. 16 / 9')} />
        </Field>
      </Section>

      <Section id="spacing" title="Spacing" active={count(SPACING_KEYS)}>
        <BoxModel style={isOverride ? effective : bag} onPatch={set} />
      </Section>

      {!isPageRoot ? (
        <Section id="position" title="Position" defaultOpen={false} active={count(POSITION_KEYS)}>
          <PositionFields val={val} ph={ph} set={set} />
        </Section>
      ) : null}

      <Section id="border" title="Border" defaultOpen={false} active={count(BORDER_KEYS)}>
        <BorderFields bag={bag} val={val} set={set} documentColors={documentColors} />
      </Section>

      {node.type !== 'image' ? (
        <Section id="typography" title="Typography" active={count(TYPE_KEYS)}>
          <TypographyFields val={val} ph={ph} set={set} documentColors={documentColors} />
        </Section>
      ) : null}

      <Section id="background" title="Background" active={count(BG_KEYS)}>
        <BackgroundFields val={val} set={set} documentColors={documentColors} />
      </Section>

      {!isPageRoot ? (
        <Section id="responsive" title="Responsive" defaultOpen={false} active={(node.hiddenOn?.length ?? 0) > 0}>
          <VisibilityFields node={node} onUpdate={onUpdate} showHidden={showHidden} onShowHiddenChange={onShowHiddenChange} />
        </Section>
      ) : null}

      <Section id="effect" title="Effect" defaultOpen={false} active={count([...EFFECT_KEYS, 'transition'])}>
        <SliderField
          value={val('opacity') ? String(Math.round(Number(val('opacity')) * 100)) : ''}
          onChange={(v) => {
            const n = parseFloat(v);
            set({ opacity: Number.isFinite(n) ? String(Math.min(100, Math.max(0, n)) / 100) : undefined });
          }}
          min={0}
          max={100}
          unit=""
          suffix="%"
          fallback={100}
          leading={<Eye size={14} />}
        />
        <ShadowList value={val('boxShadow')} onChange={setKey('boxShadow')} documentColors={documentColors} />
        <TransformList value={val('transform')} onChange={setKey('transform')} />
        <TransitionList value={val('transition')} onChange={setKey('transition')} />
        <FilterList value={val('filter')} onChange={setKey('filter')} />
      </Section>
    </>
  );
}

type Setter = (patch: Record<string, string | undefined>) => void;
type Val = (k: string) => string;
type Ph = (k: string, fallback?: string) => string;

/* ── Alignment toolbar ──────────────────────────────────────────────────── */

function AlignBar({
  node,
  isBox,
  bag,
  effective,
  set,
}: {
  node: BeekiriCodeNode;
  isBox: boolean;
  bag: StyleBag;
  effective: StyleBag;
  set: Setter;
}) {
  const display = bag.display || effective.display || '';
  const isFlex = display.includes('flex');
  const column = (bag.flexDirection || effective.flexDirection || 'row').startsWith('column');
  const hKey = column ? 'alignItems' : 'justifyContent';
  const vKey = column ? 'justifyContent' : 'alignItems';
  const canBoxAlign = isBox && node.type !== 'layout';

  const hValue = (() => {
    if (canBoxAlign && isFlex) return effective[hKey] || '';
    if (node.type === 'image') {
      const l = effective.marginLeft;
      const r = effective.marginRight;
      if (l === 'auto' && r === 'auto') return 'center';
      if (l === 'auto') return 'flex-end';
      if (r === 'auto') return 'flex-start';
      return '';
    }
    const t = effective.textAlign;
    return t === 'left' ? 'flex-start' : t === 'center' ? 'center' : t === 'right' ? 'flex-end' : '';
  })();
  const vValue = canBoxAlign && isFlex ? effective[vKey] || '' : '';

  const setH = (v: string) => {
    if (canBoxAlign) {
      set(isFlex ? { [hKey]: v } : { display: 'flex', flexDirection: 'column', alignItems: v });
      return;
    }
    if (node.type === 'image') {
      set({
        display: 'block',
        marginLeft: v === 'flex-start' ? '0px' : 'auto',
        marginRight: v === 'flex-end' ? '0px' : 'auto',
        margin: undefined,
      });
      return;
    }
    set({ textAlign: v === 'flex-start' ? 'left' : v === 'flex-end' ? 'right' : 'center' });
  };

  const setV = (v: string) => {
    if (!canBoxAlign) return;
    set(isFlex ? { [vKey]: v } : { display: 'flex', flexDirection: 'column', justifyContent: v });
  };

  const btn = (icon: ReactNode, label: string, active: boolean, onClick: () => void, disabled = false) => (
    <button
      type="button"
      className={`bk-insp-align__btn${active ? ' is-active' : ''}`}
      title={label}
      aria-label={label}
      aria-pressed={active}
      disabled={disabled}
      onClick={onClick}
    >
      {icon}
    </button>
  );

  const vDisabled = !canBoxAlign;
  return (
    <div className="bk-insp-align" role="toolbar" aria-label="Alignment">
      <div className="bk-insp-align__group">
        {btn(<AlignLeft size={15} />, 'Align left', hValue === 'flex-start' || hValue === 'start', () => setH('flex-start'))}
        {btn(<AlignCenterHorizontal size={15} />, 'Align center', hValue === 'center', () => setH('center'))}
        {btn(<AlignRight size={15} />, 'Align right', hValue === 'flex-end' || hValue === 'end', () => setH('flex-end'))}
      </div>
      <div className="bk-insp-align__group">
        {btn(<AlignTop size={15} />, 'Align top', vValue === 'flex-start' || vValue === 'start', () => setV('flex-start'), vDisabled)}
        {btn(<AlignCenterVertical size={15} />, 'Align middle', vValue === 'center', () => setV('center'), vDisabled)}
        {btn(<AlignBottom size={15} />, 'Align bottom', vValue === 'flex-end' || vValue === 'end', () => setV('flex-end'), vDisabled)}
      </div>
    </div>
  );
}

/* ── Content / Backend Fields ───────────────────────────────────────────── */

const HEADING_TAGS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
const BOX_TAGS = ['section', 'div', 'article', 'aside', 'header', 'footer', 'nav'];

function ContentFields({
  node,
  onUpdate,
  layoutFieldDefs,
  documentColors = [],
}: {
  node: BeekiriCodeNode;
  onUpdate: (patch: Partial<BeekiriCodeNode>) => void;
  layoutFieldDefs?: LayoutFieldDef[];
  documentColors?: string[];
}) {
  if (node.type === 'layout') {
    const values = node.layoutFields || {};
    const defs: BackendField[] =
      layoutFieldDefs && layoutFieldDefs.length > 0
        ? layoutFieldDefs
        : Object.keys(values).map((name) => ({
            id: name,
            name,
            label: name,
            type: 'text',
            required: false,
            instructions: '',
            choices: [],
            defaultValue: '',
          }));
    return (
      <>
        <p className="bk-insp-note">
          <code>layouts/{node.layoutSlug}/</code>
        </p>
        {defs.length === 0 ? <p className="bk-insp-note">No fields yet — add them in Backend Fields.</p> : null}
        <AcfFieldList
          fields={defs}
          values={values}
          onChange={(layoutFields) => onUpdate({ layoutFields })}
          ctx={{ documentColors }}
        />
      </>
    );
  }

  const tagOptions = node.type === 'heading' ? HEADING_TAGS : node.type === 'section' || node.type === 'container' ? BOX_TAGS : null;

  return (
    <>
      <Grid2>
        <SelectField
          value={node.type}
          placeholder="Type"
          options={MODULES.filter((m) => m.type !== 'layout').map((m) => ({ value: m.type, label: m.label }))}
          onChange={(v) => v && v !== node.type && onUpdate(defaultsForType(v as BeekiriCodeNodeType))}
        />
        {tagOptions ? (
          <SelectField value={node.tag || ''} placeholder="Tag" options={tagOptions} onChange={(v) => onUpdate({ tag: v || undefined })} />
        ) : (
          <span />
        )}
      </Grid2>
      {node.type === 'heading' || node.type === 'text' || node.type === 'button' ? (
        <Field label="Text" wide>
          <TextArea value={node.text || ''} onChange={(v) => onUpdate({ text: v })} rows={node.type === 'text' ? 4 : 2} />
        </Field>
      ) : null}
      {node.type === 'button' ? (
        <Field label="Link">
          <TextField value={node.href || ''} onChange={(v) => onUpdate({ href: v })} placeholder="https:// or /page" live />
        </Field>
      ) : null}
      {node.type === 'image' ? (
        <>
          <Field label="Source">
            <TextField value={node.src || ''} onChange={(v) => onUpdate({ src: v })} placeholder="/uploads/…" />
          </Field>
          <Field label="Alt">
            <TextField value={node.alt || ''} onChange={(v) => onUpdate({ alt: v })} placeholder="Describe the image" live />
          </Field>
        </>
      ) : null}
    </>
  );
}

/* ── Layout ─────────────────────────────────────────────────────────────── */

function LayoutFields({ val, ph, set, effective }: { val: Val; ph: Ph; set: Setter; effective: StyleBag }) {
  const display = effective.display || '';
  const isFlex = display.includes('flex');
  const isGrid = display.includes('grid');
  const segValue = isFlex ? 'flex' : isGrid ? 'grid' : display === 'none' ? 'none' : val('display') ? 'block' : '';
  return (
    <>
      <Segmented
        value={segValue}
        options={[
          { value: 'block', label: 'Block' },
          { value: 'flex', label: 'Flex' },
          { value: 'grid', label: 'Grid' },
          { value: 'none', label: 'None' },
        ]}
        onChange={(v) =>
          set(
            v
              ? { display: v }
              : { display: undefined, flexDirection: undefined, flexWrap: undefined, alignItems: undefined, justifyContent: undefined, gap: undefined, gridTemplateColumns: undefined, gridTemplateRows: undefined },
          )
        }
      />
      {isFlex ? (
        <>
          <Grid2>
            <Segmented
              allowEmpty={false}
              value={(effective.flexDirection || 'row').startsWith('column') ? 'column' : 'row'}
              options={[
                { value: 'row', label: 'Row', icon: <ArrowRight size={14} /> },
                { value: 'column', label: 'Column', icon: <ArrowDown size={14} /> },
              ]}
              onChange={(v) => set({ flexDirection: v })}
            />
            <Segmented
              value={val('flexWrap') === 'wrap' ? 'wrap' : ''}
              options={[{ value: 'wrap', label: 'Wrap' }]}
              onChange={(v) => set({ flexWrap: v || undefined })}
            />
          </Grid2>
          <Grid2>
            <SelectField
              value={val('justifyContent')}
              onChange={(v) => set({ justifyContent: v })}
              placeholder={ph('justifyContent', 'Justify')}
              options={[
                { value: 'flex-start', label: 'Start' },
                { value: 'center', label: 'Center' },
                { value: 'flex-end', label: 'End' },
                { value: 'space-between', label: 'Between' },
                { value: 'space-around', label: 'Around' },
                { value: 'space-evenly', label: 'Evenly' },
              ]}
            />
            <SelectField
              value={val('alignItems')}
              onChange={(v) => set({ alignItems: v })}
              placeholder={ph('alignItems', 'Align')}
              options={[
                { value: 'stretch', label: 'Stretch' },
                { value: 'flex-start', label: 'Start' },
                { value: 'center', label: 'Center' },
                { value: 'flex-end', label: 'End' },
                { value: 'baseline', label: 'Baseline' },
              ]}
            />
          </Grid2>
        </>
      ) : null}
      {isGrid ? (
        <Grid2>
          <TextField value={val('gridTemplateColumns')} onChange={(v) => set({ gridTemplateColumns: v })} placeholder={ph('gridTemplateColumns', 'Cols · 1fr 1fr')} mono />
          <TextField value={val('gridTemplateRows')} onChange={(v) => set({ gridTemplateRows: v })} placeholder={ph('gridTemplateRows', 'Rows · auto')} mono />
        </Grid2>
      ) : null}
      {isFlex || isGrid ? (
        <NumberField value={val('gap')} onChange={(v) => set({ gap: v })} suffix="Gap" placeholder={ph('gap', '0')} min={0} />
      ) : null}
    </>
  );
}

/* ── Position ───────────────────────────────────────────────────────────── */

function PositionFields({ val, ph, set }: { val: Val; ph: Ph; set: Setter }) {
  const pos = val('position') || ph('position');
  const offset = pos && pos !== 'static';
  return (
    <>
      <SelectField
        value={val('position')}
        onChange={(v) => set({ position: v })}
        placeholder={ph('position', 'Static')}
        options={['relative', 'absolute', 'fixed', 'sticky']}
      />
      {offset ? (
        <Grid2>
          <NumberField value={val('top')} onChange={(v) => set({ top: v })} suffix="T" placeholder={ph('top', 'Auto')} />
          <NumberField value={val('right')} onChange={(v) => set({ right: v })} suffix="R" placeholder={ph('right', 'Auto')} />
          <NumberField value={val('bottom')} onChange={(v) => set({ bottom: v })} suffix="B" placeholder={ph('bottom', 'Auto')} />
          <NumberField value={val('left')} onChange={(v) => set({ left: v })} suffix="L" placeholder={ph('left', 'Auto')} />
        </Grid2>
      ) : null}
      <NumberField value={val('zIndex')} onChange={(v) => set({ zIndex: v })} unit="" suffix="Z" placeholder={ph('zIndex', 'Auto')} />
    </>
  );
}

/* ── Border ─────────────────────────────────────────────────────────────── */

type BorderSide = '' | 'Top' | 'Right' | 'Bottom' | 'Left';

function SideIcon({ side }: { side: BorderSide }) {
  const hi = '#fff';
  const lo = 'rgba(255,255,255,0.28)';
  const c = (s: BorderSide) => (side === '' || side === s ? hi : lo);
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden>
      <line x1="2" y1="2" x2="12" y2="2" stroke={c('Top')} strokeWidth="1.6" strokeLinecap="round" />
      <line x1="12" y1="2" x2="12" y2="12" stroke={c('Right')} strokeWidth="1.6" strokeLinecap="round" />
      <line x1="2" y1="12" x2="12" y2="12" stroke={c('Bottom')} strokeWidth="1.6" strokeLinecap="round" />
      <line x1="2" y1="2" x2="2" y2="12" stroke={c('Left')} strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}

function BorderFields({ bag, val, set, documentColors }: { bag: StyleBag; val: Val; set: Setter; documentColors: string[] }) {
  const [side, setSide] = useState<BorderSide>('');
  const key = (prop: 'Width' | 'Style' | 'Color') => `border${side}${prop}`;
  const write = (patch: Record<string, string | undefined>) => set({ ...expandBorderShorthand(bag), ...patch });
  const expanded = expandBorderShorthand(bag);
  const read = (prop: 'Width' | 'Style' | 'Color') => val(key(prop)) || (side === '' ? expanded[`border${prop}`] ?? '' : '');

  const corners = ['TopLeft', 'TopRight', 'BottomRight', 'BottomLeft'] as const;
  const writeRadius = (v: string) =>
    set({ borderRadius: v, ...Object.fromEntries(corners.map((c) => [`border${c}Radius`, undefined])) });

  return (
    <>
      <Field label="Side">
        <Segmented
          allowEmpty={false}
          value={side || 'all'}
          onChange={(v) => setSide(v === 'all' ? '' : (v as BorderSide))}
          options={[
            { value: 'all', label: 'All sides', icon: <SideIcon side="" /> },
            { value: 'Top', label: 'Top', icon: <SideIcon side="Top" /> },
            { value: 'Right', label: 'Right', icon: <SideIcon side="Right" /> },
            { value: 'Bottom', label: 'Bottom', icon: <SideIcon side="Bottom" /> },
            { value: 'Left', label: 'Left', icon: <SideIcon side="Left" /> },
          ]}
        />
      </Field>
      <Field label="Style">
        <Segmented
          value={read('Style')}
          onChange={(v) => write({ [key('Style')]: v, ...(v && v !== 'none' && !read('Width') ? { [key('Width')]: '1px' } : {}) })}
          options={[
            { value: 'none', label: 'None', icon: <X size={12} weight="bold" /> },
            { value: 'solid', label: 'Solid', icon: <span className="bk-insp-line is-solid" /> },
            { value: 'dashed', label: 'Dashed', icon: <span className="bk-insp-line is-dashed" /> },
            { value: 'dotted', label: 'Dotted', icon: <span className="bk-insp-line is-dotted" /> },
          ]}
        />
      </Field>
      <Field label="Width">
        <SliderField
          value={read('Width')}
          onChange={(v) => write({ [key('Width')]: v, ...(!read('Style') ? { [key('Style')]: 'solid' } : {}) })}
          min={0}
          max={20}
        />
      </Field>
      <Field label="Color">
        <ColorField value={read('Color')} onChange={(v) => write({ [key('Color')]: v })} documentColors={documentColors} />
      </Field>
      <Field label="Radius">
        <SliderField value={val('borderRadius')} onChange={writeRadius} min={0} max={64} />
      </Field>
      <div className="bk-insp-grid4">
        {corners.map((c) => (
          <NumberField
            key={c}
            value={val(`border${c}Radius`)}
            placeholder={val('borderRadius') || '0'}
            suffix={c.replace(/[a-z]/g, '')}
            min={0}
            onChange={(v) => set({ [`border${c}Radius`]: v })}
          />
        ))}
      </div>
    </>
  );
}

/* ── Typography ─────────────────────────────────────────────────────────── */

const WEIGHTS = [
  { value: '100', label: 'Thin' },
  { value: '200', label: 'Extra Light' },
  { value: '300', label: 'Light' },
  { value: '400', label: 'Regular' },
  { value: '500', label: 'Medium' },
  { value: '600', label: 'Semibold' },
  { value: '700', label: 'Bold' },
  { value: '800', label: 'Extra Bold' },
  { value: '900', label: 'Black' },
];

function TypographyFields({ val, ph, set, documentColors }: { val: Val; ph: Ph; set: Setter; documentColors: string[] }) {
  const deco = val('textDecoration') || ph('textDecoration');
  const toggleDeco = (d: 'underline' | 'line-through') => set({ textDecoration: deco.includes(d) ? 'none' : d });
  const italic = (val('fontStyle') || ph('fontStyle')) === 'italic';
  return (
    <>
      <Field label="Font">
        <FontPicker value={val('fontFamily')} onChange={(v) => set({ fontFamily: v })} />
      </Field>
      <Grid2>
        <SelectField value={val('fontWeight')} onChange={(v) => set({ fontWeight: v })} options={WEIGHTS} placeholder={ph('fontWeight', 'Weight')} />
        <NumberField value={val('fontSize')} onChange={(v) => set({ fontSize: v })} suffix="Size" placeholder={ph('fontSize', '—')} min={0} />
      </Grid2>
      <Grid2>
        <NumberField value={val('lineHeight')} onChange={(v) => set({ lineHeight: v })} unit="" suffix="LH" placeholder={ph('lineHeight', 'Auto')} step={0.05} min={0} />
        <NumberField value={val('letterSpacing')} onChange={(v) => set({ letterSpacing: v })} suffix="LS" placeholder={ph('letterSpacing', '0')} step={0.1} />
      </Grid2>
      <Field label="Color">
        <ColorField value={val('color')} onChange={(v) => set({ color: v })} documentColors={documentColors} placeholder={ph('color', 'Inherit')} />
      </Field>
      <Field label="Align">
        <Segmented
          value={val('textAlign')}
          onChange={(v) => set({ textAlign: v })}
          options={[
            { value: 'left', label: 'Left', icon: <TextAlignLeft size={14} /> },
            { value: 'center', label: 'Center', icon: <TextAlignCenter size={14} /> },
            { value: 'right', label: 'Right', icon: <TextAlignRight size={14} /> },
            { value: 'justify', label: 'Justify', icon: <TextAlignJustify size={14} /> },
          ]}
        />
      </Field>
      <Field label="Style">
        <div className="bk-insp-seg">
          <button type="button" title="Italic" className={`bk-insp-seg__btn${italic ? ' is-active' : ''}`} onClick={() => set({ fontStyle: italic ? undefined : 'italic' })}>
            <TextItalic size={14} />
          </button>
          <button type="button" title="Underline" className={`bk-insp-seg__btn${deco.includes('underline') ? ' is-active' : ''}`} onClick={() => toggleDeco('underline')}>
            <TextUnderline size={14} />
          </button>
          <button type="button" title="Strikethrough" className={`bk-insp-seg__btn${deco.includes('line-through') ? ' is-active' : ''}`} onClick={() => toggleDeco('line-through')}>
            <TextStrikethrough size={14} />
          </button>
        </div>
      </Field>
      <Field label="Case">
        <Segmented
          value={val('textTransform')}
          onChange={(v) => set({ textTransform: v })}
          options={[
            { value: 'none', label: 'None', icon: <X size={12} weight="bold" /> },
            { value: 'uppercase', label: 'Uppercase', icon: <span className="bk-insp-case">TT</span> },
            { value: 'capitalize', label: 'Capitalize', icon: <span className="bk-insp-case">Tt</span> },
            { value: 'lowercase', label: 'Lowercase', icon: <span className="bk-insp-case">tt</span> },
          ]}
        />
      </Field>
    </>
  );
}

/* ── Background ─────────────────────────────────────────────────────────── */

function BackgroundFields({ val, set, documentColors }: { val: Val; set: Setter; documentColors: string[] }) {
  const legacy = val('background');
  const color = val('backgroundColor') || (parseColor(legacy) ? legacy : '');
  const image = val('backgroundImage');
  const imageUrl = image.match(/^url\(["']?(.*?)["']?\)$/)?.[1] ?? image;
  return (
    <>
      <Field label="Color">
        <ColorField
          value={color}
          onChange={(v) => set({ backgroundColor: v, ...(parseColor(legacy) ? { background: undefined } : {}) })}
          documentColors={documentColors}
        />
      </Field>
      <Field label="Image">
        <TextField
          value={imageUrl}
          onChange={(v) => {
            const t = v.trim();
            set({ backgroundImage: !t ? undefined : /^(url|linear-gradient|radial-gradient)\(/.test(t) ? t : `url("${t}")` });
          }}
          placeholder="/uploads/… or gradient"
        />
      </Field>
      {image ? (
        <>
          <Field label="Size">
            <Segmented
              value={val('backgroundSize')}
              onChange={(v) => set({ backgroundSize: v })}
              options={[
                { value: 'auto', label: 'Auto' },
                { value: 'cover', label: 'Cover' },
                { value: 'contain', label: 'Contain' },
              ]}
            />
          </Field>
          <Grid2>
            <SelectField
              value={val('backgroundPosition')}
              onChange={(v) => set({ backgroundPosition: v })}
              placeholder="Position"
              options={['center', 'top', 'bottom', 'left', 'right', 'top left', 'top right', 'bottom left', 'bottom right']}
            />
            <SelectField
              value={val('backgroundRepeat')}
              onChange={(v) => set({ backgroundRepeat: v })}
              placeholder="Repeat"
              options={['no-repeat', 'repeat', 'repeat-x', 'repeat-y']}
            />
          </Grid2>
        </>
      ) : null}
    </>
  );
}

/* ── Responsive visibility ──────────────────────────────────────────────── */

const BREAKPOINTS: { id: HiddenBreakpoint; label: string; Icon: typeof Desktop }[] = [
  { id: 'desktop', label: 'Desktop', Icon: Desktop },
  { id: 'tablet', label: 'Tablet', Icon: DeviceTablet },
  { id: 'mobile', label: 'Mobile', Icon: DeviceMobile },
];

function VisibilityFields({
  node,
  onUpdate,
  showHidden,
  onShowHiddenChange,
}: {
  node: BeekiriCodeNode;
  onUpdate: (patch: Partial<BeekiriCodeNode>) => void;
  showHidden: boolean;
  onShowHiddenChange?: (v: boolean) => void;
}) {
  const hidden = useMemo(() => new Set(node.hiddenOn ?? []), [node.hiddenOn]);
  const toggle = (bp: HiddenBreakpoint) => {
    const next = new Set(hidden);
    if (next.has(bp)) next.delete(bp);
    else next.add(bp);
    onUpdate({ hiddenOn: next.size ? BREAKPOINTS.map((b) => b.id).filter((id) => next.has(id)) : undefined });
  };
  return (
    <>
      <Field label="Hide on">
        <div className="bk-insp-seg">
          <button
            type="button"
            title="Visible everywhere"
            className={`bk-insp-seg__btn${hidden.size === 0 ? ' is-active' : ''}`}
            onClick={() => onUpdate({ hiddenOn: undefined })}
          >
            <X size={12} weight="bold" />
          </button>
          {BREAKPOINTS.map(({ id, label, Icon }) => (
            <button
              key={id}
              type="button"
              title={`Hide on ${label}`}
              aria-pressed={hidden.has(id)}
              className={`bk-insp-seg__btn${hidden.has(id) ? ' is-active is-warn' : ''}`}
              onClick={() => toggle(id)}
            >
              <Icon size={14} />
            </button>
          ))}
        </div>
      </Field>
      {onShowHiddenChange ? <Switch checked={showHidden} onChange={onShowHiddenChange} label="Show all hidden elements" /> : null}
    </>
  );
}
