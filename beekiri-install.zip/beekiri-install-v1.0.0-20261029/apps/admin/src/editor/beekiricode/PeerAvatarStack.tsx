import { useEffect, useMemo, useRef, useState } from 'react';
import { api } from '../../api/client';
import { useAuth } from '../../auth/AuthContext';
import { usePageEditorChrome } from '../PageEditorChrome';

export type PresencePeer = {
  userId: string;
  name: string;
  color: string;
  clientId: string;
};

type Props = {
  pageId: string;
};

/**
 * Soft mesh-style orb gradients (cyan / violet / coral …) — one per peer.
 * Layered radial gradients, no images.
 */
const MESH_GRADIENTS = [
  // cyan → deep blue
  'radial-gradient(circle at 32% 38%, #e8fbff 0%, #7dd3fc 28%, #2563eb 62%, #1e3a8a 100%)',
  // lavender → magenta
  'radial-gradient(circle at 35% 40%, #f5e8ff 0%, #e879f9 30%, #7c3aed 65%, #4c1d95 100%)',
  // peach → coral
  'radial-gradient(circle at 38% 36%, #fff1e8 0%, #fdba74 28%, #f97316 60%, #c2410c 100%)',
  // mint → teal
  'radial-gradient(circle at 30% 42%, #ecfdf5 0%, #6ee7b7 28%, #0d9488 62%, #115e59 100%)',
  // rose → crimson
  'radial-gradient(circle at 40% 35%, #fff1f2 0%, #fb7185 30%, #e11d48 64%, #9f1239 100%)',
  // sky → indigo
  'radial-gradient(circle at 34% 40%, #eef2ff 0%, #a5b4fc 28%, #6366f1 60%, #312e81 100%)',
  // amber → gold
  'radial-gradient(circle at 36% 38%, #fffbeb 0%, #fcd34d 28%, #f59e0b 60%, #b45309 100%)',
  // lime → forest
  'radial-gradient(circle at 33% 41%, #f7fee7 0%, #a3e635 28%, #65a30d 62%, #3f6212 100%)',
] as const;

function peerMesh(userId: string): string {
  let hash = 0;
  for (let i = 0; i < userId.length; i++) {
    hash = (hash * 31 + userId.charCodeAt(i)) | 0;
  }
  const idx = ((hash % MESH_GRADIENTS.length) + MESH_GRADIENTS.length) % MESH_GRADIENTS.length;
  return MESH_GRADIENTS[idx]!;
}

function clientIdForTab(): string {
  const key = 'bk-beekiricode-presence-client';
  try {
    const existing = sessionStorage.getItem(key);
    if (existing) return existing;
    const id = `c_${Math.random().toString(36).slice(2, 12)}`;
    sessionStorage.setItem(key, id);
    return id;
  } catch {
    return `c_${Math.random().toString(36).slice(2, 12)}`;
  }
}

/**
 * Live “who’s editing” stack — soft gradient orbs per user.
 * Hover shows which user is active on this page.
 */
export function PeerAvatarStack({ pageId }: Props) {
  const auth = useAuth();
  const chrome = usePageEditorChrome();
  const apiBase = chrome.apiBase;
  const clientId = useMemo(() => clientIdForTab(), []);
  const [peers, setPeers] = useState<PresencePeer[]>([]);
  const leaveSent = useRef(false);

  useEffect(() => {
    if (!pageId || !auth.user) return;
    leaveSent.current = false;
    let cancelled = false;

    const beat = async () => {
      try {
        const res = await api<{ peers: PresencePeer[] }>(
          `${apiBase}/${pageId}/presence`,
          {
            method: 'POST',
            json: { clientId },
          },
        );
        if (!cancelled) setPeers(res.peers ?? []);
      } catch {
        /* presence is best-effort */
      }
    };

    void beat();
    const timer = window.setInterval(() => void beat(), 4000);

    const onLeave = () => {
      if (leaveSent.current) return;
      leaveSent.current = true;
      void api(
        `${apiBase}/${pageId}/presence?clientId=${encodeURIComponent(clientId)}`,
        { method: 'DELETE' },
      ).catch(() => undefined);
    };

    window.addEventListener('pagehide', onLeave);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
      window.removeEventListener('pagehide', onLeave);
      onLeave();
    };
  }, [pageId, clientId, auth.user, apiBase]);

  const me = auth.user;
  const stack = useMemo(() => {
    const list: PresencePeer[] = peers.map((p) => ({ ...p }));
    if (me) {
      const self: PresencePeer = {
        userId: me.id,
        name: me.displayName?.trim() || me.username,
        color: peerMesh(me.id),
        clientId,
      };
      if (!list.some((p) => p.userId === me.id)) list.unshift(self);
      else {
        const idx = list.findIndex((p) => p.userId === me.id);
        if (idx > 0) {
          const [mine] = list.splice(idx, 1);
          if (mine) list.unshift(mine);
        }
      }
    }
    return list.slice(0, 5);
  }, [peers, me, clientId]);

  if (stack.length === 0) return null;

  const groupLabel =
    stack.length === 1
      ? `${stack[0]!.name} (you) — editing this page`
      : `${stack.length} editing — ${stack.map((p) => p.name).join(', ')}`;

  return (
    <div
      className="bk-beekiricode__peer-stack"
      role="group"
      aria-label={groupLabel}
    >
      {stack.map((peer, index) => {
        const isMe = me?.id === peer.userId;
        const name = isMe ? `${peer.name} (you)` : peer.name;
        return (
          <button
            key={peer.userId}
            type="button"
            className={`bk-beekiricode__peer-avatar${isMe ? ' is-me' : ''}`}
            style={{ zIndex: index + 1 }}
            aria-label={`${name} — editing this page`}
            data-username={name}
          >
            <span
              className="bk-beekiricode__peer-face"
              aria-hidden
              style={{ ['--peer-mesh' as string]: peerMesh(peer.userId) }}
            />
            <span className="bk-beekiricode__peer-tip" role="tooltip">
              {name}
            </span>
          </button>
        );
      })}
    </div>
  );
}
