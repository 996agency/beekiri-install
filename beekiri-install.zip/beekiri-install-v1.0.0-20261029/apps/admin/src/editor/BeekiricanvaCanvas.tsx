import { useEffect, useMemo, useState } from 'react';
import {
  Beekiricanva,
  FieldLabel,
  blocksPlugin,
  outlinePlugin,
  type Config,
  type Data,
} from '@beekiri/beekiricanva';
import { ListBullets, SquaresFour } from '@phosphor-icons/react';
import {
  emptyBeekiricanvaData,
  isBeekiricanvaData,
  beekiricanvaConfig,
  beekiricanvaDataFromLegacyHtml,
  withLayouts,
  ensureLayoutStyles,
  ensureLayoutScripts,
  type LayoutDef,
} from '@beekiri/page-blocks';
import { api } from '../api/client';
import '@beekiri/beekiricanva/editor.css';
import '@beekiri/page-blocks/blocks.css';
import './beekiricanva.css';
import './inspector/inspector.css';
import { withInspectorFields } from './inspector/fields';
import { BeekiricanvaHeader } from './BeekiricanvaHeader';
import { PageSettingsModal } from './PageSettingsModal';
import { BEEKIRI_VIEWPORTS } from './viewports';

type Props = {
  beekiricanva: unknown | null | undefined;
  legacyHtml?: string;
  onChange: (data: Data) => void;
};

const pluginIcon = (Icon: typeof SquaresFour) => (
  <Icon size={20} weight="regular" aria-hidden />
);

/** Blocks + Outline only. Fields open on the right when a block is selected. */
const beekiriPlugins = [
  blocksPlugin({ icon: pluginIcon(SquaresFour) }),
  outlinePlugin({ icon: pluginIcon(ListBullets) }),
];

export function resolveInitialBeekiricanvaData(
  doc: unknown | null | undefined,
  legacyHtml = '',
): Data {
  if (isBeekiricanvaData(doc) && Array.isArray(doc.content) && doc.content.length > 0) {
    return doc;
  }
  if (isBeekiricanvaData(doc) && doc.content) {
    return { root: doc.root ?? { props: {} }, content: doc.content, zones: doc.zones };
  }
  if (legacyHtml.trim()) return beekiricanvaDataFromLegacyHtml(legacyHtml);
  return emptyBeekiricanvaData;
}

function BlocksEmptyState() {
  return (
    <div className="bk-blocks-empty" role="status">
      <p className="bk-blocks-empty__title">No blocks yet</p>
      <p className="bk-blocks-empty__text">
        You need to add blocks from Backend Fields.
      </p>
    </div>
  );
}

export function BeekiricanvaCanvas({
  beekiricanva,
  legacyHtml = '',
  onChange,
}: Props) {
  const [layouts, setLayouts] = useState<LayoutDef[] | null>(null);

  useEffect(() => {
    let cancelled = false;
    api<{ layouts: LayoutDef[] }>('/api/layouts')
      .then((res) => {
        if (cancelled) return;
        const list = res.layouts ?? [];
        setLayouts(list);
        ensureLayoutStyles(list, '');
        ensureLayoutScripts(list, '');
      })
      .catch(() => {
        if (!cancelled) setLayouts([]);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const editorConfig = useMemo(() => {
    const merged = withLayouts(beekiricanvaConfig, layouts ?? []);
    return withInspectorFields(merged as Config);
  }, [layouts]);

  const hasRegisteredBlocks = Object.keys(editorConfig.components ?? {}).length > 0;

  const initialData = useMemo(
    () => resolveInitialBeekiricanvaData(beekiricanva, legacyHtml),
    // Only seed once per page load — parent remounts via key={page.id}
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  // Wait for layouts so Blocks panel isn't briefly empty then filled.
  if (layouts === null) {
    return (
      <div className="bk-beekiricanva">
        <div className="bk-blocks-empty" role="status">
          <p className="bk-blocks-empty__text">Loading layouts…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bk-beekiricanva">
      <Beekiricanva
        key={`layouts-${layouts.map((l) => l.slug).join(',')}`}
        config={editorConfig}
        data={initialData}
        onChange={onChange}
        headerPath=""
        viewports={BEEKIRI_VIEWPORTS}
        plugins={beekiriPlugins}
        ui={{ rightSideBarVisible: false }}
        overrides={{
          header: ({ actions }) => <BeekiricanvaHeader actions={actions} />,
          headerActions: () => <></>,
          drawer: ({ children }) =>
            hasRegisteredBlocks ? <>{children}</> : <BlocksEmptyState />,
          fieldLabel: (props) => {
            if (
              [
                'Typography',
                'Layout',
                'Spacing',
                'Background',
                'Border',
                'Effects',
              ].includes(props.label)
            ) {
              return <>{props.children}</>;
            }
            return <FieldLabel {...props} />;
          },
        }}
      />
      <PageSettingsModal />
    </div>
  );
}
