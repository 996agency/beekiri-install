import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import type { Icon } from '@phosphor-icons/react';
import {
  ArrowSquareOut,
  ChartLine,
  FileText,
  GearSix,
  Images,
  List,
  MagnifyingGlass,
  NotePencil,
  PaintBrush,
  Plugs,
  PuzzlePiece,
  SquaresFour,
  Stack,
  Users,
  X,
} from '@phosphor-icons/react';
import '../styles/wp/admin.css';
import './admin-shell.css';
import { api } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { useCoreUpdate } from '../core/CoreUpdateContext';
import { BrandMark } from '../components/BrandMark';
import { resolveAdminIcon } from '../components/IconPicker';
import { AdminSpotlightSearch } from '../components/AdminSpotlightSearch';
import { LighthouseToolbar } from '../components/LighthouseToolbar';
import { SiteFavicon } from '../components/SiteFavicon';
import { BeeAgentWidget } from '../components/BeeAgentWidget';
import { ConfirmDialogHost } from '../components/ConfirmDialog';
import { CONNECTOR_CHANGED, POST_TYPES_CHANGED } from '../lib/admin-events';
import { AdminPageTransition } from './AdminPageTransition';

import { SITE_URL as LIVE_SITE } from '../config';
/** Fallback if updates API has not loaded yet — keep in sync with root package.json. */
const FALLBACK_VERSION = '1.0.0';

type MenuChild = {
  label: string;
  to: string;
  /** Optional brand mark (e.g. connector provider logo). */
  logoSrc?: string;
  logoClass?: string;
};

const CONNECTOR_LOGO: Record<string, string> = {
  beequeen: '/admin/beekiri-logo.png',
  claude: '/admin/connector/claude.svg',
  openai: '/admin/connector/openai.svg',
  gemini: '/admin/connector/gemini.svg',
  grok: '/admin/connector/grok.svg',
};

type MenuItem = {
  label: string;
  to: string;
  icon: Icon;
  disabled?: boolean;
  children?: MenuChild[];
};

type MenuGroup = {
  /** Section label shown above the group. Omit for unlabeled top items. */
  label?: string;
  items: MenuItem[];
};

const FIELDS_CHILDREN: MenuChild[] = [
  { label: 'Field Groups', to: '/admin/fields' },
  { label: 'Post Types', to: '/admin/fields/post-types' },
  { label: 'Taxonomies', to: '/admin/fields/taxonomies' },
  { label: 'Options Pages', to: '/admin/fields/options-pages' },
  { label: 'Settings', to: '/admin/fields/settings' },
  { label: 'Tools', to: '/admin/fields/tools' },
];

const APPEARANCE_CHILDREN: MenuChild[] = [
  { label: 'Themes', to: '/admin/appearance' },
  { label: 'Header', to: '/admin/appearance/header' },
  { label: 'Footer', to: '/admin/appearance/footer' },
  { label: 'Templates', to: '/admin/appearance/templates' },
];

const ANALYTICS_CHILDREN: MenuChild[] = [
  { label: 'Overview', to: '/admin/analytics' },
  { label: 'Heatmap', to: '/admin/analytics/heatmap' },
  { label: 'BeeCookies', to: '/admin/analytics/cookies' },
];

type NavCpt = {
  slug: string;
  plural: string;
  menuIcon: string;
  showInMenu: boolean;
  active: boolean;
};

type NavConnector = {
  id: string;
  name: string;
  enabled: boolean;
};

function buildMenuGroups(
  cpts: NavCpt[],
  connectors: NavConnector[],
  caps: string[],
  isOwner: boolean,
): MenuGroup[] {
  const canFields = caps.includes('manage_fields');
  const canUsers = caps.includes('list_users');
  const usersChildren: MenuChild[] = [
    { label: 'All Users', to: '/admin/users' },
    ...(isOwner
      ? [{ label: 'User Permissions', to: '/admin/users/permissions' } satisfies MenuChild]
      : []),
  ];
  const cptItems: MenuItem[] = cpts
    .filter((c) => c.active && c.showInMenu)
    .map((c) => ({
      label: c.plural,
      to: `/admin/content/${c.slug}`,
      icon: resolveAdminIcon(c.menuIcon),
    }));

  const connectorChildren: MenuChild[] = connectors
    .filter((c) => c.enabled)
    .map((c) => ({
      label: c.name,
      to: `/admin/connector/${c.id}`,
      logoSrc: CONNECTOR_LOGO[c.id],
      logoClass: `bk-menu-provider-logo is-${c.id}`,
    }));

  return [
    {
      items: [
        { label: 'Dashboard', to: '/admin', icon: SquaresFour },
        {
          label: 'Analytics',
          to: '/admin/analytics',
          icon: ChartLine,
          children: ANALYTICS_CHILDREN,
        },
      ],
    },
    {
      label: 'Content',
      items: [
        { label: 'Posts', to: '/admin/posts', icon: NotePencil },
        { label: 'Pages', to: '/admin/pages', icon: FileText },
        ...cptItems,
        { label: 'Media', to: '/admin/media', icon: Images },
        { label: 'SEO', to: '/admin/seo', icon: MagnifyingGlass },
      ],
    },
    {
      label: 'Admin',
      items: [
        ...(canFields
          ? [
              {
                label: 'Backend Fields',
                to: '/admin/fields',
                icon: Stack,
                children: FIELDS_CHILDREN,
              } satisfies MenuItem,
            ]
          : []),
        ...(canUsers
          ? [
              {
                label: 'Users',
                to: '/admin/users',
                icon: Users,
                children: usersChildren,
              } satisfies MenuItem,
            ]
          : []),
        {
          label: 'Appearance',
          to: '/admin/appearance',
          icon: PaintBrush,
          children: APPEARANCE_CHILDREN,
        },
        {
          label: 'Connector',
          to: '/admin/connector',
          icon: Plugs,
          ...(connectorChildren.length ? { children: connectorChildren } : {}),
        },
        { label: 'Extensions', to: '/admin/extensions', icon: PuzzlePiece, disabled: true },
        { label: 'Settings', to: '/admin/settings', icon: GearSix },
      ],
    },
  ];
}

function pathMatches(pathname: string, to: string) {
  if (to === '/admin') return pathname === '/admin';
  if (to === '/admin/fields') {
    if (pathname === '/admin/fields' || pathname === '/admin/fields/') return true;
    // Field group editor: /admin/fields/new, /admin/fields/:id
    const sub = pathname.match(/^\/admin\/fields\/([^/]+)\/?$/)?.[1];
    return !!sub && !['post-types', 'taxonomies', 'options-pages', 'settings', 'tools'].includes(sub);
  }
  if (to === '/admin/appearance') {
    return pathname === '/admin/appearance' || pathname === '/admin/appearance/';
  }
  if (to === '/admin/analytics') {
    return pathname === '/admin/analytics' || pathname === '/admin/analytics/';
  }
  if (to === '/admin/connector') {
    return pathname === '/admin/connector' || pathname === '/admin/connector/';
  }
  if (to === '/admin/users') {
    return pathname === '/admin/users' || pathname === '/admin/users/';
  }
  return pathname === to || pathname.startsWith(`${to}/`);
}

function sectionOpen(pathname: string, item: MenuItem) {
  if (!item.children?.length) return false;
  if (item.to === '/admin/analytics') {
    return pathname === '/admin/analytics' || pathname.startsWith('/admin/analytics/');
  }
  if (item.to === '/admin/connector') {
    return pathname === '/admin/connector' || pathname.startsWith('/admin/connector/');
  }
  return pathname === item.to || pathname.startsWith(`${item.to}/`);
}

function MenuItemRow({
  item,
  pathname,
  updateAvailable,
  updateCount,
  latestVersion,
}: {
  item: MenuItem;
  pathname: string;
  updateAvailable: boolean;
  updateCount: number;
  latestVersion?: string;
}) {
  const liRef = useRef<HTMLLIElement>(null);
  const [flyout, setFlyout] = useState(false);
  const [flyoutTop, setFlyoutTop] = useState(0);
  const open = sectionOpen(pathname, item);
  const current = item.children?.length ? open : pathMatches(pathname, item.to);
  const showUpdateBadge = item.to === '/admin/settings' && updateAvailable;
  const Icon = item.icon;
  const showFlyout = Boolean(item.children?.length && flyout && !open);

  const openFlyout = () => {
    if (!item.children?.length || open) return;
    const rect = liRef.current?.getBoundingClientRect();
    if (rect) setFlyoutTop(rect.top);
    setFlyout(true);
  };

  return (
    <li
      ref={liRef}
      className={[
        current ? 'current' : '',
        open ? 'wp-has-current-submenu' : '',
        item.children?.length ? 'wp-has-submenu' : '',
        showFlyout ? 'is-flyout-open' : '',
      ]
        .filter(Boolean)
        .join(' ') || undefined}
      onMouseEnter={openFlyout}
      onMouseLeave={() => setFlyout(false)}
      onFocusCapture={openFlyout}
      onBlurCapture={(e) => {
        if (!liRef.current?.contains(e.relatedTarget as Node | null)) setFlyout(false);
      }}
    >
      {item.disabled ? (
        <a
          className="disabled"
          href={item.to}
          title="Extensions coming later"
          onClick={(e) => e.preventDefault()}
        >
          <Icon size={18} weight="regular" className="bk-menu-icon" aria-hidden />
          <span className="bk-menu-name">{item.label}</span>
        </a>
      ) : (
        <Link
          to={item.to}
          aria-current={
            item.children?.length
              ? pathMatches(pathname, item.to)
                ? 'page'
                : undefined
              : current
                ? 'page'
                : undefined
          }
          aria-haspopup={item.children?.length ? 'menu' : undefined}
          aria-expanded={item.children?.length ? open || showFlyout : undefined}
          title={
            showUpdateBadge && latestVersion
              ? `Beekiri Core v${latestVersion} available`
              : undefined
          }
        >
          <Icon size={18} weight="regular" className="bk-menu-icon" aria-hidden />
          <span className="bk-menu-name">{item.label}</span>
          {showUpdateBadge ? <span className="bk-count">+{updateCount}</span> : null}
        </Link>
      )}
      {item.children?.length ? (
        <ul
          className={`bk-menu-submenu${open ? ' is-open' : ''}${showFlyout ? ' is-flyout' : ''}`}
          aria-label={`${item.label} submenu`}
          style={showFlyout ? { top: Math.max(8, flyoutTop) } : undefined}
        >
          {item.children.map((child) => {
            const childCurrent = pathMatches(pathname, child.to);
            return (
              <li key={child.to} className={childCurrent ? 'current' : undefined}>
                <Link to={child.to} aria-current={childCurrent ? 'page' : undefined}>
                  {child.logoSrc ? (
                    <img
                      src={child.logoSrc}
                      alt=""
                      width={14}
                      height={14}
                      className={child.logoClass ?? 'bk-menu-provider-logo'}
                      draggable={false}
                      aria-hidden
                    />
                  ) : null}
                  <span className="bk-menu-name">{child.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      ) : null}
    </li>
  );
}

export function AdminShell({ children }: { children: React.ReactNode }) {
  const auth = useAuth();
  const location = useLocation();
  const { updateCount, updateAvailable, updates } = useCoreUpdate();
  const version = updates?.currentVersion ?? FALLBACK_VERSION;
  const [menuOpen, setMenuOpen] = useState(false);
  const [cpts, setCpts] = useState<NavCpt[]>([]);
  const [connectors, setConnectors] = useState<NavConnector[]>([]);
  const [isNarrow, setIsNarrow] = useState(
    () => typeof window !== 'undefined' && window.matchMedia('(max-width: 960px)').matches,
  );
  const menuGroups = useMemo(
    () =>
      buildMenuGroups(
        cpts,
        connectors,
        auth.user?.capabilities ?? [],
        Boolean(auth.user?.isOwner),
      ),
    [cpts, connectors, auth.user?.capabilities, auth.user?.isOwner],
  );

  useEffect(() => {
    document.body.classList.add('beekiri-admin');
    return () => document.body.classList.remove('beekiri-admin');
  }, []);

  useEffect(() => {
    let cancelled = false;
    const loadCpts = () => {
      api<{ postTypes: NavCpt[] }>('/api/fields/post-types')
        .then((res) => {
          if (!cancelled) setCpts(res.postTypes ?? []);
        })
        .catch(() => {
          if (!cancelled) setCpts([]);
        });
    };
    loadCpts();
    window.addEventListener(POST_TYPES_CHANGED, loadCpts);
    return () => {
      cancelled = true;
      window.removeEventListener(POST_TYPES_CHANGED, loadCpts);
    };
  }, [auth.user?.id]);

  useEffect(() => {
    let cancelled = false;
    const loadConnectors = () => {
      api<{ providers: NavConnector[] }>('/api/connector')
        .then((res) => {
          if (!cancelled) setConnectors(res.providers ?? []);
        })
        .catch(() => {
          if (!cancelled) setConnectors([]);
        });
    };
    loadConnectors();
    window.addEventListener(CONNECTOR_CHANGED, loadConnectors);
    return () => {
      cancelled = true;
      window.removeEventListener(CONNECTOR_CHANGED, loadConnectors);
    };
  }, [auth.user?.id]);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const mq = window.matchMedia('(max-width: 960px)');
    const onChange = () => {
      setIsNarrow(mq.matches);
      if (!mq.matches) setMenuOpen(false);
    };
    onChange();
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenuOpen(false);
    };
    document.addEventListener('keydown', onKey);
    document.body.classList.add('bk-menu-open');
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.classList.remove('bk-menu-open');
    };
  }, [menuOpen]);

  return (
    <div className="beekiri-admin" style={{ minHeight: '100%' }}>
      <SiteFavicon />
      <div id="beekiri-admin" className={menuOpen ? 'is-menu-open' : undefined}>
        <button
          type="button"
          className="bk-menu-backdrop"
          aria-label="Close menu"
          tabIndex={menuOpen ? 0 : -1}
          onClick={() => setMenuOpen(false)}
        />
        <div
          id="adminmenumain"
          role="navigation"
          aria-label="Main menu"
          {...(isNarrow && !menuOpen ? { inert: true } : {})}
        >
          <div className="bk-menu-drawer-head">
            <Link
              to="/admin"
              className="bk-menu-drawer-brand"
              title="Beekiri"
              onClick={() => setMenuOpen(false)}
            >
              <BrandMark size={22} />
              <span className="bk-menu-name">Beekiri</span>
            </Link>
            <button
              type="button"
              className="bk-menu-close"
              aria-label="Close menu"
              onClick={() => setMenuOpen(false)}
            >
              <X size={20} weight="regular" aria-hidden />
            </button>
          </div>
          {/* Outside #adminmenu so the scrollbar never runs through the logo */}
          <div className="bk-menu-brand">
            <Link to="/admin" className="ab-item" title="Beekiri">
              <BrandMark size={22} />
              <span className="bk-menu-name">Beekiri</span>
            </Link>
          </div>
          <ul id="adminmenu">
            <li>
              <a
                className="ab-item"
                href={LIVE_SITE}
                target="_blank"
                rel="noreferrer"
                title="Open live public site"
              >
                <ArrowSquareOut size={18} weight="regular" className="bk-menu-icon" aria-hidden />
                <span className="bk-menu-name">View site</span>
              </a>
            </li>
            <li className="bk-menu-sep" aria-hidden="true" />
            {menuGroups.map((group, groupIndex) => (
              <li key={group.label ?? `group-${groupIndex}`} className="bk-menu-group">
                {group.label ? (
                  <p className="bk-menu-label" id={`bk-menu-${group.label.toLowerCase()}`}>
                    {group.label}
                  </p>
                ) : null}
                <ul
                  className="bk-menu-group__list"
                  aria-labelledby={
                    group.label ? `bk-menu-${group.label.toLowerCase()}` : undefined
                  }
                >
                  {group.items.map((item) => (
                    <MenuItemRow
                      key={item.to}
                      item={item}
                      pathname={location.pathname}
                      updateAvailable={updateAvailable}
                      updateCount={updateCount}
                      latestVersion={updates?.latestVersion ?? undefined}
                    />
                  ))}
                </ul>
              </li>
            ))}
          </ul>

          <div className="bk-menu-version" aria-label="Beekiri version">
            <span className="bk-menu-version__label">Beekiri Core</span>
            <span className="bk-menu-version__value">v{version}</span>
            <span className="bk-menu-version__meta">
              © 996Agency · Licensed use only
            </span>
          </div>
        </div>
        <div id="bk-content">
          <div id="bk-toolbar" role="navigation" aria-label="Toolbar">
            <button
              type="button"
              className="bk-menu-toggle"
              aria-label={menuOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={menuOpen}
              aria-controls="adminmenumain"
              onClick={() => setMenuOpen((open) => !open)}
            >
              {menuOpen ? (
                <X size={20} weight="regular" aria-hidden />
              ) : (
                <List size={20} weight="regular" aria-hidden />
              )}
            </button>
            <LighthouseToolbar />
            <AdminSpotlightSearch />
            <span className="spacer" />
            {auth.user ? (
              <Link
                to={`/admin/users/${auth.user.id}`}
                className="ab-item bk-toolbar-user"
                title="Edit your profile"
              >
                <BrandMark size={20} title={auth.user.displayName || 'User'} />
                <span className="bk-toolbar-user__name">{auth.user.displayName}</span>
              </Link>
            ) : null}
            <button
              type="button"
              className="ab-item bk-toolbar-logout"
              onClick={() => void auth.logout()}
            >
              Sign out
            </button>
          </div>
          <div id="bk-body">
            <AdminPageTransition>{children}</AdminPageTransition>
          </div>
        </div>
      </div>
      <ConfirmDialogHost />
      <BeeAgentWidget />
    </div>
  );
}
