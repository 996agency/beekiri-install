import { useEffect, useState, type ReactNode } from 'react';
import { useLocation } from 'react-router-dom';

function prefersReducedMotion() {
  if (typeof window === 'undefined' || !window.matchMedia) return false;
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

/** Soft fade/slide on route change + smooth scroll-to-top. */
export function AdminPageTransition({ children }: { children: ReactNode }) {
  const location = useLocation();
  const [reduceMotion, setReduceMotion] = useState(prefersReducedMotion);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const onChange = () => setReduceMotion(mq.matches);
    onChange();
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  useEffect(() => {
    if (location.hash) return;
    // Page editor owns its own scroll surface — don't yank the window.
    if (document.querySelector('#bk-body .wrap--page-editor')) return;
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: reduceMotion ? 'auto' : 'smooth',
    });
  }, [location.pathname, reduceMotion]);

  return (
    <div
      key={location.pathname}
      className={reduceMotion ? undefined : 'bk-page-enter'}
    >
      {children}
    </div>
  );
}
