import { useEffect, useState } from 'react';
import { api } from '../api/client';
import type { CptLabels } from './contentKind';

export type CptMeta = {
  slug: string;
  singular: string;
  plural: string;
  active?: boolean;
  showInMenu?: boolean;
};

export type CptResolveState =
  | { status: 'loading' }
  | { status: 'ready'; labels: CptLabels; meta: CptMeta; all: CptMeta[] }
  | { status: 'missing'; all: CptMeta[] };

/** Resolve a CPT slug against registered post types (admin content routes). */
export function useCptMeta(slug: string): CptResolveState {
  const [state, setState] = useState<CptResolveState>({ status: 'loading' });

  useEffect(() => {
    if (!slug) {
      setState({ status: 'missing', all: [] });
      return;
    }
    let cancelled = false;
    setState({ status: 'loading' });
    api<{ postTypes: CptMeta[] }>('/api/fields/post-types')
      .then((res) => {
        if (cancelled) return;
        const all = (res.postTypes ?? []).filter((p) => p.active !== false);
        const row = all.find((p) => p.slug === slug);
        if (row) {
          setState({
            status: 'ready',
            labels: { singular: row.singular, plural: row.plural },
            meta: row,
            all,
          });
        } else {
          setState({ status: 'missing', all });
        }
      })
      .catch(() => {
        if (!cancelled) setState({ status: 'missing', all: [] });
      });
    return () => {
      cancelled = true;
    };
  }, [slug]);

  return state;
}
