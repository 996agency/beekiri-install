/** Admin config so Pages, Posts, and custom post types share the same list/editor UX. */

export type BuiltinContentKind = 'page' | 'post';
export type ContentKind = BuiltinContentKind | (string & {});

export type ContentKindConfig = {
  kind: ContentKind;
  apiBase: string;
  listPath: string;
  listKey: string;
  itemKey: string;
  editCap: 'edit_pages' | 'edit_posts';
  publishCap: 'publish_pages' | 'publish_posts';
  deleteCap: 'delete_pages' | 'delete_posts';
  label: string;
  labelLower: string;
  labelPlural: string;
  pathPrefix: string;
  blurb: string;
  emptyTitle: string;
  emptyFilteredTitle: string;
};

export type CptLabels = { singular?: string; plural?: string };

export const CONTENT_KINDS: Record<BuiltinContentKind, ContentKindConfig> = {
  page: {
    kind: 'page',
    apiBase: '/api/pages',
    listPath: '/admin/pages',
    listKey: 'pages',
    itemKey: 'page',
    editCap: 'edit_pages',
    publishCap: 'publish_pages',
    deleteCap: 'delete_pages',
    label: 'Page',
    labelLower: 'page',
    labelPlural: 'Pages',
    pathPrefix: '/',
    blurb: 'Create and publish pages for your site.',
    emptyTitle: 'No pages yet. Click Add new to start.',
    emptyFilteredTitle: 'No pages match these filters.',
  },
  post: {
    kind: 'post',
    apiBase: '/api/posts',
    listPath: '/admin/posts',
    listKey: 'posts',
    itemKey: 'post',
    editCap: 'edit_posts',
    publishCap: 'publish_posts',
    deleteCap: 'delete_posts',
    label: 'Post',
    labelLower: 'post',
    labelPlural: 'Posts',
    pathPrefix: '/blog/',
    blurb: 'Create and publish single blog posts.',
    emptyTitle: 'No posts yet. Click Add new to start.',
    emptyFilteredTitle: 'No posts match these filters.',
  },
};

export function contentKindConfig(kind: ContentKind, labels?: CptLabels): ContentKindConfig {
  if (kind === 'page') return CONTENT_KINDS.page;
  if (kind === 'post') return CONTENT_KINDS.post;

  const singular = (labels?.singular || kind).trim() || kind;
  const plural = (labels?.plural || `${singular}s`).trim() || `${singular}s`;
  const lower = singular.toLowerCase();
  return {
    kind,
    apiBase: `/api/content/${kind}`,
    listPath: `/admin/content/${kind}`,
    listKey: 'items',
    itemKey: 'item',
    editCap: 'edit_posts',
    publishCap: 'publish_posts',
    deleteCap: 'delete_posts',
    label: singular,
    labelLower: lower,
    labelPlural: plural,
    pathPrefix: `/${kind}/`,
    blurb: `Create and publish ${plural.toLowerCase()}.`,
    emptyTitle: `No ${plural.toLowerCase()} yet. Click Add new to start.`,
    emptyFilteredTitle: `No ${plural.toLowerCase()} match these filters.`,
  };
}
