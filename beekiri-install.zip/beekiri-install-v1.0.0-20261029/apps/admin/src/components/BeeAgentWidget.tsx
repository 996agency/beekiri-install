import { useEffect, useState } from 'react';
import { api } from '../api/client';
import { CONNECTOR_CHANGED } from '../lib/admin-events';
import { BeeAgentChat } from './BeeAgentChat';
import { CubeBee } from './CubeBee';
import './bee-agent-widget.css';

type Provider = { id: string; name: string; enabled: boolean; configured?: boolean };

/**
 * Floating Beekiri bee — shows when any AI connector is on.
 * Hidden until hover (same pattern as Cookie settings reopen); click opens BeeQueen.
 */
export function BeeAgentWidget() {
  const [enabled, setEnabled] = useState<Provider[]>([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const load = () => {
      api<{ providers: Provider[] }>('/api/connector')
        .then((res) => {
          if (!cancelled) setEnabled((res.providers ?? []).filter((p) => p.enabled));
        })
        .catch(() => {
          if (!cancelled) setEnabled([]);
        });
    };
    load();
    window.addEventListener(CONNECTOR_CHANGED, load);
    return () => {
      cancelled = true;
      window.removeEventListener(CONNECTOR_CHANGED, load);
    };
  }, []);

  useEffect(() => {
    const on = enabled.length > 0;
    document.body.classList.toggle('bk-has-bee-agent', on);
    return () => document.body.classList.remove('bk-has-bee-agent');
  }, [enabled.length]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  if (!enabled.length) return null;

  const first = enabled[0];
  const brand = ['beequeen', 'claude', 'openai', 'gemini', 'grok'].includes(first.id)
    ? first.id
    : 'beequeen';
  const ready = enabled.filter((p) => p.configured);
  const label =
    enabled.length === 1
      ? first.configured
        ? first.name
        : `${first.name} is waiting`
      : ready.length === enabled.length
        ? `${enabled.length} agents`
        : `${enabled.length} agents waiting`;

  return (
    <>
      {/* Hidden while chat is open — same idea as Cookie settings reopen */}
      {!open ? (
        <button
          type="button"
          className={`bk-bee-agent is-${brand}`}
          aria-label={`Open ${label}`}
          title={label}
          onClick={() => setOpen(true)}
        >
          <span className="bk-bee-agent__hint" aria-hidden>
            <span className="bk-bee-agent__dot" />
            <span className="bk-bee-agent__reveal">
              <span className="bk-bee-agent__scene">
                <CubeBee brand={brand} />
              </span>
              <span className="bk-bee-agent__tip">{label}</span>
            </span>
          </span>
        </button>
      ) : null}

      <BeeAgentChat open={open} agentName={first.name} onClose={() => setOpen(false)} />
    </>
  );
}
