import { useEffect, useId, useState } from 'react';
import { createPortal } from 'react-dom';

export type ConfirmOptions = {
  title?: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  /** Destructive action (red confirm button). */
  danger?: boolean;
};

type PendingConfirm = ConfirmOptions & {
  resolve: (ok: boolean) => void;
};

let pending: PendingConfirm | null = null;
const listeners = new Set<() => void>();

function notify() {
  listeners.forEach((l) => l());
}

/** Drop-in async replacement for `window.confirm`. */
export function confirmDialog(messageOrOptions: string | ConfirmOptions): Promise<boolean> {
  const opts: ConfirmOptions =
    typeof messageOrOptions === 'string' ? { message: messageOrOptions } : messageOrOptions;

  return new Promise<boolean>((resolve) => {
    if (pending) pending.resolve(false);
    pending = {
      title: opts.title ?? 'Please confirm',
      message: opts.message,
      confirmLabel: opts.confirmLabel ?? 'OK',
      cancelLabel: opts.cancelLabel ?? 'Cancel',
      danger: opts.danger ?? false,
      resolve,
    };
    notify();
  });
}

function settle(ok: boolean) {
  const req = pending;
  pending = null;
  notify();
  req?.resolve(ok);
}

/** Mount once inside the admin shell so confirms can open from anywhere. */
export function ConfirmDialogHost() {
  const [, tick] = useState(0);
  const titleId = useId();
  const req = pending;

  useEffect(() => {
    const onChange = () => tick((n) => n + 1);
    listeners.add(onChange);
    return () => {
      listeners.delete(onChange);
    };
  }, []);

  useEffect(() => {
    if (!req) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') settle(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [req]);

  if (!req || typeof document === 'undefined') return null;

  return createPortal(
    <div
      className="bk-confirm"
      role="dialog"
      aria-modal="true"
      aria-labelledby={titleId}
      onClick={(e) => {
        if (e.target === e.currentTarget) settle(false);
      }}
    >
      <div className="bk-confirm__panel">
        <div className="bk-confirm__head">
          <h2 id={titleId} className="bk-confirm__title">
            {req.title}
          </h2>
        </div>
        <div className="bk-confirm__body">
          <p className="bk-confirm__message">{req.message}</p>
        </div>
        <div className="bk-confirm__actions">
          <button type="button" className="button" onClick={() => settle(false)} autoFocus>
            {req.cancelLabel}
          </button>
          <button
            type="button"
            className={`button ${req.danger ? 'bk-confirm__danger' : 'button-primary'}`}
            onClick={() => settle(true)}
          >
            {req.confirmLabel}
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}
