import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';

const DISMISS_MS = 4000;

/** Viewport-fixed bottom toast; portaled so page transforms can't trap it. */
export function SuccessNotice({
  message,
  onDismiss,
}: {
  message: string;
  onDismiss: () => void;
}) {
  const onDismissRef = useRef(onDismiss);
  onDismissRef.current = onDismiss;

  useEffect(() => {
    const t = window.setTimeout(() => onDismissRef.current(), DISMISS_MS);
    return () => window.clearTimeout(t);
  }, [message]);

  if (typeof document === 'undefined') return null;

  return createPortal(
    <div className="beekiri-notice is-success bk-toast-notice" role="status">
      <p>{message}</p>
    </div>,
    document.body,
  );
}
