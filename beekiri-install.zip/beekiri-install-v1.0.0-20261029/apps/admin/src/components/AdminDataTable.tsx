import { ReactNode, useEffect, useMemo, useState } from 'react';

export type AdminTableFilter =
  | {
      key: string;
      label: string;
      type: 'text';
      placeholder?: string;
    }
  | {
      key: string;
      label: string;
      type: 'select';
      options: { value: string; label: string }[];
      allLabel?: string;
    };

export type AdminTableColumn<T> = {
  key: string;
  header: string;
  render: (row: T) => ReactNode;
  className?: string;
};

type Props<T> = {
  rows: T[];
  columns: AdminTableColumn<T>[];
  getRowId: (row: T) => string;
  filters?: AdminTableFilter[];
  /** Controlled filter values (preferred when Clear filters lives in the page header). */
  filterValues?: Record<string, string>;
  onFilterChange?: (values: Record<string, string>) => void;
  /** Return true to keep the row. `values` maps filter key → current value ('' = all / empty). */
  filterFn?: (row: T, values: Record<string, string>) => boolean;
  /** Click anywhere on the row (except interactive controls that stop propagation). */
  onRowClick?: (row: T) => void;
  pageSizeOptions?: number[];
  defaultPageSize?: number;
  loading?: boolean;
  emptyTitle?: string;
  emptyFilteredTitle?: string;
};

const DEFAULT_PAGE_SIZES = [10, 25, 50];

function emptyFilterState(filters: AdminTableFilter[]) {
  const init: Record<string, string> = {};
  for (const f of filters) init[f.key] = '';
  return init;
}

export function hasActiveAdminFilters(values: Record<string, string>) {
  return Object.values(values).some((v) => v.trim() !== '');
}

export function AdminDataTable<T>({
  rows,
  columns,
  getRowId,
  filters = [],
  filterValues: controlledValues,
  onFilterChange,
  filterFn,
  onRowClick,
  pageSizeOptions = DEFAULT_PAGE_SIZES,
  defaultPageSize = 10,
  loading = false,
  emptyTitle = 'Nothing here yet.',
  emptyFilteredTitle = 'No rows match these filters.',
}: Props<T>) {
  const isControlled = controlledValues !== undefined;
  const [internalValues, setInternalValues] = useState(() => emptyFilterState(filters));
  const filterValues = isControlled ? controlledValues! : internalValues;

  const setFilterValues = (next: Record<string, string>) => {
    if (!isControlled) setInternalValues(next);
    onFilterChange?.(next);
  };

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(defaultPageSize);

  const filtered = useMemo(() => {
    if (!filterFn) return rows;
    return rows.filter((row) => filterFn(row, filterValues));
  }, [rows, filterFn, filterValues]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(page, totalPages);

  useEffect(() => {
    setPage(1);
  }, [filterValues, pageSize, rows.length]);

  useEffect(() => {
    if (page !== safePage) setPage(safePage);
  }, [page, safePage]);

  const pageRows = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, safePage, pageSize]);

  const from = filtered.length === 0 ? 0 : (safePage - 1) * pageSize + 1;
  const to = Math.min(safePage * pageSize, filtered.length);
  const hasActiveFilters = hasActiveAdminFilters(filterValues);

  const setFilter = (key: string, value: string) => {
    setFilterValues({ ...filterValues, [key]: value });
  };

  return (
    <div className="bk-table">
      {filters.length > 0 ? (
        <div className="bk-table__toolbar">
          <div className="bk-table__filters">
            {filters.map((f) =>
              f.type === 'text' ? (
                <label key={f.key} className="bk-table__filter">
                  <span className="bk-table__filter-label">{f.label}</span>
                  <input
                    type="search"
                    className="regular-text"
                    value={filterValues[f.key] ?? ''}
                    placeholder={f.placeholder ?? ''}
                    onChange={(e) => setFilter(f.key, e.target.value)}
                  />
                </label>
              ) : (
                <label key={f.key} className="bk-table__filter">
                  <span className="bk-table__filter-label">{f.label}</span>
                  <select
                    value={filterValues[f.key] ?? ''}
                    onChange={(e) => setFilter(f.key, e.target.value)}
                  >
                    <option value="">{f.allLabel ?? `All ${f.label.toLowerCase()}s`}</option>
                    {f.options.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </label>
              ),
            )}
          </div>
        </div>
      ) : null}

      {loading ? (
        <div className="bk-table__empty">
          <p className="bk-muted" style={{ margin: 0 }}>
            Loading…
          </p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="bk-table__empty">
          <p className="bk-muted" style={{ margin: 0 }}>
            {hasActiveFilters ? emptyFilteredTitle : emptyTitle}
          </p>
        </div>
      ) : (
        <>
          <div className="bk-table__wrap">
            <table className="bk-table__grid">
              <thead>
                <tr>
                  {columns.map((col) => (
                    <th key={col.key} scope="col" className={col.className}>
                      {col.header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {pageRows.map((row) => (
                  <tr
                    key={getRowId(row)}
                    className={onRowClick ? 'is-clickable' : undefined}
                    onClick={onRowClick ? () => onRowClick(row) : undefined}
                  >
                    {columns.map((col) => (
                      <td key={col.key} className={col.className}>
                        {col.render(row)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="bk-table__footer">
            <p className="bk-table__count">
              Showing <strong>{from}</strong>–<strong>{to}</strong> of{' '}
              <strong>{filtered.length}</strong>
              {hasActiveFilters ? ` (filtered from ${rows.length})` : null}
            </p>

            <div className="bk-table__pager">
              <label className="bk-table__pagesize">
                <span>Per page</span>
                <select
                  value={pageSize}
                  onChange={(e) => setPageSize(Number(e.target.value))}
                >
                  {pageSizeOptions.map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
              </label>

              <div className="bk-table__pages" role="navigation" aria-label="Pagination">
                <button
                  type="button"
                  className="button"
                  disabled={safePage <= 1}
                  onClick={() => setPage(1)}
                  aria-label="First page"
                >
                  «
                </button>
                <button
                  type="button"
                  className="button"
                  disabled={safePage <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  aria-label="Previous page"
                >
                  ‹
                </button>
                <span className="bk-table__page-label">
                  Page {safePage} of {totalPages}
                </span>
                <button
                  type="button"
                  className="button"
                  disabled={safePage >= totalPages}
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  aria-label="Next page"
                >
                  ›
                </button>
                <button
                  type="button"
                  className="button"
                  disabled={safePage >= totalPages}
                  onClick={() => setPage(totalPages)}
                  aria-label="Last page"
                >
                  »
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
