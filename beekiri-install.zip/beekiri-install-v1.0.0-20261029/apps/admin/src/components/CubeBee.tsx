import { useMemo, type CSSProperties } from 'react';

type Rgb = readonly [number, number, number];

const ORANGE: Rgb = [255, 149, 8];
const DEFAULT_INK: Rgb = [26, 22, 18];

/** Design canvas in the original HTML. */
const DESIGN = 420;
/** Widget bee size — keep form, no CSS stretch. */
export const CUBE_BEE_SIZE = 42;
const S = CUBE_BEE_SIZE / DESIGN;

/** Connector brand → stripe RGB (cube bands wrap through the body). */
export const CUBE_BEE_STRIPE: Record<string, Rgb> = {
  beequeen: DEFAULT_INK,
  claude: [217, 119, 87],
  openai: [16, 163, 127],
  gemini: [66, 133, 244],
  grok: [29, 35, 39],
};

function band(t: number) {
  return (t > 0.22 && t < 0.4) || (t > 0.58 && t < 0.76);
}

function mix(c: Rgb, k: number) {
  return `rgb(${c.map((v) => Math.round(v * k)).join(',')})`;
}

type Slice = { key: number; style: CSSProperties };

function buildSlices(ink: Rgb): Slice[] {
  const W = 180 * S;
  const H = 170 * S;
  const D = 160 * S;
  const R = 36 * S;
  const N = 48;
  const out: Slice[] = [];
  for (let i = 0; i <= N; i++) {
    const t = i / N;
    const z = D / 2 - t * D;
    const a = Math.abs(z);
    const cap = D / 2 - R;
    const inset = a > cap ? R - Math.sqrt(R * R - (a - cap) * (a - cap)) : 0;
    const w = W - inset * 2;
    const h = H - inset * 2;
    out.push({
      key: i,
      style: {
        width: w,
        height: h,
        left: -w / 2,
        top: -h / 2,
        borderRadius: Math.max(26 * S, 52 * S - inset * 0.4),
        transform: `translateZ(${z.toFixed(3)}px)`,
        background: mix(band(t) ? ink : ORANGE, 1 - 0.2 * t),
      },
    });
  }
  return out;
}

type Props = {
  brand?: string;
  className?: string;
};

/**
 * Rounded cube bee — same proportions as `Beekiri cube bee.html`, drawn at 42×42.
 */
export function CubeBee({ brand = 'beequeen', className }: Props) {
  const ink = CUBE_BEE_STRIPE[brand] ?? DEFAULT_INK;
  const slices = useMemo(() => buildSlices(ink), [ink]);

  const rootStyle = {
    width: CUBE_BEE_SIZE,
    height: CUBE_BEE_SIZE,
    ['--cb-persp' as string]: `${1000 * S}px`,
    ['--cb-eye-w' as string]: `${26 * S}px`,
    ['--cb-eye-h' as string]: `${32 * S}px`,
    ['--cb-eye-top' as string]: `${14 * S}px`,
    ['--cb-eye-z' as string]: `${81 * S}px`,
    ['--cb-eye-gap' as string]: `${34 * S}px`,
    ['--cb-ant-top' as string]: `${-134 * S}px`,
    ['--cb-ant-w' as string]: `${3 * S}px`,
    ['--cb-ant-h' as string]: `${52 * S}px`,
    ['--cb-ant-knob' as string]: `${15 * S}px`,
    ['--cb-ant-knob-l' as string]: `${-6 * S}px`,
    ['--cb-ant-knob-t' as string]: `${-10 * S}px`,
    ['--cb-ant-x' as string]: `${34 * S}px`,
    ['--cb-ant-z' as string]: `${22 * S}px`,
    ['--cb-hinge-top' as string]: `${-6 * S}px`,
    ['--cb-hinge-x' as string]: `${90 * S}px`,
    ['--cb-wing-w' as string]: `${78 * S}px`,
    ['--cb-wing-h' as string]: `${30 * S}px`,
    ['--cb-wing-top' as string]: `${-14 * S}px`,
    ['--cb-fly-x' as string]: `${80 * S}px`,
    ['--cb-fly-y' as string]: `${20 * S}px`,
    ['--cb-fly-z' as string]: `${70 * S}px`,
    ['--cb-fly-y2' as string]: `${8 * S}px`,
    ['--cb-fly-z2' as string]: `${20 * S}px`,
    ['--cb-bob' as string]: `${7 * S}px`,
    ['--cb-shadow-w' as string]: `${200 * S}px`,
    ['--cb-shadow-h' as string]: `${26 * S}px`,
  } as CSSProperties;

  return (
    <div className={`bk-cube-bee${className ? ` ${className}` : ''}`} style={rootStyle} aria-hidden>
      <div className="bk-cube-bee__stage">
        <div className="bk-cube-bee__tilt">
          <div className="bk-cube-bee__path">
            <div className="bk-cube-bee__bob">
              <div className="bk-cube-bee__hinge bk-cube-bee__hinge--l">
                <div className="bk-cube-bee__wing" />
              </div>
              <div className="bk-cube-bee__hinge bk-cube-bee__hinge--r">
                <div className="bk-cube-bee__wing" />
              </div>
              <div className="bk-cube-bee__body">
                {slices.map((s) => (
                  <div key={s.key} className="bk-cube-bee__slice" style={s.style} />
                ))}
              </div>
              <div className="bk-cube-bee__eye bk-cube-bee__eye--a" />
              <div className="bk-cube-bee__eye bk-cube-bee__eye--b" />
              <div className="bk-cube-bee__ant bk-cube-bee__ant--a" />
              <div className="bk-cube-bee__ant bk-cube-bee__ant--b" />
            </div>
          </div>
        </div>
        <div className="bk-cube-bee__shadow" />
      </div>
    </div>
  );
}
