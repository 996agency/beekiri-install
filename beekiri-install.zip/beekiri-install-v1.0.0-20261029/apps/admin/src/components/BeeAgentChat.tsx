import { createPortal } from 'react-dom';
import { X } from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import MorphOrb from './morph-orb/MorphOrb';
import './bee-agent-chat.css';

type Props = {
  open: boolean;
  agentName: string;
  onClose: () => void;
};

type AgentResponse = {
  ok: boolean;
  reply: string;
  action?: string;
  group?: { id: string; title: string; path: string };
};

/** Full-screen BeeQueen — runs theme/layout agent (creates field group + syncs PHP/SCSS). */
export function BeeAgentChat({ open, agentName, onClose }: Props) {
  if (!open || typeof document === 'undefined') return null;

  const runAgent = async (text: string) => {
    try {
      const res = await api<AgentResponse>('/api/connector/agent', {
        method: 'POST',
        json: { prompt: text },
      });
      return res.reply;
    } catch (e) {
      if (e instanceof ApiError) return e.message;
      if (e instanceof Error) return e.message;
      return 'BeeQueen could not complete that.';
    }
  };

  return createPortal(
    <div
      className="bk-bee-chat"
      role="dialog"
      aria-modal="true"
      aria-label={`${agentName} assistant`}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bk-bee-chat__panel">
        <div className="bk-bee-chat__bar">
          <div className="bk-bee-chat__titles">
            <strong>{agentName}</strong>
            <span>Ask for a section — she builds it for your site theme</span>
          </div>
          <button type="button" className="bk-bee-chat__close" aria-label="Close" onClick={onClose}>
            <X size={18} weight="regular" aria-hidden />
          </button>
        </div>
        <div className="bk-bee-chat__stage">
          <MorphOrb minThinkMs={1800} onSubmit={runAgent} />
        </div>
        <p className="bk-bee-chat__hint">
          Theme layouts only — model API coming soon (Claude). You can still open BeeQueen; asks won’t edit files yet.
        </p>
      </div>
    </div>,
    document.body,
  );
}
