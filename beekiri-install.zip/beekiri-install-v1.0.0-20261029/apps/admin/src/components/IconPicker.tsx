import { useMemo, useState } from 'react';
import * as Phosphor from '@phosphor-icons/react';
import type { Icon } from '@phosphor-icons/react';

/** Curated Phosphor icons for CPT menu + general admin use. */
export const ADMIN_ICON_NAMES = [
  'Cube',
  'Package',
  'ShoppingBag',
  'ShoppingCart',
  'Storefront',
  'Tag',
  'Tags',
  'Ticket',
  'Calendar',
  'CalendarBlank',
  'Clock',
  'MapPin',
  'Buildings',
  'House',
  'Users',
  'User',
  'UserCircle',
  'Briefcase',
  'GraduationCap',
  'BookOpen',
  'Newspaper',
  'Article',
  'NotePencil',
  'FileText',
  'Files',
  'Folder',
  'Images',
  'Image',
  'Camera',
  'VideoCamera',
  'MusicNotes',
  'Microphone',
  'Megaphone',
  'ChatCircle',
  'Envelope',
  'Phone',
  'Globe',
  'Compass',
  'MapTrifold',
  'Car',
  'Airplane',
  'Boat',
  'Heart',
  'Star',
  'Trophy',
  'Gift',
  'Lightning',
  'Flame',
  'Leaf',
  'PawPrint',
  'Wrench',
  'GearSix',
  'PuzzlePiece',
  'Stack',
  'SquaresFour',
  'ChartLine',
  'CurrencyDollar',
  'Handshake',
  'Smiley',
] as const;

export type AdminIconName = (typeof ADMIN_ICON_NAMES)[number];

export function resolveAdminIcon(name: string | null | undefined): Icon {
  const key = (name || 'Cube').trim();
  const mod = Phosphor as unknown as Record<string, Icon>;
  return mod[key] || Phosphor.Cube;
}

type Props = {
  value: string;
  onChange: (name: string) => void;
  id?: string;
};

export function IconPicker({ value, onChange, id }: Props) {
  const [query, setQuery] = useState('');
  const selected = value || 'Cube';
  const SelectedIcon = resolveAdminIcon(selected);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [...ADMIN_ICON_NAMES];
    return ADMIN_ICON_NAMES.filter((n) => n.toLowerCase().includes(q));
  }, [query]);

  return (
    <div className="bk-icon-picker" id={id}>
      <div className="bk-icon-picker__current">
        <span className="bk-icon-picker__preview" aria-hidden>
          <SelectedIcon size={22} weight="regular" />
        </span>
        <code>{selected}</code>
      </div>
      <input
        type="search"
        className="regular-text bk-icon-picker__search"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search icons…"
        aria-label="Search icons"
      />
      <div className="bk-icon-picker__grid" role="listbox" aria-label="Icon library">
        {filtered.map((name) => {
          const IconCmp = resolveAdminIcon(name);
          const active = name === selected;
          return (
            <button
              key={name}
              type="button"
              role="option"
              aria-selected={active}
              className={`bk-icon-picker__btn${active ? ' is-active' : ''}`}
              title={name}
              onClick={() => onChange(name)}
            >
              <IconCmp size={20} weight="regular" aria-hidden />
              <span>{name}</span>
            </button>
          );
        })}
      </div>
      <p className="description">Pick an icon for the admin sidebar menu item.</p>
    </div>
  );
}
