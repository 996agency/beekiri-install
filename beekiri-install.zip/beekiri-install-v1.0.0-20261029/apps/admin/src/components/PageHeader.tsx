import { ReactNode } from 'react';

type Props = {
  title: string;
  /** Right-side page actions (Clear filters, Add user, etc.) — same on every list page. */
  actions?: ReactNode;
};

/** Standard admin page title row: title left, actions right. */
export function PageHeader({ title, actions }: Props) {
  return (
    <div className="bk-page-head">
      <h1 className="bk-page-head__title">{title}</h1>
      {actions ? <div className="bk-page-head__actions">{actions}</div> : null}
    </div>
  );
}
