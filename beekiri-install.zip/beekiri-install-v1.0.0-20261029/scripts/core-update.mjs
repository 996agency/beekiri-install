#!/usr/bin/env node
/**
 * In-place Beekiri Core update, started from Settings → Beekiri Core → Update.
 * Runs detached from the API (the API restarts while files change).
 *
 * Never touches: .env files, uploads, backups, the database contents,
 * site-generated theme layouts, node_modules (reinstalled), git history.
 * Only copies/overwrites core files; nothing on the site is deleted.
 * Retired core files are moved into the update backup.
 *
 * Usage: node scripts/core-update.mjs <version> <zipUrl>
 */
import { spawnSync } from 'node:child_process';
import {
  cpSync,
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, relative, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const STATUS = join(ROOT, '.beekiri-update.json');
const [version, zipUrl] = process.argv.slice(2);

const SKIP_TOP = new Set([
  '.git',
  'node_modules',
  'uploads',
  'backups',
  'releases',
  '.env',
  '.env.local',
  '.beekiri-update.json',
  '.turbo',
]);
const SKIP_ANYWHERE = new Set(['node_modules', '.next', '.next-dev', 'dist', '.turbo', 'uploads']);
const SKIP_EXACT = new Set([
  'apps/api/.env',
  'apps/api/.env.local',
  'apps/api/.cache-epoch',
  'apps/admin/.env',
  'apps/web/.env',
]);

/** Core paths removed in later versions. Moved into the update backup, never deleted outright. */
const RETIRED = [
  'apps/api/nest-cli.json',
  'apps/api/prisma',
  'apps/api/src/main.ts',
  'apps/api/src/app.module.ts',
  ...['auth', 'common', 'fields', 'health', 'install', 'layouts', 'mail', 'media', 'pages', 'prisma', 'site', 'system', 'themes', 'users'].map(
    (dir) => `apps/api/src/${dir}`,
  ),
  '.env.example',
  'scripts/client-prep.sh',
  'scripts/setup-996-ssh.sh',
  'docs',
];

const startedAt = new Date().toISOString();
let fromVersion = '';
try {
  fromVersion = JSON.parse(readFileSync(join(ROOT, 'beekiri.manifest.json'), 'utf8')).coreVersion ?? '';
} catch {
  /* unknown */
}

function status(patch) {
  let prev = {};
  try {
    prev = JSON.parse(readFileSync(STATUS, 'utf8'));
  } catch {
    /* first write */
  }
  writeFileSync(
    STATUS,
    JSON.stringify(
      { ...prev, version, fromVersion, startedAt, updatedAt: new Date().toISOString(), ...patch },
      null,
      2,
    ),
  );
}

function fail(message, detail) {
  status({ state: 'error', message, detail: detail ? String(detail).slice(-2000) : undefined });
  process.exit(1);
}

function run(cmd, args, label) {
  const res = spawnSync(cmd, args, {
    cwd: ROOT,
    encoding: 'utf8',
    shell: process.platform === 'win32',
    env: { ...process.env, CI: '1' },
    maxBuffer: 64 * 1024 * 1024,
  });
  if (res.status !== 0) {
    fail(`${label} failed.`, `${res.stderr || ''}\n${res.stdout || ''}`.trim() || res.error?.message);
  }
  return res;
}

function skip(rel) {
  const norm = rel.split(sep).join('/');
  const top = norm.split('/')[0];
  if (SKIP_TOP.has(top)) return true;
  if (SKIP_EXACT.has(norm)) return true;
  if (norm.split('/').some((part) => SKIP_ANYWHERE.has(part))) return true;
  // Child themes and site-generated layouts stay as the site built them.
  if (/^apps\/web\/themes\/[^/]+-child(\/|$)/.test(norm)) return true;
  if (/^apps\/web\/themes\/[^/]+\/layouts\//.test(norm)) return true;
  return false;
}

function extract(zip, dest) {
  mkdirSync(dest, { recursive: true });
  const attempts =
    process.platform === 'win32'
      ? [
          ['tar', ['-xf', zip, '-C', dest]],
          [
            'powershell',
            ['-NoProfile', '-Command', `Expand-Archive -Force -Path '${zip}' -DestinationPath '${dest}'`],
          ],
        ]
      : [
          ['unzip', ['-q', '-o', zip, '-d', dest]],
          ['tar', ['-xf', zip, '-C', dest]],
        ];
  for (const [cmd, args] of attempts) {
    const res = spawnSync(cmd, args, { encoding: 'utf8', shell: process.platform === 'win32' });
    if (res.status === 0) return;
  }
  fail('Could not unpack the update package.');
}

function packageRoot(dir) {
  if (existsSync(join(dir, 'beekiri.manifest.json'))) return dir;
  for (const name of readdirSync(dir)) {
    const sub = join(dir, name);
    if (statSync(sub).isDirectory() && existsSync(join(sub, 'beekiri.manifest.json'))) return sub;
  }
  return null;
}

async function main() {
  if (!version || !zipUrl) fail('Missing update version or package URL.');

  const work = join(tmpdir(), `beekiri-update-${Date.now()}`);
  mkdirSync(work, { recursive: true });

  // 1. Download
  status({ state: 'running', step: 'download', progress: 5, message: 'Downloading update…' });
  let zipPath = join(work, 'core.zip');
  try {
    const res = await fetch(`${zipUrl}${zipUrl.includes('?') ? '&' : '?'}t=${Date.now()}`, {
      redirect: 'follow',
      headers: { 'User-Agent': 'Beekiri-CMS-Updater' },
    });
    if (!res.ok) fail(`Download failed (HTTP ${res.status}).`);
    const total = Number(res.headers.get('content-length')) || 0;
    const chunks = [];
    let received = 0;
    for await (const chunk of res.body) {
      chunks.push(chunk);
      received += chunk.length;
      if (total) {
        status({ progress: 5 + Math.round((received / total) * 20), message: 'Downloading update…' });
      }
    }
    writeFileSync(zipPath, Buffer.concat(chunks));
  } catch (e) {
    fail('Could not download the update.', e?.message);
  }

  // 2. Unpack + verify
  status({ step: 'verify', progress: 28, message: 'Verifying package…' });
  extract(zipPath, join(work, 'pkg'));
  const pkg = packageRoot(join(work, 'pkg'));
  if (!pkg) fail('Update package is not a Beekiri Core package.');
  const pkgVersion = JSON.parse(readFileSync(join(pkg, 'beekiri.manifest.json'), 'utf8')).coreVersion;
  if (pkgVersion !== version) fail(`Package is v${pkgVersion}, expected v${version}.`);

  // 3. Backup current core files (code only; database and uploads are untouched)
  status({ step: 'backup', progress: 35, message: 'Backing up current core files…' });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupDir = join(ROOT, 'backups', `core-v${fromVersion || 'unknown'}-${stamp}`);
  try {
    mkdirSync(backupDir, { recursive: true });
    for (const name of readdirSync(ROOT)) {
      if (skip(name)) continue;
      cpSync(join(ROOT, name), join(backupDir, name), {
        recursive: true,
        filter: (src) => !skip(relative(ROOT, src)),
      });
    }
  } catch (e) {
    fail('Backup failed. No files were changed.', e?.message);
  }

  // 4. Apply new core files (copy over; never delete site files)
  status({ step: 'apply', progress: 50, message: 'Applying core files…', backupDir });
  try {
    cpSync(pkg, ROOT, {
      recursive: true,
      force: true,
      filter: (src) => {
        const rel = relative(pkg, src);
        return !rel || !skip(rel);
      },
    });
  } catch (e) {
    fail(`Applying files failed. Restore from ${backupDir}.`, e?.message);
  }

  for (const rel of RETIRED) {
    const from = join(ROOT, rel);
    if (!existsSync(from) || existsSync(join(pkg, rel))) continue;
    try {
      const to = join(backupDir, 'retired', rel);
      mkdirSync(dirname(to), { recursive: true });
      renameSync(from, to);
    } catch {
      /* leftovers are harmless: the API build only compiles from its entry points */
    }
  }

  // 5. Dependencies
  status({ step: 'install', progress: 62, message: 'Installing dependencies…' });
  run('npm', ['install', '--prefer-offline', '--no-audit', '--no-fund'], 'Installing dependencies');

  // 6. Database migrations (applies new migrations only; existing data is kept)
  status({ step: 'migrate', progress: 80, message: 'Updating database schema safely…' });
  run('npm', ['run', 'db:migrate'], 'Database migration');

  // 7. Production builds (dev servers reload on their own)
  if (process.env.NODE_ENV === 'production') {
    status({ step: 'build', progress: 88, message: 'Building…' });
    run('npm', ['run', 'build'], 'Build');
  }

  rmSync(work, { recursive: true, force: true });

  // The dev watcher only reloads on content changes, so write a fresh stamp the API imports.
  if (process.env.NODE_ENV !== 'production') {
    status({ step: 'reload', progress: 95, message: 'Restarting Beekiri services…' });
    try {
      writeFileSync(
        join(ROOT, 'apps', 'api', 'src', 'core-build.ts'),
        `// Rewritten by scripts/core-update.mjs after each update so the dev server reloads.\nexport const CORE_BUILD = 'v${version}-${Date.now()}';\n`,
      );
    } catch {
      /* ignore */
    }
    await new Promise((r) => setTimeout(r, 8000));
  }

  status({
    state: 'done',
    step: 'done',
    progress: 100,
    message: `Beekiri Core v${version} is installed.`,
    restartRequired: process.env.NODE_ENV === 'production',
    finishedAt: new Date().toISOString(),
  });
}

main().catch((e) => fail('Update failed.', e?.stack || e?.message || e));
