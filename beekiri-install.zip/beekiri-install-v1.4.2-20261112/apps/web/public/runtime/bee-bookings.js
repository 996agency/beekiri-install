/* Bee Bookings — the booking widget (apps/web/public/runtime/bee-bookings.js).
   Mounts on every [data-bee-booking]: service → person → day and time → details → booked.
   Optional attributes: data-service="<service id or name>" starts on that service. */
(function () {
  'use strict';
  if (window.__beeBookings) return;
  window.__beeBookings = true;

  var API = '/api/bookings/public';
  var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  var DOW = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
  var setupPromise = null;

  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function get(path) {
    return fetch(API + path, { credentials: 'same-origin', headers: { Accept: 'application/json' } }).then(function (r) {
      return r.json().then(function (d) {
        if (!r.ok) throw new Error((d && d.message) || 'Something went wrong. Please try again.');
        return d;
      });
    });
  }
  function loadSetup() {
    if (!setupPromise) setupPromise = get('/setup').catch(function (e) { setupPromise = null; throw e; });
    return setupPromise;
  }
  /** "Tuesday, 12 November" for a YYYY-MM-DD date. */
  function niceDate(date) {
    var d = new Date(date + 'T12:00:00Z');
    return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][d.getUTCDay()] + ', ' + d.getUTCDate() + ' ' + MONTHS[d.getUTCMonth()];
  }
  function minutes(n) {
    if (n < 60) return n + ' min';
    return Math.floor(n / 60) + ' h' + (n % 60 ? ' ' + (n % 60) + ' min' : '');
  }

  function mount(root) {
    if (root.__bkBooking) return;
    root.__bkBooking = true;
    root.classList.add('bk-book');
    root.innerHTML = '<p class="bk-book__hint">Loading…</p>';

    var s = { setup: null, service: null, staff: undefined, month: '', days: null, date: '', slots: null, slot: null, step: 'service', busy: false, error: '', result: null };

    loadSetup().then(function (setup) {
      s.setup = setup;
      s.month = setup.today.slice(0, 7);
      var want = (root.getAttribute('data-service') || '').trim().toLowerCase();
      var pre = want ? setup.services.filter(function (x) { return x.id.toLowerCase() === want || x.name.toLowerCase() === want; })[0] : null;
      if (!pre && setup.services.length === 1) pre = setup.services[0];
      if (pre) pickService(pre); else draw();
    }).catch(function () {
      root.innerHTML = '<p class="bk-book__hint">Online booking is not available right now.</p>';
    });

    function people() {
      return s.setup.staff.filter(function (p) { return !p.serviceIds.length || p.serviceIds.indexOf(s.service.id) !== -1; });
    }
    function pickService(service) {
      s.service = service;
      s.staff = undefined;
      var who = people();
      // One person (or none to choose from): no need to ask.
      if (who.length <= 1) { s.staff = who[0] || null; goWhen(); }
      else { s.step = 'staff'; draw(); }
    }
    function goWhen() {
      s.step = 'when';
      s.date = '';
      s.slots = null;
      s.slot = null;
      loadDays();
    }
    function query() {
      return '?serviceId=' + encodeURIComponent(s.service.id) + (s.staff ? '&staffId=' + encodeURIComponent(s.staff.id) : '');
    }
    function loadDays() {
      s.days = null;
      draw();
      var month = s.month;
      get('/days' + query() + '&month=' + month).then(function (d) {
        if (month !== s.month) return;
        s.days = d.days || [];
        // Nothing free this month: look at the next one once, so the calendar does not open empty.
        if (!s.days.length && !s.date && !s.skipped && month < s.setup.last.slice(0, 7)) { s.skipped = true; shiftMonth(1); return; }
        draw();
      }).catch(function (e) { s.days = []; s.error = e.message; draw(); });
    }
    function shiftMonth(by) {
      var y = Number(s.month.slice(0, 4)), m = Number(s.month.slice(5, 7)) - 1 + by;
      var d = new Date(Date.UTC(y, m, 1));
      s.month = d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1);
      loadDays();
    }
    function pickDate(date) {
      s.date = date;
      s.slots = null;
      draw();
      get('/slots' + query() + '&date=' + date).then(function (d) {
        if (date !== s.date) return;
        s.slots = d.slots || [];
        draw();
      }).catch(function (e) { s.slots = []; s.error = e.message; draw(); });
    }

    function steps() {
      var order = ['service', 'staff', 'when', 'details'];
      var labels = { service: 'Service', staff: 'Person', when: 'Day and time', details: 'Your details' };
      var shown = order.filter(function (k) { return k !== 'staff' || (s.service ? people().length > 1 : s.setup.staff.length > 1); });
      var at = shown.indexOf(s.step);
      return '<ol class="bk-book__steps">' + shown.map(function (k, i) {
        return '<li class="' + (i < at ? 'is-done' : i === at ? 'is-current' : '') + '"' + (i === at ? ' aria-current="step"' : '') + '>' +
          '<span class="bk-book__step-n" aria-hidden="true">' + (i < at ? '&#10003;' : i + 1) + '</span><span class="bk-book__step-label">' + labels[k] + '</span></li>';
      }).join('') + '</ol>';
    }
    function back(label) {
      return '<button type="button" class="bk-book__back" data-back>&larr; ' + label + '</button>';
    }

    function drawService() {
      if (!s.setup.services.length) return '<p class="bk-book__hint">There is nothing to book yet.</p>';
      return '<h3 class="bk-book__title">What would you like to book?</h3><div class="bk-book__options">' + s.setup.services.map(function (x) {
        return '<button type="button" class="bk-book__option" data-service-id="' + esc(x.id) + '"><span><strong>' + esc(x.name) + '</strong>' +
          '<small>' + minutes(x.durationMin) + (x.description ? ' · ' + esc(x.description) : '') + '</small></span>' +
          '<span class="bk-book__option-meta">' + esc(x.price) + '</span></button>';
      }).join('') + '</div>';
    }
    function drawStaff() {
      return (s.setup.services.length > 1 ? back('Services') : '') + '<h3 class="bk-book__title">Who would you like to see?</h3><div class="bk-book__options">' +
        '<button type="button" class="bk-book__option" data-staff-id=""><span><strong>Anyone available</strong><small>The first person who is free</small></span></button>' +
        people().map(function (p) {
          return '<button type="button" class="bk-book__option" data-staff-id="' + esc(p.id) + '"><span><strong>' + esc(p.name) + '</strong></span></button>';
        }).join('') + '</div>';
    }
    function drawWhen() {
      var y = Number(s.month.slice(0, 4)), m = Number(s.month.slice(5, 7)) - 1;
      var first = new Date(Date.UTC(y, m, 1));
      var lead = (first.getUTCDay() + 6) % 7;
      var count = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
      var cells = '';
      for (var i = 0; i < lead; i++) cells += '<span></span>';
      for (var d = 1; d <= count; d++) {
        var date = s.month + '-' + pad(d);
        var open = s.days && s.days.indexOf(date) !== -1;
        cells += '<button type="button" class="bk-book__day' + (date === s.date ? ' is-selected' : '') + (date === s.setup.today ? ' is-today' : '') + '" data-date="' + date + '"' + (open ? '' : ' disabled') +
          ' aria-label="' + niceDate(date) + (open ? '' : ', not available') + '">' + d + '</button>';
      }
      var canPrev = s.month > s.setup.today.slice(0, 7), canNext = s.month < s.setup.last.slice(0, 7);
      var times;
      var empty = function (text) {
        return '<div class="bk-book__empty"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
          '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><p>' + text + '</p></div>';
      };
      if (!s.date) times = empty(s.days === null ? 'Looking for free days…' : s.days.length ? 'Pick a day to see the free times.' : 'No free days this month. Try the next one.');
      else if (s.slots === null) times = empty('Looking for free times…');
      else if (!s.slots.length) times = empty('No free times left on this day. Please pick another one.');
      else {
        // Morning, afternoon, evening: easier to scan than one long grid.
        var parts = [['Morning', 0, 12], ['Afternoon', 12, 17], ['Evening', 17, 24]];
        times = '<div class="bk-book__times">' + parts.map(function (part) {
          var buttons = s.slots.map(function (t, i) {
            var hour = Number(t.time.slice(0, 2));
            return hour >= part[1] && hour < part[2] ? '<button type="button" class="bk-book__time" data-slot="' + i + '">' + esc(t.time) + '</button>' : '';
          }).join('');
          return buttons ? '<p class="bk-book__part">' + part[0] + '</p><div class="bk-book__time-grid">' + buttons + '</div>' : '';
        }).join('') + '</div>';
      }
      var canBack = people().length > 1 || s.setup.services.length > 1;
      return '<div class="bk-book__picked"><div><strong>' + esc(s.service.name) + '</strong><span>' + minutes(s.service.durationMin) + ' · ' + esc(s.service.price) +
        (s.staff ? ' · with ' + esc(s.staff.name) : '') + '</span></div>' +
        (canBack ? '<button type="button" class="bk-book__change" data-back>Change</button>' : '') + '</div>' +
        '<div class="bk-book__when"><div class="bk-book__cal"><div class="bk-book__cal-head">' +
        '<button type="button" class="bk-book__nav" data-month="-1" aria-label="Previous month"' + (canPrev ? '' : ' disabled') + '>&lsaquo;</button>' +
        '<span>' + MONTHS[m] + ' ' + y + '</span>' +
        '<button type="button" class="bk-book__nav" data-month="1" aria-label="Next month"' + (canNext ? '' : ' disabled') + '>&rsaquo;</button></div>' +
        '<div class="bk-book__grid">' + DOW.map(function (x) { return '<span class="bk-book__dow">' + x + '</span>'; }).join('') + cells + '</div></div>' +
        '<div class="bk-book__slots"><p class="bk-book__times-title">' + (s.date ? niceDate(s.date) : 'Choose a time') + '</p>' + times + '</div></div>' +
        '<p class="bk-book__tz">Times are shown in ' + esc(s.setup.timezone.replace(/_/g, ' ')) + ' time.</p>';
    }
    function summary() {
      return '<div class="bk-book__summary"><strong>' + esc(s.service.name) + '</strong>' + niceDate(s.date) + ' at ' + esc(s.slot.time) +
        ' · ' + minutes(s.service.durationMin) + (s.staff ? ' · ' + esc(s.staff.name) : '') + (s.service.free ? '' : ' · ' + esc(s.service.price)) +
        (s.setup.location ? '<br>' + esc(s.setup.location) : '') + '</div>';
    }
    function drawDetails() {
      return back('Day and time') + '<h3 class="bk-book__title">Your details</h3>' + summary() +
        '<form data-book novalidate><div class="bk-book__fields">' +
        '<label class="bk-book__field">Name<input type="text" name="name" autocomplete="name" required maxlength="120"></label>' +
        '<label class="bk-book__field">Email<input type="email" name="email" autocomplete="email" required maxlength="200"></label>' +
        '<label class="bk-book__field">Phone (optional)<input type="tel" name="phone" autocomplete="tel" maxlength="40"></label>' +
        '<label class="bk-book__field is-wide">Anything we should know? (optional)<textarea name="note" rows="3" maxlength="2000"></textarea></label>' +
        '<label class="bk-book__hp" aria-hidden="true">Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label>' +
        '</div><button type="submit" class="bk-book__submit">' + (s.setup.autoConfirm ? 'Confirm booking' : 'Request booking') + '</button></form>';
    }
    function drawDone() {
      var pending = s.result.status === 'pending';
      return '<div class="bk-book__done"><div class="bk-book__done-mark" aria-hidden="true">&#10003;</div>' +
        '<h3 class="bk-book__title">' + (pending ? 'Request sent' : 'You are booked') + '</h3>' +
        '<p><strong>' + esc(s.service.name) + '</strong> on ' + niceDate(s.date) + ' at ' + esc(s.slot.time) + (s.result.staffName ? ' with ' + esc(s.result.staffName) : '') + '.</p>' +
        '<p>' + (pending ? 'We will email you as soon as it is confirmed.' : 'We sent the details to your email, with a link to cancel if your plans change.') + '</p>' +
        '<button type="button" class="bk-book__again" data-again>Book another appointment</button></div>';
    }

    function draw() {
      // What the customer typed survives a redraw (an error, a retry).
      var kept = {};
      Array.prototype.forEach.call(root.querySelectorAll('[data-book] [name]'), function (el) { kept[el.name] = el.value; });
      var body = s.step === 'service' ? drawService() : s.step === 'staff' ? drawStaff() : s.step === 'when' ? drawWhen() : s.step === 'details' ? drawDetails() : drawDone();
      root.innerHTML = (s.step === 'done' ? '' : steps()) + body + (s.error ? '<p class="bk-book__error" role="alert">' + esc(s.error) + '</p>' : '');
      Object.keys(kept).forEach(function (name) {
        var el = root.querySelector('[data-book] [name="' + name + '"]');
        if (el) el.value = kept[name];
      });
      var submit = root.querySelector('.bk-book__submit');
      if (submit && s.busy) { submit.disabled = true; submit.textContent = 'Booking…'; }
    }

    root.addEventListener('click', function (e) {
      var t = e.target.closest ? e.target.closest('button') : null;
      if (!t || !root.contains(t) || !s.setup) return;
      s.error = '';
      if (t.hasAttribute('data-service-id')) {
        var id = t.getAttribute('data-service-id');
        pickService(s.setup.services.filter(function (x) { return x.id === id; })[0]);
      } else if (t.hasAttribute('data-staff-id')) {
        var sid = t.getAttribute('data-staff-id');
        s.staff = sid ? s.setup.staff.filter(function (p) { return p.id === sid; })[0] : null;
        goWhen();
      } else if (t.hasAttribute('data-month')) {
        s.date = ''; s.slots = null; s.skipped = true;
        shiftMonth(Number(t.getAttribute('data-month')));
      } else if (t.hasAttribute('data-date')) {
        pickDate(t.getAttribute('data-date'));
      } else if (t.hasAttribute('data-slot')) {
        s.slot = s.slots[Number(t.getAttribute('data-slot'))];
        s.step = 'details';
        draw();
        var first = root.querySelector('[data-book] input');
        if (first) first.focus();
      } else if (t.hasAttribute('data-back')) {
        if (s.step === 'details') { s.step = 'when'; draw(); }
        else if (s.step === 'when') { if (people().length > 1) { s.step = 'staff'; draw(); } else { s.step = 'service'; s.service = null; draw(); } }
        else { s.step = 'service'; s.service = null; draw(); }
      } else if (t.hasAttribute('data-again')) {
        s.result = null; s.slot = null; s.date = ''; s.skipped = false; s.step = 'service'; s.service = null;
        s.month = s.setup.today.slice(0, 7);
        if (s.setup.services.length === 1) pickService(s.setup.services[0]); else draw();
      }
    });

    root.addEventListener('submit', function (e) {
      var form = e.target;
      if (!form.hasAttribute || !form.hasAttribute('data-book')) return;
      e.preventDefault();
      if (s.busy) return;
      var v = function (n) { return (form.elements[n].value || '').trim(); };
      if (!v('name')) { s.error = 'Please give your name.'; draw(); return; }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v('email'))) { s.error = 'Please give a valid email address.'; draw(); return; }
      s.busy = true; s.error = ''; draw();
      fetch(API + '/book', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'X-Beekiri-Booking': '1' },
        body: JSON.stringify({ serviceId: s.service.id, staffId: s.staff ? s.staff.id : null, startAt: s.slot.startAt, name: v('name'), email: v('email'), phone: v('phone'), note: v('note'), website: v('website') }),
      }).then(function (r) {
        return r.json().then(function (d) { return { ok: r.ok, status: r.status, d: d }; });
      }).then(function (res) {
        s.busy = false;
        if (!res.ok) {
          s.error = (res.d && res.d.message) || 'The booking could not be made. Please try again.';
          // The time was taken meanwhile: back to the times, freshly loaded.
          if (res.status === 409) { s.step = 'when'; s.slot = null; pickDate(s.date); return; }
          draw();
          return;
        }
        s.result = res.d; s.step = 'done'; draw();
        try { window.dispatchEvent(new CustomEvent('bk:booking:made', { detail: { serviceId: s.service.id } })); } catch (err) {}
      }).catch(function () {
        s.busy = false; s.error = 'The booking could not be made. Please check your connection and try again.'; draw();
      });
    });
  }

  /* The customer's own booking (/booking/<token>, from the link in their email): details and Cancel. */
  function mountManage(root) {
    if (root.__bkBooking) return;
    root.__bkBooking = true;
    root.classList.add('bk-book', 'bk-book--manage');
    root.innerHTML = '<p class="bk-book__hint">Loading…</p>';
    var token = root.getAttribute('data-bee-booking-manage');
    var path = '/manage/' + encodeURIComponent(token);
    var busy = false;

    function show(b, notice, error) {
      var rows = [['Service', b.serviceName], ['When', b.day + ' at ' + b.time], ['With', b.staffName], ['Where', b.location], ['Price', b.price]]
        .filter(function (r) { return r[1]; })
        .map(function (r) { return '<div><dt>' + r[0] + '</dt><dd>' + esc(r[1]) + '</dd></div>'; }).join('');
      root.innerHTML = '<h1 class="bk-book__title">Your booking</h1>' +
        (notice ? '<p class="bk-book__notice" role="status">' + esc(notice) + '</p>' : '') +
        '<p><span class="bk-book__status' + (b.open ? '' : ' is-off') + '">' + esc(b.statusLabel) + '</span></p>' +
        '<dl class="bk-book__facts">' + rows + '</dl>' +
        (b.canCancel ? '<button type="button" class="bk-book__cancel" data-cancel>Cancel this booking</button>'
          : b.open ? '<p class="bk-book__hint">It is too close to the appointment to cancel online. Please contact us.</p>' : '') +
        (error ? '<p class="bk-book__error" role="alert">' + esc(error) + '</p>' : '');
    }

    var current = null;
    get(path).then(function (b) { current = b; show(b); }).catch(function (e) {
      root.innerHTML = '<h1 class="bk-book__title">Booking not found</h1><p class="bk-book__hint">' + esc(e.message || 'This link is not valid any more.') + '</p>';
    });

    root.addEventListener('click', function (e) {
      var t = e.target.closest ? e.target.closest('[data-cancel]') : null;
      if (!t || busy || !current) return;
      if (!window.confirm('Cancel this booking?')) return;
      busy = true;
      t.disabled = true;
      fetch(API + path + '/cancel', { method: 'POST', credentials: 'same-origin', headers: { Accept: 'application/json', 'X-Beekiri-Booking': '1' } })
        .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
        .then(function (res) {
          busy = false;
          if (!res.ok) { show(current, '', (res.d && res.d.message) || 'The booking could not be cancelled.'); return; }
          current = res.d;
          show(current, 'Your booking is cancelled. We sent you a confirmation by email.');
        })
        .catch(function () { busy = false; show(current, '', 'The booking could not be cancelled. Please check your connection and try again.'); });
    });
  }

  function init() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-bee-booking]'), function (el) {
      if (!el.hasAttribute('data-bee-booking-preview')) mount(el);
    });
    Array.prototype.forEach.call(document.querySelectorAll('[data-bee-booking-manage]'), mountManage);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
  window.addEventListener('bk:navigate', init);
})();
