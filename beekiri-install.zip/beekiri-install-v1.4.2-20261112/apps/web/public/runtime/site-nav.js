(function () {
 if (window.__bkSiteNav) return;
 window.__bkSiteNav = true;
 var PASSTHROUGH = ['/api/', '/uploads/', '/_next/', '/admin/'];
 var FILE_EXT = /\.[a-z0-9]{1,8}$/i;
 var prefetched = Object.create(null);
 var busy = false;
 function routable(anchor) {
 if (!anchor || anchor.hasAttribute('download') || anchor.hasAttribute('data-bk-reload')) {
 return null;
 }
 var target = anchor.getAttribute('target');
 if (target && target !== '_self') return null;
 var raw = anchor.getAttribute('href');
 if (!raw || raw.charAt(0) === '#' || /^(mailto|tel|javascript):/i.test(raw)) return null;
 var url;
 try {
 url = new URL(anchor.href, location.href);
 } catch (e) {
 return null;
 }
 if (url.origin !== location.origin) return null;
 // "/.//other.site/x" is a link on this site whose path starts with "//": fetched as written it
 // would go to that other site. Such links get a normal page load.
 if (url.pathname.indexOf('//') === 0 || url.pathname.indexOf('\\') !== -1) return null;
 for (var i = 0; i < PASSTHROUGH.length; i++) {
 var p = PASSTHROUGH[i];
 if (url.pathname === p.slice(0, -1) || url.pathname.indexOf(p) === 0) return null;
 }
 if (FILE_EXT.test(url.pathname)) return null;
 if (url.hash && url.pathname === location.pathname && url.search === location.search) {
 return null;
 }
 return url.pathname + url.search + url.hash;
 }
 function prefetch(href) {
 var path = href.split('#')[0] || '/';
 if (prefetched[path]) return;
 prefetched[path] = true;
 var link = document.createElement('link');
 link.rel = 'prefetch';
 link.as = 'document';
 link.href = path;
 document.head.appendChild(link);
 }
 function adoptStyles(doc) {
 doc.head.querySelectorAll('link[rel="stylesheet"]').forEach(function (node) {
 var href = node.getAttribute('href');
 if (!href) return;
 var abs = new URL(href, location.href).href;
 var found = false;
 document.head.querySelectorAll('link[rel="stylesheet"]').forEach(function (cur) {
 if (cur.href === abs) found = true;
 });
 if (!found) document.head.appendChild(document.importNode(node, true));
 });
 // React hoists <style precedence href> into <head> as data-precedence / data-href.
 // Page rules (bk-page-*) are swapped for the new page's; anything else is added once.
 var wanted = Object.create(null);
 doc.head.querySelectorAll('style[data-href], style[href]').forEach(function (node) {
 var key = styleKey(node);
 if (key) wanted[key] = node;
 });
 var stale = [];
 document.head.querySelectorAll('style[data-href], style[href]').forEach(function (cur) {
 var key = styleKey(cur);
 if (key in wanted) delete wanted[key];
 else if (key.indexOf('bk-page-') === 0) stale.push(cur);
 });
 // New rules take the old page's slot so the cascade matches a full load.
 var anchor = stale.length
 ? stale[stale.length - 1].nextSibling
 : document.head.querySelector('[data-precedence]');
 stale.forEach(function (node) {
 node.remove();
 });
 Object.keys(wanted).forEach(function (key) {
 document.head.insertBefore(document.importNode(wanted[key], true), anchor);
 });
 }
 // A page brought in without a reload carries <script src> tags that never run by themselves
 // (a layout's script.js): start the ones this visit hasn't loaded yet. Scripts already loaded
 // set their sections up again on 'bk:navigate'.
 var loadedScripts = Object.create(null);
 document.querySelectorAll('script[src]').forEach(function (node) {
 loadedScripts[node.src] = true;
 });
 function adoptScripts(shell) {
 shell.querySelectorAll('script[src]').forEach(function (node) {
 var src = node.src;
 if (!src || loadedScripts[src]) return;
 loadedScripts[src] = true;
 var script = document.createElement('script');
 if (node.type) script.type = node.type;
 script.src = src;
 node.replaceWith(script);
 });
 }
 function styleKey(node) {
 return node.getAttribute('data-href') || node.getAttribute('href') || '';
 }
 function applyDocument(html, href, push) {
 var doc = new DOMParser().parseFromString(html, 'text/html');
 var nextShell = doc.querySelector('.bk-shell');
 var curShell = document.querySelector('.bk-shell');
 if (!nextShell || !curShell) {
 location.assign(href);
 return;
 }
 document.title = doc.title || document.title;
 var lang = doc.documentElement.getAttribute('lang');
 if (lang) document.documentElement.lang = lang;
 var theme = doc.documentElement.getAttribute('data-theme');
 if (theme) document.documentElement.setAttribute('data-theme', theme);
 adoptStyles(doc);
 var shell = document.importNode(nextShell, true);
 curShell.replaceWith(shell);
 adoptScripts(shell);
 if (push) history.pushState({ bk: 1 }, '', href);
 window.dispatchEvent(
 new CustomEvent('bk:navigate', { detail: { pathname: location.pathname } }),
 );
 if (location.hash) {
 var el = document.getElementById(location.hash.slice(1));
 if (el) el.scrollIntoView();
 } else {
 window.scrollTo(0, 0);
 }
 }
 function load(href, push) {
 if (busy) return;
 busy = true;
 var path = href.split('#')[0] || '/';
 var run = function () {
 return fetch(path, {
 credentials: 'same-origin',
 // Never another site's page (also when this site redirects there): its markup would run here.
 mode: 'same-origin',
 headers: { Accept: 'text/html' },
 })
 .then(function (res) {
 if (res.url && new URL(res.url).origin !== location.origin) throw new Error('other-site');
 return res;
 })
 .then(function (res) {
 if (!res.ok) throw new Error(String(res.status));
 var ct = res.headers.get('content-type') || '';
 if (ct.indexOf('text/html') === -1) throw new Error('not-html');
 return res.text();
 })
 .then(function (html) {
 applyDocument(html, href, push);
 })
 .catch(function () {
 if (push) location.assign(href);
 else location.reload();
 })
 .finally(function () {
 busy = false;
 });
 };
 if (push && document.startViewTransition) document.startViewTransition(run);
 else run();
 }
 // Language switcher in theme headers (bee_language_switcher): open / close its menu.
 // Capture phase, so the soft navigation below never treats the button as a link.
 function closeLanguageMenus(except) {
 document.querySelectorAll('[data-bk-langsw].is-open').forEach(function (box) {
 if (box === except) return;
 box.classList.remove('is-open');
 var b = box.querySelector('.bk-langsw__btn');
 var m = box.querySelector('.bk-langsw__menu');
 if (b) b.setAttribute('aria-expanded', 'false');
 if (m) m.hidden = true;
 });
 }
 document.addEventListener(
 'click',
 function (e) {
 var t = e.target && e.target.closest ? e.target : null;
 var btn = t && t.closest('[data-bk-langsw] .bk-langsw__btn');
 if (btn) {
 e.preventDefault();
 var box = btn.closest('[data-bk-langsw]');
 var menu = box.querySelector('.bk-langsw__menu');
 var open = !box.classList.contains('is-open');
 closeLanguageMenus(box);
 box.classList.toggle('is-open', open);
 btn.setAttribute('aria-expanded', open ? 'true' : 'false');
 if (menu) menu.hidden = !open;
 return;
 }
 if (!t || !t.closest('[data-bk-langsw]')) closeLanguageMenus(null);
 },
 true,
 );
 document.addEventListener('keydown', function (e) {
 if (e.key !== 'Escape') return;
 var open = document.querySelector('[data-bk-langsw].is-open .bk-langsw__btn');
 closeLanguageMenus(null);
 if (open) open.focus();
 });
 window.addEventListener('bk:navigate', function () {
 closeLanguageMenus(null);
 });
 // Deferred section photos (data-bk-bg): apply each one when it comes within 600px of view.
 var bgObserver = null;
 function lazyBackgrounds() {
 var els = document.querySelectorAll('[data-bk-bg]:not(.bk-bg-in)');
 if (!els.length) return;
 if (!('IntersectionObserver' in window)) {
 els.forEach(function (el) {
 el.classList.add('bk-bg-in');
 });
 return;
 }
 if (!bgObserver) {
 bgObserver = new IntersectionObserver(
 function (entries) {
 entries.forEach(function (entry) {
 if (!entry.isIntersecting) return;
 entry.target.classList.add('bk-bg-in');
 bgObserver.unobserve(entry.target);
 });
 },
 { rootMargin: '600px 0px' },
 );
 }
 els.forEach(function (el) {
 bgObserver.observe(el);
 });
 }
 // Start after the page has loaded, so these never compete with the first screen's photo.
 if (document.readyState === 'complete') lazyBackgrounds();
 else window.addEventListener('load', lazyBackgrounds, { once: true });
 window.addEventListener('bk:navigate', lazyBackgrounds);
 // Tabs element (data-bk-tabs): show the panel of the tab that was clicked or arrowed to.
 function selectTab(tab) {
 var root = tab.closest('[data-bk-tabs]');
 if (!root) return;
 var tabs = root.querySelectorAll('.bk-tabs__tab');
 var panels = root.querySelectorAll('.bk-tabs__panel');
 for (var i = 0; i < tabs.length; i++) {
 var on = tabs[i] === tab;
 tabs[i].classList.toggle('is-active', on);
 tabs[i].setAttribute('aria-selected', on ? 'true' : 'false');
 tabs[i].tabIndex = on ? 0 : -1;
 if (panels[i]) panels[i].hidden = !on;
 }
 }
 document.addEventListener('click', function (e) {
 var tab = e.target && e.target.closest ? e.target.closest('[data-bk-tabs] .bk-tabs__tab') : null;
 if (tab) selectTab(tab);
 });
 document.addEventListener('keydown', function (e) {
 if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
 var tab = e.target && e.target.closest ? e.target.closest('[data-bk-tabs] .bk-tabs__tab') : null;
 if (!tab) return;
 var tabs = Array.prototype.slice.call(tab.parentNode.querySelectorAll('.bk-tabs__tab'));
 var next = tabs[(tabs.indexOf(tab) + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length];
 if (!next) return;
 e.preventDefault();
 selectTab(next);
 next.focus();
 });
 document.addEventListener('click', function (e) {
 if (e.defaultPrevented || e.button !== 0) return;
 if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
 var anchor = e.target && e.target.closest ? e.target.closest('a[href]') : null;
 var href = routable(anchor);
 if (!href) return;
 e.preventDefault();
 load(href, true);
 });
 document.addEventListener(
 'mouseover',
 function (e) {
 var anchor = e.target && e.target.closest ? e.target.closest('a[href]') : null;
 var href = routable(anchor);
 if (href) prefetch(href);
 },
 { passive: true },
 );
 document.addEventListener('focusin', function (e) {
 var anchor = e.target && e.target.closest ? e.target.closest('a[href]') : null;
 var href = routable(anchor);
 if (href) prefetch(href);
 });
 window.addEventListener('popstate', function () {
 load(location.pathname + location.search + location.hash, false);
 });
 /* ── Site search dialog (bee_search_modal(): pages + shop products) ───────────── */
 var searchOverflow = '';
 var searchTimer = null;
 var searchSeq = 0;
 function searchDialog() {
 return document.querySelector('[data-bk-search]');
 }
 function searchEmpty(dialog) {
 var pagesLeft = dialog.querySelectorAll('[data-bk-search-item]:not([hidden])').length;
 var products = dialog.querySelector('[data-bk-search-products]');
 var productsLeft = products && !products.hidden ? products.children.length : 0;
 var empty = dialog.querySelector('[data-bk-search-empty]');
 if (empty) empty.hidden = pagesLeft + productsLeft > 0;
 }
 function filterPages(dialog, q) {
 dialog.querySelectorAll('[data-bk-search-item]').forEach(function (li) {
 li.hidden = !(!q || (li.getAttribute('data-q') || '').indexOf(q) !== -1);
 });
 // Each page group (Pages / Shop / Journal) shows only while something in it matches.
 dialog.querySelectorAll('[data-bk-search-pages]').forEach(function (list) {
 var key = list.getAttribute('data-bk-search-pages');
 var left = list.querySelectorAll('[data-bk-search-item]:not([hidden])').length;
 var group = dialog.querySelector('[data-bk-search-group="' + key + '"]');
 if (group) group.hidden = left === 0;
 });
 }
 function escapeHtml(s) {
 return String(s).replace(/[&<>"]/g, function (c) {
 return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
 });
 }
 function showProducts(dialog, items) {
 var list = dialog.querySelector('[data-bk-search-products]');
 var group = dialog.querySelector('[data-bk-search-group="products"]');
 if (!list) return;
 list.innerHTML = items
 .map(function (p) {
 var img = p.image && p.image.url ? '<img src="' + escapeHtml(p.image.url) + '" alt="" loading="lazy">' : '';
 var cat = p.categories && p.categories[0] ? '<small>' + escapeHtml(p.categories[0].name) + '</small>' : '';
 var price = p.price && p.price.formatted ? '<span class="bk-search__price">' + escapeHtml(p.price.formatted) + '</span>' : '';
 return '<li data-bk-search-product><a href="' + escapeHtml(p.path) + '"><span class="bk-search__product">' + img + '<span><span>' + escapeHtml(p.title) + '</span>' + cat + '</span></span>' + price + '</a></li>';
 })
 .join('');
 list.hidden = items.length === 0;
 if (group) group.hidden = items.length === 0;
 }
 function searchProducts(dialog, q) {
 var list = dialog.querySelector('[data-bk-search-products]');
 if (!list) return;
 clearTimeout(searchTimer);
 if (!q) {
 showProducts(dialog, []);
 return;
 }
 searchTimer = setTimeout(function () {
 var seq = ++searchSeq;
 fetch('/api/shop/public/catalog?perPage=6&q=' + encodeURIComponent(q), { headers: { Accept: 'application/json' }, credentials: 'same-origin' })
 .then(function (r) {
 return r.ok ? r.json() : { items: [] };
 })
 .then(function (data) {
 if (seq !== searchSeq) return;
 showProducts(dialog, Array.isArray(data.items) ? data.items : []);
 searchEmpty(dialog);
 })
 .catch(function () {});
 }, 180);
 }
 function setSearch(open) {
 var dialog = searchDialog();
 if (!dialog || open === !dialog.hidden) return;
 dialog.hidden = !open;
 if (open) {
 searchOverflow = document.body.style.overflow;
 document.body.style.overflow = 'hidden';
 var input = dialog.querySelector('[data-bk-search-input]');
 if (input) {
 input.value = '';
 filterPages(dialog, '');
 showProducts(dialog, []);
 searchEmpty(dialog);
 input.focus();
 }
 } else {
 document.body.style.overflow = searchOverflow;
 }
 }
 function openFirstResult() {
 var dialog = searchDialog();
 var first = dialog && dialog.querySelector('[data-bk-search-product]:not([hidden]) a, [data-bk-search-item]:not([hidden]) a');
 if (first) first.click();
 }
 document.addEventListener('click', function (e) {
 var t = e.target;
 if (!(t instanceof Element)) return;
 if (t.closest('[data-bk-search-open]')) {
 e.preventDefault();
 setSearch(true);
 return;
 }
 var dialog = searchDialog();
 if (!dialog) return;
 if (t === dialog) setSearch(false);
 else if (t.closest('[data-bk-search] a')) setSearch(false);
 });
 document.addEventListener('input', function (e) {
 var t = e.target;
 if (!(t instanceof Element) || !t.matches('[data-bk-search-input]')) return;
 var dialog = searchDialog();
 if (!dialog) return;
 var q = t.value.trim().toLowerCase();
 filterPages(dialog, q);
 searchProducts(dialog, q);
 searchEmpty(dialog);
 });
 document.addEventListener('submit', function (e) {
 var form = e.target;
 if (!(form instanceof Element) || !form.matches('[data-bk-search-form]')) return;
 e.preventDefault();
 openFirstResult();
 });
 document.addEventListener('keydown', function (e) {
 var t = e.target;
 if (e.key === 'Enter' && t instanceof Element && t.matches('[data-bk-search-input]')) {
 e.preventDefault();
 openFirstResult();
 return;
 }
 if ((e.metaKey || e.ctrlKey) && String(e.key).toLowerCase() === 'k' && searchDialog()) {
 e.preventDefault();
 setSearch(true);
 }
 if (e.key === 'Escape') setSearch(false);
 });
 window.addEventListener('bk:navigate', function () {
 setSearch(false);
 });
})();
