/* Bee Forms site runtime: validation, conditional logic, steps, AJAX submit.
   Mounts on every [data-bee-form]; fills [data-bee-form-slot] placeholders from the API. */
(function () {
  if (window.__bkForms) return;
  window.__bkForms = true;

  var HEADER = 'X-Beekiri-Form';
  var EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  var PHONE = /^[+\d][\d\s().-]{4,29}$/;

  /* ── Attribution: where this visit came from ─────────────────────────
     The visit's landing page, referrer, UTM tags and ad click ids live in sessionStorage (this
     tab's visit only) and are sent with a form the visitor chooses to submit. The first visit
     is kept across days in localStorage only after analytics or marketing cookies are accepted. */
  var VISIT_KEY = 'beekiri.forms.visit';
  var FIRST_KEY = 'beekiri.forms.first';
  var TRACK_PARAMS = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'utm_id',
    'gclid', 'gbraid', 'wbraid', 'dclid', 'msclkid', 'fbclid', 'li_fat_id', 'ttclid', 'twclid', 'epik', 'sccid'];

  function consented() {
    try {
      var c = JSON.parse(localStorage.getItem('beekiri.consent') || 'null');
      return !!(c && (c.analytics || c.marketing));
    } catch (e) { return false; }
  }
  function readJson(store, key) {
    try { return JSON.parse(store.getItem(key) || 'null'); } catch (e) { return null; }
  }
  function writeJson(store, key, value) {
    try { store.setItem(key, JSON.stringify(value)); } catch (e) {}
  }
  function externalReferrer() {
    var r = document.referrer || '';
    if (!r) return '';
    try { return new URL(r).host === location.host ? '' : r.slice(0, 2000); } catch (e) { return ''; }
  }
  function currentParams() {
    var out = {};
    try {
      var q = new URLSearchParams(location.search);
      TRACK_PARAMS.forEach(function (k) { var v = q.get(k); if (v) out[k] = v.slice(0, 300); });
    } catch (e) {}
    return out;
  }
  var IDLE_MS = 30 * 60 * 1000;
  function sameParams(a, b) {
    var ka = Object.keys(a || {}), kb = Object.keys(b || {});
    if (ka.length !== kb.length) return false;
    for (var i = 0; i < ka.length; i++) if ((a || {})[ka[i]] !== (b || {})[ka[i]]) return false;
    return true;
  }
  function trackVisit(navigated) {
    var now = Date.now();
    var params = currentParams();
    var tagged = Object.keys(params).length > 0;
    var ref = navigated ? '' : externalReferrer();
    var visit = readJson(sessionStorage, VISIT_KEY);
    // A new visit starts (and becomes the source) when: there is none yet; a link with different
    // UTM tags / ad click ids was opened; the visitor arrived from another website; or after 30
    // minutes without activity (the same rule analytics tools use).
    var fresh = !visit ||
      (tagged && !sameParams(params, visit.params)) ||
      (!!ref && ref !== visit.referrer) ||
      (now - (visit.lastAt || visit.at || 0) > IDLE_MS);
    if (fresh) {
      visit = { landingUrl: location.href.slice(0, 2000), referrer: ref, params: params, at: now, pages: 0 };
    }
    visit.pages = (visit.pages || 0) + 1;
    visit.lastAt = now;
    writeJson(sessionStorage, VISIT_KEY, visit);
    if (consented() && !readJson(localStorage, FIRST_KEY)) {
      writeJson(localStorage, FIRST_KEY, { landingUrl: visit.landingUrl, referrer: visit.referrer, params: visit.params, at: visit.at });
    }
  }
  function attributionPayload() {
    var visit = readJson(sessionStorage, VISIT_KEY);
    var first = consented() ? readJson(localStorage, FIRST_KEY) : null;
    var tz = '';
    try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) {}
    return JSON.stringify({
      visit: visit,
      first: first,
      timeZone: tz,
      language: (navigator.language || '').slice(0, 40),
      screen: (window.screen ? screen.width + '×' + screen.height : ''),
      viewport: window.innerWidth + '×' + window.innerHeight,
    });
  }

  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  /* ── Values ─────────────────────────────────────────────────────────── */

  function fieldEl(form, id) { return $('[data-field="' + id + '"]', form); }

  function readValue(form, f) {
    var wrap = fieldEl(form, f.id);
    if (!wrap) return f.multiple ? [] : '';
    if (f.type === 'file') {
      var inp = $('input[type=file]', wrap);
      return inp && inp.files ? Array.prototype.map.call(inp.files, function (x) { return { name: x.name, size: x.size, type: x.type }; }) : [];
    }
    if (f.type === 'checkbox') return $$('input:checked', wrap).map(function (i) { return i.value; });
    if (f.type === 'radio') { var r = $('input:checked', wrap); return r ? r.value : ''; }
    if (f.type === 'consent') { var c = $('input', wrap); return c && c.checked ? '1' : ''; }
    if (f.type === 'select' && f.multiple) { var s = $('select', wrap); return s ? $$('option:checked', s).map(function (o) { return o.value; }) : []; }
    var el = $('input, select, textarea', wrap);
    return el ? el.value : '';
  }

  function asList(v) {
    if (v == null) return [];
    if (Array.isArray(v)) return v.map(function (x) { return typeof x === 'string' ? x : x && x.name ? x.name : String(x); });
    return [String(v)];
  }

  /* ── Conditions (same rules as the server) ───────────────────────────── */

  function ruleHolds(op, actual, expected) {
    var joined = actual.join(', ');
    var has = actual.some(function (a) { return a.trim() !== ''; });
    switch (op) {
      case 'empty': return !has;
      case 'not_empty': return has;
      case 'is': return actual.indexOf(expected) !== -1;
      case 'is_not': return actual.indexOf(expected) === -1;
      case 'contains': return joined.toLowerCase().indexOf(expected.toLowerCase()) !== -1;
      case 'not_contains': return joined.toLowerCase().indexOf(expected.toLowerCase()) === -1;
      case 'gt': return Number(actual[0]) > Number(expected);
      case 'lt': return Number(actual[0]) < Number(expected);
      default: return false;
    }
  }

  function applyConditions(state) {
    var values = {};
    state.def.fields.forEach(function (f) { if (f.type !== 'page' && f.type !== 'section') values[f.id] = readValue(state.form, f); });
    var visible = {};
    state.def.fields.forEach(function (f) { visible[f.id] = true; });
    for (var pass = 0; pass < 4; pass++) {
      var changed = false;
      state.def.fields.forEach(function (f) {
        var c = f.conditional;
        if (!c) return;
        var results = c.rules.map(function (r) { return ruleHolds(r.op, visible[r.field] ? asList(values[r.field]) : [], r.value); });
        var met = c.match === 'any' ? results.some(Boolean) : results.every(Boolean);
        var show = c.action === 'show' ? met : !met;
        if (show !== visible[f.id]) { visible[f.id] = show; changed = true; }
      });
      if (!changed) break;
    }
    state.def.fields.forEach(function (f) {
      var wrap = fieldEl(state.form, f.id);
      if (!wrap || !f.conditional) return;
      wrap.hidden = !visible[f.id];
      wrap.classList.toggle('is-conditionally-hidden', !visible[f.id]);
    });
    state.visible = visible;
  }

  /* ── Validation ─────────────────────────────────────────────────────── */

  function setError(form, id, message) {
    var wrap = fieldEl(form, id);
    if (!wrap) return;
    var err = $('[data-error]', wrap);
    wrap.classList.toggle('has-error', !!message);
    if (err) { err.textContent = message || ''; err.hidden = !message; }
    var input = $('input, select, textarea', wrap);
    if (input) { if (message) input.setAttribute('aria-invalid', 'true'); else input.removeAttribute('aria-invalid'); }
  }

  function validateField(state, f) {
    if (f.type === 'page' || f.type === 'section' || f.type === 'hidden') return '';
    if (state.visible && state.visible[f.id] === false) return '';
    var v = readValue(state.form, f);
    var label = f.label;
    if (f.type === 'file') {
      if (f.required && !v.length) return label + ' is required.';
      if (v.length > (f.maxFiles || 1)) return label + ': at most ' + (f.maxFiles || 1) + ' file(s).';
      for (var i = 0; i < v.length; i++) if (v[i].size > 10 * 1024 * 1024) return label + ': "' + v[i].name + '" is larger than 10 MB.';
      return '';
    }
    if (f.type === 'consent') return f.required && !v ? label + ' must be accepted.' : '';
    if (Array.isArray(v)) return f.required && !v.length ? label + ' is required.' : '';
    var s = String(v || '').trim();
    if (!s) return f.required ? label + ' is required.' : '';
    switch (f.type) {
      case 'email': return EMAIL.test(s) ? '' : label + ' must be a valid email address.';
      case 'phone': return PHONE.test(s) ? '' : label + ' must be a valid phone number.';
      case 'url': {
        try { var u = new URL(/^https?:\/\//i.test(s) ? s : 'https://' + s); if (u.hostname.indexOf('.') === -1) throw 0; return ''; } catch (e) { return label + ' must be a valid website address.'; }
      }
      case 'number': {
        var n = Number(s.replace(',', '.'));
        if (!isFinite(n)) return label + ' must be a number.';
        if (f.min !== undefined && f.min !== '' && n < Number(f.min)) return label + ' must be at least ' + f.min + '.';
        if (f.max !== undefined && f.max !== '' && n > Number(f.max)) return label + ' must be at most ' + f.max + '.';
        return '';
      }
      case 'date':
        if (f.min && s < f.min) return label + ' must be on or after ' + f.min + '.';
        if (f.max && s > f.max) return label + ' must be on or before ' + f.max + '.';
        return '';
      default: return '';
    }
  }

  function validatePage(state, pageIndex) {
    var page = $$('.bk-form__page', state.form)[pageIndex];
    var ids = page ? $$('[data-field]', page).map(function (w) { return w.getAttribute('data-field'); }) : [];
    var firstBad = null;
    state.def.fields.forEach(function (f) {
      if (pageIndex >= 0 && ids.indexOf(f.id) === -1) return;
      var msg = validateField(state, f);
      setError(state.form, f.id, msg);
      if (msg && !firstBad) firstBad = f.id;
    });
    if (firstBad) {
      var wrap = fieldEl(state.form, firstBad);
      var input = wrap && $('input, select, textarea', wrap);
      if (input && input.type !== 'hidden') input.focus({ preventScroll: true });
      if (wrap) wrap.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    return !firstBad;
  }

  /* ── Steps ──────────────────────────────────────────────────────────── */

  function showPage(state, index) {
    var pages = $$('.bk-form__page', state.form);
    if (index < 0 || index >= pages.length) return;
    pages.forEach(function (p, i) { p.hidden = i !== index; p.classList.toggle('is-active', i === index); });
    state.page = index;
    var bar = $('.bk-form__progress-bar', state.form);
    if (bar) bar.style.width = Math.round(((index + 1) / pages.length) * 100) + '%';
    var prog = $('[data-progress]', state.form);
    if (prog && prog.getAttribute('role') === 'progressbar') prog.setAttribute('aria-valuenow', String(index + 1));
    $$('.bk-form__step', state.form).forEach(function (s, i) {
      s.classList.toggle('is-active', i === index);
      s.classList.toggle('is-done', i < index);
    });
    if (index > 0) state.form.scrollIntoView({ behavior: 'smooth', block: 'start' });
    var first = $('input:not([type=hidden]), select, textarea', pages[index]);
    if (first && index > 0) first.focus({ preventScroll: true });
  }

  /* ── Submit ─────────────────────────────────────────────────────────── */

  function status(state, message, kind) {
    var el = $('[data-status]', state.form);
    if (!el) return;
    el.textContent = message || '';
    el.hidden = !message;
    el.className = 'bk-form__status' + (kind ? ' is-' + kind : '');
  }

  function refreshToken(state) {
    if (state.tokenFresh) return Promise.resolve();
    var tokenEl = $('[data-token]', state.form);
    return fetch('/api/forms/public/' + encodeURIComponent(state.id) + '/token', { credentials: 'same-origin', headers: { Accept: 'application/json' } })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) { if (d && d.token && tokenEl) { tokenEl.value = d.token; state.tokenFresh = true; } })
      .catch(function () {});
  }

  function fillHidden(state) {
    $$('input[data-hidden-source]', state.form).forEach(function (inp) {
      var src = inp.getAttribute('data-hidden-source');
      if (src === 'page_url') inp.value = location.href;
      else if (src === 'page_title') inp.value = document.title;
      else if (src === 'referrer') inp.value = document.referrer;
    });
  }

  function submit(state) {
    if (state.busy) return;
    applyConditions(state);
    if (!validatePage(state, -1)) return;
    state.busy = true;
    var btn = $('[data-submit]', state.form);
    var label = btn ? btn.textContent : '';
    if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }
    status(state, '', '');
    fillHidden(state);

    var fd = new FormData(state.form);
    // Hidden-by-logic fields are not sent at all.
    state.def.fields.forEach(function (f) {
      if (state.visible && state.visible[f.id] === false) fd.delete('f_' + f.id);
    });
    fd.append('_bk_page_url', location.href);
    fd.append('_bk_page_title', document.title);
    fd.append('_bk_referrer', document.referrer);
    fd.append('_bk_attr', attributionPayload());

    var headers = {};
    headers[HEADER] = '1';
    headers.Accept = 'application/json';
    fetch(state.form.getAttribute('action'), { method: 'POST', body: fd, headers: headers, credentials: 'same-origin' })
      .then(function (res) { return res.json().then(function (data) { return { res: res, data: data }; }); })
      .then(function (r) {
        var data = r.data || {};
        if (r.res.ok && data.ok) return done(state, data.confirmation);
        if (data.errors && data.errors.length) {
          data.errors.forEach(function (e) { setError(state.form, e.field, e.message); });
          var pages = $$('.bk-form__page', state.form);
          if (pages.length > 1) {
            var firstWrap = fieldEl(state.form, data.errors[0].field);
            var idx = pages.findIndex(function (p) { return firstWrap && p.contains(firstWrap); });
            if (idx >= 0) showPage(state, idx);
          }
          status(state, 'Please check the highlighted fields.', 'error');
          return;
        }
        var msg = Array.isArray(data.message) ? data.message.join(' ') : data.message;
        if (data.code === 'token' || r.res.status === 403) {
          // Stale token (long-cached page): refresh it and let them try again.
          state.tokenFresh = false;
          refreshToken(state);
        }
        status(state, msg || 'Something went wrong. Please try again.', 'error');
      })
      .catch(function () { status(state, 'Could not send the form. Check your connection and try again.', 'error'); })
      .then(function () {
        state.busy = false;
        if (btn) { btn.disabled = false; btn.textContent = label; }
      });
  }

  function done(state, confirmation) {
    // Only a path on this site or an http(s) address: never a script address.
    if (confirmation && confirmation.type === 'redirect' && /^(https?:\/\/|\/(?![\/\\]))/i.test(confirmation.url || '')) {
      location.assign(confirmation.url);
      return;
    }
    var box = $('[data-done]', state.root);
    state.form.hidden = true;
    if (box) {
      box.textContent = '';
      var icon = document.createElement('span');
      icon.className = 'bk-form__done-icon';
      icon.setAttribute('aria-hidden', 'true');
      icon.innerHTML = '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
      var p = document.createElement('p');
      p.className = 'bk-form__done-text';
      p.textContent = (confirmation && confirmation.message) || 'Thanks! Your message has been sent.';
      box.appendChild(icon);
      box.appendChild(p);
      box.hidden = false;
      box.focus({ preventScroll: true });
      box.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    try { window.dispatchEvent(new CustomEvent('bk:form:sent', { detail: { formId: state.id } })); } catch (e) {}
  }

  /* ── Mount ──────────────────────────────────────────────────────────── */

  function mount(root) {
    if (root.__bkState || root.hasAttribute('data-bee-form-preview')) return;
    var form = $('[data-bee-form-el]', root);
    var defEl = $('[data-bee-form-def]', root);
    if (!form || !defEl) return;
    var def;
    try { def = JSON.parse(defEl.textContent || '{}'); } catch (e) { return; }
    var state = { root: root, form: form, def: def, id: root.getAttribute('data-bee-form'), page: 0, busy: false, tokenFresh: false, visible: null };
    root.__bkState = state;
    applyConditions(state);

    form.addEventListener('input', function (e) {
      applyConditions(state);
      var wrap = e.target && e.target.closest && e.target.closest('[data-field]');
      if (wrap && wrap.classList.contains('has-error')) {
        var f = def.fields.filter(function (x) { return x.id === wrap.getAttribute('data-field'); })[0];
        if (f) setError(form, f.id, validateField(state, f));
      }
      if (e.target && e.target.type === 'file') {
        var hint = $('[data-file-hint]', wrap || form);
        var names = e.target.files ? Array.prototype.map.call(e.target.files, function (x) { return x.name; }) : [];
        if (hint && names.length) hint.textContent = names.join(', ');
      }
    });
    form.addEventListener('change', function () { applyConditions(state); });
    form.addEventListener('focusin', function () { refreshToken(state); }, { once: true });

    form.addEventListener('click', function (e) {
      var t = e.target && e.target.closest ? e.target.closest('[data-next],[data-back]') : null;
      if (!t) return;
      e.preventDefault();
      if (t.hasAttribute('data-back')) { showPage(state, state.page - 1); return; }
      applyConditions(state);
      if (validatePage(state, state.page)) showPage(state, state.page + 1);
    });
    form.addEventListener('keydown', function (e) {
      // Enter on a step that isn't the last moves on instead of submitting.
      if (e.key !== 'Enter' || e.target.tagName === 'TEXTAREA') return;
      var next = $('[data-next]', $$('.bk-form__page', form)[state.page] || form);
      if (next) { e.preventDefault(); next.click(); }
    });
    form.addEventListener('submit', function (e) { e.preventDefault(); submit(state); });
  }

  function fillSlots() {
    $$('[data-bee-form-slot]').forEach(function (slot) {
      if (slot.__bkLoading) return;
      slot.__bkLoading = true;
      fetch('/api/forms/public/' + encodeURIComponent(slot.getAttribute('data-bee-form-slot')) + '/html', { credentials: 'same-origin', headers: { Accept: 'application/json' } })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (d) {
          if (!d || !d.html) { slot.remove(); return; }
          var tpl = document.createElement('div');
          tpl.innerHTML = d.html;
          var el = tpl.firstElementChild;
          if (!el) return;
          slot.replaceWith(el);
          mount(el);
        })
        .catch(function () {});
    });
  }

  function init() {
    $$('[data-bee-form]').forEach(mount);
    fillSlots();
  }

  trackVisit(false);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
  window.addEventListener('bk:navigate', function () { trackVisit(true); init(); });
})();
