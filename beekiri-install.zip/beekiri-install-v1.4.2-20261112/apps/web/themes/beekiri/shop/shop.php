<?php
/**
 * Shop archive (also used for /shop/category/{slug}).
 *
 * Data: shop {title, path, …}, products[], categories[], category|null, query, sort,
 *       sorts[], pagination, base_path. See themes/beekiri/shop/README.md.
 */
$shop = get_bee_field('shop') ?: [];
$products = get_bee_field('products') ?: [];
$categories = get_bee_field('categories') ?: [];
$category = get_bee_field('category');
$query = (string) (get_bee_field('query') ?: '');
$sort = (string) (get_bee_field('sort') ?: 'menu_order');
$sorts = get_bee_field('sorts') ?: [];
$pagination = get_bee_field('pagination') ?: [];
/**
 * Sidebar filters. facets {sale, price{min,max}, attributes[{name, options[{value, count}]}]};
 * filters {sale, attr{Name: [values]}, price{min,max}}; money {symbol, position}. Prices in whole units.
 */
$facets = get_bee_field('facets') ?: [];
$filters = get_bee_field('filters') ?: [];
$money = get_bee_field('money') ?: ['symbol' => '', 'position' => 'left'];
$fmtMajor = function ($n) use ($money): string {
  $n = number_format((float) $n, 0, '.', ',');
  $sym = (string) ($money['symbol'] ?? '');
  switch ($money['position'] ?? 'left') {
    case 'right': return $n . $sym;
    case 'right_space': return $n . ' ' . $sym;
    case 'left_space': return $sym . ' ' . $n;
    default: return $sym . $n;
  }
};
$saleOn = !empty($filters['sale']);
$attrOn = is_array($filters['attr'] ?? null) ? $filters['attr'] : [];
$priceOn = is_array($filters['price'] ?? null) ? $filters['price'] : ['min' => null, 'max' => null];
$priceRange = is_array($facets['price'] ?? null) && ($facets['price']['max'] ?? 0) > ($facets['price']['min'] ?? 0) ? $facets['price'] : null;
$facetAttrs = array_values(array_filter((array) ($facets['attributes'] ?? []), fn($a) => !empty($a['name']) && count($a['options'] ?? []) > 0));
$hasSale = array_key_exists('sale', (array) $facets);
$hasFilters = $priceRange || $hasSale || $saleOn || $facetAttrs;
$attrParam = implode('|', array_map(fn($k, $v) => $k . ':' . implode(',', (array) $v), array_keys($attrOn), $attrOn));
$priceParam = ($priceOn['min'] !== null || $priceOn['max'] !== null) ? (($priceOn['min'] ?? '') . '-' . ($priceOn['max'] ?? '')) : '';
$anyFilter = $saleOn || $attrOn || $priceOn['min'] !== null || $priceOn['max'] !== null;
/** Swatch colour for colour-like attributes (Colour, Finish…): a CSS colour, a known furniture tone, or none. */
$SWATCHES = ['cream' => '#efe6d8', 'ivory' => '#f4efe4', 'beige' => '#d9c7ad', 'sand' => '#d9c7ad', 'oak' => '#c89b5f', 'walnut' => '#6b4a2b', 'ebony' => '#2b2622', 'ash' => '#d8cdb8', 'teak' => '#a86a3a', 'cognac' => '#b5672f', 'tan' => '#c9a16c', 'brown' => '#7a4b2a', 'green' => '#5b6b3a', 'olive' => '#6f7a3f', 'sage' => '#9aa88a', 'navy' => '#1f2a44', 'blue' => '#3b5aa6', 'black' => '#111111', 'white' => '#ffffff', 'grey' => '#8a8a8a', 'gray' => '#8a8a8a', 'charcoal' => '#3a3a3a', 'red' => '#b8352f', 'orange' => '#e07a3f', 'yellow' => '#e7c24a', 'pink' => '#e2a7b8', 'purple' => '#7b4b8a', 'gold' => '#c9a227', 'silver' => '#bfc3c7', 'brass' => '#b5933a', 'chrome' => '#c8ccd0', 'natural' => '#d6c3a5'];
$swatch = function (string $value) use ($SWATCHES): string {
  $v = strtolower(trim($value));
  if (preg_match('/^#([0-9a-f]{3}|[0-9a-f]{6})$/', $v)) return $v;
  if (isset($SWATCHES[$v])) return $SWATCHES[$v];
  foreach ($SWATCHES as $k => $hex) if (strpos($v, $k) !== false) return $hex;
  return '';
};
$isColorAttr = fn(string $name): bool => (bool) preg_match('/colou?r|finish|shade|tone/i', $name);
$basePath = (string) (get_bee_field('base_path') ?: ($shop['path'] ?? '/shop'));
$title = is_array($category) ? ($category['name'] ?? '') : ($shop['title'] ?? 'Shop');
$description = is_array($category) ? ($category['description'] ?? '') : ($shop['description'] ?? '');
$crumbs = [['label' => $shop['title'] ?? 'Shop', 'url' => $shop['path'] ?? '/shop']];
if (is_array($category)) $crumbs[] = ['label' => $category['name'] ?? '', 'url' => $category['path'] ?? $basePath];
$total = (int) ($pagination['total'] ?? count($products));
$opts = $shop['options'] ?? [];
$opt = fn(string $k, bool $d = true) => isset($opts[$k]) ? (bool) $opts[$k] : $d;
$columns = max(2, min(4, (int) ($opts['columns'] ?? 3)));
/**
 * Category tiles in the left column ("sidebar" option) — one level at a time: the top-level
 * categories, or, inside a category that has subcategories, those subcategories (with the parent
 * on top to go back). A subcategory page shows its siblings the same way.
 */
$hasSidebar = $opt('showSidebar') && !empty($shop['show_categories']) && $categories;
$currentSlug = is_array($category) ? ($category['slug'] ?? '') : '';
$catTiles = [];
$catParent = null;
if ($hasSidebar) {
  $byId = [];
  $byParent = [];
  foreach ($categories as $c) {
    $byId[$c['id']] = $c;
    $byParent[$c['parentId'] ?? ''][] = $c;
  }
  $current = is_array($category) ? ($byId[$category['id'] ?? ''] ?? null) : null;
  $levelId = '';
  if ($current) $levelId = !empty($byParent[$current['id']]) ? $current['id'] : (string) ($current['parentId'] ?? '');
  $catParent = $levelId !== '' ? ($byId[$levelId] ?? null) : null;
  // Products in a category and its subcategories: a branch with none (e.g. another theme's
  // demo categories while its products are parked) is left out.
  $branch = function (string $id) use (&$branch, $byId, $byParent): int {
    $n = (int) ($byId[$id]['count'] ?? 0);
    foreach ($byParent[$id] ?? [] as $k) $n += $branch((string) $k['id']);
    return $n;
  };
  foreach ($byParent[$levelId] ?? [] as $c) {
    if ($branch((string) $c['id']) <= 0) continue;
    $kids = count(array_filter($byParent[$c['id']] ?? [], fn($k) => $branch((string) $k['id']) > 0));
    $catTiles[] = $c + ['children' => $kids];
  }
}
?>
<section class="bk-shop bk-shop--archive" data-shop-view="shop" data-archive="<?php echo is_array($category) ? 'category' : 'shop'; ?>" data-archive-slug="<?php echo esc_attr($currentSlug); ?>" data-archive-path="<?php echo esc_url($basePath); ?>">
  <div class="bk-shop__wrap">
    <header class="bk-archive__head">
      <?php if ($opt('showBreadcrumbs')) echo bee_shop_breadcrumbs($crumbs); ?>
      <div class="bk-archive__title-row">
        <h1 class="bk-archive__title"><?php echo esc_html($title); ?></h1>
        <?php if ($opt('showResultCount')) : ?>
          <p class="bk-archive__count" data-archive-count aria-live="polite">
            <?php
            if ($query !== '') echo esc_html(sprintf(bee_shop_t('%d results for “%s”'), $total, $query));
            else echo esc_html(sprintf($total === 1 ? bee_shop_t('%d product') : bee_shop_t('%d products'), $total));
            ?>
          </p>
        <?php endif; ?>
        <?php if ($catTiles || $hasFilters) : ?>
          <button type="button" class="bk-archive__drawer-btn" aria-controls="bk-filter-drawer" aria-expanded="false" data-drawer-open>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="15" cy="7" r="2.5"/><circle cx="9" cy="17" r="2.5"/></svg>
            <?php echo esc_html(bee_shop_t('Filters')); ?><small data-filter-count<?php echo $anyFilter ? '' : ' hidden'; ?>><?php echo (int) (($saleOn ? 1 : 0) + count($attrOn) + (($priceOn['min'] !== null || $priceOn['max'] !== null) ? 1 : 0)); ?></small>
          </button>
        <?php endif; ?>
      </div>
      <?php if ($description) : ?><p class="bk-archive__lead"><?php echo esc_html($description); ?></p><?php endif; ?>
    </header>

    <div class="bk-archive<?php echo $catTiles ? ' has-cats' : ''; ?>">
      <?php if ($catTiles || $hasFilters) : ?>
        <div class="bk-drawer" id="bk-filter-drawer" data-drawer hidden>
          <div class="bk-drawer__scrim" data-drawer-close></div>
          <div class="bk-drawer__panel" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr(bee_shop_t('Filters')); ?>" tabindex="-1">
            <div class="bk-drawer__head">
              <strong><?php echo esc_html(bee_shop_t('Filters')); ?></strong>
              <button type="button" class="bk-drawer__close" aria-label="<?php echo esc_attr(bee_shop_t('Close')); ?>" data-drawer-close><?php echo bee_shop_icon('close'); ?></button>
            </div>
            <div class="bk-drawer__body" data-drawer-body></div>
            <div class="bk-drawer__foot">
              <a class="bk-facets__clear" href="<?php echo esc_url($basePath); ?>" data-archive-clear<?php echo $anyFilter ? '' : ' hidden'; ?>><?php echo esc_html(bee_shop_t('Clear all')); ?></a>
              <button type="button" class="bk-btn bk-drawer__apply" data-drawer-close><?php echo esc_html(bee_shop_t('Show products')); ?></button>
            </div>
          </div>
        </div>
      <?php endif; ?>
      <?php if ($catTiles) : ?>
        <aside class="bk-archive__side" aria-label="<?php echo esc_attr(bee_shop_t('Categories')); ?>" data-cat-panel>
          <div class="bk-archive__side-head">
            <h2 class="bk-archive__side-title"><?php echo esc_html(bee_shop_t('Categories')); ?></h2>
            <?php if (count($catTiles) > 8) : ?>
              <label class="bk-visually-hidden" for="bk-cat-filter"><?php echo esc_html(bee_shop_t('Filter categories')); ?></label>
              <input id="bk-cat-filter" class="bk-archive__cat-filter" type="search" placeholder="<?php echo esc_attr(bee_shop_t('Filter categories…')); ?>" autocomplete="off" data-cat-filter>
            <?php endif; ?>
          </div>
          <ul class="bk-archive__tiles" role="list">
            <li>
              <a class="bk-archive__tile is-all<?php echo $currentSlug === '' ? ' is-active' : ''; ?>" href="<?php echo esc_url($shop['path'] ?? '/shop'); ?>"<?php echo $currentSlug === '' ? ' aria-current="page"' : ''; ?> data-cat-name="<?php echo esc_attr(bee_shop_t('All products')); ?>">
                <?php
                  // "All products": a small collage of category photos (different images first), or a grid icon.
                  $collage = [];
                  foreach ($catTiles ?: $categories as $ct) {
                    $u = $ct['image']['url'] ?? '';
                    if ($u !== '' && !in_array($u, $collage, true)) $collage[] = $u;
                    if (count($collage) === 4) break;
                  }
                ?>
                <span class="bk-archive__tile-media" aria-hidden="true">
                  <?php if (count($collage) >= 2) : ?>
                    <span class="bk-archive__collage is-<?php echo count($collage); ?>">
                      <?php foreach ($collage as $u) : ?><img src="<?php echo esc_url($u); ?>" alt="" loading="lazy" decoding="async"><?php endforeach; ?>
                    </span>
                  <?php else : ?>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/></svg>
                  <?php endif; ?>
                </span>
                <span class="bk-archive__tile-text"><span class="bk-archive__tile-name"><?php echo esc_html(bee_shop_t('All products')); ?></span></span>
              </a>
            </li>
            <?php if ($catParent) : $on = ($catParent['slug'] ?? '') === $currentSlug; ?>
              <li>
                <a class="bk-archive__tile is-parent<?php echo $on ? ' is-active' : ''; ?>" href="<?php echo esc_url($catParent['path']); ?>"<?php echo $on ? ' aria-current="page"' : ''; ?> data-cat-name="<?php echo esc_attr($catParent['name']); ?>">
                  <span class="bk-archive__tile-media bk-archive__tile-back" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg>
                  </span>
                  <span class="bk-archive__tile-text">
                    <span class="bk-archive__tile-name"><?php echo esc_html($catParent['name']); ?></span>
                    <span class="bk-archive__tile-count"><?php echo esc_html(bee_shop_t('All in this category')); ?></span>
                  </span>
                </a>
              </li>
            <?php endif; ?>
            <?php foreach ($catTiles as $c) : $on = $c['slug'] === $currentSlug; ?>
              <li>
                <a class="bk-archive__tile<?php echo $on ? ' is-active' : ''; ?><?php echo $c['children'] ? ' has-children' : ''; ?>" href="<?php echo esc_url($c['path']); ?>"<?php echo $on ? ' aria-current="page"' : ''; ?> data-cat-name="<?php echo esc_attr($c['name']); ?>">
                  <span class="bk-archive__tile-media" aria-hidden="true">
                    <?php if (!empty($c['image']['url'])) : ?>
                      <img src="<?php echo esc_url($c['image']['url']); ?>" alt="" loading="lazy" decoding="async">
                    <?php else : ?>
                      <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="12" y="14" width="40" height="36" rx="3"/><path d="M12 26h40M24 50v6M40 50v6"/></svg>
                    <?php endif; ?>
                  </span>
                  <span class="bk-archive__tile-text">
                    <span class="bk-archive__tile-name"><?php echo esc_html($c['name']); ?></span>
                    <span class="bk-archive__tile-count"><?php
                      echo esc_html(sprintf((int) $c['count'] === 1 ? bee_shop_t('%d product') : bee_shop_t('%d products'), (int) $c['count']));
                      if ($c['children']) echo ' · ' . esc_html(sprintf((int) $c['children'] === 1 ? bee_shop_t('%d subcategory') : bee_shop_t('%d subcategories'), (int) $c['children']));
                    ?></span>
                  </span>
                  <?php if ($c['children']) : ?><svg class="bk-archive__tile-more" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg><?php endif; ?>
                </a>
              </li>
            <?php endforeach; ?>
          </ul>
          <p class="bk-archive__no-match" data-cat-empty hidden><?php echo esc_html(bee_shop_t('No categories match.')); ?></p>
        </aside>
      <?php endif; ?>

      <div class="bk-archive__main">
        <?php if ($opt('showSearch') || $opt('showSort') || $hasFilters) : ?>
          <div class="bk-archive__bar">
            <?php if ($opt('showSearch')) : ?>
              <form class="bk-archive__search" method="get" action="<?php echo esc_url($basePath); ?>" role="search" data-archive-search>
                <?php echo bee_shop_icon('search'); ?>
                <label class="bk-visually-hidden" for="bk-shop-q"><?php echo esc_html(bee_shop_t('Search products')); ?></label>
                <?php if ($saleOn) : ?><input type="hidden" name="sale" value="1"><?php endif; ?>
                <?php if ($attrParam !== '') : ?><input type="hidden" name="attr" value="<?php echo esc_attr($attrParam); ?>"><?php endif; ?>
                <?php if ($priceParam !== '') : ?><input type="hidden" name="price" value="<?php echo esc_attr($priceParam); ?>"><?php endif; ?>
                <input id="bk-shop-q" type="search" name="q" value="<?php echo esc_attr($query); ?>" autocomplete="off" placeholder="<?php echo esc_attr(is_array($category) ? sprintf(bee_shop_t('Search in %s…'), $category['name'] ?? '') : bee_shop_t('Search products…')); ?>">
              </form>
            <?php endif; ?>
            <?php if ($hasFilters) : ?>
              <div class="bk-facets" data-filters>
                <?php if ($priceRange) : $lo = $priceOn['min'] ?? $priceRange['min']; $hi = $priceOn['max'] ?? $priceRange['max']; $span = max(1, $priceRange['max'] - $priceRange['min']); $priceActive = $priceOn['min'] !== null || $priceOn['max'] !== null; ?>
                  <div class="bk-facet<?php echo $priceActive ? ' is-on' : ''; ?>" data-facet="price">
                    <button type="button" class="bk-facet__btn" aria-expanded="false" aria-haspopup="true">
                      <span class="bk-facet__label" data-facet-label="<?php echo esc_attr(bee_shop_t('Price')); ?>"><?php echo esc_html($priceActive ? $fmtMajor($lo) . ' – ' . $fmtMajor($hi) : bee_shop_t('Price')); ?></span>
                      <?php echo bee_shop_icon('chevron'); ?>
                    </button>
                    <div class="bk-facet__panel" hidden>
                      <div class="bk-range" data-price-range data-symbol="<?php echo esc_attr($money['symbol'] ?? ''); ?>" data-position="<?php echo esc_attr($money['position'] ?? 'left'); ?>" style="--lo: <?php echo round(($lo - $priceRange['min']) / $span * 100, 2); ?>%; --hi: <?php echo round(($hi - $priceRange['min']) / $span * 100, 2); ?>%;">
                        <span class="bk-range__track" aria-hidden="true"></span>
                        <span class="bk-range__fill" aria-hidden="true"></span>
                        <input type="range" min="<?php echo (int) $priceRange['min']; ?>" max="<?php echo (int) $priceRange['max']; ?>" step="1" value="<?php echo (int) $lo; ?>" data-price-min aria-label="<?php echo esc_attr(bee_shop_t('Minimum price')); ?>">
                        <input type="range" min="<?php echo (int) $priceRange['min']; ?>" max="<?php echo (int) $priceRange['max']; ?>" step="1" value="<?php echo (int) $hi; ?>" data-price-max aria-label="<?php echo esc_attr(bee_shop_t('Maximum price')); ?>">
                      </div>
                      <div class="bk-range__labels"><span data-price-min-label><?php echo esc_html($fmtMajor($lo)); ?></span><span data-price-max-label><?php echo esc_html($fmtMajor($hi)); ?></span></div>
                    </div>
                  </div>
                <?php endif; ?>
                <?php if ($hasSale || $saleOn) : ?>
                  <label class="bk-facet bk-facet--toggle<?php echo $saleOn ? ' is-on' : ''; ?>" data-facet="sale">
                    <input type="checkbox" value="1"<?php echo $saleOn ? ' checked' : ''; ?> data-archive-filter="sale">
                    <span class="bk-facet__btn">
                      <span class="bk-switch__track" aria-hidden="true"></span>
                      <span class="bk-facet__label"><?php echo esc_html(bee_shop_t('On sale')); ?></span>
                      <small><?php echo (int) ($facets['sale'] ?? 0); ?></small>
                    </span>
                  </label>
                <?php endif; ?>
                <?php foreach ($facetAttrs as $a) : $picked = array_map('strval', (array) ($attrOn[$a['name']] ?? [])); $color = $isColorAttr($a['name']); ?>
                  <div class="bk-facet<?php echo $picked ? ' is-on' : ''; ?>" data-facet="attr" data-attr-name="<?php echo esc_attr($a['name']); ?>">
                    <button type="button" class="bk-facet__btn" aria-expanded="false" aria-haspopup="true">
                      <span class="bk-facet__label" data-facet-label="<?php echo esc_attr($a['name']); ?>"><?php echo esc_html($picked ? (count($picked) === 1 ? $picked[0] : $a['name'] . ' · ' . count($picked)) : $a['name']); ?></span>
                      <?php echo bee_shop_icon('chevron'); ?>
                    </button>
                    <div class="bk-facet__panel" hidden>
                      <ul class="<?php echo $color ? 'bk-swatches' : 'bk-checks'; ?>" role="list">
                        <?php foreach ($a['options'] as $o) : $on = in_array((string) $o['value'], $picked, true); $hex = $color ? $swatch((string) $o['value']) : ''; ?>
                          <li>
                            <label class="<?php echo $color ? 'bk-swatch' : 'bk-check'; ?>">
                              <input type="checkbox" value="<?php echo esc_attr($o['value']); ?>"<?php echo $on ? ' checked' : ''; ?> data-archive-filter="attr" data-attr-name="<?php echo esc_attr($a['name']); ?>">
                              <?php if ($color) : ?>
                                <span class="bk-swatch__dot<?php echo $hex === '' ? ' is-plain' : ''; ?>" style="--swatch: <?php echo esc_attr($hex !== '' ? $hex : '#e8e4df'); ?>" aria-hidden="true"><?php echo $hex === '' ? esc_html(mb_substr((string) $o['value'], 0, 1)) : ''; ?></span>
                              <?php else : ?>
                                <span class="bk-check__box" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span>
                              <?php endif; ?>
                              <span class="bk-check__text"><?php echo esc_html($o['value']); ?></span>
                              <small><?php echo (int) $o['count']; ?></small>
                            </label>
                          </li>
                        <?php endforeach; ?>
                      </ul>
                    </div>
                  </div>
                <?php endforeach; ?>
                <a class="bk-facets__clear" href="<?php echo esc_url($basePath . ($query !== '' ? '?q=' . rawurlencode($query) : '')); ?>" data-archive-clear<?php echo $anyFilter ? '' : ' hidden'; ?>>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg><?php echo esc_html(bee_shop_t('Clear')); ?>
                </a>
              </div>
            <?php endif; ?>
            <?php if ($opt('showSort')) : ?>
              <form class="bk-archive__sort" method="get" action="<?php echo esc_url($basePath); ?>">
                <?php if ($query !== '') : ?><input type="hidden" name="q" value="<?php echo esc_attr($query); ?>"><?php endif; ?>
                <?php if ($saleOn) : ?><input type="hidden" name="sale" value="1"><?php endif; ?>
                <?php if ($attrParam !== '') : ?><input type="hidden" name="attr" value="<?php echo esc_attr($attrParam); ?>"><?php endif; ?>
                <?php if ($priceParam !== '') : ?><input type="hidden" name="price" value="<?php echo esc_attr($priceParam); ?>"><?php endif; ?>
                <label class="bk-visually-hidden" for="bk-shop-sort"><?php echo esc_html(bee_shop_t('Sort by')); ?></label>
                <select id="bk-shop-sort" name="sort" data-shop-sort>
                  <?php foreach ($sorts as $o) : ?>
                    <option value="<?php echo esc_attr($o['id']); ?>"<?php echo $o['id'] === $sort ? ' selected' : ''; ?>><?php echo esc_html(bee_shop_t($o['label'])); ?></option>
                  <?php endforeach; ?>
                </select>
              </form>
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <div class="bk-archive__results" data-archive-results>
        <?php if ($products) : ?>
          <ul class="bk-products bk-products--cols-<?php echo $columns; ?>">
            <?php /* Cards sit right under the page title (h2), and the first row loads at once: it is what a visitor sees first. */ ?>
            <?php foreach (array_values($products) as $i => $product) bee_shop_partial('product-card', ['product' => $product, 'heading' => 'h2', 'priority' => $i < 2]); ?>
          </ul>
          <?php bee_shop_partial('pagination', ['pagination' => $pagination]); ?>
        <?php else : ?>
          <div class="bk-archive__empty">
            <span class="bk-cart-empty__icon" aria-hidden="true"><?php echo bee_shop_icon('search'); ?></span>
            <p><?php echo esc_html($query !== '' ? bee_shop_t('No products matched your search.') : bee_shop_t('No products were found.')); ?></p>
            <?php if ($query !== '' || is_array($category)) : ?>
              <a class="bk-btn bk-btn--ghost" href="<?php echo esc_url($shop['path'] ?? '/shop'); ?>"><?php echo esc_html(bee_shop_t('Browse all products')); ?></a>
            <?php endif; ?>
          </div>
        <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</section>
