/**
 * Public HTML for BeekiriCode page trees.
 * Semantic sections only — no inline <style>, no hashed classes, no nested <main>.
 * Theme layout SCSS (layouts/{slug}/styles.css) owns the look.
 */

import { applyBindings, uploadPath, type Bindings, type LoopConfig, type LoopItem } from './dynamic';
import { iconSvg } from './icons';

export type BeekiriCodePublishNode = {
  id: string;
  type: string;
  /** Bee Forms: the form shown by a `form` element. */
  formId?: string;
  /** Bee Bookings: a `booking` element can start on one service (its id or name). */
  bookingService?: string;
  /** Dynamic content: this box repeats its first child for every item of the source. */
  loop?: LoopConfig;
  /** Dynamic content: which item fields fill this element's text / link / photo. */
  bind?: Bindings;
  /** Editor-only display name — never published. */
  label?: string;
  tag?: string;
  text?: string;
  src?: string;
  alt?: string;
  href?: string;
  newTab?: boolean;
  /** Video: play by itself (always muted — browsers block sound on autoplay), loop, mute, show controls, cover image. */
  autoplay?: boolean;
  /** Video: play again from the start (`loop` is dynamic content). */
  videoLoop?: boolean;
  muted?: boolean;
  controls?: boolean;
  poster?: string;
  /** Icon element: a name from the built-in set (icons.ts). */
  icon?: string;
  /** Accordion / Tabs: one title + text per item. */
  items?: BeekiriCodeItem[];
  /** Accordion: every item starts closed (otherwise the first one is open). */
  startClosed?: boolean;
  /** Map: the place to show, and how close (1 = world, 20 = building). */
  address?: string;
  zoom?: number;
  /** Star rating: 0 – 5, halves allowed. */
  rating?: number;
  /** Advanced panel: element id, extra classes, extra CSS declarations. */
  cssId?: string;
  cssClass?: string;
  customCss?: string;
  layoutSlug?: string;
  layoutTitle?: string;
  layoutFields?: Record<string, unknown>;
  style?: Record<string, string>;
  /** :hover styles (every device). */
  hoverStyle?: Record<string, string>;
  stylesByBreakpoint?: { tablet?: Record<string, string>; mobile?: Record<string, string> };
  hiddenOn?: ('desktop' | 'tablet' | 'mobile')[];
  children: string[];
};

/** One item of an Accordion or Tabs element. */
export type BeekiriCodeItem = { title: string; text: string };

export type BeekiriCodePublishDoc = {
  version: 1;
  rootId: string;
  nodes: Record<string, BeekiriCodePublishNode>;
};

function escapeHtml(s: string) {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escapeAttr(s: string) {
  return escapeHtml(s).replace(/'/g, '&#39;');
}

function camelToKebab(s: string) {
  return s.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`);
}

/**
 * Embed URL for a YouTube / Vimeo page link, or null when `src` is a direct
 * media file (rendered with <video>). Shared with the editor canvas.
 */
export type VideoOptions = { autoplay?: boolean; loop?: boolean; muted?: boolean; controls?: boolean };

export function videoEmbedUrl(src: string, opts: VideoOptions = {}): string | null {
  const v = src.trim();
  const yt = v.match(
    /(?:youtube\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/|live\/)|youtu\.be\/)([\w-]{11})/i,
  );
  if (yt) {
    const q = new URLSearchParams();
    if (opts.autoplay) q.set('autoplay', '1');
    if (opts.autoplay || opts.muted) q.set('mute', '1');
    // YouTube only loops a single video when it is also its own playlist.
    if (opts.loop) {
      q.set('loop', '1');
      q.set('playlist', yt[1]);
    }
    if (opts.controls === false) q.set('controls', '0');
    if (opts.autoplay) q.set('playsinline', '1');
    const qs = q.toString();
    return `https://www.youtube-nocookie.com/embed/${yt[1]}${qs ? `?${qs}` : ''}`;
  }
  const vimeo = v.match(/vimeo\.com\/(?:video\/)?(\d+)/i);
  if (vimeo) {
    const q = new URLSearchParams();
    if (opts.autoplay) q.set('autoplay', '1');
    if (opts.autoplay || opts.muted) q.set('muted', '1');
    if (opts.loop) q.set('loop', '1');
    if (opts.controls === false) q.set('controls', '0');
    const qs = q.toString();
    return `https://player.vimeo.com/video/${vimeo[1]}${qs ? `?${qs}` : ''}`;
  }
  return null;
}

/** A video node's playback options. */
export function videoOptions(node: { autoplay?: boolean; videoLoop?: boolean; muted?: boolean; controls?: boolean }): VideoOptions {
  return { autoplay: node.autoplay, loop: node.videoLoop, muted: node.muted, controls: node.controls };
}

/** <video> attributes for a direct file: controls unless switched off; autoplay is always muted. */
export function videoFileAttrs(node: VideoOptions & { poster?: string }): string {
  const parts = ['playsinline'];
  if (node.controls !== false) parts.push('controls');
  if (node.autoplay) parts.push('autoplay');
  if (node.autoplay || node.muted) parts.push('muted');
  if (node.loop) parts.push('loop');
  parts.push(`preload="${node.autoplay ? 'auto' : 'metadata'}"`);
  const poster = safeUrl(node.poster || '');
  if (poster) parts.push(`poster="${escapeAttr(poster)}"`);
  return parts.join(' ');
}

/** Only http(s) and site-relative URLs are embedded. */
function safeUrl(src: string): string {
  const v = src.trim();
  return /^(https?:\/\/|\/)/i.test(v) ? v : '';
}

const LIST_TAGS = new Set(['ul', 'ol']);

/**
 * Inline colour the editor writes as `[color=#F2842F]words[/color]` (see the admin's
 * inline-markup.ts). The text is escaped first; only a validated colour reaches the style.
 */
const INLINE_COLOR = /^(#[0-9a-fA-F]{3,8}|[a-zA-Z]+|rgba?\([\d.,\s%]+\)|hsla?\([\d.,\s%]+\))$/;

function inlineHtml(text: string): string {
  return escapeHtml(text).replace(/\[color=([^\]]{1,40})\]([\s\S]*?)\[\/color\]/g, (all, color: string, body: string) =>
    INLINE_COLOR.test(color.trim()) ? `<span style="color:${color.trim()}">${body}</span>` : all,
  );
}

function listItemsHtml(text: string): string {
  return text
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => `<li>${inlineHtml(l)}</li>`)
    .join('');
}

/** Link targets a visitor may be sent to: never javascript:, data: or other schemes. */
export function safeLinkHref(raw: string | undefined): string {
  const v = (raw || '').trim();
  if (!v) return '#';
  return /^(https?:\/\/|\/(?!\/)|#|\?|mailto:|tel:)/i.test(v) ? v : '#';
}

function buttonAttrs(node: BeekiriCodePublishNode, item?: LoopItem): string {
  const href = escapeAttr(safeLinkHref(node.href));
  // A link bound to "Add to cart": the shop script adds the product without leaving the page.
  const add = item && node.bind?.href === 'addToCart' && item.addToCartId ? ` data-add-to-cart="${escapeAttr(item.addToCartId)}"` : '';
  return (node.newTab ? ` href="${href}" target="_blank" rel="noopener"` : ` href="${href}"`) + add;
}

/** Sizes the server makes of a Media photo (/uploads/_w{width}/…). */
export const PHOTO_WIDTHS = [320, 480, 640, 750, 828, 1290, 1600];

/**
 * Responsive copies of a Media photo for an <img>. Lazy photos say `sizes="auto"`: the browser
 * picks the copy for the size the photo really shows at (a small card gets a small file).
 */
function imageSrcset(src: string, lazy = true): string {
  const path = uploadPath(src);
  if (!path) return '';
  const set = PHOTO_WIDTHS.map((w) => `/uploads/_w${w}/${escapeAttr(path)} ${w}w`).join(', ');
  return ` srcset="${set}, ${escapeAttr(src)} 2400w" sizes="${lazy ? 'auto, ' : ''}(max-width: 767px) 100vw, 50vw"`;
}

/** Inline background for one repeated card (beats the template's stylesheet rule). */
function boundBackgroundStyle(node: BeekiriCodePublishNode): string {
  const raw = node.style?.backgroundImage;
  if (!node.bind?.bg || !raw) return '';
  const url = raw.match(/^url\("([^"]+)"\)$/)?.[1];
  if (!url) return raw === 'none' ? ' style="background-image:none"' : '';
  const path = uploadPath(url);
  const value = path ? screenImageSet(path) : `url("${url}")`;
  return ` style="background-image:${escapeAttr(value)}"`;
}

/** Items of a dynamic-content box, from the API. */
export type LoopItemsLoader = (loop: LoopConfig) => Promise<LoopItem[]>;

const BG_PHOTO_KEYS = new Set(['backgroundImage', 'backgroundSize', 'backgroundPosition', 'backgroundRepeat', 'backgroundAttachment']);

/**
 * A box with nothing inside whose look is a photo (the editor's "photo in a box"): published as
 * `<figure><img>` so the picture is real content — alt text, lazy loading, responsive copies —
 * instead of an invisible CSS background. Boxes with content on top keep their background.
 */
function leafPhoto(node: BeekiriCodePublishNode): { url: string; fit: string; position: string } | null {
  if ((node.type !== 'container' && node.type !== 'section') || (node.children || []).length) return null;
  const raw = node.style?.backgroundImage?.trim() ?? '';
  const m = raw.match(/^url\((['"]?)([^'")]+)\1\)$/);
  if (!m) return null;
  const url = safeUrl(m[2]);
  if (!url || !/\.(jpe?g|png|webp|avif|gif|svg)(\?|$)/i.test(url)) return null;
  const size = (node.style?.backgroundSize ?? '').trim();
  return { url, fit: size === 'contain' ? 'contain' : 'cover', position: (node.style?.backgroundPosition ?? '').trim() || 'center' };
}

/** The style bag without its photo (the <img> carries it now). */
function withoutBgPhoto(bag: Record<string, string> | undefined): Record<string, string> | undefined {
  if (!bag) return bag;
  return Object.fromEntries(Object.entries(bag).filter(([k]) => !BG_PHOTO_KEYS.has(k)));
}

function photoImgHtml(photo: { url: string; fit: string; position: string }, alt: string, lazy: boolean): string {
  const pos = cssValue(photo.position).replace(/"/g, '');
  const style = ` style="object-fit:${photo.fit};object-position:${escapeAttr(pos)}"`;
  const load = lazy ? ' loading="lazy"' : ' fetchpriority="high"';
  return `<img src="${escapeAttr(photo.url)}"${imageSrcset(photo.url, lazy)} alt="${escapeAttr(alt)}"${load} decoding="async"${style} />`;
}

/** `attr` carries the wrapper's class / id / data-bk attributes. */
function videoHtml(node: BeekiriCodePublishNode, attr: string): string {
  const src = safeUrl(node.src || '');
  if (!src) return '';
  const title = escapeAttr(node.alt || 'Video');
  const embed = videoEmbedUrl(src, videoOptions(node));
  if (embed) {
    return `<div${attr}><iframe src="${escapeAttr(embed)}" title="${title}" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe></div>`;
  }
  return `<div${attr}><video src="${escapeAttr(src)}" title="${title}" ${videoFileAttrs({ ...videoOptions(node), poster: node.poster })}></video></div>`;
}

/** Paragraph text for an item: plain text, inline colour, line breaks kept. */
function itemTextHtml(text: string): string {
  return inlineHtml(text).replace(/\r?\n/g, '<br />');
}

function itemsOf(node: BeekiriCodePublishNode): BeekiriCodeItem[] {
  return (Array.isArray(node.items) ? node.items : [])
    .filter((it) => it && typeof it === 'object')
    .map((it) => ({ title: String(it.title ?? ''), text: String(it.text ?? '') }));
}

/** Icon: inline SVG that takes the text colour and size; a link when `href` is set. */
function iconHtml(node: BeekiriCodePublishNode, attr: string): string {
  const svg = iconSvg(node.icon);
  if (!svg) return '';
  const label = (node.alt || '').trim();
  const a11y = label ? ` role="img" aria-label="${escapeAttr(label)}"` : '';
  if (node.href) {
    const href = escapeAttr(safeLinkHref(node.href));
    const target = node.newTab ? ' target="_blank" rel="noopener"' : '';
    const name = label || (node.icon ?? '').replace(/-/g, ' ');
    return `<a${attr} href="${href}"${target} aria-label="${escapeAttr(name)}">${svg}</a>`;
  }
  return `<span${attr}${a11y}>${svg}</span>`;
}

/** Accordion: native <details>, so it opens and closes without any script. */
function accordionHtml(node: BeekiriCodePublishNode, attr: string): string {
  const items = itemsOf(node);
  if (!items.length) return '';
  const body = items
    .map(
      (it, i) =>
        `<details class="bk-accordion__item"${i === 0 && !node.startClosed ? ' open' : ''}>` +
        `<summary class="bk-accordion__title">${inlineHtml(it.title)}</summary>` +
        `<div class="bk-accordion__body">${itemTextHtml(it.text)}</div></details>`,
    )
    .join('');
  return `<div${attr}>${body}</div>`;
}

/** Tabs: the first panel shows; the site script (site-nav.js) switches panels on click. */
function tabsHtml(node: BeekiriCodePublishNode, attr: string): string {
  const items = itemsOf(node);
  if (!items.length) return '';
  const tabs = items
    .map(
      (it, i) =>
        `<button type="button" class="bk-tabs__tab${i === 0 ? ' is-active' : ''}" role="tab" aria-selected="${i === 0}"${i === 0 ? '' : ' tabindex="-1"'}>${inlineHtml(it.title)}</button>`,
    )
    .join('');
  const panels = items
    .map((it, i) => `<div class="bk-tabs__panel" role="tabpanel"${i === 0 ? '' : ' hidden'}>${itemTextHtml(it.text)}</div>`)
    .join('');
  return `<div${attr} data-bk-tabs><div class="bk-tabs__list" role="tablist">${tabs}</div>${panels}</div>`;
}

/** Google Maps embed for an address (no API key needed). Shared with the editor canvas. */
export function mapEmbedUrl(address: string | undefined, zoom?: number): string {
  const q = (address || '').trim();
  if (!q) return '';
  const z = Math.min(20, Math.max(1, Math.round(Number(zoom) || 14)));
  return `https://www.google.com/maps?q=${encodeURIComponent(q)}&z=${z}&output=embed`;
}

function mapHtml(node: BeekiriCodePublishNode, attr: string): string {
  const src = mapEmbedUrl(node.address, node.zoom);
  if (!src) return '';
  const title = escapeAttr(`Map: ${(node.address || '').trim()}`);
  return `<div${attr}><iframe src="${escapeAttr(src)}" title="${title}" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe></div>`;
}

/** A star rating between 0 and 5 (halves allowed). Shared with the editor canvas. */
export function ratingValue(raw: unknown): number {
  const n = Number(raw);
  return Number.isFinite(n) ? Math.min(5, Math.max(0, Math.round(n * 2) / 2)) : 5;
}

/** Star rating: five grey stars with the filled ones laid over them, cut at the rating. */
function ratingHtml(node: BeekiriCodePublishNode, attr: string): string {
  const value = ratingValue(node.rating);
  const stars = iconSvg('star-fill').repeat(5);
  return (
    `<div${attr} role="img" aria-label="${value} out of 5 stars">` +
    `<span class="bk-rating__stars"><span class="bk-rating__base">${stars}</span>` +
    `<span class="bk-rating__fill" style="width:${value * 20}%">${stars}</span></span></div>`
  );
}

/** Values go into a <style> block — strip anything that could close a rule or the tag. */
function cssValue(v: string): string {
  return v.trim().replace(/[{}<>;]/g, '');
}

function styleBagToCss(bag: Record<string, string> | undefined): string {
  if (!bag) return '';
  return Object.entries(bag)
    .filter(([k, v]) => /^[a-zA-Z]+$/.test(k) && typeof v === 'string' && v.trim() !== '')
    .map(([k, v]) => `${camelToKebab(k)}:${cssValue(v)}`)
    .filter((d) => !d.endsWith(':'))
    .join(';');
}

/** Properties that animate smoothly when a hover style changes them. */
const HOVER_TRANSITION_PROPS: Record<string, string> = {
  backgroundColor: 'background-color',
  background: 'background',
  color: 'color',
  borderColor: 'border-color',
  borderTopColor: 'border-color',
  borderRightColor: 'border-color',
  borderBottomColor: 'border-color',
  borderLeftColor: 'border-color',
  borderRadius: 'border-radius',
  boxShadow: 'box-shadow',
  opacity: 'opacity',
  transform: 'transform',
  filter: 'filter',
  letterSpacing: 'letter-spacing',
};

/**
 * Default `transition` for an element that has hover styles and no transition of its own,
 * so hovers fade instead of snapping. Shared with the editor canvas.
 */
export function hoverTransition(hover: Record<string, string> | undefined, base: Record<string, string> | undefined): string {
  if (!hover || base?.transition) return '';
  const props = [...new Set(Object.keys(hover).map((k) => HOVER_TRANSITION_PROPS[k]).filter(Boolean))];
  return props.length ? props.map((p) => `${p} 0.2s ease`).join(', ') : '';
}

/** Hover bag → declarations (shared with the editor). */
export function hoverDeclarations(hover: Record<string, string> | undefined): string {
  return styleBagToCss(hover);
}

/**
 * Free-form "Custom CSS" from the Advanced panel: only `prop: value` declarations
 * survive (no selectors, braces or markup), so it can never escape its rule.
 * Shared with the editor canvas so both render the same thing.
 */
export function sanitizeDeclarations(css: string | undefined): string {
  if (!css) return '';
  return css
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .split(';')
    .map((d) => {
      const i = d.indexOf(':');
      if (i < 0) return '';
      const prop = d.slice(0, i).trim();
      const value = d.slice(i + 1).trim().replace(/[{}<>;]/g, '');
      return /^(--[\w-]+|[a-zA-Z-]+)$/.test(prop) && value ? `${prop}:${value}` : '';
    })
    .filter(Boolean)
    .join(';');
}

const safeToken = (s: string) => s.replace(/[^\w-]/g, '');

/** `class="bk-heading my-class"` — author classes are whitelisted to [\w-]. */
function classAttr(base: string, node: Pick<BeekiriCodePublishNode, 'cssClass'>): string {
  const extra = (node.cssClass || '')
    .split(/\s+/)
    .map(safeToken)
    .filter(Boolean);
  return ` class="${[base, ...extra].join(' ')}"`;
}

function idAttr(node: Pick<BeekiriCodePublishNode, 'cssId'>): string {
  const id = safeToken(node.cssId || '');
  return id ? ` id="${id}"` : '';
}

/** Same breakpoints as the editor frames (Desktop / Tablet 768 / Mobile 375). */
const MQ_TABLET = '(max-width: 1024px)';
const MQ_MOBILE = '(max-width: 767px)';
const MQ_ONLY = {
  desktop: '(min-width: 1025px)',
  tablet: '(min-width: 768px) and (max-width: 1024px)',
  mobile: '(max-width: 767px)',
} as const;

type CssSink = {
  base: string[];
  tablet: string[];
  mobile: string[];
  hide: Record<keyof typeof MQ_ONLY, string[]>;
};

const newSink = (): CssSink => ({
  base: [],
  tablet: [],
  mobile: [],
  hide: { desktop: [], tablet: [], mobile: [] },
});

function sinkToCss(s: CssSink): string {
  const out = [...s.base];
  if (s.tablet.length) out.push(`@media ${MQ_TABLET}{${s.tablet.join('')}}`);
  if (s.mobile.length) out.push(`@media ${MQ_MOBILE}{${s.mobile.join('')}}`);
  for (const bp of Object.keys(MQ_ONLY) as (keyof typeof MQ_ONLY)[]) {
    if (s.hide[bp].length) {
      out.push(`@media ${MQ_ONLY[bp]}{${s.hide[bp].join(',')}{display:none!important}}`);
    }
  }
  return out.join('\n');
}

/**
 * Collect Props styles for a node into the page stylesheet.
 * Returns the `data-bk` hook to put on the element ('' when it has no styles).
 */
/**
 * Below-the-fold photos: `background-image:url(…)` becomes the custom property `--bk-bg`, which
 * the browser does not download. The element gets `data-bk-bg`; the site's runtime adds
 * `.bk-bg-in` when it comes near the viewport and `[data-bk-bg].bk-bg-in` applies the image
 * (a <noscript> rule shows them all without JavaScript). Gradients stay as they are.
 */
function deferBackground(decls: string): string {
  return decls.replace(/(^|;)background-image:(?=[^;]*url\()/g, '$1--bk-bg:');
}

/**
 * Media photos are served at the size the screen needs; the server makes /uploads/_w{width}/…
 * on first request. Phones: 828 px (1–2× screens) or 1290 px (3×). Larger screens: 1600 px at
 * 1×, the original on 2× displays.
 */
export function phoneImageSet(path: string): string {
  return `image-set(url("/uploads/_w828/${path}") 2x, url("/uploads/_w1290/${path}") 3x)`;
}

export function screenImageSet(path: string): string {
  return `image-set(url("/uploads/_w1600/${path}") 1x, url("/uploads/${path}") 2x)`;
}

function screenBackground(decls: string): string {
  return decls.replace(UPLOAD_BG_ALL, (_w, prop: string, _q: string, path: string) => `${prop}:${screenImageSet(path)}`);
}

const UPLOAD_BG = /(background-image|--bk-bg):url\((['"]?)\/uploads\/([^'")]+)\2\)/;
const UPLOAD_BG_ALL = /(background-image|--bk-bg):url\((['"]?)\/uploads\/([^'")]+)\2\)/g;

/** Mobile declaration for a node whose photo comes from Media (unless mobile sets its own). */
function phoneBackground(base: string, mobile: string): string {
  if (/(^|;)(background-image|--bk-bg):/.test(mobile)) return '';
  const m = base.match(UPLOAD_BG);
  return m ? `${m[1]}:${phoneImageSet(m[3])}` : '';
}

function collectNodeCss(
  node: BeekiriCodePublishNode,
  sink: CssSink,
  clean: (bag: Record<string, string> | undefined) => Record<string, string> | undefined = (b) => b,
  lazyBackground = false,
): string {
  const id = node.id.replace(/[^\w-]/g, '');
  if (!id) return '';
  const sel = `#main [data-bk="${id}"]`;
  const custom = sanitizeDeclarations(node.customCss);
  const defer = (d: string) => (lazyBackground ? deferBackground(d) : d);
  const rawBase = defer([styleBagToCss(clean(node.style)), custom].filter(Boolean).join(';'));
  const base = screenBackground(rawBase);
  const tablet = screenBackground(defer(styleBagToCss(clean(node.stylesByBreakpoint?.tablet))));
  const ownMobile = defer(styleBagToCss(clean(node.stylesByBreakpoint?.mobile)));
  const mobile = screenBackground([ownMobile, phoneBackground(rawBase, ownMobile)].filter(Boolean).join(';'));
  const deferred = [base, tablet, mobile].some((d) => d.includes('--bk-bg:'));
  const hidden = (node.hiddenOn ?? []).filter((bp) => bp in MQ_ONLY);
  const hover = styleBagToCss(clean(node.hoverStyle));
  const transition = hover ? hoverTransition(node.hoverStyle, node.style) : '';
  if (!base && !tablet && !mobile && !hidden.length && !hover) return '';
  // Default transition first so an explicit one in `base` still wins.
  if (transition) sink.base.push(`${sel}{transition:${cssValue(transition)}}`);
  if (base) sink.base.push(`${sel}{${base}}`);
  // :hover outranks the breakpoint rules (same selector + pseudo-class).
  if (hover) sink.base.push(`${sel}:hover{${hover}}`);
  if (tablet) sink.tablet.push(`${sel}{${tablet}}`);
  if (mobile) sink.mobile.push(`${sel}{${mobile}}`);
  for (const bp of hidden) sink.hide[bp].push(sel);
  return ` data-bk="${id}"${deferred ? ' data-bk-bg' : ''}`;
}

/** Drop leftover editor scaffold chrome so public HTML matches theme PHP. */
const LAYOUT_CHROME_KEYS = new Set([
  'display',
  'flexDirection',
  'flexWrap',
  'alignItems',
  'justifyContent',
  'gap',
  'rowGap',
  'columnGap',
  'padding',
  'paddingTop',
  'paddingRight',
  'paddingBottom',
  'paddingLeft',
  'border',
  'borderWidth',
  'borderStyle',
  'borderColor',
  'borderRadius',
  'minHeight',
]);

/** Early placeholder look (dashed border / #fafafa) — never real Props edits. */
function isLayoutScaffold(bag: Record<string, string> | undefined): boolean {
  if (!bag) return false;
  const norm = (v: string | undefined) => (v ?? '').replace(/\s/g, '').toLowerCase();
  return (
    norm(bag.border).includes('dashed') ||
    norm(bag.borderStyle) === 'dashed' ||
    norm(bag.background) === '#fafafa' ||
    norm(bag.backgroundColor) === '#fafafa'
  );
}

function cleanLayoutBag(bag: Record<string, string> | undefined): Record<string, string> | undefined {
  if (!bag || !isLayoutScaffold(bag)) return bag;
  const cleaned: Record<string, string> = {};
  for (const [k, v] of Object.entries(bag)) {
    if (LAYOUT_CHROME_KEYS.has(k)) continue;
    if ((k === 'background' || k === 'backgroundColor') && v.replace(/\s/g, '').toLowerCase() === '#fafafa') {
      continue;
    }
    cleaned[k] = v;
  }
  return cleaned;
}

/**
 * Props backgroundColor must beat theme `background:` gradients on the layout
 * <section>. Clear background-image when only a solid color was set.
 */
function expandLayoutBackground(bag: Record<string, string> | undefined): Record<string, string> | undefined {
  if (!bag) return bag;
  if (bag.backgroundColor && !bag.background && !bag.backgroundImage) {
    return { ...bag, backgroundImage: 'none' };
  }
  return bag;
}

/** Put the data-bk hook on the layout's root <section>. */
function injectSectionAttr(html: string, attr: string): string {
  if (!attr) return html;
  return html.replace(/<section\b/i, `<section${attr}`);
}

function isImageField(name: string, value: string) {
  if (/^(image|img|photo|thumbnail|logo)$/i.test(name)) return true;
  return /^(https?:\/\/|\/uploads\/|data:image\/)/i.test(value);
}

function renderLayoutFields(fields: Record<string, unknown> | undefined): string {
  if (!fields) return '';
  const parts: string[] = [];
  for (const [name, raw] of Object.entries(fields)) {
    // Only plain values here; nested field values (rows, links, ids) need the PHP layout.
    if (typeof raw !== 'string' && typeof raw !== 'number') continue;
    const v = String(raw).trim();
    if (!v) continue;
    if (isImageField(name, v)) {
      parts.push(
        `<figure class="bk-layout__field bk-layout__field--${escapeAttr(name)}"><img src="${escapeAttr(v)}" alt="" loading="lazy" decoding="async" /></figure>`,
      );
      continue;
    }
    if (name === 'title') {
      parts.push(
        `<div class="bk-layout__field bk-layout__field--title">${escapeHtml(v)}</div>`,
      );
      continue;
    }
    parts.push(
      `<div class="bk-layout__field bk-layout__field--${escapeAttr(name)}">${escapeHtml(v)}</div>`,
    );
  }
  return parts.join('');
}

function fallbackLayoutHtml(node: BeekiriCodePublishNode): string {
  const slug = (node.layoutSlug || '').trim() || 'layout';
  const fieldHtml = renderLayoutFields(node.layoutFields);
  const inner =
    fieldHtml ||
    `<p class="bk-layout__label">${escapeHtml(node.layoutTitle || slug)}</p>`;
  return [
    `<section class="${escapeAttr(slug)} section bk-layout bk-layout--${escapeAttr(slug)}" data-layout="${escapeAttr(slug)}">`,
    `<div class="wrapper"><div class="inner">${inner}</div></div>`,
    `</section>`,
  ].join('');
}

export type LayoutPhpRenderer = (
  slug: string,
  fields: Record<string, unknown>,
) => Promise<string | null>;

/**
 * Publish markup shaped like AgencyUK flexible layouts.
 * When `renderLayoutPhp` is provided, layout nodes run themes/.../{slug}.php.
 */
export function renderBeekiriCodeHtml(doc: BeekiriCodePublishDoc): string {
  // Sync path (no PHP) — used by admin publish payload; public site uses async.
  const root = doc?.nodes?.[doc.rootId];
  if (!root) return '';
  return (root.children || []).map((id) => walkSync(doc, id)).join('');
}

function walkSync(doc: BeekiriCodePublishDoc, id: string): string {
  const node = doc.nodes[id];
  if (!node) return '';

  if (node.type === 'image') {
    const src = (node.src || '').trim();
    if (!src) return '';
    return `<img class="bk-image" src="${escapeAttr(src)}" alt="${escapeAttr(node.alt || '')}" loading="lazy" decoding="async" />`;
  }

  if (node.type === 'layout') {
    return fallbackLayoutHtml(node);
  }

  if (node.type === 'heading') {
    const tag = node.tag && /^h[1-6]$/i.test(node.tag) ? node.tag.toLowerCase() : 'h2';
    const kids = (node.children || []).map((cid) => walkSync(doc, cid)).join('');
    return `<${tag} class="bk-heading">${inlineHtml(node.text || '')}${kids}</${tag}>`;
  }

  if (node.type === 'text') {
    const kids = (node.children || []).map((cid) => walkSync(doc, cid)).join('');
    return `<p class="bk-text">${inlineHtml(node.text || '')}${kids}</p>`;
  }

  if (node.type === 'button') {
    return `<a class="bk-button"${buttonAttrs(node)}>${inlineHtml(node.text || 'Button')}</a>`;
  }

  if (node.type === 'list') {
    const tag = node.tag && LIST_TAGS.has(node.tag) ? node.tag : 'ul';
    return `<${tag} class="bk-list">${listItemsHtml(node.text || '')}</${tag}>`;
  }

  if (node.type === 'video') return videoHtml(node, ' class="bk-video"');
  if (node.type === 'shop_content') return SHOP_SLOT_HTML;
  if (node.type === 'form') return formSlotHtml(node.formId, ' class="bk-form-slot"');
  if (node.type === 'booking') return bookingHtml(node.bookingService, ' class="bk-booking"');
  if (node.type === 'divider') return `<hr class="bk-divider" />`;
  if (node.type === 'spacer') return `<div class="bk-spacer" aria-hidden="true"></div>`;
  if (node.type === 'icon') return iconHtml(node, ' class="bk-icon"');
  if (node.type === 'accordion') return accordionHtml(node, ' class="bk-accordion"');
  if (node.type === 'tabs') return tabsHtml(node, ' class="bk-tabs"');
  if (node.type === 'map') return mapHtml(node, ' class="bk-map"');
  if (node.type === 'rating') return ratingHtml(node, ' class="bk-rating"');

  const photo = leafPhoto(node);
  if (photo) {
    return `<figure class="${node.type === 'container' ? 'bk-container' : 'bk-section'} bk-photo">${photoImgHtml(photo, node.alt || '', true)}</figure>`;
  }

  if (node.type === 'container') {
    const kids = (node.children || []).map((cid) => walkSync(doc, cid)).join('');
    return `<div class="bk-container">${kids}</div>`;
  }

  const kids = (node.children || []).map((cid) => walkSync(doc, cid)).join('');
  return `<section class="bk-section">${kids}</section>`;
}

const BOX_TAGS = new Set(['section', 'div', 'article', 'aside', 'header', 'footer', 'nav']);

/** Emitted for the "Shop content" element; must match apps/api/src/lib/shop/constants.ts SHOP_SLOT_HTML. */
export const SHOP_SLOT_HTML = '<div class="bk-shop-slot" data-shop-slot></div>';

/**
 * Public HTML + page stylesheet. Layouts run their PHP templates; Props styles
 * (incl. tablet/mobile overrides and hide-on-breakpoint) become CSS for <head>.
 */
/** Bee Forms: HTML of a form by id ('' when missing or inactive). */
export type FormRenderer = (formId: string) => Promise<string>;

/** Placeholder the site script can fill when no server renderer ran (admin publish payload). */
export function formSlotHtml(formId: string | undefined, attrs: string): string {
  if (!formId) return '';
  return `<div${attrs} data-bee-form-slot="${escapeAttr(formId)}"></div>`;
}

/** Bee Bookings: the element the site script (bee-bookings.js) turns into the booking widget. */
export function bookingHtml(service: string | undefined, attrs: string): string {
  const only = (service ?? '').trim();
  return `<div${attrs} data-bee-booking${only ? ` data-service="${escapeAttr(only)}"` : ''}></div>`;
}

const QUOTE = `(?:"|'|&quot;|&#34;|&#39;|&#039;)`;
const BOOKING_SHORTCODE = new RegExp(`\\[bee_booking(?:\\s+service=${QUOTE}([^"'\\]&<>]{0,120})${QUOTE})?\\s*\\]`, 'g');

/**
 * `[bee_booking]` or `[bee_booking service="Haircut"]` typed in any text, button label aside,
 * becomes the booking widget — in page elements and in theme layouts alike.
 */
export function expandBookingShortcodes(html: string): string {
  if (!html.includes('[bee_booking')) return html;
  return html.replace(BOOKING_SHORTCODE, (_all, service?: string) => bookingHtml(service, ' class="bk-booking"'));
}

export async function renderBeekiriCodePage(
  doc: BeekiriCodePublishDoc,
  renderLayoutPhp?: LayoutPhpRenderer,
  renderForm?: FormRenderer,
  loadItems?: LoopItemsLoader,
): Promise<{ html: string; css: string }> {
  if (!doc?.rootId || !doc.nodes?.[doc.rootId]) return { html: '', css: '' };
  const sink = newSink();
  // Styles are collected once per node: repeated cards share the template's rules.
  const styled = new Set<string>();
  const nodeCss = (
    node: BeekiriCodePublishNode,
    clean?: (bag: Record<string, string> | undefined) => Record<string, string> | undefined,
    lazy = false,
  ) => {
    if (styled.has(node.id)) {
      const id = node.id.replace(/[^\w-]/g, '');
      return id ? ` data-bk="${id}"` : '';
    }
    styled.add(node.id);
    return collectNodeCss(node, sink, clean, lazy);
  };

  // `lazy`: inside any top-level section after the first one (below the fold on load).
  // `item`: the current dynamic-content item; `copy`: a repeated card after the first (no ids).
  const walk = async (id: string, lazy: boolean, item?: LoopItem, copy = false): Promise<string> => {
    const raw = doc.nodes[id];
    if (!raw) return '';
    // The template's own styles go to the stylesheet; the item only changes text, links and photos.
    const node = item ? applyBindings(raw, item) : raw;
    const kidsHtml = async () => (await Promise.all((node.children || []).map((cid) => walk(cid, lazy, item, copy)))).join('');
    const ownId = () => (copy ? '' : idAttr(node));

    if (node.loop && loadItems && (node.type === 'section' || node.type === 'container')) {
      let items: LoopItem[] = [];
      try {
        items = await loadItems(node.loop);
      } catch {
        items = [];
      }
      const tag = node.tag && BOX_TAGS.has(node.tag) ? node.tag : node.type === 'container' ? 'div' : 'section';
      const attr = classAttr(node.type === 'container' ? 'bk-container' : 'bk-section', node) + ownId() + nodeCss(raw, undefined, lazy);
      const template = (node.children || [])[0];
      const cards = template ? (await Promise.all(items.map((it, i) => walk(template, lazy, it, copy || i > 0)))).join('') : '';
      return `<${tag}${attr} data-bk-loop="${escapeAttr(node.loop.source)}">${cards}</${tag}>`;
    }

    if (node.type === 'layout') {
      const slug = (node.layoutSlug || '').trim() || 'layout';
      // The PHP <section> already carries its classes; only the id is added.
      const attr = ownId() + nodeCss(raw, (b) => expandLayoutBackground(cleanLayoutBag(b)), lazy);
      // Missing / trashed theme layouts must not show a stub on the public site.
      if (!renderLayoutPhp) return '';
      try {
        const html = await renderLayoutPhp(slug, node.layoutFields || {});
        if (html && html.trim()) return injectSectionAttr(html, attr);
      } catch {
        /* omit */
      }
      return '';
    }

    if (node.type === 'image') {
      const src = (node.src || '').trim();
      if (!src) return '';
      const attr = classAttr('bk-image', node) + ownId() + nodeCss(raw, undefined, lazy);
      const srcset = item && node.bind?.src ? imageSrcset(src) : '';
      return `<img${attr} src="${escapeAttr(src)}"${srcset} alt="${escapeAttr(node.alt || '')}" loading="lazy" decoding="async" />`;
    }

    const attrs = (base: string) => classAttr(base, node) + ownId() + nodeCss(raw, undefined, lazy);

    if (node.type === 'heading') {
      const tag = node.tag && /^h[1-6]$/i.test(node.tag) ? node.tag.toLowerCase() : 'h2';
      return `<${tag}${attrs('bk-heading')}>${inlineHtml(node.text || '')}${await kidsHtml()}</${tag}>`;
    }

    if (node.type === 'text') {
      return `<p${attrs('bk-text')}>${inlineHtml(node.text || '')}${await kidsHtml()}</p>`;
    }

    if (node.type === 'button') {
      return `<a${attrs('bk-button')}${buttonAttrs(node, item)}>${inlineHtml(node.text || (item && node.bind?.text ? '' : 'Button'))}</a>`;
    }

    if (node.type === 'list') {
      const tag = node.tag && LIST_TAGS.has(node.tag) ? node.tag : 'ul';
      return `<${tag}${attrs('bk-list')}>${listItemsHtml(node.text || '')}</${tag}>`;
    }

    if (node.type === 'video') return videoHtml(node, attrs('bk-video'));
    // Shopping: the website replaces this marker with the live shop markup.
    if (node.type === 'shop_content') return SHOP_SLOT_HTML;
    // Bee Forms: the form markup comes from the API; the site script takes it from there.
    if (node.type === 'form') {
      if (!node.formId) return '';
      let inner = '';
      if (renderForm) {
        try {
          inner = await renderForm(node.formId);
        } catch {
          inner = '';
        }
      }
      return `<div${attrs('bk-form-wrap')}>${inner || formSlotHtml(node.formId, ' class="bk-form-slot"')}</div>`;
    }
    // Bee Bookings: the site script draws the booking widget in this element.
    if (node.type === 'booking') return bookingHtml(node.bookingService, attrs('bk-booking'));
    if (node.type === 'divider') return `<hr${attrs('bk-divider')} />`;
    if (node.type === 'spacer') return `<div${attrs('bk-spacer')} aria-hidden="true"></div>`;
    // An element with nothing to show yet (no icon, no items, no address) is left out.
    if (node.type === 'icon') return iconSvg(node.icon) ? iconHtml(node, attrs('bk-icon')) : '';
    if (node.type === 'accordion') return itemsOf(node).length ? accordionHtml(node, attrs('bk-accordion')) : '';
    if (node.type === 'tabs') return itemsOf(node).length ? tabsHtml(node, attrs('bk-tabs')) : '';
    if (node.type === 'map') return (node.address || '').trim() ? mapHtml(node, attrs('bk-map')) : '';
    if (node.type === 'rating') return ratingHtml(node, attrs('bk-rating'));

    const photo = leafPhoto(node);
    if (photo) {
      const base = node.type === 'container' ? 'bk-container' : 'bk-section';
      const attr = classAttr(`${base} bk-photo`, node) + ownId() + nodeCss(raw, withoutBgPhoto, lazy);
      return `<figure${attr}>${photoImgHtml(photo, node.alt || '', lazy)}</figure>`;
    }

    const tag = node.tag && BOX_TAGS.has(node.tag) ? node.tag : node.type === 'container' ? 'div' : 'section';
    const bg = item ? boundBackgroundStyle(node) : '';
    return `<${tag}${attrs(node.type === 'container' ? 'bk-container' : 'bk-section')}${bg}>${await kidsHtml()}</${tag}>`;
  };

  const root = doc.nodes[doc.rootId];
  const kids = (await Promise.all((root.children || []).map((id, i) => walk(id, i > 0)))).join('');
  // Page (root) styles land on a .bk-page wrapper only when there are any.
  const rootAttr = nodeCss({ ...root, hiddenOn: undefined });
  const html = rootAttr ? `<div class="bk-page"${rootAttr}>${kids}</div>` : kids;
  return { html: expandBookingShortcodes(html), css: sinkToCss(sink) };
}

/** HTML only (styles dropped) — prefer renderBeekiriCodePage for the public site. */
export async function renderBeekiriCodeHtmlAsync(
  doc: BeekiriCodePublishDoc,
  renderLayoutPhp?: LayoutPhpRenderer,
): Promise<string> {
  return (await renderBeekiriCodePage(doc, renderLayoutPhp)).html;
}

export function isBeekiriCodePublishDoc(raw: unknown): raw is BeekiriCodePublishDoc {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return false;
  const o = raw as Record<string, unknown>;
  return (
    o.version === 1 &&
    typeof o.rootId === 'string' &&
    !!o.nodes &&
    typeof o.nodes === 'object' &&
    !Array.isArray(o.nodes)
  );
}
