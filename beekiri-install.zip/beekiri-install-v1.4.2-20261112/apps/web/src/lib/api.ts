import { headers } from 'next/headers';
import { API_URL, SITE_URL } from './env';

/**
 * Multisite: the Beekiri server tells the website which site of the network a request is for
 * (request headers it sets itself; visitors cannot). Server-side calls to the API pass the site
 * back with the internal token, and Next keeps cached API answers apart per site because the
 * headers are part of its fetch cache key.
 */
const SITE_HEADER = 'x-beekiri-site-id';
const SITE_URL_HEADER = 'x-beekiri-site-url';
const INTERNAL_HEADER = 'x-beekiri-internal';
/** The visitor this page is rendered for, so the API's limits count them and not this server. */
const CLIENT_IP_HEADER = 'x-beekiri-client-ip';

async function requestHeader(name: string): Promise<string | null> {
  try {
    return (await headers()).get(name);
  } catch {
    // Outside a request (next build, static generation).
    return null;
  }
}

/** The site this page is rendered for (null outside a request). */
export async function requestSiteId(): Promise<string | null> {
  return requestHeader(SITE_HEADER);
}

/** This site's public address (multisite: its own sub-domain); APP_URL outside a request. */
export async function requestSiteUrl(): Promise<string> {
  return ((await requestHeader(SITE_URL_HEADER)) || SITE_URL || '').replace(/\/+$/, '');
}

/** fetch() for the Beekiri API, on behalf of this request's site. */
export async function apiFetch(url: string, init: RequestInit & { next?: NextFetchRequestConfig } = {}): Promise<Response> {
  const site = await requestSiteId();
  const token = process.env.BEEKIRI_INTERNAL_TOKEN;
  if (!site || !token || !url.startsWith(API_URL)) return fetch(url, init);
  const merged: Record<string, string> = {};
  new Headers(init.headers).forEach((value, key) => {
    merged[key] = value;
  });
  merged[SITE_HEADER] = site;
  merged[INTERNAL_HEADER] = token;
  const visitor = await requestHeader(CLIENT_IP_HEADER);
  if (visitor) merged[CLIENT_IP_HEADER] = visitor;
  return fetch(url, { ...init, headers: merged });
}
