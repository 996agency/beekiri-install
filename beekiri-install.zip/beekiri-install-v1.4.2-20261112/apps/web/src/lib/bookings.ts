import { API_URL as API } from '@/lib/env';
import { apiFetch } from './api';

/**
 * Bee Bookings when its extension is active (the root layout then loads bee-bookings.js and the
 * stylesheet, at its versioned address), else null.
 */
export async function bookingsConfig(): Promise<{ cssUrl: string } | null> {
  try {
    const res = await apiFetch(`${API}/api/bookings/public/config`, { next: { revalidate: 30 } });
    if (!res.ok) return null;
    const data = (await res.json()) as { active?: boolean; cssUrl?: string };
    return data.active === true ? { cssUrl: data.cssUrl || '/api/bookings/public/assets/booking.css' } : null;
  } catch {
    return null;
  }
}
