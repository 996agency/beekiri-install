import { headers } from 'next/headers';
import { cache } from 'react';
import { API_URL as API, SITE_URL } from './env';
import { apiFetch } from './api';

/**
 * Settings → Translation on the public site.
 *
 * The Beekiri server strips the language prefix (`/de/about` → `/about`) and passes
 * `x-beekiri-lang` + `x-beekiri-path`. Everything is translated while rendering —
 * never after — so the HTML and React's hydration payload carry the same text.
 */

export type I18nLanguage = {
  code: string;
  name: string;
  native: string;
  rtl: boolean;
  /** `''` for the default language, `/de` otherwise. */
  prefix: string;
};

type PublicTranslations = {
  defaultLanguage: string;
  /** Served without a prefix; older APIs omit it (= defaultLanguage). */
  primaryLanguage?: string;
  language: string;
  languages: I18nLanguage[];
  strings: Record<string, string>;
};

export type SwitcherOptions = {
  style?: 'dropdown' | 'list';
  /** native = Deutsch, code = DE, both = Deutsch (DE), name = German. */
  show?: 'native' | 'code' | 'both' | 'name';
};

export type I18n = {
  language: string;
  /** Language the content is written in (no translation needed). */
  defaultLanguage: string;
  /** Language on the plain address — `x-default` for search engines. */
  primaryLanguage: string;
  isDefault: boolean;
  dir: 'ltr' | 'rtl';
  languages: I18nLanguage[];
  /** Current path without the language prefix. */
  path: string;
  /** Translate one plain string (exact match). */
  t(text: string): string;
  /** Translate rendered HTML, localize internal links, expand shortcodes. */
  html(html: string): string;
  /** Internal path in the current language. */
  href(path: string): string;
  /** The current page in another language. */
  switchUrl(code: string): string;
  switcherHtml(options?: SwitcherOptions): string;
};

const FALLBACK: PublicTranslations = {
  defaultLanguage: 'en',
  language: 'en',
  languages: [],
  strings: {},
};

async function load(lang: string): Promise<PublicTranslations> {
  try {
    const qs = lang ? `?lang=${encodeURIComponent(lang)}` : '';
    const res = await apiFetch(`${API}/api/site/translations/public${qs}`, {
      next: { revalidate: 30 },
    });
    if (!res.ok) return FALLBACK;
    return (await res.json()) as PublicTranslations;
  } catch {
    return FALLBACK;
  }
}

/* ---------------------------------------------------------------- text helpers */

const ENTITIES: Record<string, string> = {
  amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', copy: '©', reg: '®',
  trade: '™', hellip: '…', mdash: '—', ndash: '–', laquo: '«', raquo: '»', lsquo: '‘',
  rsquo: '’', ldquo: '“', rdquo: '”', euro: '€', pound: '£', middot: '·', bull: '•',
};

function decode(text: string): string {
  return text.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (whole, ent: string) => {
    if (ent[0] === '#') {
      const n = ent[1] === 'x' || ent[1] === 'X' ? parseInt(ent.slice(2), 16) : parseInt(ent.slice(1), 10);
      return Number.isFinite(n) && n > 0 && n < 0x110000 ? String.fromCodePoint(n) : whole;
    }
    return ENTITIES[ent.toLowerCase()] ?? whole;
  });
}

function escapeText(text: string): string {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function escapeAttr(text: string): string {
  return escapeText(text).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/** Keys are compared with whitespace collapsed — the same way the admin scans. */
function normalize(text: string): string {
  return text.replace(/[\s ]+/g, ' ').trim();
}

function escapeRegExp(text: string): string {
  return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/* ---------------------------------------------------------------- the translator */

const PASSTHROUGH = /^\/(?:_next|api|uploads|runtime|web-api|admin)(?:\/|$)/;
const FILE_EXT = /\.[a-z0-9]{1,8}$/i;
const RAW_TAGS = new Set(['script', 'style', 'textarea', 'noscript', 'template', 'svg']);
const SKIP_TAGS = new Set(['code', 'pre', 'kbd', 'samp']);
const VOID_TAGS = new Set([
  'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'source', 'track', 'wbr',
]);
const TEXT_ATTRS = /(\s(?:title|alt|placeholder|aria-label|aria-description|data-tooltip)\s*=\s*)(["'])([^"']*)\2/gi;
const URL_ATTRS = /(\s(?:href|action)\s*=\s*)(["'])([^"']*)\2/gi;
const SHORTCODE = /\[(?:beekiri_language_switcher|language_switcher)((?:\s+[a-z]+=(?:"[^"\]]*"|'[^'\]]*'|&quot;[^\]]*?&quot;|[“”][^\]]*?[“”]|[^\s\]]+))*)\s*\/?\]/gi;

function shortcodeOptions(raw: string): SwitcherOptions {
  const opts: Record<string, string> = {};
  const re = /([a-z]+)=(?:"([^"]*)"|'([^']*)'|&quot;(.*?)&quot;|[“”](.*?)[“”]|([^\s\]]+))/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(raw))) {
    opts[m[1].toLowerCase()] = (m[2] ?? m[3] ?? m[4] ?? m[5] ?? m[6] ?? '').trim().toLowerCase();
  }
  return {
    style: opts.style === 'list' || opts.style === 'inline' ? 'list' : 'dropdown',
    show:
      opts.show === 'code' || opts.show === 'both' || opts.show === 'name' ? opts.show : 'native',
  };
}

function createI18n(data: PublicTranslations, path: string, siteBase: string = SITE_URL): I18n {
  const language = data.language || data.defaultLanguage;
  const isDefault = language === data.defaultLanguage;
  const languages = data.languages ?? [];
  const current = languages.find((l) => l.code === language);
  const prefixes = languages.filter((l) => l.prefix).map((l) => l.prefix);

  const map = new Map<string, string>();
  for (const [src, tr] of Object.entries(isDefault ? {} : data.strings ?? {})) {
    const key = normalize(src);
    if (key && tr && key !== tr) map.set(key, tr);
  }
  // Inline pass for strings that are only part of a text node, longest first.
  const inline = [...map.keys()]
    .filter((k) => k.length >= 2 && !map.get(k)!.includes(k))
    .sort((a, b) => b.length - a.length);
  const inlineRe = inline.length
    ? new RegExp(`(?<![\\p{L}\\p{N}])(?:${inline.map(escapeRegExp).join('|')})(?![\\p{L}\\p{N}])`, 'gu')
    : null;

  const t = (text: string): string => {
    if (!map.size || !text) return text;
    const key = normalize(text);
    if (!key) return text;
    const exact = map.get(key);
    if (exact) return exact;
    if (!inlineRe) return text;
    const replaced = key.replace(inlineRe, (m) => map.get(m) ?? m);
    return replaced === key ? text : replaced;
  };

  /** Translate a raw (entity-encoded) text node, keeping its surrounding whitespace. */
  const translateRaw = (raw: string): string => {
    if (!map.size || !raw.trim()) return raw;
    const decoded = decode(raw);
    const out = t(decoded);
    if (out === decoded) return raw;
    const lead = /^[\s ]*/.exec(decoded)?.[0] ?? '';
    const trail = /[\s ]*$/.exec(decoded)?.[0] ?? '';
    return escapeText(lead + out.trim() + trail);
  };

  // A non-primary language (even the original one) lives under its prefix.
  const prefixed = Boolean(current?.prefix);

  const localizePath = (target: string): string => {
    if (!current || !prefixed) return target;
    let url = target;
    if (siteBase && url.startsWith(siteBase)) url = url.slice(siteBase.length) || '/';
    if (!url.startsWith('/') || url.startsWith('//')) return target;
    const pathOnly = url.split(/[?#]/)[0] || '/';
    if (PASSTHROUGH.test(pathOnly) || FILE_EXT.test(pathOnly)) return target;
    if (prefixes.some((p) => pathOnly === p || pathOnly.startsWith(`${p}/`))) return target;
    return `${current.prefix}${url === '/' ? '' : url}` || '/';
  };

  const switchUrl = (code: string): string => {
    const lang = languages.find((l) => l.code === code);
    if (!lang) return path;
    return lang.prefix ? `${lang.prefix}${path === '/' ? '' : path}` : path;
  };

  const labelFor = (l: I18nLanguage, show: SwitcherOptions['show']): string => {
    const code = l.code.toUpperCase();
    if (show === 'code') return code;
    if (show === 'name') return l.name;
    if (show === 'both') return `${l.native} (${code})`;
    return l.native;
  };

  const switcherHtml = ({ style = 'dropdown', show = 'native' }: SwitcherOptions = {}): string => {
    if (languages.length < 2) return '';
    if (style === 'list') {
      const items = languages
        .map((l) => {
          const active = l.code === language;
          return `<a class="bk-lang__item${active ? ' is-active' : ''}" href="${escapeAttr(switchUrl(l.code))}" hreflang="${l.code}" lang="${l.code}" data-bk-reload${active ? ' aria-current="true"' : ''}>${escapeText(labelFor(l, show))}</a>`;
        })
        .join('');
      return `<nav class="bk-lang bk-lang--list" aria-label="Language" translate="no">${items}</nav>`;
    }
    const options = languages
      .map(
        (l) =>
          `<option value="${escapeAttr(switchUrl(l.code))}" lang="${l.code}"${l.code === language ? ' selected' : ''}>${escapeText(labelFor(l, show))}</option>`,
      )
      .join('');
    return `<span class="bk-lang bk-lang--dropdown" translate="no"><select class="bk-lang__select" aria-label="Language" onchange="if(this.value)location.href=this.value">${options}</select></span>`;
  };

  const rewriteTag = (tag: string, translateAttrs: boolean): string => {
    let out = tag.replace(URL_ATTRS, (whole, lead: string, q: string, value: string) => {
      const v = value.trim();
      // Menu language switcher (Settings → Permalinks → Language switcher).
      if (v === '#bk-lang') return `${lead}${q}${escapeAttr(switchUrl(language))}${q}`;
      if (v.startsWith('#bk-lang=')) {
        const code = v.slice('#bk-lang='.length);
        const here = code === language ? ' aria-current="true"' : '';
        return `${lead}${q}${escapeAttr(switchUrl(code))}${q} hreflang="${escapeAttr(code)}" lang="${escapeAttr(code)}" data-bk-reload translate="no"${here}`;
      }
      if (!translateAttrs || !prefixed) return whole;
      const next = localizePath(decode(v));
      return next === decode(v) ? whole : `${lead}${q}${escapeAttr(next)}${q}`;
    });
    if (translateAttrs && !isDefault && map.size) {
      out = out.replace(TEXT_ATTRS, (whole, lead: string, q: string, value: string) => {
        const next = t(decode(value));
        return next === decode(value) ? whole : `${lead}${q}${escapeAttr(next)}${q}`;
      });
    }
    return out;
  };

  const html = (input: string): string => {
    if (!input) return input;
    let source = input;
    if (source.includes('[')) {
      source = source.replace(SHORTCODE, (_m, attrs: string) => switcherHtml(shortcodeOptions(attrs ?? '')));
    }
    const hasSwitcherLinks = source.includes('#bk-lang');
    if (isDefault && !prefixed && !hasSwitcherLinks) return source;

    const nameNative = current?.native ?? language.toUpperCase();
    let out = '';
    let i = 0;
    let skipTag: string | null = null;
    let skipDepth = 0;
    let inSwitcherLink = false;
    const tagRe = /<!--[\s\S]*?-->|<!\[CDATA\[[\s\S]*?\]\]>|<![^>]*>|<\/?([a-zA-Z][\w:-]*)\b[^>]*>/g;
    let m: RegExpExecArray | null;
    while ((m = tagRe.exec(source))) {
      const text = source.slice(i, m.index);
      if (text) {
        if (inSwitcherLink) {
          out += text
            .replace(/\{current\}/g, escapeText(nameNative))
            .replace(/\{current_code\}/g, escapeText(language.toUpperCase()));
        }
        else out += skipTag ? text : translateRaw(text);
      }
      const tag = m[0];
      const name = m[1]?.toLowerCase();
      i = m.index + tag.length;
      if (!name) {
        out += tag;
        continue;
      }
      const closing = tag[1] === '/';
      if (!closing && RAW_TAGS.has(name)) {
        // Copy the element's contents untouched.
        const end = source.toLowerCase().indexOf(`</${name}`, i);
        const stop = end === -1 ? source.length : end;
        out += tag + source.slice(i, stop);
        i = stop;
        tagRe.lastIndex = stop;
        continue;
      }
      if (skipTag) {
        if (name === skipTag && !VOID_TAGS.has(name)) skipDepth += closing ? -1 : tag.endsWith('/>') ? 0 : 1;
        if (skipDepth <= 0) skipTag = null;
        out += rewriteTag(tag, false);
        continue;
      }
      if (closing) {
        if (name === 'a') inSwitcherLink = false;
        out += tag;
        continue;
      }
      if (name === 'a' && /href\s*=\s*["']#bk-lang["']/i.test(tag)) inSwitcherLink = true;
      const noTranslate =
        SKIP_TAGS.has(name) ||
        // Language names in the menu switcher always stay in their own language.
        /\shref\s*=\s*["']#bk-lang=/i.test(tag) ||
        /\stranslate\s*=\s*["']?no\b/i.test(tag) ||
        /\sclass\s*=\s*["'][^"']*\bnotranslate\b/i.test(tag);
      if (noTranslate && !VOID_TAGS.has(name) && !tag.endsWith('/>')) {
        skipTag = name;
        skipDepth = 1;
        out += rewriteTag(tag, false);
        continue;
      }
      out += rewriteTag(tag, !isDefault || prefixed);
    }
    const rest = source.slice(i);
    out += skipTag ? rest : translateRaw(rest);
    return out;
  };

  return {
    language,
    defaultLanguage: data.defaultLanguage,
    primaryLanguage: data.primaryLanguage || data.defaultLanguage,
    isDefault,
    dir: current?.rtl ? 'rtl' : 'ltr',
    languages,
    path,
    t,
    html,
    href: localizePath,
    switchUrl,
    switcherHtml,
  };
}

/** Per-request translator (React `cache` = once per render). */
export const getI18n = cache(async (): Promise<I18n> => {
  let lang = '';
  let path = '/';
  let siteBase = SITE_URL;
  try {
    const h = await headers();
    lang = h.get('x-beekiri-lang') ?? '';
    path = h.get('x-beekiri-path') || '/';
    // Multisite: this site's own address.
    siteBase = (h.get('x-beekiri-site-url') || SITE_URL || '').replace(/\/+$/, '');
  } catch {
    // Outside a request (build): default language.
  }
  return createI18n(await load(lang), path.startsWith('/') ? path : `/${path}`, siteBase);
});

/** Page-like records translated for metadata, JSON-LD and React-rendered titles. */
export function localizeRecord<T extends { title: string; path?: string; excerpt?: string; seo?: unknown }>(
  i18n: I18n,
  record: T,
): T {
  if (i18n.isDefault) {
    return record.path !== undefined ? { ...record, path: i18n.href(record.path) } : record;
  }
  const seo = record.seo && typeof record.seo === 'object' ? { ...(record.seo as Record<string, unknown>) } : record.seo;
  if (seo && typeof seo === 'object') {
    const s = seo as Record<string, unknown>;
    for (const key of ['metaTitle', 'metaDescription', 'ogTitle', 'ogDescription', 'focusKeyword']) {
      if (typeof s[key] === 'string' && s[key]) s[key] = i18n.t(s[key] as string);
    }
    // A hand-set canonical points at the default-language page; let each language self-canonicalize.
    if (typeof s.canonicalUrl === 'string') s.canonicalUrl = '';
    if (Array.isArray(s.faq)) {
      s.faq = (s.faq as { question: string; answer: string }[]).map((f) => ({
        question: i18n.t(f.question),
        answer: i18n.t(f.answer),
      }));
    }
  }
  return {
    ...record,
    title: i18n.t(record.title),
    ...(record.excerpt !== undefined ? { excerpt: i18n.t(record.excerpt) } : {}),
    ...(record.path !== undefined ? { path: i18n.href(record.path) } : {}),
    seo,
  };
}
