import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { bookingsConfig } from '../../../lib/bookings';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = { title: 'Your booking', robots: { index: false, follow: false } };

type Props = { params: Promise<{ token: string }> };

/**
 * /booking/<token> — the customer's own booking, from the link in their email: what is booked
 * and a Cancel button. bee-bookings.js draws it (the token is the only key; never cached).
 */
export default async function BookingPage({ params }: Props) {
  const { token } = await params;
  if (!/^[0-9a-f]{48}$/.test(token) || !(await bookingsConfig())) notFound();
  return (
    // Raw HTML, so React leaves what the script draws in it alone (the token is hex, checked above).
    <main id="main" className="bk-main bk-booking-page" suppressHydrationWarning dangerouslySetInnerHTML={{ __html: `<div data-bee-booking-manage="${token}"></div>` }} />
  );
}
