import type { Metadata, Viewport } from 'next';
import './globals.css';
import { AdminDock } from '../components/AdminDock';
import { BeeCookies } from '../components/BeeCookies';
import { SiteCodeBody, SiteCodeFooter, SiteCodeHead } from '../components/SiteCode';
import { SiteChrome, type ChromeSite } from '../components/SiteChrome';
import { getI18n } from '../lib/i18n';
import { bookingsConfig } from '../lib/bookings';
import { formsConfig } from '../lib/forms';
import { shopConfig } from '../lib/shop';
import type { SiteMenuItem } from '../lib/site-menu';

import { API_URL as API } from '@/lib/env';
import { apiFetch, requestSiteUrl } from '@/lib/api';
// Content comes from the Beekiri API, which is not running during `next build`:
// render on request (API responses are still cached by their `revalidate`).
export const dynamic = 'force-dynamic';

const DEFAULT_FAVICON = '/icon-512.png';
/** Bump when the bundled icons change, so browsers never reuse an old (or cached 404) icon. */
const ICON_V = '?v=3';

const FALLBACK_META = {
  favicon: DEFAULT_FAVICON,
  title: 'Beekiri',
  tagline: '',
  theme: 'beekiri-child',
  site: null,
  customHeadHtml: '',
  customBodyHtml: '',
  customFooterHtml: '',
} satisfies PublicMeta;

type PublicMeta = {
  favicon: string;
  title: string;
  tagline: string;
  theme: string;
  site: ChromeSite | null;
  customHeadHtml: string;
  customBodyHtml: string;
  customFooterHtml: string;
};

async function getPublicMeta(): Promise<PublicMeta> {
  try {
    const res = await apiFetch(`${API}/api/site/public`, {
      next: { revalidate: 30 },
    });
    if (!res.ok) {
      return FALLBACK_META;
    }
    const data = (await res.json()) as ChromeSite & {
      installed?: boolean;
      faviconUrl?: string;
      theme?: string;
      menu?: SiteMenuItem[];
      customHeadHtml?: string;
      customBodyHtml?: string;
      customFooterHtml?: string;
    };
    const favicon = (data.faviconUrl ?? '').trim() || DEFAULT_FAVICON;
    const title = (data.title ?? '').trim() || 'Beekiri';
    const tagline = (data.tagline ?? '').trim();
    const theme = (data.theme ?? '').trim() || 'beekiri-child';
    const site: ChromeSite | null = data.installed
      ? { title, tagline, blogPublic: data.blogPublic, menu: data.menu }
      : null;
    return {
      favicon,
      title,
      tagline,
      theme,
      site,
      customHeadHtml: data.customHeadHtml ?? '',
      customBodyHtml: data.customBodyHtml ?? '',
      customFooterHtml: data.customFooterHtml ?? '',
    };
  } catch {
    return FALLBACK_META;
  }
}

/**
 * The script behind Beekiri.use(): layout scripts ask it for GSAP or Three.js, which then load
 * from this site, only on the pages that use them. Printed inline, so it costs no request.
 */
async function getLibsLoader(): Promise<string> {
  try {
    const res = await apiFetch(`${API}/api/libs/loader.js`, { next: { revalidate: 300 } });
    return res.ok ? await res.text() : '';
  } catch {
    return '';
  }
}

export async function generateMetadata(): Promise<Metadata> {
  const meta = await getPublicMeta();
  const i18n = await getI18n();
  const { favicon } = meta;
  const title = i18n.t(meta.title);
  const tagline = i18n.t(meta.tagline);
  const description =
    tagline ||
    'Beekiri helps you publish pages, manage media, and grow your website with a fast, secure content management system.';

  // Multisite: canonical addresses use this site's own address.
  const siteBase = await requestSiteUrl();
  return {
    metadataBase: siteBase ? new URL(siteBase) : undefined,
    title: {
      default: title,
      template: `%s · ${title}`,
    },
    description,
    applicationName: title,
    authors: [{ name: '996agency' }],
    generator: 'Beekiri CMS',
    referrer: 'origin-when-cross-origin',
    keywords: ['Beekiri', 'CMS', 'content management', 'website', title],
    robots: {
      index: true,
      follow: true,
    },
    icons: {
      // One source of truth: site favicon (Settings → General); the default ships sized brand icons.
      icon:
        favicon === DEFAULT_FAVICON
          ? [
              { url: `/favicon.ico${ICON_V}`, sizes: 'any' },
              { url: `/favicon-32.png${ICON_V}`, type: 'image/png', sizes: '32x32' },
              { url: `/icon-192.png${ICON_V}`, type: 'image/png', sizes: '192x192' },
            ]
          : [{ url: favicon }],
      shortcut: [{ url: favicon === DEFAULT_FAVICON ? `/favicon.ico${ICON_V}` : favicon }],
      apple: [{ url: favicon === DEFAULT_FAVICON ? `/apple-touch-icon.png${ICON_V}` : favicon }],
    },
    openGraph: {
      type: 'website',
      locale: i18n.language.replace('-', '_'),
      siteName: title,
      title,
      description,
      url: siteBase || undefined,
    },
    twitter: {
      card: 'summary',
      title,
      description,
    },
    manifest: `/site.webmanifest${ICON_V}`,
    other: {
      // Helps some crawlers / assistive tech when dynamic content lacks labels
      'format-detection': 'telephone=no',
    },
  };
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#ffffff',
  colorScheme: 'light',
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const [{ theme, site, customHeadHtml, customBodyHtml, customFooterHtml }, i18n, shop, forms, bookings, libsLoader] = await Promise.all([
    getPublicMeta(),
    getI18n(),
    shopConfig(),
    formsConfig(),
    bookingsConfig(),
    getLibsLoader(),
  ]);
  const siteBase = await requestSiteUrl();
  const alternates =
    i18n.languages.length > 1
      ? [
          ...i18n.languages.map((l) => ({ hrefLang: l.code, href: i18n.switchUrl(l.code) })),
          { hrefLang: 'x-default', href: i18n.switchUrl(i18n.primaryLanguage) },
        ]
      : [];
  return (
    // A script may style <html> before React wakes up (GSAP's ScrollTrigger sets scroll-behavior).
    <html lang={i18n.language} dir={i18n.dir} data-theme={theme} suppressHydrationWarning>
      <head>
        {alternates.map((a) => (
          <link
            key={a.hrefLang}
            rel="alternate"
            hrefLang={a.hrefLang}
            href={siteBase ? `${siteBase}${a.href === '/' ? '' : a.href}` : a.href}
          />
        ))}
        {/* Shopping extension: storefront styles on every page (header cart count, add-to-cart). */}
        {shop ? <link rel="stylesheet" href={shop.cssUrl} precedence="beekiri-shop" /> : null}
        {forms ? <link rel="stylesheet" href={forms.cssUrl} precedence="beekiri-forms" /> : null}
        {bookings ? <link rel="stylesheet" href={bookings.cssUrl} precedence="beekiri-bookings" /> : null}
        {/* Before any layout script runs: Beekiri.use('gsap'), Beekiri.use('three'). */}
        {libsLoader ? <script dangerouslySetInnerHTML={{ __html: libsLoader }} /> : null}
        <SiteCodeHead html={customHeadHtml} />
      </head>
      <body>
        <SiteCodeBody html={i18n.html(customBodyHtml)} />
        <a className="bk-skip" href="#main">
          {i18n.t('Skip to main content')}
        </a>
        <div className="bk-shell">
          <SiteChrome kind="header" site={site} />
          {children}
          <SiteChrome kind="footer" site={site} />
        </div>
        <BeeCookies />
        <AdminDock />
        {/* Native script (no next/script client runtime) — soft nav without React router. */}
        <script src="/runtime/site-nav.js" defer />
        {shop ? <script src={shop.jsUrl} defer /> : null}
        {forms ? <script src="/runtime/bee-forms.js" defer /> : null}
        {bookings ? <script src="/runtime/bee-bookings.js" defer /> : null}
        <SiteCodeFooter html={i18n.html(customFooterHtml)} />
      </body>
    </html>
  );
}
