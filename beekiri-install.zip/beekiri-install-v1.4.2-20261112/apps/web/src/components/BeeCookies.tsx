'use client';

import { useCallback, useEffect, useId, useState } from 'react';
import { createPortal } from 'react-dom';
import './bee-cookies.css';

/**
 * The page as analytics may see it. A customer's booking link and an order receipt carry a secret
 * in the address, so only the kind of page is reported (never to Google either).
 */
function publicPath(): string {
  const path = location.pathname
    .replace(/^\/booking\/[^/]+/, '/booking/:token')
    .replace(/^\/checkout\/order-received\/[^/]+/, '/checkout/order-received/:token');
  return path === location.pathname ? path + location.search : path;
}

type Category = { enabled: boolean; label: string; description: string };

type Config = {
  enabled: boolean;
  position: 'bottom' | 'bottom-left' | 'bottom-right';
  bannerTitle: string;
  bannerMessage: string;
  acceptLabel: string;
  rejectLabel: string;
  preferencesLabel: string;
  saveLabel: string;
  privacyPolicyUrl: string;
  trackPageViews: boolean;
  googleMeasurementId?: string;
  categories: {
    essential: Category;
    functional: Category;
    analytics: Category;
    marketing: Category;
  };
};

type Choice = { functional: boolean; analytics: boolean; marketing: boolean };

const VISITOR_KEY = 'beekiri.visitor';
const CONSENT_KEY = 'beekiri.consent';
const COOKIE = 'beekiri_consent';

function visitorId(): string {
  try {
    const existing = localStorage.getItem(VISITOR_KEY);
    if (existing && /^[A-Za-z0-9_-]{8,64}$/.test(existing)) return existing;
    const id =
      typeof crypto !== 'undefined' && crypto.randomUUID
        ? crypto.randomUUID()
        : `v${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
    localStorage.setItem(VISITOR_KEY, id);
    return id;
  } catch {
    return `v${Date.now().toString(36)}`;
  }
}

function readChoice(): Choice | null {
  try {
    const raw = localStorage.getItem(CONSENT_KEY);
    if (!raw) return null;
    const o = JSON.parse(raw) as Record<string, unknown>;
    if (typeof o.functional !== 'boolean') return null;
    return {
      functional: Boolean(o.functional),
      analytics: Boolean(o.analytics),
      marketing: Boolean(o.marketing),
    };
  } catch {
    return null;
  }
}

function writeChoice(choice: Choice) {
  try {
    localStorage.setItem(CONSENT_KEY, JSON.stringify({ ...choice, at: Date.now() }));
  } catch {
    /* private mode */
  }
  const maxAge = 60 * 60 * 24 * 180;
  const secure = location.protocol === 'https:' ? '; Secure' : '';
  document.cookie = `${COOKIE}=1; Path=/; Max-Age=${maxAge}; SameSite=Lax${secure}`;
}

function optionalKeys(config: Config): Array<keyof Choice> {
  return (['functional', 'analytics', 'marketing'] as const).filter(
    (key) => config.categories[key].enabled,
  );
}

function allOn(config: Config): Choice {
  return {
    functional: config.categories.functional.enabled,
    analytics: config.categories.analytics.enabled,
    marketing: config.categories.marketing.enabled,
  };
}

function allOff(): Choice {
  return { functional: false, analytics: false, marketing: false };
}

async function post(path: string, body: unknown) {
  try {
    await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      credentials: 'same-origin',
    });
  } catch {
    /* never block the page */
  }
}

function visitorGeo() {
  try {
    return {
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || '',
      locale: navigator.language || '',
    };
  } catch {
    return { timeZone: '', locale: '' };
  }
}

function applyGoogleTag(measurementId: string | undefined, analyticsOn: boolean) {
  const id = (measurementId ?? '').trim();
  if (!id || !/^G-[A-Z0-9]+$/i.test(id)) return;
  const w = window as Window & {
    dataLayer?: unknown[];
    gtag?: (...args: unknown[]) => void;
  };
  if (!w.gtag) {
    w.dataLayer = w.dataLayer ?? [];
    w.gtag = (...args: unknown[]) => {
      w.dataLayer!.push(args);
    };
    if (!document.getElementById('bk-ga4')) {
      const s = document.createElement('script');
      s.id = 'bk-ga4';
      s.async = true;
      s.src = `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(id)}`;
      document.head.appendChild(s);
    }
    w.gtag('js', new Date());
    w.gtag('consent', 'default', { analytics_storage: 'denied', ad_storage: 'denied' });
    w.gtag('config', id, { anonymize_ip: true, page_location: location.origin + publicPath() });
  }
  w.gtag('consent', 'update', {
    analytics_storage: analyticsOn ? 'granted' : 'denied',
  });
}

function visitMeta() {
  try {
    return {
      title: (document.title || '').slice(0, 200),
      screen:
        typeof screen !== 'undefined' && screen.width && screen.height
          ? `${screen.width}x${screen.height}`
          : '',
      language: navigator.language || '',
    };
  } catch {
    return { title: '', screen: '', language: '' };
  }
}

function sendVisit(id: string, analyticsOn: boolean, track: boolean) {
  if (!analyticsOn || !track) return;
  void post('/api/bee-cookies/visit', {
    visitorId: id,
    path: publicPath(),
    referrer: document.referrer || '',
    ...visitorGeo(),
    ...visitMeta(),
  });
}

function sendHeartbeat(id: string, analyticsOn: boolean, track: boolean) {
  if (!analyticsOn || !track) return;
  if (typeof document !== 'undefined' && document.visibilityState === 'hidden') return;
  void post('/api/bee-cookies/heartbeat', {
    visitorId: id,
    path: publicPath(),
  });
}

type ClickPoint = { x: number; y: number };

const clickQueue: ClickPoint[] = [];
let clickFlushTimer: number | null = null;

function flushClicks(id: string) {
  if (!clickQueue.length) return;
  if (location.pathname.startsWith('/admin')) {
    clickQueue.length = 0;
    return;
  }
  const clicks = clickQueue.splice(0, 40);
  void post('/api/bee-cookies/clicks', {
    visitorId: id,
    path: publicPath(),
    viewportW: window.innerWidth || 0,
    clicks,
  });
}

function queueClick(id: string, point: ClickPoint) {
  clickQueue.push(point);
  if (clickQueue.length >= 20) {
    if (clickFlushTimer !== null) {
      window.clearTimeout(clickFlushTimer);
      clickFlushTimer = null;
    }
    flushClicks(id);
    return;
  }
  if (clickFlushTimer !== null) return;
  clickFlushTimer = window.setTimeout(() => {
    clickFlushTimer = null;
    flushClicks(id);
  }, 2_000);
}

function clickPct(e: MouseEvent): ClickPoint | null {
  const doc = document.documentElement;
  const body = document.body;
  const w = Math.max(doc.scrollWidth, body?.scrollWidth ?? 0, doc.clientWidth, window.innerWidth || 0, 1);
  const h = Math.max(doc.scrollHeight, body?.scrollHeight ?? 0, doc.clientHeight, window.innerHeight || 0, 1);
  const x = (e.pageX / w) * 100;
  const y = (e.pageY / h) * 100;
  if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
  return {
    x: Math.round(Math.min(100, Math.max(0, x)) * 10) / 10,
    y: Math.round(Math.min(100, Math.max(0, y)) * 10) / 10,
  };
}

function shouldIgnoreClick(target: EventTarget | null): boolean {
  if (!(target instanceof Element)) return false;
  return Boolean(
    target.closest('[data-beekiri="cookies"], .bk-bee-cookies, [data-beekiri-ignore]'),
  );
}

export function BeeCookies() {
  const titleId = useId();
  const [mounted, setMounted] = useState(false);
  const [config, setConfig] = useState<Config | null>(null);
  const [choice, setChoice] = useState<Choice | null>(null);
  const [open, setOpen] = useState<'banner' | 'prefs' | null>(null);
  const [draft, setDraft] = useState<Choice>(allOff());

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    let cancelled = false;
    fetch('/api/bee-cookies/config', { credentials: 'same-origin' })
      .then((r) => (r.ok ? r.json() : null))
      .then((data: Config | null) => {
        if (cancelled || !data?.enabled) {
          setConfig(data?.enabled ? data : null);
          return;
        }
        setConfig(data);
        const stored = readChoice();
        if (stored) {
          setChoice(stored);
          sendVisit(visitorId(), stored.analytics, data.trackPageViews);
          applyGoogleTag(data.googleMeasurementId, stored.analytics);
        } else {
          setOpen('banner');
          setDraft(allOff());
        }
      })
      .catch(() => {
        if (!cancelled) setConfig(null);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const persist = useCallback(
    (next: Choice) => {
      if (!config) return;
      writeChoice(next);
      setChoice(next);
      setOpen(null);
      void post('/api/bee-cookies/consent', {
        visitorId: visitorId(),
        ...next,
        path: publicPath(),
        ...visitorGeo(),
      });
      sendVisit(visitorId(), next.analytics, config.trackPageViews);
      sendHeartbeat(visitorId(), next.analytics, config.trackPageViews);
      applyGoogleTag(config.googleMeasurementId, next.analytics);
    },
    [config],
  );

  useEffect(() => {
    const openPrefs = () => {
      if (!config) return;
      setDraft(choice ?? allOff());
      setOpen('prefs');
    };
    (window as Window & { beekiriOpenCookies?: () => void }).beekiriOpenCookies = openPrefs;
    window.addEventListener('beekiri:cookies', openPrefs);
    return () => {
      delete (window as Window & { beekiriOpenCookies?: () => void }).beekiriOpenCookies;
      window.removeEventListener('beekiri:cookies', openPrefs);
    };
  }, [config, choice]);

  useEffect(() => {
    if (!config || !choice?.analytics || !config.trackPageViews) return;
    const onNav = () => {
      sendVisit(visitorId(), true, true);
      sendHeartbeat(visitorId(), true, true);
    };
    window.addEventListener('bk:navigate', onNav);
    window.addEventListener('popstate', onNav);
    return () => {
      window.removeEventListener('bk:navigate', onNav);
      window.removeEventListener('popstate', onNav);
    };
  }, [config, choice]);

  useEffect(() => {
    if (!config || !choice?.analytics || !config.trackPageViews) return;
    const beat = () => sendHeartbeat(visitorId(), true, true);
    beat();
    const id = window.setInterval(beat, 30_000);
    const onVis = () => {
      if (document.visibilityState === 'visible') beat();
    };
    document.addEventListener('visibilitychange', onVis);
    return () => {
      window.clearInterval(id);
      document.removeEventListener('visibilitychange', onVis);
    };
  }, [config, choice]);

  useEffect(() => {
    if (!config || !choice?.analytics || !config.trackPageViews) return;
    const id = visitorId();
    const onClick = (e: MouseEvent) => {
      if (e.button !== 0) return;
      if (shouldIgnoreClick(e.target)) return;
      const point = clickPct(e);
      if (!point) return;
      queueClick(id, point);
    };
    const onHide = () => flushClicks(id);
    document.addEventListener('click', onClick, true);
    window.addEventListener('pagehide', onHide);
    document.addEventListener('visibilitychange', onHide);
    return () => {
      document.removeEventListener('click', onClick, true);
      window.removeEventListener('pagehide', onHide);
      document.removeEventListener('visibilitychange', onHide);
      flushClicks(id);
      if (clickFlushTimer !== null) {
        window.clearTimeout(clickFlushTimer);
        clickFlushTimer = null;
      }
    };
  }, [config, choice]);

  if (!mounted || !config?.enabled) return null;

  const optionals = optionalKeys(config);
  const decided = choice !== null;

  return createPortal(
    <div className="bk-bee-cookies" data-beekiri="cookies">
      {open === 'banner' ? (
        <div
          className={`bk-bee-cookies__banner is-${config.position}`}
          role="dialog"
          aria-modal="false"
          aria-labelledby={titleId}
        >
          <div className="bk-bee-cookies__copy">
            <p id={titleId} className="bk-bee-cookies__title">
              {config.bannerTitle}
            </p>
            <p className="bk-bee-cookies__msg">{config.bannerMessage}</p>
            {config.privacyPolicyUrl ? (
              <a className="bk-bee-cookies__link" href={config.privacyPolicyUrl}>
                Privacy policy
              </a>
            ) : null}
          </div>
          <div className="bk-bee-cookies__actions">
            <button type="button" className="bk-bee-cookies__btn is-ghost" onClick={() => persist(allOff())}>
              {config.rejectLabel}
            </button>
            {optionals.length ? (
              <button
                type="button"
                className="bk-bee-cookies__btn is-ghost"
                onClick={() => {
                  setDraft(choice ?? allOff());
                  setOpen('prefs');
                }}
              >
                {config.preferencesLabel}
              </button>
            ) : null}
            <button
              type="button"
              className="bk-bee-cookies__btn is-primary"
              onClick={() => persist(allOn(config))}
            >
              {config.acceptLabel}
            </button>
          </div>
        </div>
      ) : null}

      {open === 'prefs' ? (
        <div className="bk-bee-cookies__scrim" role="presentation" onClick={() => setOpen(decided ? null : 'banner')}>
          <div
            className="bk-bee-cookies__panel"
            role="dialog"
            aria-modal="true"
            aria-labelledby={`${titleId}-prefs`}
            onClick={(e) => e.stopPropagation()}
          >
            <p id={`${titleId}-prefs`} className="bk-bee-cookies__title">
              {config.preferencesLabel}
            </p>
            <ul className="bk-bee-cookies__cats">
              <li>
                <label>
                  <input type="checkbox" checked disabled />
                  <span>
                    <strong>{config.categories.essential.label}</strong>
                    {config.categories.essential.description}
                  </span>
                </label>
              </li>
              {optionals.map((key) => (
                <li key={key}>
                  <label>
                    <input
                      type="checkbox"
                      checked={draft[key]}
                      onChange={(e) => setDraft({ ...draft, [key]: e.target.checked })}
                    />
                    <span>
                      <strong>{config.categories[key].label}</strong>
                      {config.categories[key].description}
                    </span>
                  </label>
                </li>
              ))}
            </ul>
            <div className="bk-bee-cookies__actions">
              <button type="button" className="bk-bee-cookies__btn is-ghost" onClick={() => persist(allOff())}>
                {config.rejectLabel}
              </button>
              <button type="button" className="bk-bee-cookies__btn is-primary" onClick={() => persist(draft)}>
                {config.saveLabel}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {decided && open === null ? (
        <button
          type="button"
          className="bk-bee-cookies__reopen"
          aria-label="Cookie settings"
          onClick={() => {
            setDraft(choice);
            setOpen('prefs');
          }}
        >
          <span className="bk-bee-cookies__hint" aria-hidden="true">
            <span className="bk-bee-cookies__dot" />
            <span className="bk-bee-cookies__tip">Cookie settings</span>
          </span>
        </button>
      ) : null}
    </div>,
    document.body,
  );
}
