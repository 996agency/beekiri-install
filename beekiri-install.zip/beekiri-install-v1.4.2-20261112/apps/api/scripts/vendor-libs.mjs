// Refreshes the animation libraries Beekiri ships to sites (apps/api/vendor/libs): GSAP with its
// plugins, and Three.js as one minified ES module. Sites load them from their own server through
// Beekiri.use() — see src/lib/site-libs.ts.
//
//   node apps/api/scripts/vendor-libs.mjs [gsap version] [three version]
//
// Needs the network (npm pack) and esbuild (already installed for the admin build).
import { execFileSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const out = join(root, 'vendor', 'libs');
const current = existsSync(join(out, 'versions.json')) ? JSON.parse(readFileSync(join(out, 'versions.json'), 'utf8')) : {};
const versions = { gsap: process.argv[2] || current.gsap, three: process.argv[3] || current.three };
if (!versions.gsap || !versions.three) throw new Error('Give the versions: vendor-libs.mjs <gsap> <three>');

/** GSAP plugins sites may ask for by name (Beekiri.use('gsap', 'ScrollTrigger')). */
const GSAP_PLUGINS = [
  'ScrollTrigger',
  'ScrollSmoother',
  'ScrollToPlugin',
  'SplitText',
  'Flip',
  'Observer',
  'Draggable',
  'InertiaPlugin',
  'MotionPathPlugin',
  'DrawSVGPlugin',
  'MorphSVGPlugin',
  'TextPlugin',
  'ScrambleTextPlugin',
  'CustomEase',
];

const work = mkdtempSync(join(tmpdir(), 'beekiri-libs-'));
const unpack = (name, version) => {
  const tgz = execFileSync('npm', ['pack', `${name}@${version}`, '--silent'], { cwd: work, encoding: 'utf8' }).trim().split('\n').pop();
  const dir = join(work, name);
  mkdirSync(dir);
  execFileSync('tar', ['-xzf', join(work, tgz), '-C', dir]);
  return join(dir, 'package');
};

try {
  rmSync(out, { recursive: true, force: true });
  mkdirSync(join(out, 'gsap'), { recursive: true });
  mkdirSync(join(out, 'three'), { recursive: true });

  const gsap = unpack('gsap', versions.gsap);
  for (const file of ['gsap', ...GSAP_PLUGINS]) cpSync(join(gsap, 'dist', `${file}.min.js`), join(out, 'gsap', `${file}.min.js`));

  // Three.js publishes its module in two unminified files: one minified file loads in one request.
  const three = unpack('three', versions.three);
  const esbuild = join(root, '..', '..', 'node_modules', '.bin', 'esbuild');
  execFileSync(esbuild, [
    join(three, 'build', 'three.module.js'),
    '--bundle',
    '--minify',
    '--format=esm',
    '--target=es2020',
    '--legal-comments=none',
    `--banner:js=/*! three.js ${versions.three} | (c) three.js authors | MIT License | https://threejs.org */`,
    `--outfile=${join(out, 'three', 'three.module.min.js')}`,
  ]);
  cpSync(join(three, 'LICENSE'), join(out, 'three', 'LICENSE'));

  writeFileSync(join(out, 'versions.json'), `${JSON.stringify({ ...versions, gsapPlugins: GSAP_PLUGINS }, null, 2)}\n`);
  console.log(`Vendored gsap ${versions.gsap} and three ${versions.three} into ${out}`);
} finally {
  rmSync(work, { recursive: true, force: true });
}
