import { existsSync, readdirSync, statSync } from 'fs';
import { join, relative, sep } from 'path';
import { REPO_ROOT } from '../../config/paths';
import { config } from '../../config/env';

/**
 * A deploy package is this whole site in one .zip: Beekiri itself (as installed here, already
 * built), plus the site's content as a migration file. On a new server it is unzipped, started
 * like any Beekiri install, and the content is restored from Settings → Migration.
 */

/** Where the site's content sits inside the package, and on the server it is unpacked on. */
export const BUNDLE_DIR = 'deploy';
export const BUNDLE_FILE = 'site.beekiri';
/** Says the built files in the package match its code, so the first start does not build again. */
export const PREBUILT_MARKER = '.beekiri-prebuilt';

export function bundlePath(): string {
  return join(REPO_ROOT, BUNDLE_DIR, BUNDLE_FILE);
}

export type DeployFile = { rel: string; abs: string; size: number };

/** Folders that never travel, wherever they are. */
const SKIP_DIRS = new Set([
  'node_modules',
  '.git',
  '.turbo',
  '.vite',
  '.next-dev',
  '.harness',
  'coverage',
  'uploads',
  'releases',
  'backups',
  '__tests__',
  'playwright-report',
  'test-results',
  '.cursor',
  '.claude',
  '.idea',
  '.vscode',
]);

/** Paths from the install folder that stay behind: site data, secrets, release tooling. */
const SKIP_PATHS = new Set([
  'database',
  'installer',
  BUNDLE_DIR,
  'START_HERE.txt',
  PREBUILT_MARKER,
  '.beekiri-update.json',
  'apps/admin/cache',
  'apps/api/test',
  'apps/api/.cache-epoch',
  'apps/api/.setup-token',
  'apps/web/.next/cache',
  'apps/web/.next/trace',
  'apps/web/.next/diagnostics',
  'apps/web/.next/types',
  'scripts/pack-release.sh',
  'scripts/publish-release.sh',
]);

/** `.env.example` is documentation and stays in. */
const SKIP_FILES = /(^\.env(\.(?!example$).*)?$|\.log$|^\.DS_Store$|^Thumbs\.db$|\.tsbuildinfo$|\.pem$|\.key$|\.swp$|\.(test|spec)\.tsx?$|^vitest\.config\.)/;

/** Built output that belongs in the package (other `dist` folders are leftovers). */
const BUILT_DIRS = ['apps/api/dist', 'apps/admin/dist', 'apps/admin/vendor/beeseo/dist', 'apps/web/.next'];
const VENDOR_DIST = /^apps\/web\/modules\/beekiricanva\/vendor\/[^/]+\/pkg\/dist$/;

/** Themes that come with Beekiri; every other theme travels inside the site's content. */
const CORE_THEMES = new Set(['beekiri', 'beekiri-child']);

function keepDir(rel: string, name: string): boolean {
  if (SKIP_DIRS.has(name) || SKIP_PATHS.has(rel)) return false;
  if (name === 'dist' || name === '.next') return BUILT_DIRS.includes(rel) || VENDOR_DIST.test(rel);
  const theme = /^apps\/web\/themes\/([^/]+)(\/.*)?$/.exec(rel);
  if (theme) {
    if (!CORE_THEMES.has(theme[1])) return false;
    const inside = theme[2] ?? '';
    // This site's own layouts and templates are content: they arrive with the child theme.
    if (/^\/sites(\/|$)/.test(inside) || /^\/cpts\/[^/]+$/.test(inside)) return false;
    if (theme[1] === 'beekiri-child' && /^\/layouts\/[^/]+$/.test(inside) && inside !== '/layouts/hero-banner') return false;
  }
  return true;
}

/** Every file of this install that a new server needs, `rel` with forward slashes. */
export function listDeployFiles(includeBuilt: boolean): DeployFile[] {
  const out: DeployFile[] = [];
  const mediaRoot = relative(REPO_ROOT, config.media.root).split(sep).join('/');
  const walk = (dir: string) => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const abs = join(dir, entry.name);
      const rel = relative(REPO_ROOT, abs).split(sep).join('/');
      if (entry.isSymbolicLink()) continue;
      if (entry.isDirectory()) {
        if (rel === mediaRoot || !keepDir(rel, entry.name)) continue;
        if (!includeBuilt && BUILT_DIRS.includes(rel)) continue;
        walk(abs);
      } else if (entry.isFile()) {
        if (SKIP_PATHS.has(rel) || SKIP_FILES.test(entry.name)) continue;
        out.push({ rel, abs, size: statSync(abs).size });
      }
    }
  };
  walk(REPO_ROOT);
  return out.sort((a, b) => a.rel.localeCompare(b.rel));
}

const WALK_SKIP = new Set(['node_modules', 'dist', '.next', '.next-dev']);

function newest(paths: string[]): number {
  let latest = 0;
  for (const path of paths) {
    if (!existsSync(path)) continue;
    const st = statSync(path);
    if (!st.isDirectory()) {
      latest = Math.max(latest, st.mtimeMs);
      continue;
    }
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      if (entry.isDirectory() && WALK_SKIP.has(entry.name)) continue;
      latest = Math.max(latest, newest([join(path, entry.name)]));
    }
  }
  return latest;
}

/**
 * True when every built part is newer than its code — the same check `npm start` makes
 * (scripts/start.mjs) before it builds. Code edited since the last start means the built
 * files are stale: the package then goes without them and the new server builds on first start.
 */
export function builtIsCurrent(): boolean {
  const at = (...p: string[]) => join(REPO_ROOT, ...p);
  const parts: [string, string[]][] = [
    [at('apps/admin/vendor/beeseo/dist/index.js'), ['src', 'package.json', 'tsup.config.ts'].map((p) => at('apps/admin/vendor/beeseo', p))],
    [at('apps/admin/dist/index.html'), ['src', 'public', 'index.html', 'vite.config.ts', 'package.json'].map((p) => at('apps/admin', p))],
    [at('apps/web/.next/prerender-manifest.json'), ['src', 'modules', 'public', 'next.config.ts', 'package.json'].map((p) => at('apps/web', p))],
    [at('apps/api/dist/server.js'), ['src', 'package.json'].map((p) => at('apps/api', p))],
  ];
  return parts.every(([output, sources]) => existsSync(output) && statSync(output).mtimeMs >= newest(sources));
}

/** START_HERE.txt at the top of the package. */
export function startHereText(info: { siteName: string; siteUrl: string; version: string; built: boolean; madeAt: Date }): string {
  return `Deploy package: ${info.siteName}
${'='.repeat(16 + info.siteName.length)}

Made on ${info.madeAt.toISOString().slice(0, 10)} from ${info.siteUrl} (Beekiri ${info.version}).
It holds Beekiri and the whole site: pages, posts, settings, users, themes
and media. Keep it private.

WHAT THE SERVER NEEDS
- Node.js 20 or later, and the right to keep a Node.js program running
  (a VPS, or a hosting plan with Node.js apps). Plain PHP-only web hosting
  cannot run Beekiri.
- A PostgreSQL database, or none: Beekiri can install its own.
- PHP 8 or later on the command line if the theme uses PHP layouts or the shop.

PUT IT ONLINE
1. Upload this zip to the server and unzip it into the folder the site runs from.
2. In that folder run:
       npm install
       npm start
   ${info.built ? 'Beekiri is already built, so the first start takes seconds.' : 'The first start builds Beekiri, which takes a few minutes.'}
   Hosts that ask for an "entry file" or "startup file" instead of a
   command: use server.js. The port comes from the PORT setting of the host.
3. Open the setup link that npm start prints. Choose the database ("Set it
   up for me", or the details from your host), then create the site and an
   account. The account is only for the next step.
4. Sign in, open Settings -> Migration and click "Restore this site". The
   content replaces the empty site; sign in again with your account from
   ${info.siteUrl}.

AFTER THAT
- Addresses inside the content are changed to the new address for you.
- Enter payment keys (Stripe, PayPal) and e-mail passwords again: secrets
  never travel in a package.
- Point the domain at the server and put HTTPS in front of it, as your host
  describes. Set APP_URL in apps/api/.env to the public address
  (https://example.com) and restart.
- To keep it running after you log out, use the host's Node.js app manager
  or a process manager, for example:  npx pm2 start "npm start" --name beekiri

Updates: Settings -> Beekiri Core in the admin.
`;
}
