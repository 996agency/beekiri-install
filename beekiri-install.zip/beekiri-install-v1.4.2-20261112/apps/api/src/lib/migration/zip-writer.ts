import { createReadStream, createWriteStream, statSync, type WriteStream } from 'fs';
import { once } from 'events';
import * as zlib from 'zlib';
import { deflateRawSync } from 'zlib';

/**
 * Writes a .zip one file at a time, straight to disk, so a deploy package with gigabytes of
 * media never sits in memory (adm-zip builds the whole archive in RAM). Text is deflated;
 * files that are already compressed (photos, video, .beekiri) are stored as they are.
 * Entries or archives past 4 GB use the ZIP64 fields, which every current unzip tool reads.
 */

const MAX32 = 0xffffffff;
/** Deflate in memory up to this size; larger files are stored (they are media or archives). */
const DEFLATE_LIMIT = 8 * 1024 * 1024;
const STORED = /\.(webp|jpe?g|png|gif|avif|ico|mp4|webm|mov|mp3|wav|ogg|pdf|zip|gz|br|woff2?|beekiri)$/i;

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();

/** Node's own checksum where it exists (20.15+), else the table above. */
const nativeCrc32 = (zlib as unknown as { crc32?: (data: Buffer, seed?: number) => number }).crc32;

function crc32(buf: Buffer, seed = 0): number {
  if (nativeCrc32) return nativeCrc32(buf, seed);
  let c = ~seed >>> 0;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return ~c >>> 0;
}

function dosTime(date: Date): { time: number; day: number } {
  const y = Math.max(1980, date.getFullYear());
  return {
    time: (date.getHours() << 11) | (date.getMinutes() << 5) | (date.getSeconds() >> 1),
    day: ((y - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate(),
  };
}

type Entry = { name: Buffer; method: number; crc: number; packed: number; size: number; offset: number; time: number; day: number; mode: number };

export class ZipWriter {
  private readonly out: WriteStream;
  private readonly entries: Entry[] = [];
  private offset = 0;
  private failed: Error | null = null;

  /** `forceZip64` is for tests: write the ZIP64 fields even for a small archive. */
  constructor(path: string, private readonly forceZip64 = false) {
    this.out = createWriteStream(path, { mode: 0o600 });
    this.out.on('error', (e) => {
      this.failed = e;
    });
  }

  get bytesWritten(): number {
    return this.offset;
  }

  private async write(buf: Buffer) {
    if (this.failed) throw this.failed;
    this.offset += buf.length;
    if (!this.out.write(buf)) await once(this.out, 'drain');
  }

  private localHeader(e: Entry, zip64: boolean): Buffer {
    const extra = zip64 ? Buffer.alloc(20) : Buffer.alloc(0);
    if (zip64) {
      extra.writeUInt16LE(0x0001, 0);
      extra.writeUInt16LE(16, 2);
      extra.writeBigUInt64LE(BigInt(e.size), 4);
      extra.writeBigUInt64LE(BigInt(e.packed), 12);
    }
    const h = Buffer.alloc(30);
    h.writeUInt32LE(0x04034b50, 0);
    h.writeUInt16LE(zip64 ? 45 : 20, 4);
    h.writeUInt16LE(0x0800, 6); // names are UTF-8
    h.writeUInt16LE(e.method, 8);
    h.writeUInt16LE(e.time, 10);
    h.writeUInt16LE(e.day, 12);
    h.writeUInt32LE(e.crc, 14);
    h.writeUInt32LE(zip64 ? MAX32 : e.packed, 18);
    h.writeUInt32LE(zip64 ? MAX32 : e.size, 22);
    h.writeUInt16LE(e.name.length, 26);
    h.writeUInt16LE(extra.length, 28);
    return Buffer.concat([h, e.name, extra]);
  }

  private begin(name: string, mtime: Date, mode: number): Omit<Entry, 'method' | 'crc' | 'packed' | 'size'> {
    if (!name || name.startsWith('/') || name.split('/').includes('..')) throw new Error(`Bad path in the package: ${name}`);
    return { name: Buffer.from(name, 'utf8'), offset: this.offset, mode, ...dosTime(mtime) };
  }

  /** Text or other bytes held in memory. */
  async addBuffer(name: string, data: Buffer, mtime = new Date(), mode = 0o644) {
    const packed = data.length > 64 && !STORED.test(name) ? deflateRawSync(data, { level: 6 }) : null;
    const body = packed && packed.length < data.length ? packed : data;
    const e: Entry = { ...this.begin(name, mtime, mode), method: body === data ? 0 : 8, crc: crc32(data), packed: body.length, size: data.length };
    await this.write(this.localHeader(e, this.forceZip64));
    await this.write(body);
    this.entries.push(e);
  }

  /** A file on disk; `onBytes` reports progress for large ones. */
  async addFile(name: string, path: string, onBytes?: (n: number) => void) {
    const st = statSync(path);
    const mode = st.mode & 0o111 ? 0o755 : 0o644;
    if (st.size <= DEFLATE_LIMIT) {
      const { readFile } = await import('fs/promises');
      await this.addBuffer(name, await readFile(path), st.mtime, mode);
      onBytes?.(st.size);
      return;
    }
    // Stored: the header needs the checksum first, so the file is read twice.
    let crc = 0;
    for await (const chunk of createReadStream(path)) crc = crc32(chunk as Buffer, crc);
    const e: Entry = { ...this.begin(name, st.mtime, mode), method: 0, crc, packed: st.size, size: st.size };
    await this.write(this.localHeader(e, this.forceZip64 || st.size >= MAX32));
    let sent = 0;
    for await (const chunk of createReadStream(path)) {
      await this.write(chunk as Buffer);
      sent += (chunk as Buffer).length;
      onBytes?.((chunk as Buffer).length);
    }
    if (sent !== st.size) throw new Error(`${name} changed while it was being packed.`);
    this.entries.push(e);
  }

  /** Writes the index and closes the file. */
  async close() {
    const start = this.offset;
    for (const e of this.entries) {
      const big = this.forceZip64 || e.size >= MAX32 || e.packed >= MAX32 || e.offset >= MAX32;
      const extra = big ? Buffer.alloc(28) : Buffer.alloc(0);
      if (big) {
        extra.writeUInt16LE(0x0001, 0);
        extra.writeUInt16LE(24, 2);
        extra.writeBigUInt64LE(BigInt(e.size), 4);
        extra.writeBigUInt64LE(BigInt(e.packed), 12);
        extra.writeBigUInt64LE(BigInt(e.offset), 20);
      }
      const h = Buffer.alloc(46);
      h.writeUInt32LE(0x02014b50, 0);
      h.writeUInt16LE((3 << 8) | (big ? 45 : 20), 4); // made on Unix: the mode below is kept
      h.writeUInt16LE(big ? 45 : 20, 6);
      h.writeUInt16LE(0x0800, 8);
      h.writeUInt16LE(e.method, 10);
      h.writeUInt16LE(e.time, 12);
      h.writeUInt16LE(e.day, 14);
      h.writeUInt32LE(e.crc, 16);
      h.writeUInt32LE(big ? MAX32 : e.packed, 20);
      h.writeUInt32LE(big ? MAX32 : e.size, 24);
      h.writeUInt16LE(e.name.length, 28);
      h.writeUInt16LE(extra.length, 30);
      h.writeUInt32LE(((0o100000 | e.mode) << 16) >>> 0, 38);
      h.writeUInt32LE(big ? MAX32 : e.offset, 42);
      await this.write(Buffer.concat([h, e.name, extra]));
    }
    const size = this.offset - start;
    const count = this.entries.length;
    if (this.forceZip64 || count >= 0xffff || start >= MAX32 || size >= MAX32) {
      const z = Buffer.alloc(56 + 20);
      z.writeUInt32LE(0x06064b50, 0);
      z.writeBigUInt64LE(44n, 4);
      z.writeUInt16LE((3 << 8) | 45, 12);
      z.writeUInt16LE(45, 14);
      z.writeBigUInt64LE(BigInt(count), 24);
      z.writeBigUInt64LE(BigInt(count), 32);
      z.writeBigUInt64LE(BigInt(size), 40);
      z.writeBigUInt64LE(BigInt(start), 48);
      z.writeUInt32LE(0x07064b50, 56);
      z.writeBigUInt64LE(BigInt(start + size), 64);
      z.writeUInt32LE(1, 72);
      await this.write(z);
    }
    const end = Buffer.alloc(22);
    end.writeUInt32LE(0x06054b50, 0);
    end.writeUInt16LE(Math.min(count, 0xffff), 8);
    end.writeUInt16LE(Math.min(count, 0xffff), 10);
    end.writeUInt32LE(Math.min(size, MAX32), 12);
    end.writeUInt32LE(Math.min(start, MAX32), 16);
    await this.write(end);
    this.out.end();
    await once(this.out, 'close');
    if (this.failed) throw this.failed;
  }

  /** Stops writing after an error; the caller removes the half-written file. */
  async abort() {
    if (this.out.closed) return;
    this.out.destroy();
    await once(this.out, 'close').catch(() => {});
  }
}
