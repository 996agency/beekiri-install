import { createHash } from 'crypto';
import {
  copyFileSync,
  cpSync,
  createReadStream,
  existsSync,
  lstatSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync,
} from 'fs';
import { dirname, join } from 'path';
import { config } from '../../config/env';
import { resolveThemesRoot, sanitizeThemeSlug } from '../themes/theme-registry';
import { isSafeRelPath } from './archive';
import { migrationRoot, newId } from './storage';

export type FileEntry = { path: string; size: number; abs: string };

const SKIP_DIRS = new Set(['node_modules']);

/** Regular files under a folder: no symlinks, no hidden files or folders. */
export function walkFiles(root: string): FileEntry[] {
  const out: FileEntry[] = [];
  const walk = (dir: string, prefix: string) => {
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (entry.name.startsWith('.') || SKIP_DIRS.has(entry.name)) continue;
      const abs = join(dir, entry.name);
      const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
      if (entry.isDirectory()) walk(abs, rel);
      else if (entry.isFile() && !lstatSync(abs).isSymbolicLink()) out.push({ path: rel, size: statSync(abs).size, abs });
    }
  };
  walk(root, '');
  return out.sort((a, b) => a.path.localeCompare(b.path));
}

export function themeDir(slug: string): string {
  return join(resolveThemesRoot(), sanitizeThemeSlug(slug));
}

export function uploadsRoot(): string {
  return config.media.root;
}

/* ---------- Media: path, size and content hash of every file, cached by size + time ---------- */

export type MediaFile = { p: string; s: number; h: string };

type HashCache = Record<string, [size: number, mtimeMs: number, hash: string]>;

function hashCachePath() {
  return join(migrationRoot(), 'media-hashes.json');
}

function sha1File(abs: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const hash = createHash('sha1');
    createReadStream(abs)
      .on('data', (chunk) => hash.update(chunk))
      .on('error', reject)
      .on('end', () => resolve(hash.digest('hex')));
  });
}

export async function mediaManifest(onProgress?: (done: number, total: number) => void): Promise<MediaFile[]> {
  let cache: HashCache = {};
  try {
    cache = JSON.parse(readFileSync(hashCachePath(), 'utf8')) as HashCache;
  } catch {
    cache = {};
  }
  const next: HashCache = {};
  const files = walkFiles(uploadsRoot());
  const out: MediaFile[] = [];
  for (const [i, f] of files.entries()) {
    const st = statSync(f.abs);
    const hit = cache[f.path];
    const hash = hit && hit[0] === st.size && hit[1] === st.mtimeMs ? hit[2] : await sha1File(f.abs);
    next[f.path] = [st.size, st.mtimeMs, hash];
    out.push({ p: f.path, s: st.size, h: hash });
    if (i % 50 === 0) onProgress?.(i, files.length);
  }
  try {
    writeFileSync(hashCachePath(), JSON.stringify(next), { mode: 0o600 });
  } catch {
    // The cache only saves time.
  }
  return out;
}

/** Files to send (new or different on the other side) and, when mirroring, files to remove there. */
export function diffMedia(source: MediaFile[], target: MediaFile[], mirror: boolean) {
  const there = new Map(target.map((f) => [f.p, f]));
  const send = source.filter((f) => {
    const t = there.get(f.p);
    return !t || t.s !== f.s || t.h !== f.h;
  });
  const keep = new Set(source.map((f) => f.p));
  const remove = mirror ? target.filter((f) => !keep.has(f.p)).map((f) => f.p) : [];
  return { send, remove };
}

/* ---------- Writing files into place ---------- */

/** Move a folder, also across disks (copy, then delete). */
function moveDir(from: string, to: string) {
  try {
    renameSync(from, to);
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code !== 'EXDEV') throw e;
    cpSync(from, to, { recursive: true });
    rmSync(from, { recursive: true, force: true });
  }
}

/**
 * Puts a staged theme folder in place of the current one in a single swap; the old folder is
 * only deleted once the new one is there (and put back if the swap fails).
 */
export function swapThemeFolder(slug: string, staged: string) {
  const root = resolveThemesRoot();
  mkdirSync(root, { recursive: true });
  const target = join(root, sanitizeThemeSlug(slug));
  const tag = newId(6);
  const incoming = join(root, `.${slug}.incoming-${tag}`);
  const old = join(root, `.${slug}.previous-${tag}`);
  moveDir(staged, incoming);
  const hadOld = existsSync(target);
  try {
    if (hadOld) renameSync(target, old);
    renameSync(incoming, target);
  } catch (e) {
    if (hadOld && !existsSync(target) && existsSync(old)) renameSync(old, target);
    rmSync(incoming, { recursive: true, force: true });
    throw e;
  }
  if (hadOld) rmSync(old, { recursive: true, force: true });
}

export function removeThemeFolder(slug: string) {
  // Never the themes folder itself, and never a path: only a plain theme slug.
  if (!slug || sanitizeThemeSlug(slug) !== slug) throw new Error(`Unsafe theme name: ${slug}`);
  const target = themeDir(slug);
  if (existsSync(target)) rmSync(target, { recursive: true, force: true });
}

/** Writes one staged media file into the library (via a temporary name, then a rename). */
export function placeMediaFile(rel: string, staged: string) {
  if (!isSafeRelPath(rel)) throw new Error(`Unsafe media path: ${rel}`);
  const dest = join(uploadsRoot(), rel);
  mkdirSync(dirname(dest), { recursive: true });
  const tmp = `${dest}.bkm-${newId(4)}`;
  try {
    renameSync(staged, tmp);
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code !== 'EXDEV') throw e;
    copyFileSync(staged, tmp);
    rmSync(staged, { force: true });
  }
  renameSync(tmp, dest);
}

export function removeMediaFile(rel: string) {
  if (!isSafeRelPath(rel)) return;
  rmSync(join(uploadsRoot(), rel), { force: true });
}
