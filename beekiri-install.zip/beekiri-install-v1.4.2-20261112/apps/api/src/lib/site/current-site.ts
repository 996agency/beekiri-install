import { AsyncLocalStorage } from 'node:async_hooks';
import type { NextFunction, Request, Response } from 'express';
import { config } from '../../config/env';
import { getSelfUrl } from '../../config/runtime';
import { Site, SiteSettings } from '../../models';
import type { SiteAccess } from '../../models/site.model';
import { randomToken, safeEqual } from '../../utils/crypto';
import { readOptions } from './site-options';

/**
 * Multisite: every request belongs to one site of the network, chosen from its host:
 *
 *   APP_URL host (and its www.)      → the primary site
 *   <slug>.<network domain>          → the site with that slug   (shop.example.com)
 *   a site's own `domain`            → that site
 *   anything else on this machine    → the primary site (localhost, 127.0.0.1, health checks)
 *
 * The site is kept for the whole request (AsyncLocalStorage), so services ask
 * `currentSiteId()` instead of passing it around. The website (Next.js, same process) gets it
 * as the `x-beekiri-site-id` request header and sends it back on its server-side API calls
 * together with an internal token, the only way a request can choose its site by header.
 */

export type SiteRef = { id: string; slug: string | null; domain: string | null; status: string; isPrimary: boolean };

type Context = { site: SiteRef };

const store = new AsyncLocalStorage<Context>();

export const SITE_HEADER = 'x-beekiri-site-id';
/** The visitor's address, passed to the website and back so limits count per visitor, not per server. */
export const CLIENT_IP_HEADER = 'x-beekiri-client-ip';
export const SITE_URL_HEADER = 'x-beekiri-site-url';
export const INTERNAL_HEADER = 'x-beekiri-internal';

/** Shared with the website when it starts in this process (see hosting/site-host.ts). */
export const INTERNAL_TOKEN = (process.env.BEEKIRI_INTERNAL_TOKEN ||= randomToken(32));

/* ── Site list cache (the table is tiny; refreshed every few seconds and on every change) ── */

/** A password-protected site: its name (for the sign-in page) and protection settings. */
export type SiteLock = { title: string; access: SiteAccess };

type Loaded = { sites: SiteRef[]; baseDomain: string; locks: Map<string, SiteLock> };

let cache: ({ at: number } & Loaded) | null = null;
let inflight: Promise<Loaded> | null = null;
const TTL_MS = 5_000;

export function bumpSiteCache(): void {
  cache = null;
}

/** The main site's address: APP_URL, else the address this server listens on (local installs). */
function appUrlString(): string {
  return (config.urls.app || getSelfUrl() || '').replace(/\/+$/, '');
}

function appUrl(): URL | null {
  try {
    const url = appUrlString();
    return url ? new URL(url) : null;
  } catch {
    return null;
  }
}

/** Host name without port, lower-case, without a trailing dot. */
export function normalizeHost(host: string | undefined | null): string {
  return (host || '').trim().toLowerCase().replace(/\.$/, '').replace(/:\d+$/, '').replace(/^\[|\]$/g, '');
}

/** Network domain sites hang off: the setting, else APP_URL's host without `www.`. */
function defaultBaseDomain(): string {
  return normalizeHost(appUrl()?.hostname).replace(/^www\./, '');
}

async function loadSites(): Promise<Loaded> {
  if (cache && Date.now() - cache.at < TTL_MS) return cache;
  if (inflight) return inflight;
  inflight = (async () => {
    try {
      const rows = await Site.unscoped().findAll({
        attributes: ['id', 'title', 'slug', 'domain', 'status', 'isPrimary', 'access', 'createdAt'],
        include: [{ model: SiteSettings, as: 'settings', attributes: ['options'] }],
        order: [['createdAt', 'ASC']],
      });
      const sites = rows.map((s) => ({
        id: s.id,
        slug: s.slug ?? null,
        domain: s.domain ? normalizeHost(s.domain) : null,
        status: s.status || 'active',
        isPrimary: Boolean(s.isPrimary),
      }));
      // Older databases: the oldest site is the primary one.
      if (sites.length && !sites.some((s) => s.isPrimary)) sites[0]!.isPrimary = true;
      const primary = rows.find((r) => r.id === sites.find((s) => s.isPrimary)?.id);
      const configured = normalizeHost(readOptions(primary?.settings?.options).network?.baseDomain);
      const locks = new Map<string, SiteLock>();
      for (const row of rows) {
        if (row.access?.passwordHash) locks.set(row.id, { title: row.title, access: row.access });
      }
      const result = { sites, baseDomain: configured || defaultBaseDomain(), locks };
      cache = { at: Date.now(), ...result };
      return result;
    } finally {
      inflight = null;
    }
  })();
  return inflight;
}

/** Sites known from the last load (every request refreshes it; 0 before the first). */
export function cachedSiteCount(): number {
  return cache?.sites.length ?? 0;
}

export async function listSiteRefs(): Promise<SiteRef[]> {
  return (await loadSites()).sites;
}

/** The site's password protection, or null when anyone may visit it. */
export async function siteLockFor(siteId: string): Promise<SiteLock | null> {
  return (await loadSites()).locks.get(siteId) ?? null;
}

export async function networkBaseDomain(): Promise<string> {
  return (await loadSites()).baseDomain;
}

export async function primarySiteRef(): Promise<SiteRef | null> {
  const { sites } = await loadSites();
  return sites.find((s) => s.isPrimary) ?? null;
}

/**
 * The site for a host. `null` means "no site here": an unknown sub-domain of the network,
 * so it is not silently answered by the primary site.
 */
export async function siteForHost(host: string | undefined | null): Promise<SiteRef | null> {
  const { sites, baseDomain } = await loadSites();
  const primary = sites.find((s) => s.isPrimary) ?? null;
  const name = normalizeHost(host);
  if (!name) return primary;

  const byDomain = sites.find((s) => s.domain && s.domain === name);
  if (byDomain) return byDomain;

  const appHost = normalizeHost(appUrl()?.hostname);
  if (name === appHost || name === baseDomain || name === `www.${baseDomain}`) return primary;

  // Sub-domains of the network domain, and of localhost for local development.
  for (const base of new Set([baseDomain, 'localhost'])) {
    if (base && name.endsWith(`.${base}`)) {
      const label = name.slice(0, -(base.length + 1));
      if (label === 'www') return primary;
      if (!label.includes('.')) return sites.find((s) => s.slug === label) ?? null;
    }
  }
  return primary;
}

/** Public address of a site (canonical URLs, links between sites, e-mails). */
export async function siteUrl(site: Pick<SiteRef, 'slug' | 'domain' | 'isPrimary'>): Promise<string> {
  const app = appUrl();
  const fallback = appUrlString();
  if (!app || site.isPrimary) return fallback;
  const port = app.port ? `:${app.port}` : '';
  if (site.domain) return `${app.protocol}//${site.domain}${port}`;
  if (!site.slug) return fallback;
  const { baseDomain } = await loadSites();
  const base = baseDomain || normalizeHost(app.hostname);
  return `${app.protocol}//${site.slug}.${base}${port}`;
}

/* ── Request context ─────────────────────────────────────────────────── */

export function currentSite(): SiteRef | null {
  return store.getStore()?.site ?? null;
}

export function currentSiteId(): string | null {
  return store.getStore()?.site.id ?? null;
}

/** Run `fn` as if it were a request for `site` (background jobs loop over every site). */
export function runWithSite<T>(site: SiteRef, fn: () => T): T {
  return store.run({ site }, fn);
}

/** Runs `fn` once per active site of the network, one after the other (boot, nightly jobs). */
export async function forEachSite(fn: (site: SiteRef) => Promise<unknown> | unknown): Promise<void> {
  let sites: SiteRef[] = [];
  try {
    sites = (await loadSites()).sites.filter((s) => s.status === 'active');
  } catch {
    return;
  }
  for (const site of sites) await runWithSite(site, () => fn(site));
}

declare module 'express-serve-static-core' {
  interface Request {
    site?: SiteRef;
  }
}

function internalSite(req: Request, sites: SiteRef[]): SiteRef | null {
  const token = req.get(INTERNAL_HEADER);
  const id = req.get(SITE_HEADER);
  if (!token || !id || !safeEqual(token, INTERNAL_TOKEN)) return null;
  return sites.find((s) => s.id === id) ?? null;
}

/**
 * Picks the request's site. Unknown sub-domains and archived sites get a 404 page, so a
 * mistyped address never shows another site's content.
 */
export async function siteContext(req: Request, res: Response, next: NextFunction): Promise<void> {
  let site: SiteRef | null;
  try {
    const { sites } = await loadSites();
    // Not installed yet (first-run wizard): no site to choose.
    if (!sites.length) {
      bumpSiteCache();
      delete req.headers[SITE_HEADER];
      delete req.headers[SITE_URL_HEADER];
      next();
      return;
    }
    site = internalSite(req, sites) ?? (await siteForHost(req.get('host')));
  } catch {
    // Database not set up yet (first-run wizard): no site context.
    delete req.headers[SITE_HEADER];
    delete req.headers[SITE_URL_HEADER];
    next();
    return;
  }
  // Only this server may tell the website which site a request is for (and who is asking).
  delete req.headers[SITE_HEADER];
  delete req.headers[SITE_URL_HEADER];
  delete req.headers[CLIENT_IP_HEADER];
  if (!site || site.status === 'archived') {
    res.status(404).type('text/plain').send('There is no site at this address.');
    return;
  }
  req.site = site;
  req.headers[SITE_HEADER] = site.id;
  req.headers[CLIENT_IP_HEADER] = req.ip ?? '';
  req.headers[SITE_URL_HEADER] = await siteUrl(site).catch(() => '');
  store.run({ site }, () => next());
}

/**
 * Re-enters the request's site context. Stream-based parsers (JSON bodies, uploads) can call
 * back outside it; mount this after them.
 */
export function rebindSite(req: Request, _res: Response, next: NextFunction): void {
  if (req.site && currentSiteId() !== req.site.id) {
    store.run({ site: req.site }, () => next());
    return;
  }
  next();
}
