/** Connector: AI providers the site can use. */

export const CONNECTOR_PROVIDER_IDS = [
  'beequeen',
  'claude',
  'openai',
  'gemini',
  'grok',
] as const;

export type ConnectorProviderId = (typeof CONNECTOR_PROVIDER_IDS)[number];

export const CONNECTOR_EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max'] as const;

export type ConnectorEffort = (typeof CONNECTOR_EFFORTS)[number];

export const DEFAULT_EFFORT: ConnectorEffort = 'max';

export type ConnectorProviderState = {
  id: ConnectorProviderId;
  enabled: boolean;
  /** Preferred model id for this provider. */
  defaultModel: string;
  /** Reasoning effort for providers that support it (Claude, BeeQueen). */
  effort: ConnectorEffort;
};

/**
 * Where the Beekiri Hub and Connector run: 996Agency. Clients never set this. BEEQUEEN_SERVICE_URL
 * (or BEEKIRI_HUB_URL) points a site somewhere else, e.g. a local 996ai for testing.
 */
export const DEFAULT_BEEQUEEN_URL = (process.env.BEEQUEEN_SERVICE_URL?.trim() || 'https://996agency.com').replace(/\/+$/, '');

export type ConnectorOptions = {
  providers: Record<ConnectorProviderId, ConnectorProviderState>;
};

export type ConnectorProviderCatalog = {
  id: ConnectorProviderId;
  name: string;
  vendor: string;
  blurb: string;
  badge?: string;
  docsUrl: string;
  models: { id: string; label: string }[];
  /** Offers the reasoning-effort setting. */
  supportsEffort?: boolean;
  /** Not offered on the Connector page for now (BeeQueen only). */
  hidden?: boolean;
};

/** Claude models BeeQueen and the Claude connector can run on (first = default). */
const CLAUDE_MODELS = [
  { id: 'claude-opus-5-5', label: 'Claude Opus 5.5' },
  { id: 'claude-sonnet-5-5', label: 'Claude Sonnet 5.5' },
  { id: 'claude-haiku-5-5', label: 'Claude Haiku 5.5' },
  { id: 'claude-fable-5-1', label: 'Claude Fable 5.1' },
];

/** Catalog order = Beekiri agent first, then third-party providers. */
export const CONNECTOR_PROVIDER_CATALOG: ConnectorProviderCatalog[] = [
  {
    id: 'beequeen',
    name: 'Beekiri',
    vendor: '996Agency',
    blurb:
      'Beekiri builds layouts, Backend Fields and pages inside your theme. It runs on Claude through 996Agency’s Anthropic API account — no Claude key or setup needed. Prepaid: top up a balance ($20, $50, $100 or your own amount), then each message takes only what it uses.',
    badge: 'Claude',
    docsUrl: 'https://996agency.com',
    models: CLAUDE_MODELS,
    supportsEffort: true,
  },
  {
    id: 'claude',
    hidden: true,
    name: 'Claude',
    vendor: 'Anthropic',
    blurb: 'Strongest for long writing, editing, and careful site work.',
    docsUrl: 'https://console.anthropic.com/settings/keys',
    models: CLAUDE_MODELS,
    supportsEffort: true,
  },
  {
    id: 'openai',
    hidden: true,
    name: 'ChatGPT',
    vendor: 'OpenAI',
    blurb: 'Versatile models for drafts, ideas, and everyday assistance.',
    docsUrl: 'https://platform.openai.com/api-keys',
    models: [
      { id: 'gpt-5.2', label: 'GPT-5.2' },
      { id: 'gpt-5-mini', label: 'GPT-5 mini' },
      { id: 'gpt-4.1', label: 'GPT-4.1' },
    ],
  },
  {
    id: 'gemini',
    hidden: true,
    name: 'Gemini',
    vendor: 'Google',
    blurb: 'Fast multimodal models with strong research-style answers.',
    docsUrl: 'https://aistudio.google.com/apikey',
    models: [
      { id: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro' },
      { id: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash' },
      { id: 'gemini-2.0-flash', label: 'Gemini 2.0 Flash' },
    ],
  },
  {
    id: 'grok',
    hidden: true,
    name: 'Grok',
    vendor: 'xAI',
    blurb: 'Realtime-flavored answers with a bold, conversational style.',
    docsUrl: 'https://console.x.ai/',
    models: [
      { id: 'grok-3', label: 'Grok 3' },
      { id: 'grok-3-mini', label: 'Grok 3 mini' },
      { id: 'grok-2', label: 'Grok 2' },
    ],
  },
];

function defaultModelFor(id: ConnectorProviderId): string {
  return CONNECTOR_PROVIDER_CATALOG.find((p) => p.id === id)?.models[0]?.id ?? '';
}

function emptyState(id: ConnectorProviderId): ConnectorProviderState {
  return {
    id,
    enabled: false,
    defaultModel: defaultModelFor(id),
    effort: DEFAULT_EFFORT,
  };
}

export const DEFAULT_CONNECTOR: ConnectorOptions = {
  providers: {
    beequeen: emptyState('beequeen'),
    claude: emptyState('claude'),
    openai: emptyState('openai'),
    gemini: emptyState('gemini'),
    grok: emptyState('grok'),
  },
};

function asBool(v: unknown, fallback: boolean): boolean {
  return typeof v === 'boolean' ? v : fallback;
}

function asString(v: unknown, fallback = ''): string {
  return typeof v === 'string' ? v : fallback;
}

export function isConnectorProviderId(v: string): v is ConnectorProviderId {
  return (CONNECTOR_PROVIDER_IDS as readonly string[]).includes(v);
}

export function parseConnector(raw: unknown): ConnectorOptions {
  const o = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
  const providersRaw =
    o.providers && typeof o.providers === 'object'
      ? (o.providers as Record<string, unknown>)
      : {};

  const providers = { ...DEFAULT_CONNECTOR.providers };
  for (const id of CONNECTOR_PROVIDER_IDS) {
    const row = providersRaw[id];
    const r = row && typeof row === 'object' ? (row as Record<string, unknown>) : {};
    const models = CONNECTOR_PROVIDER_CATALOG.find((p) => p.id === id)?.models ?? [];
    const model = asString(r.defaultModel, defaultModelFor(id));
    const effort = asString(r.effort, DEFAULT_EFFORT) as ConnectorEffort;
    providers[id] = {
      id,
      enabled: asBool(r.enabled, false),
      defaultModel: models.some((m) => m.id === model) ? model : defaultModelFor(id),
      effort: CONNECTOR_EFFORTS.includes(effort) ? effort : DEFAULT_EFFORT,
    };
  }

  return { providers };
}

export function normalizeServiceUrl(raw: string): string {
  const v = raw.trim().replace(/\/+$/, '');
  return /^https?:\/\/[^\s/]+(\/[^\s]*)?$/i.test(v) ? v : '';
}

/**
 * An Anthropic key for running the agent without 996Agency — only for the owner's own testing on a
 * local machine (localEnginesAllowed). It comes from the server environment, never from the database:
 * a site stores no AI key of any kind, so a database dump or export has none to leak.
 */
export function localAnthropicKey(): string {
  return (process.env.ANTHROPIC_API_KEY ?? '').trim();
}
