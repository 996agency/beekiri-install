/**
 * Settings → Email: this site's own outgoing mail server (SMTP). Each site of a network keeps
 * its own, so a client's forms, shop and booking emails leave through the client's mailbox.
 * The password is stored encrypted and never leaves the server.
 */

export const MAIL_SECURITY = ['tls', 'starttls', 'none'] as const;
export type MailSecurity = (typeof MAIL_SECURITY)[number];

export type MailSettings = {
  /** Off = this site sends through the server's own mail settings (if it has any). */
  enabled: boolean;
  host: string;
  port: number;
  /** tls: encrypted from the first byte (465). starttls: upgraded before signing in (587). */
  security: MailSecurity;
  username: string;
  /** Encrypted at rest (lib/shop/secrets). */
  password: string;
  fromEmail: string;
  fromName: string;
  replyTo: string;
  /** Set only when the network owner saved a host on a private address (a mail relay on the server itself). */
  allowPrivateHost: boolean;
};

export const EMAIL_RE = /^[^\s@<>"',;]+@[^\s@<>"',;]+\.[^\s@<>"',;]{2,}$/;
/** A host name or an IP address — nothing that could carry a path, a port or a header. */
export const HOST_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$|^\[?[0-9a-f:.]{2,45}\]?$/i;

const oneLine = (v: unknown, max: number) => (typeof v === 'string' ? v.replace(/[\r\n\0]+/g, ' ').trim().slice(0, max) : '');

export function defaultMailSettings(): MailSettings {
  return { enabled: false, host: '', port: 587, security: 'starttls', username: '', password: '', fromEmail: '', fromName: '', replyTo: '', allowPrivateHost: false };
}

export function parseMailSettings(raw: unknown): MailSettings {
  const d = defaultMailSettings();
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return d;
  const o = raw as Record<string, unknown>;
  const host = oneLine(o.host, 253).toLowerCase();
  const port = Number(o.port);
  const email = (v: unknown) => {
    const s = oneLine(v, 254);
    return EMAIL_RE.test(s) ? s : '';
  };
  return {
    enabled: o.enabled === true,
    host: HOST_RE.test(host) ? host : '',
    port: Number.isInteger(port) && port >= 1 && port <= 65535 ? port : d.port,
    security: MAIL_SECURITY.includes(o.security as MailSecurity) ? (o.security as MailSecurity) : d.security,
    username: oneLine(o.username, 320),
    password: typeof o.password === 'string' ? o.password.slice(0, 2000) : '',
    fromEmail: email(o.fromEmail),
    fromName: oneLine(o.fromName, 120).replace(/["<>]/g, ''),
    replyTo: email(o.replyTo),
    allowPrivateHost: o.allowPrivateHost === true,
  };
}
