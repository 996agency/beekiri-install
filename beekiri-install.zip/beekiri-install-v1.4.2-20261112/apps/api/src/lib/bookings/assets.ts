import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

let cached: string | null = null;

/** Public booking stylesheet (booking.css next to this file; copied into dist by copy-assets). */
export function bookingCss(): string {
  if (cached === null || process.env.NODE_ENV !== 'production') {
    cached = readFileSync(join(__dirname, 'booking.css'), 'utf8');
  }
  return cached;
}

export const BOOKING_CSS_PATH = '/api/bookings/public/assets/booking.css';

/** The stylesheet address with its content hash (?v=), so browsers can keep it for a year. */
export function bookingCssUrl(): string {
  return `${BOOKING_CSS_PATH}?v=${createHash('sha1').update(bookingCss()).digest('hex').slice(0, 10)}`;
}
