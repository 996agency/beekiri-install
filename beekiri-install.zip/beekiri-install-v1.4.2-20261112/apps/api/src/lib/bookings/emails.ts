import { escHtml } from '../forms/render';

export type BookingEmail = { subject: string; text: string; html: string };

export type BookingEmailInput = {
  siteTitle: string;
  subject: string;
  /** First paragraph. */
  intro: string;
  /** Label → value rows (service, when, with, where…); empty values are left out. */
  rows: [string, string][];
  /** Extra paragraph under the rows. */
  note?: string;
  /** Button (and plain link in the text version). */
  action?: { label: string; url: string };
};

/** A booking email in the same plain, inline-styled shell the shop and form emails use. */
export function renderBookingEmail(input: BookingEmailInput): BookingEmail {
  const rows = input.rows.filter(([, value]) => value.trim());
  const text = [
    input.intro,
    '',
    ...rows.map(([label, value]) => `${label}: ${value}`),
    ...(input.note ? ['', input.note] : []),
    ...(input.action ? ['', `${input.action.label}: ${input.action.url}`] : []),
  ].join('\n');
  const html =
    `<!doctype html><html><body style="margin:0;padding:24px;background:#f0f0f1;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif">` +
    `<div style="max-width:600px;margin:0 auto;background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:28px 32px;color:#202734;font-size:15px;line-height:1.6">` +
    `<p style="margin:0 0 18px;font-size:12px;letter-spacing:.04em;text-transform:uppercase;color:#8c8f94">${escHtml(input.siteTitle)}</p>` +
    `<p style="margin:0 0 18px">${escHtml(input.intro)}</p>` +
    `<table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;margin:0 0 18px">` +
    rows
      .map(
        ([label, value]) =>
          `<tr><td style="padding:8px 12px 8px 0;border-top:1px solid #eee;color:#646970;font-size:13px;white-space:nowrap;vertical-align:top">${escHtml(label)}</td>` +
          `<td style="padding:8px 0;border-top:1px solid #eee;font-weight:600">${escHtml(value).replace(/\n/g, '<br>')}</td></tr>`,
      )
      .join('') +
    `</table>` +
    (input.note ? `<p style="margin:0 0 18px;color:#50575e">${escHtml(input.note).replace(/\n/g, '<br>')}</p>` : '') +
    (input.action
      ? `<p style="margin:0"><a href="${escHtml(input.action.url)}" style="display:inline-block;padding:10px 18px;border-radius:8px;background:#202734;color:#fff;text-decoration:none;font-weight:600">${escHtml(input.action.label)}</a></p>`
      : '') +
    `</div>` +
    `<p style="max-width:600px;margin:14px auto 0;font-size:12px;color:#8c8f94;text-align:center">Sent by Bee Bookings on ${escHtml(input.siteTitle)}</p>` +
    `</body></html>`;
  return { subject: input.subject.replace(/\s+/g, ' ').trim().slice(0, 300), text, html };
}
