/** Bee Bookings extension constants (shared by the API, middleware and public assets). */

export const BOOKINGS_EXTENSION_SLUG = 'bee-bookings';

/** Custom header the public booking script sends; a cross-site HTML form cannot set it. */
export const BOOKINGS_REQUEST_HEADER = 'x-beekiri-booking';

/** Data attribute the Booking element, the shortcode and PHP layouts emit; the site script mounts on it. */
export const BOOKINGS_MOUNT_ATTR = 'data-bee-booking';

/** `[bee_booking]` (optionally `[bee_booking service="…"]`) in any page text becomes the booking widget. */
export const BOOKINGS_SHORTCODE = 'bee_booking';

export const BOOKING_STATUSES = ['pending', 'confirmed', 'completed', 'no_show', 'cancelled'] as const;
export type BookingStatus = (typeof BOOKING_STATUSES)[number];

/** Statuses that keep their time taken on the calendar. */
export const BOOKING_HOLDING: BookingStatus[] = ['pending', 'confirmed', 'completed', 'no_show'];
