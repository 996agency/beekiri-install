import { DAY_KEYS, isClosedOn, type BookingSettings, type WeekHours } from './schema';
import { addDays, clockOf, localParts, minutesOf, weekdayOf, zonedToUtc } from './time';

/**
 * Which start times are free. Pure: the caller loads the staff and the time already taken.
 * A slot is free for a staff member when it lies inside their hours for that weekday, starts
 * far enough ahead, and neither it nor its buffer overlaps anything they already have.
 */

export type StaffHours = { id: string; hours: WeekHours | null; daysOff: { from: string; to: string }[] };
/** Time already taken: an appointment (plus its buffer) or blocked time; `staffId: null` blocks everyone. */
export type Busy = { staffId: string | null; start: number; end: number };
export type Slot = { time: string; startAt: string; staffIds: string[] };

export type SlotQuery = {
  /** Calendar date in the business's time zone. */
  date: string;
  durationMin: number;
  bufferMin: number;
  staff: StaffHours[];
  settings: BookingSettings;
  busy: Busy[];
  now: number;
  /** Admin bookings ignore the notice and how-far-ahead rules (never the calendar). */
  anyTime?: boolean;
};

export function daySlots(q: SlotQuery): Slot[] {
  const { settings, date } = q;
  const tz = settings.timezone;
  if (isClosedOn(settings.closedDates, date)) return [];
  if (!q.anyTime) {
    const today = localParts(q.now, tz).date;
    if (date < today || date > addDays(today, settings.maxDaysAhead)) return [];
  }
  const earliest = q.anyTime ? 0 : q.now + settings.minNoticeHours * 3_600_000;
  const day = DAY_KEYS[weekdayOf(date)];
  const byTime = new Map<string, Slot>();

  for (const person of q.staff) {
    if (isClosedOn(person.daysOff, date)) continue;
    const taken = q.busy.filter((b) => b.staffId === null || b.staffId === person.id);
    for (const interval of (person.hours ?? settings.hours)[day]) {
      const close = minutesOf(interval.to);
      for (let m = minutesOf(interval.from); m + q.durationMin <= close; m += settings.slotStep) {
        const time = clockOf(m);
        const start = zonedToUtc(date, time, tz).getTime();
        if (start < earliest) continue;
        const end = start + (q.durationMin + q.bufferMin) * 60_000;
        if (taken.some((b) => start < b.end && end > b.start)) continue;
        const slot = byTime.get(time);
        if (slot) slot.staffIds.push(person.id);
        else byTime.set(time, { time, startAt: new Date(start).toISOString(), staffIds: [person.id] });
      }
    }
  }
  return [...byTime.values()].sort((a, b) => (a.time < b.time ? -1 : 1));
}

/** The dates of a month (YYYY-MM) that still have at least one free start time. */
export function openDays(month: string, q: Omit<SlotQuery, 'date'>): string[] {
  const out: string[] = [];
  for (let date = `${month}-01`; date.startsWith(month); date = addDays(date, 1)) {
    if (daySlots({ ...q, date }).length) out.push(date);
  }
  return out;
}
