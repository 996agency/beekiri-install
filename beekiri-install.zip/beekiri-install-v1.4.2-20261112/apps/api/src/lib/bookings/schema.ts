import { addDays, isClock, isDate, isTimeZone, minutesOf } from './time';

/** Shapes stored as JSON by Bee Bookings, and the cleaning that turns anything sent into them. */

export const DAY_KEYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'] as const;
export type DayKey = (typeof DAY_KEYS)[number];
export type Interval = { from: string; to: string };
/** Opening hours per weekday; an empty list is a closed day. */
export type WeekHours = Record<DayKey, Interval[]>;
export type DateRange = { from: string; to: string; note: string };

export type BookingSettings = {
  timezone: string;
  /** Business hours; staff follow them unless they have their own. */
  hours: WeekHours;
  /** Start times are offered every this many minutes. */
  slotStep: number;
  /** A booking must be made at least this many hours ahead. */
  minNoticeHours: number;
  /** …and at most this many days ahead. */
  maxDaysAhead: number;
  /** Holidays and other closed days (whole business). */
  closedDates: DateRange[];
  /** New website bookings are confirmed straight away (otherwise they wait for approval). */
  autoConfirm: boolean;
  /** Where "new booking" emails go (empty = the staff member only). */
  notifyEmail: string;
  /** Reminder email this many hours before (0 = none). */
  reminderHours: number;
  /** Customers can cancel from their email until this many hours before (0 = any time). */
  cancelHours: number;
  currency: string;
  /** Shown to the customer: an address, "Online", a room… */
  location: string;
  /** Extra line in the confirmation (what to bring, parking…). */
  confirmationNote: string;
};

const HOURS_9_TO_5: Interval[] = [{ from: '09:00', to: '17:00' }];
export const DEFAULT_HOURS: WeekHours = { sun: [], mon: HOURS_9_TO_5, tue: HOURS_9_TO_5, wed: HOURS_9_TO_5, thu: HOURS_9_TO_5, fri: HOURS_9_TO_5, sat: [] };

const str = (v: unknown, max: number) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const int = (v: unknown, min: number, max: number, fallback: number) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
};

/** Up to four non-overlapping intervals a day, in order. */
function parseIntervals(raw: unknown): Interval[] {
  if (!Array.isArray(raw)) return [];
  const out: Interval[] = [];
  for (const item of raw.slice(0, 8)) {
    const r = item as Partial<Interval> | null;
    if (!r || !isClock(r.from) || !isClock(r.to) || minutesOf(r.to) <= minutesOf(r.from)) continue;
    out.push({ from: r.from, to: r.to });
  }
  out.sort((a, b) => minutesOf(a.from) - minutesOf(b.from));
  return out.filter((iv, i) => i === 0 || minutesOf(iv.from) >= minutesOf(out[i - 1].to)).slice(0, 4);
}

export function parseWeekHours(raw: unknown, fallback: WeekHours | null): WeekHours | null {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return fallback;
  const r = raw as Record<string, unknown>;
  return Object.fromEntries(DAY_KEYS.map((d) => [d, parseIntervals(r[d])])) as WeekHours;
}

export function parseDateRanges(raw: unknown): DateRange[] {
  if (!Array.isArray(raw)) return [];
  const out: DateRange[] = [];
  for (const item of raw.slice(0, 200)) {
    const r = item as Record<string, unknown> | null;
    // A single closed day may come as { date }.
    const from = r && isDate(r.from) ? r.from : r && isDate(r.date) ? r.date : null;
    if (!r || !from) continue;
    const to = isDate(r.to) && r.to >= from ? r.to : from;
    // A range longer than two years is a typo, not a holiday.
    out.push({ from, to: to > addDays(from, 730) ? from : to, note: str(r.note, 120) });
  }
  return out.sort((a, b) => (a.from < b.from ? -1 : 1));
}

export function parseSettings(raw: unknown, fallbackTz: string): BookingSettings {
  const r = (raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {}) as Record<string, unknown>;
  const step = int(r.slotStep, 5, 240, 30);
  return {
    timezone: isTimeZone(r.timezone) ? r.timezone : isTimeZone(fallbackTz) ? fallbackTz : 'UTC',
    hours: parseWeekHours(r.hours, DEFAULT_HOURS) ?? DEFAULT_HOURS,
    slotStep: [5, 10, 15, 20, 30, 45, 60, 90, 120].includes(step) ? step : 30,
    minNoticeHours: int(r.minNoticeHours, 0, 24 * 30, 2),
    maxDaysAhead: int(r.maxDaysAhead, 1, 365, 60),
    closedDates: parseDateRanges(r.closedDates),
    autoConfirm: r.autoConfirm !== false,
    notifyEmail: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str(r.notifyEmail, 200)) ? str(r.notifyEmail, 200) : '',
    reminderHours: int(r.reminderHours, 0, 24 * 14, 24),
    cancelHours: int(r.cancelHours, 0, 24 * 30, 24),
    currency: /^[A-Z]{3}$/.test(str(r.currency, 3).toUpperCase()) ? str(r.currency, 3).toUpperCase() : 'EUR',
    location: str(r.location, 300),
    confirmationNote: str(r.confirmationNote, 1000),
  };
}

export const isClosedOn = (ranges: { from: string; to: string }[], date: string) => ranges.some((r) => r.from <= date && date <= r.to);

/** "€45.00" — or "Free" for 0. */
export function formatPrice(cents: number, currency: string): string {
  if (!cents) return 'Free';
  try {
    return new Intl.NumberFormat('en', { style: 'currency', currency }).format(cents / 100);
  } catch {
    return `${(cents / 100).toFixed(2)} ${currency}`;
  }
}
