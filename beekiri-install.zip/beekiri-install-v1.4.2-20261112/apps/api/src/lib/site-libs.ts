import { existsSync, readFileSync } from 'fs';
import { join } from 'path';
import { brotliCompressSync, constants, gzipSync } from 'zlib';

/**
 * Animation libraries Beekiri ships to sites: GSAP (with its plugins) and Three.js. A layout's
 * script.js asks for them — Beekiri.use('gsap', 'ScrollTrigger'), Beekiri.use('three') — and they
 * load from the site's own server, only on the pages that ask. Nothing comes from a CDN.
 * The files live in apps/api/vendor/libs; scripts/vendor-libs.mjs refreshes them.
 */

const LIBS_DIR = join(__dirname, '..', '..', 'vendor', 'libs');

type Versions = { gsap: string; three: string; gsapPlugins: string[] };

let versions: Versions | null | undefined;
const files = new Map<string, Buffer | null>();
/** Each file compressed once per encoding (Three.js is 750 KB: not something to redo per request). */
const packed = new Map<string, Buffer>();

/** What ships with this Beekiri (null when the vendor folder is missing). */
export function siteLibVersions(): Versions | null {
  if (versions === undefined) {
    try {
      versions = JSON.parse(readFileSync(join(LIBS_DIR, 'versions.json'), 'utf8')) as Versions;
    } catch {
      versions = null;
    }
  }
  return versions;
}

/** One library file by its public name, or null when Beekiri doesn't ship it. */
export function readSiteLib(lib: string, file: string): Buffer | null {
  const v = siteLibVersions();
  if (!v) return null;
  const known =
    lib === 'gsap'
      ? ['gsap', ...v.gsapPlugins].some((name) => file === `${name}.min.js`)
      : lib === 'three' && file === 'three.module.min.js';
  if (!known) return null;
  const key = `${lib}/${file}`;
  if (!files.has(key)) {
    const path = join(LIBS_DIR, lib, file);
    files.set(key, existsSync(path) ? readFileSync(path) : null);
  }
  return files.get(key) ?? null;
}

/** A library file ready to send: brotli or gzip when the browser takes it. */
export function packedSiteLib(lib: string, file: string, acceptEncoding: string): { body: Buffer; encoding: 'br' | 'gzip' | null } | null {
  const raw = readSiteLib(lib, file);
  if (!raw) return null;
  const encoding = /\bbr\b/.test(acceptEncoding) ? 'br' : /\bgzip\b/.test(acceptEncoding) ? 'gzip' : null;
  if (!encoding) return { body: raw, encoding };
  const key = `${encoding}:${lib}/${file}`;
  let body = packed.get(key);
  if (!body) {
    body =
      encoding === 'br'
        ? brotliCompressSync(raw, { params: { [constants.BROTLI_PARAM_QUALITY]: 9, [constants.BROTLI_PARAM_SIZE_HINT]: raw.length } })
        : gzipSync(raw, { level: 9 });
    packed.set(key, body);
  }
  return { body, encoding };
}

/**
 * The script that gives every page Beekiri.use(): it resolves with the libraries asked for,
 * e.g. { gsap, ScrollTrigger } or { THREE }, loading each file once. The website prints it inline
 * (with Beekiri.libsUrl set to this API), so it costs no request.
 */
export function siteLibsLoader(): string {
  const v = siteLibVersions();
  if (!v) return '';
  return `(function(){
var B=window.Beekiri=window.Beekiri||{};
if(B.use)return;
var base=B.libsUrl||'/api/libs',V=${JSON.stringify({ gsap: v.gsap, three: v.three })},P=${JSON.stringify(v.gsapPlugins)},loading={};
function script(src){return new Promise(function(done,fail){var s=document.createElement('script');s.src=src;s.onload=function(){done()};s.onerror=function(){fail(new Error('Beekiri.use: could not load '+src))};document.head.appendChild(s)})}
function gsapFile(name){return base+'/gsap/'+name+'.min.js?v='+V.gsap}
function fetchLib(name){
if(name==='three')return import(base+'/three/three.module.min.js?v='+V.three);
if(name==='gsap')return window.gsap?Promise.resolve(window.gsap):script(gsapFile('gsap')).then(function(){return window.gsap});
if(P.indexOf(name)>-1)return load('gsap').then(function(gsap){return(window[name]?Promise.resolve():script(gsapFile(name))).then(function(){gsap.registerPlugin(window[name]);return window[name]})});
return Promise.reject(new Error('Beekiri.use: there is no library called "'+name+'"'));
}
function load(name){
if(!loading[name])loading[name]=fetchLib(name).catch(function(error){delete loading[name];throw error});
return loading[name];
}
B.use=function(){
var names=Array.prototype.slice.call(arguments);
return Promise.all(names.map(load)).then(function(found){var out={};names.forEach(function(name,i){out[name==='three'?'THREE':name]=found[i]});return out});
};
B.libs=V;
})();`;
}
