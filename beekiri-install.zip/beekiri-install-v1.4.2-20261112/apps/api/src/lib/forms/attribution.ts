/**
 * Where a form entry came from. The site script records the landing page, referrer, UTM tags
 * and ad click ids of the visit (and of the first visit, with consent); this turns them into a
 * channel and a readable source. Pure; no I/O.
 */

export const UTM_KEYS = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'utm_id'] as const;

/** Ad click ids → the network that added them, and whether they always mean a paid click. */
export const CLICK_IDS: Record<string, { network: string; paid: boolean; kind: 'search' | 'social' | 'display' }> = {
  gclid: { network: 'Google Ads', paid: true, kind: 'search' },
  gbraid: { network: 'Google Ads', paid: true, kind: 'search' },
  wbraid: { network: 'Google Ads', paid: true, kind: 'search' },
  dclid: { network: 'Google Display', paid: true, kind: 'display' },
  msclkid: { network: 'Microsoft Ads', paid: true, kind: 'search' },
  li_fat_id: { network: 'LinkedIn Ads', paid: true, kind: 'social' },
  ttclid: { network: 'TikTok Ads', paid: true, kind: 'social' },
  twclid: { network: 'X Ads', paid: true, kind: 'social' },
  epik: { network: 'Pinterest Ads', paid: true, kind: 'social' },
  sccid: { network: 'Snapchat Ads', paid: true, kind: 'social' },
  // Facebook adds fbclid to every outbound link, paid or not.
  fbclid: { network: 'Meta', paid: false, kind: 'social' },
};

/** One visit as the browser saw it. */
export type Touch = {
  landingUrl?: string;
  referrer?: string;
  at?: number;
  params?: Record<string, string>;
};

export type Channel =
  | 'Paid search'
  | 'Paid social'
  | 'Display'
  | 'Paid'
  | 'Organic search'
  | 'Social'
  | 'Email'
  | 'Affiliate'
  | 'Referral'
  | 'Campaign'
  | 'Direct';

export type Attribution = {
  channel: Channel;
  /** Readable source, e.g. "Google Ads", "LinkedIn", "newsletter", "example.com". */
  source: string;
  medium: string;
  campaign: string;
  term: string;
  content: string;
  /** Ad click id parameter present on the landing URL (gclid, li_fat_id…), if any. */
  clickId: string;
  /** Landing page (path + query) and external referrer of this touch. */
  landingPage: string;
  referrer: string;
  referrerHost: string;
  at: string | null;
};

const SEARCH: Record<string, string> = {
  google: 'Google',
  bing: 'Bing',
  yahoo: 'Yahoo',
  duckduckgo: 'DuckDuckGo',
  yandex: 'Yandex',
  baidu: 'Baidu',
  ecosia: 'Ecosia',
  brave: 'Brave Search',
  qwant: 'Qwant',
  startpage: 'Startpage',
  perplexity: 'Perplexity',
  chatgpt: 'ChatGPT',
};

const SOCIAL: Record<string, string> = {
  facebook: 'Facebook',
  fb: 'Facebook',
  'm.facebook': 'Facebook',
  'l.facebook': 'Facebook',
  'lm.facebook': 'Facebook',
  instagram: 'Instagram',
  'l.instagram': 'Instagram',
  linkedin: 'LinkedIn',
  lnkd: 'LinkedIn',
  twitter: 'X',
  x: 'X',
  't.co': 'X',
  reddit: 'Reddit',
  pinterest: 'Pinterest',
  tiktok: 'TikTok',
  youtube: 'YouTube',
  'youtu.be': 'YouTube',
  whatsapp: 'WhatsApp',
  telegram: 'Telegram',
  threads: 'Threads',
  snapchat: 'Snapchat',
  meta: 'Meta',
};

const PRETTY_SOURCE: Record<string, string> = { ...SEARCH, ...SOCIAL, fb: 'Facebook', ig: 'Instagram', li: 'LinkedIn', tw: 'X', yt: 'YouTube', mailchimp: 'Mailchimp', newsletter: 'Newsletter' };

const PAID_MEDIUMS = new Set(['cpc', 'ppc', 'paid', 'paidsearch', 'paid_search', 'paid-search', 'sem', 'cpm', 'cpv', 'cpa', 'paid_social', 'paid-social', 'paidsocial', 'ads', 'ad', 'sponsored']);
const DISPLAY_MEDIUMS = new Set(['display', 'banner', 'cpm', 'programmatic', 'video']);
const EMAIL_MEDIUMS = new Set(['email', 'e-mail', 'e_mail', 'newsletter', 'mail']);
const SOCIAL_MEDIUMS = new Set(['social', 'social-network', 'social_network', 'social-media', 'sm', 'organic_social', 'social media']);

const clean = (v: unknown, max = 300): string => (typeof v === 'string' ? v.trim().slice(0, max) : '');

/** google.co.uk → "google", l.facebook.com → "l.facebook", t.co → "t.co" */
function hostKey(host: string): string {
  const h = host.toLowerCase().replace(/^www\./, '');
  if (h === 't.co' || h === 'youtu.be' || h === 'lnkd.in') return h === 'lnkd.in' ? 'lnkd' : h;
  const parts = h.split('.');
  const tld2 = parts.length >= 3 && ['co', 'com', 'org', 'net', 'ac', 'gov'].includes(parts[parts.length - 2]);
  const core = parts.slice(0, tld2 ? -2 : -1);
  if (!core.length) return h;
  const last = core[core.length - 1];
  const sub = core.length > 1 ? `${core[core.length - 2]}.${last}` : '';
  if (sub && (sub in SOCIAL || sub in SEARCH)) return sub;
  return last;
}

export function hostOf(url: string): string {
  try {
    return new URL(url).hostname.toLowerCase().replace(/^www\./, '');
  } catch {
    return '';
  }
}

function prettySource(raw: string): string {
  const key = raw.toLowerCase();
  if (PRETTY_SOURCE[key]) return PRETTY_SOURCE[key];
  const fromHost = hostKey(key);
  return PRETTY_SOURCE[fromHost] ?? raw;
}

/** `raw` when it is an absolute http(s) address, else '' (the admin shows these as links). */
export function webUrl(raw: string): string {
  try {
    return /^https?:$/.test(new URL(raw).protocol) ? raw : '';
  } catch {
    return '';
  }
}

/** Bounded, cleaned copy of what the browser sent (never trust its shape). */
export function parseTouch(raw: unknown): Touch | null {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const r = raw as Record<string, unknown>;
  const params: Record<string, string> = {};
  if (r.params && typeof r.params === 'object' && !Array.isArray(r.params)) {
    for (const [k, v] of Object.entries(r.params as Record<string, unknown>)) {
      const key = k.toLowerCase();
      if ((UTM_KEYS as readonly string[]).includes(key) || key in CLICK_IDS) {
        const val = clean(v, key in CLICK_IDS ? 200 : 300);
        if (val) params[key] = val;
      }
    }
  }
  const at = typeof r.at === 'number' && Number.isFinite(r.at) ? r.at : undefined;
  const touch: Touch = {
    landingUrl: webUrl(clean(r.landingUrl, 2000)),
    referrer: webUrl(clean(r.referrer, 2000)),
    at,
    params,
  };
  if (!touch.landingUrl && !touch.referrer && !Object.keys(params).length) return null;
  return touch;
}

/** Channel + source for one touch. `siteHost` stops the site's own pages counting as referrals. */
export function attributionOf(touch: Touch | null, siteHost = ''): Attribution {
  const p = touch?.params ?? {};
  const referrer = clean(touch?.referrer, 2000);
  let referrerHost = referrer ? hostOf(referrer) : '';
  const own = siteHost.toLowerCase().replace(/^www\./, '');
  if (referrerHost && own && (referrerHost === own || referrerHost.endsWith(`.${own}`))) referrerHost = '';
  const landingPage = (() => {
    const u = clean(touch?.landingUrl, 2000);
    if (!u) return '';
    try {
      const url = new URL(u);
      return `${url.pathname}${url.search}`.slice(0, 2000);
    } catch {
      return u;
    }
  })();

  const base = {
    medium: p.utm_medium ?? '',
    campaign: p.utm_campaign ?? '',
    term: p.utm_term ?? '',
    content: p.utm_content ?? '',
    landingPage,
    referrer: referrerHost ? referrer : '',
    referrerHost,
    at: touch?.at && Number.isFinite(touch.at) && Math.abs(touch.at) < 8.64e15 ? new Date(touch.at).toISOString() : null,
  };
  const medium = base.medium.toLowerCase();
  const utmSource = p.utm_source ?? '';
  const clickKey = Object.keys(CLICK_IDS).find((k) => p[k]) ?? '';
  const click = clickKey ? CLICK_IDS[clickKey] : null;
  const isSearchName = (s: string) => hostKey(s.toLowerCase()) in SEARCH || s.toLowerCase() in SEARCH;
  const isSocialName = (s: string) => hostKey(s.toLowerCase()) in SOCIAL || s.toLowerCase() in SOCIAL;
  const out = (channel: Channel, source: string): Attribution => ({ channel, source, clickId: clickKey, ...base });

  // 1. Ad click ids are the strongest signal.
  if (click && (click.paid || PAID_MEDIUMS.has(medium))) {
    const channel: Channel = click.kind === 'search' ? 'Paid search' : click.kind === 'display' ? 'Display' : 'Paid social';
    return out(channel, click.network === 'Meta' ? 'Meta Ads' : click.network);
  }

  // 2. UTM tags.
  if (utmSource || medium) {
    const source = utmSource ? prettySource(utmSource) : referrerHost || 'Unknown';
    if (EMAIL_MEDIUMS.has(medium) || /mail|newsletter/i.test(utmSource) && !medium) return out('Email', source);
    if (DISPLAY_MEDIUMS.has(medium) && !PAID_MEDIUMS.has(medium)) return out('Display', source);
    if (PAID_MEDIUMS.has(medium) || /paid|cpc|ppc/.test(medium)) {
      if (isSearchName(utmSource)) return out('Paid search', source === 'Google' ? 'Google Ads' : source === 'Bing' ? 'Microsoft Ads' : `${source} Ads`);
      if (isSocialName(utmSource) || /social/.test(medium)) return out('Paid social', /Ads$/.test(source) ? source : `${source} Ads`);
      if (medium === 'cpm') return out('Display', source);
      return out('Paid', source);
    }
    if (medium === 'affiliate' || medium === 'partner') return out('Affiliate', source);
    if (SOCIAL_MEDIUMS.has(medium) || (!medium && isSocialName(utmSource))) return out('Social', source);
    if (medium === 'organic' && isSearchName(utmSource)) return out('Organic search', source);
    if (medium === 'referral') return out('Referral', source);
    return out('Campaign', source);
  }

  // 3. fbclid without paid tags: a Facebook/Instagram link.
  if (click) return out('Social', referrerHost ? prettySource(referrerHost) : 'Facebook');

  // 4. Referrer.
  if (referrerHost) {
    const key = hostKey(referrerHost);
    if (key in SEARCH || referrerHost.startsWith('google.')) return out('Organic search', SEARCH[key] ?? 'Google');
    if (key in SOCIAL) return out('Social', SOCIAL[key]);
    if (/mail\.|outlook\.|webmail/.test(referrerHost)) return out('Email', referrerHost);
    return out('Referral', referrerHost);
  }

  return out('Direct', 'Direct');
}

/** Short label for lists: "Google Ads", "LinkedIn", "Direct"… */
export function sourceLabel(a: Pick<Attribution, 'channel' | 'source'> | null | undefined): string {
  if (!a) return '';
  return a.source || a.channel;
}
