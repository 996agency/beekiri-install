import type { EntryValues } from './conditions';
import { valueFields, type FormField } from './schema';

/**
 * Made-up answers for a form, so an email can be previewed (and a test sent) before anyone has
 * filled the form in. Shaped exactly like stored entry values.
 */
export function sampleValues(fields: FormField[], pageUrl: string): EntryValues {
  const values: EntryValues = {};
  for (const f of valueFields(fields)) {
    const options = f.options ?? [];
    const key = `${f.name} ${f.label}`.toLowerCase();
    switch (f.type) {
      case 'email':
        values[f.id] = 'alex.morgan@example.com';
        break;
      case 'phone':
        values[f.id] = '+44 20 7946 0123';
        break;
      case 'url':
        values[f.id] = 'https://example.com';
        break;
      case 'number':
        values[f.id] = f.min || '3';
        break;
      case 'date':
        values[f.id] = new Date().toISOString().slice(0, 10);
        break;
      case 'textarea':
        values[f.id] = 'Hello, I would like to know more about what you offer.\nCould you get back to me this week?';
        break;
      case 'checkbox':
        values[f.id] = options.slice(0, 2).map((o) => o.value);
        break;
      case 'select':
        values[f.id] = f.multiple ? options.slice(0, 2).map((o) => o.value) : (options[0]?.value ?? '');
        break;
      case 'radio':
        values[f.id] = options[0]?.value ?? '';
        break;
      case 'consent':
        values[f.id] = 'Yes';
        break;
      case 'file':
        values[f.id] = [{ id: 'sample', name: 'brief.pdf', mime: 'application/pdf', size: 248_000 }];
        break;
      case 'hidden':
        values[f.id] = f.hiddenSource && f.hiddenSource !== 'static' ? pageUrl : (f.defaultValue ?? '');
        break;
      default:
        values[f.id] = /company|business|organi[sz]ation/.test(key)
          ? 'Northwind Studio'
          : /name/.test(key)
            ? /last|surname/.test(key)
              ? 'Morgan'
              : /first/.test(key)
                ? 'Alex'
                : 'Alex Morgan'
            : /subject|topic/.test(key)
              ? 'A question about your services'
              : /phone|mobile/.test(key)
                ? '+44 20 7946 0123'
                : f.defaultValue || 'Sample answer';
    }
  }
  return values;
}
