import { answeredFields, isFileList, mergeText, resolveTag, type MergeContext } from './merge';
import { escHtml } from './render';
import { defaultEmailDesign, type FormEmailDesign } from './schema';

export type RenderedFormEmail = { subject: string; text: string; html: string };

const FONT = "-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";
const INK = '#202734';
const MUTED = '#646970';
const LINE = '#e3e5e8';

/** Relative luminance of a #rgb / #rrggbb colour (0 = black, 1 = white). */
function luminance(hex: string): number {
  const h = hex.replace('#', '');
  const full = h.length === 3 ? h.replace(/./g, '$&$&') : h;
  const [r, g, b] = [0, 2, 4].map((i) => {
    const c = parseInt(full.slice(i, i + 2), 16) / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** Links take the accent colour, unless it is too pale to read on the white card. */
const linkColor = (accent: string) => (1.05 / (luminance(accent) + 0.05) >= 4.5 ? accent : INK);

const TAG = /\{([a-z_]+)(?::([a-z0-9_]+))?\}/gi;
/** Where a merged value goes, kept out of the way while the owner's own text is formatted. */
const slot = (i: number) => `\u0000${i}\u0000`;
const SLOT = /\u0000(\d+)\u0000/g;
const FORMAT = /\*\*([^*\n]+)\*\*|\[([^\]\n]+)\]\(([^)\s]+)\)/g;

/** {all_fields}: one row per answer, label beside value. */
function fieldsTable(ctx: MergeContext, accent: string): string {
  const rows = answeredFields(ctx)
    .map((r, i) => {
      const value =
        isFileList(r.value) && ctx.fileUrl
          ? r.value.map((f) => `<a href="${escHtml(ctx.fileUrl!(f))}" style="color:${accent}">${escHtml(f.name)}</a>`).join('<br>')
          : escHtml(r.text).replace(/\n/g, '<br>');
      const edge = i ? `border-top:1px solid ${LINE};` : '';
      return (
        `<tr><td width="34%" style="${edge}padding:10px 16px 10px 0;color:${MUTED};font-size:13px;line-height:1.5;vertical-align:top">${escHtml(r.field.label)}</td>` +
        `<td style="${edge}padding:10px 0;color:${INK};font-size:14px;line-height:1.5;vertical-align:top;word-break:break-word">${value}</td></tr>`
      );
    })
    .join('');
  return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin:4px 0 18px;border-top:1px solid ${LINE};border-bottom:1px solid ${LINE}">${rows}</table>`;
}

/**
 * The message as HTML. The owner's text may use **bold**, [a link](https://…), lines that start
 * with # or ## (headings) and --- (a line). Only their text is formatted: what a visitor typed is
 * merged in afterwards, always as plain text, so an answer can never add a link or markup.
 */
export function messageHtml(template: string, ctx: MergeContext, accent: string): string {
  const html: string[] = [];
  const plain: string[] = [];
  const tables = new Set<string>();
  const source = template.replace(/\u0000/g, '').replace(TAG, (m, tag: string, arg?: string) => {
    const found = resolveTag(tag, arg, ctx);
    if (!found) return m;
    const all = 'all' in found;
    html.push(all ? fieldsTable(ctx, accent) : escHtml(found.text).replace(/\n/g, '<br>'));
    plain.push(all ? '' : found.text);
    const mark = slot(html.length - 1);
    if (all) tables.add(mark);
    return mark;
  });

  const inline = (text: string) => {
    let out = '';
    let last = 0;
    for (const m of text.matchAll(FORMAT)) {
      out += escHtml(text.slice(last, m.index));
      if (m[1] !== undefined) {
        out += `<strong>${escHtml(m[1])}</strong>`;
      } else {
        // A link may point at a tag ({page_url}); whatever it resolves to must be a web or mail address.
        const url = m[3].replace(SLOT, (_, i: string) => plain[Number(i)] ?? '').trim();
        out += /^(https?:\/\/|mailto:)[^\s"'<>]+$/i.test(url)
          ? `<a href="${escHtml(url)}" style="color:${accent};text-decoration:underline">${escHtml(m[2])}</a>`
          : escHtml(m[2]);
      }
      last = m.index + m[0].length;
    }
    return out + escHtml(text.slice(last));
  };

  const blocks: string[] = [];
  let paragraph: string[] = [];
  const flush = () => {
    if (paragraph.length) blocks.push(`<p style="margin:0 0 14px">${paragraph.join('<br>')}</p>`);
    paragraph = [];
  };
  for (const raw of source.split(/\r?\n/)) {
    const line = raw.trim();
    const heading = line.match(/^(#{1,2})\s+(.+)$/);
    if (!line) flush();
    else if (tables.has(line)) {
      flush();
      blocks.push(line);
    } else if (heading) {
      flush();
      const big = heading[1].length === 1;
      blocks.push(`<h2 style="margin:${blocks.length ? '22px' : '0'} 0 10px;font-size:${big ? 22 : 17}px;line-height:1.3;font-weight:650;color:${INK}">${inline(heading[2])}</h2>`);
    } else if (/^-{3,}$/.test(line)) {
      flush();
      blocks.push(`<hr style="border:0;border-top:1px solid ${LINE};margin:20px 0">`);
    } else {
      paragraph.push(inline(line));
    }
  }
  flush();
  return blocks.join('').replace(SLOT, (_, i: string) => html[Number(i)] ?? '');
}

/** The plain-text version: the same message without the formatting marks. */
export function messageText(template: string, ctx: MergeContext): string {
  const bare = template
    .replace(/\*\*([^*\n]+)\*\*/g, '$1')
    .replace(/\[([^\]\n]+)\]\(([^)\s]+)\)/g, (_, label: string, url: string) => (label === url ? url : `${label} (${url})`))
    .replace(/^#{1,2}\s+/gm, '')
    .replace(/^-{3,}$/gm, '----------');
  return mergeText(bare, ctx);
}

/**
 * A form email: the merged message inside the form's own look (logo or site title, accent bar,
 * footer). `logoSrc` is what the logo image points at — a cid: for mail that carries the picture,
 * a web address otherwise.
 */
export function renderFormEmail(
  subject: string,
  message: string,
  ctx: MergeContext,
  design: FormEmailDesign = defaultEmailDesign(),
  logoSrc = '',
): RenderedFormEmail {
  const mergedSubject = mergeText(subject, ctx).replace(/\s+/g, ' ').trim().slice(0, 300);
  const centred = design.align === 'center';
  // The small print sits on the page colour: light on a dark page, grey on a light one.
  const footerColor = luminance(design.background) < 0.3 ? '#c9ccd1' : '#6b6f76';
  const head = logoSrc
    ? `<img src="${escHtml(logoSrc)}" width="${design.logoWidth}" alt="${escHtml(ctx.siteTitle)}" style="display:block;${centred ? 'margin:0 auto;' : ''}width:${design.logoWidth}px;max-width:100%;height:auto;border:0;outline:none;text-decoration:none">`
    : `<p style="margin:0;font-size:12px;letter-spacing:.04em;text-transform:uppercase;color:#8c8f94">${escHtml(ctx.siteTitle)}</p>`;
  const footer = mergeText(design.footer, ctx).trim();
  const html =
    `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light only"><title>${escHtml(mergedSubject)}</title></head>` +
    `<body style="margin:0;padding:0;background:${design.background};font-family:${FONT}">` +
    `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:${design.background}"><tr><td align="center" style="padding:28px 16px">` +
    `<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="width:100%;max-width:600px;background:#ffffff;border:1px solid ${LINE};border-radius:8px;border-collapse:separate;overflow:hidden">` +
    `<tr><td style="height:4px;line-height:4px;font-size:0;background:${design.accent}">&nbsp;</td></tr>` +
    `<tr><td align="${centred ? 'center' : 'left'}" style="padding:26px 32px 0">${head}</td></tr>` +
    `<tr><td style="padding:22px 32px 18px;font-family:${FONT};color:${INK};font-size:15px;line-height:1.6">${messageHtml(message, ctx, linkColor(design.accent))}</td></tr>` +
    `</table>` +
    (footer
      ? `<p style="max-width:600px;margin:14px auto 0;font-family:${FONT};font-size:12px;line-height:1.5;color:${footerColor};text-align:center">${escHtml(footer).replace(/\n/g, '<br>')}</p>`
      : '') +
    `</td></tr></table></body></html>`;
  return { subject: mergedSubject, text: messageText(message, ctx), html };
}
