/**
 * Merge tags for notifications, auto-replies and confirmations:
 *   {field:name}  a field's value        {all_fields}  every answered field
 *   {form_title}  {entry_id}  {date}  {page_url}  {site_title}  {admin_email}
 */
import type { EntryValues } from './conditions';
import { escHtml } from './render';
import { valueFields, type FormField } from './schema';

export type MergeContext = {
  formTitle: string;
  fields: FormField[];
  values: EntryValues;
  entryId: string;
  pageUrl: string;
  siteTitle: string;
  adminEmail: string;
  date: Date;
  /** Builds a link to a stored file for the HTML version (admin download URL). */
  fileUrl?: (file: StoredFile) => string;
};

/** What a `{tag}` stands for: its text, every answered field, or null when it is not a tag. */
export function resolveTag(tag: string, arg: string | undefined, ctx: MergeContext): { text: string } | { all: true } | null {
  const t = tag.toLowerCase();
  if (t === 'field' && arg) {
    const f = ctx.fields.find((x) => x.name === arg.toLowerCase());
    return { text: f ? valueText(ctx.values[f.id]) : '' };
  }
  if (t === 'all_fields') return { all: true };
  const simple = simpleTags(ctx);
  return t in simple ? { text: simple[t] } : null;
}

export type StoredFile = { id: string; name: string; mime: string; size: number };

export const isFileList = (v: unknown): v is StoredFile[] =>
  Array.isArray(v) && v.every((x) => x && typeof x === 'object' && typeof (x as StoredFile).name === 'string');

/** Plain-text rendering of one value. */
export function valueText(v: unknown): string {
  if (v == null) return '';
  if (isFileList(v)) return v.map((f) => f.name).join(', ');
  if (Array.isArray(v)) return v.map((x) => String(x)).join(', ');
  return String(v);
}

export function answeredFields(ctx: MergeContext): { field: FormField; value: unknown; text: string }[] {
  return valueFields(ctx.fields)
    .map((field) => ({ field, value: ctx.values[field.id], text: valueText(ctx.values[field.id]) }))
    .filter((r) => r.text !== '');
}

function allFieldsText(ctx: MergeContext): string {
  return answeredFields(ctx)
    .map((r) => `${r.field.label}: ${r.text}`)
    .join('\n');
}

function allFieldsHtml(ctx: MergeContext): string {
  const rows = answeredFields(ctx)
    .map((r) => {
      let value: string;
      if (isFileList(r.value) && ctx.fileUrl) {
        value = r.value.map((f) => `<a href="${escHtml(ctx.fileUrl!(f))}">${escHtml(f.name)}</a>`).join('<br>');
      } else {
        value = escHtml(r.text).replace(/\n/g, '<br>');
      }
      return `<tr><td style="padding:6px 12px 6px 0;color:#646970;vertical-align:top;white-space:nowrap">${escHtml(r.field.label)}</td><td style="padding:6px 0;color:#202734;vertical-align:top">${value}</td></tr>`;
    })
    .join('');
  return `<table role="presentation" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-size:14px;line-height:1.5">${rows}</table>`;
}

function simpleTags(ctx: MergeContext): Record<string, string> {
  return {
    form_title: ctx.formTitle,
    entry_id: ctx.entryId,
    date: ctx.date.toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }),
    page_url: ctx.pageUrl,
    site_title: ctx.siteTitle,
    admin_email: ctx.adminEmail,
  };
}

/** Plain text with every tag replaced. Unknown tags are left as written. */
export function mergeText(template: string, ctx: MergeContext): string {
  const simple = simpleTags(ctx);
  const byName = new Map(ctx.fields.map((f) => [f.name, f]));
  return template.replace(/\{([a-z_]+)(?::([a-z0-9_]+))?\}/gi, (m, tag: string, arg?: string) => {
    const t = tag.toLowerCase();
    if (t === 'field' && arg) {
      const f = byName.get(arg.toLowerCase());
      return f ? valueText(ctx.values[f.id]) : '';
    }
    if (t === 'all_fields') return allFieldsText(ctx);
    if (t in simple) return simple[t];
    return m;
  });
}

/** HTML version: text escaped, newlines kept, {all_fields} as a table, file names linked. */
export function mergeHtml(template: string, ctx: MergeContext): string {
  const simple = simpleTags(ctx);
  const byName = new Map(ctx.fields.map((f) => [f.name, f]));
  const marker = '\u0000ALL\u0000';
  const withPlaceholders = template.replace(/\{([a-z_]+)(?::([a-z0-9_]+))?\}/gi, (m, tag: string, arg?: string) => {
    const t = tag.toLowerCase();
    if (t === 'field' && arg) {
      const f = byName.get(arg.toLowerCase());
      return f ? valueText(ctx.values[f.id]) : '';
    }
    if (t === 'all_fields') return marker;
    if (t in simple) return simple[t];
    return m;
  });
  return escHtml(withPlaceholders)
    .replace(/\n/g, '<br>')
    .split(marker)
    .join(allFieldsHtml(ctx));
}

/** Comma/semicolon separated recipients after merging; invalid ones dropped. */
export function mergeRecipients(template: string, ctx: MergeContext): string[] {
  return [...new Set(
    mergeText(template, ctx)
      .split(/[,;\n]/)
      .map((s) => s.trim())
      .filter((s) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s)),
  )].slice(0, 10);
}
