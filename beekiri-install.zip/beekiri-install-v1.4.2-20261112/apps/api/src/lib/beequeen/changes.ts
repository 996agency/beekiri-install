import { existsSync, mkdirSync, readFileSync, unlinkSync, writeFileSync } from 'fs';
import type { AuthUser } from '../../types/auth';
import { dirname, join } from 'path';
import { col, fn, literal, Op } from 'sequelize';
import { hasPending, keepPending } from '../pages/pending';
import { placementOf, SITE_SECTION_KIND } from '../pages/site-sections';
import { sectionPreview } from './section-preview';
import { BeeQueenChange, BeeQueenChat, FieldGroup, MediaAsset, Post, PostType, Taxonomy, User } from '../../models';
import { parseContent } from '../pages/pages.content';
import type { BeeQueenChangeKind } from '../../models/beequeen-change.model';
import { fieldsService } from '../../services/fields.service';
import { layoutSyncService } from '../../services/layout-sync.service';
import { mediaService } from '../../services/media.service';
import { pagesService } from '../../services/pages.service';
import { productsService } from '../../services/shop/products.service';
import { structureService } from '../../services/structure.service';
import { BadRequest, Conflict, NotFound } from '../../utils/http-error';
import { revalidatePublicPaths } from '../revalidate-public';
import { resolveThemesRoot } from '../themes/theme-registry';

/**
 * Beekiri's change history: every theme file, layout, page and taxonomy the agent changes is
 * recorded with its before/after, so the owner can revert one change or a whole message from the
 * Connector page. Reverting never deletes for good: created pages and layouts go to the trash.
 */

export type ChangeContext = {
  actor: AuthUser;
  runId: string;
  chatId: string | null;
  /** The owner's message that led to it. */
  prompt?: string;
  /** Told when a page (post, entry) was saved, so a page editor holding it open can show the new version. */
  onPage?: (pageId: string) => void;
};

type FileMap = Record<string, string | null>;

const readOrNull = (abs: string) => (existsSync(abs) ? readFileSync(abs, 'utf8') : null);

function writeOrRemove(abs: string, content: string | null) {
  if (content === null) {
    if (existsSync(abs)) unlinkSync(abs);
    return;
  }
  mkdirSync(dirname(abs), { recursive: true });
  writeFileSync(abs, content, 'utf8');
}

/* ── Snapshots ───────────────────────────────────────────────────────────── */

export const snapshots = {
  themeFile(theme: string, rel: string) {
    return { content: readOrNull(join(resolveThemesRoot(), theme, rel)) };
  },

  /** The layout's own files, keyed by theme-relative path. */
  layoutFiles(theme: string, files: string[]): FileMap {
    const root = resolveThemesRoot();
    return Object.fromEntries(files.map((rel) => [rel, readOrNull(join(root, theme, rel))]));
  },

  async fieldGroup(siteId: string, key: string) {
    const g = await FieldGroup.findOne({ where: { siteId, key, trashedAt: null } });
    return g
      ? { id: g.id, title: g.title, description: g.description, fields: g.fields, active: g.active, location: g.location }
      : null;
  },

  /** A page, or a blog post (kind "post", which also keeps its excerpt and photo). */
  async page(actor: AuthUser, id: string, kind: string = 'page') {
    const p = await pagesService.get(actor, id, kind);
    return {
      title: p.title,
      slug: p.slug,
      status: p.status,
      beekiricode: p.beekiricode ?? null,
      ...(kind === 'post' ? { excerpt: p.excerpt, featuredImageId: p.featuredImageId ?? null } : {}),
    };
  },

  /** A shop product as save_product changes it (prices in minor units, variations with ids). */
  async product(actor: AuthUser, id: string) {
    try {
      const p = await productsService.get(actor, id);
      const { id: _commerceId, gallery: _gallery, totalSales: _sales, ...commerce } = p.commerce;
      return {
        title: p.title,
        status: p.status,
        description: p.description,
        shortDescription: p.shortDescription,
        featuredImageId: p.featuredImageId ?? '',
        categoryIds: p.categoryIds,
        commerce,
        variants: p.variants.map((v) => ({
          id: v.id,
          sku: v.sku,
          attributes: v.attributes,
          regularPrice: v.regularPrice,
          salePrice: v.salePrice,
          manageStock: v.manageStock,
          stockQty: v.stockQty,
          stockStatus: v.stockStatus,
          imageId: v.imageId,
          enabled: v.enabled,
        })),
      };
    } catch {
      return null;
    }
  },

  async postType(siteId: string, id: string) {
    const t = await PostType.findOne({ where: { id, siteId } });
    return t
      ? {
          slug: t.slug,
          singular: t.singular,
          plural: t.plural,
          description: t.description,
          public: t.public,
          hierarchical: t.hierarchical,
          hasArchive: t.hasArchive,
          showInMenu: t.showInMenu,
          supports: t.supports,
          active: t.active,
          menuIcon: t.menuIcon,
        }
      : null;
  },

  async taxonomy(siteId: string, id: string) {
    const t = await Taxonomy.findOne({ where: { id, siteId } });
    return t
      ? {
          slug: t.slug,
          singular: t.singular,
          plural: t.plural,
          description: t.description,
          hierarchical: t.hierarchical,
          public: t.public,
          objectTypes: t.objectTypes,
          active: t.active,
        }
      : null;
  },
};

export async function recordChange(
  ctx: ChangeContext | undefined,
  change: { kind: BeeQueenChangeKind; label: string; target: Record<string, unknown>; before: unknown; after: unknown },
) {
  if (!ctx) return;
  await BeeQueenChange.create({
    siteId: ctx.actor.siteId,
    userId: ctx.actor.id,
    chatId: ctx.chatId,
    runId: ctx.runId,
    kind: change.kind,
    label: change.label,
    target: { ...change.target, ...(ctx.prompt ? { prompt: ctx.prompt.slice(0, 160) } : {}) } as never,
    before: (change.before ?? null) as never,
    after: (change.after ?? null) as never,
  });
  if (change.kind === 'page' && typeof change.target.pageId === 'string') ctx.onPage?.(change.target.pageId);
}

/* ── History ─────────────────────────────────────────────────────────────── */

const RUNS_PER_PAGE = 10;

/** Where a history period starts: today, this week (from Monday), this month, or all time. */
export function periodStart(period: 'today' | 'week' | 'month' | 'all', now = new Date()): Date | null {
  const d = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (period === 'today') return d;
  if (period === 'week') return new Date(d.getFullYear(), d.getMonth(), d.getDate() - ((d.getDay() + 6) % 7));
  if (period === 'month') return new Date(d.getFullYear(), d.getMonth(), 1);
  return null;
}

/** What Beekiri changed, one group per message, newest first: a period at a time, a page at a time. */
export async function listChanges(siteId: string, opts: { period?: 'today' | 'week' | 'month' | 'all'; page?: number } = {}) {
  const from = periodStart(opts.period ?? 'all');
  const scope = { siteId, ...(from ? { createdAt: { [Op.gte]: from } } : {}) };
  // Page by message (run), not by row: a message's changes always stay together.
  const total = (await BeeQueenChange.count({ where: scope, distinct: true, col: 'runId' })) as number;
  const pages = Math.max(1, Math.ceil(total / RUNS_PER_PAGE));
  const page = Math.min(Math.max(1, Math.floor(opts.page ?? 1) || 1), pages);
  const runIds = (
    (await BeeQueenChange.findAll({
      where: scope,
      attributes: ['runId', [fn('max', col('createdAt')), 'lastAt']],
      group: ['runId'],
      order: [[literal('"lastAt"'), 'DESC']],
      limit: RUNS_PER_PAGE,
      offset: (page - 1) * RUNS_PER_PAGE,
      raw: true,
    })) as unknown as { runId: string }[]
  ).map((r) => r.runId);
  const rows = runIds.length
    ? await BeeQueenChange.findAll({ where: { siteId, runId: { [Op.in]: runIds } }, order: [['createdAt', 'DESC']] })
    : [];
  const chatIds = [...new Set(rows.map((r) => r.chatId).filter((v): v is string => Boolean(v)))];
  const userIds = [...new Set(rows.map((r) => r.userId))];
  const chats = new Map(
    (await BeeQueenChat.findAll({ where: { id: { [Op.in]: chatIds } }, attributes: ['id', 'title'] })).map((c) => [c.id, c.title]),
  );
  const users = new Map(
    (await User.findAll({ where: { id: { [Op.in]: userIds } }, attributes: ['id', 'displayName', 'username'] })).map((u) => [
      u.id,
      u.displayName || u.username,
    ]),
  );
  // One group per agent message (run), newest first.
  const runs = new Map<string, { runId: string; chatTitle: string; user: string; createdAt: string; changes: unknown[] }>();
  for (const r of rows) {
    const run =
      runs.get(r.runId) ??
      runs
        .set(r.runId, {
          runId: r.runId,
          chatTitle: ((r.target as { prompt?: string }).prompt || (r.chatId && chats.get(r.chatId)) || 'Beekiri chat') as string,
          user: users.get(r.userId) ?? '',
          createdAt: r.createdAt.toISOString(),
          changes: [],
        })
        .get(r.runId)!;
    run.changes.push({
      id: r.id,
      kind: r.kind,
      label: r.label,
      created: r.before === null,
      createdAt: r.createdAt.toISOString(),
      revertedAt: r.revertedAt?.toISOString() ?? null,
    });
  }
  // A message whose additions still wait for Keep (hidden from visitors) says so, with its Keep button.
  const waiting = await Promise.all(
    [...runs.values()].map(async (run) => {
      const pageIds = rows.filter((r) => r.runId === run.runId && r.kind === 'page' && !r.revertedAt).map((r) => r.target as { pageId: string; kind?: string });
      for (const t of pageIds) {
        const row = await Post.findOne({ where: { id: t.pageId, siteId }, attributes: ['content'] });
        if (row && hasPending(parseContent(row.content).beekiricode, run.runId)) return true;
      }
      return false;
    }),
  );
  return { runs: [...runs.values()].map((run, i) => ({ ...run, pending: waiting[i] })), page, pages, perPage: RUNS_PER_PAGE, total };
}

/**
 * The Beekiri messages (runs) of one chat with what became of their changes: still waiting for Keep
 * (something hidden from visitors), all reverted, or done. `from`/`to`: when each run's changes were made,
 * so a reply can be matched to the run it reported on (also for replies saved before runs were stored).
 */
export async function chatRuns(siteId: string, chatId: string) {
  const rows = await BeeQueenChange.findAll({ where: { siteId, chatId }, order: [['createdAt', 'ASC']] });
  const runs = new Map<
    string,
    { runId: string; from: Date; to: Date; reverted: boolean; kept: boolean; waiting: boolean; pages: { pageId: string }[] }
  >();
  for (const r of rows) {
    const run = runs.get(r.runId) ?? { runId: r.runId, from: r.createdAt, to: r.createdAt, reverted: true, kept: true, waiting: false, pages: [] };
    run.to = r.createdAt;
    if (!r.revertedAt) {
      run.reverted = false;
      // Kept only once the owner said so for everything it still has.
      if (!r.keptAt) run.kept = false;
      if (r.kind === 'page') run.pages.push(r.target as { pageId: string });
    }
    runs.set(r.runId, run);
  }
  for (const run of runs.values()) {
    for (const t of run.pages) {
      const row = await Post.findOne({ where: { id: t.pageId, siteId }, attributes: ['content'] });
      if (row && hasPending(parseContent(row.content).beekiricode, run.runId)) {
        run.waiting = true;
        break;
      }
    }
  }
  return [...runs.values()];
}

/* ── Keep ────────────────────────────────────────────────────────────────── */

/**
 * Keep: what one Beekiri message added to live pages (waiting, hidden from visitors) goes public.
 * The change's "after" snapshot follows, so Undo / Revert still see the page as unedited since.
 */
export async function keepRun(actor: AuthUser, runId: string) {
  const rows = await BeeQueenChange.findAll({ where: { siteId: actor.siteId, runId, kind: 'page', revertedAt: null } });
  let kept = 0;
  for (const c of rows) {
    const t = c.target as { pageId: string; kind?: string };
    const kind = t.kind || 'page';
    const page = await pagesService.get(actor, t.pageId, kind).catch(() => null);
    if (!page || !hasPending(page.beekiricode, runId)) continue;
    const next = keepPending(page.beekiricode, runId);
    await pagesService.update(actor, t.pageId, { beekiricode: next.doc as never }, kind);
    kept += next.kept;
    await c.update({ after: (await snapshots.page(actor, t.pageId, kind)) as never });
  }
  // The owner's choice, also for what was never hidden (a new draft page, a layout, a theme file).
  await BeeQueenChange.update({ keptAt: new Date() }, { where: { siteId: actor.siteId, runId, revertedAt: null, keptAt: null } });
  return { kept };
}

/**
 * Where to look at what this message made: a private preview for pages whose additions still wait
 * for Keep and for drafts (visitors can't see either), the page itself when it is live as it is.
 */
export async function previewRun(actor: AuthUser, runId: string) {
  const rows = await BeeQueenChange.findAll({ where: { siteId: actor.siteId, runId, kind: 'page', revertedAt: null } });
  /** preview: a private link (what waits for Keep, or a draft); otherwise the live page. */
  const pages: { title: string; url: string; preview: boolean }[] = [];
  const seen = new Set<string>();
  for (const c of rows) {
    const t = c.target as { pageId: string; kind?: string };
    if (seen.has(t.pageId)) continue;
    seen.add(t.pageId);
    const kind = t.kind || 'page';
    const page = await pagesService.get(actor, t.pageId, kind).catch(() => null);
    if (!page || page.status === 'trash') continue;
    const waiting = hasPending(page.beekiricode, runId);
    // A site section has no page of its own: preview a page it shows on.
    if (kind === SITE_SECTION_KIND) {
      const shown = await sectionPreview(actor, placementOf({ placement: (page as { placement?: unknown }).placement }));
      if (shown) pages.push({ title: `${page.title} (on ${shown.title})`, url: shown.url, preview: true });
      continue;
    }
    if (!waiting && page.status === 'publish') {
      pages.push({ title: page.title, url: page.path, preview: false });
      continue;
    }
    const preview = await pagesService.createPreview(actor, t.pageId, {}, kind);
    pages.push({ title: page.title, url: preview.previewPath, preview: true });
  }
  return { pages };
}

/* ── Revert ──────────────────────────────────────────────────────────────── */

/** Same content, whatever the key order (snapshots come back from jsonb with their keys reordered). */
function canonical(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>)
        .filter(([, v]) => v !== undefined)
        .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
        .map(([k, v]) => [k, canonical(v)]),
    );
  }
  return value ?? null;
}
const same = (a: unknown, b: unknown) => JSON.stringify(canonical(a)) === JSON.stringify(canonical(b));

/** Is what's there now still what Beekiri left? If not, a revert would also undo later edits. */
async function changedSince(actor: AuthUser, c: BeeQueenChange): Promise<boolean> {
  const t = c.target as Record<string, string>;
  const after = c.after as Record<string, unknown> | null;
  switch (c.kind) {
    case 'theme_file':
      return !same(snapshots.themeFile(t.theme, t.rel).content, after?.content);
    case 'layout':
      return !same(snapshots.layoutFiles(t.theme, Object.keys((after?.files as FileMap) ?? {})), after?.files);
    case 'page': {
      try {
        const now = await snapshots.page(actor, t.pageId, t.kind || 'page');
        return !same(now.beekiricode, after?.beekiricode) || now.title !== after?.title;
      } catch {
        return true;
      }
    }
    case 'taxonomy':
      return !same(await snapshots.taxonomy(actor.siteId, t.id), after);
    case 'post_type':
      return !same(await snapshots.postType(actor.siteId, t.id), after);
    case 'product': {
      // Stock moves with every sale: only the owner's own edits count as "changed since".
      const strip = (s: unknown) => {
        if (!s || typeof s !== 'object') return s;
        const p = s as { commerce?: Record<string, unknown>; variants?: Record<string, unknown>[] };
        return {
          ...p,
          commerce: { ...p.commerce, stockQty: undefined, stockStatus: undefined },
          variants: p.variants?.map((v) => ({ ...v, stockQty: undefined, stockStatus: undefined })),
        };
      };
      return !same(strip(await snapshots.product(actor, t.productId)), strip(after));
    }
    case 'media':
      return false;
    default:
      return false;
  }
}

async function apply(actor: AuthUser, c: BeeQueenChange) {
  const t = c.target as Record<string, string>;
  const before = c.before as Record<string, unknown> | null;
  const after = c.after as Record<string, unknown> | null;
  switch (c.kind) {
    case 'theme_file':
      writeOrRemove(join(resolveThemesRoot(), t.theme, t.rel), (before?.content as string | null) ?? null);
      break;
    case 'layout': {
      const group = before?.group as { id: string; title: string; description: string; fields: never; active: boolean; location: never } | null;
      if (!group) {
        // Beekiri created this layout: its field group (and the layout folder) go to the trash.
        if (after?.groupId) await fieldsService.remove(actor, after.groupId as string);
      } else {
        await fieldsService.update(actor, group.id, {
          title: group.title,
          description: group.description,
          fields: group.fields,
          active: group.active,
          location: group.location,
        });
        const root = resolveThemesRoot();
        for (const [rel, content] of Object.entries((before?.files as FileMap) ?? {})) writeOrRemove(join(root, t.theme, rel), content);
        try {
          layoutSyncService.compileSlug(t.slug);
        } catch {
          /* the restored SCSS is what was there before; a compile error was there too */
        }
      }
      break;
    }
    case 'page': {
      const kind = t.kind || 'page';
      if (!before) await pagesService.remove(actor, t.pageId, kind);
      else
        await pagesService.update(
          actor,
          t.pageId,
          {
            title: before.title as string,
            slug: before.slug as string,
            status: before.status as never,
            beekiricode: before.beekiricode as never,
            ...(kind === 'post'
              ? { excerpt: (before.excerpt as string) ?? '', featuredImageId: (before.featuredImageId as string | null) ?? '' }
              : {}),
          },
          kind,
        );
      break;
    }
    case 'taxonomy':
      if (!before) await structureService.removeTaxonomy(actor, t.id);
      else await structureService.updateTaxonomy(actor, t.id, before as never);
      break;
    case 'post_type':
      if (!before) await structureService.removePostType(actor, t.id);
      else await structureService.updatePostType(actor, t.id, before as never);
      break;
    case 'product':
      // A product Beekiri created goes to the trash; an edited one gets its earlier version back.
      if (!before) await productsService.remove(actor, t.productId);
      else {
        // Stock sold since stays sold: today's stock levels are kept.
        type Snap = NonNullable<Awaited<ReturnType<typeof snapshots.product>>>;
        const old = before as unknown as Snap;
        const now = await snapshots.product(actor, t.productId);
        await productsService.update(actor, t.productId, {
          ...old,
          commerce: { ...old.commerce, stockQty: now?.commerce.stockQty ?? old.commerce.stockQty, stockStatus: now?.commerce.stockStatus ?? old.commerce.stockStatus },
          variants: old.variants.map((v) => {
            const current = now?.variants.find((n) => n.id === v.id);
            return { ...v, stockQty: current?.stockQty ?? v.stockQty, stockStatus: current?.stockStatus ?? v.stockStatus };
          }),
        } as never);
      }
      break;
    case 'media':
      if (await MediaAsset.findOne({ where: { id: t.mediaId, siteId: actor.siteId }, attributes: ['id'] })) {
        await mediaService.remove(t.mediaId);
      }
      break;
  }
  void revalidatePublicPaths(['/']);
}

/** Revert changes newest-first. Throws 409 (unless forced) when something was edited since. */
export async function revertChanges(actor: AuthUser, where: { id?: string; runId?: string }, force = false) {
  const rows = await BeeQueenChange.findAll({
    where: { siteId: actor.siteId, revertedAt: null, ...(where.id ? { id: where.id } : {}), ...(where.runId ? { runId: where.runId } : {}) },
    order: [['createdAt', 'DESC']],
  });
  if (!rows.length) throw NotFound('Nothing left to revert there.');
  if (!force) {
    const edited: string[] = [];
    for (const c of rows) if (await changedSince(actor, c)) edited.push(c.label);
    if (edited.length) {
      throw Conflict(
        `${edited.join(', ')} ${edited.length === 1 ? 'was' : 'were'} edited after Beekiri changed ${edited.length === 1 ? 'it' : 'them'}. Reverting would undo those edits too.`,
      );
    }
  }
  const done: string[] = [];
  for (const c of rows) {
    try {
      await apply(actor, c);
    } catch (error) {
      throw BadRequest(`Reverted ${done.length} of ${rows.length}; "${c.label}" could not be reverted: ${(error as Error).message}`);
    }
    await c.update({ revertedAt: new Date(), revertedById: actor.id });
    done.push(c.label);
  }
  return { reverted: done.length };
}
