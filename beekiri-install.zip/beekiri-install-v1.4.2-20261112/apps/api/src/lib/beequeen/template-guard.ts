import { spawn } from 'child_process';
import { basename, extname } from 'path';

import { phpArgs, phpEnv } from '../layouts/php/php-sandbox';

/**
 * The Connector may build layouts and theme markup, but never code that runs on the server.
 * Every PHP template it writes must be a plain template: PHP itself tokenises it (token_get_all,
 * in a sandboxed `php` started without a shell) and only these pieces may appear:
 *
 * - <?php ?> / <?= ?>, echo / print, if / elseif / else, foreach, for, while, break / continue
 * - isset / empty, variables, array access and array literals, strings and numbers
 * - string concatenation, comparison, logic and arithmetic, casts
 * - calls to the functions in TEMPLATE_FUNCTIONS below — nothing else
 *
 * Refused: any other function, variable functions and methods, `new`, `::`, `->`, include /
 * require, eval, backticks, `$$` / `${…}`, superglobals, `__halt_compiler`, `declare`, `goto`,
 * closures and function definitions, classes, heredocs with code in them, and `<?` hidden in
 * HTML. The model gets the reasons back as a tool error so it can rewrite the template.
 */

/**
 * The function allowlist. Built from every function the shipped templates call (apps/web/themes,
 * ~/Desktop/Beekiri-Themes and the Backend Fields generator's renderPhp output), then reviewed by
 * hand: each one only formats or reads values. Left out on purpose: array_map / usort /
 * array_filter with a callback (a string callback such as 'system' is a function call), extract
 * (overwrites variables), is_file (looks at the server's files), and theme-defined helpers
 * (bch_*, bee_shop_*) that only exist after an include.
 */
export const TEMPLATE_FUNCTIONS: readonly string[] = [
  // Beekiri field API (layout-runner.php)
  'get_bee_field', 'the_bee_field', 'get_bee_fields', 'have_bee_rows', 'the_bee_row', 'get_bee_row',
  'get_bee_row_index', 'get_bee_row_layout', 'reset_bee_rows',
  // Escaping and markup helpers (layout-runner.php)
  'esc_html', 'esc_attr', 'esc_url', 'esc_textarea', 'bee_esc_html', 'wp_kses_post', 'wpautop', 'nl2br',
  'sanitize_title', 'wp_trim_words', 'bee_form', 'the_bee_form', 'bee_language_switcher', 'bee_search_modal',
  'wp_get_attachment_image', 'wp_get_attachment_url', 'wp_get_attachment_image_url', 'wp_get_attachment_image_src',
  'get_permalink', 'get_the_title', 'function_exists',
  // Values and arrays
  'count', 'is_array', 'is_string', 'is_numeric', 'in_array', 'array_key_exists', 'array_keys', 'array_values',
  'array_slice', 'array_splice', 'array_column', 'array_unique', 'array_merge', 'array_shift', 'array_flip',
  'array_reverse', 'array_filter', 'implode', 'explode', 'json_encode', 'intval',
  // Strings
  'trim', 'rtrim', 'ltrim', 'substr', 'mb_substr', 'strlen', 'mb_strlen', 'strpos', 'str_contains',
  'str_starts_with', 'strtolower', 'strtoupper', 'ucfirst', 'str_pad', 'str_replace', 'sprintf', 'strip_tags',
  'preg_match', 'preg_replace', 'preg_split', 'rawurlencode', 'urlencode',
  // Numbers and dates
  'number_format', 'round', 'floor', 'ceil', 'abs', 'min', 'max', 'date', 'strtotime',
];

/** Functions that also take a callback: allowed only with their first argument alone. */
export const ONE_ARGUMENT_FUNCTIONS: readonly string[] = ['array_filter'];

/** Bare names a template may use as values. */
export const TEMPLATE_CONSTANTS: readonly string[] = [
  'true', 'false', 'null', 'ENT_QUOTES', 'PHP_EOL', 'STR_PAD_LEFT', 'STR_PAD_RIGHT', 'STR_PAD_BOTH',
];

/** Tokenises in PHP and walks the tokens. Input and verdict travel as JSON on stdin / stdout. */
const CHECKER = String.raw`
$in = json_decode(stream_get_contents(STDIN), true);
$src = (string) ($in['source'] ?? '');
$fns = array_flip($in['functions'] ?? []);
$consts = array_flip(array_map('strtolower', $in['constants'] ?? []));
$oneArg = array_flip($in['oneArg'] ?? []);
$problems = [];
$seen = [];
$add = function (int $line, string $msg) use (&$problems, &$seen) {
  if (isset($seen[$msg]) || count($problems) >= 20) return;
  $seen[$msg] = true;
  $problems[] = ['line' => $line, 'message' => $msg];
};
try {
  $raw = token_get_all($src, TOKEN_PARSE);
} catch (\Throwable $e) {
  echo json_encode(['problems' => [['line' => $e->getLine(), 'message' => 'PHP syntax error: ' . $e->getMessage()]]]);
  exit(0);
}
$ids = function (array $names): array {
  $out = [];
  foreach ($names as $n) if (defined($n)) $out[constant($n)] = true;
  return $out;
};
$allowed = $ids([
  'T_OPEN_TAG', 'T_OPEN_TAG_WITH_ECHO', 'T_CLOSE_TAG', 'T_INLINE_HTML', 'T_ECHO', 'T_PRINT',
  'T_IF', 'T_ELSE', 'T_ELSEIF', 'T_ENDIF', 'T_FOREACH', 'T_ENDFOREACH', 'T_AS', 'T_FOR', 'T_ENDFOR',
  'T_WHILE', 'T_ENDWHILE', 'T_BREAK', 'T_CONTINUE', 'T_ISSET', 'T_EMPTY', 'T_ARRAY',
  'T_VARIABLE', 'T_STRING', 'T_CONSTANT_ENCAPSED_STRING', 'T_ENCAPSED_AND_WHITESPACE', 'T_LNUMBER',
  'T_DNUMBER', 'T_NUM_STRING', 'T_CURLY_OPEN', 'T_START_HEREDOC', 'T_END_HEREDOC', 'T_DOUBLE_ARROW',
  'T_COALESCE', 'T_COALESCE_EQUAL', 'T_IS_EQUAL', 'T_IS_NOT_EQUAL', 'T_IS_IDENTICAL', 'T_IS_NOT_IDENTICAL',
  'T_IS_SMALLER_OR_EQUAL', 'T_IS_GREATER_OR_EQUAL', 'T_SPACESHIP', 'T_BOOLEAN_AND', 'T_BOOLEAN_OR',
  'T_LOGICAL_AND', 'T_LOGICAL_OR', 'T_LOGICAL_XOR', 'T_INC', 'T_DEC', 'T_PLUS_EQUAL', 'T_MINUS_EQUAL',
  'T_MUL_EQUAL', 'T_DIV_EQUAL', 'T_MOD_EQUAL', 'T_CONCAT_EQUAL', 'T_POW', 'T_POW_EQUAL',
  'T_STRING_CAST', 'T_INT_CAST', 'T_DOUBLE_CAST', 'T_BOOL_CAST', 'T_ARRAY_CAST',
]);
$named = [
  'T_EVAL' => 'eval', 'T_INCLUDE' => 'include', 'T_INCLUDE_ONCE' => 'include_once', 'T_REQUIRE' => 'require',
  'T_REQUIRE_ONCE' => 'require_once', 'T_NEW' => '"new" (objects)', 'T_DOUBLE_COLON' => 'static calls (::)',
  'T_OBJECT_OPERATOR' => 'methods and properties (->)', 'T_NULLSAFE_OBJECT_OPERATOR' => 'methods and properties (?->)',
  'T_HALT_COMPILER' => '__halt_compiler', 'T_DECLARE' => 'declare', 'T_GOTO' => 'goto',
  'T_FUNCTION' => 'functions and closures (function)', 'T_FN' => 'arrow functions (fn)', 'T_CLASS' => 'classes',
  'T_DOLLAR_OPEN_CURLY_BRACES' => 'variable variables ($' . '{...})', 'T_GLOBAL' => 'global', 'T_STATIC' => 'static',
  'T_EXIT' => 'exit / die', 'T_USE' => 'use', 'T_NAMESPACE' => 'namespace', 'T_FILE' => '__FILE__', 'T_DIR' => '__DIR__',
  'T_NAME_FULLY_QUALIFIED' => 'namespaced names (\\name)', 'T_NAME_QUALIFIED' => 'namespaced names',
  'T_NAME_RELATIVE' => 'namespaced names', 'T_RETURN' => 'return', 'T_UNSET' => 'unset', 'T_LIST' => 'list()',
];
$friendly = [];
foreach ($named as $n => $label) if (defined($n)) $friendly[constant($n)] = $label;
$superglobals = ['$GLOBALS', '$_SERVER', '$_GET', '$_POST', '$_FILES', '$_COOKIE', '$_SESSION', '$_REQUEST', '$_ENV',
  '$argv', '$argc', '$this', '$http_response_header', '$php_errormsg'];
$okChars = array_flip([';', ',', '.', '(', ')', '[', ']', '{', '}', '=', '+', '-', '*', '/', '%', '<', '>', '!', '?', ':', '"', '&', '|', '^', '~', '@']);

$t = [];
$line = 1;
foreach ($raw as $tok) {
  if (is_array($tok)) {
    $line = $tok[2];
    if (in_array($tok[0], [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)) continue;
    $t[] = [$tok[0], $tok[1], $line];
  } else {
    $t[] = [$tok, $tok, $line];
  }
}
$n = count($t);
$inString = false;
$inHeredoc = false;
for ($i = 0; $i < $n; $i++) {
  [$id, $text, $ln] = $t[$i];
  $prev = $i > 0 ? $t[$i - 1][0] : null;
  $next = $i + 1 < $n ? $t[$i + 1][0] : null;
  if ($id === T_START_HEREDOC) { $inHeredoc = true; continue; }
  if ($id === T_END_HEREDOC) { $inHeredoc = false; continue; }
  if ($inHeredoc && $id !== T_ENCAPSED_AND_WHITESPACE) {
    $add($ln, 'Heredocs may only hold plain text (no variables or code); use a normal string with concatenation.');
    continue;
  }
  if ($id === '"') { $inString = !$inString; }
  if (is_string($id)) {
    if ($id === '$') { $add($ln, 'Variable variables ($$name) are not allowed.'); continue; }
    if ($id === '` + '`' + String.raw`') { $add($ln, 'Backticks (shell commands) are not allowed.'); continue; }
    if (!isset($okChars[$id])) { $add($ln, "\"$id\" is not allowed in templates."); continue; }
    if ($id === '(' && $prev !== null && (in_array($prev, [T_VARIABLE, T_CONSTANT_ENCAPSED_STRING], true) || in_array($prev, [']', ')', '}', '"'], true))) {
      $add($ln, 'Calling a value as a function (variable functions, $fn(), "name"()) is not allowed; call the function by its name.');
    }
    continue;
  }
  if (isset($friendly[$id])) { $add($ln, $friendly[$id] . ' is not allowed in templates.'); continue; }
  if (!isset($allowed[$id])) { $add($ln, token_name($id) . ' ("' . trim(substr($text, 0, 30)) . '") is not allowed in templates.'); continue; }
  if ($id === T_INLINE_HTML && strpos($text, '<?') !== false) {
    $add($ln, 'Write PHP only inside <?php ... ?> or <?= ... ?>; "<?" may not appear in the HTML.');
    continue;
  }
  if ($id === T_VARIABLE && (in_array($text, $superglobals, true) || strpos($text, '$_') === 0)) {
    $add($ln, "$text is not available in templates; read values with get_bee_field().");
    continue;
  }
  if ($id === T_STRING) {
    // "$row[key]" inside a double-quoted string: an unquoted array key, not a name.
    if ($inString && $prev === '[' && $i > 1 && $t[$i - 2][0] === T_VARIABLE) continue;
    $lower = strtolower($text);
    if ($next === '(') {
      if (!isset($fns[$lower])) {
        $add($ln, "$text() is not an allowed template function.");
        continue;
      }
      if (isset($oneArg[$lower])) {
        $depth = 0;
        for ($j = $i + 1; $j < $n; $j++) {
          $c = $t[$j][0];
          if ($c === '(' || $c === '[' || $c === '{' || $c === T_CURLY_OPEN) $depth++;
          elseif ($c === ')' || $c === ']' || $c === '}') { $depth--; if ($depth === 0) break; }
          elseif ($c === ',' && $depth === 1) { $add($ln, "$text() may only take the array here (no callback)."); break; }
        }
      }
      continue;
    }
    if (!isset($consts[$lower])) $add($ln, "\"$text\" is not allowed here; only true, false, null and a few constants (ENT_QUOTES, PHP_EOL…) may be used by name.");
  }
}
echo json_encode(['problems' => $problems]);
`;

export type TemplateProblem = { line: number; message: string };

/** Runs the checker; resolves with its problems (empty = a plain template). Fails closed. */
export function checkPhpTemplate(source: string): Promise<TemplateProblem[]> {
  const input = JSON.stringify({
    source,
    functions: TEMPLATE_FUNCTIONS,
    constants: TEMPLATE_CONSTANTS,
    oneArg: ONE_ARGUMENT_FUNCTIONS,
  });
  return new Promise((resolve) => {
    const fail = (why: string) => resolve([{ line: 0, message: `The template could not be checked (${why}), so it was not saved.` }]);
    // short_open_tag on: "<?" counts as PHP here, so nothing can hide as HTML from the check.
    const child = spawn('php', phpArgs(['-d', 'short_open_tag=1', '-d', 'error_reporting=0', '-r', CHECKER]), { env: phpEnv() });
    const out: Buffer[] = [];
    const timer = setTimeout(() => child.kill('SIGKILL'), 8000);
    child.stdout.on('data', (b: Buffer) => out.push(b));
    child.stderr.on('data', () => undefined);
    child.on('error', (e) => {
      clearTimeout(timer);
      fail((e as NodeJS.ErrnoException).code === 'ENOENT' ? 'PHP is not installed on this server' : e.message);
    });
    child.on('close', () => {
      clearTimeout(timer);
      try {
        const parsed = JSON.parse(Buffer.concat(out).toString('utf8')) as { problems?: TemplateProblem[] };
        if (!Array.isArray(parsed.problems)) throw new Error('no verdict');
        resolve(parsed.problems);
      } catch {
        fail('the checker gave no answer');
      }
    });
    child.stdin.on('error', () => undefined);
    child.stdin.end(input);
  });
}

/** Problems as a tool error the model can act on. */
export function templateProblemsText(file: string, problems: TemplateProblem[]): string {
  return [
    `${file} was refused — templates may only print values, never run server code:`,
    ...problems.map((p) => `- ${p.line ? `line ${p.line}: ` : ''}${p.message}`),
    'Allowed: echo/print, if/elseif/else, foreach, for, while, isset/empty, array access, "." concatenation, comparison and arithmetic, and these functions: ' +
      `${TEMPLATE_FUNCTIONS.join(', ')} (array_filter with the array only). Rewrite the template with those and save again.`,
  ].join('\n');
}

/** Throws the tool error when the template is not a plain template. */
export async function assertPlainTemplate(file: string, source: string): Promise<void> {
  const problems = await checkPhpTemplate(source);
  if (problems.length) throw new Error(templateProblemsText(file, problems));
}

// ─── Which files the agent may write ─────────────────────────────────────────

/** Server-executed (or server-configuring) file types: never written by the agent. */
const SERVER_CODE = new Set(['.ts', '.tsx', '.mts', '.cts', '.jsx', '.mjs', '.cjs', '.phtml', '.phar', '.php3', '.php4', '.php5', '.php7', '.php8', '.phps', '.inc', '.htaccess', '.ini', '.json', '.sh', '.py', '.rb', '.pl', '.cgi']);
const SERVER_NAMES = new Set(['.htaccess', '.user.ini', 'php.ini', 'theme.json', 'package.json']);

export type ThemeWriteKind = 'php' | 'style' | 'script' | 'text';

/**
 * What kind of theme file this is, or an error: PHP templates (checked separately), styles,
 * the theme's browser script.js, or Markdown notes. Everything else is refused.
 */
export function themeWriteKind(rel: string): ThemeWriteKind {
  const name = basename(rel).toLowerCase();
  const ext = extname(name);
  if (SERVER_NAMES.has(name) || SERVER_CODE.has(ext)) {
    throw new Error(`${rel} is a file type that runs on (or configures) the server, which Beekiri never writes. Theme templates (.php), styles (.css, .scss) and the browser script.js are fine.`);
  }
  if (ext === '.php') return 'php';
  if (ext === '.css' || ext === '.scss') return 'style';
  if (ext === '.md') return 'text';
  if (ext === '.js') {
    if (name === 'script.js') return 'script';
    throw new Error(`Only the theme's browser script (script.js) can be written, not ${rel}: other .js files may run on the server.`);
  }
  throw new Error('Only .php templates, .css/.scss styles, script.js and .md theme files can be written.');
}

/**
 * Markup that runs JavaScript on visitors' pages: a script tag, an event-handler attribute
 * (onclick=, onerror=…), a javascript: address, or an element that loads another page or plugin.
 * Only people with unfiltered_html may put such things in a template.
 */
export function hasScriptTag(source: string): boolean {
  return (
    /<\s*script\b/i.test(source) ||
    /<[a-z][^>]*\son[a-z]+\s*=/i.test(source) ||
    /(?:href|src|action|formaction|xlink:href|data)\s*=\s*["']?\s*(?:javascript|vbscript|data:text\/html)/i.test(source) ||
    /javascript\s*:/i.test(source.replace(/<\?php[\s\S]*?\?>/g, '')) ||
    /<\s*(?:iframe|object|embed|base|meta)\b/i.test(source)
  );
}
