import { Op } from 'sequelize';
import { BeeQueenChat, BeeQueenMessage, User } from '../../models';

/** A line of spending from 996Agency: when the message started and what it cost. */
type Spend = { createdAt: string; cost: { amount: number } };

/** What the Connector page shows next to the cost: the request itself and who sent it. */
export type SpendLabel = { prompt: string | null; user: string | null };

/** Clocks of the site and 996Agency may differ a little; a message is matched within this margin. */
const MARGIN_MS = 90_000;
const PROMPT_MAX = 160;

function oneLine(text: string): string {
  const flat = text.replace(/\s+/g, ' ').trim();
  return flat.length > PROMPT_MAX ? `${flat.slice(0, PROMPT_MAX - 1).trimEnd()}…` : flat;
}

/**
 * Says what each line of spending was for. 996Agency only knows the time and the cost of a
 * message; the request itself is in this site's chats, so each line is paired with the chat turn
 * that ran at that time (the same cost first, then the nearest in time). Lines without a chat turn
 * (section edits in the page editor, one-click helpers) stay unnamed.
 */
export async function describeSpending<T extends Spend>(siteId: string, rows: T[]): Promise<(T & SpendLabel)[]> {
  const blank = (r: T): T & SpendLabel => ({ ...r, prompt: null, user: null });
  if (!rows.length) return [];
  try {
    const times = rows.map((r) => Date.parse(r.createdAt)).filter((t) => Number.isFinite(t));
    if (!times.length) return rows.map(blank);
    // A long message may have started well before its last line of spending.
    const from = new Date(Math.min(...times) - 30 * 60_000);
    const to = new Date(Math.max(...times) + 30 * 60_000);
    const chats = await BeeQueenChat.findAll({ where: { siteId, updatedAt: { [Op.gte]: from } }, attributes: ['id', 'userId'] });
    if (!chats.length) return rows.map(blank);
    const owner = new Map(chats.map((c) => [c.id, c.userId]));
    const messages = await BeeQueenMessage.findAll({
      where: { chatId: { [Op.in]: [...owner.keys()] }, createdAt: { [Op.between]: [from, to] } },
      attributes: ['chatId', 'role', 'text', 'usage', 'createdAt'],
      order: [['createdAt', 'ASC']],
    });
    // Chat turns: a request and the answer that followed it in the same chat.
    type Turn = { chatId: string; prompt: string; start: number; end: number; cost: number | null; taken: boolean };
    const turns: Turn[] = [];
    const asked = new Map<string, { text: string; at: number }>();
    for (const m of messages) {
      const at = m.createdAt.getTime();
      if (m.role === 'user') {
        asked.set(m.chatId, { text: m.text, at });
        continue;
      }
      const request = asked.get(m.chatId);
      if (!request) continue;
      asked.delete(m.chatId);
      const cost = Number((m.usage as { cost?: unknown } | null)?.cost);
      turns.push({ chatId: m.chatId, prompt: request.text, start: request.at, end: at, cost: Number.isFinite(cost) ? cost : null, taken: false });
    }
    // A request still being answered counts too (its spending shows before the answer is saved).
    for (const [chatId, request] of asked) turns.push({ chatId, prompt: request.text, start: request.at, end: request.at + 20 * 60_000, cost: null, taken: false });

    const userIds = [...new Set(chats.map((c) => c.userId))];
    const names = new Map(
      (await User.findAll({ where: { id: { [Op.in]: userIds } }, attributes: ['id', 'displayName', 'username'] })).map((u) => [u.id, u.displayName || u.username]),
    );

    return rows.map((row) => {
      const at = Date.parse(row.createdAt);
      let best: Turn | null = null;
      let bestScore = Infinity;
      for (const turn of turns) {
        if (turn.taken || at < turn.start - MARGIN_MS || at > turn.end + MARGIN_MS) continue;
        const sameCost = turn.cost !== null && Math.abs(turn.cost - row.cost.amount) <= Math.max(0.011, row.cost.amount * 0.02);
        // The same cost wins outright; otherwise the turn that started nearest.
        const score = Math.abs(at - turn.start) + (sameCost ? 0 : 3_600_000);
        if (score < bestScore) {
          best = turn;
          bestScore = score;
        }
      }
      if (!best) return blank(row);
      best.taken = true;
      return { ...row, prompt: oneLine(best.prompt) || null, user: names.get(owner.get(best.chatId) ?? '') ?? null };
    });
  } catch {
    // The costs matter more than their names.
    return rows.map(blank);
  }
}
