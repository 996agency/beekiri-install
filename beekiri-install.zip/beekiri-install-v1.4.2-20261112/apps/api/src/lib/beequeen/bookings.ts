import { extensionsService } from '../../services/extensions.service';
import { bookingsService } from '../../services/bookings/bookings.service';
import { BOOKINGS_EXTENSION_SLUG } from '../bookings/constants';
import { DAY_KEYS, formatPrice, type WeekHours } from '../bookings/schema';
import type { Workspace } from './workspace';

/**
 * Beekiri's tools for Bee Bookings: read the setup, and set up services, staff, hours and rules
 * from what the owner says ("a barber shop, two barbers, open Tue–Sat 9 to 6").
 */

export type BookingsSetupInput = {
  services?: { id?: string; name: string; durationMin?: number; price?: number; bufferMin?: number; description?: string; active?: boolean }[];
  staff?: { id?: string; name: string; email?: string; phone?: string; services?: string[]; hours?: Record<string, { from: string; to: string }[]> | null; daysOff?: { from: string; to?: string; note?: string }[]; active?: boolean }[];
  settings?: {
    hours?: Record<string, { from: string; to: string }[]>;
    slotStep?: number;
    minNoticeHours?: number;
    maxDaysAhead?: number;
    closedDates?: { from: string; to?: string; note?: string }[];
    autoConfirm?: boolean;
    notifyEmail?: string;
    reminderHours?: number;
    cancelHours?: number;
    currency?: string;
    location?: string;
    confirmationNote?: string;
    timezone?: string;
  };
};

const hoursLine = (hours: WeekHours) =>
  DAY_KEYS.map((d) => `${d} ${hours[d].length ? hours[d].map((i) => `${i.from}–${i.to}`).join(', ') : 'closed'}`).join('; ');

export async function getBookingsSetup(ws: Workspace): Promise<string> {
  const siteId = ws.actor.siteId;
  const active = await extensionsService.isActive(BOOKINGS_EXTENSION_SLUG);
  const [services, staff, settings] = await Promise.all([bookingsService.listServices(siteId), bookingsService.listStaff(siteId), bookingsService.settings(siteId)]);
  const names = new Map(services.map((s) => [s.id, s.name]));
  return [
    `Bee Bookings is ${active ? 'on' : 'off (save_bookings_setup turns it on)'}.`,
    `Business hours (${settings.timezone}): ${hoursLine(settings.hours)}.`,
    `Rules: a start time every ${settings.slotStep} min; book at least ${settings.minNoticeHours} h and at most ${settings.maxDaysAhead} days ahead; ${settings.autoConfirm ? 'bookings are confirmed straight away' : 'bookings wait for approval'}; reminder ${settings.reminderHours ? `${settings.reminderHours} h before` : 'off'}; currency ${settings.currency}; location: ${settings.location || '(none)'}; new-booking emails to ${settings.notifyEmail || '(the staff member only)'}.`,
    settings.closedDates.length ? `Closed: ${settings.closedDates.map((c) => (c.from === c.to ? c.from : `${c.from}–${c.to}`) + (c.note ? ` (${c.note})` : '')).join(', ')}.` : 'No closed dates.',
    services.length
      ? `Services:\n${services.map((s) => `- ${s.name} (id ${s.id}): ${s.durationMin} min${s.bufferMin ? ` + ${s.bufferMin} min free after` : ''}, ${formatPrice(s.priceCents, settings.currency)}${s.active ? '' : ', off'}${s.description ? ` — ${s.description}` : ''}`).join('\n')}`
      : 'No services yet.',
    staff.length
      ? `Staff:\n${staff.map((p) => `- ${p.name} (id ${p.id})${p.email ? `, ${p.email}` : ''}: ${p.serviceIds.length ? p.serviceIds.map((id) => names.get(id) ?? id).join(', ') : 'all services'}; ${p.hours ? `own hours: ${hoursLine(p.hours)}` : 'business hours'}${p.active ? '' : '; off'}`).join('\n')}`
      : 'No staff yet (bookings need at least one person).',
    'To show the booking widget on a page, add a text element whose text is exactly [bee_booking] (or [bee_booking service="Service name"] to start on one service).',
  ].join('\n');
}

export async function saveBookingsSetup(ws: Workspace, input: BookingsSetupInput): Promise<string> {
  const actor = ws.actor;
  const done: string[] = [];

  if (!(await extensionsService.isActive(BOOKINGS_EXTENSION_SLUG))) {
    const listed = (await extensionsService.list()).extensions.find((e) => e.slug === BOOKINGS_EXTENSION_SLUG);
    if (!listed) throw new Error('Bee Bookings is not available on this site.');
    // Switching an extension on is an administrator's decision, as it is in the admin.
    if (!actor.isOwner && !actor.capabilities.includes('manage_options')) {
      throw new Error('Bee Bookings is switched off. An administrator has to turn it on under Extensions first.');
    }
    if (listed.status === 'available') await extensionsService.install(actor, BOOKINGS_EXTENSION_SLUG);
    else await extensionsService.activate(actor, BOOKINGS_EXTENSION_SLUG);
    done.push('Turned Bee Bookings on (Bookings is now in the admin menu).');
  }

  if (input.settings) {
    await bookingsService.saveSettings(actor, input.settings);
    done.push('Saved the booking settings.');
  }

  for (const s of input.services ?? []) {
    const saved = await bookingsService.saveService(actor, s.id ?? null, {
      name: s.name,
      ...(s.description !== undefined ? { description: s.description } : {}),
      ...(s.durationMin !== undefined ? { durationMin: s.durationMin } : {}),
      ...(s.bufferMin !== undefined ? { bufferMin: s.bufferMin } : {}),
      ...(s.price !== undefined ? { priceCents: Math.round(s.price * 100) } : {}),
      ...(s.active !== undefined ? { active: s.active } : {}),
    });
    done.push(`${s.id ? 'Updated' : 'Added'} service "${saved.name}" (id ${saved.id}, ${saved.durationMin} min).`);
  }

  if (input.staff?.length) {
    // Staff name their services by name (or id); unknown names are reported, not guessed.
    const services = await bookingsService.listServices(actor.siteId);
    const find = (ref: string) => services.find((x) => x.id === ref || x.name.toLowerCase() === ref.trim().toLowerCase());
    for (const p of input.staff) {
      const unknown = (p.services ?? []).filter((ref) => !find(ref));
      const saved = await bookingsService.saveStaff(actor, p.id ?? null, {
        name: p.name,
        ...(p.email !== undefined ? { email: p.email } : {}),
        ...(p.phone !== undefined ? { phone: p.phone } : {}),
        ...(p.services !== undefined ? { serviceIds: p.services.map((ref) => find(ref)?.id).filter((id): id is string => Boolean(id)) } : {}),
        ...(p.hours !== undefined ? { hours: p.hours as WeekHours | null } : {}),
        ...(p.daysOff !== undefined ? { daysOff: p.daysOff.map((d) => ({ from: d.from, to: d.to ?? d.from, note: d.note ?? '' })) } : {}),
        ...(p.active !== undefined ? { active: p.active } : {}),
      });
      done.push(`${p.id ? 'Updated' : 'Added'} ${saved.name} (id ${saved.id})${unknown.length ? ` — unknown services ignored: ${unknown.join(', ')}` : ''}.`);
    }
  }

  const staffCount = (await bookingsService.listStaff(actor.siteId, true)).length;
  if (!staffCount) done.push('There is no staff member yet: add at least one, or nobody can be booked.');
  done.push('To put the booking widget on a page, add a text element whose text is exactly [bee_booking]. The calendar, services and staff are under Bookings in the admin.');
  return done.join('\n');
}
