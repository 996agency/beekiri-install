import * as z from 'zod/v4';

/**
 * Section mode: the owner selected one element in the BeekiriCode editor and asked Beekiri
 * to work on just that. Beekiri sees that subtree and may only replace it — the editor
 * applies the result as one undoable change and saves it with the draft.
 */

/** Plain editor elements Beekiri may create. Theme layouts, forms and the shop slot stay as they are. */
const CREATABLE = ['section', 'container', 'heading', 'text', 'image', 'button', 'video', 'list', 'divider', 'spacer', 'icon', 'accordion', 'tabs', 'map', 'rating'] as const;
const PROTECTED_TYPES = new Set(['layout', 'form', 'shop_content', 'booking']);
/** Fields Beekiri never sets: they tie a node to theme layouts, forms or dynamic content. */
const PROTECTED_KEYS = ['layoutSlug', 'layoutTitle', 'formId', 'bookingService', 'loop', 'bind'] as const;

export const MAX_SECTION_NODES = 400;
const MAX_SECTION_BYTES = 300_000;

type Node = Record<string, unknown> & { id: string; type: string; children: string[] };
export type SectionTree = { rootId: string; nodes: Record<string, Node> };

export type SectionScope = {
  pageId: string;
  pageTitle: string;
  /** The selected element; it keeps its id so it stays in the same place on the page. */
  nodeId: string;
  label: string;
  /** Desktop, tablet or mobile — where the owner was looking when they asked. */
  viewport: string;
  tree: SectionTree;
};

/** CSS values: models often write numbers (fontWeight 500, zIndex 1) — keep them as strings. */
const styleBag = z.record(z.string().max(60), z.coerce.string().max(600));

/** Text fields: `null` from the model means "not set". */
const text = (max: number) => z.string().max(max).nullish();

/** One element as Beekiri writes it (unknown keys are dropped). */
const nodeInput = z.object({
  id: z.string().min(1).max(64),
  type: z.string().max(40),
  label: text(120),
  tag: text(20),
  text: text(8000),
  src: text(2000),
  alt: text(500),
  href: text(2000),
  newTab: z.boolean().nullish(),
  autoplay: z.boolean().nullish(),
  videoLoop: z.boolean().nullish(),
  muted: z.boolean().nullish(),
  controls: z.boolean().nullish(),
  poster: text(2000),
  // Icon (a name from the built-in set), Accordion / Tabs items, Map and Star rating.
  icon: text(60),
  items: z.array(z.object({ title: z.coerce.string().max(300), text: z.coerce.string().max(8000) })).max(40).nullish(),
  startClosed: z.boolean().nullish(),
  address: text(300),
  zoom: z.coerce.number().min(1).max(20).nullish(),
  rating: z.coerce.number().min(0).max(5).nullish(),
  cssId: text(80),
  cssClass: text(200),
  customCss: text(4000),
  style: styleBag.nullish(),
  hoverStyle: styleBag.nullish(),
  stylesByBreakpoint: z.object({ tablet: styleBag.nullish(), mobile: styleBag.nullish() }).nullish(),
  hiddenOn: z.array(z.enum(['desktop', 'tablet', 'mobile'])).nullish(),
  layoutSlug: text(80),
  layoutFields: z.record(z.string(), z.unknown()).nullish(),
  children: z.array(z.string().max(64)).max(200).nullish(),
});

/**
 * Models sometimes send the element map as a JSON string — and when they do, an extra closing
 * brace at the end is common. Read the first complete JSON object in the string and ignore the rest.
 */
export function parseLooseJsonObject(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    /* fall through to the balanced read */
  }
  const start = text.indexOf('{');
  if (start < 0) return text;
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = start; i < text.length; i++) {
    const c = text[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (c === '\\') escaped = true;
      else if (c === '"') inString = false;
      continue;
    }
    if (c === '"') inString = true;
    else if (c === '{') depth++;
    else if (c === '}' && --depth === 0) {
      try {
        return JSON.parse(text.slice(start, i + 1));
      } catch {
        return text;
      }
    }
  }
  return text;
}

export const sectionInputSchema = z.object({
  rootId: z.string().describe('Must be the selected element’s id'),
  nodes: z
    .preprocess((v) => (typeof v === 'string' ? parseLooseJsonObject(v) : v), z.record(z.string(), nodeInput))
    .describe('A JSON object (not a string) with every element of the new section, keyed by id'),
});

/** Request-side check of what the editor sent (size and shape only — the editor owns its doc). */
export function readScope(raw: unknown): SectionScope | null {
  if (!raw || typeof raw !== 'object') return null;
  const o = raw as Record<string, unknown>;
  const tree = o.tree as SectionTree | undefined;
  if (
    typeof o.pageId !== 'string' ||
    typeof o.nodeId !== 'string' ||
    !tree ||
    typeof tree !== 'object' ||
    tree.rootId !== o.nodeId ||
    !tree.nodes ||
    typeof tree.nodes !== 'object' ||
    !tree.nodes[o.nodeId]
  ) {
    return null;
  }
  if (Object.keys(tree.nodes).length > MAX_SECTION_NODES || JSON.stringify(tree).length > MAX_SECTION_BYTES) return null;
  return {
    pageId: o.pageId.slice(0, 64),
    pageTitle: typeof o.pageTitle === 'string' ? o.pageTitle.slice(0, 200) : '',
    nodeId: o.nodeId,
    label: typeof o.label === 'string' ? o.label.slice(0, 120) : '',
    viewport: typeof o.viewport === 'string' ? o.viewport.slice(0, 20) : 'desktop',
    tree,
  };
}

/** Layout slugs in a proposed tree that differ from what those elements show now (to check they exist). */
export function requestedLayouts(original: SectionTree, input: z.infer<typeof sectionInputSchema>): string[] {
  const nodes = input.nodes && typeof input.nodes === 'object' ? Object.values(input.nodes) : [];
  const slugs = nodes
    .filter((n) => n.layoutSlug && n.layoutSlug !== original.nodes[n.id]?.layoutSlug)
    .map((n) => String(n.layoutSlug));
  return [...new Set(slugs)];
}

/**
 * Turns Beekiri's proposed section into a tree the editor can drop in place of the original.
 * Throws with a message written for the model when something has to be fixed.
 * `layouts`: theme layouts an element may switch to (checked to exist) — a layout element
 * otherwise keeps the one it shows.
 */
export function normalizeSection(
  original: SectionTree,
  input: z.infer<typeof sectionInputSchema>,
  layouts: ReadonlySet<string> = new Set(),
): SectionTree {
  if (input.rootId !== original.rootId) {
    throw new Error(`rootId must stay "${original.rootId}" (the selected element), so the section stays in its place.`);
  }
  const proposed = input.nodes;
  if (!proposed[input.rootId]) throw new Error(`nodes is missing the root element "${input.rootId}".`);

  const nodes: Record<string, Node> = {};
  const seen = new Set<string>();
  const problems: string[] = [];

  const visit = (id: string, depth: number) => {
    if (seen.has(id)) {
      problems.push(`"${id}" is used more than once.`);
      return;
    }
    if (depth > 40) {
      problems.push('The section is nested too deeply.');
      return;
    }
    const raw = proposed[id];
    if (!raw) {
      problems.push(`A children list points at "${id}", which is not in nodes.`);
      return;
    }
    seen.add(id);
    const before = original.nodes[id];
    const keepsProtected = before && PROTECTED_TYPES.has(before.type);
    // A theme layout: the one it shows, or another that exists (e.g. one create_layout just made).
    const switchTo = raw.layoutSlug && raw.layoutSlug !== before?.layoutSlug ? raw.layoutSlug : null;
    if (switchTo && !layouts.has(switchTo)) {
      problems.push(`"${id}" uses layout "${switchTo}", which does not exist — create it with create_layout first.`);
      return;
    }
    let type = raw.type;
    if (switchTo && (type === 'layout' || before?.type === 'layout')) {
      type = 'layout';
    } else if (keepsProtected) {
      type = before.type;
    } else if (!(CREATABLE as readonly string[]).includes(type)) {
      problems.push(`"${id}" has type "${type}" — use one of: ${CREATABLE.join(', ')}.`);
      return;
    }
    // Drop "not set" (null) fields so they never reach the page.
    const fields = Object.fromEntries(Object.entries(raw).filter(([, v]) => v !== null && v !== undefined));
    const node: Node = { ...fields, id, type, children: [] };
    for (const key of PROTECTED_KEYS) {
      delete node[key];
      if (before && before[key] !== undefined) node[key] = before[key];
    }
    if (type === 'layout' && switchTo) {
      // The editor fills in the new layout's title and any missing field defaults.
      node.layoutSlug = switchTo;
      delete node.layoutTitle;
    } else if (type === 'layout' && !node.layoutSlug) {
      problems.push(`"${id}" is a layout without layoutSlug.`);
      return;
    }
    // Field values only belong to theme layouts.
    if (type !== 'layout') delete node.layoutFields;
    nodes[id] = node;
    if (seen.size > MAX_SECTION_NODES) {
      problems.push(`Keep the section under ${MAX_SECTION_NODES} elements.`);
      return;
    }
    node.children = (raw.children ?? []).filter((child) => {
      visit(child, depth + 1);
      return Boolean(nodes[child]);
    });
  };
  visit(input.rootId, 0);

  if (problems.length) throw new Error(`The section was not applied: ${[...new Set(problems)].slice(0, 8).join(' ')}`);
  return { rootId: input.rootId, nodes };
}
