import { hasPending } from '../pages/pending';
import type { SectionPlacement } from '../pages/pages.content';
import { ensureSiteSectionType, placementOf, SITE_SECTION_KIND } from '../pages/site-sections';
import { sectionPreview } from './section-preview';
import { execFile } from 'child_process';
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { dirname, extname, join, relative, resolve, sep } from 'path';
import { pathToFileURL } from 'url';
import { promisify } from 'util';
import { compileString as compileSassString } from 'sass';
import { Op } from 'sequelize';

import { FieldGroup, MediaAsset, Post, PostType, Taxonomy, Term } from '../../models';
import { createTerm, setPostTaxonomies } from '../pages/page-taxonomies';
import { structureService } from '../../services/structure.service';
import { recordChange, snapshots, type ChangeContext } from './changes';
import { revalidatePublicPaths } from '../revalidate-public';
import { layoutSyncService } from '../../services/layout-sync.service';
import { fieldsService } from '../../services/fields.service';
import { pagesService } from '../../services/pages.service';
import { pageThemeScope, themesService } from '../../services/themes.service';
import { findCurrentSite } from '../../services/site-context';
import type { AuthUser } from '../../types/auth';
import { parseFields, toSlugKey, type BackendField } from '../fields/fields.types';
import { layoutPaths, layoutSlugFromTitle, resolveLayoutPaths, sanitizeLayoutSlug } from '../layouts/layout-paths';
import { readOptions } from '../site/site-options';
import { resolveClientThemeSlug, resolveThemesRoot, themeAncestry, writableThemeSlug } from '../themes/theme-registry';
import type { CapabilitySlug } from '../cms-types';
import { phpArgs, phpEnv } from '../layouts/php/php-sandbox';
import { assertPlainTemplate, checkPhpTemplate, hasScriptTag, templateProblemsText, themeWriteKind } from './template-guard';
import { untrusted } from './untrusted';

/**
 * Everything BeeQueen can touch: the client theme folder, Backend Fields groups
 * that sync into it, pages built from those layouts, and (read-only) media.
 * Core apps, the parent theme and other themes stay out of reach.
 */

const execFileAsync = promisify(execFile);

const TEXT_EXTENSIONS = new Set(['.php', '.tsx', '.scss', '.css', '.js', '.json', '.md', '.svg', '.txt']);
const MAX_READ_BYTES = 120_000;

/** preview: `url` is a private preview (the live page doesn't show what waits for Keep); `livePath` is the page itself. */
export type WorkspaceLink = {
  kind: 'layout' | 'page' | 'post' | 'product' | 'media' | 'file' | 'type' | 'entry';
  label: string;
  admin?: string;
  url?: string;
  preview?: boolean;
  livePath?: string;
};

/**
 * A private preview link for a live page whose new elements wait for Keep: the snapshot shows them,
 * visitors on the page itself don't see them yet. Null if the preview can't be made.
 */
async function waitingPreview(ws: Workspace, id: string, kind: string): Promise<string | null> {
  try {
    return (await pagesService.createPreview(ws.actor, id, {}, kind)).previewPath;
  } catch {
    return null;
  }
}

export type Workspace = {
  actor: AuthUser;
  /** Records what changed so the chat can link to it. */
  links: WorkspaceLink[];
  /** Change history: every write is recorded so the owner can revert it from Connector. */
  change?: ChangeContext;
};

type Runtime = 'php' | 'react';

async function context() {
  const active = await themesService.getActiveSlug();
  // A store theme's own files are read-only; changes go to its child folder.
  const theme = writableThemeSlug(resolveClientThemeSlug(active));
  const site = await findCurrentSite();
  const runtime: Runtime = readOptions(site?.settings?.options).frontendRuntime === 'react' ? 'react' : 'php';
  return { active, theme, ancestry: themeAncestry(theme), runtime };
}

export function addLink(ws: Workspace, link: WorkspaceLink) {
  const i = ws.links.findIndex((l) => l.kind === link.kind && l.label === link.label);
  if (i >= 0) ws.links[i] = link;
  else ws.links.push(link);
}

/** A theme-relative path, or an error when it climbs out of the theme. */
function themeRel(raw: string): string {
  const rel = raw.trim().replace(/^\/+/, '').replace(/\\/g, '/');
  if (!rel || rel.split('/').some((part) => part === '..' || part.startsWith('.'))) {
    throw new Error(`"${raw}" is not a path inside the theme.`);
  }
  return rel;
}

function inside(root: string, abs: string): boolean {
  return resolve(abs).startsWith(resolve(root) + sep);
}

/** The same refusal the tools give, for checks that depend on what is being written. */
function requireCapability(ws: Workspace, capability: CapabilitySlug, what: string) {
  if (!ws.actor.capabilities.includes(capability)) {
    throw new Error(
      `This account does not have the "${capability}" permission, which ${what} needs. Tell the owner what you wanted to do so they can grant it or make the change.`,
    );
  }
}

/** Pages / posts others wrote are listed only once published, unless the account may edit them. */
function visibleContent(ws: Workspace, editOthers: CapabilitySlug) {
  return ws.actor.capabilities.includes(editOthers)
    ? {}
    : { [Op.or]: [{ status: 'publish' }, { authorId: ws.actor.id }] };
}

function fieldSummary(fields: BackendField[], depth = 0): string[] {
  const pad = '  '.repeat(depth);
  const out: string[] = [];
  for (const f of fields) {
    const extra = [f.returnFormat ? `returns ${f.returnFormat}` : '', f.choices.length ? `choices: ${f.choices.join(' | ')}` : '']
      .filter(Boolean)
      .join(', ');
    out.push(`${pad}- ${f.name} (${f.type}) "${f.label}"${extra ? ` — ${extra}` : ''}`);
    if (f.subFields?.length) out.push(...fieldSummary(f.subFields, depth + 1));
    for (const l of f.layouts ?? []) {
      out.push(`${pad}  · row layout "${l.name}"`);
      out.push(...fieldSummary(l.subFields, depth + 2));
    }
  }
  return out;
}

// ─── Overview ─────────────────────────────────────────────────────────────────

export async function siteOverview(ws: Workspace): Promise<string> {
  const ctx = await context();
  const layouts = layoutSyncService.listPublic();
  const pages = await Post.findAll({
    where: {
      siteId: ws.actor.siteId,
      type: 'page',
      ...(await pageThemeScope('page')),
      status: { [Op.notIn]: ['auto-draft', 'trash'] },
      ...visibleContent(ws, 'edit_others_pages'),
    },
    attributes: ['id', 'title', 'slug', 'status'],
    order: [['updatedAt', 'DESC']],
    limit: 60,
  });
  const lines = [
    `Active theme: ${ctx.active} · Beekiri writes to: ${ctx.theme} (parents: ${ctx.ancestry.slice(1).join(', ') || 'none'})`,
    `Frontend runtime: ${ctx.runtime} (layout templates are ${ctx.runtime === 'php' ? '{slug}.php' : '{slug}.tsx'})`,
    '',
    `Layouts (${layouts.length}):`,
    ...(layouts.length
      ? layouts.flatMap((l) => [`• ${l.slug} — "${l.title}" [theme ${l.theme}]`, ...fieldSummary(l.fields, 1)])
      : ['(none yet)']),
    '',
    `Pages (${pages.length}):`,
    pages.length
      ? untrusted('page titles', pages.map((p) => `• ${p.id} — "${p.title}" /${p.slug} [${p.status}]`).join('\n'))
      : '(none yet)',
  ];
  return lines.join('\n');
}

// ─── Theme files ──────────────────────────────────────────────────────────────

export async function listThemeFiles(): Promise<string> {
  const ctx = await context();
  const root = resolveThemesRoot();
  const out: string[] = [];
  for (const theme of ctx.ancestry) {
    const base = join(root, theme);
    const files: string[] = [];
    const walk = (dir: string, depth: number) => {
      if (depth > 4 || files.length > 300) return;
      for (const entry of readdirSync(dir, { withFileTypes: true })) {
        if (entry.name.startsWith('.') || entry.name === 'node_modules') continue;
        const abs = join(dir, entry.name);
        if (entry.isDirectory()) walk(abs, depth + 1);
        else if (TEXT_EXTENSIONS.has(extname(entry.name))) files.push(relative(base, abs));
      }
    };
    if (existsSync(base)) walk(base, 0);
    out.push(`${theme}${theme === ctx.theme ? ' (writable)' : ' (read-only parent)'}:`, ...files.sort().map((f) => `  ${f}`));
  }
  return out.join('\n');
}

/** Child file first, then the parent's — the same lookup the site uses. */
export async function readThemeFile(rawPath: string): Promise<string> {
  const ctx = await context();
  const rel = themeRel(rawPath);
  if (!TEXT_EXTENSIONS.has(extname(rel))) throw new Error('Only text files (php, scss, css, js, json, md…) can be read.');
  const root = resolveThemesRoot();
  for (const theme of ctx.ancestry) {
    const abs = join(root, theme, rel);
    if (!existsSync(abs) || !statSync(abs).isFile()) continue;
    const body = readFileSync(abs, 'utf8');
    const clipped = body.length > MAX_READ_BYTES ? `${body.slice(0, MAX_READ_BYTES)}\n…(truncated)` : body;
    return `// ${theme}/${rel}\n${clipped}`;
  }
  throw new Error(`${rel} does not exist in ${ctx.ancestry.join(' or ')}.`);
}

/** Writes go to the client (child) theme only; layouts go through save_layout. */
export async function writeThemeFile(ws: Workspace, rawPath: string, content: string): Promise<string> {
  const ctx = await context();
  const rel = themeRel(rawPath);
  // macOS file systems ignore case: "Layouts/x" is the same folder as "layouts/x".
  const lower = rel.toLowerCase();
  if (lower === 'theme.json' || lower === 'layouts' || lower.startsWith('layouts/')) {
    throw new Error('Use save_layout for layouts — it keeps Backend Fields and the theme in sync.');
  }
  // Templates, styles and the browser script only; never code that runs on the server.
  const kind = themeWriteKind(rel);
  if (kind === 'script' || (kind === 'php' && hasScriptTag(content))) {
    requireCapability(ws, 'unfiltered_html', 'adding JavaScript to the site');
  }
  if (kind === 'php') await assertPlainTemplate(rel, content);
  const base = join(resolveThemesRoot(), ctx.theme);
  const abs = join(base, rel);
  if (!inside(base, abs)) throw new Error('That path is outside the theme.');
  const before = snapshots.themeFile(ctx.theme, rel);
  mkdirSync(dirname(abs), { recursive: true });
  writeFileSync(abs, content, 'utf8');
  await recordChange(ws.change, {
    kind: 'theme_file',
    label: `${ctx.theme}/${rel}`,
    target: { theme: ctx.theme, rel },
    before: before.content === null ? null : before,
    after: { content },
  });
  void revalidatePublicPaths(['/']);
  addLink(ws, { kind: 'file', label: `${ctx.theme}/${rel}`, admin: 'appearance' });
  return `Saved ${ctx.theme}/${rel} (${content.length} chars).`;
}

// ─── Layouts (Backend Fields ↔ theme) ─────────────────────────────────────────

/** The slug save_layout gives a layout with this title ('' if the title has no letters or digits). */
export function layoutSlugForTitle(title: string): string {
  return sanitizeLayoutSlug(layoutSlugFromTitle(title.trim()) || '') || '';
}

/** Is there a layout with this slug in the active theme (child or parent)? */
export async function layoutExists(rawSlug: string): Promise<boolean> {
  const slug = sanitizeLayoutSlug(rawSlug);
  if (!slug) return false;
  const ctx = await context();
  return existsSync(resolveLayoutPaths(slug, ctx.theme).meta);
}

export async function readLayout(rawSlug: string): Promise<string> {
  const slug = sanitizeLayoutSlug(rawSlug);
  if (!slug) throw new Error('Give a layout slug.');
  const ctx = await context();
  const paths = resolveLayoutPaths(slug, ctx.theme);
  if (!existsSync(paths.dir)) throw new Error(`No layout "${slug}". Call get_site_overview for the list.`);
  const read = (p: string) => (existsSync(p) ? readFileSync(p, 'utf8') : '(missing)');
  return [
    `Layout ${slug} in theme ${paths.themeSlug}`,
    `--- ${slug}.meta.json (Backend Fields definition)\n${read(paths.meta)}`,
    `--- ${ctx.runtime === 'php' ? `${slug}.php` : `${slug}.tsx`}\n${read(ctx.runtime === 'php' ? paths.php : paths.tsx)}`,
    `--- styles.scss\n${read(paths.scss)}`,
    `--- script.js\n${read(paths.js)}`,
  ].join('\n\n');
}

export type SaveLayoutInput = {
  title: string;
  description?: string;
  fields: Record<string, unknown>[];
  template: string;
  scss: string;
  js?: string;
};

/** Values that exercise a template once so PHP errors show up before a page uses it. */
function sampleValues(fields: BackendField[]): Record<string, unknown> {
  const row: Record<string, unknown> = {};
  for (const f of fields) {
    switch (f.type) {
      case 'repeater':
        row[f.name] = [sampleValues(f.subFields ?? []), sampleValues(f.subFields ?? [])];
        break;
      case 'group':
        row[f.name] = sampleValues(f.subFields ?? []);
        break;
      case 'flexible_content':
        row[f.name] = (f.layouts ?? []).map((l) => ({ acf_fc_layout: l.name, ...sampleValues(l.subFields) }));
        break;
      case 'image':
        row[f.name] = 'https://placehold.co/1200x800.png';
        break;
      case 'gallery':
        row[f.name] = ['https://placehold.co/800x600.png'];
        break;
      case 'link':
        row[f.name] = { title: 'Learn more', url: '/', target: '' };
        break;
      case 'url':
        row[f.name] = 'https://example.com';
        break;
      case 'true_false':
        row[f.name] = true;
        break;
      case 'number':
      case 'range':
        row[f.name] = 3;
        break;
      case 'select':
      case 'radio':
      case 'button_group':
      case 'checkbox': {
        const first = (f.choices[0] ?? '').split(':')[0].trim();
        row[f.name] = f.type === 'checkbox' || f.multiple ? [first] : first;
        break;
      }
      case 'message':
      case 'accordion':
      case 'tab':
        break;
      case 'form':
        row[f.name] = { ID: 'sample', title: 'Sample form', html: '<div class="bk-form"></div>' };
        break;
      default:
        row[f.name] = `Sample ${f.label}`;
    }
  }
  return row;
}

/** Keep field ids stable across edits so saved values and the editor stay attached. */
function keepFieldIds(next: BackendField[], prev: BackendField[]): BackendField[] {
  const byName = new Map(prev.map((f) => [f.name, f]));
  return next.map((f) => {
    const old = byName.get(f.name);
    const merged: BackendField = old ? { ...f, id: old.id } : f;
    if (f.subFields) merged.subFields = keepFieldIds(f.subFields, old?.subFields ?? []);
    return merged;
  });
}

/** `php -l` on a scratch copy, so a broken draft is caught before it replaces a working template. */
async function lintPhp(source: string, slug: string): Promise<string | null> {
  const scratch = join(tmpdir(), `beequeen-${slug}-${Math.random().toString(36).slice(2, 8)}.php`);
  writeFileSync(scratch, source, 'utf8');
  try {
    await execFileAsync('php', phpArgs(['-l', scratch]), { timeout: 8000, env: phpEnv() });
    return null;
  } catch (e) {
    const err = e as { code?: string; stdout?: string; stderr?: string; message: string };
    if (err.code === 'ENOENT') return null; // No PHP CLI here; the render check reports it.
    const out = (err.stdout || err.stderr || err.message).split(scratch).join(`${slug}.php`);
    return `PHP syntax error: ${out.replace(/\s*Errors parsing.*$/s, '').trim()}`;
  } finally {
    rmSync(scratch, { force: true });
  }
}

/** Every field name a template reads, so typos against the field group surface early. */
function fieldNames(fields: BackendField[], into = new Set<string>()): Set<string> {
  for (const f of fields) {
    into.add(f.name);
    if (f.subFields) fieldNames(f.subFields, into);
    for (const l of f.layouts ?? []) fieldNames(l.subFields, into);
  }
  return into;
}

function unknownFieldReads(template: string, fields: BackendField[]): string[] {
  const known = fieldNames(fields);
  const read = [...template.matchAll(/(?:get_bee_field|the_bee_field|have_bee_rows)\(\s*['"]([A-Za-z0-9_]+)['"]/g)].map((m) => m[1]);
  return [...new Set(read.filter((name) => !known.has(name)))];
}

async function checkRender(slug: string, fields: BackendField[]): Promise<string[]> {
  const problems: string[] = [];
  const html = await layoutSyncService.renderPhpLayout(slug, sampleValues(fields));
  if (html == null) problems.push('The template did not render with sample values (PHP runtime error).');
  else if (/(Fatal error|Warning|Notice|Deprecated):/i.test(html)) {
    problems.push(`PHP printed an error while rendering sample values:\n${html.slice(0, 1500)}`);
  } else if (!html.includes(`data-layout="${slug}"`)) {
    problems.push(`The root element must carry data-layout="${slug}" so the site loads its CSS/JS.`);
  }
  return problems;
}

export async function saveLayout(ws: Workspace, input: SaveLayoutInput): Promise<string> {
  const ctx = await context();
  const title = input.title.trim();
  const slug = sanitizeLayoutSlug(layoutSlugFromTitle(title) || '');
  if (!slug) throw new Error('Give the layout a title made of letters or numbers.');
  // Backend Fields names folders after the group key for titles like this, so the slug would not match.
  if (slug.startsWith('group-')) throw new Error('Pick a layout title that does not start with "Group".');
  const fields = parseFields(input.fields);
  if (input.fields.length && fields.length < input.fields.length) {
    throw new Error('Some fields were dropped: every field needs a label and a snake_case name.');
  }

  // Check the draft before touching Backend Fields or the theme: a broken draft must
  // never replace a layout that live pages already render.
  const draftProblems: string[] = [];
  try {
    compileSassString(input.scss, {
      loadPaths: [layoutPaths(slug, ctx.theme).dir],
      url: pathToFileURL(layoutPaths(slug, ctx.theme).scss),
    });
  } catch (e) {
    draftProblems.push(`SCSS does not compile: ${(e as Error).message}`);
  }
  if ((input.js !== undefined && input.js.trim() !== '') || hasScriptTag(input.template)) {
    requireCapability(ws, 'unfiltered_html', 'a layout with JavaScript (script.js or a <script> tag)');
  }
  if (ctx.runtime === 'php') {
    const lint = await lintPhp(input.template, slug);
    if (lint) draftProblems.push(lint);
    else {
      // Only a plain template (values, ifs and loops) — never code that runs on the server.
      const refused = await checkPhpTemplate(input.template);
      if (refused.length) draftProblems.push(templateProblemsText(`${slug}.php`, refused));
    }
  }
  if (draftProblems.length) {
    throw new Error(
      `Nothing was saved — fix and call save_layout again:\n${draftProblems.map((p) => `- ${p}`).join('\n')}`,
    );
  }

  // Same slug → same Backend Fields group: update it instead of making a duplicate.
  const existingMeta = layoutPaths(slug, ctx.theme).meta;
  let existingKey: string | null = null;
  if (existsSync(existingMeta)) {
    try {
      existingKey = (JSON.parse(readFileSync(existingMeta, 'utf8')) as { key?: string }).key ?? null;
    } catch {
      existingKey = null;
    }
  }
  const key = existingKey ?? toSlugKey(title);
  const group = await FieldGroup.findOne({ where: { siteId: ws.actor.siteId, key, trashedAt: null } });
  // Change history: the layout's own files and its field group, as they are now.
  const layoutRel = (abs: string) => relative(join(resolveThemesRoot(), ctx.theme), abs).replace(/\\/g, '/');
  const lp = layoutPaths(slug, ctx.theme);
  const layoutFiles = [ctx.runtime === 'php' ? lp.php : lp.tsx, lp.scss, lp.js].map(layoutRel);
  const beforeLayout = group
    ? { group: await snapshots.fieldGroup(ws.actor.siteId, key), files: snapshots.layoutFiles(ctx.theme, layoutFiles) }
    : null;

  const created = !group;
  if (group) {
    await fieldsService.update(ws.actor, group.id, {
      title,
      active: true,
      location: ['page'],
      fields: keepFieldIds(fields, parseFields(group.fields)),
      ...(input.description !== undefined ? { description: input.description } : {}),
    });
  } else {
    await fieldsService.create(ws.actor, {
      title,
      key,
      description: input.description ?? 'Built by Beekiri.',
      active: true,
      location: ['page'],
      fields,
    });
  }

  // Backend Fields just synced the folder; now lay BeeQueen's own files over it.
  // No @beekiri-managed marker, so later field edits never overwrite this design.
  const paths = layoutPaths(slug, ctx.theme);
  mkdirSync(paths.dir, { recursive: true });
  // React templates (.tsx) run on the server: there the template Backend Fields generates stays.
  if (ctx.runtime === 'php') writeFileSync(paths.php, input.template.replace(/^.*@beekiri-managed.*\n/m, ''), 'utf8');
  writeFileSync(paths.scss, input.scss.replace(/^.*@beekiri-managed.*\n/m, ''), 'utf8');
  if (input.js !== undefined) writeFileSync(paths.js, input.js.replace(/^.*@beekiri-managed.*\n/m, ''), 'utf8');

  const problems: string[] = [];
  try {
    layoutSyncService.compileSlug(slug);
  } catch (e) {
    problems.push(`SCSS did not compile: ${(e as Error).message}`);
  }
  const unknown = ctx.runtime === 'php' ? unknownFieldReads(input.template, fields) : [];
  if (unknown.length) {
    problems.push(`The template reads ${unknown.join(', ')}, which ${unknown.length === 1 ? 'is' : 'are'} not in the field list.`);
  }
  if (ctx.runtime === 'php') problems.push(...(await checkRender(slug, fields)));
  // The site caches its layout list; refresh it so pages pick up this layout's CSS/JS right away.
  void revalidatePublicPaths(['/']);

  const savedGroup = await FieldGroup.findOne({ where: { siteId: ws.actor.siteId, key, trashedAt: null }, attributes: ['id'] });
  await recordChange(ws.change, {
    kind: 'layout',
    label: `Layout “${title}”`,
    target: { theme: ctx.theme, slug, key },
    before: beforeLayout,
    after: { groupId: savedGroup?.id ?? null, files: snapshots.layoutFiles(ctx.theme, layoutFiles) },
  });

  addLink(ws, { kind: 'layout', label: title, admin: 'fields' });
  const head = `${created ? 'Created' : 'Updated'} layout "${title}" (slug ${slug}) in ${ctx.theme}/layouts/${slug}/ and Backend Fields group ${key}.${
    ctx.runtime === 'react' ? ' This site renders with React: its .tsx template runs on the server, so Beekiri keeps the one Backend Fields generates from the fields and did not write yours.' : ''
  }`;
  return problems.length
    ? `${head}\nPROBLEMS — fix and call save_layout again:\n${problems.map((p) => `- ${p}`).join('\n')}`
    : `${head}\nSCSS compiled and the template rendered cleanly with sample values.`;
}

// ─── Pages (BeekiriCode documents) ────────────────────────────────────────────

/** A BeekiriCode element. Only the fields Beekiri edits are named; the rest (loops, bindings, video options…) ride along untouched. */
type DocNode = {
  id: string;
  type: string;
  tag?: string;
  text?: string;
  src?: string;
  alt?: string;
  href?: string;
  newTab?: boolean;
  layoutSlug?: string;
  layoutTitle?: string;
  layoutFields?: Record<string, unknown>;
  cssClass?: string;
  style?: Record<string, string>;
  hoverStyle?: Record<string, string>;
  stylesByBreakpoint?: { tablet?: Record<string, string>; mobile?: Record<string, string> };
  hiddenOn?: ('desktop' | 'tablet' | 'mobile')[];
  children: string[];
  [key: string]: unknown;
};

type PageDoc = { version: 1; rootId: string; nodes: Record<string, DocNode> };

const ELEMENT_TAGS: Record<string, string> = {
  section: 'section',
  container: 'div',
  heading: 'h2',
  text: 'p',
  image: 'img',
  button: 'a',
  video: 'div',
  list: 'ul',
  divider: 'hr',
  spacer: 'div',
  icon: 'span',
  accordion: 'div',
  tabs: 'div',
  map: 'div',
  rating: 'div',
};

/** Accordion / Tabs rows from the model: title + text pairs, capped. */
function blockItems(raw: unknown): { title: string; text: string }[] | undefined {
  if (!Array.isArray(raw)) return undefined;
  return raw
    .filter((it): it is Record<string, unknown> => Boolean(it) && typeof it === 'object' && !Array.isArray(it))
    .slice(0, 40)
    .map((it) => ({ title: String(it.title ?? '').slice(0, 300), text: String(it.text ?? '').slice(0, 8000) }));
}

const rid = (prefix: string) => `${prefix}_${Math.random().toString(36).slice(2, 10)}`;

function styleBag(raw: unknown): Record<string, string> | undefined {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return undefined;
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    if (typeof v === 'string' || typeof v === 'number') {
      out[k.replace(/-([a-z])/g, (_, c: string) => c.toUpperCase())] = String(v);
    }
  }
  return Object.keys(out).length ? out : undefined;
}

/** Tablet / phone overrides as the editor stores them; undefined when there are none. */
function breakpointStyles(raw: unknown): DocNode['stylesByBreakpoint'] {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return undefined;
  const r = raw as Record<string, unknown>;
  const tablet = styleBag(r.tablet);
  const mobile = styleBag(r.mobile);
  return tablet || mobile ? { ...(tablet ? { tablet } : {}), ...(mobile ? { mobile } : {}) } : undefined;
}

const BREAKPOINTS = ['desktop', 'tablet', 'mobile'] as const;

function isDoc(doc: unknown): doc is PageDoc {
  const d = doc as PageDoc | null;
  return Boolean(d && typeof d === 'object' && d.nodes && d.rootId && d.nodes[d.rootId]);
}

/**
 * Block specs from the model → BeekiriCode nodes, validating layouts as we go. With the page's
 * current document, a block that carries the id of an existing element starts from that element:
 * everything Beekiri didn't send (phone/tablet styles, hover, loops, bindings, video options…)
 * is kept, so re-saving a page never strips what the owner or the theme set up.
 */
export function buildDoc(
  blocks: unknown[],
  layouts: Map<string, { title: string; fields: BackendField[] }>,
  existing?: PageDoc | null,
  opts: { removeConfirmed?: boolean; pendingRun?: string } = {},
): PageDoc {
  const nodes: Record<string, DocNode> = {};
  const errors: string[] = [];
  const old = existing?.nodes ?? {};

  const build = (raw: unknown, where: string): string | null => {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
      errors.push(`${where}: each block must be an object.`);
      return null;
    }
    const b = raw as Record<string, unknown>;
    const prev = typeof b.id === 'string' && old[b.id] && !nodes[b.id] && b.id !== existing?.rootId ? old[b.id] : null;
    const type = typeof b.type === 'string' ? b.type : (prev?.type ?? '');
    if (type === 'layout') {
      const slug = sanitizeLayoutSlug(String(b.layout ?? b.slug ?? prev?.layoutSlug ?? '')) ?? '';
      const layout = layouts.get(slug);
      if (!layout) {
        errors.push(`${where}: layout "${slug}" does not exist — create it with save_layout first.`);
        return null;
      }
      const values =
        b.fields && typeof b.fields === 'object' && !Array.isArray(b.fields)
          ? (b.fields as Record<string, unknown>)
          : (prev?.layoutFields ?? {});
      const known = new Set(layout.fields.map((f) => f.name));
      const unknown = Object.keys(values).filter((k) => !known.has(k));
      if (unknown.length) {
        errors.push(`${where}: layout "${slug}" has no field(s) ${unknown.join(', ')} (it has ${[...known].join(', ') || 'none'}).`);
      }
      const id = prev?.type === 'layout' ? prev.id : rid('lay');
      nodes[id] = {
        ...(prev?.type === 'layout' ? prev : {}),
        id,
        type: 'layout',
        tag: prev?.tag ?? 'section',
        layoutSlug: slug,
        layoutTitle: layout.title,
        layoutFields: values,
        text: layout.title,
        style: prev?.style ?? {},
        children: [],
      };
      return id;
    }
    // Elements Beekiri can't create (forms, shop blocks…) may still stay where they are.
    if (!(type in ELEMENT_TAGS) && !(prev && prev.type === type)) {
      errors.push(`${where}: unknown block type "${type}". Use layout, ${Object.keys(ELEMENT_TAGS).join(', ')}.`);
      return null;
    }
    const base: Partial<DocNode> = prev && prev.type === type ? prev : {};
    const id = base.id ?? rid(type.slice(0, 3));
    const node: DocNode = {
      ...base,
      id,
      type,
      tag: typeof b.tag === 'string' && /^[a-z][a-z0-9]*$/.test(b.tag) ? b.tag : base.id ? base.tag : ELEMENT_TAGS[type],
      style: 'style' in b ? styleBag(b.style) : base.style,
      children: [],
    };
    for (const k of ['text', 'src', 'alt', 'href', 'cssClass'] as const) {
      if (typeof b[k] === 'string') node[k] = b[k] as string;
    }
    if (typeof b.newTab === 'boolean') node.newTab = b.newTab;
    // Icon, Accordion / Tabs, Map and Star rating keep their content in fields of their own.
    if (typeof b.icon === 'string') node.icon = b.icon.slice(0, 60);
    if (typeof b.address === 'string') node.address = b.address.slice(0, 300);
    if (typeof b.zoom === 'number' && Number.isFinite(b.zoom)) node.zoom = Math.min(20, Math.max(1, Math.round(b.zoom)));
    if (typeof b.rating === 'number' && Number.isFinite(b.rating)) node.rating = Math.min(5, Math.max(0, b.rating));
    if ('items' in b) node.items = blockItems(b.items) ?? node.items;
    if ('hoverStyle' in b) node.hoverStyle = styleBag(b.hoverStyle);
    if ('stylesByBreakpoint' in b) node.stylesByBreakpoint = breakpointStyles(b.stylesByBreakpoint);
    if ('hiddenOn' in b) {
      const hidden = Array.isArray(b.hiddenOn) ? BREAKPOINTS.filter((bp) => (b.hiddenOn as unknown[]).includes(bp)) : [];
      node.hiddenOn = hidden.length ? hidden : undefined;
    }
    for (const k of ['tag', 'style', 'hoverStyle', 'stylesByBreakpoint', 'hiddenOn'] as const) if (node[k] === undefined) delete node[k];
    nodes[id] = node;
    const kids = Array.isArray(b.children) ? b.children : null;
    // An existing element sent without "children" keeps everything inside it, untouched. That is how a
    // page gets a new section without re-sending (or losing) the others.
    if (!kids && base.id && base.children?.length) {
      node.children = base.children.filter((cid) => keepSubtree(cid));
    }
    if (kids) {
      if (type !== 'section' && type !== 'container' && !base.children?.length) {
        errors.push(`${where}: only section and container blocks can have children.`);
      } else {
        kids.forEach((child, i) => {
          const cid = build(child, `${where}.children[${i}]`);
          if (cid) node.children.push(cid);
        });
      }
    }
    return id;
  };

  /** Copies an existing element and everything inside it, as it is. */
  const keepSubtree = (nid: string): boolean => {
    const n = old[nid];
    if (!n || nodes[nid] || nid === existing?.rootId) return false;
    nodes[nid] = { ...n, children: [] };
    nodes[nid].children = (n.children ?? []).filter((cid) => keepSubtree(cid));
    return true;
  };

  const children: string[] = [];
  blocks.forEach((block, i) => {
    const id = build(block, `blocks[${i}]`);
    if (id) children.push(id);
  });
  if (errors.length) throw new Error(`The page was not saved:\n${errors.map((e) => `- ${e}`).join('\n')}`);
  // Nothing on the page disappears by accident: removing content needs the user's request behind it.
  if (existing && !opts.removeConfirmed) {
    const gone = Object.values(old).filter((n) => n.id !== existing.rootId && !nodes[n.id]);
    if (gone.length) {
      const top = (old[existing.rootId]?.children ?? []).filter((cid) => !nodes[cid]).map((cid) => `"${(old[cid] as { label?: string } | undefined)?.label || old[cid]?.layoutTitle || old[cid]?.text || old[cid]?.type || cid}" (${cid})`);
      throw new Error(
        `The page was not saved: it would remove ${gone.length} existing element(s)${top.length ? `, including the section(s) ${top.join(', ')}` : ''}. ` +
          'To keep a section or element as it is, send just {"id": "<its id>"} (no children) and everything inside it stays. ' +
          'Only if the user asked to remove these, call save_page again with "removeConfirmed": true.',
      );
    }
  }
  // Re-sending a page without its ids re-creates every element and loses its phone/tablet styles.
  if (existing) {
    const lost = Object.values(old).filter((n) => n.stylesByBreakpoint && !nodes[n.id]);
    if (lost.length >= 3 && Object.keys(nodes).length + 1 >= 0.8 * Object.keys(old).length) {
      throw new Error(
        `The page was not saved: ${lost.length} elements that have phone/tablet styles would be re-created without them. Call get_page and send every block back with its "id" unchanged, then add your change.`,
      );
    }
  }
  // On a live page, what Beekiri adds stays off the public site until the owner presses Keep.
  if (existing && opts.pendingRun) {
    for (const [nid, n] of Object.entries(nodes)) if (!old[nid]) (n as DocNode & { pending?: string }).pending = opts.pendingRun;
  }
  // The page root keeps its own settings; the theme already wraps pages in <main>.
  const root = existing ? old[existing.rootId] : null;
  const rootId = root?.id ?? rid('root');
  nodes[rootId] = root ? { ...root, children } : { id: rootId, type: 'section', tag: 'div', style: {}, children };
  return { version: 1, rootId, nodes };
}

/**
 * BeekiriCode document → the same block shape save_page takes, for editing. Every element carries
 * its id (send it back so the element keeps everything else it has) and its phone/tablet styles.
 */
export function docToBlocks(doc: unknown): unknown[] {
  if (!isDoc(doc)) return [];
  const d = doc;
  const toBlock = (id: string): unknown => {
    const n = d.nodes[id];
    if (!n) return null;
    if (n.type === 'layout') return { id: n.id, type: 'layout', layout: n.layoutSlug, fields: n.layoutFields ?? {} };
    const out: Record<string, unknown> = { id: n.id, type: n.type };
    for (const k of ['tag', 'text', 'src', 'alt', 'href', 'newTab', 'cssClass', 'icon', 'items', 'address', 'zoom', 'rating'] as const) {
      if (n[k] !== undefined && n[k] !== '') out[k] = n[k];
    }
    if (n.style && Object.keys(n.style).length) out.style = n.style;
    if (n.hoverStyle && Object.keys(n.hoverStyle).length) out.hoverStyle = n.hoverStyle;
    if (n.stylesByBreakpoint && (n.stylesByBreakpoint.tablet || n.stylesByBreakpoint.mobile)) out.stylesByBreakpoint = n.stylesByBreakpoint;
    if (n.hiddenOn?.length) out.hiddenOn = n.hiddenOn;
    if (n.children?.length) out.children = n.children.map(toBlock).filter(Boolean);
    return out;
  };
  return (d.nodes[d.rootId].children ?? []).map(toBlock).filter(Boolean);
}

export async function getPage(ws: Workspace, id: string, kind: string = 'page'): Promise<string> {
  const page = await pagesService.get(ws.actor, id, kind);
  return untrusted(`${kind} content`, JSON.stringify(
    {
      id: page.id,
      title: page.title,
      slug: page.slug,
      status: page.status,
      path: page.path,
      ...(kind === 'post' ? { excerpt: page.excerpt, featuredImageId: page.featuredImageId } : {}),
      blocks: docToBlocks(page.beekiricode),
    },
    null,
    1,
  ));
}

export type SavePageInput = {
  id?: string;
  title: string;
  slug?: string;
  status?: 'draft' | 'publish';
  blocks: unknown[];
  /** The user asked to remove content: existing elements left out of `blocks` may go. */
  removeConfirmed?: boolean;
};

/** How one content kind is saved and shown in Beekiri's links. */
type ContentSave = { kind: string; noun: string; admin: (id: string) => string };

/**
 * Create or update an entry of any content kind (pages, site sections, custom content types) from
 * blocks, recorded for Undo. On a live entry, what Beekiri adds waits for the owner's Keep.
 */
async function saveContent(
  ws: Workspace,
  how: ContentSave,
  input: SavePageInput & { placement?: SectionPlacement },
): Promise<{ page: Awaited<ReturnType<typeof pagesService.get>>; waiting: boolean; pendingRun?: string }> {
  const layouts = new Map(layoutSyncService.listPublic().map((l) => [l.slug, { title: l.title, fields: l.fields }]));
  const existing = input.id ? await pagesService.get(ws.actor, input.id, how.kind) : null;
  const current = existing?.beekiricode ?? null;
  // Live already, or going live new: what Beekiri adds waits for Keep (site sections show everywhere).
  const goesLive = existing ? existing.status === 'publish' : how.kind === SITE_SECTION_KIND && input.status === 'publish';
  const pendingRun = goesLive ? ws.change?.runId : undefined;
  const doc = buildDoc(input.blocks, layouts, isDoc(current) ? current : null, { removeConfirmed: input.removeConfirmed === true, pendingRun });
  if (!existing && pendingRun) {
    for (const n of Object.values(doc.nodes)) if (n.id !== doc.rootId) (n as DocNode & { pending?: string }).pending = pendingRun;
  }
  const body = {
    title: input.title.trim(),
    ...(input.slug ? { slug: input.slug } : {}),
    ...(input.status ? { status: input.status } : {}),
    ...(input.placement ? { placement: input.placement } : {}),
    beekiricode: doc as unknown as Record<string, unknown>,
  };
  const before = input.id ? await snapshots.page(ws.actor, input.id, how.kind) : null;
  const page = input.id
    ? await pagesService.update(ws.actor, input.id, body as never, how.kind)
    : await pagesService.create(ws.actor, { ...body, status: input.status ?? 'draft' } as never, how.kind);
  await recordChange(ws.change, {
    kind: 'page',
    label: `${how.noun} “${page.title}”`,
    target: { pageId: page.id, ...(how.kind !== 'page' ? { kind: how.kind } : {}) },
    before,
    after: await snapshots.page(ws.actor, page.id, how.kind),
  });
  return { page, waiting: hasPending(page.beekiricode, pendingRun), pendingRun };
}

const WAITING_NOTE =
  ' What you added is hidden from visitors until the owner presses Keep under your reply (Undo removes it); the Preview link shows it. Tell the owner that.';

export async function savePage(ws: Workspace, input: SavePageInput): Promise<string> {
  const { page, waiting } = await saveContent(ws, { kind: 'page', noun: 'Page', admin: (id) => `pages/${id}` }, input);
  const preview = waiting ? await waitingPreview(ws, page.id, 'page') : null;
  addLink(ws, {
    kind: 'page',
    label: page.title,
    admin: `pages/${page.id}`,
    url: preview ?? (page.status === 'publish' ? page.path : undefined),
    ...(preview ? { preview: true, livePath: page.path } : {}),
  });
  return (
    `${input.id ? 'Updated' : 'Created'} page "${page.title}" (id ${page.id}, ${page.status}) at ${page.path} with ${input.blocks.length} top-level blocks.` +
    (waiting ? `${WAITING_NOTE} Edits to existing elements are already live.` : '')
  );
}

// ─── Content types and their entries ─────────────────────────────────────────

/** Content kinds Beekiri saves through their own tools, never as generic entries. */
const OWN_TOOLS = new Set(['page', 'post', 'product', SITE_SECTION_KIND]);

export async function listContentTypes(ws: Workspace): Promise<string> {
  const rows = await PostType.findAll({ where: { siteId: ws.actor.siteId }, order: [['menuOrder', 'ASC']] });
  if (!rows.length) return 'No custom content types yet (pages, posts and products are built in). Create one with save_content_type.';
  const lines = await Promise.all(
    rows.map(async (t) => {
      const count = await Post.count({ where: { siteId: ws.actor.siteId, type: t.slug, status: { [Op.in]: ['draft', 'publish'] } } });
      const builtIn = t.slug === SITE_SECTION_KIND ? ' · built in: site sections (save_site_section); the owner may rename this menu with save_content_type' : '';
      return `• ${t.id} — "${t.plural}" (slug ${t.slug}, one is a "${t.singular}") · ${t.public ? 'public pages' : 'not public on its own'} · ${t.active ? 'on' : 'off'} · ${count} entr${count === 1 ? 'y' : 'ies'}${builtIn}`;
    }),
  );
  return lines.join('\n');
}

export type SaveContentTypeInput = {
  id?: string;
  slug: string;
  singular: string;
  plural: string;
  description?: string;
  public?: boolean;
  hasArchive?: boolean;
  menuIcon?: string;
};

/** The owner's name for site sections (they may rename the menu, e.g. to "Popups"). */
async function siteSectionNames(siteId: string): Promise<{ singular: string; plural: string }> {
  const row = await PostType.findOne({ where: { siteId, slug: SITE_SECTION_KIND }, attributes: ['singular', 'plural'] });
  return { singular: row?.singular || 'Site section', plural: row?.plural || 'Site sections' };
}

export async function saveContentType(ws: Workspace, input: SaveContentTypeInput): Promise<string> {
  // The site-sections menu is the owner's to name ("Popups", "Banners"…); its slug and behaviour stay.
  if (input.slug === SITE_SECTION_KIND) return renameSiteSections(ws, input);
  if (OWN_TOOLS.has(input.slug)) throw new Error(`"${input.slug}" is built in — use its own tools.`);
  const before = input.id ? await snapshots.postType(ws.actor.siteId, input.id) : null;
  const dto = {
    slug: input.slug,
    singular: input.singular,
    plural: input.plural,
    ...(input.description !== undefined ? { description: input.description } : {}),
    ...(input.public !== undefined ? { public: input.public } : {}),
    ...(input.hasArchive !== undefined ? { hasArchive: input.hasArchive } : {}),
    ...(input.menuIcon ? { menuIcon: input.menuIcon } : {}),
  };
  const row = input.id
    ? await structureService.updatePostType(ws.actor, input.id, dto as never)
    : await structureService.createPostType(ws.actor, { ...dto, showInMenu: true, active: true } as never);
  await recordChange(ws.change, {
    kind: 'post_type',
    label: `Content type “${row.plural}”`,
    target: { id: row.id },
    before,
    after: await snapshots.postType(ws.actor.siteId, row.id),
  });
  addLink(ws, { kind: 'type', label: row.plural, admin: `content/${row.slug}` });
  return `${input.id ? 'Updated' : 'Created'} the content type "${row.plural}" (slug ${row.slug}, id ${row.id}). It has its own menu entry; add entries with save_entry (type "${row.slug}").`;
}

async function renameSiteSections(ws: Workspace, input: SaveContentTypeInput): Promise<string> {
  await ensureSiteSectionType(ws.actor.siteId);
  const row = await PostType.findOne({ where: { siteId: ws.actor.siteId, slug: SITE_SECTION_KIND } });
  if (!row) throw new Error('The site sections menu could not be found.');
  const before = await snapshots.postType(ws.actor.siteId, row.id);
  const updated = await structureService.updatePostType(ws.actor, row.id, {
    singular: input.singular,
    plural: input.plural,
    ...(input.description !== undefined ? { description: input.description } : {}),
    ...(input.menuIcon ? { menuIcon: input.menuIcon } : {}),
  } as never);
  await recordChange(ws.change, {
    kind: 'post_type',
    label: `Menu “${updated.plural}”`,
    target: { id: row.id },
    before,
    after: await snapshots.postType(ws.actor.siteId, row.id),
  });
  addLink(ws, { kind: 'type', label: updated.plural, admin: `content/${SITE_SECTION_KIND}` });
  return `The site sections menu is now called "${updated.plural}" (one is a "${updated.singular}"). Everything in it works as before; its address in the admin stays /content/${SITE_SECTION_KIND}.`;
}

export async function listEntries(ws: Workspace, type: string): Promise<string> {
  const rows = await Post.findAll({
    where: { siteId: ws.actor.siteId, type, status: { [Op.in]: ['draft', 'publish'] }, ...(await pageThemeScope(type)), ...visibleContent(ws, 'edit_others_posts') },
    attributes: ['id', 'title', 'slug', 'status'],
    order: [['updatedAt', 'DESC']],
    limit: 100,
  });
  if (!rows.length) return `No "${type}" entries yet.`;
  return untrusted(`${type} titles`, rows.map((p) => `• ${p.id} — "${p.title}" (${p.status})`).join('\n'));
}

export type SaveEntryInput = SavePageInput & { type: string };

export async function saveEntry(ws: Workspace, input: SaveEntryInput): Promise<string> {
  if (OWN_TOOLS.has(input.type)) throw new Error(`Use the ${input.type === SITE_SECTION_KIND ? 'save_site_section' : `save_${input.type}`} tool for "${input.type}".`);
  const type = await PostType.findOne({ where: { siteId: ws.actor.siteId, slug: input.type, active: true } });
  if (!type) throw new Error(`There is no content type "${input.type}". list_content_types shows them; save_content_type creates one.`);
  const { page, waiting } = await saveContent(ws, { kind: type.slug, noun: type.singular, admin: (id) => `content/${type.slug}/${id}` }, input);
  const preview = waiting && type.public ? await waitingPreview(ws, page.id, type.slug) : null;
  addLink(ws, {
    kind: 'entry',
    label: page.title,
    admin: `content/${type.slug}/${page.id}`,
    url: preview ?? (page.status === 'publish' && type.public ? page.path : undefined),
    ...(preview ? { preview: true, livePath: page.path } : {}),
  });
  return `${input.id ? 'Updated' : 'Created'} ${type.singular} "${page.title}" (id ${page.id}, ${page.status}).${waiting ? WAITING_NOTE : ''}`;
}

// ─── Site sections (popups, banners… on every page) ──────────────────────────

export async function listSiteSections(ws: Workspace): Promise<string> {
  const rows = await Post.findAll({
    where: { siteId: ws.actor.siteId, type: SITE_SECTION_KIND, status: { [Op.in]: ['draft', 'publish'] }, ...(await pageThemeScope(SITE_SECTION_KIND)) },
    attributes: ['id', 'title', 'status', 'content'],
    order: [['menuOrder', 'ASC'], ['createdAt', 'ASC']],
  });
  if (!rows.length) return 'No site sections yet. save_site_section makes one (a popup, banner, announcement bar…) that shows on every page or the pages chosen.';
  return untrusted(
    'site section titles',
    rows
      .map((r) => {
        const p = placementOf(r.content);
        return `• ${r.id} — "${r.title}" (${r.status === 'publish' ? 'on' : 'off'}) · ${p.position} of ${p.pages === 'all' ? 'every page' : `${p.pages.length} page(s): ${p.pages.join(', ')}`}`;
      })
      .join('\n'),
  );
}

export type SaveSiteSectionInput = SavePageInput & { position?: 'top' | 'bottom'; pages?: 'all' | string[] };

export async function saveSiteSection(ws: Workspace, input: SaveSiteSectionInput): Promise<string> {
  await ensureSiteSectionType(ws.actor.siteId);
  const current = input.id ? await pagesService.get(ws.actor, input.id, SITE_SECTION_KIND) : null;
  const was = current ? placementOf({ placement: (current as { placement?: unknown }).placement }) : null;
  const placement: SectionPlacement = {
    position: input.position ?? was?.position ?? 'bottom',
    pages: input.pages ?? was?.pages ?? 'all',
  };
  if (placement.pages !== 'all') {
    const found = await Post.count({ where: { siteId: ws.actor.siteId, id: placement.pages, type: 'page' } });
    if (found !== placement.pages.length) throw new Error('Some of those page ids are not pages on this site — get_site_overview lists them.');
  }
  const { page, waiting } = await saveContent(
    ws,
    { kind: SITE_SECTION_KIND, noun: 'Site section', admin: (id) => `content/${SITE_SECTION_KIND}/${id}` },
    { ...input, status: input.status ?? (current ? undefined : 'publish'), placement },
  );
  const preview = waiting ? await sectionPreview(ws.actor, placement) : null;
  addLink(ws, {
    kind: 'entry',
    label: `Site section “${page.title}”`,
    admin: `content/${SITE_SECTION_KIND}/${page.id}`,
    ...(preview ? { url: preview.url, preview: true, livePath: preview.livePath } : {}),
  });
  const where = `${placement.position} of ${placement.pages === 'all' ? 'every page' : `${placement.pages.length} chosen page(s)`}`;
  return (
    `${input.id ? 'Updated' : 'Created'} the site section "${page.title}" (id ${page.id}, ${page.status === 'publish' ? 'on' : 'off'}) at the ${where}. ` +
    `The owner edits it once under "${(await siteSectionNames(ws.actor.siteId)).plural}" in the admin menu and it changes everywhere; drafting it turns it off.` +
    (waiting ? WAITING_NOTE : '')
  );
}

// ─── Blog posts ───────────────────────────────────────────────────────────────

export async function listPosts(ws: Workspace): Promise<string> {
  const rows = await Post.findAll({
    where: {
      siteId: ws.actor.siteId,
      type: 'post',
      ...(await pageThemeScope('post')),
      status: { [Op.in]: ['draft', 'publish'] },
      ...visibleContent(ws, 'edit_others_posts'),
    },
    attributes: ['id', 'title', 'slug', 'status', 'publishedAt'],
    order: [['publishedAt', 'DESC NULLS LAST'], ['updatedAt', 'DESC']],
    limit: 60,
  });
  if (!rows.length) return 'No blog posts yet.';
  return untrusted('post titles', rows.map((p) => `• ${p.id} — "${p.title}" /blog/${p.slug} (${p.status})`).join('\n'));
}

export type SavePostInput = SavePageInput & { excerpt?: string; featuredImageId?: string; topics?: string[] };

/** The taxonomy posts are filed under (a categories-like one first). */
async function postTaxonomy(siteId: string) {
  const rows = await Taxonomy.findAll({ where: { siteId, active: true }, order: [['menuOrder', 'ASC']] });
  const forPosts = rows.filter((t) => (t.objectTypes as string[]).includes('post'));
  return forPosts.find((t) => t.hierarchical) ?? forPosts[0] ?? null;
}

/** File a post under topics by name, creating the ones that don't exist yet. */
async function setPostTopics(ws: Workspace, postId: string, names: string[]): Promise<string> {
  const siteId = ws.actor.siteId;
  const taxonomy = await postTaxonomy(siteId);
  if (!taxonomy) {
    return ' No taxonomy is attached to posts, so topics were not set — create one with save_taxonomy (e.g. slug "topic", objectTypes ["post"]) and save the post again.';
  }
  const existing = await Term.findAll({ where: { siteId, taxonomyId: taxonomy.id } });
  const termIds: string[] = [];
  for (const raw of names.map((n) => n.trim()).filter(Boolean).slice(0, 10)) {
    const found = existing.find((t) => t.name.toLowerCase() === raw.toLowerCase());
    if (found) {
      termIds.push(found.id);
      continue;
    }
    const created = (await createTerm(siteId, taxonomy.id, { name: raw })) as { id?: string; term?: { id: string } };
    const id = created.term?.id ?? created.id;
    if (id) termIds.push(id);
  }
  await setPostTaxonomies(postId, siteId, 'post', [{ taxonomyId: taxonomy.id, termIds }]);
  return termIds.length ? ` Filed under ${taxonomy.plural}: ${names.join(', ')}.` : '';
}

export async function savePost(ws: Workspace, input: SavePostInput): Promise<string> {
  const layouts = new Map(layoutSyncService.listPublic().map((l) => [l.slug, { title: l.title, fields: l.fields }]));
  const existingPost = input.id ? await pagesService.get(ws.actor, input.id, 'post') : null;
  const current = existingPost?.beekiricode ?? null;
  const pendingRun = existingPost?.status === 'publish' ? ws.change?.runId : undefined;
  const doc = buildDoc(input.blocks, layouts, isDoc(current) ? current : null, { removeConfirmed: input.removeConfirmed === true, pendingRun });
  const body = {
    title: input.title.trim(),
    ...(input.slug ? { slug: input.slug } : {}),
    ...(input.status ? { status: input.status } : {}),
    ...(input.excerpt !== undefined ? { excerpt: input.excerpt } : {}),
    ...(input.featuredImageId !== undefined ? { featuredImageId: input.featuredImageId } : {}),
    beekiricode: doc as unknown as Record<string, unknown>,
  };
  const before = input.id ? await snapshots.page(ws.actor, input.id, 'post') : null;
  const post = input.id
    ? await pagesService.update(ws.actor, input.id, body, 'post')
    : await pagesService.create(ws.actor, { ...body, status: input.status ?? 'draft' }, 'post');
  const topics = input.topics?.length ? await setPostTopics(ws, post.id, input.topics) : '';
  await recordChange(ws.change, {
    kind: 'page',
    label: `Post “${post.title}”`,
    target: { pageId: post.id, kind: 'post' },
    before,
    after: await snapshots.page(ws.actor, post.id, 'post'),
  });
  const postWaiting = hasPending(post.beekiricode, pendingRun);
  const preview = postWaiting ? await waitingPreview(ws, post.id, 'post') : null;
  addLink(ws, {
    kind: 'post',
    label: post.title,
    admin: `posts/${post.id}`,
    url: preview ?? (post.status === 'publish' ? post.path : undefined),
    ...(preview ? { preview: true, livePath: post.path } : {}),
  });
  const waiting = postWaiting
    ? ' The post is live, so the elements you added are hidden from visitors until the owner presses Keep under your reply (Undo removes them). Tell the owner that.'
    : '';
  return `${input.id ? 'Updated' : 'Created'} post "${post.title}" (id ${post.id}, ${post.status}) at ${post.path}.${topics}${waiting}`;
}

// ─── Media (read-only) ────────────────────────────────────────────────────────

export async function listMedia(ws: Workspace, search?: string, kind: 'image' | 'video' = 'image'): Promise<string> {
  const rows = await MediaAsset.findAll({
    where: {
      siteId: ws.actor.siteId,
      mimeType: { [Op.like]: `${kind}/%` },
      ...(search ? { originalName: { [Op.iLike]: `%${search}%` } } : {}),
    },
    attributes: ['id', 'originalName', 'url', 'alt', 'width', 'height'],
    order: [['createdAt', 'DESC']],
    limit: 40,
  });
  if (!rows.length) {
    return kind === 'video'
      ? 'No videos in the media library. Do not fake a video or a play button: ask the owner for a YouTube/Vimeo link or to upload an .mp4 to Media, or keep the photo.'
      : 'No images in the media library. Leave image fields empty — the user can pick images in the editor.';
  }
  return untrusted(
    'media names and alt texts',
    rows
      .map((m) => `• ${m.id} — ${m.originalName}${kind === 'image' ? ` ${m.width ?? '?'}×${m.height ?? '?'}` : ''}${m.alt ? ` alt="${m.alt}"` : ''} ${m.url}`)
      .join('\n'),
  );
}

// ─── Taxonomies (Backend Fields) ──────────────────────────────────────────────

/** Built-in content types plus the site's own post types (shop products are "product"). */
async function objectTypes(siteId: string): Promise<string[]> {
  const custom = await PostType.findAll({ where: { siteId }, attributes: ['slug'] });
  return ['post', 'page', ...custom.map((p) => p.slug)];
}

export async function listTaxonomies(ws: Workspace): Promise<string> {
  const rows = await Taxonomy.findAll({ where: { siteId: ws.actor.siteId }, order: [['menuOrder', 'ASC']] });
  const types = await objectTypes(ws.actor.siteId);
  const lines = rows.map(
    (t) => `• ${t.id} — ${t.slug} ("${t.plural}") on ${(t.objectTypes as string[]).join(', ')}${t.hierarchical ? ', hierarchical' : ''}${t.active ? '' : ', inactive'}`,
  );
  return `${lines.length ? lines.join('\n') : 'No taxonomies yet.'}\nContent types you can attach to: ${types.join(', ')}.`;
}

export type SaveTaxonomyInput = {
  id?: string;
  slug: string;
  singular: string;
  plural: string;
  description?: string;
  hierarchical?: boolean;
  objectTypes: string[];
};

/** Create or update a taxonomy (never delete — reverting a Beekiri change does that). */
export async function saveTaxonomy(ws: Workspace, input: SaveTaxonomyInput): Promise<string> {
  const allowed = await objectTypes(ws.actor.siteId);
  const unknown = input.objectTypes.filter((t) => !allowed.includes(t));
  if (unknown.length) throw new Error(`Unknown content type ${unknown.join(', ')} — use: ${allowed.join(', ')}.`);
  const slug = input.slug.trim().toLowerCase();
  if (!/^[a-z][a-z0-9_-]{1,39}$/.test(slug)) throw new Error('The slug must be 2–40 lowercase letters, digits, "-" or "_".');
  if (['category', 'post_tag', 'nav_menu', 'post_format'].includes(slug)) throw new Error(`"${slug}" is reserved.`);
  const dto = {
    slug,
    singular: input.singular.trim(),
    plural: input.plural.trim(),
    description: input.description?.trim() ?? '',
    hierarchical: input.hierarchical ?? true,
    objectTypes: input.objectTypes,
  };
  const before = input.id ? await snapshots.taxonomy(ws.actor.siteId, input.id) : null;
  if (input.id && !before) throw new Error('No taxonomy with that id — call list_taxonomies.');
  const row = input.id
    ? await structureService.updateTaxonomy(ws.actor, input.id, dto as never)
    : await structureService.createTaxonomy(ws.actor, { ...dto, public: true, active: true } as never);
  await recordChange(ws.change, {
    kind: 'taxonomy',
    label: `Taxonomy “${row.plural}”`,
    target: { id: row.id },
    before,
    after: await snapshots.taxonomy(ws.actor.siteId, row.id),
  });
  return `${input.id ? 'Updated' : 'Created'} taxonomy "${row.plural}" (${row.slug}, id ${row.id}) on ${dto.objectTypes.join(', ')}. Terms are added by editors on the matching content screens.`;
}

