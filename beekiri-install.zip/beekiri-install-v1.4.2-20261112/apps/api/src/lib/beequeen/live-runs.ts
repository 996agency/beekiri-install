/**
 * Beekiri runs outlive the browser tab that started them: moving to another admin page, reloading
 * or closing the chat must not stop (or half-finish) a change. Each run keeps its stream events
 * here, so the admin can join it again (all events replayed, then live) and only an explicit Stop
 * aborts it. Finished runs stay a short while for a late rejoin; the saved chat has the rest.
 */

export type LiveEvent = { type: string } & Record<string, unknown>;

type Listener = (event: LiveEvent | null) => void;

export type LiveRun = {
  runId: string;
  userId: string;
  siteId: string;
  chatId: string;
  abort: AbortController;
  events: LiveEvent[];
  done: boolean;
  finishedAt: number;
  listeners: Set<Listener>;
};

/** How long a finished run can still be joined. */
const KEEP_FINISHED_MS = 2 * 60 * 1000;
/** A run's replay buffer: status lines and section trees, never more than this many events. */
const MAX_EVENTS = 2000;

const runs = new Map<string, LiveRun>();

function sweep() {
  const now = Date.now();
  for (const [id, run] of runs) {
    if (run.done && now - run.finishedAt > KEEP_FINISHED_MS) runs.delete(id);
  }
}

export function startLiveRun(input: { runId: string; userId: string; siteId: string; chatId: string }): LiveRun {
  sweep();
  const run: LiveRun = { ...input, abort: new AbortController(), events: [], done: false, finishedAt: 0, listeners: new Set() };
  runs.set(run.runId, run);
  return run;
}

/** Record an event and pass it to everyone following the run. */
export function pushLiveEvent(run: LiveRun, event: LiveEvent) {
  if (run.events.length >= MAX_EVENTS) {
    // Keep the start (chat id) and drop old progress lines, never the section trees that matter last.
    const drop = run.events.findIndex((e, i) => i > 0 && (e.type === 'status' || e.type === 'note'));
    run.events.splice(drop > 0 ? drop : 1, 1);
  }
  run.events.push(event);
  for (const listen of run.listeners) listen(event);
}

export function finishLiveRun(run: LiveRun) {
  run.done = true;
  run.finishedAt = Date.now();
  for (const listen of run.listeners) listen(null);
  run.listeners.clear();
}

/** The run, if it belongs to this user on this site. */
export function getLiveRun(runId: string, userId: string, siteId: string): LiveRun | null {
  const run = runs.get(runId);
  return run && run.userId === userId && run.siteId === siteId ? run : null;
}

/** This user's run that is still going on this site (one at a time per person). */
export function activeLiveRun(userId: string, siteId: string): LiveRun | null {
  sweep();
  for (const run of runs.values()) {
    if (!run.done && run.userId === userId && run.siteId === siteId) return run;
  }
  return null;
}

/** Replay what happened so far, then follow; `onEnd` runs once the run is over. Returns an unsubscribe. */
export function followLiveRun(run: LiveRun, onEvent: (event: LiveEvent) => void, onEnd: () => void): () => void {
  for (const event of run.events) onEvent(event);
  if (run.done) {
    onEnd();
    return () => undefined;
  }
  const listen: Listener = (event) => (event ? onEvent(event) : onEnd());
  run.listeners.add(listen);
  return () => run.listeners.delete(listen);
}
