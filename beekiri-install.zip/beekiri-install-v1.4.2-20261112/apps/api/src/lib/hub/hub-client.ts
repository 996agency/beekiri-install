import { randomBytes } from 'crypto';
import { readFileSync } from 'fs';
import { join } from 'path';
import { secretsStable } from '../../config/env';
import { User } from '../../models';
import { findPrimarySite, saveSiteOptions } from '../../services/site-context';
import { createLogger } from '../../utils/logger';
import { decryptSecret, encryptSecret, isEncrypted } from '../shop/secrets';
import { DEFAULT_BEEQUEEN_URL, normalizeServiceUrl } from '../site/connector';
import { mergeSiteOptions, readOptions, type HubOptions } from '../site/site-options';
import { readCoreManifest } from '../system/core-manifest';
import { siteAddress, siteEnvironment } from '../site/environment';
import { BUILTIN_THEME_SLUGS, listThemeManifests, resolveThemeDir } from '../themes/theme-registry';

/**
 * The Beekiri Hub (996Agency) sees every install and sells themes. Beekiri is free:
 * the install registers itself once (getting an install token) and checks in daily.
 * Nothing here ever blocks the site — when the Hub is unreachable, only the theme store waits.
 */

const log = createLogger('hub');
const DAY_MS = 24 * 60 * 60 * 1000;

export class HubError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
  }
}

/**
 * BEEKIRI_HUB_URL wins; otherwise 996agency.com (or BEEQUEEN_SERVICE_URL). Only the server's own
 * environment can move it — never a value in the database — so nobody who gets at the admin or the
 * database can send this site's install token somewhere else.
 */
export async function hubUrl(): Promise<string> {
  const fromEnv = normalizeServiceUrl(process.env.BEEKIRI_HUB_URL ?? '');
  if (fromEnv) return safeHubUrl(fromEnv, true);
  return safeHubUrl(DEFAULT_BEEQUEEN_URL, Boolean(process.env.BEEQUEEN_SERVICE_URL?.trim()));
}

function isLoopbackHost(host: string): boolean {
  const h = host.replace(/^\[|\]$/g, '').toLowerCase();
  return h === 'localhost' || h.endsWith('.localhost') || h === '::1' || /^127\./.test(h);
}

/**
 * The Hub hands out theme code and signs this site in to the Connector, so only talk to it over
 * https — plain http only to this machine. A Hub on this machine that nobody configured (the
 * built-in default) is only trusted by a local site: on a shared server anyone could listen there.
 */
function safeHubUrl(url: string, configured: boolean): string {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    throw new HubError('The Beekiri Hub address is not valid.', 503);
  }
  const loopback = isLoopbackHost(parsed.hostname);
  if (parsed.protocol !== 'https:' && !loopback) {
    throw new HubError('The Beekiri Hub must be reached over https.', 503);
  }
  if (loopback && !configured && siteEnvironment().value !== 'local') {
    throw new HubError('The Beekiri Hub address is not set for this site (BEEKIRI_HUB_URL).', 503);
  }
  return url;
}

/** What the Hub shows for this install (and checks theme licences against: owner e-mail + environment). */
async function details(requestOrigin?: string | null): Promise<Record<string, unknown>> {
  const site = await findPrimarySite();
  const owner = await User.findOne({ where: { isOwner: true }, attributes: ['email'], order: [['createdAt', 'ASC']] });
  return {
    siteUrl: siteAddress(requestOrigin),
    siteName: site?.title?.trim() || null,
    ownerEmail: owner?.email ?? null,
    environment: siteEnvironment(requestOrigin).value,
    version: readCoreManifest().coreVersion,
    meta: { node: process.version, platform: process.platform, themesInstalled: listThemeManifests().length },
  };
}

async function hubFetch(url: string, init: RequestInit & { timeoutMs?: number } = {}): Promise<Response> {
  try {
    return await fetch(url, {
      ...init,
      headers: { Accept: 'application/json', ...(init.body ? { 'Content-Type': 'application/json' } : {}), ...init.headers },
      signal: AbortSignal.timeout(init.timeoutMs ?? 15_000),
    });
  } catch {
    throw new HubError('Could not reach the Beekiri Hub. Check your internet connection and try again.', 503);
  }
}

async function messageOf(res: Response, fallback: string): Promise<string> {
  const data = (await res.json().catch(() => ({}))) as { message?: string };
  return typeof data.message === 'string' && data.message ? data.message : fallback;
}

/** Registers this install with the Hub at `url` and stores the token (encrypted). */
async function register(url: string): Promise<{ url: string; token: string }> {
  const site = await findPrimarySite();
  if (!site) throw new HubError('Finish setting up the site first.', 409);
  const installId = randomBytes(18).toString('base64url');
  const res = await hubFetch(`${url}/api/beekiri/v1/installs`, {
    method: 'POST',
    body: JSON.stringify({ installId, ...(await details()) }),
  });
  if (!res.ok) throw new HubError(await messageOf(res, 'The Beekiri Hub did not accept the registration.'), res.status);
  const data = (await res.json()) as { token?: string };
  if (!data.token) throw new HubError('The Beekiri Hub sent no install token.', 502);

  // Encrypt only with a stable CACHE_FLUSH_SECRET: a per-process key would make the token unreadable
  // after a restart and register the site again. The token only unlocks this site's own themes.
  const token = secretsStable ? encryptSecret(data.token) : data.token;
  const fresh = await findPrimarySite();
  // Licence keys belong to the theme purchases, not the token: they survive registering again.
  const licenceKeys = readOptions(fresh?.settings?.options).hub?.licenceKeys;
  const hub: HubOptions = { url, installId, token, registeredAt: new Date().toISOString(), ...(licenceKeys ? { licenceKeys } : {}) };
  await saveSiteOptions(site.id, mergeSiteOptions(fresh?.settings?.options, { hub }));
  log.info(`Registered with the Beekiri Hub at ${url}.`);
  return { url, token: data.token };
}

/** Does the Hub at `url` accept this install token? (Only a clear yes counts.) */
async function tokenKnownAt(url: string, token: string): Promise<boolean> {
  try {
    const res = await hubFetch(`${url}/api/beekiri/v1/installs/heartbeat`, {
      method: 'POST',
      body: JSON.stringify(await details()),
      headers: { Authorization: `Bearer ${token}` },
    });
    return res.ok;
  } catch {
    return false;
  }
}

let registering: Promise<{ url: string; token: string }> | null = null;

/** This install's Hub address and token, registering first when needed (one at a time). */
async function connection(force = false): Promise<{ url: string; token: string }> {
  const url = await hubUrl();
  if (!force) {
    const site = await findPrimarySite();
    const hub = readOptions(site?.settings?.options).hub;
    const token = hub ? decryptSecret(hub.token) : '';
    // A token saved in plain text (registered before this server had a stable secret) is encrypted now.
    if (token && site && hub && secretsStable && !isEncrypted(hub.token)) {
      const fresh = await findPrimarySite();
      const current = readOptions(fresh?.settings?.options).hub;
      if (current?.token === hub.token) {
        await saveSiteOptions(site.id, mergeSiteOptions(fresh?.settings?.options, { hub: { ...current, token: encryptSecret(token) } }));
      }
    }
    if (token && hub?.url === url) return { url, token };
    // The Hub moved (e.g. from a local test address to 996agency.com with the same data): keep this
    // install — its purchases, licences and balance — when the new address still knows its token.
    if (token && site && hub && (await tokenKnownAt(url, token))) {
      const fresh = await findPrimarySite();
      const current = readOptions(fresh?.settings?.options).hub;
      if (current) await saveSiteOptions(site.id, mergeSiteOptions(fresh?.settings?.options, { hub: { ...current, url } }));
      log.info(`The Beekiri Hub moved to ${url}; this install kept its registration.`);
      return { url, token };
    }
  }
  registering ??= register(url).finally(() => {
    registering = null;
  });
  return registering;
}

let credentialsFailedAt = 0;

/**
 * This install's Hub address and token — also how the site signs in to 996Agency's Connector
 * (same service), so no Connector key is ever pasted, shown or sent to a browser. Null when the
 * Hub can't be reached; a failure is remembered for a minute so status checks stay quick.
 */
export async function hubCredentials(): Promise<{ url: string; token: string } | null> {
  if (Date.now() - credentialsFailedAt < 60_000) return null;
  try {
    return await connection();
  } catch (error) {
    credentialsFailedAt = Date.now();
    log.warn(`Connector: could not sign in to the Beekiri Hub: ${(error as Error).message}`);
    return null;
  }
}

/** A call to the Hub as this install. An unknown token (Hub data reset) registers again once. */
export async function hubRequest(path: string, init: RequestInit & { timeoutMs?: number } = {}): Promise<Response> {
  let conn = await connection();
  const send = () =>
    hubFetch(`${conn.url}/api/beekiri/v1${path}`, {
      ...init,
      headers: { ...init.headers, Authorization: `Bearer ${conn.token}` },
    });
  let res = await send();
  if (res.status === 401) {
    conn = await connection(true);
    res = await send();
  }
  return res;
}

/** JSON helper: throws HubError with the Hub's message on failure. */
export async function hubJson<T>(path: string, init: RequestInit & { timeoutMs?: number } = {}): Promise<T> {
  const res = await hubRequest(path, init);
  if (!res.ok) throw new HubError(await messageOf(res, 'The Beekiri Hub could not complete that.'), res.status);
  return (await res.json()) as T;
}

export async function heartbeat(): Promise<void> {
  await hubJson('/installs/heartbeat', { method: 'POST', body: JSON.stringify(await details()) });
}

export type ThemeLicence = {
  /** False for themes the Hub does not sell (built-in, free or your own). */
  required: boolean;
  licensed: boolean;
  message?: string;
  code?: string;
  /** Answer from the last successful check, used because the Hub could not be reached. */
  offline?: boolean;
};

/** Store themes say so in theme.json (`"licence": "beekiri-hub"`), so they are recognised offline too. */
export function isStoreThemeFolder(dir: string | null): boolean {
  if (!dir) return false;
  try {
    const meta = JSON.parse(readFileSync(join(dir, 'theme.json'), 'utf8')) as { licence?: unknown };
    return meta.licence === 'beekiri-hub';
  } catch {
    return false;
  }
}

/** The licence key this site keeps for a store theme, if any. */
export async function licenceKeyFor(slug: string): Promise<string | null> {
  const site = await findPrimarySite();
  const stored = readOptions(site?.settings?.options).hub?.licenceKeys?.[slug];
  return stored ? decryptSecret(stored) || null : null;
}

/** Keeps (or, with null, forgets) a store theme's licence key, encrypted like the install token. */
export async function saveLicenceKey(slug: string, key: string | null): Promise<void> {
  const site = await findPrimarySite();
  if (!site) return;
  const hub = readOptions(site.settings?.options).hub;
  if (!hub) return;
  const licenceKeys = { ...(hub.licenceKeys ?? {}) };
  if (key) licenceKeys[slug] = secretsStable ? encryptSecret(key) : key;
  else delete licenceKeys[slug];
  await saveSiteOptions(site.id, mergeSiteOptions(site.settings?.options, { hub: { ...hub, licenceKeys } }));
}

/** Every stored key as `slug:key` pairs, the X-Licence-Key header the Hub reads for its catalog. */
export async function licenceKeyHeader(): Promise<string> {
  const site = await findPrimarySite();
  const keys = readOptions(site?.settings?.options).hub?.licenceKeys ?? {};
  return Object.entries(keys)
    .map(([slug, stored]) => {
      const key = decryptSecret(stored);
      return key ? `${slug}:${key}` : '';
    })
    .filter(Boolean)
    .join(',');
}

async function cacheLicence(slug: string, value: { required: boolean; licensed: boolean }) {
  const site = await findPrimarySite();
  if (!site) return;
  const hub = readOptions(site.settings?.options).hub;
  if (!hub) return;
  const licences = { ...(hub.licences ?? {}), [slug]: { ...value, checkedAt: new Date().toISOString() } };
  await saveSiteOptions(site.id, mergeSiteOptions(site.settings?.options, { hub: { ...hub, licences } }));
}

/**
 * Asks the Hub whether this site may use a store theme, taking a licence slot for it when one is
 * free (one local, one staging and one production site per licence, same owner e-mail).
 * `themeDir`: the theme's folder (installed or arriving), to recognise store themes offline.
 */
export async function checkThemeLicence(
  slug: string,
  opts: { requestOrigin?: string | null; themeDir?: string | null; activate?: boolean; licenceKey?: string | null } = {},
): Promise<ThemeLicence> {
  if (BUILTIN_THEME_SLUGS.has(slug)) return { required: false, licensed: true };
  try {
    const licenceKey = opts.licenceKey?.trim() || (await licenceKeyFor(slug));
    const res = await hubRequest(`/themes/${encodeURIComponent(slug)}/licence`, {
      method: 'POST',
      body: JSON.stringify({ ...(await details(opts.requestOrigin)), activate: opts.activate !== false, ...(licenceKey ? { licenceKey } : {}) }),
    });
    const data = (await res.json().catch(() => ({}))) as Partial<ThemeLicence> & { licenceKey?: unknown };
    // The Hub shows the key to the project's own sites: keep it, so this site can pass it on (migrations).
    if (res.ok) {
      const key = typeof data.licenceKey === 'string' && data.licenceKey ? data.licenceKey : licenceKey;
      if (key) await saveLicenceKey(slug, key).catch(() => undefined);
    }
    if (res.ok || res.status === 402 || res.status === 403) {
      const answer: ThemeLicence = {
        required: data.required !== false,
        licensed: res.ok && data.licensed !== false,
        message: typeof data.message === 'string' ? data.message : undefined,
        code: typeof data.code === 'string' ? data.code : undefined,
      };
      await cacheLicence(slug, { required: answer.required, licensed: answer.licensed }).catch(() => undefined);
      return answer;
    }
    throw new HubError(typeof data.message === 'string' ? data.message : 'The Beekiri Hub could not check the licence.', res.status);
  } catch (error) {
    // Hub unreachable: fall back to the last answer, then to what the theme says about itself.
    const site = await findPrimarySite().catch(() => null);
    const cached = readOptions(site?.settings?.options).hub?.licences?.[slug];
    if (cached) return { required: cached.required, licensed: cached.licensed, offline: true };
    const dir = opts.themeDir === undefined ? resolveThemeDir(slug) : opts.themeDir;
    if (!isStoreThemeFolder(dir)) return { required: false, licensed: true, offline: true };
    log.warn(`Theme licence check for ${slug} failed: ${(error as Error).message}`);
    return {
      required: true,
      licensed: false,
      offline: true,
      message: `Could not reach the Beekiri Hub to check the licence of this theme. Try again when the site is online.`,
    };
  }
}

/** Check in shortly after start, then once a day (BEEKIRI_HUB_DISABLED=1 turns it off). Failures are logged and retried tomorrow. */
export function startHubCheckins(): void {
  if (/^(1|true|yes)$/i.test(process.env.BEEKIRI_HUB_DISABLED ?? '')) return;
  const beat = () =>
    heartbeat()
      .then(checkActiveThemeLicence)
      .catch((error: unknown) => log.warn(`Beekiri Hub check-in skipped: ${(error as Error).message}`));
  setTimeout(beat, 15_000).unref();
  setInterval(beat, DAY_MS).unref();
}

/** Daily: the active theme's licence (takes its slot if free; the answer shows in Appearance). */
async function checkActiveThemeLicence(): Promise<void> {
  const site = await findPrimarySite();
  const active = readOptions(site?.settings?.options).activeTheme?.trim();
  if (!active || BUILTIN_THEME_SLUGS.has(active)) return;
  const answer = await checkThemeLicence(active);
  if (answer.required && !answer.licensed) log.warn(`Theme licence: ${answer.message ?? `${active} is not licensed for this site.`}`);
}
