/**
 * Beekiri's own extensions (made and published by Beekiri, free). Features that ship with
 * Beekiri itself (BeeSEO, BeeCookies, analytics, translation…) are part of core, not
 * extensions. A public extension API for developers is planned (see README).
 */

export type ExtensionKind = 'built-in' | 'package';
export type ExtensionStatus = 'active' | 'inactive' | 'available' | 'coming-soon';

export type ExtensionEntry = {
  slug: string;
  name: string;
  /** One line for lists and cards. */
  tagline: string;
  /** Paragraphs for the details view. */
  description: string[];
  features: string[];
  version: string;
  /** Minimum Beekiri core version. */
  requires: string;
  author: 'Beekiri';
  category: 'Commerce' | 'Marketing' | 'Analytics' | 'Content' | 'Performance' | 'Forms' | 'Bookings';
  /** Admin icon key (the admin maps it to an icon). */
  icon: 'cart' | 'form' | 'calendar';
  /** Brand color for the icon tile and banner. */
  color: string;
  kind: ExtensionKind;
  status: ExtensionStatus;
  /** Admin path of the extension's own screen. */
  settingsPath?: string;
  changelog: { version: string; notes: string[] }[];
};

export const EXTENSION_CATALOG: ExtensionEntry[] = [
  {
    slug: 'bee-forms',
    name: 'Bee Forms',
    tagline: 'Build contact and lead forms, drop them on any page, and get every entry in your inbox and admin.',
    description: [
      'Bee Forms adds a drag-and-drop form builder to the admin. Pick the fields you need, set which ones are required, add conditional logic and split long forms into steps. Every form gets a notification email with the answers, an optional auto-reply to the visitor, and a thank-you message or redirect.',
      'Put a form on any page with the Form element in the page editor, or let a theme layout choose one through a Form Backend Field, exactly like a Gravity Forms field in ACF. Entries are kept in the admin with search, status and CSV export; uploaded files stay private.',
      'Spam is handled without keys or third parties: a honeypot, a timing check and rate limits. Deactivate at any time; nothing is deleted unless you choose to.',
    ],
    features: [
      'Text, email, phone, website, message, number, dropdown, checkboxes, choices, date, hidden, consent and file upload fields',
      'Drag-and-drop builder with widths, placeholders, help text and conditional logic',
      'Multi-step forms with a progress bar or numbered steps',
      'Notification emails with merge tags, auto-reply to the visitor, reply-to',
      'Thank-you message or redirect after sending',
      'Entries inbox with unread counts, search, spam/trash and CSV export',
      'Form element in the page editor and a Form Backend Field for theme layouts (bee_form() in PHP)',
      'Built-in spam protection: honeypot, timing check and rate limits',
    ],
    version: '1.0.0',
    requires: '1.1.0',
    author: 'Beekiri',
    category: 'Forms',
    icon: 'form',
    color: '#006199',
    kind: 'package',
    status: 'available',
    settingsPath: 'forms',
    changelog: [
      {
        version: '1.0.0',
        notes: [
          'First release: form builder, entries, notifications, auto-reply, multi-step and conditional logic.',
          'Form element for the page editor and a Form Backend Field with bee_form() for PHP layouts.',
        ],
      },
    ],
  },
  {
    slug: 'bee-bookings',
    name: 'Bee Bookings',
    tagline: 'Let customers book appointments on your site: services, staff, a calendar, confirmations and reminders.',
    description: [
      'Bee Bookings adds appointment booking to a Beekiri site. Set up the services you offer (length, price, free time after each one) and the people who do them, each with their own working hours and days off. Customers pick a service, a person, a day and a time that is really free, and get a confirmation by email.',
      'The admin has a calendar with day, week and month views. Add, move, confirm or cancel appointments, block time, and mark holidays. Customers can cancel from the link in their email, and a reminder goes out before the appointment.',
      'Put the booking widget on any page with the Booking element in the page editor, or type [bee_booking] in any text. Beekiri can set it all up from a sentence in the chat. Deactivate at any time; nothing is deleted unless you choose to.',
    ],
    features: [
      'Services with duration, price, colour and free time after each appointment',
      'Staff with their own services, weekly hours and days off',
      'Business hours, holidays, minimum notice and how far ahead customers can book',
      'Calendar with day, week and month views; add, reschedule, confirm, cancel, block time',
      'Booking widget for the website: service, person, day, time, details',
      'Booking element in the page editor and the [bee_booking] shortcode',
      'Emails: confirmation, new-booking notice, cancellation and a reminder before the appointment',
      'Customers cancel from the link in their email',
      'Beekiri can set up services, staff and hours from the chat',
    ],
    version: '1.0.0',
    requires: '1.3.5',
    author: 'Beekiri',
    category: 'Bookings',
    icon: 'calendar',
    color: '#4f7a26',
    kind: 'package',
    status: 'available',
    settingsPath: 'bookings',
    changelog: [
      {
        version: '1.0.0',
        notes: [
          'First release: services, staff, availability, calendar, website widget, emails and reminders.',
          'Booking element for the page editor, the [bee_booking] shortcode and Beekiri chat tools.',
        ],
      },
    ],
  },
  {
    slug: 'shopping',
    name: 'Bee Shopping',
    tagline: 'Sell from your Beekiri site — products, a cart, checkout and orders, in your own theme.',
    description: [
      'Bee Shopping turns a Beekiri site into a shop. Products are managed in the admin like pages, with prices, stock, variations, images, categories and tags. The shop, product, cart and checkout pages are rendered by your theme, so they look like the rest of the site.',
      'Shoppers pay by card through Stripe Checkout (card details never touch your server), by bank transfer or cash on delivery. Orders land in the admin with their status, notes and refunds; customers and coupons have their own screens, and every step sends the right email.',
      'Install it from here: the product post type, product categories and tags, and a Shop menu appear immediately. Deactivate at any time; nothing is deleted unless you choose to.',
    ],
    features: [
      'Simple and variable products with sale prices, stock tracking and galleries',
      'Product categories and tags, search and sorting on the shop page',
      'Cart, coupons, shipping zones and tax rates',
      'Stripe Checkout, bank transfer and cash on delivery',
      'Orders with status flow, notes, refunds and customer emails',
      'Customers, coupons and a sales overview in the admin',
      'Shop pages rendered by the theme (themes/beekiri/shop) — override any template in Beekiri Child',
    ],
    version: '1.0.0',
    requires: '1.0.0',
    author: 'Beekiri',
    category: 'Commerce',
    icon: 'cart',
    color: '#7f54b3',
    kind: 'package',
    status: 'available',
    settingsPath: 'shop',
    changelog: [
      {
        version: '1.0.0',
        notes: [
          'First release: products, variations, categories, tags, cart, coupons, shipping zones, taxes.',
          'Payments: Stripe Checkout (with webhooks and refunds), bank transfer, cash on delivery.',
          'Orders, customers, emails, sales overview and a dashboard widget.',
          'Storefront templates in themes/beekiri/shop with child-theme overrides.',
        ],
      },
    ],
  },
];
