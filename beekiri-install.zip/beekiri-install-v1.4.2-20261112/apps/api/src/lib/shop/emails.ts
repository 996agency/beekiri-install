import type { ShopOrder, ShopOrderItem } from '../../models';
import { ORDER_STATUS_LABELS, SHOP_PATHS, type OrderStatus } from './constants';
import { countryName } from './countries';
import { formatMoney } from './money';
import { moneyFormatOf, type ShopSettings } from './settings';
import { parseFulfillment } from './tracking';

/**
 * Transactional emails. Every dynamic value goes through `esc()`; templates are
 * inline-styled HTML so they render the same in every mail client, plus a text part.
 */

export type EmailKind =
  | 'newOrderAdmin'
  | 'orderReceived'
  | 'onHold'
  | 'processing'
  | 'completed'
  | 'cancelled'
  | 'refunded'
  | 'customerNote'
  | 'shipped'
  | 'delivered';

export type EmailSite = { title: string; url: string };

export type RenderedEmail = { subject: string; html: string; text: string };

export function esc(v: unknown): string {
  return String(v ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

type Address = {
  firstName?: string;
  lastName?: string;
  company?: string;
  line1?: string;
  line2?: string;
  city?: string;
  state?: string;
  postcode?: string;
  country?: string;
};

export function addressLines(a: Address | null | undefined): string[] {
  if (!a) return [];
  return [
    [a.firstName, a.lastName].filter(Boolean).join(' '),
    a.company,
    a.line1,
    a.line2,
    [a.postcode, a.city].filter(Boolean).join(' '),
    a.state,
    countryName(a.country),
  ]
    .map((v) => (v ?? '').toString().trim())
    .filter(Boolean);
}

function customFieldLines(order: Pick<ShopOrder, 'customFields'>): { label: string; value: string }[] {
  const raw = order.customFields;
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return [];
  return Object.values(raw as Record<string, { label?: string; value?: unknown }>)
    .map((v) => ({ label: String(v?.label ?? ''), value: String(v?.value ?? '') }))
    .filter((l) => l.label && l.value);
}

export function orderNumberLabel(order: Pick<ShopOrder, 'number'>, settings: ShopSettings): string {
  return `${settings.advanced.orderNumberPrefix}${order.number}`;
}

function subjectFor(kind: EmailKind, settings: ShopSettings, order: ShopOrder, site: EmailSite): string {
  const template = settings.emails[kind]?.subject || '{site} order #{number}';
  return template.replace('{site}', site.title).replace('{number}', String(order.number));
}

function intro(kind: EmailKind, order: ShopOrder, settings: ShopSettings): { heading: string; lead: string } {
  const n = orderNumberLabel(order, settings);
  switch (kind) {
    case 'newOrderAdmin':
      return { heading: `New order ${n}`, lead: `You have received a new order from ${order.email}.` };
    case 'orderReceived':
      return { heading: 'Thank you for your order', lead: `We have received order ${n} and will let you know once it is on its way.` };
    case 'onHold':
      return { heading: 'Your order is on hold', lead: `Order ${n} is waiting for payment confirmation. The details are below.` };
    case 'processing':
      return { heading: 'Your order is being processed', lead: `Payment for order ${n} has been received. We are preparing it now.` };
    case 'completed':
      return { heading: 'Your order is complete', lead: `Order ${n} has been completed. Thank you for shopping with us.` };
    case 'cancelled':
      return { heading: 'Your order has been cancelled', lead: `Order ${n} was cancelled. If this is unexpected, please contact us.` };
    case 'refunded':
      return { heading: 'Your order has been refunded', lead: `A refund has been issued for order ${n}.` };
    case 'customerNote':
      return { heading: 'A note about your order', lead: `A note has been added to order ${n}.` };
    case 'shipped':
      return { heading: 'Your order is on its way', lead: `Good news — order ${n} has been shipped.` };
    case 'delivered':
      return { heading: 'Your order has been delivered', lead: `Order ${n} has been delivered. Enjoy, and thank you for shopping with us.` };
  }
}

function paymentInstructions(order: ShopOrder, settings: ShopSettings): string {
  if (order.paymentStatus === 'paid') return '';
  if (order.paymentMethod === 'bank_transfer') {
    const bt = settings.payments.bankTransfer;
    const accounts = bt.accounts
      .map((a) =>
        [
          a.accountName && `Account name: ${a.accountName}`,
          a.bankName && `Bank: ${a.bankName}`,
          a.accountNumber && `Account number: ${a.accountNumber}`,
          a.sortCode && `Sort code: ${a.sortCode}`,
          a.iban && `IBAN: ${a.iban}`,
          a.bic && `BIC / SWIFT: ${a.bic}`,
        ]
          .filter(Boolean)
          .join('\n'),
      )
      .filter(Boolean);
    return [bt.instructions, ...accounts].filter(Boolean).join('\n\n');
  }
  if (order.paymentMethod === 'cod') return settings.payments.cod.instructions;
  return '';
}

export function renderOrderEmail(
  kind: EmailKind,
  order: ShopOrder,
  items: ShopOrderItem[],
  settings: ShopSettings,
  site: EmailSite,
  extra: { note?: string; refundAmount?: number; purchaseNotes?: { name: string; note: string }[] } = {},
): RenderedEmail {
  const fmt = moneyFormatOf(settings);
  const money = (v: number) => formatMoney(v, { ...fmt, currency: order.currency || fmt.currency });
  const accent = settings.emails.accentColor;
  const n = orderNumberLabel(order, settings);
  const { heading, lead } = intro(kind, order, settings);
  const orderUrl = `${site.url}${SHOP_PATHS.orderReceived(order.accessToken)}`;
  const billing = addressLines(order.billing as Address);
  const shipping = order.shipToDifferent ? addressLines(order.shipping as Address) : [];
  const method = order.shippingMethod as { title?: string } | null;
  const instructions = kind === 'orderReceived' || kind === 'onHold' ? paymentInstructions(order, settings) : '';
  const status = ORDER_STATUS_LABELS[order.status as OrderStatus] ?? order.status;
  const f = parseFulfillment(order.fulfillment);
  const tracking = (kind === 'shipped' || kind === 'delivered') && (f.carrier || f.trackingNumber || f.trackingUrl) ? f : null;

  const rows = items
    .map(
      (i) => `
      <tr>
        <td style="padding:10px 0;border-bottom:1px solid #e5e5e5;">
          <strong>${esc(i.name)}</strong>${i.sku ? `<br><span style="color:#666;font-size:12px;">SKU ${esc(i.sku)}</span>` : ''}
          ${Object.keys((i.attributes as Record<string, string>) ?? {}).length ? `<br><span style="color:#666;font-size:12px;">${esc(Object.entries(i.attributes as Record<string, string>).map(([k, v]) => `${k}: ${v}`).join(', '))}</span>` : ''}
        </td>
        <td style="padding:10px 0;border-bottom:1px solid #e5e5e5;text-align:center;">${i.qty}</td>
        <td style="padding:10px 0;border-bottom:1px solid #e5e5e5;text-align:right;">${esc(money(i.total))}</td>
      </tr>`,
    )
    .join('');

  const totalsRows: [string, string][] = [['Subtotal', money(order.subtotal)]];
  if (order.discountTotal > 0) totalsRows.push([`Discount${order.couponCode ? ` (${order.couponCode})` : ''}`, `-${money(order.discountTotal)}`]);
  if (method || order.shippingTotal > 0) totalsRows.push([`Shipping${method?.title ? ` (${method.title})` : ''}`, money(order.shippingTotal)]);
  if (order.taxTotal > 0) totalsRows.push([settings.tax.pricesIncludeTax ? 'Includes tax' : 'Tax', money(order.taxTotal)]);
  totalsRows.push(['Total', money(order.total)]);
  if (kind === 'refunded' && extra.refundAmount) totalsRows.push(['Refunded', `-${money(extra.refundAmount)}`]);

  const totalsHtml = totalsRows
    .map(
      ([k, v], idx) =>
        `<tr><td style="padding:6px 0;${idx === totalsRows.length - 1 ? 'font-weight:700;' : ''}">${esc(k)}</td><td style="padding:6px 0;text-align:right;${idx === totalsRows.length - 1 ? 'font-weight:700;' : ''}">${esc(v)}</td></tr>`,
    )
    .join('');

  const block = (title: string, lines: string[]) =>
    lines.length
      ? `<td style="vertical-align:top;padding:0 12px 0 0;width:50%;"><h3 style="margin:0 0 6px;font-size:14px;">${esc(title)}</h3><p style="margin:0;color:#444;line-height:1.5;">${lines.map(esc).join('<br>')}</p></td>`
      : '';

  const html = `<!doctype html>
<html><body style="margin:0;padding:0;background:#f4f4f5;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#202734;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f4f4f5;padding:24px 0;"><tr><td align="center">
<table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width:600px;width:100%;background:#fff;border-radius:8px;overflow:hidden;">
  <tr><td style="background:${esc(accent)};padding:20px 28px;color:#fff;font-size:20px;font-weight:700;">${esc(site.title)}</td></tr>
  <tr><td style="padding:28px;">
    <h1 style="margin:0 0 8px;font-size:22px;">${esc(heading)}</h1>
    <p style="margin:0 0 20px;color:#444;line-height:1.5;">${esc(lead)}</p>
    ${extra.note ? `<div style="margin:0 0 20px;padding:12px 16px;background:#fff8e6;border-left:4px solid ${esc(accent)};white-space:pre-wrap;">${esc(extra.note)}</div>` : ''}
    ${tracking ? `<div style="margin:0 0 20px;padding:12px 16px;background:#f6f7f7;border-radius:6px;line-height:1.6;">${tracking.carrier ? `<strong>Carrier:</strong> ${esc(tracking.carrier)}<br>` : ''}${tracking.trackingNumber ? `<strong>Tracking number:</strong> ${esc(tracking.trackingNumber)}<br>` : ''}${tracking.trackingUrl ? `<a href="${esc(tracking.trackingUrl)}" style="color:${esc(accent)};font-weight:600;">Track your parcel</a>` : ''}</div>` : ''}
    ${instructions ? `<div style="margin:0 0 20px;padding:12px 16px;background:#f6f7f7;border-radius:6px;white-space:pre-wrap;line-height:1.5;">${esc(instructions)}</div>` : ''}
    <p style="margin:0 0 6px;font-size:13px;color:#666;">Order ${esc(n)} · ${esc(new Date(order.placedAt).toLocaleDateString('en-GB', { year: 'numeric', month: 'long', day: 'numeric' }))} · ${esc(status)}</p>
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:12px 0 4px;">
      <thead><tr>
        <th align="left" style="padding:0 0 8px;border-bottom:2px solid #e5e5e5;font-size:13px;">Product</th>
        <th align="center" style="padding:0 0 8px;border-bottom:2px solid #e5e5e5;font-size:13px;">Qty</th>
        <th align="right" style="padding:0 0 8px;border-bottom:2px solid #e5e5e5;font-size:13px;">Total</th>
      </tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:8px 0 24px;">${totalsHtml}</table>
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:0 0 24px;"><tr>
      ${block('Billing address', [...billing, order.email, order.phone].filter(Boolean))}
      ${block('Shipping address', shipping)}
    </tr></table>
    ${(extra.purchaseNotes ?? []).map((p) => `<div style="margin:0 0 16px;padding:12px 16px;background:#f6f7f7;border-radius:6px;line-height:1.5;"><strong>${esc(p.name)}</strong><div style="white-space:pre-wrap;color:#444;margin-top:4px;">${esc(p.note)}</div></div>`).join('')}
    ${order.customerNote ? `<p style="margin:0 0 20px;color:#444;"><strong>Your note:</strong> ${esc(order.customerNote)}</p>` : ''}
    ${customFieldLines(order).map((l) => `<p style="margin:0 0 8px;color:#444;"><strong>${esc(l.label)}:</strong> ${esc(l.value)}</p>`).join('')}
    <p style="margin:0;"><a href="${esc(orderUrl)}" style="display:inline-block;padding:10px 18px;background:${esc(accent)};color:#fff;text-decoration:none;border-radius:6px;font-weight:600;">View your order</a></p>
  </td></tr>
  <tr><td style="padding:16px 28px;background:#fafafa;color:#777;font-size:12px;line-height:1.5;">${esc(settings.emails.footerText || `${site.title} · ${site.url}`)}</td></tr>
</table>
</td></tr></table>
</body></html>`;

  const text = [
    heading,
    '',
    lead,
    extra.note ? `\n${extra.note}\n` : '',
    instructions ? `\n${instructions}\n` : '',
    tracking ? [tracking.carrier && `Carrier: ${tracking.carrier}`, tracking.trackingNumber && `Tracking number: ${tracking.trackingNumber}`, tracking.trackingUrl && `Track: ${tracking.trackingUrl}`].filter(Boolean).join('\n') : '',
    `Order ${n} (${status})`,
    '',
    ...items.map((i) => `${i.qty} × ${i.name}${i.sku ? ` [${i.sku}]` : ''} — ${money(i.total)}`),
    '',
    ...totalsRows.map(([k, v]) => `${k}: ${v}`),
    '',
    ...(extra.purchaseNotes ?? []).map((p) => `${p.name}:\n${p.note}\n`),
    billing.length ? `Billing: ${billing.join(', ')}` : '',
    shipping.length ? `Shipping: ${shipping.join(', ')}` : '',
    order.customerNote ? `Note: ${order.customerNote}` : '',
    ...customFieldLines(order).map((l) => `${l.label}: ${l.value}`),
    '',
    `View your order: ${orderUrl}`,
  ]
    .filter((l) => l !== null)
    .join('\n');

  return { subject: subjectFor(kind, settings, order, site), html, text };
}

/* ── Account emails (verify email, reset password) ─────────────────── */

export function renderAccountEmail(
  kind: 'verify' | 'reset',
  settings: ShopSettings,
  site: EmailSite,
  data: { name: string; link: string },
): RenderedEmail {
  const accent = settings.emails.accentColor;
  const heading = kind === 'verify' ? 'Confirm your email address' : 'Reset your password';
  const lead =
    kind === 'verify'
      ? 'Thanks for creating an account. Confirm your email to see your orders and saved addresses.'
      : 'Someone asked to reset the password of your account. If that was you, choose a new password below.';
  const button = kind === 'verify' ? 'Confirm email' : 'Choose a new password';
  const footnote =
    kind === 'verify' ? 'The link is valid for 48 hours.' : 'The link is valid for one hour. If you did not ask for this, you can ignore this email.';
  const html = `<!doctype html>
<html><body style="margin:0;padding:0;background:#f4f4f5;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#202734;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f4f4f5;padding:24px 0;"><tr><td align="center">
<table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width:600px;width:100%;background:#fff;border-radius:8px;overflow:hidden;">
  <tr><td style="background:${esc(accent)};padding:20px 28px;color:#fff;font-size:20px;font-weight:700;">${esc(site.title)}</td></tr>
  <tr><td style="padding:28px;">
    <h1 style="margin:0 0 8px;font-size:22px;">${esc(heading)}</h1>
    <p style="margin:0 0 6px;color:#444;line-height:1.5;">Hi ${esc(data.name || 'there')},</p>
    <p style="margin:0 0 20px;color:#444;line-height:1.5;">${esc(lead)}</p>
    <p style="margin:0 0 20px;"><a href="${esc(data.link)}" style="display:inline-block;padding:10px 18px;background:${esc(accent)};color:#fff;text-decoration:none;border-radius:6px;font-weight:600;">${esc(button)}</a></p>
    <p style="margin:0;color:#777;font-size:12px;">${esc(footnote)}</p>
  </td></tr>
</table></td></tr></table></body></html>`;
  const text = [heading, '', `Hi ${data.name || 'there'},`, '', lead, '', `${button}: ${data.link}`, '', footnote].join('\n');
  return { subject: `${site.title}: ${heading.toLowerCase()}`, html, text };
}
