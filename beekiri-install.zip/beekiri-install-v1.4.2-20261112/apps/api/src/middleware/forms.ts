import type { NextFunction, Request, Response } from 'express';
import multer from 'multer';
import { formCssUrl } from '../lib/forms/assets';
import { rebindSite } from '../lib/site/current-site';
import { FORMS_EXTENSION_SLUG, FORMS_MAX_FIELDS, FORMS_MAX_FILES, FORMS_MAX_FILE_BYTES, FORMS_REQUEST_HEADER } from '../lib/forms/constants';
import { extensionsService } from '../services/extensions.service';
import { Forbidden, NotFound, TooManyRequests } from '../utils/http-error';
import { visitorKey } from './rate-limit';
import { assertTrustedOrigin } from './authenticate';

/** Every forms route answers 404 while the extension is not active. */
export async function requireFormsActive(_req: Request, _res: Response, next: NextFunction) {
  try {
    if (!(await extensionsService.isActive(FORMS_EXTENSION_SLUG))) throw NotFound('Bee Forms is not active.');
    next();
  } catch (error) {
    next(error);
  }
}

/** The website asks on every render; a 200 `{ active:false }` keeps its fetch cache honest (see shop.ts). */
export async function formsConfig(_req: Request, res: Response, next: NextFunction) {
  try {
    const active = await extensionsService.isActive(FORMS_EXTENSION_SLUG);
    res.json({ active, ...(active ? { cssUrl: formCssUrl() } : {}) });
  } catch (error) {
    next(error);
  }
}

/**
 * Anonymous submissions carry no session CSRF token, so they must come from an allowed origin
 * and carry the custom header the site script sets (a cross-site HTML form cannot).
 */
export function requireFormRequest(req: Request, _res: Response, next: NextFunction) {
  try {
    assertTrustedOrigin(req);
    if (req.get(FORMS_REQUEST_HEADER) !== '1') throw Forbidden('Missing form request header.');
    next();
  } catch (error) {
    next(error);
  }
}

/**
 * Submissions with files are read into memory (up to 100 MB each), so only a few are taken at the
 * same time — across the server, and per visitor — and the rest are asked to try again shortly.
 */
let inFlight = 0;
const perVisitor = new Map<string, number>();
const MAX_IN_FLIGHT = 6;
const MAX_PER_VISITOR = 2;

export function limitSubmissions(req: Request, res: Response, next: NextFunction) {
  const key = visitorKey(req);
  const mine = perVisitor.get(key) ?? 0;
  if (inFlight >= MAX_IN_FLIGHT || mine >= MAX_PER_VISITOR) {
    next(TooManyRequests('The form is busy right now. Please try again in a moment.'));
    return;
  }
  inFlight += 1;
  perVisitor.set(key, mine + 1);
  let released = false;
  const release = () => {
    if (released) return;
    released = true;
    inFlight -= 1;
    const left = (perVisitor.get(key) ?? 1) - 1;
    if (left > 0) perVisitor.set(key, left);
    else perVisitor.delete(key);
  };
  res.on('finish', release);
  res.on('close', release);
  next();
}

/** Multipart parser for a submission: many text fields, a few files, all kept in memory. */
export const parseSubmission = Object.assign(
  multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: FORMS_MAX_FILE_BYTES,
      files: FORMS_MAX_FILES,
      fields: FORMS_MAX_FIELDS,
      fieldSize: 64 * 1024,
      parts: FORMS_MAX_FIELDS + FORMS_MAX_FILES,
    },
  }).any(),
  { upload: { field: 'f_*', maxBytes: FORMS_MAX_FILE_BYTES } },
);

/** Browsers send UTF-8 names; busboy decodes them as latin1. */
export function fixUploadNames(req: Request, _res: Response, next: NextFunction) {
  for (const f of (req.files as Express.Multer.File[] | undefined) ?? []) {
    f.originalname = Buffer.from(f.originalname, 'latin1').toString('utf8');
  }
  // Runs right after the multipart parser, which can resolve outside the site context.
  rebindSite(req, _res, next);
}
