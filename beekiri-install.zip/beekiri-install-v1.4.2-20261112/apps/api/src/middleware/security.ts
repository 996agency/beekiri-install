import cors from 'cors';
import { createHash } from 'crypto';
import type { Request } from 'express';
import helmet from 'helmet';
import { config } from '../config/env';
import { isLoopbackOrigin } from '../utils/loopback';

const allowed = new Set(config.corsOrigins);

/** The configured site addresses, plus (outside production) anything on this machine. */
export function isAllowedOrigin(origin: string): boolean {
  return allowed.has(origin) || (config.allowLoopbackOrigins && isLoopbackOrigin(origin));
}

/**
 * Origin of this API as the browser sees it (same-origin calls are always fine). Behind a
 * trusted proxy (see TRUST_PROXY) the scheme and host come from X-Forwarded-Proto/-Host.
 */
export function selfOrigin(req: Request): string {
  return `${req.protocol}://${req.host ?? ''}`;
}

/**
 * Only allow-listed browser origins get CORS headers (with cookies). Requests without
 * an Origin (server-side fetches from the public site, curl) are not affected by CORS.
 */
export const corsMiddleware = cors({
  origin(origin, callback) {
    callback(null, !origin || isAllowedOrigin(origin));
  },
  credentials: true,
  methods: ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'X-CSRF-Token', 'X-Setup-Token', 'Authorization'],
  maxAge: 600,
});

/** Every response: the usual hardening headers, without a page CSP (pages set their own). */
export const siteSecurityHeaders = helmet({
  // Theme/layout assets and uploads may be embedded by other pages.
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
  hsts: config.isProduction ? { maxAge: 15_552_000, includeSubDomains: true } : false,
});

/** SHA-256 sources for the inline scripts a built HTML document carries. */
function inlineScriptHashes(html: string): string[] {
  const hashes = new Set<string>();
  for (const match of html.matchAll(/<script\b(?![^>]*\bsrc\s*=)[^>]*>([\s\S]*?)<\/script>/gi)) {
    const body = match[1] ?? '';
    if (!body.trim()) continue;
    hashes.add(`'sha256-${createHash('sha256').update(body, 'utf8').digest('base64')}'`);
  }
  return [...hashes];
}

/**
 * The admin document (production build). Scripts may only come from this site, plus the
 * exact inline snippets shipped in index.html, so injected markup can never run code with
 * an administrator's session. Styles, images and fonts stay open: themes previewed in
 * the editor may use web fonts and remote images.
 */
export function adminDocumentCsp(html: string, host: string | undefined): string {
  const sockets = host ? ` ws://${host} wss://${host}` : '';
  return [
    "default-src 'self'",
    ["script-src 'self'", ...inlineScriptHashes(html)].join(' '),
    "style-src 'self' 'unsafe-inline' https:",
    "img-src 'self' data: blob: https:",
    "media-src 'self' data: blob: https:",
    "font-src 'self' data: https:",
    `connect-src 'self'${sockets}`,
    // Video and Map elements on the editor canvas (the map source is that one path, not all of google.com).
    "frame-src 'self' https://www.youtube-nocookie.com https://www.youtube.com https://player.vimeo.com https://www.google.com/maps",
    "worker-src 'self' blob:",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'self'",
  ].join('; ');
}

/**
 * Public website pages. Site owners may add their own scripts (analytics, chat widgets)
 * through Settings, so scripts are not restricted here; this blocks plugins, <base>
 * hijacking and framing by other sites, and upgrades stray http:// requests on https sites.
 */
export function websiteCsp(): string {
  return [
    "object-src 'none'",
    "base-uri 'self'",
    "frame-ancestors 'self'",
    ...(config.auth.cookieSecure ? ['upgrade-insecure-requests'] : []),
  ].join('; ');
}

/** JSON API responses: nothing in them may run as a page or be framed. */
export const apiContentSecurityPolicy = helmet.contentSecurityPolicy({
  useDefaults: false,
  directives: { defaultSrc: ["'none'"], frameAncestors: ["'none'"] },
});
