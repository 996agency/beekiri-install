import type { NextFunction, Request, Response } from 'express';
import { bookingCssUrl } from '../lib/bookings/assets';
import { BOOKINGS_EXTENSION_SLUG, BOOKINGS_REQUEST_HEADER } from '../lib/bookings/constants';
import { extensionsService } from '../services/extensions.service';
import { Forbidden, NotFound } from '../utils/http-error';
import { assertTrustedOrigin } from './authenticate';

/** Every bookings route answers 404 while the extension is not active. */
export async function requireBookingsActive(_req: Request, _res: Response, next: NextFunction) {
  try {
    if (!(await extensionsService.isActive(BOOKINGS_EXTENSION_SLUG))) throw NotFound('Bee Bookings is not active.');
    next();
  } catch (error) {
    next(error);
  }
}

/** The website asks on every render; a 200 `{ active:false }` keeps its fetch cache honest (see forms.ts). */
export async function bookingsConfig(_req: Request, res: Response, next: NextFunction) {
  try {
    const active = await extensionsService.isActive(BOOKINGS_EXTENSION_SLUG);
    res.json({ active, ...(active ? { cssUrl: bookingCssUrl() } : {}) });
  } catch (error) {
    next(error);
  }
}

/**
 * Anonymous bookings carry no session CSRF token, so they must come from an allowed origin
 * and carry the custom header the site script sets (a cross-site HTML form cannot).
 */
export function requireBookingRequest(req: Request, _res: Response, next: NextFunction) {
  try {
    assertTrustedOrigin(req);
    if (req.get(BOOKINGS_REQUEST_HEADER) !== '1') throw Forbidden('Missing booking request header.');
    next();
  } catch (error) {
    next(error);
  }
}
