import {
  Model,
  type CreationOptional,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, optionalText, text } from './_shared';

/** One thing the admin's bell reports: a new order, a booking, a form entry, a changed setting… */
export class AdminNotification extends Model<InferAttributes<AdminNotification>, InferCreationAttributes<AdminNotification>> {
  declare id: CreationOptional<string>;
  declare siteId: string;
  declare kind: string;
  declare title: string;
  declare body: CreationOptional<string>;
  /** Admin path it opens. */
  declare link: CreationOptional<string>;
  /** Capability needed to see it ('' = everyone in the admin). */
  declare capability: CreationOptional<string>;
  /** Who did it (not notified about their own action). */
  declare actorId: CreationOptional<string | null>;
  declare dedupeKey: CreationOptional<string | null>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    AdminNotification.init(
      {
        id: idColumn(),
        siteId: text(),
        kind: text(),
        title: text(),
        body: text({ defaultValue: '' }),
        link: text({ defaultValue: '' }),
        capability: text({ defaultValue: '' }),
        actorId: optionalText(),
        dedupeKey: optionalText(),
        createdAt: date(),
      },
      { sequelize, tableName: 'AdminNotification', modelName: 'AdminNotification', timestamps: true, updatedAt: false },
    );
  }
}

/** When a person last opened the bell on a site: everything newer counts as unread. */
export class AdminNotificationSeen extends Model<InferAttributes<AdminNotificationSeen>, InferCreationAttributes<AdminNotificationSeen>> {
  declare id: CreationOptional<string>;
  declare siteId: string;
  declare userId: string;
  declare seenAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    AdminNotificationSeen.init(
      { id: idColumn(), siteId: text(), userId: text(), seenAt: date() },
      { sequelize, tableName: 'AdminNotificationSeen', modelName: 'AdminNotificationSeen', timestamps: false },
    );
  }
}
