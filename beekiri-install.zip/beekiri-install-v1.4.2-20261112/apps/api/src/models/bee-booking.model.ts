import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import type { BookingStatus } from '../lib/bookings/constants';
import { bool, date, idColumn, int, jsonb, optionalDate, optionalText, text, type Json } from './_shared';
import type { Site } from './site.model';

/** Something customers book: its length, the free time kept after it, and its price. */
export class BeeBookingService extends Model<InferAttributes<BeeBookingService>, InferCreationAttributes<BeeBookingService>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare name: string;
  declare description: CreationOptional<string>;
  declare durationMin: CreationOptional<number>;
  declare bufferMin: CreationOptional<number>;
  declare priceCents: CreationOptional<number>;
  declare color: CreationOptional<string>;
  declare active: CreationOptional<boolean>;
  declare sortOrder: CreationOptional<number>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    BeeBookingService.init(
      {
        id: idColumn(),
        siteId: text(),
        name: text(),
        description: text({ defaultValue: '' }),
        durationMin: int(60),
        bufferMin: int(0),
        priceCents: int(0),
        color: text({ defaultValue: '#006199' }),
        active: bool(true),
        sortOrder: int(0),
        createdAt: date(),
        updatedAt: date(),
      },
      { sequelize, tableName: 'BeeBookingService', modelName: 'BeeBookingService', timestamps: true },
    );
  }
}

/** A person (or room, chair…) that takes appointments, with the services they do and their hours. */
export class BeeBookingStaff extends Model<InferAttributes<BeeBookingStaff>, InferCreationAttributes<BeeBookingStaff>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare name: string;
  declare email: CreationOptional<string>;
  declare phone: CreationOptional<string>;
  declare serviceIds: CreationOptional<Json>;
  declare hours: CreationOptional<Json | null>;
  declare daysOff: CreationOptional<Json>;
  declare active: CreationOptional<boolean>;
  declare sortOrder: CreationOptional<number>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    BeeBookingStaff.init(
      {
        id: idColumn(),
        siteId: text(),
        name: text(),
        email: text({ defaultValue: '' }),
        phone: text({ defaultValue: '' }),
        serviceIds: jsonb([]),
        hours: { ...jsonb(null), allowNull: true },
        daysOff: jsonb([]),
        active: bool(true),
        sortOrder: int(0),
        createdAt: date(),
        updatedAt: date(),
      },
      { sequelize, tableName: 'BeeBookingStaff', modelName: 'BeeBookingStaff', timestamps: true },
    );
  }
}

/** An appointment, or blocked time (`kind: 'block'`, no customer; no staff = everyone). */
export class BeeBooking extends Model<InferAttributes<BeeBooking>, InferCreationAttributes<BeeBooking>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare kind: CreationOptional<'appointment' | 'block'>;
  declare serviceId: CreationOptional<string | null>;
  declare staffId: CreationOptional<string | null>;
  declare serviceName: CreationOptional<string>;
  declare priceCents: CreationOptional<number>;
  declare bufferMin: CreationOptional<number>;
  declare startAt: Date;
  declare endAt: Date;
  declare status: CreationOptional<BookingStatus>;
  declare customerName: CreationOptional<string>;
  declare customerEmail: CreationOptional<string>;
  declare customerPhone: CreationOptional<string>;
  declare note: CreationOptional<string>;
  declare adminNote: CreationOptional<string>;
  declare token: string;
  declare source: CreationOptional<'website' | 'admin'>;
  declare reminderSentAt: CreationOptional<Date | null>;
  declare cancelledAt: CreationOptional<Date | null>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    BeeBooking.init(
      {
        id: idColumn(),
        siteId: text(),
        kind: text({ defaultValue: 'appointment' }),
        serviceId: optionalText(),
        staffId: optionalText(),
        serviceName: text({ defaultValue: '' }),
        priceCents: int(0),
        bufferMin: int(0),
        startAt: date(),
        endAt: date(),
        status: text({ defaultValue: 'confirmed' }),
        customerName: text({ defaultValue: '' }),
        customerEmail: text({ defaultValue: '' }),
        customerPhone: text({ defaultValue: '' }),
        note: text({ defaultValue: '' }),
        adminNote: text({ defaultValue: '' }),
        token: text(),
        source: text({ defaultValue: 'website' }),
        reminderSentAt: optionalDate(),
        cancelledAt: optionalDate(),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'BeeBooking',
        modelName: 'BeeBooking',
        timestamps: true,
        indexes: [{ name: 'BeeBooking_siteId_startAt_idx', fields: ['siteId', 'startAt'] }],
      },
    );
  }
}

/** One row per site: the Bee Bookings settings (parsed by lib/bookings/schema). */
export class BeeBookingSetting extends Model<InferAttributes<BeeBookingSetting>, InferCreationAttributes<BeeBookingSetting>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare data: CreationOptional<Json>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    BeeBookingSetting.init(
      { id: idColumn(), siteId: text(), data: jsonb({}), createdAt: date(), updatedAt: date() },
      {
        sequelize,
        tableName: 'BeeBookingSetting',
        modelName: 'BeeBookingSetting',
        timestamps: true,
        indexes: [{ name: 'BeeBookingSetting_siteId_key', unique: true, fields: ['siteId'] }],
      },
    );
  }
}
