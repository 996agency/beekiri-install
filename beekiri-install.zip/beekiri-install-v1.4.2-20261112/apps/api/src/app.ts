import cookieParser from 'cookie-parser';
import express, { Router, type Express } from 'express';
import { mkdirSync } from 'fs';
import { config } from './config/env';
import { rebindSite, siteContext } from './lib/site/current-site';
import { siteLock } from './lib/site/site-lock';
import { mediaVariant } from './lib/media/media-variant';
import { resolveUploadsRoot } from './lib/media/media.paths';
import { compressText } from './middleware/compress';
import { errorHandler, notFoundHandler } from './middleware/error-handler';
import { requireAuth, requireCapabilities } from './middleware/authenticate';
import { apiRateLimit } from './middleware/rate-limit';
import {
  apiContentSecurityPolicy,
  corsMiddleware,
  siteSecurityHeaders,
} from './middleware/security';
import { requireConfiguredDatabase } from './middleware/setup';
import { apiRoutes } from './routes';
import { docsRoutes } from './routes/docs.routes';

/** Everything under /api: parsers, CORS and errors stay here so pages get untouched requests. */
function apiApp(): Router {
  const api = Router();
  // Stylesheets, scripts and JSON go out compressed (the shop's CSS: 85 KB → about 12 KB).
  api.use(compressText);
  api.use(apiContentSecurityPolicy);
  api.use(corsMiddleware);
  const json = express.json({
    limit: config.server.jsonBodyLimit,
    // Payment webhooks verify a signature over the exact bytes received.
    verify: (req, _res, buf) => {
      if (req.url?.startsWith('/shop/webhooks/')) (req as express.Request & { rawBody?: Buffer }).rawBody = buf;
    },
  });
  // A Beekiri message can carry a few pictures: that one route reads its (larger) body itself,
  // after the sign-in check (routes/connector.routes.ts).
  api.use((req, res, next) => (req.method === 'POST' && req.path === '/connector/agent' ? next() : json(req, res, next)));
  api.use(express.urlencoded({ extended: false, limit: config.server.jsonBodyLimit }));
  api.use(cookieParser());
  // Body parsers can call back outside the request's site context; put it back.
  api.use(rebindSite);
  // The API map (every route and the permission it needs) is for site administrators only.
  api.use(
    '/docs',
    requireConfiguredDatabase,
    apiRateLimit,
    requireAuth,
    requireCapabilities('manage_options'),
    docsRoutes,
  );
  api.use(requireConfiguredDatabase, apiRateLimit, apiRoutes);
  api.use(notFoundHandler);
  api.use(errorHandler);
  return api;
}

/**
 * One server for the whole site: /api, /uploads and, via `mountSite`, the admin
 * (/admin) and the website (everything else).
 */
export function createApp({ mountSite }: { mountSite?: (app: Express) => void } = {}): Express {
  const app = express();

  app.set('trust proxy', config.server.trustProxy);
  app.disable('x-powered-by');
  app.use(siteSecurityHeaders);

  const uploadsRoot = resolveUploadsRoot();
  mkdirSync(uploadsRoot, { recursive: true });

  // Multisite: which site of the network this request is for (by host), kept for the request.
  app.use(siteContext);
  // Password-protected sites: only visitors with the password get past this.
  app.use(siteLock);
  // Uploads sit behind the lock too: a protected site's photos and files are its content.
  // Phone-sized copies of photos (/uploads/_w828/…), made on first request.
  app.use('/uploads', mediaVariant(uploadsRoot));
  app.use(
    '/uploads',
    express.static(uploadsRoot, {
      dotfiles: 'deny',
      index: false,
      redirect: false,
      fallthrough: true,
      setHeaders(res, path) {
        // Upload names carry a content hash, so images can be cached for a year.
        if (/\.(webp|avif|jpe?g|png|gif)$/i.test(path)) {
          // A protected site's files must not be kept by shared caches (CDN, proxies).
          const locked = Boolean((res as express.Response).locals?.siteLocked);
          res.setHeader('Cache-Control', `${locked ? 'private' : 'public'}, max-age=31536000, immutable`);
        }
        // Uploaded SVG/HTML must never execute as a page on the site's origin.
        res.setHeader(
          'Content-Security-Policy',
          "default-src 'none'; style-src 'unsafe-inline'; sandbox",
        );
      },
    }),
  );

  app.use('/api', apiApp());
  mountSite?.(app);
  app.use(notFoundHandler);
  return app;
}
