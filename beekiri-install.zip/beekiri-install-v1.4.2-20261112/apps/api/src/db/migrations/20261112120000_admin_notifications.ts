import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

/** Admin notifications (the bell in the toolbar) and when each person last looked at them. */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.createTable(
      'AdminNotification',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        /** What happened, e.g. 'shop.order', 'booking.new', 'form.entry', 'settings.updated', 'core.update'. */
        kind: { type: DataTypes.TEXT, allowNull: false },
        title: { type: DataTypes.TEXT, allowNull: false },
        body: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        /** Admin path it opens, e.g. 'shop/orders/abc'. */
        link: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        /** The capability a person needs to see it ('' = everyone who can open the admin). */
        capability: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        /** Who did it: they are not notified about their own action. */
        actorId: { type: DataTypes.TEXT, allowNull: true },
        /** One notification per key and site (e.g. one per new core version). */
        dedupeKey: { type: DataTypes.TEXT, allowNull: true },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.createTable(
      'AdminNotificationSeen',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        userId: { type: DataTypes.TEXT, allowNull: false },
        seenAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.addIndex('AdminNotification', ['siteId', 'createdAt'], { name: 'AdminNotification_siteId_createdAt_idx', transaction });
    await queryInterface.addIndex('AdminNotification', ['siteId', 'dedupeKey'], { name: 'AdminNotification_siteId_dedupeKey_key', unique: true, transaction });
    await queryInterface.addIndex('AdminNotificationSeen', ['siteId', 'userId'], { name: 'AdminNotificationSeen_siteId_userId_key', unique: true, transaction });
    for (const table of ['AdminNotification', 'AdminNotificationSeen']) {
      await queryInterface.addConstraint(table, {
        type: 'foreign key',
        name: `${table}_siteId_fkey`,
        fields: ['siteId'],
        references: { table: 'Site', field: 'id' },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
        transaction,
      });
    }
    await queryInterface.addConstraint('AdminNotificationSeen', {
      type: 'foreign key',
      name: 'AdminNotificationSeen_userId_fkey',
      fields: ['userId'],
      references: { table: 'User', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.dropTable('AdminNotificationSeen', { transaction });
    await queryInterface.dropTable('AdminNotification', { transaction });
  });
}
