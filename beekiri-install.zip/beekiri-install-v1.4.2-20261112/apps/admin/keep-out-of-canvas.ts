import path from 'node:path';

/** The parts of a PostCSS rule used here (Vite brings its own postcss copy, so no shared types). */
type CssNode = { type: string; name?: string; parent?: CssNode };
type CssRule = CssNode & { selectors: string[]; source?: { input: { file?: string } } };

/**
 * The page editor draws theme layouts inside the admin page, and themes use the same class names
 * as the admin (.bk-title, .bk-actions, .bk-muted, .bk-panel…). Without this, admin rules restyle
 * those sections, so the editor shows something the site doesn't.
 *
 * Every admin rule gets `:where(:not(.bk-beekiricode__frame-canvas *))` on the element it styles:
 * it no longer reaches inside a canvas frame, and `:where` keeps its specificity unchanged.
 * Editor stylesheets (src/editor/**) are left alone — they style the canvas on purpose.
 */
const FRAME = '.bk-beekiricode__frame-canvas';
const GUARD = `:where(:not(${FRAME} *))`;
const PSEUDO_ELEMENT = /^(?:::|:(?:before|after|first-line|first-letter)\b)/i;

/** Where the guard goes in `selector`: before a pseudo-element of the last compound, else at the end. */
function guardAt(selector: string): number {
  let depth = 0;
  let quote = '';
  let compound = 0;
  let pseudo = -1;
  for (let i = 0; i < selector.length; i++) {
    const ch = selector[i];
    if (quote) {
      if (ch === '\\') i++;
      else if (ch === quote) quote = '';
      continue;
    }
    if (ch === '"' || ch === "'") quote = ch;
    else if (ch === '\\') i++;
    else if (ch === '(' || ch === '[') depth++;
    else if (ch === ')' || ch === ']') depth--;
    else if (depth === 0 && /[\s>+~]/.test(ch)) {
      compound = i + 1;
      pseudo = -1;
    } else if (depth === 0 && ch === ':' && pseudo < 0 && i >= compound && PSEUDO_ELEMENT.test(selector.slice(i))) {
      pseudo = i;
    }
  }
  return pseudo >= 0 ? pseudo : selector.trimEnd().length;
}

export function guardSelector(selector: string): string {
  if (selector.includes('bk-beekiricode') || selector.includes(GUARD)) return selector;
  const at = guardAt(selector);
  return `${selector.slice(0, at)}${GUARD}${selector.slice(at)}`;
}

function inKeyframes(rule: CssRule): boolean {
  for (let p = rule.parent; p; p = p.parent) {
    if (p.type === 'atrule' && /keyframes$/i.test(p.name ?? '')) return true;
  }
  return false;
}

export function keepOutOfCanvas(srcDir: string) {
  const editorDir = path.join(srcDir, 'editor') + path.sep;
  return {
    postcssPlugin: 'beekiri-keep-out-of-canvas',
    Rule(rule: CssRule) {
      const file = rule.source?.input.file;
      if (!file || !file.startsWith(srcDir + path.sep) || file.startsWith(editorDir)) return;
      if (inKeyframes(rule)) return;
      const next = rule.selectors.map(guardSelector);
      if (next.some((s, i) => s !== rule.selectors[i])) rule.selectors = next;
    },
  };
}
