import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { keepOutOfCanvas } from './keep-out-of-canvas';

const srcDir = path.join(path.dirname(fileURLToPath(import.meta.url)), 'src');

// The admin is served by the Beekiri server at /admin (built files in production, this
// config as middleware in development), on the same address as the API and website.
export default defineConfig({
  base: '/admin/',
  plugins: [react()],
  css: {
    // Admin styles stop at the page editor's canvas, so theme sections look as they do on the site.
    postcss: { plugins: [keepOutOfCanvas(srcDir)] },
  },
  server: {
    fs: {
      // Shared editor packages (page-blocks / beekiricanva) live in apps/web/modules.
      allow: ['../..', '../web/modules'],
    },
  },
});
