export type CapabilitySlug =
  | 'manage_options'
  | 'edit_users'
  | 'list_users'
  | 'create_users'
  | 'delete_users'
  | 'edit_posts'
  | 'edit_others_posts'
  | 'publish_posts'
  | 'delete_posts'
  | 'edit_pages'
  | 'edit_others_pages'
  | 'publish_pages'
  | 'delete_pages'
  | 'upload_files'
  | 'moderate_comments'
  | 'manage_categories'
  | 'edit_theme_options'
  | 'customize_dashboard'
  | 'manage_fields'
  | 'update_core'
  | 'manage_settings_general'
  | 'manage_settings_reading'
  | 'manage_settings_writing'
  | 'manage_settings_page_editor'
  | 'manage_settings_advanced'
  | 'manage_settings_permalinks'
  | 'manage_settings_media'
  | 'manage_settings_cache'
  | 'manage_settings_instructions'
  | 'use_beequeen'
  | 'unfiltered_html'
  | 'manage_shop'
  | 'edit_products'
  | 'edit_shop_orders'
  | 'view_shop_reports'
  | 'manage_forms'
  | 'view_form_entries'
  | 'manage_bookings'
  | 'read';

export type RoleSlug =
  | 'administrator'
  | 'editor'
  | 'author'
  | 'contributor'
  | 'subscriber'
  | 'shop_manager';

export interface PublicUser {
  id: string;
  username: string;
  email: string;
  displayName: string;
  role: RoleSlug;
  capabilities: CapabilitySlug[];
  isOwner: boolean;
  /** The site of the network this session is on (multisite). */
  siteId?: string;
}

export interface SitePublic {
  id: string;
  title: string;
  tagline: string;
  language: string;
  installed: boolean;
  blogPublic: boolean;
}

export interface InstallStatusResponse {
  installed: boolean;
  databaseOk: boolean;
  databaseMessage: string;
  canInstall: boolean;
}

export interface InstallRequest {
  language: string;
  siteTitle: string;
  username: string;
  password: string;
  email: string;
  blogPublic: boolean;
}

export interface LoginRequest {
  login: string;
  password: string;
  remember?: boolean;
}

export interface ApiErrorBody {
  statusCode: number;
  message: string;
  error?: string;
  code?: string;
}
