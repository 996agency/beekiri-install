import { FormEvent, useCallback, useEffect, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import type { RoleSlug } from '../cms-types';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import { useAdminHref } from '../lib/AdminEntryContext';
import { generatePassword, passwordStrength } from '../util/password';
import { ErrorNotice } from '../components/ErrorNotice';
import { Check, Copy, Eye, EyeSlash, Plus, Sparkle, Trash, User } from '@phosphor-icons/react';
import './user-edit-page.css';

type RoleOption = { slug: RoleSlug; label: string };

type CustomField = { id: string; label: string; value: string };

type SiteUser = {
  id: string;
  username: string;
  email: string;
  displayName: string;
  role: RoleSlug;
  roleLabel: string;
  isOwner: boolean;
  jobDescription?: string;
  customFields?: CustomField[];
  createdAt: string;
  updatedAt: string;
};

const EMPTY_FORM = {
  username: '',
  email: '',
  displayName: '',
  password: '',
  currentPassword: '',
  role: 'subscriber' as RoleSlug,
  jobDescription: '',
  customFields: [] as CustomField[],
};

function newCustomField(): CustomField {
  return {
    id: `cf-${Math.random().toString(36).slice(2, 9)}`,
    label: '',
    value: '',
  };
}

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

const ROLE_LABELS: Record<RoleSlug, string> = {
  administrator: 'Administrator',
  editor: 'Editor',
  author: 'Author',
  contributor: 'Contributor',
  subscriber: 'Subscriber',
  shop_manager: 'Shop manager',
};

/** What a role is for, in one line. The exact rights of each role are set in User Permissions. */
const ROLE_HINTS: Record<RoleSlug, string> = {
  administrator: 'Runs the site: settings, users, themes and all content.',
  editor: 'Publishes and manages all pages and posts.',
  author: 'Writes and publishes their own posts.',
  contributor: 'Writes posts; someone else publishes them.',
  subscriber: 'Signs in and looks after their own profile.',
  shop_manager: 'Looks after products, orders and customers.',
};

const STRENGTH_LABEL = { weak: 'Weak', medium: 'Good', strong: 'Strong' } as const;

/** "Altin Beqiri" → "AB"; one word → its first two letters. */
function initials(name: string): string {
  const words = name.trim().split(/[\s._-]+/).filter(Boolean);
  if (!words.length) return '?';
  return (words.length === 1 ? words[0].slice(0, 2) : words[0][0] + words[words.length - 1][0]).toUpperCase();
}

function longDate(iso: string): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '—' : d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

export function UserEditPage() {
  const { id } = useParams<{ id: string }>();
  const isNew = !id || id === 'new';
  const auth = useAuth();
  const href = useAdminHref();
  const navigate = useNavigate();
  const location = useLocation();

  const [roles, setRoles] = useState<RoleOption[]>([]);
  const [user, setUser] = useState<SiteUser | null>(null);
  const [loading, setLoading] = useState(!isNew);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [showPw, setShowPw] = useState(isNew);
  const [copiedId, setCopiedId] = useState(false);

  useEffect(() => {
    const state = location.state as { notice?: string } | null;
    if (state?.notice) {
      setNotice(state.notice);
      navigate(location.pathname, { replace: true, state: null });
    }
  }, [location.pathname, location.state, navigate]);

  const canCreate = auth.user?.capabilities.includes('create_users') ?? false;
  const canEdit = auth.user?.capabilities.includes('edit_users') ?? false;
  const canList = auth.user?.capabilities.includes('list_users') ?? false;
  const isSelf = Boolean(id && auth.user?.id === id);
  const allowed = isNew ? canCreate : canEdit || isSelf;
  const canChangeRole = canEdit && !isSelf;
  /** Same rule as the menu: the owner manages what each role may do. */
  const canSeePermissions = Boolean(auth.user?.isOwner);
  const backTo = canList ? href('users') : href();
  const pageTitle = isNew
    ? 'Add new user'
    : isSelf
      ? 'Your profile'
      : 'Edit user';

  const loadRoles = useCallback(async () => {
    if (!canList) return;
    const res = await api<{ roles: RoleOption[] }>('/api/users/roles');
    setRoles(res.roles);
    return res.roles;
  }, [canList]);

  useEffect(() => {
    if (!allowed) return;
    let cancelled = false;
    (async () => {
      try {
        setError(null);
        const options = (await loadRoles()) ?? [];
        if (isNew) {
          if (!cancelled) {
            // Roles can be deleted in User Permissions: start on one that still exists.
            const role =
              options.find((r) => r.slug === EMPTY_FORM.role)?.slug ??
              [...options].reverse().find((r) => r.slug !== 'administrator')?.slug ??
              EMPTY_FORM.role;
            setForm({ ...EMPTY_FORM, role, password: generatePassword(16), customFields: [] });
            setShowPw(true);
            setUser(null);
            setLoading(false);
          }
          return;
        }
        setLoading(true);
        const row = await api<SiteUser>(`/api/users/${id}`);
        if (cancelled) return;
        setUser(row);
        setForm({
          username: row.username,
          email: row.email,
          displayName: row.displayName,
          password: '',
          currentPassword: '',
          role: row.role,
          jobDescription: row.jobDescription ?? '',
          customFields: (row.customFields ?? []).map((f) => ({ ...f })),
        });
        setShowPw(false);
      } catch (e) {
        if (!cancelled) setError(formatError(e));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [allowed, id, isNew, loadRoles]);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!allowed) return;
    setBusy(true);
    setError(null);
    try {
      const profilePayload = {
        jobDescription: form.jobDescription.trim(),
        customFields: form.customFields
          .map((f) => ({
            id: f.id,
            label: f.label.trim(),
            value: f.value.trim(),
          }))
          .filter((f) => f.label),
      };
      if (isNew) {
        const created = await api<SiteUser>('/api/users', {
          method: 'POST',
          json: {
            username: form.username.trim(),
            email: form.email.trim(),
            displayName: form.displayName.trim() || form.username.trim(),
            password: form.password,
            role: form.role,
            ...profilePayload,
          },
        });
        navigate(href(`users/${created.id}`), {
          replace: true,
          state: { notice: `User “${created.username}” created.` },
        });
        return;
      }

      if (!id) return;
      const payload: Record<string, unknown> = {
        username: form.username.trim(),
        email: form.email.trim(),
        displayName: form.displayName.trim() || form.username.trim(),
        ...profilePayload,
      };
      if (canChangeRole) payload.role = form.role;
      if (form.password.trim()) payload.password = form.password.trim();
      if (isSelf && form.currentPassword) payload.currentPassword = form.currentPassword;
      const updated = await api<SiteUser>(`/api/users/${id}`, {
        method: 'PATCH',
        json: payload,
      });
      setUser(updated);
      setForm((f) => ({ ...f, password: '', currentPassword: '' }));
      const notice =
        form.password.trim() && updated.id === auth.user?.id
          ? `Profile updated. Your password changed — you may need to sign in again.`
          : isSelf
            ? 'Your profile was updated.'
            : `User “${updated.username}” updated.`;
      if (isSelf && !canList) {
        setNotice(notice);
      } else {
        navigate(backTo, { state: { notice } });
      }
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  if (!allowed) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title={pageTitle} />
        <div className="beekiri-notice is-error" role="alert">
          <p>You do not have permission to {isNew ? 'create' : 'edit'} users.</p>
        </div>
        <p>
          <Link to={backTo} className="button">
            {canList ? 'Back to users' : 'Back to dashboard'}
          </Link>
        </p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title={pageTitle} />
        <p className="bk-muted">Loading…</p>
      </div>
    );
  }

  if (!isNew && !user && error) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title={pageTitle} />
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
        <p>
          <Link to={backTo} className="button">
            {canList ? 'Back to users' : 'Back to dashboard'}
          </Link>
        </p>
      </div>
    );
  }

  const formId = 'user-form';
  const editing = user;
  const strength = form.password ? passwordStrength(form.password) : null;
  const roleLabel =
    roles.find((r) => r.slug === form.role)?.label ?? ROLE_LABELS[form.role] ?? form.role;

  const shownName = form.displayName.trim() || form.username.trim() || (isNew ? 'New user' : '');
  const copyId = async () => {
    if (!editing) return;
    try {
      await navigator.clipboard.writeText(editing.id);
      setCopiedId(true);
      window.setTimeout(() => setCopiedId(false), 1600);
    } catch {
      window.prompt('Copy the user ID:', editing.id);
    }
  };

  return (
    <div className="wrap wrap--wide bk-user">
      <PageHeader
        title={editing ? (isSelf ? 'Your profile' : 'Edit user') : 'Add new user'}
        actions={
          <>
            <Link to={backTo} className="button" aria-disabled={busy}>
              Cancel
            </Link>
            <button type="submit" form={formId} className="button button-primary" disabled={busy}>
              {busy ? 'Saving…' : editing ? 'Save changes' : 'Add user'}
            </button>
          </>
        }
      />

      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}

      <section className="bk-panel bk-user-card" aria-label="Account">
        <span className="bk-user-card__avatar" aria-hidden>
          {form.displayName.trim() || form.username.trim() ? initials(shownName) : <User size={28} />}
        </span>
        <div className="bk-user-card__who">
          <h2 className="bk-user-card__name">{shownName || 'New user'}</h2>
          <p className="bk-user-card__line">
            {form.username.trim() ? `@${form.username.trim()}` : 'Choose a username below'}
            {form.email.trim() ? ` · ${form.email.trim()}` : ''}
          </p>
          <p className="bk-user-card__tags">
            <span className="bk-user-tag is-role">{roleLabel}</span>
            {editing?.isOwner ? <span className="bk-user-tag is-owner">Site owner</span> : null}
            {isSelf ? <span className="bk-user-tag">You</span> : null}
          </p>
        </div>
        {editing ? (
          <dl className="bk-user-card__facts">
            <div>
              <dt>Member since</dt>
              <dd>{longDate(editing.createdAt)}</dd>
            </div>
            <div>
              <dt>Last updated</dt>
              <dd>{longDate(editing.updatedAt)}</dd>
            </div>
            <div>
              <dt>User ID</dt>
              <dd>
                <code className="bk-user-id">{editing.id}</code>
                <button type="button" className="bk-user-iconbtn" onClick={() => void copyId()} title="Copy the user ID" aria-label="Copy the user ID">
                  {copiedId ? <Check size={14} weight="bold" /> : <Copy size={14} />}
                </button>
              </dd>
            </div>
          </dl>
        ) : (
          <p className="bk-user-card__note">Create an account for someone who needs access to this site.</p>
        )}
      </section>

      <form id={formId} className="bk-user-layout" onSubmit={onSubmit}>
        <div className="bk-user-layout__main">
          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Profile</h2>
            </div>
            <div className="bk-panel__body bk-user-grid">
              <div className="bk-field">
                <label htmlFor="user_username">Username</label>
                <input
                  id="user_username"
                  type="text"
                  autoComplete="off"
                  required
                  minLength={3}
                  maxLength={60}
                  value={form.username}
                  onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))}
                />
                <p className="description">Letters, numbers and . - _ only. Used to sign in.</p>
              </div>
              <div className="bk-field">
                <label htmlFor="user_email">Email</label>
                <input
                  id="user_email"
                  type="email"
                  autoComplete="off"
                  required
                  value={form.email}
                  onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                />
                <p className="description">For sign-in, password resets and notices.</p>
              </div>
              <div className="bk-field is-wide">
                <label htmlFor="user_display">Display name</label>
                <input
                  id="user_display"
                  type="text"
                  autoComplete="off"
                  maxLength={120}
                  value={form.displayName}
                  placeholder={form.username || 'Shown publicly'}
                  onChange={(e) => setForm((f) => ({ ...f, displayName: e.target.value }))}
                />
                <p className="description">The name shown on the site and in the admin. Empty: the username.</p>
              </div>
              <div className="bk-field is-wide">
                <label htmlFor="user_job">Job description</label>
                <textarea
                  id="user_job"
                  rows={3}
                  maxLength={2000}
                  value={form.jobDescription}
                  placeholder="Optional: role, team, or what this person does"
                  onChange={(e) => setForm((f) => ({ ...f, jobDescription: e.target.value }))}
                />
              </div>
            </div>
          </section>

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Custom fields</h2>
            </div>
            <div className="bk-panel__body">
              <p className="description bk-user-lead">Optional extras for this user only: department, phone, notes and so on.</p>
              {form.customFields.length ? (
                <div className="bk-user-fields" role="group" aria-label="Custom fields">
                  <span className="bk-user-fields__head">Label</span>
                  <span className="bk-user-fields__head">Value</span>
                  <span />
                  {form.customFields.map((field, index) => (
                    <div key={field.id} className="bk-user-fields__row">
                      <input
                        type="text"
                        maxLength={80}
                        placeholder="e.g. Phone"
                        aria-label={`Custom field ${index + 1} label`}
                        value={field.label}
                        onChange={(e) => {
                          const label = e.target.value;
                          setForm((f) => ({
                            ...f,
                            customFields: f.customFields.map((row) => (row.id === field.id ? { ...row, label } : row)),
                          }));
                        }}
                      />
                      <input
                        type="text"
                        maxLength={500}
                        placeholder="Value"
                        aria-label={`Custom field ${index + 1} value`}
                        value={field.value}
                        onChange={(e) => {
                          const value = e.target.value;
                          setForm((f) => ({
                            ...f,
                            customFields: f.customFields.map((row) => (row.id === field.id ? { ...row, value } : row)),
                          }));
                        }}
                      />
                      <button
                        type="button"
                        className="bk-user-iconbtn is-danger"
                        title="Remove this field"
                        aria-label={`Remove custom field ${index + 1}`}
                        onClick={() => setForm((f) => ({ ...f, customFields: f.customFields.filter((row) => row.id !== field.id) }))}
                      >
                        <Trash size={15} />
                      </button>
                    </div>
                  ))}
                </div>
              ) : null}
              <button
                type="button"
                className="button bk-user-add"
                onClick={() => setForm((f) => ({ ...f, customFields: [...f.customFields, newCustomField()] }))}
              >
                <Plus size={14} weight="bold" aria-hidden />
                Add field
              </button>
            </div>
          </section>
        </div>

        <div className="bk-user-layout__side">
          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Role</h2>
            </div>
            <div className="bk-panel__body bk-user-stack">
              {canChangeRole && !editing?.isOwner ? (
                <div className="bk-field">
                  <label htmlFor="user_role" className="screen-reader-text">
                    Role
                  </label>
                  <select id="user_role" value={form.role} onChange={(e) => setForm((f) => ({ ...f, role: e.target.value as RoleSlug }))}>
                    {roles.map((r) => (
                      <option key={r.slug} value={r.slug}>
                        {r.label}
                      </option>
                    ))}
                  </select>
                </div>
              ) : (
                <p className="bk-user-role">{roleLabel}</p>
              )}
              <p className="description">{ROLE_HINTS[form.role] ?? 'A role made for this site.'}</p>
              <p className="description">
                {editing?.isOwner
                  ? 'The site owner stays an administrator.'
                  : isSelf
                    ? 'Your role is set by the site owner.'
                    : canChangeRole
                      ? 'The role decides what this person can see and change.'
                      : 'The role cannot be changed here.'}
                {canSeePermissions ? (
                  <>
                    {' '}
                    <Link className="button-link" to={href('users/permissions')}>
                      See what each role can do
                    </Link>
                  </>
                ) : null}
              </p>
            </div>
          </section>

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Password</h2>
            </div>
            <div className="bk-panel__body bk-user-stack">
              {isSelf ? (
                <div className="bk-field">
                  <label htmlFor="user_current_password">Current password</label>
                  <input
                    id="user_current_password"
                    type="password"
                    autoComplete="current-password"
                    value={form.currentPassword}
                    onChange={(e) => setForm((f) => ({ ...f, currentPassword: e.target.value }))}
                  />
                  <p className="description">Needed to change your email address or password.</p>
                </div>
              ) : null}
              <div className="bk-field">
                <label htmlFor="user_password">{editing ? 'New password' : 'Password'}</label>
                <div className="bk-user-pwfield">
                  <input
                    id="user_password"
                    type={showPw ? 'text' : 'password'}
                    autoComplete="new-password"
                    required={!editing}
                    minLength={editing && !form.password ? undefined : 8}
                    value={form.password}
                    placeholder={editing ? 'Leave empty to keep it' : ''}
                    onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
                  />
                  <button
                    type="button"
                    className="bk-user-iconbtn"
                    onClick={() => setShowPw((v) => !v)}
                    title={showPw ? 'Hide the password' : 'Show the password'}
                    aria-label={showPw ? 'Hide the password' : 'Show the password'}
                  >
                    {showPw ? <EyeSlash size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                {strength ? (
                  <div className={`bk-user-strength is-${strength}`} role="status">
                    <span className="bk-user-strength__bar" aria-hidden>
                      <span />
                    </span>
                    <span className="bk-user-strength__label">{STRENGTH_LABEL[strength]}</span>
                  </div>
                ) : (
                  <p className="description">{editing ? 'Leave empty to keep the current password.' : 'At least 8 characters.'}</p>
                )}
              </div>
              <button
                type="button"
                className="button bk-user-add"
                onClick={() => {
                  setForm((f) => ({ ...f, password: generatePassword(16) }));
                  setShowPw(true);
                }}
              >
                <Sparkle size={14} aria-hidden />
                Generate a strong password
              </button>
            </div>
          </section>
        </div>
      </form>
    </div>
  );
}
