import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAdminHref } from '../lib/AdminEntryContext';

export type MediaFolder = {
  id: string;
  name: string;
  /** Auto-generated; unique among siblings. Not shown in the UI. */
  slug: string;
  /** null = top-level folder */
  parentId: string | null;
};

export type MediaSettings = {
  convertToWebp: boolean;
  webpLossless: boolean;
  webpQuality: number;
  maxWidth: number;
  maxHeight: number;
  stripMetadata: boolean;
  keepOriginal: boolean;
  folders: MediaFolder[];
};

type Props = {
  media: MediaSettings;
  busy: boolean;
  onSave: (media: MediaSettings) => void;
};

function uid() {
  return `folder-${Math.random().toString(36).slice(2, 9)}`;
}

function toSlug(label: string): string {
  return label
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .replace(/-{2,}/g, '-');
}

/** Unique slug among siblings so nested paths never collide. */
function uniqueSlug(name: string, siblings: MediaFolder[]): string {
  const base = toSlug(name) || 'folder';
  const taken = new Set(siblings.map((s) => s.slug));
  if (!taken.has(base)) return base;
  let n = 2;
  while (taken.has(`${base}-${n}`)) n += 1;
  return `${base}-${n}`;
}

/** A new folder under `parentId` (null = top level), with its id and path made for it. */
export function createMediaFolder(name: string, parentId: string | null, folders: MediaFolder[]): MediaFolder {
  const siblings = folders.filter((f) => (f.parentId ?? null) === parentId);
  return { id: uid(), name, slug: uniqueSlug(name, siblings), parentId };
}

function normalizeFolders(folders: MediaFolder[]): MediaFolder[] {
  return folders.map((f) => ({
    ...f,
    parentId: f.parentId ?? null,
  }));
}

export function MediaSettingsPanel({ media: initial, busy, onSave }: Props) {
  // Folders are created and deleted on the Media page; they are carried along here unchanged.
  const [media, setMedia] = useState<MediaSettings>(() => ({
    ...initial,
    folders: normalizeFolders(initial.folders),
  }));
  const href = useAdminHref();

  const patch = (partial: Partial<MediaSettings>) =>
    setMedia((m) => ({ ...m, ...partial }));

  return (
    <div className="bk-stack">
      <section className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Image optimization</h2>
        </div>
        <div className="bk-panel__body">
          <p className="bk-muted" style={{ marginTop: 0 }}>
            Every upload is optimized automatically — resized to Full HD and converted to{' '}
            <strong>WebP</strong>, quality preserved. The Media library will use these rules.
          </p>

          <div className="bk-media-opts">
            <label className="bk-check">
              <input
                type="checkbox"
                checked={media.convertToWebp}
                onChange={(e) => patch({ convertToWebp: e.target.checked })}
              />
              <span className="bk-check__box" aria-hidden />
              <span className="bk-check__label">Convert all images to WebP on upload</span>
            </label>

            <label className="bk-check">
              <input
                type="checkbox"
                checked={media.webpLossless}
                disabled={!media.convertToWebp}
                onChange={(e) => patch({ webpLossless: e.target.checked })}
              />
              <span className="bk-check__box" aria-hidden />
              <span className="bk-check__label">
                Best quality WebP (recommended): graphics stay lossless, photos are saved visually lossless at a fraction of the size
              </span>
            </label>

            {!media.webpLossless && media.convertToWebp ? (
              <div className="bk-field" style={{ maxWidth: 220 }}>
                <label htmlFor="webp_quality">WebP quality</label>
                <input
                  id="webp_quality"
                  type="number"
                  min={1}
                  max={100}
                  value={media.webpQuality}
                  onChange={(e) =>
                    patch({
                      webpQuality: Math.min(100, Math.max(1, Number(e.target.value) || 100)),
                    })
                  }
                />
                <p className="description">100 = highest quality when not using lossless.</p>
              </div>
            ) : null}

            <label className="bk-check">
              <input
                type="checkbox"
                checked={media.stripMetadata}
                onChange={(e) => patch({ stripMetadata: e.target.checked })}
              />
              <span className="bk-check__box" aria-hidden />
              <span className="bk-check__label">
                Strip EXIF / GPS metadata (smaller, more private)
              </span>
            </label>

            <label className="bk-check">
              <input
                type="checkbox"
                checked={media.keepOriginal}
                onChange={(e) => patch({ keepOriginal: e.target.checked })}
              />
              <span className="bk-check__box" aria-hidden />
              <span className="bk-check__label">Also keep the original file (uses more disk)</span>
            </label>
          </div>

          <div className="bk-media-dims">
            <div className="bk-field">
              <label htmlFor="media_max_w">Max width (px)</label>
              <input
                id="media_max_w"
                type="number"
                min={320}
                max={7680}
                value={media.maxWidth}
                onChange={(e) =>
                  patch({
                    maxWidth: Math.min(7680, Math.max(320, Number(e.target.value) || 1920)),
                  })
                }
              />
            </div>
            <div className="bk-field">
              <label htmlFor="media_max_h">Max height (px)</label>
              <input
                id="media_max_h"
                type="number"
                min={320}
                max={7680}
                value={media.maxHeight}
                onChange={(e) =>
                  patch({
                    maxHeight: Math.min(7680, Math.max(320, Number(e.target.value) || 1920)),
                  })
                }
              />
            </div>
          </div>
          <p className="description" style={{ marginTop: 8 }}>
            Default <strong>1920 × 1920</strong> = Full HD longest edge. Larger uploads are scaled
            down; smaller ones stay as-is. Never upscaled.
          </p>

          <div className="bk-help" style={{ marginTop: 16 }}>
            <strong>Pipeline:</strong> upload → resize to max Full HD → convert to WebP
            {media.webpLossless ? ' (lossless)' : ` (quality ${media.webpQuality})`}
            {media.stripMetadata ? ' → strip metadata' : ''} → store in a media folder.
          </div>
          <p className="description" style={{ marginTop: 12 }}>
            Folders are created and deleted on the <Link to={href('media')}>Media</Link> page.
          </p>
        </div>
      </section>

      <p className="submit" style={{ margin: 0 }}>
        <button
          type="button"
          className="button button-primary"
          disabled={busy}
          onClick={() => onSave(media)}
        >
          {busy ? 'Saving…' : 'Save media settings'}
        </button>
      </p>
    </div>
  );
}
