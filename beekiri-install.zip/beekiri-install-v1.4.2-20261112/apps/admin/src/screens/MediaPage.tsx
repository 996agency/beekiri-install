import {
  ChangeEvent,
  DragEvent,
  FormEvent,
  Fragment,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useSearchParams } from 'react-router-dom';
import { CaretRight, FolderPlus, FolderSimpleDashed, House, ListBullets, MagnifyingGlass, Sparkle, SquaresFour, UploadSimple } from '@phosphor-icons/react';
import { api, apiUpload, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { AdminDataTable, type AdminTableColumn } from '../components/AdminDataTable';
import { confirmDialog } from '../components/ConfirmDialog';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import { SITE_URL as PUBLIC_SITE } from '../config';
import { ErrorNotice } from '../components/ErrorNotice';
import { safeHref } from '../lib/safe-html';
import { notifyBeeQueenCredits } from '../lib/admin-events';
import { CONNECTOR_COMING_SOON } from '../lib/features';
import { createMediaFolder, type MediaFolder, type MediaSettings } from './MediaSettingsPanel';
import { FolderChip, FolderGlyph, FolderTile, MEDIA_DRAG, NewFolderTile, folderAndInside, indexFolders, mediaThumb } from './MediaFolders';
import './media-page.css';

type MediaItem = {
  id: string;
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  width: number | null;
  height: number | null;
  url: string;
  folderId: string | null;
  alt: string;
  createdAt: string;
  updatedAt?: string;
};

type View = 'grid' | 'list';
type Sort = 'newest' | 'oldest' | 'name' | 'size';

const VIEW_KEY = 'bk-media-view';
/** Thumbnails drawn at first in the grid; "Show more" adds as many again. */
const GRID_PAGE = 48;

const SORTS: { value: Sort; label: string }[] = [
  { value: 'newest', label: 'Newest first' },
  { value: 'oldest', label: 'Oldest first' },
  { value: 'name', label: 'Name A–Z' },
  { value: 'size', label: 'Largest first' },
];

function savedView(): View {
  try {
    return localStorage.getItem(VIEW_KEY) === 'list' ? 'list' : 'grid';
  } catch {
    return 'grid';
  }
}

/** Photos Beekiri can describe (the API refuses icons and SVG drawings). */
const DESCRIBABLE = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif']);

/** Empty, the file name, or a word or two: worth asking Beekiri for a better one. */
function altNeedsWork(alt: string, item: MediaItem): boolean {
  const words = (s: string) => s.toLowerCase().replace(/\.[a-z0-9]+$/, '').replace(/[-_]+/g, ' ').trim();
  const text = words(alt);
  if (!text || text === words(item.originalName)) return true;
  return text.split(/\s+/).length < 3;
}

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function absoluteUrl(path: string) {
  if (/^https?:\/\//i.test(path)) return path;
  const base = PUBLIC_SITE.replace(/\/$/, '');
  return `${base}${path.startsWith('/') ? path : `/${path}`}`;
}

/** "1200 × 800 · 84.0 KB" */
function fileFacts(item: MediaItem) {
  return item.width && item.height ? `${item.width} × ${item.height} · ${formatBytes(item.size)}` : formatBytes(item.size);
}

/** Logos, icons and drawings are shown whole; photos fill their tile. */
function showsWhole(item: MediaItem) {
  return /svg|icon|gif/i.test(item.mimeType) || Boolean(item.width && item.width <= 256);
}

/** A picture of the file: a small copy of a photo, or the file type for anything else. */
function Thumb({ item }: { item: MediaItem }) {
  if (!item.mimeType.startsWith('image/')) {
    return <span className="bk-media-ext">{(item.filename.split('.').pop() || 'file').slice(0, 4)}</span>;
  }
  return (
    <img
      className={showsWhole(item) ? 'is-whole' : undefined}
      src={mediaThumb(item.url)}
      alt=""
      loading="lazy"
      decoding="async"
      draggable={false}
      onError={(e) => {
        // No small copy (an odd file name, a broken photo): fall back to the file itself, once.
        const img = e.currentTarget;
        if (img.dataset.full) return;
        img.dataset.full = '1';
        img.src = item.url;
      }}
    />
  );
}

export function MediaPage() {
  const auth = useAuth();
  const canUpload = auth.user?.capabilities.includes('upload_files') ?? false;
  const mayUseBeekiri =
    !CONNECTOR_COMING_SOON && Boolean(auth.user?.isOwner || auth.user?.capabilities.includes('use_beequeen'));
  /** Folders are part of Settings → Media: making one here needs that access too. */
  const canManageFolders =
    canUpload && Boolean(auth.user?.capabilities.some((c) => c === 'manage_options' || c === 'manage_settings_media'));
  const fileRef = useRef<HTMLInputElement>(null);
  const [params, setParams] = useSearchParams();

  const [items, setItems] = useState<MediaItem[]>([]);
  const [folders, setFolders] = useState<MediaFolder[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [view, setView] = useState<View>(savedView);
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState<Sort>('newest');
  /** How many thumbnails the grid draws. */
  const [shown, setShown] = useState(GRID_PAGE);
  /** A folder is being named (the tile with the text field). */
  const [creating, setCreating] = useState(false);
  const [folderBusy, setFolderBusy] = useState(false);
  /** Files from the computer are being dragged over the page. */
  const [dragging, setDragging] = useState(false);
  const dragDepth = useRef(0);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [bulkFolderId, setBulkFolderId] = useState('');
  const [active, setActive] = useState<MediaItem | null>(null);
  /** The open item now — a suggestion that arrives after closing or switching is dropped. */
  const activeIdRef = useRef<string | null>(null);
  activeIdRef.current = active?.id ?? null;
  const [editAlt, setEditAlt] = useState('');
  const [editFolderId, setEditFolderId] = useState('');
  const [copied, setCopied] = useState(false);
  /** Beekiri (Connector) can run: the ✦ alt text button shows. */
  const [beekiriReady, setBeekiriReady] = useState(false);
  const [altBusy, setAltBusy] = useState(false);
  const [altNote, setAltNote] = useState<{ kind: 'done' | 'error'; text: string } | null>(null);

  useEffect(() => {
    if (!mayUseBeekiri || !canUpload) return;
    api<{ available: boolean }>('/api/connector/beequeen/status')
      .then((s) => setBeekiriReady(Boolean(s.available)))
      .catch(() => setBeekiriReady(false));
  }, [mayUseBeekiri, canUpload]);

  const load = useCallback(async () => {
    setError(null);
    const listRes = await api<{ items: MediaItem[]; folders?: MediaFolder[] }>('/api/media');
    setItems(listRes.items);
    setFolders(listRes.folders ?? []);
  }, []);

  useEffect(() => {
    setLoading(true);
    load()
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [load]);

  useEffect(() => {
    if (!active) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setActive(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [active]);

  const openItem = (item: MediaItem) => {
    setActive(item);
    setEditAlt(item.alt ?? '');
    setEditFolderId(item.folderId ?? '');
    setAltNote(null);
    setCopied(false);
    setError(null);
  };

  /** Uploads go into the folder that is open, or the one they were dropped on. */
  const uploadFiles = async (files: FileList | File[], into: string | null = current?.id ?? null) => {
    if (!canUpload) return;
    const list = Array.from(files);
    if (!list.length) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      let lastUrl = '';
      for (const file of list) {
        const form = new FormData();
        form.append('file', file);
        if (into) form.append('folderId', into);
        const res = await apiUpload<{ item: MediaItem }>('/api/media/upload', form);
        lastUrl = res.item.url;
      }
      await load();
      const where = into ? ` to ${folders.find((f) => f.id === into)?.name ?? 'the folder'}` : '';
      setNotice(
        list.length === 1
          ? `Uploaded${where} — available at ${lastUrl}`
          : `Uploaded ${list.length} files${where}.`,
      );
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const onPick = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.length) void uploadFiles(e.target.files);
  };

  /* ── Files dragged in from the computer: the whole browser area takes them ── */
  const carriesFiles = (e: DragEvent) => e.dataTransfer.types.includes('Files');
  const dropHandlers = canUpload
    ? {
        onDragEnter: (e: DragEvent) => {
          if (!carriesFiles(e)) return;
          e.preventDefault();
          dragDepth.current += 1;
          setDragging(true);
        },
        onDragOver: (e: DragEvent) => {
          if (carriesFiles(e)) e.preventDefault();
        },
        onDragLeave: (e: DragEvent) => {
          if (!carriesFiles(e)) return;
          dragDepth.current = Math.max(0, dragDepth.current - 1);
          if (dragDepth.current === 0) setDragging(false);
        },
        onDrop: (e: DragEvent) => {
          dragDepth.current = 0;
          setDragging(false);
          if (!e.dataTransfer.files?.length) return;
          e.preventDefault();
          void uploadFiles(e.dataTransfer.files);
        },
      }
    : {};

  const remove = async (item: MediaItem) => {
    if (!canUpload) return;
    const ok = await confirmDialog({
      title: 'Delete file',
      message: `Delete “${item.originalName}”? This cannot be undone.`,
      confirmLabel: 'Delete',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    setError(null);
    try {
      await api(`/api/media/${item.id}`, { method: 'DELETE' });
      setSelected((prev) => {
        const next = new Set(prev);
        next.delete(item.id);
        return next;
      });
      if (active?.id === item.id) setActive(null);
      await load();
      setNotice('File deleted.');
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const saveActive = async (e: FormEvent) => {
    e.preventDefault();
    if (!active || !canUpload) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ item: MediaItem }>(`/api/media/${active.id}`, {
        method: 'PATCH',
        json: { alt: editAlt.trim() },
      });
      setItems((prev) => prev.map((row) => (row.id === res.item.id ? res.item : row)));
      setActive(res.item);
      setEditFolderId(res.item.folderId ?? '');
      setNotice('Media details saved.');
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  /** Beekiri looks at the photo and fills in alt text; Save details keeps it. */
  const suggestAlt = async () => {
    if (!active || altBusy) return;
    const id = active.id;
    setAltBusy(true);
    setAltNote(null);
    try {
      const res = await api<{ alt: string; cost: number | null; balance: number | null }>(`/api/media/${id}/suggest-alt`, {
        method: 'POST',
      });
      if (activeIdRef.current !== id) return;
      setEditAlt(res.alt);
      setAltNote({ kind: 'done', text: 'Suggested by Beekiri. Check it, then click Save details.' });
      if (res.cost != null) {
        notifyBeeQueenCredits({ running: false, runCost: res.cost, balance: res.balance ?? undefined });
      }
    } catch (err) {
      if (activeIdRef.current === id) setAltNote({ kind: 'error', text: formatError(err) });
    } finally {
      setAltBusy(false);
    }
  };

  const moveActive = async () => {
    if (!active || !canUpload) return;
    const current = active.folderId ?? '';
    if (editFolderId === current) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ item: MediaItem }>(`/api/media/${active.id}`, {
        method: 'PATCH',
        json: { folderId: editFolderId || null },
      });
      setItems((prev) => prev.map((row) => (row.id === res.item.id ? res.item : row)));
      setActive(res.item);
      setEditFolderId(res.item.folderId ?? '');
      const dest =
        folders.find((f) => f.id === (res.item.folderId ?? ''))?.name ?? 'No folder';
      setNotice(`Moved to ${dest}.`);
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const copyUrl = async (path: string) => {
    const url = absoluteUrl(path);
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      window.prompt('Copy URL:', url);
    }
  };

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const clearSelection = () => setSelected(new Set());

  const bulkMove = async () => {
    if (!canUpload || selected.size === 0) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ updated: number }>('/api/media/bulk-move', {
        method: 'POST',
        json: {
          ids: [...selected],
          folderId: bulkFolderId || null,
        },
      });
      await load();
      clearSelection();
      setNotice(
        `Moved ${res.updated} file${res.updated === 1 ? '' : 's'} to ${
          bulkFolderId
            ? folders.find((f) => f.id === bulkFolderId)?.name ?? 'folder'
            : 'No folder'
        }.`,
      );
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const bulkDelete = async () => {
    if (!canUpload || selected.size === 0) return;
    const count = selected.size;
    const ok = await confirmDialog({
      title: 'Delete files',
      message: `Delete ${count} selected file${count === 1 ? '' : 's'}? This cannot be undone.`,
      confirmLabel: 'Delete',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ deleted: number }>('/api/media/bulk-delete', {
        method: 'POST',
        json: { ids: [...selected] },
      });
      if (active && selected.has(active.id)) setActive(null);
      clearSelection();
      await load();
      setNotice(`Deleted ${res.deleted} file${res.deleted === 1 ? '' : 's'}.`);
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  /* ── Folders: where we are, and what is in it ───────────────────────────── */

  const tree = useMemo(() => indexFolders(folders, items), [folders, items]);
  const current = useMemo(() => folders.find((f) => f.id === params.get('folder')) ?? null, [folders, params]);
  const path = useMemo(() => tree.pathOf(current?.id ?? null), [tree, current]);
  /** "Brand / Logos" — for the move menus and search results. */
  const folderLabel = useCallback((id: string | null) => tree.pathOf(id).map((f) => f.name).join(' / '), [tree]);
  /** Every folder with its full path, parents before the folders inside them. */
  const folderOptions = useMemo(() => {
    const out: { id: string; label: string }[] = [];
    const walk = (parent: string | null) => {
      for (const f of tree.children.get(parent) ?? []) {
        out.push({ id: f.id, label: folderLabel(f.id) });
        walk(f.id);
      }
    };
    walk(null);
    return out;
  }, [tree, folderLabel]);

  const q = query.trim().toLowerCase();
  const searching = q !== '';

  /** Files on screen: the open folder's, or matches from every folder while searching. */
  const visibleFiles = useMemo(() => {
    const known = new Set(folders.map((f) => f.id));
    const here = current?.id ?? null;
    const list = items.filter((row) => {
      if (searching) {
        return (
          row.originalName.toLowerCase().includes(q) ||
          row.filename.toLowerCase().includes(q) ||
          row.url.toLowerCase().includes(q) ||
          (row.alt ?? '').toLowerCase().includes(q)
        );
      }
      // A file whose folder was deleted shows at the top level.
      return (row.folderId && known.has(row.folderId) ? row.folderId : null) === here;
    });
    const byDate = (a: MediaItem, b: MediaItem) => b.createdAt.localeCompare(a.createdAt);
    if (sort === 'oldest') list.sort((a, b) => byDate(b, a));
    else if (sort === 'name') list.sort((a, b) => a.originalName.localeCompare(b.originalName, undefined, { numeric: true }));
    else if (sort === 'size') list.sort((a, b) => b.size - a.size);
    else list.sort(byDate);
    return list;
  }, [items, folders, current, searching, q, sort]);

  const visibleFolders = useMemo(
    () => (searching ? folders.filter((f) => f.name.toLowerCase().includes(q)) : (tree.children.get(current?.id ?? null) ?? [])),
    [searching, folders, q, tree, current],
  );

  const visibleIds = useMemo(() => visibleFiles.map((r) => r.id), [visibleFiles]);
  const allVisibleSelected = visibleIds.length > 0 && visibleIds.every((id) => selected.has(id));

  const toggleSelectAllVisible = () => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (allVisibleSelected) {
        for (const id of visibleIds) next.delete(id);
      } else {
        for (const id of visibleIds) next.add(id);
      }
      return next;
    });
  };

  // A new folder, search or order starts the grid from its first screenful again.
  useEffect(() => {
    setShown(GRID_PAGE);
  }, [current?.id, q, sort]);

  const openFolder = (id: string | null) => {
    setParams(id ? { folder: id } : {});
    setQuery('');
    setCreating(false);
    clearSelection();
  };

  const chooseView = (next: View) => {
    setView(next);
    try {
      localStorage.setItem(VIEW_KEY, next);
    } catch {
      /* private window: the choice lasts for this visit */
    }
  };

  /** Files dragged onto a folder (or a step of the path) move there. */
  const moveItems = async (ids: string[], target: string | null) => {
    const moving = ids.filter((id) => (items.find((i) => i.id === id)?.folderId ?? null) !== target);
    if (!canUpload || moving.length === 0) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ updated: number }>('/api/media/bulk-move', { method: 'POST', json: { ids: moving, folderId: target } });
      await load();
      setSelected((prev) => new Set([...prev].filter((id) => !moving.includes(id))));
      setNotice(`Moved ${res.updated} file${res.updated === 1 ? '' : 's'} to ${target ? folderLabel(target) : 'Media (no folder)'}.`);
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  /**
   * Folders are stored with the media settings: read them fresh, change the list, and save the
   * whole settings object back (a partial save would reset the WebP and size options).
   */
  const saveFolders = async (change: (list: MediaFolder[]) => MediaFolder[]) => {
    const settings = await api<{ media: MediaSettings }>('/api/site/settings');
    const existing = (settings.media.folders ?? []).map((f) => ({ ...f, parentId: f.parentId ?? null }));
    await api('/api/site/settings', { method: 'PATCH', json: { media: { ...settings.media, folders: change(existing) } } });
  };

  /** A new folder inside the open one. */
  const createFolder = async (name: string) => {
    setFolderBusy(true);
    setError(null);
    try {
      await saveFolders((list) => [...list, createMediaFolder(name, current?.id ?? null, list)]);
      await load();
      setNotice(`Folder “${name}” created.`);
    } catch (e) {
      setError(formatError(e));
    } finally {
      setFolderBusy(false);
      setCreating(false);
    }
  };

  /** Deletes the folder and the folders inside it; their files move up to its parent, never away. */
  const deleteFolder = async (folder: MediaFolder) => {
    const gone = folderAndInside(folders, folder.id);
    const files = items.filter((i) => i.folderId && gone.has(i.folderId)).map((i) => i.id);
    const parent = folder.parentId && !gone.has(folder.parentId) ? folder.parentId : null;
    const dest = parent ? `“${folderLabel(parent)}”` : 'Media (no folder)';
    const inside = gone.size - 1;
    const ok = await confirmDialog({
      title: 'Delete folder',
      message:
        `Delete the folder “${folder.name}”${inside ? ` and the ${inside} folder${inside === 1 ? '' : 's'} inside it` : ''}? ` +
        (files.length ? `Its ${files.length} file${files.length === 1 ? '' : 's'} move to ${dest}; no files are deleted.` : 'It is empty.'),
      confirmLabel: 'Delete folder',
      danger: true,
    });
    if (!ok) return;
    setFolderBusy(true);
    setError(null);
    try {
      for (let at = 0; at < files.length; at += 500) {
        await api('/api/media/bulk-move', { method: 'POST', json: { ids: files.slice(at, at + 500), folderId: parent } });
      }
      await saveFolders((list) => list.filter((f) => !gone.has(f.id)));
      if (current && gone.has(current.id)) openFolder(parent);
      await load();
      setNotice(`Folder “${folder.name}” deleted${files.length ? `; ${files.length} file${files.length === 1 ? '' : 's'} moved to ${dest}` : ''}.`);
    } catch (e) {
      setError(formatError(e));
      await load().catch(() => {});
    } finally {
      setFolderBusy(false);
    }
  };

  const startDrag = (e: DragEvent, item: MediaItem) => {
    // Dragging one of the ticked files takes all of them along.
    const ids = selected.has(item.id) ? [...selected] : [item.id];
    e.dataTransfer.setData(MEDIA_DRAG, JSON.stringify(ids));
    e.dataTransfer.effectAllowed = 'move';
  };

  /** A step of the path takes dropped files, like a folder does. */
  const pathDrop = (target: string | null) =>
    canUpload
      ? {
          onDragOver: (e: DragEvent) => {
            if (!e.dataTransfer.types.includes(MEDIA_DRAG)) return;
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
          },
          onDrop: (e: DragEvent) => {
            const ids = e.dataTransfer.getData(MEDIA_DRAG);
            if (!ids) return;
            e.preventDefault();
            void moveItems(JSON.parse(ids) as string[], target);
          },
        }
      : {};

  const selectBox = (item: MediaItem, className: string) => (
    <label className={`bk-check ${className}`} onClick={(e) => e.stopPropagation()}>
      <input type="checkbox" checked={selected.has(item.id)} onChange={() => toggleSelect(item.id)} aria-label={`Select ${item.originalName}`} />
      <span className="bk-check__box" aria-hidden />
    </label>
  );

  /* ── List view: the files of the open folder (its folders sit above, as chips) ── */

  const columns: AdminTableColumn<MediaItem>[] = useMemo(
    () => [
      {
        key: 'select',
        header: '',
        className: 'bk-media-col-select',
        render: (row) => (canUpload ? selectBox(row, 'bk-media-check') : null),
      },
      {
        key: 'preview',
        header: '',
        className: 'bk-media-col-preview',
        render: (row) => (
          <button type="button" className="bk-media-thumb-btn" onClick={() => openItem(row)} aria-label={`Open ${row.originalName}`}>
            <span className="bk-media-rowthumb">
              <Thumb item={row} />
            </span>
          </button>
        ),
      },
      {
        key: 'name',
        header: 'Name',
        render: (row) => (
          <button type="button" className="bk-media-file-btn" onClick={() => openItem(row)}>
            <span className="bk-media-file">
              <strong>{row.originalName}</strong>
              <span className="bk-muted">{row.url}</span>
              {row.alt ? <span className="bk-muted">Alt: {row.alt}</span> : null}
            </span>
          </button>
        ),
      },
      // While searching, files come from everywhere: say where each one is.
      ...(searching
        ? [
            {
              key: 'folder',
              header: 'Folder',
              className: 'bk-media-col-folder',
              render: (row: MediaItem) => folderLabel(row.folderId) || '—',
            },
          ]
        : []),
      {
        key: 'size',
        header: 'Size',
        className: 'bk-media-col-size',
        render: (row) => (
          <span>
            {formatBytes(row.size)}
            {row.width && row.height ? (
              <span className="bk-muted">
                {' '}
                · {row.width}×{row.height}
              </span>
            ) : null}
          </span>
        ),
      },
      {
        key: 'date',
        header: 'Uploaded',
        className: 'bk-media-col-size',
        render: (row) => new Date(row.createdAt).toLocaleDateString(),
      },
      {
        key: 'actions',
        header: '',
        render: (row) => (
          <div className="bk-table__row-actions" onClick={(e) => e.stopPropagation()}>
            <button type="button" className="button-link" onClick={() => openItem(row)}>
              Edit
            </button>
            {canUpload ? (
              <>
                <span className="bk-table__sep">|</span>
                <button type="button" className="button-link is-danger" disabled={busy} onClick={() => void remove(row)}>
                  Delete
                </button>
              </>
            ) : null}
          </div>
        ),
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps -- the handlers read current state when called
    [busy, canUpload, selected, searching, folderLabel],
  );

  /** What every folder (tile or chip) can do. */
  const folderProps = (f: MediaFolder) => ({
    folder: f,
    info: tree.info.get(f.id),
    onOpen: () => openFolder(f.id),
    onDropItems: canUpload ? (ids: string[]) => void moveItems(ids, f.id) : undefined,
    onDropFiles: canUpload ? (files: FileList) => void uploadFiles(files, f.id) : undefined,
    onDelete: canManageFolders && !folderBusy ? () => void deleteFolder(f) : undefined,
  });

  const inFolder = current ? `“${current.name}”` : null;
  const nothingHere = !loading && visibleFolders.length === 0 && visibleFiles.length === 0 && !creating;
  const folderSelect = (value: string, onChange: (id: string) => void, label: string, id?: string) => (
    <select id={id} value={value} onChange={(e) => onChange(e.target.value)} disabled={busy || !canUpload} aria-label={label}>
      <option value="">No folder</option>
      {folderOptions.map((f) => (
        <option key={f.id} value={f.id}>
          {f.label}
        </option>
      ))}
    </select>
  );

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Media"
        actions={
          canUpload ? (
            <>
              {canManageFolders ? (
                <button type="button" className="button bk-media-iconbtn" disabled={busy || folderBusy || creating || searching} onClick={() => setCreating(true)}>
                  <FolderPlus size={16} aria-hidden />
                  New folder
                </button>
              ) : null}
              <button type="button" className="button button-primary bk-media-iconbtn" disabled={busy} onClick={() => fileRef.current?.click()}>
                <UploadSimple size={16} aria-hidden />
                {busy ? 'Working…' : 'Upload'}
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="image/jpeg,image/png,image/webp,image/gif,image/svg+xml,image/x-icon,.ico"
                multiple
                hidden
                onChange={onPick}
              />
            </>
          ) : null
        }
      />
      <p className="bk-muted">
        Images and files for your site. Click a file to edit its details.{' '}
        {items.length} file{items.length === 1 ? '' : 's'}
        {folders.length ? ` in ${folders.length} folder${folders.length === 1 ? '' : 's'}` : ''}.
      </p>

      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}
      {!canUpload ? <p className="bk-muted">You need the upload_files capability to manage media.</p> : null}

      <div className="bk-media-toolbar">
        <label className="bk-media-search">
          <MagnifyingGlass size={15} aria-hidden />
          <input type="search" value={query} placeholder="Search all files and folders…" aria-label="Search media" onChange={(e) => setQuery(e.target.value)} />
        </label>
        <div className="bk-media-toolbar__right">
          <select className="bk-media-sort" value={sort} onChange={(e) => setSort(e.target.value as Sort)} aria-label="Order of files">
            {SORTS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
          <div className="bk-tabs is-inline" role="tablist" aria-label="View">
            <button type="button" role="tab" aria-selected={view === 'grid'} className={`bk-tabs__item bk-media-viewtab${view === 'grid' ? ' is-active' : ''}`} onClick={() => chooseView('grid')}>
              <SquaresFour size={15} aria-hidden />
              Grid
            </button>
            <button type="button" role="tab" aria-selected={view === 'list'} className={`bk-tabs__item bk-media-viewtab${view === 'list' ? ' is-active' : ''}`} onClick={() => chooseView('list')}>
              <ListBullets size={15} aria-hidden />
              List
            </button>
          </div>
        </div>
      </div>

      {searching ? (
        <p className="bk-media-path is-note">
          {visibleFiles.length} file{visibleFiles.length === 1 ? '' : 's'}
          {visibleFolders.length ? ` and ${visibleFolders.length} folder${visibleFolders.length === 1 ? '' : 's'}` : ''} match “{query.trim()}” in all folders.{' '}
          <button type="button" className="button-link" onClick={() => setQuery('')}>
            Clear search
          </button>
        </p>
      ) : current ? (
        <nav className="bk-media-path" aria-label="Folder path">
          <button type="button" className="bk-media-path__item" onClick={() => openFolder(null)} {...pathDrop(null)}>
            <House size={15} aria-hidden />
            Media
          </button>
          {path.map((f, i) => (
            <Fragment key={f.id}>
              <CaretRight size={11} weight="bold" aria-hidden />
              {i === path.length - 1 ? (
                <span className="bk-media-path__item is-current" aria-current="page">
                  <FolderGlyph size={17} />
                  {f.name}
                </span>
              ) : (
                <button type="button" className="bk-media-path__item" onClick={() => openFolder(f.id)} {...pathDrop(f.id)}>
                  <FolderGlyph size={17} />
                  {f.name}
                </button>
              )}
            </Fragment>
          ))}
        </nav>
      ) : null}

      {selected.size > 0 ? (
        <div className="bk-media-bulk" role="region" aria-label="Bulk actions">
          <label className="bk-check">
            <input type="checkbox" checked={allVisibleSelected} onChange={toggleSelectAllVisible} />
            <span className="bk-check__box" aria-hidden />
            <span className="bk-check__label">
              {selected.size} selected
              {visibleIds.length ? ` · ${visibleIds.length} shown here` : ''}
            </span>
          </label>
          <div className="bk-media-bulk__actions">
            <label className="bk-media-folder-select">{folderSelect(bulkFolderId, setBulkFolderId, 'Move to folder')}</label>
            <button type="button" className="button" disabled={busy || !canUpload} onClick={() => void bulkMove()}>
              Move to folder
            </button>
            <button type="button" className="button" disabled={busy || !canUpload} onClick={() => void bulkDelete()}>
              Delete selected
            </button>
            <button type="button" className="button-link" onClick={clearSelection}>
              Clear
            </button>
          </div>
        </div>
      ) : null}

      <div className={`bk-media-browser${dragging ? ' is-dragging' : ''}`} {...dropHandlers}>
        {visibleFolders.length > 0 || creating ? (
          <section className="bk-media-section" aria-label="Folders">
            <div className="bk-media-section__head">
              <h2 className="bk-media-section__title">
                Folders <span>{visibleFolders.length}</span>
              </h2>
            </div>
            {view === 'grid' || creating ? (
              <div className="bk-media-grid">
                {creating ? <NewFolderTile busy={folderBusy} onCreate={(name) => void createFolder(name)} onCancel={() => setCreating(false)} /> : null}
                {view === 'grid' ? visibleFolders.map((f) => <FolderTile key={f.id} {...folderProps(f)} />) : null}
              </div>
            ) : null}
            {view === 'list' ? (
              <div className="bk-media-chips">
                {visibleFolders.map((f) => (
                  <FolderChip key={f.id} {...folderProps(f)} />
                ))}
              </div>
            ) : null}
          </section>
        ) : null}

        {view === 'grid' ? (
          visibleFiles.length > 0 ? (
            <section className="bk-media-section" aria-label="Files">
              <div className="bk-media-section__head">
                <h2 className="bk-media-section__title">
                  Files <span>{visibleFiles.length}</span>
                </h2>
                {canUpload ? (
                  <label className="bk-check bk-media-section__all">
                    <input type="checkbox" checked={allVisibleSelected} onChange={toggleSelectAllVisible} />
                    <span className="bk-check__box" aria-hidden />
                    <span className="bk-check__label">Select all</span>
                  </label>
                ) : null}
              </div>
              <div className={`bk-media-grid${selected.size > 0 ? ' has-selection' : ''}`}>
                {visibleFiles.slice(0, shown).map((item) => (
                  <div
                    key={item.id}
                    className={`bk-media-card${selected.has(item.id) ? ' is-selected' : ''}`}
                    draggable={canUpload}
                    onDragStart={(e) => startDrag(e, item)}
                  >
                    <button type="button" className="bk-media-card__thumb" onClick={() => openItem(item)} aria-label={`Open ${item.originalName}`}>
                      <Thumb item={item} />
                    </button>
                    {canUpload ? selectBox(item, 'bk-media-card__check') : null}
                    <button type="button" className="bk-media-card__text" onClick={() => openItem(item)} tabIndex={-1}>
                      <span className="bk-media-card__name" title={item.originalName}>
                        {item.originalName}
                      </span>
                      <span className="bk-media-card__meta">{searching && item.folderId ? `in ${folderLabel(item.folderId)}` : fileFacts(item)}</span>
                    </button>
                  </div>
                ))}
              </div>
              {visibleFiles.length > shown ? (
                <div className="bk-media-more">
                  <span className="bk-muted">
                    Showing {shown} of {visibleFiles.length}
                  </span>
                  <button type="button" className="button" onClick={() => setShown((n) => n + GRID_PAGE)}>
                    Show more
                  </button>
                </div>
              ) : null}
            </section>
          ) : null
        ) : visibleFiles.length > 0 || loading ? (
          <AdminDataTable
            rows={visibleFiles}
            columns={columns}
            getRowId={(r) => r.id}
            onRowClick={(row) => openItem(row)}
            defaultPageSize={25}
            loading={loading}
          />
        ) : null}

        {view === 'grid' && loading ? <p className="bk-muted">Loading media…</p> : null}

        {nothingHere ? (
          <div className="bk-media-empty">
            <FolderSimpleDashed size={34} weight="light" aria-hidden />
            <p className="bk-media-empty__title">
              {searching ? `Nothing matches “${query.trim()}”.` : current ? 'This folder is empty.' : 'No media yet.'}
            </p>
          </div>
        ) : null}

        {canUpload && !searching ? (
          <p className="bk-media-hint">
            Drop images anywhere here to upload them{inFolder ? ` to ${inFolder}` : ''}
            {view === 'grid' && visibleFolders.length ? ', or drag a file onto a folder to move it' : ''}. JPEG, PNG, WebP, GIF, SVG or ICO, up to
            20&nbsp;MB; files follow your Media settings (WebP / size limits).
          </p>
        ) : null}

        {dragging ? (
          <div className="bk-media-dropveil" aria-hidden>
            <UploadSimple size={26} />
            <strong>Drop to upload{inFolder ? ` to ${inFolder}` : ''}</strong>
          </div>
        ) : null}
      </div>

      {active ? (
        <div
          className="bk-media-modal"
          role="dialog"
          aria-modal="true"
          aria-labelledby="bk-media-modal-title"
          onClick={(e) => {
            if (e.target === e.currentTarget) setActive(null);
          }}
        >
          <div className="bk-media-modal__panel">
            <div className="bk-media-modal__head">
              <h2 id="bk-media-modal-title" className="bk-media-modal__title">
                {active.originalName}
              </h2>
              <button
                type="button"
                className="button"
                onClick={() => setActive(null)}
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            <div className="bk-media-modal__body">
              <div className="bk-media-modal__preview">
                <img src={active.url} alt={editAlt || active.originalName} />
              </div>

              <form className="bk-media-modal__details" onSubmit={saveActive}>
                <div className="bk-field">
                  <div className="bk-media-alt__head">
                    <label htmlFor="media_alt">Alt text</label>
                    {beekiriReady && DESCRIBABLE.has(active.mimeType) ? (
                      <button
                        type="button"
                        className={`button bk-media-alt__ai${altNeedsWork(editAlt, active) ? ' is-attention' : ''}${
                          altBusy ? ' is-busy' : ''
                        }`}
                        disabled={busy || altBusy}
                        onClick={() => void suggestAlt()}
                        aria-label="Suggest alt text with Beekiri"
                        title={
                          altNeedsWork(editAlt, active)
                            ? 'This alt text is missing or too short. Beekiri can look at the photo and suggest one.'
                            : 'Ask Beekiri to look at the photo and suggest better alt text'
                        }
                      >
                        <Sparkle size={15} weight={altNeedsWork(editAlt, active) ? 'fill' : 'regular'} aria-hidden />
                      </button>
                    ) : null}
                  </div>
                  <input
                    id="media_alt"
                    type="text"
                    maxLength={500}
                    value={editAlt}
                    disabled={!canUpload || busy || altBusy}
                    placeholder={altBusy ? 'Beekiri is looking at the photo…' : 'Describe the image for accessibility'}
                    onChange={(e) => {
                      setEditAlt(e.target.value);
                      if (altNote?.kind === 'error') setAltNote(null);
                    }}
                  />
                  {altNote ? (
                    <p className={`description bk-media-alt__note${altNote.kind === 'error' ? ' is-error' : ''}`} role="status">
                      {altNote.text}
                    </p>
                  ) : null}
                </div>

                <div className="bk-field">
                  <label htmlFor="media_folder">Folder</label>
                  <div className="bk-media-url-row">
                    <select
                      id="media_folder"
                      value={editFolderId}
                      disabled={!canUpload || busy}
                      onChange={(e) => setEditFolderId(e.target.value)}
                    >
                      <option value="">No folder</option>
                      {folderOptions.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.label}
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      className="button"
                      disabled={
                        !canUpload ||
                        busy ||
                        editFolderId === (active.folderId ?? '')
                      }
                      onClick={() => void moveActive()}
                    >
                      Move
                    </button>
                  </div>
                  <p className="description" style={{ marginTop: 6 }}>
                    Choose a folder, then click Move. Selecting alone does not move the file.
                  </p>
                </div>

                <div className="bk-field">
                  <label htmlFor="media_url">URL</label>
                  <div className="bk-media-url-row">
                    <input
                      id="media_url"
                      type="text"
                      readOnly
                      value={absoluteUrl(active.url)}
                    />
                    <button
                      type="button"
                      className="button"
                      onClick={() => void copyUrl(active.url)}
                    >
                      {copied ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                </div>

                <dl className="bk-media-meta">
                  <div>
                    <dt>Type</dt>
                    <dd>{active.mimeType}</dd>
                  </div>
                  <div>
                    <dt>Size</dt>
                    <dd>{formatBytes(active.size)}</dd>
                  </div>
                  <div>
                    <dt>Dimensions</dt>
                    <dd>
                      {active.width && active.height
                        ? `${active.width} × ${active.height}`
                        : '—'}
                    </dd>
                  </div>
                  <div>
                    <dt>Filename</dt>
                    <dd>{active.filename}</dd>
                  </div>
                  <div>
                    <dt>Uploaded</dt>
                    <dd>{new Date(active.createdAt).toLocaleString()}</dd>
                  </div>
                </dl>

                <div className="bk-media-modal__actions">
                  {canUpload ? (
                    <button type="submit" className="button button-primary" disabled={busy}>
                      {busy ? 'Saving…' : 'Save details'}
                    </button>
                  ) : null}
                  <a
                    className="button"
                    href={safeHref(active.url)}
                    target="_blank"
                    rel="noreferrer"
                  >
                    Open file
                  </a>
                  {canUpload ? (
                    <button
                      type="button"
                      className="button"
                      disabled={busy}
                      onClick={() => void remove(active)}
                    >
                      Delete
                    </button>
                  ) : null}
                </div>
              </form>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
