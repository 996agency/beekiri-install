import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../../api/client';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { useAdminHref } from '../../lib/AdminEntryContext';
import { formatDate, formatMoney, useShopMeta, type ReportRange, type ShopMeta, type ShopOverview } from './api';
import { formatError, StatusPill } from './OrdersPage';
import './shop.css';
import './orders.css';

const RANGES: { id: ReportRange; label: string }[] = [
  { id: 'today', label: 'Today' },
  { id: '7d', label: '7 days' },
  { id: '30d', label: '30 days' },
  { id: '90d', label: '90 days' },
  { id: 'year', label: 'Year' },
];

/** Clean tick values: 0 … a round number at or above the max. */
function niceTicks(max: number, count = 4): number[] {
  if (max <= 0) return [0];
  const rough = max / count;
  const pow = 10 ** Math.floor(Math.log10(rough));
  const step = Math.max(1, [1, 2, 2.5, 5, 10].map((m) => m * pow).find((s) => s >= rough) ?? pow * 10);
  const ticks: number[] = [];
  for (let v = 0; v <= max + step - 1; v += step) ticks.push(Math.round(v));
  if (ticks[ticks.length - 1]! < max) ticks.push(ticks[ticks.length - 1]! + step);
  return ticks;
}

function compactMoney(minor: number, meta: ShopMeta | null): string {
  const decimals = meta?.currencies.find((c) => c.code === meta.currency)?.decimals ?? 2;
  const major = minor / 10 ** decimals;
  const sym = meta?.currencies.find((c) => c.code === meta.currency)?.symbol ?? '';
  if (major >= 1_000_000) return `${sym}${(major / 1_000_000).toFixed(1).replace(/\.0$/, '')}M`;
  if (major >= 10_000) return `${sym}${(major / 1_000).toFixed(0)}K`;
  if (major >= 1_000) return `${sym}${(major / 1_000).toFixed(1).replace(/\.0$/, '')}K`;
  return `${sym}${Number.isInteger(major) ? major : major.toFixed(0)}`;
}

function dayLabel(date: string, short = false): string {
  const d = new Date(`${date}T12:00:00`);
  if (Number.isNaN(d.getTime())) return date;
  return short
    ? d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' })
    : d.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
}

/**
 * Revenue per day — single series, so no legend; thin rounded bars on one baseline,
 * recessive hairline grid, per-bar hover tooltip and a table view. Drawn at the width it is
 * shown at (not scaled), so its text stays the admin's size on any screen.
 */
function RevenueChart({ series, meta }: { series: ShopOverview['series']; meta: ShopMeta | null }) {
  const [hover, setHover] = useState<number | null>(null);
  const [table, setTable] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(720);
  useEffect(() => {
    const el = box.current;
    if (!el) return;
    const ro = new ResizeObserver((entries) => {
      const w = Math.round(entries[0]?.contentRect.width ?? 0);
      if (w > 0) setWidth(w);
    });
    ro.observe(el);
    return () => ro.disconnect();
    // The box is not there while the period has no sales.
  }, [series.length === 0]);
  const W = Math.max(280, width);
  const H = 220;
  const PAD = { top: 10, right: 8, bottom: 26, left: 48 };
  const max = Math.max(0, ...series.map((s) => s.revenue));
  const ticks = useMemo(() => niceTicks(max), [max]);
  const top = ticks[ticks.length - 1] || 1;
  const innerW = W - PAD.left - PAD.right;
  const innerH = H - PAD.top - PAD.bottom;
  const n = series.length;
  const band = n ? innerW / n : innerW;
  const barW = Math.min(24, Math.max(2, band - 2));
  const y = (v: number) => PAD.top + innerH - (v / top) * innerH;
  // Label every k-th day so the axis never collides.
  const every = Math.max(n <= 8 ? 1 : n <= 31 ? 5 : n <= 91 ? 14 : 30, Math.ceil(n / Math.max(2, Math.floor(innerW / 64))));

  if (!series.length) return <p className="bk-shop-chart__empty">No sales in this period.</p>;

  const hovered = hover !== null ? series[hover] : null;
  const total = series.reduce((a, s) => a + s.revenue, 0);

  return (
    <div className="bk-shop-chart" ref={box}>
      <div className="bk-shop-chart__head">
        <span className="bk-muted" style={{ fontSize: 12.5 }}>
          Revenue per day · {formatMoney(total, meta)} total
        </span>
        <button type="button" onClick={() => setTable((t) => !t)}>
          {table ? 'Show chart' : 'Show table'}
        </button>
      </div>
      {table ? (
        <table className="bk-shop-chart__table">
          <thead>
            <tr>
              <th scope="col">Day</th>
              <th scope="col" className="is-num">
                Orders
              </th>
              <th scope="col" className="is-num">
                Revenue
              </th>
            </tr>
          </thead>
          <tbody>
            {series.map((s) => (
              <tr key={s.date}>
                <td>{dayLabel(s.date)}</td>
                <td className="is-num">{s.orders}</td>
                <td className="is-num">{formatMoney(s.revenue, meta)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <>
          <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H} role="img" aria-label={`Revenue per day, ${n} days`}>
            {ticks.map((t) => (
              <g key={t}>
                <line className="bk-shop-chart__grid" x1={PAD.left} x2={W - PAD.right} y1={y(t)} y2={y(t)} />
                <text className="bk-shop-chart__axis" x={PAD.left - 6} y={y(t) + 4} textAnchor="end">
                  {compactMoney(t, meta)}
                </text>
              </g>
            ))}
            {series.map((s, i) => {
              const cx = PAD.left + band * i + band / 2;
              const x = cx - barW / 2;
              const h = s.revenue > 0 ? Math.max(2, (s.revenue / top) * innerH) : 0;
              const r = Math.min(4, barW / 2, h);
              // 4px rounded top, square at the baseline.
              const d = h > 0 ? `M${x},${y(0)} v${-(h - r)} a${r},${r} 0 0 1 ${r},${-r} h${barW - 2 * r} a${r},${r} 0 0 1 ${r},${r} v${h - r} z` : '';
              // Every k-th day and the last one, but not a k-th day too close to the last (they would touch).
              const show = i === n - 1 || (i % every === 0 && (n - 1 - i) * band >= 72);
              return (
                <g key={s.date}>
                  <rect
                    className="bk-shop-chart__hit"
                    x={PAD.left + band * i}
                    y={PAD.top}
                    width={band}
                    height={innerH}
                    tabIndex={0}
                    onMouseEnter={() => setHover(i)}
                    onMouseLeave={() => setHover(null)}
                    onFocus={() => setHover(i)}
                    onBlur={() => setHover(null)}
                    aria-label={`${dayLabel(s.date)}: ${formatMoney(s.revenue, meta)}, ${s.orders} orders`}
                  />
                  {h > 0 ? <path className="bk-shop-chart__bar" d={d} /> : <rect className="bk-shop-chart__bar is-empty" x={x} y={y(0) - 1} width={barW} height={1} />}
                  {show ? (
                    <text className="bk-shop-chart__axis" x={cx} y={H - 8} textAnchor={i === n - 1 && n > 1 ? 'end' : i === 0 ? 'start' : 'middle'}>
                      {dayLabel(s.date, true)}
                    </text>
                  ) : null}
                </g>
              );
            })}
            <line className="bk-shop-chart__grid" x1={PAD.left} x2={W - PAD.right} y1={y(0)} y2={y(0)} />
          </svg>
          {hovered && hover !== null ? (
            <div
              className="bk-shop-chart__tip"
              style={{
                left: `${((PAD.left + band * hover + band / 2) / W) * 100}%`,
                top: `${(y(hovered.revenue) / H) * 100}%`,
              }}
            >
              <strong>{dayLabel(hovered.date)}</strong>
              {formatMoney(hovered.revenue, meta)} · {hovered.orders} {hovered.orders === 1 ? 'order' : 'orders'}
            </div>
          ) : null}
        </>
      )}
    </div>
  );
}

export function ShopOverviewPage() {
  const href = useAdminHref();
  const meta = useShopMeta();
  const [range, setRange] = useState<ReportRange>('30d');
  const [data, setData] = useState<ShopOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api<ShopOverview>(`/api/shop/overview?range=${range}`)
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch((e) => {
        if (!cancelled) setError(formatError(e));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [range]);

  const t = data?.totals;
  const rangeLabel = RANGES.find((r) => r.id === range)?.label ?? range;

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title={meta?.shopTitle ? `${meta.shopTitle} — overview` : 'Shop overview'}
        actions={
          <div className="bk-tabs is-inline" role="tablist" aria-label="Period">
            {RANGES.map((r) => (
              <button
                key={r.id}
                type="button"
                role="tab"
                aria-selected={range === r.id}
                className={`bk-tabs__item${range === r.id ? ' is-active' : ''}`}
                onClick={() => setRange(r.id)}
              >
                {r.label}
              </button>
            ))}
          </div>
        }
      />
      <div className="bk-shop-overview__bar">
        <p className="bk-muted" style={{ margin: 0 }}>
          Sales from processing and completed orders · {rangeLabel.toLowerCase()}.
        </p>
        <div className="bk-shop-overview__links">
          <Link className="button button-primary" to={href('shop/products/new')}>
            Add product
          </Link>
          <Link className="button" to={href('shop/orders')}>
            Orders
          </Link>
          <Link className="button" to={href('shop/settings')}>
            Settings
          </Link>
        </div>
      </div>
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}

      <div className="bk-shop-stats" aria-busy={loading}>
        <div className="bk-shop-stat">
          <p className="bk-shop-stat__label">Revenue</p>
          <p className="bk-shop-stat__value">{t?.revenueFormatted ?? '—'}</p>
          <p className="bk-shop-stat__sub">net of refunds</p>
        </div>
        <div className="bk-shop-stat">
          <p className="bk-shop-stat__label">Orders</p>
          <p className="bk-shop-stat__value">{t?.orders ?? '—'}</p>
          <p className="bk-shop-stat__sub">{t ? `${t.itemsSold} items sold` : ' '}</p>
        </div>
        <div className="bk-shop-stat">
          <p className="bk-shop-stat__label">Average order</p>
          <p className="bk-shop-stat__value">{t?.averageOrderFormatted ?? '—'}</p>
          <p className="bk-shop-stat__sub">per order</p>
        </div>
        <div className="bk-shop-stat">
          <p className="bk-shop-stat__label">New customers</p>
          <p className="bk-shop-stat__value">{t?.newCustomers ?? '—'}</p>
          <p className="bk-shop-stat__sub">first order in this period</p>
        </div>
        <div className="bk-shop-stat">
          <p className="bk-shop-stat__label">Stock alerts</p>
          <p className="bk-shop-stat__value">{data ? data.stock.lowStock + data.stock.outOfStock : '—'}</p>
          <p className="bk-shop-stat__sub">
            {data ? (
              <>
                {data.stock.lowStock} low (≤ {data.stock.threshold}) ·{' '}
                <Link to={href('shop/products?stock=outofstock')}>{data.stock.outOfStock} out of stock</Link>
              </>
            ) : (
              ' '
            )}
          </p>
        </div>
      </div>

      <section className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Revenue</h2>
        </div>
        <div className="bk-panel__body">{data ? <RevenueChart series={data.series} meta={meta} /> : <p className="bk-muted">Loading…</p>}</div>
      </section>

      <div className="bk-shop-overview__grid">
        <section className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Recent orders</h2>
          </div>
          <div className="bk-panel__body">
            {data && data.recentOrders.length ? (
              <ul className="bk-shop-list">
                {data.recentOrders.map((o) => (
                  <li key={o.id}>
                    <span className="bk-shop-list__left">
                      <span>
                        <Link to={href(`shop/orders/${o.id}`)}>{o.numberLabel}</Link> {o.customerName}
                      </span>
                      <StatusPill status={o.status} label={o.statusLabel} />
                    </span>
                    <span className="is-num">
                      {o.totalFormatted} <span className="is-muted">· {formatDate(o.placedAt, false)}</span>
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="bk-muted" style={{ margin: 0 }}>
                {data ? 'No orders yet.' : 'Loading…'}
              </p>
            )}
          </div>
        </section>

        <section className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Top products</h2>
          </div>
          <div className="bk-panel__body">
            {data && data.topProducts.length ? (
              <ul className="bk-shop-list">
                {data.topProducts.map((p, i) => (
                  <li key={`${p.productId ?? p.name}-${i}`}>
                    <span className="bk-shop-list__left">
                      <span>{p.postId ? <Link to={href(`shop/products/${p.postId}`)}>{p.name}</Link> : p.name}</span>
                      <span className="is-muted">× {p.qty}</span>
                    </span>
                    <span className="is-num">{p.revenueFormatted}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="bk-muted" style={{ margin: 0 }}>
                {data ? 'Nothing sold in this period.' : 'Loading…'}
              </p>
            )}
          </div>
        </section>

        <section className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Orders by status</h2>
          </div>
          <div className="bk-panel__body">
            {data ? (
              <ul className="bk-shop-list">
                {data.statusCounts.map((s) => (
                  <li key={s.id}>
                    <span className="bk-shop-list__left">
                      <StatusPill status={s.id} label={s.label} />
                    </span>
                    <span className="is-num">
                      {s.count > 0 ? <Link to={href(`shop/orders?status=${s.id}`)}>{s.count}</Link> : <span className="is-muted">0</span>}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="bk-muted" style={{ margin: 0 }}>
                Loading…
              </p>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
