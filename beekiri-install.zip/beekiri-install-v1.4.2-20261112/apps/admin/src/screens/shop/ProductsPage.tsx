import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Image as ImageIcon, Plus } from '@phosphor-icons/react';
import { api } from '../../api/client';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { LiveSearch } from '../../components/LiveSearch';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { useAdminHref } from '../../lib/AdminEntryContext';
import { SITE_URL } from '../../config';
import {
  shopError,
  buildQuery,
  formatDate,
  formatMoney,
  useShopMeta,
  type ProductList,
  type ProductListRow,
  type ShopMeta,
  type TermList,
} from './api';
import './shop.css';
import './products.css';

type View = 'all' | 'publish' | 'draft' | 'trash';
type BulkAction = 'publish' | 'draft' | 'trash' | 'restore' | 'delete';

const formatError = shopError;

function PriceCell({ row, meta }: { row: ProductListRow; meta: ShopMeta | null }) {
  if (!row.price) return <span className="bk-muted">—</span>;
  if (row.type === 'variable') {
    const { min, max } = row.price;
    return (
      <span className="bk-shop-money bk-prod-price-range">
        {min === max ? formatMoney(min, meta) : `${formatMoney(min, meta)} – ${formatMoney(max, meta)}`}
      </span>
    );
  }
  if (row.price.onSale && row.regularPrice !== null) {
    return (
      <span className="bk-shop-money">
        <del>{formatMoney(row.regularPrice, meta)}</del>
        <ins>{formatMoney(row.price.min, meta)}</ins>
      </span>
    );
  }
  return <span className="bk-shop-money">{formatMoney(row.price.min, meta)}</span>;
}

function StockCell({ row }: { row: ProductListRow }) {
  if (row.stockStatus === 'outofstock') return <span className="bk-shop-pill is-danger">Out of stock</span>;
  if (row.stockStatus === 'onbackorder') return <span className="bk-shop-pill is-warn">On backorder</span>;
  return (
    <span className="bk-shop-pill is-ok">
      In stock{row.manageStock && row.stockQty !== null ? ` (${row.stockQty})` : ''}
    </span>
  );
}

/** Shop → Products: the WooCommerce-style "All products" list. */
export function ProductsPage() {
  const href = useAdminHref();
  const navigate = useNavigate();
  const meta = useShopMeta();
  const [params, setParams] = useSearchParams();
  const view = (params.get('status') as View) || 'all';
  const q = params.get('q') ?? '';
  const category = params.get('category') ?? '';
  const stock = params.get('stock') ?? '';
  const type = params.get('type') ?? '';
  const sort = params.get('sort') ?? 'updated';
  const page = Math.max(1, Number(params.get('page')) || 1);

  const [data, setData] = useState<ProductList | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [categories, setCategories] = useState<TermList['terms']>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);

  const setParam = useCallback(
    (patch: Record<string, string | undefined>) => {
      const next = new URLSearchParams(params);
      for (const [k, v] of Object.entries(patch)) {
        if (v) next.set(k, v);
        else next.delete(k);
      }
      if (!('page' in patch)) next.delete('page');
      // Typing does not fill the browser history with every letter.
      setParams(next, { replace: 'q' in patch && Object.keys(patch).length === 1 });
    },
    [params, setParams],
  );

  // Only the newest request may fill the list (results of fast typing can come back out of order).
  const latest = useRef(0);
  const load = useCallback(async () => {
    const ticket = ++latest.current;
    setLoading(true);
    try {
      const res = await api<ProductList>(
        `/api/shop/products${buildQuery({ status: view, q, category, stock, type, sort, page, perPage: 20 })}`,
      );
      if (ticket !== latest.current) return;
      setData(res);
      setSelected(new Set());
    } catch (e) {
      if (ticket === latest.current) setError(formatError(e));
    } finally {
      if (ticket === latest.current) setLoading(false);
    }
  }, [view, q, category, stock, type, sort, page]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (!meta?.categoryTaxonomyId) return;
    api<TermList>(`/api/fields/taxonomies/${meta.categoryTaxonomyId}/terms`)
      .then((res) => setCategories(res.terms))
      .catch(() => setCategories([]));
  }, [meta?.categoryTaxonomyId]);


  const counts = data?.counts ?? { all: 0, publish: 0, draft: 0, trash: 0 };
  const rows = data?.items ?? [];
  const allChecked = rows.length > 0 && rows.every((r) => selected.has(r.id));

  const run = async (fn: () => Promise<unknown>, message: string) => {
    setBusy(true);
    setError(null);
    try {
      await fn();
      setNotice(message);
      await load();
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const applyBulk = async (bulk: BulkAction) => {
    if (selected.size === 0) return;
    const ids = [...selected];
    if (bulk === 'delete') {
      const ok = await confirmDialog({
        title: `Permanently delete ${ids.length} product${ids.length === 1 ? '' : 's'}?`,
        message: 'This cannot be undone. Orders keep their line items.',
        confirmLabel: 'Delete permanently',
        danger: true,
      });
      if (!ok) return;
    }
    await run(
      () => api('/api/shop/products/bulk', { json: { ids, action: bulk } }),
      `${ids.length} product${ids.length === 1 ? '' : 's'} updated.`,
    );
  };

  const trash = (row: ProductListRow) =>
    run(() => api(`/api/shop/products/${row.id}`, { method: 'DELETE' }), `“${row.title || 'Untitled'}” moved to trash.`);
  const restore = (row: ProductListRow) =>
    run(() => api(`/api/shop/products/${row.id}/restore`, { method: 'POST' }), `“${row.title || 'Untitled'}” restored.`);
  const destroy = async (row: ProductListRow) => {
    const ok = await confirmDialog({
      title: `Permanently delete “${row.title || 'Untitled'}”?`,
      message: 'This cannot be undone. Orders keep their line items.',
      confirmLabel: 'Delete permanently',
      danger: true,
    });
    if (!ok) return;
    await run(() => api(`/api/shop/products/${row.id}?force=1`, { method: 'DELETE' }), 'Product deleted.');
  };
  const duplicate = async (row: ProductListRow) => {
    setBusy(true);
    try {
      const copy = await api<{ id: string }>(`/api/shop/products/${row.id}/duplicate`, { method: 'POST' });
      navigate(href(`shop/products/${copy.id}`));
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const categoryOptions = useMemo(() => {
    const byParent = new Map<string | null, TermList['terms']>();
    for (const t of categories) {
      const list = byParent.get(t.parentId) ?? [];
      list.push(t);
      byParent.set(t.parentId, list);
    }
    const out: { id: string; label: string }[] = [];
    const walk = (parent: string | null, depth: number) => {
      for (const t of byParent.get(parent) ?? []) {
        out.push({ id: t.id, label: `${'— '.repeat(depth)}${t.name}` });
        walk(t.id, depth + 1);
      }
    };
    walk(null, 0);
    return out;
  }, [categories]);

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Products"
        actions={
          <Link to={href('shop/products/new')} className="button button-primary">
            <Plus size={14} weight="bold" aria-hidden /> Add product
          </Link>
        }
      />
      <p className="bk-muted">Everything you sell. Click a product to edit it. {counts.all} total.</p>

      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <nav className="bk-tabs" aria-label="Product status">
        {(
          [
            ['all', 'All', counts.all],
            ['publish', 'Published', counts.publish],
            ['draft', 'Drafts', counts.draft],
            ['trash', 'Trash', counts.trash],
          ] as const
        ).map(([id, label, count]) => (
          <button
            key={id}
            type="button"
            className={`bk-tabs__item${view === id ? ' is-active' : ''}`}
            aria-current={view === id ? 'page' : undefined}
            onClick={() => setParam({ status: id === 'all' ? undefined : id })}
          >
            {label}
            <span className="bk-tabs__count">{count}</span>
          </button>
        ))}
      </nav>

      {selected.size > 0 ? (
        <div className="bk-prod-bar is-bulk" role="toolbar" aria-label="Selected products">
          <strong className="bk-prod-bar__count">{selected.size} selected</strong>
          {(view === 'trash'
            ? ([
                ['restore', 'Restore'],
                ['delete', 'Delete permanently'],
              ] as const)
            : ([
                ['publish', 'Publish'],
                ['draft', 'Set to draft'],
                ['trash', 'Move to trash'],
              ] as const)
          ).map(([action, label]) => (
            <button
              key={action}
              type="button"
              className={`button${action === 'delete' ? ' bk-prod-bar__danger' : ''}`}
              disabled={busy}
              onClick={() => void applyBulk(action)}
            >
              {label}
            </button>
          ))}
          <span className="bk-shop-toolbar__spacer" />
          <button type="button" className="button-link" onClick={() => setSelected(new Set())}>
            Clear selection
          </button>
        </div>
      ) : (
        <div className="bk-prod-bar" role="search">
          <LiveSearch
            value={q}
            onSearch={(text) => setParam({ q: text || undefined })}
            placeholder="Search by name or SKU…"
            label="Search products"
          />
          <select value={category} onChange={(e) => setParam({ category: e.target.value || undefined })} aria-label="Filter by category">
            <option value="">All categories</option>
            {categoryOptions.map((c) => (
              <option key={c.id} value={c.id}>
                {c.label}
              </option>
            ))}
          </select>
          <select value={stock} onChange={(e) => setParam({ stock: e.target.value || undefined })} aria-label="Filter by stock">
            <option value="">Any stock</option>
            <option value="instock">In stock</option>
            <option value="outofstock">Out of stock</option>
            <option value="onbackorder">On backorder</option>
          </select>
          <select value={type} onChange={(e) => setParam({ type: e.target.value || undefined })} aria-label="Filter by type">
            <option value="">Any type</option>
            <option value="simple">Simple</option>
            <option value="variable">Variable</option>
          </select>
          <select value={sort} onChange={(e) => setParam({ sort: e.target.value === 'updated' ? undefined : e.target.value })} aria-label="Sort">
            <option value="updated">Recently updated</option>
            <option value="title">Name A–Z</option>
            <option value="price">Price: low to high</option>
            <option value="price-desc">Price: high to low</option>
            <option value="sku">SKU</option>
            <option value="stock">Stock: low to high</option>
          </select>
          {q || category || stock || type ? (
            <button
              type="button"
              className="button-link bk-prod-bar__reset"
              onClick={() => setParam({ q: undefined, category: undefined, stock: undefined, type: undefined })}
            >
              Clear filters
            </button>
          ) : null}
        </div>
      )}

      <div className="bk-shop-table-wrap">
        <table className="bk-shop-table">
          <thead>
            <tr>
              <th className="is-check">
                <input
                  type="checkbox"
                  aria-label="Select all"
                  checked={allChecked}
                  onChange={(e) => setSelected(e.target.checked ? new Set(rows.map((r) => r.id)) : new Set())}
                />
              </th>
              <th className="is-thumb">
                <span className="screen-reader-text">Image</span>
              </th>
              <th>Name</th>
              <th>SKU</th>
              <th>Stock</th>
              <th>Price</th>
              <th>Categories</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {loading && !data ? (
              <tr>
                <td colSpan={8} className="bk-shop-table__empty">
                  Loading…
                </td>
              </tr>
            ) : rows.length === 0 ? (
              <tr>
                <td colSpan={8} className="bk-shop-table__empty">
                  {view === 'trash' ? (
                    'Trash is empty.'
                  ) : q || category || stock || type ? (
                    'No products match these filters.'
                  ) : (
                    <>
                      No products yet. <Link to={href('shop/products/new')}>Add your first product</Link>.
                    </>
                  )}
                </td>
              </tr>
            ) : (
              rows.map((row) => (
                <tr key={row.id} className="is-clickable" onClick={() => navigate(href(`shop/products/${row.id}`))}>
                  <td className="is-check" onClick={(e) => e.stopPropagation()}>
                    <input
                      type="checkbox"
                      aria-label={`Select ${row.title}`}
                      checked={selected.has(row.id)}
                      onChange={(e) => {
                        const next = new Set(selected);
                        if (e.target.checked) next.add(row.id);
                        else next.delete(row.id);
                        setSelected(next);
                      }}
                    />
                  </td>
                  <td className="is-thumb">
                    {row.image ? (
                      <img className="bk-shop-thumb" src={row.image.url} alt="" />
                    ) : (
                      <span className="bk-shop-thumb is-empty" aria-hidden>
                        <ImageIcon size={18} />
                      </span>
                    )}
                  </td>
                  <td>
                    <Link to={href(`shop/products/${row.id}`)} className="bk-shop-table__primary" onClick={(e) => e.stopPropagation()}>
                      {row.title || <em>Untitled</em>}
                    </Link>
                    {row.status === 'draft' ? <span className="bk-table__badge">Draft</span> : null}
                    {row.featured ? <span className="bk-table__badge is-accent">Featured</span> : null}
                    {row.type === 'variable' ? (
                      <span className="bk-shop-table__sub">
                        Variable · {row.variantCount} variation{row.variantCount === 1 ? '' : 's'}
                      </span>
                    ) : null}
                    <div className="bk-shop-table__actions" onClick={(e) => e.stopPropagation()}>
                      {view === 'trash' ? (
                        <>
                          <button type="button" disabled={busy} onClick={() => void restore(row)}>
                            Restore
                          </button>
                          <span className="sep">|</span>
                          <button type="button" className="is-danger" disabled={busy} onClick={() => void destroy(row)}>
                            Delete permanently
                          </button>
                        </>
                      ) : (
                        <>
                          <Link to={href(`shop/products/${row.id}`)}>Edit</Link>
                          <span className="sep">|</span>
                          <button type="button" disabled={busy} onClick={() => void duplicate(row)}>
                            Duplicate
                          </button>
                          <span className="sep">|</span>
                          <button type="button" className="is-danger" disabled={busy} onClick={() => void trash(row)}>
                            Trash
                          </button>
                          {row.status === 'publish' ? (
                            <>
                              <span className="sep">|</span>
                              <a href={`${SITE_URL}${row.path}`} target="_blank" rel="noopener noreferrer">
                                View
                              </a>
                            </>
                          ) : null}
                        </>
                      )}
                    </div>
                  </td>
                  <td>{row.sku || <span className="bk-muted">—</span>}</td>
                  <td>
                    <StockCell row={row} />
                  </td>
                  <td>
                    <PriceCell row={row} meta={meta} />
                  </td>
                  <td>
                    {row.categories.length ? (
                      row.categories.map((c, i) => (
                        <span key={c.id}>
                          {i ? ', ' : ''}
                          <button type="button" className="button-link" onClick={(e) => { e.stopPropagation(); setParam({ category: c.id }); }}>
                            {c.name}
                          </button>
                        </span>
                      ))
                    ) : (
                      <span className="bk-muted">—</span>
                    )}
                  </td>
                  <td>
                    {row.status === 'publish' ? 'Published' : 'Last modified'}
                    <span className="bk-shop-table__sub">{formatDate(row.status === 'publish' ? row.publishedAt ?? row.updatedAt : row.updatedAt)}</span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {data && data.pages > 1 ? (
        <div className="bk-shop-pager">
          <span>
            {data.total} item{data.total === 1 ? '' : 's'} · page {data.page} of {data.pages}
          </span>
          <div className="bk-shop-pager__buttons">
            <button type="button" className="button" disabled={page <= 1} onClick={() => setParam({ page: String(page - 1) })}>
              ‹ Previous
            </button>
            <button type="button" className="button" disabled={page >= data.pages} onClick={() => setParam({ page: String(page + 1) })}>
              Next ›
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
