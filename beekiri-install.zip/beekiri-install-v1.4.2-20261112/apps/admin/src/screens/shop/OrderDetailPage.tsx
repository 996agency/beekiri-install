import { useCallback, useEffect, useState, type CSSProperties, type FormEvent } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../../api/client';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { useAdminHref } from '../../lib/AdminEntryContext';
import {
  formatDate,
  formatMoney,
  moneyToInput,
  parseMoney,
  useShopMeta,
  type Address,
  type Fulfillment,
  type FulfillmentStatus,
  type OrderDetail,
  type OrderStatus,
} from './api';
import { formatError, PAYMENT_STATUS_LABELS, StatusPill } from './OrdersPage';
import './shop.css';
import './orders.css';

const EMAIL_KINDS: { id: string; label: string }[] = [
  { id: 'orderReceived', label: 'Order received (customer)' },
  { id: 'onHold', label: 'On hold / payment instructions (customer)' },
  { id: 'processing', label: 'Processing (customer)' },
  { id: 'completed', label: 'Completed (customer)' },
  { id: 'cancelled', label: 'Cancelled (customer)' },
  { id: 'refunded', label: 'Refunded (customer)' },
  { id: 'shipped', label: 'Order shipped (customer)' },
  { id: 'delivered', label: 'Order delivered (customer)' },
  { id: 'newOrderAdmin', label: 'New order (shop admin)' },
];

const FULFILLMENT_STEPS: { id: FulfillmentStatus; label: string; at: keyof Fulfillment | null }[] = [
  { id: 'unfulfilled', label: 'Not shipped', at: null },
  { id: 'packed', label: 'Packed', at: 'packedAt' },
  { id: 'shipped', label: 'Shipped', at: 'shippedAt' },
  { id: 'delivered', label: 'Delivered', at: 'deliveredAt' },
];

/** Shipping & tracking: one "next step" action, an undo link, tracking fields once the order is packed. */
function ShippingPanel({
  detail,
  busy,
  onSave,
}: {
  detail: OrderDetail;
  busy: boolean;
  onSave: (body: { status: FulfillmentStatus; carrier: string; trackingNumber: string; trackingUrl: string; notify: boolean }, label: string) => Promise<void>;
}) {
  const { order } = detail;
  const f = order.fulfillment;
  const [carrier, setCarrier] = useState(f.carrier);
  const [trackingNumber, setTrackingNumber] = useState(f.trackingNumber);
  const [trackingUrl, setTrackingUrl] = useState(f.trackingUrl);
  const [notify, setNotify] = useState(true);
  const [showTracking, setShowTracking] = useState(false);
  useEffect(() => {
    setCarrier(f.carrier);
    setTrackingNumber(f.trackingNumber);
    setTrackingUrl(f.trackingUrl);
  }, [f.carrier, f.trackingNumber, f.trackingUrl, f.status]);

  const stopped = ['cancelled', 'refunded', 'failed'].includes(order.status);
  const pending = order.status === 'pending';
  const disabled = busy || stopped || pending;
  const index = FULFILLMENT_STEPS.findIndex((s) => s.id === f.status);
  const next = FULFILLMENT_STEPS[index + 1];
  const prev = index > 0 ? FULFILLMENT_STEPS[index - 1] : null;
  const t = order.tracking;
  const hasTracking = Boolean(f.carrier || f.trackingNumber || f.trackingUrl);
  const trackingVisible = showTracking || hasTracking || index >= 1;
  const trackingChanged = carrier !== f.carrier || trackingNumber !== f.trackingNumber || trackingUrl !== f.trackingUrl;
  const save = (status: FulfillmentStatus) =>
    onSave(
      { status, carrier, trackingNumber, trackingUrl, notify },
      status === f.status
        ? 'Tracking details saved.'
        : status === 'unfulfilled'
          ? 'Shipment reset.'
          : `Marked as ${FULFILLMENT_STEPS.find((s) => s.id === status)?.label.toLowerCase()}.`,
    );

  return (
    <section className="bk-panel">
      <div className="bk-panel__head bk-order-card__head">
        <h2 className="bk-panel__title">Shipping</h2>
        <span className={`bk-shop-pill is-${FULFILLMENT_TONE[f.status]}`}>{FULFILLMENT_STEPS[index]?.label ?? f.status}</span>
      </div>
      <div className="bk-panel__body">
        {stopped ? <p className="bk-shop-note is-info">This order is {order.statusLabel.toLowerCase()}, so it cannot be shipped.</p> : null}
        {pending ? <p className="bk-shop-note">Waiting for payment — shipping unlocks once the order is paid.</p> : null}
        <ol className="bk-ship-steps" aria-label="Fulfilment progress" style={{ '--ship-progress': index / (FULFILLMENT_STEPS.length - 1) } as CSSProperties}>
          {FULFILLMENT_STEPS.map((s, i) => {
            const at = s.at ? (f[s.at] as string | null) : null;
            const state = i < index ? 'done' : i === index ? 'current' : 'upcoming';
            return (
              <li key={s.id} className={`bk-ship-steps__step is-${state}`}>
                <span className="bk-ship-steps__dot" aria-hidden />
                <span className="bk-ship-steps__label">{s.label}</span>
                <span className="bk-ship-steps__at">{at ? formatDate(at) : '\u00a0'}</span>
              </li>
            );
          })}
        </ol>
        {trackingVisible ? (
          <div className="bk-ship-tracking">
            <div className="bk-shop-row">
              <div className="bk-shop-field">
                <label htmlFor="ship-carrier">Carrier</label>
                <input id="ship-carrier" type="text" value={carrier} maxLength={80} placeholder="e.g. DHL, Post" disabled={disabled} onChange={(e) => setCarrier(e.target.value)} />
              </div>
              <div className="bk-shop-field">
                <label htmlFor="ship-number">Tracking number</label>
                <input id="ship-number" type="text" value={trackingNumber} maxLength={120} disabled={disabled} onChange={(e) => setTrackingNumber(e.target.value)} />
              </div>
            </div>
            <div className="bk-shop-field">
              <label htmlFor="ship-url">Tracking link</label>
              <input id="ship-url" type="url" value={trackingUrl} maxLength={500} placeholder="https://…" disabled={disabled} onChange={(e) => setTrackingUrl(e.target.value)} />
              <p className="description">Shown to the customer as a “Track parcel” button.</p>
            </div>
          </div>
        ) : null}
      </div>

      <div className="bk-ship-foot">
        <div className="bk-ship-foot__info">
          <p className="bk-ship-sees">
            Customer sees <strong className={t.stopped?.tone === 'danger' ? 'is-danger' : ''}>{t.stopped ? t.stopped.label : t.headline}</strong>
          </p>
          {next || trackingVisible ? (
            <label className="bk-check bk-ship-notify">
              <input type="checkbox" checked={notify} disabled={disabled} onChange={(e) => setNotify(e.target.checked)} /> <span className="bk-check__box" aria-hidden />
              <span>Email the customer when the order is shipped or delivered</span>
            </label>
          ) : null}
        </div>
        <div className="bk-ship-actions">
          {prev && !disabled ? (
            <button type="button" className="button-link bk-ship-actions__undo" onClick={() => void save(prev.id)}>
              Back to “{prev.label}”
            </button>
          ) : null}
          {!trackingVisible && !disabled ? (
            <button type="button" className="button" onClick={() => setShowTracking(true)}>
              Add tracking details
            </button>
          ) : null}
          {trackingVisible && (trackingChanged || !next) ? (
            <button type="button" className="button" disabled={disabled || !trackingChanged} onClick={() => void save(f.status)}>
              Save tracking
            </button>
          ) : null}
          {next ? (
            <button type="button" className="button button-primary" disabled={disabled} onClick={() => void save(next.id)}>
              Mark as {next.label.toLowerCase()}
            </button>
          ) : null}
        </div>
      </div>
    </section>
  );
}

const FULFILLMENT_TONE: Record<FulfillmentStatus, string> = { unfulfilled: 'warn', packed: 'info', shipped: 'info', delivered: 'ok' };
const PAYMENT_TONE: Record<string, string> = { unpaid: 'warn', paid: 'ok', partially_refunded: 'info', refunded: 'muted', failed: 'danger' };

const ADDRESS_FIELDS: { key: keyof Address; label: string; autoComplete: string }[] = [
  { key: 'firstName', label: 'First name', autoComplete: 'given-name' },
  { key: 'lastName', label: 'Last name', autoComplete: 'family-name' },
  { key: 'company', label: 'Company', autoComplete: 'organization' },
  { key: 'line1', label: 'Address line 1', autoComplete: 'address-line1' },
  { key: 'line2', label: 'Address line 2', autoComplete: 'address-line2' },
  { key: 'city', label: 'City', autoComplete: 'address-level2' },
  { key: 'state', label: 'State / County', autoComplete: 'address-level1' },
  { key: 'postcode', label: 'Postcode', autoComplete: 'postal-code' },
];

function addressLines(a: Address | null | undefined, countryName: (c?: string) => string): string[] {
  if (!a) return [];
  return [
    [a.firstName, a.lastName].filter(Boolean).join(' '),
    a.company,
    a.line1,
    a.line2,
    [a.postcode, a.city].filter(Boolean).join(' '),
    a.state,
    countryName(a.country),
  ]
    .map((v) => (v ?? '').toString().trim())
    .filter(Boolean);
}

function AddressBlock({ title, lines }: { title: string; lines: string[] }) {
  return (
    <div className="bk-order-addr">
      <h3>{title}</h3>
      {lines.length ? (
        <address>
          {lines.map((l, i) => (
            <span key={i}>{l}</span>
          ))}
        </address>
      ) : (
        <p className="bk-muted">No address given.</p>
      )}
    </div>
  );
}

type AddressForm = { email: string; phone: string; customerNote: string; billing: Address; shipping: Address };

export function OrderDetailPage() {
  const { id = '' } = useParams();
  const href = useAdminHref();
  const meta = useShopMeta();
  const [detail, setDetail] = useState<OrderDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const [status, setStatus] = useState<OrderStatus>('pending');
  const [statusNote, setStatusNote] = useState('');
  const [statusNoteOpen, setStatusNoteOpen] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [noteKind, setNoteKind] = useState<'private' | 'customer'>('private');
  const [emailKind, setEmailKind] = useState(EMAIL_KINDS[0]!.id);
  const [refundOpen, setRefundOpen] = useState(false);
  const [refundAmount, setRefundAmount] = useState('');
  const [refundReason, setRefundReason] = useState('');
  const [refundVia, setRefundVia] = useState(false);
  const [refundRestock, setRefundRestock] = useState(true);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState<AddressForm | null>(null);

  const load = useCallback(async () => {
    const res = await api<OrderDetail>(`/api/shop/orders/${encodeURIComponent(id)}`);
    setDetail(res);
    setStatus(res.order.status);
    setRefundAmount(moneyToInput(res.order.total - res.order.refundedTotal, res.order.currency, meta?.currencies));
    setRefundVia(res.canRefundViaProvider);
    return res;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffect(() => {
    load().catch((e) => setError(formatError(e)));
  }, [load]);

  const countryName = (code?: string) => meta?.countries.find((c) => c.code === code)?.name ?? code ?? '';

  const run = async (label: string, fn: () => Promise<OrderDetail | { ok: boolean }>) => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const res = await fn();
      if ('order' in res) setDetail(res);
      setNotice(label);
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  if (error && !detail) {
    return (
      <div className="wrap">
        <PageHeader title="Order" />
        <ErrorNotice message={error} onDismiss={() => setError(null)} />
        <p>
          <Link className="button" to={href('shop/orders')}>
            ← Back to orders
          </Link>
        </p>
      </div>
    );
  }
  if (!detail) {
    return (
      <div className="wrap">
        <PageHeader title="Order" />
        <p className="bk-muted">Loading…</p>
      </div>
    );
  }

  const { order, customer, canRefundViaProvider } = detail;
  const remaining = order.total - order.refundedTotal;
  const unpaidOffline = order.paymentStatus === 'unpaid' && (order.status === 'on-hold' || order.status === 'pending');
  const money = (v: number) => formatMoney(v, meta, order.currency);
  const paymentRef = order.paymentRef as { sessionId?: string; paymentIntentId?: string };

  const startEdit = () => {
    setForm({ email: order.email, phone: order.phone, customerNote: order.customerNote, billing: { ...order.billing }, shipping: { ...order.shipping } });
    setEditing(true);
  };

  const saveDetails = async (e: FormEvent) => {
    e.preventDefault();
    if (!form) return;
    await run('Order details saved.', () =>
      api<OrderDetail>(`/api/shop/orders/${encodeURIComponent(id)}`, {
        method: 'PATCH',
        json: { email: form.email.trim(), phone: form.phone.trim(), billing: form.billing, shipping: form.shipping, customerNote: form.customerNote },
      }),
    );
    setEditing(false);
  };

  const updateStatus = async (e: FormEvent) => {
    e.preventDefault();
    if (status === order.status && !statusNote.trim()) return;
    if (status === 'cancelled' || status === 'refunded') {
      const ok = await confirmDialog({
        title: `Mark this order as ${status}?`,
        message: 'Stock is put back for every item in the order and the customer is emailed.',
        confirmLabel: 'Update status',
        danger: true,
      });
      if (!ok) return;
    }
    await run('Order status updated.', () =>
      api<OrderDetail>(`/api/shop/orders/${encodeURIComponent(id)}/status`, { method: 'POST', json: { status, note: statusNote.trim() || undefined } }),
    );
    setStatusNote('');
    setStatusNoteOpen(false);
  };

  const addNote = async (e: FormEvent) => {
    e.preventDefault();
    if (!noteText.trim()) return;
    await run(noteKind === 'customer' ? 'Note added and emailed to the customer.' : 'Private note added.', () =>
      api<OrderDetail>(`/api/shop/orders/${encodeURIComponent(id)}/notes`, { method: 'POST', json: { note: noteText.trim(), isCustomerNote: noteKind === 'customer' } }),
    );
    setNoteText('');
  };

  const deleteNote = async (noteId: string) => {
    const ok = await confirmDialog({ title: 'Delete this note?', message: 'The note is removed from the order history.', confirmLabel: 'Delete', danger: true });
    if (!ok) return;
    await run('Note deleted.', () => api<OrderDetail>(`/api/shop/orders/${encodeURIComponent(id)}/notes/${encodeURIComponent(noteId)}`, { method: 'DELETE' }));
  };

  const refund = async (e: FormEvent) => {
    e.preventDefault();
    const amount = parseMoney(refundAmount, order.currency, meta?.currencies);
    if (amount === null || amount <= 0) {
      setError('Enter a refund amount.');
      return;
    }
    if (amount > remaining) {
      setError(`You can refund at most ${money(remaining)}.`);
      return;
    }
    const ok = await confirmDialog({
      title: `Refund ${money(amount)}?`,
      message: refundVia
        ? 'The refund is sent to Stripe and the customer gets the money back on their card. This cannot be undone.'
        : 'This records the refund on the order. Send the money back to the customer yourself.',
      confirmLabel: 'Refund',
      danger: true,
    });
    if (!ok) return;
    await run('Refund recorded.', () =>
      api<OrderDetail>(`/api/shop/orders/${encodeURIComponent(id)}/refund`, {
        method: 'POST',
        json: { amount, reason: refundReason.trim() || undefined, viaProvider: refundVia, restock: refundRestock },
      }),
    );
    setRefundOpen(false);
    setRefundReason('');
  };

  const resend = async () => {
    await run('Email sent.', () => api<{ ok: boolean }>(`/api/shop/orders/${encodeURIComponent(id)}/resend-email`, { method: 'POST', json: { kind: emailKind } }));
  };

  const addressField = (scope: 'billing' | 'shipping', key: keyof Address, label: string, autoComplete: string) => (
    <div className="bk-shop-field" key={`${scope}.${key}`}>
      <label htmlFor={`addr-${scope}-${key}`}>{label}</label>
      <input
        id={`addr-${scope}-${key}`}
        className="regular-text"
        type="text"
        autoComplete={autoComplete}
        value={form?.[scope][key] ?? ''}
        onChange={(e) => setForm((f) => (f ? { ...f, [scope]: { ...f[scope], [key]: e.target.value } } : f))}
      />
    </div>
  );

  const countrySelect = (scope: 'billing' | 'shipping') => (
    <div className="bk-shop-field">
      <label htmlFor={`addr-${scope}-country`}>Country</label>
      <select
        id={`addr-${scope}-country`}
        value={form?.[scope].country ?? ''}
        onChange={(e) => setForm((f) => (f ? { ...f, [scope]: { ...f[scope], country: e.target.value } } : f))}
      >
        <option value="">—</option>
        {(meta?.countries ?? []).map((c) => (
          <option key={c.code} value={c.code}>
            {c.name}
          </option>
        ))}
      </select>
    </div>
  );

  const itemCount = order.items.reduce((n, it) => n + it.qty, 0);
  const shippingLines = order.shipToDifferent ? addressLines(order.shipping, countryName) : addressLines(order.billing, countryName);
  const billingLines = addressLines(order.billing, countryName);
  const sameAddress = !order.shipToDifferent || shippingLines.join('|') === billingLines.join('|');

  return (
    <div className="wrap wrap--wide bk-order">
      <Link className="bk-order__back" to={href('shop/orders')}>
        ← Orders
      </Link>
      <header className="bk-order__head">
        <div className="bk-order__title-row">
          <h1 className="bk-order__title">Order {order.numberLabel}</h1>
          <StatusPill status={order.status} label={order.statusLabel} />
          <span className={`bk-shop-pill is-${PAYMENT_TONE[order.paymentStatus] ?? 'neutral'}`}>{PAYMENT_STATUS_LABELS[order.paymentStatus] ?? order.paymentStatus}</span>
          <span className={`bk-shop-pill is-${FULFILLMENT_TONE[order.fulfillment.status]}`}>
            {FULFILLMENT_STEPS.find((s) => s.id === order.fulfillment.status)?.label ?? order.fulfillment.status}
          </span>
        </div>
        <p className="bk-order__meta">
          {formatDate(order.placedAt)} · {order.paymentMethodTitle} · {money(order.total)}
        </p>
      </header>

      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <div className="bk-shop-editor">
        <div className="bk-shop-editor__main">
          {editing && form ? (
            <section className="bk-panel">
              <div className="bk-panel__head">
                <h2 className="bk-panel__title">Edit customer details</h2>
              </div>
              <div className="bk-panel__body">
                <form onSubmit={saveDetails}>
                  <div className="bk-shop-row">
                    <div className="bk-shop-field">
                      <label htmlFor="order-email">Email</label>
                      <input id="order-email" className="regular-text" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
                    </div>
                    <div className="bk-shop-field">
                      <label htmlFor="order-phone">Phone</label>
                      <input id="order-phone" className="regular-text" type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                    </div>
                  </div>
                  <div className="bk-shop-addresses">
                    <div>
                      <h3 className="bk-shop-section-title">Billing</h3>
                      {ADDRESS_FIELDS.map((f) => addressField('billing', f.key, f.label, f.autoComplete))}
                      {countrySelect('billing')}
                    </div>
                    <div>
                      <h3 className="bk-shop-section-title">Shipping</h3>
                      {ADDRESS_FIELDS.map((f) => addressField('shipping', f.key, f.label, f.autoComplete))}
                      {countrySelect('shipping')}
                    </div>
                  </div>
                  <div className="bk-shop-field">
                    <label htmlFor="order-cnote">Customer note</label>
                    <textarea id="order-cnote" rows={2} value={form.customerNote} onChange={(e) => setForm({ ...form, customerNote: e.target.value })} />
                  </div>
                  <div className="bk-shop-inline">
                    <button type="submit" className="button button-primary" disabled={busy}>
                      {busy ? 'Saving…' : 'Save details'}
                    </button>
                    <button type="button" className="button" onClick={() => setEditing(false)} disabled={busy}>
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            </section>
          ) : null}

          <section className="bk-panel">
            <div className="bk-panel__head bk-order-card__head">
              <h2 className="bk-panel__title">Items</h2>
              <span className="bk-muted bk-order-card__count">
                {itemCount} {itemCount === 1 ? 'item' : 'items'}
              </span>
            </div>
            <div className="bk-panel__body bk-order-card__flush">
              <table className="bk-order-items">
                <thead>
                  <tr>
                    <th scope="col">Product</th>
                    <th scope="col" className="is-right">Price</th>
                    <th scope="col" className="is-right">Qty</th>
                    <th scope="col" className="is-right">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {order.items.map((it) => (
                    <tr key={it.id}>
                      <td>
                        <div className="bk-order-items__product">
                          {it.imageUrl ? <img src={it.imageUrl} alt="" /> : <span className="bk-order-items__ph" aria-hidden />}
                          <div>
                            {it.postId ? <Link to={href(`shop/products/${it.postId}`)}>{it.name}</Link> : <span>{it.name}</span>}
                            {Object.keys(it.attributes ?? {}).length ? <small>{Object.values(it.attributes).join(' · ')}</small> : null}
                            {it.sku ? <small>SKU {it.sku}</small> : null}
                          </div>
                        </div>
                      </td>
                      <td className="is-right is-num">{it.formatted.unitPrice}</td>
                      <td className="is-right is-num">{it.qty}</td>
                      <td className="is-right is-num is-strong">{it.formatted.total}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section className="bk-panel">
            <div className="bk-panel__head bk-order-card__head">
              <h2 className="bk-panel__title">Payment</h2>
              <span className={`bk-shop-pill is-${PAYMENT_TONE[order.paymentStatus] ?? 'neutral'}`}>{PAYMENT_STATUS_LABELS[order.paymentStatus] ?? order.paymentStatus}</span>
            </div>
            <div className="bk-panel__body">
              {unpaidOffline ? (
                <p className="bk-shop-note">
                  <strong>Awaiting payment.</strong>{' '}
                  {order.paymentMethod === 'bank_transfer'
                    ? 'Set the status to Processing once the bank transfer arrives — that counts it as paid and emails the customer.'
                    : order.paymentMethod === 'stripe'
                      ? 'The card payment has not been confirmed yet. It is cancelled automatically if the customer never pays.'
                      : 'Set the status to Processing when you are ready to fulfil it.'}
                </p>
              ) : null}
              <table className="bk-order-totals">
                <tbody>
                  <tr>
                    <th scope="row">Subtotal</th>
                    <td>{order.formatted.subtotal}</td>
                  </tr>
                  {order.discountTotal > 0 ? (
                    <tr>
                      <th scope="row">Discount{order.couponCode ? ` (${order.couponCode})` : ''}</th>
                      <td>−{order.formatted.discountTotal}</td>
                    </tr>
                  ) : null}
                  {order.shippingMethod || order.shippingTotal > 0 ? (
                    <tr>
                      <th scope="row">Shipping{order.shippingMethod ? ` · ${order.shippingMethod.title}` : ''}</th>
                      <td>{order.formatted.shippingTotal}</td>
                    </tr>
                  ) : null}
                  {order.taxTotal > 0 ? (
                    <tr>
                      <th scope="row">Tax</th>
                      <td>{order.formatted.taxTotal}</td>
                    </tr>
                  ) : null}
                  <tr className="is-total">
                    <th scope="row">Total</th>
                    <td>{order.formatted.total}</td>
                  </tr>
                  {order.refundedTotal > 0 ? (
                    <>
                      <tr className="is-refund">
                        <th scope="row">Refunded</th>
                        <td>−{order.formatted.refundedTotal}</td>
                      </tr>
                      <tr className="is-total">
                        <th scope="row">Net</th>
                        <td>{order.formatted.net}</td>
                      </tr>
                    </>
                  ) : null}
                </tbody>
              </table>
              <dl className="bk-order-kv">
                <dt>Method</dt>
                <dd>{order.paymentMethodTitle}</dd>
                {order.paidAt ? (
                  <>
                    <dt>Paid</dt>
                    <dd>{formatDate(order.paidAt)}</dd>
                  </>
                ) : null}
                {order.transactionId ? (
                  <>
                    <dt>Transaction</dt>
                    <dd>
                      <code>{order.transactionId}</code>
                    </dd>
                  </>
                ) : null}
                {paymentRef.sessionId ? (
                  <>
                    <dt>Stripe session</dt>
                    <dd>
                      <code>{paymentRef.sessionId}</code>
                    </dd>
                  </>
                ) : null}
              </dl>
              {order.paymentStatus !== 'unpaid' && order.paymentStatus !== 'failed' && remaining > 0 ? (
                refundOpen ? (
                  <form className="bk-order-refund" onSubmit={refund}>
                    <div className="bk-shop-row">
                      <div className="bk-shop-field">
                        <label htmlFor="refund-amount">Amount ({order.currency}) — up to {money(remaining)}</label>
                        <input id="refund-amount" className="regular-text" type="text" inputMode="decimal" value={refundAmount} onChange={(e) => setRefundAmount(e.target.value)} />
                      </div>
                      <div className="bk-shop-field">
                        <label htmlFor="refund-reason">Reason (optional)</label>
                        <input id="refund-reason" className="regular-text" type="text" value={refundReason} onChange={(e) => setRefundReason(e.target.value)} />
                      </div>
                    </div>
                    {canRefundViaProvider ? (
                      <label className="bk-shop-check">
                        <input type="checkbox" checked={refundVia} onChange={(e) => setRefundVia(e.target.checked)} /> Refund via Stripe
                      </label>
                    ) : (
                      <p className="bk-muted bk-order-small">Recorded manually — send the money back yourself.</p>
                    )}
                    <label className="bk-shop-check">
                      <input type="checkbox" checked={refundRestock} onChange={(e) => setRefundRestock(e.target.checked)} /> Put items back in stock (full refunds)
                    </label>
                    <div className="bk-shop-inline" style={{ marginTop: 8 }}>
                      <button type="submit" className="button button-primary" disabled={busy}>
                        {busy ? 'Refunding…' : 'Refund'}
                      </button>
                      <button type="button" className="button" onClick={() => setRefundOpen(false)} disabled={busy}>
                        Cancel
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="bk-order-card__foot">
                    <button type="button" className="button" onClick={() => setRefundOpen(true)}>
                      Refund…
                    </button>
                  </div>
                )
              ) : null}
            </div>
          </section>

          <ShippingPanel
            detail={detail}
            busy={busy}
            onSave={(body, label) =>
              run(label, () => api<OrderDetail>(`/api/shop/orders/${encodeURIComponent(id)}/fulfillment`, { method: 'POST', json: body }))
            }
          />

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Timeline</h2>
            </div>
            <div className="bk-panel__body">
              <form className="bk-order-composer" onSubmit={addNote}>
                <textarea rows={2} value={noteText} onChange={(e) => setNoteText(e.target.value)} placeholder="Add a note…" aria-label="New note" />
                <div className="bk-order-composer__row">
                  <select value={noteKind} onChange={(e) => setNoteKind(e.target.value as 'private' | 'customer')} aria-label="Note type">
                    <option value="private">Private note</option>
                    <option value="customer">Note to customer (emailed)</option>
                  </select>
                  <button type="submit" className="button button-primary" disabled={busy || !noteText.trim()}>
                    Add note
                  </button>
                </div>
              </form>
              {order.notes.length ? (
                <ol className="bk-order-timeline">
                  {order.notes.map((n) => (
                    <li key={n.id} className={n.isCustomerNote ? 'is-customer' : n.authorId ? 'is-private' : 'is-system'}>
                      <p>{n.note}</p>
                      <div className="bk-order-timeline__meta">
                        <span>
                          {n.authorName} · {formatDate(n.createdAt)}
                          {n.isCustomerNote ? ' · sent to customer' : ''}
                        </span>
                        {n.authorId ? (
                          <button type="button" onClick={() => void deleteNote(n.id)} disabled={busy}>
                            Delete
                          </button>
                        ) : null}
                      </div>
                    </li>
                  ))}
                </ol>
              ) : (
                <p className="bk-muted bk-order-small">No activity yet.</p>
              )}
            </div>
          </section>
        </div>

        <div className="bk-shop-editor__side">
          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Status</h2>
            </div>
            <div className="bk-panel__body">
              <form className="bk-order-status" onSubmit={updateStatus}>
                <label className="screen-reader-text" htmlFor="order-status">
                  Order status
                </label>
                <select id="order-status" value={status} onChange={(e) => setStatus(e.target.value as OrderStatus)}>
                  {(meta?.orderStatuses ?? []).map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.label}
                    </option>
                  ))}
                </select>
                {statusNoteOpen ? (
                  <textarea
                    id="order-status-note"
                    rows={2}
                    value={statusNote}
                    onChange={(e) => setStatusNote(e.target.value)}
                    placeholder="Included in the status email."
                    aria-label="Note to customer"
                  />
                ) : (
                  <button type="button" className="button-link bk-order-small" onClick={() => setStatusNoteOpen(true)}>
                    + Add a note for the customer
                  </button>
                )}
                <button type="submit" className="button button-primary" disabled={busy || (status === order.status && !statusNote.trim())}>
                  {busy ? 'Saving…' : 'Update status'}
                </button>
              </form>
            </div>
          </section>

          <section className="bk-panel">
            <div className="bk-panel__head bk-order-card__head">
              <h2 className="bk-panel__title">Customer</h2>
              {!editing ? (
                <button type="button" className="button-link bk-order-small" onClick={startEdit}>
                  Edit
                </button>
              ) : null}
            </div>
            <div className="bk-panel__body bk-order-customer">
              <div className="bk-order-customer__who">
                <strong>{order.customerName}</strong>
                {customer ? (
                  <Link className="bk-order-small" to={href(`shop/orders?customerId=${encodeURIComponent(customer.id)}`)}>
                    {customer.ordersCount} {customer.ordersCount === 1 ? 'order' : 'orders'} · {money(customer.totalSpent)} spent
                  </Link>
                ) : null}
              </div>
              <div className="bk-order-customer__block">
                <h3>Contact</h3>
                <span className="bk-shop-email">{order.email}</span>
                {order.phone ? <span>{order.phone}</span> : null}
              </div>
              <div className="bk-order-customer__block">
                <AddressBlock title="Shipping address" lines={shippingLines} />
                {order.shippingMethod ? <span className="bk-muted bk-order-small">{order.shippingMethod.title}</span> : null}
              </div>
              <div className="bk-order-customer__block">
                {sameAddress ? (
                  <>
                    <h3>Billing address</h3>
                    <span className="bk-muted bk-order-small">Same as shipping address</span>
                  </>
                ) : (
                  <AddressBlock title="Billing address" lines={billingLines} />
                )}
              </div>
              {order.customerNote ? (
                <div className="bk-order-customer__block">
                  <h3>Customer note</h3>
                  <p className="bk-order-customer__note">{order.customerNote}</p>
                </div>
              ) : null}
              {order.customFields?.length ? (
                <div className="bk-order-customer__block">
                  <h3>Checkout answers</h3>
                  <dl className="bk-order-kv">
                    {order.customFields.map((f) => (
                      <div key={f.key} className="bk-order-kv__row">
                        <dt>{f.label}</dt>
                        <dd>{f.value}</dd>
                      </div>
                    ))}
                  </dl>
                </div>
              ) : null}
              {order.couponCode || order.ipAddress ? (
                <div className="bk-order-customer__block">
                  <h3>Order details</h3>
                  {order.couponCode ? <span>Coupon {order.couponCode}</span> : null}
                  {order.ipAddress ? <span className="bk-muted">IP {order.ipAddress}</span> : null}
                </div>
              ) : null}
            </div>
          </section>

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Resend email</h2>
            </div>
            <div className="bk-panel__body bk-order-resend">
              <select value={emailKind} onChange={(e) => setEmailKind(e.target.value)} aria-label="Email to send">
                {EMAIL_KINDS.map((k) => (
                  <option key={k.id} value={k.id}>
                    {k.label}
                  </option>
                ))}
              </select>
              <button type="button" className="button" onClick={() => void resend()} disabled={busy}>
                Send email
              </button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
