import { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { api, ApiError } from '../../api/client';
import { ErrorNotice } from '../../components/ErrorNotice';
import { LiveSearch } from '../../components/LiveSearch';
import { PageHeader } from '../../components/PageHeader';
import { useAdminHref } from '../../lib/AdminEntryContext';
import {
  buildQuery,
  formatDate,
  ORDER_STATUS_TONE,
  useShopMeta,
  type Customer,
  type OrderList,
  type OrderStatus,
  type OrderListRow,
} from './api';
import './shop.css';
import './orders.css';

export function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

const SHIPPING_PILL: Record<string, { label: string; tone: string }> = {
  unfulfilled: { label: 'Not shipped', tone: 'neutral' },
  packed: { label: 'Packed', tone: 'info' },
  shipped: { label: 'Shipped', tone: 'warn' },
  delivered: { label: 'Delivered', tone: 'ok' },
};

/** Fulfilment pill for the orders list ("—" when the order will never ship). */
export function ShippingPill({ order }: { order: OrderListRow }) {
  if (['cancelled', 'refunded', 'failed'].includes(order.status)) return <span className="bk-muted">—</span>;
  const pill = SHIPPING_PILL[order.fulfillment?.status ?? 'unfulfilled'] ?? SHIPPING_PILL.unfulfilled!;
  return <span className={`bk-shop-pill is-${pill.tone}`}>{pill.label}</span>;
}

/** Order status as a colored pill (shared by the order screens and the overview). */
export function StatusPill({ status, label }: { status: OrderStatus | string; label: string }) {
  const tone = ORDER_STATUS_TONE[status as OrderStatus] ?? 'neutral';
  return <span className={`bk-shop-pill is-${tone}`}>{label}</span>;
}

export const PAYMENT_STATUS_LABELS: Record<string, string> = {
  unpaid: 'Unpaid',
  paid: 'Paid',
  partially_refunded: 'Partially refunded',
  refunded: 'Refunded',
  failed: 'Failed',
};

/** Prev / next pager for server-paginated lists. */
export function Pager({
  page,
  pages,
  total,
  perPage,
  onPage,
  noun,
}: {
  page: number;
  pages: number;
  total: number;
  perPage: number;
  onPage: (page: number) => void;
  noun: string;
}) {
  if (total === 0) return null;
  const from = (page - 1) * perPage + 1;
  const to = Math.min(total, page * perPage);
  return (
    <div className="bk-shop-pager">
      <span>
        {from}–{to} of {total} {noun}
      </span>
      <div className="bk-shop-pager__buttons">
        <button type="button" className="button" disabled={page <= 1} onClick={() => onPage(page - 1)}>
          ‹ Previous
        </button>
        <span style={{ padding: '0 8px', alignSelf: 'center' }}>
          Page {page} of {pages}
        </span>
        <button type="button" className="button" disabled={page >= pages} onClick={() => onPage(page + 1)}>
          Next ›
        </button>
      </div>
    </div>
  );
}

const STATUS_ORDER: OrderStatus[] = ['pending', 'on-hold', 'processing', 'completed', 'cancelled', 'refunded', 'failed'];

export function OrdersPage() {
  const href = useAdminHref();
  const navigate = useNavigate();
  const meta = useShopMeta();
  const [params, setParams] = useSearchParams();
  const status = params.get('status') ?? 'all';
  const q = params.get('q') ?? '';
  const payment = params.get('payment') ?? '';
  const customerId = params.get('customerId') ?? '';
  const page = Math.max(1, Number(params.get('page') ?? '1') || 1);

  const [data, setData] = useState<OrderList | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [customer, setCustomer] = useState<Customer | null>(null);

  const setParam = (patch: Record<string, string | null>) => {
    const next = new URLSearchParams(params);
    for (const [k, v] of Object.entries(patch)) {
      if (v === null || v === '') next.delete(k);
      else next.set(k, v);
    }
    if (!('page' in patch)) next.delete('page');
    // Typing does not fill the browser history with every letter.
    setParams(next, { replace: 'q' in patch && Object.keys(patch).length === 1 });
  };

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api<OrderList>(
      `/api/shop/orders${buildQuery({ status: status === 'all' ? undefined : status, q, payment, customerId, page, perPage: 25 })}`,
    )
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch((e) => {
        if (!cancelled) setError(formatError(e));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [status, q, payment, customerId, page]);

  useEffect(() => {
    if (!customerId) {
      setCustomer(null);
      return;
    }
    let cancelled = false;
    api<Customer>(`/api/shop/customers/${encodeURIComponent(customerId)}`)
      .then((c) => {
        if (!cancelled) setCustomer(c);
      })
      .catch(() => {
        if (!cancelled) setCustomer(null);
      });
    return () => {
      cancelled = true;
    };
  }, [customerId]);

  const counts = data?.counts ?? {};
  const statusLabel = (id: OrderStatus) => data?.statuses.find((s) => s.id === id)?.label ?? id;
  const rows = data?.items ?? [];
  const hasFilters = Boolean(q || payment || customerId || status !== 'all');

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Orders"
        actions={
          hasFilters ? (
            <button type="button" className="button" onClick={() => setParams(new URLSearchParams())}>
              Clear filters
            </button>
          ) : null
        }
      />
      <p className="bk-muted">Every order placed in your shop. Click an order to manage it.</p>
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}

      <nav className="bk-tabs" aria-label="Order status">
        {(['all', ...STATUS_ORDER] as const).map((s) => (
          <button
            key={s}
            type="button"
            className={`bk-tabs__item${status === s ? ' is-active' : ''}`}
            aria-current={status === s ? 'page' : undefined}
            onClick={() => setParam({ status: s === 'all' ? null : s })}
          >
            {s === 'all' ? 'All' : statusLabel(s)}
            <span className="bk-tabs__count">{counts[s] ?? 0}</span>
          </button>
        ))}
      </nav>

      <div className="bk-shop-toolbar">
        <LiveSearch
          value={q}
          onSearch={(text) => setParam({ q: text })}
          placeholder="Search order number, email or name…"
          label="Search orders"
        />
        <select value={payment} onChange={(e) => setParam({ payment: e.target.value })} aria-label="Payment method">
          <option value="">All payment methods</option>
          {(meta?.paymentMethods ?? []).map((m) => (
            <option key={m.id} value={m.id}>
              {m.title}
            </option>
          ))}
        </select>
        {customerId ? (
          <span className="bk-shop-filter-chip">
            Showing orders for {customer?.email ?? 'this customer'}
            <button type="button" onClick={() => setParam({ customerId: null })} aria-label="Clear customer filter">
              ✕
            </button>
          </span>
        ) : null}
        <span className="bk-shop-toolbar__spacer" />
        {data ? <span className="bk-shop-toolbar__count">{data.total} {data.total === 1 ? 'order' : 'orders'}</span> : null}
      </div>

      <div className="bk-shop-table-wrap">
        <table className="bk-shop-table">
          <thead>
            <tr>
              <th scope="col">Order</th>
              <th scope="col">Date</th>
              <th scope="col">Status</th>
              <th scope="col">Payment</th>
              <th scope="col">Shipping</th>
              <th scope="col" className="is-right">
                Items
              </th>
              <th scope="col" className="is-right">
                Total
              </th>
            </tr>
          </thead>
          <tbody>
            {loading && !data ? (
              <tr>
                <td colSpan={7} className="bk-shop-table__empty">
                  Loading…
                </td>
              </tr>
            ) : rows.length === 0 ? (
              <tr>
                <td colSpan={7} className="bk-shop-table__empty">
                  {hasFilters ? 'No orders match these filters.' : 'No orders yet. They appear here as soon as someone checks out.'}
                </td>
              </tr>
            ) : (
              rows.map((o) => (
                <tr key={o.id} className="is-clickable" onClick={() => navigate(href(`shop/orders/${o.id}`))}>
                  <td>
                    <Link className="bk-shop-table__primary" to={href(`shop/orders/${o.id}`)} onClick={(e) => e.stopPropagation()}>
                      {o.numberLabel} {o.customerName}
                    </Link>
                    <span className="bk-shop-table__sub">{o.email}</span>
                  </td>
                  <td>{formatDate(o.placedAt)}</td>
                  <td>
                    <StatusPill status={o.status} label={o.statusLabel} />
                  </td>
                  <td>
                    {o.paymentMethodTitle}
                    <span className="bk-shop-table__sub">{PAYMENT_STATUS_LABELS[o.paymentStatus] ?? o.paymentStatus}</span>
                  </td>
                  <td>
                    <ShippingPill order={o} />
                  </td>
                  <td className="is-right">{o.itemCount}</td>
                  <td className="is-right bk-shop-money">
                    {o.formatted.total}
                    {o.refundedTotal > 0 ? <span className="bk-shop-table__sub">−{o.formatted.refundedTotal} refunded</span> : null}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      {data ? (
        <Pager page={data.page} pages={data.pages} total={data.total} perPage={data.perPage} onPage={(p) => setParam({ page: String(p) })} noun="orders" />
      ) : null}
    </div>
  );
}
