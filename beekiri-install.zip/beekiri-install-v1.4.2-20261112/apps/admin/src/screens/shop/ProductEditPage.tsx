import { Fragment, useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  ArrowSquareOut,
  CaretDown,
  CaretRight,
  Image as ImageIcon,
  Plus,
  Trash,
} from '@phosphor-icons/react';
import { api } from '../../api/client';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { RichEditor } from '../../components/RichEditor';
import { SuccessNotice } from '../../components/SuccessNotice';
import { MediaPicker, type MediaItem } from '../../editor/beekiricode/inspector/MediaPicker';
import { useAdminHref } from '../../lib/AdminEntryContext';
import { SITE_URL } from '../../config';
import {
  shopError,
  formatDate,
  moneyToInput,
  parseMoney,
  useShopMeta,
  type MediaRef,
  type Product,
  type ProductAttribute,
  type ProductPatch,
  type ProductVariant,
  type ShopMeta,
  type StockStatus,
  type TermList,
} from './api';
import './shop.css';
import './products.css';

const formatError = shopError;

/* ── Small pieces ────────────────────────────────────────────────────── */

/** One row of "More details": its title and what is set now; opens to the fields. */
function Fold({ id, title, summary, open, onToggle, children }: { id: string; title: string; summary: string; open: Set<string>; onToggle: (id: string) => void; children: ReactNode }) {
  const isOpen = open.has(id);
  return (
    <div className={`bk-prod-fold${isOpen ? ' is-open' : ''}`}>
      <button type="button" className="bk-prod-fold__head" aria-expanded={isOpen} onClick={() => onToggle(id)}>
        {isOpen ? <CaretDown size={14} aria-hidden /> : <CaretRight size={14} aria-hidden />}
        <strong>{title}</strong>
        {!isOpen ? <span className="bk-prod-fold__summary">{summary}</span> : null}
      </button>
      {isOpen ? <div className="bk-prod-fold__body">{children}</div> : null}
    </div>
  );
}

/** Rich text as one plain line (for a row's summary). */
const plain = (html: string) => {
  const text = html.replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
  return text.length > 90 ? `${text.slice(0, 90)}…` : text;
};

const STOCK_LABEL: Record<StockStatus, string> = { instock: 'In stock', outofstock: 'Out of stock', onbackorder: 'On backorder' };
const VISIBILITY_LABEL: Record<Product['commerce']['catalogVisibility'], string> = {
  visible: 'In shop and search',
  catalog: 'Shop only',
  search: 'Search only',
  hidden: 'Hidden',
};

/** Values as chips: type one and press Enter (or a comma); Backspace takes the last one back. */
function ChipInput({ values, onChange, placeholder, id }: { values: string[]; onChange: (v: string[]) => void; placeholder?: string; id?: string }) {
  const [text, setText] = useState('');
  const add = (raw: string) => {
    const parts = raw.split(/[|,]/).map((s) => s.trim()).filter(Boolean);
    setText('');
    if (parts.length) onChange([...new Set([...values, ...parts])]);
  };
  return (
    <div className="bk-prod-chipinput">
      {values.map((v) => (
        <span key={v} className="bk-shop-chip">
          {v}
          <button type="button" aria-label={`Remove ${v}`} onClick={() => onChange(values.filter((x) => x !== v))}>
            ×
          </button>
        </span>
      ))}
      <input
        id={id}
        type="text"
        value={text}
        placeholder={values.length ? 'Add another…' : placeholder}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ',') {
            e.preventDefault();
            add(text);
          } else if (e.key === 'Backspace' && !text && values.length) {
            onChange(values.slice(0, -1));
          }
        }}
        onBlur={() => add(text)}
      />
    </div>
  );
}

/* ── Small inputs ────────────────────────────────────────────────────── */

function MoneyInput({ value, onChange, meta, id, placeholder }: { value: number | null; onChange: (v: number | null) => void; meta: ShopMeta | null; id?: string; placeholder?: string }) {
  const currency = meta?.currency ?? 'EUR';
  const [text, setText] = useState(moneyToInput(value, currency, meta?.currencies));
  useEffect(() => setText(moneyToInput(value, currency, meta?.currencies)), [value, currency, meta?.currencies]);
  const symbol = meta?.currencies.find((c) => c.code === currency)?.symbol ?? currency;
  return (
    <div className="bk-shop-prefix">
      <span>{symbol}</span>
      <input
        id={id}
        type="text"
        inputMode="decimal"
        value={text}
        placeholder={placeholder ?? '0.00'}
        onChange={(e) => setText(e.target.value)}
        onBlur={() => {
          const parsed = parseMoney(text, currency, meta?.currencies);
          onChange(parsed);
          setText(moneyToInput(parsed, currency, meta?.currencies));
        }}
      />
    </div>
  );
}

function IntInput({ value, onChange, id, min = 0, placeholder }: { value: number | null; onChange: (v: number | null) => void; id?: string; min?: number; placeholder?: string }) {
  return (
    <input
      id={id}
      type="number"
      min={min}
      step={1}
      value={value ?? ''}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value === '' ? null : Math.max(min, Math.trunc(Number(e.target.value) || 0)))}
    />
  );
}

function toLocalInput(iso: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function fromLocalInput(v: string): string | null {
  if (!v) return null;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

const slugify = (s: string) =>
  s
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 120);

/* ── Variations helpers ──────────────────────────────────────────────── */

function variationAttributes(attrs: ProductAttribute[]) {
  return attrs.filter((a) => a.variation && a.name.trim() && a.options.length);
}

function combinations(attrs: ProductAttribute[]): Record<string, string>[] {
  let out: Record<string, string>[] = [{}];
  for (const a of attrs) {
    const next: Record<string, string>[] = [];
    for (const combo of out) for (const opt of a.options) next.push({ ...combo, [a.name]: opt });
    out = next;
  }
  return out;
}

const signature = (attrs: Record<string, string>) =>
  Object.keys(attrs)
    .sort()
    .map((k) => `${k}=${attrs[k]}`)
    .join('|');

/* ── Term checklist (categories) ─────────────────────────────────────── */

function TermChecklist({
  taxonomyId,
  selected,
  onChange,
  onError,
  label,
  singular,
}: {
  taxonomyId: string | null;
  selected: string[];
  onChange: (ids: string[]) => void;
  onError: (m: string) => void;
  label: string;
  singular: string;
}) {
  const [terms, setTerms] = useState<TermList['terms']>([]);
  const [draft, setDraft] = useState('');
  const [adding, setAdding] = useState(false);
  const reload = useCallback(() => {
    if (!taxonomyId) return;
    api<TermList>(`/api/fields/taxonomies/${taxonomyId}/terms`)
      .then((r) => setTerms(r.terms))
      .catch(() => setTerms([]));
  }, [taxonomyId]);
  useEffect(reload, [reload]);
  const tree = useMemo(() => {
    const byParent = new Map<string | null, TermList['terms']>();
    for (const t of terms) byParent.set(t.parentId, [...(byParent.get(t.parentId) ?? []), t]);
    const out: { term: TermList['terms'][number]; depth: number }[] = [];
    const walk = (p: string | null, depth: number) => {
      for (const t of byParent.get(p) ?? []) {
        out.push({ term: t, depth });
        walk(t.id, depth + 1);
      }
    };
    walk(null, 0);
    return out;
  }, [terms]);
  const add = async () => {
    const name = draft.trim();
    if (!name || !taxonomyId) return;
    setAdding(true);
    try {
      const created = await api<{ id: string }>(`/api/fields/taxonomies/${taxonomyId}/terms`, { json: { name } });
      setDraft('');
      onChange([...selected, created.id]);
      reload();
    } catch (e) {
      onError(formatError(e));
    } finally {
      setAdding(false);
    }
  };
  if (!taxonomyId) return <p className="bk-muted">Not available.</p>;
  return (
    <>
      <ul className="bk-shop-terms">
        {tree.length === 0 ? <li className="bk-muted">No {label.toLowerCase()} yet.</li> : null}
        {tree.map(({ term, depth }) => (
          <li key={term.id} className={depth ? 'is-child' : ''} style={depth > 1 ? { paddingLeft: depth * 18 } : undefined}>
            <label>
              <input
                type="checkbox"
                checked={selected.includes(term.id)}
                onChange={(e) => onChange(e.target.checked ? [...selected, term.id] : selected.filter((id) => id !== term.id))}
              />
              {term.name}
            </label>
          </li>
        ))}
      </ul>
      <div className="bk-shop-terms__add">
        <input
          type="text"
          placeholder={`New ${singular.toLowerCase()}…`}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              void add();
            }
          }}
        />
        <button type="button" className="button" disabled={adding || !draft.trim()} onClick={() => void add()}>
          Add
        </button>
      </div>
    </>
  );
}

function TagInput({
  taxonomyId,
  selected,
  onChange,
  onError,
}: {
  taxonomyId: string | null;
  selected: string[];
  onChange: (ids: string[]) => void;
  onError: (m: string) => void;
}) {
  const [terms, setTerms] = useState<TermList['terms']>([]);
  const [draft, setDraft] = useState('');
  const reload = useCallback(() => {
    if (!taxonomyId) return;
    api<TermList>(`/api/fields/taxonomies/${taxonomyId}/terms`)
      .then((r) => setTerms(r.terms))
      .catch(() => setTerms([]));
  }, [taxonomyId]);
  useEffect(reload, [reload]);
  const byId = new Map(terms.map((t) => [t.id, t]));
  const add = async () => {
    const name = draft.trim();
    if (!name || !taxonomyId) return;
    const existing = terms.find((t) => t.name.toLowerCase() === name.toLowerCase());
    if (existing) {
      if (!selected.includes(existing.id)) onChange([...selected, existing.id]);
      setDraft('');
      return;
    }
    try {
      const created = await api<{ id: string }>(`/api/fields/taxonomies/${taxonomyId}/terms`, { json: { name } });
      onChange([...selected, created.id]);
      setDraft('');
      reload();
    } catch (e) {
      onError(formatError(e));
    }
  };
  const suggestions = terms.filter((t) => !selected.includes(t.id) && (!draft || t.name.toLowerCase().includes(draft.toLowerCase()))).slice(0, 12);
  if (!taxonomyId) return <p className="bk-muted">Not available.</p>;
  return (
    <>
      <div className="bk-shop-chips">
        {selected.map((id) => (
          <span key={id} className="bk-shop-chip">
            {byId.get(id)?.name ?? '…'}
            <button type="button" aria-label="Remove tag" onClick={() => onChange(selected.filter((s) => s !== id))}>
              ×
            </button>
          </span>
        ))}
        {selected.length === 0 ? <span className="bk-muted">No tags.</span> : null}
      </div>
      <div className="bk-prod-tags__input">
        <input
          type="text"
          placeholder="Add a tag…"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              void add();
            }
          }}
        />
        <button type="button" className="button" disabled={!draft.trim()} onClick={() => void add()}>
          Add
        </button>
      </div>
      {suggestions.length ? (
        <ul className="bk-prod-tags__suggest">
          {suggestions.map((t) => (
            <li key={t.id}>
              <button type="button" onClick={() => onChange([...selected, t.id])}>
                {t.name}
              </button>
            </li>
          ))}
        </ul>
      ) : null}
    </>
  );
}

/* ── New product: create a draft and open it ─────────────────────────── */

export function ProductNewRedirect() {
  const navigate = useNavigate();
  const href = useAdminHref();
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    api<Product>('/api/shop/products', { json: { title: '', status: 'draft' } })
      .then((p) => navigate(href(`shop/products/${p.id}`), { replace: true }))
      .catch((e) => setError(formatError(e)));
  }, [navigate, href]);
  return (
    <div className="wrap">
      <PageHeader title="New product" />
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : <p className="bk-muted">Creating…</p>}
    </div>
  );
}

/* ── Editor ──────────────────────────────────────────────────────────── */

type Draft = {
  title: string;
  slug: string;
  description: string;
  shortDescription: string;
  featuredImageId: string | null;
  image: MediaRef | null;
  commerce: Product['commerce'];
  variants: ProductVariant[];
  categoryIds: string[];
  tagIds: string[];
};

function draftFrom(p: Product): Draft {
  return {
    title: p.title,
    slug: p.slug,
    description: p.description,
    shortDescription: p.shortDescription,
    featuredImageId: p.featuredImageId,
    image: p.image,
    commerce: { ...p.commerce, attributes: p.commerce.attributes.map((a) => ({ ...a, options: [...a.options] })) },
    variants: p.variants.map((v) => ({ ...v, attributes: { ...v.attributes } })),
    categoryIds: [...p.categoryIds],
    tagIds: [...p.tagIds],
  };
}

function toMediaRef(m: MediaItem): MediaRef {
  return { id: m.id, url: m.url, alt: m.alt, width: m.width ?? null, height: m.height ?? null };
}

export function ProductEditPage() {
  const { id = '' } = useParams();
  const navigate = useNavigate();
  const href = useAdminHref();
  const meta = useShopMeta();
  const [product, setProduct] = useState<Product | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [baseline, setBaseline] = useState('');
  /** Which rows of "More details" are open. */
  const [folds, setFolds] = useState<Set<string>>(new Set());
  const toggleFold = (key: string) =>
    setFolds((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  /** The sale dates stay folded away until asked for (or already set). */
  const [showSchedule, setShowSchedule] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [picker, setPicker] = useState<'image' | 'gallery' | { variant: number } | null>(null);
  const [openVariants, setOpenVariants] = useState<Set<number>>(new Set());
  /** "Same price for all" above the variations table. */
  const [bulkPrice, setBulkPrice] = useState<number | null>(null);
  const [slugEdit, setSlugEdit] = useState(false);

  const load = useCallback(async () => {
    try {
      const p = await api<Product>(`/api/shop/products/${id}`);
      setProduct(p);
      const d = draftFrom(p);
      setDraft(d);
      setBaseline(JSON.stringify(d));
    } catch (e) {
      setError(formatError(e));
    }
  }, [id]);
  useEffect(() => {
    void load();
  }, [load]);

  const dirty = draft !== null && JSON.stringify(draft) !== baseline;
  useEffect(() => {
    if (!dirty) return;
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
    };
    window.addEventListener('beforeunload', onBeforeUnload);
    return () => window.removeEventListener('beforeunload', onBeforeUnload);
  }, [dirty]);

  const update = (patch: Partial<Draft>) => setDraft((d) => (d ? { ...d, ...patch } : d));
  const updateCommerce = (patch: Partial<Product['commerce']>) => setDraft((d) => (d ? { ...d, commerce: { ...d.commerce, ...patch } } : d));
  const updateVariant = (index: number, patch: Partial<ProductVariant>) =>
    setDraft((d) => (d ? { ...d, variants: d.variants.map((v, i) => (i === index ? { ...v, ...patch } : v)) } : d));

  const save = async (status?: 'draft' | 'publish') => {
    if (!draft || !product) return;
    setBusy(true);
    setError(null);
    try {
      const body: ProductPatch = {
        title: draft.title,
        slug: draft.slug,
        description: draft.description,
        shortDescription: draft.shortDescription,
        featuredImageId: draft.featuredImageId ?? '',
        commerce: {
          type: draft.commerce.type,
          sku: draft.commerce.sku,
          regularPrice: draft.commerce.regularPrice,
          salePrice: draft.commerce.salePrice,
          saleFrom: draft.commerce.saleFrom,
          saleTo: draft.commerce.saleTo,
          manageStock: draft.commerce.manageStock,
          stockQty: draft.commerce.stockQty,
          stockStatus: draft.commerce.stockStatus,
          lowStockThreshold: draft.commerce.lowStockThreshold,
          soldIndividually: draft.commerce.soldIndividually,
          weight: draft.commerce.weight,
          length: draft.commerce.length,
          width: draft.commerce.width,
          height: draft.commerce.height,
          virtual: draft.commerce.virtual,
          taxable: draft.commerce.taxable,
          galleryIds: draft.commerce.galleryIds,
          attributes: draft.commerce.attributes.filter((a) => a.name.trim()).map((a) => ({ ...a, name: a.name.trim(), options: a.options.filter(Boolean) })),
          purchaseNote: draft.commerce.purchaseNote,
          featured: draft.commerce.featured,
          catalogVisibility: draft.commerce.catalogVisibility,
        },
        variants: draft.variants.map(({ image: _img, ...v }) => v),
        categoryIds: draft.categoryIds,
        tagIds: draft.tagIds,
      };
      if (status) body.status = status;
      const saved = await api<Product>(`/api/shop/products/${id}`, { method: 'PATCH', json: body });
      setProduct(saved);
      const d = draftFrom(saved);
      setDraft(d);
      setBaseline(JSON.stringify(d));
      setNotice(status === 'publish' ? 'Product published.' : saved.status === 'publish' ? 'Product updated.' : 'Draft saved.');
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const trash = async () => {
    if (!product) return;
    const ok = await confirmDialog({ title: 'Move this product to trash?', message: 'You can restore it from the Trash view later.', confirmLabel: 'Move to trash', danger: true });
    if (!ok) return;
    setBusy(true);
    try {
      await api(`/api/shop/products/${id}`, { method: 'DELETE' });
      navigate(href('shop/products'));
    } catch (e) {
      setError(formatError(e));
      setBusy(false);
    }
  };

  const generateVariations = () => {
    if (!draft) return;
    const attrs = variationAttributes(draft.commerce.attributes);
    if (!attrs.length) {
      setError('Add at least one attribute with "Used for variations" and some options first.');
      return;
    }
    const existing = new Map(draft.variants.map((v) => [signature(v.attributes), v]));
    const next: ProductVariant[] = combinations(attrs).map((combo, i) => {
      const found = existing.get(signature(combo));
      return (
        found ?? {
          sku: '',
          attributes: combo,
          regularPrice: draft.commerce.regularPrice,
          salePrice: null,
          saleFrom: null,
          saleTo: null,
          manageStock: false,
          stockQty: null,
          stockStatus: 'instock' as StockStatus,
          weight: null,
          imageId: null,
          image: null,
          enabled: true,
          menuOrder: i,
        }
      );
    });
    update({ variants: next });
    setNotice(`${next.length} variation${next.length === 1 ? '' : 's'} ready. Set prices and stock, then save.`);
  };

  if (error && !draft) {
    return (
      <div className="wrap">
        <PageHeader title="Product" />
        <ErrorNotice message={error} onDismiss={() => setError(null)} />
        <p>
          <Link to={href('shop/products')}>Back to products</Link>
        </p>
      </div>
    );
  }
  if (!draft || !product) {
    return (
      <div className="wrap">
        <PageHeader title="Product" />
        <p className="bk-muted">Loading…</p>
      </div>
    );
  }

  const c = draft.commerce;
  const isVariable = c.type === 'variable';
  const published = product.status === 'publish';
  const viewUrl = `${SITE_URL}${product.path}`;
  const scheduleOpen = showSchedule || Boolean(c.saleFrom || c.saleTo);
  const saving = c.regularPrice && c.salePrice !== null && c.salePrice < c.regularPrice ? Math.round(100 * (1 - c.salePrice / c.regularPrice)) : 0;

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title={draft.title.trim() || 'New product'}
        actions={
          <>
            <Link to={href('shop/products')} className="button">
              ← All products
            </Link>
            {published ? (
              <a className="button" href={viewUrl} target="_blank" rel="noopener noreferrer">
                View <ArrowSquareOut size={13} aria-hidden />
              </a>
            ) : null}
          </>
        }
      />
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <form
        className="bk-shop-editor"
        onSubmit={(e) => {
          e.preventDefault();
          void save();
        }}
      >
        <div className="bk-shop-editor__main">
          <div className="bk-panel">
            <div className="bk-panel__body">
              <div className="bk-shop-field">
                <label htmlFor="p-title">Product name</label>
                <input
                  id="p-title"
                  type="text"
                  className="regular-text bk-prod-title"
                  placeholder="e.g. Oversized Tee, Ochre"
                  value={draft.title}
                  onChange={(e) => {
                    const title = e.target.value;
                    update({ title, ...(product.slug.startsWith('auto-draft') && !slugEdit ? { slug: slugify(title) } : {}) });
                  }}
                  autoFocus={!product.title}
                />
                <div className="bk-prod-permalink">
                  <span>Link:</span>
                  {slugEdit ? (
                    <>
                      <input type="text" value={draft.slug} onChange={(e) => update({ slug: slugify(e.target.value) })} aria-label="Link ending" />
                      <button type="button" className="button" onClick={() => setSlugEdit(false)}>
                        OK
                      </button>
                    </>
                  ) : (
                    <>
                      <code>/product/{draft.slug || '…'}</code>
                      <button type="button" className="button-link" onClick={() => setSlugEdit(true)}>
                        Edit
                      </button>
                    </>
                  )}
                </div>
              </div>
              {isVariable ? (
                <p className="bk-shop-note is-info">Each version has its own price. Set them under Options and variations below.</p>
              ) : (
                <div className="bk-shop-row">
                  <div className="bk-shop-field">
                    <label htmlFor="p-regular">Regular price</label>
                    <MoneyInput id="p-regular" value={c.regularPrice} onChange={(v) => updateCommerce({ regularPrice: v })} meta={meta} />
                  </div>
                  <div className="bk-shop-field">
                    <label htmlFor="p-sale">Sale price</label>
                    <MoneyInput id="p-sale" value={c.salePrice} onChange={(v) => updateCommerce({ salePrice: v })} meta={meta} placeholder="Optional" />
                  </div>
                </div>
              )}
              {!isVariable && saving ? <p className="bk-prod-saving">Customers save {saving}%.</p> : null}
              {!isVariable && !scheduleOpen ? (
                <p className="bk-prod-more">
                  <button type="button" className="button-link" onClick={() => setShowSchedule(true)}>
                    Schedule the sale
                  </button>
                </p>
              ) : null}
              {!isVariable && scheduleOpen ? (
                <div className="bk-shop-row">
                  <div className="bk-shop-field">
                    <label htmlFor="p-sale-from">Sale starts</label>
                    <input id="p-sale-from" type="datetime-local" value={toLocalInput(c.saleFrom)} onChange={(e) => updateCommerce({ saleFrom: fromLocalInput(e.target.value) })} />
                    <p className="description">Leave empty to start immediately.</p>
                  </div>
                  <div className="bk-shop-field">
                    <label htmlFor="p-sale-to">Sale ends</label>
                    <input id="p-sale-to" type="datetime-local" value={toLocalInput(c.saleTo)} onChange={(e) => updateCommerce({ saleTo: fromLocalInput(e.target.value) })} />
                    <p className="description">Leave empty to run until you remove the sale price.</p>
                  </div>
                </div>
              ) : null}
              <div className="bk-shop-field bk-prod-last">
                <label>Description</label>
                <RichEditor value={draft.description} onChange={(v) => update({ description: v })} placeholder="Describe the product: what it is, what it is made of, how it fits…" label="Description" />
              </div>
            </div>
          </div>

          <div className="bk-panel bk-prod-folds">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">More details</h2>
              <span className="bk-prod-folds__hint">All optional. Open what you need.</span>
            </div>
            <Fold id="short" title="Short description" summary={plain(draft.shortDescription) || 'None'} open={folds} onToggle={toggleFold}>
              <RichEditor short value={draft.shortDescription} onChange={(v) => update({ shortDescription: v })} placeholder="A sentence or two shown next to the price…" label="Short description" />
            </Fold>
            <Fold
              id="inventory"
              title="Inventory"
              summary={[c.sku ? `SKU ${c.sku}` : 'No SKU', c.manageStock ? `${c.stockQty ?? 0} in stock` : STOCK_LABEL[c.stockStatus]].join(' · ')}
              open={folds}
              onToggle={toggleFold}
            >
              <div className="bk-shop-field">
                <label htmlFor="p-sku">SKU</label>
                <input id="p-sku" type="text" value={c.sku} onChange={(e) => updateCommerce({ sku: e.target.value })} placeholder="e.g. HOODIE-001" />
                <p className="description">Stock keeping unit — a unique reference for this product.</p>
              </div>
              <div className="bk-shop-field">
                <label className="bk-check">
                  <input type="checkbox" checked={c.manageStock} onChange={(e) => updateCommerce({ manageStock: e.target.checked, stockQty: e.target.checked ? (c.stockQty ?? 0) : null })} /> <span className="bk-check__box" aria-hidden />
                  <span>Track stock quantity {isVariable ? 'at product level (variations can override)' : 'for this product'}</span>
                </label>
              </div>
              {c.manageStock ? (
                <div className="bk-shop-row">
                  <div className="bk-shop-field">
                    <label htmlFor="p-qty">Quantity</label>
                    <IntInput id="p-qty" value={c.stockQty} onChange={(v) => updateCommerce({ stockQty: v ?? 0 })} />
                  </div>
                  <div className="bk-shop-field">
                    <label htmlFor="p-low">Low stock threshold</label>
                    <IntInput id="p-low" value={c.lowStockThreshold} onChange={(v) => updateCommerce({ lowStockThreshold: v })} placeholder={String(meta?.lowStockThreshold ?? 2)} />
                  </div>
                  <div className="bk-shop-field">
                    <label htmlFor="p-backorder">When out of stock</label>
                    <select id="p-backorder" value={c.stockStatus === 'onbackorder' ? 'onbackorder' : 'instock'} onChange={(e) => updateCommerce({ stockStatus: e.target.value as StockStatus })}>
                      <option value="instock">Do not allow orders</option>
                      <option value="onbackorder">Allow backorders</option>
                    </select>
                  </div>
                </div>
              ) : (
                <div className="bk-shop-field">
                  <label htmlFor="p-stock">Stock status</label>
                  <select id="p-stock" value={c.stockStatus} onChange={(e) => updateCommerce({ stockStatus: e.target.value as StockStatus })}>
                    <option value="instock">In stock</option>
                    <option value="outofstock">Out of stock</option>
                    <option value="onbackorder">On backorder</option>
                  </select>
                </div>
              )}
              <div className="bk-shop-field">
                <label className="bk-check">
                  <input type="checkbox" checked={c.soldIndividually} onChange={(e) => updateCommerce({ soldIndividually: e.target.checked })} /> <span className="bk-check__box" aria-hidden />
                  <span>Sold individually — limit to one per order</span>
                </label>
              </div>
            </Fold>
            <Fold id="shipping" title="Shipping" summary={c.virtual ? 'No shipping needed' : c.weight ? `Physical product · ${c.weight} g` : 'Physical product'} open={folds} onToggle={toggleFold}>
              <div className="bk-shop-field">
                <label className="bk-check">
                  <input type="checkbox" checked={!c.virtual} onChange={(e) => updateCommerce({ virtual: !e.target.checked })} /> <span className="bk-check__box" aria-hidden />
                  <span>This is a physical product that needs shipping</span>
                </label>
              </div>
              {!c.virtual ? (
                <>
                <div className="bk-shop-field">
                  <label htmlFor="p-weight">Weight (g)</label>
                  <IntInput id="p-weight" value={c.weight} onChange={(v) => updateCommerce({ weight: v })} placeholder="e.g. 450" />
                </div>
                <div className="bk-shop-row">
                  <div className="bk-shop-field">
                    <label htmlFor="p-length">Length (mm)</label>
                    <IntInput id="p-length" value={c.length} onChange={(v) => updateCommerce({ length: v })} />
                  </div>
                  <div className="bk-shop-field">
                    <label htmlFor="p-width">Width (mm)</label>
                    <IntInput id="p-width" value={c.width} onChange={(v) => updateCommerce({ width: v })} />
                  </div>
                  <div className="bk-shop-field">
                    <label htmlFor="p-height">Height (mm)</label>
                    <IntInput id="p-height" value={c.height} onChange={(v) => updateCommerce({ height: v })} />
                  </div>
                </div>
                <p className="description">Shipping rates are configured per zone in Shop → Settings → Shipping.</p>
                </>
              ) : (
                <p className="description bk-prod-last">Nothing to ship: a service, a download or a booking.</p>
              )}
            </Fold>
            <Fold
              id="options"
              title="Options and variations"
              summary={
                c.attributes.filter((x) => x.name.trim()).length
                  ? `${c.attributes.filter((x) => x.name.trim()).map((x) => `${x.name}: ${x.options.join(', ') || '—'}`).join(' · ')}${isVariable ? ` · ${draft.variants.length} variation${draft.variants.length === 1 ? '' : 's'}` : ''}`
                  : 'None. Add sizes, colours or materials'
              }
              open={folds}
              onToggle={toggleFold}
            >
              <div className="bk-shop-field">
                <label className="bk-check">
                  <input type="checkbox" checked={isVariable} onChange={(e) => updateCommerce({ type: e.target.checked ? 'variable' : 'simple' })} /> <span className="bk-check__box" aria-hidden />
                  <span>This product comes in different versions, each with its own price or stock</span>
                </label>
              </div>
              {c.attributes.map((a, index) => (
                <div key={index} className="bk-shop-attr">
                  <div className="bk-shop-attr__head">
                    <strong>{a.name || 'New option'}</strong>
                    <label className="bk-check">
                      <input type="checkbox" checked={a.visible} onChange={(e) => updateCommerce({ attributes: c.attributes.map((x, i) => (i === index ? { ...x, visible: e.target.checked } : x)) })} /> <span className="bk-check__box" aria-hidden />
                      <span>Visible on the product page</span>
                    </label>
                    {isVariable ? (
                      <label className="bk-check">
                        <input type="checkbox" checked={a.variation} onChange={(e) => updateCommerce({ attributes: c.attributes.map((x, i) => (i === index ? { ...x, variation: e.target.checked } : x)) })} /> <span className="bk-check__box" aria-hidden />
                        <span>Customers choose this (makes variations)</span>
                      </label>
                    ) : null}
                    <button type="button" className="button" onClick={() => updateCommerce({ attributes: c.attributes.filter((_, i) => i !== index) })} aria-label="Remove attribute">
                      <Trash size={14} aria-hidden /> Remove
                    </button>
                  </div>
                  <div className="bk-shop-attr__body bk-shop-row">
                    <div className="bk-shop-field">
                      <label htmlFor={`attr-name-${index}`}>Name</label>
                      <input id={`attr-name-${index}`} type="text" value={a.name} placeholder="e.g. Size" onChange={(e) => updateCommerce({ attributes: c.attributes.map((x, i) => (i === index ? { ...x, name: e.target.value } : x)) })} />
                    </div>
                    <div className="bk-shop-field bk-prod-options">
                      <label htmlFor={`attr-opts-${index}`}>Values</label>
                      <ChipInput
                        id={`attr-opts-${index}`}
                        values={a.options}
                        placeholder="Type a value and press Enter, e.g. Small"
                        onChange={(options) => updateCommerce({ attributes: c.attributes.map((x, i) => (i === index ? { ...x, options } : x)) })}
                      />
                    </div>
                  </div>
                </div>
              ))}
              <button type="button" className="button" onClick={() => updateCommerce({ attributes: [...c.attributes, { name: '', options: [], visible: true, variation: isVariable }] })}>
                <Plus size={13} weight="bold" aria-hidden /> Add an option
              </button>
              {isVariable ? (
                <div className="bk-prod-variations">
                  <h3 className="bk-prod-subtitle">
                    Variations <span className="bk-tabs__count">{draft.variants.length}</span>
                  </h3>
                  <p className="description">One row per version a customer can buy. Type prices and stock straight into the table.</p>
              <div className="bk-prod-var-bar">
                <div className="bk-prod-var__attrs">
                  {variationAttributes(c.attributes).length ? (
                    variationAttributes(c.attributes).map((a) => (
                      <span key={a.name}>
                        {a.name}: {a.options.join(', ')}
                      </span>
                    ))
                  ) : (
                    <span className="bk-muted">Add an option above (like Size) with its values first.</span>
                  )}
                </div>
                <span className="bk-shop-toolbar__spacer" />
                <button type="button" className="button" onClick={generateVariations} disabled={!variationAttributes(c.attributes).length}>
                  {draft.variants.length ? 'Update the list' : 'Create all variations'}
                </button>
                <button
                  type="button"
                  className="button"
                  onClick={() => update({ variants: [...draft.variants, { sku: '', attributes: Object.fromEntries(variationAttributes(c.attributes).map((a) => [a.name, ''])), regularPrice: null, salePrice: null, saleFrom: null, saleTo: null, manageStock: false, stockQty: null, stockStatus: 'instock', weight: null, imageId: null, image: null, enabled: true, menuOrder: draft.variants.length }] })}
                >
                  <Plus size={13} weight="bold" aria-hidden /> Add manually
                </button>
              </div>
                  {draft.variants.length ? (
                    <>
                      <div className="bk-prod-vbulk">
                        <span>Same price for all</span>
                        <MoneyInput value={bulkPrice} onChange={setBulkPrice} meta={meta} />
                        <button
                          type="button"
                          className="button"
                          disabled={bulkPrice === null}
                          onClick={() => {
                            update({ variants: draft.variants.map((v) => ({ ...v, regularPrice: bulkPrice })) });
                            setBulkPrice(null);
                          }}
                        >
                          Apply to all
                        </button>
                      </div>
                      <div className="bk-prod-vtable-wrap">
                        <table className="bk-prod-vtable">
                          <thead>
                            <tr>
                              <th className="is-photo">Photo</th>
                              <th>Variation</th>
                              <th>Price</th>
                              <th>Sale price</th>
                              <th>SKU</th>
                              <th>Stock</th>
                              <th className="is-on">For sale</th>
                              <th className="is-tools" aria-label="More" />
                            </tr>
                          </thead>
                          <tbody>
                            {draft.variants.map((v, index) => {
                              const open = openVariants.has(index);
                              const name = Object.values(v.attributes).map((val) => val || 'Any').join(' / ') || 'Variation';
                              const toggle = () => {
                                const next = new Set(openVariants);
                                if (open) next.delete(index);
                                else next.add(index);
                                setOpenVariants(next);
                              };
                              return (
                                <Fragment key={v.id ?? `new-${index}`}>
                                  <tr className={`${v.enabled ? '' : 'is-off'}${open ? ' is-open' : ''}`}>
                                    <td className="is-photo">
                                      <button type="button" className="bk-prod-vphoto" onClick={() => setPicker({ variant: index })} title={v.image ? 'Change the photo' : 'Add a photo'} aria-label={`${v.image ? 'Change' : 'Add'} the photo for ${name}`}>
                                        {v.image ? <img src={v.image.url} alt="" /> : <ImageIcon size={16} aria-hidden />}
                                      </button>
                                    </td>
                                    <td className="bk-prod-vname">{name}</td>
                                    <td>
                                      <MoneyInput value={v.regularPrice} onChange={(val) => updateVariant(index, { regularPrice: val })} meta={meta} />
                                    </td>
                                    <td>
                                      <MoneyInput value={v.salePrice} onChange={(val) => updateVariant(index, { salePrice: val })} meta={meta} placeholder="None" />
                                    </td>
                                    <td>
                                      <input type="text" value={v.sku} onChange={(e) => updateVariant(index, { sku: e.target.value })} aria-label={`SKU for ${name}`} />
                                    </td>
                                    <td>
                                      {v.manageStock ? (
                                        <IntInput value={v.stockQty} onChange={(val) => updateVariant(index, { stockQty: val ?? 0 })} />
                                      ) : (
                                        <select value={v.stockStatus} onChange={(e) => updateVariant(index, { stockStatus: e.target.value as StockStatus })} aria-label={`Stock for ${name}`}>
                                          <option value="instock">In stock</option>
                                          <option value="outofstock">Out of stock</option>
                                          <option value="onbackorder">On backorder</option>
                                        </select>
                                      )}
                                    </td>
                                    <td className="is-on">
                                      <label className="bk-check" title={v.enabled ? 'Customers can buy this one' : 'Hidden from customers'}>
                                        <input type="checkbox" checked={v.enabled} onChange={(e) => updateVariant(index, { enabled: e.target.checked })} aria-label={`${name} is for sale`} /> <span className="bk-check__box" aria-hidden />
                                      </label>
                                    </td>
                                    <td className="is-tools">
                                      <button type="button" className="bk-prod-vtool" onClick={toggle} aria-expanded={open} title="More settings" aria-label={`More settings for ${name}`}>
                                        {open ? <CaretDown size={14} aria-hidden /> : <CaretRight size={14} aria-hidden />}
                                      </button>
                                      <button type="button" className="bk-prod-vtool is-danger" onClick={() => update({ variants: draft.variants.filter((_, i) => i !== index) })} title="Remove" aria-label={`Remove ${name}`}>
                                        <Trash size={14} aria-hidden />
                                      </button>
                                    </td>
                                  </tr>
                                  {open ? (
                                    <tr className="bk-prod-vmore">
                                      <td colSpan={8}>
                                        <div className="bk-shop-row">
                                          {variationAttributes(c.attributes).map((a) => (
                                            <div key={a.name} className="bk-shop-field">
                                              <label>{a.name}</label>
                                              <select value={v.attributes[a.name] ?? ''} onChange={(e) => updateVariant(index, { attributes: { ...v.attributes, [a.name]: e.target.value } })}>
                                                <option value="">Any {a.name}</option>
                                                {a.options.map((o) => (
                                                  <option key={o} value={o}>
                                                    {o}
                                                  </option>
                                                ))}
                                              </select>
                                            </div>
                                          ))}
                                          <div className="bk-shop-field">
                                            <label>Weight (g)</label>
                                            <IntInput value={v.weight} onChange={(val) => updateVariant(index, { weight: val })} />
                                          </div>
                                          {v.manageStock ? (
                                            <div className="bk-shop-field">
                                              <label>When it runs out</label>
                                              <select value={v.stockStatus === 'onbackorder' ? 'onbackorder' : 'instock'} onChange={(e) => updateVariant(index, { stockStatus: e.target.value as StockStatus })}>
                                                <option value="instock">Do not allow orders</option>
                                                <option value="onbackorder">Allow backorders</option>
                                              </select>
                                            </div>
                                          ) : null}
                                        </div>
                                        <div className="bk-shop-inline">
                                          <label className="bk-check">
                                            <input type="checkbox" checked={v.manageStock} onChange={(e) => updateVariant(index, { manageStock: e.target.checked, stockQty: e.target.checked ? (v.stockQty ?? 0) : null })} /> <span className="bk-check__box" aria-hidden />
                                            <span>Count stock for this variation</span>
                                          </label>
                                          {v.image ? (
                                            <button type="button" className="button-link" onClick={() => updateVariant(index, { imageId: null, image: null })}>
                                              Remove its photo
                                            </button>
                                          ) : null}
                                        </div>
                                      </td>
                                    </tr>
                                  ) : null}
                                </Fragment>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </>
                  ) : null}
                </div>
              ) : null}
            </Fold>
            <Fold
              id="more"
              title="Tax, visibility and notes"
              summary={[VISIBILITY_LABEL[c.catalogVisibility], c.taxable ? 'Taxed' : 'No tax', c.featured ? 'Featured' : ''].filter(Boolean).join(' · ')}
              open={folds}
              onToggle={toggleFold}
            >
              <div className="bk-shop-field">
                <label className="bk-check">
                  <input type="checkbox" checked={c.taxable} onChange={(e) => updateCommerce({ taxable: e.target.checked })} /> <span className="bk-check__box" aria-hidden />
                  <span>Charge tax on this product</span>
                </label>
                <p className="description">{meta?.taxEnabled ? 'Taxes are enabled in Shop → Settings → Tax.' : 'Taxes are turned off in Shop → Settings → Tax; this only matters once they are enabled.'}</p>
              </div>
              <div className="bk-shop-field">
                <label htmlFor="p-note">Purchase note</label>
                <textarea id="p-note" rows={3} value={c.purchaseNote} onChange={(e) => updateCommerce({ purchaseNote: e.target.value })} />
                <p className="description">Sent to the customer in the order email once the order is paid. Never shown on the product page.</p>
              </div>
              <div className="bk-shop-field">
                <label htmlFor="p-vis">Catalog visibility</label>
                <select id="p-vis" value={c.catalogVisibility} onChange={(e) => updateCommerce({ catalogVisibility: e.target.value as Product['commerce']['catalogVisibility'] })}>
                  <option value="visible">Shop and search results</option>
                  <option value="catalog">Shop only</option>
                  <option value="search">Search results only</option>
                  <option value="hidden">Hidden (direct link only)</option>
                </select>
              </div>
              <div className="bk-shop-field">
                <label className="bk-check">
                  <input type="checkbox" checked={c.featured} onChange={(e) => updateCommerce({ featured: e.target.checked })} /> <span className="bk-check__box" aria-hidden />
                  <span>Featured product</span>
                </label>
              </div>
              <p className="description">Total sales so far: {c.totalSales}</p>
            </Fold>
          </div>
        </div>

        <aside className="bk-shop-editor__side">
          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Publish</h2>
            </div>
            <div className="bk-panel__body">
              <div className="bk-shop-publish__meta">
                <div>
                  <span>Status</span>
                  <strong>{published ? 'Published' : product.status === 'trash' ? 'In trash' : 'Draft'}</strong>
                </div>
                <div>
                  <span>Last updated</span>
                  <span>{formatDate(product.updatedAt)}</span>
                </div>
                {product.updatedByName ? (
                  <div>
                    <span>By</span>
                    <span>{product.updatedByName}</span>
                  </div>
                ) : null}
              </div>
              <div className="bk-shop-publish__actions">
                <button type="button" className="button-link is-danger" disabled={busy} onClick={() => void trash()}>
                  Move to trash
                </button>
                <span className="bk-shop-inline">
                  {!published ? (
                    <button type="submit" className="button" disabled={busy}>
                      {busy ? 'Saving…' : 'Save draft'}
                    </button>
                  ) : (
                    <button type="button" className="button" disabled={busy} onClick={() => void save('draft')}>
                      Unpublish
                    </button>
                  )}
                  <button type="button" className="button button-primary" disabled={busy || !draft.title.trim()} onClick={() => void save('publish')} title={!draft.title.trim() ? 'Give the product a name first' : undefined}>
                    {busy ? 'Saving…' : published ? 'Update' : 'Publish'}
                  </button>
                </span>
              </div>
            </div>
          </div>

          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Photos</h2>
            </div>
            <div className="bk-panel__body">
              <div className="bk-prod-photos">
                <div className="bk-prod-photos__main">
                  <button type="button" className="bk-shop-image" onClick={() => setPicker('image')} aria-label={draft.image ? 'Change the main photo' : 'Choose the main photo'}>
                    {draft.image ? <img src={draft.image.url} alt={draft.image.alt} /> : <span className="bk-shop-image__empty">Add main photo</span>}
                  </button>
                  {draft.image ? (
                    <button type="button" className="bk-shop-gallery__remove" aria-label="Remove the main photo" onClick={() => update({ featuredImageId: null, image: null })}>
                      ×
                    </button>
                  ) : null}
                </div>
                {c.gallery.map((g) => (
                  <div key={g.id} className="bk-shop-gallery__item">
                    <img src={g.url} alt={g.alt} />
                    <button type="button" className="bk-shop-gallery__remove" aria-label="Remove from gallery" onClick={() => updateCommerce({ galleryIds: c.galleryIds.filter((id2) => id2 !== g.id), gallery: c.gallery.filter((x) => x.id !== g.id) })}>
                      ×
                    </button>
                  </div>
                ))}
                <button type="button" className="bk-shop-gallery__add" onClick={() => setPicker('gallery')} aria-label="Add more photos" title="Add more photos">
                  <Plus size={18} aria-hidden />
                </button>
              </div>
              <p className="description bk-prod-photos__hint">The large one is the main photo; the others make the gallery.</p>
            </div>
          </div>

          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Categories</h2>
            </div>
            <div className="bk-panel__body">
              <TermChecklist taxonomyId={product.categoryTaxonomyId ?? meta?.categoryTaxonomyId ?? null} selected={draft.categoryIds} onChange={(ids) => update({ categoryIds: ids })} onError={setError} label="Categories" singular="Category" />
            </div>
          </div>

          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Tags</h2>
            </div>
            <div className="bk-panel__body">
              <TagInput taxonomyId={product.tagTaxonomyId ?? meta?.tagTaxonomyId ?? null} selected={draft.tagIds} onChange={(ids) => update({ tagIds: ids })} onError={setError} />
            </div>
          </div>
        </aside>

        {dirty ? (
          <div className="bk-prod-savebar" role="status">
            <p>You have changes that aren’t saved yet.</p>
            <div className="bk-shop-inline">
              <button type="button" className="button" disabled={busy} onClick={() => setDraft(JSON.parse(baseline) as Draft)}>
                Discard
              </button>
              <button type="submit" className="button button-primary" disabled={busy}>
                {busy ? 'Saving…' : published ? 'Save changes' : 'Save draft'}
              </button>
            </div>
          </div>
        ) : null}
      </form>

      <MediaPicker
        open={picker !== null}
        kind="image"
        multiple={picker === 'gallery'}
        selected={picker === 'gallery' ? c.galleryIds : []}
        title={picker === 'gallery' ? 'Add gallery images' : 'Choose an image'}
        onClose={() => setPicker(null)}
        onSelect={(items) => {
          if (picker === 'image' && items[0]) update({ featuredImageId: items[0].id, image: toMediaRef(items[0]) });
          else if (picker === 'gallery') {
            const refs = items.map(toMediaRef);
            const ids = [...new Set([...c.galleryIds, ...refs.map((r) => r.id)])];
            const existing = new Map(c.gallery.map((g) => [g.id, g]));
            for (const r of refs) existing.set(r.id, r);
            updateCommerce({ galleryIds: ids, gallery: ids.map((id2) => existing.get(id2)).filter((g): g is MediaRef => Boolean(g)) });
          } else if (picker && typeof picker === 'object' && items[0]) {
            updateVariant(picker.variant, { imageId: items[0].id, image: toMediaRef(items[0]) });
          }
          setPicker(null);
        }}
      />
    </div>
  );
}
