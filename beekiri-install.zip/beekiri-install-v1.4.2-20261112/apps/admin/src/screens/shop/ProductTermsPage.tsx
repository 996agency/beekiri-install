import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react';
import { api } from '../../api/client';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { shopError, useShopMeta, type TermList, type TermRow } from './api';
import { LiveSearch } from '../../components/LiveSearch';
import './shop.css';
import './products.css';

const formatError = shopError;

type Draft = { name: string; slug: string; parentId: string; description: string };
const EMPTY: Draft = { name: '', slug: '', parentId: '', description: '' };

/** Generic manager for a product taxonomy (categories or tags), WooCommerce "Categories" style. */
function TermsManager({ taxonomyId, title, intro }: { taxonomyId: string | null; title: string; intro: string }) {
  const [data, setData] = useState<TermList | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft>(EMPTY);
  const [editing, setEditing] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState<Draft>(EMPTY);
  const [busy, setBusy] = useState(false);
  const [query, setQuery] = useState('');

  const load = useCallback(async () => {
    if (!taxonomyId) return;
    try {
      setData(await api<TermList>(`/api/fields/taxonomies/${taxonomyId}/terms`));
    } catch (e) {
      setError(formatError(e));
    }
  }, [taxonomyId]);
  useEffect(() => {
    void load();
  }, [load]);

  const hierarchical = data?.taxonomy.hierarchical ?? false;
  const rows = useMemo(() => {
    const terms = data?.terms ?? [];
    const byParent = new Map<string | null, TermRow[]>();
    for (const t of terms) byParent.set(t.parentId, [...(byParent.get(t.parentId) ?? []), t]);
    const out: { term: TermRow; depth: number }[] = [];
    const walk = (p: string | null, depth: number) => {
      for (const t of byParent.get(p) ?? []) {
        out.push({ term: t, depth });
        if (hierarchical) walk(t.id, depth + 1);
      }
    };
    walk(null, 0);
    // Orphans (parent deleted) still show.
    for (const t of terms) if (!out.some((r) => r.term.id === t.id)) out.push({ term: t, depth: 0 });
    const q = query.trim().toLowerCase();
    return q ? out.filter((r) => `${r.term.name} ${r.term.slug}`.toLowerCase().includes(q)) : out;
  }, [data, hierarchical, query]);

  const create = async (e: FormEvent) => {
    e.preventDefault();
    if (!taxonomyId || !draft.name.trim()) return;
    setBusy(true);
    setError(null);
    try {
      const created = await api<{ id: string }>(`/api/fields/taxonomies/${taxonomyId}/terms`, {
        json: { name: draft.name.trim(), slug: draft.slug.trim() || undefined, parentId: hierarchical && draft.parentId ? draft.parentId : null },
      });
      if (draft.description.trim()) {
        await api(`/api/fields/terms/${created.id}`, { method: 'PATCH', json: { description: draft.description.trim() } });
      }
      setDraft(EMPTY);
      setNotice(`“${draft.name.trim()}” added.`);
      await load();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const startEdit = (t: TermRow) => {
    setEditing(t.id);
    setEditDraft({ name: t.name, slug: t.slug, parentId: t.parentId ?? '', description: t.description });
  };

  const saveEdit = async () => {
    if (!editing) return;
    setBusy(true);
    setError(null);
    try {
      await api(`/api/fields/terms/${editing}`, {
        method: 'PATCH',
        json: {
          name: editDraft.name.trim(),
          slug: editDraft.slug.trim(),
          description: editDraft.description.trim(),
          ...(hierarchical ? { parentId: editDraft.parentId || null } : {}),
        },
      });
      setEditing(null);
      setNotice('Saved.');
      await load();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const remove = async (t: TermRow) => {
    const ok = await confirmDialog({
      title: `Delete “${t.name}”?`,
      message: t.count ? `${t.count} product${t.count === 1 ? ' is' : 's are'} in it. They stay published but lose this ${data?.taxonomy.singular.toLowerCase() ?? 'term'}.` : 'This cannot be undone.',
      confirmLabel: 'Delete',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    try {
      await api(`/api/fields/terms/${t.id}`, { method: 'DELETE' });
      setNotice(`“${t.name}” deleted.`);
      await load();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const parentOptions = (excludeId?: string) =>
    rows.filter((r) => r.term.id !== excludeId).map((r) => ({ id: r.term.id, label: `${'— '.repeat(r.depth)}${r.term.name}` }));

  if (!taxonomyId) {
    return (
      <div className="wrap">
        <PageHeader title={title} />
        {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : <p className="bk-muted">Loading…</p>}
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide">
      <PageHeader title={title} />
      <p className="bk-muted">{intro}</p>
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <div className="bk-terms">
        <form className="bk-panel" onSubmit={create}>
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Add new {data?.taxonomy.singular.toLowerCase() ?? 'term'}</h2>
          </div>
          <div className="bk-panel__body">
            <div className="bk-shop-field">
              <label htmlFor="term-name">Name</label>
              <input id="term-name" type="text" required value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
            </div>
            <div className="bk-shop-field">
              <label htmlFor="term-slug">Slug</label>
              <input id="term-slug" type="text" value={draft.slug} placeholder="Generated from the name" onChange={(e) => setDraft({ ...draft, slug: e.target.value })} />
              <p className="description">Used in the URL: /shop/category/{draft.slug || 'slug'}</p>
            </div>
            {hierarchical ? (
              <div className="bk-shop-field">
                <label htmlFor="term-parent">Parent</label>
                <select id="term-parent" value={draft.parentId} onChange={(e) => setDraft({ ...draft, parentId: e.target.value })}>
                  <option value="">None</option>
                  {parentOptions().map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </div>
            ) : null}
            <div className="bk-shop-field">
              <label htmlFor="term-desc">Description</label>
              <textarea id="term-desc" rows={3} value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} />
              <p className="description">Shown at the top of the category page in the shop.</p>
            </div>
            <p className="submit">
              <button type="submit" className="button button-primary" disabled={busy || !draft.name.trim()}>
                Add {data?.taxonomy.singular.toLowerCase() ?? 'term'}
              </button>
            </p>
          </div>
        </form>

        <div>
          <div className="bk-shop-toolbar">
            <LiveSearch value={query} onSearch={setQuery} placeholder="Search…" label="Search" />
            <span className="bk-shop-toolbar__spacer" />
            <span className="bk-shop-toolbar__count">{data?.terms.length ?? 0} total</span>
          </div>
          <div className="bk-shop-table-wrap">
            <table className="bk-shop-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Slug</th>
                  <th>Description</th>
                  <th className="is-right">Products</th>
                </tr>
              </thead>
              <tbody>
                {!data ? (
                  <tr>
                    <td colSpan={4} className="bk-shop-table__empty">
                      Loading…
                    </td>
                  </tr>
                ) : rows.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="bk-shop-table__empty">
                      {query ? 'Nothing matches.' : `No ${data.taxonomy.plural.toLowerCase()} yet. Add the first one on the left.`}
                    </td>
                  </tr>
                ) : (
                  rows.map(({ term, depth }) => (
                    <tr key={term.id}>
                      {editing === term.id ? (
                        <td colSpan={4}>
                          <div className="bk-terms__inline">
                            <div className="bk-shop-row">
                              <div className="bk-shop-field">
                                <label>Name</label>
                                <input type="text" value={editDraft.name} onChange={(e) => setEditDraft({ ...editDraft, name: e.target.value })} />
                              </div>
                              <div className="bk-shop-field">
                                <label>Slug</label>
                                <input type="text" value={editDraft.slug} onChange={(e) => setEditDraft({ ...editDraft, slug: e.target.value })} />
                              </div>
                              {hierarchical ? (
                                <div className="bk-shop-field">
                                  <label>Parent</label>
                                  <select value={editDraft.parentId} onChange={(e) => setEditDraft({ ...editDraft, parentId: e.target.value })}>
                                    <option value="">None</option>
                                    {parentOptions(term.id).map((o) => (
                                      <option key={o.id} value={o.id}>
                                        {o.label}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                              ) : null}
                            </div>
                            <div className="bk-shop-field">
                              <label>Description</label>
                              <textarea rows={2} value={editDraft.description} onChange={(e) => setEditDraft({ ...editDraft, description: e.target.value })} />
                            </div>
                            <div className="bk-terms__inline-actions">
                              <button type="button" className="button button-primary" disabled={busy || !editDraft.name.trim()} onClick={() => void saveEdit()}>
                                Save
                              </button>
                              <button type="button" className="button" onClick={() => setEditing(null)}>
                                Cancel
                              </button>
                            </div>
                          </div>
                        </td>
                      ) : (
                        <>
                          <td className={`bk-terms__depth-${Math.min(depth, 3)}`}>
                            <span className="bk-terms__name">{term.name}</span>
                            <div className="bk-shop-table__actions">
                              <button type="button" onClick={() => startEdit(term)}>
                                Edit
                              </button>
                              <span className="sep">|</span>
                              <button type="button" className="is-danger" disabled={busy} onClick={() => void remove(term)}>
                                Delete
                              </button>
                            </div>
                          </td>
                          <td>
                            <code>{term.slug}</code>
                          </td>
                          <td className="bk-muted">{term.description || '—'}</td>
                          <td className="is-right">{term.count}</td>
                        </>
                      )}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export function ProductCategoriesPage() {
  const meta = useShopMeta();
  return <TermsManager taxonomyId={meta?.categoryTaxonomyId ?? null} title="Product categories" intro="Group products so shoppers can browse by category. Categories can be nested." />;
}

export function ProductTagsPage() {
  const meta = useShopMeta();
  return <TermsManager taxonomyId={meta?.tagTaxonomyId ?? null} title="Product tags" intro="Tags are free-form labels for products (e.g. “new”, “gift”)." />;
}
