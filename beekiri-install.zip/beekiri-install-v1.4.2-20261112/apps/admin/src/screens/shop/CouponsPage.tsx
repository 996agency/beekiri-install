import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../../api/client';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { LiveSearch } from '../../components/LiveSearch';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { useAdminHref } from '../../lib/AdminEntryContext';
import {
  buildQuery,
  formatDate,
  formatMoney,
  moneyToInput,
  parseMoney,
  useShopMeta,
  type Coupon,
  type CouponType,
  type ProductLookupRow,
  type ShopMeta,
  type TermList,
  type TermRow,
} from './api';
import { formatError } from './OrdersPage';
import './shop.css';
import './orders.css';

const TYPE_LABELS: Record<CouponType, string> = {
  percent: 'Percentage discount',
  fixed_cart: 'Fixed cart discount',
  fixed_product: 'Fixed product discount',
};

function amountLabel(c: Coupon, meta: ShopMeta | null): string {
  if (c.type === 'percent') return `${(c.amount / 100).toFixed(2).replace(/\.?0+$/, '')}%`;
  return `${formatMoney(c.amount, meta)}${c.type === 'fixed_product' ? ' per item' : ''}`;
}

function isExpired(c: Coupon): boolean {
  return Boolean(c.expiresAt && new Date(c.expiresAt).getTime() < Date.now());
}

/* ── List ─────────────────────────────────────────────────────────────── */

export function CouponsPage() {
  const href = useAdminHref();
  const meta = useShopMeta();
  const [coupons, setCoupons] = useState<Coupon[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [query, setQuery] = useState('');

  const load = useCallback(async () => {
    const res = await api<{ coupons: Coupon[] }>('/api/shop/coupons');
    setCoupons(res.coupons);
  }, []);

  useEffect(() => {
    load().catch((e) => setError(formatError(e)));
  }, [load]);

  const remove = async (c: Coupon) => {
    const ok = await confirmDialog({
      title: `Delete coupon ${c.code}?`,
      message: 'Shoppers can no longer use this code. Orders that already used it are not changed.',
      confirmLabel: 'Delete',
      danger: true,
    });
    if (!ok) return;
    try {
      await api(`/api/shop/coupons/${encodeURIComponent(c.id)}`, { method: 'DELETE' });
      setCoupons((list) => (list ?? []).filter((x) => x.id !== c.id));
      setNotice(`Coupon ${c.code} deleted.`);
    } catch (e) {
      setError(formatError(e));
    }
  };

  const toggleActive = async (c: Coupon) => {
    try {
      const updated = await api<Coupon>(`/api/shop/coupons/${encodeURIComponent(c.id)}`, { method: 'PATCH', json: { active: !c.active } });
      setCoupons((list) => (list ?? []).map((x) => (x.id === c.id ? updated : x)));
      setNotice(updated.active ? `Coupon ${c.code} enabled.` : `Coupon ${c.code} disabled.`);
    } catch (e) {
      setError(formatError(e));
    }
  };

  const rows = (coupons ?? []).filter((c) => {
    const q = query.trim().toLowerCase();
    return !q || `${c.code} ${c.description}`.toLowerCase().includes(q);
  });

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Coupons"
        actions={
          <Link className="button button-primary" to={href('shop/coupons/new')}>
            Add coupon
          </Link>
        }
      />
      <p className="bk-muted">Discount codes shoppers enter in the cart. {coupons ? `${coupons.length} total.` : ''}</p>
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <div className="bk-shop-toolbar">
        <LiveSearch value={query} onSearch={setQuery} placeholder="Search coupons…" label="Search coupons" />
      </div>

      <div className="bk-shop-table-wrap">
        <table className="bk-shop-table">
          <thead>
            <tr>
              <th scope="col">Code</th>
              <th scope="col">Type</th>
              <th scope="col">Amount</th>
              <th scope="col">Usage</th>
              <th scope="col">Expires</th>
              <th scope="col">Status</th>
            </tr>
          </thead>
          <tbody>
            {!coupons ? (
              <tr>
                <td colSpan={6} className="bk-shop-table__empty">
                  Loading…
                </td>
              </tr>
            ) : rows.length === 0 ? (
              <tr>
                <td colSpan={6} className="bk-shop-table__empty">
                  {coupons.length === 0 ? (
                    <>
                      No coupons yet. <Link to={href('shop/coupons/new')}>Create your first coupon</Link>.
                    </>
                  ) : (
                    'No coupons match your search.'
                  )}
                </td>
              </tr>
            ) : (
              rows.map((c) => (
                <tr key={c.id}>
                  <td>
                    <Link className="bk-shop-table__primary bk-shop-coupon-code" to={href(`shop/coupons/${c.id}`)}>
                      {c.code}
                    </Link>
                    {c.description ? <span className="bk-shop-table__sub">{c.description}</span> : null}
                    <div className="bk-shop-table__actions">
                      <Link to={href(`shop/coupons/${c.id}`)}>Edit</Link>
                      <span className="sep">|</span>
                      <button type="button" onClick={() => void toggleActive(c)}>
                        {c.active ? 'Disable' : 'Enable'}
                      </button>
                      <span className="sep">|</span>
                      <button type="button" className="is-danger" onClick={() => void remove(c)}>
                        Delete
                      </button>
                    </div>
                  </td>
                  <td>{TYPE_LABELS[c.type]}</td>
                  <td className="bk-shop-money">
                    {amountLabel(c, meta)}
                    {c.freeShipping ? <span className="bk-shop-table__sub">+ free shipping</span> : null}
                  </td>
                  <td>
                    {c.usageCount} / {c.usageLimit ?? '∞'}
                  </td>
                  <td>{c.expiresAt ? formatDate(c.expiresAt, false) : <span className="bk-muted">Never</span>}</td>
                  <td>
                    {!c.active ? (
                      <span className="bk-shop-pill is-muted">Disabled</span>
                    ) : isExpired(c) ? (
                      <span className="bk-shop-pill is-warn">Expired</span>
                    ) : c.usageLimit !== null && c.usageCount >= c.usageLimit ? (
                      <span className="bk-shop-pill is-warn">Limit reached</span>
                    ) : (
                      <span className="bk-shop-pill is-ok">Active</span>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ── Editor ───────────────────────────────────────────────────────────── */

type FormState = {
  code: string;
  type: CouponType;
  amount: string;
  description: string;
  minSpend: string;
  maxSpend: string;
  usageLimit: string;
  usageLimitPerEmail: string;
  expiresAt: string;
  productIds: string[];
  excludeProductIds: string[];
  categoryIds: string[];
  freeShipping: boolean;
  active: boolean;
};

const EMPTY: FormState = {
  code: '',
  type: 'percent',
  amount: '',
  description: '',
  minSpend: '',
  maxSpend: '',
  usageLimit: '',
  usageLimitPerEmail: '',
  expiresAt: '',
  productIds: [],
  excludeProductIds: [],
  categoryIds: [],
  freeShipping: false,
  active: true,
};

function toDateInput(iso: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/** YYYY-MM-DD → end of that local day as ISO. */
function fromDateInput(value: string): string | null {
  if (!value) return null;
  const [y, m, d] = value.split('-').map(Number);
  if (!y || !m || !d) return null;
  return new Date(y, m - 1, d, 23, 59, 59).toISOString();
}

function fromCoupon(c: Coupon, currency: string, meta: ShopMeta | null): FormState {
  return {
    code: c.code,
    type: c.type,
    amount: c.type === 'percent' ? (c.amount / 100).toFixed(2).replace(/\.?0+$/, '') : moneyToInput(c.amount, currency, meta?.currencies),
    description: c.description,
    minSpend: moneyToInput(c.minSpend, currency, meta?.currencies),
    maxSpend: moneyToInput(c.maxSpend, currency, meta?.currencies),
    usageLimit: c.usageLimit === null ? '' : String(c.usageLimit),
    usageLimitPerEmail: c.usageLimitPerEmail === null ? '' : String(c.usageLimitPerEmail),
    expiresAt: toDateInput(c.expiresAt),
    productIds: c.productIds,
    excludeProductIds: c.excludeProductIds,
    categoryIds: c.categoryIds,
    freeShipping: c.freeShipping,
    active: c.active,
  };
}

function intOrNull(v: string): number | null {
  const t = v.trim();
  if (!t) return null;
  const n = Number(t);
  return Number.isInteger(n) && n >= 0 ? n : null;
}

/** Search-and-pick products as chips (coupon include / exclude lists). */
function ProductPicker({
  label,
  ids,
  onChange,
  names,
  onNames,
}: {
  label: string;
  ids: string[];
  onChange: (ids: string[]) => void;
  names: Map<string, string>;
  onNames: (rows: ProductLookupRow[]) => void;
}) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<ProductLookupRow[]>([]);
  const [open, setOpen] = useState(false);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    if (timer.current) window.clearTimeout(timer.current);
    const q = query.trim();
    if (!q) {
      setResults([]);
      return;
    }
    timer.current = window.setTimeout(() => {
      api<{ items: ProductLookupRow[] }>(`/api/shop/products/lookup${buildQuery({ q })}`)
        .then((res) => {
          setResults(res.items);
          onNames(res.items);
          setOpen(true);
        })
        .catch(() => setResults([]));
    }, 250);
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  return (
    <div className="bk-shop-field">
      <label>{label}</label>
      {ids.length ? (
        <div className="bk-shop-chips" style={{ marginBottom: 6 }}>
          {ids.map((id) => (
            <span key={id} className="bk-shop-chip">
              {names.get(id) ?? id}
              <button type="button" aria-label="Remove" onClick={() => onChange(ids.filter((x) => x !== id))}>
                ×
              </button>
            </span>
          ))}
        </div>
      ) : null}
      <div className="bk-shop-picker">
        <input
          className="regular-text"
          type="search"
          placeholder="Search products by name…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => results.length && setOpen(true)}
          onBlur={() => window.setTimeout(() => setOpen(false), 150)}
        />
        {open && results.length ? (
          <ul className="bk-shop-picker__list">
            {results
              .filter((r) => !ids.includes(r.id))
              .map((r) => (
                <li key={r.id}>
                  <button
                    type="button"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => {
                      onChange([...ids, r.id]);
                      setQuery('');
                      setOpen(false);
                    }}
                  >
                    <span>{r.title || '(untitled)'}</span>
                    <small>{r.sku || r.status}</small>
                  </button>
                </li>
              ))}
          </ul>
        ) : null}
      </div>
    </div>
  );
}

export function CouponEditPage() {
  const { id } = useParams();
  const isNew = !id;
  const href = useAdminHref();
  const navigate = useNavigate();
  const meta = useShopMeta();
  const currency = meta?.currency ?? 'EUR';
  const [form, setForm] = useState<FormState | null>(isNew ? EMPTY : null);
  const [coupon, setCoupon] = useState<Coupon | null>(null);
  const [categories, setCategories] = useState<TermRow[]>([]);
  const [names, setNames] = useState<Map<string, string>>(new Map());
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // Existing coupon (needs meta for money formatting).
  useEffect(() => {
    if (isNew || !meta) return;
    let cancelled = false;
    api<Coupon>(`/api/shop/coupons/${encodeURIComponent(id)}`)
      .then((c) => {
        if (cancelled) return;
        setCoupon(c);
        setForm(fromCoupon(c, meta.currency, meta));
        const ids = [...c.productIds, ...c.excludeProductIds];
        if (ids.length) {
          api<{ items: ProductLookupRow[] }>(`/api/shop/products/lookup${buildQuery({ ids: ids.join(',') })}`)
            .then((res) => {
              if (!cancelled) setNames((m) => new Map([...m, ...res.items.map((r) => [r.id, r.title] as const)]));
            })
            .catch(() => undefined);
        }
      })
      .catch((e) => {
        if (!cancelled) setError(formatError(e));
      });
    return () => {
      cancelled = true;
    };
  }, [id, isNew, meta]);

  useEffect(() => {
    if (!meta?.categoryTaxonomyId) return;
    let cancelled = false;
    api<TermList>(`/api/fields/taxonomies/${encodeURIComponent(meta.categoryTaxonomyId)}/terms`)
      .then((res) => {
        if (!cancelled) setCategories(res.terms);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [meta?.categoryTaxonomyId]);

  const rememberNames = (rows: ProductLookupRow[]) => setNames((m) => new Map([...m, ...rows.map((r) => [r.id, r.title] as const)]));

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm((f) => (f ? { ...f, [key]: value } : f));

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!form) return;
    setError(null);
    setNotice(null);
    const code = form.code.trim().toUpperCase();
    if (!code) {
      setError('Enter a coupon code.');
      return;
    }
    let amount: number | null;
    if (form.type === 'percent') {
      const pct = Number(form.amount.replace(',', '.'));
      amount = Number.isFinite(pct) && pct >= 0 && pct <= 100 ? Math.round(pct * 100) : null;
      if (amount === null) {
        setError('Enter a percentage between 0 and 100.');
        return;
      }
    } else {
      amount = parseMoney(form.amount, currency, meta?.currencies);
      if (amount === null) {
        setError('Enter the discount amount.');
        return;
      }
    }
    const minSpend = form.minSpend.trim() ? parseMoney(form.minSpend, currency, meta?.currencies) : null;
    const maxSpend = form.maxSpend.trim() ? parseMoney(form.maxSpend, currency, meta?.currencies) : null;
    if ((form.minSpend.trim() && minSpend === null) || (form.maxSpend.trim() && maxSpend === null)) {
      setError('Minimum and maximum spend must be amounts (e.g. 25.00).');
      return;
    }
    const usageLimit = intOrNull(form.usageLimit);
    const usageLimitPerEmail = intOrNull(form.usageLimitPerEmail);
    if ((form.usageLimit.trim() && usageLimit === null) || (form.usageLimitPerEmail.trim() && usageLimitPerEmail === null)) {
      setError('Usage limits must be whole numbers.');
      return;
    }
    const body = {
      code,
      type: form.type,
      amount,
      description: form.description.trim(),
      minSpend,
      maxSpend,
      usageLimit,
      usageLimitPerEmail,
      expiresAt: fromDateInput(form.expiresAt),
      productIds: form.productIds,
      excludeProductIds: form.excludeProductIds,
      categoryIds: form.categoryIds,
      freeShipping: form.freeShipping,
      active: form.active,
    };
    setBusy(true);
    try {
      if (isNew) {
        const created = await api<Coupon>('/api/shop/coupons', { method: 'POST', json: body });
        navigate(href(`shop/coupons/${created.id}`), { replace: true });
      } else {
        const updated = await api<Coupon>(`/api/shop/coupons/${encodeURIComponent(id)}`, { method: 'PATCH', json: body });
        setCoupon(updated);
        setForm(fromCoupon(updated, currency, meta));
        setNotice('Coupon saved.');
      }
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!coupon) return;
    const ok = await confirmDialog({ title: `Delete coupon ${coupon.code}?`, message: 'Shoppers can no longer use this code.', confirmLabel: 'Delete', danger: true });
    if (!ok) return;
    try {
      await api(`/api/shop/coupons/${encodeURIComponent(coupon.id)}`, { method: 'DELETE' });
      navigate(href('shop/coupons'));
    } catch (e) {
      setError(formatError(e));
    }
  };

  if (!form) {
    return (
      <div className="wrap">
        <PageHeader title={isNew ? 'Add coupon' : 'Edit coupon'} />
        {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
        <p className="bk-muted">Loading…</p>
      </div>
    );
  }

  const topCats = categories.filter((c) => !c.parentId);
  const childrenOf = (parentId: string) => categories.filter((c) => c.parentId === parentId);
  const toggleCat = (cid: string) => set('categoryIds', form.categoryIds.includes(cid) ? form.categoryIds.filter((x) => x !== cid) : [...form.categoryIds, cid]);

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title={isNew ? 'Add coupon' : `Coupon ${coupon?.code ?? ''}`}
        actions={
          <Link className="button" to={href('shop/coupons')}>
            ← All coupons
          </Link>
        }
      />
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <form className="bk-shop-editor" onSubmit={save} style={{ marginTop: 12 }}>
        <div className="bk-shop-editor__main">
          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">General</h2>
            </div>
            <div className="bk-panel__body">
              <div className="bk-shop-row">
                <div className="bk-shop-field">
                  <label htmlFor="coupon-code">Coupon code</label>
                  <input
                    id="coupon-code"
                    className="regular-text bk-shop-coupon-code"
                    type="text"
                    value={form.code}
                    onChange={(e) => set('code', e.target.value.toUpperCase().replace(/[^A-Z0-9_-]/g, ''))}
                    placeholder="SUMMER20"
                    maxLength={40}
                    required
                  />
                  <p className="description">Letters, numbers, - and _ only. Shoppers type this in the cart.</p>
                </div>
                <div className="bk-shop-field">
                  <label htmlFor="coupon-type">Discount type</label>
                  <select id="coupon-type" value={form.type} onChange={(e) => set('type', e.target.value as CouponType)}>
                    {(Object.keys(TYPE_LABELS) as CouponType[]).map((t) => (
                      <option key={t} value={t}>
                        {TYPE_LABELS[t]}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="bk-shop-field">
                  <label htmlFor="coupon-amount">{form.type === 'percent' ? 'Percentage' : 'Amount'}</label>
                  <div className="bk-shop-prefix">
                    <span>{form.type === 'percent' ? '%' : currency}</span>
                    <input id="coupon-amount" className="regular-text" type="text" inputMode="decimal" value={form.amount} onChange={(e) => set('amount', e.target.value)} placeholder={form.type === 'percent' ? '10' : '5.00'} required />
                  </div>
                  <p className="description">
                    {form.type === 'percent'
                      ? 'Taken off the eligible items.'
                      : form.type === 'fixed_cart'
                        ? 'Taken off the cart once.'
                        : 'Taken off each eligible item (× quantity).'}
                  </p>
                </div>
              </div>
              <div className="bk-shop-field">
                <label htmlFor="coupon-desc">Description (internal)</label>
                <input id="coupon-desc" className="regular-text" type="text" value={form.description} onChange={(e) => set('description', e.target.value)} maxLength={500} />
              </div>
              <div className="bk-shop-row">
                <div className="bk-shop-field">
                  <label htmlFor="coupon-expiry">Expiry date</label>
                  <input id="coupon-expiry" className="regular-text" type="date" value={form.expiresAt} onChange={(e) => set('expiresAt', e.target.value)} />
                  <p className="description">The coupon works until the end of that day. Leave empty for no expiry.</p>
                </div>
              </div>
              <label className="bk-shop-check">
                <input type="checkbox" checked={form.freeShipping} onChange={(e) => set('freeShipping', e.target.checked)} /> Also grants free shipping
              </label>
            </div>
          </section>

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Usage restriction</h2>
            </div>
            <div className="bk-panel__body">
              <div className="bk-shop-row">
                <div className="bk-shop-field">
                  <label htmlFor="coupon-min">Minimum spend</label>
                  <div className="bk-shop-prefix">
                    <span>{currency}</span>
                    <input id="coupon-min" className="regular-text" type="text" inputMode="decimal" value={form.minSpend} onChange={(e) => set('minSpend', e.target.value)} placeholder="No minimum" />
                  </div>
                </div>
                <div className="bk-shop-field">
                  <label htmlFor="coupon-max">Maximum spend</label>
                  <div className="bk-shop-prefix">
                    <span>{currency}</span>
                    <input id="coupon-max" className="regular-text" type="text" inputMode="decimal" value={form.maxSpend} onChange={(e) => set('maxSpend', e.target.value)} placeholder="No maximum" />
                  </div>
                </div>
              </div>
              <ProductPicker label="Products (only these qualify)" ids={form.productIds} onChange={(ids) => set('productIds', ids)} names={names} onNames={rememberNames} />
              <ProductPicker label="Exclude products" ids={form.excludeProductIds} onChange={(ids) => set('excludeProductIds', ids)} names={names} onNames={rememberNames} />
              <div className="bk-shop-field">
                <label>Product categories (only these qualify)</label>
                {categories.length ? (
                  <ul className="bk-shop-terms">
                    {topCats.map((c) => (
                      <li key={c.id}>
                        <label>
                          <input type="checkbox" checked={form.categoryIds.includes(c.id)} onChange={() => toggleCat(c.id)} /> {c.name}
                        </label>
                        {childrenOf(c.id).map((ch) => (
                          <label key={ch.id} className="is-child">
                            <input type="checkbox" checked={form.categoryIds.includes(ch.id)} onChange={() => toggleCat(ch.id)} /> {ch.name}
                          </label>
                        ))}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="description">No product categories yet.</p>
                )}
                <p className="description">Leave products and categories empty to apply the coupon to the whole cart.</p>
              </div>
            </div>
          </section>

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Usage limits</h2>
            </div>
            <div className="bk-panel__body">
              <div className="bk-shop-row">
                <div className="bk-shop-field">
                  <label htmlFor="coupon-limit">Usage limit per coupon</label>
                  <input id="coupon-limit" className="regular-text" type="number" min={0} value={form.usageLimit} onChange={(e) => set('usageLimit', e.target.value)} placeholder="Unlimited" />
                  <p className="description">
                    {coupon ? `Used ${coupon.usageCount} ${coupon.usageCount === 1 ? 'time' : 'times'} so far.` : 'How many orders can use this coupon in total.'}
                  </p>
                </div>
                <div className="bk-shop-field">
                  <label htmlFor="coupon-limit-email">Usage limit per customer</label>
                  <input id="coupon-limit-email" className="regular-text" type="number" min={0} value={form.usageLimitPerEmail} onChange={(e) => set('usageLimitPerEmail', e.target.value)} placeholder="Unlimited" />
                  <p className="description">Counted per email address.</p>
                </div>
              </div>
            </div>
          </section>
        </div>

        <div className="bk-shop-editor__side">
          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Publish</h2>
            </div>
            <div className="bk-panel__body">
              <label className="bk-shop-check" style={{ marginBottom: 10 }}>
                <input type="checkbox" checked={form.active} onChange={(e) => set('active', e.target.checked)} /> Coupon is active
              </label>
              {coupon ? (
                <div className="bk-shop-publish__meta">
                  <div>
                    <span>Created</span>
                    <span>{formatDate(coupon.createdAt, false)}</span>
                  </div>
                  <div>
                    <span>Used</span>
                    <span>
                      {coupon.usageCount} {coupon.usageLimit !== null ? `/ ${coupon.usageLimit}` : ''}
                    </span>
                  </div>
                </div>
              ) : null}
              <div className="bk-shop-publish__actions">
                {coupon ? (
                  <button type="button" className="button-link is-danger" onClick={() => void remove()} disabled={busy}>
                    Delete
                  </button>
                ) : (
                  <span />
                )}
                <button type="submit" className="button button-primary" disabled={busy}>
                  {busy ? 'Saving…' : isNew ? 'Create coupon' : 'Save coupon'}
                </button>
              </div>
            </div>
          </section>
        </div>
      </form>
    </div>
  );
}
