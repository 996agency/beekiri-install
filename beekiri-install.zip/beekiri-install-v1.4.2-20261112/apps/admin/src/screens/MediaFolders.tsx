import { useEffect, useRef, useState, type DragEvent } from 'react';
import { Trash } from '@phosphor-icons/react';
import type { MediaFolder } from './MediaSettingsPanel';

/** Folders on the Media page: the tree around the files, and tiles that look like folders. */

/** Dragging files of the library (their ids) onto a folder moves them there. */
export const MEDIA_DRAG = 'application/x-beekiri-media';

type FileLike = { id: string; url: string; mimeType: string; folderId: string | null };

export type FolderInfo = {
  /** Files directly in the folder. */
  files: number;
  /** Folders directly in the folder. */
  subfolders: number;
  /** Files in the folder and everything under it. */
  total: number;
  /** Up to three photos from inside, newest first — shown peeking out of the tile. */
  peek: string[];
};

export type FolderIndex = {
  /** Folders by parent (null = top level), sorted by name. */
  children: Map<string | null, MediaFolder[]>;
  info: Map<string, FolderInfo>;
  /** The folder and its parents, top level first. */
  pathOf: (id: string | null) => MediaFolder[];
};

/**
 * A small copy of a photo for thumbnails (the server makes /uploads/_w320/… on first request).
 * Drawings, GIFs and other files have no copies and are shown as they are.
 */
export function mediaThumb(url: string, width: 320 | 480 = 320): string {
  const m = /^\/uploads\/((?!_w\d+\/)[\w./-]+\.(?:webp|jpe?g|png))$/i.exec(url);
  return m && !m[1].split('/').some((part) => part.startsWith('.')) ? `/uploads/_w${width}/${m[1]}` : url;
}

export function indexFolders(folders: MediaFolder[], items: FileLike[]): FolderIndex {
  const byId = new Map(folders.map((f) => [f.id, f]));
  const children = new Map<string | null, MediaFolder[]>();
  for (const f of folders) {
    // A folder whose parent is gone shows at the top level instead of disappearing.
    const parent = f.parentId && byId.has(f.parentId) ? f.parentId : null;
    children.set(parent, [...(children.get(parent) ?? []), f]);
  }
  for (const list of children.values()) list.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));

  const direct = new Map<string, FileLike[]>();
  for (const item of items) {
    if (item.folderId && byId.has(item.folderId)) direct.set(item.folderId, [...(direct.get(item.folderId) ?? []), item]);
  }

  const info = new Map<string, FolderInfo>();
  const visit = (folder: MediaFolder, seen: Set<string>): { total: number; photos: string[] } => {
    if (seen.has(folder.id)) return { total: 0, photos: [] };
    seen.add(folder.id);
    const own = direct.get(folder.id) ?? [];
    const kids = children.get(folder.id) ?? [];
    let total = own.length;
    // Photos of the folder itself first, then of the folders inside it.
    const photos = own.filter((i) => i.mimeType.startsWith('image/')).map((i) => i.url);
    for (const kid of kids) {
      const sub = visit(kid, seen);
      total += sub.total;
      photos.push(...sub.photos);
    }
    info.set(folder.id, { files: own.length, subfolders: kids.length, total, peek: photos.slice(0, 3) });
    return { total, photos: photos.slice(0, 3) };
  };
  const seen = new Set<string>();
  for (const top of children.get(null) ?? []) visit(top, seen);
  // Folders caught in a loop of parents were never reached from the top.
  for (const f of folders) {
    if (!info.has(f.id)) info.set(f.id, { files: direct.get(f.id)?.length ?? 0, subfolders: 0, total: direct.get(f.id)?.length ?? 0, peek: [] });
  }

  const pathOf = (id: string | null) => {
    const path: MediaFolder[] = [];
    const guard = new Set<string>();
    let cur = id ? byId.get(id) : undefined;
    while (cur && !guard.has(cur.id)) {
      guard.add(cur.id);
      path.unshift(cur);
      cur = cur.parentId ? byId.get(cur.parentId) : undefined;
    }
    return path;
  };

  return { children, info, pathOf };
}

/** The folder and every folder inside it, at any depth. */
export function folderAndInside(folders: MediaFolder[], id: string): Set<string> {
  const out = new Set([id]);
  let grew = true;
  while (grew) {
    grew = false;
    for (const f of folders) {
      if (f.parentId && out.has(f.parentId) && !out.has(f.id)) {
        out.add(f.id);
        grew = true;
      }
    }
  }
  return out;
}

/** "12 files · 2 folders" */
export function folderSummary(info: FolderInfo | undefined): string {
  if (!info || (info.total === 0 && info.subfolders === 0)) return 'Empty';
  const parts = [`${info.total} file${info.total === 1 ? '' : 's'}`];
  if (info.subfolders) parts.push(`${info.subfolders} folder${info.subfolders === 1 ? '' : 's'}`);
  return parts.join(' · ');
}

/** The folder drawing: a back with its tab, photos from inside, and a front that opens on hover. */
function FolderArt({ peek = [] }: { peek?: string[] }) {
  return (
    <span className="bk-folder__art" aria-hidden>
      <span className="bk-folder__back" />
      {peek.map((url, i) => (
        <img key={url + i} className="bk-folder__photo" src={mediaThumb(url)} alt="" loading="lazy" decoding="async" draggable={false} />
      ))}
      <span className="bk-folder__front" />
    </span>
  );
}

/** A small folder for list rows and the path above the files. */
export function FolderGlyph({ size = 18 }: { size?: number }) {
  return (
    <svg className="bk-folder-glyph" width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path className="bk-folder-glyph__back" d="M2.5 6.6A1.6 1.6 0 0 1 4.1 5h4.6c.5 0 .9.2 1.2.6l1 1.4h9a1.6 1.6 0 0 1 1.6 1.6V10h-19V6.6Z" />
      <rect className="bk-folder-glyph__front" x="2.5" y="8.6" width="19" height="10.9" rx="1.8" />
    </svg>
  );
}

type TileProps = {
  folder: MediaFolder;
  info: FolderInfo | undefined;
  onOpen: () => void;
  /** Library files dropped on the folder (to move them in). */
  onDropItems?: (ids: string[]) => void;
  /** Files from the computer dropped on the folder (to upload into it). */
  onDropFiles?: (files: FileList) => void;
  /** Shown as a bin button on hover. */
  onDelete?: () => void;
};

/** Drag-and-drop for a folder: library files move in, files from the computer upload into it. */
function useFolderDrop({ onDropItems, onDropFiles }: Pick<TileProps, 'onDropItems' | 'onDropFiles'>) {
  const [over, setOver] = useState(false);
  const accepts = (e: DragEvent) =>
    (onDropItems && e.dataTransfer.types.includes(MEDIA_DRAG)) || (onDropFiles && e.dataTransfer.types.includes('Files'));
  const handlers = {
    onDragOver: (e: DragEvent) => {
      if (!accepts(e)) return;
      e.preventDefault();
      e.stopPropagation();
      e.dataTransfer.dropEffect = e.dataTransfer.types.includes(MEDIA_DRAG) ? 'move' : 'copy';
      setOver(true);
    },
    onDragLeave: (e: DragEvent) => {
      if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setOver(false);
    },
    onDrop: (e: DragEvent) => {
      setOver(false);
      if (!accepts(e)) return;
      e.preventDefault();
      e.stopPropagation();
      const ids = e.dataTransfer.getData(MEDIA_DRAG);
      if (ids && onDropItems) onDropItems(JSON.parse(ids) as string[]);
      else if (e.dataTransfer.files?.length && onDropFiles) onDropFiles(e.dataTransfer.files);
    },
  };
  return { over, handlers };
}

function DeleteFolderButton({ name, onDelete }: { name: string; onDelete: () => void }) {
  return (
    <button type="button" className="bk-folder__delete" title={`Delete ${name}`} aria-label={`Delete folder ${name}`} onClick={onDelete}>
      <Trash size={14} />
    </button>
  );
}

export function FolderTile({ folder, info, onOpen, onDropItems, onDropFiles, onDelete }: TileProps) {
  const { over, handlers } = useFolderDrop({ onDropItems, onDropFiles });
  return (
    <div className={`bk-folder-cell${over ? ' is-drop' : ''}`} {...handlers}>
      <button type="button" className="bk-folder" title={`Open ${folder.name}`} onClick={onOpen}>
        <FolderArt peek={info?.peek} />
        <span className="bk-folder__name">{folder.name}</span>
        <span className="bk-folder__meta">{folderSummary(info)}</span>
      </button>
      {onDelete ? <DeleteFolderButton name={folder.name} onDelete={onDelete} /> : null}
    </div>
  );
}

/** A folder as one compact pill (list view, under the search). */
export function FolderChip({ folder, info, onOpen, onDropItems, onDropFiles, onDelete }: TileProps) {
  const { over, handlers } = useFolderDrop({ onDropItems, onDropFiles });
  return (
    <div className={`bk-folder-chip${over ? ' is-drop' : ''}`} {...handlers}>
      <button type="button" className="bk-folder-chip__open" title={`Open ${folder.name}`} onClick={onOpen}>
        <FolderGlyph size={20} />
        <span className="bk-folder-chip__name">{folder.name}</span>
        <span className="bk-folder-chip__meta">{folderSummary(info)}</span>
      </button>
      {onDelete ? <DeleteFolderButton name={folder.name} onDelete={onDelete} /> : null}
    </div>
  );
}

/** A folder that is being named: Enter (or clicking away) keeps it, Escape drops it. */
export function NewFolderTile({ busy, onCreate, onCancel }: { busy: boolean; onCreate: (name: string) => void; onCancel: () => void }) {
  const [name, setName] = useState('');
  const input = useRef<HTMLInputElement>(null);
  /** Enter, then the blur as the tile goes away: only the first one counts. */
  const done = useRef(false);
  useEffect(() => {
    input.current?.focus();
  }, []);
  const finish = (keep = true) => {
    if (done.current) return;
    done.current = true;
    const clean = keep ? name.trim() : '';
    if (clean) onCreate(clean);
    else onCancel();
  };
  return (
    <form
      className="bk-folder is-new"
      onSubmit={(e) => {
        e.preventDefault();
        finish();
      }}
    >
      <FolderArt />
      <input
        ref={input}
        className="bk-folder__input"
        type="text"
        value={name}
        maxLength={80}
        disabled={busy}
        placeholder="Folder name"
        aria-label="Folder name"
        onChange={(e) => setName(e.target.value)}
        onBlur={() => finish()}
        onKeyDown={(e) => {
          if (e.key === 'Escape') {
            e.preventDefault();
            finish(false);
          }
        }}
      />
      <span className="bk-folder__meta">{busy ? 'Creating…' : 'Enter to create'}</span>
    </form>
  );
}
