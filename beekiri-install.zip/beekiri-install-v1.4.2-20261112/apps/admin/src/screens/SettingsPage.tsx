import { ChangeEvent, FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { api, apiUpload, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { CoreUpdateRunner } from '../components/CoreUpdateRunner';
import { signalSiteEnterReady } from '../components/SiteEnterCover';
import { SuccessNotice } from '../components/SuccessNotice';
import { useCoreUpdate } from '../core/CoreUpdateContext';
import {
  canAccessSettingsSection,
  canAccessSettingsTab,
  canUpdateCore,
} from '../lib/admin-capabilities';
import { useAdminHref } from '../lib/AdminEntryContext';
import { SITE_URL } from '../config';
import { MediaSettings, MediaSettingsPanel } from './MediaSettingsPanel';
import { EmailSettingsPanel } from './EmailSettingsPanel';
import { InstructionsPanel } from './InstructionsPanel';
import { MigrationPanel } from './MigrationPanel';
import { SitesPanel } from './SitesPanel';
import {
  MenuItem,
  PermalinkStructure,
  PermalinksPanel,
} from './PermalinksPanel';
import { SiteCodePanel } from './SiteCodePanel';
import { TranslationPanel } from './TranslationPanel';

function parseSitemapLocs(xml: string): string[] {
  const locs: string[] = [];
  const re = /<loc>\s*([^<]+?)\s*<\/loc>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml))) {
    const url = m[1]?.trim();
    if (url) locs.push(url);
  }
  return locs;
}

function ReadingSitemapPanel({
  blogPublic,
  adminBasePath,
}: {
  blogPublic: boolean;
  adminBasePath: string;
}) {
  const sitemapUrl = `${SITE_URL}/sitemap.xml`;
  const robotsUrl = `${SITE_URL}/robots.txt`;
  const adminPath = (adminBasePath || '/admin').replace(/\/+$/, '') || '/admin';
  const [urls, setUrls] = useState<string[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setLoadError(null);
    fetch(sitemapUrl, { credentials: 'same-origin' })
      .then(async (res) => {
        if (!res.ok) throw new Error(`Could not load sitemap (${res.status}).`);
        return res.text();
      })
      .then((xml) => {
        if (cancelled) return;
        setUrls(parseSitemapLocs(xml));
      })
      .catch((e) => {
        if (cancelled) return;
        setUrls(null);
        setLoadError(e instanceof Error ? e.message : 'Could not load sitemap.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [sitemapUrl, blogPublic]);

  return (
    <tr>
      <th scope="row">Sitemap</th>
      <td>
        <div className="bk-sitemap">
          <p className="bk-sitemap__intro">
            Public URL for search engines:{' '}
            <a href={sitemapUrl} target="_blank" rel="noreferrer">
              <code>{sitemapUrl}</code>
            </a>
            <span className="bk-sitemap__sep" aria-hidden>
              ·
            </span>
            <a href={robotsUrl} target="_blank" rel="noreferrer">
              <code>{robotsUrl}</code>
            </a>
          </p>
          {!blogPublic ? (
            <p className="bk-sitemap__note">
              Search engines are told not to index this site (<code>Disallow: /</code> in
              robots.txt). The sitemap file may still exist, but crawlers are asked to stay away.
            </p>
          ) : (
            <p className="bk-sitemap__note">
              Admin is excluded from indexing (<code>{adminPath}</code>
              {adminPath !== '/admin' ? ' and /admin' : ''}). It will not appear in the sitemap.
            </p>
          )}
          <div className="bk-sitemap__box">
            <div className="bk-sitemap__box-head">
              <h3 className="bk-sitemap__box-title">Current sitemap</h3>
              {urls && urls.length > 0 ? (
                <span className="bk-sitemap__count">
                  {urls.length} URL{urls.length === 1 ? '' : 's'}
                </span>
              ) : null}
            </div>
            <div className="bk-sitemap__box-body">
              {loading ? (
                <p className="bk-muted">Loading…</p>
              ) : loadError ? (
                <p className="bk-muted" role="alert">
                  {loadError}
                </p>
              ) : !urls?.length ? (
                <p className="bk-muted">No URLs listed yet.</p>
              ) : (
                <ul className="bk-sitemap__list">
                  {urls.map((u) => (
                    <li key={u}>
                      <a href={u} target="_blank" rel="noreferrer">
                        {u}
                      </a>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      </td>
    </tr>
  );
}

type Tab =
  | 'core'
  | 'general'
  | 'page-editor'
  | 'advanced'
  | 'translation'
  | 'permalinks'
  | 'media'
  | 'email'
  | 'cache'
  | 'migration'
  | 'sites'
  | 'instructions';

const TAB_IDS = new Set<Tab>([
  'core',
  'general',
  'page-editor',
  'advanced',
  'translation',
  'permalinks',
  'media',
  'email',
  'cache',
  'migration',
  'sites',
  'instructions',
]);

function tabFromSearch(params: URLSearchParams): Tab | null {
  const raw = params.get('tab');
  // Reading and Writing moved into Advanced; keep old links working.
  if (raw === 'reading' || raw === 'writing') return 'advanced';
  if (raw && TAB_IDS.has(raw as Tab)) return raw as Tab;
  return null;
}

type FrontendRuntime = 'react' | 'php';

type SiteSettings = {
  id: string;
  title: string;
  tagline: string;
  language: string;
  blogPublic: boolean;
  timezone: string;
  dateFormat: string;
  timeFormat: string;
  businessName: string;
  businessCategory: string;
  businessPhone: string;
  businessAddress: string;
  businessHours: string;
  businessImageUrl: string;
  /** Settings → General → Site code */
  customHeadHtml: string;
  customBodyHtml: string;
  customFooterHtml: string;
  faviconUrl: string;
  faviconResolved?: string;
  faviconDefault?: string;
  /** Admin SPA mount, e.g. `/admin` or `/my-hive`. */
  adminBasePath: string;
  /** Sign-in URL segment: {adminBasePath}/{adminLoginSlug} */
  adminLoginSlug: string;
  adminLoginPath?: string;
  permalinkStructure: PermalinkStructure;
  permalinkCustom: string;
  menuItems: MenuItem[];
  frontPageId?: string;
  frontPageSlug?: string;
  media: MediaSettings;
  pageEditorStyle: 'beekiricode';
  frontendRuntime: FrontendRuntime;
};

type SystemStatus = {
  api: { ok: boolean; label: string };
  database: { ok: boolean; label: string };
  uptimeSeconds: number;
  nodeVersion: string;
  environment: string;
  coreVersion: string;
  channel: string;
  checkedAt: string;
  frontend?: string;
  admin?: string;
  apiStack?: string;
  databaseEngine?: string;
};

const TABS: { id: Tab; label: string }[] = [
  { id: 'core', label: 'Beekiri Core' },
  { id: 'general', label: 'General' },
  { id: 'page-editor', label: 'Page editor' },
  { id: 'advanced', label: 'Advanced' },
  { id: 'translation', label: 'Translation' },
  { id: 'permalinks', label: 'Permalinks' },
  { id: 'media', label: 'Media' },
  { id: 'email', label: 'Email' },
  { id: 'cache', label: 'Cache' },
  { id: 'migration', label: 'Migration' },
  { id: 'sites', label: 'Sites' },
  { id: 'instructions', label: 'Instructions' },
];

function formatUptime(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  if (m < 60) return `${m}m ${s}s`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  if (h < 24) return `${h}h ${rm}m`;
  const d = Math.floor(h / 24);
  return `${d}d ${h % 24}h`;
}

function StatusValue({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span className={`bk-status ${ok ? 'is-ok' : 'is-down'}`}>
      <span className="bk-status__dot" aria-hidden />
      {label}
    </span>
  );
}

export function SettingsPage() {
  const auth = useAuth();
  const href = useAdminHref();
  const caps = auth.user?.capabilities ?? [];
  const allowCoreUpdates = canUpdateCore(caps);
  const canReading = canAccessSettingsSection(caps, 'reading');
  const canWriting = canAccessSettingsSection(caps, 'writing');
  const canLanguage = canAccessSettingsSection(caps, 'advanced');
  const visibleTabs = useMemo(
    // The owner's alone: Sites manages the whole network, Migration copies and replaces every
    // account, and Email decides where password-reset links travel.
    () =>
      TABS.filter((t) =>
        t.id === 'sites' || t.id === 'migration' || t.id === 'email' ? Boolean(auth.user?.isOwner) : canAccessSettingsTab(caps, t.id),
      ),
    [caps, auth.user?.isOwner],
  );
  const coreUpdate = useCoreUpdate();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const faviconFileRef = useRef<HTMLInputElement>(null);
  const [tab, setTab] = useState<Tab>(() => tabFromSearch(searchParams) ?? 'core');
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [busy, setBusy] = useState(false);
  const [faviconUploading, setFaviconUploading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [flushing, setFlushing] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  /** Confirm before switching site-wide PHP ↔ React layout runtime. */
  const [panelPhase, setPanelPhase] = useState<'in' | 'out'>('in');
  const tabSwitchTimer = useRef<number | null>(null);

  const panelReady =
    tab === 'instructions' ||
    tab === 'email' ||
    tab === 'cache' ||
    tab === 'migration' ||
    tab === 'sites' ||
    (tab === 'core' ? Boolean(status) : Boolean(settings));

  useEffect(() => {
    if (!panelReady) return;
    const id = window.requestAnimationFrame(() => {
      window.requestAnimationFrame(() => signalSiteEnterReady());
    });
    return () => window.cancelAnimationFrame(id);
  }, [panelReady]);

  const applyTab = (next: Tab) => {
    if (next === tab) return;
    if (tabSwitchTimer.current) window.clearTimeout(tabSwitchTimer.current);
    setPanelPhase('out');
    setError(null);
    setNotice(null);
    tabSwitchTimer.current = window.setTimeout(() => {
      setTab(next);
      setPanelPhase('in');
      tabSwitchTimer.current = null;
    }, 220);
  };

  const selectTab = (next: Tab) => {
    if (next === tab) return;
    setSearchParams(next === 'core' ? {} : { tab: next }, { replace: true });
  };

  useEffect(() => {
    if (searchParams.get('tab') === 'bee-cookies') {
      navigate(href('analytics/cookies'), { replace: true });
      return;
    }
    const fromUrl = tabFromSearch(searchParams) ?? 'core';
    if (fromUrl !== tab) applyTab(fromUrl);
    // URL is the source of truth (toolbar search + tab clicks).
    // eslint-disable-next-line react-hooks/exhaustive-deps -- intentional URL sync
  }, [searchParams]);

  useEffect(() => {
    if (!visibleTabs.some((t) => t.id === tab)) {
      const fallback = (visibleTabs[0]?.id ?? 'core') as Tab;
      selectTab(fallback);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- keep on allowed tab
  }, [visibleTabs, tab]);

  const updates = coreUpdate.updates;
  const updateAvailable = coreUpdate.updateAvailable;
  const updateCount = coreUpdate.updateCount;

  const loadSettings = async () => {
    const s = await api<SiteSettings>('/api/site/settings');
    setSettings({
      ...s,
      businessName: s.businessName ?? '',
      businessCategory: s.businessCategory ?? '',
      businessPhone: s.businessPhone ?? '',
      businessAddress: s.businessAddress ?? '',
      businessHours: s.businessHours ?? '',
      businessImageUrl: s.businessImageUrl ?? '',
      customHeadHtml: s.customHeadHtml ?? '',
      customBodyHtml: s.customBodyHtml ?? '',
      customFooterHtml: s.customFooterHtml ?? '',
      faviconUrl: s.faviconUrl ?? '',
      faviconResolved: s.faviconResolved ?? '/icon-512.png',
      faviconDefault: s.faviconDefault ?? '/icon-512.png',
      adminBasePath: s.adminBasePath ?? '/admin',
      adminLoginSlug: s.adminLoginSlug ?? 'login',
      adminLoginPath: s.adminLoginPath ?? '/admin/login',
      permalinkStructure: s.permalinkStructure ?? 'postname',
      permalinkCustom: s.permalinkCustom ?? '/%postname%/',
      frontPageId: s.frontPageId ?? '',
      frontPageSlug: s.frontPageSlug ?? '',
      pageEditorStyle: 'beekiricode',
      frontendRuntime: s.frontendRuntime === 'react' ? 'react' : 'php',
      menuItems: s.menuItems?.length
        ? s.menuItems
        : [
            { id: 'home', label: 'Home', path: '/', enabled: true },
            { id: 'blog', label: 'Blog', path: '/blog', enabled: true },
            { id: 'about', label: 'About', path: '/about', enabled: false },            { id: 'contact', label: 'Contact', path: '/contact', enabled: false },
          ],
      media: s.media
        ? {
            ...s.media,
            folders: (s.media.folders ?? []).map((f) => ({
              ...f,
              parentId: f.parentId ?? null,
            })),
          }
        : {
            convertToWebp: true,
            webpLossless: true,
            webpQuality: 100,
            maxWidth: 1920,
            maxHeight: 1920,
            stripMetadata: true,
            keepOriginal: false,
            folders: [
              { id: 'general', name: 'General', slug: 'general', parentId: null },
              { id: 'heroes', name: 'Heroes', slug: 'heroes', parentId: null },
              { id: 'blog', name: 'Blog', slug: 'blog', parentId: null },
            ],
          },
    });
  };

  const loadCore = async () => {
    const s = await api<SystemStatus>('/api/system/status');
    setStatus(s);
  };

  useEffect(() => {
    return () => {
      if (tabSwitchTimer.current) window.clearTimeout(tabSwitchTimer.current);
    };
  }, []);

  useEffect(() => {
    if (tab === 'core') {
      loadCore().catch((e) =>
        setError(e instanceof ApiError ? e.message : 'Could not load core status'),
      );
      void coreUpdate.refresh();
    } else if (tab !== 'instructions') {
      loadSettings().catch((e) =>
        setError(e instanceof ApiError ? e.message : 'Could not load settings'),
      );
    }
  }, [tab]);

  const refreshStatus = async () => {
    setRefreshing(true);
    setError(null);
    try {
      await loadCore();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Could not refresh status');
    } finally {
      setRefreshing(false);
    }
  };

  const saveSettings = async (e: FormEvent, patch: Partial<SiteSettings>) => {
    e.preventDefault();
    if (!settings) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const saved = await api<SiteSettings>('/api/site/settings', {
        method: 'PATCH',
        json: patch,
      });
      setSettings({
        ...saved,
        adminBasePath: saved.adminBasePath ?? '/admin',
        adminLoginSlug: saved.adminLoginSlug ?? 'login',
        adminLoginPath: saved.adminLoginPath ?? '/admin/login',
        customHeadHtml: saved.customHeadHtml ?? '',
        customBodyHtml: saved.customBodyHtml ?? '',
        customFooterHtml: saved.customFooterHtml ?? '',
        businessName: saved.businessName ?? '',
        businessCategory: saved.businessCategory ?? '',
        businessPhone: saved.businessPhone ?? '',
        businessAddress: saved.businessAddress ?? '',
        businessHours: saved.businessHours ?? '',
        businessImageUrl: saved.businessImageUrl ?? '',
      });
      if (patch.adminBasePath !== undefined || patch.adminLoginSlug !== undefined) {
        window.dispatchEvent(
          new CustomEvent('beekiri:admin-entry-changed', {
            detail: {
              adminBasePath: saved.adminBasePath,
              adminLoginSlug: saved.adminLoginSlug,
              adminLoginPath: saved.adminLoginPath,
            },
          }),
        );
        const nextBase = saved.adminBasePath ?? '/admin';
        const nextLogin =
          saved.adminLoginPath ?? `${nextBase}/${saved.adminLoginSlug ?? 'login'}`;
        setNotice(
          `Settings saved. Admin is at ${nextBase}; sign-in is ${nextLogin}. Bookmark both — the old /admin URLs stop working when you change the base.`,
        );
        // Hard navigate so the SPA remounts under the new base path.
        if (
          patch.adminBasePath !== undefined &&
          nextBase !== (settings?.adminBasePath ?? '/admin')
        ) {
          window.setTimeout(() => {
            window.location.assign(`${nextBase}/settings`);
          }, 400);
        }
      } else {
        setNotice('Settings saved.');
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Save failed');
    } finally {
      setBusy(false);
    }
  };

  const checkUpdates = async () => {
    setError(null);
    setNotice(null);
    const u = await coreUpdate.refresh();
    if (!u) {
      setError('Could not check for updates. Confirm the API is running, then try again.');
      return;
    }
    if (u.source === 'error') {
      setError(u.message || 'Could not check for updates right now.');
      return;
    }
    if (u.updateAvailable && u.latestVersion) {
      setNotice(`Update available: Beekiri Core v${u.latestVersion}.`);
      return;
    }
    setNotice(`You're up to date on Beekiri Core v${u.currentVersion}.`);
  };

  return (
    <div className={`wrap${tab === 'permalinks' || tab === 'translation' ? ' is-full' : ''}`}>
      <h1>
        Settings
        {allowCoreUpdates && updateCount > 0 ? (
          <span className="bk-count" aria-label={`${updateCount} update available`}>
            +{updateCount}
          </span>
        ) : null}
      </h1>

      <nav className="bk-tabs" aria-label="Settings sections">
        {visibleTabs.map(({ id, label }) => (
          <button
            key={id}
            type="button"
            className={`bk-tabs__item${tab === id ? ' is-active' : ''}`}
            onClick={() => selectTab(id)}
          >
            {label}
            {id === 'core' && allowCoreUpdates && updateCount > 0 ? (
              <span className="bk-count">+{updateCount}</span>
            ) : null}
          </button>
        ))}
      </nav>

      {error && (
        <div className="beekiri-notice is-error">
          <p>{error}</p>
        </div>
      )}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}

      <div
        className={`bk-settings-panel is-${panelPhase}${panelReady ? '' : ' is-loading'}`}
        aria-busy={!panelReady}
      >
      {!panelReady ? (
        <div className="bk-settings-panel__loading" role="status">
          <span className="bk-settings-panel__spinner" aria-hidden />
          <span>Loading…</span>
        </div>
      ) : null}
      {panelReady && tab === 'general' && settings && (
        <form
          className="bk-stack"
          onSubmit={(e) =>
            void saveSettings(e, {
              title: settings.title,
              tagline: settings.tagline,
              businessName: settings.businessName,
              businessCategory: settings.businessCategory,
              businessPhone: settings.businessPhone,
              businessAddress: settings.businessAddress,
              businessHours: settings.businessHours,
              businessImageUrl: settings.businessImageUrl,
              faviconUrl: settings.faviconUrl.trim(),
              adminBasePath: (settings.adminBasePath ?? '/admin').trim() || '/admin',
              adminLoginSlug: (settings.adminLoginSlug ?? 'login').trim() || 'login',
              customHeadHtml: settings.customHeadHtml ?? '',
              customBodyHtml: settings.customBodyHtml ?? '',
              customFooterHtml: settings.customFooterHtml ?? '',
            })
          }
        >
          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Site</h2>
            </div>
            <div className="bk-panel__body">
              <table className="form-table">
                <tbody>
                  <tr>
                    <th scope="row">
                      <label htmlFor="blogname">Site title</label>
                    </th>
                    <td>
                      <input
                        id="blogname"
                        className="regular-text"
                        value={settings.title}
                        onChange={(e) => setSettings({ ...settings, title: e.target.value })}
                        required
                      />
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="blogdescription">Tagline</label>
                    </th>
                    <td>
                      <input
                        id="blogdescription"
                        className="regular-text"
                        value={settings.tagline}
                        onChange={(e) => setSettings({ ...settings, tagline: e.target.value })}
                      />
                      <p className="description">Shown on the public landing page.</p>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="site_favicon">Favicon</label>
                    </th>
                    <td>
                      <div className="bk-favicon-field">
                        <img
                          className="bk-favicon-field__preview"
                          src={
                            settings.faviconUrl.trim() ||
                            settings.faviconDefault ||
                            '/icon-512.png'
                          }
                          alt=""
                          width={32}
                          height={32}
                        />
                        <div className="bk-favicon-field__inputs">
                          <div className="bk-favicon-field__row">
                            <input
                              id="site_favicon"
                              className="regular-text"
                              type="text"
                              placeholder="/icon-512.png or https://…"
                              value={settings.faviconUrl}
                              onChange={(e) =>
                                setSettings({ ...settings, faviconUrl: e.target.value })
                              }
                            />
                            <button
                              type="button"
                              className="button"
                              disabled={faviconUploading || busy}
                              onClick={() => faviconFileRef.current?.click()}
                            >
                              {faviconUploading ? 'Uploading…' : 'Upload'}
                            </button>
                            <input
                              ref={faviconFileRef}
                              type="file"
                              accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml,image/x-icon,.ico"
                              hidden
                              onChange={async (e: ChangeEvent<HTMLInputElement>) => {
                                const file = e.target.files?.[0];
                                if (!file) return;
                                setFaviconUploading(true);
                                setError(null);
                                setNotice(null);
                                try {
                                  const form = new FormData();
                                  form.append('file', file);
                                  form.append('purpose', 'favicon');
                                  const res = await apiUpload<{ item: { url: string } }>(
                                    '/api/media/upload?purpose=favicon',
                                    form,
                                  );
                                  setSettings({ ...settings, faviconUrl: res.item.url });
                                  setNotice(
                                    'Favicon uploaded. Click Save changes to apply it to the site.',
                                  );
                                } catch (err) {
                                  setError(
                                    err instanceof ApiError
                                      ? err.message
                                      : err instanceof Error
                                        ? err.message
                                        : 'Upload failed.',
                                  );
                                } finally {
                                  setFaviconUploading(false);
                                  if (faviconFileRef.current) faviconFileRef.current.value = '';
                                }
                              }}
                            />
                          </div>
                          <p className="description">
                            Browser tab icon for this client site. Upload a file (saved to Media) or
                            paste a URL / path. Leave blank for the Beekiri default (
                            <code>/icon-512.png</code>).
                          </p>
                          {settings.faviconUrl.trim() ? (
                            <button
                              type="button"
                              className="button"
                              onClick={() => setSettings({ ...settings, faviconUrl: '' })}
                            >
                              Reset to default
                            </button>
                          ) : null}
                        </div>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="admin_base_path">Admin URL</label>
                    </th>
                    <td>
                      <input
                        id="admin_base_path"
                        className="regular-text"
                        type="text"
                        minLength={2}
                        maxLength={80}
                        pattern="/?[A-Za-z0-9._\-]+(/[A-Za-z0-9._\-]+)*"
                        required
                        value={settings.adminBasePath ?? '/admin'}
                        onChange={(e) =>
                          setSettings({ ...settings, adminBasePath: e.target.value })
                        }
                      />
                      <p className="description">
                        Where the whole admin lives after install. Default is <code>/admin</code>.
                        Change it to something only you know (e.g. <code>/my-hive</code>) — then{' '}
                        <code>/admin</code> will show “Not Found”. Bookmark the new address after
                        saving.
                      </p>
                      <p className="description">
                        Current admin:{' '}
                        <code>
                          {typeof window !== 'undefined'
                            ? `${window.location.origin}${settings.adminBasePath || '/admin'}`
                            : settings.adminBasePath || '/admin'}
                        </code>
                      </p>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="admin_login_slug">Login path</label>
                    </th>
                    <td>
                      <div className="bk-admin-login-field">
                        <code className="bk-muted">
                          {(settings.adminBasePath || '/admin').replace(/\/$/, '')}/
                        </code>
                        <input
                          id="admin_login_slug"
                          className="regular-text"
                          type="text"
                          minLength={3}
                          maxLength={64}
                          pattern="[A-Za-z0-9._\-]+"
                          required
                          value={settings.adminLoginSlug ?? 'login'}
                          onChange={(e) =>
                            setSettings({ ...settings, adminLoginSlug: e.target.value })
                          }
                        />
                      </div>
                      <p className="description">
                        Sign-in segment under your admin URL. Default is <code>login</code>.
                      </p>
                      <p className="description">
                        Current sign-in:{' '}
                        <code>
                          {typeof window !== 'undefined'
                            ? `${window.location.origin}${(settings.adminBasePath || '/admin').replace(/\/$/, '')}/${settings.adminLoginSlug || 'login'}`
                            : `${(settings.adminBasePath || '/admin').replace(/\/$/, '')}/${settings.adminLoginSlug || 'login'}`}
                        </code>
                      </p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <SiteCodePanel
            value={{
              customHeadHtml: settings.customHeadHtml ?? '',
              customBodyHtml: settings.customBodyHtml ?? '',
              customFooterHtml: settings.customFooterHtml ?? '',
            }}
            onChange={(next) => setSettings({ ...settings, ...next })}
            business={{
              title: settings.title,
              tagline: settings.tagline,
              businessName: settings.businessName,
              businessCategory: settings.businessCategory,
              businessPhone: settings.businessPhone,
              businessAddress: settings.businessAddress,
              businessHours: settings.businessHours,
              businessImageUrl: settings.businessImageUrl,
            }}
            onBusinessChange={(patch) => setSettings({ ...settings, ...patch })}
          />

          <p className="submit" style={{ margin: 0 }}>
            <button type="submit" className="button button-primary" disabled={busy}>
              {busy ? 'Saving…' : 'Save changes'}
            </button>
          </p>
        </form>
      )}

      {panelReady && tab === 'page-editor' && settings && (
        <div className="bk-stack">
          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Frontend</h2>
            </div>
            <div className="bk-panel__body">
              <p className="bk-muted" style={{ marginTop: 0, marginBottom: 16 }}>
                This site was installed with the{' '}
                <strong>{settings.frontendRuntime === 'react' ? 'React' : 'PHP'}</strong> frontend.
                Every theme template — header, footer, and layouts — runs from{' '}
                <code>{settings.frontendRuntime === 'react' ? '.tsx' : '.php'}</code> files. The CMS
                (pages, media, fields) works the same either way.
              </p>
              <div className="bk-choice-grid" aria-label="Installed frontend">
                <div className="bk-choice-card is-selected" aria-current="true">
                  <span className="bk-choice-card__radio" aria-hidden />
                  <span className="bk-choice-card__body">
                    <span className="bk-choice-card__title">
                      {settings.frontendRuntime === 'react' ? 'React' : 'PHP'}
                      <span className="bk-choice-card__badge">Installed</span>
                    </span>
                    <span className="bk-choice-card__blurb">
                      {settings.frontendRuntime === 'react'
                        ? 'Theme templates are React components rendered by the Next.js frontend.'
                        : 'Theme templates are PHP files using the Bee field API.'}
                    </span>
                    <span className="bk-choice-card__files">
                      {(settings.frontendRuntime === 'react'
                        ? ['header/header.tsx', 'footer/footer.tsx', 'layouts/hero/hero.tsx']
                        : ['header/header.php', 'footer/footer.php', 'layouts/hero/hero.php']
                      ).map((f) => (
                        <code key={f}>{f}</code>
                      ))}
                    </span>
                  </span>
                </div>
              </div>
              <p className="bk-muted" style={{ marginTop: 14, marginBottom: 0 }}>
                The frontend is locked after install so a site never mixes PHP and React templates.
                To use a different frontend, install a new site into an empty database.
              </p>
              <p className="bk-muted" style={{ marginTop: 10, marginBottom: 0, fontSize: 12 }}>
                Tip: remove the <code>@beekiri-managed</code> line from a layout file so Beekiri
                stops regenerating it when you save field groups.
              </p>
            </div>
          </div>
        </div>
      )}

      {panelReady && tab === 'advanced' && settings && (
        <form
          className="bk-stack"
          onSubmit={(e) =>
            void saveSettings(e, {
              ...(canReading ? { blogPublic: settings.blogPublic } : {}),
              ...(canWriting
                ? { dateFormat: settings.dateFormat, timeFormat: settings.timeFormat }
                : {}),
              ...(canLanguage ? { language: settings.language, timezone: settings.timezone } : {}),
            })
          }
        >
          {canReading ? (
            <div className="bk-panel">
              <div className="bk-panel__head">
                <h2 className="bk-panel__title">Reading</h2>
              </div>
              <div className="bk-panel__body">
                <table className="form-table">
                  <tbody>
                    <tr>
                      <th scope="row">Search visibility</th>
                      <td>
                        <label className="bk-check">
                          <input
                            type="checkbox"
                            checked={settings.blogPublic}
                            onChange={(e) =>
                              setSettings({ ...settings, blogPublic: e.target.checked })
                            }
                          />
                          <span className="bk-check__box" aria-hidden />
                          <span className="bk-check__label">
                            Allow search engines to index this site
                          </span>
                        </label>
                        <div className="bk-help" style={{ marginTop: 12 }}>
                          <p style={{ margin: 0 }}>
                            <strong>Checked (recommended for live sites):</strong> Google, Bing, and
                            other search engines can find and list your pages.
                          </p>
                          <p style={{ margin: '8px 0 0' }}>
                            <strong>Unchecked:</strong> Beekiri tells crawlers not to index the site
                            (useful while you build or for private staging). Your site still works —
                            visitors can open links — it just stays out of search results as much as
                            crawlers respect the request.
                          </p>
                        </div>
                      </td>
                    </tr>
                    <ReadingSitemapPanel
                      blogPublic={settings.blogPublic}
                      adminBasePath={settings.adminBasePath ?? '/admin'}
                    />
                  </tbody>
                </table>
              </div>
            </div>
          ) : null}

          {canWriting ? (
            <div className="bk-panel">
              <div className="bk-panel__head">
                <h2 className="bk-panel__title">Writing</h2>
              </div>
              <div className="bk-panel__body">
                <table className="form-table">
                  <tbody>
                    <tr>
                      <th scope="row">
                        <label htmlFor="date_format">Date format</label>
                      </th>
                      <td>
                        <input
                          id="date_format"
                          className="regular-text"
                          value={settings.dateFormat}
                          onChange={(e) =>
                            setSettings({ ...settings, dateFormat: e.target.value })
                          }
                        />
                        <p className="description">Used when dates are shown in admin and themes.</p>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">
                        <label htmlFor="time_format">Time format</label>
                      </th>
                      <td>
                        <input
                          id="time_format"
                          className="regular-text"
                          value={settings.timeFormat}
                          onChange={(e) =>
                            setSettings({ ...settings, timeFormat: e.target.value })
                          }
                        />
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          ) : null}

          {canLanguage ? (
            <div className="bk-panel">
              <div className="bk-panel__head">
                <h2 className="bk-panel__title">Language and timezone</h2>
              </div>
              <div className="bk-panel__body">
                <table className="form-table">
                  <tbody>
                    <tr>
                      <th scope="row">
                        <label htmlFor="site_language">Site language</label>
                      </th>
                      <td>
                        <select
                          id="site_language"
                          value={settings.language}
                          onChange={(e) =>
                            setSettings({ ...settings, language: e.target.value })
                          }
                        >
                          <option value="en_US">English (United States)</option>
                          <option value="en_GB">English (UK)</option>
                          <option value="sq">Albanian</option>
                          <option value="de_DE">German</option>
                          <option value="fr_FR">French</option>
                          <option value="it_IT">Italian</option>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">
                        <label htmlFor="timezone_string">Timezone</label>
                      </th>
                      <td>
                        <select
                          id="timezone_string"
                          value={settings.timezone}
                          onChange={(e) =>
                            setSettings({ ...settings, timezone: e.target.value })
                          }
                        >
                          <option value="UTC">UTC</option>
                          <option value="Europe/London">Europe/London</option>
                          <option value="Europe/Berlin">Europe/Berlin</option>
                          <option value="Europe/Tirane">Europe/Tirane</option>
                          <option value="America/New_York">America/New_York</option>
                          <option value="America/Los_Angeles">America/Los_Angeles</option>
                        </select>
                        <p className="description">
                          Changing language or timezone does not rewrite your content. It only affects how
                          the admin and public site format dates and labels going forward.
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          ) : null}

          <p className="submit" style={{ margin: 0 }}>
            <button type="submit" className="button button-primary" disabled={busy}>
              {busy ? 'Saving…' : 'Save changes'}
            </button>
          </p>
        </form>
      )}

      {panelReady && tab === 'translation' && (
        <TranslationPanel
          onNotice={(message) => setNotice(message)}
          onError={(message) => setError(message)}
          onOpenMenu={() => selectTab('permalinks')}
        />
      )}

      {panelReady && tab === 'permalinks' && settings && (
        <PermalinksPanel
          key={`permalinks-${settings.id}-${settings.menuItems.map((m) => m.id).join('.')}`}
          siteTitle={settings.title}
          permalinkStructure={settings.permalinkStructure}
          permalinkCustom={settings.permalinkCustom}
          menuItems={settings.menuItems}
          busy={busy}
          onSave={(data) => {
            void (async () => {
              setBusy(true);
              setError(null);
              setNotice(null);
              try {
                const saved = await api<SiteSettings>('/api/site/settings', {
                  method: 'PATCH',
                  json: data,
                });
                setSettings({
                  ...settings,
                  ...saved,
                  menuItems: saved.menuItems?.length ? saved.menuItems : data.menuItems,
                  permalinkStructure: saved.permalinkStructure ?? data.permalinkStructure,
                  permalinkCustom: saved.permalinkCustom ?? data.permalinkCustom,
                  frontPageId: saved.frontPageId ?? data.frontPageId ?? '',
                  frontPageSlug: saved.frontPageSlug ?? data.frontPageSlug ?? '',
                });
                setNotice('Permalinks and menu saved.');
              } catch (err) {
                setError(err instanceof ApiError ? err.message : 'Save failed');
              } finally {
                setBusy(false);
              }
            })();
          }}
        />
      )}

      {panelReady && tab === 'media' && settings && (
        <MediaSettingsPanel
          key={`media-${settings.id}-${settings.media.folders.map((f) => f.id).join('.')}`}
          media={settings.media}
          busy={busy}
          onSave={(media) => {
            void (async () => {
              setBusy(true);
              setError(null);
              setNotice(null);
              try {
                // Folders are managed on the Media page: save the ones that exist now, not the
                // list this tab loaded (a folder made since then would be lost).
                const latest = await api<SiteSettings>('/api/site/settings');
                const saved = await api<SiteSettings>('/api/site/settings', {
                  method: 'PATCH',
                  json: { media: { ...media, folders: latest.media?.folders ?? media.folders } },
                });
                setSettings({
                  ...settings,
                  media: saved.media ?? media,
                });
                setNotice('Media settings saved.');
              } catch (err) {
                setError(err instanceof ApiError ? err.message : 'Save failed');
              } finally {
                setBusy(false);
              }
            })();
          }}
        />
      )}

      {panelReady && tab === 'cache' && (
        <div className="bk-stack">
          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Cache</h2>
            </div>
            <div className="bk-panel__body">
              <p className="bk-muted" style={{ marginTop: 0 }}>
                Full flush busts theme/layout CSS &amp; JS URLs, revalidates the public Next.js
                pages, clears the hive Lighthouse cache, and rebuilds the production web bundle
                used for Performance scores.
              </p>
              <div className="beekiri-notice is-info" style={{ marginBottom: 16 }}>
                <p style={{ margin: '0 0 8px' }}>
                  <strong>How PageSpeed is measured</strong>
                </p>
                <p style={{ margin: 0 }}>
                  Performance scores come from <strong>Hive status</strong> in the admin bar.
                  Refresh that control after a cache flush to update the report. Scores from
                  other browser tools or extensions may differ and are not used by Beekiri.
                </p>
              </div>
              <p className="submit" style={{ marginBottom: 0 }}>
                <button
                  type="button"
                  className="button button-primary"
                  disabled={flushing}
                  onClick={() => {
                    void (async () => {
                      setFlushing(true);
                      setError(null);
                      setNotice(null);
                      try {
                        const res = await api<{
                          ok: boolean;
                          cacheEpoch: number;
                          web: { ok: boolean; message: string };
                          productionBuildCleared: boolean;
                        }>('/api/system/cache/flush', { method: 'POST' });
                        const bits = [
                          `Asset epoch ${res.cacheEpoch}`,
                          res.web.message,
                          res.productionBuildCleared
                            ? 'Production build cleared (next hive check rebuilds)'
                            : null,
                        ].filter(Boolean);
                        setNotice(`Cache flushed — ${bits.join(' · ')}.`);
                      } catch (err) {
                        setError(err instanceof ApiError ? err.message : 'Cache flush failed');
                      } finally {
                        setFlushing(false);
                      }
                    })();
                  }}
                >
                  {flushing ? 'Flushing…' : 'Flush full cache'}
                </button>
              </p>
            </div>
          </div>
          <div className="bk-help">
            <strong>Tip:</strong> After a cache flush, refresh Hive status in the admin bar to
            update Performance scores.
          </div>
        </div>
      )}

      {panelReady && tab === 'email' && auth.user?.isOwner ? <EmailSettingsPanel /> : null}

      {panelReady && tab === 'migration' && auth.user?.isOwner ? <MigrationPanel /> : null}

      {panelReady && tab === 'sites' && auth.user?.isOwner ? <SitesPanel /> : null}

      {panelReady && tab === 'instructions' ? <InstructionsPanel /> : null}

      {panelReady && tab === 'core' && status && (
        <div className="bk-stack">
          {allowCoreUpdates && updateAvailable && updates?.latestVersion ? (
            <div className="beekiri-notice is-update" role="status">
              <p>
                You have a new update — Beekiri Core{' '}
                <strong>v{updates.latestVersion}</strong> is available. You are on{' '}
                <strong>v{updates.currentVersion}</strong>.
              </p>
            </div>
          ) : null}

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Status</h2>
              <button
                type="button"
                className="button button-primary"
                onClick={() => void refreshStatus()}
                disabled={refreshing}
              >
                {refreshing ? 'Refreshing…' : 'Refresh'}
              </button>
            </div>
            <div className="bk-panel__body">
              <ul className="bk-rows">
                <li className="bk-row">
                  <span className="bk-row__label">API server</span>
                  <span className="bk-row__value">
                    <StatusValue ok={status.api.ok} label={status.api.label} />
                    {status.apiStack ? (
                      <span className="bk-muted"> · {status.apiStack}</span>
                    ) : null}
                  </span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Frontend</span>
                  <span className="bk-row__value">{status.frontend ?? '—'}</span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Admin</span>
                  <span className="bk-row__value">{status.admin ?? '—'}</span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Database</span>
                  <span className="bk-row__value">
                    <StatusValue ok={status.database.ok} label={status.database.label} />
                    {status.databaseEngine ? (
                      <span className="bk-muted"> · {status.databaseEngine}</span>
                    ) : null}
                  </span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Uptime</span>
                  <span className="bk-row__value">{formatUptime(status.uptimeSeconds)}</span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Environment</span>
                  <span className="bk-row__value">{status.environment}</span>
                </li>
              </ul>
            </div>
          </section>

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Version</h2>
              {updateAvailable ? <span className="bk-count">+{updateCount}</span> : null}
            </div>
            <div className="bk-panel__body">
              <ul className="bk-rows">
                <li className="bk-row">
                  <span className="bk-row__label">Beekiri Core</span>
                  <span className="bk-row__value">
                    <strong>v{status.coreVersion}</strong>
                    <span className="bk-badge">{status.channel}</span>
                    {updateAvailable && updates?.latestVersion ? (
                      <span className="bk-badge is-update">
                        → v{updates.latestVersion}
                      </span>
                    ) : null}
                  </span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Node.js</span>
                  <span className="bk-row__value">{status.nodeVersion}</span>
                </li>
              </ul>

              {allowCoreUpdates ? (
              <div className="bk-actions">
                <button
                  type="button"
                  className="button button-primary"
                  onClick={() => void checkUpdates()}
                  disabled={coreUpdate.checking}
                >
                  {coreUpdate.checking ? 'Checking…' : 'Check for updates'}
                </button>
              </div>
              ) : (
                <p className="description" style={{ marginTop: 12 }}>
                  You can view Core status. Checking for updates requires the{' '}
                  <strong>Beekiri Core — check for updates</strong> permission.
                </p>
              )}

              {allowCoreUpdates && updates && !updateAvailable && updates.source !== 'error' ? (
                <div className="bk-help">
                  <p style={{ margin: 0 }}>
                    <strong>You&apos;re up to date</strong> on Beekiri Core v{updates.currentVersion}.
                  </p>
                  <p className="bk-muted" style={{ margin: '8px 0 0' }}>
                    When a new version is ready, you&apos;ll see a <strong>+1</strong> on Settings.
                    Click <strong>Check for updates</strong>, then <strong>Update</strong>. Your
                    site content stays as it is.
                  </p>
                </div>
              ) : null}

              {allowCoreUpdates && updates && updateAvailable ? (
                <div className="bk-help" style={{ marginTop: 14 }}>
                  <p style={{ margin: 0 }}>
                    <strong>Update available</strong>: Beekiri Core v{updates.latestVersion}{' '}
                    (you&apos;re on v{updates.currentVersion}).
                  </p>
                  <p className="bk-muted" style={{ margin: '8px 0 0' }}>
                    Click <strong>Update</strong> below. Your pages, media, and settings stay on
                    this site.
                  </p>
                  <div
                    className="bk-actions"
                    style={{ marginTop: 12, paddingTop: 0, borderTop: 'none' }}
                  >
                    {updates.latestVersion ? (
                      <CoreUpdateRunner latestVersion={updates.latestVersion} />
                    ) : null}
                    {updates.releaseUrl ? (
                      <a
                        className="button"
                        href={updates.releaseUrl}
                        target="_blank"
                        rel="noreferrer"
                      >
                        What&apos;s new
                      </a>
                    ) : null}
                  </div>
                </div>
              ) : null}
            </div>
          </section>
        </div>
      )}
      </div>
    </div>
  );
}
