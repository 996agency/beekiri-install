import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { LinkSimple, Minus, TextB, TextH } from '@phosphor-icons/react';
import { api } from '../../api/client';
import { MediaPicker } from '../../editor/beekiricode/inspector/MediaPicker';
import {
  DEFAULT_EMAIL_DESIGN,
  MERGE_TAGS,
  formsError,
  type FormEmailDesign,
  type FormEmailPreview,
  type FormField,
  type FormSettings,
} from './api';
import { Row, Seg } from './ui';

export type EmailKind = 'notification' | 'autoReply';

/* ── Message: a text box with a few formatting helpers ───────────────── */

/**
 * An email message. The buttons write simple marks into the text (**bold**, [link](https://…),
 * ## heading, ---) that the server turns into formatting; "Insert an answer" drops in a merge tag.
 */
export function MessageEditor({ value, onChange, fields }: { value: string; onChange: (v: string) => void; fields: FormField[] }) {
  const ref = useRef<HTMLTextAreaElement>(null);
  /** Where the cursor goes once the new text is in the box (a changed value would leave it at the end). */
  const select = useRef<[number, number] | null>(null);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el || !select.current) return;
    el.focus();
    el.setSelectionRange(select.current[0], select.current[1]);
    select.current = null;
  }, [value]);

  /** Replaces the selection (or inserts at the cursor), then selects `pick` characters from `from`. */
  const edit = (build: (selected: string, start: number, end: number) => { text: string; from: number; pick: number }) => {
    const el = ref.current;
    if (!el) return;
    const start = el.selectionStart;
    const end = el.selectionEnd;
    const { text, from, pick } = build(value.slice(start, end), start, end);
    select.current = [start + from, start + from + pick];
    onChange(value.slice(0, start) + text + value.slice(end));
  };

  const bold = () => edit((sel) => ({ text: `**${sel || 'bold text'}**`, from: 2, pick: (sel || 'bold text').length }));
  const link = () =>
    edit((sel) => {
      const label = sel || 'link text';
      return { text: `[${label}](https://)`, from: label.length + 3, pick: 'https://'.length };
    });
  const insert = (text: string) => edit(() => ({ text, from: text.length, pick: 0 }));
  /** A heading or a dividing line sits on a line of its own. */
  const block = (kind: 'heading' | 'line') =>
    edit((sel, start, end) => {
      const lead = start === 0 || value[start - 1] === '\n' ? '' : '\n';
      const tail = end === value.length || value[end] === '\n' ? '' : '\n';
      const title = sel.trim() || 'Heading';
      return kind === 'heading'
        ? { text: `${lead}## ${title}${tail}`, from: lead.length + 3, pick: title.length }
        : { text: `${lead}---${tail || '\n'}`, from: lead.length + 4, pick: 0 };
    });

  return (
    <div className="bk-fm-msg">
      <div className="bk-fm-msg__bar">
        <button type="button" onClick={bold} title="Bold" aria-label="Bold">
          <TextB size={15} weight="bold" aria-hidden />
        </button>
        <button type="button" onClick={link} title="Link" aria-label="Link">
          <LinkSimple size={15} aria-hidden />
        </button>
        <button type="button" onClick={() => block('heading')} title="Heading" aria-label="Heading">
          <TextH size={15} aria-hidden />
        </button>
        <button type="button" onClick={() => block('line')} title="Dividing line" aria-label="Dividing line">
          <Minus size={15} aria-hidden />
        </button>
        <select
          value=""
          aria-label="Insert an answer"
          onChange={(e) => {
            if (e.target.value) insert(e.target.value);
          }}
        >
          <option value="">Insert an answer…</option>
          {MERGE_TAGS.map((t) => (
            <option key={t.tag} value={t.tag}>
              {t.label}
            </option>
          ))}
          {fields.map((f) => (
            <option key={f.id} value={`{field:${f.name}}`}>
              {f.label}
            </option>
          ))}
        </select>
      </div>
      <textarea ref={ref} className="bk-fm-textarea" rows={8} value={value} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}

/* ── Design: logo, colours, footer ───────────────────────────────────── */

function ColorField({ value, onChange, label }: { value: string; onChange: (v: string) => void; label: string }) {
  const [text, setText] = useState(value);
  useEffect(() => setText(value), [value]);
  return (
    <div className="bk-fm-color">
      <input type="color" value={value} aria-label={label} onChange={(e) => onChange(e.target.value)} />
      <input
        type="text"
        value={text}
        maxLength={7}
        spellCheck={false}
        aria-label={`${label} (hex)`}
        onChange={(e) => {
          const next = e.target.value.trim();
          setText(next);
          if (/^#[0-9a-f]{6}$/i.test(next)) onChange(next.toLowerCase());
        }}
        onBlur={() => setText(value)}
      />
    </div>
  );
}

/** How both of the form's emails look. */
export function EmailDesignPanel({ design: saved, onChange }: { design: FormEmailDesign | undefined; onChange: (d: FormEmailDesign) => void }) {
  const design = saved ?? DEFAULT_EMAIL_DESIGN;
  const [picking, setPicking] = useState(false);
  const set = (patch: Partial<FormEmailDesign>) => onChange({ ...design, ...patch });
  const changed = JSON.stringify(design) !== JSON.stringify(DEFAULT_EMAIL_DESIGN);
  return (
    <div className="bk-panel">
      <div className="bk-panel__head">
        <h2 className="bk-panel__title">Email design</h2>
        {changed ? (
          <button type="button" className="button-link" onClick={() => onChange({ ...DEFAULT_EMAIL_DESIGN })}>
            Reset
          </button>
        ) : (
          <span className="bk-fm-head-meta">Used by both emails</span>
        )}
      </div>
      <div className="bk-panel__body bk-fm-rows">
        <Row label="Logo" hint="Shown at the top. Without a logo the site title is shown.">
          <div className="bk-fm-logo">
            {design.logoUrl ? (
              <span className="bk-fm-logo__thumb">
                <img src={design.logoUrl} alt="" />
              </span>
            ) : null}
            <button type="button" className="button" onClick={() => setPicking(true)}>
              {design.logoUrl ? 'Change logo' : 'Choose logo'}
            </button>
            {design.logoUrl ? (
              <button type="button" className="button" onClick={() => set({ logoUrl: '' })}>
                Remove
              </button>
            ) : null}
          </div>
          <MediaPicker
            open={picking}
            onClose={() => setPicking(false)}
            kind="image"
            title="Email logo"
            onSelect={(items) => {
              if (items[0]) set({ logoUrl: items[0].url });
              setPicking(false);
            }}
          />
        </Row>
        {design.logoUrl ? (
          <Row label="Logo width" inline>
            <div className="bk-fm-range">
              <input type="range" min={60} max={320} step={10} value={design.logoWidth} aria-label="Logo width" onChange={(e) => set({ logoWidth: Number(e.target.value) })} />
              <span>{design.logoWidth}px</span>
            </div>
          </Row>
        ) : null}
        <Row label="Position" hint="Where the logo (or site title) sits." inline>
          <Seg
            value={design.align}
            options={[
              { value: 'left', label: 'Left' },
              { value: 'center', label: 'Centre' },
            ]}
            onChange={(align) => set({ align })}
          />
        </Row>
        <Row label="Accent colour" hint="The bar across the top, and links." inline>
          <ColorField label="Accent colour" value={design.accent} onChange={(accent) => set({ accent })} />
        </Row>
        <Row label="Background" hint="The area around the white card." inline>
          <ColorField label="Background colour" value={design.background} onChange={(background) => set({ background })} />
        </Row>
        <Row label="Footer" hint="Small print under the email. Leave it empty for none.">
          <input type="text" className="regular-text" value={design.footer} maxLength={500} onChange={(e) => set({ footer: e.target.value })} />
        </Row>
      </div>
    </div>
  );
}

/* ── Preview ─────────────────────────────────────────────────────────── */

/**
 * The email as it will arrive, rendered by the server from the form as it is in the editor
 * (saved or not) with made-up answers. "Send me a test" mails that same message to you.
 */
export function EmailPreview({
  title,
  fields,
  settings,
  kind,
  onKind,
}: {
  title: string;
  fields: FormField[];
  settings: FormSettings;
  kind: EmailKind;
  onKind: (k: EmailKind) => void;
}) {
  const [data, setData] = useState<FormEmailPreview | null>(null);
  const [error, setError] = useState('');
  const [device, setDevice] = useState<'desktop' | 'phone'>('desktop');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState<{ ok: boolean; text: string } | null>(null);
  const frameRef = useRef<HTMLIFrameElement>(null);
  const [height, setHeight] = useState(420);

  const body = useMemo(() => JSON.stringify({ title, fields, settings, kind }), [title, fields, settings, kind]);
  useEffect(() => {
    let live = true;
    // Typing shouldn't ask the server for every letter.
    const timer = window.setTimeout(() => {
      api<FormEmailPreview>('/api/forms/email/preview', { method: 'POST', json: JSON.parse(body) })
        .then((res) => {
          if (!live) return;
          setData(res);
          setError('');
        })
        .catch((e) => {
          if (live) setError(formsError(e));
        });
    }, 350);
    return () => {
      live = false;
      window.clearTimeout(timer);
    };
  }, [body]);

  // The frame grows to the email's own height (no scrollbar inside the preview).
  const fit = () => {
    const doc = frameRef.current?.contentDocument;
    if (doc?.documentElement) setHeight(Math.max(240, doc.documentElement.scrollHeight));
  };
  useEffect(() => {
    const t = window.setTimeout(fit, 60);
    return () => window.clearTimeout(t);
  }, [device, data?.html]);

  const sendTest = async () => {
    setSending(true);
    setSent(null);
    try {
      const res = await api<{ sentTo: string }>('/api/forms/email/test', { method: 'POST', json: JSON.parse(body) });
      setSent({ ok: true, text: `Test sent to ${res.sentTo}.` });
    } catch (e) {
      setSent({ ok: false, text: formsError(e) });
    } finally {
      setSending(false);
    }
  };

  const off = !settings[kind].enabled;
  // Links in the preview don't go anywhere.
  const html = data ? data.html.replace('<head>', '<head><base target="_blank">') : '';

  return (
    <aside className="bk-panel bk-fm-mailview" aria-label="Email preview">
      <div className="bk-panel__head">
        <h2 className="bk-panel__title">Preview</h2>
        <Seg
          value={kind}
          options={[
            { value: 'notification', label: 'Notification' },
            { value: 'autoReply', label: 'Auto-reply' },
          ]}
          onChange={onKind}
        />
      </div>
      {error ? <p className="bk-fm-mailview__note is-error">{error}</p> : null}
      {off ? (
        <p className="bk-fm-mailview__note">This email is switched off, so it isn't sent. This is how it would look.</p>
      ) : null}
      {data ? (
        <>
          <dl className="bk-fm-mailview__meta">
            <div>
              <dt>Subject</dt>
              <dd>
                <strong>{data.subject || '(no subject)'}</strong>
              </dd>
            </div>
            <div>
              <dt>To</dt>
              <dd>{data.to.length ? data.to.join(', ') : kind === 'autoReply' ? 'Add an Email field to the form' : 'No valid address yet'}</dd>
            </div>
            {data.replyTo ? (
              <div>
                <dt>Reply to</dt>
                <dd>{data.replyTo}</dd>
              </div>
            ) : null}
          </dl>
          <div className={`bk-fm-mailview__stage${device === 'phone' ? ' is-phone' : ''}`}>
            <iframe ref={frameRef} title="Email preview" sandbox="allow-same-origin" srcDoc={html} style={{ height }} onLoad={fit} />
          </div>
          <div className="bk-fm-mailview__foot">
            <Seg
              value={device}
              options={[
                { value: 'desktop', label: 'Desktop' },
                { value: 'phone', label: 'Phone' },
              ]}
              onChange={setDevice}
            />
            <button
              type="button"
              className="button"
              onClick={() => void sendTest()}
              disabled={sending || !data.mailReady}
              title={data.mailReady ? `Sends this email to ${data.sendsTo}` : 'Add your mail server under Settings → Email first'}
            >
              {sending ? 'Sending…' : 'Send me a test'}
            </button>
          </div>
          {sent ? <p className={`bk-fm-mailview__note${sent.ok ? ' is-ok' : ' is-error'}`}>{sent.text}</p> : null}
          <p className="bk-fm-mailview__note">
            Shown with sample answers.
            {data.mailReady
              ? ` A test goes to ${data.sendsTo}.`
              : ' Email is not set up yet, so this form cannot send anything. Add your mail server under Settings → Email.'}
          </p>
        </>
      ) : !error ? (
        <p className="bk-fm-mailview__note">Loading the preview…</p>
      ) : null}
    </aside>
  );
}
