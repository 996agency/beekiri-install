import type { ReactNode } from 'react';

/** Small controls shared by the form builder's tabs. */

export function Switch({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <label className={`bk-fm-switch${disabled ? ' is-disabled' : ''}`}>
      <input type="checkbox" role="switch" checked={checked} disabled={disabled} aria-label={label} onChange={(e) => onChange(e.target.checked)} />
      <span className="bk-fm-switch__track" aria-hidden>
        <span className="bk-fm-switch__knob" />
      </span>
    </label>
  );
}

export function Row({ label, hint, children, inline }: { label: string; hint?: string; children: ReactNode; inline?: boolean }) {
  return (
    <div className={`bk-fm-row${inline ? ' is-inline' : ''}`}>
      <div className="bk-fm-row__text">
        <span className="bk-fm-row__label">{label}</span>
        {hint ? <span className="bk-fm-row__hint">{hint}</span> : null}
      </div>
      <div className="bk-fm-row__control">{children}</div>
    </div>
  );
}

export function Seg<T extends string>({ value, options, onChange }: { value: T; options: { value: T; label: string }[]; onChange: (v: T) => void }) {
  return (
    <div className="bk-fm-seg" role="group">
      {options.map((o) => (
        <button key={o.value} type="button" className={o.value === value ? 'is-active' : ''} aria-pressed={o.value === value} onClick={() => onChange(o.value)}>
          {o.label}
        </button>
      ))}
    </div>
  );
}
