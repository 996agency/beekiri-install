import { useCallback, useEffect, useState } from 'react';
import { api, ApiError } from '../../api/client';

/* ── Shapes (mirror apps/api/src/services/bookings) ──────────────────── */

export const DAY_KEYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'] as const;
export type DayKey = (typeof DAY_KEYS)[number];
export const DAY_LABELS: Record<DayKey, string> = { mon: 'Monday', tue: 'Tuesday', wed: 'Wednesday', thu: 'Thursday', fri: 'Friday', sat: 'Saturday', sun: 'Sunday' };
export type Interval = { from: string; to: string };
export type WeekHours = Record<DayKey, Interval[]>;
export type DateRange = { from: string; to: string; note: string };

export type Service = { id: string; name: string; description: string; durationMin: number; bufferMin: number; priceCents: number; color: string; active: boolean; sortOrder: number };
export type Staff = { id: string; name: string; email: string; phone: string; serviceIds: string[]; hours: WeekHours | null; daysOff: DateRange[]; active: boolean; sortOrder: number };
export type BookingStatus = 'pending' | 'confirmed' | 'completed' | 'no_show' | 'cancelled';
export type Booking = {
  id: string;
  kind: 'appointment' | 'block';
  serviceId: string | null;
  serviceName: string;
  color: string;
  staffId: string | null;
  staffName: string;
  startAt: string;
  endAt: string;
  status: BookingStatus;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  note: string;
  adminNote: string;
  priceCents: number;
  source: string;
  createdAt: string;
};
export type Settings = {
  timezone: string;
  hours: WeekHours;
  slotStep: number;
  minNoticeHours: number;
  maxDaysAhead: number;
  closedDates: DateRange[];
  autoConfirm: boolean;
  notifyEmail: string;
  reminderHours: number;
  cancelHours: number;
  currency: string;
  location: string;
  confirmationNote: string;
};
export type Overview = { services: Service[]; staff: Staff[]; settings: Settings; today: string };

export const STATUS_LABEL: Record<BookingStatus, string> = { pending: 'Waiting', confirmed: 'Confirmed', completed: 'Completed', no_show: 'No-show', cancelled: 'Cancelled' };
export const STATUS_TONE: Record<BookingStatus, string> = { pending: 'warn', confirmed: 'ok', completed: 'muted', no_show: 'danger', cancelled: 'muted' };

export function bookingsError(e: unknown): string {
  if (e instanceof ApiError) {
    const body = e.body as { message?: unknown } | undefined;
    if (Array.isArray(body?.message)) return (body!.message as unknown[]).map(String).join(' ');
    return e.message;
  }
  return e instanceof Error ? e.message : 'Something went wrong.';
}

/** Services, staff and settings, shared by every Bookings screen. */
export function useOverview(): { data: Overview | null; error: string | null; reload: () => Promise<void> } {
  const [data, setData] = useState<Overview | null>(null);
  const [error, setError] = useState<string | null>(null);
  const reload = useCallback(async () => {
    try {
      setData(await api<Overview>('/api/bookings/overview'));
      setError(null);
    } catch (e) {
      setError(bookingsError(e));
    }
  }, []);
  useEffect(() => {
    void reload();
  }, [reload]);
  return { data, error, reload };
}

/* ── Time: the calendar shows the business's time zone, not the browser's ── */

const pad = (n: number) => String(n).padStart(2, '0');
const formatters = new Map<string, Intl.DateTimeFormat>();
function formatter(tz: string) {
  let f = formatters.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
    formatters.set(tz, f);
  }
  return f;
}
function parts(at: number, tz: string) {
  return Object.fromEntries(formatter(tz).formatToParts(new Date(at)).map((p) => [p.type, p.value]));
}

/** Date (YYYY-MM-DD), time (HH:MM) and minutes since midnight of an instant on the business's clock. */
export function local(iso: string | number, tz: string): { date: string; time: string; minutes: number } {
  const p = parts(typeof iso === 'number' ? iso : Date.parse(iso), tz);
  return { date: `${p.year}-${p.month}-${p.day}`, time: `${p.hour}:${p.minute}`, minutes: Number(p.hour) * 60 + Number(p.minute) };
}

/** The instant (ISO) of a date and time on the business's clock. */
export function zonedIso(date: string, time: string, tz: string): string {
  const [y, m, d] = date.split('-').map(Number);
  const [hh, mm] = time.split(':').map(Number);
  const guess = Date.UTC(y, m - 1, d, hh, mm);
  const offset = (at: number) => {
    const p = parts(at, tz);
    return Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day), Number(p.hour), Number(p.minute), Number(p.second)) - Math.floor(at / 1000) * 1000;
  };
  return new Date(guess - offset(guess - offset(guess))).toISOString();
}

export function addDays(date: string, days: number): string {
  const d = new Date(`${date}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
}

/** Monday of the week a date is in. */
export function weekStart(date: string): string {
  const dow = (new Date(`${date}T12:00:00Z`).getUTCDay() + 6) % 7;
  return addDays(date, -dow);
}

export const dayKeyOf = (date: string): DayKey => DAY_KEYS[(new Date(`${date}T12:00:00Z`).getUTCDay() + 6) % 7];
export const minutesOf = (clock: string) => Number(clock.slice(0, 2)) * 60 + Number(clock.slice(3, 5));
export const clockOf = (minutes: number) => `${pad(Math.floor(minutes / 60))}:${pad(minutes % 60)}`;

/** "Tue 12 Nov", "12 November 2026", "November 2026" for a calendar date. */
export function formatDay(date: string, style: 'short' | 'long' | 'month' = 'short'): string {
  const d = new Date(`${date}T12:00:00Z`);
  const opts: Intl.DateTimeFormatOptions =
    style === 'short' ? { weekday: 'short', day: 'numeric', month: 'short' } : style === 'long' ? { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' } : { month: 'long', year: 'numeric' };
  return new Intl.DateTimeFormat('en-GB', { ...opts, timeZone: 'UTC' }).format(d);
}

export function formatPrice(cents: number, currency: string): string {
  if (!cents) return 'Free';
  try {
    return new Intl.NumberFormat('en', { style: 'currency', currency }).format(cents / 100);
  } catch {
    return `${(cents / 100).toFixed(2)} ${currency}`;
  }
}

export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes} min`;
  return `${Math.floor(minutes / 60)} h${minutes % 60 ? ` ${minutes % 60} min` : ''}`;
}

/** Does this person do that service? (No list = every service.) */
export const does = (staff: Staff, serviceId: string) => staff.serviceIds.length === 0 || staff.serviceIds.includes(serviceId);
