import { useCallback, useEffect, useMemo, useState, type CSSProperties, type MouseEvent } from 'react';
import { Link } from 'react-router-dom';
import { CaretLeft, CaretRight, Plus, Prohibit } from '@phosphor-icons/react';
import { api } from '../../api/client';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { useAdminHref } from '../../lib/AdminEntryContext';
import {
  addDays,
  bookingsError,
  clockOf,
  DAY_KEYS,
  dayKeyOf,
  formatDay,
  local,
  minutesOf,
  STATUS_LABEL,
  useOverview,
  weekStart,
  zonedIso,
  type Booking,
  type Overview,
} from './api';
import { BookingModal, type BookingDraft } from './BookingModal';
import './bookings.css';

type View = 'day' | 'week' | 'month';
const VIEWS: { id: View; label: string }[] = [
  { id: 'day', label: 'Day' },
  { id: 'week', label: 'Week' },
  { id: 'month', label: 'Month' },
];
/** Height of one hour on the day and week grids. */
const HOUR_PX = 52;

/** One column of the time grid: a day (week view) or a person (day view). */
type Column = { key: string; date: string; staffId: string | null; title: string; sub?: string; today?: boolean };
type Placed = { booking: Booking; top: number; height: number; lane: number; lanes: number; time: string };

/** First and last hour worth showing: the opening hours of the business and its staff, plus what is booked. */
function hourRange(overview: Overview, bookings: Booking[], tz: string): [number, number] {
  let min = 24 * 60;
  let max = 0;
  const all = [overview.settings.hours, ...overview.staff.filter((s) => s.active && s.hours).map((s) => s.hours!)];
  for (const hours of all) {
    for (const day of DAY_KEYS) {
      for (const iv of hours[day] ?? []) {
        min = Math.min(min, minutesOf(iv.from));
        max = Math.max(max, minutesOf(iv.to));
      }
    }
  }
  for (const b of bookings) {
    const start = local(b.startAt, tz);
    const end = local(b.endAt, tz);
    min = Math.min(min, start.minutes);
    max = Math.max(max, end.date === start.date ? end.minutes : 24 * 60);
  }
  if (min >= max) return [8, 18];
  return [Math.max(0, Math.floor(min / 60) - 1), Math.min(24, Math.ceil(max / 60) + 1)];
}

/** Bookings of one column with their place on the grid; overlapping ones share the width. */
function place(bookings: Booking[], column: Column, tz: string, firstHour: number, lastHour: number): Placed[] {
  const items = bookings
    .filter((b) => (column.staffId === null || b.staffId === column.staffId || (b.kind === 'block' && b.staffId === null)) && b.status !== 'cancelled')
    .map((b) => {
      const start = local(b.startAt, tz);
      const end = local(b.endAt, tz);
      // The part of it that falls on this column's day.
      if (start.date > column.date || end.date < column.date || (end.date === column.date && end.minutes === 0 && start.date < column.date)) return null;
      const from = start.date < column.date ? 0 : start.minutes;
      const to = end.date > column.date ? 24 * 60 : end.minutes;
      const top = Math.max(from, firstHour * 60);
      const bottom = Math.min(to, lastHour * 60);
      if (bottom <= top) return null;
      return { booking: b, from: top, to: bottom, time: start.time };
    })
    .filter((x): x is { booking: Booking; from: number; to: number; time: string } => x !== null)
    .sort((a, b) => a.from - b.from || b.to - a.to);

  const out: Placed[] = [];
  let cluster: { item: (typeof items)[number]; lane: number }[] = [];
  let clusterEnd = -1;
  const flush = () => {
    const lanes = Math.max(1, ...cluster.map((c) => c.lane + 1));
    for (const c of cluster) {
      out.push({
        booking: c.item.booking,
        top: ((c.item.from - firstHour * 60) / 60) * HOUR_PX,
        height: Math.max(22, ((c.item.to - c.item.from) / 60) * HOUR_PX - 2),
        lane: c.lane,
        lanes,
        time: c.item.time,
      });
    }
    cluster = [];
  };
  for (const item of items) {
    if (item.from >= clusterEnd) flush();
    const taken = new Set(cluster.filter((c) => c.item.to > item.from).map((c) => c.lane));
    let lane = 0;
    while (taken.has(lane)) lane++;
    cluster.push({ item, lane });
    clusterEnd = Math.max(clusterEnd, item.to);
  }
  flush();
  return out;
}

export function CalendarPage() {
  const href = useAdminHref();
  const { data: overview, error: loadError, reload } = useOverview();
  const [view, setView] = useState<View>('week');
  const [anchor, setAnchor] = useState('');
  const [staffFilter, setStaffFilter] = useState('');
  const [bookings, setBookings] = useState<Booking[] | null>(null);
  const [draft, setDraft] = useState<BookingDraft | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const tz = overview?.settings.timezone ?? 'UTC';
  const today = overview?.today ?? '';
  useEffect(() => {
    if (today && !anchor) setAnchor(today);
  }, [today, anchor]);

  // The dates on screen.
  const range = useMemo(() => {
    if (!anchor) return null;
    if (view === 'day') return { from: anchor, days: 1 };
    if (view === 'week') return { from: weekStart(anchor), days: 7 };
    return { from: weekStart(`${anchor.slice(0, 7)}-01`), days: 42 };
  }, [anchor, view]);

  const load = useCallback(async () => {
    if (!range || !overview) return;
    try {
      const q = new URLSearchParams({ from: zonedIso(range.from, '00:00', tz), to: zonedIso(addDays(range.from, range.days), '00:00', tz) });
      const res = await api<{ items: Booking[] }>(`/api/bookings?${q.toString()}`);
      setBookings(res.items);
    } catch (e) {
      setError(bookingsError(e));
    }
  }, [range, overview, tz]);
  useEffect(() => {
    void load();
  }, [load]);

  const visible = useMemo(() => (bookings ?? []).filter((b) => !staffFilter || b.staffId === staffFilter || (b.kind === 'block' && b.staffId === null)), [bookings, staffFilter]);
  const activeStaff = useMemo(() => (overview?.staff ?? []).filter((s) => s.active), [overview]);
  const [firstHour, lastHour] = useMemo(() => (overview ? hourRange(overview, visible, tz) : [8, 18]), [overview, visible, tz]);

  if (loadError && !overview) {
    return (
      <div className="wrap wrap--wide bk-bkg">
        <PageHeader title="Calendar" />
        <ErrorNotice message={loadError} onDismiss={() => undefined} />
      </div>
    );
  }
  if (!overview || !anchor || !range) {
    return (
      <div className="wrap wrap--wide bk-bkg">
        <PageHeader title="Calendar" />
        <p className="bk-muted">Loading…</p>
      </div>
    );
  }

  const step = view === 'day' ? 1 : view === 'week' ? 7 : 0;
  const move = (dir: 1 | -1) => {
    if (step) return setAnchor(addDays(anchor, dir * step));
    const d = new Date(`${anchor.slice(0, 7)}-15T12:00:00Z`);
    d.setUTCMonth(d.getUTCMonth() + dir);
    setAnchor(`${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-01`);
  };
  const title = view === 'day' ? formatDay(anchor, 'long') : view === 'week' ? `${formatDay(range.from)} – ${formatDay(addDays(range.from, 6))}` : formatDay(anchor, 'month');

  const columns: Column[] =
    view === 'day'
      ? (staffFilter ? activeStaff.filter((s) => s.id === staffFilter) : activeStaff).map((s) => ({ key: s.id, date: anchor, staffId: s.id, title: s.name }))
      : Array.from({ length: 7 }, (_, i) => {
          const date = addDays(range.from, i);
          return { key: date, date, staffId: null, title: formatDay(date).split(' ')[0], sub: String(Number(date.slice(8))), today: date === today };
        });

  const isClosed = (date: string) => overview.settings.closedDates.some((c) => c.from <= date && date <= c.to);
  /** Is that minute inside opening hours for the column (its person, or anyone in the week view)? */
  const openAt = (column: Column, minute: number) => {
    if (isClosed(column.date)) return false;
    const day = dayKeyOf(column.date);
    const people = column.staffId ? activeStaff.filter((s) => s.id === column.staffId) : staffFilter ? activeStaff.filter((s) => s.id === staffFilter) : activeStaff;
    const sets = people.length ? people.filter((s) => !s.daysOff.some((d) => d.from <= column.date && column.date <= d.to)).map((s) => (s.hours ?? overview.settings.hours)[day] ?? []) : [overview.settings.hours[day] ?? []];
    return sets.some((ivs) => ivs.some((iv) => minutesOf(iv.from) <= minute && minute < minutesOf(iv.to)));
  };

  const newAt = (column: Column, e: MouseEvent<HTMLDivElement>) => {
    const y = e.clientY - e.currentTarget.getBoundingClientRect().top;
    const slot = overview.settings.slotStep;
    const minute = Math.min(lastHour * 60 - slot, Math.max(firstHour * 60, firstHour * 60 + Math.floor(((y / HOUR_PX) * 60) / slot) * slot));
    setDraft({ kind: 'appointment', date: column.date, time: clockOf(minute), staffId: column.staffId ?? (staffFilter || null) });
  };

  const nowParts = local(Date.now(), tz);
  const hours = Array.from({ length: lastHour - firstHour }, (_, i) => firstHour + i);
  const setupMissing = overview.services.length === 0 || activeStaff.length === 0;
  const browserTz = Intl.DateTimeFormat().resolvedOptions().timeZone;

  return (
    <div className="wrap wrap--wide bk-bkg">
      <PageHeader
        title="Calendar"
        actions={
          <>
            <button type="button" className="button" onClick={() => setDraft({ kind: 'block', date: anchor, time: '12:00', staffId: staffFilter || null })}>
              <Prohibit size={14} aria-hidden /> Block time
            </button>
            <button type="button" className="button button-primary" disabled={setupMissing} onClick={() => setDraft({ kind: 'appointment', date: anchor < today ? today : anchor, time: '09:00', staffId: staffFilter || null })}>
              <Plus size={14} weight="bold" aria-hidden /> New appointment
            </button>
          </>
        }
      />
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}
      {tz === 'UTC' && browserTz && browserTz !== 'UTC' ? (
        <div className="bk-bkg-setup">
          <strong>Check the time zone</strong>
          <p>
            Opening hours and appointment times are in UTC, but this computer is on {browserTz.replace(/_/g, ' ')} time.{' '}
            <button
              type="button"
              className="button-link"
              onClick={() => {
                api('/api/bookings/settings', { method: 'PUT', json: { timezone: browserTz } })
                  .then(() => reload())
                  .then(() => setNotice(`Bookings now use ${browserTz.replace(/_/g, ' ')} time.`))
                  .catch((e) => setError(bookingsError(e)));
              }}
            >
              Use {browserTz.replace(/_/g, ' ')}
            </button>
          </p>
        </div>
      ) : null}
      {setupMissing ? (
        <div className="bk-bkg-setup">
          <strong>Two things before customers can book</strong>
          <p>
            {overview.services.length === 0 ? (
              <>
                <Link to={href('bookings/services')}>Add a service</Link> (what people book, how long it takes, what it costs)
              </>
            ) : (
              'Services: done'
            )}
            {' · '}
            {activeStaff.length === 0 ? (
              <>
                <Link to={href('bookings/staff')}>Add a staff member</Link> (who does it, and when they work)
              </>
            ) : (
              'Staff: done'
            )}
            . Or ask Beekiri in the chat: “Set up bookings for my salon…”.
          </p>
        </div>
      ) : null}

      <div className="bk-bkg-toolbar">
        <div className="bk-bkg-toolbar__nav">
          <button type="button" className="button" onClick={() => setAnchor(today)}>
            Today
          </button>
          <button type="button" className="bk-bkg-iconbtn is-boxed" onClick={() => move(-1)} aria-label="Previous">
            <CaretLeft size={14} aria-hidden />
          </button>
          <button type="button" className="bk-bkg-iconbtn is-boxed" onClick={() => move(1)} aria-label="Next">
            <CaretRight size={14} aria-hidden />
          </button>
          <h2 className="bk-bkg-toolbar__title">{title}</h2>
        </div>
        <div className="bk-bkg-toolbar__right">
          {activeStaff.length > 1 ? (
            <select value={staffFilter} onChange={(e) => setStaffFilter(e.target.value)} aria-label="Staff">
              <option value="">Everyone</option>
              {activeStaff.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          ) : null}
          <div className="bk-bkg-seg" role="tablist" aria-label="View">
            {VIEWS.map((v) => (
              <button key={v.id} type="button" role="tab" aria-selected={view === v.id} className={view === v.id ? 'is-active' : ''} onClick={() => setView(v.id)}>
                {v.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {view === 'month' ? (
        <div className="bk-bkg-month">
          {DAY_KEYS.map((d) => (
            <div key={d} className="bk-bkg-month__dow">
              {d[0].toUpperCase() + d.slice(1)}
            </div>
          ))}
          {Array.from({ length: 42 }, (_, i) => {
            const date = addDays(range.from, i);
            const items = visible.filter((b) => b.status !== 'cancelled' && local(b.startAt, tz).date === date).sort((a, b) => (a.startAt < b.startAt ? -1 : 1));
            const outside = date.slice(0, 7) !== anchor.slice(0, 7);
            return (
              <div key={date} className={`bk-bkg-month__cell${outside ? ' is-outside' : ''}${date === today ? ' is-today' : ''}${isClosed(date) ? ' is-closed' : ''}`}>
                <button
                  type="button"
                  className="bk-bkg-month__date"
                  onClick={() => {
                    setAnchor(date);
                    setView('day');
                  }}
                  title="Open this day"
                >
                  {Number(date.slice(8))}
                </button>
                {items.slice(0, 3).map((b) => (
                  <button key={b.id} type="button" className={`bk-bkg-chip${b.kind === 'block' ? ' is-block' : ''}${b.status === 'pending' ? ' is-pending' : ''}`} style={{ '--c': b.color } as CSSProperties} onClick={() => setDraft({ booking: b })}>
                    <span>{local(b.startAt, tz).time}</span> {b.kind === 'block' ? b.note || 'Blocked' : b.customerName}
                  </button>
                ))}
                {items.length > 3 ? (
                  <button
                    type="button"
                    className="bk-bkg-month__more"
                    onClick={() => {
                      setAnchor(date);
                      setView('day');
                    }}
                  >
                    +{items.length - 3} more
                  </button>
                ) : null}
              </div>
            );
          })}
        </div>
      ) : columns.length === 0 ? (
        <p className="bk-bkg-empty">Add a staff member to see the day view.</p>
      ) : (
        <div className="bk-bkg-grid" style={{ '--cols': columns.length, '--hour': `${HOUR_PX}px` } as CSSProperties}>
          <div className="bk-bkg-grid__head">
            <span />
            {columns.map((c) => (
              <div key={c.key} className={`bk-bkg-grid__colhead${c.today ? ' is-today' : ''}`}>
                {c.sub ? (
                  <button
                    type="button"
                    onClick={() => {
                      setAnchor(c.date);
                      setView('day');
                    }}
                    title="Open this day"
                  >
                    <small>{c.title}</small>
                    <strong>{c.sub}</strong>
                  </button>
                ) : (
                  <strong>{c.title}</strong>
                )}
              </div>
            ))}
          </div>
          <div className="bk-bkg-grid__body">
            <div className="bk-bkg-grid__hours">
              {hours.map((h) => (
                <span key={h}>{clockOf(h * 60)}</span>
              ))}
            </div>
            {columns.map((c) => (
              <div key={c.key} className="bk-bkg-grid__col" style={{ height: hours.length * HOUR_PX }} onClick={(e) => (e.target === e.currentTarget || (e.target as HTMLElement).classList.contains('bk-bkg-grid__shade') ? newAt(c, e) : undefined)}>
                {/* Closed hours are shaded, half an hour at a time. */}
                {hours.flatMap((h) =>
                  [0, 30].map((m) =>
                    openAt(c, h * 60 + m) ? null : <span key={`${h}:${m}`} className="bk-bkg-grid__shade" style={{ top: ((h - firstHour) * 60 + m) * (HOUR_PX / 60), height: HOUR_PX / 2 }} />,
                  ),
                )}
                {c.date === nowParts.date && nowParts.minutes >= firstHour * 60 && nowParts.minutes <= lastHour * 60 ? (
                  <span className="bk-bkg-grid__now" style={{ top: ((nowParts.minutes - firstHour * 60) / 60) * HOUR_PX }} />
                ) : null}
                {place(visible, c, tz, firstHour, lastHour).map((p) => (
                  <button
                    key={p.booking.id}
                    type="button"
                    className={`bk-bkg-event${p.booking.kind === 'block' ? ' is-block' : ''}${p.booking.status === 'pending' ? ' is-pending' : ''}${p.height < 34 ? ' is-short' : ''}`}
                    style={{ top: p.top, height: p.height, left: `calc(${(p.lane / p.lanes) * 100}% + 2px)`, width: `calc(${100 / p.lanes}% - 4px)`, '--c': p.booking.color } as CSSProperties}
                    title={p.booking.kind === 'block' ? p.booking.note || 'Blocked' : `${p.booking.customerName} · ${p.booking.serviceName} · ${STATUS_LABEL[p.booking.status]}`}
                    onClick={() => setDraft({ booking: p.booking })}
                  >
                    <strong>{p.booking.kind === 'block' ? p.booking.note || 'Blocked' : p.booking.customerName}</strong>
                    <span>
                      {p.time} · {p.booking.kind === 'block' ? p.booking.staffName || 'Everyone' : p.booking.serviceName}
                      {view === 'week' && p.booking.kind !== 'block' && p.booking.staffName ? ` · ${p.booking.staffName}` : ''}
                    </span>
                  </button>
                ))}
              </div>
            ))}
          </div>
        </div>
      )}
      <p className="bk-bkg-foot">Times are in {tz.replace(/_/g, ' ')} time. Click an empty time to add an appointment; grey means closed.</p>

      {draft ? (
        <BookingModal
          overview={overview}
          draft={draft}
          onClose={() => setDraft(null)}
          onSaved={(message) => {
            setDraft(null);
            setNotice(message);
            void load();
            void reload();
          }}
        />
      ) : null}
    </div>
  );
}
