import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../../api/client';
import { ErrorNotice } from '../../components/ErrorNotice';
import { LiveSearch } from '../../components/LiveSearch';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { bookingsError, formatDay, formatPrice, local, STATUS_LABEL, STATUS_TONE, useOverview, type Booking } from './api';
import { BookingModal } from './BookingModal';
import { StatusPill } from './parts';
import './bookings.css';

type Tab = 'upcoming' | 'pending' | 'past' | 'cancelled';
const TABS: { id: Tab; label: string }[] = [
  { id: 'upcoming', label: 'Upcoming' },
  { id: 'pending', label: 'Waiting for you' },
  { id: 'past', label: 'Past' },
  { id: 'cancelled', label: 'Cancelled' },
];

/** Every appointment as a list: what is coming, what waits for confirmation, and what is done. */
export function AppointmentsPage() {
  const { data: overview, error: loadError } = useOverview();
  const [tab, setTab] = useState<Tab>('upcoming');
  const [search, setSearch] = useState('');
  const [list, setList] = useState<{ items: Booking[]; counts: Record<string, number> } | null>(null);
  const [open, setOpen] = useState<Booking | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // Only the newest request may fill the list.
  const latest = useRef(0);
  const load = useCallback(async () => {
    const ticket = ++latest.current;
    try {
      const q = new URLSearchParams({ status: tab, ...(search ? { search } : {}) });
      const res = await api<{ items: Booking[]; counts: Record<string, number> }>(`/api/bookings?${q.toString()}`);
      if (ticket === latest.current) setList(res);
    } catch (e) {
      if (ticket === latest.current) setError(bookingsError(e));
    }
  }, [tab, search]);
  useEffect(() => {
    void load();
  }, [load]);

  const tz = overview?.settings.timezone ?? 'UTC';
  const items = (list?.items ?? []).filter((b) => b.kind === 'appointment');

  return (
    <div className="wrap wrap--wide bk-bkg">
      <PageHeader title="Appointments" />
      {loadError ? <ErrorNotice message={loadError} onDismiss={() => undefined} /> : null}
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <nav className="bk-tabs" aria-label="Appointments">
        {TABS.map((t) => (
          <button key={t.id} type="button" className={`bk-tabs__item${tab === t.id ? ' is-active' : ''}`} onClick={() => setTab(t.id)}>
            {t.label}
            {t.id === 'upcoming' || t.id === 'pending' ? <span className="bk-tabs__count">{list?.counts[t.id] ?? 0}</span> : null}
          </button>
        ))}
      </nav>

      <div className="bk-bkg-listbar">
        <LiveSearch value={search} onSearch={setSearch} placeholder="Search by name, email or phone…" label="Search appointments" />
        <span className="bk-bkg-muted">{list ? `${items.length} ${items.length === 1 ? 'appointment' : 'appointments'}` : ''}</span>
      </div>

      <div className="bk-bkg-table-wrap">
        <table className="bk-bkg-table">
          <thead>
            <tr>
              <th>When</th>
              <th>Customer</th>
              <th>Service</th>
              <th>With</th>
              <th>Price</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {!list ? (
              <tr>
                <td colSpan={6} className="bk-bkg-table__empty">
                  Loading…
                </td>
              </tr>
            ) : items.length === 0 ? (
              <tr>
                <td colSpan={6} className="bk-bkg-table__empty">
                  {search ? `Nothing matches “${search}”.` : tab === 'upcoming' ? 'No upcoming appointments yet. They appear here as soon as someone books.' : tab === 'pending' ? 'Nothing is waiting for your confirmation.' : `No ${tab} appointments.`}
                </td>
              </tr>
            ) : (
              items.map((b) => {
                const when = local(b.startAt, tz);
                return (
                  <tr key={b.id} className="is-clickable" tabIndex={0} onClick={() => setOpen(b)} onKeyDown={(e) => e.key === 'Enter' && setOpen(b)}>
                    <td>
                      <span className="bk-bkg-table__primary">{formatDay(when.date)}</span>
                      <span className="bk-bkg-table__sub">{when.time}</span>
                    </td>
                    <td>
                      <span className="bk-bkg-table__primary">{b.customerName}</span>
                      <span className="bk-bkg-table__sub">{[b.customerEmail, b.customerPhone].filter(Boolean).join(' · ')}</span>
                    </td>
                    <td>
                      <span className="bk-bkg-dot" style={{ background: b.color }} aria-hidden /> {b.serviceName}
                    </td>
                    <td>{b.staffName || '—'}</td>
                    <td>{overview ? formatPrice(b.priceCents, overview.settings.currency) : ''}</td>
                    <td>
                      <StatusPill tone={STATUS_TONE[b.status]}>{STATUS_LABEL[b.status]}</StatusPill>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {open && overview ? (
        <BookingModal
          overview={overview}
          draft={{ booking: open }}
          onClose={() => setOpen(null)}
          onSaved={(message) => {
            setOpen(null);
            setNotice(message);
            void load();
          }}
        />
      ) : null}
    </div>
  );
}
