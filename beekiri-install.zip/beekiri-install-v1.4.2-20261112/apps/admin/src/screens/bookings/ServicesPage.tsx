import { useState } from 'react';
import { Plus } from '@phosphor-icons/react';
import { api } from '../../api/client';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { bookingsError, does, formatDuration, formatPrice, useOverview, type Service } from './api';
import { Check, Field, Modal, StatusPill } from './parts';
import './bookings.css';

const COLORS = ['#006199', '#4f7a26', '#a9531a', '#7b4fa3', '#b32d2e', '#2f7f7b', '#8a6d00', '#50575e'];
const DURATIONS = [15, 20, 30, 45, 60, 75, 90, 120, 150, 180, 240];

type Form = { id: string | null; name: string; description: string; durationMin: number; bufferMin: number; price: string; color: string; active: boolean };

const formOf = (s: Service | null, index: number): Form => ({
  id: s?.id ?? null,
  name: s?.name ?? '',
  description: s?.description ?? '',
  durationMin: s?.durationMin ?? 60,
  bufferMin: s?.bufferMin ?? 0,
  price: s ? (s.priceCents ? (s.priceCents / 100).toFixed(2) : '') : '',
  color: s?.color ?? COLORS[index % COLORS.length],
  active: s?.active ?? true,
});

/** What customers can book: how long it takes, what it costs, and the free time kept after it. */
export function ServicesPage() {
  const { data: overview, error: loadError, reload } = useOverview();
  const [form, setForm] = useState<Form | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const save = async () => {
    if (!form) return;
    const price = Number(form.price.replace(',', '.') || 0);
    if (!Number.isFinite(price) || price < 0) return setFormError('The price must be a number, like 45 or 19.50.');
    setBusy(true);
    setFormError(null);
    try {
      const body = { name: form.name, description: form.description, durationMin: form.durationMin, bufferMin: form.bufferMin, priceCents: Math.round(price * 100), color: form.color, active: form.active };
      if (form.id) await api(`/api/bookings/services/${form.id}`, { method: 'PATCH', json: body });
      else await api('/api/bookings/services', { method: 'POST', json: body });
      setNotice(form.id ? 'Service saved.' : 'Service added.');
      setForm(null);
      await reload();
    } catch (e) {
      setFormError(bookingsError(e));
    } finally {
      setBusy(false);
    }
  };

  const remove = async (s: Service) => {
    const ok = await confirmDialog({ title: `Delete “${s.name}”?`, message: 'Past appointments keep its name. Customers can no longer book it.', confirmLabel: 'Delete', danger: true });
    if (!ok) return;
    try {
      await api(`/api/bookings/services/${s.id}`, { method: 'DELETE' });
      setNotice('Service deleted.');
      setForm(null);
      await reload();
    } catch (e) {
      setError(bookingsError(e));
    }
  };

  const services = overview?.services ?? [];
  return (
    <div className="wrap wrap--wide bk-bkg">
      <PageHeader
        title="Services"
        actions={
          <button type="button" className="button button-primary" onClick={() => setForm(formOf(null, services.length))}>
            <Plus size={14} weight="bold" aria-hidden /> Add service
          </button>
        }
      />
      <p className="bk-muted">What customers can book. Each service has its own length and price.</p>
      {loadError ? <ErrorNotice message={loadError} onDismiss={() => undefined} /> : null}
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      {overview && services.length === 0 ? (
        <div className="bk-bkg-blank">
          <h2>No services yet</h2>
          <p>Add the first thing people can book: a haircut, a consultation, a class.</p>
          <button type="button" className="button button-primary" onClick={() => setForm(formOf(null, 0))}>
            Add service
          </button>
        </div>
      ) : (
        <div className="bk-bkg-table-wrap">
          <table className="bk-bkg-table">
            <thead>
              <tr>
                <th>Service</th>
                <th>Length</th>
                <th>Price</th>
                <th>Done by</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {!overview ? (
                <tr>
                  <td colSpan={5} className="bk-bkg-table__empty">
                    Loading…
                  </td>
                </tr>
              ) : (
                services.map((s, i) => {
                  const who = overview.staff.filter((p) => p.active && does(p, s.id));
                  return (
                    <tr key={s.id} className="is-clickable" tabIndex={0} onClick={() => setForm(formOf(s, i))} onKeyDown={(e) => e.key === 'Enter' && setForm(formOf(s, i))}>
                      <td>
                        <span className="bk-bkg-table__primary">
                          <span className="bk-bkg-dot" style={{ background: s.color }} aria-hidden /> {s.name}
                        </span>
                        {s.description ? <span className="bk-bkg-table__sub">{s.description}</span> : null}
                      </td>
                      <td>
                        {formatDuration(s.durationMin)}
                        {s.bufferMin ? <span className="bk-bkg-table__sub">+ {formatDuration(s.bufferMin)} free after</span> : null}
                      </td>
                      <td>{formatPrice(s.priceCents, overview.settings.currency)}</td>
                      <td>{who.length ? who.map((p) => p.name).join(', ') : <span className="bk-bkg-warn">Nobody yet</span>}</td>
                      <td>
                        <StatusPill tone={s.active ? 'ok' : 'muted'}>{s.active ? 'Bookable' : 'Off'}</StatusPill>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      )}

      {form && overview ? (
        <Modal
          title={form.id ? 'Edit service' : 'New service'}
          onClose={() => setForm(null)}
          footer={
            <>
              {form.id ? (
                <button type="button" className="button-link is-danger" disabled={busy} onClick={() => void remove(services.find((s) => s.id === form.id)!)}>
                  Delete
                </button>
              ) : (
                <span />
              )}
              <span className="bk-bkg-modal__actions">
                <button type="button" className="button" onClick={() => setForm(null)}>
                  Cancel
                </button>
                <button type="button" className="button button-primary" disabled={busy || !form.name.trim()} onClick={() => void save()}>
                  {busy ? 'Saving…' : 'Save'}
                </button>
              </span>
            </>
          }
        >
          {formError ? (
            <div className="bk-bkg-alert" role="alert">
              <span>{formError}</span>
            </div>
          ) : null}
          <div className="bk-bkg-form">
            <Field label="Name" wide>
              <input type="text" value={form.name} maxLength={120} placeholder="e.g. Haircut" autoFocus onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </Field>
            <Field label="Short description (optional)" wide>
              <input type="text" value={form.description} maxLength={300} placeholder="Shown under the name on the website" onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </Field>
            <Field label="Length">
              <select value={form.durationMin} onChange={(e) => setForm({ ...form, durationMin: Number(e.target.value) })}>
                {[...new Set([...DURATIONS, form.durationMin])].sort((a, b) => a - b).map((m) => (
                  <option key={m} value={m}>
                    {formatDuration(m)}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Free time after" hint="To clean up or travel before the next one">
              <select value={form.bufferMin} onChange={(e) => setForm({ ...form, bufferMin: Number(e.target.value) })}>
                {[...new Set([0, 5, 10, 15, 20, 30, 45, 60, form.bufferMin])].sort((a, b) => a - b).map((m) => (
                  <option key={m} value={m}>
                    {m ? formatDuration(m) : 'None'}
                  </option>
                ))}
              </select>
            </Field>
            <Field label={`Price (${overview.settings.currency})`} hint="Leave empty for free">
              <input type="text" inputMode="decimal" value={form.price} placeholder="0.00" onChange={(e) => setForm({ ...form, price: e.target.value })} />
            </Field>
            <div className="bk-bkg-field">
              <span>Colour on the calendar</span>
              <div className="bk-bkg-colors">
                {COLORS.map((c) => (
                  <button key={c} type="button" className={c === form.color ? 'is-selected' : ''} style={{ background: c }} aria-label={`Colour ${c}`} aria-pressed={c === form.color} onClick={() => setForm({ ...form, color: c })} />
                ))}
              </div>
            </div>
            <div className="bk-bkg-field is-wide">
              <Check checked={form.active} onChange={(v) => setForm({ ...form, active: v })}>
                Customers can book this on the website
              </Check>
            </div>
          </div>
        </Modal>
      ) : null}
    </div>
  );
}
