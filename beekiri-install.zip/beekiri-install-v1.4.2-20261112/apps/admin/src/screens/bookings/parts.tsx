import { useEffect, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Plus, Trash, X } from '@phosphor-icons/react';
import { DAY_KEYS, DAY_LABELS, minutesOf, type DateRange, type Interval, type WeekHours } from './api';

/** A dialog over the admin: title, body, and a footer of actions. Esc or the backdrop closes it. */
export function Modal({ title, onClose, children, footer, wide }: { title: ReactNode; onClose: () => void; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return createPortal(
    <div
      className="bk-bkg-modal"
      role="dialog"
      aria-modal="true"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className={`bk-bkg-modal__box${wide ? ' is-wide' : ''}`}>
        <div className="bk-bkg-modal__head">
          <h2>{title}</h2>
          <button type="button" className="bk-bkg-iconbtn" onClick={onClose} aria-label="Close">
            <X size={16} aria-hidden />
          </button>
        </div>
        <div className="bk-bkg-modal__body">{children}</div>
        {footer ? <div className="bk-bkg-modal__foot">{footer}</div> : null}
      </div>
    </div>,
    document.getElementById('beekiri-admin') ?? document.body,
  );
}

export function Field({ label, hint, children, wide }: { label: string; hint?: string; children: ReactNode; wide?: boolean }) {
  return (
    <label className={`bk-bkg-field${wide ? ' is-wide' : ''}`}>
      <span>{label}</span>
      {children}
      {hint ? <small>{hint}</small> : null}
    </label>
  );
}

export function Check({ checked, onChange, children, disabled }: { checked: boolean; onChange: (v: boolean) => void; children: ReactNode; disabled?: boolean }) {
  return (
    <label className="bk-check bk-bkg-check">
      <input type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} /> <span className="bk-check__box" aria-hidden />
      <span>{children}</span>
    </label>
  );
}

const OPEN: Interval = { from: '09:00', to: '17:00' };

/** Opening hours for each weekday: open or closed, from–to, and an optional second part of the day. */
export function WeekHoursEditor({ value, onChange }: { value: WeekHours; onChange: (v: WeekHours) => void }) {
  const set = (day: (typeof DAY_KEYS)[number], intervals: Interval[]) => onChange({ ...value, [day]: intervals });
  return (
    <div className="bk-bkg-hours">
      {DAY_KEYS.map((day) => {
        const intervals = value[day] ?? [];
        const open = intervals.length > 0;
        return (
          <div key={day} className={`bk-bkg-hours__row${open ? '' : ' is-closed'}`}>
            <Check checked={open} onChange={(v) => set(day, v ? [OPEN] : [])}>
              {DAY_LABELS[day]}
            </Check>
            <div className="bk-bkg-hours__times">
              {open ? (
                intervals.map((iv, i) => (
                  <span key={i} className="bk-bkg-hours__interval">
                    <input type="time" value={iv.from} aria-label={`${DAY_LABELS[day]} from`} onChange={(e) => set(day, intervals.map((x, k) => (k === i ? { ...x, from: e.target.value } : x)))} />
                    <span>to</span>
                    <input type="time" value={iv.to} aria-label={`${DAY_LABELS[day]} to`} onChange={(e) => set(day, intervals.map((x, k) => (k === i ? { ...x, to: e.target.value } : x)))} />
                    {i > 0 ? (
                      <button type="button" className="bk-bkg-iconbtn" onClick={() => set(day, intervals.filter((_, k) => k !== i))} aria-label="Remove these hours">
                        <X size={13} aria-hidden />
                      </button>
                    ) : null}
                    {minutesOf(iv.to) <= minutesOf(iv.from) ? <em>End must be after start</em> : null}
                  </span>
                ))
              ) : (
                <span className="bk-bkg-muted">Closed</span>
              )}
            </div>
            {open && intervals.length < 2 ? (
              <button
                type="button"
                className="button-link bk-bkg-hours__add"
                title="For a lunch break: a morning and an afternoon"
                onClick={() => {
                  const last = intervals[intervals.length - 1];
                  const from = Math.min(minutesOf(last.to) + 60, 22 * 60);
                  set(day, [...intervals, { from: `${String(Math.floor(from / 60)).padStart(2, '0')}:00`, to: `${String(Math.min(Math.floor(from / 60) + 4, 23)).padStart(2, '0')}:00` }]);
                }}
              >
                Add a break
              </button>
            ) : (
              <span />
            )}
          </div>
        );
      })}
    </div>
  );
}

/** A list of dates or date ranges with a note: holidays, days off. */
export function DateRangesEditor({ value, onChange, addLabel, noteHint }: { value: DateRange[]; onChange: (v: DateRange[]) => void; addLabel: string; noteHint: string }) {
  return (
    <div className="bk-bkg-ranges">
      {value.map((r, i) => (
        <div key={i} className="bk-bkg-ranges__row">
          <input type="date" value={r.from} aria-label="From" onChange={(e) => onChange(value.map((x, k) => (k === i ? { ...x, from: e.target.value, to: x.to < e.target.value ? e.target.value : x.to } : x)))} />
          <span>to</span>
          <input type="date" value={r.to} min={r.from} aria-label="To" onChange={(e) => onChange(value.map((x, k) => (k === i ? { ...x, to: e.target.value } : x)))} />
          <input type="text" value={r.note} placeholder={noteHint} maxLength={120} aria-label="Note" onChange={(e) => onChange(value.map((x, k) => (k === i ? { ...x, note: e.target.value } : x)))} />
          <button type="button" className="bk-bkg-iconbtn is-danger" onClick={() => onChange(value.filter((_, k) => k !== i))} aria-label="Remove">
            <Trash size={14} aria-hidden />
          </button>
        </div>
      ))}
      <button
        type="button"
        className="button"
        onClick={() => {
          const today = new Date().toISOString().slice(0, 10);
          onChange([...value, { from: today, to: today, note: '' }]);
        }}
      >
        <Plus size={13} weight="bold" aria-hidden /> {addLabel}
      </button>
    </div>
  );
}

export function StatusPill({ tone, children }: { tone: string; children: ReactNode }) {
  return <span className={`bk-bkg-pill is-${tone}`}>{children}</span>;
}
