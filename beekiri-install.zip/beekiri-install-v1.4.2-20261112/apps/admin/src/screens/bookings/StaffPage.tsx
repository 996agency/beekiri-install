import { useState } from 'react';
import { Plus } from '@phosphor-icons/react';
import { api } from '../../api/client';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { bookingsError, DAY_KEYS, useOverview, type DateRange, type Staff, type WeekHours } from './api';
import { Check, DateRangesEditor, Field, Modal, StatusPill, WeekHoursEditor } from './parts';
import './bookings.css';

type Form = { id: string | null; name: string; email: string; phone: string; allServices: boolean; serviceIds: string[]; ownHours: boolean; hours: WeekHours; daysOff: DateRange[]; active: boolean };

/** "Mon–Fri 09:00–17:00"-style line for a week of hours. */
function hoursSummary(hours: WeekHours): string {
  const open = DAY_KEYS.filter((d) => hours[d]?.length);
  if (!open.length) return 'Never';
  const first = hours[open[0]].map((i) => `${i.from}–${i.to}`).join(', ');
  const same = open.every((d) => hours[d].map((i) => `${i.from}–${i.to}`).join(', ') === first);
  const names = open.map((d) => d[0].toUpperCase() + d.slice(1));
  return same ? `${names.length > 2 ? `${names[0]}–${names[names.length - 1]}` : names.join(', ')} ${first}` : `${names.join(', ')} (different hours)`;
}

/** The people who take appointments: what they do, when they work, and their days off. */
export function StaffPage() {
  const { data: overview, error: loadError, reload } = useOverview();
  const [form, setForm] = useState<Form | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const formOf = (s: Staff | null): Form => ({
    id: s?.id ?? null,
    name: s?.name ?? '',
    email: s?.email ?? '',
    phone: s?.phone ?? '',
    allServices: !s || s.serviceIds.length === 0,
    serviceIds: s?.serviceIds ?? [],
    ownHours: Boolean(s?.hours),
    hours: s?.hours ?? overview!.settings.hours,
    daysOff: s?.daysOff ?? [],
    active: s?.active ?? true,
  });

  const save = async () => {
    if (!form) return;
    setBusy(true);
    setFormError(null);
    try {
      const body = {
        name: form.name,
        email: form.email,
        phone: form.phone,
        serviceIds: form.allServices ? [] : form.serviceIds,
        hours: form.ownHours ? form.hours : null,
        daysOff: form.daysOff.filter((d) => d.from),
        active: form.active,
      };
      if (form.id) await api(`/api/bookings/staff/${form.id}`, { method: 'PATCH', json: body });
      else await api('/api/bookings/staff', { method: 'POST', json: body });
      setNotice(form.id ? 'Staff member saved.' : 'Staff member added.');
      setForm(null);
      await reload();
    } catch (e) {
      setFormError(bookingsError(e));
    } finally {
      setBusy(false);
    }
  };

  const remove = async (s: Staff) => {
    const ok = await confirmDialog({ title: `Remove ${s.name}?`, message: 'Past appointments stay on the calendar without a name. Customers can no longer book this person.', confirmLabel: 'Remove', danger: true });
    if (!ok) return;
    try {
      await api(`/api/bookings/staff/${s.id}`, { method: 'DELETE' });
      setNotice('Staff member removed.');
      setForm(null);
      await reload();
    } catch (e) {
      setError(bookingsError(e));
    }
  };

  const staff = overview?.staff ?? [];
  const services = overview?.services ?? [];
  return (
    <div className="wrap wrap--wide bk-bkg">
      <PageHeader
        title="Staff"
        actions={
          <button type="button" className="button button-primary" disabled={!overview} onClick={() => setForm(formOf(null))}>
            <Plus size={14} weight="bold" aria-hidden /> Add staff member
          </button>
        }
      />
      <p className="bk-muted">Who takes appointments. Each person can have their own services, working hours and days off. Working alone? Add yourself.</p>
      {loadError ? <ErrorNotice message={loadError} onDismiss={() => undefined} /> : null}
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      {overview && staff.length === 0 ? (
        <div className="bk-bkg-blank">
          <h2>No staff yet</h2>
          <p>Bookings need at least one person. Add yourself, or everyone who takes appointments.</p>
          <button type="button" className="button button-primary" onClick={() => setForm(formOf(null))}>
            Add staff member
          </button>
        </div>
      ) : (
        <div className="bk-bkg-table-wrap">
          <table className="bk-bkg-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Services</th>
                <th>Working hours</th>
                <th>Days off</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {!overview ? (
                <tr>
                  <td colSpan={5} className="bk-bkg-table__empty">
                    Loading…
                  </td>
                </tr>
              ) : (
                staff.map((s) => (
                  <tr key={s.id} className="is-clickable" tabIndex={0} onClick={() => setForm(formOf(s))} onKeyDown={(e) => e.key === 'Enter' && setForm(formOf(s))}>
                    <td>
                      <span className="bk-bkg-table__primary">{s.name}</span>
                      <span className="bk-bkg-table__sub">{[s.email, s.phone].filter(Boolean).join(' · ')}</span>
                    </td>
                    <td>{s.serviceIds.length ? services.filter((x) => s.serviceIds.includes(x.id)).map((x) => x.name).join(', ') || '—' : 'All services'}</td>
                    <td>{s.hours ? hoursSummary(s.hours) : <span className="bk-bkg-muted">Business hours</span>}</td>
                    <td>{s.daysOff.length ? `${s.daysOff.length} planned` : <span className="bk-bkg-muted">None</span>}</td>
                    <td>
                      <StatusPill tone={s.active ? 'ok' : 'muted'}>{s.active ? 'Bookable' : 'Off'}</StatusPill>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {form && overview ? (
        <Modal
          wide
          title={form.id ? 'Edit staff member' : 'New staff member'}
          onClose={() => setForm(null)}
          footer={
            <>
              {form.id ? (
                <button type="button" className="button-link is-danger" disabled={busy} onClick={() => void remove(staff.find((s) => s.id === form.id)!)}>
                  Remove
                </button>
              ) : (
                <span />
              )}
              <span className="bk-bkg-modal__actions">
                <button type="button" className="button" onClick={() => setForm(null)}>
                  Cancel
                </button>
                <button type="button" className="button button-primary" disabled={busy || !form.name.trim()} onClick={() => void save()}>
                  {busy ? 'Saving…' : 'Save'}
                </button>
              </span>
            </>
          }
        >
          {formError ? (
            <div className="bk-bkg-alert" role="alert">
              <span>{formError}</span>
            </div>
          ) : null}
          <div className="bk-bkg-form">
            <Field label="Name" wide>
              <input type="text" value={form.name} maxLength={120} autoFocus onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </Field>
            <Field label="Email" hint="New bookings for this person are emailed here">
              <input type="email" value={form.email} maxLength={200} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </Field>
            <Field label="Phone (optional)">
              <input type="tel" value={form.phone} maxLength={40} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </Field>
          </div>

          <h3 className="bk-bkg-subhead">Services</h3>
          <Check checked={form.allServices} onChange={(v) => setForm({ ...form, allServices: v })}>
            Does every service
          </Check>
          {!form.allServices ? (
            <div className="bk-bkg-checks">
              {services.length === 0 ? <span className="bk-bkg-muted">Add services first.</span> : null}
              {services.map((s) => (
                <Check key={s.id} checked={form.serviceIds.includes(s.id)} onChange={(v) => setForm({ ...form, serviceIds: v ? [...form.serviceIds, s.id] : form.serviceIds.filter((id) => id !== s.id) })}>
                  {s.name}
                </Check>
              ))}
            </div>
          ) : null}

          <h3 className="bk-bkg-subhead">Working hours</h3>
          <Check checked={!form.ownHours} onChange={(v) => setForm({ ...form, ownHours: !v })}>
            Same as the business hours
          </Check>
          {form.ownHours ? <WeekHoursEditor value={form.hours} onChange={(hours) => setForm({ ...form, hours })} /> : null}

          <h3 className="bk-bkg-subhead">Days off</h3>
          <DateRangesEditor value={form.daysOff} onChange={(daysOff) => setForm({ ...form, daysOff })} addLabel="Add days off" noteHint="e.g. Holiday" />

          <h3 className="bk-bkg-subhead">Availability</h3>
          <Check checked={form.active} onChange={(v) => setForm({ ...form, active: v })}>
            Customers can book this person on the website
          </Check>
        </Modal>
      ) : null}
    </div>
  );
}
