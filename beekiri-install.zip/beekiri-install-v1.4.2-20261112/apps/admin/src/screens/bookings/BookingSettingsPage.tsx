import { useEffect, useState } from 'react';
import { Check as CheckIcon, Copy } from '@phosphor-icons/react';
import { api } from '../../api/client';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { bookingsError, useOverview, type Settings } from './api';
import { Check, DateRangesEditor, Field, WeekHoursEditor } from './parts';
import './bookings.css';

const SHORTCODE = '[bee_booking]';

/** Opening hours, booking rules, holidays and emails for the whole business. */
export function BookingSettingsPage() {
  const { data: overview, error: loadError, reload } = useOverview();
  const [form, setForm] = useState<Settings | null>(null);
  const [baseline, setBaseline] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (overview && !form) {
      setForm(overview.settings);
      setBaseline(JSON.stringify(overview.settings));
    }
  }, [overview, form]);

  if (!form) {
    return (
      <div className="wrap bk-bkg">
        <PageHeader title="Booking settings" />
        {loadError ? <ErrorNotice message={loadError} onDismiss={() => undefined} /> : <p className="bk-muted">Loading…</p>}
      </div>
    );
  }

  const set = <K extends keyof Settings>(key: K, value: Settings[K]) => setForm({ ...form, [key]: value });
  const num = (v: string, fallback: number) => (v === '' || Number.isNaN(Number(v)) ? fallback : Math.max(0, Math.round(Number(v))));
  const dirty = JSON.stringify(form) !== baseline;

  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      const saved = await api<Settings>('/api/bookings/settings', { method: 'PUT', json: { ...form, closedDates: form.closedDates.filter((d) => d.from) } });
      setForm(saved);
      setBaseline(JSON.stringify(saved));
      setNotice('Settings saved.');
      await reload();
    } catch (e) {
      setError(bookingsError(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="wrap bk-bkg bk-bkg-settings">
      <PageHeader
        title="Booking settings"
        actions={
          <button type="button" className="button button-primary" disabled={busy || !dirty} onClick={() => void save()}>
            {busy ? 'Saving…' : 'Save changes'}
          </button>
        }
      />
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <section className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Show it on your website</h2>
        </div>
        <div className="bk-panel__body">
          <p className="bk-bkg-help">
            In the page editor, add the <strong>Booking</strong> element where the booking calendar should appear. Or type this in any text on a page:
          </p>
          <button
            type="button"
            className="bk-bkg-code"
            onClick={() => {
              void navigator.clipboard?.writeText(SHORTCODE).then(() => {
                setCopied(true);
                window.setTimeout(() => setCopied(false), 1400);
              });
            }}
          >
            <code>{SHORTCODE}</code>
            {copied ? <CheckIcon size={14} aria-hidden /> : <Copy size={14} aria-hidden />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
          <p className="bk-bkg-help">
            To open straight on one service: <code>[bee_booking service="Haircut"]</code>. You can also ask Beekiri in the chat to build a booking page for you.
          </p>
        </div>
      </section>

      <section className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Business hours</h2>
          <span className="bk-bkg-muted">Staff follow these unless they have their own</span>
        </div>
        <div className="bk-panel__body">
          <WeekHoursEditor value={form.hours} onChange={(hours) => set('hours', hours)} />
        </div>
      </section>

      <section className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Booking rules</h2>
        </div>
        <div className="bk-panel__body">
          <div className="bk-bkg-form">
            <Field label="Start times every" hint="How often a new start time is offered">
              <select value={form.slotStep} onChange={(e) => set('slotStep', Number(e.target.value))}>
                {[10, 15, 20, 30, 45, 60, 90, 120].map((m) => (
                  <option key={m} value={m}>
                    {m} minutes
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Book at least … hours ahead" hint="0 = right up to the start">
              <input type="number" min={0} max={720} value={form.minNoticeHours} onChange={(e) => set('minNoticeHours', num(e.target.value, form.minNoticeHours))} />
            </Field>
            <Field label="Book at most … days ahead">
              <input type="number" min={1} max={365} value={form.maxDaysAhead} onChange={(e) => set('maxDaysAhead', Math.max(1, num(e.target.value, form.maxDaysAhead)))} />
            </Field>
            <Field label="Customers can cancel until … hours before" hint="From the link in their email. 0 = any time">
              <input type="number" min={0} max={720} value={form.cancelHours} onChange={(e) => set('cancelHours', num(e.target.value, form.cancelHours))} />
            </Field>
            <div className="bk-bkg-field is-wide">
              <Check checked={form.autoConfirm} onChange={(v) => set('autoConfirm', v)}>
                Confirm website bookings straight away
              </Check>
              <small>{form.autoConfirm ? 'The time is the customer’s as soon as they book.' : 'Each booking waits under Appointments → Waiting for you until you confirm it.'}</small>
            </div>
          </div>
        </div>
      </section>

      <section className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Holidays and closed days</h2>
          <span className="bk-bkg-muted">Nobody can be booked on these days</span>
        </div>
        <div className="bk-panel__body">
          <DateRangesEditor value={form.closedDates} onChange={(closedDates) => set('closedDates', closedDates)} addLabel="Add closed days" noteHint="e.g. New Year" />
        </div>
      </section>

      <section className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Emails</h2>
        </div>
        <div className="bk-panel__body">
          <div className="bk-bkg-form">
            <Field label="Send new bookings to" hint="The staff member booked is always emailed too">
              <input type="email" value={form.notifyEmail} maxLength={200} placeholder="you@example.com" onChange={(e) => set('notifyEmail', e.target.value)} />
            </Field>
            <Field label="Remind the customer … hours before" hint="0 = no reminder">
              <input type="number" min={0} max={336} value={form.reminderHours} onChange={(e) => set('reminderHours', num(e.target.value, form.reminderHours))} />
            </Field>
            <Field label="Extra line in the confirmation (optional)" hint="What to bring, where to park…" wide>
              <textarea rows={2} value={form.confirmationNote} maxLength={1000} onChange={(e) => set('confirmationNote', e.target.value)} />
            </Field>
          </div>
        </div>
      </section>

      <section className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Place and money</h2>
        </div>
        <div className="bk-panel__body">
          <div className="bk-bkg-form">
            <Field label="Where appointments happen" hint="An address, a room, or “Online”. Shown to the customer" wide>
              <input type="text" value={form.location} maxLength={300} onChange={(e) => set('location', e.target.value)} />
            </Field>
            <Field label="Currency" hint="Three letters, like EUR, USD, GBP">
              <input type="text" value={form.currency} maxLength={3} onChange={(e) => set('currency', e.target.value.toUpperCase())} />
            </Field>
            <Field label="Time zone" hint="All hours and appointment times use it">
              <input type="text" value={form.timezone} maxLength={64} placeholder="Europe/Skopje" onChange={(e) => set('timezone', e.target.value)} />
            </Field>
          </div>
        </div>
      </section>
    </div>
  );
}
