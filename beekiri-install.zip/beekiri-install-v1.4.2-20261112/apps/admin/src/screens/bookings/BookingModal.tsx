import { useEffect, useMemo, useState } from 'react';
import { api, ApiError } from '../../api/client';
import { confirmDialog } from '../../components/ConfirmDialog';
import {
  addDays,
  bookingsError,
  clockOf,
  does,
  formatDay,
  formatDuration,
  formatPrice,
  local,
  minutesOf,
  STATUS_LABEL,
  STATUS_TONE,
  zonedIso,
  type Booking,
  type BookingStatus,
  type Overview,
} from './api';
import { Check, Field, Modal, StatusPill } from './parts';

/** What the dialog opens on: an existing appointment or block, or a new one at a clicked time. */
export type BookingDraft = { booking: Booking } | { kind: 'appointment' | 'block'; date: string; time: string; staffId?: string | null };

type Props = { overview: Overview; draft: BookingDraft; onClose: () => void; onSaved: (message: string) => void };

/** Add, change, move or cancel an appointment — or block time off the calendar. */
export function BookingModal({ overview, draft, onClose, onSaved }: Props) {
  const tz = overview.settings.timezone;
  const existing = 'booking' in draft ? draft.booking : null;
  const kind = existing ? existing.kind : (draft as { kind: 'appointment' | 'block' }).kind;
  const startParts = existing ? local(existing.startAt, tz) : null;
  const fresh = existing ? null : (draft as { date: string; time: string; staffId?: string | null });

  const activeServices = overview.services.filter((s) => s.active || s.id === existing?.serviceId);
  const [serviceId, setServiceId] = useState(existing?.serviceId ?? activeServices[0]?.id ?? '');
  const [staffId, setStaffId] = useState<string>(existing?.staffId ?? fresh?.staffId ?? '');
  const [date, setDate] = useState(startParts?.date ?? fresh!.date);
  const [time, setTime] = useState(startParts?.time ?? fresh!.time);
  const [endTime, setEndTime] = useState(existing ? local(existing.endAt, tz).time : clockOf(Math.min(minutesOf(fresh!.time) + 60, 23 * 60 + 59)));
  const [name, setName] = useState(existing?.customerName ?? '');
  const [email, setEmail] = useState(existing?.customerEmail ?? '');
  const [phone, setPhone] = useState(existing?.customerPhone ?? '');
  const [note, setNote] = useState(existing?.note ?? '');
  const [adminNote, setAdminNote] = useState(existing?.adminNote ?? '');
  const [notify, setNotify] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  /** The server said the time is taken: offer to book over it. */
  const [clash, setClash] = useState(false);
  const [slots, setSlots] = useState<string[] | null>(null);

  const service = overview.services.find((s) => s.id === serviceId) ?? null;
  const people = useMemo(
    () => overview.staff.filter((p) => (p.active || p.id === existing?.staffId) && (kind === 'block' || !serviceId || does(p, serviceId))),
    [overview.staff, serviceId, kind, existing?.staffId],
  );

  // An appointment needs a person: default to the first who does the service.
  useEffect(() => {
    if (kind === 'appointment' && people.length && !people.some((p) => p.id === staffId)) setStaffId(people[0].id);
  }, [people, staffId, kind]);

  // Free start times for that service, person and day (the appointment's own time counts as free).
  useEffect(() => {
    if (kind !== 'appointment' || !serviceId || !staffId || !date) return;
    let cancelled = false;
    setSlots(null);
    const q = new URLSearchParams({ serviceId, staffId, date, ...(existing ? { ignoreId: existing.id } : {}) });
    api<{ slots: { time: string }[] }>(`/api/bookings/slots?${q.toString()}`)
      .then((r) => !cancelled && setSlots(r.slots.map((s) => s.time)))
      .catch(() => !cancelled && setSlots([]));
    return () => {
      cancelled = true;
    };
  }, [kind, serviceId, staffId, date, existing]);

  const save = async (opts: { force?: boolean; status?: BookingStatus } = {}) => {
    setBusy(true);
    setError(null);
    setClash(false);
    try {
      const body =
        kind === 'block'
          ? { kind: 'block', staffId: staffId || null, startAt: zonedIso(date, time, tz), endAt: zonedIso(minutesOf(endTime) <= minutesOf(time) ? addDays(date, 1) : date, endTime, tz), note }
          : {
              ...(existing ? {} : { kind: 'appointment', serviceId }),
              staffId,
              startAt: zonedIso(date, time, tz),
              customerName: name,
              customerEmail: email,
              customerPhone: phone,
              note,
              adminNote,
              silent: !notify,
              ...(opts.force ? { force: true } : {}),
              ...(opts.status ? { status: opts.status } : {}),
            };
      if (existing) await api(`/api/bookings/${existing.id}`, { method: 'PATCH', json: body });
      else await api('/api/bookings', { method: 'POST', json: body });
      onSaved(
        opts.status === 'cancelled'
          ? 'Appointment cancelled.'
          : opts.status
            ? `Marked as ${STATUS_LABEL[opts.status].toLowerCase()}.`
            : kind === 'block'
              ? 'Time blocked.'
              : existing
                ? 'Appointment saved.'
                : 'Appointment added.',
      );
    } catch (e) {
      setError(bookingsError(e));
      if (e instanceof ApiError && e.status === 409) setClash(true);
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!existing) return;
    const ok = await confirmDialog({
      title: kind === 'block' ? 'Remove this blocked time?' : 'Delete this appointment?',
      message: kind === 'block' ? 'The time becomes bookable again.' : 'It disappears from the calendar for good and the customer is not told. To tell them, cancel it instead.',
      confirmLabel: kind === 'block' ? 'Remove' : 'Delete',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    try {
      await api(`/api/bookings/${existing.id}`, { method: 'DELETE' });
      onSaved(kind === 'block' ? 'Blocked time removed.' : 'Appointment deleted.');
    } catch (e) {
      setError(bookingsError(e));
      setBusy(false);
    }
  };

  const status = existing?.status;
  const open = status === 'pending' || status === 'confirmed';
  const started = existing ? Date.parse(existing.startAt) < Date.now() : false;
  const canSave = kind === 'block' ? Boolean(date && time && endTime) : Boolean(serviceId && staffId && date && time && name.trim());

  const title =
    kind === 'block' ? (
      existing ? 'Blocked time' : 'Block time'
    ) : existing ? (
      <>
        {existing.customerName || 'Appointment'} <StatusPill tone={STATUS_TONE[existing.status]}>{STATUS_LABEL[existing.status]}</StatusPill>
      </>
    ) : (
      'New appointment'
    );

  return (
    <Modal
      title={title}
      onClose={onClose}
      footer={
        <>
          {existing ? (
            <button type="button" className="button-link is-danger" disabled={busy} onClick={() => void remove()}>
              {kind === 'block' ? 'Remove' : 'Delete'}
            </button>
          ) : (
            <span />
          )}
          <span className="bk-bkg-modal__actions">
            {existing && kind === 'appointment' && open ? (
              <button type="button" className="button" disabled={busy} onClick={() => void save({ status: 'cancelled' })}>
                Cancel appointment
              </button>
            ) : null}
            {status === 'pending' ? (
              <button type="button" className="button" disabled={busy} onClick={() => void save({ status: 'confirmed' })}>
                Confirm
              </button>
            ) : null}
            {status === 'confirmed' && started ? (
              <>
                <button type="button" className="button" disabled={busy} onClick={() => void save({ status: 'no_show' })}>
                  No-show
                </button>
                <button type="button" className="button" disabled={busy} onClick={() => void save({ status: 'completed' })}>
                  Completed
                </button>
              </>
            ) : null}
            {existing && !open && kind === 'appointment' ? (
              <button type="button" className="button" disabled={busy} onClick={() => void save({ status: 'confirmed' })}>
                Reopen
              </button>
            ) : null}
            <button type="button" className="button button-primary" disabled={busy || !canSave} onClick={() => void save()}>
              {busy ? 'Saving…' : existing ? 'Save' : kind === 'block' ? 'Block time' : 'Add appointment'}
            </button>
          </span>
        </>
      }
    >
      {error ? (
        <div className="bk-bkg-alert" role="alert">
          <span>{error}</span>
          {clash ? (
            <button type="button" className="button" disabled={busy} onClick={() => void save({ force: true })}>
              Book anyway
            </button>
          ) : null}
        </div>
      ) : null}

      {kind === 'block' ? (
        <div className="bk-bkg-form">
          <Field label="Who" wide>
            <select value={staffId} onChange={(e) => setStaffId(e.target.value)}>
              <option value="">Everyone</option>
              {people.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Day" wide>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <Field label="From">
            <input type="time" value={time} onChange={(e) => setTime(e.target.value)} />
          </Field>
          <Field label="To">
            <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
          </Field>
          <Field label="Note (only you see it)" wide>
            <input type="text" value={note} maxLength={300} placeholder="e.g. Dentist, stock take" onChange={(e) => setNote(e.target.value)} />
          </Field>
        </div>
      ) : (
        <div className="bk-bkg-form">
          <Field label="Service" hint={service ? `${formatDuration(service.durationMin)} · ${formatPrice(service.priceCents, overview.settings.currency)}` : undefined}>
            {existing ? (
              <input type="text" value={existing.serviceName} disabled />
            ) : (
              <select value={serviceId} onChange={(e) => setServiceId(e.target.value)}>
                {activeServices.length === 0 ? <option value="">Add a service first</option> : null}
                {activeServices.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            )}
          </Field>
          <Field label="With">
            <select value={staffId} onChange={(e) => setStaffId(e.target.value)}>
              {people.length === 0 ? <option value="">Nobody does this service yet</option> : null}
              {people.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Day" hint={date ? formatDay(date, 'long') : undefined}>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <Field label="Time">
            <input type="time" value={time} step={overview.settings.slotStep * 60} onChange={(e) => setTime(e.target.value)} />
          </Field>
          <div className="bk-bkg-field is-wide">
            <span>Free times that day</span>
            {slots === null ? (
              <small>Looking…</small>
            ) : slots.length ? (
              <div className="bk-bkg-slots">
                {slots.map((t) => (
                  <button key={t} type="button" className={t === time ? 'is-selected' : ''} onClick={() => setTime(t)}>
                    {t}
                  </button>
                ))}
              </div>
            ) : (
              <small>No free time in this person’s hours that day. You can still type any time above.</small>
            )}
          </div>
          <Field label="Customer name">
            <input type="text" value={name} maxLength={120} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="Email">
            <input type="email" value={email} maxLength={200} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="Phone">
            <input type="tel" value={phone} maxLength={40} onChange={(e) => setPhone(e.target.value)} />
          </Field>
          <Field label="Your note (only you see it)">
            <input type="text" value={adminNote} maxLength={2000} onChange={(e) => setAdminNote(e.target.value)} />
          </Field>
          <Field label="Customer’s message" wide>
            <textarea rows={2} value={note} maxLength={2000} onChange={(e) => setNote(e.target.value)} />
          </Field>
          <div className="bk-bkg-field is-wide">
            <Check checked={notify && Boolean(email)} disabled={!email} onChange={setNotify}>
              Email the customer about this{email ? '' : ' (add their email first)'}
            </Check>
          </div>
        </div>
      )}
    </Modal>
  );
}
