import { useCallback, useEffect, useState } from 'react';
import { ArrowClockwise } from '@phosphor-icons/react';
import { useSearchParams } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import { confirmDialog } from '../components/ConfirmDialog';
import { ErrorNotice } from '../components/ErrorNotice';
import {
  byDay,
  ListPager,
  PeriodTabs,
  timeOf,
  type HistoryPeriod,
} from '../components/HistoryControls';
import { SuccessNotice } from '../components/SuccessNotice';
import { notifyConnectorChanged } from '../lib/admin-events';
import { formatMoney } from '../lib/money';
import './beequeen-account.css';

type Money = { amount: number; label: string };

type Account =
  | { connected: false }
  | {
      connected: true;
      currency: string;
      paymentMethod: 'stripe' | 'paypal' | 'manual';
      balance: Money;
      month: { month: string; cost: Money; runs: number };
      spent: Money;
      paid: Money;
      topups: { id: string; amount: Money }[];
      customTopup: { min: number; max: number };
      orders: {
        id: string;
        amount: Money;
        status: string;
        createdAt: string | null;
        decidedAt: string | null;
      }[];
    };

/** Spending, one row per message, for a period and a page (paged on 996Agency). */
type History = {
  period: HistoryPeriod;
  page: number;
  pages: number;
  perPage: number;
  total: number;
  spent: Money;
  messages: {
    id: string;
    createdAt: string;
    cost: Money;
    calls: number;
    model: string | null;
    test: boolean;
    /** The request this was for and who sent it, when it came from a chat on this site. */
    prompt?: string | null;
    user?: string | null;
  }[];
};

const PERIOD_SPENT: Record<HistoryPeriod, string> = {
  today: 'Spent today',
  week: 'Spent this week',
  month: 'Spent this month',
  all: 'Spent in total',
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

const dateOf = (iso: string) => new Date(iso).toLocaleDateString(undefined, { dateStyle: 'medium' });

/** Model id → short name ("claude-opus-5-5" → "Opus 5.5"). */
function modelName(id: string | null) {
  const m = id?.match(/^claude-([a-z]+)-(\d+)-(\d+)/);
  return m ? `${m[1][0].toUpperCase()}${m[1].slice(1)} ${m[2]}.${m[3]}` : (id ?? '');
}

const TOPUP_STATUS: Record<string, string> = {
  pending: 'Waiting for payment',
  approved: 'Added',
  rejected: 'Declined',
};

/**
 * This site's prepaid Beekiri balance on 996Agency. Top: what was added, what was spent and what
 * is left, as one sum. Below, side by side: what was spent (every message with its cost) and what
 * was added (with the buttons to add more).
 */
export function BeeQueenAccount({ reloadKey }: { reloadKey: number }) {
  const [account, setAccount] = useState<Account | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [custom, setCustom] = useState('');
  const [params, setParams] = useSearchParams();
  const [period, setPeriod] = useState<HistoryPeriod>('month');
  const [page, setPage] = useState(1);
  const [history, setHistory] = useState<History | null>(null);
  const [historyBusy, setHistoryBusy] = useState(false);
  const [historyError, setHistoryError] = useState<string | null>(null);

  const loadHistory = useCallback(async (p: HistoryPeriod, n: number) => {
    setHistoryBusy(true);
    setHistoryError(null);
    try {
      setHistory(await api<History>(`/api/connector/beequeen/history?period=${p}&page=${n}`));
    } catch (e) {
      setHistoryError(formatError(e));
    } finally {
      setHistoryBusy(false);
    }
  }, []);

  useEffect(() => {
    void loadHistory(period, page);
  }, [loadHistory, period, page, reloadKey]);

  const load = useCallback(async () => {
    setError(null);
    setRefreshing(true);
    try {
      setAccount(await api<Account>('/api/connector/beequeen/account'));
    } catch (e) {
      setAccount(null);
      setError(formatError(e));
    } finally {
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load, reloadKey]);

  // Back from Stripe / PayPal: say what happened, then tidy the address bar.
  useEffect(() => {
    const outcome = params.get('topup');
    if (!outcome) return;
    if (outcome === 'success') setNotice('Payment received — your balance is topped up.');
    else if (outcome === 'cancelled') setNotice('Checkout cancelled. Nothing was charged.');
    else
      setNotice(
        'We could not confirm the payment yet. If you paid, your balance is topped up within a few minutes — refresh this page.',
      );
    const next = new URLSearchParams(params);
    next.delete('topup');
    setParams(next, { replace: true });
    notifyConnectorChanged();
  }, [params, setParams]);

  const topup = async (
    choice: { pack: string } | { amount: number },
    label: string,
    manual: boolean,
  ) => {
    if (manual) {
      const ok = await confirmDialog({
        title: `Add ${label} to the Beekiri balance?`,
        message:
          '996Agency will contact you to arrange payment. The money is added here as soon as it is paid.',
        confirmLabel: 'Send request',
      });
      if (!ok) return;
    }
    setBusy('pack' in choice ? choice.pack : 'custom');
    setError(null);
    setNotice(null);
    try {
      const res = await api<{
        status: 'checkout' | 'pending';
        checkoutUrl: string | null;
        account: Account;
      }>('/api/connector/beequeen/topup', {
        method: 'POST',
        json: choice,
      });
      if (res.status === 'checkout' && res.checkoutUrl) {
        window.location.assign(res.checkoutUrl);
        return;
      }
      setAccount(res.account);
      setCustom('');
      setNotice(`Request sent. ${label} is added once 996Agency confirms the payment.`);
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(null);
    }
  };

  const refresh = () => {
    void load();
    void loadHistory(period, page);
  };

  const head = (
    <div className="bk-panel__head">
      <h2 className="bk-panel__title">Balance</h2>
      <button
        type="button"
        className="button bk-bqa__refresh"
        disabled={refreshing}
        onClick={refresh}
      >
        <ArrowClockwise size={14} aria-hidden className={refreshing ? 'is-spinning' : undefined} />
        <span>Refresh</span>
      </button>
    </div>
  );

  const message = (text: string, isError = false) => (
    <section className="bk-panel bk-bqa">
      {head}
      <div className="bk-panel__body">
        <p className={isError ? 'bk-bqa__error' : 'bk-muted'} style={{ margin: 0 }}>
          {text}
        </p>
      </div>
    </section>
  );

  if (error && !account) return message(error, true);
  if (!account) return message('Loading balance…');
  if (!account.connected)
    return message('The balance appears here once this site is connected to 996Agency.');
  if (!('topups' in account) || typeof account.balance !== 'object')
    return message('996Agency is still on the older billing. Refresh after it has been updated.');

  const money = (v: number, fine = false) => formatMoney(v, account.currency, fine);
  const added = account.orders;
  const manual = account.paymentMethod === 'manual';
  const left = account.balance.amount;
  const empty = left <= 0;
  const { min, max } = account.customTopup;
  const customAmount = Number(custom);
  const customOk = Number.isInteger(customAmount) && customAmount >= min && customAmount <= max;
  // How much of what was added is gone (the bar under the sum).
  const total = Math.max(account.paid.amount, account.spent.amount + Math.max(0, left));
  const spentShare = total > 0 ? Math.min(100, Math.round((account.spent.amount / total) * 100)) : 0;
  const waiting = added.filter((o) => o.status === 'pending');
  const waitingSum = waiting.reduce((sum, o) => sum + o.amount.amount, 0);
  const perMessage = account.month.runs > 0 ? account.month.cost.amount / account.month.runs : 0;
  // Days cut by the page (the first one after page 1, the last one before the last page) get no day total.
  const days = history ? byDay(history.messages, (m) => m.createdAt) : [];

  return (
    <div className="bk-bqa">
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <section className="bk-panel">
        {head}
        <div className="bk-panel__body bk-bqa__overview">
          <div className="bk-bqa__sum">
            <div className="bk-bqa__figure">
              <p className="bk-bqa__figure-label">Added</p>
              <p className="bk-bqa__figure-value">{money(account.paid.amount)}</p>
              <p className="bk-bqa__figure-sub">paid in so far</p>
            </div>
            <span className="bk-bqa__op" aria-hidden>
              −
            </span>
            <div className="bk-bqa__figure">
              <p className="bk-bqa__figure-label">
                <span className="bk-bqa__key is-spent" aria-hidden />
                Spent
              </p>
              <p className="bk-bqa__figure-value">{money(account.spent.amount)}</p>
              <p className="bk-bqa__figure-sub">on Beekiri messages</p>
            </div>
            <span className="bk-bqa__op" aria-hidden>
              =
            </span>
            <div className={`bk-bqa__figure is-left${empty ? ' is-empty' : ''}`}>
              <p className="bk-bqa__figure-label">
                <span className="bk-bqa__key is-left" aria-hidden />
                Left to spend
                {empty ? <span className="bk-bqa__flag">Empty</span> : null}
              </p>
              <p className="bk-bqa__figure-value">{money(left)}</p>
              <p className="bk-bqa__figure-sub">
                {empty ? 'Beekiri pauses until you add money' : 'never expires'}
              </p>
            </div>
          </div>

          <div
            className="bk-bqa__meter"
            role="img"
            aria-label={`${spentShare}% of what you added is spent, ${100 - spentShare}% is left`}
          >
            <span style={{ width: `${spentShare}%` }} />
          </div>
          <div className="bk-bqa__meter-note">
            <span>{spentShare}% spent</span>
            <span>{100 - spentShare}% left</span>
          </div>

          <ul className="bk-bqa__facts">
            <li>
              <span>This month</span>
              <strong>{money(account.month.cost.amount)}</strong>
              <span>
                {account.month.runs.toLocaleString()} message{account.month.runs === 1 ? '' : 's'}
              </span>
            </li>
            {perMessage > 0 ? (
              <li>
                <span>A message costs about</span>
                <strong>{money(perMessage)}</strong>
                <span>this month, on average</span>
              </li>
            ) : null}
            {waitingSum > 0 ? (
              <li className="is-waiting">
                <span>On its way</span>
                <strong>{money(waitingSum)}</strong>
                <span>added once the payment is confirmed</span>
              </li>
            ) : null}
          </ul>
        </div>
      </section>

      <div className="bk-bqa__columns">
        <section className="bk-panel bk-bqa__spent">
          <div className="bk-panel__head bk-bqa__list-head">
            <h2 className="bk-panel__title">Spent</h2>
            <PeriodTabs
              value={period}
              label="Spending period"
              inline
              onChange={(p) => {
                setPeriod(p);
                setPage(1);
              }}
            />
          </div>
          <div className="bk-bqa__total" aria-live="polite">
            <span>{PERIOD_SPENT[period]}</span>
            <strong>{history ? money(history.spent.amount) : '…'}</strong>
            <span>
              {history
                ? `${history.total.toLocaleString()} message${history.total === 1 ? '' : 's'}`
                : ''}
            </span>
          </div>
          {historyError ? (
            <p className="bk-history__empty bk-bqa__error">{historyError}</p>
          ) : !history ? (
            <p className="bk-history__empty">Loading…</p>
          ) : history.messages.length === 0 ? (
            <p className="bk-history__empty">
              Nothing spent {period === 'all' ? 'yet' : 'in this period'}.
            </p>
          ) : (
            <div aria-busy={historyBusy}>
              {days.map((group, i) => {
                const whole =
                  !(i === 0 && history.page > 1) &&
                  !(i === days.length - 1 && history.page < history.pages);
                const sum = group.items.reduce((s, m) => s + m.cost.amount, 0);
                return (
                  <div key={group.day}>
                    <p className="bk-history__day">
                      <span>{group.day}</span>
                      {whole ? <span>{money(sum)}</span> : null}
                    </p>
                    <table className="bk-bqa__rows">
                      <colgroup>
                        <col className="bk-bqa__col-time" />
                        <col />
                        <col className="bk-bqa__col-cost" />
                      </colgroup>
                      <thead className="screen-reader-text">
                        <tr>
                          <th scope="col">Time</th>
                          <th scope="col">Message</th>
                          <th scope="col">Cost</th>
                        </tr>
                      </thead>
                      <tbody>
                        {group.items.map((r) => (
                          <tr key={r.id}>
                            <td className="bk-bqa__time">{timeOf(r.createdAt)}</td>
                            <td className="bk-bqa__what">
                              <span className="bk-bqa__what-text" title={r.prompt ?? undefined}>
                                {r.prompt || 'Beekiri message'}
                              </span>
                              <span className="bk-bqa__what-sub">
                                {[
                                  r.user,
                                  modelName(r.model),
                                  r.calls > 1 ? `${r.calls} Claude calls` : '',
                                  r.test ? 'test run on Claude Code' : '',
                                ]
                                  .filter(Boolean)
                                  .join(' · ')}
                              </span>
                            </td>
                            <td className="bk-bqa__cost">{money(r.cost.amount, true)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                );
              })}
            </div>
          )}
          {history ? (
            <ListPager
              page={history.page}
              pages={history.pages}
              total={history.total}
              perPage={history.perPage}
              noun="messages"
              busy={historyBusy}
              onPage={setPage}
            />
          ) : null}
        </section>

        <section className="bk-panel bk-bqa__added">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Added</h2>
            <strong className="bk-bqa__head-total">{money(account.paid.amount)}</strong>
          </div>
          <div className="bk-bqa__add">
            <p className="bk-bqa__add-title">Add money</p>
            <div className="bk-bqa__add-amounts">
              {account.topups.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  className="button"
                  disabled={busy !== null}
                  onClick={() => void topup({ pack: t.id }, money(t.amount.amount), manual)}
                >
                  {busy === t.id ? 'Opening…' : money(t.amount.amount)}
                </button>
              ))}
            </div>
            <form
              className="bk-bqa__add-custom"
              onSubmit={(e) => {
                e.preventDefault();
                if (customOk) void topup({ amount: customAmount }, money(customAmount), manual);
              }}
            >
              <label className="screen-reader-text" htmlFor="bqa-custom">
                Other amount in dollars
              </label>
              <span className="bk-bqa__add-field">
                <span aria-hidden>$</span>
                <input
                  id="bqa-custom"
                  type="number"
                  inputMode="numeric"
                  min={min}
                  max={max}
                  step={1}
                  placeholder="Other amount"
                  value={custom}
                  onChange={(e) => setCustom(e.target.value)}
                />
              </span>
              <button
                type="submit"
                className="button button-primary"
                disabled={busy !== null || !customOk}
              >
                {busy === 'custom' ? 'Opening…' : 'Add'}
              </button>
            </form>
            <p className="bk-bqa__fine">
              {`Whole dollars, ${money(min)} to ${money(max)}. `}
              {manual
                ? '996Agency confirms each payment by hand for now; the money is added as soon as it is paid.'
                : 'Paid by card through 996Agency; the money is added as soon as the payment goes through.'}
            </p>
          </div>
          {added.length === 0 ? (
            <p className="bk-history__empty">No money added yet.</p>
          ) : (
            <table className="bk-bqa__rows bk-bqa__topups">
              <colgroup>
                <col />
                <col className="bk-bqa__col-state" />
                <col className="bk-bqa__col-cost" />
              </colgroup>
              <thead className="screen-reader-text">
                <tr>
                  <th scope="col">Date</th>
                  <th scope="col">Status</th>
                  <th scope="col">Amount</th>
                </tr>
              </thead>
              <tbody>
                {added.map((o) => (
                  <tr key={o.id} className={`is-${o.status}`}>
                    <td className="bk-bqa__what">
                      <span className="bk-bqa__what-text">
                        {o.createdAt ? dateOf(o.createdAt) : 'Top-up'}
                      </span>
                    </td>
                    <td className="bk-bqa__state">
                      <span className={`bk-bqa__status is-${o.status}`}>
                        {TOPUP_STATUS[o.status] ?? o.status}
                      </span>
                    </td>
                    <td className="bk-bqa__cost">
                      {o.status === 'approved' ? '+' : ''}
                      {money(o.amount.amount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          <p className="bk-bqa__fine bk-bqa__fine--foot">
            Prepaid, with no subscription: each message takes only the Claude work it does — a small
            edit costs cents, a full page more.
          </p>
        </section>
      </div>
    </div>
  );
}
