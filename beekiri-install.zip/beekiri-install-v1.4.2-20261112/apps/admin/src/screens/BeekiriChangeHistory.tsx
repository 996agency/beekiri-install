import { useCallback, useEffect, useState } from 'react';
import {
  ArrowClockwise,
  ArrowCounterClockwise,
  CaretRight,
  Check,
  Stack,
  Eye,
  FileCode,
  Image,
  Layout,
  NotePencil,
  ShoppingBag,
  Tag,
} from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { confirmDialog } from '../components/ConfirmDialog';
import { ErrorNotice } from '../components/ErrorNotice';
import {
  byDay,
  ListPager,
  PeriodTabs,
  timeOf,
  type HistoryPeriod,
} from '../components/HistoryControls';
import { SuccessNotice } from '../components/SuccessNotice';
import './beekiri-change-history.css';

type Change = {
  id: string;
  kind: 'theme_file' | 'layout' | 'page' | 'taxonomy' | 'post_type' | 'product' | 'media';
  label: string;
  created: boolean;
  createdAt: string;
  revertedAt: string | null;
};
/** pending: it added sections to live pages that visitors don't see until you press Keep. */
type Run = {
  runId: string;
  chatTitle: string;
  user: string;
  createdAt: string;
  changes: Change[];
  pending?: boolean;
};
type Page = { runs: Run[]; page: number; pages: number; perPage: number; total: number };

const ICON = {
  post_type: Stack,
  theme_file: FileCode,
  layout: Layout,
  page: NotePencil,
  taxonomy: Tag,
  product: ShoppingBag,
  media: Image,
} as const;

const NOUN: Record<Change['kind'], string> = {
  theme_file: 'theme file',
  layout: 'layout',
  page: 'page',
  taxonomy: 'taxonomy',
  post_type: 'content type',
  product: 'product',
  media: 'photo',
};

/** What a change is, in a word: the start of its label ("Page “Home”" → page), else its kind. */
function nounOf(c: Change): string {
  const named = /^([A-Z][a-z]+(?: [a-z]+)?) “/.exec(c.label);
  return named ? named[1].toLowerCase() : NOUN[c.kind] ?? 'item';
}

function plural(noun: string, n: number): string {
  if (n === 1) return `1 ${noun}`;
  return `${n} ${noun.endsWith('y') ? `${noun.slice(0, -1)}ies` : `${noun}s`}`;
}

function listOf(parts: string[]): string {
  if (parts.length < 2) return parts.join('');
  return `${parts.slice(0, -1).join(', ')} and ${parts[parts.length - 1]}`;
}

/** "Created 5 layouts and 1 page · changed 2 pages": a message's changes in one line. */
function summary(changes: Change[]): string {
  const count = (items: Change[]) => {
    const byNoun = new Map<string, number>();
    for (const c of items) byNoun.set(nounOf(c), (byNoun.get(nounOf(c)) ?? 0) + 1);
    return listOf([...byNoun].sort((a, b) => b[1] - a[1]).map(([noun, n]) => plural(noun, n)));
  };
  const created = changes.filter((c) => c.created);
  const changed = changes.filter((c) => !c.created);
  const parts = [
    created.length ? `Created ${count(created)}` : '',
    changed.length ? `${created.length ? 'changed' : 'Changed'} ${count(changed)}` : '',
  ].filter(Boolean);
  return parts.join(' · ');
}

/**
 * What Beekiri changed outside the page editor (theme files, layouts, pages, posts, products,
 * photos, taxonomies): one line per message, opened to see each change, with Revert. Messages
 * whose additions still wait for Keep are listed first. Section edits in the editor have their own
 * Undo there.
 */
export function BeekiriChangeHistory({ onWaiting }: { onWaiting?: (count: number) => void }) {
  const [data, setData] = useState<Page | null>(null);
  const [period, setPeriod] = useState<HistoryPeriod>('all');
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const runs = data?.runs ?? null;
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [open, setOpen] = useState<Record<string, boolean>>({});

  const load = useCallback(async () => {
    setError(null);
    setLoading(true);
    try {
      const res = await api<Page>(`/api/connector/changes?period=${period}&page=${page}`);
      setData(res);
      if (period === 'all' && page === 1) onWaiting?.(res.runs.filter((r) => r.pending).length);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load the change history.');
    } finally {
      setLoading(false);
    }
  }, [period, page, onWaiting]);

  useEffect(() => {
    void load();
  }, [load]);

  /** Private preview links per message, made on request (visitors don't see what waits for Keep). */
  const [previews, setPreviews] = useState<Record<string, { title: string; url: string }[]>>({});
  const preview = async (run: Run) => {
    setBusy(`preview:${run.runId}`);
    setError(null);
    try {
      const res = await api<{ pages: { title: string; url: string }[] }>(
        '/api/connector/changes/preview',
        {
          method: 'POST',
          json: { runId: run.runId },
        },
      );
      setPreviews((p) => ({ ...p, [run.runId]: res.pages }));
      if (!res.pages.length) setNotice('Nothing from that message is waiting any more.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not make a preview.');
    } finally {
      setBusy(null);
    }
  };

  const keep = async (run: Run) => {
    setBusy(`keep:${run.runId}`);
    setError(null);
    setNotice(null);
    try {
      await api('/api/connector/changes/keep', { method: 'POST', json: { runId: run.runId } });
      setNotice('Kept — it is live for your visitors now.');
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not keep that.');
    } finally {
      setBusy(null);
    }
  };

  const revert = async (
    target: { changeId?: string; runId?: string },
    what: { title: string; message: string },
    force = false,
  ): Promise<void> => {
    if (
      !force &&
      !(await confirmDialog({
        title: what.title,
        message: `${what.message} Pages and layouts Beekiri created go to the trash.`,
        confirmLabel: 'Revert',
        danger: true,
      }))
    )
      return;
    setBusy(target.changeId ?? target.runId ?? null);
    setError(null);
    setNotice(null);
    try {
      const res = await api<{ reverted: number }>('/api/connector/changes/revert', {
        method: 'POST',
        json: { ...target, ...(force ? { force: true } : {}) },
      });
      setNotice(`Reverted ${res.reverted} change${res.reverted === 1 ? '' : 's'}.`);
      await load();
    } catch (e) {
      if (e instanceof ApiError && e.status === 409 && !force) {
        setBusy(null);
        const anyway = await confirmDialog({
          title: 'It was edited since',
          message: `${e.message} Revert anyway?`,
          confirmLabel: 'Revert anyway',
          danger: true,
        });
        if (anyway) return revert(target, what, true);
        return;
      }
      setError(e instanceof Error ? e.message : 'Could not revert.');
    } finally {
      setBusy(null);
    }
  };

  const row = (run: Run) => {
    const live = run.changes.filter((c) => !c.revertedAt);
    const undone = run.changes.length - live.length;
    const shown = Boolean(open[run.runId]);
    const links = run.pending ? previews[run.runId] : undefined;
    return (
      <li
        key={run.runId}
        className={`bk-bch__run${shown ? ' is-open' : ''}${live.length ? '' : ' is-reverted'}${run.pending ? ' is-pending' : ''}`}
      >
        <div className="bk-bch__line">
          <button
            type="button"
            className="bk-bch__toggle"
            aria-expanded={shown}
            aria-controls={`bch-${run.runId}`}
            onClick={() => setOpen((o) => ({ ...o, [run.runId]: !shown }))}
          >
            <CaretRight size={12} weight="bold" aria-hidden className="bk-bch__caret" />
            <span className="bk-bch__time">{timeOf(run.createdAt)}</span>
            <span className="bk-bch__text">
              <span className="bk-bch__title" title={run.chatTitle}>
                {run.chatTitle}
              </span>
              <span className="bk-bch__meta">
                {[run.user, summary(run.changes), undone && live.length ? `${undone} reverted` : '']
                  .filter(Boolean)
                  .join(' · ')}
              </span>
            </span>
          </button>
          <span className="bk-bch__actions">
            {!live.length ? (
              <span className="bk-bch__tag">Reverted</span>
            ) : (
              <>
                {run.pending ? (
                  <>
                    <span className="bk-bch__tag is-pending">Not public yet</span>
                    <button
                      type="button"
                      className="button"
                      disabled={busy !== null}
                      onClick={() => void preview(run)}
                    >
                      <Eye size={14} aria-hidden />
                      {busy === `preview:${run.runId}` ? 'Opening…' : 'Preview'}
                    </button>
                    <button
                      type="button"
                      className="button button-primary"
                      disabled={busy !== null}
                      onClick={() => void keep(run)}
                    >
                      <Check size={14} aria-hidden />
                      {busy === `keep:${run.runId}` ? 'Keeping…' : 'Keep'}
                    </button>
                  </>
                ) : null}
                <button
                  type="button"
                  className="button"
                  disabled={busy !== null}
                  onClick={() =>
                    void revert(
                      { runId: run.runId },
                      {
                        title: `Revert ${live.length === 1 ? 'this change' : `these ${live.length} changes`}?`,
                        message: `Everything Beekiri did for “${run.chatTitle}” is undone.`,
                      },
                    )
                  }
                >
                  <ArrowCounterClockwise size={14} aria-hidden />
                  {busy === run.runId ? 'Reverting…' : 'Revert'}
                </button>
              </>
            )}
          </span>
        </div>
        {links?.length ? (
          <p className="bk-bch__previews">
            Preview (only you can see it, for 24 hours):{' '}
            {links.map((p, i) => (
              <span key={p.url}>
                {i ? ' · ' : ''}
                <a href={p.url} target="_blank" rel="noreferrer">
                  {p.title} ↗
                </a>
              </span>
            ))}
          </p>
        ) : null}
        {shown ? (
          <ul className="bk-bch__changes" id={`bch-${run.runId}`}>
            {run.changes.map((c) => {
              const Icon = ICON[c.kind] ?? FileCode;
              return (
                <li key={c.id} className={c.revertedAt ? 'is-reverted' : ''}>
                  <Icon size={15} aria-hidden />
                  <span className="bk-bch__label">{c.label}</span>
                  <span className="bk-bch__how">{c.created ? 'Created' : 'Changed'}</span>
                  {c.revertedAt ? (
                    <span className="bk-bch__tag">Reverted</span>
                  ) : (
                    <button
                      type="button"
                      className="button-link"
                      disabled={busy !== null}
                      onClick={() =>
                        void revert(
                          { changeId: c.id },
                          { title: 'Revert this change?', message: `${c.label} goes back to how it was.` },
                        )
                      }
                    >
                      {busy === c.id ? 'Reverting…' : 'Revert'}
                    </button>
                  )}
                </li>
              );
            })}
          </ul>
        ) : null}
      </li>
    );
  };

  const waiting = runs?.filter((r) => r.pending && r.changes.some((c) => !c.revertedAt)) ?? [];
  const rest = runs?.filter((r) => !waiting.includes(r)) ?? [];

  return (
    <section className="bk-panel bk-bch">
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      <div className="bk-panel__head bk-bch__head">
        <h2 className="bk-panel__title">Change history</h2>
        <span className="bk-bch__tools">
          <PeriodTabs
            value={period}
            label="Change history period"
            inline
            onChange={(p) => {
              setPeriod(p);
              setPage(1);
            }}
          />
          <button
            type="button"
            className="button bk-bch__refresh"
            disabled={loading}
            aria-label="Refresh"
            title="Refresh"
            onClick={() => void load()}
          >
            <ArrowClockwise size={14} aria-hidden className={loading ? 'is-spinning' : undefined} />
          </button>
        </span>
      </div>
      <p className="bk-bch__intro">
        <span>
          Each line is one message to Beekiri and what it changed in your theme, layouts, pages,
          posts, products and photos. Open a line to see every change; Revert undoes one change or
          the whole message. Section edits in the page editor are undone there, with Undo.
        </span>
      </p>
      {!runs ? (
        <p className="bk-history__empty">Loading…</p>
      ) : runs.length === 0 ? (
        <p className="bk-history__empty">
          No changes {period === 'all' ? 'yet' : 'in this period'}.
        </p>
      ) : (
        <div aria-busy={loading}>
          {waiting.length ? (
            <div className="bk-bch__waiting">
              <p className="bk-history__day">
                <span>Waiting for you</span>
                <span>visitors don’t see these until you press Keep</span>
              </p>
              <ol className="bk-bch__runs">{waiting.map(row)}</ol>
            </div>
          ) : null}
          {byDay(rest, (r) => r.createdAt).map((group) => (
            <div key={group.day}>
              <p className="bk-history__day">
                <span>{group.day}</span>
                <span>
                  {group.items.length} message{group.items.length === 1 ? '' : 's'}
                </span>
              </p>
              <ol className="bk-bch__runs">{group.items.map(row)}</ol>
            </div>
          ))}
        </div>
      )}
      {data ? (
        <ListPager
          page={data.page}
          pages={data.pages}
          total={data.total}
          perPage={data.perPage}
          noun="messages"
          busy={loading}
          onPage={setPage}
        />
      ) : null}
    </section>
  );
}
