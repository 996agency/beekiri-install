/**
 * Screenshots for the Beekiri chat: the owner drags over part of the screen and the chat attaches
 * a picture of it. Rendered from the page itself (html-to-image), so no screen-sharing permission
 * is needed; the chat and the drag overlay are left out of the picture.
 */

export type ShotRect = { left: number; top: number; width: number; height: number };
export type Shot = { image: string; width: number; height: number };

/** Longest side of the attached picture, and its largest data URL (the API takes up to 1.9 MB). */
const MAX_SIDE = 1600;
const MAX_DATA_URL = 1_200_000;
/** Pixels rendered before cropping — a tall page at 2× would otherwise be a huge canvas. */
const MAX_RENDER_PIXELS = 16_000_000;
/** Images that can't be fetched (other sites without CORS) render as nothing, not as an error. */
const BLANK_PIXEL = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';

const contains = (outer: DOMRect, r: ShotRect, slack = 4) =>
  outer.left - slack <= r.left &&
  outer.top - slack <= r.top &&
  outer.right + slack >= r.left + r.width &&
  outer.bottom + slack >= r.top + r.height;

/** Everything under the middle of the area, top first (the chat and the overlay must be hidden by now). */
function centreElements(rect: ShotRect): Element[] {
  return document.elementsFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2);
}

const CANVAS = '.bk-beekiricode__frame-canvas';
const CANVAS_NODE = `${CANVAS} [data-node-id]`;

/**
 * An area that starts on the page editor's canvas is trimmed to the canvas: the dark workspace
 * around it isn't part of the design, and the canvas is zoomed with a transform that a picture
 * taken from outside it would not reproduce.
 */
export function clipToCanvas(rect: ShotRect): ShotRect {
  const canvas = centreElements(rect)
    .map((hit) => hit.closest(CANVAS))
    .find(Boolean);
  if (!canvas) return rect;
  const box = canvas.getBoundingClientRect();
  const left = Math.max(rect.left, box.left);
  const top = Math.max(rect.top, box.top);
  const right = Math.min(rect.left + rect.width, box.right);
  const bottom = Math.min(rect.top + rect.height, box.bottom);
  return right - left >= 4 && bottom - top >= 4 ? { left, top, width: right - left, height: bottom - top } : rect;
}

/** The page editor element the area shows: the smallest one on the canvas that holds all of it. */
export function canvasNodeUnder(rect: ShotRect): string | null {
  // The editor's hover and selection chrome sit above the canvas, so look through them.
  let el: HTMLElement | null = null;
  for (const hit of centreElements(rect)) {
    el = hit.closest<HTMLElement>(CANVAS_NODE);
    if (el) break;
  }
  let last: HTMLElement | null = null;
  while (el) {
    last = el;
    if (contains(el.getBoundingClientRect(), rect)) return el.dataset.nodeId ?? null;
    el = el.parentElement?.closest<HTMLElement>(CANVAS_NODE) ?? null;
  }
  return last?.dataset.nodeId ?? null;
}

/** The smallest element that holds the whole area and isn't scrolled (a clone renders at scroll 0). */
function containerFor(rect: ShotRect): HTMLElement {
  let el = (centreElements(rect)[0] as HTMLElement | undefined) ?? null;
  while (el && el !== document.body) {
    if (contains(el.getBoundingClientRect(), rect, 0) && !el.scrollTop && !el.scrollLeft) return el;
    el = el.parentElement;
  }
  return document.body;
}

/** The colour behind an element: its own, or the first ancestor's that isn't transparent. */
function backdropOf(el: HTMLElement): string {
  for (let node: HTMLElement | null = el; node; node = node.parentElement) {
    const bg = getComputedStyle(node).backgroundColor;
    if (bg && bg !== 'transparent' && !/^rgba\(.*,\s*0\)$/.test(bg)) return bg;
  }
  return '#ffffff';
}

/** A picture of one area of the screen, as a JPEG data URL small enough to send. */
export async function captureRegion(rect: ShotRect): Promise<Shot> {
  const el = containerFor(rect);
  const box = el.getBoundingClientRect();
  // The editor canvas is zoomed with a transform: the element renders at its own (layout) size,
  // so screen pixels map onto the render by layout ÷ on-screen size.
  const zoom = el.offsetWidth && box.width ? box.width / el.offsetWidth : 1;
  let scale = Math.min(window.devicePixelRatio || 1, 2, MAX_SIDE / rect.width, MAX_SIDE / rect.height);
  scale = Math.min(scale, Math.sqrt(MAX_RENDER_PIXELS / Math.max(1, box.width * box.height)));

  // Photos still loading would come out blank.
  await Promise.all(
    Array.from(el.querySelectorAll('img')).map((img) => (img.complete ? null : img.decode().catch(() => null))),
  );
  const { toCanvas } = await import('html-to-image');
  const page = await toCanvas(el, {
    pixelRatio: scale * zoom,
    backgroundColor: backdropOf(el),
    imagePlaceholder: BLANK_PIXEL,
    filter: (node) => !(node instanceof Element && (node.classList.contains('bk-bee-chat') || node.classList.contains('bk-shot'))),
  });

  const width = Math.max(1, Math.round(rect.width * scale));
  const height = Math.max(1, Math.round(rect.height * scale));
  const out = document.createElement('canvas');
  out.width = width;
  out.height = height;
  const ctx = out.getContext('2d');
  if (!ctx) throw new Error('This browser could not make the picture.');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);
  const kx = page.width / box.width;
  const ky = page.height / box.height;
  ctx.drawImage(page, (rect.left - box.left) * kx, (rect.top - box.top) * ky, rect.width * kx, rect.height * ky, 0, 0, width, height);

  // Lower the quality first, then the size, until it fits.
  let canvas = out;
  for (let quality = 0.86; ; quality -= 0.12) {
    const image = canvas.toDataURL('image/jpeg', Math.max(0.5, quality));
    if (image.length <= MAX_DATA_URL) return { image, width: canvas.width, height: canvas.height };
    if (quality <= 0.5) {
      const half = document.createElement('canvas');
      half.width = Math.max(1, Math.round(canvas.width / 2));
      half.height = Math.max(1, Math.round(canvas.height / 2));
      half.getContext('2d')?.drawImage(canvas, 0, 0, half.width, half.height);
      canvas = half;
      quality = 0.98;
    }
  }
}
