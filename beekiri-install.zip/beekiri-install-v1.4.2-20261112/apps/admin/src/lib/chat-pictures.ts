/**
 * Pictures for the Beekiri chat: a screenshot of the screen (screen-capture.ts), or a design
 * reference the owner uploads, pastes or drops in. Every reference is redrawn as a JPEG small
 * enough to send; a tall one (a whole landing page) is cut into parts so its details stay readable.
 */
import type { Shot } from './screen-capture';

export type ChatPicture = {
  id: string;
  kind: 'screenshot' | 'reference';
  /** What is sent: one JPEG data URL, or a tall picture's parts from top to bottom. */
  parts: string[];
  /** A small copy for the chat (the top of a tall picture). */
  thumb: string;
  /** The picture's own size. */
  width: number;
  height: number;
};

export const PICTURE_TYPES = 'image/png,image/jpeg,image/webp,image/gif,image/avif';

/** One message carries at most this many parts, and this much data (the API takes 6 MB). */
const MAX_PARTS = 6;
const MAX_TOTAL = 5_000_000;
/** A page reads well at this width; Retina screenshots are twice the size they show at. */
const PART_WIDTH = 1280;
const PART_HEIGHT = 1280;
/** Up to this height a picture stays whole. */
const WHOLE_HEIGHT = 1600;
const MAX_PARTS_EACH = 4;
/** Neighbouring parts share a strip, so a section cut by the edge is whole in one of them. */
const OVERLAP = 48;
const MAX_PART_DATA_URL = 800_000;
const MAX_FILE_BYTES = 40 * 1024 * 1024;

const uid = () => `pic-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

/** Whether these pictures can go in one message. */
export function picturesFit(list: ChatPicture[]): boolean {
  const parts = list.flatMap((p) => p.parts);
  return parts.length <= MAX_PARTS && parts.reduce((sum, part) => sum + part.length, 0) <= MAX_TOTAL;
}

export function pictureFromShot(shot: Shot): ChatPicture {
  return { id: uid(), kind: 'screenshot', parts: [shot.image], thumb: shot.image, width: shot.width, height: shot.height };
}

async function openImage(file: File): Promise<HTMLImageElement> {
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.src = url;
    await img.decode();
    if (!img.naturalWidth || !img.naturalHeight) throw new Error('empty');
    return img;
  } catch {
    throw new Error(`${file.name || 'That picture'} could not be opened. Use a PNG, JPEG, WebP, GIF or AVIF picture.`);
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** One area of the picture, redrawn at the given size on white (a transparent PNG has no backdrop). */
function draw(img: HTMLImageElement, sy: number, sh: number, width: number, height: number): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(width));
  canvas.height = Math.max(1, Math.round(height));
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('This browser could not read the picture.');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, 0, sy, img.naturalWidth, sh, 0, 0, canvas.width, canvas.height);
  return canvas;
}

/** A JPEG data URL that fits: lower the quality first, then the size. */
function toJpeg(source: HTMLCanvasElement, maxLength: number): string {
  let canvas = source;
  for (let quality = 0.86; ; quality -= 0.12) {
    const image = canvas.toDataURL('image/jpeg', Math.max(0.5, quality));
    if (image.length <= maxLength || (canvas.width <= 64 && quality <= 0.5)) return image;
    if (quality <= 0.5) {
      const smaller = document.createElement('canvas');
      smaller.width = Math.max(1, Math.round(canvas.width * 0.75));
      smaller.height = Math.max(1, Math.round(canvas.height * 0.75));
      smaller.getContext('2d')?.drawImage(canvas, 0, 0, smaller.width, smaller.height);
      canvas = smaller;
      quality = 0.98;
    }
  }
}

/** A picture file (uploaded, pasted or dropped) as a design reference for Beekiri. */
export async function pictureFromFile(file: File): Promise<ChatPicture> {
  if (!PICTURE_TYPES.split(',').includes(file.type)) {
    throw new Error('Beekiri can read PNG, JPEG, WebP, GIF and AVIF pictures.');
  }
  if (file.size > MAX_FILE_BYTES) throw new Error('That picture is too large. Use one under 40 MB.');
  const img = await openImage(file);
  const { naturalWidth: w, naturalHeight: h } = img;

  let scale = Math.min(1, PART_WIDTH / w);
  let count = 1;
  if (h * scale > WHOLE_HEIGHT) {
    count = Math.min(MAX_PARTS_EACH, Math.ceil((h * scale) / PART_HEIGHT));
    // Taller than the parts hold: the whole picture gets smaller, nothing is cut off.
    scale = Math.min(scale, (count * PART_HEIGHT) / h);
  }
  const step = h / count;
  const overlap = count > 1 ? Math.min(OVERLAP / scale, step / 4) : 0;
  const parts: string[] = [];
  for (let i = 0; i < count; i += 1) {
    const top = Math.max(0, i * step - overlap);
    const bottom = Math.min(h, (i + 1) * step);
    parts.push(toJpeg(draw(img, top, bottom - top, w * scale, (bottom - top) * scale), MAX_PART_DATA_URL));
  }

  const thumbScale = Math.min(1, 480 / w);
  const thumbHeight = Math.min(h, (360 / thumbScale) | 0);
  const thumb = count === 1 && parts[0].length < 200_000 ? parts[0] : toJpeg(draw(img, 0, thumbHeight, w * thumbScale, thumbHeight * thumbScale), 120_000);
  return { id: uid(), kind: 'reference', parts, thumb, width: w, height: h };
}
