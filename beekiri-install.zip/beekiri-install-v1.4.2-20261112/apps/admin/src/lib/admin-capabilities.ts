import type { CapabilitySlug } from '../cms-types';

/** Settings tab caps (Beekiri Core is always shown when Settings is open). */
export const SETTINGS_TAB_CAPS = [
  'manage_settings_general',
  'manage_settings_reading',
  'manage_settings_writing',
  'manage_settings_page_editor',
  'manage_settings_advanced',
  'manage_settings_permalinks',
  'manage_settings_media',
  'manage_settings_cache',
  'manage_settings_instructions',
] as const satisfies readonly CapabilitySlug[];

export const SETTINGS_ACCESS_CAPS: CapabilitySlug[] = [
  'update_core',
  ...SETTINGS_TAB_CAPS,
];

export const SETTINGS_TAB_CAP_BY_ID: Record<string, CapabilitySlug> = {
  general: 'manage_settings_general',
  reading: 'manage_settings_reading',
  writing: 'manage_settings_writing',
  'page-editor': 'manage_settings_page_editor',
  advanced: 'manage_settings_advanced',
  translation: 'manage_settings_advanced',
  permalinks: 'manage_settings_permalinks',
  media: 'manage_settings_media',
  cache: 'manage_settings_cache',
  instructions: 'manage_settings_instructions',
};

/** Caps required for admin areas — keep sidebar, routes, and spotlight in sync. */
export const ADMIN_AREA_CAPS = {
  analytics: 'manage_options',
  seo: 'manage_options',
  connector: 'manage_options',
  extensions: 'manage_options',
  appearance: 'edit_theme_options',
  fields: 'manage_fields',
  users: 'list_users',
  posts: 'edit_posts',
  pages: 'edit_pages',
  media: 'upload_files',
  // Shopping extension (shown only while it is active)
  shopProducts: 'edit_products',
  shopOrders: 'edit_shop_orders',
  shopSettings: 'manage_shop',
  shopReports: 'view_shop_reports',
  // Bee Forms extension (shown only while it is active)
  forms: 'manage_forms',
  formEntries: 'view_form_entries',
} as const satisfies Record<string, CapabilitySlug>;

/** Either forms capability opens the Forms menu. */
export const FORMS_CAPS: CapabilitySlug[] = ['manage_forms', 'view_form_entries'];

export function canAccessForms(caps: readonly string[] | undefined): boolean {
  return hasAnyCap(caps, FORMS_CAPS);
}

/** Any shop capability opens the Shop menu and its overview. */
export const SHOP_CAPS: CapabilitySlug[] = ['edit_products', 'edit_shop_orders', 'manage_shop', 'view_shop_reports'];

export function canAccessShop(caps: readonly string[] | undefined): boolean {
  return hasAnyCap(caps, SHOP_CAPS);
}

export type AdminArea = keyof typeof ADMIN_AREA_CAPS | 'settings';

export function hasCap(caps: readonly string[] | undefined, cap: CapabilitySlug): boolean {
  return (caps ?? []).includes(cap);
}

export function hasAnyCap(
  caps: readonly string[] | undefined,
  needed: readonly CapabilitySlug[],
): boolean {
  const list = caps ?? [];
  return needed.some((c) => list.includes(c));
}

/** Legacy `manage_options` still unlocks all Settings tabs + Core updates. */
export function canAccessSettings(caps: readonly string[] | undefined): boolean {
  const list = caps ?? [];
  if (list.includes('manage_options')) return true;
  return hasAnyCap(list, SETTINGS_ACCESS_CAPS);
}

export function canUpdateCore(caps: readonly string[] | undefined): boolean {
  const list = caps ?? [];
  return list.includes('update_core') || list.includes('manage_options');
}

export function canAccessSettingsTab(
  caps: readonly string[] | undefined,
  tabId: string,
): boolean {
  if (tabId === 'core') return canAccessSettings(caps);
  // Advanced also holds the Reading and Writing sections.
  if (tabId === 'advanced') {
    return ['reading', 'writing', 'advanced'].some((id) => canAccessSettingsSection(caps, id));
  }
  return canAccessSettingsSection(caps, tabId);
}

/** One section's own cap, e.g. Advanced → Reading. */
export function canAccessSettingsSection(
  caps: readonly string[] | undefined,
  sectionId: string,
): boolean {
  const list = caps ?? [];
  if (list.includes('manage_options')) return true;
  const needed = SETTINGS_TAB_CAP_BY_ID[sectionId];
  return needed ? list.includes(needed) : false;
}

export function canAccessArea(
  caps: readonly string[] | undefined,
  area: AdminArea,
): boolean {
  if (area === 'settings') return canAccessSettings(caps);
  return hasCap(caps, ADMIN_AREA_CAPS[area]);
}

/** Spotlight / search item ids gated by capability. */
export const SPOTLIGHT_CAP_BY_ID: Record<string, CapabilitySlug> = {
  analytics: 'manage_options',
  'analytics-bee-cookies': 'manage_options',
  'analytics-heatmap': 'manage_options',
  seo: 'manage_options',
  connector: 'manage_options',
  extensions: 'manage_options',
  appearance: 'edit_theme_options',
  header: 'edit_theme_options',
  footer: 'edit_theme_options',
  templates: 'edit_theme_options',
  fields: 'manage_fields',
  'post-types': 'manage_fields',
  taxonomies: 'manage_fields',
  'options-pages': 'manage_fields',
  'fields-settings': 'manage_fields',
  'fields-tools': 'manage_fields',
  users: 'list_users',
  posts: 'edit_posts',
  pages: 'edit_pages',
  media: 'upload_files',
  'shop-products': 'edit_products',
  'shop-products-new': 'edit_products',
  'shop-categories': 'edit_products',
  'shop-tags': 'edit_products',
  'shop-pages': 'edit_products',
  'shop-orders': 'edit_shop_orders',
  'shop-customers': 'edit_shop_orders',
  'shop-coupons': 'edit_shop_orders',
  'shop-settings': 'manage_shop',
  forms: 'manage_forms',
  'forms-new': 'manage_forms',
  'forms-entries': 'view_form_entries',
  'forms-integrations': 'manage_forms',
  bookings: 'manage_bookings',
  'bookings-appointments': 'manage_bookings',
  'bookings-services': 'manage_bookings',
  'bookings-staff': 'manage_bookings',
  'bookings-settings': 'manage_bookings',
};

/** Spotlight settings entries — use canAccessSettings / tab helpers instead of a single cap. */
export const SPOTLIGHT_SETTINGS_IDS = new Set([
  'settings',
  'settings-core',
  'settings-general',
  'settings-page-editor',
  'settings-advanced',
  'settings-translation',
  'settings-permalinks',
  'settings-media',
  'settings-cache',
  'settings-migration',
  'settings-instructions',
]);

export function canAccessSpotlightItem(
  caps: readonly string[] | undefined,
  itemId: string,
): boolean {
  if (itemId === 'settings' || itemId === 'settings-core') return canAccessSettings(caps);
  if (itemId.startsWith('settings-')) {
    const tab = itemId.slice('settings-'.length);
    return canAccessSettingsTab(caps, tab);
  }
  const needed = SPOTLIGHT_CAP_BY_ID[itemId];
  return needed ? hasCap(caps, needed) : true;
}
