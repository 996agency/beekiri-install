import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import type { Icon } from '@phosphor-icons/react';
import {
  ArrowSquareOut,
  ChartLine,
  FileText,
  GearSix,
  Images,
  List,
  MagnifyingGlass,
  NotePencil,
  PaintBrush,
  Plugs,
  PuzzlePiece,
  SquaresFour,
  Stack,
  CalendarCheck,
  ClipboardText,
  Storefront,
  Users,
  X,
} from '@phosphor-icons/react';
import '../styles/wp/admin.css';
import './admin-shell.css';
import { api } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { useCoreUpdate } from '../core/CoreUpdateContext';
import { BrandMark } from '../components/BrandMark';
import { resolveAdminIcon } from '../components/IconPicker';
import { BOOKINGS_EXTENSION, FORMS_EXTENSION, SHOPPING_EXTENSION, useActiveExtensions } from '../lib/extensions-state';
import { canAccessForms, canAccessShop, hasCap } from '../lib/admin-capabilities';
import { AdminSpotlightSearch } from '../components/AdminSpotlightSearch';
import { LighthouseToolbar } from '../components/LighthouseToolbar';
import { IdleSessionToolbar } from '../components/IdleSessionToolbar';
import { NotificationsBell } from '../components/NotificationsBell';
import { SiteFavicon } from '../components/SiteFavicon';
import { BeeAgentWidget } from '../components/BeeAgentWidget';
import { CONNECTOR_COMING_SOON } from '../lib/features';
import { CreditsToolbar } from '../components/CreditsToolbar';
import { SiteSwitcher } from '../components/SiteSwitcher';
import { ConfirmDialogHost } from '../components/ConfirmDialog';
import { POST_TYPES_CHANGED } from '../lib/admin-events';
import { canAccessArea, type AdminArea } from '../lib/admin-capabilities';
import { useAdminEntry } from '../lib/AdminEntryContext';
import { adminHref } from '../lib/admin-login';
import { AdminPageTransition } from './AdminPageTransition';

import { SITE_URL as LIVE_SITE } from '../config';
/** Fallback if updates API has not loaded yet — keep in sync with root package.json. */
const FALLBACK_VERSION = '1.0.0';

type MenuChild = {
  label: string;
  to: string;
  /** Optional brand mark (e.g. connector provider logo). */
  logoSrc?: string;
  logoClass?: string;
};

type MenuItem = {
  label: string;
  to: string;
  icon: Icon;
  disabled?: boolean;
  children?: MenuChild[];
};

type MenuGroup = {
  /** Section label shown above the group. Omit for unlabeled top items. */
  label?: string;
  items: MenuItem[];
};

function fieldsChildren(base: string): MenuChild[] {
  return [
    { label: 'Field Groups', to: adminHref(base, 'fields') },
    { label: 'Post Types', to: adminHref(base, 'fields/post-types') },
    { label: 'Taxonomies', to: adminHref(base, 'fields/taxonomies') },
    { label: 'Options Pages', to: adminHref(base, 'fields/options-pages') },
    { label: 'Settings', to: adminHref(base, 'fields/settings') },
    { label: 'Tools', to: adminHref(base, 'fields/tools') },
  ];
}

function appearanceChildren(base: string): MenuChild[] {
  return [
    { label: 'Themes', to: adminHref(base, 'appearance') },
    { label: 'Header', to: adminHref(base, 'appearance/header') },
    { label: 'Footer', to: adminHref(base, 'appearance/footer') },
    { label: 'Templates', to: adminHref(base, 'appearance/templates') },
  ];
}

function analyticsChildren(base: string): MenuChild[] {
  return [
    { label: 'Overview', to: adminHref(base, 'analytics') },
    { label: 'Heatmap', to: adminHref(base, 'analytics/heatmap') },
    { label: 'BeeCookies', to: adminHref(base, 'analytics/cookies') },
  ];
}

type NavCpt = {
  slug: string;
  plural: string;
  menuIcon: string;
  showInMenu: boolean;
  active: boolean;
};

function shopChildren(base: string, caps: string[]): MenuChild[] {
  return [
    { label: 'Overview', to: adminHref(base, 'shop') },
    ...(hasCap(caps, 'edit_products')
      ? [
          { label: 'Products', to: adminHref(base, 'shop/products') },
          { label: 'Categories', to: adminHref(base, 'shop/categories') },
          { label: 'Tags', to: adminHref(base, 'shop/tags') },
        ]
      : []),
    ...(hasCap(caps, 'edit_shop_orders')
      ? [
          { label: 'Orders', to: adminHref(base, 'shop/orders') },
          { label: 'Customers', to: adminHref(base, 'shop/customers') },
          { label: 'Coupons', to: adminHref(base, 'shop/coupons') },
        ]
      : []),
    ...(hasCap(caps, 'edit_products') ? [{ label: 'Shop Editor', to: adminHref(base, 'shop/pages') }] : []),
    ...(hasCap(caps, 'manage_shop') ? [{ label: 'Settings', to: adminHref(base, 'shop/settings') }] : []),
  ];
}

function formsChildren(base: string, caps: string[]): MenuChild[] {
  return [
    ...(hasCap(caps, 'manage_forms') ? [{ label: 'All Forms', to: adminHref(base, 'forms') }] : []),
    ...(hasCap(caps, 'view_form_entries') ? [{ label: 'Entries', to: adminHref(base, 'forms/entries') }] : []),
    ...(hasCap(caps, 'manage_forms') ? [{ label: 'Integrations', to: adminHref(base, 'forms/integrations') }] : []),
  ];
}

function buildMenuGroups(
  base: string,
  cpts: NavCpt[],
  caps: string[],
  isOwner: boolean,
  shopActive: boolean,
  formsActive: boolean,
  bookingsActive: boolean,
): MenuGroup[] {
  const can = (area: AdminArea) => canAccessArea(caps, area);
  const formsItems: MenuItem[] =
    formsActive && canAccessForms(caps)
      ? [{ label: 'Forms', to: adminHref(base, hasCap(caps, 'manage_forms') ? 'forms' : 'forms/entries'), icon: ClipboardText, children: formsChildren(base, caps) }]
      : [];
  const bookingsItems: MenuItem[] =
    bookingsActive && hasCap(caps, 'manage_bookings')
      ? [
          {
            label: 'Bookings',
            to: adminHref(base, 'bookings'),
            icon: CalendarCheck,
            children: [
              { label: 'Calendar', to: adminHref(base, 'bookings') },
              { label: 'Appointments', to: adminHref(base, 'bookings/appointments') },
              { label: 'Services', to: adminHref(base, 'bookings/services') },
              { label: 'Staff', to: adminHref(base, 'bookings/staff') },
              { label: 'Settings', to: adminHref(base, 'bookings/settings') },
            ],
          },
        ]
      : [];
  const shopItems: MenuItem[] =
    shopActive && canAccessShop(caps)
      ? [
          { label: 'Shop', to: adminHref(base, 'shop'), icon: Storefront, children: shopChildren(base, caps) },
        ]
      : [];
  const usersChildren: MenuChild[] = [
    { label: 'All Users', to: adminHref(base, 'users') },
    ...(isOwner
      ? [{ label: 'User Permissions', to: adminHref(base, 'users/permissions') } satisfies MenuChild]
      : []),
  ];
  const cptItems: MenuItem[] = can('posts')
    ? cpts
        .filter((c) => c.active && c.showInMenu)
        .map((c) => ({
          label: c.plural,
          to: adminHref(base, `content/${c.slug}`),
          icon: resolveAdminIcon(c.menuIcon),
        }))
    : [];

  const contentItems: MenuItem[] = [
    ...(can('posts')
      ? [{ label: 'Posts', to: adminHref(base, 'posts'), icon: NotePencil } satisfies MenuItem]
      : []),
    ...(can('pages')
      ? [{ label: 'Pages', to: adminHref(base, 'pages'), icon: FileText } satisfies MenuItem]
      : []),
    ...cptItems,
    ...(can('media')
      ? [{ label: 'Media', to: adminHref(base, 'media'), icon: Images } satisfies MenuItem]
      : []),
    ...(can('seo')
      ? [{ label: 'SEO', to: adminHref(base, 'seo'), icon: MagnifyingGlass } satisfies MenuItem]
      : []),
  ];

  const adminItems: MenuItem[] = [
    ...(can('fields')
      ? [
          {
            label: 'Backend Fields',
            to: adminHref(base, 'fields'),
            icon: Stack,
            children: fieldsChildren(base),
          } satisfies MenuItem,
        ]
      : []),
    ...(can('users')
      ? [
          {
            label: 'Users',
            to: adminHref(base, 'users'),
            icon: Users,
            children: usersChildren,
          } satisfies MenuItem,
        ]
      : []),
    ...(can('appearance')
      ? [
          {
            label: 'Appearance',
            to: adminHref(base, 'appearance'),
            icon: PaintBrush,
            children: appearanceChildren(base),
          } satisfies MenuItem,
        ]
      : []),
    ...(can('connector')
      ? [
          {
            label: 'Connector',
            to: adminHref(base, 'connector'),
            icon: Plugs,
            disabled: CONNECTOR_COMING_SOON,
          } satisfies MenuItem,
        ]
      : []),
    ...(can('extensions')
      ? [
          {
            label: 'Extensions',
            to: adminHref(base, 'extensions'),
            icon: PuzzlePiece,
            children: [
              { label: 'Installed', to: adminHref(base, 'extensions') },
              { label: 'Add New', to: adminHref(base, 'extensions/new') },
            ],
          } satisfies MenuItem,
        ]
      : []),
    ...(can('settings')
      ? [{ label: 'Settings', to: adminHref(base, 'settings'), icon: GearSix } satisfies MenuItem]
      : []),
  ];

  return [
    {
      items: [
        { label: 'Dashboard', to: adminHref(base), icon: SquaresFour },
        ...(can('analytics')
          ? [
              {
                label: 'Analytics',
                to: adminHref(base, 'analytics'),
                icon: ChartLine,
                children: analyticsChildren(base),
              } satisfies MenuItem,
            ]
          : []),
      ],
    },
    ...(contentItems.length ? [{ label: 'Content', items: contentItems }] : []),
    ...(shopItems.length ? [{ label: 'Shop', items: shopItems }] : []),
    ...(formsItems.length ? [{ label: 'Forms', items: formsItems }] : []),
    ...(bookingsItems.length ? [{ label: 'Bookings', items: bookingsItems }] : []),
    ...(adminItems.length ? [{ label: 'Admin', items: adminItems }] : []),
  ];
}

function pathMatches(pathname: string, to: string, base: string) {
  if (to === base) return pathname === base || pathname === `${base}/`;
  if (to === adminHref(base, 'fields')) {
    if (pathname === to || pathname === `${to}/`) return true;
    // Field group editor: {base}/fields/new, {base}/fields/:id
    const escaped = base.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const sub = pathname.match(new RegExp(`^${escaped}/fields/([^/]+)/?$`))?.[1];
    return !!sub && !['post-types', 'taxonomies', 'options-pages', 'settings', 'tools'].includes(sub);
  }
  if (to === adminHref(base, 'appearance')) {
    return pathname === to || pathname === `${to}/`;
  }
  if (to === adminHref(base, 'forms')) {
    // Form builder: {base}/forms/new, {base}/forms/:id (entries has its own item)
    return pathname === to || pathname === `${to}/` || (pathname.startsWith(`${to}/`) && !pathname.startsWith(`${to}/entries`) && !pathname.startsWith(`${to}/integrations`));
  }
  if (to === adminHref(base, 'analytics')) {
    return pathname === to || pathname === `${to}/`;
  }
  if (to === adminHref(base, 'connector')) {
    return pathname === to || pathname === `${to}/`;
  }
  if (to === adminHref(base, 'users')) {
    return pathname === to || pathname === `${to}/`;
  }
  if (to === adminHref(base, 'shop')) {
    return pathname === to || pathname === `${to}/`;
  }
  return pathname === to || pathname.startsWith(`${to}/`);
}

function sectionOpen(pathname: string, item: MenuItem) {
  if (!item.children?.length) return false;
  return pathname === item.to || pathname.startsWith(`${item.to}/`);
}

/** Hover flyouts: forgiving close, and no jumping to a neighbour on the way to a flyout. */
const FLYOUT_CLOSE_MS = 300;
const FLYOUT_SWITCH_MS = 140;
/** Closes the flyout that is open now (only one at a time). */
let closeOpenFlyout: (() => void) | null = null;

function MenuItemRow({
  item,
  pathname,
  basePath,
  updateAvailable,
  updateCount,
  latestVersion,
}: {
  item: MenuItem;
  pathname: string;
  basePath: string;
  updateAvailable: boolean;
  updateCount: number;
  latestVersion?: string;
}) {
  const liRef = useRef<HTMLLIElement>(null);
  const subRef = useRef<HTMLUListElement>(null);
  const timer = useRef<number | null>(null);
  const [flyout, setFlyout] = useState(false);
  const [flyoutPos, setFlyoutPos] = useState({ top: 0, left: 0 });
  const open = sectionOpen(pathname, item);
  const current = item.children?.length ? open : pathMatches(pathname, item.to, basePath);
  const showUpdateBadge = item.to === adminHref(basePath, 'settings') && updateAvailable;
  const Icon = item.icon;
  const showFlyout = Boolean(item.children?.length && flyout && !open);

  // Stable across renders, so "the open flyout" can be compared and closed from another row.
  const { current: clearTimer } = useRef(() => {
    if (timer.current !== null) window.clearTimeout(timer.current);
    timer.current = null;
  });
  const { current: close } = useRef(() => {
    clearTimer();
    setFlyout(false);
    if (closeOpenFlyout === close) closeOpenFlyout = null;
  });

  // Next to the row, starting at its right edge (no gap over the menu's scrollbar), kept
  // inside the window so the last links stay reachable.
  const place = () => {
    const rect = liRef.current?.getBoundingClientRect();
    if (!rect) return;
    const height = subRef.current?.offsetHeight ?? 0;
    const top = Math.max(8, Math.min(rect.top, window.innerHeight - height - 8));
    setFlyoutPos((p) => (p.top === top && p.left === rect.right ? p : { top, left: rect.right }));
  };

  const show = () => {
    clearTimer();
    if (closeOpenFlyout && closeOpenFlyout !== close) closeOpenFlyout();
    closeOpenFlyout = close;
    place();
    setFlyout(true);
  };

  const openFlyout = () => {
    clearTimer();
    if (!item.children?.length || open || flyout) return;
    // Another flyout is open: wait a moment, the pointer may only be passing on its way there.
    if (closeOpenFlyout) timer.current = window.setTimeout(show, FLYOUT_SWITCH_MS);
    else show();
  };

  const leave = () => {
    clearTimer();
    if (flyout) timer.current = window.setTimeout(close, FLYOUT_CLOSE_MS);
  };

  useLayoutEffect(() => {
    if (!showFlyout) return;
    place();
    const menu = document.getElementById('adminmenu');
    menu?.addEventListener('scroll', place, { passive: true });
    window.addEventListener('resize', place);
    return () => {
      menu?.removeEventListener('scroll', place);
      window.removeEventListener('resize', place);
    };
  }, [showFlyout]);

  useEffect(() => close, [close]);

  return (
    <li
      ref={liRef}
      className={[
        current ? 'current' : '',
        open ? 'wp-has-current-submenu' : '',
        item.children?.length ? 'wp-has-submenu' : '',
        showFlyout ? 'is-flyout-open' : '',
      ]
        .filter(Boolean)
        .join(' ') || undefined}
      onMouseEnter={openFlyout}
      onMouseLeave={leave}
      onFocusCapture={() => (flyout ? clearTimer() : item.children?.length && !open ? show() : undefined)}
      onBlurCapture={(e) => {
        if (!liRef.current?.contains(e.relatedTarget as Node | null)) close();
      }}
    >
      {item.disabled ? (
        <a
          className="disabled"
          href={item.to}
          title={`${item.label} — coming soon`}
          onClick={(e) => e.preventDefault()}
        >
          <Icon size={18} weight="regular" className="bk-menu-icon" aria-hidden />
          <span className="bk-menu-name">{item.label}</span>
        </a>
      ) : (
        <Link
          to={item.to}
          aria-current={
            item.children?.length
              ? pathMatches(pathname, item.to, basePath)
                ? 'page'
                : undefined
              : current
                ? 'page'
                : undefined
          }
          aria-haspopup={item.children?.length ? 'menu' : undefined}
          aria-expanded={item.children?.length ? open || showFlyout : undefined}
          title={
            showUpdateBadge && latestVersion
              ? `Beekiri Core v${latestVersion} available`
              : undefined
          }
        >
          <Icon size={18} weight="regular" className="bk-menu-icon" aria-hidden />
          <span className="bk-menu-name">{item.label}</span>
          {showUpdateBadge ? <span className="bk-count">+{updateCount}</span> : null}
        </Link>
      )}
      {item.children?.length ? (
        <ul
          ref={subRef}
          className={`bk-menu-submenu${open ? ' is-open' : ''}${showFlyout ? ' is-flyout' : ''}`}
          aria-label={`${item.label} submenu`}
          style={showFlyout ? { top: flyoutPos.top, left: flyoutPos.left } : undefined}
        >
          {item.children.map((child) => {
            const childCurrent = pathMatches(pathname, child.to, basePath);
            return (
              <li key={child.to} className={childCurrent ? 'current' : undefined}>
                <Link to={child.to} aria-current={childCurrent ? 'page' : undefined}>
                  {child.logoSrc ? (
                    <img
                      src={child.logoSrc}
                      alt=""
                      width={14}
                      height={14}
                      className={child.logoClass ?? 'bk-menu-provider-logo'}
                      draggable={false}
                      aria-hidden
                    />
                  ) : null}
                  <span className="bk-menu-name">{child.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      ) : null}
    </li>
  );
}

export function AdminShell({ children }: { children: React.ReactNode }) {
  const auth = useAuth();
  const location = useLocation();
  const { basePath } = useAdminEntry();
  const { updateCount, updateAvailable, updates } = useCoreUpdate();
  const version = updates?.currentVersion ?? FALLBACK_VERSION;
  const [menuOpen, setMenuOpen] = useState(false);
  const [cpts, setCpts] = useState<NavCpt[]>([]);
  const activeExtensions = useActiveExtensions();
  const shopActive = activeExtensions.includes(SHOPPING_EXTENSION);
  const formsActive = activeExtensions.includes(FORMS_EXTENSION);
  const bookingsActive = activeExtensions.includes(BOOKINGS_EXTENSION);
  const [isNarrow, setIsNarrow] = useState(
    () => typeof window !== 'undefined' && window.matchMedia('(max-width: 960px)').matches,
  );
  const menuGroups = useMemo(
    () =>
      buildMenuGroups(
        basePath,
        cpts,
        auth.user?.capabilities ?? [],
        Boolean(auth.user?.isOwner),
        shopActive,
        formsActive,
        bookingsActive,
      ),
    [basePath, cpts, auth.user?.capabilities, auth.user?.isOwner, shopActive, formsActive, bookingsActive],
  );

  useEffect(() => {
    document.body.classList.add('beekiri-admin');
    return () => document.body.classList.remove('beekiri-admin');
  }, []);

  useEffect(() => {
    let cancelled = false;
    const loadCpts = () => {
      api<{ postTypes: NavCpt[] }>('/api/fields/post-types')
        .then((res) => {
          if (!cancelled) setCpts(res.postTypes ?? []);
        })
        .catch(() => {
          if (!cancelled) setCpts([]);
        });
    };
    loadCpts();
    window.addEventListener(POST_TYPES_CHANGED, loadCpts);
    return () => {
      cancelled = true;
      window.removeEventListener(POST_TYPES_CHANGED, loadCpts);
    };
  }, [auth.user?.id]);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const mq = window.matchMedia('(max-width: 960px)');
    const onChange = () => {
      setIsNarrow(mq.matches);
      if (!mq.matches) setMenuOpen(false);
    };
    onChange();
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenuOpen(false);
    };
    document.addEventListener('keydown', onKey);
    document.body.classList.add('bk-menu-open');
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.classList.remove('bk-menu-open');
    };
  }, [menuOpen]);

  return (
    <div className="beekiri-admin" style={{ minHeight: '100%' }}>
      <SiteFavicon />
      <div id="beekiri-admin" className={menuOpen ? 'is-menu-open' : undefined}>
        <button
          type="button"
          className="bk-menu-backdrop"
          aria-label="Close menu"
          tabIndex={menuOpen ? 0 : -1}
          onClick={() => setMenuOpen(false)}
        />
        <div
          id="adminmenumain"
          role="navigation"
          aria-label="Main menu"
          {...(isNarrow && !menuOpen ? { inert: true } : {})}
        >
          <div className="bk-menu-drawer-head">
            <Link
              to={basePath}
              className="bk-menu-drawer-brand"
              title="Beekiri"
              onClick={() => setMenuOpen(false)}
            >
              <BrandMark variant="logo" tone="white" size={20} />
            </Link>
            <button
              type="button"
              className="bk-menu-close"
              aria-label="Close menu"
              onClick={() => setMenuOpen(false)}
            >
              <X size={20} weight="regular" aria-hidden />
            </button>
          </div>
          {/* Outside #adminmenu so the scrollbar never runs through the logo */}
          <div className="bk-menu-brand">
            <Link to={basePath} className="ab-item" title="Beekiri">
              <BrandMark variant="logo" tone="white" size={18} />
            </Link>
          </div>
          <ul id="adminmenu">
            <li>
              <a
                className="ab-item"
                href={LIVE_SITE}
                target="_blank"
                rel="noreferrer"
                title="Open live public site"
              >
                <ArrowSquareOut size={18} weight="regular" className="bk-menu-icon" aria-hidden />
                <span className="bk-menu-name">View site</span>
              </a>
            </li>
            <li className="bk-menu-sep" aria-hidden="true" />
            {menuGroups.map((group, groupIndex) => (
              <li key={group.label ?? `group-${groupIndex}`} className="bk-menu-group">
                {group.label ? (
                  <p className="bk-menu-label" id={`bk-menu-${group.label.toLowerCase()}`}>
                    {group.label}
                  </p>
                ) : null}
                <ul
                  className="bk-menu-group__list"
                  aria-labelledby={
                    group.label ? `bk-menu-${group.label.toLowerCase()}` : undefined
                  }
                >
                  {group.items.map((item) => (
                    <MenuItemRow
                      key={item.to}
                      item={item}
                      pathname={location.pathname}
                      basePath={basePath}
                      updateAvailable={updateAvailable}
                      updateCount={updateCount}
                      latestVersion={updates?.latestVersion ?? undefined}
                    />
                  ))}
                </ul>
              </li>
            ))}
          </ul>

          <div className="bk-menu-version" aria-label="Beekiri version">
            <span className="bk-menu-version__label">Beekiri Core</span>
            <span className="bk-menu-version__value">v{version}</span>
            <span className="bk-menu-version__meta">
              © 996agency · Free forever
            </span>
          </div>
        </div>
        <div id="bk-content">
          <div id="bk-toolbar" role="navigation" aria-label="Toolbar">
            <button
              type="button"
              className="bk-menu-toggle"
              aria-label={menuOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={menuOpen}
              aria-controls="adminmenumain"
              onClick={() => setMenuOpen((open) => !open)}
            >
              {menuOpen ? (
                <X size={20} weight="regular" aria-hidden />
              ) : (
                <List size={20} weight="regular" aria-hidden />
              )}
            </button>
            {(auth.user?.capabilities ?? []).includes('manage_options') ? (
              <LighthouseToolbar />
            ) : null}
            <AdminSpotlightSearch />
            <span className="spacer" />
            <SiteSwitcher />
            <CreditsToolbar />
            <IdleSessionToolbar />
            {auth.user ? <NotificationsBell /> : null}
            {auth.user ? (
              <Link
                to={adminHref(basePath, `users/${auth.user.id}`)}
                className="ab-item bk-toolbar-user"
                title="Edit your profile"
              >
                <img
                  src={`${import.meta.env.BASE_URL}icon-192.png`}
                  alt=""
                  width={20}
                  height={20}
                  decoding="async"
                  style={{ display: 'block', borderRadius: 5 }}
                />
                <span className="bk-toolbar-user__name">{auth.user.displayName}</span>
              </Link>
            ) : null}
            <button
              type="button"
              className="ab-item bk-toolbar-logout"
              onClick={() => void auth.logout()}
            >
              Sign out
            </button>
          </div>
          <div id="bk-body">
            <AdminPageTransition>{children}</AdminPageTransition>
          </div>
        </div>
      </div>
      <ConfirmDialogHost />
      <BeeAgentWidget />
    </div>
  );
}
