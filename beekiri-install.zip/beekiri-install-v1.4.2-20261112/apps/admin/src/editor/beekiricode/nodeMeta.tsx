import type { ComponentType } from 'react';
import {
  ArrowsClockwise,
  CalendarCheck,
  ArrowsOutLineVertical,
  Browser,
  CardsThree,
  ChartBar,
  ChatCenteredText,
  ClipboardText,
  CurrencyDollar,
  CursorClick,
  FrameCorners,
  GridFour,
  IdentificationCard,
  Image as ImageIcon,
  Info,
  ListBullets,
  ListChecks,
  MapPin,
  Megaphone,
  Minus,
  Paragraph,
  PlayCircle,
  PuzzlePiece,
  Quotes,
  Rectangle,
  ShareNetwork,
  Slideshow,
  Sparkle,
  Square,
  SquaresFour,
  Star,
  Storefront,
  Tabs,
  TextH,
  UserCircle,
  type IconProps,
} from '@phosphor-icons/react';
import type { BeekiriCodeNode, BeekiriCodeNodeType } from './document';
import type { ElementKey } from './elements';

/** Shared names, icons and colours for every node type (Layers, Props, Add, canvas). */

export type IconLike = ComponentType<IconProps>;
export type Tone = 'blue' | 'amber' | 'purple' | 'teal' | 'rose' | 'gray';

function ColumnsIcon({ count, size = 16 }: { count: 2 | 3 | 4; size?: number | string }) {
  const gap = 2;
  const w = (14 - gap * (count - 1)) / count;
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" aria-hidden>
      {Array.from({ length: count }, (_, i) => (
        <rect
          key={i}
          x={1 + i * (w + gap)}
          y={2}
          width={w}
          height={12}
          rx={1.2}
          stroke="currentColor"
          strokeWidth={1.3}
        />
      ))}
    </svg>
  );
}

const Columns2: IconLike = ({ size }) => <ColumnsIcon count={2} size={size} />;
const Columns3: IconLike = ({ size }) => <ColumnsIcon count={3} size={size} />;
const Columns4: IconLike = ({ size }) => <ColumnsIcon count={4} size={size} />;

/** Label above a bar: an image, icon or card with text under it. */
function StackIcon({ size = 16, round = false }: { size?: number | string; round?: boolean }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" aria-hidden>
      <rect x={round ? 5 : 2} y={2} width={round ? 6 : 12} height={6} rx={round ? 3 : 1.4} stroke="currentColor" strokeWidth={1.3} />
      <path d="M3 11h10M5 13.6h6" stroke="currentColor" strokeWidth={1.3} strokeLinecap="round" />
    </svg>
  );
}

const ImageBoxIcon: IconLike = ({ size }) => <StackIcon size={size} />;
const IconBoxIcon: IconLike = ({ size }) => <StackIcon size={size} round />;

/** A track with part of it filled. */
const ProgressIcon: IconLike = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 16 16" fill="none" aria-hidden>
    <rect x={1.5} y={6} width={13} height={4} rx={2} stroke="currentColor" strokeWidth={1.3} />
    <rect x={3} y={7.4} width={6} height={1.2} rx={0.6} fill="currentColor" />
  </svg>
);

/** Stacked rows, the first one open. */
const AccordionIcon: IconLike = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 16 16" fill="none" aria-hidden>
    <rect x={2} y={2} width={12} height={6} rx={1.4} stroke="currentColor" strokeWidth={1.3} />
    <path d="M2.6 10.8h10.8M2.6 13.6h10.8" stroke="currentColor" strokeWidth={1.3} strokeLinecap="round" />
  </svg>
);

export const TYPE_META: Record<BeekiriCodeNodeType, { label: string; Icon: IconLike; tone: Tone }> =
  {
    section: { label: 'Section', Icon: Rectangle, tone: 'amber' },
    container: { label: 'Container', Icon: Square, tone: 'amber' },
    heading: { label: 'Heading', Icon: TextH, tone: 'blue' },
    text: { label: 'Text', Icon: Paragraph, tone: 'blue' },
    button: { label: 'Button', Icon: CursorClick, tone: 'rose' },
    list: { label: 'List', Icon: ListBullets, tone: 'blue' },
    image: { label: 'Image', Icon: ImageIcon, tone: 'teal' },
    video: { label: 'Video', Icon: PlayCircle, tone: 'teal' },
    divider: { label: 'Divider', Icon: Minus, tone: 'gray' },
    shop_content: { label: 'Shop content', Icon: Storefront, tone: 'purple' },
    form: { label: 'Form', Icon: ClipboardText, tone: 'teal' },
    booking: { label: 'Booking', Icon: CalendarCheck, tone: 'teal' },
    spacer: { label: 'Spacer', Icon: ArrowsOutLineVertical, tone: 'gray' },
    icon: { label: 'Icon', Icon: Sparkle, tone: 'rose' },
    accordion: { label: 'Accordion', Icon: AccordionIcon, tone: 'blue' },
    tabs: { label: 'Tabs', Icon: Tabs, tone: 'blue' },
    map: { label: 'Map', Icon: MapPin, tone: 'teal' },
    rating: { label: 'Star rating', Icon: Star, tone: 'rose' },
    layout: { label: 'Layout', Icon: PuzzlePiece, tone: 'purple' },
  };

export const ROOT_META = { label: 'Body', Icon: Browser, tone: 'blue' as Tone };

export type ElementGroup = 'structure' | 'basic' | 'media' | 'interactive' | 'blocks';

export type ElementDef = {
  key: ElementKey;
  label: string;
  hint: string;
  Icon: IconLike;
  group: ElementGroup;
  /** Extra search terms. */
  keywords?: string;
  /** Only offered while editing a Shop page (Shop → Shop Editor). */
  shopOnly?: boolean;
  /** Only offered while this extension is active. */
  extension?: string;
};

export const ELEMENT_GROUPS: { id: ElementGroup; label: string; note?: string }[] = [
  { id: 'structure', label: 'Structure' },
  { id: 'basic', label: 'Basic' },
  { id: 'media', label: 'Media' },
  { id: 'interactive', label: 'Interactive' },
  { id: 'blocks', label: 'Blocks', note: 'Ready-made pieces built from the elements above. Change anything in them.' },
];

export const ELEMENTS: ElementDef[] = [
  { key: 'shop_content', label: 'Shop content', hint: 'Products or cart', Icon: Storefront, group: 'structure', keywords: 'shop products cart checkout order store', shopOnly: true },
  { key: 'section', label: 'Section', hint: 'Full-width row', Icon: Rectangle, group: 'structure', keywords: 'row block wrapper' },
  { key: 'container', label: 'Container', hint: 'Groups elements', Icon: Square, group: 'structure', keywords: 'div box group flex' },
  { key: 'columns-2', label: '2 Columns', hint: 'Side by side', Icon: Columns2, group: 'structure', keywords: 'grid two half' },
  { key: 'columns-3', label: '3 Columns', hint: 'Three across', Icon: Columns3, group: 'structure', keywords: 'grid three thirds' },
  { key: 'columns-4', label: '4 Columns', hint: 'Four across', Icon: Columns4, group: 'structure', keywords: 'grid four quarters' },
  { key: 'grid', label: 'Grid', hint: 'Rows of cells', Icon: GridFour, group: 'structure', keywords: 'grid cells tiles rows columns' },
  { key: 'spacer', label: 'Spacer', hint: 'Empty space', Icon: ArrowsOutLineVertical, group: 'structure', keywords: 'gap margin vertical' },
  { key: 'divider', label: 'Divider', hint: 'A thin line', Icon: Minus, group: 'structure', keywords: 'hr line separator rule horizontal' },

  { key: 'heading', label: 'Heading', hint: 'A title', Icon: TextH, group: 'basic', keywords: 'title h1 h2 h3 h4 h5 h6' },
  { key: 'text', label: 'Text', hint: 'A paragraph', Icon: Paragraph, group: 'basic', keywords: 'paragraph copy body' },
  { key: 'button', label: 'Button', hint: 'A link to press', Icon: CursorClick, group: 'basic', keywords: 'link cta anchor' },
  { key: 'list', label: 'List', hint: 'Bullets or numbers', Icon: ListBullets, group: 'basic', keywords: 'ul ol bullets numbered items' },
  { key: 'icon', label: 'Icon', hint: 'From 145 icons', Icon: Sparkle, group: 'basic', keywords: 'symbol svg pictogram social logo' },
  { key: 'icon-list', label: 'Icon list', hint: 'Points with ticks', Icon: ListChecks, group: 'basic', keywords: 'checklist check features bullets ticks' },
  { key: 'quote', label: 'Quote', hint: 'Words and a name', Icon: Quotes, group: 'basic', keywords: 'blockquote citation saying' },
  { key: 'rating', label: 'Star rating', hint: '0 to 5 stars', Icon: Star, group: 'basic', keywords: 'stars review score rate' },
  { key: 'form', label: 'Form', hint: 'A Bee Forms form', Icon: ClipboardText, group: 'basic', keywords: 'form contact email input submit lead bee forms', extension: 'bee-forms' },
  { key: 'booking', label: 'Booking', hint: 'Book a time', Icon: CalendarCheck, group: 'basic', keywords: 'booking appointment calendar schedule reserve bee bookings', extension: 'bee-bookings' },

  { key: 'image', label: 'Image', hint: 'One photo', Icon: ImageIcon, group: 'media', keywords: 'picture photo img media library' },
  { key: 'video', label: 'Video', hint: 'YouTube or file', Icon: PlayCircle, group: 'media', keywords: 'youtube vimeo embed mp4' },
  { key: 'gallery', label: 'Gallery', hint: 'A grid of photos', Icon: SquaresFour, group: 'media', keywords: 'photos pictures images grid portfolio' },
  { key: 'slider', label: 'Slider', hint: 'Swipe sideways', Icon: Slideshow, group: 'media', keywords: 'carousel slideshow swipe scroll photos' },
  { key: 'map', label: 'Map', hint: 'Google Maps', Icon: MapPin, group: 'media', keywords: 'google maps location address directions' },

  { key: 'accordion', label: 'Accordion', hint: 'Open and close', Icon: AccordionIcon, group: 'interactive', keywords: 'faq questions answers toggle collapse details' },
  { key: 'tabs', label: 'Tabs', hint: 'Switch content', Icon: Tabs, group: 'interactive', keywords: 'tabbed panels switch' },

  { key: 'hero', label: 'Hero', hint: 'Big opening', Icon: FrameCorners, group: 'blocks', keywords: 'banner header intro headline top' },
  { key: 'features', label: 'Features', hint: 'Three icon boxes', Icon: CardsThree, group: 'blocks', keywords: 'services benefits why us icon boxes' },
  { key: 'icon-box', label: 'Icon box', hint: 'Icon, title, text', Icon: IconBoxIcon, group: 'blocks', keywords: 'feature service benefit' },
  { key: 'image-box', label: 'Image box', hint: 'Photo, title, text', Icon: ImageBoxIcon, group: 'blocks', keywords: 'photo caption service' },
  { key: 'card', label: 'Card', hint: 'Photo, text, button', Icon: IdentificationCard, group: 'blocks', keywords: 'post article product tile' },
  { key: 'cta', label: 'Call to action', hint: 'Title and button', Icon: Megaphone, group: 'blocks', keywords: 'cta banner contact sign up' },
  { key: 'testimonial', label: 'Testimonial', hint: 'A customer review', Icon: ChatCenteredText, group: 'blocks', keywords: 'review quote customer feedback stars' },
  { key: 'pricing', label: 'Pricing', hint: 'Plan and price', Icon: CurrencyDollar, group: 'blocks', keywords: 'price plan table package subscription' },
  { key: 'team', label: 'Team member', hint: 'Photo, name, role', Icon: UserCircle, group: 'blocks', keywords: 'person staff profile about people' },
  { key: 'stats', label: 'Stats', hint: 'Big numbers', Icon: ChartBar, group: 'blocks', keywords: 'counter numbers figures facts' },
  { key: 'progress', label: 'Progress bar', hint: 'A filled bar', Icon: ProgressIcon, group: 'blocks', keywords: 'skill bar percent meter' },
  { key: 'alert', label: 'Notice', hint: 'A note in a box', Icon: Info, group: 'blocks', keywords: 'alert info message callout warning tip' },
  { key: 'social', label: 'Social icons', hint: 'Links to profiles', Icon: ShareNetwork, group: 'blocks', keywords: 'facebook instagram linkedin youtube follow share' },
];

/** Display name: custom label → layout title → text snippet → type. */
export function nodeName(node: BeekiriCodeNode, isRoot: boolean): string {
  if (isRoot) return node.label?.trim() || ROOT_META.label;
  if (node.label?.trim()) return node.label.trim();
  if (node.type === 'layout') return (node.layoutTitle || node.layoutSlug || 'Layout').trim();
  if (node.type === 'heading' || node.type === 'text' || node.type === 'button') {
    const snippet = (node.text || '').replace(/\s+/g, ' ').trim();
    if (snippet) return snippet.length > 28 ? `${snippet.slice(0, 28)}…` : snippet;
  }
  return TYPE_META[node.type]?.label ?? node.type;
}

/** Monospace chip next to the name: `body`, `h1`, `section`, layout slug… */
export function nodeTag(node: BeekiriCodeNode, isRoot: boolean): string {
  if (isRoot) return 'body';
  if (node.type === 'layout') return node.layoutSlug || 'layout';
  if (node.type === 'image') return 'img';
  if (node.type === 'video') return 'video';
  return (node.tag || node.type).toLowerCase();
}

export function nodeMeta(node: BeekiriCodeNode, isRoot: boolean): { Icon: IconLike; tone: Tone } {
  if (isRoot) return ROOT_META;
  // A box that repeats its card for live products / posts / rows.
  if (node.loop && (node.type === 'section' || node.type === 'container')) return { Icon: ArrowsClockwise, tone: 'purple' };
  return TYPE_META[node.type] ?? TYPE_META.container;
}

/* ── Drag payloads from the Add panel ───────────────────────────────────── */

export const ELEMENT_MIME = 'application/x-beekiri-element';

export type PaletteDrag =
  | { kind: 'element'; key: ElementKey }
  | { kind: 'layout'; slug: string }
  | { kind: 'section'; key: string };

/** dragover can't read dataTransfer, so the active palette drag is tracked here. */
let activeDrag: PaletteDrag | null = null;

export function setPaletteDrag(d: PaletteDrag | null) {
  activeDrag = d;
}

export function getPaletteDrag(): PaletteDrag | null {
  return activeDrag;
}

export function encodePaletteDrag(d: PaletteDrag): string {
  if (d.kind === 'element') return `el:${d.key}`;
  return d.kind === 'section' ? `section:${d.key}` : `layout:${d.slug}`;
}

export function decodePaletteDrag(raw: string): PaletteDrag | null {
  if (raw.startsWith('el:')) return { kind: 'element', key: raw.slice(3) as ElementKey };
  if (raw.startsWith('layout:')) return { kind: 'layout', slug: raw.slice(7) };
  if (raw.startsWith('section:')) return { kind: 'section', key: raw.slice(8) };
  return null;
}
