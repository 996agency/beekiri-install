import { useEffect, useMemo, useState, type ReactNode } from 'react';
import {
  AlignBottom,
  AlignCenterHorizontal,
  AlignCenterVertical,
  AlignLeft,
  AlignRight,
  AlignTop,
  ArrowCounterClockwise,
  ArrowDown,
  ArrowRight,
  ArrowsOutCardinal,
  BoundingBox,
  CaretRight,
  CircleHalf,
  Code,
  Columns,
  CopySimple,
  CornersIn,
  CornersOut,
  CursorClick,
  Desktop,
  DeviceMobile,
  Devices,
  DeviceTablet,
  Eye,
  FileText,
  Image as ImageIcon,
  Layout,
  LinkSimple,
  LinkSimpleBreak,
  ListBullets,
  ListNumbers,
  MagicWand,
  PaintBucket,
  PencilSimpleLine,
  Plus,
  PuzzlePiece,
  Rectangle,
  Rows,
  TextAa,
  TextAlignCenter,
  TextAlignJustify,
  TextAlignLeft,
  TextAlignRight,
  TextItalic,
  TextStrikethrough,
  TextUnderline,
  Trash,
  X,
} from '@phosphor-icons/react';
import {
  canAcceptChildren,
  convertNode,
  convertibleTypes,
  findParentId,
  type BeekiriCodeNode,
  type BeekiriCodeNodeType,
  type BeekiriCodePageDoc,
  type HiddenBreakpoint,
} from './document';
import { TYPE_META, nodeMeta, nodeName, nodeTag } from './nodeMeta';
import { MediaPicker, useMediaItem } from './inspector/MediaPicker';
import {
  applyBreakpointStylePatch,
  getOverrideBag,
  resolveStyleForBreakpoint,
  type StyleBreakpoint,
} from './responsiveStyles';
import {
  BG_KEYS,
  BORDER_KEYS,
  CHILD_KEYS,
  LAYOUT_KEYS,
  SIZE_KEYS,
  SPACING_KEYS,
  TYPE_KEYS,
  countSetKeys,
  fluidSize,
  patchStyle,
  readBoxSide,
  type StyleBag,
} from './styleHelpers';
import {
  Cap,
  Field,
  Grid2,
  LENGTH_UNITS,
  More,
  NumberField,
  Section,
  Segmented,
  SelectField,
  SliderField,
  Switch,
  TextArea,
  TextField,
} from './inspector/controls';
import { ColorField } from './inspector/ColorPicker';
import { FontPicker } from './inspector/FontPicker';
import type { Side, SpacingFocus } from './inspector/BoxModel';
import { FilterList, ShadowList, TransformList, TransitionList } from './inspector/EffectLists';
import { parseColor, splitSpaces } from './inspector/css-values';
import { AcfFieldList, FormPicker } from './inspector/AcfFieldInputs';
import { IconPicker, ItemsEditor } from './inspector/ElementFields';
import { BindRow, LoopFields, loopContextFor, offersLoop, type LoopContext } from './inspector/DynamicFields';
import type { ThemeLayout } from './document';
import type { BackendField } from '../../fields/acf-types';
import { applyColor, colorAt, plainText } from './inline-markup';
import './inspector/inspector.css';

export type LayoutFieldDef = BackendField;

type Props = {
  node: BeekiriCodeNode | null;
  /** Whole page tree — drives the breadcrumb in the header. */
  doc?: BeekiriCodePageDoc;
  /** True when the selected node is the page root (whole page). */
  isPageRoot?: boolean;
  onUpdate: (patch: Partial<BeekiriCodeNode>) => void;
  /** Floating overlay (legacy) or bare body for left Explorer tab. */
  variant?: 'floating' | 'embedded';
  onClose?: () => void;
  /** Where style edits write: base = all breakpoints, or tablet/mobile only. */
  editTarget?: StyleBreakpoint;
  onSelectPage?: () => void;
  onSelectNode?: (id: string) => void;
  onRename?: (label: string) => void;
  onDuplicate?: () => void;
  onDelete?: () => void;
  /** Open the Add panel targeting the selected box. */
  onAddInside?: () => void;
  /** Beekiri (Connector) is on: open its chat on this element only. */
  onAskBeekiri?: () => void;
  /** Spacing field under the pointer — the canvas highlights that padding / margin side. */
  onSpacingFocus?: (focus: SpacingFocus) => void;
  /** Parent of the selected node — drives the “In parent” (flex / grid item) section. */
  parentNode?: BeekiriCodeNode | null;
  /** Backend Fields defs for the selected layout (labels / types). */
  layoutFieldDefs?: LayoutFieldDef[];
  /** Every theme layout (field group) — dynamic content can repeat a repeater's rows. */
  layouts?: ThemeLayout[];
  /** Shopping extension on: boxes can repeat shop products. */
  shopActive?: boolean;
  /** Remove nodes (the extra cards when a box starts repeating its first one). */
  onRemoveNodes?: (ids: string[]) => void;
  /** Colors already used on the page — shown as "Document" swatches. */
  documentColors?: string[];
  showHidden?: boolean;
  onShowHiddenChange?: (v: boolean) => void;
  /** Words highlighted in the canvas text editor: the colour field then colours only those. */
  textSelection?: { start: number; end: number } | null;
};

const POSITION_KEYS = ['position', 'top', 'right', 'bottom', 'left', 'zIndex'];
/** One Layout section: size, how the element sits in its parent, and its own flex / grid. */
const LAYOUT_ALL_KEYS = [...LAYOUT_KEYS, ...SIZE_KEYS, ...CHILD_KEYS];
const CORNERS = ['TopLeft', 'TopRight', 'BottomRight', 'BottomLeft'] as const;
const RADIUS_KEYS = ['borderRadius', ...CORNERS.map((c) => `border${c}Radius`)];
/** Appearance: opacity + corner radius (as in Figma); the stroke and effects live in their own sections. */
const APPEARANCE_KEYS = ['opacity', ...RADIUS_KEYS];
const EFFECTS_SECTION_KEYS = ['boxShadow', 'filter', 'transform', 'transition'];

const SIDES = ['Top', 'Right', 'Bottom', 'Left'] as const;
/** Every border longhand the Border section can write — so “Reset” clears all of it. Radius is Appearance. */
const BORDER_RESET_KEYS = [
  ...BORDER_KEYS,
  ...SIDES.flatMap((s) => [`border${s}Width`, `border${s}Style`, `border${s}Color`]),
].filter((k) => !k.endsWith('Radius'));

/** Chain of ancestors from the page body down to `id` (inclusive). */
function nodePath(doc: BeekiriCodePageDoc | undefined, id: string): { id: string; name: string }[] {
  if (!doc) return [];
  const out: { id: string; name: string }[] = [];
  let cur: string | null = id;
  while (cur && doc.nodes[cur]) {
    out.unshift({ id: cur, name: nodeName(doc.nodes[cur], cur === doc.rootId) });
    cur = cur === doc.rootId ? null : findParentId(doc, cur);
  }
  return out;
}

/** Split legacy `border: 1px solid #ccc` into longhands so side/width edits compose. */
function expandBorderShorthand(bag: StyleBag): Record<string, string | undefined> {
  const raw = bag.border;
  if (!raw) return {};
  const out: Record<string, string | undefined> = { border: undefined };
  for (const t of splitSpaces(raw)) {
    if (/^(none|solid|dashed|dotted|double|groove|ridge|inset|outset)$/.test(t)) out.borderStyle ??= t;
    else if (parseColor(t)) out.borderColor ??= t;
    else if (/^-?\d/.test(t) || /^(thin|medium|thick)$/.test(t)) out.borderWidth ??= t;
  }
  return out;
}

export function PropertiesPanel({
  node,
  doc,
  isPageRoot = false,
  onUpdate,
  variant = 'floating',
  onClose,
  editTarget = 'base',
  onSelectPage,
  onSelectNode,
  onRename,
  onDuplicate,
  onDelete,
  onAddInside,
  onAskBeekiri,
  onSpacingFocus,
  parentNode,
  layoutFieldDefs,
  layouts,
  shopActive = false,
  onRemoveNodes,
  documentColors = [],
  showHidden = false,
  onShowHiddenChange,
  textSelection,
}: Props) {
  const embedded = variant === 'embedded';

  const body = !node ? (
    <div className="bk-insp-empty">
      <div className="bk-insp-empty__icon">
        <FileText size={20} />
      </div>
      <p className="bk-insp-empty__title">Nothing selected</p>
      <p className="bk-insp-empty__text">Click an element on the canvas or in Layers to edit its properties.</p>
      {onSelectPage ? (
        <button type="button" className="bk-insp-btn" onClick={onSelectPage}>
          Edit page body
        </button>
      ) : null}
    </div>
  ) : (
    <Inspector
      key={node.id}
      node={node}
      doc={doc}
      isPageRoot={isPageRoot}
      onUpdate={onUpdate}
      editTarget={editTarget}
      onSelectNode={onSelectNode}
      onRename={onRename}
      onDuplicate={onDuplicate}
      onDelete={onDelete}
      onAddInside={onAddInside}
      onAskBeekiri={onAskBeekiri}
      onSpacingFocus={onSpacingFocus}
      parentNode={parentNode}
      layoutFieldDefs={layoutFieldDefs}
      layouts={layouts}
      shopActive={shopActive}
      onRemoveNodes={onRemoveNodes}
      documentColors={documentColors}
      showHidden={showHidden}
          textSelection={textSelection}
      onShowHiddenChange={onShowHiddenChange}
    />
  );

  if (embedded) return <div className="bk-insp" aria-label="Properties">{body}</div>;

  return (
    <aside className="bk-beekiricode__panel bk-beekiricode__panel--right bk-beekiricode__panel--props" aria-label="Properties">
      <div className="bk-beekiricode__panel-head">
        <span>Properties</span>
        {onClose ? (
          <button type="button" className="bk-beekiricode__btn" onClick={onClose} aria-label="Close">
            <X size={12} weight="bold" />
          </button>
        ) : null}
      </div>
      <div className="bk-insp">{body}</div>
    </aside>
  );
}

/* ── Inspector body ─────────────────────────────────────────────────────── */

function Inspector({
  node,
  doc,
  isPageRoot,
  onUpdate,
  editTarget,
  onSelectNode,
  onRename,
  onDuplicate,
  onDelete,
  onAddInside,
  onAskBeekiri,
  onSpacingFocus,
  parentNode,
  layoutFieldDefs,
  layouts,
  shopActive,
  onRemoveNodes,
  documentColors,
  showHidden,
  onShowHiddenChange,
  textSelection,
}: Required<Pick<Props, 'onUpdate' | 'editTarget' | 'documentColors' | 'showHidden'>> &
  Pick<
    Props,
    | 'textSelection'
    | 'doc'
    | 'onSelectNode'
    | 'onRename'
    | 'onDuplicate'
    | 'onDelete'
    | 'onAddInside'
    | 'onAskBeekiri'
    | 'onSpacingFocus'
    | 'parentNode'
    | 'layoutFieldDefs'
    | 'layouts'
    | 'shopActive'
    | 'onRemoveNodes'
    | 'onShowHiddenChange'
  > & {
    node: BeekiriCodeNode;
    isPageRoot: boolean;
  }) {
  // Inside a repeating card: which item fields the element can bind to.
  const loopCtx = isPageRoot ? null : loopContextFor(doc, node.id, layouts);
  const bag = getOverrideBag(node, editTarget);
  const effective = resolveStyleForBreakpoint(node, editTarget === 'base' ? 'desktop' : editTarget);
  const isOverride = editTarget !== 'base';

  const val = (k: string) => bag[k] ?? '';
  /** In tablet/mobile mode show the inherited value as a placeholder. */
  const ph = (k: string, fallback = '') => (isOverride ? effective[k] || fallback : fallback);
  const set = (patch: Record<string, string | undefined>) => onUpdate(applyBreakpointStylePatch(node, editTarget, patch));
  const setKey = (k: string) => (v: string) => set({ [k]: v });

  const isBox = isPageRoot || node.type === 'section' || node.type === 'container' || node.type === 'layout';
  const count = (keys: string[]) => countSetKeys(bag, keys) > 0;
  /** “Reset” action for a section: clears its keys in the current scope. */
  const reset = (keys: string[]) =>
    count(keys) ? (
      <button
        type="button"
        className="bk-insp-icon-btn"
        title={isOverride ? `Remove ${editTarget} overrides` : 'Reset to defaults'}
        aria-label="Reset section"
        onClick={() => set(Object.fromEntries(keys.map((k) => [k, undefined])))}
      >
        <ArrowCounterClockwise size={12} weight="bold" />
      </button>
    ) : undefined;

  /* ── Hover state (Background / Typography / Border) ───────────────────── */
  const hoverBag = node.hoverStyle ?? {};
  const hVal = (k: string) => hoverBag[k] ?? '';
  /** Hover fields show the normal value as their placeholder. */
  const hPh = (k: string, fallback = '') => effective[k] || fallback;
  const hSet = (patch: Record<string, string | undefined>) => {
    const next = patchStyle(node.hoverStyle, patch);
    onUpdate({ hoverStyle: Object.keys(next).length ? next : undefined });
  };
  const hCount = (keys: string[]) => keys.some((k) => Boolean(hoverBag[k]));
  const [states, setStates] = useState<Record<string, StyleState>>(() => ({ ...stateMemory }));
  const stateOf = (id: string): StyleState => states[id] ?? 'normal';
  const setState = (id: string, v: StyleState) => {
    stateMemory[id] = v;
    setStates((m) => ({ ...m, [id]: v }));
  };
  /** Field accessors for a section, depending on its Normal / Hover switch. */
  const io = (id: string) =>
    stateOf(id) === 'hover'
      ? { val: hVal, ph: hPh, set: hSet, bag: hoverBag, hover: true }
      : { val, ph, set, bag, hover: false };
  const sectionActive = (keys: string[]) => count(keys) || hCount(keys);
  const sectionReset = (id: string, keys: string[]) =>
    stateOf(id) === 'hover'
      ? hCount(keys)
        ? (
            <button
              type="button"
              className="bk-insp-icon-btn"
              title="Clear hover styles"
              aria-label="Clear hover styles"
              onClick={() => hSet(Object.fromEntries(keys.map((k) => [k, undefined])))}
            >
              <ArrowCounterClockwise size={12} weight="bold" />
            </button>
          )
        : undefined
      : reset(keys);
  /** Header toggle: edit the hover state of this section (dot = hover styles exist). */
  const hoverToggle = (id: string, keys: string[]) => (
    <button
      type="button"
      className={`bk-insp-hover${stateOf(id) === 'hover' ? ' is-active' : ''}${hCount(keys) ? ' has-value' : ''}`}
      aria-pressed={stateOf(id) === 'hover'}
      title={stateOf(id) === 'hover' ? 'Back to the normal state' : 'Edit the hover state'}
      onClick={() => setState(id, stateOf(id) === 'hover' ? 'normal' : 'hover')}
    >
      <CursorClick size={11} weight="bold" />
      Hover
    </button>
  );
  const stateNote = (id: string) =>
    stateOf(id) === 'hover' ? (
      <p className="bk-insp-note">Hover state: shown while the pointer is over this element. Empty fields keep the normal value.</p>
    ) : null;
  const sectionTools = (id: string, keys: string[]) => (
    <>
      {hoverToggle(id, keys)}
      {sectionReset(id, keys)}
    </>
  );

  const { Icon, tone } = nodeMeta(node, isPageRoot);
  const kind = isPageRoot ? 'Page' : TYPE_META[node.type].label;
  const name = nodeName(node, isPageRoot);
  const path = nodePath(doc, node.id);
  const scopeLabel = editTarget === 'base' ? 'All devices' : editTarget === 'tablet' ? 'Tablet' : 'Mobile';
  const hasText = node.type === 'heading' || node.type === 'text' || node.type === 'button' || node.type === 'list';
  const hasTypography = hasText || isBox || node.type === 'accordion' || node.type === 'tabs';

  return (
    <>
      <div className="bk-insp-head">
        {path.length > 1 ? (
          <nav className="bk-insp-crumbs" aria-label="Location">
            {path.slice(0, -1).map((p) => (
              <span key={p.id} className="bk-insp-crumbs__item">
                <button type="button" onClick={() => onSelectNode?.(p.id)} title={`Select ${p.name}`}>
                  {p.name}
                </button>
                <CaretRight size={9} weight="bold" aria-hidden />
              </span>
            ))}
          </nav>
        ) : null}
        <div className="bk-insp-head__row">
          <span className={`bk-insp-head__icon is-${tone}`} aria-hidden>
            <Icon size={14} weight="regular" />
          </span>
          <div className="bk-insp-head__main">
            {onRename && !isPageRoot ? (
              <input
                key={`${node.id}:${node.label ?? ''}`}
                className="bk-insp-head__name"
                defaultValue={node.label ?? ''}
                placeholder={name}
                aria-label="Element name"
                spellCheck={false}
                title="Name shown in Layers (editor only)"
                onBlur={(e) => {
                  if (e.target.value.trim() !== (node.label ?? '')) onRename(e.target.value);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') (e.target as HTMLInputElement).blur();
                  if (e.key === 'Escape') {
                    (e.target as HTMLInputElement).value = node.label ?? '';
                    (e.target as HTMLInputElement).blur();
                  }
                }}
              />
            ) : (
              <span className="bk-insp-head__title">{isPageRoot ? 'Page body' : name}</span>
            )}
            <span className="bk-insp-head__kind">
              {kind}
              {!isPageRoot ? <code>{nodeTag(node, false)}</code> : null}
            </span>
          </div>
          {!isPageRoot ? (
            <div className="bk-insp-head__tools">
              {onAskBeekiri ? (
                <button
                  type="button"
                  className="bk-insp-icon-btn bk-insp-ask"
                  onClick={onAskBeekiri}
                  title="Ask Beekiri to change this element"
                  aria-label="Ask Beekiri to change this element"
                >
                  <img src="/admin/connector/claude.svg" alt="" width={14} height={14} draggable={false} />
                </button>
              ) : null}
              {onDuplicate ? (
                <button type="button" className="bk-insp-icon-btn" onClick={onDuplicate} title="Duplicate (⌘D)" aria-label="Duplicate">
                  <CopySimple size={14} />
                </button>
              ) : null}
              {onDelete ? (
                <button type="button" className="bk-insp-icon-btn is-danger" onClick={onDelete} title="Delete" aria-label="Delete">
                  <Trash size={14} />
                </button>
              ) : null}
            </div>
          ) : null}
          <span
            className={`bk-insp-scope${isOverride ? ' is-override' : ' is-icon'}`}
            title={
              isOverride
                ? `Styles below apply on ${editTarget} only. Empty fields inherit the desktop value.`
                : 'Styles apply on every device. Switch the canvas to Tablet or Mobile to add overrides.'
            }
            aria-label={scopeLabel}
          >
            {editTarget === 'tablet' ? <DeviceTablet size={13} /> : editTarget === 'mobile' ? <DeviceMobile size={13} /> : <Desktop size={13} />}
            {isOverride ? scopeLabel : null}
          </span>
        </div>
      </div>

      {isOverride ? (
        <p className="bk-insp-scope-note">
          Editing <strong>{scopeLabel.toLowerCase()}</strong> overrides — blank fields keep the desktop value.
        </p>
      ) : null}

      {onAddInside && canAcceptChildren(node, isPageRoot) ? (
        <button type="button" className="bk-insp-add" onClick={onAddInside} title="Pick an element to put inside this one">
          <Plus size={13} weight="bold" />
          Add element inside
        </button>
      ) : null}

      {!isPageRoot ? (
        <Section
          id="content"
          title={node.type === 'layout' ? 'Backend Fields' : 'Content'}
          icon={node.type === 'layout' ? <PuzzlePiece size={15} /> : <PencilSimpleLine size={15} />}
          active={Boolean(node.loop) || Boolean(loopCtx && node.bind)}
        >
          <ContentFields
            node={node}
            doc={doc}
            onUpdate={onUpdate}
            styleIo={{ val, ph, set }}
            layoutFieldDefs={layoutFieldDefs}
            documentColors={documentColors}
            layouts={layouts}
            shopActive={Boolean(shopActive)}
            loopCtx={loopCtx}
            onRemoveNodes={onRemoveNodes}
          />
        </Section>
      ) : null}

      <Section id="layout" title="Layout" icon={<Layout size={15} />} active={count(LAYOUT_ALL_KEYS)} actions={reset(LAYOUT_ALL_KEYS)}>
        <AlignBar node={node} isBox={isBox} bag={bag} effective={effective} set={set} />
        <Field label="Size">
          <Grid2>
            <NumberField value={val('width')} onChange={setKey('width')} prefix="W" units={LENGTH_UNITS} keywords={['auto', 'fit-content']} placeholder={ph('width', 'Auto')} />
            <NumberField value={val('height')} onChange={setKey('height')} prefix="H" units={LENGTH_UNITS} keywords={['auto', 'fit-content']} placeholder={ph('height', 'Auto')} />
          </Grid2>
        </Field>
        {!isPageRoot && parentNode ? <ChildFields node={node} parent={parentNode} val={val} ph={ph} set={set} part="main" /> : null}
        {isBox ? <LayoutFields val={val} ph={ph} set={set} effective={effective} /> : null}
        <More id="layout-more" label="More size options">
          <Field label="Min">
            <Grid2>
              <NumberField value={val('minWidth')} onChange={setKey('minWidth')} prefix="W" units={LENGTH_UNITS} placeholder={ph('minWidth', '—')} min={0} />
              <NumberField value={val('minHeight')} onChange={setKey('minHeight')} prefix="H" units={LENGTH_UNITS} placeholder={ph('minHeight', '—')} min={0} />
            </Grid2>
          </Field>
          <Field label="Max">
            <Grid2>
              <NumberField value={val('maxWidth')} onChange={setKey('maxWidth')} prefix="W" units={LENGTH_UNITS} keywords={['none']} placeholder={ph('maxWidth', '—')} min={0} />
              <NumberField value={val('maxHeight')} onChange={setKey('maxHeight')} prefix="H" units={LENGTH_UNITS} keywords={['none']} placeholder={ph('maxHeight', '—')} min={0} />
            </Grid2>
          </Field>
          <Field label="Overflow">
            <Segmented
              value={val('overflow')}
              onChange={setKey('overflow')}
              options={[
                { value: 'visible', label: 'Visible' },
                { value: 'hidden', label: 'Hidden' },
                { value: 'auto', label: 'Scroll' },
              ]}
            />
          </Field>
          {node.type === 'image' || node.type === 'video' ? (
            <Field label="Fit">
              <SelectField value={val('objectFit')} onChange={setKey('objectFit')} options={['cover', 'contain', 'fill', 'none', 'scale-down']} placeholder={ph('objectFit', 'Default')} />
            </Field>
          ) : null}
          <Field label="Aspect">
            <Segmented
              value={ASPECTS.some((a) => a.value === val('aspectRatio')) ? val('aspectRatio') : ''}
              onChange={setKey('aspectRatio')}
              options={ASPECTS}
            />
          </Field>
          {!isPageRoot && parentNode ? <ChildFields node={node} parent={parentNode} val={val} ph={ph} set={set} part="more" /> : null}
        </More>
      </Section>

      <Section id="spacing" title="Spacing" icon={<BoundingBox size={15} />} active={count(SPACING_KEYS)} actions={reset(SPACING_KEYS)}>
        <SpacingRows box="padding" style={isOverride ? effective : bag} onPatch={set} onFocus={onSpacingFocus} />
        <SpacingRows box="margin" style={isOverride ? effective : bag} onPatch={set} onFocus={onSpacingFocus} />
      </Section>

      <Section id="appearance" title="Appearance" icon={<CircleHalf size={15} />} active={count(APPEARANCE_KEYS)} actions={reset(APPEARANCE_KEYS)}>
        <AppearanceFields val={val} ph={ph} set={set} />
      </Section>

      {hasTypography ? (
        <Section id="typography" title="Typography" icon={<TextAa size={15} />} active={sectionActive(TYPE_KEYS)} actions={sectionTools('typography', TYPE_KEYS)}>
          {stateNote('typography')}
          <TypographyFields
            key={stateOf('typography')}
            val={io('typography').val}
            ph={io('typography').ph}
            set={io('typography').set}
            documentColors={documentColors}
            node={node}
            onUpdate={onUpdate}
            textSelection={stateOf('typography') === 'normal' && hasText ? textSelection : null}
          />
        </Section>
      ) : null}

      <Section id="background" title="Background" icon={<PaintBucket size={15} />} active={sectionActive(BG_KEYS)} actions={sectionTools('background', BG_KEYS)}>
        {stateNote('background')}
        <BackgroundFields
          key={stateOf('background')}
          val={io('background').val}
          set={io('background').set}
          documentColors={documentColors}
        />
      </Section>

      <Section
        id="border"
        title="Border"
        icon={<Rectangle size={15} />}
        defaultOpen={node.type === 'divider'}
        active={sectionActive(BORDER_RESET_KEYS)}
        actions={sectionTools('border', BORDER_RESET_KEYS)}
      >
        {stateNote('border')}
        <BorderFields
          key={stateOf('border')}
          bag={io('border').bag}
          val={io('border').val}
          set={io('border').set}
          documentColors={documentColors}
        />
      </Section>

      <Section id="effect" title="Effects" icon={<MagicWand size={15} />} defaultOpen={false} active={count(EFFECTS_SECTION_KEYS)} actions={reset(EFFECTS_SECTION_KEYS)}>
        <Field label="Shadow">
          <div className="bk-insp-chips" role="group" aria-label="Shadow presets">
            {SHADOW_PRESETS.map((p) => (
              <button
                key={p.label}
                type="button"
                className={`bk-insp-chip${(val('boxShadow') || '') === p.value ? ' is-active' : ''}`}
                title={p.value || 'No shadow'}
                onClick={() => set({ boxShadow: p.value || undefined })}
              >
                {p.label}
              </button>
            ))}
          </div>
        </Field>
        <ShadowList value={val('boxShadow')} onChange={setKey('boxShadow')} documentColors={documentColors} />
        <TransformList value={val('transform')} onChange={setKey('transform')} />
        <TransitionList value={val('transition')} onChange={setKey('transition')} />
        <FilterList value={val('filter')} onChange={setKey('filter')} />
      </Section>

      {!isPageRoot ? (
        <Section id="position" title="Position" icon={<ArrowsOutCardinal size={15} />} defaultOpen={false} active={count(POSITION_KEYS)} actions={reset(POSITION_KEYS)}>
          <PositionFields val={val} ph={ph} set={set} />
        </Section>
      ) : null}

      {!isPageRoot ? (
        <Section id="responsive" title="Responsive" icon={<Devices size={15} />} defaultOpen={false} active={(node.hiddenOn?.length ?? 0) > 0}>
          <VisibilityFields node={node} onUpdate={onUpdate} showHidden={showHidden} onShowHiddenChange={onShowHiddenChange} />
        </Section>
      ) : null}

      {!isPageRoot && node.type !== 'layout' ? (
        <Section
          id="advanced"
          title="Advanced"
          icon={<Code size={15} />}
          defaultOpen={false}
          active={Boolean(node.cssId || node.cssClass || node.customCss)}
        >
          <Field label="CSS ID">
            <TextField value={node.cssId || ''} onChange={(v) => onUpdate({ cssId: v.trim().replace(/[^\w-]/g, '') || undefined })} placeholder="unique-id" mono />
          </Field>
          <Field label="Classes">
            <TextField value={node.cssClass || ''} onChange={(v) => onUpdate({ cssClass: v.trim() || undefined })} placeholder="hero  is-dark" mono />
          </Field>
          <Field label="Custom CSS" wide>
            <TextArea
              value={node.customCss || ''}
              onChange={(v) => onUpdate({ customCss: v || undefined })}
              rows={4}
              mono
              placeholder={'letter-spacing: 0.02em;\nbackdrop-filter: blur(8px);'}
            />
          </Field>
          <p className="bk-insp-note">
            Declarations only (<code>property: value;</code>) — applied to this element on every device, after the styles above.
          </p>
        </Section>
      ) : null}
    </>
  );
}

type StyleState = 'normal' | 'hover';

/** Remembers each section's Normal / Hover choice while moving between elements. */
const stateMemory: Record<string, StyleState> = {};

type Setter = (patch: Record<string, string | undefined>) => void;
type Val = (k: string) => string;
type Ph = (k: string, fallback?: string) => string;

const SPACING_PRESETS = [0, 8, 16, 24, 32, 48, 64];

const ASPECTS = [
  { value: '1 / 1', label: '1:1', icon: <span className="bk-insp-case">1:1</span> },
  { value: '4 / 3', label: '4:3', icon: <span className="bk-insp-case">4:3</span> },
  { value: '16 / 9', label: '16:9', icon: <span className="bk-insp-case">16:9</span> },
  { value: '3 / 2', label: '3:2', icon: <span className="bk-insp-case">3:2</span> },
  { value: '21 / 9', label: '21:9', icon: <span className="bk-insp-case">21:9</span> },
];

const SHADOW_PRESETS = [
  { label: 'None', value: '' },
  { label: 'Soft', value: '0 1px 2px rgba(0, 0, 0, 0.06), 0 1px 3px rgba(0, 0, 0, 0.1)' },
  { label: 'Medium', value: '0 4px 6px rgba(0, 0, 0, 0.07), 0 10px 15px rgba(0, 0, 0, 0.1)' },
  { label: 'Large', value: '0 10px 15px rgba(0, 0, 0, 0.08), 0 25px 50px rgba(0, 0, 0, 0.18)' },
  { label: 'Glow', value: '0 0 0 1px rgba(242, 132, 47, 0.35), 0 0 24px rgba(242, 132, 47, 0.35)' },
];

/* ── In parent (flex / grid item) ───────────────────────────────────────── */

const SELF_OPTIONS = [
  { value: 'auto', label: 'Auto' },
  { value: 'flex-start', label: 'Start' },
  { value: 'center', label: 'Center' },
  { value: 'flex-end', label: 'End' },
  { value: 'stretch', label: 'Stretch' },
];

const spanOf = (v: string) => v.match(/^span\s+(\d+)$/)?.[1] ?? '';

/**
 * How the element sits in its flex / grid parent. `main` = hug / fill (or grid spans), shown in
 * Layout next to the size; `more` = align self, order and shrink, behind "More options".
 */
function ChildFields({
  node,
  parent,
  val,
  ph,
  set,
  part,
}: {
  node: BeekiriCodeNode;
  parent: BeekiriCodeNode;
  val: Val;
  ph: Ph;
  set: Setter;
  part: 'main' | 'more';
}) {
  const parentDisplay = parent.style?.display || '';
  const inFlex = parentDisplay.includes('flex');
  const inGrid = parentDisplay.includes('grid');
  if (!inFlex && !inGrid) return null;
  const column = (parent.style?.flexDirection || 'row').startsWith('column');
  const grow = (val('flexGrow') || ph('flexGrow')) === '1';
  const noShrink = (val('flexShrink') || ph('flexShrink')) === '0';
  const gridCols = (parent.style?.gridTemplateColumns || '').match(/repeat\((\d+)/)?.[1];
  const maxSpan = gridCols ? Number(gridCols) : 4;
  if (part === 'more') {
    return (
      <>
        {inFlex ? <Switch checked={noShrink} onChange={(v) => set({ flexShrink: v ? '0' : undefined })} label="Keep size (don’t shrink)" /> : null}
        <Field label="Align self">
          <SelectField value={val('alignSelf')} onChange={(v) => set({ alignSelf: v })} options={SELF_OPTIONS} placeholder={ph('alignSelf', 'Inherit')} />
        </Field>
        <Field label="Order">
          <NumberField value={val('order')} onChange={(v) => set({ order: v })} unit="" placeholder={ph('order', '0')} step={1} />
        </Field>
        {node.type === 'layout' ? <p className="bk-insp-note">Layouts are usually full-width rows; these only matter inside a flex or grid box.</p> : null}
      </>
    );
  }
  return (
    <>
      {inFlex ? (
        <Switch
          checked={grow}
          label={column ? 'Fill the height that is left' : 'Fill the width that is left'}
          onChange={(v) => set(v ? { flexGrow: '1', flexBasis: '0%', minWidth: column ? undefined : '0' } : { flexGrow: undefined, flexBasis: undefined })}
        />
      ) : (
        <>
          <Field label="Col span">
            <Segmented
              value={spanOf(val('gridColumn') || ph('gridColumn'))}
              onChange={(v) => set({ gridColumn: v ? `span ${v}` : undefined })}
              options={Array.from({ length: Math.max(2, Math.min(6, maxSpan)) }, (_, i) => ({
                value: String(i + 1),
                label: `Span ${i + 1} column${i ? 's' : ''}`,
                icon: <span className="bk-insp-case">{i + 1}</span>,
              }))}
            />
          </Field>
          <Field label="Row span">
            <Segmented
              value={spanOf(val('gridRow') || ph('gridRow'))}
              onChange={(v) => set({ gridRow: v ? `span ${v}` : undefined })}
              options={[1, 2, 3].map((n) => ({ value: String(n), label: `Span ${n} row${n > 1 ? 's' : ''}`, icon: <span className="bk-insp-case">{n}</span> }))}
            />
          </Field>
        </>
      )}
    </>
  );
}

/* ── Quick alignment ────────────────────────────────────────────────────── */

/** Elements a left / centre / right choice moves (the rest fill their row or have nothing to align). */
const ALIGNABLE = new Set(['heading', 'text', 'list', 'button', 'image', 'icon', 'rating', 'layout']);
/** Moved with auto margins: text-align would only shift what is inside them. */
const MARGIN_ALIGNED = new Set(['image', 'button']);

/**
 * Left / centre / right (and top / middle / bottom for a box) in one click. A box that already
 * lays out its children (flex or grid) has the 3 × 3 picker below instead.
 */
function AlignBar({
  node,
  isBox,
  bag,
  effective,
  set,
}: {
  node: BeekiriCodeNode;
  isBox: boolean;
  bag: StyleBag;
  effective: StyleBag;
  set: Setter;
}) {
  const display = bag.display || effective.display || '';
  const canBoxAlign = isBox && node.type !== 'layout';
  if (canBoxAlign ? /flex|grid/.test(display) : !ALIGNABLE.has(node.type)) return null;
  const byMargin = MARGIN_ALIGNED.has(node.type);

  const hValue = (() => {
    if (canBoxAlign) return '';
    if (byMargin) {
      const l = effective.marginLeft;
      const r = effective.marginRight;
      if (l === 'auto' && r === 'auto') return 'center';
      if (l === 'auto') return 'flex-end';
      if (r === 'auto') return 'flex-start';
      return '';
    }
    const t = effective.textAlign;
    return t === 'left' ? 'flex-start' : t === 'center' ? 'center' : t === 'right' ? 'flex-end' : '';
  })();

  const setH = (v: string) => {
    // A plain box becomes a column that places what is inside it.
    if (canBoxAlign) return set({ display: 'flex', flexDirection: 'column', alignItems: v });
    if (byMargin) {
      return set({
        display: node.type === 'image' ? 'block' : 'flex',
        marginLeft: v === 'flex-start' ? '0px' : 'auto',
        marginRight: v === 'flex-end' ? '0px' : 'auto',
        margin: undefined,
      });
    }
    set({ textAlign: v === 'flex-start' ? 'left' : v === 'flex-end' ? 'right' : 'center' });
  };
  const setV = (v: string) => set({ display: 'flex', flexDirection: 'column', justifyContent: v });

  const btn = (icon: ReactNode, label: string, active: boolean, onClick: () => void) => (
    <button type="button" className={`bk-insp-seg__btn${active ? ' is-active' : ''}`} title={label} aria-label={label} aria-pressed={active} onClick={onClick}>
      {icon}
    </button>
  );

  return (
    <Field label="Align">
      <div className={canBoxAlign ? 'bk-insp-grid2' : undefined} role="toolbar" aria-label="Alignment">
        <div className="bk-insp-seg">
          {btn(<AlignLeft size={15} />, 'Left', hValue === 'flex-start', () => setH('flex-start'))}
          {btn(<AlignCenterHorizontal size={15} />, 'Center', hValue === 'center', () => setH('center'))}
          {btn(<AlignRight size={15} />, 'Right', hValue === 'flex-end', () => setH('flex-end'))}
        </div>
        {canBoxAlign ? (
          <div className="bk-insp-seg">
            {btn(<AlignTop size={15} />, 'Top', false, () => setV('flex-start'))}
            {btn(<AlignCenterVertical size={15} />, 'Middle', false, () => setV('center'))}
            {btn(<AlignBottom size={15} />, 'Bottom', false, () => setV('flex-end'))}
          </div>
        ) : null}
      </div>
    </Field>
  );
}

/* ── Content / Backend Fields ───────────────────────────────────────────── */

const HEADING_TAGS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
const BOX_TAGS = ['section', 'div', 'article', 'aside', 'header', 'footer', 'nav'];

function ContentFields({
  node,
  doc,
  onUpdate,
  styleIo,
  layoutFieldDefs,
  documentColors = [],
  layouts,
  shopActive,
  loopCtx,
  onRemoveNodes,
}: {
  node: BeekiriCodeNode;
  doc?: BeekiriCodePageDoc;
  onUpdate: (patch: Partial<BeekiriCodeNode>) => void;
  /** Style access for the few looks that belong with the content (an icon's size and colour). */
  styleIo: { val: Val; ph: Ph; set: Setter };
  layoutFieldDefs?: LayoutFieldDef[];
  documentColors?: string[];
  layouts?: ThemeLayout[];
  shopActive: boolean;
  loopCtx: LoopContext | null;
  onRemoveNodes?: (ids: string[]) => void;
}) {
  const bind = (prop: 'text' | 'href' | 'src' | 'alt' | 'bg', label: string, children: ReactNode, wide?: boolean) => (
    <BindRow prop={prop} label={label} wide={wide} ctx={loopCtx} node={node} onUpdate={onUpdate}>
      {children}
    </BindRow>
  );
  const boundText = Boolean(loopCtx && node.bind?.text);

  if (node.type === 'layout') {
    const values = node.layoutFields || {};
    const defs: BackendField[] =
      layoutFieldDefs && layoutFieldDefs.length > 0
        ? layoutFieldDefs
        : Object.keys(values).map((name) => ({
            id: name,
            name,
            label: name,
            type: 'text',
            required: false,
            instructions: '',
            choices: [],
            defaultValue: '',
          }));
    return (
      <>
        <p className="bk-insp-note">
          <code>layouts/{node.layoutSlug}/</code>
        </p>
        {defs.length === 0 ? <p className="bk-insp-note">No fields yet — add them in Backend Fields.</p> : null}
        <AcfFieldList
          fields={defs}
          values={values}
          onChange={(layoutFields) => onUpdate({ layoutFields })}
          ctx={{ documentColors }}
        />
      </>
    );
  }

  const convertible = convertibleTypes(node.type);
  const convert =
    convertible.length > 1 ? (
      <Field label="Type">
        <SelectField
          value={node.type}
          options={convertible.map((t) => ({ value: t, label: TYPE_META[t].label }))}
          onChange={(v) => v && v !== node.type && onUpdate(convertNode(node, v as BeekiriCodeNodeType))}
        />
      </Field>
    ) : null;

  switch (node.type) {
    case 'heading':
      return (
        <>
          <Field label="Level">
            <Segmented
              allowEmpty={false}
              value={node.tag || 'h2'}
              options={HEADING_TAGS.map((t) => ({ value: t, label: `Heading ${t.slice(1)}`, icon: <span className="bk-insp-case">{t.toUpperCase()}</span> }))}
              onChange={(v) => onUpdate({ tag: v })}
            />
          </Field>
          {bind('text', 'Text', <TextArea value={node.text || ''} onChange={(v) => onUpdate({ text: v })} rows={2} placeholder="Heading text" />, true)}
          {boundText ? <p className="bk-insp-note">The text comes from each item; the canvas shows the first one.</p> : null}
          {convert}
        </>
      );
    case 'text':
      return (
        <>
          {bind('text', 'Text', <TextArea value={node.text || ''} onChange={(v) => onUpdate({ text: v })} rows={4} placeholder="Paragraph text" />, true)}
          {boundText ? <p className="bk-insp-note">The text comes from each item; the canvas shows the first one.</p> : null}
          {convert}
        </>
      );
    case 'button':
      return (
        <>
          {bind('text', 'Label', <TextField value={node.text || ''} onChange={(v) => onUpdate({ text: v })} placeholder="Button" live />)}
          {bind('href', 'Link', <TextField value={node.href || ''} onChange={(v) => onUpdate({ href: v })} placeholder="https:// or /page" live />)}
          <Switch checked={Boolean(node.newTab)} onChange={(v) => onUpdate({ newTab: v || undefined })} label="Open in a new tab" />
          {convert}
        </>
      );
    case 'list':
      return (
        <>
          <Field label="Style">
            <Segmented
              allowEmpty={false}
              value={node.tag === 'ol' ? 'ol' : 'ul'}
              options={[
                { value: 'ul', label: 'Bulleted', icon: <ListBullets size={14} /> },
                { value: 'ol', label: 'Numbered', icon: <ListNumbers size={14} /> },
              ]}
              onChange={(v) => onUpdate({ tag: v })}
            />
          </Field>
          <Field label="Items" wide>
            <TextArea value={node.text || ''} onChange={(v) => onUpdate({ text: v })} rows={5} placeholder={'First item\nSecond item'} />
          </Field>
          <p className="bk-insp-note">One item per line.</p>
          {convert}
        </>
      );
    case 'image': {
      const boundSrc = Boolean(loopCtx && node.bind?.src);
      return (
        <>
          {loopCtx ? (
            bind('src', 'Image', <ImageSource value={node.src || ''} onChange={(src) => onUpdate({ src })} />, true)
          ) : (
            <ImageSource value={node.src || ''} onChange={(src) => onUpdate({ src })} />
          )}
          {!boundSrc ? (
            <Field label="URL">
              <TextField value={node.src || ''} onChange={(v) => onUpdate({ src: v.trim() })} placeholder="…or paste an image URL" mono />
            </Field>
          ) : null}
          {bind('alt', 'Alt text', <TextField value={node.alt || ''} onChange={(v) => onUpdate({ alt: v })} placeholder={boundSrc ? 'The item’s own alt text' : 'Describe the image'} live />)}
        </>
      );
    }
    case 'video':
      return (
        <>
          <VideoSource value={node.src || ''} onChange={(src) => onUpdate({ src })} />
          <Field label="Video" wide>
            <TextField value={node.src || ''} onChange={(v) => onUpdate({ src: v.trim() })} placeholder="Paste a YouTube, Vimeo or .mp4 link" mono />
          </Field>
          <Field label="Title">
            <TextField value={node.alt || ''} onChange={(v) => onUpdate({ alt: v })} placeholder="For screen readers" live />
          </Field>
          <Switch
            checked={Boolean(node.autoplay)}
            onChange={(v) => onUpdate({ autoplay: v || undefined, ...(v ? { muted: true } : {}) })}
            label="Autoplay (muted)"
          />
          <Switch checked={Boolean(node.videoLoop)} onChange={(v) => onUpdate({ videoLoop: v || undefined })} label="Loop" />
          <Switch
            checked={Boolean(node.muted || node.autoplay)}
            onChange={(v) => onUpdate({ muted: v || undefined })}
            label="Muted"
          />
          <Switch
            checked={node.controls !== false}
            onChange={(v) => onUpdate({ controls: v ? undefined : false })}
            label="Show player controls"
          />
          <Field label="Cover image" wide>
            <ImageSource value={node.poster || ''} onChange={(poster) => onUpdate({ poster: poster || undefined })} />
          </Field>
          <p className="bk-insp-note">
            The cover shows before the video plays. YouTube and Vimeo links embed their player; .mp4 / .webm files use the browser’s player. Browsers only autoplay muted videos.
          </p>
        </>
      );
    case 'divider':
      return (
        <p className="bk-insp-note">
          Thickness, style and colour are under <strong>Border</strong> (top side). Use <strong>Spacing</strong> for the gap around it.
        </p>
      );
    case 'spacer':
      return (
        <p className="bk-insp-note">
          Set the height under <strong>Size</strong>. Spacers are invisible on the live site.
        </p>
      );
    case 'icon':
      return (
        <>
          <Field label="Icon">
            <IconPicker value={node.icon || ''} onChange={(icon) => onUpdate({ icon })} />
          </Field>
          <GlyphLook io={styleIo} documentColors={documentColors} />
          <Field label="Link">
            <TextField value={node.href || ''} onChange={(v) => onUpdate({ href: v.trim() || undefined })} placeholder="None · https:// or /page" live />
          </Field>
          {node.href ? (
            <>
              <Switch checked={Boolean(node.newTab)} onChange={(v) => onUpdate({ newTab: v || undefined })} label="Open in a new tab" />
              <Field label="Name">
                <TextField value={node.alt || ''} onChange={(v) => onUpdate({ alt: v || undefined })} placeholder="Read out by screen readers" live />
              </Field>
            </>
          ) : null}
        </>
      );
    case 'rating':
      return (
        <>
          <Field label="Stars">
            <SliderField value={String(node.rating ?? 5)} onChange={(v) => onUpdate({ rating: Math.min(5, Math.max(0, parseFloat(v) || 0)) })} min={0} max={5} step={0.5} unit="" suffix="/ 5" fallback={5} />
          </Field>
          <GlyphLook io={styleIo} documentColors={documentColors} />
        </>
      );
    case 'accordion':
      return (
        <>
          <ItemsEditor items={node.items ?? []} onChange={(items) => onUpdate({ items })} noun="item" />
          <Switch checked={!node.startClosed} onChange={(v) => onUpdate({ startClosed: v ? undefined : true })} label="Start with the first one open" />
        </>
      );
    case 'tabs':
      return <ItemsEditor items={node.items ?? []} onChange={(items) => onUpdate({ items })} noun="tab" />;
    case 'map':
      return (
        <>
          <Field label="Address" wide>
            <TextField value={node.address || ''} onChange={(v) => onUpdate({ address: v.trim() })} placeholder="Street, city — or a place name" />
          </Field>
          <Field label="Zoom">
            <SliderField value={String(node.zoom ?? 14)} onChange={(v) => onUpdate({ zoom: Math.round(parseFloat(v)) || 14 })} min={1} max={20} unit="" fallback={14} />
          </Field>
          <p className="bk-insp-note">
            Shows Google Maps for this address. Set the height under <strong>Layout</strong>.
          </p>
        </>
      );
    case 'form':
      return (
        <>
          <Field label="Form">
            <FormPicker value={node.formId ?? ''} onChange={(v) => onUpdate({ formId: v || undefined })} allowNull />
          </Field>
          <p className="bk-insp-note">Build and edit forms under <strong>Forms</strong>. The live form appears here on the website; the preview is read-only.</p>
        </>
      );
    case 'booking':
      return (
        <>
          <Field label="Open on one service (optional)" wide>
            <TextField value={node.bookingService ?? ''} onChange={(v) => onUpdate({ bookingService: v || undefined })} placeholder="All services" live />
          </Field>
          <p className="bk-insp-note">
            Customers pick a service, a person, a day and a time here. Set up services, staff and hours under <strong>Bookings</strong>. Type a service’s name above to skip the first step.
          </p>
        </>
      );
    case 'shop_content':
      return (
        <p className="bk-insp-note">
          The live shop content (products grid, product details, cart, checkout or order page) is rendered here by the theme’s <strong>shop/</strong> templates. Build your page around it; keep exactly one on the page.
        </p>
      );
    default:
      return (
        <>
          {/* Only boxes of cards get "Repeat for"; boxes inside a card only bind (the repeat
              settings live on the card's box). */}
          {(!loopCtx || node.loop) && offersLoop(node, doc) ? (
            <LoopFields
              node={node}
              doc={doc}
              layouts={layouts}
              shopActive={shopActive}
              documentColors={documentColors}
              onUpdate={onUpdate}
              onRemoveNodes={onRemoveNodes}
            />
          ) : null}
          {loopCtx ? bind('bg', 'Photo', <span className="bk-insp-muted">Set under Background, or fill it from each item</span>) : null}
          {/* An empty box with a background photo is published as a real image — it needs a description. */}
          {node.children.length === 0 && /url\(/.test(node.style?.backgroundImage ?? '') ? (
            <>
              {bind('alt', 'Alt text', <TextField value={node.alt || ''} onChange={(v) => onUpdate({ alt: v })} placeholder={loopCtx && node.bind?.bg ? 'The item’s own description' : 'Describe the photo'} live />)}
              <p className="bk-insp-note">This box is published as a photo (<code>&lt;figure&gt;&lt;img&gt;</code>). The alt text is what search engines and screen readers read.</p>
            </>
          ) : null}
          <Field label="HTML tag">
            <SelectField
              value={node.tag || ''}
              placeholder={node.type === 'container' ? 'div' : 'section'}
              options={BOX_TAGS}
              onChange={(v) => onUpdate({ tag: v || undefined })}
            />
          </Field>
          {convert}
        </>
      );
  }
}

/** Size and colour of an Icon or Star rating: they follow font-size and color, like text. */
function GlyphLook({ io, documentColors }: { io: { val: Val; ph: Ph; set: Setter }; documentColors: string[] }) {
  return (
    <>
      <Field label="Size">
        <SliderField value={io.val('fontSize')} onChange={(v) => io.set({ fontSize: v })} min={8} max={160} fallback={parseFloat(io.ph('fontSize')) || 32} />
      </Field>
      <Field label="Color">
        <ColorField value={io.val('color')} onChange={(v) => io.set({ color: v })} documentColors={documentColors} placeholder={io.ph('color', 'Inherit')} />
      </Field>
    </>
  );
}

/** Media-library picker for the Image element (stores the public URL). */
function ImageSource({ value, onChange }: { value: string; onChange: (url: string) => void }) {
  const [open, setOpen] = useState(false);
  const item = useMediaItem(value);
  return (
    <>
      {value ? (
        <div className="bk-acf-media">
          <button type="button" className="bk-acf-media__thumb" onClick={() => setOpen(true)} title="Replace image">
            {item ? <img src={item.url} alt={item.alt} /> : <span className="bk-acf-media__loading">Loading…</span>}
          </button>
          <div className="bk-acf-media__meta">
            <span className="bk-acf-media__name">{item?.originalName ?? value}</span>
            {item?.width ? (
              <span className="bk-acf-media__dim">
                {item.width} × {item.height}
              </span>
            ) : null}
            <div className="bk-acf-media__actions">
              <button type="button" onClick={() => setOpen(true)}>
                Replace
              </button>
              <button type="button" className="is-danger" onClick={() => onChange('')}>
                Remove
              </button>
            </div>
          </div>
        </div>
      ) : (
        <button type="button" className="bk-acf-media-empty" onClick={() => setOpen(true)}>
          <ImageIcon size={20} />
          <span>Choose from media library</span>
        </button>
      )}
      <MediaPicker
        open={open}
        onClose={() => setOpen(false)}
        kind="image"
        title="Select image"
        onSelect={(items) => items[0] && onChange(items[0].url)}
      />
    </>
  );
}

/** Pick a video file from the media library (or paste a link below). */
function VideoSource({ value, onChange }: { value: string; onChange: (src: string) => void }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" className="bk-acf-media-empty" onClick={() => setOpen(true)}>
        <ImageIcon size={20} />
        <span>{value ? 'Replace video from media library' : 'Choose a video from the media library'}</span>
      </button>
      <MediaPicker
        open={open}
        onClose={() => setOpen(false)}
        kind="file"
        title="Select video"
        onSelect={(items) => items[0] && onChange(items[0].url)}
      />
    </>
  );
}

/* ── Layout ─────────────────────────────────────────────────────────────── */

/* ── Alignment picker (3 × 3, as in Figma) ─────────────────────────────── */

const AXIS = ['flex-start', 'center', 'flex-end'] as const;
/** start / end, and the "not set" values that sit at the start edge, read as flex-start. */
const normAxis = (v: string) => (v === 'end' ? 'flex-end' : v === 'center' || v === 'flex-end' ? v : isSpace(v) ? v : 'flex-start');
/** Grid items take start / end rather than flex-start / flex-end. */
const gridAxis = (v: string) => (v === 'flex-start' ? 'start' : v === 'flex-end' ? 'end' : v);
const isSpace = (v: string) => v.startsWith('space-');
const X_WORD: Record<string, string> = { 'flex-start': 'left', center: 'center', 'flex-end': 'right' };
const Y_WORD: Record<string, string> = { 'flex-start': 'Top', center: 'Middle', 'flex-end': 'Bottom' };
const cellName = (x: string, y: string) => (x === 'center' && y === 'center' ? 'Center' : `${Y_WORD[y]} ${X_WORD[x]}`);

/**
 * Where the children sit in the box: one click sets both axes, and the choice is spelled out
 * beside the picker. With the main axis distributed (space-between…), the whole row or column
 * along it lights up.
 */
function AlignBlock({ x, y, distAxis, onAlign }: { x: string; y: string; distAxis: 'x' | 'y' | null; onAlign: (x: string, y: string) => void }) {
  const nx = normAxis(x);
  const ny = normAxis(y);
  const where = distAxis === 'x' ? `Spread across, ${Y_WORD[ny].toLowerCase()}` : distAxis === 'y' ? `Spread down, ${X_WORD[nx]}` : cellName(nx, ny);
  return (
    <div className="bk-insp-row">
      <div className="bk-insp-agrid" role="group" aria-label="Alignment">
        {AXIS.map((yy) =>
          AXIS.map((xx) => {
            const mx = nx === xx;
            const my = ny === yy;
            const active = distAxis === 'x' ? my : distAxis === 'y' ? mx : mx && my;
            return (
              <button key={`${xx}-${yy}`} type="button" className={`bk-insp-agrid__cell${active ? ' is-active' : ''}`} aria-pressed={active} title={cellName(xx, yy)} onClick={() => onAlign(xx, yy)}>
                <span />
              </button>
            );
          }),
        )}
      </div>
      <p className="bk-insp-agrid__where">
        <strong>{where}</strong>
        <span>Click a dot to move what is inside.</span>
      </p>
    </div>
  );
}

/* ── Gap ───────────────────────────────────────────────────────────────── */

/** Space between the children: one number, or rows and columns on their own after the toggle. */
function GapField({ gap, placeholder, onGap }: { gap: string; placeholder: string; onGap: (gap: string | undefined) => void }) {
  const parts = splitSpaces(gap);
  const rowGap = parts[0] ?? '';
  const colGap = parts[1] ?? parts[0] ?? '';
  const uneven = rowGap !== colGap;
  const [split, setSplit] = useState(uneven);
  useEffect(() => {
    if (uneven) setSplit(true);
  }, [uneven]);
  const write = (row: string, col: string) => {
    if (!row && !col) return onGap(undefined);
    onGap(row === col ? row : `${row || '0px'} ${col || '0px'}`);
  };
  return (
    <Field label="Gap">
      <div className="bk-insp-row">
        {split ? (
          <div className="bk-insp-grid2 bk-insp-row__grow">
            <NumberField value={rowGap} onChange={(v) => write(v, colGap)} icon={<span title="Between rows"><Rows size={13} /></span>} units={LENGTH_UNITS} placeholder={placeholder} min={0} />
            <NumberField value={colGap} onChange={(v) => write(rowGap, v)} icon={<span title="Between columns"><Columns size={13} /></span>} units={LENGTH_UNITS} placeholder={placeholder} min={0} />
          </div>
        ) : (
          <NumberField value={rowGap} onChange={(v) => write(v, v)} units={LENGTH_UNITS} placeholder={placeholder} min={0} />
        )}
        <button
          type="button"
          className={`bk-insp-icon-btn${split ? ' is-active' : ''}`}
          aria-pressed={split}
          title={split ? 'One gap for rows and columns' : 'Rows and columns on their own'}
          aria-label="Separate row and column gap"
          onClick={() => {
            if (split && uneven) write(rowGap, rowGap);
            setSplit(!split);
          }}
        >
          {split ? <LinkSimpleBreak size={14} /> : <LinkSimple size={14} />}
        </button>
      </div>
    </Field>
  );
}

/* ── Padding / margin as typed fields ───────────────────────────────────── */

const BOX_SIDES: Side[] = ['Top', 'Right', 'Bottom', 'Left'];
const spacingModeMemory: Record<string, 'axis' | 'sides'> = {};

/** A faint box with the named edges drawn strong: which sides a spacing field changes. */
function EdgeIcon({ sides }: { sides: Side[] }) {
  const on = (side: Side) => ({ stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round' as const, opacity: sides.includes(side) ? 1 : 0 });
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
      <rect x="2.5" y="2.5" width="9" height="9" rx="1" stroke="currentColor" strokeWidth="1" opacity="0.3" />
      <line x1="2" y1="1.5" x2="12" y2="1.5" {...on('Top')} />
      <line x1="12.5" y1="2" x2="12.5" y2="12" {...on('Right')} />
      <line x1="2" y1="12.5" x2="12" y2="12.5" {...on('Bottom')} />
      <line x1="1.5" y1="2" x2="1.5" y2="12" {...on('Left')} />
    </svg>
  );
}

const SIDE_HINT: Record<Side, string> = { Top: 'Top', Right: 'Right', Bottom: 'Bottom', Left: 'Left' };

/**
 * One row per box: left + right and top + bottom, or all four sides after the toggle — the
 * way Figma's auto layout padding works. Hovering a field highlights that side on the canvas.
 * Padding also gets one-click sizes.
 */
function SpacingRows({
  box,
  style,
  onPatch,
  onFocus,
}: {
  box: 'padding' | 'margin';
  style: StyleBag;
  onPatch: Setter;
  onFocus?: (focus: SpacingFocus) => void;
}) {
  const read = (side: Side) => readBoxSide(style, box, side);
  const t = read('Top');
  const r = read('Right');
  const b = read('Bottom');
  const l = read('Left');
  const uneven = t !== b || l !== r;
  const [mode, setMode] = useState<'axis' | 'sides'>(() => spacingModeMemory[box] ?? (uneven ? 'sides' : 'axis'));
  useEffect(() => {
    if (uneven) setMode('sides');
  }, [uneven]);

  const write = (sides: Side[], v: string) => {
    const patch: Record<string, string | undefined> = { [box]: undefined };
    for (const side of BOX_SIDES) patch[`${box}${side}`] = (sides.includes(side) ? v : read(side)) || undefined;
    onPatch(patch);
  };
  const focus = (side: Side) => (hovering: boolean) => onFocus?.(hovering ? { box, side } : null);
  const toggle = () => {
    const next = mode === 'axis' ? 'sides' : 'axis';
    spacingModeMemory[box] = next;
    setMode(next);
    // Back to two fields: the top and left values win.
    if (next === 'axis' && uneven) onPatch({ [box]: undefined, [`${box}Top`]: t || undefined, [`${box}Bottom`]: t || undefined, [`${box}Left`]: l || undefined, [`${box}Right`]: l || undefined });
  };
  const keywords = box === 'margin' ? ['auto'] : undefined;
  const min = box === 'padding' ? 0 : undefined;
  const edge = (sides: Side[], hint: string) => (
    <span title={hint}>
      <EdgeIcon sides={sides} />
    </span>
  );
  const all = [t, r, b, l];

  return (
    <Field label={box === 'padding' ? 'Padding' : 'Margin'}>
      <div className="bk-insp-row">
        {mode === 'axis' ? (
          <div className="bk-insp-grid2 bk-insp-row__grow">
            <NumberField value={l === r ? l : ''} onChange={(v) => write(['Left', 'Right'], v)} icon={edge(['Left', 'Right'], 'Left and right')} units={LENGTH_UNITS} keywords={keywords} placeholder="0" min={min} onHoverChange={focus('Left')} />
            <NumberField value={t === b ? t : ''} onChange={(v) => write(['Top', 'Bottom'], v)} icon={edge(['Top', 'Bottom'], 'Top and bottom')} units={LENGTH_UNITS} keywords={keywords} placeholder="0" min={min} onHoverChange={focus('Top')} />
          </div>
        ) : (
          <div className="bk-insp-grid2 bk-insp-row__grow">
            {BOX_SIDES.map((side) => (
              <NumberField key={side} value={read(side)} onChange={(v) => write([side], v)} icon={edge([side], SIDE_HINT[side])} units={LENGTH_UNITS} keywords={keywords} placeholder="0" min={min} onHoverChange={focus(side)} />
            ))}
          </div>
        )}
        <button
          type="button"
          className={`bk-insp-icon-btn${mode === 'sides' ? ' is-active' : ''}`}
          aria-pressed={mode === 'sides'}
          title={mode === 'sides' ? 'Same on both sides' : 'Each side on its own'}
          aria-label="Individual sides"
          onClick={toggle}
        >
          {mode === 'sides' ? <LinkSimpleBreak size={14} /> : <LinkSimple size={14} />}
        </button>
      </div>
      {box === 'padding' ? (
        <div className="bk-insp-chips is-fit" role="group" aria-label="Padding on all sides">
          {SPACING_PRESETS.map((n) => {
            const active = all.every((v) => v === `${n}px` || (n === 0 && (v === '0' || v === '0px' || v === '')));
            return (
              <button key={n} type="button" className={`bk-insp-chip${active ? ' is-active' : ''}`} title={`${n}px on all sides`} onClick={() => write(BOX_SIDES, `${n}px`)}>
                {n}
              </button>
            );
          })}
        </div>
      ) : null}
    </Field>
  );
}

const GRID_PRESETS = [1, 2, 3, 4];

const gridPreset = (n: number) => `repeat(${n}, minmax(0, 1fr))`;

function gridPresetOf(template: string): string {
  const m = template.replace(/\s+/g, ' ').trim().match(/^repeat\((\d+), ?(?:minmax\(0, ?1fr\)|1fr)\)$/);
  if (m) return m[1];
  const parts = template.trim().split(/\s+/);
  return parts.length > 0 && parts.every((p) => p === '1fr') ? String(parts.length) : '';
}

function LayoutFields({ val, ph, set, effective }: { val: Val; ph: Ph; set: Setter; effective: StyleBag }) {
  const display = effective.display || '';
  const isFlex = display.includes('flex');
  const isGrid = display.includes('grid');
  const segValue = isFlex ? 'flex' : isGrid ? 'grid' : display === 'none' ? 'none' : val('display') ? 'block' : '';
  const column = (effective.flexDirection || 'row').startsWith('column');
  const columns = val('gridTemplateColumns') || effective.gridTemplateColumns || '';
  const justify = val('justifyContent') || ph('justifyContent');
  const alignItems = val('alignItems') || ph('alignItems');
  return (
    <>
      <Field label="Display">
        <Segmented
          value={segValue}
          options={[
            { value: 'block', label: 'Block', hint: 'Block: what is inside stacks, one under the other' },
            { value: 'flex', label: 'Flex', hint: 'Flex: a row or a column, with alignment and gaps' },
            { value: 'grid', label: 'Grid', hint: 'Grid: equal columns' },
            { value: 'none', label: 'None', hint: 'None: hidden everywhere' },
          ]}
          onChange={(v) =>
            set(
              v
                ? { display: v }
                : {
                    display: undefined,
                    flexDirection: undefined,
                    flexWrap: undefined,
                    alignItems: undefined,
                    justifyContent: undefined,
                    gap: undefined,
                    gridTemplateColumns: undefined,
                    gridTemplateRows: undefined,
                  },
            )
          }
        />
      </Field>
      {isFlex ? (
        <>
          <Field label="Direction">
            <Segmented
              allowEmpty={false}
              value={column ? 'column' : 'row'}
              options={[
                { value: 'row', label: 'Row', hint: 'Side by side', icon: <span className="bk-insp-seg__text"><ArrowRight size={13} />Row</span> },
                { value: 'column', label: 'Column', hint: 'One under the other', icon: <span className="bk-insp-seg__text"><ArrowDown size={13} />Column</span> },
              ]}
              onChange={(v) => set({ flexDirection: v })}
            />
          </Field>
          <Field label="Align">
            <AlignBlock
              x={column ? alignItems : justify}
              y={column ? justify : alignItems}
              distAxis={isSpace(justify) ? (column ? 'y' : 'x') : null}
              onAlign={(x, y) => set(column ? { alignItems: x, justifyContent: y } : { justifyContent: x, alignItems: y })}
            />
          </Field>
          <GapField gap={val('gap')} placeholder={ph('gap', '0')} onGap={(g) => set({ gap: g })} />
          <Field label="Distribute" wide>
            <Segmented
              allowEmpty={false}
              value={isSpace(justify) ? justify : 'packed'}
              onChange={(v) => set({ justifyContent: v === 'packed' ? 'flex-start' : v })}
              options={[
                { value: 'packed', label: 'Packed', hint: 'Packed: kept together' },
                { value: 'space-between', label: 'Between', hint: 'Between: first and last at the edges, equal space between' },
                { value: 'space-around', label: 'Around', hint: 'Around: equal space around each one' },
                { value: 'space-evenly', label: 'Evenly', hint: 'Evenly: the same space everywhere' },
              ]}
            />
          </Field>
          <Switch checked={(val('flexWrap') || ph('flexWrap')) === 'wrap'} onChange={(v) => set({ flexWrap: v ? 'wrap' : undefined })} label="Wrap onto new lines when full" />
        </>
      ) : null}
      {isGrid ? (
        <>
          <Field label="Columns">
            <Segmented
              value={gridPresetOf(columns)}
              options={GRID_PRESETS.map((n) => ({ value: String(n), label: `${n} column${n === 1 ? '' : 's'}`, icon: <span className="bk-insp-case">{n}</span> }))}
              onChange={(v) => set({ gridTemplateColumns: v ? gridPreset(Number(v)) : undefined })}
            />
          </Field>
          <Grid2>
            <Cap label="Custom columns">
              <TextField value={val('gridTemplateColumns')} onChange={(v) => set({ gridTemplateColumns: v })} placeholder={ph('gridTemplateColumns', '2fr 1fr')} mono />
            </Cap>
            <Cap label="Custom rows">
              <TextField value={val('gridTemplateRows')} onChange={(v) => set({ gridTemplateRows: v })} placeholder={ph('gridTemplateRows', 'auto')} mono />
            </Cap>
          </Grid2>
          <Field label="Align">
            <AlignBlock
              x={val('justifyItems') || ph('justifyItems')}
              y={alignItems}
              distAxis={null}
              onAlign={(x, y) => set({ justifyItems: gridAxis(x), alignItems: gridAxis(y) })}
            />
          </Field>
          <GapField gap={val('gap')} placeholder={ph('gap', '0')} onGap={(g) => set({ gap: g })} />
        </>
      ) : null}
    </>
  );
}

/* ── Position ───────────────────────────────────────────────────────────── */

function PositionFields({ val, ph, set }: { val: Val; ph: Ph; set: Setter }) {
  const pos = val('position') || ph('position');
  const offset = pos && pos !== 'static';
  return (
    <>
      <Field label="Type">
        <SelectField
          value={val('position')}
          onChange={(v) => set({ position: v })}
          placeholder={ph('position', 'Normal (in the flow)')}
          options={[
            { value: 'relative', label: 'Relative · nudged from its place' },
            { value: 'absolute', label: 'Absolute · placed inside its box' },
            { value: 'fixed', label: 'Fixed · stays on screen' },
            { value: 'sticky', label: 'Sticky · sticks while scrolling' },
          ]}
        />
      </Field>
      {offset ? (
        <Field label="Offset">
          <Grid2>
            <NumberField value={val('top')} onChange={(v) => set({ top: v })} prefix="T" units={LENGTH_UNITS} placeholder={ph('top', 'Auto')} />
            <NumberField value={val('right')} onChange={(v) => set({ right: v })} prefix="R" units={LENGTH_UNITS} placeholder={ph('right', 'Auto')} />
            <NumberField value={val('bottom')} onChange={(v) => set({ bottom: v })} prefix="B" units={LENGTH_UNITS} placeholder={ph('bottom', 'Auto')} />
            <NumberField value={val('left')} onChange={(v) => set({ left: v })} prefix="L" units={LENGTH_UNITS} placeholder={ph('left', 'Auto')} />
          </Grid2>
        </Field>
      ) : null}
      <Field label="Layer">
        <NumberField value={val('zIndex')} onChange={(v) => set({ zIndex: v })} unit="" placeholder={ph('zIndex', 'Auto · higher sits on top')} />
      </Field>
    </>
  );
}

/* ── Appearance: opacity + corner radius ────────────────────────────────── */

function AppearanceFields({ val, ph, set }: { val: Val; ph: Ph; set: Setter }) {
  const hasCorners = CORNERS.some((c) => Boolean(val(`border${c}Radius`)));
  const [independent, setIndependent] = useState(hasCorners);
  useEffect(() => {
    if (hasCorners) setIndependent(true);
  }, [hasCorners]);
  const pct = (v: string) => (v ? String(Math.round(Number(v) * 100)) : '');
  return (
    <>
      <div className="bk-insp-cols">
        <div className="bk-insp-col">
          <span className="bk-insp-cap">Opacity</span>
          <NumberField
            value={pct(val('opacity'))}
            onChange={(v) => {
              const n = parseFloat(v);
              set({ opacity: Number.isFinite(n) ? String(Math.min(100, Math.max(0, n)) / 100) : undefined });
            }}
            icon={<Eye size={13} />}
            unit=""
            suffix="%"
            placeholder={pct(ph('opacity')) || '100'}
            min={0}
          />
        </div>
        <div className="bk-insp-col">
          <span className="bk-insp-cap">Corner radius</span>
          <div className="bk-insp-row">
            <NumberField
              value={val('borderRadius')}
              onChange={(v) => set({ borderRadius: v, ...(independent ? {} : Object.fromEntries(CORNERS.map((c) => [`border${c}Radius`, undefined]))) })}
              icon={<CornersOut size={13} />}
              units={LENGTH_UNITS}
              placeholder={ph('borderRadius', '0')}
              min={0}
            />
            <button
              type="button"
              className={`bk-insp-icon-btn${independent ? ' is-active' : ''}`}
              aria-pressed={independent}
              title="Independent corners"
              aria-label="Independent corners"
              onClick={() => {
                if (independent) set(Object.fromEntries(CORNERS.map((c) => [`border${c}Radius`, undefined])));
                setIndependent(!independent);
              }}
            >
              <CornersIn size={13} />
            </button>
          </div>
        </div>
      </div>
      {independent ? (
        <div className="bk-insp-grid4">
          {CORNERS.map((c) => (
            <NumberField
              key={c}
              value={val(`border${c}Radius`)}
              placeholder={val('borderRadius') || ph('borderRadius', '0')}
              suffix={c.replace(/[a-z]/g, '')}
              min={0}
              onChange={(v) => set({ [`border${c}Radius`]: v })}
            />
          ))}
        </div>
      ) : null}
    </>
  );
}

/* ── Stroke ─────────────────────────────────────────────────────────────── */

type BorderSide = '' | 'Top' | 'Right' | 'Bottom' | 'Left';

function SideIcon({ side }: { side: BorderSide }) {
  const hi = '#fff';
  const lo = 'rgba(255,255,255,0.28)';
  const c = (s: BorderSide) => (side === '' || side === s ? hi : lo);
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden>
      <line x1="2" y1="2" x2="12" y2="2" stroke={c('Top')} strokeWidth="1.6" strokeLinecap="round" />
      <line x1="12" y1="2" x2="12" y2="12" stroke={c('Right')} strokeWidth="1.6" strokeLinecap="round" />
      <line x1="2" y1="12" x2="12" y2="12" stroke={c('Bottom')} strokeWidth="1.6" strokeLinecap="round" />
      <line x1="2" y1="2" x2="2" y2="12" stroke={c('Left')} strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}

function BorderFields({ bag, val, set, documentColors }: { bag: StyleBag; val: Val; set: Setter; documentColors: string[] }) {
  const [side, setSide] = useState<BorderSide>('');
  const key = (prop: 'Width' | 'Style' | 'Color') => `border${side}${prop}`;
  const write = (patch: Record<string, string | undefined>) => set({ ...expandBorderShorthand(bag), ...patch });
  const expanded = expandBorderShorthand(bag);
  const read = (prop: 'Width' | 'Style' | 'Color') => val(key(prop)) || (side === '' ? expanded[`border${prop}`] ?? '' : '');

  return (
    <>
      <Field label="Color">
        <ColorField value={read('Color')} onChange={(v) => write({ [key('Color')]: v })} documentColors={documentColors} />
      </Field>
      <Field label="Width">
        <SliderField
          value={read('Width')}
          onChange={(v) => write({ [key('Width')]: v, ...(!read('Style') ? { [key('Style')]: 'solid' } : {}) })}
          min={0}
          max={20}
        />
      </Field>
      <Field label="Side">
        <Segmented
          allowEmpty={false}
          value={side || 'all'}
          onChange={(v) => setSide(v === 'all' ? '' : (v as BorderSide))}
          options={[
            { value: 'all', label: 'All sides', icon: <SideIcon side="" /> },
            { value: 'Top', label: 'Top', icon: <SideIcon side="Top" /> },
            { value: 'Right', label: 'Right', icon: <SideIcon side="Right" /> },
            { value: 'Bottom', label: 'Bottom', icon: <SideIcon side="Bottom" /> },
            { value: 'Left', label: 'Left', icon: <SideIcon side="Left" /> },
          ]}
        />
      </Field>
      <Field label="Style">
        <Segmented
          value={read('Style')}
          onChange={(v) => write({ [key('Style')]: v, ...(v && v !== 'none' && !read('Width') ? { [key('Width')]: '1px' } : {}) })}
          options={[
            { value: 'none', label: 'None', icon: <X size={12} weight="bold" /> },
            { value: 'solid', label: 'Solid', icon: <span className="bk-insp-line is-solid" /> },
            { value: 'dashed', label: 'Dashed', icon: <span className="bk-insp-line is-dashed" /> },
            { value: 'dotted', label: 'Dotted', icon: <span className="bk-insp-line is-dotted" /> },
          ]}
        />
      </Field>
    </>
  );
}

/* ── Typography ─────────────────────────────────────────────────────────── */

const WEIGHTS = [
  { value: '100', label: 'Thin' },
  { value: '200', label: 'Extra Light' },
  { value: '300', label: 'Light' },
  { value: '400', label: 'Regular' },
  { value: '500', label: 'Medium' },
  { value: '600', label: 'Semibold' },
  { value: '700', label: 'Bold' },
  { value: '800', label: 'Extra Bold' },
  { value: '900', label: 'Black' },
];

/** Text sizes as a phone → desktop pair; the CSS clamp() is written for the user. */
const SIZE_PRESETS = [
  { key: 'display', label: 'Display', min: 48, max: 88 },
  { key: 'h1', label: 'Heading 1', min: 36, max: 64 },
  { key: 'h2', label: 'Heading 2', min: 30, max: 48 },
  { key: 'h3', label: 'Heading 3', min: 24, max: 36 },
  { key: 'h4', label: 'Heading 4', min: 20, max: 28 },
  { key: 'h5', label: 'Heading 5', min: 18, max: 22 },
  { key: 'h6', label: 'Heading 6', min: 16, max: 18 },
  { key: 'lead', label: 'Body large', min: 18, max: 20 },
  { key: 'body', label: 'Body', min: 16, max: 16 },
  { key: 'small', label: 'Small', min: 14, max: 14 },
];
/** Reads back our clamp(), any clamp(apx, …, bpx) a theme wrote, or a plain px size. */
function parseFontSize(v: string): { min: number; max: number } | null {
  const t = v.trim();
  const clamp = t.match(/^clamp\(\s*([\d.]+)px\s*,[\s\S]*,\s*([\d.]+)px\s*\)$/i);
  if (clamp) return { min: Number(clamp[1]), max: Number(clamp[2]) };
  const px = t.match(/^([\d.]+)px$/i);
  return px ? { min: Number(px[1]), max: Number(px[1]) } : null;
}
const sizeLabel = (p: { min: number; max: number }) => (p.min === p.max ? `${p.min}px` : `${p.min}–${p.max}px`);

function TypographyFields({
  val,
  ph,
  set,
  documentColors,
  node,
  onUpdate,
  textSelection,
}: {
  val: Val;
  ph: Ph;
  set: Setter;
  documentColors: string[];
  node: BeekiriCodeNode;
  onUpdate: (patch: Partial<BeekiriCodeNode>) => void;
  textSelection?: { start: number; end: number } | null;
}) {
  const deco = val('textDecoration') || ph('textDecoration');
  const toggleDeco = (d: 'underline' | 'line-through') => set({ textDecoration: deco.includes(d) ? 'none' : d });
  const italic = (val('fontStyle') || ph('fontStyle')) === 'italic';

  const fontSize = val('fontSize');
  const size = parseFontSize(fontSize);
  const sizePh = parseFontSize(ph('fontSize'));
  const preset = size ? SIZE_PRESETS.find((p) => p.min === size.min && p.max === size.max) : undefined;
  const sizeValue = !fontSize ? '' : preset ? preset.key : 'custom';
  const num = (v: string) => parseFloat(v) || 0;
  const writeSize = (min: number, max: number) => set({ fontSize: fluidSize(Math.max(1, min), Math.max(1, max)) });

  // Words highlighted on the canvas: the colour goes on them, not on the whole element.
  const text = node.text || '';
  const sel = textSelection && textSelection.end > textSelection.start ? textSelection : null;
  const selWords = sel ? plainText(text).slice(sel.start, sel.end).trim() : '';

  return (
    <>
      <Field label="Font">
        <FontPicker value={val('fontFamily')} onChange={(v) => set({ fontFamily: v })} />
      </Field>
      <Grid2>
        <Cap label="Weight">
          <SelectField value={val('fontWeight')} onChange={(v) => set({ fontWeight: v })} options={WEIGHTS} placeholder={ph('fontWeight', 'Default')} />
        </Cap>
        <Cap label="Size">
        <SelectField
          value={sizeValue}
          placeholder={sizePh ? sizeLabel(sizePh) : 'Default'}
          options={[
            ...SIZE_PRESETS.map((p) => ({ value: p.key, label: `${p.label} · ${sizeLabel(p)}` })),
            { value: 'custom', label: 'Custom' },
          ]}
          onChange={(k) => {
            const p = SIZE_PRESETS.find((x) => x.key === k);
            if (p) writeSize(p.min, p.max);
            else if (k === 'custom') set({ fontSize: fontSize || '24px' });
            else set({ fontSize: undefined });
          }}
        />
        </Cap>
      </Grid2>
      <Grid2>
        <Cap label="Size on phones">
          <NumberField
            value={size ? String(size.min) : ''}
            onChange={(v) => writeSize(num(v), size ? size.max : num(v))}
            icon={<DeviceMobile size={13} />}
            suffix="px"
            placeholder={sizePh ? String(sizePh.min) : '–'}
            min={1}
          />
        </Cap>
        <Cap label="Size on desktop">
          <NumberField
            value={size ? String(size.max) : ''}
            onChange={(v) => writeSize(size ? size.min : num(v), num(v))}
            icon={<Desktop size={13} />}
            suffix="px"
            placeholder={sizePh ? String(sizePh.max) : '–'}
            min={1}
          />
        </Cap>
      </Grid2>
      {fontSize && !size ? (
        <Field label="Value">
          <TextField value={fontSize} onChange={(v) => set({ fontSize: v })} mono />
        </Field>
      ) : null}
      <Grid2>
        <Cap label="Line height">
          <NumberField value={val('lineHeight')} onChange={(v) => set({ lineHeight: v })} unit="" placeholder={ph('lineHeight', 'Auto')} step={0.05} min={0} />
        </Cap>
        <Cap label="Letter spacing">
          <NumberField value={val('letterSpacing')} onChange={(v) => set({ letterSpacing: v })} units={['px', 'em']} placeholder={ph('letterSpacing', '0')} step={0.1} />
        </Cap>
      </Grid2>
      {sel ? (
        <>
          <Field label="Color">
            <ColorField
              value={colorAt(text, sel.start, sel.end)}
              onChange={(v) => onUpdate({ text: applyColor(text, sel.start, sel.end, v || null) })}
              documentColors={documentColors}
              placeholder="Selected words"
            />
          </Field>
          <p className="bk-insp-note">
            Colours only <strong>“{selWords.length > 32 ? `${selWords.slice(0, 32)}…` : selWords}”</strong>. Click the element on the page to colour all of its text.
          </p>
        </>
      ) : (
        <Field label="Color">
          <ColorField value={val('color')} onChange={(v) => set({ color: v })} documentColors={documentColors} placeholder={ph('color', 'Inherit')} />
        </Field>
      )}
      <Field label="Align">
        <Segmented
          value={val('textAlign')}
          onChange={(v) => set({ textAlign: v })}
          options={[
            { value: 'left', label: 'Left', icon: <TextAlignLeft size={14} /> },
            { value: 'center', label: 'Center', icon: <TextAlignCenter size={14} /> },
            { value: 'right', label: 'Right', icon: <TextAlignRight size={14} /> },
            { value: 'justify', label: 'Justify', icon: <TextAlignJustify size={14} /> },
          ]}
        />
      </Field>
      <Field label="Style">
        <div className="bk-insp-seg">
          <button type="button" title="Italic" className={`bk-insp-seg__btn${italic ? ' is-active' : ''}`} onClick={() => set({ fontStyle: italic ? undefined : 'italic' })}>
            <TextItalic size={14} />
          </button>
          <button type="button" title="Underline" className={`bk-insp-seg__btn${deco.includes('underline') ? ' is-active' : ''}`} onClick={() => toggleDeco('underline')}>
            <TextUnderline size={14} />
          </button>
          <button type="button" title="Strikethrough" className={`bk-insp-seg__btn${deco.includes('line-through') ? ' is-active' : ''}`} onClick={() => toggleDeco('line-through')}>
            <TextStrikethrough size={14} />
          </button>
        </div>
      </Field>
      <Field label="Case">
        <Segmented
          value={val('textTransform')}
          onChange={(v) => set({ textTransform: v })}
          options={[
            { value: 'none', label: 'None', icon: <X size={12} weight="bold" /> },
            { value: 'uppercase', label: 'Uppercase', icon: <span className="bk-insp-case">TT</span> },
            { value: 'capitalize', label: 'Capitalize', icon: <span className="bk-insp-case">Tt</span> },
            { value: 'lowercase', label: 'Lowercase', icon: <span className="bk-insp-case">tt</span> },
          ]}
        />
      </Field>
    </>
  );
}

/* ── Background ─────────────────────────────────────────────────────────── */

type BgMode = 'none' | 'color' | 'gradient' | 'image';
type Gradient = { angle: number; from: string; to: string };

/** Only the two-stop linear gradients this panel writes are parsed back. */
function parseGradient(v: string): Gradient | null {
  const m = v.trim().match(/^linear-gradient\(\s*(-?\d+(?:\.\d+)?)deg\s*,\s*(.+?)\s+\d+%\s*,\s*(.+?)\s+\d+%\s*\)$/i);
  return m ? { angle: Number(m[1]), from: m[2].trim(), to: m[3].trim() } : null;
}

const gradientCss = (g: Gradient) => `linear-gradient(${g.angle}deg, ${g.from} 0%, ${g.to} 100%)`;

const BG_IMAGE_KEYS = ['backgroundImage', 'backgroundSize', 'backgroundPosition', 'backgroundRepeat', 'backgroundAttachment'];
const clearKeys = (keys: string[]) => Object.fromEntries(keys.map((k) => [k, undefined])) as Record<string, undefined>;

function BackgroundFields({ val, set, documentColors }: { val: Val; set: Setter; documentColors: string[] }) {
  const legacy = val('background');
  const color = val('backgroundColor') || (parseColor(legacy) ? legacy : '');
  const image = val('backgroundImage');
  const gradient = image ? parseGradient(image) : null;
  const url = image.match(/^url\(["']?(.*?)["']?\)$/)?.[1] ?? '';
  const detected: BgMode = gradient ? 'gradient' : url ? 'image' : color ? 'color' : 'none';
  const [mode, setMode] = useState<BgMode>(detected);
  useEffect(() => {
    if (detected !== 'none') setMode(detected);
  }, [detected]);

  const switchMode = (m: BgMode) => {
    setMode(m);
    if (m === 'none') set({ background: undefined, backgroundColor: undefined, ...clearKeys(BG_IMAGE_KEYS) });
    if (m === 'color') set(clearKeys(BG_IMAGE_KEYS));
    if (m === 'gradient') {
      set({ ...clearKeys(BG_IMAGE_KEYS), backgroundImage: gradientCss({ angle: 135, from: color || '#FFC93C', to: '#F26B1D' }) });
    }
    if (m === 'image' && !url) set(clearKeys(BG_IMAGE_KEYS));
  };

  const writeGradient = (patch: Partial<Gradient>) =>
    set({ backgroundImage: gradientCss({ ...(gradient ?? { angle: 135, from: '#FFC93C', to: '#F26B1D' }), ...patch }) });

  return (
    <>
      <Field label="Type">
        <Segmented
          allowEmpty={false}
          value={mode}
          onChange={(v) => switchMode(v as BgMode)}
          options={[
            { value: 'none', label: 'None' },
            { value: 'color', label: 'Color' },
            { value: 'gradient', label: 'Gradient' },
            { value: 'image', label: 'Image' },
          ]}
        />
      </Field>

      {mode === 'color' || mode === 'image' ? (
        <Field label="Color">
          <ColorField
            value={color}
            onChange={(v) => set({ backgroundColor: v, ...(parseColor(legacy) ? { background: undefined } : {}) })}
            documentColors={documentColors}
            placeholder={mode === 'image' ? 'Behind image' : 'None'}
          />
        </Field>
      ) : null}

      {mode === 'gradient' ? (
        <>
          <div className="bk-insp-gradient" style={{ backgroundImage: image || gradientCss({ angle: 135, from: '#FFC93C', to: '#F26B1D' }) }} aria-hidden />
          <Field label="From">
            <ColorField value={gradient?.from ?? '#FFC93C'} onChange={(v) => v && writeGradient({ from: v })} documentColors={documentColors} />
          </Field>
          <Field label="To">
            <ColorField value={gradient?.to ?? '#F26B1D'} onChange={(v) => v && writeGradient({ to: v })} documentColors={documentColors} />
          </Field>
          <Field label="Angle">
            <SliderField
              value={gradient ? String(gradient.angle) : '135'}
              onChange={(v) => writeGradient({ angle: parseFloat(v) || 0 })}
              min={0}
              max={360}
              unit=""
              suffix="°"
              fallback={135}
            />
          </Field>
          <Field label="Direction">
            <Segmented
              value={gradient ? String(gradient.angle) : '135'}
              onChange={(v) => v && writeGradient({ angle: Number(v) })}
              options={[
                { value: '0', label: 'Up', icon: <span className="bk-insp-case">↑</span> },
                { value: '90', label: 'Right', icon: <span className="bk-insp-case">→</span> },
                { value: '180', label: 'Down', icon: <span className="bk-insp-case">↓</span> },
                { value: '135', label: 'Diagonal', icon: <span className="bk-insp-case">↘</span> },
              ]}
            />
          </Field>
          <button
            type="button"
            className="bk-insp-link-btn"
            onClick={() => gradient && writeGradient({ from: gradient.to, to: gradient.from })}
          >
            Swap colors
          </button>
        </>
      ) : null}

      {mode === 'image' ? (
        <>
          <ImageSource value={url} onChange={(u) => set({ backgroundImage: u ? `url("${u}")` : undefined })} />
          <Field label="URL">
            <TextField
              value={url}
              onChange={(v) => {
                const t = v.trim();
                set({ backgroundImage: t ? `url("${t}")` : undefined });
              }}
              placeholder="…or paste an image URL"
              mono
            />
          </Field>
          {url ? (
            <>
              <Field label="Size">
                <Segmented
                  value={val('backgroundSize')}
                  onChange={(v) => set({ backgroundSize: v })}
                  options={[
                    { value: 'cover', label: 'Cover' },
                    { value: 'contain', label: 'Contain' },
                    { value: 'auto', label: 'Original' },
                  ]}
                />
              </Field>
              <Field label="Position">
                <SelectField
                  value={val('backgroundPosition')}
                  onChange={(v) => set({ backgroundPosition: v })}
                  placeholder="Center"
                  options={['center', 'top', 'bottom', 'left', 'right', 'top left', 'top right', 'bottom left', 'bottom right']}
                />
              </Field>
              <Field label="Repeat">
                <Segmented
                  value={val('backgroundRepeat')}
                  onChange={(v) => set({ backgroundRepeat: v })}
                  options={[
                    { value: 'no-repeat', label: 'No' },
                    { value: 'repeat', label: 'Tile' },
                    { value: 'repeat-x', label: 'X' },
                    { value: 'repeat-y', label: 'Y' },
                  ]}
                />
              </Field>
              <Switch
                checked={val('backgroundAttachment') === 'fixed'}
                onChange={(v) => set({ backgroundAttachment: v ? 'fixed' : undefined })}
                label="Fixed while scrolling (parallax)"
              />
            </>
          ) : null}
        </>
      ) : null}
    </>
  );
}

/* ── Responsive visibility ──────────────────────────────────────────────── */

const BREAKPOINTS: { id: HiddenBreakpoint; label: string; Icon: typeof Desktop }[] = [
  { id: 'desktop', label: 'Desktop', Icon: Desktop },
  { id: 'tablet', label: 'Tablet', Icon: DeviceTablet },
  { id: 'mobile', label: 'Mobile', Icon: DeviceMobile },
];

function VisibilityFields({
  node,
  onUpdate,
  showHidden,
  onShowHiddenChange,
}: {
  node: BeekiriCodeNode;
  onUpdate: (patch: Partial<BeekiriCodeNode>) => void;
  showHidden: boolean;
  onShowHiddenChange?: (v: boolean) => void;
}) {
  const hidden = useMemo(() => new Set(node.hiddenOn ?? []), [node.hiddenOn]);
  const toggle = (bp: HiddenBreakpoint) => {
    const next = new Set(hidden);
    if (next.has(bp)) next.delete(bp);
    else next.add(bp);
    onUpdate({ hiddenOn: next.size ? BREAKPOINTS.map((b) => b.id).filter((id) => next.has(id)) : undefined });
  };
  return (
    <>
      <Field label="Hide on">
        <div className="bk-insp-seg">
          <button
            type="button"
            title="Visible everywhere"
            className={`bk-insp-seg__btn${hidden.size === 0 ? ' is-active' : ''}`}
            onClick={() => onUpdate({ hiddenOn: undefined })}
          >
            <X size={12} weight="bold" />
          </button>
          {BREAKPOINTS.map(({ id, label, Icon }) => (
            <button
              key={id}
              type="button"
              title={`Hide on ${label}`}
              aria-pressed={hidden.has(id)}
              className={`bk-insp-seg__btn${hidden.has(id) ? ' is-active is-warn' : ''}`}
              onClick={() => toggle(id)}
            >
              <Icon size={14} />
            </button>
          ))}
        </div>
      </Field>
      {onShowHiddenChange ? <Switch checked={showHidden} onChange={onShowHiddenChange} label="Show all hidden elements" /> : null}
    </>
  );
}
