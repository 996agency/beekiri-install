import { useEffect, useMemo, useState } from 'react';
import {
  CaretDown,
  CheckCircle,
  Image as ImageIcon,
  Info,
  Plus,
  Sparkle,
  Trash,
  Warning,
  WarningCircle,
} from '@phosphor-icons/react';
import { api, ApiError } from '../../api/client';
import { useAuth } from '../../auth/AuthContext';
import { notifyBeeQueenCredits } from '../../lib/admin-events';
import { CONNECTOR_COMING_SOON } from '../../lib/features';
import type { BeekiriCodePageDoc } from './document';
import { Field, Section, Segmented, SelectField, Switch, TextArea, TextField } from './inspector/controls';
import { MediaPicker, useMediaItem } from './inspector/MediaPicker';
import {
  DESC_MAX,
  DESC_MIN,
  SEO_SCHEMA_TYPES,
  TITLE_MAX,
  contentFacts,
  effectiveDescription,
  renderedFacts,
  seoSpots,
  applyTextFix,
  type ContentFacts,
  effectiveTitle,
  runSeoChecks,
  seoScore,
  type CheckStatus,
  type PageSeo,
  type SeoCheck,
} from './seo';
import './inspector/inspector.css';
import './seo-panel.css';

type Props = {
  seo: PageSeo;
  onChange: (seo: PageSeo) => void;
  title: string;
  slug: string;
  excerpt: string;
  /** Full public URL prefix, e.g. https://site.com/ or https://site.com/blog/ */
  urlPrefix: string;
  featuredImageId: string | null;
  doc: BeekiriCodePageDoc;
  isPublished: boolean;
  /** Jump to the Page settings modal (excerpt / featured image live there too). */
  onOpenSettings?: () => void;
  /** Apply a Beekiri fix to the page (one undo step). Without it, fixes show as advice only. */
  onDocChange?: (doc: BeekiriCodePageDoc) => void;
  onSlugChange?: (slug: string) => void;
};

/** An edit Beekiri proposes for the page (see the API's SeoFix). */
type SeoFix =
  | { label: string; type: 'text'; ref: string; text: string }
  | { label: string; type: 'slug'; slug: string }
  | { label: string; type: 'share_image'; mediaId: string };

type FixState = 'open' | 'done' | 'gone';

const GROUPS: { id: SeoCheck['group']; label: string }[] = [
  { id: 'search', label: 'Search appearance' },
  { id: 'content', label: 'Content' },
  { id: 'social', label: 'Social' },
  { id: 'technical', label: 'Technical' },
];

const ROBOTS_ADVANCED = [
  { value: 'noarchive', label: 'No cached copy', hint: 'Hide the “Cached” link in results' },
  { value: 'nosnippet', label: 'No snippet', hint: 'Show only the title in results' },
  { value: 'noimageindex', label: 'Don’t index images', hint: 'Keep images out of image search' },
  { value: 'notranslate', label: 'No translation', hint: 'Don’t offer Google Translate' },
];

function StatusIcon({ status }: { status: CheckStatus }) {
  if (status === 'good') return <CheckCircle size={15} weight="fill" />;
  if (status === 'bad') return <WarningCircle size={15} weight="fill" />;
  if (status === 'warn') return <Warning size={15} weight="fill" />;
  return <Info size={15} weight="fill" />;
}

/** Character counter that turns amber / red around the recommended range. */
function Counter({ n, min, max }: { n: number; min?: number; max: number }) {
  const tone = n === 0 ? '' : n > max ? ' is-over' : min && n < min ? ' is-under' : ' is-ok';
  return (
    <span className={`bk-pseo__count${tone}`}>
      {n}/{max}
    </span>
  );
}

function ShareImage({ value, onChange }: { value: string; onChange: (id: string) => void }) {
  const [open, setOpen] = useState(false);
  const item = useMediaItem(value);
  return (
    <>
      {value ? (
        <div className="bk-acf-media">
          <button type="button" className="bk-acf-media__thumb" onClick={() => setOpen(true)} title="Replace image">
            {item ? <img src={item.url} alt={item.alt} /> : <span className="bk-acf-media__loading">Loading…</span>}
          </button>
          <div className="bk-acf-media__meta">
            <span className="bk-acf-media__name">{item?.originalName ?? value}</span>
            {item?.width ? (
              <span className="bk-acf-media__dim">
                {item.width} × {item.height}
                {item.width < 1200 ? ' · under 1200px wide' : ''}
              </span>
            ) : null}
            <div className="bk-acf-media__actions">
              <button type="button" onClick={() => setOpen(true)}>
                Replace
              </button>
              <button type="button" className="is-danger" onClick={() => onChange('')}>
                Remove
              </button>
            </div>
          </div>
        </div>
      ) : (
        <button type="button" className="bk-acf-media-empty" onClick={() => setOpen(true)}>
          <ImageIcon size={20} />
          <span>Choose share image · 1200 × 630 recommended</span>
        </button>
      )}
      <MediaPicker
        open={open}
        onClose={() => setOpen(false)}
        kind="image"
        title="Share image"
        onSelect={(items) => items[0] && onChange(items[0].id)}
      />
    </>
  );
}

export function SeoPanel({
  seo,
  onChange,
  title,
  slug,
  excerpt,
  urlPrefix,
  featuredImageId,
  doc,
  isPublished,
  onOpenSettings,
  onDocChange,
  onSlugChange,
}: Props) {
  const [siteTitle, setSiteTitle] = useState('');
  const [schemaError, setSchemaError] = useState<string | null>(null);
  const [schemaDraft, setSchemaDraft] = useState(seo.schemaJson);
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({ search: true, content: true, social: true, technical: true });

  useEffect(() => {
    api<{ title?: string }>('/api/site/public')
      .then((s) => setSiteTitle((s.title ?? '').trim()))
      .catch(() => setSiteTitle(''));
  }, []);

  useEffect(() => setSchemaDraft(seo.schemaJson), [seo.schemaJson]);

  const set = (patch: Partial<PageSeo>) => onChange({ ...seo, ...patch });

  /* ── Beekiri (Connector): suggest the search listing ── */
  const auth = useAuth();
  const mayUseBeekiri =
    !CONNECTOR_COMING_SOON && Boolean(auth.user?.isOwner || auth.user?.capabilities.includes('use_beequeen'));
  const [beekiriReady, setBeekiriReady] = useState(false);
  const [aiBusy, setAiBusy] = useState(false);
  const [aiNote, setAiNote] = useState<{ kind: 'done' | 'error'; text: string; tips?: string[] } | null>(null);
  const [fixes, setFixes] = useState<{ fix: SeoFix; state: FixState }[]>([]);
  useEffect(() => {
    if (!mayUseBeekiri) return;
    api<{ available: boolean }>('/api/connector/beequeen/status')
      .then((s) => setBeekiriReady(Boolean(s.available)))
      .catch(() => setBeekiriReady(false));
  }, [mayUseBeekiri]);

  // Counted from what the canvas renders (theme layouts included), like the live page.
  const [rendered, setRendered] = useState<ContentFacts | null>(null);
  useEffect(() => {
    const canvas =
      document.querySelector<HTMLElement>('.bk-beekiricode__frame[data-bp="desktop"] .bk-beekiricode__frame-canvas') ??
      document.querySelector<HTMLElement>('.bk-beekiricode__frame-canvas');
    if (!canvas) {
      setRendered(null);
      return;
    }
    let timer = 0;
    const read = () => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => setRendered(renderedFacts(canvas)), 350);
    };
    read();
    // Layouts render a moment after the document changes.
    const watch = new MutationObserver(read);
    watch.observe(canvas, { subtree: true, childList: true, characterData: true, attributeFilter: ['alt', 'href', 'src'] });
    return () => {
      window.clearTimeout(timer);
      watch.disconnect();
    };
  }, [doc]);
  const facts = useMemo(() => rendered ?? contentFacts(doc), [rendered, doc]);
  const input = useMemo(
    () => ({ seo, title, slug, excerpt, siteTitle, facts, hasFeaturedImage: Boolean(featuredImageId) }),
    [seo, title, slug, excerpt, siteTitle, facts, featuredImageId],
  );
  const checks = useMemo(() => runSeoChecks(input), [input]);
  const score = seoScore(checks);
  const scoreTone = score >= 80 ? 'good' : score >= 50 ? 'warn' : 'bad';
  const counts = {
    bad: checks.filter((c) => c.status === 'bad').length,
    warn: checks.filter((c) => c.status === 'warn').length,
    good: checks.filter((c) => c.status === 'good').length,
  };

  const serpTitle = effectiveTitle(input);
  const serpDesc = effectiveDescription(input) || 'Add a meta description to control this text.';
  const url = `${urlPrefix}${slug}`;
  const displayUrl = url.replace(/^https?:\/\//, '');
  const ogTitle = seo.ogTitle.trim() || seo.metaTitle.trim() || title || 'Untitled';
  const ogDesc = seo.ogDescription.trim() || effectiveDescription(input);
  const shareImage = useMediaItem(seo.ogImageId || featuredImageId || '');

  const commitSchema = (value: string) => {
    const v = value.trim();
    if (!v) {
      setSchemaError(null);
      set({ schemaJson: '' });
      return;
    }
    try {
      const parsed = JSON.parse(v) as unknown;
      if (!parsed || typeof parsed !== 'object') throw new Error('Must be an object or array');
      setSchemaError(null);
      set({ schemaJson: JSON.stringify(parsed, null, 2) });
    } catch (e) {
      setSchemaError(e instanceof Error ? e.message : 'Invalid JSON');
    }
  };

  /** Beekiri writes the keyword, title and description; they save with the page like any edit. */
  const suggest = async () => {
    if (aiBusy) return;
    setAiBusy(true);
    setAiNote(null);
    setFixes([]);
    const canEditPage = Boolean(onDocChange);
    // Photos to choose a share image from — only when the page has none.
    let images: { id: string; name: string; alt: string }[] = [];
    if (!seo.ogImageId && !featuredImageId) {
      try {
        const lib = await api<{ items: { id: string; originalName: string; alt: string; mimeType: string; width: number | null }[] }>('/api/media');
        images = lib.items
          .filter((m) => /^image\/(jpeg|png|webp|avif)$/.test(m.mimeType) && (m.width ?? 0) >= 600)
          .slice(0, 40)
          .map((m) => ({ id: m.id, name: m.originalName.slice(0, 160), alt: (m.alt || '').slice(0, 300) }));
      } catch {
        images = [];
      }
    }
    const headings = [...facts.h1.map((h) => `H1: ${h}`), ...facts.h2.slice(0, 12).map((h) => `H2: ${h}`)].join('\n');
    try {
      const res = await api<{
        focusKeyword: string;
        metaTitle: string;
        metaDescription: string;
        fixes: SeoFix[];
        tips: string[];
        cost: number | null;
        balance: number | null;
      }>('/api/connector/beequeen/seo', {
        method: 'POST',
        json: {
          title: title.slice(0, 300),
          slug: slug.slice(0, 300),
          siteTitle: siteTitle.slice(0, 200),
          keyword: seo.focusKeyword.trim().slice(0, 120),
          metaTitle: seo.metaTitle.slice(0, 300),
          metaDescription: seo.metaDescription.slice(0, 600),
          openChecks: checks
            .filter((c) => c.status === 'bad' || c.status === 'warn')
            .map((c) => `${c.title}: ${c.detail}`.slice(0, 200))
            .slice(0, 30),
          text: `${headings}\n\n${facts.text}`.slice(0, 20_000),
          spots: canEditPage ? seoSpots(doc, facts) : [],
          images,
        },
      });
      const newKeyword = !seo.focusKeyword.trim() && Boolean(res.focusKeyword);
      set({ focusKeyword: res.focusKeyword, metaTitle: res.metaTitle, metaDescription: res.metaDescription });
      setAiNote({
        kind: 'done',
        text: `Beekiri filled in the keyword, title and description below. Check them — they save with the page.${
          newKeyword ? ' The new keyword also turns on the keyword checks, so the score can move until the page uses it.' : ''
        }`,
        tips: res.tips,
      });
      setFixes(res.fixes.map((fix) => ({ fix, state: 'open' as FixState })));
      if (res.cost != null) notifyBeeQueenCredits({ running: false, runCost: res.cost, balance: res.balance ?? undefined });
    } catch (err) {
      setAiNote({ kind: 'error', text: err instanceof ApiError || err instanceof Error ? err.message : 'Beekiri could not help right now.' });
    } finally {
      setAiBusy(false);
    }
  };

  /** Apply fixes in the editor: page texts as one undoable edit, then the slug and share image. */
  const applyFixes = (indexes: number[]) => {
    let next = doc;
    const states = new Map<number, FixState>();
    let seoPatch: Partial<PageSeo> = {};
    for (const i of indexes) {
      const item = fixes[i];
      if (!item || item.state !== 'open') continue;
      const f = item.fix;
      if (f.type === 'text') {
        const changed = applyTextFix(next, f.ref, f.text);
        states.set(i, changed ? 'done' : 'gone');
        if (changed) next = changed;
      } else if (f.type === 'slug') {
        if (onSlugChange) {
          onSlugChange(f.slug);
          states.set(i, 'done');
        }
      } else {
        seoPatch = { ...seoPatch, ogImageId: f.mediaId };
        states.set(i, 'done');
      }
    }
    if (next !== doc) onDocChange?.(next);
    if (Object.keys(seoPatch).length) set(seoPatch);
    setFixes((list) => list.map((item, i) => (states.has(i) ? { ...item, state: states.get(i)! } : item)));
  };
  const openFixes = fixes.map((f, i) => (f.state === 'open' ? i : -1)).filter((i) => i >= 0);

  const jump = (id?: string) => {
    if (!id) return;
    document.querySelector(`[data-seo-section="${id}"]`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="bk-insp bk-pseo" aria-label="SEO">
      {/* ── Score ─────────────────────────────────────────────── */}
      <div className="bk-pseo__score">
        <div className={`bk-pseo__ring is-${scoreTone}`} style={{ ['--p' as string]: `${score}%` }}>
          <strong>{score}</strong>
        </div>
        <div className="bk-pseo__score-text">
          <strong>{score >= 80 ? 'Looking good' : score >= 50 ? 'Needs work' : 'Not ready for search'}</strong>
          <span>
            {counts.bad ? `${counts.bad} to fix` : 'Nothing critical'}
            {counts.warn ? ` · ${counts.warn} to improve` : ''}
            {!isPublished ? ' · draft' : ''}
          </span>
        </div>
        {beekiriReady ? (
          <button
            type="button"
            className={`bk-pseo__ai${counts.bad + counts.warn ? ' is-attention' : ''}${aiBusy ? ' is-busy' : ''}`}
            disabled={aiBusy}
            onClick={() => void suggest()}
            aria-label="Improve the search listing with Beekiri"
            title={
              counts.bad + counts.warn
                ? `Beekiri can write the keyword, title and description to fix the open checks (${counts.bad + counts.warn} open)`
                : 'Ask Beekiri for a fresh keyword, title and description'
            }
          >
            <Sparkle size={15} weight={counts.bad + counts.warn ? 'fill' : 'regular'} aria-hidden />
          </button>
        ) : null}
      </div>
      {aiBusy || aiNote ? (
        <div className={`bk-pseo__ai-note${aiNote?.kind === 'error' ? ' is-error' : ''}`} role="status">
          {aiBusy ? (
            <p>Beekiri is reading the page…</p>
          ) : aiNote ? (
            <>
              <p>{aiNote.text}</p>
              {fixes.length ? (
                <>
                  <div className="bk-pseo__fixes-head">
                    <strong>Fixes for the page</strong>
                    {openFixes.length > 1 ? (
                      <button type="button" className="bk-pseo__fix-btn" onClick={() => applyFixes(openFixes)}>
                        Fix all
                      </button>
                    ) : null}
                  </div>
                  <ul className="bk-pseo__fixes">
                    {fixes.map(({ fix, state }, i) => (
                      <li key={`${fix.type}-${i}`} className={`is-${state}`}>
                        <div>
                          <span>{fix.label}</span>
                          {fix.type === 'text' ? <em>“{fix.text.length > 140 ? `${fix.text.slice(0, 140)}…` : fix.text}”</em> : null}
                          {fix.type === 'slug' ? (
                            <em>
                              New address: /{fix.slug}
                              {isPublished ? ' — links to the old address stop working.' : ''}
                            </em>
                          ) : null}
                          {state === 'gone' ? <em>That part of the page changed — ask Beekiri again.</em> : null}
                        </div>
                        {state === 'open' ? (
                          <button type="button" className="bk-pseo__fix-btn" onClick={() => applyFixes([i])}>
                            Fix
                          </button>
                        ) : state === 'done' ? (
                          <CheckCircle size={16} weight="fill" className="bk-pseo__fix-done" aria-label="Fixed" />
                        ) : null}
                      </li>
                    ))}
                  </ul>
                </>
              ) : null}
              {aiNote.tips?.length ? (
                <>
                  <strong>Also worth doing</strong>
                  <ul>
                    {aiNote.tips.map((t) => (
                      <li key={t}>{t}</li>
                    ))}
                  </ul>
                </>
              ) : null}
            </>
          ) : null}
        </div>
      ) : null}

      {/* ── Search preview ────────────────────────────────────── */}
      <div className="bk-pseo__serp" aria-label="Google result preview">
        <div className="bk-pseo__serp-site">
          <span className="bk-pseo__serp-favicon" aria-hidden>
            {(siteTitle || 'B').slice(0, 1).toUpperCase()}
          </span>
          <span>
            <b>{siteTitle || 'Your site'}</b>
            <i>{displayUrl}</i>
          </span>
        </div>
        <span className={`bk-pseo__serp-title${serpTitle.length > TITLE_MAX ? ' is-long' : ''}`}>{serpTitle}</span>
        <span className={`bk-pseo__serp-desc${seo.metaDescription || excerpt ? '' : ' is-empty'}`}>
          {serpDesc.length > DESC_MAX ? `${serpDesc.slice(0, DESC_MAX).trimEnd()}…` : serpDesc}
        </span>
      </div>

      {/* ── Basics ────────────────────────────────────────────── */}
      <div data-seo-section="basics">
        <Section id="seo-basics" title="Search listing" active={Boolean(seo.metaTitle || seo.metaDescription || seo.focusKeyword)}>
          <Field label="Keyword" wide>
            <TextField
              value={seo.focusKeyword}
              onChange={(v) => set({ focusKeyword: v })}
              placeholder="What should this page rank for? e.g. “wedding photographer leeds”"
              live
            />
          </Field>
          <Field label="Title" wide>
            <div className="bk-pseo__labelled">
              <TextField
                value={seo.metaTitle}
                onChange={(v) => set({ metaTitle: v })}
                placeholder={`${title || 'Page title'} · ${siteTitle || 'Site'}`}
                live
              />
              <Counter n={serpTitle.length} min={30} max={TITLE_MAX} />
            </div>
            <span className="bk-insp-note">
              Leave empty to use “{title || 'Page title'} · {siteTitle || 'Site'}”. Put the keyword near the start.
            </span>
          </Field>
          <Field label="Description" wide>
            <div className="bk-pseo__labelled is-area">
              <TextArea
                value={seo.metaDescription}
                onChange={(v) => set({ metaDescription: v })}
                rows={3}
                placeholder={excerpt.trim() ? `Using the excerpt: ${excerpt.trim().slice(0, 90)}…` : 'One or two sentences that make people click. Include the keyword.'}
              />
              <Counter n={(seo.metaDescription || excerpt).trim().length} min={DESC_MIN} max={DESC_MAX} />
            </div>
            {!seo.metaDescription && onOpenSettings ? (
              <button type="button" className="bk-insp-link-btn" onClick={onOpenSettings}>
                Edit the page excerpt instead →
              </button>
            ) : null}
          </Field>
        </Section>
      </div>

      {/* ── Social ────────────────────────────────────────────── */}
      <div data-seo-section="social">
        <Section
          id="seo-social"
          title="Social sharing"
          defaultOpen={false}
          active={Boolean(seo.ogTitle || seo.ogDescription || seo.ogImageId)}
        >
          <div className={`bk-pseo__card${seo.twitterCard === 'summary' ? ' is-compact' : ''}`} aria-label="Share preview">
            <div className="bk-pseo__card-img">
              {shareImage?.url ? <img src={shareImage.url} alt="" /> : <ImageIcon size={22} />}
            </div>
            <div className="bk-pseo__card-body">
              <span className="bk-pseo__card-host">{displayUrl.split('/')[0]}</span>
              <strong>{ogTitle}</strong>
              <span className="bk-pseo__card-desc">{ogDesc || 'Description shown under the title on Facebook, LinkedIn, Slack…'}</span>
            </div>
          </div>
          <Field label="Image" wide>
            <ShareImage value={seo.ogImageId} onChange={(id) => set({ ogImageId: id })} />
            {!seo.ogImageId && featuredImageId ? <span className="bk-insp-note">Using the featured image.</span> : null}
          </Field>
          <Field label="Title" wide>
            <TextField value={seo.ogTitle} onChange={(v) => set({ ogTitle: v })} placeholder={ogTitle} live />
          </Field>
          <Field label="Text" wide>
            <TextArea value={seo.ogDescription} onChange={(v) => set({ ogDescription: v })} rows={2} placeholder="Defaults to the meta description" />
          </Field>
          <Field label="X card">
            <Segmented
              allowEmpty={false}
              value={seo.twitterCard}
              onChange={(v) => set({ twitterCard: v as PageSeo['twitterCard'] })}
              options={[
                { value: 'summary_large_image', label: 'Large image' },
                { value: 'summary', label: 'Small' },
              ]}
            />
          </Field>
        </Section>
      </div>

      {/* ── Schema ────────────────────────────────────────────── */}
      <div data-seo-section="schema">
        <Section id="seo-schema" title="Structured data" defaultOpen={false} active={seo.schemaType !== 'WebPage' || Boolean(seo.schemaJson) || seo.faq.length > 0}>
          <Field label="Type">
            <SelectField
              value={seo.schemaType}
              onChange={(v) => set({ schemaType: (v || 'WebPage') as PageSeo['schemaType'] })}
              options={SEO_SCHEMA_TYPES.map((t) => ({ value: t.value, label: t.label }))}
            />
          </Field>
          <span className="bk-insp-note">
            {SEO_SCHEMA_TYPES.find((t) => t.value === seo.schemaType)?.hint}. Beekiri writes the JSON-LD (name, description, URL, image, dates, publisher) automatically.
          </span>

          {seo.schemaType === 'FAQPage' || seo.faq.length ? (
            <div className="bk-pseo__faq">
              <div className="bk-insp-subhead">
                <span>Questions &amp; answers</span>
                <button
                  type="button"
                  className="bk-insp-icon-btn"
                  aria-label="Add question"
                  onClick={() => set({ faq: [...seo.faq, { question: '', answer: '' }] })}
                >
                  <Plus size={13} weight="bold" />
                </button>
              </div>
              {seo.faq.length === 0 ? <span className="bk-insp-note">Add the questions answered on this page — Google can show them under your result.</span> : null}
              {seo.faq.map((f, i) => (
                <div key={i} className="bk-insp-list__card">
                  <div className="bk-insp-list__row">
                    <TextField
                      value={f.question}
                      onChange={(v) => set({ faq: seo.faq.map((x, k) => (k === i ? { ...x, question: v } : x)) })}
                      placeholder={`Question ${i + 1}`}
                      live
                    />
                    <button
                      type="button"
                      className="bk-insp-icon-btn is-danger"
                      aria-label="Remove question"
                      onClick={() => set({ faq: seo.faq.filter((_, k) => k !== i) })}
                    >
                      <Trash size={13} />
                    </button>
                  </div>
                  <TextArea
                    value={f.answer}
                    onChange={(v) => set({ faq: seo.faq.map((x, k) => (k === i ? { ...x, answer: v } : x)) })}
                    rows={2}
                    placeholder="Answer"
                  />
                </div>
              ))}
            </div>
          ) : null}

          <Field label="Custom JSON-LD" wide>
            <TextArea
              value={schemaDraft}
              onChange={(v) => {
                setSchemaDraft(v);
                commitSchema(v);
              }}
              rows={6}
              mono
              placeholder={'{\n  "@context": "https://schema.org",\n  "@type": "Product",\n  "name": "…"\n}'}
            />
            {schemaError ? (
              <span className="bk-pseo__error">{schemaError}</span>
            ) : (
              <span className="bk-insp-note">Optional. Added alongside the automatic schema — an object or an array of objects.</span>
            )}
          </Field>
        </Section>
      </div>

      {/* ── Advanced ──────────────────────────────────────────── */}
      <div data-seo-section="advanced">
        <Section
          id="seo-advanced"
          title="Indexing"
          defaultOpen={false}
          active={!seo.robotsIndex || !seo.robotsFollow || seo.robotsAdvanced.length > 0 || Boolean(seo.canonicalUrl) || seo.excludeFromSitemap}
        >
          <Switch checked={seo.robotsIndex} onChange={(v) => set({ robotsIndex: v })} label="Allow search engines to index this page" />
          <Switch checked={seo.robotsFollow} onChange={(v) => set({ robotsFollow: v })} label="Allow search engines to follow links" />
          <Switch checked={!seo.excludeFromSitemap} onChange={(v) => set({ excludeFromSitemap: !v })} label="Include in sitemap.xml" />
          <Field label="Canonical" wide>
            <TextField
              value={seo.canonicalUrl}
              onChange={(v) => set({ canonicalUrl: v.trim() })}
              placeholder={url}
              mono
            />
            <span className="bk-insp-note">Only set this when the same content lives at another URL that should get the credit.</span>
          </Field>
          <Field label="Advanced" wide>
            <div className="bk-pseo__chips">
              {ROBOTS_ADVANCED.map((d) => {
                const on = seo.robotsAdvanced.includes(d.value);
                return (
                  <button
                    key={d.value}
                    type="button"
                    className={`bk-insp-chip${on ? ' is-active' : ''}`}
                    title={d.hint}
                    aria-pressed={on}
                    onClick={() =>
                      set({
                        robotsAdvanced: on
                          ? seo.robotsAdvanced.filter((x) => x !== d.value)
                          : [...seo.robotsAdvanced, d.value],
                      })
                    }
                  >
                    {d.label}
                  </button>
                );
              })}
            </div>
          </Field>
        </Section>
      </div>

      {/* ── Checks ────────────────────────────────────────────── */}
      <div className="bk-pseo__checks">
        <div className="bk-pseo__checks-head">
          <span>Checklist</span>
          <em>
            {counts.good} passed · {counts.warn + counts.bad} open
          </em>
        </div>
        {GROUPS.map((g) => {
          const items = checks.filter((c) => c.group === g.id);
          if (!items.length) return null;
          const open = openGroups[g.id] !== false;
          const worst = items.some((c) => c.status === 'bad') ? 'bad' : items.some((c) => c.status === 'warn') ? 'warn' : 'good';
          return (
            <div key={g.id} className="bk-pseo__group">
              <button
                type="button"
                className="bk-pseo__group-head"
                aria-expanded={open}
                onClick={() => setOpenGroups((o) => ({ ...o, [g.id]: !open }))}
              >
                <span className={`bk-pseo__dot is-${worst}`} aria-hidden />
                <span>{g.label}</span>
                <em>{items.filter((c) => c.status === 'good').length}/{items.filter((c) => c.status !== 'info').length}</em>
                <CaretDown size={12} weight="bold" className={`bk-pseo__caret${open ? ' is-open' : ''}`} />
              </button>
              {open ? (
                <ul className="bk-pseo__list">
                  {items.map((c) => (
                    <li key={c.id} className={`is-${c.status}`}>
                      <span className="bk-pseo__list-icon">
                        <StatusIcon status={c.status} />
                      </span>
                      <div className="bk-pseo__list-text">
                        <strong>{c.title}</strong>
                        <span>{c.detail}</span>
                      </div>
                      {c.fix ? (
                        <button type="button" className="bk-pseo__fix" onClick={() => jump(c.fix)}>
                          Fix
                        </button>
                      ) : null}
                    </li>
                  ))}
                </ul>
              ) : null}
            </div>
          );
        })}
      </div>
    </div>
  );
}
