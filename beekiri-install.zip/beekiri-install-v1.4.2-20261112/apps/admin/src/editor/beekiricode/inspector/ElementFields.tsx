import { useCallback, useMemo, useRef, useState } from 'react';
import { ArrowDown, ArrowUp, CaretDown, CaretRight, MagnifyingGlass, Plus, Trash } from '@phosphor-icons/react';
import { ICON_NAMES, type BeekiriCodeItem } from '@beekiri/page-blocks';
import { IconGlyph } from '../ElementPreviews';
import { Popover } from './Popover';
import { TextArea, TextField } from './controls';

/* ── Icon picker ────────────────────────────────────────────────────────── */

/** Other words people search an icon by. */
const ICON_WORDS: Record<string, string> = {
  envelope: 'mail email message',
  'map-pin': 'location address place marker',
  phone: 'call telephone',
  search: 'find magnifying glass',
  gear: 'settings cog',
  house: 'home',
  'x-logo': 'twitter',
  x: 'close cross',
  check: 'tick done',
  'check-circle': 'tick done',
  'check-circle-fill': 'tick done',
  lightning: 'fast bolt energy',
  'shield-check': 'safe secure trust',
  heart: 'love like',
  'heart-fill': 'love like',
  'star-fill': 'rating review',
  user: 'person account profile',
  users: 'people team group',
  'shopping-cart': 'basket shop buy',
  'shopping-bag': 'shop buy',
  dollar: 'money price',
  'credit-card': 'pay payment',
  clock: 'time hours',
  calendar: 'date booking',
  globe: 'world web internet',
  chat: 'message talk comment',
  'chat-text': 'message talk comment',
  quotes: 'testimonial quote',
  mobile: 'phone smartphone',
  desktop: 'computer screen monitor',
  'fork-knife': 'food restaurant eat',
  car: 'auto vehicle',
  airplane: 'travel flight',
  barbell: 'gym fitness',
  'first-aid': 'health medical',
  tooth: 'dentist dental',
  scissors: 'hair salon barber cut',
  leaf: 'eco nature green',
  'graduation-cap': 'school education',
  truck: 'delivery shipping',
  package: 'box delivery parcel',
  lock: 'secure private',
  wrench: 'repair fix tool',
  hammer: 'build tool',
  'paper-plane': 'send',
  'trend-up': 'growth',
  rocket: 'launch start fast',
};

const iconLabel = (name: string) => name.replace(/-fill$/, ' (filled)').replace(/-logo$/, '').replace(/-/g, ' ');

export function IconPicker({ value, onChange }: { value: string; onChange: (name: string) => void }) {
  const anchorRef = useRef<HTMLButtonElement>(null);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const close = useCallback(() => {
    setOpen(false);
    setQuery('');
  }, []);
  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q ? ICON_NAMES.filter((n) => `${n.replace(/-/g, ' ')} ${ICON_WORDS[n] ?? ''}`.includes(q)) : ICON_NAMES;
  }, [query]);

  return (
    <>
      <button ref={anchorRef} type="button" className={`bk-insp-input bk-insp-iconpick${open ? ' is-open' : ''}`} onClick={() => setOpen((o) => !o)}>
        <span className="bk-insp-iconpick__glyph" aria-hidden>
          <IconGlyph name={value} />
        </span>
        <span className="bk-insp-iconpick__name">{value ? iconLabel(value) : 'Choose an icon'}</span>
        <CaretDown size={11} weight="bold" />
      </button>
      <Popover anchorRef={anchorRef} open={open} onClose={close} width={292}>
        <div className="bk-insp-fonts">
          <label className="bk-insp-fonts__search">
            <MagnifyingGlass size={13} />
            <input
              autoFocus
              value={query}
              placeholder={`Search ${ICON_NAMES.length} icons`}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && list[0]) {
                  onChange(list[0]);
                  close();
                }
              }}
            />
          </label>
          {list.length ? (
            <div className="bk-insp-icons" role="listbox" aria-label="Icons">
              {list.map((name) => (
                <button
                  key={name}
                  type="button"
                  role="option"
                  aria-selected={name === value}
                  title={iconLabel(name)}
                  className={`bk-insp-icons__item${name === value ? ' is-active' : ''}`}
                  onClick={() => {
                    onChange(name);
                    close();
                  }}
                >
                  <IconGlyph name={name} />
                </button>
              ))}
            </div>
          ) : (
            <p className="bk-insp-icons__empty">No icon matches “{query.trim()}”.</p>
          )}
        </div>
      </Popover>
    </>
  );
}

/* ── Accordion / Tabs items ─────────────────────────────────────────────── */

const MAX_ITEMS = 40;

/** Title + text rows with add, remove and reorder; one row is open for editing at a time. */
export function ItemsEditor({
  items,
  onChange,
  noun,
}: {
  items: BeekiriCodeItem[];
  onChange: (items: BeekiriCodeItem[]) => void;
  /** What one row is called: "item" (accordion) or "tab". */
  noun: string;
}) {
  const [open, setOpen] = useState<number | null>(0);
  const patch = (i: number, part: Partial<BeekiriCodeItem>) => onChange(items.map((it, n) => (n === i ? { ...it, ...part } : it)));
  const move = (i: number, by: -1 | 1) => {
    const to = i + by;
    if (to < 0 || to >= items.length) return;
    const next = [...items];
    [next[i], next[to]] = [next[to], next[i]];
    onChange(next);
    setOpen((o) => (o === i ? to : o === to ? i : o));
  };
  const remove = (i: number) => {
    onChange(items.filter((_, n) => n !== i));
    setOpen((o) => (o === null || o === i ? null : o > i ? o - 1 : o));
  };
  const add = () => {
    onChange([...items, { title: `New ${noun}`, text: '' }]);
    setOpen(items.length);
  };

  return (
    <div className="bk-acf-rows">
      {items.map((item, i) => {
        const isOpen = open === i;
        return (
          <div key={i} className={`bk-acf-row${isOpen ? ' is-open' : ''}`}>
            <div className="bk-acf-row__head">
              <button type="button" className="bk-acf-row__toggle" aria-expanded={isOpen} onClick={() => setOpen(isOpen ? null : i)}>
                {isOpen ? <CaretDown size={10} weight="bold" /> : <CaretRight size={10} weight="bold" />}
                <span className="bk-acf-row__index">{i + 1}</span>
                <span className="bk-acf-row__title">{item.title || `Untitled ${noun}`}</span>
              </button>
              <button type="button" className="bk-acf-row__btn" title="Move up" aria-label="Move up" disabled={i === 0} onClick={() => move(i, -1)}>
                <ArrowUp size={12} />
              </button>
              <button type="button" className="bk-acf-row__btn" title="Move down" aria-label="Move down" disabled={i === items.length - 1} onClick={() => move(i, 1)}>
                <ArrowDown size={12} />
              </button>
              <button type="button" className="bk-acf-row__btn is-danger" title={`Remove this ${noun}`} aria-label={`Remove this ${noun}`} onClick={() => remove(i)}>
                <Trash size={12} />
              </button>
            </div>
            {isOpen ? (
              <div className="bk-acf-row__body bk-insp-items__body">
                <TextField value={item.title} onChange={(v) => patch(i, { title: v })} placeholder="Title" live />
                <TextArea value={item.text} onChange={(v) => patch(i, { text: v })} rows={4} placeholder="Text" />
              </div>
            ) : null}
          </div>
        );
      })}
      {items.length < MAX_ITEMS ? (
        <button type="button" className="bk-acf-addbtn" onClick={add}>
          <Plus size={12} weight="bold" />
          Add {noun}
        </button>
      ) : null}
    </div>
  );
}
