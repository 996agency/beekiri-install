import { useMemo, useState, type DragEvent } from 'react';
import { Link } from 'react-router-dom';
import { ArrowSquareOut, MagnifyingGlass, PuzzlePiece, Rows, X } from '@phosphor-icons/react';
import { useAdminEntry } from '../../lib/AdminEntryContext';
import { useActiveExtensions } from '../../lib/extensions-state';
import { adminHref } from '../../lib/admin-login';
import type { ThemeLayout, ThemeSection } from './document';
import type { ElementKey } from './elements';
import {
  ELEMENTS,
  ELEMENT_GROUPS,
  ELEMENT_MIME,
  encodePaletteDrag,
  setPaletteDrag,
  type PaletteDrag,
} from './nodeMeta';

type Props = {
  layouts: ThemeLayout[];
  /** GET /api/layouts progress — an empty list only means "none" once it is ready. */
  layoutsStatus: 'loading' | 'ready' | 'error';
  onReloadLayouts: () => void;
  /** Where a click will put the element, e.g. "inside Section". */
  insertHint: string;
  onAddElement: (key: ElementKey) => void;
  onAddLayout: (layout: ThemeLayout) => void;
  /** Ready-made sections of the active theme, inserted with their default content. */
  sections: ThemeSection[];
  onAddSection: (section: ThemeSection) => void;
  /** Editing a Shop page: offer the "Shop content" element. */
  shopPage?: boolean;
};

function startDrag(e: DragEvent, drag: PaletteDrag) {
  e.dataTransfer.setData(ELEMENT_MIME, encodePaletteDrag(drag));
  e.dataTransfer.effectAllowed = 'copy';
  setPaletteDrag(drag);
}

/** Explorer “Add” tab — basic elements, then Layouts: the theme's ready-made sections and Backend Fields layouts. */
export function AddPanel({
  layouts,
  layoutsStatus,
  onReloadLayouts,
  insertHint,
  onAddElement,
  onAddLayout,
  sections,
  onAddSection,
  shopPage = false,
}: Props) {
  const [query, setQuery] = useState('');
  const q = query.trim().toLowerCase();
  const fieldsHref = adminHref(useAdminEntry().basePath, 'fields');
  const activeExtensions = useActiveExtensions();

  const elementGroups = useMemo(
    () =>
      ELEMENT_GROUPS.map((g) => ({
        ...g,
        items: ELEMENTS.filter(
          (el) =>
            el.group === g.id &&
            (!el.shopOnly || shopPage) &&
            (!el.extension || activeExtensions.includes(el.extension)) &&
            (!q || `${el.label} ${el.hint} ${el.keywords ?? ''}`.toLowerCase().includes(q)),
        ),
      })).filter((g) => g.items.length > 0),
    [q, shopPage, activeExtensions],
  );

  const visibleLayouts = useMemo(
    () => layouts.filter((l) => !q || `${l.title} ${l.slug} ${l.key}`.toLowerCase().includes(q)),
    [layouts, q],
  );

  const visibleSections = useMemo(
    () => sections.filter((s) => !q || `${s.title} ${s.description} ${s.key}`.toLowerCase().includes(q)),
    [sections, q],
  );

  const nothing = elementGroups.length === 0 && visibleLayouts.length === 0 && visibleSections.length === 0;

  return (
    <div className="bk-add">
      <label className="bk-add__search">
        <MagnifyingGlass size={14} aria-hidden />
        <input
          type="search"
          value={query}
          placeholder="Search elements, sections and layouts…"
          aria-label="Search elements and layouts"
          onChange={(e) => setQuery(e.target.value)}
        />
        {query ? (
          <button type="button" aria-label="Clear search" onClick={() => setQuery('')}>
            <X size={12} weight="bold" />
          </button>
        ) : null}
      </label>

      <div className="bk-add__scroll">
        {elementGroups.map((g) => (
          <section key={g.id} className="bk-add__group" aria-label={g.label}>
            <h3 className="bk-add__group-title">{g.label}</h3>
            {g.note && !q ? <p className="bk-add__group-note">{g.note}</p> : null}
            <div className="bk-add__grid" role="list">
              {g.items.map((el) => (
                <button
                  key={el.key}
                  type="button"
                  role="listitem"
                  className="bk-add__tile"
                  draggable
                  title={`${el.label} — ${el.hint}. Click to add, or drag onto the page.`}
                  onClick={() => onAddElement(el.key)}
                  onDragStart={(e) => startDrag(e, { kind: 'element', key: el.key })}
                  onDragEnd={() => setPaletteDrag(null)}
                >
                  <span className="bk-add__tile-icon" aria-hidden>
                    <el.Icon size={18} weight="regular" />
                  </span>
                  <span className="bk-add__tile-label">{el.label}</span>
                  <span className="bk-add__tile-hint">{el.hint}</span>
                </button>
              ))}
            </div>
          </section>
        ))}

        {!q || visibleSections.length > 0 || visibleLayouts.length > 0 ? (
          <section className="bk-add__group bk-add__group--layouts" aria-label="Layouts">
            <div className="bk-add__group-head">
              <h3 className="bk-add__group-title">
                Layouts
                {sections.length + layouts.length ? (
                  <span className="bk-add__count">{sections.length + layouts.length}</span>
                ) : null}
              </h3>
              <Link to={fieldsHref} className="bk-add__group-link" title="Manage field layouts in Backend Fields">
                Backend Fields <ArrowSquareOut size={11} aria-hidden />
              </Link>
            </div>
            <p className="bk-add__group-note">
              Ready-made blocks from your theme. They drop in with text and photos you can change.
            </p>
            {visibleSections.length || visibleLayouts.length ? (
              <div className="bk-add__grid" role="list">
                {visibleSections.map((section) => (
                  <button
                    key={`section-${section.key}`}
                    type="button"
                    role="listitem"
                    className="bk-add__tile"
                    draggable
                    title={`${section.title} — ${section.description} Click to add below the current section, or drag onto the page.`}
                    onClick={() => onAddSection(section)}
                    onDragStart={(e) => startDrag(e, { kind: 'section', key: section.key })}
                    onDragEnd={() => setPaletteDrag(null)}
                  >
                    <span className="bk-add__tile-icon" aria-hidden>
                      <Rows size={18} weight="regular" />
                    </span>
                    <span className="bk-add__tile-label">{section.title}</span>
                    <span className="bk-add__tile-hint bk-add__tile-hint--wrap">{section.description}</span>
                  </button>
                ))}
                {visibleLayouts.map((layout) => (
                  <button
                    key={`layout-${layout.slug}`}
                    type="button"
                    role="listitem"
                    className="bk-add__tile"
                    draggable
                    title={`${layout.title} (${layout.slug}) — a Backend Fields layout. Click to add, or drag onto the page.`}
                    onClick={() => onAddLayout(layout)}
                    onDragStart={(e) => startDrag(e, { kind: 'layout', slug: layout.slug })}
                    onDragEnd={() => setPaletteDrag(null)}
                  >
                    <span className="bk-add__tile-icon" aria-hidden>
                      <PuzzlePiece size={18} weight="regular" />
                    </span>
                    <span className="bk-add__tile-label">{layout.title}</span>
                    <span className="bk-add__tile-hint">
                      {layout.fields?.length
                        ? `${layout.fields.length} field${layout.fields.length === 1 ? '' : 's'}`
                        : 'Field layout'}
                    </span>
                  </button>
                ))}
              </div>
            ) : layoutsStatus === 'loading' ? (
              <p className="bk-add__empty">Loading layouts…</p>
            ) : layoutsStatus === 'error' ? (
              <p className="bk-add__empty">
                Couldn’t load the theme layouts.{' '}
                <button type="button" className="bk-add__retry" onClick={onReloadLayouts}>
                  Try again
                </button>
              </p>
            ) : (
              <p className="bk-add__empty">
                No layouts yet. Themes from Templates bring their own, or create a field group in Backend Fields.
              </p>
            )}
          </section>
        ) : null}

        {nothing ? <p className="bk-add__empty">Nothing matches “{query}”.</p> : null}
      </div>

      <p className="bk-add__foot">
        Click adds {insertHint}. Drag to place anywhere in Layers or on the page.
      </p>
    </div>
  );
}
