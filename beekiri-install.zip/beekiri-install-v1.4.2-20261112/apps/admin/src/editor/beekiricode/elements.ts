/** Everything the Add panel can drop onto the page: single elements and ready-made blocks. */

import { createNodeOfType, type BeekiriCodeNode, type BeekiriCodeNodeType, type NodeTree } from './document';
import { fluidSize } from './styleHelpers';

/** Add-panel keys: a node type, or a preset that creates several nodes. */
export type ElementKey =
  | 'section'
  | 'container'
  | 'columns-2'
  | 'columns-3'
  | 'columns-4'
  | 'grid'
  | 'spacer'
  | 'divider'
  | 'heading'
  | 'text'
  | 'button'
  | 'list'
  | 'icon'
  | 'icon-list'
  | 'quote'
  | 'rating'
  | 'image'
  | 'video'
  | 'gallery'
  | 'slider'
  | 'map'
  | 'accordion'
  | 'tabs'
  | 'hero'
  | 'features'
  | 'icon-box'
  | 'image-box'
  | 'card'
  | 'cta'
  | 'testimonial'
  | 'pricing'
  | 'team'
  | 'stats'
  | 'progress'
  | 'alert'
  | 'social'
  | 'shop_content'
  | 'form'
  | 'booking';

type Style = Record<string, string>;

/** One node of a preset, with the nodes inside it. Leaves start from their element's defaults. */
type Spec = Omit<Partial<BeekiriCodeNode>, 'id' | 'type' | 'children'> & {
  type: BeekiriCodeNodeType;
  kids?: Spec[];
};

const BOX: BeekiriCodeNodeType[] = ['section', 'container'];

function build(spec: Spec): NodeTree {
  const nodes: Record<string, BeekiriCodeNode> = {};
  const add = ({ kids = [], ...rest }: Spec): string => {
    const base = createNodeOfType(rest.type);
    const node: BeekiriCodeNode = {
      ...base,
      ...rest,
      // Boxes are laid out by the preset alone; leaves keep their defaults (margin 0, line height…).
      style: BOX.includes(rest.type) ? { ...rest.style } : { ...base.style, ...rest.style },
      children: [],
    };
    nodes[node.id] = node;
    node.children = kids.map(add);
    return node.id;
  };
  return { rootId: add(spec), nodes };
}

/* ── Spec shorthands ────────────────────────────────────────────────────── */

/* Colours are only set where a block brings its own background; elsewhere text follows the theme. */
const INK = '#111111';
const MUTED = '#555555';
const LINE = '#E4E4E7';
const SOFT = '#F4F4F5';
const muted: Style = { color: MUTED };
const ink: Style = { color: INK };

const col = (style: Style, kids: Spec[], rest: Partial<Spec> = {}): Spec => ({
  type: 'container',
  tag: 'div',
  style: { display: 'flex', flexDirection: 'column', ...style },
  kids,
  ...rest,
});

const row = (style: Style, kids: Spec[], rest: Partial<Spec> = {}): Spec => ({
  type: 'container',
  tag: 'div',
  style: { display: 'flex', flexDirection: 'row', alignItems: 'center', ...style },
  kids,
  ...rest,
});

const grid = (columns: number, style: Style, kids: Spec[], rest: Partial<Spec> = {}): Spec => ({
  type: 'container',
  tag: 'div',
  style: { display: 'grid', gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`, width: '100%', ...style },
  kids,
  ...rest,
});

const cols = (n: number) => `repeat(${n}, minmax(0, 1fr))`;

const heading = (text: string, tag: string, size: [number, number], style: Style = {}): Spec => ({
  type: 'heading',
  tag,
  text,
  style: { fontSize: fluidSize(size[0], size[1]), ...style },
});

const text = (value: string, style: Style = {}): Spec => ({ type: 'text', tag: 'p', text: value, style });

const button = (label: string, style: Style = {}): Spec => ({ type: 'button', tag: 'a', text: label, href: '#', style: { borderRadius: '8px', ...style } });

const outline: Style = { background: 'transparent', color: INK, borderWidth: '1px', borderStyle: 'solid', borderColor: INK };

const icon = (name: string, size: number, style: Style = {}, rest: Partial<Spec> = {}): Spec => ({
  type: 'icon',
  icon: name,
  style: { fontSize: `${size}px`, ...style },
  ...rest,
});

/** An image slot that keeps its shape while empty. */
const image = (ratio: string, style: Style = {}): Spec => ({
  type: 'image',
  style: { width: '100%', maxWidth: 'none', aspectRatio: ratio, objectFit: 'cover', borderRadius: '8px', ...style },
});

const avatar = (size: number): Spec => ({
  type: 'image',
  style: { width: `${size}px`, maxWidth: 'none', height: `${size}px`, aspectRatio: '1 / 1', objectFit: 'cover', borderRadius: '999px', flexShrink: '0' },
});

const checkRow = (label: string, colors: Style = {}): Spec =>
  row({ gap: '10px' }, [icon('check-circle-fill', 20, { flexShrink: '0', ...colors }), text(label, colors)], { label: 'List item' });

const iconBox = (name: string, title: string): Spec =>
  col(
    { gap: '12px', alignItems: 'flex-start' },
    [
      row({ justifyContent: 'center', width: '48px', height: '48px', borderRadius: '12px', background: SOFT }, [icon(name, 24, ink)], { label: 'Icon' }),
      heading(title, 'h3', [20, 20]),
      text('Say what this is about in a sentence or two.'),
    ],
    { label: 'Icon box' },
  );

const stat = (value: string, label: string): Spec =>
  col({ gap: '4px', alignItems: 'center' }, [heading(value, 'h3', [36, 48], { textAlign: 'center' }), text(label, { textAlign: 'center' })], { label: 'Stat' });

const socialRow = (size: number): Spec =>
  row(
    { gap: '14px' },
    ['facebook', 'instagram', 'linkedin', 'youtube'].map((name) => icon(name, size, {}, { href: '#', newTab: true, alt: name[0].toUpperCase() + name.slice(1) })),
    { label: 'Social icons' },
  );

/* ── Presets ────────────────────────────────────────────────────────────── */

/** Equal-width grid that stacks on smaller screens. */
function columns(count: number): Spec {
  const cells: Spec[] = Array.from({ length: count }, () => col({ gap: '12px', minWidth: '0' }, [], { label: 'Column' }));
  return grid(count, { gap: '24px' }, cells, {
    label: 'Columns',
    stylesByBreakpoint: count > 3 ? { tablet: { gridTemplateColumns: cols(2) }, mobile: { gridTemplateColumns: cols(1) } } : { mobile: { gridTemplateColumns: cols(1) } },
  });
}

const PRESETS: Partial<Record<ElementKey, () => Spec>> = {
  'columns-2': () => columns(2),
  'columns-3': () => columns(3),
  'columns-4': () => columns(4),

  grid: () =>
    grid(3, { gap: '24px' }, Array.from({ length: 6 }, () => col({ gap: '12px', minWidth: '0' }, [], { label: 'Cell' })), {
      label: 'Grid',
      stylesByBreakpoint: { tablet: { gridTemplateColumns: cols(2) }, mobile: { gridTemplateColumns: cols(1) } },
    }),

  'icon-list': () => col({ gap: '12px' }, [checkRow('First point'), checkRow('Second point'), checkRow('Third point')], { label: 'Icon list' }),

  quote: () =>
    col(
      { gap: '10px', paddingLeft: '20px', borderLeftWidth: '3px', borderLeftStyle: 'solid', borderLeftColor: 'currentColor' },
      [
        text('“A short quote from a customer or someone you admire goes here.”', { fontSize: fluidSize(18, 22), lineHeight: '1.5', fontStyle: 'italic' }),
        text('— Full name, Company', { fontSize: '14px' }),
      ],
      { label: 'Quote' },
    ),

  gallery: () =>
    grid(3, { gap: '12px' }, Array.from({ length: 6 }, () => image('1 / 1')), {
      label: 'Gallery',
      stylesByBreakpoint: { mobile: { gridTemplateColumns: cols(2), gap: '8px' } },
    }),

  slider: () =>
    row(
      { alignItems: 'stretch', gap: '16px', width: '100%', overflowX: 'auto', scrollSnapType: 'x mandatory', paddingBottom: '8px' },
      Array.from({ length: 4 }, (_, i) =>
        col(
          { gap: '10px', width: '44%', flexShrink: '0', scrollSnapAlign: 'start' },
          [image('4 / 3'), text(`Slide ${i + 1} caption`, { fontSize: '14px' })],
          { label: 'Slide', stylesByBreakpoint: { mobile: { width: '82%' } } },
        ),
      ),
      { label: 'Slider' },
    ),

  hero: () => ({
    type: 'section',
    tag: 'section',
    label: 'Hero',
    style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '20px', padding: '96px 24px', background: SOFT, textAlign: 'center' },
    stylesByBreakpoint: { mobile: { padding: '64px 20px', gap: '16px' } },
    kids: [
      text('Welcome', { fontSize: '14px', fontWeight: '600', letterSpacing: '0.08em', textTransform: 'uppercase', ...muted }),
      heading('A clear headline that says what you do', 'h1', [36, 64], { maxWidth: '820px', lineHeight: '1.1', ...ink }),
      text('One or two sentences that explain who it is for and why it matters.', { fontSize: fluidSize(16, 18), maxWidth: '620px', ...muted }),
      row({ justifyContent: 'center', flexWrap: 'wrap', gap: '12px' }, [button('Get started'), button('Learn more', outline)], { label: 'Buttons' }),
    ],
  }),

  features: () => ({
    type: 'section',
    tag: 'section',
    label: 'Features',
    style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '40px', padding: '72px 24px' },
    stylesByBreakpoint: { mobile: { padding: '48px 20px', gap: '28px' } },
    kids: [
      heading('Why people choose us', 'h2', [30, 48], { textAlign: 'center' }),
      grid(3, { gap: '32px', maxWidth: '1120px' }, [iconBox('lightning', 'Fast'), iconBox('shield-check', 'Reliable'), iconBox('heart', 'Friendly')], {
        label: 'Columns',
        stylesByBreakpoint: { mobile: { gridTemplateColumns: cols(1), gap: '24px' } },
      }),
    ],
  }),

  'icon-box': () => iconBox('lightning', 'Feature title'),

  'image-box': () =>
    col({ gap: '12px', maxWidth: '420px' }, [image('4 / 3'), heading('Title', 'h3', [20, 20]), text('Say what the photo shows in a sentence or two.')], { label: 'Image box' }),

  card: () =>
    col(
      { gap: '0', overflow: 'hidden', maxWidth: '380px', borderWidth: '1px', borderStyle: 'solid', borderColor: LINE, borderRadius: '12px', background: '#ffffff' },
      [
        image('16 / 10', { borderRadius: '0' }),
        col({ gap: '10px', padding: '20px' }, [heading('Card title', 'h3', [20, 20], ink), text('A short description that makes people want to read more.', muted), button('Read more')], { label: 'Card text' }),
      ],
      { label: 'Card' },
    ),

  cta: () => ({
    type: 'section',
    tag: 'section',
    label: 'Call to action',
    style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px', padding: '64px 24px', background: INK, textAlign: 'center' },
    stylesByBreakpoint: { mobile: { padding: '48px 20px' } },
    kids: [
      heading('Ready to get started?', 'h2', [30, 48], { color: '#ffffff' }),
      text('Tell people what happens when they press the button.', { color: 'rgba(255, 255, 255, 0.75)', maxWidth: '560px' }),
      button('Contact us', { background: '#ffffff', color: INK }),
    ],
  }),

  testimonial: () =>
    col(
      { gap: '16px', maxWidth: '560px', padding: '28px', borderWidth: '1px', borderStyle: 'solid', borderColor: LINE, borderRadius: '12px', background: '#ffffff' },
      [
        { type: 'rating', rating: 5, style: { fontSize: '18px' } },
        text('“They were quick, friendly and did exactly what they promised. I would recommend them to anyone.”', { fontSize: '18px', lineHeight: '1.6', color: INK }),
        row({ gap: '12px' }, [avatar(48), col({ gap: '2px' }, [text('Full name', { fontSize: '15px', fontWeight: '600', ...ink }), text('Role, Company', { fontSize: '14px', ...muted })], { label: 'Name' })], { label: 'Author' }),
      ],
      { label: 'Testimonial' },
    ),

  pricing: () =>
    col(
      { gap: '18px', maxWidth: '360px', padding: '32px', borderWidth: '1px', borderStyle: 'solid', borderColor: LINE, borderRadius: '12px', background: '#ffffff' },
      [
        text('Standard', { fontSize: '14px', fontWeight: '600', letterSpacing: '0.06em', textTransform: 'uppercase', ...muted }),
        row({ alignItems: 'baseline', gap: '6px' }, [heading('$29', 'h3', [40, 48], ink), text('/ month', muted)], { label: 'Price' }),
        text('Everything a small team needs to get going.', muted),
        { type: 'divider' },
        col({ gap: '12px' }, [checkRow('First thing included', ink), checkRow('Second thing included', ink), checkRow('Third thing included', ink)], { label: 'Icon list' }),
        button('Choose plan', { width: '100%' }),
      ],
      { label: 'Pricing' },
    ),

  team: () =>
    col(
      { gap: '10px', alignItems: 'center', maxWidth: '280px' },
      [avatar(120), heading('Full name', 'h3', [20, 20], { textAlign: 'center' }), text('Role', { textAlign: 'center' }), socialRow(20)],
      { label: 'Team member' },
    ),

  stats: () =>
    grid(3, { gap: '24px' }, [stat('120+', 'Happy clients'), stat('15', 'Years of experience'), stat('98%', 'Would recommend us')], {
      label: 'Stats',
      stylesByBreakpoint: { mobile: { gridTemplateColumns: cols(1) } },
    }),

  progress: () =>
    col(
      { gap: '8px', width: '100%' },
      [
        row({ justifyContent: 'space-between', gap: '12px' }, [text('Skill or goal', { fontWeight: '600' }), text('80%')], { label: 'Label' }),
        {
          type: 'container',
          tag: 'div',
          label: 'Track',
          style: { display: 'block', width: '100%', height: '8px', overflow: 'hidden', borderRadius: '999px', background: 'rgba(127, 127, 127, 0.25)' },
          kids: [{ type: 'container', tag: 'div', label: 'Bar', style: { display: 'block', width: '80%', height: '100%', borderRadius: '999px', background: 'currentColor' } }],
        },
      ],
      { label: 'Progress bar' },
    ),

  alert: () =>
    row(
      { alignItems: 'flex-start', gap: '12px', padding: '16px 18px', borderRadius: '8px', background: '#EEF6FB', borderWidth: '1px', borderStyle: 'solid', borderColor: '#C7E0EE' },
      [
        icon('info', 22, { color: '#006199', flexShrink: '0' }),
        col({ gap: '2px' }, [text('Good to know', { fontWeight: '600', ...ink }), text('A short note people should not miss.', { color: '#333333' })], { label: 'Text' }),
      ],
      { label: 'Notice' },
    ),

  social: () => socialRow(26),
};

/** A detached tree for an Add-panel key, ready to insert into the page. */
export function createElement(key: ElementKey): NodeTree {
  const preset = PRESETS[key];
  if (preset) return build(preset());
  const node = createNodeOfType(key as BeekiriCodeNodeType);
  return { rootId: node.id, nodes: { [node.id]: node } };
}
