/** Helpers for reading/writing CSS-ish style bags on BeekiriCode nodes. */

export type StyleBag = Record<string, string>;

const SIDE_KEYS = ['Top', 'Right', 'Bottom', 'Left'] as const;

export function readStyle(style: StyleBag | undefined, key: string): string {
  if (!style) return '';
  const v = style[key];
  return typeof v === 'string' ? v : '';
}

export function patchStyle(
  style: StyleBag | undefined,
  patch: Record<string, string | undefined>,
): StyleBag {
  const next: StyleBag = { ...(style ?? {}) };
  for (const [k, v] of Object.entries(patch)) {
    if (v === undefined || v === '') delete next[k];
    else next[k] = v;
  }
  return next;
}

/** A text size that grows from a 390px phone to a 1440px desktop; one size when both ends match. */
export const fluidSize = (min: number, max: number) =>
  min === max ? `${max}px` : `clamp(${min}px, calc(${min}px + ${max - min} * ((100vw - 390px) / 1050)), ${max}px)`;

/** Expand CSS padding/margin shorthand into four sides (not the raw string). */
export function expandBoxShorthand(value: string): {
  Top: string;
  Right: string;
  Bottom: string;
  Left: string;
} {
  const parts = value.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) {
    return { Top: '', Right: '', Bottom: '', Left: '' };
  }
  if (parts.length === 1) {
    const a = parts[0];
    return { Top: a, Right: a, Bottom: a, Left: a };
  }
  if (parts.length === 2) {
    const [v, h] = parts;
    return { Top: v, Right: h, Bottom: v, Left: h };
  }
  if (parts.length === 3) {
    const [t, h, b] = parts;
    return { Top: t, Right: h, Bottom: b, Left: h };
  }
  const [t, r, b, l] = parts;
  return { Top: t, Right: r, Bottom: b, Left: l };
}

/** Prefer longhands; fall back to the matching side from shorthand. */
export function readBoxSide(
  style: StyleBag | undefined,
  box: 'padding' | 'margin',
  side: 'Top' | 'Right' | 'Bottom' | 'Left',
): string {
  const long = readStyle(style, `${box}${side}`);
  if (long) return long;
  const shorthand = readStyle(style, box);
  if (!shorthand) return '';
  return expandBoxShorthand(shorthand)[side];
}

export function writeBoxSide(
  style: StyleBag | undefined,
  box: 'padding' | 'margin',
  side: 'Top' | 'Right' | 'Bottom' | 'Left',
  value: string,
): StyleBag {
  // Expand shorthand into real per-side values once the user edits a side.
  let next = { ...(style ?? {}) };
  const shorthand = next[box];
  if (shorthand) {
    const sides = expandBoxShorthand(shorthand);
    for (const s of SIDE_KEYS) {
      const key = `${box}${s}`;
      if (!next[key]) next[key] = sides[s];
    }
    delete next[box];
  }
  const key = `${box}${side}`;
  if (!value) delete next[key];
  else next[key] = value;
  return next;
}

export function writeBoxAll(
  style: StyleBag | undefined,
  box: 'padding' | 'margin',
  value: string,
): StyleBag {
  let next = { ...(style ?? {}) };
  delete next[box];
  for (const s of SIDE_KEYS) {
    const key = `${box}${s}`;
    if (!value) delete next[key];
    else next[key] = value;
  }
  return next;
}

export function countSetKeys(style: StyleBag | undefined, keys: string[]): number {
  if (!style) return 0;
  return keys.filter((k) => {
    if (k === 'padding' || k === 'margin') {
      return (
        Boolean(style[k]) ||
        SIDE_KEYS.some((s) => Boolean(style[`${k}${s}`]))
      );
    }
    return Boolean(style[k]);
  }).length;
}

export const LAYOUT_KEYS = [
  'display',
  'flexDirection',
  'flexWrap',
  'alignItems',
  'justifyContent',
  'justifyItems',
  'gap',
  'rowGap',
  'columnGap',
  'gridTemplateColumns',
  'gridTemplateRows',
];

export const SPACING_KEYS = [
  'padding',
  'paddingTop',
  'paddingRight',
  'paddingBottom',
  'paddingLeft',
  'margin',
  'marginTop',
  'marginRight',
  'marginBottom',
  'marginLeft',
];

export const SIZE_KEYS = [
  'width',
  'height',
  'minWidth',
  'maxWidth',
  'minHeight',
  'maxHeight',
  'aspectRatio',
  'boxSizing',
  'overflow',
];

export const TYPE_KEYS = [
  'fontFamily',
  'fontSize',
  'fontWeight',
  'fontStyle',
  'lineHeight',
  'letterSpacing',
  'textAlign',
  'textTransform',
  'textDecoration',
  'color',
];

export const BG_KEYS = [
  'background',
  'backgroundColor',
  'backgroundImage',
  'backgroundSize',
  'backgroundPosition',
  'backgroundRepeat',
  'backgroundAttachment',
];

export const BORDER_KEYS = [
  'border',
  'borderWidth',
  'borderStyle',
  'borderColor',
  'borderRadius',
  'borderTopLeftRadius',
  'borderTopRightRadius',
  'borderBottomRightRadius',
  'borderBottomLeftRadius',
];

export const EFFECT_KEYS = ['opacity', 'boxShadow', 'filter', 'transform', 'cursor'];

/** How an element behaves inside its flex / grid parent. */
export const CHILD_KEYS = [
  'flexGrow',
  'flexShrink',
  'flexBasis',
  'alignSelf',
  'justifySelf',
  'order',
  'gridColumn',
  'gridRow',
];
