/**
 * Theme layout CSS, made to respond to the canvas frame instead of the browser window.
 *
 * On the website the window is the screen, so `@media (min-width: …)` and `vw` follow the
 * device. On the canvas all frames (desktop, tablet, mobile) share one window, so the same rules
 * would give every frame the desktop layout. Each frame canvas is a size container named
 * `bk-frame`; here width media queries become container queries on it and `vw` becomes `cqw`,
 * so every frame shows what that device shows on the site. The website keeps the original CSS.
 */

export const FRAME_CONTAINER = 'bk-frame';

/** A width feature in any syntax: (min-width: 760px), (width >= 600px), (600px <= width <= 900px). */
const WIDTH_FEATURE = /^\((?:[^()]*[\s:<>=])?(?:min-|max-)?width\b/i;
const MEDIA_TYPE = /^(?:only\s+)?(?:screen|all)$/i;

/** One media query ("screen and (min-width: 760px)") → its width part, or null if it can't apply here. */
function widthCondition(query: string): { width: string; other: string } | null {
  const parts = query.split(/\s+and\s+/i).map((p) => p.trim()).filter(Boolean);
  const width: string[] = [];
  const other: string[] = [];
  for (const part of parts) {
    if (MEDIA_TYPE.test(part)) continue;
    if (/^(?:only\s+)?print$/i.test(part) || /^not\b/i.test(part)) return null;
    if (WIDTH_FEATURE.test(part)) width.push(part);
    else other.push(part);
  }
  return { width: width.join(' and '), other: other.join(' and ') };
}

/** `@media` prelude → the at-rule(s) to open on the canvas, or null to keep the media query as it is. */
function convertPrelude(prelude: string): { open: string; close: string } | null {
  // Print-only queries never apply on screen, so they drop out of a list.
  const conditions = prelude
    .split(',')
    .map((q) => q.trim())
    .filter(Boolean)
    .map(widthCondition)
    .filter((c): c is { width: string; other: string } => c !== null);
  if (!conditions.some((c) => c.width)) return null; // no width in it: the window decides (e.g. prefers-reduced-motion)
  // A list mixing in other features (hover, orientation…): too ambiguous, keep the query.
  if (conditions.length > 1 && conditions.some((c) => c.other || !c.width)) return null;
  if (conditions.length > 1) {
    const either = conditions.map((c) => (/\sand\s/i.test(c.width) ? `(${c.width})` : c.width)).join(' or ');
    return { open: `@container ${FRAME_CONTAINER} ${either}{`, close: '}' };
  }
  const only = conditions[0];
  const container = `@container ${FRAME_CONTAINER} ${only.width}{`;
  // Non-width features still ask the window (e.g. hover); nest the container query inside them.
  return only.other ? { open: `@media ${only.other}{${container}`, close: '}}' } : { open: container, close: '}' };
}

/** Index of the `}` that closes the block whose `{` is at `open`. */
function blockEnd(css: string, open: number): number {
  let depth = 0;
  let quote = '';
  for (let i = open; i < css.length; i++) {
    const ch = css[i];
    if (quote) {
      if (ch === '\\') i++;
      else if (ch === quote) quote = '';
      continue;
    }
    if (ch === '"' || ch === "'") quote = ch;
    else if (ch === '/' && css[i + 1] === '*') {
      const end = css.indexOf('*/', i + 2);
      i = end < 0 ? css.length : end + 1;
    } else if (ch === '{') depth++;
    else if (ch === '}' && --depth === 0) return i;
  }
  return css.length - 1;
}

function convertMedia(css: string): string {
  let out = '';
  let i = 0;
  for (;;) {
    const at = css.slice(i).search(/@media\b/i);
    if (at < 0) return out + css.slice(i);
    const start = i + at;
    const brace = css.indexOf('{', start);
    if (brace < 0) return out + css.slice(i);
    const end = blockEnd(css, brace);
    const prelude = css.slice(start + 6, brace).trim();
    const inner = convertMedia(css.slice(brace + 1, end));
    const converted = convertPrelude(prelude);
    out += css.slice(i, start) + (converted ? `${converted.open}${inner}${converted.close}` : `@media ${prelude}{${inner}}`);
    i = end + 1;
  }
}

/** `vw` = the device width on the site = the frame width (`cqw`) on the canvas. */
function convertUnits(css: string): string {
  return css.replace(/(\d*\.?\d+)vw\b/g, '$1cqw');
}

/** Relative `url(...)` in a stylesheet now inlined in the page: make it absolute to where the file lives. */
function absoluteUrls(css: string, base: string): string {
  return css.replace(/url\(\s*(['"]?)(?!data:|https?:|\/\/|#)([^'")]+)\1\s*\)/g, (whole, q: string, path: string) => {
    try {
      return `url(${q}${new URL(path, base).href}${q})`;
    } catch {
      return whole;
    }
  });
}

/** The frame canvas plays the page: site-wide rules (:root, html, body, a…) apply inside it only. */
export const FRAME_SCOPE = '.bk-beekiricode__frame-canvas';

/** Split a selector list on its top-level commas (not the ones inside :is(…), :not(…)…). */
function splitSelectors(list: string): string[] {
  const out: string[] = [];
  let depth = 0;
  let start = 0;
  for (let i = 0; i < list.length; i++) {
    const ch = list[i];
    if (ch === '(' || ch === '[') depth++;
    else if (ch === ')' || ch === ']') depth--;
    else if (ch === ',' && depth === 0) {
      out.push(list.slice(start, i));
      start = i + 1;
    }
  }
  out.push(list.slice(start));
  return out.map((s) => s.trim()).filter(Boolean);
}

/** End of the compound selector starting at `from` (stops at whitespace or a combinator outside brackets). */
function compoundEnd(selector: string, from: number): number {
  let depth = 0;
  let quote = '';
  for (let i = from; i < selector.length; i++) {
    const ch = selector[i];
    if (quote) {
      if (ch === quote) quote = '';
      continue;
    }
    if (ch === '"' || ch === "'") quote = ch;
    else if (ch === '(' || ch === '[') depth++;
    else if (ch === ')' || ch === ']') depth--;
    else if (depth === 0 && /[\s>+~]/.test(ch)) return i;
  }
  return selector.length;
}

/** The frame as an ancestor adds no specificity, so site rules compete with layout CSS as on the site. */
const FRAME_ANCESTOR = `:where(${FRAME_SCOPE})`;

/**
 * `:root` / `html` and `body` are the page; on the canvas the frame is. Their qualifiers move to
 * the frame: `html[data-theme='x'] body:not(…) .a` → `<frame>[data-theme='x']:not(…) .a`.
 */
function scopeSelector(selector: string, inContainer = false): string {
  let rest = selector.trim();
  let quals = '';
  let page = false;
  for (const root of [/^(?::root|html)(?![\w-])/i, /^body(?![\w-])/i]) {
    const m = rest.match(root);
    if (!m) continue;
    const end = compoundEnd(rest, m[0].length);
    quals += rest.slice(m[0].length, end);
    rest = rest.slice(end).trimStart();
    page = true;
  }
  if (!page) return `${FRAME_ANCESTOR} ${rest}`;
  // A combinator left over after `body` (`body > .a`) still reads from the frame.
  if (rest) return `${FRAME_ANCESTOR}${quals} ${rest}`;
  // Inside a container query the frame can't style itself (it is the container): its content can.
  return inContainer ? `${FRAME_SCOPE}${quals} > *` : `${FRAME_SCOPE}${quals}`;
}

/** Every style rule limited to the canvas frames, through @media / @container / @supports / @layer. */
function scopeRules(css: string, inContainer = false): string {
  let out = '';
  let i = 0;
  while (i < css.length) {
    const brace = css.indexOf('{', i);
    if (brace < 0) return out + css.slice(i);
    // Statements before the block (e.g. @charset/@import …;) stay as they are.
    const lastSemi = css.lastIndexOf(';', brace);
    const lastClose = css.lastIndexOf('}', brace);
    const from = Math.max(i, lastSemi + 1, lastClose + 1);
    out += css.slice(i, from);
    const prelude = css.slice(from, brace).trim();
    const end = blockEnd(css, brace);
    const body = css.slice(brace + 1, end);
    if (prelude.startsWith('@')) {
      const nested = /^@(?:media|container|supports|layer|document)\b/i.test(prelude);
      const container = inContainer || /^@container\b/i.test(prelude);
      out += `${prelude}{${nested ? scopeRules(body, container) : body}}`;
    } else {
      out += `${splitSelectors(prelude).map((sel) => scopeSelector(sel, inContainer)).join(',')}{${body}}`;
    }
    i = end + 1;
  }
  return out;
}

/**
 * The stylesheet without its comments (strings are left alone). A comment in front of a rule
 * would otherwise count as part of its selector: `/* note *\/ :root { --bk-fg… }` was scoped as
 * a descendant of the frame, matched nothing, and the canvas lost the site's colours and font.
 */
function stripComments(css: string): string {
  let out = '';
  let quote = '';
  for (let i = 0; i < css.length; i++) {
    const ch = css[i];
    if (quote) {
      out += ch;
      if (ch === '\\') out += css[++i] ?? '';
      else if (ch === quote) quote = '';
    } else if (ch === '"' || ch === "'") {
      quote = ch;
      out += ch;
    } else if (ch === '/' && css[i + 1] === '*') {
      const end = css.indexOf('*/', i + 2);
      i = end < 0 ? css.length : end + 1;
      out += ' ';
    } else {
      out += ch;
    }
  }
  return out;
}

export function toFrameCss(raw: string, sourceUrl?: string, options: { scope?: boolean } = {}): string {
  const css = stripComments(raw);
  const rebased = sourceUrl ? absoluteUrls(css, new URL(sourceUrl, window.location.href).href) : css;
  const framed = convertUnits(convertMedia(rebased));
  return options.scope ? scopeRules(framed) : framed;
}
