import type { BeekiriCodePageDoc } from './document';

/** Mirror of apps/api/src/lib/pages/page-seo.ts. */
export const SEO_SCHEMA_TYPES = [
  { value: 'WebPage', label: 'Web page', hint: 'Default for most pages' },
  { value: 'Article', label: 'Article', hint: 'Long-form content' },
  { value: 'BlogPosting', label: 'Blog post', hint: 'Posts and news on a blog' },
  { value: 'NewsArticle', label: 'News article', hint: 'Time-sensitive reporting' },
  { value: 'Product', label: 'Product', hint: 'A product or service page' },
  { value: 'FAQPage', label: 'FAQ page', hint: 'Shows questions in search' },
  { value: 'AboutPage', label: 'About page', hint: 'About the organisation' },
  { value: 'ContactPage', label: 'Contact page', hint: 'Contact details' },
  { value: 'Organization', label: 'Organization', hint: 'Company home page' },
  { value: 'LocalBusiness', label: 'Local business', hint: 'Shop, office, venue' },
  { value: 'Event', label: 'Event', hint: 'Dated event page' },
  { value: 'none', label: 'None', hint: 'No automatic schema' },
] as const;

export type SeoSchemaType = (typeof SEO_SCHEMA_TYPES)[number]['value'];

export type PageSeo = {
  focusKeyword: string;
  metaTitle: string;
  metaDescription: string;
  canonicalUrl: string;
  robotsIndex: boolean;
  robotsFollow: boolean;
  robotsAdvanced: string[];
  excludeFromSitemap: boolean;
  ogTitle: string;
  ogDescription: string;
  ogImageId: string;
  twitterCard: 'summary_large_image' | 'summary';
  schemaType: SeoSchemaType;
  schemaJson: string;
  faq: { question: string; answer: string }[];
};

export const EMPTY_SEO: PageSeo = {
  focusKeyword: '',
  metaTitle: '',
  metaDescription: '',
  canonicalUrl: '',
  robotsIndex: true,
  robotsFollow: true,
  robotsAdvanced: [],
  excludeFromSitemap: false,
  ogTitle: '',
  ogDescription: '',
  ogImageId: '',
  twitterCard: 'summary_large_image',
  schemaType: 'WebPage',
  schemaJson: '',
  faq: [],
};

export function parseSeo(raw: unknown): PageSeo {
  if (!raw || typeof raw !== 'object') return { ...EMPTY_SEO };
  const o = raw as Partial<PageSeo>;
  return {
    ...EMPTY_SEO,
    ...o,
    robotsAdvanced: Array.isArray(o.robotsAdvanced) ? o.robotsAdvanced : [],
    faq: Array.isArray(o.faq) ? o.faq : [],
    schemaType: SEO_SCHEMA_TYPES.some((t) => t.value === o.schemaType) ? (o.schemaType as SeoSchemaType) : 'WebPage',
  };
}

export const isDefaultSeo = (seo: PageSeo) => JSON.stringify(seo) === JSON.stringify(EMPTY_SEO);

/* ── Content facts used by the checks ───────────────────────────────────── */

export type ContentFacts = {
  words: number;
  h1: string[];
  h2: string[];
  firstParagraph: string;
  text: string;
  images: number;
  imagesMissingAlt: number;
  links: number;
  internalLinks: number;
  externalLinks: number;
  sentences: number;
};

export function contentFacts(doc: BeekiriCodePageDoc | null | undefined): ContentFacts {
  const facts: ContentFacts = {
    words: 0,
    h1: [],
    h2: [],
    firstParagraph: '',
    text: '',
    images: 0,
    imagesMissingAlt: 0,
    links: 0,
    internalLinks: 0,
    externalLinks: 0,
    sentences: 0,
  };
  if (!doc?.nodes) return facts;
  const chunks: string[] = [];
  const walk = (id: string) => {
    const n = doc.nodes[id];
    if (!n) return;
    const text = (n.text || '').trim();
    if (n.type === 'heading') {
      if ((n.tag || 'h2') === 'h1') facts.h1.push(text);
      else if ((n.tag || 'h2') === 'h2') facts.h2.push(text);
    }
    if (n.type === 'text' && text && !facts.firstParagraph) facts.firstParagraph = text;
    if (text && n.type !== 'button') chunks.push(text);
    if (n.type === 'image') {
      facts.images += 1;
      if (!(n.alt || '').trim()) facts.imagesMissingAlt += 1;
    }
    if (n.type === 'button' && n.href && n.href !== '#') {
      facts.links += 1;
      if (/^https?:\/\//i.test(n.href)) facts.externalLinks += 1;
      else facts.internalLinks += 1;
    }
    // Theme layouts carry their own copy in field values — count plain strings.
    if (n.type === 'layout' && n.layoutFields) {
      for (const v of Object.values(n.layoutFields)) {
        if (typeof v === 'string' && v.trim() && !/^https?:|^\/|^[\w-]{10,}$/.test(v)) {
          chunks.push(v.replace(/<[^>]+>/g, ' '));
        }
      }
    }
    n.children.forEach(walk);
  };
  walk(doc.rootId);
  facts.text = chunks.join(' ').replace(/\s+/g, ' ').trim();
  facts.words = facts.text ? facts.text.split(/\s+/).length : 0;
  facts.sentences = facts.text ? facts.text.split(/[.!?]+\s/).filter((s) => s.trim()).length : 0;
  return facts;
}

/** Editor-only parts of a canvas frame: never page content. */
const EDITOR_ONLY = '.bk-selchrome, .bk-beekiricode__layout-hint, .is-bp-hidden, script, style, noscript, template';

/**
 * The same facts read from what the canvas renders — theme layouts included (their headings,
 * repeater text, links and photos), which the document alone can't see.
 */
export function renderedFacts(root: HTMLElement): ContentFacts {
  const facts: ContentFacts = {
    words: 0,
    h1: [],
    h2: [],
    firstParagraph: '',
    text: '',
    images: 0,
    imagesMissingAlt: 0,
    links: 0,
    internalLinks: 0,
    externalLinks: 0,
    sentences: 0,
  };
  const content = (el: Element) => !el.closest(EDITOR_ONLY);
  const clean = (s: string | null) => (s || '').replace(/\s+/g, ' ').trim();
  const all = <T extends Element>(sel: string) => Array.from(root.querySelectorAll<T>(sel)).filter(content);

  facts.h1 = all('h1').map((h) => clean(h.textContent)).filter(Boolean);
  facts.h2 = all('h2').map((h) => clean(h.textContent)).filter(Boolean);
  facts.firstParagraph = all('p').map((p) => clean(p.textContent)).find(Boolean) ?? '';
  for (const img of all<HTMLImageElement>('img')) {
    if (img.getAttribute('aria-hidden') === 'true' || img.getAttribute('role') === 'presentation') continue;
    facts.images += 1;
    if (!clean(img.getAttribute('alt'))) facts.imagesMissingAlt += 1;
  }
  for (const a of all<HTMLAnchorElement>('a[href]')) {
    const href = a.getAttribute('href') || '';
    if (!href || href.startsWith('#')) continue;
    facts.links += 1;
    if (/^https?:\/\//i.test(href)) {
      if (new URL(href, window.location.href).host === window.location.host) facts.internalLinks += 1;
      else facts.externalLinks += 1;
    } else if (!/^(mailto|tel|javascript):/i.test(href)) facts.internalLinks += 1;
  }

  // Text node by node, so words in neighbouring elements don't run together.
  const chunks: string[] = [];
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    const parent = node.parentElement;
    const text = clean(node.textContent);
    if (text && parent && content(parent) && !parent.closest('a.bk-button, button')) chunks.push(text);
  }
  facts.text = chunks.join(' ').replace(/\s+/g, ' ').trim();
  facts.words = facts.text ? facts.text.split(/\s+/).length : 0;
  facts.sentences = facts.text ? facts.text.split(/[.!?]+\s/).filter((s) => s.trim()).length : 0;
  return facts;
}

/* ── Checks ─────────────────────────────────────────────────────────────── */

export type CheckStatus = 'good' | 'warn' | 'bad' | 'info';

export type SeoCheck = {
  id: string;
  group: 'search' | 'content' | 'social' | 'technical';
  status: CheckStatus;
  title: string;
  detail: string;
  /** Where in the panel this is fixed (section id). */
  fix?: string;
};

export type SeoInput = {
  seo: PageSeo;
  title: string;
  slug: string;
  excerpt: string;
  siteTitle: string;
  facts: ContentFacts;
  hasFeaturedImage: boolean;
};

export const TITLE_MAX = 60;
export const DESC_MIN = 120;
export const DESC_MAX = 160;

export function effectiveTitle(input: Pick<SeoInput, 'seo' | 'title' | 'siteTitle'>): string {
  const custom = input.seo.metaTitle.trim();
  if (custom) return custom;
  const base = input.title.trim() || 'Untitled';
  return input.siteTitle ? `${base} · ${input.siteTitle}` : base;
}

export function effectiveDescription(input: Pick<SeoInput, 'seo' | 'excerpt' | 'facts'>): string {
  return input.seo.metaDescription.trim() || input.excerpt.trim() || input.facts.firstParagraph.slice(0, 200);
}

/** Loose stem: "photographer" ~ "photography", "leeds" = "leeds". */
const stem = (w: string) => (w.length > 6 ? w.slice(0, 6) : w.length > 4 ? w.slice(0, 4) : w);
const words = (t: string) => t.toLowerCase().split(/[^\p{L}\p{N}]+/u).filter((w) => w.length > 1);

/** Exact phrase, or every keyword word present (stemmed) — order-independent. */
function has(hay: string, kw: string): boolean {
  if (!kw) return false;
  const h = hay.toLowerCase();
  if (h.includes(kw.toLowerCase())) return true;
  const hw = new Set(words(hay).map(stem));
  const kws = words(kw);
  return kws.length > 0 && kws.every((w) => hw.has(stem(w)));
}

export function runSeoChecks(input: SeoInput): SeoCheck[] {
  const { seo, facts } = input;
  const kw = seo.focusKeyword.trim();
  const title = effectiveTitle(input);
  const description = effectiveDescription(input);
  const checks: SeoCheck[] = [];
  const push = (c: SeoCheck) => checks.push(c);

  // ── Search appearance
  push(
    !title.trim() || title === 'Untitled'
      ? { id: 'title', group: 'search', status: 'bad', title: 'Add a meta title', detail: 'Search engines show this as the blue link.', fix: 'basics' }
      : title.length > TITLE_MAX
        ? { id: 'title', group: 'search', status: 'warn', title: `Title is ${title.length} characters`, detail: `Keep it under ${TITLE_MAX} so it isn't cut off in results.`, fix: 'basics' }
        : title.length < 30
          ? { id: 'title', group: 'search', status: 'warn', title: 'Title is short', detail: 'Titles of 30–60 characters describe the page best.', fix: 'basics' }
          : { id: 'title', group: 'search', status: 'good', title: 'Title length looks good', detail: `${title.length} characters.` },
  );
  push(
    !description
      ? { id: 'desc', group: 'search', status: 'bad', title: 'Add a meta description', detail: 'Without one, Google picks a random snippet from the page.', fix: 'basics' }
      : description.length > DESC_MAX
        ? { id: 'desc', group: 'search', status: 'warn', title: `Description is ${description.length} characters`, detail: `Google truncates around ${DESC_MAX}.`, fix: 'basics' }
        : description.length < DESC_MIN
          ? { id: 'desc', group: 'search', status: 'warn', title: 'Description is short', detail: `Aim for ${DESC_MIN}–${DESC_MAX} characters to fill the snippet.`, fix: 'basics' }
          : { id: 'desc', group: 'search', status: 'good', title: 'Description length looks good', detail: `${description.length} characters.` },
  );
  const slugWords = input.slug.split('-').filter(Boolean).length;
  push(
    !input.slug
      ? { id: 'slug', group: 'search', status: 'warn', title: 'Set a URL slug', detail: 'A readable slug helps users and crawlers.' }
      : /\d{4,}|[A-Z_]/.test(input.slug) || slugWords > 7
        ? { id: 'slug', group: 'search', status: 'warn', title: 'Simplify the URL', detail: 'Short, lowercase, hyphenated slugs with real words rank best.' }
        : { id: 'slug', group: 'search', status: 'good', title: 'URL is readable', detail: `/${input.slug}` },
  );

  // ── Focus keyword
  if (!kw) {
    push({ id: 'kw', group: 'content', status: 'info', title: 'Add a focus keyword', detail: 'The phrase this page should rank for unlocks keyword checks.', fix: 'basics' });
  } else {
    push({ id: 'kw-title', group: 'content', status: has(title, kw) ? 'good' : 'bad', title: has(title, kw) ? 'Keyword in title' : 'Keyword missing from title', detail: `Looking for “${kw}”.`, fix: 'basics' });
    push({ id: 'kw-desc', group: 'content', status: has(description, kw) ? 'good' : 'warn', title: has(description, kw) ? 'Keyword in description' : 'Keyword missing from description', detail: 'Google bolds matching words in the snippet.', fix: 'basics' });
    const slugKw = kw.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    push({ id: 'kw-slug', group: 'content', status: input.slug.includes(slugKw) ? 'good' : 'warn', title: input.slug.includes(slugKw) ? 'Keyword in URL' : 'Keyword not in URL', detail: 'Include it in the slug if it reads naturally.' });
    const inH1 = facts.h1.some((h) => has(h, kw));
    push({ id: 'kw-h1', group: 'content', status: inH1 ? 'good' : facts.h1.length ? 'warn' : 'info', title: inH1 ? 'Keyword in H1' : 'Keyword not in H1', detail: facts.h1.length ? 'Your main heading should say what the page is about.' : 'Add an H1 heading first.' });
    push({ id: 'kw-intro', group: 'content', status: has(facts.firstParagraph, kw) ? 'good' : 'warn', title: has(facts.firstParagraph, kw) ? 'Keyword in the first paragraph' : 'Keyword not in the opening paragraph', detail: 'Mention it early so readers and crawlers confirm relevance.' });
    const occurrences = facts.text ? facts.text.toLowerCase().split(kw.toLowerCase()).length - 1 : 0;
    const density = facts.words ? (occurrences / facts.words) * 100 : 0;
    push(
      occurrences === 0
        ? { id: 'kw-density', group: 'content', status: 'warn', title: 'Keyword not used in the body', detail: 'Use it 2–5 times in natural sentences.' }
        : density > 3
          ? { id: 'kw-density', group: 'content', status: 'warn', title: 'Keyword used too often', detail: `${occurrences}× (${density.toFixed(1)}%). Over ~3% reads as stuffing.` }
          : { id: 'kw-density', group: 'content', status: 'good', title: 'Keyword used naturally', detail: `${occurrences}× in ${facts.words} words.` },
    );
  }

  // ── Content
  push(
    facts.words < 50
      ? { id: 'words', group: 'content', status: 'bad', title: 'Very little text on the page', detail: `${facts.words} words. Thin pages rarely rank — aim for 300+.` }
      : facts.words < 300
        ? { id: 'words', group: 'content', status: 'warn', title: `${facts.words} words`, detail: 'Pages with 300+ words give search engines more to work with.' }
        : { id: 'words', group: 'content', status: 'good', title: `${facts.words} words of content`, detail: 'Good depth for a page.' },
  );
  push(
    facts.h1.length === 1
      ? { id: 'h1', group: 'content', status: 'good', title: 'Exactly one H1', detail: facts.h1[0] ?? '' }
      : facts.h1.length === 0
        ? { id: 'h1', group: 'content', status: 'bad', title: 'No H1 heading', detail: 'Add one heading set to H1 in Props → Content → Level.' }
        : { id: 'h1', group: 'content', status: 'warn', title: `${facts.h1.length} H1 headings`, detail: 'Keep a single H1; use H2–H3 for sections.' },
  );
  if (facts.words > 250) {
    push(
      facts.h2.length
        ? { id: 'h2', group: 'content', status: 'good', title: `${facts.h2.length} subheadings`, detail: 'Subheadings make long pages scannable.' }
        : { id: 'h2', group: 'content', status: 'warn', title: 'No subheadings', detail: 'Break long text up with H2 headings.' },
    );
  }
  if (facts.images) {
    push(
      facts.imagesMissingAlt
        ? { id: 'alt', group: 'content', status: 'bad', title: `${facts.imagesMissingAlt} image${facts.imagesMissingAlt === 1 ? '' : 's'} without alt text`, detail: 'Alt text is read by screen readers and image search (Props → Content → Alt text).' }
        : { id: 'alt', group: 'content', status: 'good', title: 'All images have alt text', detail: `${facts.images} image${facts.images === 1 ? '' : 's'}.` },
    );
  } else {
    push({ id: 'alt', group: 'content', status: 'info', title: 'No images on the page', detail: 'A relevant image with alt text helps engagement and image search.' });
  }
  push(
    facts.internalLinks
      ? { id: 'links', group: 'content', status: 'good', title: `${facts.internalLinks} internal link${facts.internalLinks === 1 ? '' : 's'}`, detail: 'Internal links spread authority and keep visitors on the site.' }
      : { id: 'links', group: 'content', status: 'warn', title: 'No internal links', detail: 'Link to at least one related page with a Button element.' },
  );
  if (facts.sentences > 3) {
    const avg = facts.words / facts.sentences;
    push(
      avg > 25
        ? { id: 'read', group: 'content', status: 'warn', title: 'Long sentences', detail: `Average ${avg.toFixed(0)} words per sentence — under 20 reads easier.` }
        : { id: 'read', group: 'content', status: 'good', title: 'Easy to read', detail: `Average ${avg.toFixed(0)} words per sentence.` },
    );
  }

  // ── Social
  const social = Boolean(seo.ogImageId) || input.hasFeaturedImage;
  push(
    social
      ? { id: 'og-img', group: 'social', status: 'good', title: 'Share image set', detail: seo.ogImageId ? 'Custom social image.' : 'Falls back to the featured image.' }
      : { id: 'og-img', group: 'social', status: 'warn', title: 'No share image', detail: 'Links without an image get far fewer clicks on social media.', fix: 'social' },
  );

  // ── Technical
  if (!seo.robotsIndex) push({ id: 'noindex', group: 'technical', status: 'warn', title: 'Page is set to noindex', detail: 'It will not appear in search results.', fix: 'advanced' });
  else push({ id: 'index', group: 'technical', status: 'good', title: 'Indexable', detail: 'Search engines may list this page.' });
  if (seo.canonicalUrl.trim() && !/^https?:\/\//i.test(seo.canonicalUrl.trim())) {
    push({ id: 'canonical', group: 'technical', status: 'bad', title: 'Canonical URL must be absolute', detail: 'Use the full https:// address.', fix: 'advanced' });
  }
  push(
    seo.schemaType === 'none' && !seo.schemaJson.trim()
      ? { id: 'schema', group: 'technical', status: 'info', title: 'No structured data', detail: 'A schema type gives Google rich-result eligibility.', fix: 'schema' }
      : { id: 'schema', group: 'technical', status: 'good', title: `Structured data: ${seo.schemaType === 'none' ? 'custom' : seo.schemaType}`, detail: 'JSON-LD is added to the page head.' },
  );
  if (seo.schemaType === 'FAQPage' && !seo.faq.length) {
    push({ id: 'faq', group: 'technical', status: 'warn', title: 'FAQ page has no questions', detail: 'Add question / answer pairs in Schema.', fix: 'schema' });
  }
  return checks;
}

/** 0–100 from the checks: bad = 0, warn = half, good = full; info ignored. */
export function seoScore(checks: SeoCheck[]): number {
  const scored = checks.filter((c) => c.status !== 'info');
  if (!scored.length) return 0;
  const pts = scored.reduce((s, c) => s + (c.status === 'good' ? 1 : c.status === 'warn' ? 0.5 : 0), 0);
  return Math.round((pts / scored.length) * 100);
}

/* ── Beekiri fixes: texts it may rewrite, and applying a rewrite ─────────── */

export type SeoSpot = { ref: string; where: string; text: string };

/** Field values that are text a visitor reads (not links, ids, colours or HTML). */
const isCopy = (v: string) => v.trim().length >= 3 && !/<[a-z][^>]*>/i.test(v) && !/^(https?:|\/|#|[\w-]{10,}$)/.test(v.trim());

/**
 * The texts on the page a fix may rewrite: plain headings and paragraphs (ref = node id) and
 * theme layout fields (ref = "nodeId#path", e.g. "lay_1#items.2.answer"). `facts` marks which
 * one is the page's H1 / an H2, since a layout field doesn't say how it is printed.
 */
export function seoSpots(doc: BeekiriCodePageDoc, facts: Pick<ContentFacts, 'h1' | 'h2' | 'firstParagraph'>): SeoSpot[] {
  const spots: SeoSpot[] = [];
  const norm = (s: string) => s.replace(/\[\/?color[^\]]*\]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
  const h1 = new Set(facts.h1.map(norm));
  const h2 = new Set(facts.h2.map(norm));
  const opening = norm(facts.firstParagraph);
  const role = (text: string) =>
    h1.has(norm(text)) ? ' (the page’s H1)' : h2.has(norm(text)) ? ' (an H2)' : opening && norm(text) === opening ? ' (the opening paragraph)' : '';
  const fields = (value: unknown, path: string, where: string, ref: string, depth: number) => {
    if (spots.length >= 150 || depth > 3) return;
    if (typeof value === 'string') {
      if (isCopy(value)) spots.push({ ref: `${ref}#${path}`, where: `${where} → ${path}${role(value)}`, text: value.slice(0, 1200) });
    } else if (Array.isArray(value)) {
      value.forEach((v, i) => fields(v, `${path}.${i}`, where, ref, depth + 1));
    } else if (value && typeof value === 'object') {
      for (const [k, v] of Object.entries(value)) fields(v, path ? `${path}.${k}` : k, where, ref, depth + 1);
    }
  };
  const walk = (id: string) => {
    const n = doc.nodes[id];
    if (!n || spots.length >= 150) return;
    const text = (n.text || '').trim();
    if ((n.type === 'heading' || n.type === 'text') && text) {
      const where = n.type === 'heading' ? `${(n.tag || 'h2').toUpperCase()} heading` : 'Paragraph';
      spots.push({ ref: n.id, where: `${where}${n.label ? ` “${n.label}”` : ''}${role(text)}`, text: text.slice(0, 1200) });
    }
    if (n.type === 'layout' && n.layoutFields) fields(n.layoutFields, '', n.layoutTitle || n.layoutSlug || 'Layout', n.id, 0);
    n.children.forEach(walk);
  };
  walk(doc.rootId);
  return spots;
}

/** The page with one spot's text replaced, or null when that spot is gone (the page changed). */
export function applyTextFix(doc: BeekiriCodePageDoc, ref: string, text: string): BeekiriCodePageDoc | null {
  const [id, path] = ref.split('#');
  const node = doc.nodes[id];
  if (!node) return null;
  if (!path) {
    if (node.type !== 'heading' && node.type !== 'text') return null;
    return { ...doc, nodes: { ...doc.nodes, [id]: { ...node, text } } };
  }
  if (node.type !== 'layout' || !node.layoutFields) return null;
  const fields = structuredClone(node.layoutFields) as Record<string, unknown>;
  const keys = path.split('.');
  let at: Record<string, unknown> | unknown[] = fields;
  for (const key of keys.slice(0, -1)) {
    const next = (at as Record<string, unknown>)[key];
    if (!next || typeof next !== 'object') return null;
    at = next as Record<string, unknown>;
  }
  const last = keys[keys.length - 1];
  if (typeof (at as Record<string, unknown>)[last] !== 'string') return null;
  (at as Record<string, unknown>)[last] = text;
  return { ...doc, nodes: { ...doc.nodes, [id]: { ...node, layoutFields: fields } } };
}
