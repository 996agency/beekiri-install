import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type DragEvent,
  type JSX,
  type MouseEvent,
  type ReactNode,
} from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowSquareOut,
  ArrowUUpLeft,
  ArrowUUpRight,
  CaretDown,
  CircleNotch,
  CloudArrowUp,
  Cursor,
  Desktop,
  DeviceMobile,
  DeviceTablet,
  Eye,
  GearSix,
  MagnifyingGlass,
  MagnifyingGlassMinus,
  MagnifyingGlassPlus,
  CornersOut,
  Plus,
  SquaresFour,
  X,
} from '@phosphor-icons/react';
import {
  applyBindings,
  hoverDeclarations,
  hoverTransition,
  sanitizeDeclarations,
  videoEmbedUrl,
  videoOptions,
  type LoopConfig,
  type LoopItem,
} from '@beekiri/page-blocks';
import { api, apiUrl } from '../../api/client';
import { useAuth } from '../../auth/AuthContext';
import { CreditsToolbar } from '../../components/CreditsToolbar';
import { gsap } from 'gsap';
import {
  askBeekiriAboutSection,
  BEEKIRI_AGENT_ACTIVITY,
  BEEKIRI_CHAT_OPENED,
  followBeekiriSelection,
  notifyBeekiriEditorReady,
  BEEKIRI_SECTION_PREVIEW,
  BEEKIRI_SECTION_SNAPSHOT,
  BEEKIRI_SELECT_NODE,
  BEEKIRI_SECTION_UPDATE,
  CONNECTOR_CHANGED,
  type BeekiriAgentActivity,
  type BeekiriSectionPreviewDetail,
  type BeekiriSectionSnapshotDetail,
  type BeekiriSelectNode,
  type BeekiriSectionUpdateDetail,
} from '../../lib/admin-events';
import { CONNECTOR_COMING_SOON } from '../../lib/features';
import { SHOPPING_EXTENSION, useActiveExtensions } from '../../lib/extensions-state';
import {
  canAcceptChildren,
  createLayoutNode,
  duplicateNode,
  findParentId,
  insertTree,
  copyTree,
  isBeekiriCodeDoc,
  moveNode,
  parseBeekiriCodeDoc,
  pruneMissingLayouts,
  removeNode,
  replaceSubtree,
  shiftNode,
  stripLayoutChromeStyles,
  subtreeOf,
  type BeekiriCodeNode,
  type BeekiriCodePageDoc,
  type MovePosition,
  type NodeTree,
  type ThemeLayout,
  type ThemeSection,
} from './document';
import { createElement, type ElementKey } from './elements';
import { AccordionPreview, IconPreview, MapPreview, RatingPreview, TabsPreview } from './ElementPreviews';
import { AddPanel } from './AddPanel';
import { BeekiriCursor, changedParts, playBeekiriVisits } from './BeekiriCursor';
import { CanvasViewport, ZOOM_MAX, ZOOM_MIN, type ViewportApi } from './CanvasViewport';
import { LayersTree } from './LayersTree';
import { LayoutPhpPreview } from './LayoutPhpPreview';
import { safeHref } from '../../lib/safe-html';
import { FrameLayoutStyles, FrameSiteBase, preloadFrameCss } from './FrameLayoutStyles';
import { FormPreview } from './FormPreview';
import { SelectionChrome } from './SelectionChrome';
import { SeoPanel } from './SeoPanel';
import type { SpacingFocus } from './inspector/BoxModel';
import { editorDomToMarkup, editorOffset, inlineToEditorHtml, renderInline } from './inline-markup';
import {
  ELEMENT_MIME,
  TYPE_META,
  decodePaletteDrag,
  getPaletteDrag,
  nodeName,
  type PaletteDrag,
} from './nodeMeta';
import {
  EditorPresenceProvider,
  PeerAvatarStack,
  RemoteCursors,
  useEditorPresence,
} from './EditorPresence';
import { PageSettingsPanel } from './PageSettingsPanel';
import { PropertiesPanel } from './PropertiesPanel';
import { collectDocumentColors } from './inspector/css-values';
import {
  editTargetForViewMode,
  frameStyle,
  frameUnits,
  resolveStyleForBreakpoint,
} from './responsiveStyles';
import './beekiricode.css';
import { initialValue, typeDef } from '../../fields/acf-types';
import { usePageEditorChrome } from '../PageEditorChrome';

const BREAKPOINTS = [
  { id: 'desktop', label: 'Desktop', width: 1520, Icon: Desktop },
  { id: 'tablet', label: 'Tablet', width: 768, Icon: DeviceTablet },
  { id: 'mobile', label: 'Mobile', width: 375, Icon: DeviceMobile },
] as const;

type BreakpointId = (typeof BREAKPOINTS)[number]['id'];
type ExplorerTab = 'layers' | 'add' | 'properties' | 'page-settings' | 'seo';
type CanvasMode = 'select' | 'preview';
type ViewMode = 'multi' | BreakpointId;
type CanvasDrop = { id: string; position: MovePosition } | null;

const HISTORY_LIMIT = 100;
/** Edits closer together than this (typing, slider drags) share one undo step. */
const HISTORY_COALESCE_MS = 600;

const treeOf = (node: BeekiriCodeNode): NodeTree => ({ rootId: node.id, nodes: { [node.id]: node } });

/** An empty box styled to be seen as-is: a photo, fill, outline, fixed size or overlay. */
function isShapedBox(style: Record<string, unknown>): boolean {
  const has = (k: string) => typeof style[k] === 'string' && (style[k] as string).trim() !== '' && style[k] !== 'none';
  return (
    has('backgroundImage') ||
    (has('background') && !/^(transparent|none|initial|inherit)$/i.test(String(style.background).trim())) ||
    (has('backgroundColor') && !/^transparent$/i.test(String(style.backgroundColor).trim())) ||
    has('border') ||
    has('borderTop') ||
    has('borderBottom') ||
    has('borderLeft') ||
    has('borderRight') ||
    has('height') ||
    has('aspectRatio') ||
    style.position === 'absolute'
  );
}

const isMac = typeof navigator !== 'undefined' && /Mac|iPhone|iPad/.test(navigator.platform);
const MOD = isMac ? '⌘' : 'Ctrl';

const EXPLORER_TABS: { id: ExplorerTab; label: string; title: string }[] = [
  { id: 'layers', label: 'Layers', title: 'Page structure' },
  { id: 'add', label: 'Add', title: 'Elements and theme layouts' },
  { id: 'properties', label: 'Props', title: 'Properties of the selected element' },
  { id: 'page-settings', label: 'Page', title: 'Taxonomies and page settings' },
  { id: 'seo', label: 'SEO', title: 'Search, social and structured data' },
];

/** Items of a dynamic-content box, cached per query so retyping a filter doesn't refetch. */
const loopItemsCache = new Map<string, Promise<LoopItem[]>>();
function fetchLoopItems(loop: LoopConfig): Promise<LoopItem[]> {
  const key = JSON.stringify(loop);
  const hit = loopItemsCache.get(key);
  if (hit) return hit;
  if (loopItemsCache.size > 40) loopItemsCache.clear();
  const p = api<{ items: LoopItem[] }>('/api/dynamic/items', { json: { loop } })
    .then((r) => (Array.isArray(r.items) ? r.items : []))
    .catch(() => {
      loopItemsCache.delete(key);
      return [] as LoopItem[];
    });
  loopItemsCache.set(key, p);
  return p;
}

/** The current item and position while a repeating card is drawn. */
type LoopDraw = { item: LoopItem; index: number; copy: boolean };

/** Heading / text / button content is edited in place on the canvas. */
function EditableText({
  tag,
  nodeId,
  nodeType,
  text,
  className,
  style,
  href,
  onCommit,
  onCancel,
  onSelect,
}: {
  tag: keyof JSX.IntrinsicElements;
  nodeId: string;
  nodeType: string;
  text: string;
  className: string;
  style: CSSProperties;
  href?: string;
  onCommit: (text: string) => void;
  onCancel: () => void;
  /** The highlighted words (plain-text offsets), so Props can colour just those. */
  onSelect?: (sel: { start: number; end: number } | null) => void;
}) {
  const ref = useRef<HTMLElement | null>(null);
  const done = useRef(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    // Seed once; React never re-renders children into a live contenteditable.
    el.innerHTML = inlineToEditorHtml(text);
    el.focus();
    const sel = window.getSelection();
    if (sel) {
      const range = document.createRange();
      range.selectNodeContents(el);
      sel.removeAllRanges();
      sel.addRange(range);
    }
    const report = () => {
      const s = window.getSelection();
      if (!s || !s.rangeCount || !el.contains(s.anchorNode)) return;
      const r = s.getRangeAt(0);
      const start = editorOffset(el, r.startContainer, r.startOffset);
      const end = editorOffset(el, r.endContainer, r.endOffset);
      onSelect?.(end > start ? { start, end } : null);
    };
    document.addEventListener('selectionchange', report);
    return () => document.removeEventListener('selectionchange', report);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const finish = (cancel: boolean) => {
    if (done.current) return;
    done.current = true;
    if (cancel) onCancel();
    else onCommit(ref.current ? editorDomToMarkup(ref.current) : '');
  };
  // Typed as an anchor so `href` is accepted; buttons are the only tag that passes one.
  const Tag = tag as 'a';
  return (
    <Tag
      ref={ref as never}
      className={`${className} is-editing`}
      style={style}
      href={href}
      data-node-id={nodeId}
      data-node-type={nodeType}
      contentEditable
      suppressContentEditableWarning
      spellCheck
      onPaste={(e) => {
        // Pasted text only — no formatting from other apps.
        e.preventDefault();
        document.execCommand('insertText', false, e.clipboardData.getData('text/plain'));
      }}
      onClick={(e: MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
      }}
      onBlur={() => finish(false)}
      onKeyDown={(e) => {
        e.stopPropagation();
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          finish(false);
        }
        if (e.key === 'Escape') {
          e.preventDefault();
          finish(true);
        }
      }}
    />
  );
}

/** Reuse/reload one browser tab per page instead of opening extras. */
export function openOrReloadLiveView(href: string, pageId: string) {
  const name = `beekiri-view-${pageId}`;
  const win = window.open(href, name);
  if (!win) return;
  try {
    const next = new URL(href, window.location.href);
    if (win.location.href === 'about:blank') {
      win.location.replace(next.href);
    } else if (
      win.location.origin === next.origin &&
      win.location.pathname === next.pathname &&
      win.location.search === next.search
    ) {
      // Same URL after publish — force reload so updates appear.
      win.location.reload();
    } else {
      win.location.assign(next.href);
    }
    win.focus();
  } catch {
    /* cross-origin: named open() already focused that tab */
    try {
      win.focus();
    } catch {
      /* ignore */
    }
  }
}

/** Beekiri (Claude) in the presence stack while it works on this page. */
function BeekiriPeer({ activity }: { activity: BeekiriAgentActivity }) {
  const ref = useRef<HTMLButtonElement>(null);
  useLayoutEffect(() => {
    if (!ref.current || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const tween = gsap.fromTo(ref.current, { scale: 0.4, autoAlpha: 0 }, { scale: 1, autoAlpha: 1, duration: 0.5, ease: 'back.out(2)' });
    return () => {
      tween.kill();
    };
  }, []);
  const what = activity.label ? `on ${activity.label}` : 'on this site';
  return (
    <button
      ref={ref}
      type="button"
      className="bk-beekiricode__peer-avatar is-beekiri"
      aria-label={`Beekiri (Claude) is working ${what}: ${activity.step ?? ''}`}
    >
      <span className="bk-beekiricode__peer-face is-beekiri" aria-hidden>
        <img src="/admin/connector/claude.svg" alt="" width={15} height={15} draggable={false} />
      </span>
      <span className="bk-beekiricode__peer-tip" role="tooltip">
        <strong>Beekiri (Claude)</strong> {what}
        {activity.step ? <em>{activity.step}…</em> : null}
      </span>
    </button>
  );
}

/** Each element's class on the published page (page-blocks beekiricode-html.ts); layouts bring their own. */
const SITE_CLASS: Partial<Record<string, string>> = {
  section: 'bk-section',
  container: 'bk-container',
  heading: 'bk-heading',
  text: 'bk-text',
  button: 'bk-button',
  list: 'bk-list',
  image: 'bk-image',
  video: 'bk-video',
  form: 'bk-form-wrap',
  divider: 'bk-divider',
  spacer: 'bk-spacer',
  icon: 'bk-icon',
  accordion: 'bk-accordion',
  tabs: 'bk-tabs',
  map: 'bk-map',
  rating: 'bk-rating',
};

/** Longest side of a section preview Beekiri looks at (enough to judge a design, small to send). */
const PREVIEW_MAX_WIDTH = 1280;
const PREVIEW_MAX_HEIGHT = 2400;

/** Beekiri's cursor bringing in its latest change (a preview waits for it). */
let landing: Promise<void> | null = null;

/** Picture of one element on the canvas for Beekiri, posted back to the run that asked for it. */
async function sendSectionPreview(detail: BeekiriSectionPreviewDetail) {
  const answer = (body: Record<string, unknown>) =>
    api('/api/connector/agent/preview', { method: 'POST', json: { id: detail.id, ...body } }).catch(() => undefined);
  try {
    const id = CSS.escape(detail.nodeId);
    const find = () =>
      document.querySelector<HTMLElement>(`.bk-beekiricode__frame[data-bp="desktop"] [data-node-id="${id}"]`) ??
      document.querySelector<HTMLElement>(`.bk-beekiricode__frame-canvas [data-node-id="${id}"]`);
    // Let the new version render, finish its landing animation and load its photos first.
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    if (landing) await Promise.race([landing, new Promise((r) => setTimeout(r, 15000))]);
    // Theme layouts render on the server: wait (up to 10s) until each shows its new version.
    for (let waited = 0; waited < 10000; waited += 100) {
      const now = find();
      if (now && !now.querySelector('[data-layout-loading]') && !now.hasAttribute('data-layout-loading')) break;
      await new Promise((r) => setTimeout(r, 100));
    }
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    // Found after the wait: a layout that replaced a plain section is a new element.
    const el = find();
    if (!el) return answer({ error: 'The element is not on the canvas right now.' });
    await Promise.all(
      Array.from(el.querySelectorAll('img')).map((img) => (img.complete ? null : img.decode().catch(() => null))),
    );
    const width = el.offsetWidth;
    const height = el.offsetHeight;
    if (!width || !height) return answer({ error: 'The element has no size on the canvas (hidden or empty).' });
    const pixelRatio = Math.min(1, PREVIEW_MAX_WIDTH / width, PREVIEW_MAX_HEIGHT / height);
    const { toJpeg } = await import('html-to-image');
    // The "Beekiri is working" outline is editor chrome, not part of the design.
    const working = el.hasAttribute('data-beekiri-working');
    el.removeAttribute('data-beekiri-working');
    try {
      const image = await toJpeg(el, { quality: 0.82, pixelRatio, width, height, backgroundColor: '#ffffff' });
      return answer({ image, width, height });
    } finally {
      if (working) el.setAttribute('data-beekiri-working', '');
    }
  } catch (error) {
    return answer({ error: error instanceof Error ? error.message.slice(0, 200) : 'The picture could not be taken.' });
  }
}

type Props = {
  pageId: string;
  /** Content API base, e.g. `/api/pages` or `/api/content/book`. */
  apiBase: string;
  title: string;
  slug?: string;
  /** Public path including prefix (`/about` or `/blog/hello`). */
  publicPath?: string;
  permalinkBase?: string;
  isPublished?: boolean;
  doc: BeekiriCodePageDoc;
  onChange: (doc: BeekiriCodePageDoc) => void;
  busy?: boolean;
  isPublishing?: boolean;
  canPublish?: boolean;
  isDirty?: boolean;
  viewHref?: string | null;
  onSaveDraft: () => void;
  onPublish: () => void;
  onOpenSettings: () => void;
  onPreview?: () => void;
};

function cloneDoc(doc: BeekiriCodePageDoc): BeekiriCodePageDoc {
  return JSON.parse(JSON.stringify(doc)) as BeekiriCodePageDoc;
}

export function BeekiriCodeCanvas(props: Props) {
  return (
    <EditorPresenceProvider pageId={props.pageId}>
      <BeekiriCodeCanvasInner {...props} />
    </EditorPresenceProvider>
  );
}

function BeekiriCodeCanvasInner({
  pageId,
  apiBase,
  slug = '',
  publicPath,
  permalinkBase = '',
  isPublished = false,
  doc,
  onChange,
  busy,
  isPublishing = false,
  canPublish,
  isDirty,
  viewHref = null,
  onSaveDraft,
  onPublish,
  onOpenSettings,
  onPreview,
}: Props) {
  const chrome = usePageEditorChrome();
  const {
    remotePeers,
    reportCursor,
    reportSelection,
    broadcastDoc,
    subscribeRemoteDoc,
  } = useEditorPresence();
  const applyingRemoteRef = useRef(false);
  const docRef = useRef(doc);
  docRef.current = doc;
  const historyRef = useRef<{ past: BeekiriCodePageDoc[]; future: BeekiriCodePageDoc[]; stamp: number }>({
    past: [],
    future: [],
    stamp: 0,
  });
  const [history, setHistory] = useState({ canUndo: false, canRedo: false });
  const syncHistory = () => {
    const h = historyRef.current;
    setHistory({ canUndo: h.past.length > 0, canRedo: h.future.length > 0 });
  };

  /**
   * Apply a doc change. `history: 'coalesce'` is for continuous edits (typing,
   * slider drags) so a burst becomes one undo step; structural changes always
   * get their own step; `false` skips history (mount-time normalisation).
   */
  const commitDoc = useCallback(
    (next: BeekiriCodePageDoc, opts: { history?: boolean | 'coalesce' } = {}) => {
      const prev = docRef.current;
      if (!applyingRemoteRef.current && opts.history !== false && prev !== next) {
        const h = historyRef.current;
        const now = Date.now();
        const merge = opts.history === 'coalesce' && h.past.length > 0 && now - h.stamp < HISTORY_COALESCE_MS;
        if (!merge) {
          h.past.push(prev);
          if (h.past.length > HISTORY_LIMIT) h.past.shift();
        }
        // Only a run of coalescing edits keeps the window open.
        h.stamp = opts.history === 'coalesce' ? now : 0;
        h.future = [];
        syncHistory();
      }
      onChange(next);
      if (!applyingRemoteRef.current) broadcastDoc(next);
    },
    [onChange, broadcastDoc],
  );

  const undo = useCallback(() => {
    const h = historyRef.current;
    const prev = h.past.pop();
    if (!prev) return;
    h.future.push(docRef.current);
    h.stamp = 0;
    syncHistory();
    onChange(prev);
    broadcastDoc(prev);
    setSelectedId((id) => (id && prev.nodes[id] ? id : prev.rootId));
  }, [onChange, broadcastDoc]);

  const redo = useCallback(() => {
    const h = historyRef.current;
    const next = h.future.pop();
    if (!next) return;
    h.past.push(docRef.current);
    h.stamp = 0;
    syncHistory();
    onChange(next);
    broadcastDoc(next);
    setSelectedId((id) => (id && next.nodes[id] ? id : next.rootId));
  }, [onChange, broadcastDoc]);

  useEffect(() => {
    return subscribeRemoteDoc((ev) => {
      if (!isBeekiriCodeDoc(ev.doc)) return;
      const next = parseBeekiriCodeDoc(ev.doc);
      applyingRemoteRef.current = true;
      onChange(next);
      setSelectedId((prev) =>
        prev && next.nodes[prev] ? prev : next.rootId,
      );
      queueMicrotask(() => {
        applyingRemoteRef.current = false;
      });
    });
  }, [subscribeRemoteDoc, onChange]);

  const [selectedId, setSelectedId] = useState<string | null>(doc.rootId);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [explorerTab, setExplorerTab] = useState<ExplorerTab>('layers');
  const [layerQuery, setLayerQuery] = useState('');
  /** Heading / text / button being edited in place on the canvas. */
  const [editingTextId, setEditingTextId] = useState<string | null>(null);
  /** Words highlighted while editing a text element; Props colours only these. */
  const [textSel, setTextSel] = useState<{ nodeId: string; start: number; end: number } | null>(null);
  /** Drop indicator while dragging from the Add panel over the canvas. */
  const [canvasDrop, setCanvasDrop] = useState<CanvasDrop>(null);
  /** Spacing field hovered in Props → padding / margin overlay on the selected element. */
  const [spacingFocus, setSpacingFocus] = useState<SpacingFocus>(null);
  useEffect(() => setSpacingFocus(null), [selectedId, explorerTab]);
  useEffect(() => setTextSel(null), [selectedId]);

  /**
   * The active header/footer stylesheets: the site loads them on every page. The theme slug
   * goes on each frame as `data-theme`, like the site's <html>, so theme rules match there too.
   */
  const [chromeCssUrls, setChromeCssUrls] = useState<string[]>([]);
  const [siteTheme, setSiteTheme] = useState<string | undefined>(undefined);
  useEffect(() => {
    let live = true;
    void Promise.all(
      (['header', 'footer'] as const).map((kind) =>
        api<{ cssUrl: string | null; theme?: string }>(`/api/themes/chrome/${kind}/render`).catch(() => null),
      ),
    ).then((chrome) => {
      if (!live) return;
      setChromeCssUrls(chrome.map((c) => (c?.cssUrl ? apiUrl(c.cssUrl) : null)).filter((u): u is string => Boolean(u)));
      setSiteTheme(chrome.find((c) => c?.theme)?.theme);
    });
    return () => {
      live = false;
    };
  }, []);

  /** Advanced → Custom CSS, scoped to each node the same way the publisher does it. */
  const customCssText = useMemo(
    () =>
      Object.values(doc.nodes)
        .map((n) => {
          const sel = `.bk-beekiricode__frame-canvas [data-node-id="${n.id}"]`;
          const out: string[] = [];
          const decls = frameUnits(sanitizeDeclarations(n.customCss));
          if (decls) out.push(`${sel}{${decls}}`);
          const hover = frameUnits(hoverDeclarations(n.hoverStyle));
          if (hover) {
            const transition = hoverTransition(n.hoverStyle, n.style);
            if (transition) out.push(`${sel}, ${sel} > section{transition:${transition}}`);
            // Inline styles outrank stylesheets — hover must be !important here.
            // Layout nodes paint on the PHP <section> inside the host.
            const important = hover.split(';').map((d) => `${d} !important`).join(';');
            const target = n.type === 'layout' ? `${sel} > section:hover` : `${sel}:hover`;
            out.push(`${target}{${important}}`);
          }
          return out.join('\n');
        })
        .filter(Boolean)
        .join('\n'),
    [doc.nodes],
  );
  const [canvasMode, setCanvasMode] = useState<CanvasMode>('select');
  /** Default: first breakpoint (Desktop 1520) only — closer zoom than multi. */
  const [viewMode, setViewMode] = useState<ViewMode>('desktop');

  /* ── Beekiri (Connector) on one element ─────────────────────────── */
  const auth = useAuth();
  const mayUseBeekiri =
    !CONNECTOR_COMING_SOON && Boolean(auth.user?.isOwner || auth.user?.capabilities.includes('use_beequeen'));
  const [beekiriReady, setBeekiriReady] = useState(false);
  useEffect(() => {
    if (!mayUseBeekiri) return;
    const load = () =>
      api<{ available: boolean }>('/api/connector/beequeen/status')
        .then((s) => setBeekiriReady(Boolean(s.available)))
        .catch(() => setBeekiriReady(false));
    void load();
    window.addEventListener(CONNECTOR_CHANGED, load);
    return () => window.removeEventListener(CONNECTOR_CHANGED, load);
  }, [mayUseBeekiri]);

  /** What Beekiri is doing on this page right now (presence avatar + canvas outline). */
  const [beekiriActivity, setBeekiriActivity] = useState<BeekiriAgentActivity | null>(null);
  useEffect(() => {
    const onActivity = (e: Event) => {
      const d = (e as CustomEvent<BeekiriAgentActivity>).detail;
      if (d.pageId && d.pageId !== pageId) return;
      setBeekiriActivity(d.running ? d : null);
    };
    window.addEventListener(BEEKIRI_AGENT_ACTIVITY, onActivity);
    return () => window.removeEventListener(BEEKIRI_AGENT_ACTIVITY, onActivity);
  }, [pageId]);

  // The element Beekiri works on glows on every frame (an attribute React never touches).
  const workingId = beekiriActivity?.nodeId ?? null;
  useEffect(() => {
    if (!workingId) return;
    const sel = `.bk-beekiricode__frame-canvas [data-node-id="${CSS.escape(workingId)}"]`;
    const els = Array.from(document.querySelectorAll<HTMLElement>(sel));
    els.forEach((el) => el.setAttribute('data-beekiri-working', ''));
    return () => els.forEach((el) => el.removeAttribute('data-beekiri-working'));
  }, [workingId, doc]);

  const viewModeRef = useRef(viewMode);
  viewModeRef.current = viewMode;
  const pageTitleRef = useRef(chrome.title);
  pageTitleRef.current = chrome.title;

  // An open Beekiri chat follows the selection (the page body means the whole site),
  // and picks it up again whenever the chat opens.
  const selectedRef = useRef(selectedId);
  selectedRef.current = selectedId;
  useEffect(() => {
    if (!beekiriReady) return;
    const report = () => {
      const id = selectedRef.current;
      const node = id ? docRef.current.nodes[id] : null;
      const isRoot = id === docRef.current.rootId;
      followBeekiriSelection({ pageId, nodeId: node && !isRoot ? id : null, label: node && !isRoot ? nodeName(node, false) : '' });
    };
    report();
    window.addEventListener(BEEKIRI_CHAT_OPENED, report);
    return () => window.removeEventListener(BEEKIRI_CHAT_OPENED, report);
  }, [selectedId, beekiriReady, pageId]);

  /** Open Beekiri's chat on one element (Props header or the canvas selection bar). */
  const askBeekiri = useCallback(
    (nodeId: string) => {
      const node = docRef.current.nodes[nodeId];
      if (node) askBeekiriAboutSection({ pageId, nodeId, label: nodeName(node, false) });
    },
    [pageId],
  );

  useEffect(() => {
    // The chat asks for the element as it is now, right before each message.
    const onSnapshot = (e: Event) => {
      const detail = (e as CustomEvent<BeekiriSectionSnapshotDetail>).detail;
      if (detail.pageId !== pageId) return;
      const current = docRef.current;
      const tree = subtreeOf(current, detail.nodeId);
      const node = current.nodes[detail.nodeId];
      if (!tree || !node) return;
      detail.scope = {
        pageId,
        nodeId: detail.nodeId,
        label: nodeName(node, false),
        pageTitle: pageTitleRef.current,
        viewport: viewModeRef.current === 'multi' ? 'desktop' : viewModeRef.current,
        tree,
      };
    };
    // Beekiri's new version: one undoable step, saved with the draft like any edit.
    const apply = (detail: BeekiriSectionUpdateDetail) => {
      const before = subtreeOf(docRef.current, detail.nodeId);
      const next = replaceSubtree(docRef.current, detail.nodeId, detail.tree as NodeTree);
      if (!next) return Promise.resolve();
      // Beekiri's cursor visits each changed part and brings it in.
      const visits = changedParts(before, detail.tree as NodeTree);
      commitDoc(next);
      setSelectedId(detail.nodeId);
      return new Promise<void>((resolve) =>
        requestAnimationFrame(() => requestAnimationFrame(() => void playBeekiriVisits(visits).then(resolve))),
      );
    };
    const onUpdate = (e: Event) => {
      const detail = (e as CustomEvent<BeekiriSectionUpdateDetail>).detail;
      if (detail.pageId !== pageId) return;
      detail.accepted = true;
      // A layout Beekiri just made: load the list (and its styles) first, or the canvas would
      // drop the element as a missing layout.
      const known = new Set(themeLayoutsRef.current.map((l) => l.slug));
      const fresh = Object.values((detail.tree as NodeTree).nodes).some(
        (n) => n.type === 'layout' && n.layoutSlug && !known.has(n.layoutSlug),
      );
      const ready = fresh
        ? api<{ layouts: ThemeLayout[] }>('/api/layouts')
            .then(async (res) => {
              const layouts = Array.isArray(res.layouts) ? res.layouts : [];
              await preloadFrameCss(layouts.map((l) => apiUrl(l.cssUrl)));
              themeLayoutsRef.current = layouts;
              setThemeLayouts(layouts);
            })
            .catch(() => undefined)
        : Promise.resolve();
      landing = ready
        .then(() => apply(detail))
        .finally(() => {
          landing = null;
        });
    };
    // Beekiri asks to see the element: a picture of it as the canvas renders it, desktop frame first.
    const onSectionPreview = (e: Event) => {
      const detail = (e as CustomEvent<BeekiriSectionPreviewDetail>).detail;
      if (detail.pageId !== pageId) return;
      void sendSectionPreview(detail);
    };
    // A screenshot dragged over the canvas: select what it shows, so Beekiri works on that element.
    const onSelectNode = (e: Event) => {
      const { nodeId } = (e as CustomEvent<BeekiriSelectNode>).detail;
      if (docRef.current.nodes[nodeId]) setSelectedId(nodeId);
    };
    window.addEventListener(BEEKIRI_SECTION_SNAPSHOT, onSnapshot);
    window.addEventListener(BEEKIRI_SECTION_UPDATE, onUpdate);
    window.addEventListener(BEEKIRI_SECTION_PREVIEW, onSectionPreview);
    window.addEventListener(BEEKIRI_SELECT_NODE, onSelectNode);
    // Changes Beekiri made to this page while it wasn't open here land now.
    notifyBeekiriEditorReady(pageId);
    return () => {
      window.removeEventListener(BEEKIRI_SECTION_SNAPSHOT, onSnapshot);
      window.removeEventListener(BEEKIRI_SECTION_UPDATE, onUpdate);
      window.removeEventListener(BEEKIRI_SECTION_PREVIEW, onSectionPreview);
      window.removeEventListener(BEEKIRI_SELECT_NODE, onSelectNode);
    };
  }, [pageId, commitDoc]);
  const [viewportOpen, setViewportOpen] = useState(false);
  const [publishOpen, setPublishOpen] = useState(false);
  /** Current canvas scale (1 = 100%); owned by the viewport, mirrored here for the UI. */
  const [scale, setScale] = useState(0.55);
  const viewportApi = useRef<ViewportApi | null>(null);
  const [themeLayouts, setThemeLayouts] = useState<ThemeLayout[]>([]);
  const themeLayoutsRef = useRef(themeLayouts);
  themeLayoutsRef.current = themeLayouts;
  /** Edit mode only: ghost-render nodes hidden on the current breakpoint. */
  const [showHidden, setShowHidden] = useState(false);
  const shopActive = useActiveExtensions().includes(SHOPPING_EXTENSION);

  // Dynamic content: live items per repeating box (products, posts, rows), refreshed when a
  // query changes. Typing in the filters is debounced so each keystroke doesn't hit the API.
  const [loopItems, setLoopItems] = useState<Record<string, LoopItem[]>>({});
  const loopSignature = useMemo(
    () =>
      JSON.stringify(
        Object.values(doc.nodes)
          .filter((n) => n.loop && (n.type === 'section' || n.type === 'container'))
          .map((n) => [n.id, n.loop]),
      ),
    [doc.nodes],
  );
  useEffect(() => {
    const loops = JSON.parse(loopSignature) as [string, LoopConfig][];
    if (!loops.length) {
      setLoopItems((m) => (Object.keys(m).length ? {} : m));
      return;
    }
    let cancelled = false;
    const t = setTimeout(() => {
      for (const [id, loop] of loops) {
        fetchLoopItems(loop).then((items) => {
          if (!cancelled) setLoopItems((m) => (m[id] === items ? m : { ...m, [id]: items }));
        });
      }
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [loopSignature]);

  const documentColors = useMemo(
    () =>
      collectDocumentColors(
        Object.values(doc.nodes).flatMap((n) => [
          n.style,
          n.stylesByBreakpoint?.tablet,
          n.stylesByBreakpoint?.mobile,
        ]),
      ),
    [doc.nodes],
  );
  const publishRef = useRef<HTMLDivElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);

  const [layoutsStatus, setLayoutsStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const layoutsReady = layoutsStatus === 'ready';
  const [layoutsFetch, setLayoutsFetch] = useState(0);
  const reloadLayouts = useCallback(() => setLayoutsFetch((n) => n + 1), []);

  useEffect(() => {
    let cancelled = false;
    setLayoutsStatus('loading');
    api<{ layouts: ThemeLayout[] }>('/api/layouts')
      .then((res) => {
        if (cancelled) return;
        setThemeLayouts(Array.isArray(res.layouts) ? res.layouts : []);
        setLayoutsStatus('ready');
      })
      .catch(() => {
        if (cancelled) return;
        // Don't prune on fetch failure — keep existing layout nodes.
        setThemeLayouts([]);
        setLayoutsStatus('error');
      });
    return () => {
      cancelled = true;
    };
  }, [layoutsFetch]);

  // Ready-made sections of the active theme (Add → Theme sections).
  const [themeSections, setThemeSections] = useState<ThemeSection[]>([]);
  useEffect(() => {
    let cancelled = false;
    api<{ sections: ThemeSection[] }>('/api/themes/sections')
      .then((res) => {
        if (!cancelled) setThemeSections(Array.isArray(res.sections) ? res.sections : []);
      })
      .catch(() => {
        if (!cancelled) setThemeSections([]);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Load layout script.js for layouts used on the canvas (same files as the public site).
  useEffect(() => {
    if (typeof document === 'undefined' || !themeLayouts.length) return;
    // Scripts may ask for GSAP or Three.js with Beekiri.use(). The canvas shows sections still, so
    // nothing being edited is hidden or moving: here the request simply never answers.
    const site = window as Window & { Beekiri?: { use: (...names: string[]) => Promise<unknown> } };
    site.Beekiri ??= { use: () => new Promise(() => undefined) };
    const used = new Set(
      Object.values(doc.nodes)
        .filter((n) => n.type === 'layout' && n.layoutSlug)
        .map((n) => n.layoutSlug as string),
    );
    for (const layout of themeLayouts) {
      if (!used.has(layout.slug) || !layout.jsUrl) continue;
      const id = `bk-layout-js-${layout.slug}`;
      if (document.getElementById(id)) continue;
      const script = document.createElement('script');
      script.id = id;
      script.src = apiUrl(layout.jsUrl);
      script.async = true;
      document.body.appendChild(script);
    }
  }, [doc.nodes, themeLayouts]);

  // Drop trashed/missing layouts from the canvas; sync field keys for remaining ones.
  useEffect(() => {
    if (!layoutsReady) return;
    const cleaned = stripLayoutChromeStyles(doc);
    let next = pruneMissingLayouts(
      cleaned,
      themeLayouts.map((l) => l.slug),
    );
    let changed = next !== doc;

    if (themeLayouts.length) {
      if (!changed) next = cloneDoc(next);
      for (const node of Object.values(next.nodes)) {
        if (node.type !== 'layout' || !node.layoutSlug) continue;
        const def = themeLayouts.find((l) => l.slug === node.layoutSlug);
        if (!def?.fields?.length) continue;
        const fields = { ...(node.layoutFields || {}) };
        for (const f of def.fields) {
          if (typeDef(f.type).noValue || f.name in fields) continue;
          fields[f.name] = initialValue(f);
          changed = true;
        }
        node.layoutFields = fields;
        if (def.title && node.layoutTitle !== def.title) {
          node.layoutTitle = def.title;
          changed = true;
        }
      }
    }
    if (changed || next !== doc) commitDoc(next, { history: false });
    // Only on mount / layout defs — not every doc keystroke.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [themeLayouts, layoutsReady]);

  const syncLabel = busy ? 'Saving…' : isDirty ? 'Draft' : 'Draft synced';
  const syncOk = !busy && !isDirty;

  /** Preview forces a single frame; multi only in select mode. */
  const effectiveViewMode: ViewMode =
    canvasMode === 'preview'
      ? viewMode === 'multi'
        ? 'desktop'
        : viewMode
      : viewMode;

  const visibleFrames = useMemo(() => {
    if (effectiveViewMode === 'multi') return [...BREAKPOINTS];
    return BREAKPOINTS.filter((b) => b.id === effectiveViewMode);
  }, [effectiveViewMode]);

  const activeBreakpoint =
    effectiveViewMode === 'multi'
      ? BREAKPOINTS[0]
      : BREAKPOINTS.find((b) => b.id === effectiveViewMode) ?? BREAKPOINTS[0];

  /** multi / desktop → default styles for all; tablet/mobile → overrides only */
  const styleEditTarget = editTargetForViewMode(
    canvasMode === 'preview' && viewMode === 'multi' ? 'desktop' : viewMode,
  );

  const FRAME_GAP = 40;
  const designWidth =
    visibleFrames.reduce((sum, bp) => sum + bp.width, 0) + FRAME_GAP * Math.max(0, visibleFrames.length - 1);
  const zoom = Math.round(scale * 100);

  useEffect(() => {
    const onDoc = (e: Event) => {
      const t = e.target as Node;
      if (publishRef.current && !publishRef.current.contains(t)) setPublishOpen(false);
      if (viewportRef.current && !viewportRef.current.contains(t)) setViewportOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);

  const updateNode = useCallback(
    (id: string, patch: Partial<BeekiriCodeNode>) => {
      const next = cloneDoc(doc);
      const node = next.nodes[id];
      if (!node) return;
      next.nodes[id] = { ...node, ...patch, id: node.id, type: node.type };
      // Property edits arrive per keystroke / slider tick — merge them into one undo step.
      commitDoc(next, { history: 'coalesce' });
    },
    [doc, commitDoc],
  );

  const removeSelected = useCallback(
    (id: string) => {
      if (id === doc.rootId) return;
      const parentId = findParentId(doc, id);
      const next = removeNode(doc, id);
      if (!next) return;
      commitDoc(next);
      setSelectedId(parentId && next.nodes[parentId] ? parentId : next.rootId);
    },
    [doc, commitDoc],
  );

  const moveLayer = useCallback(
    (dragId: string, targetId: string, position: MovePosition) => {
      const next = moveNode(doc, dragId, targetId, position);
      if (!next) return;
      commitDoc(next);
      setSelectedId(dragId);
    },
    [doc, commitDoc],
  );

  const insertTreeAt = useCallback(
    (tree: NodeTree, targetId: string, position: MovePosition) => {
      const next = insertTree(doc, tree, targetId, position);
      if (!next) return;
      commitDoc(next);
      setSelectedId(tree.rootId);
    },
    [doc, commitDoc],
  );

  /** Where a click in the Add panel lands: inside the selected box, else right after the selection. */
  const insertAnchor = useMemo(() => {
    const id = selectedId && doc.nodes[selectedId] ? selectedId : doc.rootId;
    const node = doc.nodes[id];
    const isRoot = id === doc.rootId;
    const position: MovePosition = canAcceptChildren(node, isRoot) ? 'inside' : 'after';
    return { id, position, label: nodeName(node, isRoot) };
  }, [doc, selectedId]);

  const addElement = useCallback(
    (key: ElementKey) => insertTreeAt(createElement(key), insertAnchor.id, insertAnchor.position),
    [insertTreeAt, insertAnchor],
  );

  const addThemeLayout = useCallback(
    (layout: ThemeLayout) =>
      insertTreeAt(treeOf(createLayoutNode(layout)), insertAnchor.id, insertAnchor.position),
    [insertTreeAt, insertAnchor],
  );

  /** Sections are full-width: they go after the page-level block that holds the selection. */
  const addThemeSection = useCallback(
    (section: ThemeSection) => {
      let id = selectedId && doc.nodes[selectedId] ? selectedId : doc.rootId;
      let parent = findParentId(doc, id);
      while (parent && parent !== doc.rootId) {
        id = parent;
        parent = findParentId(doc, id);
      }
      insertTreeAt(copyTree(section.tree), id, id === doc.rootId ? 'inside' : 'after');
    },
    [doc, selectedId, insertTreeAt],
  );

  const dropPalette = useCallback(
    (drag: PaletteDrag, targetId: string, position: MovePosition) => {
      if (drag.kind === 'element') {
        insertTreeAt(createElement(drag.key), targetId, position);
        return;
      }
      if (drag.kind === 'section') {
        const section = themeSections.find((s) => s.key === drag.key);
        if (section) insertTreeAt(copyTree(section.tree), targetId, position);
        return;
      }
      const layout = themeLayouts.find((l) => l.slug === drag.slug);
      if (layout) insertTreeAt(treeOf(createLayoutNode(layout)), targetId, position);
    },
    [insertTreeAt, themeLayouts, themeSections],
  );

  const duplicateSelected = useCallback(
    (id: string) => {
      const next = duplicateNode(doc, id);
      if (!next) return;
      commitDoc(next);
      // The copy sits right after the original.
      const pid = findParentId(next, id);
      const sibs = pid ? next.nodes[pid].children : [];
      const copyId = sibs[sibs.indexOf(id) + 1];
      if (copyId) setSelectedId(copyId);
    },
    [doc, commitDoc],
  );

  const shiftSelected = useCallback(
    (id: string, delta: -1 | 1) => {
      const next = shiftNode(doc, id, delta);
      if (next) commitDoc(next);
    },
    [doc, commitDoc],
  );

  const renameNode = useCallback(
    (id: string, label: string) => updateNode(id, { label: label.trim() || undefined }),
    [updateNode],
  );

  /** Remove several nodes at once (the spare cards when a box starts repeating its first one). */
  const removeNodes = useCallback(
    (ids: string[]) => {
      let next: BeekiriCodePageDoc = doc;
      for (const id of ids) {
        const removed = removeNode(next, id);
        if (removed) next = removed;
      }
      if (next === doc) return;
      commitDoc(next);
      if (selectedId && !next.nodes[selectedId]) setSelectedId(next.rootId);
    },
    [doc, commitDoc, selectedId],
  );

  const selectParent = useCallback(
    (id: string) => {
      const pid = findParentId(doc, id);
      if (pid) setSelectedId(pid);
    },
    [doc],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (
        t &&
        (t.tagName === 'INPUT' ||
          t.tagName === 'TEXTAREA' ||
          t.tagName === 'SELECT' ||
          t.isContentEditable ||
          // Keys pressed in the Beekiri chat never edit the page.
          t.closest('.bk-bee-chat'))
      ) {
        return;
      }
      const mod = e.metaKey || e.ctrlKey;
      const key = e.key.toLowerCase();
      if (mod && key === 'z') {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
        return;
      }
      const hasSel = Boolean(selectedId && selectedId !== doc.rootId);
      if (mod && key === 'd' && hasSel) {
        e.preventDefault();
        duplicateSelected(selectedId as string);
        return;
      }
      if ((e.key === 'Delete' || e.key === 'Backspace') && hasSel) {
        e.preventDefault();
        removeSelected(selectedId as string);
        return;
      }
      if (e.key === 'Escape' && hasSel) {
        e.preventDefault();
        selectParent(selectedId as string);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selectedId, doc.rootId, removeSelected, duplicateSelected, selectParent, undo, redo]);

  /** Canvas click: select and jump to its properties. */
  const selectNode = (id: string) => {
    setSelectedId(id);
    setEditingTextId(null);
    setExplorerTab('properties');
    reportSelection(id);
  };

  /** Layers click: select without leaving the tree. */
  const selectOnly = (id: string) => {
    setSelectedId(id);
    setEditingTextId(null);
    reportSelection(id);
  };

  /** “+” on a selected box or an empty placeholder: pick something to put inside it. */
  const openAddFor = (id: string) => {
    setSelectedId(id);
    setExplorerTab('add');
  };

  useEffect(() => {
    reportSelection(selectedId);
  }, [selectedId, reportSelection]);

  const remotePeerOnNode = useCallback(
    (id: string) => remotePeers.find((p) => p.selectedNodeId === id) ?? null,
    [remotePeers],
  );

  const onFramePointer = useCallback(
    (e: MouseEvent<HTMLDivElement>, frame: BreakpointId) => {
      if (canvasMode !== 'select') return;
      const el = e.currentTarget;
      const rect = el.getBoundingClientRect();
      const scaleX = rect.width / el.offsetWidth || 1;
      const scaleY = rect.height / el.offsetHeight || 1;
      const x = (e.clientX - rect.left) / scaleX;
      const y = (e.clientY - rect.top) / scaleY;
      reportCursor({ x, y, frame });
    },
    [canvasMode, reportCursor],
  );

  const clearFramePointer = useCallback(() => {
    reportCursor(null);
  }, [reportCursor]);

  // A drag that ends anywhere (even outside the window) must clear the indicator.
  useEffect(() => {
    const clear = () => setCanvasDrop(null);
    window.addEventListener('dragend', clear);
    window.addEventListener('drop', clear);
    return () => {
      window.removeEventListener('dragend', clear);
      window.removeEventListener('drop', clear);
    };
  }, []);

  /** Top / bottom edge of a box drops beside it, the middle drops inside; leaves split in half. */
  const dropPositionFor = (node: BeekiriCodeNode, isRoot: boolean, e: DragEvent<Element>): MovePosition => {
    if (isRoot) return 'inside';
    const r = e.currentTarget.getBoundingClientRect();
    const y = (e.clientY - r.top) / Math.max(r.height, 1);
    if (canAcceptChildren(node, false)) return y < 0.2 ? 'before' : y > 0.8 ? 'after' : 'inside';
    return y < 0.5 ? 'before' : 'after';
  };

  const dragHandlers = (id: string, node: BeekiriCodeNode, isRoot: boolean) =>
    canvasMode !== 'select'
      ? {}
      : {
          onDragOver: (e: DragEvent<Element>) => {
            if (!getPaletteDrag()) return;
            e.preventDefault();
            e.stopPropagation();
            e.dataTransfer.dropEffect = 'copy';
            const position = dropPositionFor(node, isRoot, e);
            setCanvasDrop((d) => (d && d.id === id && d.position === position ? d : { id, position }));
          },
          onDragLeave: (e: DragEvent<Element>) => {
            if (e.currentTarget.contains(e.relatedTarget as Node | null)) return;
            setCanvasDrop((d) => (d?.id === id ? null : d));
          },
          onDrop: (e: DragEvent<Element>) => {
            const raw = e.dataTransfer.getData(ELEMENT_MIME);
            const drag = (raw && decodePaletteDrag(raw)) || getPaletteDrag();
            setCanvasDrop(null);
            if (!drag) return;
            e.preventDefault();
            e.stopPropagation();
            dropPalette(drag, id, dropPositionFor(node, isRoot, e));
          },
        };

  const renderNode = (
    id: string,
    frame: 'desktop' | 'tablet' | 'mobile',
    draw?: LoopDraw,
  ): ReactNode => {
    const raw = doc.nodes[id];
    if (!raw) return null;
    // Inside a repeating card the item's values replace the bound text / links / photos.
    const node = draw ? applyBindings(raw, draw.item) : raw;
    // Cards after the first are read-only copies: the template is the one that is edited.
    const copy = Boolean(draw?.copy);
    const interactive = canvasMode === 'select' && !copy;
    const isRoot = id === doc.rootId;
    const hiddenHere = node.hiddenOn?.includes(frame) ?? false;
    if (hiddenHere && !(interactive && showHidden)) return null;
    /** Added by Beekiri on a live page and not kept yet: visitors don't see it. */
    const pending = typeof (raw as { pending?: unknown }).pending === 'string';
    const peerOn = copy ? null : remotePeerOnNode(id);
    const drop = !copy && canvasDrop?.id === id ? canvasDrop.position : null;
    const isBox = canAcceptChildren(node, isRoot);
    const cls = [
      'bk-beekiricode__node',
      !copy && selectedId === id ? 'is-selected' : '',
      peerOn ? 'is-peer-selected' : '',
      !copy && hoveredId === id ? 'is-hovered' : '',
      hiddenHere ? 'is-bp-hidden' : '',
      pending ? 'is-beekiri-pending' : '',
      drop ? `is-drop-${drop}` : '',
      isBox && node.children.length === 0 ? 'is-empty' : '',
      copy ? 'is-loop-copy' : '',
      !copy && node.loop && isBox && !isRoot ? 'is-loop' : '',
    ]
      .filter(Boolean)
      .join(' ');
    const onSelect = (e: MouseEvent) => {
      // Links on the canvas must never navigate the admin.
      if (e.currentTarget instanceof HTMLAnchorElement) e.preventDefault();
      if (!interactive) return;
      e.stopPropagation();
      selectNode(id);
    };
    const resolved = frameStyle(resolveStyleForBreakpoint(node, frame));
    const peerStyle = peerOn
      ? ({ ['--peer-select' as string]: peerOn.color } as CSSProperties)
      : undefined;
    const style = { ...(resolved as CSSProperties), ...peerStyle };
    const authorClasses = (node.cssClass || '')
      .split(/\s+/)
      .map((c) => c.replace(/[^\w-]/g, ''))
      .filter(Boolean);
    const authorId = node.cssId?.replace(/[^\w-]/g, '') || undefined;
    // The class the site gives this element (site base + theme CSS style it), e.g. bk-container.
    const siteClass = isRoot ? undefined : SITE_CLASS[node.type];
    const common = {
      className: [cls, siteClass, ...authorClasses].filter(Boolean).join(' '),
      style,
      // Duplicate ids across the multi-breakpoint frames (or repeated cards) would be invalid.
      id: visibleFrames.length === 1 && !copy ? authorId : undefined,
      'data-node-id': copy ? undefined : id,
      'data-node-type': node.type,
      onClick: onSelect,
      onMouseEnter: (e: MouseEvent) => {
        if (!interactive) return;
        e.stopPropagation();
        setHoveredId(id);
      },
      onMouseLeave: () => setHoveredId(null),
      ...(copy ? {} : dragHandlers(id, node, isRoot)),
    };
    const key = draw ? `${frame}-${id}-${draw.index}` : `${frame}-${id}`;
    const kids = () => node.children.map((cid) => renderNode(cid, frame, draw));
    const meta = TYPE_META[node.type];

    const placeholder = (title: string, hint: string) => (
      <div className="bk-beekiricode__placeholder bk-beekiricode__placeholder--media">
        <meta.Icon size={20} weight="regular" aria-hidden />
        <span>{title}</span>
        {interactive ? <small>{hint}</small> : null}
      </div>
    );

    if (node.type === 'image') {
      // An image slot with its own shape (a gallery tile, an avatar) keeps it while empty.
      const shaped = Boolean(resolved.aspectRatio) || /^\d/.test(String(resolved.height ?? ''));
      const small = shaped && parseFloat(String(resolved.width ?? '')) <= 140 && /px$/.test(String(resolved.width ?? ''));
      return (
        <div key={key} {...common}>
          {node.src ? (
            // The site prints one <img> carrying these styles; here the wrapper has them and the picture follows.
            <img src={node.src} alt={node.alt || ''} className="bk-beekiricode__img" draggable={false} />
          ) : shaped ? (
            <div className={`bk-beekiricode__placeholder bk-beekiricode__placeholder--media is-shaped${small ? ' is-small' : ''}`}>
              <meta.Icon size={small ? 16 : 20} weight="regular" aria-hidden />
              {small ? null : <span>Image</span>}
            </div>
          ) : (
            placeholder('Image', 'Pick one from the media library in Props → Content')
          )}
        </div>
      );
    }

    if (node.type === 'icon' || node.type === 'accordion' || node.type === 'tabs' || node.type === 'map' || node.type === 'rating') {
      const Preview = { icon: IconPreview, accordion: AccordionPreview, tabs: TabsPreview, map: MapPreview, rating: RatingPreview }[node.type];
      return <Preview key={key} node={node} common={common} placeholder={placeholder} interactive={interactive} />;
    }

    if (node.type === 'video') {
      const src = (node.src || '').trim();
      const embed = src ? videoEmbedUrl(src, videoOptions(node)) : null;
      return (
        <div key={key} {...common}>
          {!src ? (
            placeholder('Video', 'Paste a YouTube, Vimeo or MP4 link in Props → Content')
          ) : embed ? (
            <iframe
              className="bk-beekiricode__media"
              src={embed}
              title={node.alt || 'Video'}
              loading="lazy"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : (
            <video
              // Remount when the playback options change, so the canvas shows them at once.
              key={`${node.autoplay ? 'a' : ''}${node.videoLoop ? 'l' : ''}${node.muted ? 'm' : ''}`}
              className="bk-beekiricode__media"
              src={src}
              poster={node.poster || undefined}
              controls={!interactive && node.controls !== false}
              autoPlay={Boolean(node.autoplay)}
              muted={Boolean(node.autoplay || node.muted)}
              loop={Boolean(node.videoLoop)}
              playsInline
              preload="metadata"
            />
          )}
          {/* iframes swallow pointer events — keep the element selectable while editing. */}
          {src && interactive ? <span className="bk-beekiricode__media-shield" aria-hidden /> : null}
        </div>
      );
    }

    if (node.type === 'list') {
      const Tag = (node.tag === 'ol' ? 'ol' : 'ul') as 'ul';
      const items = (node.text || '')
        .split('\n')
        .map((l) => l.trim())
        .filter(Boolean);
      return (
        <Tag
          key={key}
          {...common}
          onDoubleClick={(e) => {
            if (!interactive) return;
            e.stopPropagation();
            selectNode(id);
          }}
        >
          {items.length ? items.map((l, i) => <li key={i}>{renderInline(l)}</li>) : <li className="bk-beekiricode__ghost">List item</li>}
        </Tag>
      );
    }

    if (node.type === 'divider') return <hr key={key} {...common} />;
    if (node.type === 'spacer') return <div key={key} {...common} />;
    if (node.type === 'form') {
      return (
        <div key={key} {...common} className={`${common.className ?? ''} bk-beekiricode__form-host`.trim()}>
          <FormPreview formId={node.formId} interactive={interactive} placeholder={placeholder} />
        </div>
      );
    }
    if (node.type === 'booking') {
      return (
        <div key={key} {...common}>
          {placeholder('Booking', node.bookingService ? `Opens on “${node.bookingService}” · live on the website` : 'The booking calendar appears here on the website')}
        </div>
      );
    }
    if (node.type === 'shop_content') {
      return (
        <div key={key} {...common} className={`${common.className ?? ''} bk-beekiricode__shop-slot`.trim()}>
          <span className="bk-beekiricode__shop-slot-label">Shop content</span>
          <span className="bk-beekiricode__shop-slot-hint">The live products, cart or checkout is shown here on the website.</span>
        </div>
      );
    }

    if (node.type === 'layout') {
      const slug = node.layoutSlug || 'layout';
      const layoutCls = [
        hiddenHere ? 'is-bp-hidden' : '',
        pending ? 'is-beekiri-pending' : '',
        peerOn ? 'is-peer-selected' : '',
        drop ? `is-drop-${drop}` : '',
      ]
        .filter(Boolean)
        .join(' ');
      return (
        <LayoutPhpPreview
          key={key}
          slug={slug}
          fields={node.layoutFields || {}}
          selected={selectedId === id}
          hovered={hoveredId === id}
          interactive={interactive}
          style={resolved as CSSProperties}
          hostStyle={peerStyle}
          className={layoutCls || undefined}
          nodeId={id}
          hostProps={dragHandlers(id, node, false)}
          onSelect={onSelect}
          onHover={(e) => {
            if (!interactive) return;
            e.stopPropagation();
            setHoveredId(id);
          }}
          onLeave={() => setHoveredId(null)}
        />
      );
    }

    if (node.type === 'heading' || node.type === 'text' || node.type === 'button') {
      const Tag = (node.tag ||
        (node.type === 'heading' ? 'h2' : node.type === 'button' ? 'a' : 'p')) as keyof JSX.IntrinsicElements;
      const href = node.type === 'button' ? safeHref(node.href) || '#' : undefined;
      if (interactive && editingTextId === id) {
        return (
          <EditableText
            key={key}
            tag={Tag}
            nodeId={id}
            nodeType={node.type}
            text={node.text || ''}
            className={cls}
            style={style}
            href={href}
            onCommit={(t) => {
              setEditingTextId(null);
              if (t !== (node.text || '')) updateNode(id, { text: t });
            }}
            onCancel={() => setEditingTextId(null)}
            onSelect={(sel) => setTextSel(sel ? { nodeId: id, ...sel } : null)}
          />
        );
      }
      return (
        <Tag
          key={key}
          {...common}
          href={href}
          onDoubleClick={(e) => {
            if (!interactive) return;
            e.stopPropagation();
            setSelectedId(id);
            // Bound text comes from the item — it is changed in Props, not typed here.
            if (!(draw && node.bind?.text)) setEditingTextId(id);
          }}
        >
          {renderInline(node.text || '')}
          {kids()}
        </Tag>
      );
    }

    const Tag = (node.tag || 'div') as keyof JSX.IntrinsicElements;

    // Dynamic content: the first child is the card, drawn once per item (the first is editable).
    if (node.loop && isBox && !isRoot) {
      const items = loopItems[id];
      const template = node.children[0];
      const cards = !template
        ? null
        : items?.length
          ? items.map((item, i) => renderNode(template, frame, { item, index: i, copy: copy || i > 0 }))
          : renderNode(template, frame, draw);
      return (
        <Tag key={key} {...common}>
          {cards}
          {interactive && !template ? (
            <div
              className="bk-beekiricode__placeholder bk-beekiricode__placeholder--box"
              role="button"
              tabIndex={-1}
              onClick={(e) => {
                e.stopPropagation();
                openAddFor(id);
              }}
            >
              <Plus size={14} weight="bold" aria-hidden />
              <span>Add the card</span>
              <small>The element you add here repeats for every item</small>
            </div>
          ) : null}
        </Tag>
      );
    }
    // A box with its own look or size (photo, dot, line, overlay…) is meant to be empty:
    // the big placeholder would change its shape, so it only gets a small "+" when selected.
    if (interactive && !isRoot && node.children.length === 0 && isShapedBox(resolved)) {
      // The chip is absolutely placed; an unpositioned box becomes its anchor.
      const anchored = resolved.position ? common.style : { ...common.style, position: 'relative' as const };
      return (
        <Tag key={key} {...common} style={anchored}>
          {selectedId === id ? (
            <button
              type="button"
              className="bk-beekiricode__add-chip"
              aria-label="Add elements inside"
              onClick={(e) => {
                e.stopPropagation();
                openAddFor(id);
              }}
            >
              <Plus size={11} weight="bold" aria-hidden />
            </button>
          ) : null}
        </Tag>
      );
    }
    return (
      <Tag key={key} {...common}>
        {kids()}
        {interactive && node.children.length === 0 ? (
          <div
            className="bk-beekiricode__placeholder bk-beekiricode__placeholder--box"
            role="button"
            tabIndex={-1}
            onClick={(e) => {
              e.stopPropagation();
              openAddFor(id);
            }}
          >
            <Plus size={14} weight="bold" aria-hidden />
            <span>{isRoot ? 'Empty page' : `Empty ${meta.label.toLowerCase()}`}</span>
            <small>Click to add elements, or drag them in from Add</small>
          </div>
        ) : null}
      </Tag>
    );
  };

  const pathLabel =
    publicPath ||
    chrome.publicPath ||
    (slug ? `${/\/posts\/?$/.test(chrome.listPath) ? '/blog/' : '/'}${slug}` : '/');
  const liveHref =
    isPublished && pathLabel && permalinkBase
      ? `${permalinkBase.replace(/\/$/, '')}${pathLabel.startsWith('/') ? pathLabel : `/${pathLabel}`}`
      : null;
  const slugPrefix = pathLabel.replace(/[^/]+$/, '') || '/';
  const selectedNode = selectedId ? doc.nodes[selectedId] ?? null : null;
  const isPageRoot = Boolean(selectedId && selectedId === doc.rootId);
  const selectedLayoutDef =
    selectedNode?.type === 'layout' && selectedNode.layoutSlug
      ? themeLayouts.find((l) => l.slug === selectedNode.layoutSlug)
      : undefined;

  return (
    <div className="bk-beekiricode">
      {/* Theme CSS — the site's sheets, responding to each frame like a real device: first the
          header/footer sheets every page loads (buttons, fonts, colours), then the layouts. */}
      <FrameSiteBase />
      <FrameLayoutStyles scoped urls={chromeCssUrls} />
      <FrameLayoutStyles urls={themeLayouts.map((layout) => apiUrl(layout.cssUrl))} />
      {customCssText ? <style>{customCssText}</style> : null}
      {/* ── Top toolbar (BeekiriCode) ─────────────────────────────── */}
      <header className="bk-beekiricode__toolbar">
        <Link
          to={chrome.listPath}
          className="bk-beekiricode__back"
          title={`Back to ${chrome.pluralLabel}`}
          aria-label={`Back to ${chrome.pluralLabel}`}
        >
          <ArrowLeft size={16} weight="regular" aria-hidden />
          <span>Back</span>
        </Link>
        <div className="bk-beekiricode__context">
          <label className="bk-beekiricode__nav-hint" htmlFor="bk-beekiricode-page-title">
            <span className="bk-beekiricode__nav-label">
              Editing {chrome.singularLabel}
            </span>
            <input
              id="bk-beekiricode-page-title"
              className="bk-beekiricode__title-input"
              type="text"
              value={chrome.title}
              onChange={(e) => chrome.onTitleChange(e.target.value)}
              placeholder={`Add ${chrome.singularLabel} name`}
              maxLength={200}
              aria-label={`${chrome.singularLabel} name`}
            />
          </label>
          {chrome.slugEditing ? (
            <span className="bk-beekiricode__permalink is-editing">
              <span className="bk-beekiricode__permalink-prefix" aria-hidden>
                {slugPrefix}
              </span>
              <input
                className="bk-beekiricode__slug-input"
                type="text"
                value={chrome.slug}
                onChange={(e) => chrome.onSlugChange(e.target.value)}
                onBlur={() => chrome.commitSlug()}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    chrome.commitSlug();
                  }
                  if (e.key === 'Escape') {
                    e.preventDefault();
                    chrome.cancelSlug();
                  }
                }}
                aria-label={`${chrome.singularLabel} slug`}
                autoFocus
              />
            </span>
          ) : (
            <span className={`bk-beekiricode__permalink${!isPublished ? ' is-draft' : ''}`}>
              <button
                type="button"
                className="bk-beekiricode__permalink-edit"
                title="Edit slug"
                onClick={() => chrome.setSlugEditing(true)}
              >
                <span className="bk-beekiricode__permalink-path">{pathLabel}</span>
                {!isPublished ? (
                  <span className="bk-beekiricode__permalink-badge">Draft</span>
                ) : null}
              </button>
              {liveHref ? (
                <a
                  className="bk-beekiricode__permalink-open"
                  href={liveHref}
                  target={`beekiri-view-${pageId}`}
                  rel="noreferrer"
                  title={`Open live ${chrome.singularLabel}`}
                  aria-label={`Open live ${chrome.singularLabel}`}
                  onClick={(e) => {
                    e.preventDefault();
                    openOrReloadLiveView(liveHref, pageId);
                  }}
                >
                  <ArrowSquareOut size={14} weight="regular" aria-hidden />
                </a>
              ) : null}
            </span>
          )}
        </div>
        <div className="bk-beekiricode__toolbar-spacer" />

        {beekiriActivity ? <BeekiriPeer activity={beekiriActivity} /> : null}
        {beekiriReady ? <BeekiriCursor activity={beekiriActivity} /> : null}
        <PeerAvatarStack />

        {beekiriReady ? <CreditsToolbar /> : null}

        <div className="bk-beekiricode__zoom-group" role="group" aria-label="History">
          <button
            type="button"
            className="bk-beekiricode__icon-btn"
            title={`Undo (${MOD}Z)`}
            aria-label="Undo"
            disabled={!history.canUndo}
            onClick={undo}
          >
            <ArrowUUpLeft size={16} weight="regular" aria-hidden />
          </button>
          <button
            type="button"
            className="bk-beekiricode__icon-btn"
            title={`Redo (${MOD}⇧Z)`}
            aria-label="Redo"
            disabled={!history.canRedo}
            onClick={redo}
          >
            <ArrowUUpRight size={16} weight="regular" aria-hidden />
          </button>
        </div>

        <div className="bk-beekiricode__zoom-group" role="group" aria-label="Zoom">
          <button
            type="button"
            className="bk-beekiricode__icon-btn"
            title={`Zoom out (${MOD}−)`}
            disabled={scale <= ZOOM_MIN + 0.001}
            onClick={() => viewportApi.current?.zoomBy(1 / 1.2)}
          >
            <MagnifyingGlassMinus size={16} weight="regular" aria-hidden />
          </button>
          <button
            type="button"
            className="bk-beekiricode__zoom"
            title="Zoom to 100% (Shift+0)"
            onClick={() => viewportApi.current?.zoomTo(1)}
          >
            {zoom}%
          </button>
          <button
            type="button"
            className="bk-beekiricode__icon-btn"
            title={`Zoom in (${MOD}+)`}
            disabled={scale >= ZOOM_MAX - 0.001}
            onClick={() => viewportApi.current?.zoomBy(1.2)}
          >
            <MagnifyingGlassPlus size={16} weight="regular" aria-hidden />
          </button>
          <button
            type="button"
            className="bk-beekiricode__icon-btn"
            title={`Fit to screen (${MOD}0)`}
            onClick={() => viewportApi.current?.fit()}
          >
            <CornersOut size={16} weight="regular" aria-hidden />
          </button>
        </div>

        <span className={`bk-beekiricode__sync${syncOk ? ' is-ok' : ''}`}>
          <span className="bk-beekiricode__sync-dot" aria-hidden />
          {syncLabel}
        </span>

        <div className="bk-beekiricode__publish" ref={publishRef}>
          {isPublished && !isDirty && !isPublishing && viewHref ? (
            <a
              className="bk-beekiricode__publish-main bk-beekiricode__publish-main--view"
              href={viewHref}
              target={`beekiri-view-${pageId}`}
              rel="noreferrer"
              title={`View live ${chrome.singularLabel}`}
              onClick={(e) => {
                e.preventDefault();
                openOrReloadLiveView(viewHref, pageId);
              }}
            >
              <ArrowSquareOut size={16} weight="regular" aria-hidden />
              View {chrome.singularLabel}
            </a>
          ) : (
            <button
              type="button"
              className={`bk-beekiricode__publish-main${isPublishing ? ' is-loading' : ''}`}
              disabled={busy || !canPublish}
              onClick={onPublish}
              aria-busy={isPublishing}
            >
              {isPublishing ? (
                <CircleNotch size={16} weight="bold" className="bk-beekiricode__spin" aria-hidden />
              ) : (
                <CloudArrowUp size={16} weight="regular" aria-hidden />
              )}
              {isPublishing ? 'Publishing…' : 'Publish'}
            </button>
          )}
          <button
            type="button"
            className="bk-beekiricode__publish-caret"
            aria-label="Publish options"
            aria-expanded={publishOpen}
            disabled={busy}
            onClick={() => setPublishOpen((v) => !v)}
          >
            <CaretDown size={12} weight="regular" aria-hidden />
          </button>
          {publishOpen ? (
            <div className="bk-beekiricode__menu" role="menu">
              <button
                type="button"
                className="bk-beekiricode__menu-item"
                role="menuitem"
                onClick={() => {
                  setPublishOpen(false);
                  onSaveDraft();
                }}
              >
                Save draft
              </button>
              <button
                type="button"
                className="bk-beekiricode__menu-item"
                role="menuitem"
                disabled={!onPreview}
                onClick={() => {
                  setPublishOpen(false);
                  onPreview?.();
                }}
              >
                <Eye size={16} weight="regular" aria-hidden /> Preview page
              </button>
              <button
                type="button"
                className="bk-beekiricode__menu-item"
                role="menuitem"
                onClick={() => {
                  setPublishOpen(false);
                  onOpenSettings();
                }}
              >
                Version history…
              </button>
            </div>
          ) : null}
        </div>

        <button
          type="button"
          className="bk-beekiricode__icon-btn"
          title="Page settings"
          onClick={onOpenSettings}
        >
          <GearSix size={16} weight="regular" aria-hidden />
        </button>
      </header>

      <div className="bk-beekiricode__workspace">
        {/* ── Left Explorer ──────────────────────────────────────────── */}
        <aside className="bk-beekiricode__explorer" aria-label="Explorer">
          <div className="bk-beekiricode__explorer-head">
            <span>Explorer</span>
            <span className="bk-beekiricode__explorer-count">
              {Object.keys(doc.nodes).length - 1} element{Object.keys(doc.nodes).length === 2 ? '' : 's'}
            </span>
          </div>
          <div
            className="bk-beekiricode__tabs bk-beekiricode__tabs--5"
            role="tablist"
            aria-label="Explorer tabs"
          >
            {EXPLORER_TABS.map(({ id, label, title }) => (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={explorerTab === id}
                className={`bk-beekiricode__tab${explorerTab === id ? ' is-active' : ''}`}
                title={title}
                onClick={() => setExplorerTab(id)}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="bk-beekiricode__explorer-body">
            {explorerTab === 'layers' ? (
              <div className="bk-beekiricode__layers">
                <label className="bk-beekiricode__search">
                  <MagnifyingGlass size={13} aria-hidden />
                  <input
                    type="search"
                    value={layerQuery}
                    placeholder="Search layers…"
                    aria-label="Search layers"
                    onChange={(e) => setLayerQuery(e.target.value)}
                  />
                  {layerQuery ? (
                    <button type="button" aria-label="Clear search" onClick={() => setLayerQuery('')}>
                      <X size={11} weight="bold" />
                    </button>
                  ) : null}
                </label>
                <LayersTree
                  doc={doc}
                  selectedId={selectedId}
                  hoveredId={hoveredId}
                  query={layerQuery}
                  onSelect={selectOnly}
                  onOpenProps={selectNode}
                  onHover={setHoveredId}
                  onRemove={removeSelected}
                  onMove={moveLayer}
                  onRename={renameNode}
                  onDropPalette={dropPalette}
                />
                <div className="bk-beekiricode__layers-foot">
                  <button
                    type="button"
                    className="bk-beekiricode__layers-add"
                    onClick={() => setExplorerTab('add')}
                  >
                    <Plus size={12} weight="bold" aria-hidden />
                    Add element
                  </button>
                  <span className="bk-beekiricode__layers-hint">
                    Double-click renames · {MOD}D duplicates · ⌫ deletes
                  </span>
                </div>
              </div>
            ) : null}

            {explorerTab === 'properties' ? (
              <div className="bk-beekiricode__props-tab">
                <PropertiesPanel
                  variant="embedded"
                  doc={doc}
                  node={selectedNode}
                  isPageRoot={isPageRoot}
                  editTarget={styleEditTarget}
                  layoutFieldDefs={selectedLayoutDef?.fields}
                  layouts={themeLayouts}
                  shopActive={shopActive}
                  onRemoveNodes={removeNodes}
                  documentColors={documentColors}
                  showHidden={showHidden}
                  onShowHiddenChange={setShowHidden}
                  onSelectNode={(id) => setSelectedId(id)}
                  onSelectPage={() => {
                    setSelectedId(doc.rootId);
                    setExplorerTab('properties');
                  }}
                  onRename={(label) => selectedId && renameNode(selectedId, label)}
                  onDuplicate={() => selectedId && duplicateSelected(selectedId)}
                  onDelete={() => selectedId && removeSelected(selectedId)}
                  onAddInside={() => selectedId && openAddFor(selectedId)}
                  onAskBeekiri={beekiriReady && selectedNode && !isPageRoot ? () => askBeekiri(selectedNode.id) : undefined}
                  onSpacingFocus={setSpacingFocus}
                  textSelection={textSel && textSel.nodeId === selectedId ? textSel : null}
                  parentNode={selectedId ? (() => {
                    const pid = findParentId(doc, selectedId);
                    return pid ? doc.nodes[pid] ?? null : null;
                  })() : null}
                  onUpdate={(patch) => {
                    if (!selectedId) return;
                    updateNode(selectedId, patch);
                  }}
                />
              </div>
            ) : null}

            {explorerTab === 'add' ? (
              <AddPanel
                shopPage={apiBase.includes('/shop_page')}
                layouts={themeLayouts}
                layoutsStatus={layoutsStatus}
                onReloadLayouts={reloadLayouts}
                insertHint={`${insertAnchor.position === 'inside' ? 'inside' : 'after'} “${insertAnchor.label}”`}
                onAddElement={addElement}
                onAddLayout={addThemeLayout}
                sections={themeSections}
                onAddSection={addThemeSection}
              />
            ) : null}

            {explorerTab === 'page-settings' ? (
              <PageSettingsPanel pageId={pageId} apiBase={apiBase} />
            ) : null}

            {explorerTab === 'seo' ? (
              <SeoPanel
                seo={chrome.seo}
                onChange={chrome.setSeo}
                title={chrome.title}
                slug={chrome.slug}
                excerpt={chrome.excerpt}
                urlPrefix={`${permalinkBase.replace(/\/$/, '')}${slugPrefix}`}
                featuredImageId={chrome.featuredImageId}
                doc={doc}
                isPublished={isPublished}
                onOpenSettings={onOpenSettings}
                onDocChange={(next) => commitDoc(next)}
                onSlugChange={(next) => {
                  chrome.onSlugChange(next);
                  chrome.commitSlug();
                }}
              />
            ) : null}
          </div>
        </aside>

        {/* ── Canvas stage ───────────────────────────────────────────── */}
        <div className="bk-beekiricode__stage">
          <div className="bk-beekiricode__canvas-tools">
            <div className="bk-beekiricode__mode-pill" role="group" aria-label="Canvas mode">
              <button
                type="button"
                className={`bk-beekiricode__mode-btn${canvasMode === 'select' ? ' is-active' : ''}`}
                aria-pressed={canvasMode === 'select'}
                title="Select"
                onClick={() => {
                  setCanvasMode('select');
                }}
              >
                <Cursor size={16} weight="regular" aria-hidden />
              </button>
              <button
                type="button"
                className={`bk-beekiricode__mode-btn${canvasMode === 'preview' ? ' is-active' : ''}`}
                aria-pressed={canvasMode === 'preview'}
                title="Preview — single frame at 95%. Click again to re-center."
                onClick={() => {
                  if (viewMode === 'multi') setViewMode('desktop');
                  if (canvasMode === 'preview') {
                    // Already previewing: glide back to the preview position.
                    viewportApi.current?.fit(true);
                  } else {
                    setCanvasMode('preview');
                  }
                }}
              >
                <Eye size={16} weight="regular" aria-hidden />
              </button>
            </div>

            <div className="bk-beekiricode__viewport" ref={viewportRef}>
              <button
                type="button"
                className="bk-beekiricode__viewport-btn"
                aria-expanded={viewportOpen}
                onClick={() => setViewportOpen((v) => !v)}
              >
                <activeBreakpoint.Icon size={16} weight="regular" aria-hidden />
                {activeBreakpoint.label}
                <CaretDown size={12} weight="regular" aria-hidden />
              </button>
              <button
                type="button"
                className={`bk-beekiricode__viewport-multi${
                  viewMode === 'multi' && canvasMode !== 'preview' ? ' is-active' : ''
                }`}
                title="Show all breakpoints"
                aria-pressed={viewMode === 'multi' && canvasMode !== 'preview'}
                onClick={() => {
                  setCanvasMode('select');
                  setViewMode((m) => (m === 'multi' ? 'desktop' : 'multi'));
                }}
              >
                <SquaresFour size={16} weight="regular" aria-hidden />
              </button>
              {viewportOpen ? (
                <div className="bk-beekiricode__menu bk-beekiricode__menu--viewport" role="menu">
                  {BREAKPOINTS.map((bp) => (
                    <button
                      key={bp.id}
                      type="button"
                      role="menuitem"
                      className={`bk-beekiricode__menu-item${
                        effectiveViewMode === bp.id ? ' is-active' : ''
                      }`}
                      onClick={() => {
                        setViewMode(bp.id);
                        setCanvasMode('select');
                              setViewportOpen(false);
                      }}
                    >
                      <bp.Icon size={16} weight="regular" aria-hidden />
                      <span>{bp.label}</span>
                      <span className="bk-beekiricode__menu-meta">{bp.width}px</span>
                    </button>
                  ))}
                  <div className="bk-beekiricode__menu-sep" />
                  <button
                    type="button"
                    role="menuitem"
                    className={`bk-beekiricode__menu-item${
                      viewMode === 'multi' && canvasMode !== 'preview' ? ' is-active' : ''
                    }`}
                    onClick={() => {
                      setViewMode('multi');
                      setCanvasMode('select');
                          setViewportOpen(false);
                    }}
                  >
                    <SquaresFour size={16} weight="regular" aria-hidden />
                    All breakpoints
                  </button>
                </div>
              ) : null}
            </div>
          </div>

          <CanvasViewport
            ref={viewportApi}
            designWidth={designWidth}
            fitKey={`${effectiveViewMode}:${canvasMode}`}
            fitScale={canvasMode === 'preview' ? 0.95 : undefined}
            onScaleChange={setScale}
            // A click on the workspace around the page lets go of the element: the page is selected.
            onBackgroundClick={() => {
              if (canvasMode === 'select') selectOnly(doc.rootId);
            }}
          >
            <div className="bk-beekiricode__frames" style={{ gap: FRAME_GAP }}>
              {visibleFrames.map((bp) => (
                <div key={bp.id} className="bk-beekiricode__frame" data-bp={bp.id} style={{ width: bp.width }}>
                  <div
                    className="bk-beekiricode__frame-label"
                    style={{ transform: `scale(${1 / scale})` }}
                  >
                    <bp.Icon size={12} weight="bold" aria-hidden />
                    {bp.label} · {bp.width}
                    {styleEditTarget === bp.id ? ` · editing ${bp.label.toLowerCase()} overrides` : null}
                    {styleEditTarget === 'base' && viewMode !== 'multi' ? ' · editing default styles' : null}
                  </div>
                  <div
                    className={`bk-beekiricode__frame-canvas${canvasMode === 'preview' ? ' is-preview' : ''}`}
                    data-theme={siteTheme}
                    style={{ width: bp.width, minHeight: 900 }}
                    onClick={() => {
                      if (canvasMode === 'select') selectNode(doc.rootId);
                    }}
                    onMouseMove={(e) => onFramePointer(e, bp.id)}
                    onMouseLeave={clearFramePointer}
                  >
                    {renderNode(doc.rootId, bp.id)}
                    {canvasMode === 'select' ? (
                      <>
                        <RemoteCursors frame={bp.id} />
                        <SelectionChrome
                          doc={doc}
                          selectedId={selectedId}
                          hoveredId={hoveredId}
                          scale={scale}
                          spacingFocus={spacingFocus}
                          onSelectParent={(pid) => setSelectedId(pid)}
                          onMove={shiftSelected}
                          onDuplicate={duplicateSelected}
                          onDelete={removeSelected}
                          onAddInside={openAddFor}
                          onAskBeekiri={beekiriReady ? askBeekiri : undefined}
                        />
                      </>
                    ) : null}
                  </div>
                </div>
              ))}
            </div>
          </CanvasViewport>
        </div>
      </div>
    </div>
  );
}
