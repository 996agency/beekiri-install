import { Fragment, useState, type HTMLAttributes, type ReactNode } from 'react';
import { ICONS, mapEmbedUrl, ratingValue } from '@beekiri/page-blocks';
import { safeHref } from '../../lib/safe-html';
import type { BeekiriCodeNode } from './document';
import { renderInline } from './inline-markup';

/**
 * Canvas drawings of the Icon, Accordion, Tabs, Map and Star rating elements — the same
 * markup and classes the website prints (page-blocks beekiricode-html.ts), so the site's
 * CSS styles them here too.
 */

/** Selection, hover and drop wiring the canvas puts on every element's root. */
type Common = HTMLAttributes<HTMLElement> & { 'data-node-id'?: string; 'data-node-type'?: string };

type PreviewProps = {
  node: BeekiriCodeNode;
  common: Common;
  /** Shown while the element has nothing to draw yet. */
  placeholder: (title: string, hint: string) => ReactNode;
  interactive: boolean;
};

export function IconGlyph({ name }: { name: string | undefined }) {
  // An icon name this release doesn't know: a question mark while editing (the site prints nothing).
  const d = (name && ICONS[name]) || ICONS.question;
  return (
    <svg viewBox="0 0 256 256" width="1em" height="1em" fill="currentColor" aria-hidden focusable="false">
      <path d={d} />
    </svg>
  );
}

/** Plain text with inline colour, line breaks kept. */
function lines(text: string): ReactNode {
  return text.split(/\r?\n/).map((line, i) => (
    <Fragment key={i}>
      {i > 0 ? <br /> : null}
      {renderInline(line)}
    </Fragment>
  ));
}

export function IconPreview({ node, common }: PreviewProps) {
  return node.href ? (
    <a {...common} href={safeHref(node.href)}>
      <IconGlyph name={node.icon} />
    </a>
  ) : (
    <span {...common}>
      <IconGlyph name={node.icon} />
    </span>
  );
}

export function AccordionPreview({ node, common, placeholder }: PreviewProps) {
  const items = node.items ?? [];
  return (
    <div {...common}>
      {items.length
        ? items.map((item, i) => (
            <details key={i} className="bk-accordion__item" open={i === 0 && !node.startClosed}>
              <summary className="bk-accordion__title">{renderInline(item.title)}</summary>
              <div className="bk-accordion__body">{lines(item.text)}</div>
            </details>
          ))
        : placeholder('Accordion', 'Add the first item in Props → Content')}
    </div>
  );
}

export function TabsPreview({ node, common, placeholder }: PreviewProps) {
  const items = node.items ?? [];
  const [picked, setPicked] = useState(0);
  const active = Math.min(picked, Math.max(0, items.length - 1));
  if (!items.length) return <div {...common}>{placeholder('Tabs', 'Add the first tab in Props → Content')}</div>;
  return (
    <div {...common}>
      <div className="bk-tabs__list" role="tablist">
        {items.map((item, i) => (
          <button key={i} type="button" role="tab" aria-selected={i === active} className={`bk-tabs__tab${i === active ? ' is-active' : ''}`} onClick={() => setPicked(i)}>
            {renderInline(item.title)}
          </button>
        ))}
      </div>
      <div className="bk-tabs__panel" role="tabpanel">
        {lines(items[active].text)}
      </div>
    </div>
  );
}

export function MapPreview({ node, common, placeholder, interactive }: PreviewProps) {
  const src = mapEmbedUrl(node.address, node.zoom);
  return (
    <div {...common}>
      {src ? (
        <iframe className="bk-beekiricode__media" src={src} title={`Map: ${node.address ?? ''}`} loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
      ) : (
        placeholder('Map', 'Type an address in Props → Content')
      )}
      {/* iframes swallow pointer events — keep the element selectable while editing. */}
      {src && interactive ? <span className="bk-beekiricode__media-shield" aria-hidden /> : null}
    </div>
  );
}

export function RatingPreview({ node, common }: PreviewProps) {
  const value = ratingValue(node.rating);
  const stars = Array.from({ length: 5 }, (_, i) => <IconGlyph key={i} name="star-fill" />);
  return (
    <div {...common} role="img" aria-label={`${value} out of 5 stars`}>
      <span className="bk-rating__stars">
        <span className="bk-rating__base">{stars}</span>
        <span className="bk-rating__fill" style={{ width: `${value * 20}%` }}>
          {stars}
        </span>
      </span>
    </div>
  );
}
