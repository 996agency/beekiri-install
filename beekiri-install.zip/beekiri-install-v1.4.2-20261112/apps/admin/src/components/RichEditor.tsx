import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import {
  ArrowUUpLeft,
  ArrowUUpRight,
  Code,
  Eraser,
  Image as ImageIcon,
  LinkBreak,
  LinkSimple,
  ListBullets,
  ListNumbers,
  Minus,
  TextAlignCenter,
  TextAlignLeft,
  TextAlignRight,
  TextB,
  TextItalic,
  TextStrikethrough,
  TextUnderline,
} from '@phosphor-icons/react';
import { MediaPicker } from '../editor/beekiricode/inspector/MediaPicker';
import { safeHref, sanitizeRichText } from '../lib/safe-html';
import './rich-editor.css';

type Props = {
  value: string;
  onChange: (html: string) => void;
  /** A few lines of text: formatting and links only (no headings, photos or alignment). */
  short?: boolean;
  placeholder?: string;
  /** Names the editor for screen readers. */
  label?: string;
};

type Marks = { bold: boolean; italic: boolean; underline: boolean; strike: boolean; ul: boolean; ol: boolean; align: 'left' | 'center' | 'right'; block: string; link: boolean };
const NO_MARKS: Marks = { bold: false, italic: false, underline: false, strike: false, ul: false, ol: false, align: 'left', block: 'p', link: false };

const BLOCKS = [
  { value: 'p', label: 'Paragraph' },
  { value: 'h2', label: 'Heading' },
  { value: 'h3', label: 'Subheading' },
  { value: 'h4', label: 'Small heading' },
  { value: 'blockquote', label: 'Quote' },
];

const escapeHtml = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/** The link the selection sits in, if any. */
function anchorAt(node: Node | null, root: HTMLElement | null): HTMLAnchorElement | null {
  for (let n: Node | null = node; n && n !== root; n = n.parentNode) {
    if (n instanceof HTMLAnchorElement) return n;
  }
  return null;
}

/**
 * Rich text for the admin (product descriptions and the like): headings, bold / italic / underline /
 * strikethrough, lists, alignment, links, photos from the media library, a divider, undo / redo, and
 * an HTML view. Everything typed or pasted is cleaned (sanitizeRichText) before it reaches `onChange`.
 */
export function RichEditor({ value, onChange, short, placeholder, label }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  /** The selection inside the editor, kept while a popover or the media library has the focus. */
  const range = useRef<Range | null>(null);
  const [html, setHtml] = useState(false);
  const [marks, setMarks] = useState<Marks>(NO_MARKS);
  const [link, setLink] = useState<{ url: string; editing: boolean } | null>(null);
  const [picking, setPicking] = useState(false);

  // Outside changes (load, discard) show up; what is being typed is never replaced under the cursor.
  useEffect(() => {
    const el = ref.current;
    if (!el || document.activeElement === el) return;
    const clean = sanitizeRichText(value);
    if (el.innerHTML !== clean) el.innerHTML = clean;
  }, [value, html]);

  useEffect(() => {
    try {
      document.execCommand('defaultParagraphSeparator', false, 'p');
    } catch {
      /* older browsers keep their own separator */
    }
  }, []);

  const emit = useCallback(() => {
    if (ref.current) onChange(sanitizeRichText(ref.current.innerHTML));
  }, [onChange]);

  const inside = () => {
    const sel = window.getSelection();
    return Boolean(sel?.rangeCount && ref.current?.contains(sel.anchorNode));
  };

  /** Which toolbar buttons are on for the text under the cursor. */
  const readMarks = useCallback(() => {
    if (!inside()) return;
    const sel = window.getSelection();
    range.current = sel?.rangeCount ? sel.getRangeAt(0).cloneRange() : null;
    const on = (c: string) => {
      try {
        return document.queryCommandState(c);
      } catch {
        return false;
      }
    };
    const block = String(document.queryCommandValue('formatBlock') || 'p').toLowerCase().replace(/[<>]/g, '');
    setMarks({
      bold: on('bold'),
      italic: on('italic'),
      underline: on('underline'),
      strike: on('strikeThrough'),
      ul: on('insertUnorderedList'),
      ol: on('insertOrderedList'),
      align: on('justifyCenter') ? 'center' : on('justifyRight') ? 'right' : 'left',
      block: BLOCKS.some((b) => b.value === block) ? block : 'p',
      link: Boolean(anchorAt(sel?.anchorNode ?? null, ref.current)),
    });
    // The ref and `inside` are stable; nothing here depends on props.
  }, []);

  useEffect(() => {
    document.addEventListener('selectionchange', readMarks);
    return () => document.removeEventListener('selectionchange', readMarks);
  }, [readMarks]);

  /** Put the cursor back where it was in the editor (after a popover or the media library). */
  const restore = () => {
    const el = ref.current;
    if (!el) return;
    // Still in the editor (a toolbar button or the style menu was used): the live cursor is the truth.
    if (inside()) {
      el.focus();
      return;
    }
    el.focus();
    const sel = window.getSelection();
    if (range.current && sel) {
      sel.removeAllRanges();
      sel.addRange(range.current);
    }
  };

  /** Browsers put a new list inside a paragraph, which saves as empty paragraphs around it: lift it out. */
  const liftLists = () => {
    const el = ref.current;
    const sel = window.getSelection();
    if (!el || !sel?.rangeCount) return;
    const { startContainer, startOffset } = sel.getRangeAt(0);
    let moved = false;
    for (const list of Array.from(el.querySelectorAll('p > ul, p > ol'))) {
      const p = list.parentElement;
      if (!p || p.childNodes.length !== 1) continue;
      p.replaceWith(list);
      moved = true;
    }
    if (moved && el.contains(startContainer)) sel.collapse(startContainer, startOffset);
  };

  const cmd = (c: string, arg?: string) => {
    restore();
    document.execCommand(c, false, arg);
    if (c === 'insertUnorderedList' || c === 'insertOrderedList') liftLists();
    emit();
    readMarks();
  };

  const openLink = () => {
    const a = anchorAt(range.current?.startContainer ?? null, ref.current);
    setLink({ url: a?.getAttribute('href') ?? '', editing: Boolean(a) });
  };

  const applyLink = () => {
    const url = safeHref(link?.url.trim() ? (/^([a-z][a-z0-9+.-]*:|\/|#)/i.test(link.url.trim()) ? link.url.trim() : `https://${link.url.trim()}`) : '');
    setLink(null);
    if (!url) return;
    restore();
    const a = anchorAt(range.current?.startContainer ?? null, ref.current);
    if (a) a.setAttribute('href', url);
    else if (range.current?.collapsed) document.execCommand('insertHTML', false, `<a href="${escapeHtml(url)}">${escapeHtml(url)}</a>`);
    else document.execCommand('createLink', false, url);
    emit();
  };

  const tool = (title: string, icon: ReactNode, run: () => void, on = false) => (
    <button type="button" className={on ? 'is-on' : ''} title={title} aria-label={title} aria-pressed={on} onMouseDown={(e) => e.preventDefault()} onClick={run}>
      {icon}
    </button>
  );

  const words = value.replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').trim().split(/\s+/).filter(Boolean).length;

  return (
    <div className="bk-rte">
      <div className="bk-rte__bar" role="toolbar" aria-label="Formatting">
        {!html ? (
          <>
            {!short ? (
              <select value={marks.block} onChange={(e) => cmd('formatBlock', e.target.value)} aria-label="Text style" title="Text style">
                {BLOCKS.map((b) => (
                  <option key={b.value} value={b.value}>
                    {b.label}
                  </option>
                ))}
              </select>
            ) : null}
            <span className="bk-rte__group">
              {tool('Bold', <TextB size={15} weight="bold" />, () => cmd('bold'), marks.bold)}
              {tool('Italic', <TextItalic size={15} />, () => cmd('italic'), marks.italic)}
              {tool('Underline', <TextUnderline size={15} />, () => cmd('underline'), marks.underline)}
              {tool('Strikethrough', <TextStrikethrough size={15} />, () => cmd('strikeThrough'), marks.strike)}
            </span>
            <span className="bk-rte__group">
              {tool('Bullet list', <ListBullets size={15} />, () => cmd('insertUnorderedList'), marks.ul)}
              {tool('Numbered list', <ListNumbers size={15} />, () => cmd('insertOrderedList'), marks.ol)}
            </span>
            {!short ? (
              <span className="bk-rte__group">
                {tool('Align left', <TextAlignLeft size={15} />, () => cmd('justifyLeft'), marks.align === 'left')}
                {tool('Align centre', <TextAlignCenter size={15} />, () => cmd('justifyCenter'), marks.align === 'center')}
                {tool('Align right', <TextAlignRight size={15} />, () => cmd('justifyRight'), marks.align === 'right')}
              </span>
            ) : null}
            <span className="bk-rte__group">
              {tool(marks.link ? 'Edit link' : 'Add link', <LinkSimple size={15} />, openLink, marks.link)}
              {marks.link ? tool('Remove link', <LinkBreak size={15} />, () => cmd('unlink')) : null}
              {!short ? tool('Add a photo', <ImageIcon size={15} />, () => setPicking(true)) : null}
              {!short ? tool('Divider line', <Minus size={15} />, () => cmd('insertHorizontalRule')) : null}
            </span>
            <span className="bk-rte__group">
              {tool('Clear formatting', <Eraser size={15} />, () => {
                cmd('removeFormat');
                if (!short) cmd('formatBlock', 'p');
              })}
              {tool('Undo', <ArrowUUpLeft size={15} />, () => cmd('undo'))}
              {tool('Redo', <ArrowUUpRight size={15} />, () => cmd('redo'))}
            </span>
          </>
        ) : (
          <span className="bk-rte__hint">Editing the HTML</span>
        )}
        <span className="bk-rte__spacer" />
        <button type="button" className={html ? 'is-on' : ''} onClick={() => setHtml((h) => !h)} title={html ? 'Back to the visual editor' : 'Edit the HTML'}>
          <Code size={15} aria-hidden /> {html ? 'Visual' : 'HTML'}
        </button>
      </div>

      {link ? (
        <div className="bk-rte__link">
          <input
            type="url"
            autoFocus
            value={link.url}
            placeholder="Paste or type a link, e.g. https://example.com"
            aria-label="Link address"
            onChange={(e) => setLink({ ...link, url: e.target.value })}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                applyLink();
              } else if (e.key === 'Escape') {
                e.stopPropagation();
                setLink(null);
                restore();
              }
            }}
          />
          <button type="button" className="button button-primary" onClick={applyLink} disabled={!link.url.trim()}>
            {link.editing ? 'Update link' : 'Add link'}
          </button>
          <button
            type="button"
            className="button"
            onClick={() => {
              setLink(null);
              restore();
            }}
          >
            Cancel
          </button>
        </div>
      ) : null}

      {html ? (
        <textarea value={value} onChange={(e) => onChange(e.target.value)} onBlur={(e) => onChange(sanitizeRichText(e.target.value))} rows={short ? 5 : 12} aria-label={label ? `${label} (HTML)` : 'HTML'} spellCheck={false} />
      ) : (
        <div
          ref={ref}
          className={`bk-rte__area${short ? ' is-short' : ''}`}
          contentEditable
          suppressContentEditableWarning
          role="textbox"
          aria-multiline
          aria-label={label}
          data-placeholder={placeholder ?? ''}
          onInput={emit}
          onBlur={emit}
          onKeyUp={readMarks}
          onMouseUp={readMarks}
          onKeyDown={(e) => {
            if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
              e.preventDefault();
              openLink();
            }
          }}
        />
      )}

      {!short ? (
        <div className="bk-rte__foot">
          {words} {words === 1 ? 'word' : 'words'}
        </div>
      ) : null}

      <MediaPicker
        open={picking}
        kind="image"
        title="Add a photo"
        onClose={() => setPicking(false)}
        onSelect={(items) => {
          setPicking(false);
          const photo = items[0];
          if (!photo) return;
          restore();
          document.execCommand('insertHTML', false, `<img src="${escapeHtml(photo.url)}" alt="${escapeHtml(photo.alt ?? '')}">`);
          emit();
        }}
      />
    </div>
  );
}
