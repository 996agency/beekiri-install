import { useEffect, useRef, useState, type PointerEvent } from 'react';
import { createPortal } from 'react-dom';
import type { ShotRect } from '../lib/screen-capture';
import './screenshot-overlay.css';

/** Smaller than this is a click, not a drag. */
const MIN_SIZE = 12;

type Props = {
  /** The dragged area in viewport pixels, or null when cancelled (Esc, right click, or a click). */
  onDone: (rect: ShotRect | null) => void;
};

/** Full-screen crosshair layer: drag over any part of the page to take a screenshot of it. */
export function ScreenshotOverlay({ onDone }: Props) {
  const start = useRef<{ x: number; y: number } | null>(null);
  const [rect, setRect] = useState<ShotRect | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      // The chat would close on the same Escape.
      e.stopImmediatePropagation();
      e.preventDefault();
      onDone(null);
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [onDone]);

  const area = (x: number, y: number): ShotRect | null => {
    const from = start.current;
    if (!from) return null;
    return { left: Math.min(from.x, x), top: Math.min(from.y, y), width: Math.abs(x - from.x), height: Math.abs(y - from.y) };
  };

  const onPointerDown = (e: PointerEvent<HTMLDivElement>) => {
    if (e.button !== 0) return onDone(null);
    e.currentTarget.setPointerCapture(e.pointerId);
    start.current = { x: e.clientX, y: e.clientY };
    setRect({ left: e.clientX, top: e.clientY, width: 0, height: 0 });
  };

  const onPointerMove = (e: PointerEvent<HTMLDivElement>) => {
    if (start.current) setRect(area(e.clientX, e.clientY));
  };

  const onPointerUp = (e: PointerEvent<HTMLDivElement>) => {
    const done = area(e.clientX, e.clientY);
    start.current = null;
    onDone(done && done.width >= MIN_SIZE && done.height >= MIN_SIZE ? done : null);
  };

  return createPortal(
    <div
      className={`bk-shot${rect ? ' is-dragging' : ''}`}
      role="dialog"
      aria-label="Drag to take a screenshot. Press Escape to cancel."
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onContextMenu={(e) => e.preventDefault()}
    >
      {rect ? (
        <div className="bk-shot__area" style={{ left: rect.left, top: rect.top, width: rect.width, height: rect.height }}>
          {rect.width >= MIN_SIZE && rect.height >= MIN_SIZE ? (
            <span className="bk-shot__size">
              {Math.round(rect.width)} × {Math.round(rect.height)}
            </span>
          ) : null}
        </div>
      ) : null}
      <p className="bk-shot__tip">
        Drag to take a screenshot <kbd>Esc</kbd>
      </p>
    </div>,
    document.body,
  );
}
