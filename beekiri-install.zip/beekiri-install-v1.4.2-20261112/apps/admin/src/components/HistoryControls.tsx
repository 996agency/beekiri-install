import { CaretLeft, CaretRight } from '@phosphor-icons/react';
import './history-controls.css';

export type HistoryPeriod = 'today' | 'week' | 'month' | 'all';

const PERIODS: [HistoryPeriod, string][] = [
  ['today', 'Today'],
  ['week', 'This week'],
  ['month', 'This month'],
  ['all', 'All time'],
];

/** Today / This week / This month / All time, as the admin's tabs: flush along a card's top edge, or `inline` in its header row. */
export function PeriodTabs({
  value,
  onChange,
  label,
  inline = false,
}: {
  value: HistoryPeriod;
  onChange: (p: HistoryPeriod) => void;
  label: string;
  inline?: boolean;
}) {
  return (
    <div
      className={`bk-tabs ${inline ? 'is-inline' : 'is-flush'} bk-history__periods`}
      role="tablist"
      aria-label={label}
    >
      {PERIODS.map(([id, text]) => (
        <button
          key={id}
          type="button"
          role="tab"
          aria-selected={value === id}
          className={`bk-tabs__item${value === id ? ' is-active' : ''}`}
          onClick={() => onChange(id)}
        >
          {text}
        </button>
      ))}
    </div>
  );
}

/** "11–20 of 134 messages" with previous / next, for lists paged on the server. */
export function ListPager({
  page,
  pages,
  total,
  perPage,
  noun,
  onPage,
  busy = false,
}: {
  page: number;
  pages: number;
  total: number;
  perPage: number;
  noun: string;
  onPage: (page: number) => void;
  busy?: boolean;
}) {
  if (total <= perPage) return null;
  const from = (page - 1) * perPage + 1;
  const to = Math.min(total, page * perPage);
  return (
    <nav className="bk-history__pager" aria-label={`${noun} pages`}>
      <span className="bk-history__pager-count">
        {from}–{to} of {total.toLocaleString()} {noun}
      </span>
      <span className="bk-history__pager-buttons">
        <button
          type="button"
          className="button"
          disabled={busy || page <= 1}
          onClick={() => onPage(page - 1)}
          aria-label="Previous page"
        >
          <CaretLeft size={14} aria-hidden />
        </button>
        <span className="bk-history__pager-page">
          {page} / {pages}
        </span>
        <button
          type="button"
          className="button"
          disabled={busy || page >= pages}
          onClick={() => onPage(page + 1)}
          aria-label="Next page"
        >
          <CaretRight size={14} aria-hidden />
        </button>
      </span>
    </nav>
  );
}

/** "Today", "Yesterday", or the date ("Wed, Nov 5"). */
export function dayLabel(iso: string, now = new Date()): string {
  const d = new Date(iso);
  const start = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((start(now) - start(d)) / 86_400_000);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Yesterday';
  return d.toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    ...(d.getFullYear() !== now.getFullYear() ? { year: 'numeric' } : {}),
  });
}

/** Items in order, split into days (newest first stays newest first). */
export function byDay<T>(items: T[], dateOf: (item: T) => string): { day: string; items: T[] }[] {
  const out: { day: string; items: T[] }[] = [];
  for (const item of items) {
    const day = dayLabel(dateOf(item));
    const last = out[out.length - 1];
    if (last?.day === day) last.items.push(item);
    else out.push({ day, items: [item] });
  }
  return out;
}

/** Time of day only — the day is in the group heading. */
export const timeOf = (iso: string) =>
  new Date(iso).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
