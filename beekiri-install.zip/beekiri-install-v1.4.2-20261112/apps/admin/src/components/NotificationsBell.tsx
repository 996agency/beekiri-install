import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowCircleUp,
  Bell,
  CalendarCheck,
  CalendarX,
  ClipboardText,
  GearSix,
  ShoppingBag,
  UserPlus,
  type Icon,
} from '@phosphor-icons/react';
import { api, apiUrl } from '../api/client';
import { useAdminHref } from '../lib/AdminEntryContext';
import './notifications-bell.css';

type Notice = { id: string; kind: string; title: string; body: string; link: string; createdAt: string; unread?: boolean };

const ICONS: Record<string, Icon> = {
  'shop.order': ShoppingBag,
  'booking.new': CalendarCheck,
  'booking.cancelled': CalendarX,
  'form.entry': ClipboardText,
  'settings.updated': GearSix,
  'core.update': ArrowCircleUp,
  'user.created': UserPlus,
};

/** How long a new notification shows next to the bell. */
const TOAST_MS = 6000;
const KEEP = 40;

/** "just now", "5 min ago", "3 h ago", "Yesterday", then the date. */
function ago(iso: string, now: number): string {
  const then = new Date(iso).getTime();
  const min = Math.floor((now - then) / 60_000);
  if (min < 1) return 'just now';
  if (min < 60) return `${min} min ago`;
  const hours = Math.floor(min / 60);
  if (hours < 24) return `${hours} h ago`;
  if (hours < 48) return 'Yesterday';
  return new Date(iso).toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
}

/**
 * The bell in the toolbar: new orders, bookings, form entries, changed settings and core updates,
 * as they happen (a live stream while this tab is in view) and in a list for later.
 */
export function NotificationsBell() {
  const href = useAdminHref();
  const navigate = useNavigate();
  const [items, setItems] = useState<Notice[]>([]);
  const [unread, setUnread] = useState(0);
  const [open, setOpen] = useState(false);
  /** The one that just arrived, shown beside the bell for a moment. */
  const [toast, setToast] = useState<Notice | null>(null);
  const [ringing, setRinging] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const rootRef = useRef<HTMLDivElement>(null);
  const openRef = useRef(open);
  openRef.current = open;
  const toastTimer = useRef<number | null>(null);

  const load = useCallback(() => {
    api<{ items: Notice[]; unread: number }>('/api/notifications')
      .then((res) => {
        setItems(res.items);
        // With the list open, everything in it has been seen.
        setUnread(openRef.current ? 0 : res.unread);
        setNow(Date.now());
      })
      .catch(() => undefined);
  }, []);

  const markSeen = useCallback(() => {
    setUnread(0);
    void api('/api/notifications/seen', { method: 'POST' }).catch(() => undefined);
  }, []);

  // Live: one stream while this tab is in view. Coming back to the tab (or reconnecting) reads
  // the list again, so nothing that happened meanwhile is missed.
  useEffect(() => {
    let source: EventSource | null = null;
    const connect = () => {
      if (source || document.visibilityState !== 'visible') return;
      load();
      source = new EventSource(apiUrl('/api/notifications/stream'), { withCredentials: true });
      let dropped = false;
      source.onmessage = (e) => {
        let n: Notice;
        try {
          n = JSON.parse(e.data as string) as Notice;
        } catch {
          return;
        }
        setItems((list) => (list.some((x) => x.id === n.id) ? list : [{ ...n, unread: true }, ...list].slice(0, KEEP)));
        setNow(Date.now());
        if (openRef.current) {
          markSeen();
          return;
        }
        setUnread((count) => count + 1);
        setToast(n);
        setRinging(true);
        if (toastTimer.current) window.clearTimeout(toastTimer.current);
        toastTimer.current = window.setTimeout(() => setToast(null), TOAST_MS);
      };
      source.onerror = () => {
        dropped = true;
      };
      source.onopen = () => {
        if (dropped) load();
        dropped = false;
      };
    };
    const disconnect = () => {
      source?.close();
      source = null;
    };
    const onVisibility = () => (document.visibilityState === 'visible' ? connect() : disconnect());
    connect();
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      disconnect();
      if (toastTimer.current) window.clearTimeout(toastTimer.current);
    };
  }, [load, markSeen]);

  // The list closes on a click outside it and on Escape.
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      if (!rootRef.current?.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    window.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      window.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const toggle = () => {
    setToast(null);
    if (open) {
      // Closing: what was new has been read.
      setItems((list) => list.map((n) => (n.unread ? { ...n, unread: false } : n)));
      setOpen(false);
      return;
    }
    setNow(Date.now());
    setOpen(true);
    if (unread) markSeen();
  };

  const go = (n: Notice) => {
    setOpen(false);
    setToast(null);
    setItems((list) => list.map((x) => (x.unread ? { ...x, unread: false } : x)));
    if (unread) markSeen();
    if (n.link) navigate(href(n.link));
  };

  const row = (n: Notice, onClick: () => void) => {
    const Glyph = ICONS[n.kind] ?? Bell;
    return (
      <button type="button" className={`bk-bell__item${n.unread ? ' is-unread' : ''}`} onClick={onClick}>
        <span className="bk-bell__glyph" aria-hidden>
          <Glyph size={16} />
        </span>
        <span className="bk-bell__text">
          <strong>{n.title}</strong>
          {n.body ? <span>{n.body}</span> : null}
          <small>{ago(n.createdAt, now)}</small>
        </span>
      </button>
    );
  };

  return (
    <div className="bk-bell" ref={rootRef}>
      <button
        type="button"
        className={`ab-item bk-bell__btn${open ? ' is-open' : ''}${ringing ? ' is-ringing' : ''}`}
        aria-label={unread ? `Notifications, ${unread} new` : 'Notifications'}
        aria-haspopup="dialog"
        aria-expanded={open}
        title="Notifications"
        onClick={toggle}
        onAnimationEnd={() => setRinging(false)}
      >
        <Bell size={18} weight={unread ? 'fill' : 'regular'} aria-hidden />
        {unread ? <span className="bk-bell__count">{unread > 99 ? '99+' : unread}</span> : null}
      </button>

      {toast && !open ? (
        <div className="bk-bell__toast" role="status">
          {row(toast, () => go(toast))}
        </div>
      ) : null}

      {open ? (
        <div className="bk-bell__panel" role="dialog" aria-label="Notifications">
          <div className="bk-bell__head">
            <strong>Notifications</strong>
            <span>Live</span>
          </div>
          {items.length ? (
            <ul className="bk-bell__list">
              {items.map((n) => (
                <li key={n.id}>{row(n, () => go(n))}</li>
              ))}
            </ul>
          ) : (
            <p className="bk-bell__empty">Nothing yet. New orders, bookings, form entries and updates show up here as they happen.</p>
          )}
        </div>
      ) : null}
    </div>
  );
}
