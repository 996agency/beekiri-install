import { Fragment, useCallback, useEffect, useLayoutEffect, useRef, useState, type ClipboardEvent, type DragEvent, type KeyboardEvent, type ReactNode } from 'react';
import { gsap } from 'gsap';
import { createPortal } from 'react-dom';
import { Link } from 'react-router-dom';
import {
  ArrowCounterClockwise,
  ArrowSquareOut,
  Eye,
  Files,
  Stack,
  Article,
  ArrowUp,
  CaretDown,
  Check,
  CheckCircle,
  FileCode,
  Image,
  Layout,
  Minus,
  NotePencil,
  Paperclip,
  Plus,
  SelectionForeground,
  SelectionPlus,
  ShoppingBag,
  Stop,
  Trash,
  WarningCircle,
  X,
} from '@phosphor-icons/react';
import { useAuth } from '../auth/AuthContext';
import { useAdminHref } from '../lib/AdminEntryContext';
import { BeekiriOrb } from './BeekiriOrb';
import { ScreenshotOverlay } from './ScreenshotOverlay';
import type { BeeLink, BeeMessage, useBeeQueenChat } from './useBeeQueenChat';
import './bee-agent-chat.css';
import { formatMoney } from '../lib/money';
import { safeHref } from '../lib/safe-html';
import { selectBeekiriNode } from '../lib/admin-events';
import { canvasNodeUnder, captureRegion, clipToCanvas, type ShotRect } from '../lib/screen-capture';
import { PICTURE_TYPES, pictureFromFile, pictureFromShot, picturesFit, type ChatPicture } from '../lib/chat-pictures';

type Props = {
  open: boolean;
  agentName: string;
  /** e.g. "Claude Opus 5.5 · Max effort" */
  engineLabel: string;
  chat: ReturnType<typeof useBeeQueenChat>;
  onClose: () => void;
};

const SUGGESTIONS = [
  'Create a full About Us landing page',
  'Build a testimonials section editors can fill in',
  'Make a pricing section with three plans',
  'Review my layouts and make the hero feel more premium',
];

/** Section mode (one element from the editor). */
const SECTION_SUGGESTIONS = [
  'Rewrite the text so it sounds more confident',
  'Swap the image for a better one from the media library',
  'Give this a completely different layout',
  'Make it look great on mobile',
];

/** "3m ago", "Yesterday", "Oct 12" — for the chat history list. */
function when(iso: string): string {
  const then = new Date(iso);
  const mins = Math.round((Date.now() - then.getTime()) / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  if (mins < 60 * 24) return `${Math.round(mins / 60)}h ago`;
  if (mins < 60 * 48) return 'Yesterday';
  return then.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

/** **bold** and `code` inside one line of text. */
function inline(text: string): ReactNode[] {
  return text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**') && part.length > 4) return <strong key={i}>{part.slice(2, -2)}</strong>;
    if (part.startsWith('`') && part.endsWith('`') && part.length > 2) return <code key={i}>{part.slice(1, -1)}</code>;
    return <Fragment key={i}>{part}</Fragment>;
  });
}

/** Small markdown subset for replies: paragraphs, headings, bullet and numbered lists. */
function RichText({ text }: { text: string }) {
  const blocks: ReactNode[] = [];
  const lines = text.replace(/\r/g, '').split('\n');
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) {
      i++;
      continue;
    }
    const bullet = /^\s*[-*•]\s+/;
    const numbered = /^\s*\d+[.)]\s+/;
    if (bullet.test(line) || numbered.test(line)) {
      const ordered = numbered.test(line);
      const re = ordered ? numbered : bullet;
      const items: string[] = [];
      while (i < lines.length && re.test(lines[i])) items.push(lines[i++].replace(re, ''));
      const ListTag = ordered ? 'ol' : 'ul';
      blocks.push(
        <ListTag key={blocks.length}>
          {items.map((item, k) => (
            <li key={k}>{inline(item)}</li>
          ))}
        </ListTag>,
      );
      continue;
    }
    const heading = line.match(/^#{1,4}\s+(.*)$/);
    if (heading) {
      blocks.push(
        <p key={blocks.length} className="bk-bee-chat__h">
          {inline(heading[1])}
        </p>,
      );
      i++;
      continue;
    }
    const para: string[] = [];
    while (i < lines.length && lines[i].trim() && !bullet.test(lines[i]) && !numbered.test(lines[i]) && !/^#{1,4}\s/.test(lines[i])) {
      para.push(lines[i++]);
    }
    blocks.push(<p key={blocks.length}>{inline(para.join(' '))}</p>);
  }
  return <>{blocks}</>;
}

const LINK_ICONS: Record<BeeLink['kind'], typeof FileCode> = {
  page: NotePencil,
  post: Article,
  product: ShoppingBag,
  media: Image,
  layout: Layout,
  file: FileCode,
  type: Stack,
  entry: Files,
};
const LINK_KINDS: Record<BeeLink['kind'], string> = {
  page: 'Page',
  post: 'Blog post',
  product: 'Product',
  media: 'Photo',
  layout: 'Layout',
  file: 'Theme file',
  type: 'Content type',
  entry: 'Entry',
};

function LinkChip({ link, onNavigate }: { link: BeeLink; onNavigate: () => void }) {
  const href = useAdminHref();
  const Icon = LINK_ICONS[link.kind] ?? FileCode;
  const kind = LINK_KINDS[link.kind] ?? 'Theme file';
  return (
    <span className="bk-bee-chat__link">
      <Icon size={15} aria-hidden />
      <span className="bk-bee-chat__link-text">
        <small>{link.preview ? `${kind} · not public yet` : kind}</small>
        {link.label}
      </span>
      {link.admin ? (
        <Link to={href(link.admin)} onClick={onNavigate} className="bk-bee-chat__link-action">
          {link.kind === 'page' || link.kind === 'post' || link.kind === 'product' ? 'Edit' : 'Open'}
        </Link>
      ) : null}
      {link.url ? (
        <a
          href={safeHref(link.url)}
          target="_blank"
          rel="noreferrer"
          className="bk-bee-chat__link-action"
          aria-label={`${link.preview ? 'Preview' : 'View'} ${link.label}`}
          title={link.preview ? 'A private preview with what is waiting for Keep — visitors don’t see it yet' : undefined}
        >
          {link.preview ? 'Preview' : 'View'} <ArrowSquareOut size={12} aria-hidden />
        </a>
      ) : null}
    </span>
  );
}

function AssistantMessage({
  message,
  onNavigate,
  canManage,
  onKeep,
  onUndo,
  onPreview,
}: {
  message: BeeMessage;
  onNavigate: () => void;
  canManage: boolean;
  /** Section mode: keep or undo this reply's change (only on the latest change). */
  onKeep?: () => void;
  onUndo?: () => void;
  onPreview?: () => void;
}) {
  const href = useAdminHref();
  const [showSteps, setShowSteps] = useState(false);
  const steps = message.steps ?? [];
  const running = message.state === 'running';
  const current = steps[steps.length - 1];

  return (
    <div className={`bk-bee-chat__msg is-assistant is-${message.state ?? 'done'}`}>
      {/* While it works, only the steps show (the header says Beekiri is working). */}
      {running ? null : <BeekiriOrb size={30} still className="bk-bee-chat__avatar" />}
      <div className="bk-bee-chat__body">
        {running ? (
          <div className="bk-bee-chat__live" aria-live="polite">
            <ol className="bk-bee-chat__steps">
              {steps.slice(-6).map((s, i, arr) => (
                <li key={steps.length - arr.length + i} className={`is-${s.kind}${i === arr.length - 1 ? ' is-current' : ''}`}>
                  {s.text}
                </li>
              ))}
            </ol>
            <p className="bk-bee-chat__thinking">
              <span className="bk-bee-chat__shimmer">{current?.kind === 'status' ? `${current.text}…` : 'Thinking…'}</span>
            </p>
          </div>
        ) : (
          <>
            {message.state === 'error' ? (
              <div className="bk-bee-chat__error">
                <WarningCircle size={16} weight="fill" aria-hidden />
                <span>{message.text}</span>
                {message.needsCredits && canManage ? (
                  <Link to={href('connector')} onClick={onNavigate} className="bk-bee-chat__link-action">
                    Open Connector
                  </Link>
                ) : null}
              </div>
            ) : (
              <div className="bk-bee-chat__text">
                <RichText text={message.text} />
              </div>
            )}
            {(message.applied || message.changed) && !message.decision && onKeep && onUndo ? (
              <div className="bk-bee-chat__decide" role="group" aria-label="Keep or undo this change">
                <span className="bk-bee-chat__decide-icon" aria-hidden>
                  <Check size={15} weight="bold" />
                </span>
                <span className="bk-bee-chat__decide-copy">
                  <strong>{message.applied ? 'Applied in the editor' : 'Waiting for you'}</strong>
                  <small>
                    {message.applied
                      ? 'Keep it, or undo to put the section back.'
                      : 'New sections stay hidden from visitors until you keep them. Undo puts everything back as it was.'}
                  </small>
                </span>
                <span className="bk-bee-chat__decide-actions">
                  {onPreview && !message.applied ? (
                    <button type="button" className="bk-bee-chat__decide-undo" onClick={onPreview}>
                      <Eye size={14} aria-hidden /> Preview
                    </button>
                  ) : null}
                  <button type="button" className="bk-bee-chat__decide-undo" onClick={onUndo}>
                    <ArrowCounterClockwise size={14} aria-hidden /> Undo
                  </button>
                  <button type="button" className="bk-bee-chat__decide-keep" onClick={onKeep}>
                    <Check size={14} weight="bold" aria-hidden /> Keep
                  </button>
                </span>
              </div>
            ) : message.applied || (message.changed && message.decision) ? (
              <p className="bk-bee-chat__applied">
                <CheckCircle size={13} weight="fill" aria-hidden />{' '}
                {message.decision === 'kept' ? 'Kept' : message.decision === 'undone' ? 'Undone' : 'Applied in the editor'}
              </p>
            ) : null}
            {message.links?.length ? (
              <div className="bk-bee-chat__links">
                {message.links.map((l) => (
                  <LinkChip key={`${l.kind}:${l.label}`} link={l} onNavigate={onNavigate} />
                ))}
              </div>
            ) : null}
            {steps.length || message.cost ? (
              <div className="bk-bee-chat__trace">
                <button
                  type="button"
                  className="bk-bee-chat__trace-toggle"
                  aria-expanded={showSteps}
                  onClick={() => setShowSteps((v) => !v)}
                >
                  {message.state === 'done' ? <CheckCircle size={13} weight="fill" aria-hidden /> : null}
                  {steps.filter((s) => s.kind === 'status').length} steps
                  <CaretDown size={11} aria-hidden className={showSteps ? 'is-open' : ''} />
                </button>
                {message.cost ? (
                  <span className="bk-bee-chat__cost" title="What this message cost, taken from the Beekiri balance">
                    <img src="/admin/connector/claude.svg" alt="" width={12} height={12} draggable={false} /> {formatMoney(message.cost, 'USD', true)}
                  </span>
                ) : null}
                {showSteps ? (
                  <ol className="bk-bee-chat__steps is-done">
                    {steps.map((s, i) => (
                      <li key={i} className={`is-${s.kind}`}>
                        {s.text}
                      </li>
                    ))}
                  </ol>
                ) : null}
              </div>
            ) : null}
          </>
        )}
      </div>
    </div>
  );
}

/** "Show Beekiri what to change" stays hidden once the owner says Not now. */
const SHOT_TIP_KEY = 'bk-beekiri-shot-tip';

function readTipDismissed(): boolean {
  try {
    return localStorage.getItem(SHOT_TIP_KEY) === 'off';
  } catch {
    return false;
  }
}

/** Your chats: a menu that opens above the bar — New chat first, then the saved ones. */
function ChatsMenu({ chat, onDone }: { chat: Props['chat']; onDone: () => void }) {
  const { chats, chatId, running, newChat, openChat, deleteChat } = chat;
  return (
    <div className="bk-bee-chat__menu" role="menu" aria-label="Your chats">
      <button
        type="button"
        role="menuitem"
        className="bk-bee-chat__menu-new"
        disabled={running}
        onClick={() => {
          newChat();
          onDone();
        }}
      >
        <Plus size={14} weight="bold" aria-hidden /> New chat
      </button>
      {chats.length === 0 ? (
        <p className="bk-bee-chat__history-empty">No saved chats yet. Your conversations with Beekiri appear here.</p>
      ) : (
        <ul className="bk-bee-chat__history">
          {chats.map((c) => (
            <li key={c.id} className={c.id === chatId ? 'is-current' : ''}>
              <button
                type="button"
                role="menuitem"
                className="bk-bee-chat__history-open"
                disabled={running}
                onClick={() => {
                  void openChat(c.id);
                  onDone();
                }}
              >
                <span>{c.title || 'Untitled chat'}</span>
                <small>{when(c.updatedAt)}</small>
              </button>
              <button
                type="button"
                className="bk-bee-chat__history-delete"
                aria-label={`Delete “${c.title}”`}
                title="Delete chat"
                disabled={running && c.id === chatId}
                onClick={() => {
                  if (window.confirm(`Delete “${c.title || 'this chat'}”? This can't be undone.`)) void deleteChat(c.id);
                }}
              >
                <Trash size={14} aria-hidden />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/**
 * Beekiri chat — a command bar at the bottom of the screen that opens upward into the conversation.
 * Claude builds layouts, Backend Fields and pages inside the active theme; a screenshot of any part
 * of the screen can ride along, and one taken over the page editor's canvas selects that element.
 * A picture of a design (uploaded, pasted or dropped in) is a reference Beekiri builds from.
 */
export function BeeAgentChat({ open, agentName, engineLabel, chat, onClose }: Props) {
  const auth = useAuth();
  const canManage = Boolean(auth.user?.isOwner || auth.user?.capabilities.includes('manage_options'));
  const [draft, setDraft] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const seenRef = useRef(0);
  const [menuOpen, setMenuOpen] = useState(false);
  /** Drag-to-screenshot: the overlay is up, then the picture is being made. */
  const [capturing, setCapturing] = useState(false);
  const [shooting, setShooting] = useState(false);
  /** A design reference being read from a file. */
  const [reading, setReading] = useState(false);
  const [dropping, setDropping] = useState(false);
  const [pictures, setPictures] = useState<ChatPicture[]>([]);
  const picturesRef = useRef(pictures);
  picturesRef.current = pictures;
  const fileRef = useRef<HTMLInputElement>(null);
  const [shotError, setShotError] = useState('');
  const [tipDismissed, setTipDismissed] = useState(readTipDismissed);
  const { messages, running, loading, send, stop, newChat, chats, chatId, load, section } = chat;
  /** Keep / Undo is offered on the latest change only (a whole reply's saves need an admin to undo). */
  const lastAppliedId =
    [...messages]
      .reverse()
      .find((m) => m.role === 'assistant' && !m.decision && (m.applied || (m.changed && m.runId && canManage)))?.id ?? null;
  const lastSteps = messages[messages.length - 1]?.steps?.length ?? 0;
  /** The bar opens upward once there is a conversation to show. */
  const expanded = loading || messages.length > 0;
  const chatTitle = chatId ? chats.find((c) => c.id === chatId)?.title : null;

  useEffect(() => {
    if (open) void load();
  }, [open, load]);

  // ── Motion (GSAP) — calm and quick; nothing moves when the OS asks for reduced motion.
  const calm = () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  useLayoutEffect(() => {
    const panel = panelRef.current;
    if (!open || !panel || calm()) return;
    const tween = gsap.fromTo(
      panel,
      { autoAlpha: 0, y: 24, scale: 0.985 },
      { autoAlpha: 1, y: 0, scale: 1, duration: 0.5, ease: 'expo.out', clearProps: 'transform,opacity,visibility' },
    );
    return () => {
      tween.kill();
    };
    // Only when the chat opens.
  }, [open]);

  // New messages rise in; opening an old chat brings its last few in with a short stagger.
  useLayoutEffect(() => {
    const list = scrollRef.current?.querySelectorAll<HTMLElement>('.bk-bee-chat__msg');
    const count = list?.length ?? 0;
    if (!list || calm() || count <= seenRef.current) {
      seenRef.current = count;
      return;
    }
    const fresh = Array.from(list).slice(Math.max(seenRef.current, count - 4));
    seenRef.current = count;
    gsap.fromTo(
      fresh,
      { autoAlpha: 0, y: 12 },
      { autoAlpha: 1, y: 0, duration: 0.45, ease: 'power3.out', stagger: 0.06, clearProps: 'transform,opacity,visibility' },
    );
  }, [messages.length, open]);

  // Keep / Undo pops in once, when a change lands.
  useLayoutEffect(() => {
    if (!lastAppliedId || calm()) return;
    const card = scrollRef.current?.querySelector('.bk-bee-chat__decide');
    if (card) gsap.fromTo(card, { autoAlpha: 0, scale: 0.96, y: 6 }, { autoAlpha: 1, scale: 1, y: 0, duration: 0.5, ease: 'back.out(1.8)', clearProps: 'transform,opacity,visibility' });
  }, [lastAppliedId]);

  // The chats menu closes on a click outside it, and Escape closes the menu before the chat.
  useEffect(() => {
    if (!menuOpen) return;
    const onDown = (e: MouseEvent) => {
      if (!menuRef.current?.contains(e.target as Node)) setMenuOpen(false);
    };
    const onKey = (e: globalThis.KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      e.stopImmediatePropagation();
      setMenuOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    window.addEventListener('keydown', onKey, true);
    return () => {
      document.removeEventListener('mousedown', onDown);
      window.removeEventListener('keydown', onKey, true);
    };
  }, [menuOpen]);

  useEffect(() => {
    if (!open) return;
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [open, messages.length, lastSteps, running]);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  useEffect(() => {
    const el = inputRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 160)}px`;
  }, [draft]);

  /** Adds a picture to the next message; false when the message is full. */
  const addPicture = useCallback((picture: ChatPicture) => {
    const next = [...picturesRef.current, picture];
    if (!picturesFit(next)) {
      setShotError('That is as many pictures as Beekiri can read in one message. Remove one to add another.');
      return false;
    }
    picturesRef.current = next;
    setPictures(next);
    return true;
  }, []);

  // Uploaded, pasted or dropped pictures become design references.
  const addFiles = useCallback(
    async (files: File[]) => {
      const images = files.filter((file) => file.type.startsWith('image/'));
      if (!images.length) {
        if (files.length) setShotError('Beekiri can read pictures only: PNG, JPEG, WebP, GIF or AVIF.');
        return;
      }
      setReading(true);
      setShotError('');
      try {
        for (const file of images) {
          if (!addPicture(await pictureFromFile(file))) break;
        }
      } catch (error) {
        setShotError(error instanceof Error && error.message ? error.message : 'That picture could not be read.');
      } finally {
        setReading(false);
        inputRef.current?.focus();
      }
    },
    [addPicture],
  );

  // The drag ended: hide the overlay, select the element it covered on the canvas, then take the picture.
  const onShotDone = useCallback(async (rect: ShotRect | null) => {
    setCapturing(false);
    if (!rect) {
      inputRef.current?.focus();
      return;
    }
    setShooting(true);
    setShotError('');
    try {
      // Let the overlay go first, so neither it nor the chat is under the area.
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      const area = clipToCanvas(rect);
      const nodeId = canvasNodeUnder(area);
      if (nodeId) selectBeekiriNode(nodeId);
      addPicture(pictureFromShot(await captureRegion(area)));
    } catch (error) {
      setShotError(error instanceof Error && error.message ? `The screenshot failed: ${error.message}` : 'The screenshot failed. Try a smaller area.');
    } finally {
      setShooting(false);
      inputRef.current?.focus();
    }
  }, [addPicture]);

  if (!open || typeof document === 'undefined') return null;

  const startShot = () => {
    setMenuOpen(false);
    setShotError('');
    setCapturing(true);
  };

  const dismissTip = () => {
    setTipDismissed(true);
    try {
      localStorage.setItem(SHOT_TIP_KEY, 'off');
    } catch {
      /* storage blocked — hidden until the next visit */
    }
  };

  const submit = (text = draft) => {
    if (!text.trim() || running || shooting || reading) return;
    void send(text, pictures);
    setDraft('');
    setPictures([]);
    setShotError('');
  };

  const removePicture = (id: string) => {
    setPictures((list) => list.filter((p) => p.id !== id));
    setShotError('');
  };

  // A picture on the clipboard (a Mac screenshot, a copied image) is attached; text pastes as usual.
  const onPaste = (e: ClipboardEvent<HTMLDivElement>) => {
    const files = Array.from(e.clipboardData.files).filter((file) => file.type.startsWith('image/'));
    if (!files.length) return;
    e.preventDefault();
    void addFiles(files);
  };

  const onDragOver = (e: DragEvent<HTMLDivElement>) => {
    if (!e.dataTransfer.types.includes('Files')) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    setDropping(true);
  };

  const onDrop = (e: DragEvent<HTMLDivElement>) => {
    if (!e.dataTransfer.types.includes('Files')) return;
    e.preventDefault();
    setDropping(false);
    void addFiles(Array.from(e.dataTransfer.files));
  };

  /**
   * Preview opens the page this reply made or changed in a new tab. The tab opens on the click
   * (a tab opened after waiting for the server would be blocked as a pop-up), then goes to the link.
   */
  const openPreview = (messageId: string) => {
    const tab = window.open('about:blank', '_blank');
    void chat.previewRun(messageId).then((url) => {
      if (!tab) {
        if (url) window.open(url, '_blank', 'noopener');
        return;
      }
      if (!url) {
        tab.close();
        return;
      }
      tab.opener = null;
      tab.location.href = url;
    });
  };

  // An idea goes into the input to read or edit first; the arrow (or Enter) sends it.
  const pickSuggestion = (text: string) => {
    setDraft(text);
    requestAnimationFrame(() => {
      const el = inputRef.current;
      if (!el) return;
      el.focus();
      el.setSelectionRange(text.length, text.length);
    });
  };

  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      submit();
    }
  };

  const attaching = shooting || reading;
  const hasReference = pictures.some((p) => p.kind === 'reference');
  const showTip = !tipDismissed && !pictures.length && !attaching && !expanded;
  const showSuggestions = tipDismissed && !pictures.length && !attaching && !expanded && !draft;

  return (
    <>
      {createPortal(
        <div
          className={`bk-bee-chat is-bar${expanded ? ' is-expanded' : ''}${capturing || shooting ? ' is-capturing' : ''}`}
          role="dialog"
          aria-modal="false"
          aria-label={`${agentName} assistant`}
        >
          <div
            className={`bk-bee-chat__panel${dropping ? ' is-dropping' : ''}`}
            ref={panelRef}
            onPaste={onPaste}
            onDragOver={onDragOver}
            onDragLeave={(e) => {
              if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setDropping(false);
            }}
            onDrop={onDrop}
          >
            {expanded ? (
              <>
                <div className="bk-bee-chat__bar">
                  <div className="bk-bee-chat__titles">
                    <strong>{chatTitle || agentName}</strong>
                    <span className="bk-bee-chat__engine">
                      <img src="/admin/connector/claude.svg" alt="" width={12} height={12} draggable={false} />
                      {engineLabel}
                    </span>
                  </div>
                  <div className="bk-bee-chat__bar-actions">
                    <button
                      type="button"
                      className="bk-bee-chat__icon-btn"
                      onClick={newChat}
                      disabled={running}
                      aria-label="New chat"
                      title="New chat"
                    >
                      <NotePencil size={17} aria-hidden />
                    </button>
                    {/* A minus, not an X: the chat only steps aside, and a run keeps going. */}
                    <button
                      type="button"
                      className="bk-bee-chat__icon-btn"
                      aria-label="Minimize"
                      title={running ? `Minimize (Esc): ${agentName} keeps working` : 'Minimize (Esc): the chat stays as it is'}
                      onClick={onClose}
                    >
                      <Minus size={17} aria-hidden />
                    </button>
                  </div>
                </div>
                <div className="bk-bee-chat__scroll" ref={scrollRef}>
                  {loading ? (
                    <p className="bk-bee-chat__loading">
                      <span className="bk-bee-chat__spinner" aria-hidden /> Opening chat…
                    </p>
                  ) : (
                    messages.map((m) =>
                      m.role === 'user' ? (
                        <div key={m.id} className="bk-bee-chat__msg is-user">
                          <div className="bk-bee-chat__bubble">
                            {m.images?.length ? (
                              <span className="bk-bee-chat__bubble-shots">
                                {m.images.map((src, i) => (
                                  <img key={i} className="bk-bee-chat__bubble-shot" src={src} alt="Picture sent to Beekiri" />
                                ))}
                              </span>
                            ) : null}
                            {m.text}
                          </div>
                        </div>
                      ) : (
                        <AssistantMessage
                          key={m.id}
                          message={m}
                          onNavigate={onClose}
                          canManage={canManage}
                          {...(m.id === lastAppliedId && !running
                            ? {
                                onKeep: () => (m.applied ? chat.keepChange(m.id) : void chat.keepRun(m.id)),
                                onUndo: () => (m.applied ? chat.undoChange(m.id) : void chat.undoRun(m.id)),
                                onPreview: () => openPreview(m.id),
                              }
                            : {})}
                        />
                      ),
                    )
                  )}
                </div>
              </>
            ) : (
              <button type="button" className="bk-bee-chat__close" aria-label="Minimize" title="Minimize (Esc)" onClick={onClose}>
                <Minus size={13} weight="bold" aria-hidden />
              </button>
            )}

            <form
              className="bk-bee-chat__composer"
              onSubmit={(e) => {
                e.preventDefault();
                submit();
              }}
            >
              <BeekiriOrb size={32} busy={running} className="bk-bee-chat__mark" />
              <textarea
                ref={inputRef}
                rows={1}
                value={draft}
                placeholder={
                  running
                    ? `${agentName} is working…`
                    : hasReference
                      ? 'What should Beekiri make from this picture?'
                      : pictures.length
                        ? 'What should change here?'
                      : section
                        ? `What should change in ${section.label}?`
                        : 'What can I build for you today?'
                }
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={onKeyDown}
                aria-label={`Message ${agentName}`}
              />
              <input
                ref={fileRef}
                type="file"
                accept={PICTURE_TYPES}
                multiple
                hidden
                onChange={(e) => {
                  void addFiles(Array.from(e.target.files ?? []));
                  e.target.value = '';
                }}
              />
              <button
                type="button"
                className="bk-bee-chat__icon-btn"
                onClick={() => fileRef.current?.click()}
                disabled={attaching}
                aria-label="Attach a picture"
                title="Attach a picture of a design to build from (or paste one, or drop it here)"
              >
                <Paperclip size={18} aria-hidden />
              </button>
              <button
                type="button"
                className={`bk-bee-chat__icon-btn${capturing ? ' is-active' : ''}`}
                onClick={startShot}
                disabled={running || attaching}
                aria-label="Take a screenshot"
                title="Drag over any part of the screen to show Beekiri"
              >
                <SelectionPlus size={18} aria-hidden />
              </button>
              <div className="bk-bee-chat__chats" ref={menuRef}>
                <button
                  type="button"
                  className={`bk-bee-chat__chats-btn${menuOpen ? ' is-active' : ''}`}
                  aria-haspopup="menu"
                  aria-expanded={menuOpen}
                  onClick={() => setMenuOpen((v) => !v)}
                >
                  <span>{chatId ? chatTitle || 'This chat' : 'New chat'}</span>
                  <CaretDown size={12} aria-hidden className={menuOpen ? 'is-open' : ''} />
                </button>
                {menuOpen ? <ChatsMenu chat={chat} onDone={() => setMenuOpen(false)} /> : null}
              </div>
              {running ? (
                <button type="button" className="bk-bee-chat__send is-stop" onClick={stop} aria-label="Stop">
                  <Stop size={16} weight="fill" aria-hidden />
                </button>
              ) : (
                <button type="submit" className="bk-bee-chat__send" disabled={!draft.trim() || attaching} aria-label="Send">
                  <ArrowUp size={16} weight="bold" aria-hidden />
                </button>
              )}
            </form>

            {section || pictures.length || attaching || shotError || showTip || showSuggestions ? (
              <div className="bk-bee-chat__extras">
                {section ? (
                  <div
                    className="bk-bee-chat__scope"
                    title="Beekiri works only on this element: its text, images, layout and style. Changes land in the editor as one step, and Undo takes them back."
                  >
                    <SelectionForeground size={14} aria-hidden />
                    <span>
                      Editing <strong>{section.label}</strong> only
                    </span>
                    <button
                      type="button"
                      className="bk-bee-chat__scope-close"
                      onClick={chat.leaveSection}
                      disabled={running}
                      aria-label="Stop working on this element"
                      title="Work on the whole site instead"
                    >
                      <X size={12} aria-hidden />
                    </button>
                  </div>
                ) : null}
                {pictures.length || attaching ? (
                  <div className="bk-bee-chat__shot">
                    {pictures.map((p) => (
                      <span key={p.id} className="bk-bee-chat__pic">
                        <img src={p.thumb} alt={p.kind === 'reference' ? 'Design reference' : 'Screenshot'} />
                        <button
                          type="button"
                          onClick={() => removePicture(p.id)}
                          aria-label={p.kind === 'reference' ? 'Remove the picture' : 'Remove the screenshot'}
                          title="Remove"
                        >
                          <X size={10} weight="bold" aria-hidden />
                        </button>
                      </span>
                    ))}
                    {attaching ? <span className="bk-bee-chat__spinner" aria-hidden /> : null}
                    <span className="bk-bee-chat__shot-copy">
                      {attaching ? (
                        <strong>{shooting ? 'Taking the screenshot…' : 'Reading the picture…'}</strong>
                      ) : pictures.length > 1 ? (
                        <>
                          <strong>{pictures.length} pictures attached</strong>
                          <small>{hasReference ? 'Beekiri builds from what they show' : 'Beekiri sees them with your message'}</small>
                        </>
                      ) : (
                        <>
                          <strong>{hasReference ? 'Design reference attached' : 'Screenshot attached'}</strong>
                          <small>
                            {pictures[0].width} × {pictures[0].height} · {hasReference ? 'Beekiri builds from what it shows' : 'Beekiri sees it with your message'}
                          </small>
                        </>
                      )}
                    </span>
                  </div>
                ) : null}
                {shotError ? (
                  <div className="bk-bee-chat__error" role="alert">
                    <WarningCircle size={16} weight="fill" aria-hidden />
                    <span>{shotError}</span>
                  </div>
                ) : null}
                {showTip ? (
                  <div className="bk-bee-chat__tip">
                    <span className="bk-bee-chat__shot-copy">
                      <strong>Show Beekiri what you mean</strong>
                      <small>Screenshot the page, or add a picture of a design to copy</small>
                    </span>
                    <button type="button" className="bk-bee-chat__ghost-btn" onClick={startShot} disabled={running}>
                      Take screenshot
                    </button>
                    <button type="button" className="bk-bee-chat__ghost-btn" onClick={() => fileRef.current?.click()}>
                      Add picture
                    </button>
                    <button type="button" className="bk-bee-chat__ghost-btn" onClick={dismissTip}>
                      Not now
                    </button>
                  </div>
                ) : null}
                {showSuggestions ? (
                  <div className="bk-bee-chat__suggestions">
                    {(section ? SECTION_SUGGESTIONS : SUGGESTIONS).map((s) => (
                      <button key={s} type="button" onClick={() => pickSuggestion(s)} disabled={running}>
                        {s}
                      </button>
                    ))}
                  </div>
                ) : null}
              </div>
            ) : null}
          </div>
        </div>,
        // Inside the full-screen page editor's own layer when it is open, so the editor's menus
        // and dialogs stack above the chat and the canvas below it.
        document.querySelector('.bk-page-editor') ?? document.body,
      )}
      {capturing ? <ScreenshotOverlay onDone={onShotDone} /> : null}
    </>
  );
}
