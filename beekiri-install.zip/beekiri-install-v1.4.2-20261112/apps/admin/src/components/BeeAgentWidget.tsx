import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import {
  BEEKIRI_ASK_SECTION,
  BEEKIRI_CHAT_OPENED,
  BEEKIRI_FOLLOW_SELECTION,
  BEEKIRI_OPEN_CHAT,
  CONNECTOR_CHANGED,
  type BeekiriFollowSelection,
  type BeekiriSectionTarget,
} from '../lib/admin-events';
import { CONNECTOR_COMING_SOON } from '../lib/features';
import { BeeAgentChat } from './BeeAgentChat';
import { useBeeQueenChat } from './useBeeQueenChat';

export type BeeQueenStatus = {
  available: boolean;
  reason: string;
  engine: 'service' | 'api' | 'claude-code' | null;
  model: string | null;
  effort: string | null;
  /** The prepaid balance and this month's spend, when 996Agency bills this site. */
  usage: { enabled: true; monthCost: { amount: number; label: string }; balance: number; currency: string } | { enabled: false };
};

const MODEL_LABELS: Record<string, string> = {
  'claude-opus-5-5': 'Claude Opus 5.5',
  'claude-sonnet-5-5': 'Claude Sonnet 5.5',
  'claude-haiku-5-5': 'Claude Haiku 5.5',
  'claude-fable-5-1': 'Claude Fable 5.1',
};

const EFFORT_LABELS: Record<string, string> = {
  low: 'Low effort',
  medium: 'Medium effort',
  high: 'High effort',
  xhigh: 'Extra-high effort',
  max: 'Max effort',
};

/**
 * Beekiri chat — for anyone allowed to use BeeQueen once she is switched on.
 * Opened from the header Usage pill or the page editor's "Ask Beekiri".
 */
export function BeeAgentWidget() {
  const auth = useAuth();
  const allowed =
    !CONNECTOR_COMING_SOON && Boolean(auth.user?.isOwner || auth.user?.capabilities.includes('use_beequeen'));
  const [status, setStatus] = useState<BeeQueenStatus | null>(null);
  const [open, setOpen] = useState(false);
  const chat = useBeeQueenChat();

  const load = useCallback(() => {
    if (!allowed) return;
    api<BeeQueenStatus>('/api/connector/beequeen/status')
      .then(setStatus)
      .catch(() => setStatus(null));
  }, [allowed]);

  useEffect(() => {
    load();
    window.addEventListener(CONNECTOR_CHANGED, load);
    return () => window.removeEventListener(CONNECTOR_CHANGED, load);
  }, [load]);

  // Outside the page editor the chat starts fresh instead of reopening an element conversation.
  const { leaveEditor, freshIfSettled } = chat;
  const openRef = useRef(open);
  openRef.current = open;
  const reveal = useCallback(() => {
    if (!document.querySelector('.bk-page-editor')) leaveEditor();
    // Opened again after its change was kept or undone: that work is done, so the chat starts new.
    if (!openRef.current) freshIfSettled();
    setOpen(true);
  }, [leaveEditor, freshIfSettled]);

  // The Usage pill in the toolbar opens the chat.
  useEffect(() => {
    window.addEventListener(BEEKIRI_OPEN_CHAT, reveal);
    return () => window.removeEventListener(BEEKIRI_OPEN_CHAT, reveal);
  }, [reveal]);

  // Opening the chat picks up whatever is selected in the page editor right now.
  useEffect(() => {
    if (open) window.dispatchEvent(new Event(BEEKIRI_CHAT_OPENED));
  }, [open]);

  // While the chat is open, it follows the element selected in the page editor.
  const { followSection } = chat;
  useEffect(() => {
    if (!open) return;
    const onSelect = (e: Event) => {
      const d = (e as CustomEvent<BeekiriFollowSelection>).detail;
      followSection(d.nodeId ? { pageId: d.pageId, nodeId: d.nodeId, label: d.label } : null);
    };
    window.addEventListener(BEEKIRI_FOLLOW_SELECTION, onSelect);
    return () => window.removeEventListener(BEEKIRI_FOLLOW_SELECTION, onSelect);
  }, [open, followSection]);

  // The page editor's "Ask Beekiri": a fresh chat about that one element.
  const { enterSection } = chat;
  useEffect(() => {
    const onAsk = (e: Event) => {
      // While another run is going, the chat just opens on it.
      enterSection((e as CustomEvent<BeekiriSectionTarget>).detail);
      setOpen(true);
    };
    window.addEventListener(BEEKIRI_ASK_SECTION, onAsk);
    return () => window.removeEventListener(BEEKIRI_ASK_SECTION, onAsk);
  }, [enterSection]);


  const shown = Boolean(status?.available);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  if (!shown || !status) return null;

  const engineLabel =
    [
      MODEL_LABELS[status.model ?? ''] ?? status.model,
      EFFORT_LABELS[status.effort ?? ''],
      status.engine === 'claude-code' ? 'via Claude Code on this Mac' : '',
    ]
      .filter(Boolean)
      .join(' · ') || 'Claude';

  return (
    <BeeAgentChat
      open={open}
      agentName="Beekiri"
      engineLabel={engineLabel}
      chat={chat}
      onClose={() => setOpen(false)}
    />
  );
}
