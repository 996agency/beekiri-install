import type { CSSProperties } from 'react';
import './beekiri-orb.css';

type Props = {
  /** Diameter in px. */
  size?: number;
  /** Letters that glow one after another inside the ring (e.g. "Beekiri" while it works). */
  text?: string;
  /** Ring holds still (finished replies); `busy` spins it faster (a run is going). */
  still?: boolean;
  busy?: boolean;
  className?: string;
};

/** Beekiri's mark: a glowing orange ring that turns, with optional letters pulsing inside. */
export function BeekiriOrb({ size = 32, text, still = false, busy = false, className = '' }: Props) {
  // The glow is drawn for a 180px ring; small rings keep a floor so it stays visible.
  const style = { '--orb-size': `${size}px`, '--orb-k': Math.max(size / 180, 0.28) } as CSSProperties;
  return (
    <span
      className={`bk-orb${still ? ' is-still' : ''}${busy ? ' is-busy' : ''}${className ? ` ${className}` : ''}`}
      style={style}
      {...(text ? { role: 'img', 'aria-label': text } : { 'aria-hidden': true })}
    >
      {text
        ? text.split('').map((letter, i) => (
            <span key={i} className="bk-orb__letter" style={{ animationDelay: `${i * 0.1}s` }} aria-hidden>
              {letter}
            </span>
          ))
        : null}
      <span className="bk-orb__ring" aria-hidden />
    </span>
  );
}
