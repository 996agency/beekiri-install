import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { CheckCircle, WarningCircle } from '@phosphor-icons/react';
import './theme-switch-overlay.css';

type Phase = 'working' | 'done' | 'error';
/** What the overlay says while it works, when it is done and when it fails (defaults: a theme switch). */
export type ProgressCopy = { working: string; steps: string[]; done: string; error: string; errorNote: string };
type State = { name: string; phase: Phase; detail: string; copy: ProgressCopy };

const SWITCH_COPY = (name: string): ProgressCopy => ({
  working: `Switching to ${name}…`,
  steps: ['Saving your current pages and menu', 'Bringing in the theme’s pages', 'Restoring its menu, header and footer', 'Refreshing the website'],
  done: `We’ve switched your theme to ${name}`,
  error: `Couldn’t switch to ${name}`,
  errorNote: 'Your site is still on the previous theme.',
});

/** The bar stays up at least this long, so a fast switch still reads as a step. */
const MIN_MS = 1400;
/** After a switch the admin reloads by itself (menus, header, footer and pages change with it). */
const RELOAD_MS = 2500;

function reloadAdmin(): void {
  window.location.reload();
}

/**
 * Progress overlay for switching themes (and other theme-wide jobs such as resetting a theme's
 * pages: pass `copy`). `run(name, task)` shows a filling bar with the steps, then the success
 * message and reloads the admin. The task returns the success detail, or throws.
 */
export function useThemeSwitch(siteHref: string): {
  overlay: ReactNode;
  run: (name: string, task: () => Promise<string>, copy?: ProgressCopy) => Promise<boolean>;
} {
  const [state, setState] = useState<State | null>(null);

  const run = useCallback(async (name: string, task: () => Promise<string>, copy?: ProgressCopy) => {
    const text = copy ?? SWITCH_COPY(name);
    setState({ name, phase: 'working', detail: '', copy: text });
    const started = Date.now();
    try {
      const detail = await task();
      await new Promise((r) => setTimeout(r, Math.max(0, MIN_MS - (Date.now() - started))));
      setState({ name, phase: 'done', detail, copy: text });
      return true;
    } catch (e) {
      setState({ name, phase: 'error', detail: e instanceof Error ? e.message : 'Something went wrong.', copy: text });
      return false;
    }
  }, []);

  return {
    overlay: state ? <ThemeSwitchOverlay {...state} siteHref={siteHref} onClose={() => setState(null)} /> : null,
    run,
  };
}

function ThemeSwitchOverlay({ phase, detail, copy, siteHref, onClose }: State & { siteHref: string; onClose: () => void }) {
  const STEPS = copy.steps;
  const [step, setStep] = useState(0);

  // A switch changes what the whole admin shows, so it reloads once the success is on screen.
  useEffect(() => {
    if (phase !== 'done') return;
    const id = window.setTimeout(reloadAdmin, RELOAD_MS);
    return () => window.clearTimeout(id);
  }, [phase]);

  useEffect(() => {
    if (phase !== 'working') return;
    setStep(0);
    const id = window.setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 700);
    return () => window.clearInterval(id);
  }, [phase, STEPS.length]);

  useEffect(() => {
    if (phase === 'working') return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === 'Enter') (phase === 'done' ? reloadAdmin : onClose)();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [phase, onClose]);

  if (typeof document === 'undefined') return null;

  return createPortal(
    <div className="bk-switch" role="dialog" aria-modal="true" aria-labelledby="bk-switch-title">
      <div className={`bk-switch__card is-${phase}`}>
        {phase === 'working' ? (
          <>
            <h2 id="bk-switch-title" className="bk-switch__title">
              {copy.working}
            </h2>
            <div className="bk-switch__bar" role="progressbar" aria-label={copy.working} aria-busy="true">
              <span className="bk-switch__fill" />
            </div>
            <p className="bk-switch__step" aria-live="polite">
              {STEPS[step]}
            </p>
          </>
        ) : phase === 'done' ? (
          <>
            <CheckCircle className="bk-switch__icon" size={36} weight="fill" aria-hidden />
            <h2 id="bk-switch-title" className="bk-switch__title">
              {copy.done}
            </h2>
            <div className="bk-switch__bar" aria-hidden>
              <span className="bk-switch__fill is-full" />
            </div>
            <p className="bk-switch__step">{detail}</p>
            <p className="bk-switch__step" aria-live="polite">
              Refreshing the admin…
            </p>
            <div className="bk-switch__actions">
              <a className="button" href={siteHref} target="_blank" rel="noreferrer">
                View site
              </a>
              <button type="button" className="button button-primary" onClick={reloadAdmin} autoFocus>
                Done
              </button>
            </div>
          </>
        ) : (
          <>
            <WarningCircle className="bk-switch__icon is-error" size={36} weight="fill" aria-hidden />
            <h2 id="bk-switch-title" className="bk-switch__title">
              {copy.error}
            </h2>
            <p className="bk-switch__step">
              {detail} {copy.errorNote}
            </p>
            <div className="bk-switch__actions">
              <button type="button" className="button button-primary" onClick={onClose} autoFocus>
                Close
              </button>
            </div>
          </>
        )}
      </div>
    </div>,
    document.body,
  );
}
