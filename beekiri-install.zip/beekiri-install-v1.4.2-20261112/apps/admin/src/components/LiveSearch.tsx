import { useEffect, useRef, useState } from 'react';
import { MagnifyingGlass, X } from '@phosphor-icons/react';
import './live-search.css';

/** How long typing pauses before the list follows the box. */
const DELAY_MS = 250;

/**
 * The admin's list search: the list follows as you type (no Search button), with a clear button
 * and Esc to clear. `value` is the search the list shows (usually `?q=` in the address);
 * `onSearch` gets the trimmed text once typing pauses. The box only takes `value` back when it
 * changed from elsewhere (Back, Clear filters), never while you are still typing.
 */
export function LiveSearch({
  value,
  onSearch,
  placeholder,
  label,
  className,
}: {
  value: string;
  onSearch: (text: string) => void;
  placeholder: string;
  label: string;
  className?: string;
}) {
  const [text, setText] = useState(value);
  const sent = useRef(value);
  const latest = useRef(onSearch);
  latest.current = onSearch;

  useEffect(() => {
    const next = text.trim();
    if (next === sent.current) return;
    const t = window.setTimeout(() => {
      sent.current = next;
      latest.current(next);
    }, DELAY_MS);
    return () => window.clearTimeout(t);
  }, [text]);

  useEffect(() => {
    if (value === sent.current) return;
    sent.current = value;
    setText(value);
  }, [value]);

  return (
    <label className={`bk-live-search${className ? ` ${className}` : ''}`}>
      <span className="screen-reader-text">{label}</span>
      <MagnifyingGlass size={16} aria-hidden />
      <input
        type="search"
        placeholder={placeholder}
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Escape' && text) {
            e.preventDefault();
            setText('');
          }
        }}
      />
      {text ? (
        <button type="button" className="bk-live-search__clear" aria-label="Clear search" onClick={() => setText('')}>
          <X size={14} aria-hidden />
        </button>
      ) : null}
    </label>
  );
}
