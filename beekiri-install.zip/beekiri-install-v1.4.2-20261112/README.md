# Beekiri CMS

**A free, self-hosted CMS for websites, shops, bookings and forms.** Structured content fields, a visual page editor, media, SEO, analytics, a shop, appointment booking and a form builder in one application. It installs with one command and is set up entirely from the browser.

Beekiri is **free to use, forever**, for personal sites, client work and commercial projects, on as many sites as you like. Optional premium themes are sold in the Beekiri theme store.

| | |
|---|---|
| **Current version** | 1.4.2 |
| **Stack** | React · Express · Sequelize · PostgreSQL · Next.js · TypeScript |
| **Releases** | [github.com/996agency/Beekiri/releases](https://github.com/996agency/Beekiri/releases) |
| **License** | [Beekiri License](./LICENSE): free to use, build themes and extensions; no rebranding or clones |

---

## Contents

- [Quick start](#quick-start)
- [Requirements](#requirements)
- [Other ways to install](#other-ways-to-install)
- [First-run setup](#first-run-setup)
- [Features](#features)
- [Multisite](#multisite)
- [Themes and extensions](#themes-and-extensions)
- [What is free, what is paid](#what-is-free-what-is-paid)
- [Configuration](#configuration)
- [Moving a site to a server](#moving-a-site-to-a-server)
- [Updating](#updating)
- [Development](#development)
- [Project structure](#project-structure)
- [Security](#security)
- [License and trademarks](#license-and-trademarks)

---

## Quick start

With [Node.js 20+](https://nodejs.org) installed:

1. Download **beekiri-install.zip** from the [latest release](https://github.com/996agency/Beekiri/releases/latest) (direct link: [beekiri-install.zip](https://github.com/996agency/Beekiri/releases/latest/download/beekiri-install.zip)) and unzip it into a new folder, e.g. `my-site`.
2. In that folder run:

   ```bash
   npm install
   npm start
   ```

3. Open the **setup link** the terminal prints, choose **Set it up for me** (Beekiri installs its own database, so you don't need PostgreSQL) or enter your own database details, and create your site and admin account.

After that, start Beekiri any time with `npm start` in the site folder.

Each release ZIP comes with a 996agency signature (`beekiri-install.zip.sig`); sites check it before installing an update.

### Trying it on a new computer

1. Install [Node.js 20+](https://nodejs.org). PostgreSQL is not needed: Beekiri can install its own.
2. Download and unzip **beekiri-install.zip** as above, then run `npm install` and `npm start` in that folder (on Windows: in PowerShell).
3. Open the **setup link** the terminal prints and choose **Set it up for me**. The first time, Beekiri downloads PostgreSQL for this computer (about 100 MB, a minute or two). Then create your site and admin account.
4. Sign in at `/admin`. The site connects to the Beekiri Hub at [996agency.com](https://996agency.com) on its own; there is nothing to configure.
5. Try **Beekiri**, the built-in assistant: open it from the balance button in the admin bar, add money under **Connector → Balance**, and ask it to build or change something ("add a contact section with a map of central London"). Each change waits for **Keep** or **Undo**, and **Preview** shows it before visitors see it.
6. Premium themes are in **Appearance → Templates**.

---

## Requirements

| Software | Version | Notes |
|----------|---------|-------|
| Node.js | 20 or later | LTS recommended; includes npm and npx |
| PostgreSQL | 14 or later | Optional: the setup wizard can install Beekiri's own. Otherwise local or hosted, one database per site |
| PHP CLI | 8 or later | Optional; for PHP theme layouts and the Shopping storefront |

**Database**

The easiest choice is **Set it up for me** in the setup wizard: Beekiri downloads PostgreSQL 18 into the site folder (`database/`), creates the database with a random password, and `npm start` starts and stops it with the site. It only listens on this computer, and core updates never touch it. Back it up with the rest of the site folder. On a Linux server running as root, PostgreSQL runs as a `postgres` system user, which Beekiri creates.

To use a PostgreSQL server of your own instead:

| | |
|---|---|
| macOS | `brew install postgresql@16 && brew services start postgresql@16`, or [Postgres.app](https://postgresapp.com) |
| Ubuntu / Debian | `sudo apt install postgresql` |
| Windows | [PostgreSQL installer](https://www.postgresql.org/download/windows/) |
| Hosted | Any provider (Neon, Supabase, your hosting company…). Copy its host, port, database, user and password into the setup wizard. |

The setup wizard can create the database for you if the user has permission; otherwise create an empty one first (`createdb my_site`).

---

## Other ways to install

**On a server (VPS).** Download and unzip the release ZIP as in the [Quick start](#quick-start), run `npm install`, then keep it running with a process manager and put it behind your web server (Nginx, Caddy) with HTTPS:

```bash
npm install -g pm2
pm2 start npm --name my-site -- start
pm2 save
```

Set `APP_URL`, `NODE_ENV=production` and `HOST=127.0.0.1` in `apps/api/.env` (see [Configuration](#configuration)). With the web server on the same machine nothing else is needed: Beekiri trusts the `X-Forwarded-For` and `X-Forwarded-Proto` headers only from `127.0.0.1`/`::1`, so visitors' addresses and https come through and nobody can fake them by reaching the Node port directly. In Nginx, pass them on:

```nginx
location / {
    proxy_pass http://127.0.0.1:8080;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

Caddy (`reverse_proxy 127.0.0.1:8080`) sends these by default. Only when the proxy or load balancer runs on another machine, set `TRUST_PROXY` to its address (for example `TRUST_PROXY=10.0.0.5`), and keep the Node port closed to everyone else.

---

## First-run setup

The first start builds the application and opens in setup mode. The setup wizard then:

1. Sets up the database: **Set it up for me** installs Beekiri's own PostgreSQL in the site folder; **Use my own PostgreSQL** asks for the connection details and verifies them.
2. Saves the settings to `apps/api/.env`, generates the encryption secret and restarts Beekiri.
3. Applies the database migrations.
4. Creates the site and the owner account.

For safety, the setup link printed in the terminal contains a one-time key; nobody else who reaches the server can complete the setup.

Once setup is complete, Beekiri is available at:

| | Path |
|---|---|
| Public website | `/` |
| Admin | `/admin` |
| API reference (OpenAPI) | `/api/docs` |

---

## Features

**Content**
- Pages and posts with revisions
- Backend Fields: field groups with repeaters, groups and flexible content
- Media library with automatic Full HD resizing and WebP conversion

**Editing**
- Visual page editor (BeekiriCode) with elements, sections and theme layouts
- Dynamic content: a box repeats its card for live shop products, journal posts or Backend Fields rows, and each element inside connects its text, link or photo to the item (no prices or links typed by hand)
- Layouts generated from Backend Fields, with PHP or React output
- Parent and child themes under `apps/web/themes`
- Beekiri assistant: describe a change in plain words and it builds pages, sections, popups, banners and content types; every change can be previewed, kept or undone. Paste or upload a picture of a design (a screenshot, a mockup, a whole landing page) and it builds the same layout
- Animation built in: GSAP (with ScrollTrigger, SplitText and other plugins) and Three.js ship with Beekiri and load from your own site, only on the pages that use them. See [`docs/themes/ANIMATION.md`](./docs/themes/ANIMATION.md)

**Marketing**
- BeeSEO site audit, keyword research and backlinks
- Analytics, heatmaps and BeeCookies consent, first-party
- Translations with a language switcher

**Administration**
- Customizable overview dashboard
- Users, roles and per-user permissions
- Notifications: a bell in the admin shows new orders, bookings, form entries, changed settings and available updates as they happen, to the people whose role allows it
- Email: each site sends through its own mail server (Settings → Email), with a test button; the password is stored encrypted
- Multisite: several sites on sub-domains under one install and one sign-in
- One-click core updates and site migration (push/pull between local, staging and production)

**Extensions (free, made by Beekiri)**
- **Shopping**: products with variations and stock, cart, coupons, shipping, taxes, Stripe Checkout / bank transfer / cash on delivery, orders, customers and a sales overview. See [`docs/shopping`](./docs/shopping/USER-GUIDE.md).
- **Bee Forms**: drag-and-drop form builder with conditional logic, multi-step forms, file uploads, notification and auto-reply emails with your own logo, colours and a live preview, an entries inbox with visitor source tracking (UTM tags, ad clicks, country), CSV export, and a HubSpot integration. See [`docs/bee-forms`](./docs/bee-forms/USER-GUIDE.md).
- **Bee Bookings**: services, staff and opening hours, a booking widget for any page (`[bee_booking]`), a calendar and appointment list, and confirmation, reminder and cancellation emails with a link for the customer to manage their booking.

---

## Multisite

Run several websites from one install, each on its own sub-domain (`shop.example.com`) or domain. The owner adds sites in **Settings → Sites**, chooses who can use which site (and their role there) in **Users → User Permissions**, and everyone switches sites from **My sites** in the admin bar without signing in again. Layouts can be shared with every site and customised per site. Locally, `http://shop.localhost:8788` works out of the box; on a server you add one wildcard DNS record. See [`docs/multisite`](./docs/multisite/GUIDE.md).

---

## Themes and extensions

Your work lives **outside the core**, so core updates never overwrite it:

| | Where | Notes |
|---|---|---|
| Themes | `apps/web/themes/<your-theme>/` | Start from **Beekiri Child**, or copy the default **Beekiri** theme. A theme has a `theme.json`, a header, a footer and layouts. |
| Layouts | `apps/web/themes/<theme>/layouts/<name>/` | Created automatically from **Backend Fields** (PHP or React), then yours to edit. Remove the `@beekiri-managed` line to stop regeneration. |
| Extensions | Built in today | Beekiri's own extensions (Shopping, Bee Forms, Bee Bookings) ship with the core. A public extension API so developers can publish their own is planned. |

You may build themes and extensions for yourself or for clients, and **share or sell them** under your own terms, as long as they don't include the Beekiri core. See the [LICENSE](./LICENSE).

---

## What is free, what is paid

| | |
|---|---|
| **Beekiri CMS** | Free. Every feature, every extension made by Beekiri, unlimited sites. |
| **Default themes** | Free. Use them as they are or as the starting point for your own. |
| **Premium themes** | Paid, in **Appearance → Theme store**. A theme licence covers one local, one staging and one production site with the same owner email. |
| **Beekiri assistant** | Optional, prepaid. Add $20, $50, $100 or your own amount under **Connector → Balance**; each message takes only what it costs. Thanks and small talk are free. |

---

## Configuration

All settings live in `apps/api/.env`. The setup wizard creates this file; edit it only to configure a server by hand. Every available setting is documented in [`apps/api/.env.example`](./apps/api/.env.example).

A typical production configuration:

```env
NODE_ENV=production
PORT=8080
APP_URL=https://www.example.com

DB_HOST=db.example.com
DB_NAME=beekiri
DB_USER=beekiri
DB_PASSWORD=change-me
DB_SSL=verify-full

CACHE_FLUSH_SECRET=<output of: openssl rand -hex 32>
# Only reachable through the web server on this machine (see "On a server" above).
HOST=127.0.0.1

SMTP_HOST=smtp.example.com
SMTP_FROM=noreply@example.com
```

Behaviour to be aware of:

- **Setup mode:** without database settings, Beekiri serves only the setup wizard.
- **Validation:** an invalid value stops Beekiri at start, and every problem is listed at once.
- **Production warnings:** risky but working settings, such as a remote database without SSL, are logged on start.
- **Email:** each site sets its own mail server under **Settings → Email** (the password is stored encrypted). `SMTP_HOST` in `.env` is the default for sites that have none; with neither, emails such as password resets are written to the log instead of being sent.
- **Older installs:** settings in a repository-root `.env`, including `DATABASE_URL`, are still read.

---

## Moving a site to a server

**Settings → Migration → Deploy package** makes one zip of the whole site: Beekiri as installed (already built), the database, every theme and all media.

1. Click **Prepare deploy package** and download the zip.
2. Upload it to the server and unzip it. The server needs Node.js 20 or later and must be able to keep a Node.js program running (a VPS, or hosting with Node.js apps); PHP-only web hosting cannot run Beekiri.
3. Run `npm install`, then `npm start`. Hosts that ask for an entry file instead of a command use `server.js`; the port comes from the host's `PORT` setting.
4. Open the setup link, choose the database (**Set it up for me**, or your host's PostgreSQL details) and create an account.
5. Sign in and click **Restore this site** in Settings → Migration, then sign in again with your account from the old site.

Addresses inside the content are changed to the new address. Payment keys and e-mail passwords are never in the package: enter them again on the new server. Store themes are checked against their licence (one local, one staging and one production site). `START_HERE.txt` inside the zip repeats these steps.

To move changes between two running sites (local → staging → production), use **Push** and **Pull** on the same tab.

## Updating

Sites update themselves from the admin:

1. Go to **Settings → Beekiri Core** and click **Check for updates**.
2. If a new version is available, click **Update**.

The updater downloads the release, backs up the current core files to `backups/`, installs the new version, applies database migrations and restarts Beekiri. Content, media, layouts generated by the site, and `apps/api/.env` are never overwritten.

**If `npm start` stops with `tsup: not found` (or `tsx: not found`)** after an update made before 1.3.4: that update left out Beekiri's build tools. Run this once in the site folder, then start as usual:

```bash
npm install --include=dev
npm start
```

From 1.3.4 on, updates keep the build tools, and `npm start` puts them back by itself if they are ever missing.

### Publishing a release (996agency)

1. Raise the version in `package.json`, `beekiri.manifest.json` and `apps/api/beekiri.manifest.json`; they must match.
2. Run:

   ```bash
   npm run publish:release
   ```

This builds and signs the install package and publishes it as a release of this repository, with `beekiri-install.zip`, its `.sig` and `latest.json` attached; existing sites detect it on their next update check. Publishing requires the [GitHub CLI](https://cli.github.com/), signed in with write access to the release repository.

The release scripts (`scripts/pack-release.sh` and `scripts/publish-release.sh`) are kept on 996agency machines only. They are excluded from Git and from the install package.

---

## Development

```bash
npm run dev                          # Run Beekiri with live reload
npm run build                        # Build the admin, website and API
npm start                            # Run the production build (builds anything missing first)
npm test                             # API tests (TEST_DB_NAME=<throwaway db> for the integration suites)
npm run typecheck                    # Type-check every workspace
npm run db:migrate                   # Apply pending migrations
npm run db:migrate:status            # Show applied and pending migrations
npm run db:migrate:create -- <name>  # Create a new migration
```

---

## Project structure

```
apps/
  admin/     Admin interface (Vite + React), served at /admin
  api/       Express server: routes, controllers, services, zod validators,
             Sequelize models and migrations; hosts the admin and the website
  web/       Public website (Next.js), themes and shared editor modules
docs/        Extension documentation (shopping, bee-forms: user + developer guides)
scripts/     Core updater, run by Settings → Beekiri Core → Update
```

---

## Security

- Passwords are hashed with **Argon2id**; new passwords must not be weak (install, reset and user edit all apply the same rule).
- Sessions are stored server-side in **HttpOnly** cookies, marked Secure (with the `__Host-` prefix) on `https://` sites. Changing a password closes every session of that account.
- State-changing requests are protected against **CSRF** (allow-listed Origin plus a per-session token).
- Login is throttled per address and per account; password-reset links are single-use, expire after one hour, and are always built from `APP_URL` (never from the request's Host header), so set `APP_URL` on every production site.
- Changing your own email or password requires your current password. Only administrators can create, edit or delete administrator accounts; only the Owner can edit the Owner account; nobody can change their own role.
- Authors and contributors can only open and change their own items, cannot change items that are already published, and have scripts and event handlers stripped from the HTML they save. The `unfiltered_html` capability (administrators by default) stores HTML as written. Note that the admin and the public site share one origin, so anyone allowed to put scripts on the site can act as any administrator who visits it.
- Settings tabs delegated to a user only unlock that tab's fields; the site-code slots (head/body/footer HTML) need `unfiltered_html` as well as full settings access.
- **Owner-only tools:** Settings → Migration (a database copy holds every account) and Settings → Email (password-reset links travel through the mail server). With more than one site, theme uploads and removals, store-theme installs and core updates are the owner's too.
- Nobody hands out more than they have: only the owner can give a role beyond their own rights, and changing the password, email or username of (or deleting) someone who can do more than you is refused.
- Content from people without `unfiltered_html` cannot carry `data-*` attributes, script addresses or event handlers, and forms only redirect to web addresses. Links to other sites are never loaded in place by the site's page navigation.
- **No AI keys on a site.** The Beekiri assistant runs only through 996Agency: the site signs in with its Hub install token, which is stored encrypted, is never sent to a browser and is left out of every database export and backup. The Hub address comes only from the server's environment (`BEEKIRI_HUB_URL`), never from the admin or the database. 996Agency's Anthropic key never leaves 996Agency, and each site can only spend its own prepaid balance.
- Form emails to an address a visitor typed are capped (three per address a day, 100 per site an hour), so a form cannot be used to mail strangers. Coupon codes can't be guessed: wrong codes all get one answer and are limited per visitor.
- Rate limits count each visitor (an IPv6 visitor's /64 network as one), also when pages are rendered on the server, so one visitor cannot slow the site down for everyone.
- Rich text printed by theme templates (`bee_esc_html()` / `wp_kses_post()`) goes through a DOM-based allow-list, and `esc_url()` refuses script URLs, including obfuscated ones. Field values saved by users without `unfiltered_html` are cleaned on save as well, and the editor sanitizes layout previews before showing them.
- The admin page carries a strict **Content-Security-Policy**: scripts load only from the site itself. Website pages get a baseline policy (no plugins, no `<base>` hijacking, no framing by other sites); scripts stay open there because owners add analytics and widgets through Settings.
- **First-time setup needs a one-time setup key.** Beekiri prints a link containing it in the terminal and saves it in `apps/api/.setup-token`; it stops working once the site is created. Nobody who merely reaches the server can claim it.
- A custom admin address stays private: it is not returned by any public endpoint or listed in `robots.txt`. The API reference at `/api/docs` is only available to signed-in administrators.
- Security headers via **Helmet**, and **rate limiting** on the API, including the public layout render endpoints.
- `apps/api/.env` is written with owner-only file permissions. Never commit it or share production secrets.

To report a vulnerability, contact 996agency directly rather than opening a public issue.

---

## License and trademarks

Beekiri is **free to use** under the [Beekiri License](./LICENSE):

- ✅ Use it on any number of sites, for yourself or for clients, including commercial work.
- ✅ Create and change themes, and create extensions. Share or sell them under your own terms.
- ✅ Hosting providers may offer unmodified Beekiri to their customers.
- ❌ No rebranding: the Beekiri name, logo and notices in the admin, sign-in, setup and update screens stay.
- ❌ No clones: don't publish or sell Beekiri, or a changed version of it, as your own product.

Your public websites never need to show Beekiri branding. The name and logo are covered by the [trademark policy](./TRADEMARKS.md): *"built with Beekiri"* and *"… for Beekiri"* are welcome.

© 2026 996agency.
