// Entry file for hosts that ask for one instead of a start command (Node.js app managers in
// hosting panels such as Hostinger, cPanel or Plesk). It does what `npm start` does.
import('./apps/api/scripts/start.mjs');
