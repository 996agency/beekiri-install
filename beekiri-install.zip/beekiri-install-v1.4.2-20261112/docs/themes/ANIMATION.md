# Animation in layouts: GSAP and Three.js

Beekiri ships GSAP (with its plugins) and Three.js. A layout's `script.js` asks for them with `Beekiri.use()`. They load from the site's own server, only on pages whose script asks, and each file loads once per visit. Nothing comes from a CDN, and pages that don't animate download nothing.

## Asking for a library

```js
Beekiri.use('gsap', 'ScrollTrigger').then(function (lib) {
  lib.gsap.from('.bk-item', { y: 40, autoAlpha: 0 });
});

Beekiri.use('three').then(function (lib) {
  var THREE = lib.THREE;
});
```

| Name | What you get |
| --- | --- |
| `gsap` | GSAP core, as `lib.gsap` |
| `ScrollTrigger`, `ScrollSmoother`, `ScrollToPlugin`, `SplitText`, `Flip`, `Observer`, `Draggable`, `InertiaPlugin`, `MotionPathPlugin`, `DrawSVGPlugin`, `MorphSVGPlugin`, `TextPlugin`, `ScrambleTextPlugin`, `CustomEase` | The GSAP plugin under the same name, already registered |
| `three` | The Three.js core module, as `lib.THREE` (no addons such as OrbitControls or GLTFLoader) |

`Beekiri.libs` holds the versions that ship with this Beekiri.

## A script that animates on scroll

```js
(function () {
  function init() {
    document.querySelectorAll('[data-layout="my-layout"]:not([data-bk-ready])').forEach(function (root) {
      root.setAttribute('data-bk-ready', '');
      if (!window.Beekiri || !Beekiri.use) return;
      Beekiri.use('gsap', 'ScrollTrigger').then(function (lib) {
        var mm = lib.gsap.matchMedia(root);
        mm.add('(prefers-reduced-motion: no-preference)', function () {
          lib.gsap.from(root.querySelectorAll('.bk-item'), {
            y: 40,
            autoAlpha: 0,
            duration: 0.8,
            stagger: 0.08,
            ease: 'power3.out',
            scrollTrigger: { trigger: root, start: 'top 80%' },
          });
        });
        window.addEventListener('bk:navigate', function gone() {
          if (root.isConnected) return;
          mm.revert();
          window.removeEventListener('bk:navigate', gone);
        });
      });
    });
  }
  init();
  window.addEventListener('bk:navigate', init);
})();
```

## Rules that keep pages fast and editable

- **Visible without the script.** Don't hide content in `styles.scss` and reveal it from the script. Set start states with `gsap.from()`, `gsap.fromTo()` or `gsap.set()`. The page editor shows sections still: there `Beekiri.use()` never answers, so nothing being edited moves or hides. Preview and the live site play the motion.
- **The first screen uses CSS.** A hero's entrance is CSS `@keyframes`. A script starts late and would make the content flash.
- **Reduced motion.** Wrap motion in `gsap.matchMedia()` as above. A Three.js scene draws one still frame.
- **No CSS transition on what GSAP moves.** An element with `transition: transform` (a hover lift) fights GSAP and stops in the wrong place. Animate a wrapper, or put the hover on an inner element.
- **Clean up.** Pages change without a reload. On `bk:navigate`, when your section is gone (`!root.isConnected`), revert the animation, cancel `requestAnimationFrame` loops, disconnect observers and dispose Three.js renderers, geometries, materials and textures.
- **Three.js.** Put the `<canvas>` in a box sized by CSS (`aspect-ratio` or a height) with a photo or CSS background behind it as the fallback. Ask for `three` when the box nears the viewport, cap the pixel ratio at 2, and stop the loop while the box is off screen or the tab is hidden.

## Updating the libraries

The files live in `apps/api/vendor/libs`. To move to newer versions:

```
node apps/api/scripts/vendor-libs.mjs <gsap version> <three version>
```

GSAP is used under its [standard license](https://gsap.com/standard-license), which allows commercial sites at no charge. It does not allow building a visual, no-code animation builder on top of GSAP without Webflow's consent. Three.js is MIT licensed.
