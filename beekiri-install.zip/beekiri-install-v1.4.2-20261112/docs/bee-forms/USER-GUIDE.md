# Bee Forms — user guide

Bee Forms is a Beekiri extension for building forms (contact, quote, booking, job application…), showing them on any page, and collecting what visitors send.

## Install

1. Go to **Extensions → Add New** and install **Bee Forms**. A **Forms** menu appears.
2. That's it. There are no keys or external services to set up.

Deactivating hides the Forms menu and stops forms from showing on the website; nothing is deleted. Uninstalling asks whether to delete the forms, entries and uploaded files.

## Build a form

**Forms → Add New** creates a ready-made contact form (name, email, message). Change anything you like:

- **Add a field**: click a type in the left panel (it goes after the selected field) or drag it into place.
- **Reorder**: drag a field by its card.
- **Field settings** (right panel): label, placeholder, help text, required, width (full, half, third), default value, options for dropdown/choice/checkbox fields, allowed file types, and the **field key** used in merge tags.
- **Conditional logic**: show or hide a field depending on another field's answer. Hidden fields are never required and never stored.
- **Page break** splits the form into steps with Next/Back buttons. Choose a progress bar, numbered steps or none under **Settings → Steps**.
- The **Active** switch at the top takes the form off the website without deleting it.

Field types: Text, Email, Phone, Website, Message, Number, Date, Dropdown, Choice, Checkboxes, Consent, File upload, Hidden, Section, Page break.

### Settings tab

- **Submit button** text.
- **After sending**: show a thank-you message (merge tags work: `Thanks {field:name}!`) or redirect to a page.
- **Steps**: progress style and button labels.
- **Keep entries in the admin**: turn off for email-only forms.
- **Minimum fill time**: submissions faster than this are treated as bots.

### Notifications tab

- **Notification email**: who gets each entry. Use several addresses separated by commas; `{admin_email}` is the site owner and `{field:email}` is the visitor's address. **Reply to** makes "Reply" in your mail app go to the visitor.
- **Auto-reply**: a confirmation to the visitor, sent to their email field.
- **Merge tags**: `{field:key}` for any answer, `{all_fields}` for every answer, plus `{form_title}`, `{site_title}`, `{entry_id}`, `{date}`, `{page_url}`, `{admin_email}`.
- **Message formatting**: the buttons above each message add bold (`**text**`), a link (`[text](https://…)`), a heading (a line starting with `## `) and a dividing line (`---`). **Insert an answer** drops in a merge tag. Only your own text is formatted; a visitor's answer always arrives as plain text.
- **Email design**: one look for both emails. Choose a **logo** from the media library (without one the site title is shown), its width and position, an **accent colour** (the bar across the top, and links), the **background** around the white card, and a **footer** line (leave it empty for none). The logo travels inside the email as a PNG, so it shows in every mail app.
- **Preview**: the panel on the right shows the email as it will arrive, with sample answers, for desktop and phone. It follows the email you are editing and updates as you type, before you save. **Send me a test** mails it to your own address (needs a mail server, see Troubleshooting).

Emails go out through the site's SMTP settings (`SMTP_*` in `.env`). Without SMTP they are written to the server log.

## Put a form on a page

**In the page editor**: open **Add → Form**, drop it where you want it, then pick the form under **Props → Content**. The canvas shows a read-only preview; the live form appears on the website.

**In a theme layout** (for themes built with Backend Fields): add a **Form (Bee Forms)** field to the field group. In the page editor the layout then has a dropdown to choose the form. The generated PHP prints it with `bee_form($field)`; React layouts get `{ ID, title, html }`.

```php
<?php $contact_form = get_bee_field('contact_form'); ?>
<?php if ($contact_form) : ?>
  <div class="bk-contact-form"><?php echo bee_form($contact_form); ?></div>
<?php endif; ?>
```

Forms use the site's text colour, border and radius variables, so they match the theme. Style them further under `.bk-form` in your theme CSS.

## Entries

**Forms → Entries** lists everything sent, newest first, with unread counts. Click an entry to read it, download attachments, mark it unread, or move it to spam or trash. Pick a form in the filter to **Export CSV**. Deleting an entry also deletes its uploaded files.

Click an entry to open it full page. Besides the answers it shows:

- **Source of this visit**: the channel and source (e.g. *Paid social · LinkedIn Ads*, *Paid search · Google Ads*, *Organic search · Google*, *Email · Newsletter*, *Direct*), campaign, medium, keyword, ad content, which ad click ID was on the link (gclid, li_fat_id, msclkid, fbclid…), the landing page and the site they came from. It is kept for the whole visit, so a visitor who clicks an ad, reads three pages and then fills in the contact form still shows the ad.
- **First visit**: how they found the site the very first time, when it was different. Only recorded for visitors who accepted analytics or marketing cookies.
- **Visitor**: country, device, browser and OS, language, time zone, screen.
- **Submission**: page it was sent from, pages viewed, time on site, time to fill in.

The Entries list has **Source** and **Country** columns and a **Where entries come from** panel; click a channel or source there to filter. The CSV export includes all source columns. Tag your ad and email links with UTM parameters (`utm_source`, `utm_medium`, `utm_campaign`) for the most precise source names; Google, Microsoft, LinkedIn, TikTok, X, Pinterest and Snapchat ads are recognised from their click IDs even without tags. Country comes from your CDN (e.g. Cloudflare) when there is one, otherwise from the visitor's time zone and language. Entries sent before this was added show *Not recorded*.

Uploaded files are stored privately and can only be downloaded by signed-in admins with the Entries permission.

## Integrations (HubSpot)

**Forms → Integrations** connects a CRM. HubSpot is available now; Brevo, Mailchimp and Salesforce are coming.

1. In HubSpot, open **Settings → Integrations → Private Apps → Create a private app** (newer accounts: **Development → Legacy apps → Create → Private**). Works on every plan, including free.
2. Name it *Beekiri* and add the scopes `crm.objects.contacts.read`, `crm.objects.contacts.write` and `crm.schemas.contacts.read`.
3. Create the app, copy the access token (`pat-…`) and paste it into Beekiri. It is checked with HubSpot first and stored encrypted.

Then open a form → **Integrations**, switch HubSpot on and check the mapping. Beekiri suggests one (email, first/last name, phone, company, website, message, lifecycle stage = Lead). Each HubSpot contact property can take a form field, part of a name ("first word" / "the rest"), where the visitor came from (channel, source, campaign, landing page…) or a fixed value. Options: only send when a consent box is ticked, and add the whole entry as a note on the contact.

How it behaves:
- The entry is saved first; HubSpot runs after. A HubSpot problem never stops the form.
- Contacts are matched by email: an existing contact is updated, never duplicated.
- Values HubSpot can't accept (an option that doesn't exist, text in a number property) are left out and listed on the entry; the rest of the contact is still saved.
- If HubSpot is down or busy, Beekiri retries automatically (after 1 min, 5 min, 30 min, 2 h and 6 h), also after a restart.
- Each entry page shows the HubSpot status, a link to the contact, warnings, and **Retry now** / **Send again**. After fixing a token, **Retry failed entries** on the Integrations page re-sends everything that failed in the last 30 days.

## Permissions

- **Forms** (`manage_forms`): build and edit forms.
- **Entries** (`view_form_entries`): read, export and delete entries.

Administrators and Editors have both by default; change them under **Users → User Permissions**.

## Spam

Every form has a honeypot field, a timing check (the token issued when the form loads must be at least a few seconds old) and per-IP rate limits. Bots get a normal "thanks" reply so they learn nothing; nothing is stored or emailed. Files that could run as code (HTML, SVG, scripts, executables) are always refused.

## Troubleshooting

- **The form doesn't show on the site**: check the form is **Active**, the extension is active, and the page was saved after adding the element.
- **No emails**: add your mail server under **Settings → Email** (each site has its own), or set `SMTP_HOST`/`SMTP_FROM` in `.env` as the server-wide default; with neither, the email is only logged. The notification must be enabled and have a valid address after merge tags are replaced.
- **"This form took too long to send"**: the page was open for more than a day. Reloading fixes it.
