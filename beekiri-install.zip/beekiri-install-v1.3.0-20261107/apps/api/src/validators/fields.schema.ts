import { z } from 'zod';
import { opt } from './common';

const GROUP_KEY = z
  .string()
  .max(60)
  .regex(/^[a-z][a-z0-9_]*$/, 'Group key must start with a letter and use only a-z, 0-9, _');

const location = z
  .array(z.string().regex(/^[a-z][a-z0-9_-]*$/, 'each value in location has an invalid format'))
  .max(50)
  .refine((v) => new Set(v).size === v.length, "All location's elements must be unique");

/** Field definitions; deep-validated by parseFields() (recursive sub fields / layouts). */
const fields = z.array(z.record(z.unknown())).max(500);

export const createFieldGroupSchema = z
  .object({
    title: z.string().min(1).max(120),
    key: opt(GROUP_KEY),
    description: opt(z.string().max(500)),
    active: opt(z.boolean()),
    location: opt(location),
    fields: opt(fields),
  })
  .strict();

export const updateFieldGroupSchema = z
  .object({
    title: opt(z.string().min(1).max(120)),
    key: opt(GROUP_KEY),
    description: opt(z.string().max(500)),
    active: opt(z.boolean()),
    location: opt(location),
    fields: opt(fields),
  })
  .strict();

const csv = z.string().max(4000).optional();

export const lookupPostsQuery = z.object({ types: csv, q: csv, ids: csv }).passthrough();
export const lookupUsersQuery = z.object({ q: csv, ids: csv, roles: csv }).passthrough();

export const syncFieldGroupsSchema = z
  .object({
    keys: opt(z.array(GROUP_KEY).max(100)),
  })
  .strict();

export type CreateFieldGroupInput = z.infer<typeof createFieldGroupSchema>;
export type UpdateFieldGroupInput = z.infer<typeof updateFieldGroupSchema>;
export type SyncFieldGroupsInput = z.infer<typeof syncFieldGroupsSchema>;

/** Multisite: share a layout with every site of the network (owner). */
export const setGlobalFieldGroupSchema = z.object({ global: z.boolean() }).strict();
