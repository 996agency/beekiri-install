import { isAbsolute, resolve } from 'path';
import { z } from 'zod';
import { isLoopbackHost } from '../utils/loopback';
import { REPO_ROOT } from './paths';

/**
 * Pure configuration parsing: environment variables in, typed config (or the list of
 * problems) out. No file loading, logging or exiting here, so it is unit-testable.
 *
 * No machine addresses or ports live in code: they come from apps/api/.env, which the
 * browser setup wizard writes. With no database configured yet the server starts in
 * setup mode and serves only the wizard. Protocol-standard ports (PostgreSQL, SMTP) are
 * left to the drivers' own defaults.
 */

const PLACEHOLDER_SECRET = /change-me|changeme|dev-insecure|secret-at-least/i;
const PG_IDENTIFIER = /^[A-Za-z_][A-Za-z0-9_]{0,62}$/;

function isHttpUrl(value: string): boolean {
  try {
    return ['http:', 'https:'].includes(new URL(value).protocol);
  } catch {
    return false;
  }
}

const flag = z
  .enum(['true', 'false', '1', '0', 'yes', 'no'])
  .transform((v) => ['true', '1', 'yes'].includes(v));
const int = (fallback: number, min = 0) => z.coerce.number().int().min(min).default(fallback);
const port = z.coerce.number().int().min(1).max(65_535);
const httpUrl = z.string().refine(isHttpUrl, 'must be a full http:// or https:// address');
const list = (value: string | undefined) =>
  (value ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

const schema = z.object({
  // Server
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  /** Interface to bind; unset = every interface. */
  HOST: z.string().optional(),
  /** Required to serve HTTP (the migration CLI and tests do not need it). */
  PORT: port.optional(),
  LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error']).default('info'),
  /** Unset = trust X-Forwarded-* from this machine only ('loopback'); see trustProxy(). */
  TRUST_PROXY: z.string().optional(),
  JSON_BODY_LIMIT: z.string().default('2mb'),

  // Site addresses (required in production)
  /** The site's public address (saved by the setup wizard); unset = the request's address. */
  APP_URL: httpUrl.optional(),
  /** Extra browser origins allowed to call the API (the site's own origin always is). */
  CORS_ORIGINS: z
    .string()
    .superRefine((value, ctx) => {
      for (const origin of list(value)) {
        if (!isHttpUrl(origin))
          ctx.addIssue({ code: 'custom', message: `"${origin}" is not a full http(s) address` });
      }
    })
    .optional(),

  // Database
  DB_HOST: z.string().optional(),
  DB_PORT: port.optional(),
  DB_NAME: z.string().optional(),
  DB_USER: z.string().default(''),
  DB_PASSWORD: z.string().default(''),
  DB_SCHEMA: z
    .string()
    .regex(PG_IDENTIFIER, 'must be a plain PostgreSQL identifier')
    .default('public'),
  DB_SSL: z.enum(['disable', 'require', 'verify-full']).optional(),
  DB_SSL_CA: z.string().optional(),
  DB_POOL_MAX: int(10, 1),
  DB_LOG: flag.default('false'),
  /** Legacy single-URL setting, read only when DB_NAME is not set. */
  DATABASE_URL: z
    .string()
    .regex(/^postgres(ql)?:\/\//, 'must start with postgresql://')
    .optional(),

  // Mail (no SMTP_HOST: messages are written to the API log)
  SMTP_HOST: z.string().optional(),
  SMTP_PORT: port.optional(),
  SMTP_USER: z.string().optional(),
  SMTP_PASS: z.string().optional(),
  SMTP_FROM: z.string().optional(),

  // Media
  MEDIA_LOCAL_PATH: z.string().default('./apps/admin/uploads'),

  // Beekiri Core updates & cache
  BEEKIRI_CORE_VERSION: z.string().optional(),
  BEEKIRI_RELEASE_REPO: z.string().default('996agency/beekiri-install'),
  BEEKIRI_GITHUB_TOKEN: z.string().optional(),
  GITHUB_TOKEN: z.string().optional(),
  /** Shared with the public site's /api/cache/flush route (same value in both apps). */
  CACHE_FLUSH_SECRET: z
    .string()
    .min(32, 'must be at least 32 characters (openssl rand -hex 32)')
    .optional(),
  /** Legacy name for CACHE_FLUSH_SECRET on older sites. */
  SESSION_SECRET: z.string().optional(),

  // Lighthouse
  LIGHTHOUSE_URL: httpUrl.optional(),
});

type RawEnv = z.infer<typeof schema>;

/**
 * Rules that span several variables. They read the raw strings, so they are reported
 * together with any invalid field instead of only after every field is valid.
 */
function crossFieldProblems(env: Record<string, string>): string[] {
  const problems: string[] = [];

  // No DB_NAME and no DATABASE_URL is valid: the server starts in setup mode.
  if (!env.DB_NAME && env.DATABASE_URL) {
    try {
      const u = new URL(env.DATABASE_URL);
      if (!u.pathname.replace(/^\//, ''))
        problems.push('DATABASE_URL: must include a database name');
      if (!PG_IDENTIFIER.test(u.searchParams.get('schema') || 'public')) {
        problems.push('DATABASE_URL: ?schema= must be a plain PostgreSQL identifier');
      }
    } catch {
      // The field rule already reports a malformed DATABASE_URL.
    }
  }

  if (env.SMTP_HOST && !env.SMTP_FROM) {
    problems.push('SMTP_FROM: required when SMTP_HOST is set (e.g. noreply@example.com)');
  }
  if (env.NODE_ENV === 'production') {
    const flushSecret = env.CACHE_FLUSH_SECRET ?? env.SESSION_SECRET;
    if (flushSecret && PLACEHOLDER_SECRET.test(flushSecret)) {
      problems.push(
        'CACHE_FLUSH_SECRET: still has the example value; generate one with: openssl rand -hex 32',
      );
    }
  }

  return problems;
}

export type DbSslMode = 'disable' | 'require' | 'verify-full';

export type DatabaseSettings = {
  /** Unset = the driver default (the local server). */
  host?: string;
  port?: number;
  name: string;
  user: string;
  password: string;
  schema: string;
  ssl: DbSslMode;
  sslCa?: string;
  poolMax: number;
  logging: boolean;
};

function sslModeFromUrl(value: string | null): DbSslMode | undefined {
  switch ((value ?? '').toLowerCase()) {
    case 'verify-full':
    case 'verify-ca':
      return 'verify-full';
    case 'require':
    case 'prefer':
      return 'require';
    case 'disable':
      return 'disable';
    default:
      return undefined;
  }
}

function databaseSettings(v: RawEnv): DatabaseSettings {
  const shared = { sslCa: v.DB_SSL_CA, poolMax: v.DB_POOL_MAX, logging: v.DB_LOG };
  if (v.DB_NAME || !v.DATABASE_URL) {
    return {
      ...shared,
      host: v.DB_HOST,
      port: v.DB_PORT,
      name: v.DB_NAME ?? '',
      user: v.DB_USER,
      password: v.DB_PASSWORD,
      schema: v.DB_SCHEMA,
      ssl: v.DB_SSL ?? 'disable',
    };
  }

  // Legacy DATABASE_URL, including Prisma's ?schema= and libpq's ?sslmode= parameters.
  const u = new URL(v.DATABASE_URL);
  return {
    ...shared,
    host: u.hostname || undefined,
    port: u.port ? Number(u.port) : undefined,
    name: decodeURIComponent(u.pathname.replace(/^\//, '')),
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    schema: u.searchParams.get('schema') || v.DB_SCHEMA,
    ssl: v.DB_SSL ?? sslModeFromUrl(u.searchParams.get('sslmode')) ?? 'disable',
  };
}

const trimSlash = (value: string) => value.replace(/\/+$/, '');
const optionalUrl = (value: string | undefined) => (value ? trimSlash(value) : undefined);

function origins(urls: (string | undefined)[]): string[] {
  return [
    ...new Set(urls.filter((url): url is string => Boolean(url)).map((url) => new URL(url).origin)),
  ];
}

/**
 * Express `trust proxy`. Unset: 'loopback', so a web server on the same machine (nginx,
 * Caddy) passes on the visitor's address and https, while a client reaching the Node port
 * directly cannot fake X-Forwarded-* headers. A proxy on another machine needs its
 * address(es) or a hop count here.
 */
function trustProxy(value: string | undefined): boolean | number | string {
  const v = (value ?? '').trim();
  if (!v) return 'loopback';
  if (v === 'false' || v === '0') return false;
  if (v === 'true') return true;
  if (/^\d+$/.test(v)) return Number(v);
  return v;
}

function buildConfig(raw: RawEnv) {
  const isProduction = raw.NODE_ENV === 'production';
  const app = optionalUrl(raw.APP_URL);

  return Object.freeze({
    nodeEnv: raw.NODE_ENV,
    isProduction,
    isTest: raw.NODE_ENV === 'test',
    logLevel: raw.LOG_LEVEL,

    server: {
      host: raw.HOST,
      port: raw.PORT,
      trustProxy: trustProxy(raw.TRUST_PROXY),
      jsonBodyLimit: raw.JSON_BODY_LIMIT,
    },

    urls: {
      /** The site's public address (website, /admin and /api share it). */
      app,
    },

    /** Other browser origins allowed to call the API with cookies (same-origin always works). */
    corsOrigins: origins([app, ...list(raw.CORS_ORIGINS)]),
    /** Outside production, any origin on this machine (any port) may call the API too. */
    allowLoopbackOrigins: !isProduction,

    db: databaseSettings(raw),
    /** False until the setup wizard has saved the database settings. */
    databaseConfigured: Boolean(raw.DB_NAME || raw.DATABASE_URL),

    auth: {
      /** Session cookie is Secure whenever the site is served over https. */
      cookieSecure: app?.startsWith('https://') ?? false,
    },

    mail: {
      host: raw.SMTP_HOST,
      port: raw.SMTP_PORT,
      user: raw.SMTP_USER,
      pass: raw.SMTP_PASS,
      from: raw.SMTP_FROM,
    },

    media: {
      /** Absolute directory for uploaded files (relative values resolve from the repo root). */
      root: isAbsolute(raw.MEDIA_LOCAL_PATH)
        ? raw.MEDIA_LOCAL_PATH
        : resolve(REPO_ROOT, raw.MEDIA_LOCAL_PATH),
    },

    core: {
      /** Only used when beekiri.manifest.json cannot be read. */
      fallbackVersion: raw.BEEKIRI_CORE_VERSION ?? '0.0.0',
      releaseRepo: raw.BEEKIRI_RELEASE_REPO,
      githubToken: raw.BEEKIRI_GITHUB_TOKEN ?? raw.GITHUB_TOKEN,
      /** Shared with the website's /web-api/cache/flush route; unset = no revalidation. */
      cacheFlushSecret: raw.CACHE_FLUSH_SECRET ?? raw.SESSION_SECRET,
    },

    lighthouse: {
      /** Audit this address instead of the site itself. */
      url: optionalUrl(raw.LIGHTHOUSE_URL),
    },
  });
}

export type AppConfig = ReturnType<typeof buildConfig>;

/** Settings that work but are risky on a live site; logged once at startup. */
function productionWarnings(config: AppConfig): string[] {
  if (!config.isProduction) return [];
  const warnings: string[] = [];
  const app = config.urls.app;
  if (!app) {
    warnings.push('APP_URL is not set: links in emails and the sitemap use the request address.');
  } else if (app.startsWith('http://') && !isLoopbackHost(new URL(app).hostname)) {
    warnings.push('APP_URL uses http://. Serve the site over https://.');
  }
  if (config.db.host && !isLoopbackHost(config.db.host) && config.db.ssl === 'disable') {
    warnings.push(
      `Database host ${config.db.host} is remote but DB_SSL=disable. Set DB_SSL=verify-full (or require).`,
    );
  }
  if (!config.mail.host) {
    warnings.push('SMTP_HOST is not set: password reset emails are only written to the API log.');
  }
  if (!config.core.cacheFlushSecret) {
    warnings.push('CACHE_FLUSH_SECRET is not set: "Flush cache" cannot refresh the public site.');
  }
  return warnings;
}

export type ConfigResult =
  { ok: true; config: AppConfig; warnings: string[] } | { ok: false; problems: string[] };

export function parseConfig(env: Record<string, string | undefined>): ConfigResult {
  // An empty `KEY=` line means "not set", so defaults apply.
  const present = Object.fromEntries(
    Object.entries(env).filter(
      (entry): entry is [string, string] => entry[1] !== undefined && entry[1].trim() !== '',
    ),
  );
  const parsed = schema.safeParse(present);
  const problems = [
    ...(parsed.success
      ? []
      : parsed.error.issues.map((i) => `${i.path.join('.') || 'env'}: ${i.message}`)),
    ...crossFieldProblems(present),
  ];
  if (!parsed.success || problems.length) return { ok: false, problems };

  const config = buildConfig(parsed.data);
  return { ok: true, config, warnings: productionWarnings(config) };
}
