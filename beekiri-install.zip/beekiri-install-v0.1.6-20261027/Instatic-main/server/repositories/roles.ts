import { nanoid } from 'nanoid'
import type { DbClient } from '../db/client'
import {
  FORCE_SYNC_ROLE_IDS,
  normalizeCapabilitiesForRole,
  OWNER_ROLE_ID,
  SYSTEM_ROLES,
  type CoreCapability,
} from '../auth/capabilities'
import type { RoleRow } from '../types'
import { nowIso } from '@core/utils/isoDate'

export interface Role {
  id: string
  slug: string
  name: string
  description: string
  isSystem: boolean
  capabilities: CoreCapability[]
  createdAt: string
  updatedAt: string
}

export class RoleMutationError extends Error {
  readonly status: number

  constructor(message: string, status = 400) {
    super(message)
    this.name = 'RoleMutationError'
    this.status = status
  }
}

function rowToRole(row: RoleRow): Role {
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    description: row.description,
    isSystem: Boolean(row.is_system),
    capabilities: normalizeCapabilitiesForRole(row.id, row.capabilities_json),
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  }
}

const SYSTEM_ROLE_RANK = new Map(SYSTEM_ROLES.map((role, index) => [role.id, index]))
const CUSTOM_ROLE_RANK = SYSTEM_ROLES.length

function compareRolesByRank(a: Role, b: Role): number {
  const rankDifference =
    (SYSTEM_ROLE_RANK.get(a.id) ?? CUSTOM_ROLE_RANK) -
    (SYSTEM_ROLE_RANK.get(b.id) ?? CUSTOM_ROLE_RANK)
  if (rankDifference !== 0) return rankDifference
  return a.name.localeCompare(b.name)
}

function slugFromRoleName(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
}

export async function listRoles(db: DbClient): Promise<Role[]> {
  const { rows } = await db<RoleRow>`
    select id, slug, name, description, is_system, capabilities_json, created_at, updated_at
    from roles
    order by is_system desc, name asc
  `
  return rows.map(rowToRole).sort(compareRolesByRank)
}

export async function findRoleById(db: DbClient, roleId: string): Promise<Role | null> {
  const { rows } = await db<RoleRow>`
    select id, slug, name, description, is_system, capabilities_json, created_at, updated_at
    from roles
    where id = ${roleId}
    limit 1
  `
  return rows[0] ? rowToRole(rows[0]) : null
}

async function getRoleBySlug(db: DbClient, slug: string): Promise<Role | null> {
  const { rows } = await db<RoleRow>`
    select id, slug, name, description, is_system, capabilities_json, created_at, updated_at
    from roles
    where slug = ${slug}
    limit 1
  `
  return rows[0] ? rowToRole(rows[0]) : null
}

async function assertRoleSlugAvailable(
  db: DbClient,
  slug: string,
  currentRoleId?: string,
): Promise<void> {
  const existing = await getRoleBySlug(db, slug)
  if (existing && existing.id !== currentRoleId) {
    throw new RoleMutationError('Role slug is already in use', 409)
  }
}

export async function createCustomRole(
  db: DbClient,
  input: {
    name: string
    slug?: string
    description: string
    capabilities: CoreCapability[]
  },
): Promise<Role> {
  if (input.capabilities.includes('roles.manage')) {
    throw new RoleMutationError('roles.manage is reserved for the Owner role')
  }
  const name = input.name.trim()
  if (!name) throw new RoleMutationError('Role name is required')

  const slug = slugFromRoleName(input.slug || name)
  if (!slug) throw new RoleMutationError('Role slug is required')
  await assertRoleSlugAvailable(db, slug)

  const id = nanoid()
  const { rows } = await db<RoleRow>`
    insert into roles (id, slug, name, description, is_system, capabilities_json)
    values (${id}, ${slug}, ${name}, ${input.description.trim()}, ${false}, ${input.capabilities})
    returning id, slug, name, description, is_system, capabilities_json, created_at, updated_at
  `
  return rowToRole(rows[0]!)
}

/**
 * Update an existing role. Built-in (system) roles other than Owner are
 * editable just like custom roles — only the Owner is locked.
 *
 * Owner-role policy:
 *  - capabilities are managed by the system (synced from `CORE_CAPABILITIES`
 *    at boot via `syncOwnerRoleCapabilities`) and cannot be edited
 *  - the row itself cannot be renamed or re-described — its presence is a
 *    structural invariant of the installation
 */
export async function updateRole(
  db: DbClient,
  roleId: string,
  input: {
    name?: string
    slug?: string
    description?: string
    capabilities?: CoreCapability[]
  },
): Promise<Role | null> {
  const current = await findRoleById(db, roleId)
  if (!current) return null
  if (current.id === OWNER_ROLE_ID) {
    throw new RoleMutationError('The Owner role is locked and cannot be edited', 409)
  }
  if (input.capabilities?.includes('roles.manage')) {
    throw new RoleMutationError('roles.manage is reserved for the Owner role')
  }

  const name = input.name === undefined ? current.name : input.name.trim()
  if (!name) throw new RoleMutationError('Role name is required')
  const slug = input.slug === undefined ? current.slug : slugFromRoleName(input.slug)
  if (!slug) throw new RoleMutationError('Role slug is required')
  await assertRoleSlugAvailable(db, slug, current.id)
  const description = input.description === undefined ? current.description : input.description.trim()
  const capabilities = input.capabilities ?? current.capabilities

  const { rows } = await db<RoleRow>`
    update roles
    set slug = ${slug},
        name = ${name},
        description = ${description},
        capabilities_json = ${capabilities},
        updated_at = ${nowIso()}
    where id = ${roleId}
    returning id, slug, name, description, is_system, capabilities_json, created_at, updated_at
  `
  return rows[0] ? rowToRole(rows[0]) : null
}

/**
 * Delete a custom role. System roles (built-ins) cannot be deleted — they
 * are part of the installation's expected role registry. Use `updateRole`
 * to edit a non-owner system role's name/capabilities instead.
 */
export async function deleteCustomRole(db: DbClient, roleId: string): Promise<Role | null> {
  const current = await findRoleById(db, roleId)
  if (!current) return null
  if (current.isSystem) throw new RoleMutationError('System roles cannot be deleted', 409)

  const { rows } = await db<{ count: number }>`
    select count(*) as count
    from users
    where role_id = ${roleId}
      and deleted_at is null
  `
  if (Number(rows[0]?.count ?? 0) > 0) {
    throw new RoleMutationError('Cannot delete a role assigned to users', 409)
  }

  const result = await db`delete from roles where id = ${roleId}`
  return result.rowCount > 0 ? current : null
}

/**
 * Boot-time sync — UPSERT every entry from `SYSTEM_ROLES` so the four built-in
 * roles (owner, admin, client, member) always exist after a fresh install OR
 * an upgrade that introduces a new system role.
 *
 *  - Roles in `FORCE_SYNC_ROLE_IDS` (Owner + Admin) — name / description /
 *    capabilities are ALWAYS resynced from the code constants. Adding a new
 *    capability to `CORE_CAPABILITIES` and to the role's literal list in
 *    `SYSTEM_ROLES` propagates to every existing installation on the next
 *    boot — owners and admins are never stranded on a stale grant list, and
 *    operators don't have to manually re-grant new capabilities through the
 *    admin UI after every upgrade.
 *  - Client / Member: inserted on first boot only. Subsequent boots leave
 *    the persisted row untouched so user-customised name / description /
 *    capabilities survive upgrades. Use the admin UI to edit them.
 *
 * The trade-off for Admin force-sync: if an operator hand-removes a
 * capability from the Admin role through the UI, the boot sync restores
 * it. That is intentional — capability grants for built-in roles are a
 * code-level decision, not a runtime one. Operators who need a "limited
 * admin" persona should create a custom role.
 *
 * Called from `server/index.ts` after `runMigrations`.
 */
export async function syncSystemRoles(db: DbClient): Promise<void> {
  for (const role of SYSTEM_ROLES) {
    const forceSync = FORCE_SYNC_ROLE_IDS.includes(role.id)
    if (forceSync) {
      // Force-resync the row to whatever the code declares.
      await db`
        insert into roles (id, slug, name, description, is_system, capabilities_json)
        values (${role.id}, ${role.slug}, ${role.name}, ${role.description}, ${true}, ${role.capabilities})
        on conflict (id) do update
        set slug = excluded.slug,
            name = excluded.name,
            description = excluded.description,
            is_system = excluded.is_system,
            capabilities_json = excluded.capabilities_json,
            updated_at = ${nowIso()}
      `
    } else {
      // First-boot seed for the role; preserve any later customisation.
      await db`
        insert into roles (id, slug, name, description, is_system, capabilities_json)
        values (${role.id}, ${role.slug}, ${role.name}, ${role.description}, ${true}, ${role.capabilities})
        on conflict (id) do nothing
      `
    }
  }
}
