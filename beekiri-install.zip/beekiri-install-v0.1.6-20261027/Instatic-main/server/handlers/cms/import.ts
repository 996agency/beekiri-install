/**
 * Site bundle import endpoint.
 *
 *   POST /admin/api/cms/import[?strategy=replace|merge-add|merge-overwrite]
 *
 * Accepts a `SiteBundle` JSON body (as produced by GET/POST /admin/api/cms/export)
 * and applies it to the local instance using the specified strategy.
 *
 * Strategies:
 *   replace         (default) — delete everything, reimport from bundle atomically.
 *   merge-add                 — insert rows/tables that don't exist locally; skip
 *                               those whose id already exists. Never overwrites.
 *   merge-overwrite           — upsert rows/tables: add missing, update existing.
 *
 * All DB mutations run inside a single transaction. Media writes happen after
 * the transaction (filesystem); individual media failures log and continue
 * without aborting the import.
 *
 * `replace` also wipes the media library when the import replaces everything
 * that can reference it (`replacesMediaLibrary`). The rows go inside the
 * transaction; their stored bytes are removed after it commits and BEFORE the
 * bundle's media is written, so a bundle file at a deleted asset's storage
 * path lands after the old one is gone.
 *
 * `applySiteBundle` is the DB half both import endpoints share: this JSON
 * endpoint and `/import/archive` (`./importArchive.ts`), which streams media
 * from the ZIP instead of Base64.
 *
 * Capability matrix (G6 fix — was a single `site.structure.edit` for
 * everything, which let a Designer with structure-edit but no
 * content rights wipe every row via the import endpoint):
 *
 *   ALL strategies require:        `data.import`
 *   `replace` strategy ALSO needs: `content.manage` AND step-up
 *                                  (wipe-and-reload is the highest blast
 *                                  radius operation in the CMS)
 *   bundles carrying a `site`:     ALSO `site.structure.edit` (the site
 *                                  shell replace is a structural edit)
 */
import { mkdir, writeFile } from 'node:fs/promises'
import { dirname } from 'node:path'
import type { DbClient } from '../../db/client'
import {
  validateAndSanitizeMediaBytes,
  resolveMediaWriteTarget,
} from './importMediaValidation'
import { requireCapability, requireStepUp, userHasCapability } from '../../auth/authz'
import type { AuthUser } from '../../repositories/users'
import { saveDraftSite } from '../../repositories/site'
import {
  listDataTables,
  createDataTable,
  updateDataTable,
  insertDataTableIfAbsent,
} from '../../repositories/data/tables'
import {
  listDataRows,
  upsertDataRow,
  insertDataRowIfAbsent,
  replaceDataRow,
  type DataRowImportInput,
} from '../../repositories/data/rows'
import {
  importMediaAsset,
  assignAssetToFolders,
  deleteSiteMediaAssets,
  type DeletedMediaAsset,
} from '../../repositories/media'
import { listBranches } from '../../repositories/branches'
import { removeMediaAssetFiles } from './mediaVariants'
import {
  deleteAllDataRowRedirects,
  importDataRowRedirect,
} from '../../repositories/data/publish'
import { deleteAllMediaFolders, importMediaFolder } from '../../repositories/mediaFolders'
import { jsonResponse, readValidatedBody } from '../../http'
import { parseValue } from '@core/utils/typeboxHelpers'
import {
  SiteBundleSchema,
  ImportStrategySchema,
  ImportResultSchema,
  type ImportStrategy,
  type SiteBundle,
} from '@core/data/bundleSchema'
import { CMS_API_PREFIX, type CmsHandlerOptions } from './shared'
import {
  notifyRowWrite,
  notifyShellWrite,
  serializeCollabAwareWrite,
  type RowWriteKind,
} from '../../repositories/rowWriteEvents'
import { isMainScope, type BranchScope } from '../../branches/scope'
import { MAIN_BRANCH_ID } from '@core/branches'

// The four system table ids that are always seeded and never deleted.
const SYSTEM_TABLE_IDS = new Set(['posts', 'pages', 'components', 'layouts'])

/**
 * Order folders so every parent precedes its children — `media_folders.parent_id`
 * is a self-referencing foreign key, so inserts must be topological. Any folder
 * whose parent isn't in the set is treated as a root (defensive: a malformed
 * bundle never wedges the import).
 */
function orderFoldersParentFirst<T extends { id: string; parentId: string | null }>(
  folders: readonly T[],
): T[] {
  const byId = new Map(folders.map((f) => [f.id, f]))
  const emitted = new Set<string>()
  const ordered: T[] = []

  const visit = (folder: T): void => {
    if (emitted.has(folder.id)) return
    const parent = folder.parentId !== null ? byId.get(folder.parentId) : undefined
    if (parent) visit(parent)
    emitted.add(folder.id)
    ordered.push(folder)
  }

  for (const folder of folders) visit(folder)
  return ordered
}

/** ZIP local-file-header magic (`PK\x03\x04`) — enough to tell an archive from JSON. */
function looksLikeZipArchive(body: ArrayBuffer): boolean {
  if (body.byteLength < 4) return false
  const head = new Uint8Array(body, 0, 4)
  return head[0] === 0x50 && head[1] === 0x4b && head[2] === 0x03 && head[3] === 0x04
}

export async function handleImportRoute(
  req: Request,
  db: DbClient,
  scope: BranchScope,
  options: CmsHandlerOptions = {},
): Promise<Response | null> {
  const url = new URL(req.url)
  if (url.pathname !== `${CMS_API_PREFIX}/import`) return null
  if (req.method !== 'POST') return jsonResponse({ error: 'Method not allowed' }, { status: 405 })

  // Base gate — any import requires `data.import`.
  const user = await requireCapability(req, db, 'data.import')
  if (user instanceof Response) return user

  // Parse strategy from query string (default: replace)
  const strategyParam = url.searchParams.get('strategy') ?? 'replace'
  let strategy: ImportStrategy
  try {
    strategy = parseValue(ImportStrategySchema, strategyParam)
  } catch {
    return jsonResponse(
      { error: 'Invalid strategy — must be replace, merge-add, or merge-overwrite' },
      { status: 400 },
    )
  }

  const strategyDenied = await authorizeImportStrategy(req, db, user, strategy)
  if (strategyDenied) return strategyDenied

  // Parse and validate the bundle body. This endpoint takes the JSON bundle;
  // the ZIP archive the export UI downloads belongs to /import/archive. Sent
  // here it fails schema validation, and a bare schema error sends the caller
  // hunting a bug in their bundle instead of at the wrong door — so name the
  // mistake when the body is recognisably an archive.
  const rawBody = await req.clone().arrayBuffer()
  if (looksLikeZipArchive(rawBody)) {
    return jsonResponse(
      {
        error:
          'This endpoint accepts a JSON site bundle. The exported .zip archive goes to '
          + `${CMS_API_PREFIX}/import/archive (same strategy query parameter).`,
      },
      { status: 400 },
    )
  }
  const bundle = await readValidatedBody(req, SiteBundleSchema)
  if (!bundle) {
    return jsonResponse({ error: 'Invalid bundle: body does not conform to SiteBundleSchema' }, { status: 400 })
  }

  const shellDenied = authorizeImportedShell(user, bundle.site !== undefined)
  if (shellDenied) return shellDenied

  const applied = await applySiteBundle(db, scope, {
    bundle,
    strategy,
    carriesMedia: bundle.media !== undefined,
  })
  // After commit, before the bundle's media lands: a bundle file at a deleted
  // asset's storage path must be written after the old bytes are removed.
  await removeDeletedMediaFiles(applied.deletedMedia)

  let mediaImported = 0

  // ---------------------------------------------------------------------------
  // Media — outside the DB transaction (filesystem writes)
  // ---------------------------------------------------------------------------
  if (bundle.media && bundle.media.length > 0 && options.uploadsDir) {
    const uploadsDir = options.uploadsDir
    await mkdir(uploadsDir, { recursive: true })

    for (const asset of bundle.media) {
      try {
        // Same security gate the archive import and upload pipeline apply:
        //   - destination: no traversal, never a reserved served subtree
        //     (published/plugins/fonts) — `resolveMediaWriteTarget`;
        //   - content: real MIME must match the declared type + extension and
        //     SVG is sanitised — `validateAndSanitizeMediaBytes`.
        // Without this, a `data.import` caller could write arbitrary HTML/JS
        // (e.g. `published/current/index.html`) served same-origin as /admin.
        const target = resolveMediaWriteTarget(uploadsDir, asset.storagePath)
        const safeBytes = validateAndSanitizeMediaBytes(
          Buffer.from(asset.bytesBase64, 'base64'),
          asset,
        )
        await mkdir(dirname(target), { recursive: true })
        await writeFile(target, safeBytes)

        // Upsert the media_assets row
        await importMediaAsset(db, {
          id: asset.id,
          filename: asset.filename,
          mimeType: asset.mimeType,
          sizeBytes: safeBytes.length,
          storagePath: asset.storagePath,
          publicPath: `/uploads/${asset.storagePath}`,
          altText: asset.altText,
          caption: asset.caption,
          title: asset.title,
          tags: asset.tags,
          width: asset.width,
          height: asset.height,
          durationMs: asset.durationMs,
          dominantColor: asset.dominantColor,
          blurHash: asset.blurHash,
          posterPath: asset.posterPath,
        })

        // Restore folder membership — but only into folders we actually
        // imported, so a stale folderId can't violate the membership FK.
        const targetFolders = asset.folderIds.filter((id) => applied.importedFolderIds.has(id))
        if (targetFolders.length > 0) {
          await assignAssetToFolders(db, asset.id, { add: targetFolders })
        }

        mediaImported++
      } catch (err) {
        console.error('[import] Failed to import media asset:', asset.id, err)
        // Continue with remaining assets — a single failed asset should not
        // abort the whole import (data is already committed).
      }
    }
  }

  const result = {
    ok: true as const,
    strategy,
    tablesAffected: applied.tablesAffected,
    rowsInserted: applied.rowsInserted,
    rowsReplaced: applied.rowsReplaced,
    rowsSkipped: applied.rowsSkipped,
    mediaImported,
    mediaFoldersImported: applied.mediaFoldersImported,
    redirectsImported: applied.redirectsImported,
  }

  // Paranoia: validate result shape before returning
  parseValue(ImportResultSchema, result)

  return jsonResponse(result)
}

/**
 * Strategy gate every bundle import passes on top of `data.import` (G6 fix —
 * was a single `site.structure.edit` for everything, which let a Designer
 * with structure-edit but no content rights wipe every row via the import
 * endpoint). Checked before the body is read. Shared with the archive
 * endpoint. Returns the error response, or `null` to proceed.
 *
 * `replace` = wipe every data row and reinsert, the highest-blast-radius
 * operation in the CMS. It requires `content.manage` (so a caller with
 * `data.import` but no content rights can still merge-add but not wipe) AND
 * step-up (mirrors users.ts delete / publish.ts publish).
 */
export async function authorizeImportStrategy(
  req: Request,
  db: DbClient,
  user: AuthUser,
  strategy: ImportStrategy,
): Promise<Response | null> {
  if (strategy !== 'replace') return null
  if (!userHasCapability(user, 'content.manage')) {
    return jsonResponse({ error: 'Forbidden' }, { status: 403 })
  }
  return requireStepUp(req, db, user)
}

/**
 * Bundles that carry a site shell additionally require `site.structure.edit`:
 * replacing the shell is a structural site edit even when the strategy is
 * merge-overwrite. Shared with the archive endpoint.
 */
export function authorizeImportedShell(user: AuthUser, carriesSite: boolean): Response | null {
  if (carriesSite && !userHasCapability(user, 'site.structure.edit')) {
    return jsonResponse({ error: 'Forbidden' }, { status: 403 })
  }
  return null
}

export interface ApplySiteBundleInput {
  /** The bundle's data. Media bytes, when present, are not read here. */
  bundle: SiteBundle
  strategy: ImportStrategy
  /**
   * The import carries the media category (the bundle lists media, possibly
   * none). The archive endpoint strips media from `bundle` and streams the
   * bytes itself, so it states this separately.
   */
  carriesMedia: boolean
}

export interface AppliedSiteBundle {
  tablesAffected: number
  rowsInserted: number
  rowsReplaced: number
  rowsSkipped: number
  mediaFoldersImported: number
  redirectsImported: number
  /**
   * Folder ids that actually landed — asset memberships are restored only for
   * these, so an asset's `folderIds` pointing at a folder we didn't import is
   * skipped rather than violating the membership foreign key.
   */
  importedFolderIds: Set<string>
  /** Media rows a `replace` deleted; their bytes are the caller's to remove. */
  deletedMedia: DeletedMediaAsset[]
}

/**
 * Whether a `replace` import also replaces the media library. Media is not
 * branch-scoped, and records outside the import can reference it, so the
 * library is wiped only when nothing that survives the replace can:
 *
 *   - the import carries media at all (a bundle exported without media says
 *     nothing about the library, like folders and redirects);
 *   - it carries the site shell (a kept shell can reference media: favicon,
 *     `@font-face` sources, background images in style rules);
 *   - it runs on main and no other branch exists (branches share main's
 *     library and their rows and shells reference it).
 *
 * Assets owned by surviving records (avatars, plugin-managed media) are
 * spared by `deleteSiteMediaAssets` itself.
 */
async function replacesMediaLibrary(
  db: DbClient,
  scope: BranchScope,
  input: ApplySiteBundleInput,
): Promise<boolean> {
  if (!input.carriesMedia || input.bundle.site === undefined) return false
  if (!isMainScope(scope)) return false
  const branches = await listBranches(db)
  return branches.every((branch) => branch.id === MAIN_BRANCH_ID)
}

/**
 * Remove the bytes of media rows a committed `replace` deleted. Call it after
 * `applySiteBundle` returns and before writing the bundle's media.
 */
export async function removeDeletedMediaFiles(deleted: readonly DeletedMediaAsset[]): Promise<void> {
  for (const asset of deleted) await removeMediaAssetFiles(asset)
}

/**
 * Apply a bundle's site, tables, rows, folders, and redirects (and, for
 * `replace`, delete the media library) per `strategy`, in one transaction on
 * the collab-aware write lane, then notify open editors. Media bytes and
 * media rows are written by the caller afterwards.
 */
export async function applySiteBundle(
  db: DbClient,
  scope: BranchScope,
  input: ApplySiteBundleInput,
): Promise<AppliedSiteBundle> {
  const { bundle, strategy } = input
  let tablesAffected = 0
  let rowsInserted = 0
  let rowsReplaced = 0
  let rowsSkipped = 0
  let mediaFoldersImported = 0
  let redirectsImported = 0
  let deletedMedia: DeletedMediaAsset[] = []
  const importedFolderIds = new Set<string>()

  await serializeCollabAwareWrite(async () => {
    const affectedCollabRows = new Map(
      ['pages', 'components', 'layouts'].map((tableId) => [tableId, new Set<string>()]),
    )
    const removedCollabRows = new Map(
      ['pages', 'components', 'layouts'].map((tableId) => [tableId, new Set<string>()]),
    )
    const createdCollabRows = new Map(
      ['pages', 'components', 'layouts'].map((tableId) => [tableId, new Set<string>()]),
    )
    let shellWasWritten = false
    if (strategy === 'replace') {
      for (const tableId of affectedCollabRows.keys()) {
        for (const row of await listDataRows(db, scope, tableId)) {
          affectedCollabRows.get(tableId)?.add(row.id)
        }
      }
    }

    if (strategy === 'replace') {
      // Wipe-and-replace: delete all rows + custom tables, then reimport.
      await db.transaction(async (tx) => {
        // 1. Delete ALL of this branch's data rows (covers all tables)
        await tx`delete from data_rows where branch_id = ${scope.branchId}`

        // 2. Delete this branch's non-system data tables. The flag is bound,
        //    not written as a literal: `system = 0` is `boolean = integer` on
        //    Postgres (an error), and the SQLite adapter binds `false` as 0.
        await tx`
          delete from data_tables
          where branch_id = ${scope.branchId}
            and system = ${false}
        `

        // 3. Load remaining system tables so we know which bundle tables to
        //    update vs insert.
        const existingTables = await listDataTables(tx, scope)
        const existingTableIds = new Set(existingTables.map((t) => t.id))

        // 4. Upsert tables from the bundle
        for (const table of bundle.tables) {
          if (existingTableIds.has(table.id)) {
            // System table already present — update its fields
            await updateDataTable(tx, scope, table.id, {
              name: table.name,
              slug: table.slug,
              routeBase: table.routeBase,
              singularLabel: table.singularLabel,
              pluralLabel: table.pluralLabel,
              primaryFieldId: table.primaryFieldId,
              fields: table.fields,
            })
            tablesAffected++
          } else if (!SYSTEM_TABLE_IDS.has(table.id)) {
            // Custom table — insert with original id. `createdByPluginId` is
            // access-control state (the `@own-created` contentAccess marker
            // resolves against it), so a restore keeps plugin-created tables
            // owned by their plugin.
            await createDataTable(tx, scope, {
              id: table.id,
              name: table.name,
              slug: table.slug,
              kind: table.kind,
              routeBase: table.routeBase,
              singularLabel: table.singularLabel,
              pluralLabel: table.pluralLabel,
              primaryFieldId: table.primaryFieldId,
              fields: table.fields,
              createdByPluginId: table.createdByPluginId ?? null,
            })
            tablesAffected++
          }
          // Bundle tables whose id is a known SYSTEM_TABLE_ID but wasn't seeded
          // locally are silently skipped — they should never occur in practice.
        }

        // 5. Insert all rows (plain insert — table was just wiped)
        for (const row of bundle.rows) {
          const input: DataRowImportInput = {
            id: row.id,
            tableId: row.tableId,
            cells: row.cells,
            slug: row.slug,
            status: row.status,
            publishedAt: row.publishedAt,
            createdAt: row.createdAt,
            updatedAt: row.updatedAt,
          }
          await replaceDataRow(tx, scope, input)
          affectedCollabRows.get(row.tableId)?.add(row.id)
          rowsInserted++
        }

        // 6. Replace the site shell (only when the bundle carries one)
        if (bundle.site) {
          await saveDraftSite(tx, scope, bundle.site, null, { collabInternal: true })
          shellWasWritten = true
        }

        // 7. Media library. Wiped only when this import replaces everything
        //    that can reference it (see `replacesMediaLibrary`). Rows go
        //    here, inside the transaction; their bytes are removed by the
        //    caller after commit, so a rolled-back import never loses a file.
        if (await replacesMediaLibrary(tx, scope, input)) {
          deletedMedia = await deleteSiteMediaAssets(tx)
        }

        // 8. Media folder tree. `delete from data_rows` above does NOT touch
        //    media_folders (unrelated FK), so wipe explicitly, then insert
        //    parent-first to satisfy the self-referencing parent_id FK.
        if (bundle.mediaFolders) {
          await deleteAllMediaFolders(tx)
          for (const folder of orderFoldersParentFirst(bundle.mediaFolders)) {
            await importMediaFolder(tx, folder)
            importedFolderIds.add(folder.id)
            mediaFoldersImported++
          }
        }

        // 9. Redirects. Old ones already cascade-deleted with their target rows
        //    in step 1; wipe explicitly for clarity, then reinsert from the
        //    bundle now that the target rows exist.
        if (bundle.redirects) {
          await deleteAllDataRowRedirects(tx)
          for (const redirect of bundle.redirects) {
            await importDataRowRedirect(tx, redirect)
            redirectsImported++
          }
        }
      })
    } else if (strategy === 'merge-add') {
      // Add what's missing; never overwrite existing content.
      await db.transaction(async (tx) => {
        // Tables: insert if absent, skip if the id already exists
        for (const table of bundle.tables) {
          const inserted = await insertDataTableIfAbsent(tx, scope, {
            id: table.id,
            name: table.name,
            slug: table.slug,
            kind: table.kind,
            routeBase: table.routeBase,
            singularLabel: table.singularLabel,
            pluralLabel: table.pluralLabel,
            primaryFieldId: table.primaryFieldId,
            fields: table.fields,
            createdByPluginId: table.createdByPluginId ?? null,
          })
          if (inserted) tablesAffected++
        }

        // Rows: insert if absent, skip if the id already exists
        for (const row of bundle.rows) {
          const input: DataRowImportInput = {
            id: row.id,
            tableId: row.tableId,
            cells: row.cells,
            slug: row.slug,
            status: row.status,
            publishedAt: row.publishedAt,
            createdAt: row.createdAt,
            updatedAt: row.updatedAt,
          }
          const inserted = await insertDataRowIfAbsent(tx, scope, input)
          if (inserted) {
            affectedCollabRows.get(row.tableId)?.add(row.id)
            rowsInserted++
          } else {
            rowsSkipped++
          }
        }

        // Site shell: merge-add never overwrites the site shell — the local site
        // has existing content that must not be destroyed by an additive import.
      })
    } else {
      // merge-overwrite: upsert rows/tables; update existing with bundle values.
      await db.transaction(async (tx) => {
        // Pre-fetch all existing rows. An upsert can move an id from a table the
        // bundle does not mention, and both its old and new collab docs/rosters
        // must be invalidated after commit.
        const existingRowTables = new Map<string, string>()
        for (const table of await listDataTables(tx, scope)) {
          const existing = await listDataRows(tx, scope, table.id)
          for (const row of existing) existingRowTables.set(row.id, row.tableId)
        }

        // Tables: insert if absent, update if already present
        for (const table of bundle.tables) {
          const inserted = await insertDataTableIfAbsent(tx, scope, {
            id: table.id,
            name: table.name,
            slug: table.slug,
            kind: table.kind,
            routeBase: table.routeBase,
            singularLabel: table.singularLabel,
            pluralLabel: table.pluralLabel,
            primaryFieldId: table.primaryFieldId,
            fields: table.fields,
            createdByPluginId: table.createdByPluginId ?? null,
          })
          if (!inserted) {
            await updateDataTable(tx, scope, table.id, {
              name: table.name,
              slug: table.slug,
              routeBase: table.routeBase,
              singularLabel: table.singularLabel,
              pluralLabel: table.pluralLabel,
              primaryFieldId: table.primaryFieldId,
              fields: table.fields,
            })
          }
          tablesAffected++
        }

        // Rows: upsert all; track inserted vs replaced via the pre-fetched set
        for (const row of bundle.rows) {
          const input: DataRowImportInput = {
            id: row.id,
            tableId: row.tableId,
            cells: row.cells,
            slug: row.slug,
            status: row.status,
            publishedAt: row.publishedAt,
            createdAt: row.createdAt,
            updatedAt: row.updatedAt,
          }
          await upsertDataRow(tx, scope, input)
          const previousTableId = existingRowTables.get(row.id)
          if (previousTableId === undefined) {
            createdCollabRows.get(row.tableId)?.add(row.id)
          } else if (previousTableId !== row.tableId) {
            removedCollabRows.get(previousTableId)?.add(row.id)
            createdCollabRows.get(row.tableId)?.add(row.id)
          } else {
            affectedCollabRows.get(row.tableId)?.add(row.id)
          }
          if (previousTableId !== undefined) {
            rowsReplaced++
          } else {
            rowsInserted++
          }
        }

        // Site shell: overwrite if the bundle carries one
        if (bundle.site) {
          await saveDraftSite(tx, scope, bundle.site, null, { collabInternal: true })
          shellWasWritten = true
        }
      })
    }

    const branchId = scope.branchId
    if (shellWasWritten) notifyShellWrite(branchId)
    if (strategy === 'merge-overwrite') {
      for (const [tableId, ids] of affectedCollabRows) {
        if (ids.size > 0) notifyRowWrite({ branchId, tableId, rowIds: [...ids], kind: 'update' })
      }
      for (const [tableId, ids] of removedCollabRows) {
        if (ids.size > 0) notifyRowWrite({ branchId, tableId, rowIds: [...ids], kind: 'delete' })
      }
      for (const [tableId, ids] of createdCollabRows) {
        if (ids.size > 0) notifyRowWrite({ branchId, tableId, rowIds: [...ids], kind: 'create' })
      }
    } else {
      const eventKind: RowWriteKind = strategy === 'replace' ? 'delete' : 'create'
      for (const [tableId, ids] of affectedCollabRows) {
        if (ids.size > 0) notifyRowWrite({ branchId, tableId, rowIds: [...ids], kind: eventKind })
      }
    }
  })

  return {
    tablesAffected,
    rowsInserted,
    rowsReplaced,
    rowsSkipped,
    mediaFoldersImported,
    redirectsImported,
    importedFolderIds,
    deletedMedia,
  }
}
