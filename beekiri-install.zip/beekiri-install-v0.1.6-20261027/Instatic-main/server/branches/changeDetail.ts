/**
 * The diff helpers behind a planned change's `detail` on the review page:
 * which fields moved (as display text), which page nodes were added, changed
 * or removed, how a table's schema differs. Each entity adapter's
 * `describe` (`./entities/`) builds its kind's detail from these, over the
 * same content projections the merge compares, so the review never
 * disagrees with the plan.
 *
 * "before" is the receiving side (`into`), "after" the contributing side
 * (`from`) — main and the branch for a merge, the other way round for an
 * update.
 */
import { parsePageNode } from '@core/page-tree'
import { canonicalJson } from '@core/utils/canonicalJson'
import type { MergeFieldChange, MergeSchemaField, MergeTreeDiff } from '@core/branches'

const PREVIEW_LIMIT = 240

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function displayValue(value: unknown): { text: string | null; structured: boolean } {
  if (value === undefined || value === null) return { text: null, structured: false }
  if (typeof value === 'string') return { text: value, structured: false }
  if (typeof value === 'number' || typeof value === 'boolean') return { text: String(value), structured: false }
  const json = canonicalJson(value)
  return { text: json.length > PREVIEW_LIMIT ? `${json.slice(0, PREVIEW_LIMIT)}…` : json, structured: true }
}

export interface FieldChangeOptions {
  /** Prefix that turns a key into the conflict path the merge reports. */
  prefix: string
  conflicts: ReadonlySet<string>
  skip?: ReadonlySet<string>
  labels?: Readonly<Record<string, string>>
}

/** Field-by-field difference of two flat records, as the review displays it. */
export function fieldChanges(
  before: Record<string, unknown>,
  after: Record<string, unknown>,
  options: FieldChangeOptions,
): MergeFieldChange[] {
  const keys = [...new Set([...Object.keys(before), ...Object.keys(after)])].sort()
  const out: MergeFieldChange[] = []
  for (const key of keys) {
    if (options.skip?.has(key)) continue
    const a = before[key]
    const b = after[key]
    if (canonicalJson(a ?? null) === canonicalJson(b ?? null)) continue
    const shownBefore = displayValue(a)
    const shownAfter = displayValue(b)
    const path = `${options.prefix}${key}`
    out.push({
      id: key,
      label: options.labels?.[key] ?? key,
      before: shownBefore.text,
      after: shownAfter.text,
      structured: shownBefore.structured || shownAfter.structured,
      // A conflict deeper inside a structured value still belongs to this field.
      conflict: [...options.conflicts].some((conflict) => conflict === path || conflict.startsWith(`${path}.`)),
    })
  }
  return out
}

/**
 * What "the same node" means for the diff: the node as the editor would load
 * it, minus its children (a child list change is the child's own add/remove).
 * Rows written outside the editor (the data API, an import) may store `{}`
 * maps or omit them; parsing both sides first keeps those from counting as
 * changes.
 */
function nodeSignature(node: unknown): string {
  if (!isRecord(node)) return canonicalJson(node ?? null)
  const { children: _children, ...rest } = normalizeNode(node)
  return canonicalJson(rest)
}

function normalizeNode(node: Record<string, unknown>): Record<string, unknown> {
  try {
    return parsePageNode(node, 'node')
  } catch {
    // A node the editor could not load is compared as stored.
    return node
  }
}

const NODE_TEXT_LIMIT = 80

function quote(value: unknown): string {
  const text = typeof value === 'string' ? value : String(value)
  const shown = text.length > NODE_TEXT_LIMIT ? `${text.slice(0, NODE_TEXT_LIMIT)}…` : text
  return `“${shown}”`
}

/** A scalar the review can print inline; objects and arrays are "changed". */
function isScalar(value: unknown): value is string | number | boolean {
  return typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean'
}

/**
 * What moved between two versions of one node, as lines the review prints
 * after the node's label: a prop with scalar values on both sides is quoted
 * (`text: “a” → “b”`), a prop or node field that is structured or missing on
 * one side is named. A prop that is the label itself (a `text` node's
 * `text`) is not repeated, so the line reads `Changed text: “a” → “b”`.
 * Children are not compared here; a child list change is the child's own
 * add or remove.
 */
function nodeChangeDetails(before: Record<string, unknown>, after: Record<string, unknown>, label: string): string[] {
  const lines: string[] = []
  const a = normalizeNode(before)
  const b = normalizeNode(after)
  const aProps = isRecord(a.props) ? a.props : {}
  const bProps = isRecord(b.props) ? b.props : {}
  const name = (key: string): string => (key === label ? '' : `${key}: `)
  for (const key of [...new Set([...Object.keys(aProps), ...Object.keys(bProps)])].sort()) {
    const x = aProps[key]
    const y = bProps[key]
    if (canonicalJson(x ?? null) === canonicalJson(y ?? null)) continue
    if (isScalar(x) && isScalar(y)) lines.push(`${name(key)}${quote(x)} → ${quote(y)}`)
    else if (x === undefined || x === null) lines.push(`${name(key)}set`)
    else if (y === undefined || y === null) lines.push(`${name(key)}cleared`)
    else lines.push(key === label ? 'changed' : `${key} changed`)
  }
  for (const key of Object.keys({ ...a, ...b }).sort()) {
    if (key === 'props' || key === 'children' || key === 'parentId' || key === 'id') continue
    if (canonicalJson(a[key] ?? null) === canonicalJson(b[key] ?? null)) continue
    lines.push(`${key} changed`)
  }
  return lines
}

function nodeLabel(node: unknown): string {
  if (!isRecord(node)) return 'node'
  if (typeof node.label === 'string' && node.label.trim()) return node.label.trim()
  if (typeof node.moduleId === 'string') return node.moduleId.replace(/^base\./, '')
  return 'node'
}

/** Node-level diff of two `{ nodes, rootNodeId }` trees; null when neither side has one. */
export function treeDiff(before: unknown, after: unknown): MergeTreeDiff | null {
  const beforeNodes = isRecord(before) && isRecord(before.nodes) ? before.nodes : null
  const afterNodes = isRecord(after) && isRecord(after.nodes) ? after.nodes : null
  if (!beforeNodes && !afterNodes) return null
  const a = beforeNodes ?? {}
  const b = afterNodes ?? {}
  const diff: MergeTreeDiff = { added: [], changed: [], removed: [], labels: {}, details: {} }
  for (const id of Object.keys(b)) {
    if (!(id in a)) {
      diff.added.push(id)
      diff.labels[id] = nodeLabel(b[id])
    } else if (nodeSignature(a[id]) !== nodeSignature(b[id])) {
      diff.changed.push(id)
      diff.labels[id] = nodeLabel(b[id])
      const before = a[id]
      const after = b[id]
      if (isRecord(before) && isRecord(after)) diff.details[id] = nodeChangeDetails(before, after, diff.labels[id])
    }
  }
  for (const id of Object.keys(a)) {
    if (!(id in b)) {
      diff.removed.push(id)
      diff.labels[id] = nodeLabel(a[id])
    }
  }
  return diff
}

function schemaFieldSummary(field: unknown): { id: string; label: string; type: string } | null {
  if (!isRecord(field) || typeof field.id !== 'string') return null
  const label = typeof field.label === 'string' && field.label.trim() ? field.label : field.id
  const type = typeof field.type === 'string' ? field.type : ''
  return { id: field.id, label, type }
}

/** Which fields a table schema gained, lost, or changed. */
export function schemaDiff(before: readonly unknown[], after: readonly unknown[]): MergeSchemaField[] {
  const beforeById = new Map<string, unknown>()
  for (const field of before) {
    const summary = schemaFieldSummary(field)
    if (summary) beforeById.set(summary.id, field)
  }
  const out: MergeSchemaField[] = []
  const seen = new Set<string>()
  for (const field of after) {
    const summary = schemaFieldSummary(field)
    if (!summary) continue
    seen.add(summary.id)
    const previous = beforeById.get(summary.id)
    const status = previous === undefined
      ? 'new'
      : canonicalJson(previous) === canonicalJson(field) ? 'same' : 'changed'
    out.push({ ...summary, status })
  }
  for (const field of before) {
    const summary = schemaFieldSummary(field)
    if (summary && !seen.has(summary.id)) out.push({ ...summary, status: 'removed' })
  }
  return out
}
