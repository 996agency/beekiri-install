/** Cross-screen signals so the shell can refresh without a full page reload. */

export const POST_TYPES_CHANGED = 'beekiri:post-types-changed';
export const CONNECTOR_CHANGED = 'beekiri:connector-changed';
export const EXTENSIONS_CHANGED = 'beekiri:extensions-changed';

export function notifyPostTypesChanged() {
  window.dispatchEvent(new Event(POST_TYPES_CHANGED));
}

export function notifyConnectorChanged() {
  window.dispatchEvent(new Event(CONNECTOR_CHANGED));
}

/** An extension was installed, activated, deactivated or removed. */
export function notifyExtensionsChanged() {
  window.dispatchEvent(new Event(EXTENSIONS_CHANGED));
}

export const BEEQUEEN_CREDITS = 'beekiri:beequeen-credits';

/** Live BeeQueen credit news from the chat, for the toolbar. */
export type BeeQueenCreditsDetail = {
  /** Credits left on the site, when known. */
  balance?: number;
  /** Credits ever added (packs + grants), when known. */
  granted?: number;
  /** A run is in progress. */
  running: boolean;
  /** Credits the current (or just finished) run has used. */
  runCredits: number;
};

export function notifyBeeQueenCredits(detail: BeeQueenCreditsDetail) {
  window.dispatchEvent(new CustomEvent<BeeQueenCreditsDetail>(BEEQUEEN_CREDITS, { detail }));
}
