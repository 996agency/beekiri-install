/**
 * Switches for areas that are built but not open yet. Flip to false to bring one back —
 * nothing behind a switch is removed.
 */

/** Connector / BeeQueen: menu item, page, chat bee and toolbar credits show as "coming soon". */
export const CONNECTOR_COMING_SOON = true;
