/**
 * Client-side admin inactivity lock.
 * 20 minutes total, warn with ≥2 minutes left (WCAG 2.2.1 / GOV.UK timeout pattern).
 */
export const IDLE_TIMEOUT_MS = 20 * 60 * 1000;
export const IDLE_WARN_MS = 2 * 60 * 1000;

export function formatIdleCountdown(ms: number): string {
  const totalSec = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

/** How often aria-live should re-announce remaining time. */
export function idleAnnounceIntervalMs(remainingMs: number): number {
  if (remainingMs <= 60_000) return 20_000;
  return 30_000;
}
