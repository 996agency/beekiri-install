import { FormEvent, useCallback, useEffect, useState } from 'react';
import { Link, Navigate, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import { useAdminHref } from '../lib/AdminEntryContext';
import { notifyConnectorChanged } from '../lib/admin-events';
import { BeeQueenAccount } from './BeeQueenAccount';
import { PoweredByClaude } from '../components/PoweredByClaude';
import './connector-page.css';
import { ErrorNotice } from '../components/ErrorNotice';

type ProviderId = 'beequeen' | 'claude' | 'openai' | 'gemini' | 'grok';

type Effort = 'low' | 'medium' | 'high' | 'xhigh' | 'max';

type ProviderDetail = {
  id: ProviderId;
  name: string;
  vendor: string;
  blurb: string;
  badge?: string;
  docsUrl: string;
  apiKeyLabel: string;
  apiKeyPlaceholder: string;
  models: { id: string; label: string }[];
  supportsEffort: boolean;
  enabled: boolean;
  configured: boolean;
  apiKeyMasked: string | null;
  /** BeeQueen only: what she runs on. */
  keySource: 'service' | 'claude' | 'env' | 'claude-code' | null;
  /** BeeQueen only: the BeeQueen service address. */
  serviceUrl: string | null;
  defaultModel: string;
  effort: Effort;
};

const EFFORTS: { id: Effort; label: string }[] = [
  { id: 'low', label: 'Low — fastest, cheapest' },
  { id: 'medium', label: 'Medium' },
  { id: 'high', label: 'High' },
  { id: 'xhigh', label: 'Extra high' },
  { id: 'max', label: 'Max — deepest thinking, slowest' },
];

const KEY_SOURCE: Record<'service' | 'claude' | 'env' | 'claude-code', string> = {
  service:
    'Connected to 996Agency. BeeQueen sends each request to Claude through 996Agency’s Anthropic API account — you don’t need your own Claude key — and it is paid from this site’s credits.',
  'claude-code':
    'No BeeQueen key yet — for local testing BeeQueen runs through Claude Code on this Mac. Add the site key from 996Agency for real use.',
  claude: 'No BeeQueen key yet — testing on the Claude connector’s Anthropic key.',
  env: 'No BeeQueen key yet — testing on ANTHROPIC_API_KEY from the server environment.',
};

const LOGO: Record<ProviderId, string> = {
  beequeen: '/admin/icon-192.png',
  claude: '/admin/connector/claude.svg',
  openai: '/admin/connector/openai.svg',
  gemini: '/admin/connector/gemini.svg',
  grok: '/admin/connector/grok.svg',
};

const IDS: ProviderId[] = ['beequeen', 'claude', 'openai', 'gemini', 'grok'];

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

/**
 * Provider setup. `embedded` renders it as the whole Connector page (BeeQueen only for now):
 * no back link, and turning it off keeps you here.
 */
export function ConnectorProviderPage({ id, embedded = false }: { id?: ProviderId; embedded?: boolean } = {}) {
  const { providerId: rawId } = useParams<{ providerId: string }>();
  const providerId = (id ?? (rawId || '').toLowerCase()) as ProviderId;
  const navigate = useNavigate();
  const href = useAdminHref();
  const valid = IDS.includes(providerId);

  const [data, setData] = useState<ProviderDetail | null>(null);
  const [apiKey, setApiKey] = useState('');
  const [defaultModel, setDefaultModel] = useState('');
  const [effort, setEffort] = useState<Effort>('max');
  /** Bumped after saving so the BeeQueen account reloads with the new key. */
  const [accountKey, setAccountKey] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(async () => {
    const res = await api<ProviderDetail>(`/api/connector/${providerId}`);
    setData(res);
    setDefaultModel(res.defaultModel);
    setEffort(res.effort);
    setApiKey('');
  }, [providerId]);

  useEffect(() => {
    if (!valid) return;
    load().catch((e) => setError(formatError(e)));
  }, [load, valid]);

  if (!valid) return <Navigate to={href('connector')} replace />;

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!data) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const body: Record<string, unknown> = {
        providerId,
        enabled: true,
        defaultModel,
      };
      if (data.supportsEffort) body.effort = effort;
      if (apiKey.trim()) body.apiKey = apiKey.trim();
      const res = await api<ProviderDetail>('/api/connector', { method: 'PATCH', json: body });
      setData(res);
      setApiKey('');
      setAccountKey((k) => k + 1);
      notifyConnectorChanged();
      setNotice(`${res.name} setup saved.`);
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const setEnabled = async (enabled: boolean) => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await api('/api/connector', {
        method: 'PATCH',
        json: { providerId, enabled },
      });
      notifyConnectorChanged();
      if (!embedded) {
        navigate(href('connector'));
        return;
      }
      await load();
      setNotice(enabled ? `${data?.name ?? 'BeeQueen'} is on.` : `${data?.name ?? 'BeeQueen'} is off — the chat bee is hidden until you turn it on.`);
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  if (!data && !error) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title="Connector" />
        <p className="bk-muted">Loading…</p>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title="Connector" />
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
        <p>
          <Link className="button" to={href('connector')}>
            Back to Connector
          </Link>
        </p>
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide bk-conn">
      {embedded ? null : (
        <p className="bk-conn-back">
          <Link className="bk-conn-back__link" to={href('connector')}>
            <ArrowLeft size={16} weight="bold" aria-hidden />
            <span>Connector</span>
          </Link>
        </p>
      )}
      <PageHeader
        title={embedded ? 'Connector' : data.name}
        actions={
          <button
            type="button"
            className={data.enabled ? 'button' : 'button button-primary'}
            disabled={busy}
            onClick={() => void setEnabled(!data.enabled)}
          >
            {data.enabled ? `Turn off ${data.name}` : `Turn on ${data.name}`}
          </button>
        }
      />
      <p className="bk-muted" style={{ marginTop: 0 }}>
        {data.blurb}
      </p>
      {data.id === 'beequeen' ? <PoweredByClaude detailed /> : null}

      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}

      <form className="bk-panel" onSubmit={(e) => void save(e)}>
        <div className="bk-panel__head">
          <div className="bk-conn-setup__head">
            <span className={`bk-conn-card__mark is-${data.id}`} aria-hidden>
              <img src={LOGO[data.id]} alt="" width={22} height={22} draggable={false} />
            </span>
            <div>
              <h2 className="bk-panel__title" style={{ margin: 0 }}>
                Setup {data.name}
              </h2>
              <p className="bk-muted bk-conn-setup__by" style={{ margin: '2px 0 0', fontSize: 12 }}>
                {data.id === 'beequeen' ? (
                  <>
                    by {data.vendor} · runs on
                    <img src="/admin/connector/claude.svg" alt="" width={12} height={12} draggable={false} />
                    Claude (Anthropic API)
                  </>
                ) : (
                  data.vendor
                )}
                {data.configured ? ' · Ready' : ' · No key yet'}
              </p>
            </div>
          </div>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <tr>
                <th scope="row">
                  <label htmlFor="conn-key">{data.apiKeyLabel}</label>
                </th>
                <td>
                  <input
                    id="conn-key"
                    className="regular-text"
                    type="password"
                    autoComplete="off"
                    placeholder={
                      data.apiKeyMasked
                        ? `Saved: ${data.apiKeyMasked} — enter a new key to replace`
                        : data.apiKeyPlaceholder
                    }
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                  />
                  <p className="description">
                    {data.keySource ? `${KEY_SOURCE[data.keySource]} ` : 'Stored on this site for Beekiri agents. '}
                    <a
                      href={data.id === 'beequeen' && data.serviceUrl ? `${data.serviceUrl}/dashboard` : data.docsUrl}
                      target="_blank"
                      rel="noreferrer"
                    >
                      {data.id === 'beequeen' ? 'Get a key from 996Agency' : 'Get an API key'}
                    </a>
                  </p>
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="conn-model">Default model</label>
                </th>
                <td>
                  <select
                    id="conn-model"
                    value={defaultModel}
                    onChange={(e) => setDefaultModel(e.target.value)}
                  >
                    {data.models.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.label}
                      </option>
                    ))}
                  </select>
                  <p className="description">
                    {data.id === 'beequeen'
                      ? 'The Claude model (by Anthropic) BeeQueen thinks with. Opus is the most capable; Sonnet and Haiku use fewer credits.'
                      : `Used when BeeQueen and other agents call ${data.name}.`}
                  </p>
                </td>
              </tr>
              {data.supportsEffort ? (
                <tr>
                  <th scope="row">
                    <label htmlFor="conn-effort">Effort</label>
                  </th>
                  <td>
                    <select
                      id="conn-effort"
                      value={effort}
                      onChange={(e) => setEffort(e.target.value as Effort)}
                    >
                      {EFFORTS.map((o) => (
                        <option key={o.id} value={o.id}>
                          {o.label}
                        </option>
                      ))}
                    </select>
                    <p className="description">
                      How hard Claude thinks before acting. Higher effort builds better pages but takes longer and
                      uses more tokens.
                    </p>
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
          <p className="submit">
            <button type="submit" className="button button-primary" disabled={busy}>
              {busy ? 'Saving…' : 'Save setup'}
            </button>
          </p>
        </div>
      </form>
      {data.id === 'beequeen' ? <BeeQueenAccount reloadKey={accountKey} /> : null}
    </div>
  );
}
