import { CONNECTOR_COMING_SOON } from '../lib/features';
import { ConnectorProviderPage } from './ConnectorProviderPage';
import { PlaceholderScreen } from './PlaceholderScreen';

/** Connector: BeeQueen only for now — setup, credits, packs and usage on one page. */
export function ConnectorPage() {
  if (CONNECTOR_COMING_SOON) {
    return (
      <PlaceholderScreen
        title="Connector"
        phase="Coming soon"
        note="BeeQueen, 996Agency’s Claude-powered site agent, is on its way. Connector opens here when it is ready."
      />
    );
  }
  return <ConnectorProviderPage id="beequeen" embedded />;
}
