import { useEffect, useRef, useState, type DragEvent, type PointerEvent as ReactPointerEvent } from 'react';
import { createPortal } from 'react-dom';
import { Link } from 'react-router-dom';
import { Plus, SquaresFour, X } from '@phosphor-icons/react';
import { api } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { useAdminHref } from '../lib/AdminEntryContext';
import {
  availableWidgets,
  formatBytes,
  formatRelative,
  humanAction,
  loadLayout,
  normalizeLayout,
  saveLayout,
  snapSpan,
} from './dashboard/layout';
import {
  DEFAULT_LAYOUT,
  WIDGET_META,
  type DashboardOverview,
  type DashboardRange,
  type LayoutItem,
  type WidgetId,
  type WidgetSpan,
} from './dashboard/types';
import './dashboard/dashboard.css';
import { ShopWidget } from './dashboard/ShopWidget';

function pad2(n: number) {
  return n < 10 ? `0${n}` : String(n);
}

/** Live local clock — ticks every second; day bar matches Storage card style. */
function ClockWidgetBody() {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const h = now.getHours();
  const m = now.getMinutes();
  const s = now.getSeconds();
  const daySec = h * 3600 + m * 60 + s;
  const dayPct = Math.min(100, (daySec / 86400) * 100);
  const dateLine = now.toLocaleDateString(undefined, {
    weekday: 'long',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
  const tz =
    Intl.DateTimeFormat().resolvedOptions().timeZone?.replace(/_/g, ' ') || 'Local';

  return (
    <>
      <p className="bk-dash__stat bk-dash__stat--live" aria-live="polite">
        <span className="bk-dash__live-hms">
          {pad2(h)}
          <span className="bk-dash__live-colon" aria-hidden>
            :
          </span>
          {pad2(m)}
          <span className="bk-dash__live-colon" aria-hidden>
            :
          </span>
          <span key={s} className="bk-dash__live-sec">
            {pad2(s)}
          </span>
        </span>
      </p>
      <p className="bk-dash__sub">{dateLine}</p>
      <div className="bk-dash__fill bk-dash__mini-grid">
        <div className="bk-dash__mini-card">
          <span className="bk-dash__mini-label">
            <i className="bk-dash__mini-dot" style={{ background: '#ff9508' }} aria-hidden />
            Day
          </span>
          <strong className="bk-dash__mini-value">{Math.round(dayPct)}%</strong>
          <div className="bk-dash__mini-bar" aria-hidden>
            <span
              className="bk-dash__bar-seg--live"
              style={{ width: `${dayPct}%`, background: '#ff9508' }}
            />
          </div>
        </div>
        <div className="bk-dash__mini-card">
          <span className="bk-dash__mini-label">
            <i className="bk-dash__mini-dot" style={{ background: '#006199' }} aria-hidden />
            Zone
          </span>
          <strong className="bk-dash__mini-value bk-dash__mini-value--sm">{tz}</strong>
        </div>
      </div>
    </>
  );
}

const RANGES: { value: DashboardRange; label: string }[] = [
  { value: 'today', label: 'Today' },
  { value: '7d', label: '7d' },
  { value: '30d', label: '30d' },
  { value: 'all', label: 'All' },
];

function StackedBar({
  segments,
  total,
}: {
  segments: { label: string; value: number; color: string }[];
  total: number;
}) {
  const safe = total > 0 ? total : 1;
  return (
    <div className="bk-dash__fill">
      <div className="bk-dash__bar" aria-hidden>
        {segments.map((s) =>
          s.value > 0 ? (
            <span
              key={s.label}
              className="bk-dash__bar-seg"
              style={{ width: `${(s.value / safe) * 100}%`, background: s.color }}
            />
          ) : null,
        )}
      </div>
      <ul className="bk-dash__legend">
        {segments.map((s) => (
          <li key={s.label}>
            <span className="bk-dash__legend-swatch" style={{ background: s.color }} />
            {s.label} <strong>{formatBytes(s.value)}</strong>
          </li>
        ))}
      </ul>
    </div>
  );
}

function columnPitch(grid: HTMLElement): number {
  const styles = getComputedStyle(grid);
  const gap = parseFloat(styles.columnGap || styles.gap || '10') || 10;
  const cols = 12;
  const colW = (grid.clientWidth - gap * (cols - 1)) / cols;
  return Math.max(1, colW + gap);
}

function WidgetChrome({
  id,
  span,
  editing,
  onResize,
  onRemove,
  children,
}: {
  id: WidgetId;
  span: WidgetSpan;
  editing: boolean;
  onResize: (span: WidgetSpan) => void;
  onRemove: () => void;
  children: React.ReactNode;
}) {
  const meta = WIDGET_META[id];
  const rootRef = useRef<HTMLElement>(null);
  const dragRef = useRef<{
    edge: 'left' | 'right';
    startX: number;
    startSpan: WidgetSpan;
    pitch: number;
  } | null>(null);
  const spanRef = useRef(span);
  spanRef.current = span;
  const onResizeRef = useRef(onResize);
  onResizeRef.current = onResize;

  function beginResize(edge: 'left' | 'right', e: ReactPointerEvent<HTMLElement>) {
    e.preventDefault();
    e.stopPropagation();
    const grid = rootRef.current?.closest('.bk-dash__grid');
    if (!(grid instanceof HTMLElement)) return;
    dragRef.current = {
      edge,
      startX: e.clientX,
      startSpan: spanRef.current,
      pitch: columnPitch(grid),
    };
    document.body.dataset.bkDashResize = '1';
    e.currentTarget.setPointerCapture(e.pointerId);
  }

  function onResizePointerMove(e: ReactPointerEvent<HTMLElement>) {
    const d = dragRef.current;
    if (!d) return;
    e.preventDefault();
    const dx = e.clientX - d.startX;
    const deltaCols = Math.round(dx / d.pitch);
    const next =
      d.edge === 'right' ? snapSpan(d.startSpan + deltaCols) : snapSpan(d.startSpan - deltaCols);
    if (next !== spanRef.current) onResizeRef.current(next);
  }

  function endResize(e: ReactPointerEvent<HTMLElement>) {
    if (!dragRef.current) return;
    dragRef.current = null;
    delete document.body.dataset.bkDashResize;
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      /* already released */
    }
  }

  return (
    <section ref={rootRef} className="bk-dash__widget" style={{ ['--tint' as string]: meta.tint }}>
      <div className="bk-dash__widget-head">
        <h3 className="bk-dash__widget-title">
          <span className="bk-dash__dot" aria-hidden />
          {meta.title}
        </h3>
        {editing ? (
          <button
            type="button"
            className="bk-dash__remove"
            aria-label={`Remove ${meta.title}`}
            title="Remove block"
            draggable={false}
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => {
              e.stopPropagation();
              onRemove();
            }}
          >
            <X size={12} weight="bold" aria-hidden />
          </button>
        ) : null}
      </div>
      {children}
      {editing ? (
        <>
          <div
            role="separator"
            aria-orientation="vertical"
            aria-label="Drag left edge to resize"
            title="Drag to resize"
            className="bk-dash__resize bk-dash__resize--left"
            onPointerDown={(e) => beginResize('left', e)}
            onPointerMove={onResizePointerMove}
            onPointerUp={endResize}
            onPointerCancel={endResize}
            onDragStart={(e) => e.preventDefault()}
          />
          <div
            role="separator"
            aria-orientation="vertical"
            aria-label="Drag right edge to resize"
            title="Drag to resize"
            className="bk-dash__resize bk-dash__resize--right"
            onPointerDown={(e) => beginResize('right', e)}
            onPointerMove={onResizePointerMove}
            onPointerUp={endResize}
            onPointerCancel={endResize}
            onDragStart={(e) => e.preventDefault()}
          />
        </>
      ) : null}
    </section>
  );
}

function renderWidget(
  id: WidgetId,
  data: DashboardOverview | null,
  editing: boolean,
  span: WidgetSpan,
  onResize: (span: WidgetSpan) => void,
  onRemove: () => void,
  opts: {
    canManageFields: boolean;
    canListUsers: boolean;
    profilePath: string | null;
    href: (sub?: string) => string;
  },
) {
  const { canManageFields, canListUsers, profilePath, href } = opts;
  const d = data;
  const chrome = {
    id,
    span,
    editing,
    onResize,
    onRemove,
  };
  switch (id) {
    case 'storage': {
      const s = d?.storage;
      return (
        <WidgetChrome {...chrome}>
          <p className="bk-dash__stat">{s?.totalLabel ?? '—'}</p>
          <p className="bk-dash__sub">
            used · {s?.dialect === 'sqlite' ? 'SQLite' : 'Postgres'} · self-hosted
          </p>
          <StackedBar
            total={s?.totalBytes ?? 0}
            segments={[
              { label: 'Images', value: s?.imageBytes ?? 0, color: '#e8a07a' },
              { label: 'Videos', value: s?.videoBytes ?? 0, color: '#7c6af0' },
              { label: 'Documents', value: s?.documentBytes ?? 0, color: '#ff6b9d' },
              { label: 'Database', value: s?.databaseBytes ?? 0, color: '#006199' },
            ]}
          />
        </WidgetChrome>
      );
    }
    case 'clock':
      return (
        <WidgetChrome {...chrome}>
          <ClockWidgetBody />
        </WidgetChrome>
      );
    case 'pages': {
      const p = d?.pages;
      return (
        <WidgetChrome {...chrome}>
          <p className="bk-dash__stat">{p?.published ?? 0}</p>
          <p className="bk-dash__sub">
            Published
            {(p?.publishedThisWeek ?? 0) > 0 ? ` +${p!.publishedThisWeek} this week` : null}
          </p>
          <p className="bk-dash__meta">
            {p?.drafts ?? 0} drafts · {p?.scheduled ?? 0} scheduled
          </p>
        </WidgetChrome>
      );
    }
    case 'posts': {
      const p = d?.posts;
      return (
        <WidgetChrome {...chrome}>
          <p className="bk-dash__stat">{p?.published ?? p?.total ?? 0}</p>
          <p className="bk-dash__sub">
            Published
            {(p?.publishedThisWeek ?? 0) > 0 ? ` +${p!.publishedThisWeek} this week` : null}
          </p>
          <p className="bk-dash__meta">
            {p?.drafts ?? 0} drafts · {p?.scheduled ?? 0} scheduled
          </p>
        </WidgetChrome>
      );
    }
    case 'media': {
      const m = d?.media;
      const tiles = m?.previews?.slice(0, 8) ?? [];
      while (tiles.length < 8) {
        tiles.push({ id: `empty-${tiles.length}`, url: '', mimeType: '' });
      }
      return (
        <WidgetChrome {...chrome}>
          <p className="bk-dash__stat">{m?.files ?? 0}</p>
          <p className="bk-dash__sub">files · {m?.bytesLabel ?? '0 B'}</p>
          <div className="bk-dash__fill">
            <div className="bk-dash__media-grid">
              {tiles.map((t) =>
                t.url ? (
                  <img key={t.id} src={t.url} alt="" loading="lazy" />
                ) : (
                  <span key={t.id} />
                ),
              )}
            </div>
          </div>
        </WidgetChrome>
      );
    }
    case 'status': {
      const s = d?.status;
      return (
        <WidgetChrome {...chrome}>
          <ul className="bk-dash__status-list">
            <li>
              <span>
                <i className="bk-dash__pulse is-ok" />
                Site
              </span>
              <em>Live</em>
            </li>
            <li>
              <span>
                <i className="bk-dash__pulse is-ok" />
                Publish
              </span>
              <em>{formatRelative(s?.lastPublishAt)}</em>
            </li>
            <li>
              <span>
                <i className="bk-dash__pulse is-ok" />
                Updated
              </span>
              <em>{formatRelative(s?.lastUpdateAt)}</em>
            </li>
            <li>
              <span>
                <i className={`bk-dash__pulse ${(s?.fieldGroups ?? 0) > 0 ? 'is-ok' : 'is-warn'}`} />
                Fields
              </span>
              <em>{s?.fieldGroups ?? 0} groups</em>
            </li>
          </ul>
        </WidgetChrome>
      );
    }
    case 'activity': {
      const rows = d?.activity ?? [];
      return (
        <WidgetChrome {...chrome}>
          {rows.length === 0 ? (
            <p className="bk-dash__empty">No activity in this range.</p>
          ) : (
            <ul className="bk-dash__feed">
              {rows.map((row) => (
                <li key={row.id}>
                  <span className="bk-dash__feed-body">
                    <em>{row.actor}</em> · {humanAction(row.action)}
                  </span>
                  <span className="bk-dash__feed-time">{formatRelative(row.at)}</span>
                </li>
              ))}
            </ul>
          )}
        </WidgetChrome>
      );
    }
    case 'publish': {
      const rows = d?.publishLineup ?? [];
      return (
        <WidgetChrome {...chrome}>
          {rows.length === 0 ? (
            <p className="bk-dash__empty">No drafts waiting to publish.</p>
          ) : (
            <ul className="bk-dash__feed bk-dash__lineup">
              {rows.map((row) => (
                <li key={row.id}>
                  <Link
                    to={
                      row.type === 'post'
                        ? href(`posts/${row.id}`)
                        : href(`pages/${row.id}`)
                    }
                  >
                    <span className="bk-dash__feed-body">{row.title}</span>
                  </Link>
                  <span className="bk-dash__feed-time">{formatRelative(row.updatedAt)}</span>
                </li>
              ))}
            </ul>
          )}
        </WidgetChrome>
      );
    }
    case 'fields':
      return (
        <WidgetChrome {...chrome}>
          <p className="bk-dash__stat">{d?.fieldGroups ?? 0}</p>
          <p className="bk-dash__sub">Backend field groups</p>
          {canManageFields ? (
            <p className="bk-dash__meta">
              <Link to={href('fields')} className="button-link">
                Manage fields
              </Link>
            </p>
          ) : null}
        </WidgetChrome>
      );
    case 'shop':
      return (
        <WidgetChrome {...chrome}>
          <ShopWidget href={href} />
        </WidgetChrome>
      );
    case 'users':
      return (
        <WidgetChrome {...chrome}>
          <p className="bk-dash__stat">{d?.users ?? 0}</p>
          <p className="bk-dash__sub">People with admin access</p>
          {canListUsers ? (
            <p className="bk-dash__meta">
              <Link to={href('users')} className="button-link">
                Manage users
              </Link>
            </p>
          ) : profilePath ? (
            <p className="bk-dash__meta">
              <Link to={profilePath} className="button-link">
                Edit your profile
              </Link>
            </p>
          ) : null}
        </WidgetChrome>
      );
    default:
      return null;
  }
}

export function Dashboard() {
  const auth = useAuth();
  const href = useAdminHref();
  const userId = auth.user?.id ?? null;
  const canCustomize = auth.user?.capabilities.includes('customize_dashboard') ?? false;
  const canManageFields = auth.user?.capabilities.includes('manage_fields') ?? false;
  const canListUsers = auth.user?.capabilities.includes('list_users') ?? false;
  const [range, setRange] = useState<DashboardRange>('today');
  const [data, setData] = useState<DashboardOverview | null>(null);
  const [layout, setLayout] = useState<LayoutItem[]>(() => loadLayout(userId));
  const [editing, setEditing] = useState(false);
  const [libraryOpen, setLibraryOpen] = useState(false);
  const [dragId, setDragId] = useState<WidgetId | null>(null);

  useEffect(() => {
    if (!canCustomize && editing) {
      setEditing(false);
      setLibraryOpen(false);
    }
  }, [canCustomize, editing]);

  // Load this user's saved layout (server first, then local), keyed per account.
  useEffect(() => {
    let cancelled = false;
    setLayout(loadLayout(userId));
    if (!userId) return;
    api<{ layout: LayoutItem[] | null }>('/api/site/dashboard-layout')
      .then((res) => {
        if (cancelled) return;
        const fromServer = normalizeLayout(res.layout);
        if (fromServer) {
          setLayout(fromServer);
          saveLayout(fromServer, userId);
        }
      })
      .catch(() => {
        /* keep local / default */
      });
    return () => {
      cancelled = true;
    };
  }, [userId]);

  useEffect(() => {
    let cancelled = false;
    api<DashboardOverview>(`/api/site/dashboard?range=${range}`)
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch(() => {
        if (!cancelled) setData(null);
      });
    return () => {
      cancelled = true;
    };
  }, [range]);

  function updateLayout(next: LayoutItem[]) {
    setLayout(next);
    saveLayout(next, userId);
    if (userId) {
      void api('/api/site/dashboard-layout', {
        method: 'PUT',
        json: { layout: next },
      }).catch(() => {
        /* local copy already saved */
      });
    }
  }

  function resizeWidget(id: WidgetId, span: WidgetSpan) {
    updateLayout(layout.map((i) => (i.id === id ? { ...i, span } : i)));
  }

  /** Takes a block off the Overview; it goes back to Add block. */
  function removeWidget(id: WidgetId) {
    updateLayout(layout.filter((i) => i.id !== id));
  }

  function addWidget(id: WidgetId) {
    if (layout.some((i) => i.id === id)) return;
    updateLayout([...layout, { id, span: WIDGET_META[id].defaultSpan }]);
  }

  function onDragStart(id: WidgetId, e: DragEvent) {
    if (!editing) {
      e.preventDefault();
      return;
    }
    setDragId(id);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', id);
  }

  function onDrop(targetId: WidgetId, e: DragEvent) {
    e.preventDefault();
    const source = (e.dataTransfer.getData('text/plain') || dragId) as WidgetId | null;
    setDragId(null);
    if (!source || source === targetId) return;
    const from = layout.findIndex((i) => i.id === source);
    const to = layout.findIndex((i) => i.id === targetId);
    if (from < 0 || to < 0) return;
    const next = [...layout];
    const [item] = next.splice(from, 1);
    next.splice(to, 0, item);
    updateLayout(next);
  }

  const unused = availableWidgets(layout);
  const countLabel = String(layout.length).padStart(2, '0');

  return (
    <div className={`bk-dash${editing ? ' is-editing' : ''}`}>
      <header className="bk-dash__header">
        <div className="bk-dash__title-row">
          <h1>Overview</h1>
          <span className="bk-dash__count">{countLabel} blocks</span>
        </div>
        <div className="bk-dash__actions">
          <div className="bk-dash__ranges" role="tablist" aria-label="Time range">
            {RANGES.map((r) => (
              <button
                key={r.value}
                type="button"
                role="tab"
                aria-selected={range === r.value}
                className={range === r.value ? 'is-active' : undefined}
                onClick={() => setRange(r.value)}
              >
                {r.label}
              </button>
            ))}
          </div>
          {canCustomize ? (
            <>
              <button
                type="button"
                className={`bk-dash__btn${editing ? ' is-active' : ''}`}
                onClick={() => {
                  setEditing((v) => !v);
                  if (editing) setLibraryOpen(false);
                }}
              >
                <SquaresFour size={13} weight="bold" aria-hidden />
                {editing ? 'Done' : 'Customize'}
              </button>
              <button
                type="button"
                className="bk-dash__btn bk-dash__btn--ghost"
                onClick={() => {
                  setLibraryOpen(true);
                  setEditing(true);
                }}
              >
                <Plus size={13} weight="bold" aria-hidden />
                Add block
              </button>
            </>
          ) : null}
        </div>
      </header>

      <div className="bk-dash__grid">
        {layout.map((item) => (
          <div
            key={item.id}
            className={`bk-dash__cell${dragId === item.id ? ' is-dragging' : ''}`}
            data-span={item.span}
            draggable={editing}
            onDragStart={(e) => {
              if (document.body.dataset.bkDashResize) {
                e.preventDefault();
                return;
              }
              onDragStart(item.id, e);
            }}
            onDragOver={(e) => {
              if (editing) e.preventDefault();
            }}
            onDrop={(e) => onDrop(item.id, e)}
            onDragEnd={() => setDragId(null)}
          >
            {renderWidget(
              item.id,
              data,
              editing,
              item.span,
              (span) => resizeWidget(item.id, span),
              () => removeWidget(item.id),
              {
                canManageFields,
                canListUsers,
                profilePath: userId ? href(`users/${userId}`) : null,
                href,
              },
            )}
          </div>
        ))}
      </div>

      {typeof document !== 'undefined' && libraryOpen
        ? createPortal(
            <div className="bk-dash__library" role="dialog" aria-label="Block library">
              <div className="bk-dash__library-head">
                <h2>Add block</h2>
                <button
                  type="button"
                  className="bk-dash__btn bk-dash__btn--ghost"
                  onClick={() => setLibraryOpen(false)}
                >
                  <X size={14} weight="bold" aria-hidden /> Close
                </button>
              </div>
              <div className="bk-dash__library-body">
                {unused.length === 0 ? (
                  <p className="bk-dash__library-empty">All blocks are already on your overview.</p>
                ) : (
                  unused.map((id) => (
                    <button
                      key={id}
                      type="button"
                      className="bk-dash__library-item"
                      style={{ ['--lib-tint' as string]: WIDGET_META[id].tint }}
                      onClick={() => {
                        addWidget(id);
                        setLibraryOpen(false);
                      }}
                    >
                      <span className="bk-dash__library-item-top">
                        <i className="bk-dash__library-dot" aria-hidden />
                        <strong>{WIDGET_META[id].title}</strong>
                      </span>
                      <span className="bk-dash__library-item-desc">{WIDGET_META[id].description}</span>
                    </button>
                  ))
                )}
                <button
                  type="button"
                  className="bk-dash__library-item is-reset"
                  onClick={() => {
                    updateLayout([...DEFAULT_LAYOUT]);
                    setLibraryOpen(false);
                  }}
                >
                  <span className="bk-dash__library-item-top">
                    <i className="bk-dash__library-dot" aria-hidden />
                    <strong>Reset layout</strong>
                  </span>
                  <span className="bk-dash__library-item-desc">
                    Restore the default Overview blocks
                  </span>
                </button>
              </div>
            </div>,
            document.body,
          )
        : null}
    </div>
  );
}
