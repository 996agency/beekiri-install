import { ChangeEvent, DragEvent, useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { CaretLeft, CaretRight, CheckCircle, X } from '@phosphor-icons/react';
import { api, apiUpload, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { confirmDialog } from '../components/ConfirmDialog';
import { useThemeSwitch } from '../components/ThemeSwitchOverlay';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';

type ThemeItem = {
  slug: string;
  name: string;
  version: string;
  description: string;
  author: string;
  tags: string[];
  parent?: string;
  parentName?: string;
  active: boolean;
  builtin: boolean;
  deletable: boolean;
  screenshotUrl: string;
};

type ThemesResponse = {
  themes: ThemeItem[];
  active: string;
  installed?: string;
};

import { SITE_URL as LIVE_SITE } from '../config';
import { ErrorNotice } from '../components/ErrorNotice';
import './theme-modal.css';

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

export function AppearancePage() {
  const auth = useAuth();
  const canEdit = auth.user?.capabilities.includes('edit_theme_options') ?? false;
  const fileRef = useRef<HTMLInputElement>(null);
  const [themes, setThemes] = useState<ThemeItem[]>([]);
  const [activeSlug, setActiveSlug] = useState('beekiri-child');
  const [selectedSlug, setSelectedSlug] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const selected = selectedSlug
    ? themes.find((t) => t.slug === selectedSlug) ?? null
    : null;

  const applyList = (data: ThemesResponse) => {
    // The active theme always comes first.
    setThemes([...data.themes].sort((a, b) => Number(b.active) - Number(a.active)));
    setActiveSlug(data.active);
    if (selectedSlug && !data.themes.some((t) => t.slug === selectedSlug)) {
      setSelectedSlug(null);
    }
  };

  const load = useCallback(async () => {
    setError('');
    try {
      const data = await api<ThemesResponse>('/api/themes');
      applyList(data);
    } catch (e) {
      setError(formatError(e));
    } finally {
      setLoading(false);
    }
  }, [selectedSlug]);

  useEffect(() => {
    void load();
  }, []);

  /** Previous / next theme in the details window (wraps around). */
  const step = useCallback(
    (dir: 1 | -1) => {
      if (!selectedSlug || themes.length < 2) return;
      const i = themes.findIndex((t) => t.slug === selectedSlug);
      setSelectedSlug(themes[(i + dir + themes.length) % themes.length].slug);
    },
    [selectedSlug, themes],
  );

  useEffect(() => {
    if (!selectedSlug) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelectedSlug(null);
      else if (e.key === 'ArrowLeft') step(-1);
      else if (e.key === 'ArrowRight') step(1);
    };
    document.addEventListener('keydown', onKey);
    // The page behind stays still while the window is open.
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [selectedSlug, step]);

  const { overlay: switchOverlay, run: runSwitch } = useThemeSwitch(LIVE_SITE);

  const activate = async (slug: string) => {
    if (!canEdit || busy || slug === activeSlug) return;
    const name = themes.find((t) => t.slug === slug)?.name ?? slug;
    const ok = await confirmDialog({
      title: `Activate “${name}”?`,
      message: 'Your site switches to this theme together with its own pages, menu, header and footer. The pages you have now are kept and come back when you switch back.',
      confirmLabel: 'Activate',
    });
    if (!ok) return;
    setSelectedSlug(null);
    setBusy(true);
    setError('');
    setNotice('');
    await runSwitch(name, async () => {
      try {
        const data = await api<ThemesResponse & { pagesAdded?: number }>('/api/themes/activate', {
          method: 'POST',
          json: { slug },
        });
        applyList(data);
        return data.pagesAdded
          ? `Your site now shows ${name} with its ${data.pagesAdded} ready-made pages, menu, header and footer.`
          : `Your site now shows ${name} with its own pages, menu, header and footer.`;
      } catch (e) {
        throw new Error(formatError(e));
      }
    });
    setBusy(false);
  };

  const deactivate = async (slug: string) => {
    if (!canEdit || busy) return;
    const name = themes.find((t) => t.slug === slug)?.name ?? slug;
    const ok = await confirmDialog({
      title: `Deactivate “${name}”?`,
      message: 'Your site goes back to Beekiri Child and its own pages. This theme’s pages are kept and come back when you activate it again.',
      confirmLabel: 'Deactivate',
    });
    if (!ok) return;
    setSelectedSlug(null);
    setBusy(true);
    setError('');
    setNotice('');
    await runSwitch('Beekiri Child', async () => {
      try {
        const data = await api<ThemesResponse>('/api/themes/deactivate', {
          method: 'POST',
          json: { slug },
        });
        applyList(data);
        return `Your site now shows Beekiri Child with its own pages. ${name}’s pages are saved for later.`;
      } catch (e) {
        throw new Error(formatError(e));
      }
    });
    setBusy(false);
  };

  const remove = async (theme: ThemeItem) => {
    if (!canEdit || busy || !theme.deletable) return;
    const ok = await confirmDialog({
      title: 'Delete theme',
      message: `Delete “${theme.name}”? This removes the theme files. You can’t undo this.`,
      confirmLabel: 'Delete',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const data = await api<ThemesResponse>(`/api/themes/${encodeURIComponent(theme.slug)}`, {
        method: 'DELETE',
      });
      applyList(data);
      setSelectedSlug(null);
      setNotice(`“${theme.name}” was deleted.`);
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const uploadFile = async (file: File | null | undefined) => {
    if (!canEdit || busy || !file) return;
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const form = new FormData();
      form.append('file', file);
      const data = await apiUpload<ThemesResponse>('/api/themes/upload', form);
      applyList(data);
      const installed = data.themes.find((t) => t.slug === data.installed);
      setNotice(
        installed
          ? `“${installed.name}” uploaded. Activate it when you’re ready.`
          : 'Theme uploaded.',
      );
      if (data.installed) setSelectedSlug(data.installed);
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const onPick = (e: ChangeEvent<HTMLInputElement>) => {
    void uploadFile(e.target.files?.[0]);
  };

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files?.[0];
    void uploadFile(file);
  };

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Themes"
        actions={
          <>
            {canEdit ? (
              <button
                type="button"
                className="button button-primary"
                disabled={busy}
                onClick={() => fileRef.current?.click()}
              >
                {busy ? 'Working…' : 'Upload theme'}
              </button>
            ) : null}
            <a className="button" href={LIVE_SITE} target="_blank" rel="noreferrer">
              View site
            </a>
            <input
              ref={fileRef}
              type="file"
              accept=".zip,application/zip"
              hidden
              onChange={onPick}
            />
          </>
        }
      />
      <p className="bk-muted">
        Beekiri is the official parent theme. Activate <strong>Beekiri Child</strong> and edit files
        in <code>apps/web/themes/beekiri-child</code> so core updates do not overwrite your work.
        Click a theme for details, or upload a ZIP with a <code>theme.json</code>.
      </p>

      {error ? <ErrorNotice message={error} onDismiss={() => setError('')} /> : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice('')} />
      ) : null}

      {!canEdit ? (
        <div className="beekiri-notice is-info">
          <p>You need the edit_theme_options capability to manage themes.</p>
        </div>
      ) : (
        <div
          className={`bk-media-drop${dragging ? ' is-dragging' : ''}`}
          onDragEnter={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragOver={(e) => e.preventDefault()}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
        >
          <p>
            Drop a theme <strong>.zip</strong> here, or use <strong>Upload theme</strong>. Packages
            need a <code>theme.json</code> (name, slug, version). Built-in themes can’t be deleted.
          </p>
        </div>
      )}

      {loading ? (
        <p className="bk-muted">Loading themes…</p>
      ) : (
        <div className="bk-themes">
          {themes.map((theme) => (
            <button
              key={theme.slug}
              type="button"
              className="bk-theme-card"
              onClick={() => setSelectedSlug(theme.slug)}
            >
              <div className="bk-theme-card__shot">
                <img
                  src={theme.screenshotUrl}
                  alt=""
                  width={600}
                  height={450}
                  loading="lazy"
                />
              </div>
              <div className="bk-theme-card__body">
                <div className="bk-theme-card__meta">
                  <span className="bk-theme-card__name">
                    {theme.name}
                    {theme.active ? (
                      <span className="bk-theme-card__status">Active</span>
                    ) : null}
                    {theme.parent ? (
                      <span className="bk-theme-card__status is-muted">Child</span>
                    ) : theme.builtin ? (
                      <span className="bk-theme-card__status is-muted">Built-in</span>
                    ) : null}
                  </span>
                  <span className="bk-theme-card__by">
                    v{theme.version}
                    {theme.author ? ` · ${theme.author}` : ''}
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}

      {selected
        ? createPortal(
            <div
              className="bk-theme-modal"
              role="dialog"
              aria-modal="true"
              aria-labelledby="bk-theme-modal-title"
              onMouseDown={(e) => {
                if (e.target === e.currentTarget) setSelectedSlug(null);
              }}
            >
              <div className="bk-theme-modal__panel">
                <header className="bk-theme-modal__head">
                  <h2 id="bk-theme-modal-title">Theme details</h2>
                  <div className="bk-theme-modal__nav">
                    <button
                      type="button"
                      aria-label="Previous theme"
                      disabled={themes.length < 2}
                      onClick={() => step(-1)}
                    >
                      <CaretLeft size={16} aria-hidden />
                    </button>
                    <button
                      type="button"
                      aria-label="Next theme"
                      disabled={themes.length < 2}
                      onClick={() => step(1)}
                    >
                      <CaretRight size={16} aria-hidden />
                    </button>
                    <button type="button" aria-label="Close" onClick={() => setSelectedSlug(null)}>
                      <X size={16} aria-hidden />
                    </button>
                  </div>
                </header>

                <div className="bk-theme-modal__body">
                  <div className="bk-theme-modal__shot">
                    <div className="bk-theme-modal__frame">
                      <img src={selected.screenshotUrl} alt={`${selected.name} screenshot`} />
                    </div>
                  </div>

                  <div className="bk-theme-modal__info">
                    <h3 className="bk-theme-modal__name">
                      {selected.name}
                      {selected.active ? <span className="bk-theme-card__status">Active</span> : null}
                      {selected.parent ? (
                        <span className="bk-theme-card__status is-muted">Child</span>
                      ) : selected.builtin ? (
                        <span className="bk-theme-card__status is-muted">Built-in</span>
                      ) : null}
                    </h3>
                    <p className="bk-theme-modal__by">
                      Version {selected.version}
                      {selected.author ? (
                        <>
                          {' '}
                          · By <strong>{selected.author}</strong>
                        </>
                      ) : null}
                    </p>

                    {selected.parentName ? (
                      <p className="bk-theme-modal__callout">
                        Child theme of <strong>{selected.parentName}</strong>. Files you add here override the
                        parent; everything else is inherited.
                      </p>
                    ) : null}
                    {selected.description ? <p className="bk-theme-modal__desc">{selected.description}</p> : null}

                    {selected.tags.length ? (
                      <ul className="bk-theme-card__tags">
                        {selected.tags.map((tag) => (
                          <li key={tag}>{tag}</li>
                        ))}
                      </ul>
                    ) : null}

                    <dl className="bk-theme-modal__meta">
                      <div>
                        <dt>Slug</dt>
                        <dd>
                          <code>{selected.slug}</code>
                        </dd>
                      </div>
                      <div>
                        <dt>Type</dt>
                        <dd>{selected.builtin ? 'Built-in' : 'Uploaded'}</dd>
                      </div>
                      <div>
                        <dt>Status</dt>
                        <dd>{selected.active ? 'Active' : 'Inactive'}</dd>
                      </div>
                      {selected.parentName ? (
                        <div>
                          <dt>Parent</dt>
                          <dd>{selected.parentName}</dd>
                        </div>
                      ) : null}
                    </dl>
                  </div>
                </div>

                <footer className="bk-theme-modal__foot">
                  <div>
                    {canEdit && selected.deletable ? (
                      <button
                        type="button"
                        className="bk-theme-modal__delete"
                        disabled={busy}
                        onClick={() => void remove(selected)}
                      >
                        Delete theme
                      </button>
                    ) : null}
                  </div>
                  <div className="bk-theme-modal__actions">
                    <a className="button" href={LIVE_SITE} target="_blank" rel="noreferrer">
                      View site
                    </a>
                    {canEdit ? (
                      selected.active ? (
                        selected.slug === 'beekiri-child' ? (
                          <span className="bk-theme-modal__current">
                            <CheckCircle size={16} weight="fill" aria-hidden /> Active theme
                          </span>
                        ) : (
                          <button
                            type="button"
                            className="button"
                            disabled={busy}
                            onClick={() => void deactivate(selected.slug)}
                          >
                            Deactivate
                          </button>
                        )
                      ) : (
                        <button
                          type="button"
                          className="button button-primary"
                          disabled={busy}
                          onClick={() => void activate(selected.slug)}
                        >
                          {busy ? 'Activating…' : 'Activate'}
                        </button>
                      )
                    ) : null}
                  </div>
                </footer>
              </div>
            </div>,
            document.body,
          )
        : null}
      {switchOverlay}
    </div>
  );
}
