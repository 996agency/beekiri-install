import { ReactNode, useEffect } from 'react';
import { Link } from 'react-router-dom';
import '../styles/wp/install.css';
import './login-auth.css';
import { BrandMark } from '../components/BrandMark';
import { useAdminEntry } from '../lib/AdminEntryContext';

import { SITE_URL as SITE } from '../config';

type Props = {
  title: string;
  subtitle: string;
  children: ReactNode;
  brandTo?: string;
  /** Browser tab title; defaults from `title`. */
  documentTitle?: string;
};

const PROOF = [
  { initials: 'BK', label: 'Beekiri' },
  { initials: 'Ed', label: 'Editors' },
  { initials: 'Pub', label: 'Publishers' },
];

/** Split auth card — Sign-in-6 layout, Beekiri brand (login / forgot / reset). */
export function AuthShell({
  title,
  subtitle,
  children,
  brandTo,
  documentTitle,
}: Props) {
  const entry = useAdminEntry();
  const brandHref = brandTo ?? entry.path;
  useEffect(() => {
    const prev = document.title;
    document.title = documentTitle ?? `${title} — Beekiri CMS`;
    return () => {
      document.title = prev;
    };
  }, [documentTitle, title]);

  return (
    <div className="bk-auth">
      <div className="bk-auth__wrap">
        <div className="bk-auth__card">
          <aside className="bk-auth__visual" aria-hidden="true">
            <div className="bk-auth__visual-glow" />

            <div className="bk-auth__visual-brand">
              <BrandMark variant="logo" tone="white" size={26} title="" />
            </div>

            <div className="bk-auth__visual-copy">
              <h1 className="bk-auth__visual-title">The Future of Web Creation.</h1>
              <p className="bk-auth__visual-tagline">Where Ideas Take Flight.</p>
            </div>

            <div className="bk-auth__proof">
              <div className="bk-auth__proof-avatars">
                {PROOF.map((p) => (
                  <span key={p.initials} className="bk-auth__proof-avatar" title={p.label}>
                    {p.initials}
                  </span>
                ))}
              </div>
              <span className="bk-auth__proof-text">Beekiri CMS — publish with clarity</span>
            </div>
          </aside>

          <main className="bk-auth__panel">
            <div className="bk-auth__panel-inner">
              <Link className="bk-auth__brand bk-auth__brand--mobile" to={brandHref} title="Beekiri">
                <BrandMark variant="logo" size={26} />
              </Link>

              <div className="bk-auth__heading">
                <h2 className="bk-auth__title">{title}</h2>
                <p className="bk-auth__subtitle">{subtitle}</p>
              </div>

              {children}

              <p className="bk-auth__footer">
                <a href={SITE}>← Back to site</a>
              </p>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
