import { useEffect, useState, type ReactNode } from 'react';
import { Link, useLocation, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { ArrowSquareOut, CaretLeft, CaretRight, Check, Copy } from '@phosphor-icons/react';
import { api, apiUrl } from '../../api/client';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { useAuth } from '../../auth/AuthContext';
import { useAdminHref } from '../../lib/AdminEntryContext';
import { SourceIcon } from './SourceIcon';
import {
  CLICK_ID_NAMES,
  channelTone,
  DEVICE_LABEL,
  countryName,
  duration,
  flagEmoji,
  formatDate,
  formsError,
  isFileList,
  type Attribution,
  type EntryDetail,
  type EntryStatus,
  type HubspotSyncState,
  type IntegrationsInfo,
} from './api';
import './forms.css';

function bytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

const STATUS_LABEL: Record<EntryStatus, string> = { unread: 'Unread', read: 'Read', spam: 'Spam', trash: 'Trash' };

/** Label/value row; hidden when the value is empty so panels stay short. */
function Info({ label, children, wide }: { label: string; children: ReactNode; wide?: boolean }) {
  if (children === null || children === undefined || children === '' || children === false) return null;
  return (
    <div className={`bk-fm-info${wide ? ' is-wide' : ''}`}>
      <dt>{label}</dt>
      <dd>{children}</dd>
    </div>
  );
}

const TRACKING_KEYS = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'utm_id', 'gclid', 'gbraid', 'wbraid', 'dclid', 'msclkid', 'fbclid', 'li_fat_id', 'ttclid', 'twclid', 'epik', 'sccid'];
const PARAM_LABEL: Record<string, string> = {
  utm_source: 'Source',
  utm_medium: 'Medium',
  utm_campaign: 'Campaign',
  utm_term: 'Keyword',
  utm_content: 'Ad content',
  utm_id: 'Campaign ID',
};

/** Path + tracking parameters of the landing URL, and a full link to it. */
function landingParts(landingPage: string, origin: string) {
  try {
    const url = new URL(landingPage, origin);
    const params = TRACKING_KEYS.filter((k) => url.searchParams.has(k)).map((k) => ({ key: k, value: url.searchParams.get(k) ?? '' }));
    const others = [...url.searchParams.keys()].filter((k) => !TRACKING_KEYS.includes(k));
    return { href: url.toString(), path: url.pathname, params, others };
  } catch {
    return { href: '', path: landingPage, params: [] as { key: string; value: string }[], others: [] as string[] };
  }
}

function CopyButton({ text, label }: { text: string; label: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      className="bk-fm-iconbtn"
      title={done ? 'Copied' : label}
      aria-label={label}
      onClick={() => {
        void navigator.clipboard?.writeText(text).then(() => {
          setDone(true);
          window.setTimeout(() => setDone(false), 1400);
        });
      }}
    >
      {done ? <Check size={14} aria-hidden /> : <Copy size={14} aria-hidden />}
    </button>
  );
}

function SourceRows({ a, origin, sentAt }: { a: Attribution; origin: string; sentAt?: string }) {
  const landing = a.landingPage ? landingParts(a.landingPage, origin) : null;
  const before = a.at && sentAt ? duration(Math.max(0, Math.round((Date.parse(sentAt) - Date.parse(a.at)) / 1000))) : '';
  return (
    <div className="bk-fm-srcdetail">
      <div className="bk-fm-srchead">
        <SourceIcon channel={a.channel} source={a.source} size={44} />
        <div className="bk-fm-srchead__text">
          <span className="bk-fm-srchead__name">{a.source && a.source !== a.channel ? a.source : a.channel}</span>
          <span className="bk-fm-srchead__sub">
            <span className={`bk-fm-chan is-${channelTone(a.channel)}`}>{a.channel}</span>
            {a.at ? <span>Arrived {formatDate(a.at)}{before ? ` · ${before} before sending` : ''}</span> : null}
          </span>
        </div>
      </div>

      {a.campaign ? (
        <div className="bk-fm-campaign">
          <span className="bk-fm-campaign__label">Campaign</span>
          <span className="bk-fm-campaign__value">{a.campaign}</span>
        </div>
      ) : null}

      <dl className="bk-fm-infolist">
        <Info label="Medium">{a.medium}</Info>
        <Info label="Keyword">{a.term}</Info>
        <Info label="Ad content">{a.content}</Info>
        <Info label="Ad click">{a.clickId ? CLICK_ID_NAMES[a.clickId] ?? a.clickId : ''}</Info>
      </dl>

      {landing ? (
        <div className="bk-fm-srcblock">
          <span className="bk-fm-srcblock__label">Landing page</span>
          <div className="bk-fm-linkrow">
            {landing.href ? (
              <a href={landing.href} target="_blank" rel="noreferrer noopener" className="bk-fm-linkrow__link" title={landing.href}>
                <span className="bk-fm-linkrow__path">{landing.path}</span>
                {landing.params.length || landing.others.length ? <span className="bk-fm-linkrow__query">?{landing.params.length + landing.others.length} parameters</span> : null}
                <ArrowSquareOut size={13} aria-hidden />
              </a>
            ) : (
              <span className="bk-fm-linkrow__path">{landing.path}</span>
            )}
            {landing.href ? <CopyButton text={landing.href} label="Copy full link" /> : null}
          </div>
        </div>
      ) : null}

      {a.referrer ? (
        <div className="bk-fm-srcblock">
          <span className="bk-fm-srcblock__label">Came from</span>
          <div className="bk-fm-linkrow">
            <a href={a.referrer} target="_blank" rel="noreferrer noopener" className="bk-fm-linkrow__link" title={a.referrer}>
              <span className="bk-fm-linkrow__path">{a.referrerHost || a.referrer}</span>
              <ArrowSquareOut size={13} aria-hidden />
            </a>
          </div>
        </div>
      ) : null}

      {landing && landing.params.length ? (
        <div className="bk-fm-srcblock">
          <span className="bk-fm-srcblock__label">Tracking parameters</span>
          <table className="bk-fm-params">
            <tbody>
              {landing.params.map((p) => (
                <tr key={p.key}>
                  <th scope="row">
                    <code>{p.key}</code>
                    {PARAM_LABEL[p.key] ? <span>{PARAM_LABEL[p.key]}</span> : CLICK_ID_NAMES[p.key] ? <span>Ad click ID</span> : null}
                  </th>
                  <td>
                    <div className="bk-fm-params__cell">
                      <span className="bk-fm-params__value" title={p.value}>{p.value}</span>
                      <CopyButton text={p.value} label={`Copy ${p.key}`} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
    </div>
  );
}

const SYNC_LABEL: Record<HubspotSyncState['status'], { text: string; tone: string }> = {
  synced: { text: 'Sent', tone: 'is-ok' },
  pending: { text: 'Sending…', tone: 'is-info' },
  failed: { text: 'Failed', tone: 'is-danger' },
  skipped: { text: 'Not sent', tone: 'is-muted' },
};

/** HubSpot status of the entry, with Retry / Send. Hidden when HubSpot isn't involved. */
function HubspotCard({ entryId, state, onState }: { entryId: string; state: HubspotSyncState | null; onState: (s: HubspotSyncState) => void }) {
  const [connected, setConnected] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    api<IntegrationsInfo>('/api/forms/integrations')
      .then((r) => setConnected(Boolean(r.providers.find((p) => p.id === 'hubspot')?.connected)))
      .catch(() => setConnected(false));
  }, []);
  if (!state && !connected) return null;
  const send = async () => {
    setBusy(true);
    setError(null);
    try {
      const r = await api<{ state: HubspotSyncState | null }>(`/api/forms/entries/${entryId}/sync/hubspot`, { method: 'POST' });
      if (r.state) onState(r.state);
    } catch (e) {
      setError(formsError(e));
    } finally {
      setBusy(false);
    }
  };
  const label = state ? SYNC_LABEL[state.status] : null;
  return (
    <section className="bk-panel">
      <div className="bk-panel__head">
        <h2 className="bk-panel__title">HubSpot</h2>
        {label ? <span className={`bk-fm-pill ${label.tone}`}>{label.text}</span> : <span className="bk-fm-pill is-muted">Not sent</span>}
      </div>
      <div className="bk-panel__body">
        {state?.status === 'synced' ? (
          <p className="bk-fm-side__text">
            {state.created ? 'New contact created' : 'Existing contact updated'}
            {state.syncedAt ? ` on ${formatDate(state.syncedAt)}` : ''}.{' '}
            {state.contactUrl ? (
              <a href={state.contactUrl} target="_blank" rel="noreferrer noopener">
                Open contact in HubSpot
              </a>
            ) : null}
          </p>
        ) : null}
        {state?.status === 'pending' && state.nextAt ? <p className="bk-fm-side__text">Next try {formatDate(state.nextAt)} (attempt {state.attempts + 1}).</p> : null}
        {state?.error ? <p className={`bk-fm-side__text${state.status === 'failed' ? ' is-error' : ''}`}>{state.error}</p> : null}
        {state?.warnings?.length ? (
          <ul className="bk-fm-warnings">
            {state.warnings.map((w) => (
              <li key={w}>{w}</li>
            ))}
          </ul>
        ) : null}
        {!state ? <p className="bk-fm-side__text">This entry was not sent to HubSpot (HubSpot was off for this form, or the entry is older).</p> : null}
        {error ? <p className="bk-fm-side__text is-error">{error}</p> : null}
        <button type="button" className="button bk-fm-side__btn" disabled={busy} onClick={() => void send()}>
          {busy ? 'Sending…' : state?.status === 'synced' ? 'Send again' : state ? 'Retry now' : 'Send to HubSpot'}
        </button>
      </div>
    </section>
  );
}

export function EntryPage() {
  const { id = '' } = useParams<{ id: string }>();
  const [params] = useSearchParams();
  const formScope = params.get('formId') ?? '';
  const href = useAdminHref();
  const navigate = useNavigate();
  const location = useLocation();
  const auth = useAuth();
  const canManage = auth.user?.capabilities.includes('manage_forms') ?? false;
  const from = (location.state as { from?: string } | null)?.from ?? (formScope ? `?formId=${encodeURIComponent(formScope)}` : '');
  const backHref = href(`forms/entries${from}`);

  const [entry, setEntry] = useState<EntryDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showTech, setShowTech] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setEntry(null);
    api<EntryDetail>(`/api/forms/entries/${encodeURIComponent(id)}${formScope ? `?formId=${encodeURIComponent(formScope)}` : ''}`)
      .then((e) => !cancelled && setEntry(e))
      .catch((e) => !cancelled && setError(formsError(e)));
    return () => {
      cancelled = true;
    };
  }, [id, formScope]);

  const go = (target: string | null) => {
    if (!target) return;
    navigate(href(`forms/entries/${target}${formScope ? `?formId=${encodeURIComponent(formScope)}` : ''}`), { state: { from } });
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && /INPUT|TEXTAREA|SELECT/.test(t.tagName)) return;
      if (e.key === 'ArrowLeft' || e.key === 'k') go(entry?.newerId ?? null);
      if (e.key === 'ArrowRight' || e.key === 'j') go(entry?.olderId ?? null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- rebinds per entry
  }, [entry]);

  const act = async (status: EntryStatus | 'delete') => {
    if (!entry) return;
    if (status === 'delete') {
      const ok = await confirmDialog({ title: 'Delete entry', message: 'This entry and its uploaded files cannot be recovered.', confirmLabel: 'Delete', danger: true });
      if (!ok) return;
    }
    setBusy(true);
    try {
      if (status === 'delete') await api('/api/forms/entries/delete', { method: 'POST', json: { ids: [entry.id] } });
      else await api('/api/forms/entries/status', { method: 'POST', json: { ids: [entry.id], status } });
      if (status === 'read' || status === 'unread') {
        setEntry({ ...entry, status });
        setNotice(status === 'unread' ? 'Marked as unread.' : 'Restored to the inbox.');
      } else {
        const message = status === 'delete' ? 'Entry deleted.' : status === 'spam' ? 'Marked as spam.' : 'Moved to trash.';
        const next = entry.olderId ?? entry.newerId;
        if (next) {
          setNotice(message);
          go(next);
        } else navigate(backHref, { state: { notice: message } });
      }
    } catch (e) {
      setError(formsError(e));
    } finally {
      setBusy(false);
    }
  };

  if (!entry) {
    return (
      <div className="wrap wrap--wide bk-fm">
        <PageHeader title="Entry" />
        <p>
          <Link to={backHref}>← All entries</Link>
        </p>
        {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : <p className="bk-muted">Loading…</p>}
      </div>
    );
  }

  const m = entry.meta;
  const visit = m.attribution?.visit ?? null;
  const first = m.attribution?.first ?? null;
  const firstDiffers = Boolean(first && visit && (first.channel !== visit.channel || first.source !== visit.source || first.campaign !== visit.campaign));
  const country = m.country ? `${flagEmoji(m.country)} ${countryName(m.country)}` : '';
  const origin = (() => {
    try {
      return new URL(m.pageUrl ?? '').origin;
    } catch {
      return window.location.origin;
    }
  })();

  return (
    <div className="wrap wrap--wide bk-fm bk-fm-entrypage">
      <PageHeader
        title={entry.formTitle}
        actions={
          <div className="bk-fm-entrypage__nav">
            <button type="button" className="button" disabled={!entry.newerId} onClick={() => go(entry.newerId)} title="Newer entry (←)">
              <CaretLeft size={14} aria-hidden /> Newer
            </button>
            <button type="button" className="button" disabled={!entry.olderId} onClick={() => go(entry.olderId)} title="Older entry (→)">
              Older <CaretRight size={14} aria-hidden />
            </button>
          </div>
        }
      />
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <div className="bk-fm-entrypage__bar">
        <Link className="bk-fm-entrypage__back" to={backHref}>
          ← All entries
        </Link>
        <span className="bk-fm-entrypage__when">
          Received {formatDate(entry.createdAt)} · <span className={`bk-fm-pill ${entry.status === 'spam' || entry.status === 'trash' ? 'is-muted' : 'is-ok'}`}>{STATUS_LABEL[entry.status]}</span>
        </span>
        <div className="bk-fm-entrypage__actions">
          {entry.status === 'spam' || entry.status === 'trash' ? (
            <>
              <button type="button" className="button" disabled={busy} onClick={() => void act('read')}>Restore</button>
              <button type="button" className="button-link is-danger" disabled={busy} onClick={() => void act('delete')}>Delete forever</button>
            </>
          ) : (
            <>
              <button type="button" className="button" disabled={busy} onClick={() => void act('unread')}>Mark unread</button>
              <button type="button" className="button-link" disabled={busy} onClick={() => void act('spam')}>Spam</button>
              <button type="button" className="button-link is-danger" disabled={busy} onClick={() => void act('trash')}>Trash</button>
            </>
          )}
          {canManage ? (
            <Link className="button-link" to={href(`forms/${entry.formId}`)}>
              Edit form
            </Link>
          ) : null}
        </div>
      </div>

      <div className="bk-fm-entrypage__grid">
        <section className="bk-panel bk-fm-entrypage__answers">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Answers</h2>
            <span className="bk-fm-head-meta">{entry.answers.filter((a) => a.text).length} of {entry.answers.length} answered</span>
          </div>
          <dl className="bk-fm-answers bk-fm-answers--full">
            {entry.answers.map((a) => (
              <div key={a.fieldId} className="bk-fm-answer">
                <dt>{a.label}</dt>
                <dd>
                  {isFileList(a.value) ? (
                    <ul className="bk-fm-files">
                      {a.value.map((f) => (
                        <li key={f.id}>
                          <a href={apiUrl(`/api/forms/entries/${entry.id}/files/${f.id}`)}>{f.name}</a>
                          <span>{bytes(f.size)}</span>
                        </li>
                      ))}
                    </ul>
                  ) : a.text ? (
                    a.type === 'url' && /^https?:\/\//i.test(a.text) ? (
                      <a href={a.text} target="_blank" rel="noreferrer noopener">{a.text}</a>
                    ) : a.type === 'email' ? (
                      <a href={`mailto:${a.text}`}>{a.text}</a>
                    ) : a.type === 'phone' ? (
                      <a href={`tel:${a.text.replace(/[^\d+]/g, '')}`}>{a.text}</a>
                    ) : (
                      a.text
                    )
                  ) : (
                    <span className="bk-fm-answer__empty">Not answered</span>
                  )}
                </dd>
              </div>
            ))}
          </dl>
        </section>

        <aside className="bk-fm-entrypage__side">
          <HubspotCard entryId={entry.id} state={m.integrations?.hubspot ?? null} onState={(hubspot) => setEntry({ ...entry, meta: { ...entry.meta, integrations: { ...(entry.meta.integrations ?? {}), hubspot } } })} />

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Source of this visit</h2>
            </div>
            <div className="bk-panel__body">
              {visit ? (
                <SourceRows a={visit} origin={origin} sentAt={entry.createdAt} />
              ) : (
                <p className="bk-fm-side__empty">Not recorded. This entry was sent before source tracking was added.</p>
              )}
            </div>
          </section>

          {first ? (
            <section className="bk-panel">
              <div className="bk-panel__head">
                <h2 className="bk-panel__title">First visit</h2>
                <span className="bk-fm-head-meta">{firstDiffers ? 'Different from this visit' : 'Same as this visit'}</span>
              </div>
              <div className="bk-panel__body">
                {firstDiffers ? <SourceRows a={first} origin={origin} /> : <p className="bk-fm-side__empty">They first found the site the same way{first.at ? `, on ${formatDate(first.at, false)}` : ''}.</p>}
              </div>
            </section>
          ) : null}

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Visitor</h2>
            </div>
            <div className="bk-panel__body">
              <dl className="bk-fm-infolist">
                <Info label="Country">{country}</Info>
                <Info label="Device">{m.device ? DEVICE_LABEL[m.device] ?? m.device : ''}</Info>
                <Info label="Browser">{m.browser && m.os ? `${m.browser} on ${m.os}` : m.browser || m.os}</Info>
                <Info label="Language">{m.language}</Info>
                <Info label="Time zone">{m.timeZone}</Info>
                <Info label="Screen">{m.screen}</Info>
              </dl>
              {!country && !m.device && !m.browser ? <p className="bk-fm-side__empty">Not recorded for this entry.</p> : null}
            </div>
          </section>

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Submission</h2>
            </div>
            <div className="bk-panel__body">
              <dl className="bk-fm-infolist">
                <Info label="Sent from" wide>
                  {m.pageUrl ? (
                    <a href={m.pageUrl} target="_blank" rel="noreferrer noopener" className="bk-fm-url">
                      {m.pageTitle || m.pageUrl}
                    </a>
                  ) : (
                    ''
                  )}
                </Info>
                <Info label="Pages viewed">{m.pagesViewed ? String(m.pagesViewed) : ''}</Info>
                <Info label="Time on site">{duration(m.timeOnSiteSeconds)}</Info>
                <Info label="Time to fill in">{duration(m.fillSeconds)}</Info>
              </dl>
              <button type="button" className="button-link bk-fm-tech-toggle" onClick={() => setShowTech((v) => !v)} aria-expanded={showTech}>
                {showTech ? 'Hide technical details' : 'Technical details'}
              </button>
              {showTech ? (
                <dl className="bk-fm-infolist bk-fm-infolist--tech">
                  <Info label="Entry ID">{entry.id}</Info>
                  <Info label="IP address">{m.ip}</Info>
                  <Info label="Window">{m.viewport}</Info>
                  <Info label="User agent" wide>{m.userAgent}</Info>
                </dl>
              ) : null}
            </div>
          </section>
        </aside>
      </div>
    </div>
  );
}
