import { FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { api, ApiError } from '../../api/client';
import { confirmDialog } from '../../components/ConfirmDialog';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import {
  newField,
  toAcfJson,
  toFieldName,
  typeDef,
  type BackendField,
  type Option,
} from '../../fields/acf-types';
import { useAdminHref } from '../../lib/AdminEntryContext';
import { FieldEditorProvider, FieldListEditor } from './FieldListEditor';
import './field-group-editor.css';
import { ErrorNotice } from '../../components/ErrorNotice';

export type FieldGroup = {
  id: string;
  title: string;
  key: string;
  description: string;
  active: boolean;
  location: string[];
  fields: BackendField[];
  fieldCount: number;
  trashedAt?: string | null;
  createdAt: string;
  updatedAt: string;
};

type Form = {
  title: string;
  key: string;
  description: string;
  active: boolean;
  location: string[];
  fields: BackendField[];
};

const EMPTY: Form = {
  title: '',
  key: '',
  description: '',
  active: true,
  location: ['page'],
  fields: [],
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

/** Every value field needs a label and a unique name at its level. */
function validate(fields: BackendField[], path = ''): string | null {
  const seen = new Set<string>();
  for (const f of fields) {
    const where = path ? `${path} › ${f.label || '(no label)'}` : f.label || '(no label)';
    if (!f.label.trim()) return `A field in ${path || 'this group'} has no label.`;
    if (!typeDef(f.type).noValue) {
      if (!/^[a-z][a-z0-9_]*$/.test(f.name)) return `“${where}” needs a field name (a-z, 0-9, _ and starting with a letter).`;
      if (seen.has(f.name)) return `Duplicate field name “${f.name}” in ${path || 'this group'}.`;
      seen.add(f.name);
    }
    if (f.subFields) {
      const err = validate(f.subFields, where);
      if (err) return err;
    }
    if (f.layouts) {
      const names = new Set<string>();
      for (const l of f.layouts) {
        if (!l.label.trim() || !l.name) return `A layout in “${where}” needs a label and name.`;
        if (names.has(l.name)) return `Duplicate layout name “${l.name}” in “${where}”.`;
        names.add(l.name);
        const err = validate(l.subFields, `${where} › ${l.label}`);
        if (err) return err;
      }
    }
  }
  return null;
}

/** Drop empty choice lines etc. before save. */
function clean(fields: BackendField[]): BackendField[] {
  return fields.map((f) => ({
    ...f,
    label: f.label.trim(),
    choices: f.choices.map((c) => c.trim()).filter(Boolean),
    subFields: f.subFields ? clean(f.subFields) : undefined,
    layouts: f.layouts?.map((l) => ({ ...l, label: l.label.trim(), subFields: clean(l.subFields) })),
  }));
}

export function FieldGroupEditPage() {
  const { id } = useParams<{ id: string }>();
  const isNew = !id || id === 'new';
  const href = useAdminHref();
  const navigate = useNavigate();

  const [form, setForm] = useState<Form>(EMPTY);
  const [saved, setSaved] = useState<string>(JSON.stringify(EMPTY));
  const [group, setGroup] = useState<FieldGroup | null>(null);
  const [locations, setLocations] = useState<Option[]>([
    { value: 'post', label: 'Posts' },
    { value: 'page', label: 'Pages' },
    { value: 'user', label: 'Users' },
    { value: 'media', label: 'Media' },
  ]);
  const [roles, setRoles] = useState<Option[]>([]);
  const [loading, setLoading] = useState(!isNew);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const location = useLocation();
  const [notice, setNotice] = useState<string | null>(null);
  const keyTouched = useRef(false);

  useEffect(() => {
    const n = (location.state as { notice?: string } | null)?.notice;
    if (n) setNotice(n);
  }, [location.key, location.state]);

  useEffect(() => {
    api<{ locations: Option[] }>('/api/fields/meta')
      .then((m) => m.locations?.length && setLocations(m.locations))
      .catch(() => {});
    api<{ roles: { slug: string; label: string }[] }>('/api/users/roles')
      .then((r) => setRoles(r.roles.map((x) => ({ value: x.slug, label: x.label }))))
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (isNew) {
      const f = { ...EMPTY, fields: [newField()] };
      setForm(f);
      setSaved(JSON.stringify(f));
      setGroup(null);
      keyTouched.current = false;
      return;
    }
    setLoading(true);
    api<FieldGroup>(`/api/fields/${id}`)
      .then((g) => {
        const f: Form = {
          title: g.title,
          key: g.key,
          description: g.description,
          active: g.active,
          location: [...g.location],
          fields: g.fields,
        };
        setGroup(g);
        setForm(f);
        setSaved(JSON.stringify(f));
        keyTouched.current = true;
      })
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [id, isNew]);

  const dirty = useMemo(() => JSON.stringify(form) !== saved, [form, saved]);

  useEffect(() => {
    if (!dirty) return;
    const warn = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [dirty]);

  const postTypes = useMemo(
    () => locations.filter((l) => l.value !== 'user' && l.value !== 'media'),
    [locations],
  );

  const onSubmit = async (e?: FormEvent) => {
    e?.preventDefault();
    setError(null);
    setNotice(null);
    if (!form.title.trim()) {
      setError('Field group title is required.');
      return;
    }
    const fields = clean(form.fields);
    const problem = validate(fields);
    if (problem) {
      setError(problem);
      return;
    }
    const payload = {
      title: form.title.trim(),
      key: form.key.trim() || undefined,
      description: form.description.trim(),
      active: form.active,
      location: form.location,
      fields,
    };
    setBusy(true);
    try {
      if (isNew) {
        const created = await api<FieldGroup>('/api/fields', { method: 'POST', json: payload });
        setSaved(JSON.stringify(form));
        navigate(href(`fields/${created.id}`), {
          replace: true,
          state: { notice: `Field group “${payload.title}” published.` },
        });
      } else {
        const updated = await api<FieldGroup>(`/api/fields/${id}`, { method: 'PATCH', json: payload });
        const f: Form = {
          title: updated.title,
          key: updated.key,
          description: updated.description,
          active: updated.active,
          location: updated.location,
          fields: updated.fields,
        };
        setGroup(updated);
        setForm(f);
        setSaved(JSON.stringify(f));
        setNotice(`Field group “${updated.title}” updated.`);
      }
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const onDelete = async () => {
    if (!group) return;
    const ok = await confirmDialog({
      title: 'Move to trash',
      message: `Move field group “${group.title}” to trash? Theme layout files are kept and can be restored from Field Groups → Trash.`,
      confirmLabel: 'Move to trash',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    try {
      await api(`/api/fields/${group.id}`, { method: 'DELETE' });
      setSaved(JSON.stringify(form));
      navigate(href('fields'), {
        state: { notice: `Field group “${group.title}” moved to trash.` },
      });
    } catch (err) {
      setError(formatError(err));
      setBusy(false);
    }
  };

  const exportJson = () => {
    const json = [
      {
        key: form.key || `group_${toFieldName(form.title)}`,
        title: form.title,
        fields: clean(form.fields).map(toAcfJson),
        location: [form.location.map((v) => ({ param: 'post_type', operator: '==', value: v }))],
        menu_order: 0,
        position: 'normal',
        style: 'default',
        label_placement: 'top',
        instruction_placement: 'label',
        active: form.active,
        description: form.description,
        modified: Math.floor(Date.now() / 1000),
      },
    ];
    const blob = new Blob([`${JSON.stringify(json, null, 2)}\n`], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${form.key || 'field-group'}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  const fieldTotal = useMemo(() => {
    const count = (fs: BackendField[]): number =>
      fs.reduce(
        (n, f) => n + 1 + count(f.subFields ?? []) + (f.layouts ?? []).reduce((m, l) => m + count(l.subFields), 0),
        0,
      );
    return count(form.fields);
  }, [form.fields]);

  if (loading) {
    return (
      <div className="wrap wrap--wide">
        <p className="bk-muted">Loading field group…</p>
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide bk-acf-page">
      <PageHeader
        title={isNew ? 'Add New Field Group' : 'Edit Field Group'}
        actions={
          <>
            <Link className="button" to={href('fields/new')}>
              Add New
            </Link>
            {!isNew ? (
              <button type="button" className="button" onClick={exportJson}>
                Export JSON
              </button>
            ) : null}
            <button type="submit" form="field-group-form" className="button button-primary" disabled={busy}>
              {busy ? 'Saving…' : isNew ? 'Save Changes' : 'Update'}
            </button>
          </>
        }
      />
      <p className="bk-acf-breadcrumb">
        <Link to={href('fields')}>Field Groups</Link> <span>/</span> {form.title || (isNew ? 'New field group' : '…')}
        {dirty ? <span className="bk-acf-dirty">Unsaved changes</span> : null}
      </p>

      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <form id="field-group-form" className="bk-acf-form" onSubmit={onSubmit}>
        <input
          className="bk-acf-title"
          type="text"
          required
          maxLength={120}
          placeholder="Field group title"
          value={form.title}
          onChange={(e) => {
            const title = e.target.value;
            setForm((f) => ({
              ...f,
              title,
              key: !keyTouched.current ? `group_${toFieldName(title) || 'fields'}` : f.key,
            }));
          }}
        />

        <section className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Fields</h2>
            <span className="bk-acf-muted">{fieldTotal} field{fieldTotal === 1 ? '' : 's'}</span>
          </div>
          <div className="bk-panel__body bk-acf-panel-body">
            <FieldEditorProvider value={{ postTypes, roles }}>
              <FieldListEditor fields={form.fields} onChange={(fields) => setForm((f) => ({ ...f, fields }))} />
            </FieldEditorProvider>
          </div>
        </section>

        <section className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Settings</h2>
          </div>
          <div className="bk-panel__body">
            <div className="bk-acf-setting">
              <div className="bk-acf-setting__label">
                <span>Location Rules</span>
                <p>Show this field group if the post type is any of these. Page layouts appear in the visual editor when “Pages” is checked.</p>
              </div>
              <div className="bk-acf-setting__control">
                <div className="bk-acf-checks">
                  {locations.map((opt) => (
                    <label key={opt.value}>
                      <input
                        type="checkbox"
                        checked={form.location.includes(opt.value)}
                        onChange={() =>
                          setForm((f) => ({
                            ...f,
                            location: f.location.includes(opt.value)
                              ? f.location.filter((v) => v !== opt.value)
                              : [...f.location, opt.value],
                          }))
                        }
                      />
                      {opt.label}
                    </label>
                  ))}
                </div>
              </div>
            </div>
            <div className="bk-acf-setting">
              <div className="bk-acf-setting__label">
                <span>Active</span>
              </div>
              <div className="bk-acf-setting__control">
                <button
                  type="button"
                  role="switch"
                  aria-checked={form.active}
                  className={`bk-acf-toggle${form.active ? ' is-on' : ''}`}
                  onClick={() => setForm((f) => ({ ...f, active: !f.active }))}
                >
                  <span />
                </button>
              </div>
            </div>
            <div className="bk-acf-setting">
              <div className="bk-acf-setting__label">
                <span>Key</span>
                <p>Unique machine key for this group — used in JSON export and import (e.g. group_hero).</p>
              </div>
              <div className="bk-acf-setting__control">
                <input
                  type="text"
                  className="regular-text"
                  maxLength={60}
                  value={form.key}
                  placeholder="group_hero"
                  onChange={(e) => {
                    keyTouched.current = true;
                    setForm((f) => ({ ...f, key: e.target.value }));
                  }}
                />
              </div>
            </div>
            <div className="bk-acf-setting">
              <div className="bk-acf-setting__label">
                <span>Description</span>
                <p>Shown in the field group list</p>
              </div>
              <div className="bk-acf-setting__control">
                <textarea
                  rows={2}
                  maxLength={500}
                  value={form.description}
                  onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                />
              </div>
            </div>
            {!isNew ? (
              <div className="bk-acf-setting">
                <div className="bk-acf-setting__label">
                  <span>Delete</span>
                </div>
                <div className="bk-acf-setting__control">
                  <button type="button" className="button-link is-danger" disabled={busy} onClick={onDelete}>
                    Move field group to trash
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        </section>
      </form>
    </div>
  );
}
