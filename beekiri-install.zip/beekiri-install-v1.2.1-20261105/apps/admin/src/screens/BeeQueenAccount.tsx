import { useCallback, useEffect, useState } from 'react';
import { Coins } from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { notifyConnectorChanged } from '../lib/admin-events';
import './beequeen-account.css';

type Account =
  | { connected: false }
  | {
      connected: true;
      serviceUrl: string;
      site: { name: string };
      balance: number;
      currency: string;
      packs: { id: string; name: string; credits: number; price: number; priceLabel: string; description: string | null }[];
      requests: { id: string; pack: string | null; credits: number | null; status: string; createdAt: string; decidedAt: string | null }[];
      history: { id: string; amount: number; balanceAfter: number; kind: string; description: string | null; model: string | null; runId: string | null; createdAt: string }[];
    };

type Connected = Extract<Account, { connected: true }>;

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

const when = (iso: string) => new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });

const STATUS_LABEL: Record<string, string> = {
  pending: 'Waiting for approval',
  approved: 'Approved',
  rejected: 'Declined',
};

/**
 * Usage lines grouped by agent run, so one BeeQueen message shows as one line
 * (its Claude calls are metered one by one on the service).
 */
function groupedHistory(history: Connected['history']) {
  const out: { key: string; amount: number; balanceAfter: number; label: string; detail: string; createdAt: string }[] = [];
  const byRun = new Map<string, (typeof out)[number] & { calls: number }>();
  for (const t of history) {
    if (t.kind === 'usage' && t.runId) {
      const run = byRun.get(t.runId);
      if (run) {
        run.amount += t.amount;
        run.calls += 1;
        run.detail = `${run.calls} Claude calls · ${t.model ?? ''}`.trim();
        continue;
      }
      const row = {
        key: t.runId,
        amount: t.amount,
        balanceAfter: t.balanceAfter,
        label: 'BeeQueen run',
        detail: `1 Claude call · ${t.model ?? ''}`.trim(),
        createdAt: t.createdAt,
        calls: 1,
      };
      byRun.set(t.runId, row);
      out.push(row);
      continue;
    }
    out.push({
      key: t.id,
      amount: t.amount,
      balanceAfter: t.balanceAfter,
      label: t.description || t.kind,
      detail: t.kind === 'pack' ? 'Pack approved' : t.kind === 'grant' ? 'Added by 996Agency' : '',
      createdAt: t.createdAt,
    });
  }
  return out;
}

/** This site's BeeQueen account on the 996Agency service: credits, packs to request, usage. */
export function BeeQueenAccount({ reloadKey }: { reloadKey: number }) {
  const [account, setAccount] = useState<Account | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    try {
      setAccount(await api<Account>('/api/connector/beequeen/account'));
    } catch (e) {
      setAccount(null);
      setError(formatError(e));
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load, reloadKey]);

  const request = async (packId: string) => {
    setBusy(packId);
    setError(null);
    try {
      setAccount(await api<Account>('/api/connector/beequeen/pack-requests', { method: 'POST', json: { pack: packId } }));
      notifyConnectorChanged();
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(null);
    }
  };

  if (error) {
    return (
      <section className="bk-panel bk-bqa">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">BeeQueen account</h2>
          <button type="button" className="button" onClick={() => void load()}>
            Try again
          </button>
        </div>
        <div className="bk-panel__body">
          <p className="bk-bqa__error">{error}</p>
        </div>
      </section>
    );
  }
  if (!account) return <p className="bk-muted">Loading BeeQueen account…</p>;
  if (!account.connected) {
    return (
      <section className="bk-panel bk-bqa">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">BeeQueen account</h2>
        </div>
        <div className="bk-panel__body">
          <p className="bk-muted" style={{ margin: 0 }}>
            Add this site’s BeeQueen key above to see its credits and request packs. 996Agency gives each site its own
            key.
          </p>
        </div>
      </section>
    );
  }

  const pendingFor = new Set(account.requests.filter((r) => r.status === 'pending').map((r) => r.pack));
  const history = groupedHistory(account.history);

  return (
    <section className="bk-panel bk-bqa">
      <div className="bk-panel__head">
        <h2 className="bk-panel__title">BeeQueen account · {account.site.name}</h2>
        <button type="button" className="button" onClick={() => void load()}>
          Refresh
        </button>
      </div>
      <div className="bk-panel__body bk-bqa__body">
        <div className={`bk-bqa__balance${account.balance <= 0 ? ' is-empty' : ''}`}>
          <span className="bk-bqa__balance-icon" aria-hidden>
            <Coins size={20} />
          </span>
          <div>
            <p className="bk-bqa__label">Credits left</p>
            <p className="bk-bqa__value">{account.balance.toLocaleString()}</p>
            <p className="bk-muted bk-bqa__note">
              {account.balance <= 0
                ? 'BeeQueen is paused until a pack is approved.'
                : 'Each BeeQueen message uses credits for the Claude work it does — bigger builds use more.'}
            </p>
          </div>
        </div>

        <div>
          <h3 className="bk-bqa__h">Packs</h3>
          <div className="bk-bqa__packs">
            {account.packs.map((p) => (
              <article key={p.id} className="bk-bqa__pack">
                <p className="bk-bqa__pack-name">{p.name}</p>
                <p className="bk-bqa__pack-credits">
                  {p.credits.toLocaleString()} <span>credits</span>
                </p>
                <p className="bk-bqa__pack-price">{p.priceLabel}</p>
                {p.description ? <p className="bk-bqa__pack-desc">{p.description}</p> : null}
                <button
                  type="button"
                  className={pendingFor.has(p.name) ? 'button' : 'button button-primary'}
                  disabled={busy !== null || pendingFor.has(p.name)}
                  onClick={() => void request(p.id)}
                >
                  {pendingFor.has(p.name) ? 'Requested' : busy === p.id ? 'Requesting…' : 'Request pack'}
                </button>
              </article>
            ))}
          </div>
          <p className="bk-muted bk-bqa__fine">
            996Agency approves requests and adds the credits to this site — you’ll see them here.
          </p>
        </div>

        {account.requests.length ? (
          <div>
            <h3 className="bk-bqa__h">Requests</h3>
            <ul className="bk-bqa__requests">
              {account.requests.map((r) => (
                <li key={r.id}>
                  <span>
                    {r.pack} · {(r.credits ?? 0).toLocaleString()} credits
                  </span>
                  <span className={`bk-bqa__status is-${r.status}`}>{STATUS_LABEL[r.status] ?? r.status}</span>
                  <span className="bk-muted">{when(r.decidedAt ?? r.createdAt)}</span>
                </li>
              ))}
            </ul>
          </div>
        ) : null}

        <div>
          <h3 className="bk-bqa__h">Usage</h3>
          {history.length === 0 ? (
            <p className="bk-muted" style={{ margin: 0 }}>
              No activity yet.
            </p>
          ) : (
            <div className="bk-bqa__table-wrap">
              <table className="bk-bqa__table">
                <thead>
                  <tr>
                    <th scope="col">When</th>
                    <th scope="col">What</th>
                    <th scope="col" className="is-num">
                      Credits
                    </th>
                    <th scope="col" className="is-num">
                      Left
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((h) => (
                    <tr key={h.key}>
                      <td className="bk-bqa__date">{when(h.createdAt)}</td>
                      <td>
                        {h.label}
                        {h.detail ? <span className="bk-bqa__sub">{h.detail}</span> : null}
                      </td>
                      <td className={`is-num ${h.amount < 0 ? 'is-minus' : 'is-plus'}`}>
                        {h.amount > 0 ? '+' : ''}
                        {h.amount.toLocaleString()}
                      </td>
                      <td className="is-num">{h.balanceAfter.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
