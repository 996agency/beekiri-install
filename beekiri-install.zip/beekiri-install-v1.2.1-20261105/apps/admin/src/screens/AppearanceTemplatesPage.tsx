import { useCallback, useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { api, apiUrl, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { useThemeSwitch } from '../components/ThemeSwitchOverlay';
import { confirmDialog } from '../components/ConfirmDialog';
import { ErrorNotice } from '../components/ErrorNotice';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import { SITE_URL as LIVE_SITE } from '../config';
import { useAdminHref } from '../lib/AdminEntryContext';
import './theme-store.css';

type StoreTheme = {
  slug: string;
  name: string;
  tagline: string | null;
  description: string | null;
  version: string;
  price: number;
  priceLabel: string;
  free: boolean;
  owned: boolean;
  pending: boolean;
  hasScreenshot: boolean;
  screenshotVersion: string | null;
  demoUrl: string | null;
  tags: string[];
  installed: boolean;
  installedVersion: string | null;
  active: boolean;
  hasContent: boolean;
  contentInstalled: boolean;
  licence: {
    state: 'active' | 'available' | 'full';
    environment: string;
    limit: number;
    message: string | null;
    buyer: string | null;
    sites: { environment: string; domain: string | null; current: boolean }[];
  } | null;
};

const ENV_LABEL: Record<string, string> = { local: 'Local', staging: 'Staging', production: 'Production' };

type ContentResult = { installed: boolean; pages: { key: string; title: string; slug?: string; id?: string }[] };

type Catalog = {
  available: boolean;
  error?: string;
  currency: string;
  paymentMethod: 'stripe' | 'paypal' | 'manual';
  themes: StoreTheme[];
};

function message(e: unknown): string {
  if (e instanceof ApiError || e instanceof Error) return e.message;
  return 'Something went wrong. Try again.';
}

/** "1.2.0" > "1.10.0"-safe comparison: true when `next` is newer than `current`. */
function isNewer(next: string, current: string | null): boolean {
  if (!current) return false;
  const a = next.split('.').map((n) => parseInt(n, 10) || 0);
  const b = current.split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) > (b[i] ?? 0);
  }
  return false;
}

/** Appearance → Templates: themes from 996Agency. Buy once for this site, install, activate. */
export function AppearanceTemplatesPage() {
  const auth = useAuth();
  const href = useAdminHref();
  const canEdit = auth.user?.capabilities.includes('edit_theme_options') ?? false;
  const [homeLink, setHomeLink] = useState<string | null>(null);
  const [params, setParams] = useSearchParams();
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setCatalog(await api<Catalog>('/api/themes/store'));
    } catch (e) {
      setError(message(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  // Back from Stripe / PayPal: say what happened, then tidy the address bar.
  useEffect(() => {
    const outcome = params.get('purchase');
    if (!outcome) return;
    if (outcome === 'success') setNotice('Payment received — the theme is yours. Install it below.');
    else if (outcome === 'cancelled') setNotice('Checkout cancelled. Nothing was charged.');
    else setNotice('We could not confirm the payment yet. If you paid, the theme unlocks within a few minutes — refresh this page.');
    const next = new URLSearchParams(params);
    next.delete('purchase');
    next.delete('theme');
    setParams(next, { replace: true });
  }, [params, setParams]);

  const { overlay: switchOverlay, run: runSwitch } = useThemeSwitch(LIVE_SITE);

  const run = async (slug: string, fn: () => Promise<void>) => {
    setBusy(slug);
    setError('');
    setNotice('');
    try {
      await fn();
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(null);
    }
  };

  const buy = (t: StoreTheme) =>
    run(t.slug, async () => {
      const manual = catalog?.paymentMethod === 'manual';
      if (manual) {
        const ok = await confirmDialog({
          title: `Request “${t.name}” (${t.priceLabel})?`,
          message: '996Agency will contact you to arrange payment and unlock the theme for this site. You will see it here as soon as it is approved.',
          confirmLabel: 'Send request',
        });
        if (!ok) return;
      }
      const res = await api<{ status: 'owned' | 'pending' | 'checkout'; checkoutUrl: string | null }>(
        `/api/themes/store/${encodeURIComponent(t.slug)}/purchase`,
        { method: 'POST' },
      );
      if (res.status === 'checkout' && res.checkoutUrl) {
        window.location.assign(res.checkoutUrl);
        return;
      }
      setNotice(
        res.status === 'owned'
          ? `“${t.name}” is yours. Install it below.`
          : `Request sent. “${t.name}” unlocks here once 996Agency approves it.`,
      );
      await load();
    });

  const install = (t: StoreTheme) =>
    run(t.slug, async () => {
      await api(`/api/themes/store/${encodeURIComponent(t.slug)}/install`, { method: 'POST' });
      setNotice(t.installed ? `“${t.name}” updated to v${t.version}.` : `“${t.name}” installed. Activate it when you are ready.`);
      await load();
    });

  const installPages = async (t: StoreTheme): Promise<boolean> => {
    const ok = await confirmDialog({
      title: `Add the “${t.name}” pages?`,
      message: 'The theme comes with ready-made pages. They are added as new pages, the new Home becomes your front page and the menu points to them. Your existing pages are kept and you can edit everything in the page editor.',
      confirmLabel: 'Add pages',
      cancelLabel: 'Not now',
    });
    if (!ok) return false;
    const res = await api<ContentResult>(`/api/themes/${encodeURIComponent(t.slug)}/content/install`, { method: 'POST' });
    const home = res.pages.find((p) => p.slug === 'home') ?? res.pages[0];
    setHomeLink(home?.id ? href(`pages/${home.id}`) : null);
    setNotice(`“${t.name}” is active and its ${res.pages.length} pages are in. Open a page to start editing.`);
    return true;
  };

  const activate = (t: StoreTheme) =>
    run(t.slug, async () => {
      const ok = await confirmDialog({
        title: `Activate “${t.name}”?`,
        message: 'Your site switches to this theme together with its own pages, menu, header and footer. The pages you have now are kept and come back when you switch back.',
        confirmLabel: 'Activate',
      });
      if (!ok) return;
      setHomeLink(null);
      await runSwitch(t.name, async () => {
        try {
          // The first activation also adds the theme's ready-made pages (done by the API).
          const res = await api<{ pagesAdded?: number }>('/api/themes/activate', { method: 'POST', json: { slug: t.slug } });
          await load();
          return res.pagesAdded
            ? `Your site now shows ${t.name} with its ${res.pagesAdded} ready-made pages, menu, header and footer.`
            : `Your site now shows ${t.name} with its own pages, menu, header and footer.`;
        } catch (e) {
          throw new Error(message(e));
        }
      });
    });

  const addPages = (t: StoreTheme) =>
    run(t.slug, async () => {
      setHomeLink(null);
      await installPages(t);
      await load();
    });

  const deactivate = (t: StoreTheme) =>
    run(t.slug, async () => {
      const ok = await confirmDialog({
        title: `Deactivate “${t.name}”?`,
        message: 'Your site goes back to the Beekiri Child theme and its pages. This theme stays installed and its pages are kept, so they come back when you activate it again.',
        confirmLabel: 'Deactivate',
      });
      if (!ok) return;
      setHomeLink(null);
      await runSwitch('Beekiri Child', async () => {
        try {
          await api('/api/themes/deactivate', { method: 'POST', json: { slug: t.slug } });
          await load();
          return `Your site now shows Beekiri Child with its own pages. ${t.name}’s pages are saved for later.`;
        } catch (e) {
          throw new Error(message(e));
        }
      });
    });

  const resetPages = (t: StoreTheme) =>
    run(t.slug, async () => {
      const ok = await confirmDialog({
        title: `Reset the “${t.name}” pages?`,
        message: 'The pages this theme added go back to their original design and photos. Edits you made to those pages are replaced; your other pages, the menu and the photos already in Media are kept.',
        confirmLabel: 'Reset pages',
        cancelLabel: 'Keep my edits',
      });
      if (!ok) return;
      setHomeLink(null);
      const res = await api<ContentResult>(`/api/themes/${encodeURIComponent(t.slug)}/content/reset`, { method: 'POST' });
      const home = res.pages.find((p) => p.slug === 'home') ?? res.pages[0];
      setHomeLink(home?.id ? href(`pages/${home.id}`) : null);
      setNotice(`The “${t.name}” pages are back to the theme's design.`);
      await load();
    });

  const action = (t: StoreTheme) => {
    const working = busy === t.slug;
    if (!canEdit) return null;
    if (!t.owned) {
      if (t.pending) return <span className="bk-store__status">Waiting for approval</span>;
      return (
        <button type="button" className="button button-primary" disabled={working} onClick={() => void buy(t)}>
          {working ? 'Opening checkout…' : catalog?.paymentMethod === 'manual' ? `Request · ${t.priceLabel}` : `Buy · ${t.priceLabel}`}
        </button>
      );
    }
    if (!t.installed) {
      return (
        <button type="button" className="button button-primary" disabled={working} onClick={() => void install(t)}>
          {working ? 'Installing…' : 'Install'}
        </button>
      );
    }
    return (
      <>
        {isNewer(t.version, t.installedVersion) ? (
          <button type="button" className="button" disabled={working} onClick={() => void install(t)}>
            {working ? 'Updating…' : `Update to v${t.version}`}
          </button>
        ) : null}
        {t.active && t.hasContent && !t.contentInstalled ? (
          <button type="button" className="button" disabled={working} onClick={() => void addPages(t)}>
            {working ? 'Adding pages…' : 'Add its pages'}
          </button>
        ) : null}
        {t.active && t.hasContent && t.contentInstalled ? (
          <button type="button" className="button" disabled={working} onClick={() => void resetPages(t)}>
            {working ? 'Resetting…' : 'Reset its pages'}
          </button>
        ) : null}
        {t.active ? (
          <>
            <span className="bk-store__status is-active">Active</span>
            <button type="button" className="button" disabled={working} onClick={() => void deactivate(t)}>
              {working ? 'Deactivating…' : 'Deactivate'}
            </button>
          </>
        ) : (
          <button type="button" className="button button-primary" disabled={working} onClick={() => void activate(t)}>
            Activate
          </button>
        )}
      </>
    );
  };

  return (
    <div className="wrap wrap--wide bk-store">
      <PageHeader
        title="Templates"
        actions={
          <a className="button" href={LIVE_SITE} target="_blank" rel="noreferrer">
            View site
          </a>
        }
      />
      <p className="bk-store__lead">Themes made by 996Agency. Buy a theme once and it is yours on this site — install it, then activate it when you are ready.</p>

      {error ? <ErrorNotice message={error} onDismiss={() => setError('')} /> : null}
      {notice ? (
        <SuccessNotice
          message={notice}
          onDismiss={() => {
            setNotice('');
            setHomeLink(null);
          }}
        />
      ) : null}
      {switchOverlay}
      {notice && homeLink ? (
        <p className="bk-store__edit">
          <Link className="button button-primary" to={homeLink}>
            Edit the Home page
          </Link>
        </p>
      ) : null}

      {loading && !catalog ? (
        <div className="bk-store__grid" aria-busy="true">
          {[0, 1, 2].map((i) => (
            <div key={i} className="bk-store__card is-skeleton" />
          ))}
        </div>
      ) : catalog && !catalog.available ? (
        <div className="bk-store__empty">
          <strong>The theme store is not reachable right now.</strong>
          <p>{catalog.error} Your installed themes keep working.</p>
          <button type="button" className="button" onClick={() => void load()}>
            Try again
          </button>
        </div>
      ) : catalog && catalog.themes.length === 0 ? (
        <div className="bk-store__empty">
          <strong>No themes in the store yet.</strong>
          <p>New themes from 996Agency appear here.</p>
        </div>
      ) : catalog ? (
        <ul className="bk-store__grid">
          {[...catalog.themes].sort((a, b) => Number(b.active) - Number(a.active)).map((t) => (
            <li key={t.slug} className={`bk-store__card${t.active ? ' is-active' : ''}`}>
              <div className="bk-store__shot">
                {t.hasScreenshot ? (
                  <img src={apiUrl(`/api/themes/store/${encodeURIComponent(t.slug)}/screenshot?v=${encodeURIComponent(t.screenshotVersion ?? t.version)}`)} alt="" loading="lazy" />
                ) : (
                  <span className="bk-store__shot-empty" aria-hidden>
                    {t.name.slice(0, 1)}
                  </span>
                )}
              </div>
              <div className="bk-store__body">
                <div className="bk-store__title-row">
                  <h2 className="bk-store__name">{t.name}</h2>
                  <span className="bk-store__price">{t.owned && !t.free ? 'Owned' : t.priceLabel}</span>
                </div>
                {t.tagline ? <p className="bk-store__tagline">{t.tagline}</p> : null}
                {t.description ? <p className="bk-store__desc">{t.description}</p> : null}
                <p className="bk-store__meta">
                  v{t.version}
                  {t.hasContent ? (t.contentInstalled ? ' · pages added' : ' · includes pages') : ''}
                  {t.installed && t.installedVersion !== t.version ? ` · installed v${t.installedVersion}` : ''}
                  {t.tags.length ? ` · ${t.tags.join(' · ')}` : ''}
                </p>
                <div className="bk-store__actions">
                  {action(t)}
                  {t.demoUrl ? (
                    <a className="bk-store__demo" href={t.demoUrl} target="_blank" rel="noreferrer">
                      Live demo ↗
                    </a>
                  ) : null}
                </div>
                {t.licence && !t.free ? (
                  <div className="bk-store__licence">
                    <p className="bk-store__licence-head">
                      Licence · {t.licence.sites.length} of {t.licence.limit} sites
                      {t.licence.buyer ? <span> · {t.licence.buyer}</span> : null}
                    </p>
                    <ul className="bk-store__slots">
                      {(['local', 'staging', 'production'] as const).map((env) => {
                        const site = t.licence?.sites.find((x) => x.environment === env);
                        return (
                          <li key={env} className={`bk-store__slot${site ? ' is-used' : ''}${site?.current ? ' is-current' : ''}`}>
                            <strong>{ENV_LABEL[env]}</strong>
                            <span>{site ? `${site.domain ?? 'unknown address'}${site.current ? ' (this site)' : ''}` : 'Free'}</span>
                          </li>
                        );
                      })}
                    </ul>
                    {t.licence.message ? <p className="bk-store__note is-warning">{t.licence.message}</p> : null}
                  </div>
                ) : null}
                {t.pending && !t.owned ? (
                  <p className="bk-store__note">996Agency unlocks this theme as soon as your payment is confirmed.</p>
                ) : null}
              </div>
            </li>
          ))}
        </ul>
      ) : null}

      <p className="bk-store__foot">
        Layouts in a theme are imported from Backend Fields — after installing, open <strong>Field Groups</strong> and use <strong>Sync</strong>.
      </p>
    </div>
  );
}
