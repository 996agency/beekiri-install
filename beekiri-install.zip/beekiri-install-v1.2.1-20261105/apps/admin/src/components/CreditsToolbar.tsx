import { useCallback, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Coins } from '@phosphor-icons/react';
import { api } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { useAdminHref } from '../lib/AdminEntryContext';
import { BEEQUEEN_CREDITS, CONNECTOR_CHANGED, type BeeQueenCreditsDetail } from '../lib/admin-events';
import { CONNECTOR_COMING_SOON } from '../lib/features';
import './credits-toolbar.css';

type Status = { credits?: { enabled: boolean; balance?: number; granted?: number } };

const num = (v: unknown, fallback = 0) => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);

/**
 * Toolbar: this site's BeeQueen credits ("1,940 / 2,000"), and while BeeQueen works,
 * what the current run has spent so far.
 */
export function CreditsToolbar() {
  const auth = useAuth();
  const href = useAdminHref();
  const allowed =
    !CONNECTOR_COMING_SOON && Boolean(auth.user?.isOwner || auth.user?.capabilities.includes('use_beequeen'));
  const canManage = Boolean(auth.user?.isOwner || auth.user?.capabilities.includes('manage_options'));
  const [credits, setCredits] = useState<{ balance: number; granted: number } | null>(null);
  const [run, setRun] = useState<{ running: boolean; spent: number } | null>(null);
  const fadeRef = useRef<number | null>(null);

  const load = useCallback(() => {
    if (!allowed) return;
    api<Status>('/api/connector/beequeen/status')
      .then((s) => {
        // Tolerates an older server that sends no total: the balance stands in for it.
        const c = s.credits;
        if (!c?.enabled) return setCredits(null);
        const balance = num(c.balance);
        setCredits({ balance, granted: Math.max(num(c.granted, balance), balance) });
      })
      .catch(() => setCredits(null));
  }, [allowed]);

  useEffect(() => {
    load();
    window.addEventListener(CONNECTOR_CHANGED, load);
    return () => window.removeEventListener(CONNECTOR_CHANGED, load);
  }, [load]);

  useEffect(() => {
    const onCredits = (e: Event) => {
      const d = (e as CustomEvent<BeeQueenCreditsDetail>).detail;
      if (typeof d.balance === 'number') {
        const balance = d.balance;
        setCredits((c) => ({ balance, granted: Math.max(num(d.granted, c?.granted ?? balance), balance) }));
      }
      if (fadeRef.current) window.clearTimeout(fadeRef.current);
      setRun({ running: d.running, spent: num(d.runCredits) });
      // Keep "spent" in view for a moment after the run, then settle back to the balance.
      if (!d.running) {
        fadeRef.current = window.setTimeout(() => setRun(null), 8000);
        load();
      }
    };
    window.addEventListener(BEEQUEEN_CREDITS, onCredits);
    return () => {
      window.removeEventListener(BEEQUEEN_CREDITS, onCredits);
      if (fadeRef.current) window.clearTimeout(fadeRef.current);
    };
  }, [load]);

  if (!credits) return null;

  const low = credits.balance <= 0 || (credits.granted > 0 && credits.balance / credits.granted < 0.1);
  const pct = credits.granted > 0 ? Math.max(0, Math.min(100, (credits.balance / credits.granted) * 100)) : 0;
  const body = (
    <>
      <Coins size={14} aria-hidden className="bk-credits__icon" />
      <span className="bk-credits__label">BeeQueen</span>
      <span className="bk-credits__value">
        <strong>{credits.balance.toLocaleString()}</strong>
        <span className="bk-credits__total"> / {credits.granted.toLocaleString()}</span>
      </span>
      <span className="bk-credits__bar" aria-hidden>
        <span style={{ width: `${pct}%` }} />
      </span>
      {run ? (
        <span className={`bk-credits__run${run.running ? ' is-live' : ''}`} aria-live="polite">
          {run.running ? (run.spent ? `−${run.spent.toLocaleString()} so far` : 'working…') : `−${run.spent.toLocaleString()} this run`}
        </span>
      ) : null}
    </>
  );
  const title = `${credits.balance.toLocaleString()} of ${credits.granted.toLocaleString()} BeeQueen credits left`;
  const className = `bk-credits${low ? ' is-low' : ''}${run?.running ? ' is-running' : ''}`;

  return canManage ? (
    <Link to={href('connector')} className={className} title={`${title} — packs and usage`}>
      {body}
    </Link>
  ) : (
    <span className={className} title={title}>
      {body}
    </span>
  );
}
