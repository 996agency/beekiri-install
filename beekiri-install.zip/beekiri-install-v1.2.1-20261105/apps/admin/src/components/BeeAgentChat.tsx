import { Fragment, useEffect, useRef, useState, type KeyboardEvent, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Link } from 'react-router-dom';
import {
  ArrowSquareOut,
  ArrowUp,
  CaretDown,
  CheckCircle,
  Coins,
  ClockCounterClockwise,
  FileCode,
  Layout,
  NotePencil,
  Plus,
  Stop,
  Trash,
  WarningCircle,
  X,
} from '@phosphor-icons/react';
import { useAuth } from '../auth/AuthContext';
import { useAdminHref } from '../lib/AdminEntryContext';
import { CubeBee } from './CubeBee';
import type { BeeQueenStatus } from './BeeAgentWidget';
import type { BeeLink, BeeMessage, useBeeQueenChat } from './useBeeQueenChat';
import './bee-agent-chat.css';
import { safeHref } from '../lib/safe-html';

type Props = {
  open: boolean;
  agentName: string;
  /** e.g. "Claude Opus 5.5 · Max effort" */
  engineLabel: string;
  credits: BeeQueenStatus['credits'];
  chat: ReturnType<typeof useBeeQueenChat>;
  onClose: () => void;
};

const SUGGESTIONS = [
  'Create a full About Us landing page',
  'Build a testimonials section editors can fill in',
  'Make a pricing section with three plans',
  'Review my layouts and make the hero feel more premium',
];

/** "3m ago", "Yesterday", "Oct 12" — for the chat history list. */
function when(iso: string): string {
  const then = new Date(iso);
  const mins = Math.round((Date.now() - then.getTime()) / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  if (mins < 60 * 24) return `${Math.round(mins / 60)}h ago`;
  if (mins < 60 * 48) return 'Yesterday';
  return then.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

/** **bold** and `code` inside one line of text. */
function inline(text: string): ReactNode[] {
  return text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**') && part.length > 4) return <strong key={i}>{part.slice(2, -2)}</strong>;
    if (part.startsWith('`') && part.endsWith('`') && part.length > 2) return <code key={i}>{part.slice(1, -1)}</code>;
    return <Fragment key={i}>{part}</Fragment>;
  });
}

/** Small markdown subset for replies: paragraphs, headings, bullet and numbered lists. */
function RichText({ text }: { text: string }) {
  const blocks: ReactNode[] = [];
  const lines = text.replace(/\r/g, '').split('\n');
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) {
      i++;
      continue;
    }
    const bullet = /^\s*[-*•]\s+/;
    const numbered = /^\s*\d+[.)]\s+/;
    if (bullet.test(line) || numbered.test(line)) {
      const ordered = numbered.test(line);
      const re = ordered ? numbered : bullet;
      const items: string[] = [];
      while (i < lines.length && re.test(lines[i])) items.push(lines[i++].replace(re, ''));
      const ListTag = ordered ? 'ol' : 'ul';
      blocks.push(
        <ListTag key={blocks.length}>
          {items.map((item, k) => (
            <li key={k}>{inline(item)}</li>
          ))}
        </ListTag>,
      );
      continue;
    }
    const heading = line.match(/^#{1,4}\s+(.*)$/);
    if (heading) {
      blocks.push(
        <p key={blocks.length} className="bk-bee-chat__h">
          {inline(heading[1])}
        </p>,
      );
      i++;
      continue;
    }
    const para: string[] = [];
    while (i < lines.length && lines[i].trim() && !bullet.test(lines[i]) && !numbered.test(lines[i]) && !/^#{1,4}\s/.test(lines[i])) {
      para.push(lines[i++]);
    }
    blocks.push(<p key={blocks.length}>{inline(para.join(' '))}</p>);
  }
  return <>{blocks}</>;
}

function LinkChip({ link, onNavigate }: { link: BeeLink; onNavigate: () => void }) {
  const href = useAdminHref();
  const Icon = link.kind === 'page' ? NotePencil : link.kind === 'layout' ? Layout : FileCode;
  const kind = link.kind === 'page' ? 'Page' : link.kind === 'layout' ? 'Layout' : 'Theme file';
  return (
    <span className="bk-bee-chat__link">
      <Icon size={15} aria-hidden />
      <span className="bk-bee-chat__link-text">
        <small>{kind}</small>
        {link.label}
      </span>
      {link.admin ? (
        <Link to={href(link.admin)} onClick={onNavigate} className="bk-bee-chat__link-action">
          {link.kind === 'page' ? 'Edit' : 'Open'}
        </Link>
      ) : null}
      {link.url ? (
        <a href={safeHref(link.url)} target="_blank" rel="noreferrer" className="bk-bee-chat__link-action" aria-label={`View ${link.label}`}>
          View <ArrowSquareOut size={12} aria-hidden />
        </a>
      ) : null}
    </span>
  );
}

function AssistantMessage({
  message,
  onNavigate,
  canManage,
}: {
  message: BeeMessage;
  onNavigate: () => void;
  canManage: boolean;
}) {
  const href = useAdminHref();
  const [showSteps, setShowSteps] = useState(false);
  const steps = message.steps ?? [];
  const running = message.state === 'running';
  const current = steps[steps.length - 1];

  return (
    <div className={`bk-bee-chat__msg is-assistant is-${message.state ?? 'done'}`}>
      <span className="bk-bee-chat__avatar" aria-hidden>
        <span className="bk-bee-chat__scene">
          <CubeBee brand="beequeen" />
        </span>
      </span>
      <div className="bk-bee-chat__body">
        {running ? (
          <div className="bk-bee-chat__live" aria-live="polite">
            <ol className="bk-bee-chat__steps">
              {steps.slice(-6).map((s, i, arr) => (
                <li key={steps.length - arr.length + i} className={`is-${s.kind}${i === arr.length - 1 ? ' is-current' : ''}`}>
                  {s.text}
                </li>
              ))}
            </ol>
            <p className="bk-bee-chat__thinking">
              <span className="bk-bee-chat__spinner" aria-hidden />
              {current?.kind === 'status' ? `${current.text}…` : 'Thinking…'}
            </p>
          </div>
        ) : (
          <>
            {message.state === 'error' ? (
              <div className="bk-bee-chat__error">
                <WarningCircle size={16} weight="fill" aria-hidden />
                <span>{message.text}</span>
                {message.needsCredits && canManage ? (
                  <Link to={href('connector')} onClick={onNavigate} className="bk-bee-chat__link-action">
                    Get credits
                  </Link>
                ) : null}
              </div>
            ) : (
              <div className="bk-bee-chat__text">
                <RichText text={message.text} />
              </div>
            )}
            {message.links?.length ? (
              <div className="bk-bee-chat__links">
                {message.links.map((l) => (
                  <LinkChip key={`${l.kind}:${l.label}`} link={l} onNavigate={onNavigate} />
                ))}
              </div>
            ) : null}
            {steps.length || message.credits ? (
              <div className="bk-bee-chat__trace">
                <button
                  type="button"
                  className="bk-bee-chat__trace-toggle"
                  aria-expanded={showSteps}
                  onClick={() => setShowSteps((v) => !v)}
                >
                  {message.state === 'done' ? <CheckCircle size={13} weight="fill" aria-hidden /> : null}
                  {steps.filter((s) => s.kind === 'status').length} steps
                  <CaretDown size={11} aria-hidden className={showSteps ? 'is-open' : ''} />
                </button>
                {message.credits ? (
                  <span className="bk-bee-chat__cost" title="Credits this run used">
                    <Coins size={12} aria-hidden /> {message.credits.toLocaleString()} credits
                  </span>
                ) : null}
                {showSteps ? (
                  <ol className="bk-bee-chat__steps is-done">
                    {steps.map((s, i) => (
                      <li key={i} className={`is-${s.kind}`}>
                        {s.text}
                      </li>
                    ))}
                  </ol>
                ) : null}
              </div>
            ) : null}
          </>
        )}
      </div>
    </div>
  );
}

/** BeeQueen chat — Claude builds layouts, Backend Fields and pages inside the active theme. */
export function BeeAgentChat({ open, agentName, engineLabel, credits, chat, onClose }: Props) {
  const href = useAdminHref();
  const auth = useAuth();
  const canManage = Boolean(auth.user?.isOwner || auth.user?.capabilities.includes('manage_options'));
  const [draft, setDraft] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const [showHistory, setShowHistory] = useState(false);
  const { messages, running, loading, send, stop, newChat, openChat, deleteChat, chats, chatId, load } = chat;
  const lastSteps = messages[messages.length - 1]?.steps?.length ?? 0;

  useEffect(() => {
    if (open) void load();
  }, [open, load]);

  useEffect(() => {
    if (!open) return;
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [open, messages.length, lastSteps, running]);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  useEffect(() => {
    const el = inputRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 180)}px`;
  }, [draft]);

  if (!open || typeof document === 'undefined') return null;

  const submit = (text = draft) => {
    if (!text.trim() || running) return;
    void send(text);
    setDraft('');
  };

  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      submit();
    }
  };

  return createPortal(
    <div
      className="bk-bee-chat"
      role="dialog"
      aria-modal="true"
      aria-label={`${agentName} assistant`}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bk-bee-chat__panel">
        <div className="bk-bee-chat__bar">
          <div className="bk-bee-chat__titles">
            <strong>{agentName}</strong>
            <span className="bk-bee-chat__engine">
              <img src="/admin/connector/claude.svg" alt="" width={12} height={12} draggable={false} />
              {engineLabel}
            </span>
          </div>
          <div className="bk-bee-chat__bar-actions">
            {credits.enabled ? (
              canManage ? (
                <Link
                  to={href('connector')}
                  onClick={onClose}
                  className={`bk-bee-chat__balance${credits.balance <= 0 ? ' is-low' : ''}`}
                  title="This site’s BeeQueen credits — packs and usage"
                >
                  <Coins size={14} aria-hidden /> {credits.balance.toLocaleString()}
                  {typeof chat.runCredits === 'number' ? (
                    <span className={`bk-bee-chat__spend${running ? ' is-live' : ''}`}>
                      {running && chat.runCredits === 0 ? '…' : `−${chat.runCredits.toLocaleString()}`}
                    </span>
                  ) : null}
                </Link>
              ) : (
                <span
                  className={`bk-bee-chat__balance${credits.balance <= 0 ? ' is-low' : ''}`}
                  title="This site’s BeeQueen credits"
                >
                  <Coins size={14} aria-hidden /> {credits.balance.toLocaleString()}
                  {typeof chat.runCredits === 'number' ? (
                    <span className={`bk-bee-chat__spend${running ? ' is-live' : ''}`}>
                      {running && chat.runCredits === 0 ? '…' : `−${chat.runCredits.toLocaleString()}`}
                    </span>
                  ) : null}
                </span>
              )
            ) : null}
            <button
              type="button"
              className={`bk-bee-chat__ghost${showHistory ? ' is-active' : ''}`}
              aria-expanded={showHistory}
              onClick={() => setShowHistory((v) => !v)}
              title="Your earlier chats"
            >
              <ClockCounterClockwise size={15} aria-hidden /> History
            </button>
            {messages.length ? (
              <button
                type="button"
                className="bk-bee-chat__ghost"
                onClick={newChat}
                disabled={running}
                title="Start a new chat"
              >
                <Plus size={15} aria-hidden /> New chat
              </button>
            ) : null}
            <button type="button" className="bk-bee-chat__close" aria-label="Close" onClick={onClose}>
              <X size={18} weight="regular" aria-hidden />
            </button>
          </div>
        </div>

        <div className="bk-bee-chat__body-wrap">
        {showHistory ? (
          <aside className="bk-bee-chat__history" aria-label="Chat history">
            {chats.length === 0 ? (
              <p className="bk-bee-chat__history-empty">No saved chats yet.</p>
            ) : (
              <ul>
                {chats.map((c) => (
                  <li key={c.id} className={c.id === chatId ? 'is-current' : ''}>
                    <button
                      type="button"
                      className="bk-bee-chat__history-open"
                      disabled={running}
                      onClick={() => {
                        void openChat(c.id);
                        if (window.matchMedia('(max-width: 640px)').matches) setShowHistory(false);
                      }}
                    >
                      <span>{c.title || 'Untitled chat'}</span>
                      <small>{when(c.updatedAt)}</small>
                    </button>
                    <button
                      type="button"
                      className="bk-bee-chat__history-delete"
                      aria-label={`Delete “${c.title}”`}
                      title="Delete chat"
                      disabled={running && c.id === chatId}
                      onClick={() => {
                        if (window.confirm(`Delete “${c.title || 'this chat'}”? This can't be undone.`)) void deleteChat(c.id);
                      }}
                    >
                      <Trash size={14} aria-hidden />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </aside>
        ) : null}
        <div className="bk-bee-chat__scroll" ref={scrollRef}>
          {loading ? (
            <p className="bk-bee-chat__loading">
              <span className="bk-bee-chat__spinner" aria-hidden /> Opening chat…
            </p>
          ) : messages.length === 0 ? (
            <div className="bk-bee-chat__empty">
              <span className="bk-bee-chat__hero" aria-hidden>
                <span className="bk-bee-chat__scene">
                  <CubeBee brand="beequeen" />
                </span>
              </span>
              <h2>What should we build?</h2>
              <p>
                BeeQueen designs sections for your theme, adds their Backend Fields, and assembles pages you can
                keep editing in the page editor.
              </p>
              <div className="bk-bee-chat__suggestions">
                {SUGGESTIONS.map((s) => (
                  <button key={s} type="button" onClick={() => submit(s)}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((m) =>
              m.role === 'user' ? (
                <div key={m.id} className="bk-bee-chat__msg is-user">
                  <div className="bk-bee-chat__bubble">{m.text}</div>
                </div>
              ) : (
                <AssistantMessage key={m.id} message={m} onNavigate={onClose} canManage={canManage} />
              ),
            )
          )}
        </div>
        </div>

        <form
          className="bk-bee-chat__composer"
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
        >
          <textarea
            ref={inputRef}
            rows={1}
            value={draft}
            placeholder={running ? `${agentName} is working…` : `Ask ${agentName} to build or change something`}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={onKeyDown}
            aria-label={`Message ${agentName}`}
          />
          {running ? (
            <button type="button" className="bk-bee-chat__send is-stop" onClick={stop} aria-label="Stop">
              <Stop size={16} weight="fill" aria-hidden />
            </button>
          ) : (
            <button type="submit" className="bk-bee-chat__send" disabled={!draft.trim()} aria-label="Send">
              <ArrowUp size={16} weight="bold" aria-hidden />
            </button>
          )}
        </form>
        <p className="bk-bee-chat__hint">
          Works only inside your theme, Backend Fields and pages. New pages are saved as drafts.
        </p>
      </div>
    </div>,
    document.body,
  );
}
