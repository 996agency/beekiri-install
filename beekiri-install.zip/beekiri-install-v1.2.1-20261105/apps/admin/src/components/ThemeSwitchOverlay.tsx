import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { CheckCircle, WarningCircle } from '@phosphor-icons/react';
import './theme-switch-overlay.css';

type Phase = 'working' | 'done' | 'error';
type State = { name: string; phase: Phase; detail: string };

const STEPS = [
  'Saving your current pages and menu',
  'Bringing in the theme’s pages',
  'Restoring its menu, header and footer',
  'Refreshing the website',
];

/** The bar stays up at least this long, so a fast switch still reads as a step. */
const MIN_MS = 1400;

/**
 * Progress overlay for switching themes. `run(name, task)` shows a filling bar with the steps,
 * then "We've switched your theme". The task returns the success detail, or throws.
 */
export function useThemeSwitch(siteHref: string): {
  overlay: ReactNode;
  run: (name: string, task: () => Promise<string>) => Promise<boolean>;
} {
  const [state, setState] = useState<State | null>(null);

  const run = useCallback(async (name: string, task: () => Promise<string>) => {
    setState({ name, phase: 'working', detail: '' });
    const started = Date.now();
    try {
      const detail = await task();
      await new Promise((r) => setTimeout(r, Math.max(0, MIN_MS - (Date.now() - started))));
      setState({ name, phase: 'done', detail });
      return true;
    } catch (e) {
      setState({ name, phase: 'error', detail: e instanceof Error ? e.message : 'Something went wrong.' });
      return false;
    }
  }, []);

  return {
    overlay: state ? <ThemeSwitchOverlay {...state} siteHref={siteHref} onClose={() => setState(null)} /> : null,
    run,
  };
}

function ThemeSwitchOverlay({ name, phase, detail, siteHref, onClose }: State & { siteHref: string; onClose: () => void }) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (phase !== 'working') return;
    setStep(0);
    const id = window.setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 700);
    return () => window.clearInterval(id);
  }, [phase]);

  useEffect(() => {
    if (phase === 'working') return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === 'Enter') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [phase, onClose]);

  if (typeof document === 'undefined') return null;

  return createPortal(
    <div className="bk-switch" role="dialog" aria-modal="true" aria-labelledby="bk-switch-title">
      <div className={`bk-switch__card is-${phase}`}>
        {phase === 'working' ? (
          <>
            <h2 id="bk-switch-title" className="bk-switch__title">
              Switching to {name}…
            </h2>
            <div className="bk-switch__bar" role="progressbar" aria-label={`Switching to ${name}`} aria-busy="true">
              <span className="bk-switch__fill" />
            </div>
            <p className="bk-switch__step" aria-live="polite">
              {STEPS[step]}
            </p>
          </>
        ) : phase === 'done' ? (
          <>
            <CheckCircle className="bk-switch__icon" size={36} weight="fill" aria-hidden />
            <h2 id="bk-switch-title" className="bk-switch__title">
              We’ve switched your theme to {name}
            </h2>
            <div className="bk-switch__bar" aria-hidden>
              <span className="bk-switch__fill is-full" />
            </div>
            <p className="bk-switch__step">{detail}</p>
            <div className="bk-switch__actions">
              <a className="button" href={siteHref} target="_blank" rel="noreferrer">
                View site
              </a>
              <button type="button" className="button button-primary" onClick={onClose} autoFocus>
                Done
              </button>
            </div>
          </>
        ) : (
          <>
            <WarningCircle className="bk-switch__icon is-error" size={36} weight="fill" aria-hidden />
            <h2 id="bk-switch-title" className="bk-switch__title">
              Couldn’t switch to {name}
            </h2>
            <p className="bk-switch__step">{detail} Your site is still on the previous theme.</p>
            <div className="bk-switch__actions">
              <button type="button" className="button button-primary" onClick={onClose} autoFocus>
                Close
              </button>
            </div>
          </>
        )}
      </div>
    </div>,
    document.body,
  );
}
