import { useCallback, useEffect, useState } from 'react';
import { api } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { CONNECTOR_CHANGED } from '../lib/admin-events';
import { CONNECTOR_COMING_SOON } from '../lib/features';
import { BeeAgentChat } from './BeeAgentChat';
import { CubeBee } from './CubeBee';
import { useBeeQueenChat } from './useBeeQueenChat';
import './bee-agent-widget.css';

export type BeeQueenStatus = {
  available: boolean;
  reason: string;
  engine: 'service' | 'api' | 'claude-code' | null;
  model: string | null;
  effort: string | null;
  /** This site's BeeQueen credits, when it runs on the BeeQueen service. */
  credits: { enabled: true; balance: number; currency: string } | { enabled: false };
};

const MODEL_LABELS: Record<string, string> = {
  'claude-opus-5-5': 'Claude Opus 5.5',
  'claude-sonnet-5-5': 'Claude Sonnet 5.5',
  'claude-haiku-5-5': 'Claude Haiku 5.5',
  'claude-fable-5-1': 'Claude Fable 5.1',
};

const EFFORT_LABELS: Record<string, string> = {
  low: 'Low effort',
  medium: 'Medium effort',
  high: 'High effort',
  xhigh: 'Extra-high effort',
  max: 'Max effort',
};

/**
 * Floating Beekiri bee — shows for anyone allowed to use BeeQueen once she is switched on.
 * Hidden until hover (same pattern as Cookie settings reopen); click opens BeeQueen.
 */
export function BeeAgentWidget() {
  const auth = useAuth();
  const allowed =
    !CONNECTOR_COMING_SOON && Boolean(auth.user?.isOwner || auth.user?.capabilities.includes('use_beequeen'));
  const [status, setStatus] = useState<BeeQueenStatus | null>(null);
  const [open, setOpen] = useState(false);
  const chat = useBeeQueenChat();

  const load = useCallback(() => {
    if (!allowed) return;
    api<BeeQueenStatus>('/api/connector/beequeen/status')
      .then(setStatus)
      .catch(() => setStatus(null));
  }, [allowed]);

  useEffect(() => {
    load();
    window.addEventListener(CONNECTOR_CHANGED, load);
    return () => window.removeEventListener(CONNECTOR_CHANGED, load);
  }, [load]);

  // A finished run reports the new balance; keep the header in step without refetching.
  useEffect(() => {
    if (chat.balance === null) return;
    setStatus((s) => (s && s.credits?.enabled ? { ...s, credits: { ...s.credits, balance: chat.balance! } } : s));
  }, [chat.balance]);

  const shown = Boolean(status?.available);

  useEffect(() => {
    document.body.classList.toggle('bk-has-bee-agent', shown);
    return () => document.body.classList.remove('bk-has-bee-agent');
  }, [shown]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  if (!shown || !status) return null;

  // An older server may not send credits yet; treat that as "no credits shown".
  const credits: BeeQueenStatus['credits'] =
    status.credits?.enabled && typeof status.credits.balance === 'number' ? status.credits : { enabled: false };

  const engineLabel =
    [
      MODEL_LABELS[status.model ?? ''] ?? status.model,
      EFFORT_LABELS[status.effort ?? ''],
      status.engine === 'claude-code' ? 'via Claude Code on this Mac' : '',
    ]
      .filter(Boolean)
      .join(' · ') || 'Claude';

  return (
    <>
      {/* Hidden while chat is open — same idea as Cookie settings reopen */}
      {!open ? (
        <button
          type="button"
          className={`bk-bee-agent is-beequeen${chat.running ? ' is-working' : ''}`}
          aria-label="Open BeeQueen"
          title="BeeQueen"
          onClick={() => setOpen(true)}
        >
          <span className="bk-bee-agent__hint" aria-hidden>
            <span className="bk-bee-agent__dot" />
            <span className="bk-bee-agent__reveal">
              <span className="bk-bee-agent__scene">
                <CubeBee brand="beequeen" />
              </span>
              <span className="bk-bee-agent__tip">BeeQueen</span>
            </span>
          </span>
        </button>
      ) : null}

      <BeeAgentChat
        open={open}
        agentName="BeeQueen"
        engineLabel={engineLabel}
        credits={credits}
        chat={chat}
        onClose={() => setOpen(false)}
      />
    </>
  );
}
