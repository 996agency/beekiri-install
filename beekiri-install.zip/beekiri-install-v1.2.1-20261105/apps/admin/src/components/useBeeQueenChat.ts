import { useCallback, useEffect, useRef, useState } from 'react';
import { api, API_BASE, getCsrfToken } from '../api/client';
import { notifyBeeQueenCredits } from '../lib/admin-events';

export type BeeLink = { kind: 'layout' | 'page' | 'file'; label: string; admin?: string; url?: string };

export type BeeStep = { kind: 'status' | 'note'; text: string };

export type BeeMessage = {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  steps?: BeeStep[];
  links?: BeeLink[];
  state?: 'running' | 'done' | 'error' | 'stopped';
  model?: string | null;
  /** Credits this run cost (pay-as-you-go). */
  credits?: number;
  /** The run could not start because the account is out of credits. */
  needsCredits?: boolean;
};

export type BeeChatSummary = { id: string; title: string; updatedAt: string };

type BeeEvent =
  | { type: 'chat'; chatId: string; title: string }
  | { type: 'status'; text: string }
  | { type: 'note'; text: string }
  | { type: 'done'; reply: string; links: BeeLink[]; model: string }
  | { type: 'error'; message: string; needsCredits?: boolean }
  | { type: 'charge'; credits: number; balance: number; granted?: number; final?: boolean };

class StartError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
  }
}

/** Which chat to reopen in this browser (the chats themselves live on the server). */
const LAST_CHAT_KEY = 'bk-beequeen-last-chat';

const uid = () => Math.random().toString(36).slice(2, 10);

function readLastChat(): string | null {
  try {
    return localStorage.getItem(LAST_CHAT_KEY);
  } catch {
    return null;
  }
}

function writeLastChat(id: string | null) {
  try {
    if (id) localStorage.setItem(LAST_CHAT_KEY, id);
    else localStorage.removeItem(LAST_CHAT_KEY);
  } catch {
    /* storage blocked — the chat still works, it just won't reopen by itself */
  }
}

async function readError(res: Response): Promise<string> {
  try {
    const data = (await res.json()) as { message?: unknown };
    if (Array.isArray(data.message)) return data.message.map(String).join(' ');
    if (data.message) return String(data.message);
  } catch {
    /* not JSON */
  }
  return res.statusText || 'BeeQueen could not start.';
}

/**
 * BeeQueen conversations, saved on the server per user. Lives in the floating widget,
 * so closing the chat keeps a run going until it finishes or is stopped.
 */
export function useBeeQueenChat() {
  const [chatId, setChatId] = useState<string | null>(readLastChat);
  const [messages, setMessages] = useState<BeeMessage[]>([]);
  const [chats, setChats] = useState<BeeChatSummary[]>([]);
  const [running, setRunning] = useState(false);
  const [loading, setLoading] = useState(false);
  /** Latest balance reported by a billed run (null until one is). */
  const [balance, setBalance] = useState<number | null>(null);
  /** Credits the current (or last) run has used — counts up while BeeQueen works. */
  const [runCredits, setRunCredits] = useState<number | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const loadedRef = useRef<string | null>(null);

  useEffect(() => () => abortRef.current?.abort(), []);

  const refreshChats = useCallback(async () => {
    try {
      const res = await api<{ chats: BeeChatSummary[] }>('/api/connector/chats');
      setChats(res.chats ?? []);
    } catch {
      /* the list is a convenience; the current chat still works */
    }
  }, []);

  const openChat = useCallback(async (id: string) => {
    if (abortRef.current) return;
    setLoading(true);
    try {
      const res = await api<{ id: string; messages: BeeMessage[] }>(`/api/connector/chats/${encodeURIComponent(id)}`);
      setMessages(res.messages ?? []);
      setChatId(res.id);
      loadedRef.current = res.id;
      writeLastChat(res.id);
    } catch {
      // Deleted elsewhere or no longer ours — start fresh.
      setMessages([]);
      setChatId(null);
      loadedRef.current = null;
      writeLastChat(null);
    } finally {
      setLoading(false);
    }
  }, []);

  /** First open: list the chats and bring back the one this browser used last. */
  const load = useCallback(async () => {
    void refreshChats();
    if (chatId && loadedRef.current !== chatId && !abortRef.current) await openChat(chatId);
  }, [chatId, openChat, refreshChats]);

  const patch = useCallback((id: string, update: (m: BeeMessage) => BeeMessage) => {
    setMessages((list) => list.map((m) => (m.id === id ? update(m) : m)));
  }, []);

  const send = useCallback(
    async (raw: string) => {
      const prompt = raw.trim();
      if (!prompt || running) return;
      const replyId = uid();
      setMessages((list) => [
        ...list,
        { id: uid(), role: 'user', text: prompt },
        { id: replyId, role: 'assistant', text: '', steps: [], state: 'running' },
      ]);
      setRunning(true);
      notifyBeeQueenCredits({ running: true, runCredits: 0 });
      setRunCredits(0);
      let runCredits = 0;

      const abort = new AbortController();
      abortRef.current = abort;
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      const csrf = getCsrfToken();
      if (csrf) headers['X-CSRF-Token'] = csrf;

      const apply = (event: BeeEvent) => {
        if (event.type === 'chat') {
          setChatId(event.chatId);
          loadedRef.current = event.chatId;
          writeLastChat(event.chatId);
          setChats((list) => [
            { id: event.chatId, title: event.title, updatedAt: new Date().toISOString() },
            ...list.filter((c) => c.id !== event.chatId),
          ]);
        } else if (event.type === 'status' || event.type === 'note') {
          patch(replyId, (m) => ({ ...m, steps: [...(m.steps ?? []), { kind: event.type, text: event.text }] }));
        } else if (event.type === 'charge') {
          if (typeof event.credits !== 'number' || typeof event.balance !== 'number') return;
          runCredits = event.credits;
          setRunCredits(event.credits);
          setBalance(event.balance);
          patch(replyId, (m) => ({ ...m, credits: event.credits }));
          notifyBeeQueenCredits({
            balance: event.balance,
            granted: event.granted,
            running: !event.final,
            runCredits: event.credits,
          });
        } else if (event.type === 'done') {
          patch(replyId, (m) => ({ ...m, text: event.reply, links: event.links, model: event.model, state: 'done' }));
        } else {
          patch(replyId, (m) => ({ ...m, text: event.message, state: 'error', needsCredits: Boolean(event.needsCredits) }));
        }
      };

      try {
        const res = await fetch(`${API_BASE}/api/connector/agent`, {
          method: 'POST',
          headers,
          credentials: 'include',
          body: JSON.stringify(chatId ? { prompt, chatId } : { prompt }),
          signal: abort.signal,
        });
        if (!res.ok || !res.body) throw new StartError(await readError(res), res.status);

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        for (;;) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          let nl = buffer.indexOf('\n');
          while (nl >= 0) {
            const line = buffer.slice(0, nl).trim();
            buffer = buffer.slice(nl + 1);
            if (line) apply(JSON.parse(line) as BeeEvent);
            nl = buffer.indexOf('\n');
          }
        }
        if (buffer.trim()) apply(JSON.parse(buffer) as BeeEvent);
        // The stream ended without a verdict (server restarted, connection dropped).
        patch(replyId, (m) =>
          m.state === 'running' ? { ...m, text: 'The connection closed before BeeQueen finished.', state: 'error' } : m,
        );
      } catch (error) {
        const stopped = abort.signal.aborted;
        patch(replyId, (m) => ({
          ...m,
          text: stopped ? m.text || 'Stopped.' : error instanceof Error ? error.message : 'BeeQueen stopped.',
          state: stopped ? 'stopped' : 'error',
          needsCredits: error instanceof StartError && error.status === 402,
        }));
      } finally {
        if (abortRef.current === abort) abortRef.current = null;
        setRunning(false);
        notifyBeeQueenCredits({ running: false, runCredits });
      }
    },
    [chatId, patch, running],
  );

  const stop = useCallback(() => abortRef.current?.abort(), []);

  const newChat = useCallback(() => {
    if (abortRef.current) return;
    setMessages([]);
    setChatId(null);
    loadedRef.current = null;
    writeLastChat(null);
  }, []);

  const deleteChat = useCallback(
    async (id: string) => {
      await api(`/api/connector/chats/${encodeURIComponent(id)}`, { method: 'DELETE' });
      setChats((list) => list.filter((c) => c.id !== id));
      if (id === chatId) newChat();
    },
    [chatId, newChat],
  );

  return { chatId, messages, chats, running, loading, balance, runCredits, load, send, stop, newChat, openChat, deleteChat };
}
