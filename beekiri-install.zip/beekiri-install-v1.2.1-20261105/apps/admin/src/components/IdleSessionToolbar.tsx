import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { useAdminEntry } from '../lib/AdminEntryContext';
import {
  IDLE_TIMEOUT_MS,
  IDLE_WARN_MS,
  formatIdleCountdown,
  idleAnnounceIntervalMs,
} from '../lib/idle-session';

const ACTIVITY_EVENTS: (keyof DocumentEventMap)[] = [
  'pointerdown',
  'keydown',
  'mousemove',
  'wheel',
  'touchstart',
  'scroll',
];

/**
 * Toolbar countdown when the admin tab has been idle nearly 20 minutes.
 * Activity or “Stay signed in” resets the timer; timeout signs the user out.
 */
export function IdleSessionToolbar() {
  const auth = useAuth();
  const entry = useAdminEntry();
  const navigate = useNavigate();
  const [remainingMs, setRemainingMs] = useState(IDLE_TIMEOUT_MS);
  const [announce, setAnnounce] = useState('');
  const lastActivityRef = useRef(Date.now());
  const lastBumpAtRef = useRef(0);
  const timedOutRef = useRef(false);
  const lastAnnounceAtRef = useRef(0);
  const warningShownRef = useRef(false);

  const bump = useCallback(() => {
    lastActivityRef.current = Date.now();
    timedOutRef.current = false;
    warningShownRef.current = false;
  }, []);

  const staySignedIn = useCallback(() => {
    bump();
    setRemainingMs(IDLE_TIMEOUT_MS);
    setAnnounce('Session extended. You will stay signed in.');
    lastAnnounceAtRef.current = Date.now();
    void auth.refresh().catch(() => {
      /* local timer still reset */
    });
  }, [auth, bump]);

  useEffect(() => {
    if (!auth.authenticated) return;

    const onActivity = () => {
      const now = Date.now();
      if (now - lastBumpAtRef.current < 800) return;
      lastBumpAtRef.current = now;
      const idleFor = now - lastActivityRef.current;
      const wasWarning = idleFor >= IDLE_TIMEOUT_MS - IDLE_WARN_MS;
      bump();
      if (wasWarning) {
        setRemainingMs(IDLE_TIMEOUT_MS);
        setAnnounce('Session extended. You will stay signed in.');
        lastAnnounceAtRef.current = now;
        void auth.refresh().catch(() => undefined);
      }
    };

    for (const ev of ACTIVITY_EVENTS) {
      document.addEventListener(ev, onActivity, { capture: true, passive: true });
    }

    const tick = window.setInterval(() => {
      if (timedOutRef.current) return;
      const left = IDLE_TIMEOUT_MS - (Date.now() - lastActivityRef.current);
      setRemainingMs(Math.max(0, left));

      if (left <= IDLE_WARN_MS && left > 0) {
        const now = Date.now();
        if (!warningShownRef.current) {
          warningShownRef.current = true;
          setAnnounce(
            `You will be signed out in ${formatIdleCountdown(left)} due to inactivity.`,
          );
          lastAnnounceAtRef.current = now;
        } else if (now - lastAnnounceAtRef.current >= idleAnnounceIntervalMs(left)) {
          setAnnounce(`You will be signed out in ${formatIdleCountdown(left)}.`);
          lastAnnounceAtRef.current = now;
        }
      }

      if (left <= 0) {
        timedOutRef.current = true;
        setAnnounce('Signed out due to inactivity.');
        void (async () => {
          try {
            await auth.logout();
          } catch {
            /* still leave the shell */
          }
          navigate(`${entry.path}?reason=idle`, { replace: true });
        })();
      }
    }, 1000);

    return () => {
      for (const ev of ACTIVITY_EVENTS) {
        document.removeEventListener(ev, onActivity, true);
      }
      window.clearInterval(tick);
    };
  }, [auth, bump, entry.path, navigate]);

  const warning = auth.authenticated && remainingMs <= IDLE_WARN_MS && remainingMs > 0;
  if (!warning && !announce) {
    return <span className="screen-reader-text" aria-live="polite" aria-atomic="true" />;
  }

  return (
    <>
      <span className="screen-reader-text" aria-live="polite" aria-atomic="true">
        {announce}
      </span>
      {warning ? (
        <div
          className="bk-toolbar-idle"
          role="status"
          aria-label={`Inactivity warning: signed out in ${formatIdleCountdown(remainingMs)}`}
        >
          <span className="bk-toolbar-idle__msg">
            Signed out in{' '}
            <time className="bk-toolbar-idle__count" dateTime={`PT${Math.ceil(remainingMs / 1000)}S`}>
              {formatIdleCountdown(remainingMs)}
            </time>
            {' '}
            if inactive
          </span>
          <button type="button" className="bk-toolbar-idle__btn" onClick={staySignedIn}>
            Stay signed in
          </button>
        </div>
      ) : null}
    </>
  );
}
