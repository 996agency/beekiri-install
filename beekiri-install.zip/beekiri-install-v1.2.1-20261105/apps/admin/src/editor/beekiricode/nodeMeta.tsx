import type { ComponentType } from 'react';
import {
  ArrowsOutLineVertical,
  Browser,
  ClipboardText,
  CursorClick,
  Image as ImageIcon,
  ListBullets,
  Minus,
  Paragraph,
  PlayCircle,
  PuzzlePiece,
  Rectangle,
  Square,
  Storefront,
  TextH,
  type IconProps,
} from '@phosphor-icons/react';
import type { BeekiriCodeNode, BeekiriCodeNodeType, ElementKey } from './document';

/** Shared names, icons and colours for every node type (Layers, Props, Add, canvas). */

export type IconLike = ComponentType<IconProps>;
export type Tone = 'blue' | 'amber' | 'purple' | 'teal' | 'rose' | 'gray';

function ColumnsIcon({ count, size = 16 }: { count: 2 | 3; size?: number | string }) {
  const gap = 2;
  const w = (14 - gap * (count - 1)) / count;
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" aria-hidden>
      {Array.from({ length: count }, (_, i) => (
        <rect
          key={i}
          x={1 + i * (w + gap)}
          y={2}
          width={w}
          height={12}
          rx={1.2}
          stroke="currentColor"
          strokeWidth={1.3}
        />
      ))}
    </svg>
  );
}

const Columns2: IconLike = ({ size }) => <ColumnsIcon count={2} size={size} />;
const Columns3: IconLike = ({ size }) => <ColumnsIcon count={3} size={size} />;

export const TYPE_META: Record<BeekiriCodeNodeType, { label: string; Icon: IconLike; tone: Tone }> =
  {
    section: { label: 'Section', Icon: Rectangle, tone: 'amber' },
    container: { label: 'Container', Icon: Square, tone: 'amber' },
    heading: { label: 'Heading', Icon: TextH, tone: 'blue' },
    text: { label: 'Text', Icon: Paragraph, tone: 'blue' },
    button: { label: 'Button', Icon: CursorClick, tone: 'rose' },
    list: { label: 'List', Icon: ListBullets, tone: 'blue' },
    image: { label: 'Image', Icon: ImageIcon, tone: 'teal' },
    video: { label: 'Video', Icon: PlayCircle, tone: 'teal' },
    divider: { label: 'Divider', Icon: Minus, tone: 'gray' },
    shop_content: { label: 'Shop content', Icon: Storefront, tone: 'purple' },
    form: { label: 'Form', Icon: ClipboardText, tone: 'teal' },
    spacer: { label: 'Spacer', Icon: ArrowsOutLineVertical, tone: 'gray' },
    layout: { label: 'Layout', Icon: PuzzlePiece, tone: 'purple' },
  };

export const ROOT_META = { label: 'Body', Icon: Browser, tone: 'blue' as Tone };

export type ElementGroup = 'structure' | 'basic' | 'media';

export type ElementDef = {
  key: ElementKey;
  label: string;
  hint: string;
  Icon: IconLike;
  group: ElementGroup;
  /** Extra search terms. */
  keywords?: string;
  /** Only offered while editing a Shop page (Shop → Shop Editor). */
  shopOnly?: boolean;
  /** Only offered while this extension is active. */
  extension?: string;
};

export const ELEMENT_GROUPS: { id: ElementGroup; label: string }[] = [
  { id: 'structure', label: 'Structure' },
  { id: 'basic', label: 'Basic' },
  { id: 'media', label: 'Media' },
];

export const ELEMENTS: ElementDef[] = [
  {
    key: 'shop_content',
    label: 'Shop content',
    hint: 'Products, cart or checkout',
    Icon: Storefront,
    group: 'structure',
    keywords: 'shop products cart checkout order store',
    shopOnly: true,
  },
  {
    key: 'form',
    label: 'Form',
    hint: 'A Bee Forms form',
    Icon: ClipboardText,
    group: 'basic',
    keywords: 'form contact email input submit lead bee forms',
    extension: 'bee-forms',
  },
  {
    key: 'section',
    label: 'Section',
    hint: 'Full-width row',
    Icon: Rectangle,
    group: 'structure',
    keywords: 'row block wrapper',
  },
  {
    key: 'container',
    label: 'Container',
    hint: 'Groups elements',
    Icon: Square,
    group: 'structure',
    keywords: 'div box group flex',
  },
  {
    key: 'columns-2',
    label: '2 Columns',
    hint: 'Side by side',
    Icon: Columns2,
    group: 'structure',
    keywords: 'grid two half',
  },
  {
    key: 'columns-3',
    label: '3 Columns',
    hint: 'Three across',
    Icon: Columns3,
    group: 'structure',
    keywords: 'grid three thirds',
  },
  {
    key: 'spacer',
    label: 'Spacer',
    hint: 'Vertical space',
    Icon: ArrowsOutLineVertical,
    group: 'structure',
    keywords: 'gap margin',
  },
  {
    key: 'divider',
    label: 'Divider',
    hint: 'Horizontal line',
    Icon: Minus,
    group: 'structure',
    keywords: 'hr line separator rule',
  },
  {
    key: 'heading',
    label: 'Heading',
    hint: 'H1 – H6 title',
    Icon: TextH,
    group: 'basic',
    keywords: 'title h1 h2 h3',
  },
  {
    key: 'text',
    label: 'Text',
    hint: 'Paragraph',
    Icon: Paragraph,
    group: 'basic',
    keywords: 'paragraph copy body',
  },
  {
    key: 'button',
    label: 'Button',
    hint: 'Link styled as CTA',
    Icon: CursorClick,
    group: 'basic',
    keywords: 'link cta anchor',
  },
  {
    key: 'list',
    label: 'List',
    hint: 'Bullets or numbers',
    Icon: ListBullets,
    group: 'basic',
    keywords: 'ul ol bullets numbered items',
  },
  {
    key: 'image',
    label: 'Image',
    hint: 'From media library',
    Icon: ImageIcon,
    group: 'media',
    keywords: 'picture photo img',
  },
  {
    key: 'video',
    label: 'Video',
    hint: 'YouTube, Vimeo or MP4',
    Icon: PlayCircle,
    group: 'media',
    keywords: 'youtube vimeo embed mp4',
  },
];

/** Display name: custom label → layout title → text snippet → type. */
export function nodeName(node: BeekiriCodeNode, isRoot: boolean): string {
  if (isRoot) return node.label?.trim() || ROOT_META.label;
  if (node.label?.trim()) return node.label.trim();
  if (node.type === 'layout') return (node.layoutTitle || node.layoutSlug || 'Layout').trim();
  if (node.type === 'heading' || node.type === 'text' || node.type === 'button') {
    const snippet = (node.text || '').replace(/\s+/g, ' ').trim();
    if (snippet) return snippet.length > 28 ? `${snippet.slice(0, 28)}…` : snippet;
  }
  return TYPE_META[node.type]?.label ?? node.type;
}

/** Monospace chip next to the name: `body`, `h1`, `section`, layout slug… */
export function nodeTag(node: BeekiriCodeNode, isRoot: boolean): string {
  if (isRoot) return 'body';
  if (node.type === 'layout') return node.layoutSlug || 'layout';
  if (node.type === 'image') return 'img';
  if (node.type === 'video') return 'video';
  return (node.tag || node.type).toLowerCase();
}

export function nodeMeta(node: BeekiriCodeNode, isRoot: boolean): { Icon: IconLike; tone: Tone } {
  if (isRoot) return ROOT_META;
  return TYPE_META[node.type] ?? TYPE_META.container;
}

/* ── Drag payloads from the Add panel ───────────────────────────────────── */

export const ELEMENT_MIME = 'application/x-beekiri-element';

export type PaletteDrag =
  | { kind: 'element'; key: ElementKey }
  | { kind: 'layout'; slug: string }
  | { kind: 'section'; key: string };

/** dragover can't read dataTransfer, so the active palette drag is tracked here. */
let activeDrag: PaletteDrag | null = null;

export function setPaletteDrag(d: PaletteDrag | null) {
  activeDrag = d;
}

export function getPaletteDrag(): PaletteDrag | null {
  return activeDrag;
}

export function encodePaletteDrag(d: PaletteDrag): string {
  if (d.kind === 'element') return `el:${d.key}`;
  return d.kind === 'section' ? `section:${d.key}` : `layout:${d.slug}`;
}

export function decodePaletteDrag(raw: string): PaletteDrag | null {
  if (raw.startsWith('el:')) return { kind: 'element', key: raw.slice(3) as ElementKey };
  if (raw.startsWith('layout:')) return { kind: 'layout', slug: raw.slice(7) };
  if (raw.startsWith('section:')) return { kind: 'section', key: raw.slice(8) };
  return null;
}
