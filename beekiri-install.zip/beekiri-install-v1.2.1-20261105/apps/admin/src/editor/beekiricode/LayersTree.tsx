import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type DragEvent,
  type KeyboardEvent,
  type MouseEvent,
} from 'react';
import {
  CaretDown,
  CaretRight,
  DotsSixVertical,
  EyeSlash,
  SlidersHorizontal,
  Trash,
} from '@phosphor-icons/react';
import { canAcceptChildren, type BeekiriCodePageDoc, type MovePosition } from './document';
import {
  ELEMENT_MIME,
  decodePaletteDrag,
  getPaletteDrag,
  nodeMeta,
  nodeName,
  nodeTag,
  type PaletteDrag,
} from './nodeMeta';

type Props = {
  doc: BeekiriCodePageDoc;
  selectedId: string | null;
  /** Node under the pointer on the canvas — highlighted here too. */
  hoveredId?: string | null;
  /** Filters rows by name / tag / type (ancestors stay visible for context). */
  query?: string;
  onSelect: (id: string) => void;
  /** Select and jump to the Props tab (row button / Enter). */
  onOpenProps?: (id: string) => void;
  onHover?: (id: string | null) => void;
  onRemove: (id: string) => void;
  onMove: (dragId: string, targetId: string, position: MovePosition) => void;
  onRename?: (id: string, label: string) => void;
  /** Element or layout dragged in from the Add panel. */
  onDropPalette?: (drag: PaletteDrag, targetId: string, position: MovePosition) => void;
};

type FlatRow = {
  id: string;
  depth: number;
  hasChildren: boolean;
  /** Dimmed: shown only because a descendant matches the search. */
  context: boolean;
};

type DropHint = { id: string; position: MovePosition } | null;

const DRAG_MIME = 'application/x-beekiri-layer';
const PALETTE_DRAG_ID = '__palette__';

export function LayersTree({
  doc,
  selectedId,
  hoveredId = null,
  query = '',
  onSelect,
  onOpenProps,
  onHover,
  onRemove,
  onMove,
  onRename,
  onDropPalette,
}: Props) {
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const draggingRef = useRef<string | null>(null);
  const [dropHint, setDropHint] = useState<DropHint>(null);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const treeRef = useRef<HTMLDivElement>(null);

  const q = query.trim().toLowerCase();

  /** Ids that match the search, plus every ancestor so the path stays visible. */
  const matches = useMemo(() => {
    if (!q) return null;
    const hits = new Set<string>();
    const keep = new Set<string>();
    const walk = (id: string, path: string[]) => {
      const n = doc.nodes[id];
      if (!n) return;
      const isRoot = id === doc.rootId;
      const hay =
        `${nodeName(n, isRoot)} ${nodeTag(n, isRoot)} ${n.type} ${n.layoutSlug ?? ''}`.toLowerCase();
      if (hay.includes(q)) {
        hits.add(id);
        for (const p of path) keep.add(p);
        keep.add(id);
      }
      for (const c of n.children) walk(c, [...path, id]);
    };
    walk(doc.rootId, []);
    return { hits, keep };
  }, [doc, q]);

  const rows = useMemo(() => {
    const out: FlatRow[] = [];
    const walk = (id: string, depth: number) => {
      const n = doc.nodes[id];
      if (!n) return;
      if (matches && !matches.keep.has(id)) return;
      const hasChildren = n.children.length > 0;
      out.push({ id, depth, hasChildren, context: Boolean(matches && !matches.hits.has(id)) });
      // While searching, every kept branch is expanded.
      if (hasChildren && (matches || !collapsed[id])) {
        n.children.forEach((c) => walk(c, depth + 1));
      }
    };
    walk(doc.rootId, 0);
    return out;
  }, [doc, collapsed, matches]);

  // Reveal the selection when it is chosen from the canvas inside a collapsed branch.
  useEffect(() => {
    if (!selectedId) return;
    const toOpen: string[] = [];
    for (const [id, node] of Object.entries(doc.nodes)) {
      if (collapsed[id] && node.children.length) {
        const stack = [...node.children];
        while (stack.length) {
          const c = stack.pop() as string;
          if (c === selectedId) {
            toOpen.push(id);
            break;
          }
          const cn = doc.nodes[c];
          if (cn) stack.push(...cn.children);
        }
      }
    }
    if (toOpen.length) {
      setCollapsed((prev) => {
        const next = { ...prev };
        for (const id of toOpen) delete next[id];
        return next;
      });
    }
    // Only react to selection changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId]);

  const toggle = (e: MouseEvent, id: string) => {
    e.stopPropagation();
    setCollapsed((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const resolveDrop = (
    dragId: string | null,
    targetId: string,
    clientY: number,
    el: HTMLElement,
  ): MovePosition | null => {
    if (!dragId || dragId === targetId) return null;
    const isRoot = targetId === doc.rootId;
    const target = doc.nodes[targetId];
    const rect = el.getBoundingClientRect();
    const y = (clientY - rect.top) / Math.max(rect.height, 1);

    if (isRoot || canAcceptChildren(target, isRoot)) {
      if (y < 0.28 && !isRoot) return 'before';
      if (y > 0.72 && !isRoot) return 'after';
      return 'inside';
    }
    return y < 0.5 ? 'before' : 'after';
  };

  const isPaletteDrag = (e: DragEvent) =>
    Boolean(getPaletteDrag()) || Array.from(e.dataTransfer.types).includes(ELEMENT_MIME);

  const onDragStart = (e: DragEvent, id: string) => {
    if (id === doc.rootId || renamingId) {
      e.preventDefault();
      return;
    }
    e.dataTransfer.setData(DRAG_MIME, id);
    e.dataTransfer.effectAllowed = 'move';
    draggingRef.current = id;
    setDraggingId(id);
    onSelect(id);
  };

  const onDragEnd = () => {
    draggingRef.current = null;
    setDraggingId(null);
    setDropHint(null);
  };

  const onDragOverRow = (e: DragEvent, id: string) => {
    const palette = isPaletteDrag(e);
    const dragId = palette ? PALETTE_DRAG_ID : draggingRef.current;
    if (!dragId) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = palette ? 'copy' : 'move';
    const el = e.currentTarget as HTMLElement;
    const position = resolveDrop(dragId, id, e.clientY, el);
    if (!position) {
      setDropHint(null);
      return;
    }
    setDropHint({ id, position });
  };

  const onDropRow = (e: DragEvent, id: string) => {
    e.preventDefault();
    const el = e.currentTarget as HTMLElement;
    const paletteRaw = e.dataTransfer.getData(ELEMENT_MIME);
    const palette = (paletteRaw && decodePaletteDrag(paletteRaw)) || getPaletteDrag();
    const dragId = palette
      ? PALETTE_DRAG_ID
      : e.dataTransfer.getData(DRAG_MIME) || draggingRef.current;
    const position = dragId ? resolveDrop(dragId, id, e.clientY, el) : null;
    draggingRef.current = null;
    setDraggingId(null);
    setDropHint(null);
    if (!dragId || !position) return;
    if (palette) {
      onDropPalette?.(palette, id, position);
      return;
    }
    onMove(dragId, id, position);
  };

  const focusRow = (id: string) => {
    const el = treeRef.current?.querySelector<HTMLElement>(`[data-row-id="${CSS.escape(id)}"]`);
    el?.focus();
  };

  const onRowKey = (e: KeyboardEvent, row: FlatRow, isRoot: boolean, isOpen: boolean) => {
    if (renamingId) return;
    const idx = rows.findIndex((r) => r.id === row.id);
    switch (e.key) {
      case 'Enter':
        e.preventDefault();
        (onOpenProps ?? onSelect)(row.id);
        break;
      case ' ':
        e.preventDefault();
        onSelect(row.id);
        break;
      case 'F2':
        if (onRename) {
          e.preventDefault();
          setRenamingId(row.id);
        }
        break;
      case 'ArrowDown': {
        e.preventDefault();
        const next = rows[idx + 1];
        if (next) {
          onSelect(next.id);
          focusRow(next.id);
        }
        break;
      }
      case 'ArrowUp': {
        e.preventDefault();
        const prev = rows[idx - 1];
        if (prev) {
          onSelect(prev.id);
          focusRow(prev.id);
        }
        break;
      }
      case 'ArrowRight':
        if (row.hasChildren && !isOpen) {
          e.preventDefault();
          setCollapsed((p) => ({ ...p, [row.id]: false }));
        }
        break;
      case 'ArrowLeft':
        if (row.hasChildren && isOpen) {
          e.preventDefault();
          setCollapsed((p) => ({ ...p, [row.id]: true }));
        } else if (!isRoot) {
          e.preventDefault();
          const parent = [...rows]
            .slice(0, idx)
            .reverse()
            .find((r) => r.depth === row.depth - 1);
          if (parent) {
            onSelect(parent.id);
            focusRow(parent.id);
          }
        }
        break;
      case 'Delete':
      case 'Backspace':
        if (!isRoot) {
          e.preventDefault();
          onRemove(row.id);
        }
        break;
      default:
        break;
    }
  };

  if (q && rows.length === 0) {
    return <p className="bk-beekiricode__layers-empty">No layers match “{query}”.</p>;
  }

  return (
    <div ref={treeRef} className="bk-beekiricode__tree" role="tree" aria-label="Layers">
      {rows.map((row) => {
        const node = doc.nodes[row.id];
        if (!node) return null;
        const isRoot = row.id === doc.rootId;
        const { Icon, tone } = nodeMeta(node, isRoot);
        const name = nodeName(node, isRoot);
        const tag = nodeTag(node, isRoot);
        const isOpen = row.hasChildren && (Boolean(matches) || !collapsed[row.id]);
        const selected = selectedId === row.id;
        const hint = dropHint?.id === row.id ? dropHint.position : null;
        const hiddenCount = node.hiddenOn?.length ?? 0;

        return (
          <div
            key={row.id}
            role="treeitem"
            tabIndex={selected ? 0 : -1}
            data-row-id={row.id}
            aria-selected={selected}
            aria-level={row.depth + 1}
            aria-expanded={row.hasChildren ? isOpen : undefined}
            draggable={!isRoot && renamingId !== row.id}
            className={[
              'bk-beekiricode__tree-item',
              selected ? 'is-selected' : '',
              hoveredId === row.id && !selected ? 'is-hovered' : '',
              row.context ? 'is-context' : '',
              draggingId === row.id ? 'is-dragging' : '',
              hint === 'before' ? 'is-drop-before' : '',
              hint === 'after' ? 'is-drop-after' : '',
              hint === 'inside' ? 'is-drop-inside' : '',
            ]
              .filter(Boolean)
              .join(' ')}
            style={{ ['--depth' as string]: row.depth }}
            onClick={() => onSelect(row.id)}
            onDoubleClick={(e) => {
              if (!onRename) return;
              e.stopPropagation();
              setRenamingId(row.id);
            }}
            onMouseEnter={() => onHover?.(row.id)}
            onMouseLeave={() => onHover?.(null)}
            onKeyDown={(e) => onRowKey(e, row, isRoot, isOpen)}
            onDragStart={(e) => onDragStart(e, row.id)}
            onDragEnd={onDragEnd}
            onDragOver={(e) => onDragOverRow(e, row.id)}
            onDragLeave={() => {
              if (dropHint?.id === row.id) setDropHint(null);
            }}
            onDrop={(e) => onDropRow(e, row.id)}
          >
            {/* Indent guides, one per depth level. */}
            {Array.from({ length: row.depth }, (_, i) => (
              <span key={i} className="bk-beekiricode__tree-guide" aria-hidden />
            ))}

            <span className="bk-beekiricode__tree-caret-slot">
              {row.hasChildren ? (
                <button
                  type="button"
                  tabIndex={-1}
                  className="bk-beekiricode__tree-caret"
                  onClick={(e) => toggle(e, row.id)}
                  aria-label={isOpen ? 'Collapse' : 'Expand'}
                >
                  {isOpen ? (
                    <CaretDown size={10} weight="bold" aria-hidden />
                  ) : (
                    <CaretRight size={10} weight="bold" aria-hidden />
                  )}
                </button>
              ) : null}
            </span>

            <span className={`bk-beekiricode__tree-type-icon is-${tone}`} aria-hidden>
              <Icon size={14} weight="regular" />
            </span>

            {renamingId === row.id ? (
              <RenameInput
                initial={node.label ?? ''}
                placeholder={name}
                onDone={(label) => {
                  setRenamingId(null);
                  if (label !== (node.label ?? '')) onRename?.(row.id, label);
                  focusRow(row.id);
                }}
              />
            ) : (
              <>
                <span
                  className="bk-beekiricode__tree-label"
                  title={onRename ? `${name} — double-click to rename` : name}
                >
                  {name}
                </span>
                <span className={`bk-beekiricode__tree-tag bk-beekiricode__tree-tag--${tone}`}>
                  {tag}
                </span>
              </>
            )}

            {hiddenCount ? (
              <span
                className="bk-beekiricode__tree-flag"
                title={`Hidden on ${node.hiddenOn?.join(', ')}`}
                aria-label={`Hidden on ${node.hiddenOn?.join(', ')}`}
              >
                <EyeSlash size={11} weight="bold" />
              </span>
            ) : null}

            {!isRoot ? (
              <span className="bk-beekiricode__tree-drag" title="Drag to reorder" aria-hidden>
                <DotsSixVertical size={12} weight="bold" />
              </span>
            ) : null}
            {onOpenProps ? (
              <button
                type="button"
                tabIndex={-1}
                className={`bk-beekiricode__tree-action${isRoot ? ' is-root' : ''}`}
                title="Edit properties (Enter)"
                aria-label={`Edit properties of ${name}`}
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenProps(row.id);
                }}
              >
                <SlidersHorizontal size={12} weight="bold" aria-hidden />
              </button>
            ) : null}
            {!isRoot ? (
              <button
                type="button"
                tabIndex={-1}
                className="bk-beekiricode__tree-action is-danger"
                title="Delete (⌫)"
                aria-label={`Delete ${name}`}
                onClick={(e) => {
                  e.stopPropagation();
                  onRemove(row.id);
                }}
              >
                <Trash size={12} weight="bold" aria-hidden />
              </button>
            ) : null}
          </div>
        );
      })}
    </div>
  );
}

function RenameInput({
  initial,
  placeholder,
  onDone,
}: {
  initial: string;
  placeholder: string;
  onDone: (label: string) => void;
}) {
  const [value, setValue] = useState(initial);
  const done = useRef(false);
  const finish = (v: string) => {
    if (done.current) return;
    done.current = true;
    onDone(v.trim());
  };
  return (
    <input
      className="bk-beekiricode__tree-rename"
      value={value}
      placeholder={placeholder}
      aria-label="Layer name"
      autoFocus
      spellCheck={false}
      onFocus={(e) => e.target.select()}
      onChange={(e) => setValue(e.target.value)}
      onClick={(e) => e.stopPropagation()}
      onDoubleClick={(e) => e.stopPropagation()}
      onMouseDown={(e) => e.stopPropagation()}
      onBlur={() => finish(value)}
      onKeyDown={(e) => {
        e.stopPropagation();
        if (e.key === 'Enter') finish(value);
        if (e.key === 'Escape') finish(initial);
      }}
    />
  );
}
