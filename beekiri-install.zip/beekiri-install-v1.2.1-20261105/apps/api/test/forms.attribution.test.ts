import { describe, expect, it } from 'vitest';
import { attributionOf, parseTouch } from '../src/lib/forms/attribution';

const at = (url: string, referrer = '') => attributionOf(parseTouch({ landingUrl: url, referrer, params: Object.fromEntries(new URL(url).searchParams) }), 'beekiri.test');

describe('attributionOf', () => {
  it('reads ad click ids', () => {
    expect(at('https://beekiri.test/?gclid=abc')).toMatchObject({ channel: 'Paid search', source: 'Google Ads', clickId: 'gclid' });
    expect(at('https://beekiri.test/?li_fat_id=x')).toMatchObject({ channel: 'Paid social', source: 'LinkedIn Ads' });
    expect(at('https://beekiri.test/?msclkid=x')).toMatchObject({ channel: 'Paid search', source: 'Microsoft Ads' });
    expect(at('https://beekiri.test/?ttclid=x')).toMatchObject({ channel: 'Paid social', source: 'TikTok Ads' });
  });

  it('treats fbclid as paid only with paid UTM tags', () => {
    expect(at('https://beekiri.test/?fbclid=x', 'https://l.facebook.com/')).toMatchObject({ channel: 'Social', source: 'Facebook' });
    expect(at('https://beekiri.test/?fbclid=x&utm_medium=paid_social&utm_source=facebook')).toMatchObject({ channel: 'Paid social', source: 'Meta Ads' });
  });

  it('reads UTM tags', () => {
    expect(at('https://beekiri.test/?utm_source=linkedin&utm_medium=cpc&utm_campaign=spring')).toMatchObject({ channel: 'Paid social', source: 'LinkedIn Ads', campaign: 'spring' });
    expect(at('https://beekiri.test/?utm_source=google&utm_medium=cpc')).toMatchObject({ channel: 'Paid search', source: 'Google Ads' });
    expect(at('https://beekiri.test/?utm_source=newsletter&utm_medium=email&utm_campaign=nov')).toMatchObject({ channel: 'Email', source: 'Newsletter' });
    expect(at('https://beekiri.test/?utm_source=partner-site&utm_medium=referral')).toMatchObject({ channel: 'Referral', source: 'partner-site' });
    expect(at('https://beekiri.test/?utm_source=podcast&utm_campaign=ep12')).toMatchObject({ channel: 'Campaign', source: 'podcast' });
    expect(at('https://beekiri.test/?utm_source=linkedin&utm_medium=social')).toMatchObject({ channel: 'Social', source: 'LinkedIn' });
  });

  it('reads the referrer', () => {
    expect(at('https://beekiri.test/', 'https://www.google.co.uk/')).toMatchObject({ channel: 'Organic search', source: 'Google' });
    expect(at('https://beekiri.test/', 'https://www.linkedin.com/feed/')).toMatchObject({ channel: 'Social', source: 'LinkedIn' });
    expect(at('https://beekiri.test/', 'https://blog.example.com/post')).toMatchObject({ channel: 'Referral', source: 'blog.example.com' });
  });

  it('ignores the site itself and falls back to Direct', () => {
    expect(at('https://beekiri.test/contact', 'https://beekiri.test/about')).toMatchObject({ channel: 'Direct', referrer: '' });
    expect(attributionOf(null)).toMatchObject({ channel: 'Direct', source: 'Direct' });
  });

  it('keeps the landing page as path + query', () => {
    expect(at('https://beekiri.test/offer?utm_source=x').landingPage).toBe('/offer?utm_source=x');
  });
});

describe('parseTouch', () => {
  it('drops unknown params and junk', () => {
    expect(parseTouch({ landingUrl: 'https://x.test/', params: { utm_source: 'a', evil: 'b' } })?.params).toEqual({ utm_source: 'a' });
    expect(parseTouch('nope')).toBeNull();
    expect(parseTouch({})).toBeNull();
  });
});

describe('visitorMeta', () => {
  it('uses the tagged submit page when the recorded visit is older and untagged', async () => {
    const { visitorMeta } = await import('../src/services/forms/submit.service');
    const old = { landingUrl: 'http://localhost:8788/', referrer: '', params: {}, at: Date.now() - 38 * 60_000, pages: 33 };
    const m = visitorMeta({
      formId: 'f', body: {}, files: [], ip: '::1', userAgent: 'Mozilla/5.0 Chrome/130', pageTitle: 'Contact', referrer: '',
      pageUrl: 'http://localhost:8788/contact?utm_source=google&utm_medium=cpc&utm_campaign=test_ad_campaign&utm_id=12345',
      attribution: JSON.stringify({ visit: old, first: null, timeZone: 'Europe/Skopje', language: 'en-US' }),
      header: (n) => (n === 'host' ? 'localhost:8788' : undefined),
    });
    expect(m.attribution.visit).toMatchObject({ channel: 'Paid search', source: 'Google Ads', campaign: 'test_ad_campaign', medium: 'cpc' });
    expect(m.pagesViewed).toBe(1);
  });

  it('keeps the recorded visit when the submit page has no tags', async () => {
    const { visitorMeta } = await import('../src/services/forms/submit.service');
    const v = { landingUrl: 'http://localhost:8788/?utm_source=linkedin&utm_medium=paid_social&li_fat_id=1', referrer: '', params: { utm_source: 'linkedin', utm_medium: 'paid_social', li_fat_id: '1' }, at: Date.now() - 60_000, pages: 3 };
    const m = visitorMeta({
      formId: 'f', body: {}, files: [], ip: '::1', userAgent: 'Mozilla/5.0 Chrome/130', pageTitle: 'Contact', referrer: '',
      pageUrl: 'http://localhost:8788/contact', attribution: JSON.stringify({ visit: v, first: null }), header: () => undefined,
    });
    expect(m.attribution.visit).toMatchObject({ channel: 'Paid social', source: 'LinkedIn Ads' });
    expect(m.pagesViewed).toBe(3);
  });
});
