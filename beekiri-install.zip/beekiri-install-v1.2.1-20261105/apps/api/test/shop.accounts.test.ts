import type { Express } from 'express';
import request from 'supertest';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

/**
 * Shopper accounts + tracking: register, verify, sign in, checkout linked to the
 * account, orders hidden until verified, fulfilment updates, password reset.
 * Throwaway database only: TEST_DB_NAME=beekiri_shop_test npm test
 */
const TEST_DB_NAME = process.env.TEST_DB_NAME;
const ORIGIN = 'http://localhost';
const OWNER = { language: 'en_US', siteTitle: 'Account Shop', username: 'owner', password: 'Str0ng!Passw0rd', email: 'owner@example.com', blogPublic: true, frontendRuntime: 'php' };
const SHOPPER = { email: 'mira@example.com', password: 'Gr8!Shopper#2026', firstName: 'Mira', lastName: 'Kola' };
const BILLING = { firstName: 'Mira', lastName: 'Kola', company: '', line1: '5 Rr. Nënë Tereza', line2: '', city: 'Prishtina', state: '', postcode: '10000', country: 'XK' };

type Auth = { cookie: string; csrf: string };

describe.skipIf(!TEST_DB_NAME)('Shopping accounts and tracking', () => {
  let app: Express;
  let db: typeof import('../src/db/sequelize');
  let mail: typeof import('../src/services/mail.service');
  let clearRateLimits: () => void;
  let owner: Auth;
  let productId = '';
  let shopperCookie = '';
  let cartCookie = '';
  let orderId = '';
  let orderNumber = 0;

  const as = (a: Auth, r: request.Test) => r.set('Cookie', a.cookie).set('Origin', ORIGIN).set('X-CSRF-Token', a.csrf);
  const cookies = () => [cartCookie && `beekiri_cart=${cartCookie}`, shopperCookie && `beekiri_customer=${shopperCookie}`].filter(Boolean).join('; ');
  const shopper = (r: request.Test) => r.set('Origin', ORIGIN).set('X-Beekiri-Shop', '1').set('Cookie', cookies());
  const grab = (res: request.Response, name: string) =>
    ([] as string[]).concat(res.headers['set-cookie'] ?? []).find((c) => c.startsWith(`${name}=`))?.split(';')[0]?.split('=')[1] ?? '';
  const lastLink = async () => {
    await new Promise((r) => setTimeout(r, 300));
    return mail.mailService.getLastDevLink() ?? '';
  };

  beforeAll(async () => {
    Object.assign(process.env, { NODE_ENV: 'test', DB_NAME: TEST_DB_NAME, APP_URL: ORIGIN, MEDIA_LOCAL_PATH: '/tmp/beekiri-test-uploads', BEEKIRI_SETUP_TOKEN_FILE: `/tmp/beekiri-test-setup-token-${process.pid}` });
    const { runMigrations } = await import('../src/db/migrator');
    db = await import('../src/db/sequelize');
    const models = await import('../src/models');
    mail = await import('../src/services/mail.service');
    ({ clearRateLimits } = await import('../src/utils/rate-limit'));
    const { createApp } = await import('../src/app');
    await runMigrations();
    const tables = Object.values(db.sequelize.models).map((m) => `"${m.getTableName() as string}"`).filter((t) => t !== '"SequelizeMeta"').join(', ');
    await db.sequelize.query(`TRUNCATE ${tables} CASCADE`);
    await models.InstallationState.create({ id: 1, installed: false });
    clearRateLimits();
    app = createApp();
    const key = (await import('../src/lib/setup-token')).ensureSetupToken();
    expect((await request(app).post('/api/install').set('X-Setup-Token', key).send(OWNER)).status).toBe(201);
    const { seedRolesAndCapabilities } = await import('../src/services/install.service');
    const { refreshRoleCapabilityCache } = await import('../src/lib/auth/role-cache');
    await seedRolesAndCapabilities();
    await refreshRoleCapabilityCache();
    const login = await request(app).post('/api/auth/login').set('Origin', ORIGIN).send({ login: OWNER.username, password: OWNER.password });
    owner = { cookie: ([] as string[]).concat(login.headers['set-cookie'] ?? [])[0]!.split(';')[0]!, csrf: login.body.csrfToken };

    expect((await as(owner, request(app).post('/api/extensions/shopping/install'))).status).toBe(200);
    const { settings } = (await as(owner, request(app).get('/api/shop/settings'))).body;
    settings.shipping.zones = [{ id: 'all', name: 'All', countries: [], methods: [
      { id: 'std', type: 'flat_rate', title: 'Standard', cost: 300, minAmount: 0, enabled: true },
      { id: 'exp', type: 'flat_rate', title: 'Express', cost: 900, minAmount: 0, enabled: true },
    ] }];
    expect((await as(owner, request(app).put('/api/shop/settings')).send(settings)).status).toBe(200);
    const p = await as(owner, request(app).post('/api/shop/products')).send({ title: 'Mug' });
    productId = p.body.id;
    await as(owner, request(app).patch(`/api/shop/products/${productId}`)).send({ status: 'publish', commerce: { regularPrice: 1200 } });
  });

  afterAll(async () => {
    await db?.closeDatabase();
  });

  it('places a guest order, then a registration with that email cannot see it before verifying', async () => {
    const add = await shopper(request(app).post('/api/shop/public/cart/items')).send({ productId, qty: 1 });
    cartCookie = grab(add, 'beekiri_cart');
    const guest = await shopper(request(app).post('/api/shop/public/checkout')).send({ email: SHOPPER.email, phone: '', billing: BILLING, shipToDifferent: false, shippingMethodId: 'std', paymentMethod: 'cod' });
    expect(guest.status).toBe(201);

    const weak = await shopper(request(app).post('/api/shop/public/account/register')).send({ ...SHOPPER, password: 'password1' });
    expect(weak.status).toBe(400);
    const reg = await shopper(request(app).post('/api/shop/public/account/register')).send(SHOPPER);
    expect(reg.status).toBe(201);
    shopperCookie = grab(reg, 'beekiri_customer');
    expect(shopperCookie).toBeTruthy();
    expect(reg.body.customer.verified).toBe(false);
    // Saved guest data stays hidden until the mailbox owner confirms.
    expect(reg.body.customer.billing.line1).toBe('');
    const orders = await shopper(request(app).get('/api/shop/public/account/orders'));
    expect(orders.body).toMatchObject({ verified: false, items: [] });

    const dup = await shopper(request(app).post('/api/shop/public/account/register')).send(SHOPPER);
    expect(dup.status).toBe(409);
  });

  it('verifies the email from the link and then shows the order with tracking', async () => {
    const link = await lastLink();
    expect(link).toContain('/account/verify?token=');
    const token = new URL(link).searchParams.get('token')!;
    expect((await shopper(request(app).post('/api/shop/public/account/verify')).send({ token: 'x'.repeat(20) })).status).toBe(400);
    expect((await shopper(request(app).post('/api/shop/public/account/verify')).send({ token })).status).toBe(200);
    expect((await shopper(request(app).post('/api/shop/public/account/verify')).send({ token })).status).toBe(400); // single use

    const me = await shopper(request(app).get('/api/shop/public/account/me'));
    expect(me.body.customer).toMatchObject({ verified: true, firstName: 'Mira' });
    expect(me.body.customer.billing.city).toBe('Prishtina');
    const orders = await shopper(request(app).get('/api/shop/public/account/orders'));
    expect(orders.body.items).toHaveLength(1);
    expect(orders.body.items[0].tracking.headline).toBe('Being prepared');
    orderNumber = orders.body.items[0].number;
    orderId = orders.body.items[0].id;
  });

  it('links orders placed while signed in and keeps the cart shipping choice', async () => {
    await shopper(request(app).post('/api/shop/public/cart/items')).send({ productId, qty: 2 });
    const est = await shopper(request(app).post('/api/shop/public/cart/shipping')).send({ country: 'XK', state: '', postcode: '', shippingMethodId: 'exp' });
    expect(est.status).toBe(200);
    expect(est.body.estimate.options.find((o: { selected: boolean }) => o.selected).id).toBe('exp');
    expect(est.body.total).toBe(2400 + 900);
    const page = await shopper(request(app).get('/api/shop/public/checkout'));
    expect(page.body.preferredShippingMethodId).toBe('exp');
    expect(page.body.account.signedIn).toBe(true);
    const placed = await shopper(request(app).post('/api/shop/public/checkout')).send({ email: 'other@example.com', phone: '', billing: BILLING, shipToDifferent: false, shippingMethodId: 'exp', paymentMethod: 'cod' });
    expect(placed.status).toBe(201);
    const orders = await shopper(request(app).get('/api/shop/public/account/orders'));
    expect(orders.body.items).toHaveLength(2);
  });

  it('a guest checkout with the account email cannot overwrite saved details', async () => {
    const saved = await shopper(request(app).put('/api/shop/public/account/addresses')).send({ billing: { ...BILLING, line1: 'Saved street 1', phone: '' } });
    expect(saved.status).toBe(200);
    const keep = shopperCookie;
    shopperCookie = '';
    await shopper(request(app).post('/api/shop/public/cart/items')).send({ productId, qty: 1 });
    const placed = await shopper(request(app).post('/api/shop/public/checkout')).send({ email: SHOPPER.email, phone: '', billing: { ...BILLING, line1: 'Attacker road 9' }, shipToDifferent: false, shippingMethodId: 'std', paymentMethod: 'cod' });
    expect(placed.status).toBe(201);
    shopperCookie = keep;
    const me = await shopper(request(app).get('/api/shop/public/account/me'));
    expect(me.body.customer.billing.line1).toBe('Saved street 1');
  });

  it('shows shipping progress after the shop marks the order shipped and delivered', async () => {
    const bad = await as(owner, request(app).post(`/api/shop/orders/${orderId}/fulfillment`)).send({ status: 'shipped', trackingUrl: 'javascript:alert(1)' });
    expect(bad.status).toBe(400);
    const shipped = await as(owner, request(app).post(`/api/shop/orders/${orderId}/fulfillment`)).send({ status: 'shipped', carrier: 'Post Kosovo', trackingNumber: 'PK123', trackingUrl: 'https://track.example/PK123' });
    expect(shipped.status).toBe(200);
    expect(shipped.body.order.fulfillment).toMatchObject({ status: 'shipped', carrier: 'Post Kosovo' });
    expect(shipped.body.order.fulfillment.packedAt).toBeTruthy();
    const view = await shopper(request(app).get(`/api/shop/public/account/orders/${orderNumber}`));
    expect(view.body.tracking.headline).toBe('On its way');
    expect(view.body.tracking.fulfillment.trackingNumber).toBe('PK123');

    const delivered = await as(owner, request(app).post(`/api/shop/orders/${orderId}/fulfillment`)).send({ status: 'delivered', notify: false });
    expect(delivered.body.order.status).toBe('completed');
    const html = await shopper(request(app).get(`/api/shop/public/view/account?section=order&number=${orderNumber}`));
    expect(html.status).toBe(200);
    expect(html.body.html).toContain('bk-track');
    expect(html.body.html).toContain('PK123');
  });

  it('signs staff in to the shop with their admin login (no second account)', async () => {
    const me = await request(app).get('/api/shop/public/account/me').set('Cookie', owner.cookie);
    expect(me.body.signedIn).toBe(true);
    expect(me.body.customer).toMatchObject({ email: OWNER.email, staff: true, verified: true });
    const view = await request(app).get('/api/shop/public/view/account').set('Cookie', owner.cookie);
    expect(view.body.html).toContain('bk-acct-staff');
    expect(view.body.html).not.toContain('data-account-logout');
    const pw = await request(app).post('/api/shop/public/account/password').set('Cookie', owner.cookie).set('Origin', ORIGIN).set('X-Beekiri-Shop', '1').send({ current: OWNER.password, password: 'Another!Pass#77' });
    expect(pw.status).toBe(400);
    // Orders placed while signed in through the admin land on the staff customer record.
    const add = await request(app).post('/api/shop/public/cart/items').set('Cookie', owner.cookie).set('Origin', ORIGIN).set('X-Beekiri-Shop', '1').send({ productId, qty: 1 });
    const cart = grab(add, 'beekiri_cart');
    const placed = await request(app).post('/api/shop/public/checkout').set('Cookie', `${owner.cookie}; beekiri_cart=${cart}`).set('Origin', ORIGIN).set('X-Beekiri-Shop', '1')
      .send({ email: OWNER.email, phone: '', billing: BILLING, shipToDifferent: false, shippingMethodId: 'std', paymentMethod: 'cod' });
    expect(placed.status).toBe(201);
    const orders = await request(app).get('/api/shop/public/account/orders').set('Cookie', owner.cookie);
    expect(orders.body.items).toHaveLength(1);
    // Without any session the account API stays closed.
    expect((await request(app).get('/api/shop/public/account/orders')).status).toBe(401);
  });

  it('removes My account, its API and the header icon while Shopping is inactive', async () => {
    expect((await as(owner, request(app).post('/api/extensions/shopping/deactivate'))).status).toBe(200);
    expect((await request(app).get('/api/shop/public/view/account')).status).toBe(404);
    expect((await request(app).get('/api/shop/public/account/me').set('Cookie', owner.cookie)).status).toBe(404);
    const header = await request(app).get('/api/themes/chrome/header/render');
    expect(header.status).toBe(200);
    expect(header.body.html).toBeTruthy();
    expect(header.body.html).not.toContain('data-bk-account-link');
    expect((await as(owner, request(app).post('/api/extensions/shopping/activate'))).status).toBe(200);
    const back = await request(app).get('/api/themes/chrome/header/render');
    expect(back.body.html).toContain('data-bk-account-link');
  });

  it('keeps other shoppers out and supports sign out, sign in and password reset', async () => {
    expect((await request(app).get(`/api/shop/public/account/orders/${orderNumber}`)).status).toBe(401);
    const out = await shopper(request(app).post('/api/shop/public/account/logout')).send({});
    expect(out.status).toBe(200);
    expect((await shopper(request(app).get('/api/shop/public/account/me'))).body.signedIn).toBe(false);
    shopperCookie = '';

    clearRateLimits();
    const wrong = await shopper(request(app).post('/api/shop/public/account/login')).send({ email: SHOPPER.email, password: 'nope-nope' });
    expect(wrong.status).toBe(401);
    const unknown = await shopper(request(app).post('/api/shop/public/account/forgot')).send({ email: 'nobody@example.com' });
    expect(unknown.status).toBe(200);
    expect((await shopper(request(app).post('/api/shop/public/account/forgot')).send({ email: SHOPPER.email })).status).toBe(200);
    const link = await lastLink();
    expect(link).toContain('/account/reset?token=');
    const token = new URL(link).searchParams.get('token')!;
    expect((await shopper(request(app).post('/api/shop/public/account/reset')).send({ token, password: 'N3w!Password#99' })).status).toBe(200);
    const login = await shopper(request(app).post('/api/shop/public/account/login')).send({ email: SHOPPER.email, password: 'N3w!Password#99' });
    expect(login.status).toBe(200);
    expect(grab(login, 'beekiri_customer')).toBeTruthy();
    // Storefront writes need the header like the cart does.
    const noHeader = await request(app).post('/api/shop/public/account/login').set('Origin', ORIGIN).send({ email: SHOPPER.email, password: 'N3w!Password#99' });
    expect(noHeader.status).toBe(403);
  });
});
