import { describe, expect, it } from 'vitest';
import { availableShippingMethods, computeTotals, findTaxRate, type CartLine } from '../src/lib/shop/cart-totals';
import { formatMoney, parseMoney, percentOf } from '../src/lib/shop/money';
import { availableQty, effectivePrice, priceRange } from '../src/lib/shop/pricing';
import { defaultShopSettings, maskShopSettings, storableShopSettings, type ShopSettings } from '../src/lib/shop/settings';
import { decryptSecret, encryptSecret, isEncrypted } from '../src/lib/shop/secrets';

/** Pure shop logic — no database. */

const fmt = { currency: 'EUR', position: 'left' as const, thousandSeparator: ',', decimalSeparator: '.', decimals: null };

function line(over: Partial<CartLine> = {}): CartLine {
  return {
    key: 'p1:',
    productId: 'p1',
    commerceId: 'c1',
    variantId: null,
    name: 'Hoodie',
    sku: 'HD',
    qty: 1,
    unitPrice: 2500,
    regularPrice: 2500,
    taxable: true,
    virtual: false,
    weight: 400,
    imageUrl: '',
    attributes: {},
    categoryIds: ['cat1'],
    path: '/product/hoodie',
    ...over,
  };
}

function settingsWith(patch: (s: ShopSettings) => void): ShopSettings {
  const s = defaultShopSettings();
  patch(s);
  return s;
}

describe('money', () => {
  it('formats minor units with the configured style', () => {
    expect(formatMoney(1999, fmt)).toBe('€19.99');
    expect(formatMoney(1234567, fmt)).toBe('€12,345.67');
    expect(formatMoney(-500, fmt)).toBe('-€5.00');
    expect(formatMoney(1999, { ...fmt, position: 'right_space', decimalSeparator: ',', thousandSeparator: '.' })).toBe('19,99 €');
    expect(formatMoney(1500, { ...fmt, currency: 'JPY' })).toBe('¥1,500');
  });

  it('parses user input in both decimal conventions', () => {
    expect(parseMoney('19.99', 'EUR')).toBe(1999);
    expect(parseMoney('1.234,56', 'EUR')).toBe(123456);
    expect(parseMoney('1,234.56', 'EUR')).toBe(123456);
    expect(parseMoney('', 'EUR')).toBeNull();
    expect(parseMoney('abc', 'EUR')).toBeNull();
    expect(parseMoney('1500', 'JPY')).toBe(1500);
  });

  it('rounds percentages half-up on integers', () => {
    expect(percentOf(1000, 1250)).toBe(125);
    expect(percentOf(999, 3333)).toBe(333);
  });
});

describe('pricing', () => {
  it('uses the sale price only while the schedule runs and it is lower', () => {
    const now = Date.parse('2026-11-04T12:00:00Z');
    expect(effectivePrice({ regularPrice: 2500, salePrice: 2000 }, now)).toEqual({ price: 2000, regular: 2500, onSale: true });
    expect(effectivePrice({ regularPrice: 2500, salePrice: 2600 }, now).onSale).toBe(false);
    expect(effectivePrice({ regularPrice: 2500, salePrice: 2000, saleFrom: '2026-12-01T00:00:00Z' }, now).price).toBe(2500);
    expect(effectivePrice({ regularPrice: 2500, salePrice: 2000, saleTo: '2026-10-01T00:00:00Z' }, now).price).toBe(2500);
    expect(effectivePrice({ regularPrice: null, salePrice: null }).price).toBeNull();
  });

  it('computes variable ranges and stock availability', () => {
    expect(priceRange([{ regularPrice: 1000, salePrice: null }, { regularPrice: 3000, salePrice: 2500 }])).toEqual({ min: 1000, max: 2500, onSale: true });
    expect(availableQty({ manageStock: true, stockQty: 3, stockStatus: 'instock' })).toBe(3);
    expect(availableQty({ manageStock: true, stockQty: 0, stockStatus: 'instock' })).toBe(0);
    expect(availableQty({ manageStock: true, stockQty: 0, stockStatus: 'onbackorder' })).toBe(Infinity);
    expect(availableQty({ manageStock: false, stockQty: null, stockStatus: 'outofstock' })).toBe(0);
    expect(availableQty({ manageStock: false, stockQty: null, stockStatus: 'instock' })).toBe(Infinity);
  });
});

describe('cart totals', () => {
  it('adds up lines, shipping and a percentage coupon', () => {
    const t = computeTotals({
      lines: [line({ qty: 2 }), line({ key: 'p2:', productId: 'p2', unitPrice: 1000, categoryIds: [] })],
      coupon: { code: 'TEN', type: 'percent', amount: 1000, minSpend: null, maxSpend: null, productIds: [], excludeProductIds: [], categoryIds: [], freeShipping: false },
      shipping: { id: 'm1', type: 'flat_rate', title: 'Standard', cost: 500 },
      destination: { country: 'XK', state: '', postcode: '' },
      settings: defaultShopSettings(),
    });
    expect(t.subtotal).toBe(6000);
    expect(t.discountTotal).toBe(600);
    expect(t.lines.map((l) => l.discount)).toEqual([500, 100]);
    expect(t.shippingTotal).toBe(500);
    expect(t.taxTotal).toBe(0);
    expect(t.total).toBe(5900);
    expect(t.coupon?.amount).toBe(600);
    expect(t.couponError).toBeNull();
  });

  it('restricts coupons to products / categories and enforces minimum spend', () => {
    const base = { minSpend: null, maxSpend: null, productIds: [] as string[], excludeProductIds: [] as string[], categoryIds: [] as string[], freeShipping: false };
    const lines = [line(), line({ key: 'p2:', productId: 'p2', unitPrice: 1000, categoryIds: ['other'] })];
    const only = computeTotals({ lines, coupon: { code: 'C', type: 'fixed_cart', amount: 10_000, ...base, categoryIds: ['cat1'] }, shipping: null, destination: null, settings: defaultShopSettings() });
    expect(only.discountTotal).toBe(2500); // capped at the eligible subtotal
    const min = computeTotals({ lines, coupon: { code: 'C', type: 'percent', amount: 500, ...base, minSpend: 10_000 }, shipping: null, destination: null, settings: defaultShopSettings() });
    expect(min.discountTotal).toBe(0);
    expect(min.couponError).toMatch(/minimum spend/);
    const perItem = computeTotals({ lines: [line({ qty: 3 })], coupon: { code: 'C', type: 'fixed_product', amount: 300, ...base }, shipping: null, destination: null, settings: defaultShopSettings() });
    expect(perItem.discountTotal).toBe(900);
    const excluded = computeTotals({ lines: [line()], coupon: { code: 'C', type: 'percent', amount: 500, ...base, excludeProductIds: ['p1'] }, shipping: null, destination: null, settings: defaultShopSettings() });
    expect(excluded.couponError).toMatch(/does not apply/);
  });

  it('handles taxes included in prices and added on top', () => {
    const inclusive = settingsWith((s) => {
      s.tax.enabled = true;
      s.tax.pricesIncludeTax = true;
      s.tax.rates = [{ id: 'r', country: '', state: '', rate: 2000, name: 'VAT', shipping: true }];
    });
    const a = computeTotals({ lines: [line({ unitPrice: 1200 })], coupon: null, shipping: { id: 'm', type: 'flat_rate', title: 'S', cost: 600 }, destination: { country: 'DE', state: '', postcode: '' }, settings: inclusive });
    expect(a.total).toBe(1800);
    expect(a.taxTotal).toBe(200 + 100);
    const exclusive = settingsWith((s) => {
      s.tax.enabled = true;
      s.tax.pricesIncludeTax = false;
      s.tax.rates = [{ id: 'r', country: 'DE', state: '', rate: 1900, name: 'VAT', shipping: false }];
    });
    const b = computeTotals({ lines: [line({ unitPrice: 1000 })], coupon: null, shipping: { id: 'm', type: 'flat_rate', title: 'S', cost: 500 }, destination: { country: 'DE', state: '', postcode: '' }, settings: exclusive });
    expect(b.taxTotal).toBe(190);
    expect(b.total).toBe(1690);
    const elsewhere = computeTotals({ lines: [line({ unitPrice: 1000 })], coupon: null, shipping: null, destination: { country: 'FR', state: '', postcode: '' }, settings: exclusive });
    expect(elsewhere.taxTotal).toBe(0);
    expect(findTaxRate(exclusive.tax.rates, { country: 'de', state: '', postcode: '' })?.name).toBe('VAT');
  });

  it('skips shipping for virtual-only carts and honours free-shipping thresholds', () => {
    const settings = settingsWith((s) => {
      s.shipping.zones = [
        { id: 'eu', name: 'EU', countries: ['DE', 'FR'], methods: [{ id: 'free', type: 'free_shipping', title: 'Free', cost: 0, minAmount: 5000, enabled: true }, { id: 'flat', type: 'flat_rate', title: 'Flat', cost: 700, minAmount: 0, enabled: true }] },
        { id: 'rest', name: 'Rest', countries: [], methods: [{ id: 'world', type: 'flat_rate', title: 'World', cost: 2000, minAmount: 0, enabled: true }] },
      ];
    });
    expect(availableShippingMethods(settings, { country: 'DE', state: '', postcode: '' }, 2000).map((m) => m.id)).toEqual(['flat']);
    expect(availableShippingMethods(settings, { country: 'DE', state: '', postcode: '' }, 6000).map((m) => m.id)).toEqual(['free', 'flat']);
    expect(availableShippingMethods(settings, { country: 'US', state: '', postcode: '' }, 100).map((m) => m.id)).toEqual(['world']);
    const virtual = computeTotals({ lines: [line({ virtual: true })], coupon: null, shipping: { id: 'flat', type: 'flat_rate', title: 'Flat', cost: 700 }, destination: null, settings });
    expect(virtual.needsShipping).toBe(false);
    expect(virtual.shippingTotal).toBe(0);
    const freeCoupon = computeTotals({ lines: [line()], coupon: { code: 'SHIP', type: 'percent', amount: 0, minSpend: null, maxSpend: null, productIds: [], excludeProductIds: [], categoryIds: [], freeShipping: true }, shipping: { id: 'flat', type: 'flat_rate', title: 'Flat', cost: 700 }, destination: null, settings });
    expect(freeCoupon.shippingTotal).toBe(0);
    expect(freeCoupon.total).toBe(2500);
  });
});

describe('settings secrets', () => {
  it('encrypts, masks and keeps secrets when the admin leaves them blank or masked', () => {
    const enc = encryptSecret('sk_test_1234567890');
    expect(isEncrypted(enc)).toBe(true);
    expect(decryptSecret(enc)).toBe('sk_test_1234567890');
    expect(decryptSecret('garbage')).toBe('garbage');
    expect(decryptSecret('enc:v1:notbase64!!')).toBe('');

    const current = defaultShopSettings();
    current.payments.stripe.secretKey = enc;
    const masked = maskShopSettings(current);
    expect(masked.payments.stripe.secretKey).toMatch(/^••••••••7890$/);

    const keep = storableShopSettings({ ...masked }, current);
    expect(keep.payments.stripe.secretKey).toBe(enc);
    const blank = storableShopSettings({ ...masked, payments: { ...masked.payments, stripe: { ...masked.payments.stripe, secretKey: '' } } }, current);
    expect(blank.payments.stripe.secretKey).toBe(enc);
    const replaced = storableShopSettings({ ...masked, payments: { ...masked.payments, stripe: { ...masked.payments.stripe, secretKey: 'sk_live_new' } } }, current);
    expect(isEncrypted(replaced.payments.stripe.secretKey)).toBe(true);
    expect(decryptSecret(replaced.payments.stripe.secretKey)).toBe('sk_live_new');
  });
});

describe('order tracking timeline', () => {
  const base = { paymentMethod: 'stripe', paymentStatus: 'paid', placedAt: new Date('2026-11-01T10:00:00Z'), paidAt: new Date('2026-11-01T10:01:00Z'), completedAt: null, fulfillment: {} };
  it('walks placed → paid → packed → shipped → delivered', async () => {
    const { buildTracking } = await import('../src/lib/shop/tracking');
    const processing = buildTracking({ ...base, status: 'processing' } as never);
    expect(processing.steps.map((s) => `${s.id}:${s.state}`)).toEqual(['placed:done', 'paid:done', 'packed:current', 'shipped:upcoming', 'delivered:upcoming']);
    expect(processing.headline).toBe('Being prepared');
    expect(processing.percent).toBe(25);
    const shipped = buildTracking({ ...base, status: 'processing', fulfillment: { status: 'shipped', carrier: 'DHL', trackingNumber: 'X1', trackingUrl: 'javascript:alert(1)', shippedAt: '2026-11-02T09:00:00Z' } } as never);
    expect(shipped.headline).toBe('On its way');
    expect(shipped.steps.find((s) => s.id === 'shipped')?.detail).toBe('DHL · X1');
    expect(shipped.fulfillment.trackingUrl).toBe(''); // only http(s) links are kept
    const delivered = buildTracking({ ...base, status: 'completed', completedAt: new Date('2026-11-03T12:00:00Z') } as never);
    expect(delivered.percent).toBe(100);
    expect(delivered.headline).toBe('Delivered');
  });
  it('handles cash on delivery, bank transfers, virtual orders and cancellations', async () => {
    const { buildTracking } = await import('../src/lib/shop/tracking');
    const cod = buildTracking({ ...base, paymentMethod: 'cod', paymentStatus: 'unpaid', paidAt: null, status: 'processing' } as never);
    expect(cod.steps[1]).toMatchObject({ label: 'Pay on delivery', state: 'done' });
    const bank = buildTracking({ ...base, paymentMethod: 'bank_transfer', paymentStatus: 'unpaid', paidAt: null, status: 'on-hold' } as never);
    expect(bank.steps[1]).toMatchObject({ state: 'current', detail: 'Waiting for your bank transfer' });
    expect(bank.headline).toBe('Waiting for your payment');
    const virtual = buildTracking({ ...base, status: 'processing' } as never, { virtual: true });
    expect(virtual.steps.map((s) => s.id)).toEqual(['placed', 'paid', 'delivered']);
    const cancelled = buildTracking({ ...base, status: 'cancelled' } as never);
    expect(cancelled.stopped).toEqual({ label: 'Cancelled', tone: 'muted' });
    expect(cancelled.percent).toBe(0);
  });
});
