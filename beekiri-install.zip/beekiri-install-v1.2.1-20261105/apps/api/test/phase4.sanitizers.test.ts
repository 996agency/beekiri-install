import { execFileSync } from 'child_process';
import { createHash } from 'crypto';
import { mkdtempSync, readFileSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { describe, expect, it } from 'vitest';

/** No database needed: the PHP template helpers and the admin page policy. */

const RUNNER = join(__dirname, '../src/lib/layouts/php/layout-runner.php');

function phpAvailable(): boolean {
  try {
    execFileSync('php', ['-v'], { stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}

/** The runner's URL and rich-text helpers, run on their own. */
function runPhpHelpers(inputs: string[], fn: 'wp_kses_post' | 'esc_url'): string[] {
  const src = readFileSync(RUNNER, 'utf8');
  const start = src.indexOf("if (!function_exists('__bk_safe_url'))");
  const escUrlEnd = src.indexOf("if (!function_exists('esc_html__'))");
  const ksesStart = src.indexOf("if (!function_exists('__bk_kses'))");
  const ksesEnd = src.indexOf("if (!function_exists('wpautop'))");
  expect(start).toBeGreaterThan(0);
  expect(ksesStart).toBeGreaterThan(0);
  const dir = mkdtempSync(join(tmpdir(), 'bk-kses-'));
  const script = join(dir, 'check.php');
  writeFileSync(
    script,
    [
      '<?php',
      'function __bk_to_string($v): string { return is_string($v) ? $v : (string) $v; }',
      src.slice(start, escUrlEnd),
      src.slice(ksesStart, ksesEnd),
      '$in = json_decode(stream_get_contents(STDIN), true);',
      `echo json_encode(array_map('${fn}', $in));`,
    ].join('\n'),
  );
  const out = execFileSync('php', [script], { input: JSON.stringify(inputs) }).toString();
  return JSON.parse(out) as string[];
}

describe.skipIf(!phpAvailable())('PHP template helpers', () => {
  it('strip every script vector from rich text and keep formatting', () => {
    const attacks = [
      '<img/onerror=alert(1) src=x>',
      '<img src="x"onerror="alert(1)">',
      '<svg/onload=alert(1)>',
      '<script src=//evil.example/x.js>',
      '<a href="java&#x73;cript:alert(1)">a</a>',
      '<a href="java\tscript:alert(1)">b</a>',
      '<a href=javascript:alert(1)>c</a>',
      '<iframe srcdoc="<script>alert(1)</script>"></iframe>',
      '<noscript><p title="</noscript><img src=x onerror=alert(1)>">',
      '<math><mtext><table><mglyph><style><img src=x onerror=alert(1)>',
      '<details open ontoggle=alert(1)>x</details>',
      '<p style="background:url(javascript:alert(1))">s</p>',
    ];
    for (const out of runPhpHelpers(attacks, 'wp_kses_post')) {
      expect(out).not.toMatch(/<script|onerror|onload|ontoggle|javascript:|srcdoc|<svg|<iframe/i);
    }
    const [ok] = runPhpHelpers(
      ['<p>Hello <strong>world</strong> <a href="https://example.com">link</a></p>'],
      'wp_kses_post',
    );
    expect(ok).toBe('<p>Hello <strong>world</strong> <a href="https://example.com">link</a></p>');
  });

  it('esc_url refuses obfuscated script URLs', () => {
    const out = runPhpHelpers(
      ['java\tscript:alert(1)', '\u0001javascript:alert(1)', 'data:text/html,x', 'https://ok.example/', '/x'],
      'esc_url',
    );
    expect(out).toEqual(['', '', '', 'https://ok.example/', '/x']);
  });
});

describe('admin document policy', () => {
  it('allows only same-site scripts plus the exact inline snippets of the page', async () => {
    const { adminDocumentCsp } = await import('../src/middleware/security');
    const inline = "console.log('hi')";
    const html = `<html><head><script>${inline}</script><script type="module" src="/admin/assets/a.js"></script></head></html>`;
    const csp = adminDocumentCsp(html, 'example.com');
    const hash = createHash('sha256').update(inline).digest('base64');
    const scriptSrc = csp.split('; ').find((d) => d.startsWith('script-src'));
    expect(scriptSrc).toBe(`script-src 'self' 'sha256-${hash}'`);
    expect(csp).toContain("object-src 'none'");
    expect(csp).toContain("base-uri 'self'");
    expect(csp).toContain('connect-src \'self\' ws://example.com wss://example.com');
  });
});
