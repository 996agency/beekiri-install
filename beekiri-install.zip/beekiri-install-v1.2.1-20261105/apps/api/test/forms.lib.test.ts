import { describe, expect, it } from 'vitest';
import { visibleFieldIds } from '../src/lib/forms/conditions';
import { mergeHtml, mergeRecipients, mergeText } from '../src/lib/forms/merge';
import { renderForm } from '../src/lib/forms/render';
import { defaultFormSettings, formPages, parseFormFields, parseFormSettings, type FormField } from '../src/lib/forms/schema';
import { checkFormToken, makeFormToken } from '../src/lib/forms/token';
import { validateSubmission } from '../src/lib/forms/validate';

const fields = (): FormField[] =>
  parseFormFields([
    { id: 'name', type: 'text', label: 'Name', required: true },
    { id: 'email', type: 'email', label: 'Email', required: true },
    { id: 'topic', type: 'select', label: 'Topic', options: ['Sales', 'Support'], required: true },
    { id: 'order', type: 'text', label: 'Order number', conditional: { action: 'show', match: 'all', rules: [{ field: 'topic', op: 'is', value: 'Support' }] }, required: true },
    { id: 'cv', type: 'file', label: 'CV', accept: ['pdf'], maxFiles: 1 },
    { id: 'ok', type: 'consent', label: 'Consent', text: 'I agree' },
    { id: 'pb', type: 'page', label: 'Step 2' },
    { id: 'msg', type: 'textarea', label: 'Message' },
  ]);

describe('parseFormFields', () => {
  it('keeps ids, derives unique snake_case names and drops unknown types', () => {
    const out = parseFormFields([
      { id: 'a', type: 'text', label: 'Your Name' },
      { id: 'b', type: 'text', label: 'Your Name' },
      { id: 'c', type: 'bogus', label: 'X' },
      { type: 'select', label: 'Pick', options: [{ label: 'One', value: '1' }, 'Two'] },
    ]);
    expect(out.map((f) => f.name)).toEqual(['your_name', 'your_name_2', 'x', 'pick']);
    expect(out[2].type).toBe('text');
    expect(out[3].options).toEqual([
      { label: 'One', value: '1' },
      { label: 'Two', value: 'Two' },
    ]);
  });

  it('drops conditions that point at unknown fields', () => {
    const out = parseFormFields([
      { id: 'a', type: 'text', label: 'A', conditional: { rules: [{ field: 'zzz', op: 'is', value: '1' }] } },
    ]);
    expect(out[0].conditional).toBeUndefined();
  });

  it('splits pages at page breaks', () => {
    const pages = formPages(fields());
    expect(pages).toHaveLength(2);
    expect(pages[1].title).toBe('Step 2');
    expect(pages[1].fields.map((f) => f.id)).toEqual(['msg']);
  });
});

describe('parseFormSettings', () => {
  it('fills defaults and bounds values', () => {
    const s = parseFormSettings({ minSeconds: 999, confirmation: { type: 'redirect', url: '/thanks' }, notification: { enabled: false } });
    expect(s.minSeconds).toBe(60);
    expect(s.confirmation).toEqual({ type: 'redirect', url: '/thanks' });
    expect(s.notification.enabled).toBe(false);
    expect(s.notification.to).toBe('{admin_email}');
    expect(parseFormSettings(null)).toEqual(defaultFormSettings());
  });
});

describe('conditions', () => {
  it('hides a field until its rule is met', () => {
    const f = fields();
    expect(visibleFieldIds(f, { topic: 'Sales' }).has('order')).toBe(false);
    expect(visibleFieldIds(f, { topic: 'Support' }).has('order')).toBe(true);
  });
});

describe('validateSubmission', () => {
  it('reports required, format and option errors', () => {
    const r = validateSubmission(fields(), { values: { email: 'nope', topic: 'Other' }, files: [] });
    const msgs = r.errors.map((e) => e.field);
    expect(msgs).toContain('name');
    expect(msgs).toContain('email');
    expect(msgs).toContain('topic');
    expect(msgs).toContain('ok');
  });

  it('skips hidden fields and accepts a clean submission', () => {
    const r = validateSubmission(fields(), {
      values: { name: ' Ada ', email: 'ada@example.com', topic: 'Sales', ok: '1', msg: 'Hi' },
      files: [],
    });
    expect(r.errors).toEqual([]);
    expect(r.values.name).toBe('Ada');
    expect(r.values.ok).toBe('Yes');
    expect('order' in r.values).toBe(false);
  });

  it('requires the conditional field once shown and checks file types', () => {
    const r = validateSubmission(fields(), {
      values: { name: 'A', email: 'a@b.co', topic: 'Support', ok: '1' },
      files: [{ fieldId: 'cv', name: 'evil.html', mime: 'text/html', size: 10 }],
    });
    expect(r.errors.map((e) => e.field)).toEqual(expect.arrayContaining(['order', 'cv']));
    const ok = validateSubmission(fields(), {
      values: { name: 'A', email: 'a@b.co', topic: 'Support', order: '12', ok: '1' },
      files: [{ fieldId: 'cv', name: 'cv.pdf', mime: 'application/pdf', size: 10 }],
    });
    expect(ok.errors).toEqual([]);
    expect(ok.values.cv).toHaveLength(1);
  });

  it('refuses files for fields that are not file fields', () => {
    const r = validateSubmission(fields(), {
      values: { name: 'A', email: 'a@b.co', topic: 'Sales', ok: '1' },
      files: [{ fieldId: 'name', name: 'x.pdf', mime: 'application/pdf', size: 1 }],
    });
    expect(r.errors.some((e) => e.message === 'Unexpected file.')).toBe(true);
  });
});

describe('token', () => {
  it('accepts an aged token for its form only', () => {
    const t = makeFormToken("f1", 1_700_000_000_000);
    expect(checkFormToken('f1', t, 3, 1_700_000_000_000 + 1000)).toEqual({ ok: false, reason: 'too_fast' });
    expect(checkFormToken('f1', t, 3, 1_700_000_000_000 + 5000).ok).toBe(true);
    expect(checkFormToken('f2', t, 3, 1_700_000_000_000 + 5000)).toEqual({ ok: false, reason: 'invalid' });
    expect(checkFormToken('f1', t, 3, 1_700_000_000_000 + 25 * 3600 * 1000)).toEqual({ ok: false, reason: 'expired' });
    expect(checkFormToken('f1', 'garbage', 3).ok).toBe(false);
  });
});

describe('merge tags', () => {
  const ctx = {
    formTitle: 'Contact',
    fields: fields(),
    values: { name: 'Ada', email: 'ada@example.com', topic: 'Sales', msg: 'Hello <b>there</b>\nBye', ok: 'Yes' },
    entryId: 'e1',
    pageUrl: 'https://site.test/contact',
    siteTitle: 'Site',
    adminEmail: 'owner@site.test',
    date: new Date('2026-11-06T10:00:00Z'),
  };
  it('replaces field and simple tags in text', () => {
    expect(mergeText('Hi {field:name} from {form_title} ({entry_id}) {nope}', ctx)).toBe('Hi Ada from Contact (e1) {nope}');
    expect(mergeText('{all_fields}', ctx)).toContain('Message: Hello <b>there</b>');
  });
  it('escapes HTML and renders all_fields as a table', () => {
    const html = mergeHtml('Msg: {field:msg}\n{all_fields}', ctx);
    expect(html).toContain('&lt;b&gt;there&lt;/b&gt;<br>');
    expect(html).toContain('<table');
    expect(html).not.toContain('<b>there</b>');
  });
  it('resolves recipients', () => {
    expect(mergeRecipients('{admin_email}, {field:email}; bad', ctx)).toEqual(['owner@site.test', 'ada@example.com']);
  });
});

describe('renderForm', () => {
  it('emits every field, the honeypot, token, steps and the client definition', () => {
    const html = renderForm({ id: 'f1', title: 'Contact', definition: { fields: fields(), settings: defaultFormSettings() }, token: 'tok', action: '/api/forms/public/f1/submit' });
    expect(html).toContain('data-bee-form="f1"');
    expect(html).toContain('name="f_name"');
    expect(html).toContain('name="_bk_hp"');
    expect(html).toContain('value="tok"');
    expect(html).toContain('data-page="1"');
    expect(html).toContain('data-bee-form-def');
    const def = html.match(/data-bee-form-def>([^<]*)<\/script>/)?.[1] ?? '';
    expect(JSON.parse(def).fields.map((f: { id: string }) => f.id)).toContain('order');
    expect(html).toContain('accept=".pdf"');
    const preview = renderForm({ id: 'f1', title: 'Contact', definition: { fields: fields(), settings: defaultFormSettings() }, token: '', action: '#', preview: true });
    expect(preview).not.toContain('_bk_hp');
  });
});
