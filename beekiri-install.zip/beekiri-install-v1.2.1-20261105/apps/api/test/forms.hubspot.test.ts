import { createServer, type Server } from 'node:http';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  buildHubspotProperties,
  coerceForHubspot,
  consentGiven,
  parseIntegrations,
  suggestHubspotMapping,
  type EntryContext,
  type HubspotProperty,
} from '../src/lib/forms/integrations';
import { parseFormFields } from '../src/lib/forms/schema';

const fields = parseFormFields([
  { id: 'n', type: 'text', label: 'Name' },
  { id: 'e', type: 'email', label: 'Email' },
  { id: 'p', type: 'phone', label: 'Phone' },
  { id: 'c', type: 'text', label: 'Company' },
  { id: 'i', type: 'checkbox', label: 'Interests', options: ['Web', 'SEO', 'Ads'] },
  { id: 'd', type: 'date', label: 'Start date' },
  { id: 'm', type: 'textarea', label: 'Message' },
  { id: 'ok', type: 'consent', label: 'Marketing consent' },
]);

const ctx = (values: Record<string, unknown>): EntryContext => ({
  fields,
  values,
  meta: { pageUrl: 'https://site.test/contact', country: 'DE', attribution: { visit: { channel: 'Paid social', source: 'LinkedIn Ads', campaign: 'autumn' }, first: null } },
  formTitle: 'Contact',
  entryId: 'e1',
  createdAt: new Date('2026-11-06T10:00:00Z'),
});

const schema = new Map<string, HubspotProperty>(
  [
    { name: 'email', label: 'Email', type: 'string', fieldType: 'text' },
    { name: 'firstname', label: 'First name', type: 'string', fieldType: 'text' },
    { name: 'lastname', label: 'Last name', type: 'string', fieldType: 'text' },
    { name: 'phone', label: 'Phone', type: 'string', fieldType: 'phonenumber' },
    { name: 'interests', label: 'Interests', type: 'enumeration', fieldType: 'checkbox', options: [{ label: 'Web', value: 'web' }, { label: 'SEO', value: 'seo' }] },
    { name: 'start_date', label: 'Start', type: 'date', fieldType: 'date' },
    { name: 'lifecyclestage', label: 'Lifecycle stage', type: 'enumeration', fieldType: 'radio', options: [{ label: 'Lead', value: 'lead' }] },
    { name: 'utm_campaign_custom', label: 'Campaign', type: 'string', fieldType: 'text' },
    { name: 'hs_object_id', label: 'Record ID', type: 'number', fieldType: 'number', readOnly: true },
  ].map((p) => [p.name, p as HubspotProperty]),
);

describe('mapping', () => {
  it('suggests a sensible mapping', () => {
    const rows = suggestHubspotMapping(fields);
    const by = Object.fromEntries(rows.map((r) => [r.property, r.source]));
    expect(by.email).toEqual({ kind: 'field', field: 'email' });
    expect(by.firstname).toEqual({ kind: 'field', field: 'name', part: 'first' });
    expect(by.lastname).toEqual({ kind: 'field', field: 'name', part: 'last' });
    expect(by.phone).toEqual({ kind: 'field', field: 'phone' });
    expect(by.company).toEqual({ kind: 'field', field: 'company' });
    expect(by.message).toEqual({ kind: 'field', field: 'message' });
    expect(by.lifecyclestage).toEqual({ kind: 'static', value: 'lead' });
  });

  it('parses feeds defensively', () => {
    const f = parseIntegrations({ hubspot: { enabled: true, mapping: [{ property: 'email', source: { kind: 'field', field: 'email' } }, { property: 'bad name!', source: { kind: 'static', value: 'x' } }, { property: 'email', source: { kind: 'static', value: 'dup' } }], consentField: 'ok', addNote: true } });
    expect(f.hubspot.mapping).toHaveLength(1);
    expect(f.hubspot.consentField).toBe('ok');
    expect(parseIntegrations(null).hubspot.enabled).toBe(false);
  });

  it('builds properties with types, name parts, source data and warnings', () => {
    const feed = parseIntegrations({
      hubspot: {
        enabled: true,
        mapping: [
          { property: 'email', source: { kind: 'field', field: 'email' } },
          { property: 'firstname', source: { kind: 'field', field: 'name', part: 'first' } },
          { property: 'lastname', source: { kind: 'field', field: 'name', part: 'last' } },
          { property: 'interests', source: { kind: 'field', field: 'interests' } },
          { property: 'start_date', source: { kind: 'field', field: 'start_date' } },
          { property: 'lifecyclestage', source: { kind: 'static', value: 'Lead' } },
          { property: 'utm_campaign_custom', source: { kind: 'meta', key: 'campaign' } },
          { property: 'hs_object_id', source: { kind: 'static', value: '1' } },
          { property: 'gone_property', source: { kind: 'static', value: '1' } },
        ],
      },
    }).hubspot;
    const out = buildHubspotProperties(feed, ctx({ n: 'Ada King Lovelace', e: ' Ada@Example.COM ', i: ['Web', 'Ads'], d: '2026-12-01' }), schema);
    expect(out.properties).toEqual({
      email: 'ada@example.com',
      firstname: 'Ada',
      lastname: 'King Lovelace',
      interests: 'web',
      start_date: String(Date.UTC(2026, 11, 1)),
      lifecyclestage: 'lead',
      utm_campaign_custom: 'autumn',
    });
    expect(out.warnings.join(' ')).toMatch(/Ads/);
    expect(out.warnings.join(' ')).toMatch(/read-only/);
    expect(out.warnings.join(' ')).toMatch(/no longer exists/);
  });

  it('coerces values', () => {
    expect(coerceForHubspot({ name: 'b', label: 'B', type: 'enumeration', fieldType: 'booleancheckbox' }, 'Yes').value).toBe('true');
    expect(coerceForHubspot({ name: 'n', label: 'N', type: 'number', fieldType: 'number' }, '1 200,5').value).toBe('1200.5');
    expect(coerceForHubspot({ name: 'n', label: 'N', type: 'number', fieldType: 'number' }, 'abc').value).toBeNull();
    expect(coerceForHubspot(undefined, ['a', 'b']).value).toBe('a, b');
    expect(coerceForHubspot(undefined, '').value).toBeNull();
  });

  it('checks consent', () => {
    const feed = parseIntegrations({ hubspot: { enabled: true, consentField: 'marketing_consent', mapping: [] } }).hubspot;
    expect(consentGiven(feed, ctx({ ok: 'Yes' }))).toBe(true);
    expect(consentGiven(feed, ctx({ ok: 'No' }))).toBe(false);
  });
});

/* ── Client against a mock HubSpot ──────────────────────────────────── */

type Contact = { id: string; properties: Record<string, string> };
const contacts: Contact[] = [];
const calls: string[] = [];
let server: Server;
let client: typeof import('../src/services/forms/hubspot.client');

beforeAll(async () => {
  server = createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      calls.push(`${req.method} ${req.url}`);
      const send = (status: number, json: unknown) => {
        res.writeHead(status, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(json));
      };
      if (req.headers.authorization !== 'Bearer pat-good') return send(401, { status: 'error', message: 'Authentication credentials not found.', category: 'INVALID_AUTHENTICATION' });
      const url = new URL(req.url ?? '/', 'http://x');
      const data = body ? JSON.parse(body) : {};
      const byEmail = url.pathname.match(/^\/crm\/v3\/objects\/contacts\/([^/]+)$/);
      if (req.method === 'PATCH' && byEmail) {
        const key = decodeURIComponent(byEmail[1]);
        const c = url.searchParams.get('idProperty') === 'email' ? contacts.find((x) => x.properties.email === key) : contacts.find((x) => x.id === key);
        if (!c) return send(404, { message: 'resource not found' });
        if (data.properties.phone === 'bad') return send(400, { message: 'Property values were not valid', category: 'VALIDATION_ERROR', errors: [{ message: 'bad phone', context: { propertyName: ['phone'] } }] });
        Object.assign(c.properties, data.properties);
        return send(200, c);
      }
      if (req.method === 'POST' && url.pathname === '/crm/v3/objects/contacts') {
        if (data.properties.email === 'race@example.com') {
          contacts.push({ id: '777', properties: { email: 'race@example.com' } });
          return send(409, { message: 'Contact already exists. Existing ID: 777', category: 'CONFLICT' });
        }
        if (data.properties.phone === 'bad') return send(400, { message: 'Property values were not valid', category: 'VALIDATION_ERROR', errors: [{ message: 'bad phone', context: { propertyName: ['phone'] } }] });
        const c = { id: String(100 + contacts.length), properties: data.properties };
        contacts.push(c);
        return send(201, c);
      }
      if (url.pathname === '/crm/v3/properties/contacts') return send(200, { results: [{ name: 'email', label: 'Email', type: 'string', fieldType: 'text' }] });
      if (url.pathname === '/account-info/v3/details') return send(200, { portalId: 4242, uiDomain: 'app-eu1.hubspot.com' });
      return send(404, { message: 'nope' });
    });
  });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => r()));
  const port = (server.address() as { port: number }).port;
  process.env.BEEKIRI_HUBSPOT_API_BASE = `http://127.0.0.1:${port}`;
  client = await import('../src/services/forms/hubspot.client');
});

afterAll(() => new Promise<void>((r) => server.close(() => r())));

describe('hubspot client', () => {
  it('creates, then updates the same contact instead of duplicating', async () => {
    const a = await client.upsertContact('pat-good', 'lead@example.com', { firstname: 'Lead' });
    expect(a.created).toBe(true);
    const b = await client.upsertContact('pat-good', 'lead@example.com', { firstname: 'Lead 2' });
    expect(b).toEqual({ id: a.id, created: false });
    expect(contacts.filter((c) => c.properties.email === 'lead@example.com')).toHaveLength(1);
    expect(contacts.find((c) => c.id === a.id)?.properties.firstname).toBe('Lead 2');
  });

  it('handles a create race (409 with the existing id)', async () => {
    const r = await client.upsertContact('pat-good', 'race@example.com', { firstname: 'R' });
    expect(r).toEqual({ id: '777', created: false });
  });

  it('reports bad tokens and invalid properties precisely', async () => {
    await expect(client.upsertContact('pat-bad', 'x@example.com', {})).rejects.toMatchObject({ kind: 'auth', retryable: false });
    try {
      await client.upsertContact('pat-good', 'new@example.com', { phone: 'bad' });
      throw new Error('should fail');
    } catch (e) {
      expect(e).toBeInstanceOf(client.HubspotError);
      expect(client.invalidProperties(e as InstanceType<typeof client.HubspotError>)).toEqual(['phone']);
    }
  });

  it('reads account details and properties', async () => {
    expect((await client.accountDetails('pat-good')).portalId).toBe(4242);
    expect((await client.contactProperties('pat-good')).map((p) => p.name)).toEqual(['email']);
  });

  it('treats an unreachable HubSpot as retryable', async () => {
    const saved = process.env.BEEKIRI_HUBSPOT_API_BASE;
    expect(saved).toBeTruthy();
    const err = new client.HubspotError('network', 'down');
    expect(err.retryable).toBe(true);
    expect(new client.HubspotError('rate_limit', 'slow').retryable).toBe(true);
    expect(new client.HubspotError('validation', 'bad').retryable).toBe(false);
  });
});
