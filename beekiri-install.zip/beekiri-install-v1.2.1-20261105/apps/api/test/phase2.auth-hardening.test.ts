import type { Express } from 'express';
import request from 'supertest';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

/**
 * Authentication hardening. Same throwaway-database rule as phase1:
 * createdb beekiri_test && TEST_DB_NAME=beekiri_test npm test
 */
const TEST_DB_NAME = process.env.TEST_DB_NAME;
const ORIGIN = 'http://localhost';

const OWNER = {
  language: 'en_US',
  siteTitle: 'Hardening Site',
  username: 'owner',
  password: 'Str0ng!Passw0rd',
  email: 'owner@example.com',
  blogPublic: false,
  frontendRuntime: 'php',
};
const EDITOR = { username: 'editor', password: 'Ed1tor!Passw0rd', email: 'editor@example.com' };

type Auth = { cookie: string; csrf: string; id: string };

describe.skipIf(!TEST_DB_NAME)('Phase 2 auth hardening', () => {
  let app: Express;
  let db: typeof import('../src/db/sequelize');
  let clearRateLimits: () => void;

  const login = async (username: string, password: string): Promise<Auth> => {
    clearRateLimits();
    const res = await request(app)
      .post('/api/auth/login')
      .set('Origin', ORIGIN)
      .send({ login: username, password });
    expect(res.status).toBe(201);
    const setCookie = ([] as string[]).concat(res.headers['set-cookie'] ?? []);
    return {
      cookie: setCookie[0]!.split(';')[0]!,
      csrf: res.body.csrfToken as string,
      id: res.body.user.id as string,
    };
  };

  const as = (auth: Auth, req: request.Test) =>
    req.set('Cookie', auth.cookie).set('Origin', ORIGIN).set('X-CSRF-Token', auth.csrf);

  beforeAll(async () => {
    Object.assign(process.env, {
      NODE_ENV: 'test',
      DB_NAME: TEST_DB_NAME,
      APP_URL: ORIGIN,
      MEDIA_LOCAL_PATH: '/tmp/beekiri-test-uploads',
      BEEKIRI_SETUP_TOKEN_FILE: `/tmp/beekiri-test-setup-token-${process.pid}`,
    });
    const { runMigrations } = await import('../src/db/migrator');
    db = await import('../src/db/sequelize');
    const models = await import('../src/models');
    ({ clearRateLimits } = await import('../src/utils/rate-limit'));
    const { createApp } = await import('../src/app');

    await runMigrations();
    const tables = Object.values(db.sequelize.models)
      .map((m) => m.getTableName() as string)
      .filter((t) => t !== 'SequelizeMeta')
      .map((t) => `"${t}"`)
      .join(', ');
    await db.sequelize.query(`TRUNCATE ${tables} CASCADE`);
    await models.InstallationState.create({ id: 1, installed: false });
    clearRateLimits();
    app = createApp();
    const { ensureSetupToken } = await import('../src/lib/setup-token');
    const install = await request(app)
      .post('/api/install')
      .set('X-Setup-Token', ensureSetupToken())
      .send(OWNER);
    expect(install.status).toBe(201);
  });

  afterAll(async () => {
    await db?.closeDatabase();
  });

  it('builds password reset links from APP_URL, never from a spoofed Host header', async () => {
    clearRateLimits();
    const res = await request(app)
      .post('/api/auth/lost-password')
      .set('Host', 'evil.example')
      .set('Origin', 'http://evil.example')
      .send({ userLogin: OWNER.username });
    expect(res.status).toBe(201);
    // Outside production with no SMTP the link is echoed back for development.
    expect(res.body.devResetLink).toMatch(/^http:\/\/localhost\/admin\/reset-password\?key=/);
    expect(res.body.devResetLink).not.toContain('evil.example');
  });

  it('requires the current password to change your own email or password', async () => {
    const owner = await login(OWNER.username, OWNER.password);
    const url = `/api/users/${owner.id}`;

    const noCurrent = await as(owner, request(app).patch(url)).send({ password: 'An0ther!Passw0rd' });
    expect(noCurrent.status).toBe(403);

    const wrongCurrent = await as(owner, request(app).patch(url)).send({
      password: 'An0ther!Passw0rd',
      currentPassword: 'not-the-password',
    });
    expect(wrongCurrent.status).toBe(403);

    const emailOnly = await as(owner, request(app).patch(url)).send({ email: 'new@example.com' });
    expect(emailOnly.status).toBe(403);

    const profileOnly = await as(owner, request(app).patch(url)).send({ displayName: 'The Owner' });
    expect(profileOnly.status).toBe(200);

    const weak = await as(owner, request(app).patch(url)).send({
      password: 'password',
      currentPassword: OWNER.password,
    });
    expect(weak.status).toBe(400);

    const ok = await as(owner, request(app).patch(url)).send({
      password: 'An0ther!Passw0rd',
      currentPassword: OWNER.password,
    });
    expect(ok.status).toBe(200);
    // Every session of that account is closed after a password change.
    expect((await request(app).get('/api/site/dashboard').set('Cookie', owner.cookie)).status).toBe(401);

    // Put the password back for the remaining tests.
    const again = await login(OWNER.username, 'An0ther!Passw0rd');
    const restore = await as(again, request(app).patch(url)).send({
      password: OWNER.password,
      currentPassword: 'An0ther!Passw0rd',
    });
    expect(restore.status).toBe(200);
  });

  it('keeps administrator accounts out of reach of users who merely hold edit_users', async () => {
    const owner = await login(OWNER.username, OWNER.password);

    const created = await as(owner, request(app).post('/api/users')).send({
      ...EDITOR,
      role: 'editor',
    });
    expect(created.status).toBe(201);
    const editorId = created.body.id as string;

    const weak = await as(owner, request(app).post('/api/users')).send({
      username: 'weakling',
      email: 'weak@example.com',
      password: 'password',
      role: 'subscriber',
    });
    expect(weak.status).toBe(400);

    // The Owner hands the editor every user-management capability.
    const grant = await as(owner, request(app).patch(`/api/users/${editorId}/permissions`)).send({
      capabilities: [
        'edit_posts', 'edit_others_posts', 'publish_posts', 'delete_posts',
        'edit_pages', 'edit_others_pages', 'publish_pages', 'delete_pages',
        'upload_files', 'moderate_comments', 'manage_categories', 'customize_dashboard', 'read',
        'list_users', 'create_users', 'edit_users', 'delete_users',
      ],
    });
    expect(grant.status).toBe(200);

    const editor = await login(EDITOR.username, EDITOR.password);

    // No self-promotion, even with edit_users.
    const selfPromote = await as(editor, request(app).patch(`/api/users/${editor.id}`)).send({
      role: 'administrator',
    });
    expect(selfPromote.status).toBe(403);

    // No creating administrators.
    const makeAdmin = await as(editor, request(app).post('/api/users')).send({
      username: 'sneaky',
      email: 'sneaky@example.com',
      password: 'Sn3aky!Passw0rd',
      role: 'administrator',
    });
    expect(makeAdmin.status).toBe(403);

    // No touching the Owner (password, email or anything else).
    const ownerTakeover = await as(editor, request(app).patch(`/api/users/${owner.id}`)).send({
      password: 'Pwn3d!Passw0rd',
    });
    expect(ownerTakeover.status).toBe(403);
    const ownerRename = await as(editor, request(app).patch(`/api/users/${owner.id}`)).send({
      displayName: 'Renamed',
    });
    expect(ownerRename.status).toBe(403);
    const ownerDelete = await as(editor, request(app).delete(`/api/users/${owner.id}`));
    expect(ownerDelete.status).toBe(403);

    // Ordinary users are still manageable with those capabilities.
    const sub = await as(editor, request(app).post('/api/users')).send({
      username: 'reader',
      email: 'reader@example.com',
      password: 'R3ader!Passw0rd',
      role: 'subscriber',
    });
    expect(sub.status).toBe(201);
    const promoteToAuthor = await as(editor, request(app).patch(`/api/users/${sub.body.id}`)).send({
      role: 'author',
    });
    expect(promoteToAuthor.status).toBe(200);
    expect(promoteToAuthor.body.role).toBe('author');

    // The Owner still logs in with the original password.
    await login(OWNER.username, OWNER.password);
  });
});
