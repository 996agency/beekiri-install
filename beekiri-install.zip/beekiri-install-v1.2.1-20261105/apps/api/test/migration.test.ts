import { mkdtempSync, readFileSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { describe, expect, it } from 'vitest';
import { ArchiveWriter, isSafeRelPath, readArchive, readArchiveManifest, type ArchiveManifest } from '../src/lib/migration/archive';
import { deepReplace, keepOwnSecrets, makeReplacer, parentsFirst } from '../src/lib/migration/database';
import { diffMedia } from '../src/lib/migration/files';
import { normalizeSiteUrl, parseConnectionInfo, signRequest, verifyRequest, fromRemote } from '../src/lib/migration/remote';
import { parsePlan } from '../src/services/migration.service';

/** No database needed: the migration file format and the pure helpers around it. */

const manifest: ArchiveManifest = {
  format: 1,
  createdAt: '2026-11-04T00:00:00.000Z',
  purpose: 'export',
  label: 'test',
  source: { url: 'http://localhost:8788', name: 'Test', version: '1.1.0', siteId: 's1', migrations: ['a'], activeTheme: 'be-clinic' },
  themes: [{ slug: 'be-clinic', name: 'Be Clinic', version: '1.0.0', files: 1, fieldGroups: 0 }],
};

describe('migration file format', () => {
  it('writes and reads every kind of record, streaming files', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'bk-mig-'));
    const src = join(dir, 'style.css');
    const big = Buffer.alloc(300_000, 7);
    writeFileSync(src, big);
    const path = join(dir, 'a.beekiri');
    const w = new ArchiveWriter(path);
    await w.record({ t: 'manifest' }, JSON.stringify(manifest));
    await w.record({ t: 'theme-fields', theme: 'be-clinic', count: 0 }, '');
    await w.file({ area: 'theme', path: 'be-clinic/style.css' }, src, big.length);
    await w.record({ t: 'rows', table: 'Post', count: 2 }, '{"id":"1"}\n{"id":"2"}\n');
    await w.close();

    expect((await readArchiveManifest(path)).source.name).toBe('Test');
    const seen: string[] = [];
    for await (const entry of readArchive(path)) {
      seen.push(entry.header.t);
      if (entry.header.t === 'file') {
        const out = join(dir, 'copy.css');
        await entry.saveTo(out);
        expect(readFileSync(out).equals(big)).toBe(true);
      }
      if (entry.header.t === 'rows') expect((await entry.read()).toString()).toContain('"id":"2"');
    }
    expect(seen).toEqual(['manifest', 'theme-fields', 'file', 'rows', 'end']);
  });

  it('refuses files that are cut off or not migration files', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'bk-mig-'));
    const path = join(dir, 'a.beekiri');
    const w = new ArchiveWriter(path);
    await w.record({ t: 'manifest' }, JSON.stringify(manifest));
    await w.close();
    const whole = readFileSync(path);
    writeFileSync(join(dir, 'cut.beekiri'), whole.subarray(0, whole.length - 12));
    await expect(async () => {
      for await (const _ of readArchive(join(dir, 'cut.beekiri'))) void _;
    }).rejects.toThrow();
    writeFileSync(join(dir, 'junk.beekiri'), 'hello');
    await expect(readArchiveManifest(join(dir, 'junk.beekiri'))).rejects.toThrow(/not a Beekiri migration file/);
  });

  it('only accepts safe relative paths', () => {
    expect(isSafeRelPath('2026/11/photo.webp')).toBe(true);
    expect(isSafeRelPath('layouts/hero/hero.php')).toBe(true);
    for (const bad of ['../etc/passwd', '/abs/file', 'a/../../b', '.migrations/settings.json', 'a/.env', 'a\\b', 'a//b', '']) {
      expect(isSafeRelPath(bad)).toBe(false);
    }
  });
});

describe('find & replace', () => {
  it('replaces addresses in nested JSON, also with escaped slashes', () => {
    const fn = makeReplacer([{ find: '//localhost:8788', replace: '//staging.example.com' }])!;
    const out = deepReplace(
      { html: '<img src="http://localhost:8788/uploads/a.webp">', list: ['//localhost:8788/x'], php: 'http:\\/\\/localhost:8788\\/y', n: 4 },
      fn,
    );
    expect(out).toEqual({
      html: '<img src="http://staging.example.com/uploads/a.webp">',
      list: ['//staging.example.com/x'],
      php: 'http:\\/\\/staging.example.com\\/y',
      n: 4,
    });
  });

  it('does nothing without pairs', () => {
    expect(makeReplacer([])).toBeNull();
    expect(makeReplacer([{ find: '', replace: 'x' }])).toBeNull();
  });
});

describe('secrets stay with each site', () => {
  it("keeps this site's encrypted values and drops ones it cannot open", () => {
    const incoming = { stripe: { secretKey: 'enc:v1:FROM-OTHER-SITE', mode: 'live' }, publishable: 'pk_test' };
    expect(keepOwnSecrets(incoming, { stripe: { secretKey: 'enc:v1:MINE' } })).toEqual({
      stripe: { secretKey: 'enc:v1:MINE', mode: 'live' },
      publishable: 'pk_test',
    });
    expect(keepOwnSecrets(incoming, {})).toEqual({ stripe: { secretKey: '', mode: 'live' }, publishable: 'pk_test' });
  });
});

describe('site-to-site signatures', () => {
  const key = 'k'.repeat(43);
  const body = Buffer.from('{"a":1}');
  const sign = (time: string, nonce: string) => signRequest(key, 'POST', '/api/migration/remote/hello', time, nonce, body);

  it('accepts a correct signature once', () => {
    const time = String(Date.now());
    const nonce = 'a'.repeat(32);
    const signature = sign(time, nonce);
    expect(verifyRequest(key, 'POST', '/api/migration/remote/hello', { time, nonce, signature }, body)).toBe('ok');
    expect(verifyRequest(key, 'POST', '/api/migration/remote/hello', { time, nonce, signature }, body)).toBe('replay');
  });

  it('refuses a wrong key, a changed body or path, and old requests', () => {
    const time = String(Date.now());
    const signature = sign(time, 'b'.repeat(32));
    expect(verifyRequest('x'.repeat(43), 'POST', '/api/migration/remote/hello', { time, nonce: 'b'.repeat(32), signature }, body)).toBe('bad');
    expect(verifyRequest(key, 'POST', '/api/migration/remote/hello', { time, nonce: 'b'.repeat(32), signature }, Buffer.from('{}'))).toBe('bad');
    expect(verifyRequest(key, 'POST', '/api/migration/remote/import', { time, nonce: 'b'.repeat(32), signature }, body)).toBe('bad');
    const old = String(Date.now() - 10 * 60_000);
    expect(verifyRequest(key, 'POST', '/api/migration/remote/hello', { time: old, nonce: 'c'.repeat(32), signature: sign(old, 'c'.repeat(32)) }, body)).toBe('clock');
    expect(verifyRequest(key, 'POST', '/api/migration/remote/hello', {}, body)).toBe('missing');
  });
});

describe('connection info', () => {
  it('reads the address and key, in any layout', () => {
    const key = 'A'.repeat(43);
    expect(parseConnectionInfo(`https://staging.example.com/admin/settings\n${key}`)).toEqual({ url: 'https://staging.example.com', key });
    expect(parseConnectionInfo(`  ${key}   staging.example.com `)).toEqual({ url: 'https://staging.example.com', key });
    expect(() => parseConnectionInfo('https://staging.example.com')).toThrow();
    expect(() => normalizeSiteUrl('ftp://x')).toThrow();
  });

  it('names the other site in its messages', () => {
    expect(fromRemote('staging.example.com', 'Push is turned off on this site.')).toBe('Push is turned off on staging.example.com.');
    expect(fromRemote('staging.example.com', 'Disk full.')).toBe('staging.example.com: Disk full.');
  });
});

describe('plans', () => {
  it('needs something to migrate and never the core parent theme', () => {
    expect(() => parsePlan({})).toThrow();
    expect(() => parsePlan({ themes: ['beekiri'] })).toThrow();
    const plan = parsePlan({ database: true, themes: ['Be Clinic', 'be-clinic'], keep: ['analytics', 'nope'], media: false, mediaMirror: true });
    expect(plan.themes).toEqual(['be-clinic']);
    expect(plan.keep).toEqual(['analytics']);
    expect(plan.mediaMirror).toBe(false);
  });
});

describe('media and table order', () => {
  it('sends new and changed files, and removes extras only when mirroring', () => {
    const source = [
      { p: 'a.webp', s: 1, h: 'x' },
      { p: 'b.webp', s: 2, h: 'y' },
    ];
    const target = [
      { p: 'a.webp', s: 1, h: 'x' },
      { p: 'b.webp', s: 2, h: 'old' },
      { p: 'c.webp', s: 3, h: 'z' },
    ];
    expect(diffMedia(source, target, false)).toEqual({ send: [source[1]], remove: [] });
    expect(diffMedia(source, target, true).remove).toEqual(['c.webp']);
  });

  it('puts parents before children', () => {
    const fk = (table: string, refTable: string) => ({ table, column: 'x', refTable, refColumn: 'id', onDelete: 'c' });
    const order = parentsFirst(['Session', 'User', 'Role', 'Site'], [fk('Session', 'User'), fk('User', 'Role'), fk('User', 'Site')]);
    expect(order.indexOf('Role')).toBeLessThan(order.indexOf('User'));
    expect(order.indexOf('Site')).toBeLessThan(order.indexOf('User'));
    expect(order.indexOf('User')).toBeLessThan(order.indexOf('Session'));
  });
});
