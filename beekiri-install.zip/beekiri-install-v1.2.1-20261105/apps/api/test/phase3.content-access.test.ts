import type { Express } from 'express';
import request from 'supertest';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

/** Content ownership, published-state and HTML filtering. Throwaway database only. */
const TEST_DB_NAME = process.env.TEST_DB_NAME;
const ORIGIN = 'http://localhost';

const OWNER = {
  language: 'en_US',
  siteTitle: 'Content Site',
  username: 'owner',
  password: 'Str0ng!Passw0rd',
  email: 'owner@example.com',
  blogPublic: true,
  frontendRuntime: 'php',
};

type Auth = { cookie: string; csrf: string; id: string };
const SCRIPT = '<p>Hello</p><img src="x" onerror="alert(1)"><script>alert(2)</script><a href="javascript:alert(3)">x</a>';

describe.skipIf(!TEST_DB_NAME)('Phase 3 content access', () => {
  let app: Express;
  let db: typeof import('../src/db/sequelize');
  let clearRateLimits: () => void;

  const login = async (username: string, password: string): Promise<Auth> => {
    clearRateLimits();
    const res = await request(app)
      .post('/api/auth/login')
      .set('Origin', ORIGIN)
      .send({ login: username, password });
    expect(res.status).toBe(201);
    const setCookie = ([] as string[]).concat(res.headers['set-cookie'] ?? []);
    return { cookie: setCookie[0]!.split(';')[0]!, csrf: res.body.csrfToken, id: res.body.user.id };
  };
  const as = (auth: Auth, req: request.Test) =>
    req.set('Cookie', auth.cookie).set('Origin', ORIGIN).set('X-CSRF-Token', auth.csrf);

  const makeUser = async (owner: Auth, username: string, role: string) => {
    const res = await as(owner, request(app).post('/api/users')).send({
      username,
      email: `${username}@example.com`,
      password: `${username}-S3cret!Pass`,
      role,
    });
    expect(res.status).toBe(201);
    return login(username, `${username}-S3cret!Pass`);
  };

  beforeAll(async () => {
    Object.assign(process.env, {
      NODE_ENV: 'test',
      DB_NAME: TEST_DB_NAME,
      APP_URL: ORIGIN,
      MEDIA_LOCAL_PATH: '/tmp/beekiri-test-uploads',
      BEEKIRI_SETUP_TOKEN_FILE: `/tmp/beekiri-test-setup-token-${process.pid}`,
    });
    const { runMigrations } = await import('../src/db/migrator');
    db = await import('../src/db/sequelize');
    const models = await import('../src/models');
    ({ clearRateLimits } = await import('../src/utils/rate-limit'));
    const { createApp } = await import('../src/app');
    await runMigrations();
    const tables = Object.values(db.sequelize.models)
      .map((m) => m.getTableName() as string)
      .filter((t) => t !== 'SequelizeMeta')
      .map((t) => `"${t}"`)
      .join(', ');
    await db.sequelize.query(`TRUNCATE ${tables} CASCADE`);
    await models.InstallationState.create({ id: 1, installed: false });
    clearRateLimits();
    app = createApp();
    const { ensureSetupToken } = await import('../src/lib/setup-token');
    const install = await request(app)
      .post('/api/install')
      .set('X-Setup-Token', ensureSetupToken())
      .send(OWNER);
    expect(install.status).toBe(201);
  });

  afterAll(async () => {
    await db?.closeDatabase();
  });

  it('keeps authors and contributors to their own, unpublished items', async () => {
    const owner = await login(OWNER.username, OWNER.password);
    const author = await makeUser(owner, 'writer', 'author');
    const contributor = await makeUser(owner, 'helper', 'contributor');

    const ownerPost = await as(owner, request(app).post('/api/posts')).send({
      title: 'Owner post',
      content: '<p>Original</p>',
      status: 'publish',
    });
    expect(ownerPost.status).toBe(201);
    const ownerPostId = ownerPost.body.id as string;

    // Neither may touch someone else's post.
    for (const who of [author, contributor]) {
      const edit = await as(who, request(app).patch(`/api/posts/${ownerPostId}`)).send({
        content: '<p>Defaced</p>',
      });
      expect(edit.status).toBe(403);
      expect((await as(who, request(app).get(`/api/posts/${ownerPostId}`))).status).toBe(403);
      expect((await as(who, request(app).delete(`/api/posts/${ownerPostId}`))).status).toBe(403);
    }

    // The author publishes their own post and may keep editing it.
    const mine = await as(author, request(app).post('/api/posts')).send({
      title: 'Mine',
      content: '<p>Mine</p>',
      status: 'publish',
    });
    expect(mine.status).toBe(201);
    const again = await as(author, request(app).patch(`/api/posts/${mine.body.id}`)).send({
      content: '<p>Mine, edited</p>',
    });
    expect(again.status).toBe(200);

    // A contributor's draft, once an editor publishes it, is out of their hands.
    const draft = await as(contributor, request(app).post('/api/posts')).send({
      title: 'Draft',
      content: '<p>Draft</p>',
    });
    expect(draft.status).toBe(201);
    const stillMine = await as(contributor, request(app).patch(`/api/posts/${draft.body.id}`)).send({
      content: '<p>Draft, edited</p>',
    });
    expect(stillMine.status).toBe(200);
    const publish = await as(owner, request(app).patch(`/api/posts/${draft.body.id}`)).send({
      status: 'publish',
    });
    expect(publish.status).toBe(200);
    const afterPublish = await as(contributor, request(app).patch(`/api/posts/${draft.body.id}`)).send({
      content: '<p>Sneaky</p>',
    });
    expect(afterPublish.status).toBe(403);
    expect((await as(contributor, request(app).delete(`/api/posts/${draft.body.id}`))).status).toBe(403);

    // Scripts are stripped from what a contributor saves, kept for administrators.
    const scripted = await as(contributor, request(app).post('/api/posts')).send({
      title: 'Scripted',
      content: SCRIPT,
    });
    expect(scripted.status).toBe(201);
    const stored = JSON.stringify(scripted.body);
    expect(stored).not.toContain('<script');
    expect(stored).not.toContain('onerror');
    expect(stored).not.toContain('javascript:');
    expect(stored).toContain('<p>Hello</p>');

    // Layout field values inside the editor document get the same treatment.
    const withLayout = await as(contributor, request(app).post('/api/posts')).send({
      title: 'Layout',
      beekiricode: {
        version: 1,
        root: 'root',
        nodes: {
          root: { id: 'root', type: 'section', children: ['l1'] },
          l1: {
            id: 'l1',
            type: 'layout',
            layoutSlug: 'hero',
            fields: { body: '<p>Hi</p><img/onerror=alert(1) src=x>', title: 'a < b' },
          },
        },
      },
    });
    expect(withLayout.status).toBe(201);
    const savedDoc = JSON.stringify(withLayout.body);
    expect(savedDoc).not.toContain('onerror');
    expect(savedDoc).toContain('<p>Hi</p>');
    expect(savedDoc).toContain('a < b');

    const trusted = await as(owner, request(app).post('/api/posts')).send({
      title: 'Trusted',
      content: SCRIPT,
    });
    expect(trusted.status).toBe(201);
    expect(JSON.stringify(trusted.body)).toContain('<script');
  });

  it('limits delegated settings tabs to their own fields', async () => {
    const owner = await login(OWNER.username, OWNER.password);
    const sub = await makeUser(owner, 'mediaonly', 'subscriber');
    const grant = await as(owner, request(app).patch(`/api/users/${sub.id}/permissions`)).send({
      capabilities: ['read', 'customize_dashboard', 'manage_settings_media'],
    });
    expect(grant.status).toBe(200);
    const mediaOnly = await login('mediaonly', 'mediaonly-S3cret!Pass');

    const current = await as(mediaOnly, request(app).get('/api/site/settings'));
    expect(current.status).toBe(200);

    // Re-posting unchanged fields is fine; changing another tab's field is not.
    const same = await as(mediaOnly, request(app).patch('/api/site/settings')).send({
      title: current.body.title,
      media: current.body.media,
    });
    expect(same.status).toBe(200);
    const inject = await as(mediaOnly, request(app).patch('/api/site/settings')).send({
      customHeadHtml: '<script>alert(1)</script>',
    });
    expect(inject.status).toBe(403);
    const rename = await as(mediaOnly, request(app).patch('/api/site/settings')).send({
      title: 'Renamed by media user',
    });
    expect(rename.status).toBe(403);
  });
});
