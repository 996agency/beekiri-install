import cookieParser from 'cookie-parser';
import express, { Router, type Express } from 'express';
import { mkdirSync } from 'fs';
import { config } from './config/env';
import { mediaVariant } from './lib/media/media-variant';
import { resolveUploadsRoot } from './lib/media/media.paths';
import { errorHandler, notFoundHandler } from './middleware/error-handler';
import { requireAuth, requireCapabilities } from './middleware/authenticate';
import { apiRateLimit } from './middleware/rate-limit';
import {
  apiContentSecurityPolicy,
  corsMiddleware,
  siteSecurityHeaders,
} from './middleware/security';
import { requireConfiguredDatabase } from './middleware/setup';
import { apiRoutes } from './routes';
import { docsRoutes } from './routes/docs.routes';

/** Everything under /api: parsers, CORS and errors stay here so pages get untouched requests. */
function apiApp(): Router {
  const api = Router();
  api.use(apiContentSecurityPolicy);
  api.use(corsMiddleware);
  api.use(
    express.json({
      limit: config.server.jsonBodyLimit,
      // Payment webhooks verify a signature over the exact bytes received.
      verify: (req, _res, buf) => {
        if (req.url?.startsWith('/shop/webhooks/')) (req as express.Request & { rawBody?: Buffer }).rawBody = buf;
      },
    }),
  );
  api.use(express.urlencoded({ extended: false, limit: config.server.jsonBodyLimit }));
  api.use(cookieParser());
  // The API map (every route and the permission it needs) is for site administrators only.
  api.use(
    '/docs',
    requireConfiguredDatabase,
    apiRateLimit,
    requireAuth,
    requireCapabilities('manage_options'),
    docsRoutes,
  );
  api.use(requireConfiguredDatabase, apiRateLimit, apiRoutes);
  api.use(notFoundHandler);
  api.use(errorHandler);
  return api;
}

/**
 * One server for the whole site: /api, /uploads and, via `mountSite`, the admin
 * (/admin) and the website (everything else).
 */
export function createApp({ mountSite }: { mountSite?: (app: Express) => void } = {}): Express {
  const app = express();

  app.set('trust proxy', config.server.trustProxy);
  app.disable('x-powered-by');
  app.use(siteSecurityHeaders);

  const uploadsRoot = resolveUploadsRoot();
  mkdirSync(uploadsRoot, { recursive: true });
  // Phone-sized copies of photos (/uploads/_w828/…), made on first request.
  app.use('/uploads', mediaVariant(uploadsRoot));
  app.use(
    '/uploads',
    express.static(uploadsRoot, {
      dotfiles: 'deny',
      index: false,
      redirect: false,
      fallthrough: true,
      setHeaders(res, path) {
        // Upload names carry a content hash, so images can be cached for a year.
        if (/\.(webp|avif|jpe?g|png|gif)$/i.test(path)) {
          res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        }
        // Uploaded SVG/HTML must never execute as a page on the site's origin.
        res.setHeader(
          'Content-Security-Policy',
          "default-src 'none'; style-src 'unsafe-inline'; sandbox",
        );
      },
    }),
  );

  app.use('/api', apiApp());
  mountSite?.(app);
  app.use(notFoundHandler);
  return app;
}
