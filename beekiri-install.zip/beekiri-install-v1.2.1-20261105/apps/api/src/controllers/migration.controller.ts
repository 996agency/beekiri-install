import type { NextFunction, Request, Response } from 'express';
import { createReadStream } from 'fs';
import { HEADER_NONCE, HEADER_SIGNATURE, HEADER_TIME, verifyRequest } from '../lib/migration/remote';
import { readSettings } from '../lib/migration/storage';
import { selfOrigin } from '../middleware/security';
import { MAX_CHUNK, migrationService } from '../services/migration.service';
import { PayloadTooLarge, TooManyRequests, Unauthorized } from '../utils/http-error';

type Handler = (req: Request, res: Response, next: NextFunction) => unknown;
type WithBody = Request & { migrationBody?: Buffer };

const wrap =
  (fn: (req: Request, res: Response) => unknown): Handler =>
  async (req, res, next) => {
    try {
      const out = await fn(req, res);
      if (out !== undefined && !res.headersSent) res.json(out);
    } catch (error) {
      next(error);
    }
  };

/** Raw request bytes (file pieces and signed requests are not JSON-parsed). */
function readRaw(req: Request, limit: number): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    if (req.readableEnded) {
      resolve(Buffer.alloc(0));
      return;
    }
    const parts: Buffer[] = [];
    let size = 0;
    req.on('data', (chunk: Buffer) => {
      size += chunk.length;
      if (size > limit) {
        reject(PayloadTooLarge('That piece is too large.'));
        req.destroy();
        return;
      }
      parts.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(parts, size)));
    req.on('error', reject);
  });
}

const acting = (req: Request) => (req.auth ? { sessionId: req.auth.sessionId } : undefined);
const param = (req: Request, name: string) => String(req.params[name] ?? '');

/* ---------- site-to-site: signed with this site's connection key ---------- */

const failures = new Map<string, { count: number; until: number }>();
const FAIL_LIMIT = 20;
const FAIL_WINDOW_MS = 15 * 60_000;

export const verifySiteSignature: Handler = async (req, _res, next) => {
  try {
    const ip = req.ip ?? 'unknown';
    const now = Date.now();
    const seen = failures.get(ip);
    if (seen && seen.until > now && seen.count >= FAIL_LIMIT) {
      throw TooManyRequests('Too many refused migration requests from this address. Try again in 15 minutes.');
    }
    const time = Number(req.get(HEADER_TIME));
    if (!req.get(HEADER_SIGNATURE) || !req.get(HEADER_NONCE) || !Number.isFinite(time)) {
      throw Unauthorized('This request was not signed with a connection key.');
    }
    const body = await readRaw(req, MAX_CHUNK + 1024 * 1024);
    const result = verifyRequest(
      readSettings().key,
      req.method,
      req.originalUrl,
      { time: req.get(HEADER_TIME), nonce: req.get(HEADER_NONCE), signature: req.get(HEADER_SIGNATURE) },
      body,
    );
    if (result !== 'ok') {
      const fresh = !seen || seen.until <= now;
      failures.set(ip, { count: fresh ? 1 : seen.count + 1, until: fresh ? now + FAIL_WINDOW_MS : seen.until });
      if (failures.size > 5_000) failures.clear();
      throw Unauthorized(
        result === 'clock'
          ? 'The clocks of the two sites are more than 5 minutes apart. Correct the server time and try again.'
          : 'This site did not accept the connection key. Copy the connection info from Settings → Migration on this site again.',
      );
    }
    (req as WithBody).migrationBody = body;
    next();
  } catch (error) {
    next(error);
  }
};

const remote =
  (action: string): Handler =>
  async (req, res, next) => {
    try {
      const out = await migrationService.remote(
        action,
        (req as WithBody).migrationBody ?? Buffer.alloc(0),
        req.query as Record<string, unknown>,
        req.params as Record<string, string>,
        selfOrigin(req),
      );
      res.setHeader('Cache-Control', 'no-store');
      if (Buffer.isBuffer(out)) res.type('application/octet-stream').send(out);
      else res.json(out);
    } catch (error) {
      next(error);
    }
  };

/* ---------- admin ---------- */

function sendFile(res: Response, path: string, name: string) {
  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Cache-Control', 'no-store');
  res.attachment(name);
  createReadStream(path).pipe(res);
}

export const migrationController = {
  remote,

  overview: wrap((req) => migrationService.overview(selfOrigin(req))),
  settings: wrap((req) => migrationService.updateSettings((req.body ?? {}) as Record<string, unknown>, selfOrigin(req))),
  regenerateKey: wrap((req) => migrationService.regenerateKey(selfOrigin(req))),

  addConnection: wrap((req) => migrationService.addConnection((req.body ?? {}) as Record<string, unknown>, selfOrigin(req))),
  testConnection: wrap((req) => migrationService.testConnection(param(req, 'id'))),
  renameConnection: wrap((req) => migrationService.renameConnection(param(req, 'id'), (req.body as { label?: unknown })?.label)),
  removeConnection: wrap((req) => migrationService.removeConnection(param(req, 'id'))),

  start: wrap((req, res) => {
    res.status(202);
    return migrationService.start((req.body ?? {}) as Record<string, unknown>, selfOrigin(req), acting(req));
  }),
  exportFile: wrap((req, res) => {
    res.status(202);
    return migrationService.startExport((req.body as { plan?: unknown })?.plan, selfOrigin(req));
  }),
  download: wrap((req, res) => {
    const pkg = migrationService.download(param(req, 'id'));
    sendFile(res, pkg.path, pkg.name);
  }),

  createUpload: wrap((req) => {
    const body = (req.body ?? {}) as Record<string, unknown>;
    return migrationService.createUpload({ size: body.size, name: body.name, purpose: 'package' });
  }),
  uploadChunk: wrap(async (req) => {
    const body = await readRaw(req, MAX_CHUNK);
    return migrationService.appendChunk(param(req, 'id'), req.query.offset, body);
  }),
  inspect: wrap((req) => migrationService.inspectUpload(param(req, 'id'))),
  importFile: wrap((req, res) => {
    res.status(202);
    return migrationService.startImport((req.body ?? {}) as Record<string, unknown>, acting(req), selfOrigin(req));
  }),

  restore: wrap((req, res) => {
    res.status(202);
    return migrationService.startRestore(param(req, 'id'), acting(req), selfOrigin(req));
  }),
  backupDownload: wrap((req, res) => {
    const file = migrationService.backupFile(param(req, 'id'));
    sendFile(res, file.path, file.name);
  }),
  deleteBackup: wrap((req) => migrationService.deleteBackup(param(req, 'id'))),

  job: wrap((req) => migrationService.job(param(req, 'id'))),
  publicJob: wrap((req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    return migrationService.publicJob(param(req, 'id'));
  }),
  cancel: wrap((req) => migrationService.cancel(param(req, 'id'))),
};
