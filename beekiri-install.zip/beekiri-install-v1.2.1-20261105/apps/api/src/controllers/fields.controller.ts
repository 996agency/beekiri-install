import type { NextFunction, Request, Response } from 'express';
import { FIELD_TYPES, LOCATION_TARGETS } from '../lib/fields/fields.types';
import { createTerm, deleteTerm, listTerms, updateTerm } from '../lib/pages/page-taxonomies';
import { authUser } from '../middleware/authenticate';
import { fieldsService } from '../services/fields.service';
import { structureService } from '../services/structure.service';

const id = (req: Request) => req.params.id as string;
const csv = (v: unknown) => (typeof v === 'string' && v ? v.split(',') : []);

function canEditContent(req: Request): boolean {
  const caps = authUser(req).capabilities;
  return (
    caps.includes('edit_pages') ||
    caps.includes('edit_posts') ||
    caps.includes('manage_fields') ||
    caps.includes('edit_products')
  );
}

function locationLabel(value: string): string {
  if (value === 'user') return 'Users';
  if (value === 'media') return 'Media';
  return `${value[0].toUpperCase()}${value.slice(1)}s`;
}

export const fieldsController = {
  async meta(req: Request, res: Response, next: NextFunction) {
    try {
      const { postTypes } = await structureService.listPostTypes(authUser(req));
      const customLocations = postTypes
        .filter((p) => p.active)
        .map((p) => ({ value: p.slug, label: p.plural }));
      res.json({
        fieldTypes: FIELD_TYPES.map((type) => ({
          type,
          label: type.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
        })),
        locations: [
          ...LOCATION_TARGETS.map((value) => ({ value, label: locationLabel(value) })),
          ...customLocations,
        ],
      });
    } catch (error) {
      next(error);
    }
  },

  async lookupPosts(req: Request, res: Response, next: NextFunction) {
    try {
      if (!canEditContent(req)) {
        res.json({ posts: [] });
        return;
      }
      res.json(
        await fieldsService.lookupPosts(authUser(req), {
          types: csv(req.query.types),
          q: (req.query.q as string | undefined) ?? '',
          ids: csv(req.query.ids),
        }),
      );
    } catch (error) {
      next(error);
    }
  },

  async lookupUsers(req: Request, res: Response, next: NextFunction) {
    try {
      if (!canEditContent(req)) {
        res.json({ users: [] });
        return;
      }
      res.json(
        await fieldsService.lookupUsers(authUser(req), {
          q: (req.query.q as string | undefined) ?? '',
          ids: csv(req.query.ids),
          roles: csv(req.query.roles),
        }),
      );
    } catch (error) {
      next(error);
    }
  },

  // Field groups

  async list(req: Request, res: Response, next: NextFunction) {
    try {
      const status = String(req.query.status || '') === 'trash' ? 'trash' : 'all';
      res.json(await fieldsService.list(authUser(req), { status }));
    } catch (error) {
      next(error);
    }
  },

  async listSync(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await fieldsService.listSync(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  async applySync(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await fieldsService.applySync(authUser(req), req.body.keys));
    } catch (error) {
      next(error);
    }
  },

  async get(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await fieldsService.get(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await fieldsService.create(authUser(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await fieldsService.update(authUser(req), id(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async remove(req: Request, res: Response, next: NextFunction) {
    try {
      const force =
        String(req.query.force || '') === '1' ||
        String(req.query.force || '').toLowerCase() === 'true';
      res.json(await fieldsService.remove(authUser(req), id(req), { force }));
    } catch (error) {
      next(error);
    }
  },

  async restore(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await fieldsService.restore(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  // Post types

  async listPostTypes(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await structureService.listPostTypes(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  async createPostType(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await structureService.createPostType(authUser(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async updatePostType(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await structureService.updatePostType(authUser(req), id(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async removePostType(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await structureService.removePostType(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  // Taxonomies

  async listTaxonomies(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await structureService.listTaxonomies(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  async createTaxonomy(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await structureService.createTaxonomy(authUser(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async updateTaxonomy(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await structureService.updateTaxonomy(authUser(req), id(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async removeTaxonomy(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await structureService.removeTaxonomy(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  async createTerm(req: Request, res: Response, next: NextFunction) {
    try {
      if (!canEditContent(req)) {
        res.status(403).json({ message: 'You cannot edit content.' });
        return;
      }
      res.status(201).json(
        await createTerm(authUser(req).siteId, id(req), {
          name: req.body.name,
          slug: req.body.slug,
          parentId: req.body.parentId,
        }),
      );
    } catch (error) {
      next(error);
    }
  },

  async listTerms(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await listTerms(authUser(req).siteId, id(req)));
    } catch (error) {
      next(error);
    }
  },

  async updateTerm(req: Request, res: Response, next: NextFunction) {
    try {
      if (!canEditContent(req)) {
        res.status(403).json({ message: 'You cannot edit content.' });
        return;
      }
      res.json(await updateTerm(authUser(req).siteId, id(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async removeTerm(req: Request, res: Response, next: NextFunction) {
    try {
      if (!canEditContent(req)) {
        res.status(403).json({ message: 'You cannot edit content.' });
        return;
      }
      res.json(await deleteTerm(authUser(req).siteId, id(req)));
    } catch (error) {
      next(error);
    }
  },

  // Options pages

  async listOptionsPages(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await structureService.listOptionsPages(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  async createOptionsPage(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await structureService.createOptionsPage(authUser(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async updateOptionsPage(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await structureService.updateOptionsPage(authUser(req), id(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async removeOptionsPage(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await structureService.removeOptionsPage(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  // Settings

  async getSettings(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await structureService.getSettings(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  async updateSettings(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await structureService.updateSettings(authUser(req), req.body));
    } catch (error) {
      next(error);
    }
  },
};
