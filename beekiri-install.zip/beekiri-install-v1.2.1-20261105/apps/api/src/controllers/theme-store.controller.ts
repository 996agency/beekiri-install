import type { NextFunction, Request, Response } from 'express';
import { themeStoreService } from '../services/theme-store.service';
import { NotFound } from '../utils/http-error';

/** Appearance → Templates: the Beekiri Hub theme store. */
export const themeStoreController = {
  async catalog(_req: Request, res: Response, next: NextFunction) {
    try {
      res.setHeader('Cache-Control', 'no-store');
      res.json(await themeStoreService.catalog());
    } catch (error) {
      next(error);
    }
  },

  async purchase(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await themeStoreService.purchase(String(req.params.slug)));
    } catch (error) {
      next(error);
    }
  },

  async install(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await themeStoreService.install(String(req.params.slug)));
    } catch (error) {
      next(error);
    }
  },

  async screenshot(req: Request, res: Response, next: NextFunction) {
    try {
      const image = await themeStoreService.screenshot(String(req.params.slug));
      if (!image) throw NotFound('No screenshot');
      res.setHeader('Content-Type', image.type);
      res.setHeader('Cache-Control', 'private, max-age=3600');
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.end(image.body);
    } catch (error) {
      next(error);
    }
  },
};
