import { NotFound } from '../utils/http-error';
import { heatmapSnapshotService, isHeatmapDevice, type HeatmapDevice } from '../services/heatmap-snapshot.service';
import type { NextFunction, Request, Response } from 'express';
import { analyticsService } from '../services/analytics.service';
import type { AnalyticsRange } from '../validators/analytics.schema';

export const analyticsController = {
  async settings(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await analyticsService.settings());
    } catch (error) {
      next(error);
    }
  },

  async updateSettings(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await analyticsService.updateSettings(req.body));
    } catch (error) {
      next(error);
    }
  },

  async report(req: Request, res: Response, next: NextFunction) {
    try {
      const range = (req.query.range as AnalyticsRange | undefined) ?? '30d';
      const source = req.query.source === 'google' ? 'google' : 'beekiri';
      res.json(await analyticsService.report(range, source));
    } catch (error) {
      next(error);
    }
  },

  async live(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await analyticsService.live());
    } catch (error) {
      next(error);
    }
  },

  async heatmap(req: Request, res: Response, next: NextFunction) {
    try {
      const range = (req.query.range as AnalyticsRange | undefined) ?? '30d';
      const path = typeof req.query.path === 'string' ? req.query.path : undefined;
      const device = isHeatmapDevice(req.query.device) ? req.query.device : 'desktop';
      res.json(await analyticsService.heatmap(range, path, device));
    } catch (error) {
      next(error);
    }
  },

  /** The saved screenshot of a page (admin only; never under the public /uploads). */
  async heatmapSnapshot(req: Request, res: Response, next: NextFunction) {
    try {
      const device = req.query.device as HeatmapDevice;
      const image = await heatmapSnapshotService.readImage(String(req.query.path), device);
      if (!image) throw NotFound('No screenshot yet.');
      res.setHeader('Content-Type', 'image/webp');
      // The URL carries ?v=<capturedAt>, so a new screenshot is a new URL.
      res.setHeader('Cache-Control', 'private, max-age=31536000, immutable');
      res.send(image);
    } catch (error) {
      next(error);
    }
  },

  /** Take (or retake) the screenshot of a page now. */
  async captureHeatmapSnapshot(req: Request, res: Response, next: NextFunction) {
    try {
      const shot = await heatmapSnapshotService.capture(req.body.path, req.body.device);
      res.status(201).json({ capturedAt: shot.capturedAt, width: shot.width, height: shot.height });
    } catch (error) {
      next(error);
    }
  },
};
