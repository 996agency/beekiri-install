import type { NextFunction, Request, Response } from 'express';
import { authUser } from '../../middleware/authenticate';
import { shopPagesService } from '../../services/shop/shop-pages.service';
import { shopSettingsService } from '../../services/shop/shop-settings.service';

export const shopPagesController = {
  async listShopPages(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await shopPagesService.list(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  async resetShopPage(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await shopPagesService.reset(authUser(req), String(req.params.view ?? '')));
    } catch (error) {
      next(error);
    }
  },
};

export const shopSettingsController = {
  async getSettings(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await shopSettingsService.getForAdmin(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  async updateSettings(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await shopSettingsService.update(authUser(req), req.body, req.ip));
    } catch (error) {
      next(error);
    }
  },
};
