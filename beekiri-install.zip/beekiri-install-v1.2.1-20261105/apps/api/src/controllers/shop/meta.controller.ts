import type { NextFunction, Request, Response } from 'express';
import { ORDER_STATUS_LABELS, ORDER_STATUSES, PAYMENT_METHODS, PRODUCT_CATEGORY_TAXONOMY, PRODUCT_TAG_TAXONOMY } from '../../lib/shop/constants';
import { COUNTRIES } from '../../lib/shop/countries';
import { CURRENCIES } from '../../lib/shop/money';
import { enabledPaymentMethods, moneyFormatOf } from '../../lib/shop/settings';
import { authUser } from '../../middleware/authenticate';
import { Post, Taxonomy } from '../../models';
import { shopSettingsService } from '../../services/shop/shop-settings.service';
import { paymentTitle } from '../../services/shop/orders.service';

export const shopMetaController = {
  /** Everything the admin screens share: currency format, statuses, countries, taxonomy ids. */
  async shopMeta(req: Request, res: Response, next: NextFunction) {
    try {
      const actor = authUser(req);
      const settings = await shopSettingsService.get(actor.siteId);
      const taxonomies = await Taxonomy.findAll({
        where: { siteId: actor.siteId, slug: [PRODUCT_CATEGORY_TAXONOMY, PRODUCT_TAG_TAXONOMY] },
        attributes: ['id', 'slug'],
      });
      const pages = await Post.findAll({
        where: { siteId: actor.siteId, type: 'page', status: 'publish' },
        attributes: ['id', 'title', 'slug'],
        order: [['title', 'ASC']],
        limit: 500,
      });
      res.json({
        /** Published pages (for the Terms / Privacy pickers in Settings). */
        pages: pages.map((p) => ({ id: p.id, title: p.title, slug: p.slug })),
        currency: settings.general.currency,
        money: moneyFormatOf(settings),
        currencies: CURRENCIES,
        countries: COUNTRIES,
        orderStatuses: ORDER_STATUSES.map((s) => ({ id: s, label: ORDER_STATUS_LABELS[s] })),
        paymentMethods: PAYMENT_METHODS.map((id) => ({ id, title: paymentTitle(id, settings) })),
        enabledPaymentMethods: enabledPaymentMethods(settings).map((m) => m.id),
        categoryTaxonomyId: taxonomies.find((t) => t.slug === PRODUCT_CATEGORY_TAXONOMY)?.id ?? null,
        tagTaxonomyId: taxonomies.find((t) => t.slug === PRODUCT_TAG_TAXONOMY)?.id ?? null,
        orderNumberPrefix: settings.advanced.orderNumberPrefix,
        lowStockThreshold: settings.products.lowStockThreshold,
        shopTitle: settings.products.shopTitle,
        taxEnabled: settings.tax.enabled,
        shippingEnabled: settings.shipping.enabled,
      });
    } catch (error) {
      next(error);
    }
  },
};
