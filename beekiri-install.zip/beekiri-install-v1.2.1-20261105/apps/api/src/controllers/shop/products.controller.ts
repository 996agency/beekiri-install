import type { NextFunction, Request, Response } from 'express';
import { authUser } from '../../middleware/authenticate';
import { productsService } from '../../services/shop/products.service';

const id = (req: Request) => String(req.params.id ?? '');

export const shopProductsController = {
  async listProducts(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await productsService.list(authUser(req), req.query));
    } catch (error) {
      next(error);
    }
  },

  async lookupProducts(req: Request, res: Response, next: NextFunction) {
    try {
      const q = req.query as { q?: string; ids?: string };
      res.json(
        await productsService.lookup(authUser(req), {
          q: q.q,
          ids: q.ids ? q.ids.split(',').map((s) => s.trim()).filter(Boolean) : undefined,
        }),
      );
    } catch (error) {
      next(error);
    }
  },

  async getProduct(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await productsService.get(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  async createProduct(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await productsService.create(authUser(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async updateProduct(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await productsService.update(authUser(req), id(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async removeProduct(req: Request, res: Response, next: NextFunction) {
    try {
      const force = ['1', 'true'].includes(String((req.query as { force?: string }).force ?? ''));
      res.json(await productsService.remove(authUser(req), id(req), { force }));
    } catch (error) {
      next(error);
    }
  },

  async restoreProduct(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await productsService.restore(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  async duplicateProduct(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await productsService.duplicate(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  async bulkProducts(req: Request, res: Response, next: NextFunction) {
    try {
      const body = req.body as { ids: string[]; action: 'publish' | 'draft' | 'trash' | 'restore' | 'delete' };
      res.json(await productsService.bulk(authUser(req), body.ids, body.action));
    } catch (error) {
      next(error);
    }
  },
};
