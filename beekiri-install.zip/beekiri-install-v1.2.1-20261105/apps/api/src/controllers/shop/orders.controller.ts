import type { NextFunction, Request, Response } from 'express';
import type { EmailKind } from '../../lib/shop/emails';
import { authUser } from '../../middleware/authenticate';
import { couponsService } from '../../services/shop/coupons.service';
import { customersService } from '../../services/shop/customers.service';
import { ordersService } from '../../services/shop/orders.service';
import { reportsService, type ReportRange } from '../../services/shop/reports.service';
import { BadRequest } from '../../utils/http-error';

const id = (req: Request) => String(req.params.id ?? '');

const EMAIL_KINDS = new Set(['newOrderAdmin', 'orderReceived', 'onHold', 'processing', 'completed', 'cancelled', 'refunded', 'shipped', 'delivered']);

export const shopOrdersController = {
  async listOrders(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await ordersService.list(authUser(req), req.query));
    } catch (error) {
      next(error);
    }
  },

  async getOrder(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await ordersService.get(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  async setOrderStatus(req: Request, res: Response, next: NextFunction) {
    try {
      const body = req.body as { status: Parameters<typeof ordersService.setStatus>[2]; note?: string };
      res.json(await ordersService.setStatus(authUser(req), id(req), body.status, body.note));
    } catch (error) {
      next(error);
    }
  },

  async updateOrder(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await ordersService.updateDetails(authUser(req), id(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async setOrderFulfillment(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await ordersService.setFulfillment(authUser(req), id(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async addOrderNote(req: Request, res: Response, next: NextFunction) {
    try {
      const body = req.body as { note: string; isCustomerNote?: boolean };
      res.status(201).json(await ordersService.addNote(authUser(req), id(req), body.note, Boolean(body.isCustomerNote)));
    } catch (error) {
      next(error);
    }
  },

  async removeOrderNote(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await ordersService.removeNote(authUser(req), id(req), String(req.params.noteId ?? '')));
    } catch (error) {
      next(error);
    }
  },

  async refundOrder(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await ordersService.refund(authUser(req), id(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async resendOrderEmail(req: Request, res: Response, next: NextFunction) {
    try {
      const kind = String((req.body as { kind?: string }).kind ?? '');
      if (!EMAIL_KINDS.has(kind)) throw BadRequest('Unknown email type.');
      res.json(await ordersService.resendEmail(authUser(req), id(req), kind as EmailKind));
    } catch (error) {
      next(error);
    }
  },

  async listCustomers(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await customersService.list(authUser(req), req.query));
    } catch (error) {
      next(error);
    }
  },

  async getCustomer(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await customersService.get(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  async listCoupons(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await couponsService.list(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  async getCoupon(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await couponsService.get(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  async createCoupon(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await couponsService.create(authUser(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async updateCoupon(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await couponsService.update(authUser(req), id(req), req.body));
    } catch (error) {
      next(error);
    }
  },

  async removeCoupon(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await couponsService.remove(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  async shopOverview(req: Request, res: Response, next: NextFunction) {
    try {
      const range = ((req.query as { range?: string }).range ?? '30d') as ReportRange;
      res.json(await reportsService.overview(authUser(req), range));
    } catch (error) {
      next(error);
    }
  },
};
