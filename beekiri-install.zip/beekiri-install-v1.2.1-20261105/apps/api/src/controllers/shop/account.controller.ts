import type { NextFunction, Request, Response } from 'express';
import { config } from '../../config/env';
import { CUSTOMER_COOKIE } from '../../lib/shop/constants';
import type { ShopCustomer } from '../../models';
import { accountsService } from '../../services/shop/accounts.service';
import { checkoutService } from '../../services/shop/checkout.service';
import { requirePrimarySite } from '../../services/site-context';
import { sessionToken } from '../../middleware/authenticate';
import { authService } from '../../services/auth.service';
import { BadRequest, Unauthorized } from '../../utils/http-error';

/** Storefront "My account" endpoints. Writes are guarded by requireStorefrontRequest in the router. */

function cookieOpts(maxAgeMs?: number) {
  return { httpOnly: true, sameSite: 'lax' as const, secure: config.auth.cookieSecure, path: '/', ...(maxAgeMs ? { maxAge: maxAgeMs } : {}) };
}

export function customerToken(req: Request): string | undefined {
  return (req.cookies as Record<string, string> | undefined)?.[CUSTOMER_COOKIE];
}

/** Signed-in shopper or null (never throws). */
export async function currentCustomer(req: Request): Promise<ShopCustomer | null> {
  try {
    const site = await requirePrimarySite();
    const shopper = await accountsService.resolve(site.id, customerToken(req));
    if (shopper) return shopper;
    // Same login for staff: a valid admin session signs you in to the shop too.
    const admin = await authService.resolveSession(sessionToken(req));
    if (admin?.user && admin.user.siteId === site.id) return await accountsService.forStaff(admin.user);
    return null;
  } catch {
    return null;
  }
}

async function required(req: Request): Promise<ShopCustomer> {
  const customer = await currentCustomer(req);
  if (!customer) throw Unauthorized('Please sign in.');
  return customer;
}

const meta = (req: Request) => ({ ip: req.ip, userAgent: req.get('user-agent') ?? '' });

export function setCustomerCookie(res: Response, session: { token: string; maxAgeMs: number }) {
  res.cookie(CUSTOMER_COOKIE, session.token, cookieOpts(session.maxAgeMs));
}

export const accountController = {
  async accountMe(req: Request, res: Response, next: NextFunction) {
    try {
      const customer = await currentCustomer(req);
      res.setHeader('Cache-Control', 'no-store');
      res.json({ signedIn: Boolean(customer), customer: customer ? accountsService.serialize(customer) : null });
    } catch (error) {
      next(error);
    }
  },

  async accountRegister(req: Request, res: Response, next: NextFunction) {
    try {
      const site = await requirePrimarySite();
      const result = await accountsService.register(site.id, req.body, meta(req));
      setCustomerCookie(res, result);
      res.status(201).json({ signedIn: true, customer: accountsService.serialize(result.customer) });
    } catch (error) {
      next(error);
    }
  },

  async accountLogin(req: Request, res: Response, next: NextFunction) {
    try {
      const site = await requirePrimarySite();
      const result = await accountsService.login(site.id, req.body, meta(req));
      setCustomerCookie(res, result);
      res.json({ signedIn: true, customer: accountsService.serialize(result.customer) });
    } catch (error) {
      next(error);
    }
  },

  async accountLogout(req: Request, res: Response, next: NextFunction) {
    try {
      if (!customerToken(req) && (await currentCustomer(req))) {
        throw BadRequest('You are signed in with your Beekiri admin account. Sign out from the admin.');
      }
      await accountsService.logout(customerToken(req));
      res.clearCookie(CUSTOMER_COOKIE, cookieOpts());
      res.json({ signedIn: false });
    } catch (error) {
      next(error);
    }
  },

  async accountVerify(req: Request, res: Response, next: NextFunction) {
    try {
      const site = await requirePrimarySite();
      res.json(await accountsService.verify(site.id, (req.body as { token: string }).token));
    } catch (error) {
      next(error);
    }
  },

  async accountResendVerify(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await accountsService.resendVerify(await required(req), meta(req)));
    } catch (error) {
      next(error);
    }
  },

  async accountForgot(req: Request, res: Response, next: NextFunction) {
    try {
      const site = await requirePrimarySite();
      res.json(await accountsService.forgotPassword(site.id, (req.body as { email: string }).email, meta(req)));
    } catch (error) {
      next(error);
    }
  },

  async accountReset(req: Request, res: Response, next: NextFunction) {
    try {
      const site = await requirePrimarySite();
      const body = req.body as { token: string; password: string };
      res.json(await accountsService.resetPassword(site.id, body.token, body.password));
    } catch (error) {
      next(error);
    }
  },

  async accountDetails(req: Request, res: Response, next: NextFunction) {
    try {
      res.json({ customer: await accountsService.updateDetails(await required(req), req.body) });
    } catch (error) {
      next(error);
    }
  },

  async accountPassword(req: Request, res: Response, next: NextFunction) {
    try {
      const body = req.body as { current: string; password: string };
      res.json(await accountsService.changePassword(await required(req), body.current, body.password, customerToken(req)));
    } catch (error) {
      next(error);
    }
  },

  async accountAddresses(req: Request, res: Response, next: NextFunction) {
    try {
      res.json({ customer: await accountsService.updateAddresses(await required(req), req.body) });
    } catch (error) {
      next(error);
    }
  },

  async accountOrders(req: Request, res: Response, next: NextFunction) {
    try {
      const page = Math.max(1, Number((req.query as { page?: string }).page) || 1);
      res.setHeader('Cache-Control', 'no-store');
      res.json(await accountsService.orders(await required(req), page));
    } catch (error) {
      next(error);
    }
  },

  async accountOrder(req: Request, res: Response, next: NextFunction) {
    try {
      const customer = await required(req);
      const order = await accountsService.order(customer, Number(req.params.number));
      res.setHeader('Cache-Control', 'no-store');
      res.json(await checkoutService.orderByToken(customer.siteId, order.accessToken));
    } catch (error) {
      next(error);
    }
  },
};
