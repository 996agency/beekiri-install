import type { NextFunction, Request, Response } from 'express';
import { config } from '../../config/env';
import { CART_COOKIE, SHOP_PATHS } from '../../lib/shop/constants';
import { enabledPaymentMethods, moneyFormatOf, type ShopSettings } from '../../lib/shop/settings';
import type { ShopCart } from '../../models';
import { cartService } from '../../services/shop/cart.service';
import { catalogService } from '../../services/shop/catalog.service';
import { checkoutService } from '../../services/shop/checkout.service';
import { shopSettingsService } from '../../services/shop/shop-settings.service';
import { requirePrimarySite } from '../../services/site-context';
import { SHOP_VIEWS, storefrontRenderService, type ShopView } from '../../services/shop/storefront-render.service';
import { shopPagesService } from '../../services/shop/shop-pages.service';
import { currentCustomer, setCustomerCookie } from './account.controller';
import { BadRequest, NotFound } from '../../utils/http-error';

function cookieOptions(settings: ShopSettings) {
  return {
    httpOnly: true,
    sameSite: 'lax' as const,
    secure: config.auth.cookieSecure,
    path: '/',
    maxAge: settings.advanced.cartExpiryDays * 24 * 60 * 60 * 1000,
  };
}

async function context(req: Request) {
  const site = await requirePrimarySite();
  const settings = await shopSettingsService.get(site.id);
  return { siteId: site.id, settings };
}

/** Cart from the cookie, creating one (and setting the cookie) when needed. */
async function cartFor(req: Request, res: Response, siteId: string, settings: ShopSettings, create: boolean): Promise<ShopCart | null> {
  const token = (req.cookies as Record<string, string> | undefined)?.[CART_COOKIE];
  if (!create) return cartService.find(siteId, token);
  const { cart, created } = await cartService.getOrCreate(siteId, token, settings);
  if (created || token !== cart.id) res.cookie(CART_COOKIE, cart.id, cookieOptions(settings));
  return cart;
}

const EMPTY_CART = (settings: ShopSettings) => ({
  token: null,
  items: [],
  itemCount: 0,
  currency: settings.general.currency,
  subtotal: 0,
  discountTotal: 0,
  shippingTotal: 0,
  taxTotal: 0,
  total: 0,
  needsShipping: false,
  pricesIncludeTax: settings.tax.enabled && settings.tax.pricesIncludeTax,
  shipping: null,
  coupon: null,
  couponError: null,
  formatted: { subtotal: '', discountTotal: '', shippingTotal: '', taxTotal: '', total: '' },
  messages: [] as string[],
});

export const storefrontController = {
  /** What every page needs: is the shop on, where are its pages, how many items in the cart. */
  async shopConfig(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId, settings } = await context(req);
      const cart = await cartFor(req, res, siteId, settings, false);
      let itemCount = 0;
      if (cart) {
        const resolved = await cartService.resolve(cart, settings);
        itemCount = resolved.lines.reduce((a, l) => a + l.qty, 0);
      }
      res.json({
        active: true,
        ...(await storefrontRenderService.assetUrls()),
        paths: { shop: SHOP_PATHS.shop, cart: SHOP_PATHS.cart, checkout: SHOP_PATHS.checkout },
        currency: settings.general.currency,
        money: moneyFormatOf(settings),
        shopTitle: settings.products.shopTitle,
        cartCount: itemCount,
        paymentMethods: enabledPaymentMethods(settings).map((m) => m.id),
      });
    } catch (error) {
      next(error);
    }
  },

  async catalog(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId, settings } = await context(req);
      res.json(await catalogService.list(siteId, req.query, settings));
    } catch (error) {
      next(error);
    }
  },

  async categories(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId } = await context(req);
      res.json({ categories: await catalogService.categories(siteId) });
    } catch (error) {
      next(error);
    }
  },

  async product(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId, settings } = await context(req);
      res.json(await catalogService.bySlug(siteId, String(req.params.slug ?? ''), settings));
    } catch (error) {
      next(error);
    }
  },

  async getCart(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId, settings } = await context(req);
      const cart = await cartFor(req, res, siteId, settings, false);
      res.json(cart ? await cartService.view(cart, settings) : EMPTY_CART(settings));
    } catch (error) {
      next(error);
    }
  },

  async addToCart(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId, settings } = await context(req);
      const cart = (await cartFor(req, res, siteId, settings, true))!;
      res.json(await cartService.add(cart, req.body, settings));
    } catch (error) {
      next(error);
    }
  },

  /** Cart page shipping estimate (country + method). */
  async cartShipping(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId, settings } = await context(req);
      const cart = await cartFor(req, res, siteId, settings, false);
      if (!cart) throw BadRequest('Your cart is empty.');
      res.json(await cartService.setShipping(cart, req.body, settings));
    } catch (error) {
      next(error);
    }
  },

  async updateCartItem(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId, settings } = await context(req);
      const cart = await cartFor(req, res, siteId, settings, false);
      if (!cart) throw BadRequest('Your cart is empty.');
      const body = req.body as { key: string; qty: number };
      res.json(await cartService.setQty(cart, body.key, body.qty, settings));
    } catch (error) {
      next(error);
    }
  },

  async applyCoupon(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId, settings } = await context(req);
      const cart = await cartFor(req, res, siteId, settings, false);
      if (!cart) throw BadRequest('Add something to your cart first.');
      res.json(await cartService.applyCoupon(cart, (req.body as { code: string }).code, settings));
    } catch (error) {
      next(error);
    }
  },

  async removeCoupon(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId, settings } = await context(req);
      const cart = await cartFor(req, res, siteId, settings, false);
      if (!cart) throw BadRequest('Your cart is empty.');
      res.json(await cartService.removeCoupon(cart, settings));
    } catch (error) {
      next(error);
    }
  },

  async checkoutPage(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId, settings } = await context(req);
      const cart = await cartFor(req, res, siteId, settings, false);
      if (!cart) {
        res.json({ cart: EMPTY_CART(settings), shippingOptions: [], shippingRequired: false, shippingUnavailable: false, paymentMethods: [], countries: [], defaultCountry: '', fields: null, termsPage: null, privacyPage: null });
        return;
      }
      res.json(await checkoutService.page(cart, settings, null, await currentCustomer(req)));
    } catch (error) {
      next(error);
    }
  },

  /** Shipping options + totals for an address the shopper typed. */
  async shippingQuote(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId, settings } = await context(req);
      const cart = await cartFor(req, res, siteId, settings, false);
      if (!cart) throw BadRequest('Your cart is empty.');
      const body = req.body as { country: string; state: string; postcode: string };
      res.json(await checkoutService.page(cart, settings, { country: body.country, state: body.state, postcode: body.postcode }, await currentCustomer(req)));
    } catch (error) {
      next(error);
    }
  },

  async placeOrder(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId, settings } = await context(req);
      const cart = await cartFor(req, res, siteId, settings, false);
      if (!cart) throw BadRequest('Your cart is empty.');
      const result = await checkoutService.placeOrder(cart, req.body, { ip: req.ip, userAgent: req.get('user-agent') ?? '' }, await currentCustomer(req));
      if (result.session) setCustomerCookie(res, result.session);
      const { session: _session, ...body } = result;
      res.status(201).json(body);
    } catch (error) {
      next(error);
    }
  },

  async confirmPayment(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId } = await context(req);
      const body = req.body as { token: string; sessionId?: string };
      res.json(await checkoutService.confirm(siteId, body.token, body.sessionId));
    } catch (error) {
      next(error);
    }
  },

  async orderByToken(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId } = await context(req);
      res.json(await checkoutService.orderByToken(siteId, String(req.params.token ?? '')));
    } catch (error) {
      next(error);
    }
  },

  /** Server-rendered storefront page (theme PHP templates) for the website. */
  async renderView(req: Request, res: Response, next: NextFunction) {
    try {
      const view = String(req.params.view ?? '') as ShopView;
      if (!SHOP_VIEWS.includes(view)) throw NotFound('Unknown shop view.');
      const token = (req.cookies as Record<string, string> | undefined)?.[CART_COOKIE];
      const rendered = await storefrontRenderService.render(view, req.query, token, await currentCustomer(req));
      res.setHeader('Cache-Control', 'no-store');
      res.status(rendered.status === 404 ? 404 : 200).json(rendered);
    } catch (error) {
      next(error);
    }
  },

  async shopAsset(req: Request, res: Response, next: NextFunction) {
    try {
      const file = String(req.params.file ?? '');
      if (file !== 'styles.css' && file !== 'script.js') throw NotFound('Asset not found');
      const asset = await storefrontRenderService.readAsset(file);
      res.setHeader('Content-Type', asset.contentType);
      res.setHeader('Cache-Control', req.query.v ? 'public, max-age=31536000, immutable' : 'public, max-age=60');
      res.send(asset.body);
    } catch (error) {
      next(error);
    }
  },

  /** Published BeekiriCode document of a storefront page (Shop → Shop Editor). */
  async shopPage(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId } = await context(req);
      res.json(await shopPagesService.publicDoc(siteId, String(req.params.view ?? '')));
    } catch (error) {
      next(error);
    }
  },

  async stripeWebhook(req: Request, res: Response, next: NextFunction) {
    try {
      const { siteId } = await context(req);
      const raw = (req as Request & { rawBody?: Buffer }).rawBody;
      if (!raw) throw BadRequest('Raw body unavailable.');
      const signature = req.get('stripe-signature') ?? '';
      res.json(await checkoutService.handleStripeWebhook(siteId, raw, signature));
    } catch (error) {
      next(error);
    }
  },
};
