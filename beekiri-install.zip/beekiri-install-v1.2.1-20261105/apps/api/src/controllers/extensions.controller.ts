import type { NextFunction, Request, Response } from 'express';
import { authUser } from '../middleware/authenticate';
import { extensionsService } from '../services/extensions.service';

const slug = (req: Request) => String(req.params.slug ?? '').trim().toLowerCase();

export const extensionsController = {
  async list(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await extensionsService.list());
    } catch (error) {
      next(error);
    }
  },

  /** Active extension slugs — any signed-in user (drives the admin menu). */
  async active(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json({ active: await extensionsService.activeSlugs() });
    } catch (error) {
      next(error);
    }
  },

  async install(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await extensionsService.install(authUser(req), slug(req)));
    } catch (error) {
      next(error);
    }
  },

  async activate(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await extensionsService.activate(authUser(req), slug(req)));
    } catch (error) {
      next(error);
    }
  },

  async deactivate(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await extensionsService.deactivate(authUser(req), slug(req)));
    } catch (error) {
      next(error);
    }
  },

  async uninstall(req: Request, res: Response, next: NextFunction) {
    try {
      const deleteData = Boolean((req.body as { deleteData?: boolean } | undefined)?.deleteData);
      res.json(await extensionsService.uninstall(authUser(req), slug(req), { deleteData }));
    } catch (error) {
      next(error);
    }
  },
};
