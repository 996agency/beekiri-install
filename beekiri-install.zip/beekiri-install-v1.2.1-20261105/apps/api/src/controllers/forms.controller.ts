import type { NextFunction, Request, Response } from 'express';
import { authUser } from '../middleware/authenticate';
import { entriesService, type EntryListInput } from '../services/forms/entries.service';
import { formsService, type FormInput } from '../services/forms/forms.service';
import { integrationsService } from '../services/forms/integrations.service';
import { submitService } from '../services/forms/submit.service';
import { formCss } from '../lib/forms/assets';
import { NotFound } from '../utils/http-error';

const id = (req: Request) => String(req.params.id ?? '');
const str = (v: unknown) => (Array.isArray(v) ? String(v[0] ?? '') : typeof v === 'string' ? v : '');

export const formsController = {
  /* ── Admin: forms ───────────────────────────────────────────────────── */
  async list(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await formsService.list(authUser(req), str(req.query.q)));
    } catch (error) {
      next(error);
    }
  },
  async lookup(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await formsService.lookup(authUser(req)));
    } catch (error) {
      next(error);
    }
  },
  async get(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await formsService.get(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },
  async create(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await formsService.create(authUser(req), req.body as FormInput));
    } catch (error) {
      next(error);
    }
  },
  async update(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await formsService.update(authUser(req), id(req), req.body as FormInput));
    } catch (error) {
      next(error);
    }
  },
  async duplicate(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await formsService.duplicate(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },
  async remove(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await formsService.remove(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },
  async preview(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await formsService.previewHtml(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  /* ── Admin: entries ─────────────────────────────────────────────────── */
  async listEntries(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await entriesService.list(authUser(req), req.query as EntryListInput));
    } catch (error) {
      next(error);
    }
  },
  async getEntry(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await entriesService.get(authUser(req), id(req), { formId: str(req.query.formId) || undefined }));
    } catch (error) {
      next(error);
    }
  },
  async setEntryStatus(req: Request, res: Response, next: NextFunction) {
    try {
      const body = req.body as { ids: string[]; status: 'unread' | 'read' | 'spam' | 'trash' };
      res.json(await entriesService.setStatus(authUser(req), body.ids, body.status));
    } catch (error) {
      next(error);
    }
  },
  async deleteEntries(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await entriesService.remove(authUser(req), (req.body as { ids: string[] }).ids));
    } catch (error) {
      next(error);
    }
  },
  async entryFile(req: Request, res: Response, next: NextFunction) {
    try {
      const { file, stream, size } = await entriesService.file(authUser(req), id(req), String(req.params.fileId ?? ''));
      res.setHeader('Content-Type', file.mime || 'application/octet-stream');
      res.setHeader('Content-Length', String(size));
      res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(file.name)}`);
      res.setHeader('Content-Security-Policy', "default-src 'none'; sandbox");
      res.setHeader('X-Content-Type-Options', 'nosniff');
      stream.pipe(res);
    } catch (error) {
      next(error);
    }
  },
  async exportEntries(req: Request, res: Response, next: NextFunction) {
    try {
      const status = req.query.status as EntryListInput['status'] | undefined;
      const { filename, csv } = await entriesService.exportCsv(authUser(req), id(req), status);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(csv);
    } catch (error) {
      next(error);
    }
  },

  /* ── Admin: integrations ────────────────────────────────────────────── */
  async integrations(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await integrationsService.list(authUser(req)));
    } catch (error) {
      next(error);
    }
  },
  async connectHubspot(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await integrationsService.connectHubspot(authUser(req), String((req.body as { token: string }).token)));
    } catch (error) {
      next(error);
    }
  },
  async testHubspot(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await integrationsService.testHubspot(authUser(req)));
    } catch (error) {
      next(error);
    }
  },
  async retryFailedHubspot(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await integrationsService.retryFailed(authUser(req)));
    } catch (error) {
      next(error);
    }
  },
  async disconnectIntegration(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await integrationsService.disconnect(authUser(req), String(req.params.provider)));
    } catch (error) {
      next(error);
    }
  },
  async hubspotProperties(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await integrationsService.hubspotProperties(authUser(req), req.query.refresh === '1'));
    } catch (error) {
      next(error);
    }
  },
  async syncEntryHubspot(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await integrationsService.retry(authUser(req), id(req)));
    } catch (error) {
      next(error);
    }
  },

  /* ── Public ─────────────────────────────────────────────────────────── */
  publicCss(_req: Request, res: Response) {
    res.setHeader('Content-Type', 'text/css; charset=utf-8');
    res.setHeader('Cache-Control', 'public, max-age=3600');
    res.send(formCss());
  },
  async publicHtml(req: Request, res: Response, next: NextFunction) {
    try {
      const out = await formsService.publicHtml(id(req));
      if (!out) throw NotFound('Form not found.');
      res.setHeader('Cache-Control', 'no-store');
      res.json(out);
    } catch (error) {
      next(error);
    }
  },
  async publicToken(req: Request, res: Response, next: NextFunction) {
    try {
      res.setHeader('Cache-Control', 'no-store');
      res.json(await formsService.publicToken(id(req)));
    } catch (error) {
      next(error);
    }
  },
  async submit(req: Request, res: Response, next: NextFunction) {
    try {
      const body = (req.body ?? {}) as Record<string, string | string[] | undefined>;
      const result = await submitService.submit({
        formId: id(req),
        body,
        files: ((req.files as Express.Multer.File[] | undefined) ?? []).map((f) => ({
          fieldname: f.fieldname,
          originalname: f.originalname,
          mimetype: f.mimetype,
          size: f.size,
          buffer: f.buffer,
        })),
        ip: req.ip ?? '',
        userAgent: req.get('user-agent') ?? '',
        pageUrl: str(body._bk_page_url),
        pageTitle: str(body._bk_page_title),
        referrer: str(body._bk_referrer),
        attribution: str(body._bk_attr),
        header: (name: string) => req.get(name),
      });
      res.status(result.ok ? 200 : 422).json(result);
    } catch (error) {
      next(error);
    }
  },
};
