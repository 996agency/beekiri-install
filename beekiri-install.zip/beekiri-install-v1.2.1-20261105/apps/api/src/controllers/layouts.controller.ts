import type { NextFunction, Request, Response } from 'express';
import { sanitizeLayoutSlug } from '../lib/layouts/layout-paths';
import { layoutSyncService } from '../services/layout-sync.service';
import { NotFound } from '../utils/http-error';

type Runtime = 'php' | 'react';

function slugOf(req: Request): string {
  const clean = sanitizeLayoutSlug(req.params.slug as string);
  if (!clean) throw NotFound('Layout not found.');
  return clean;
}

function parseFieldsQuery(raw: unknown): Record<string, unknown> {
  if (typeof raw !== 'string' || !raw) return {};
  try {
    const parsed = JSON.parse(raw) as unknown;
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed)
      ? (parsed as Record<string, unknown>)
      : {};
  } catch {
    return {};
  }
}

/** Versioned (`?v=`) by listPublic, so a long cache is safe. */
function sendAsset(res: Response, contentType: string, body: string) {
  res.setHeader('Content-Type', contentType);
  res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.send(body);
}

export const layoutsController = {
  /** Public: editor + front-end load available page layouts. */
  async list(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json({ layouts: await layoutSyncService.listActive() });
    } catch (error) {
      next(error);
    }
  },

  css(req: Request, res: Response, next: NextFunction) {
    try {
      const css = layoutSyncService.readCss(slugOf(req));
      if (css == null) throw NotFound('Layout CSS not found.');
      sendAsset(res, 'text/css; charset=utf-8', css);
    } catch (error) {
      next(error);
    }
  },

  js(req: Request, res: Response, next: NextFunction) {
    try {
      const js = layoutSyncService.readJs(slugOf(req));
      if (js == null) throw NotFound('Layout script not found.');
      sendAsset(res, 'application/javascript; charset=utf-8', js);
    } catch (error) {
      next(error);
    }
  },

  /**
   * Public: render layouts/{slug}/{slug}.php or .tsx (Settings → frontend runtime).
   * `runtime: 'php' | 'react'` forces one engine (avoids proxy loops).
   */
  async renderGet(req: Request, res: Response, next: NextFunction) {
    try {
      const slug = slugOf(req);
      const query = req.query as { fields?: string; runtime?: Runtime };
      const html = await layoutSyncService.renderLayout(
        slug,
        parseFieldsQuery(query.fields),
        query.runtime,
      );
      if (html == null) throw NotFound('Layout not found.');
      res.setHeader('Cache-Control', 'no-store');
      res.json({ slug, html });
    } catch (error) {
      next(error);
    }
  },

  async renderPost(req: Request, res: Response, next: NextFunction) {
    try {
      const slug = slugOf(req);
      const body = req.body as { fields?: Record<string, unknown>; runtime?: Runtime };
      const html = await layoutSyncService.renderLayout(slug, body.fields ?? {}, body.runtime);
      if (html == null) throw NotFound('Layout not found.');
      res.setHeader('Cache-Control', 'no-store');
      res.status(201).json({ slug, html });
    } catch (error) {
      next(error);
    }
  },

  /** Public: formatted field values (what get_bee_field() returns) for React layouts. */
  async formatFields(req: Request, res: Response, next: NextFunction) {
    try {
      const slug = slugOf(req);
      const fields = await layoutSyncService.formatLayoutFields(slug, req.body.fields ?? {});
      res.setHeader('Cache-Control', 'no-store');
      res.status(201).json({ slug, fields });
    } catch (error) {
      next(error);
    }
  },

  async syncAll(_req: Request, res: Response, next: NextFunction) {
    try {
      const synced = await layoutSyncService.syncAllActive();
      res.status(201).json({ ok: true, synced, layouts: layoutSyncService.listPublic() });
    } catch (error) {
      next(error);
    }
  },

  compile(req: Request, res: Response, next: NextFunction) {
    try {
      const slug = req.params.slug as string;
      if (!layoutSyncService.compileSlug(slug)) throw NotFound('Layout SCSS not found.');
      res.status(201).json({ ok: true, slug: sanitizeLayoutSlug(slug) });
    } catch (error) {
      next(error);
    }
  },
};
