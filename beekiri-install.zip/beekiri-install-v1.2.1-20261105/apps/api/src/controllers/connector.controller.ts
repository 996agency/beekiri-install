import { randomUUID } from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import type { WorkspaceLink } from '../lib/beequeen/workspace';
import { authUser } from '../middleware/authenticate';
import { beeQueenAgentService, type BeeQueenEvent } from '../services/beequeen-agent.service';
import { beeQueenChatsService, type AssistantRecord, type RunUsage } from '../services/beequeen-chats.service';
import { connectorService } from '../services/connector.service';
import { createLogger } from '../utils/logger';
import type { BeeQueenAgentInput } from '../validators/connector.schema';
import { connectorService as connectors } from '../services/connector.service';

const log = createLogger('beequeen');

/** A chat turn as it streams: `chat` first, then status / note lines, done or error, then `charge` when billed. */
type StreamEvent =
  | BeeQueenEvent
  | { type: 'chat'; chatId: string; title: string }
  /** Credits this run has used so far (`final` once it has finished). */
  | { type: 'charge'; credits: number; balance: number; granted?: number; final: boolean };

export const connectorController = {
  async get(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await connectorService.get());
    } catch (error) {
      next(error);
    }
  },

  async getProvider(req: Request, res: Response, next: NextFunction) {
    try {
      const providerId = String((req.params as { providerId?: string }).providerId || '');
      res.json(await connectorService.getProvider(providerId));
    } catch (error) {
      next(error);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await connectorService.update(req.body));
    } catch (error) {
      next(error);
    }
  },

  async status(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await beeQueenAgentService.status());
    } catch (error) {
      next(error);
    }
  },

  async beeQueenAccount(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await connectors.beeQueenAccount());
    } catch (error) {
      next(error);
    }
  },

  async requestBeeQueenPack(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await connectors.requestBeeQueenPack(String((req.body as { pack: string }).pack)));
    } catch (error) {
      next(error);
    }
  },

  async listChats(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await beeQueenChatsService.list(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  async getChat(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await beeQueenChatsService.get(authUser(req), String(req.params.chatId)));
    } catch (error) {
      next(error);
    }
  },

  async deleteChat(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await beeQueenChatsService.remove(authUser(req), String(req.params.chatId)));
    } catch (error) {
      next(error);
    }
  },

  /** Streams BeeQueen's progress as NDJSON and saves both sides of the turn to the chat. */
  async runAgent(req: Request, res: Response, next: NextFunction) {
    const actor = authUser(req);
    const body = req.body as BeeQueenAgentInput;
    let setup: Awaited<ReturnType<typeof beeQueenAgentService.prepare>>;
    let turn: Awaited<ReturnType<typeof beeQueenChatsService.beginTurn>>;
    try {
      setup = await beeQueenAgentService.prepare();
      turn = await beeQueenChatsService.beginTurn(actor, body.chatId, body.prompt);
    } catch (error) {
      next(error);
      return;
    }
    // Every Claude call in this turn carries the run id; the BeeQueen service bills by it.
    const runId = randomUUID();

    const abort = new AbortController();
    // Closing the chat (or the tab) stops the run instead of building on in the background.
    res.on('close', () => {
      if (!res.writableEnded) abort.abort();
    });

    res.status(200);
    res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();

    // What gets saved for BeeQueen's side, built from the same events the chat sees.
    const record: AssistantRecord = { text: '', state: 'stopped', steps: [], links: [] };
    const write = (event: StreamEvent) => {
      if (!res.writableEnded && !res.destroyed) res.write(`${JSON.stringify(event)}\n`);
    };
    const emit = (event: BeeQueenEvent) => {
      if (event.type === 'status' || event.type === 'note') {
        record.steps.push({ kind: event.type, text: event.text });
      } else if (event.type === 'done') {
        Object.assign(record, { text: event.reply, state: 'done', links: event.links as WorkspaceLink[], model: event.model });
      } else if (event.type === 'error') {
        Object.assign(record, { text: event.message, state: 'error' });
      }
      write(event);
    };
    // Keeps proxies from closing a quiet connection while Claude thinks.
    const ping = setInterval(() => {
      if (!res.writableEnded && !res.destroyed) res.write('\n');
    }, 15_000);

    write({ type: 'chat', chatId: turn.chat.id, title: turn.chat.title });
    // While BeeQueen works, ask the service what this run has cost so far, so the
    // toolbar can count it up live.
    let lastSpent = -1;
    let polling = false;
    const spendTicker =
      setup.engine === 'service'
        ? setInterval(() => {
            if (polling) return;
            polling = true;
            beeQueenAgentService
              .runCost(setup, runId)
              .then((cost) => {
                if (cost && cost.credits !== lastSpent) {
                  lastSpent = cost.credits;
                  write({ type: 'charge', credits: cost.credits, balance: cost.balance, granted: cost.granted, final: false });
                }
              })
              .catch(() => undefined)
              .finally(() => {
                polling = false;
              });
          }, 4_000)
        : null;
    let usage: RunUsage | null = null;
    try {
      usage = await beeQueenAgentService.run(
        actor,
        { prompt: body.prompt, history: turn.history, runId },
        setup,
        emit,
        abort.signal,
      );
    } catch (error) {
      emit({ type: 'error', message: error instanceof Error ? error.message : 'BeeQueen stopped.' });
    } finally {
      clearInterval(ping);
      if (spendTicker) clearInterval(spendTicker);
      if (abort.signal.aborted && record.state !== 'done') {
        record.state = 'stopped';
        record.text = 'Stopped.';
      }
      // The BeeQueen service charged each Claude call; report the run's total and the new balance.
      if (setup.engine === 'service') {
        try {
          const cost = await beeQueenAgentService.runCost(setup, runId);
          if (cost) {
            usage = { ...(usage ?? { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 }), credits: cost.credits };
            write({ type: 'charge', credits: cost.credits, balance: cost.balance, granted: cost.granted, final: true });
          }
        } catch (error) {
          log.warn(`Could not read the BeeQueen run cost: ${(error as Error).message}`);
        }
      }
      try {
        await beeQueenChatsService.finishTurn(turn.chat.id, { ...record, usage });
      } catch (error) {
        log.warn(`Could not save the BeeQueen reply: ${(error as Error).message}`);
      }
      if (!res.writableEnded) res.end();
    }
  },
};
