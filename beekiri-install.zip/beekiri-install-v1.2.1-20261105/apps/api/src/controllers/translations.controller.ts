import type { NextFunction, Request, Response } from 'express';
import { translationsService } from '../services/translations.service';

export const translationsController = {
  async publicConfig(req: Request, res: Response, next: NextFunction) {
    try {
      const lang = typeof req.query.lang === 'string' ? req.query.lang : undefined;
      res.json(await translationsService.publicConfig(lang));
    } catch (error) {
      next(error);
    }
  },

  async getSettings(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await translationsService.getSettings());
    } catch (error) {
      next(error);
    }
  },

  async updateSettings(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await translationsService.updateSettings(req.body));
    } catch (error) {
      next(error);
    }
  },

  async autoTranslate(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await translationsService.autoTranslate(req.body));
    } catch (error) {
      next(error);
    }
  },
};
