import { gzipSync } from 'zlib';
import type { NextFunction, Request, Response } from 'express';
import { selfOrigin } from '../middleware/security';
import { createReadStream } from 'fs';
import { extname } from 'path';
import { isThemeChromeKind, type ThemeChromeKind } from '../lib/themes/theme-registry';
import { authUser } from '../middleware/authenticate';
import { isChromeAssetName, isChromeFontName, themeChromeService } from '../services/theme-chrome.service';
import { themeContentService } from '../services/theme-content.service';
import { themesService } from '../services/themes.service';
import { BadRequest, NotFound } from '../utils/http-error';

function chromeKind(raw: unknown): ThemeChromeKind {
  if (typeof raw !== 'string' || !isThemeChromeKind(raw)) throw NotFound('Unknown chrome kind');
  return raw;
}

const MIME: Record<string, string> = {
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
};

export const themesController = {
  async list(_req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await themesService.list());
    } catch (error) {
      next(error);
    }
  },

  /** Header / footer options of the active theme (Appearance → Header / Footer). */
  async listChrome(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await themeChromeService.list(chromeKind(req.params.kind)));
    } catch (error) {
      next(error);
    }
  },

  async activateChrome(req: Request, res: Response, next: NextFunction) {
    try {
      res
        .status(201)
        .json(await themeChromeService.activate(chromeKind(req.params.kind), req.body.slug));
    } catch (error) {
      next(error);
    }
  },

  /** Public: active header/footer for the installed runtime (PHP: rendered HTML). */
  async renderChrome(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await themeChromeService.render(chromeKind(req.params.kind)));
    } catch (error) {
      next(error);
    }
  },

  /** Public: styles.css / script.js of the active header/footer. */
  async chromeAsset(req: Request, res: Response, next: NextFunction) {
    try {
      const file = req.params.file as string;
      if (isChromeFontName(file)) {
        const font = await themeChromeService.readFont(chromeKind(req.params.kind), file);
        res.setHeader('Content-Type', 'font/woff2');
        // styles.css and the preload links carry ?v=<file time>, so a long cache is safe.
        res.setHeader('Cache-Control', req.query.v ? 'public, max-age=31536000, immutable' : 'public, max-age=86400');
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.send(font);
        return;
      }
      if (!isChromeAssetName(file)) throw NotFound('Asset not found');
      const asset = await themeChromeService.readAsset(chromeKind(req.params.kind), file);
      res.setHeader('Content-Type', asset.contentType);
      // Versioned via ?v=, so a long cache is safe.
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Vary', 'Accept-Encoding');
      if (/\bgzip\b/.test(String(req.headers['accept-encoding'] ?? ''))) {
        res.setHeader('Content-Encoding', 'gzip');
        res.send(gzipSync(asset.body));
        return;
      }
      res.send(asset.body);
    } catch (error) {
      next(error);
    }
  },

  /**
   * Switches the site to the theme (its pages, front page, menu and header/footer come along).
   * A theme with ready-made pages that this site has not added yet gets them now.
   */
  async activate(req: Request, res: Response, next: NextFunction) {
    try {
      const result = await themesService.activate(req.body.slug, selfOrigin(req));
      const content = await themeContentService.status(result.active).catch(() => null);
      let pagesAdded = 0;
      if (content?.hasContent && !content.installed) {
        pagesAdded = (await themeContentService.install(authUser(req), result.active)).pages.length;
      }
      res.status(201).json({ ...result, pagesAdded });
    } catch (error) {
      next(error);
    }
  },

  async deactivate(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await themesService.deactivate(req.body.slug));
    } catch (error) {
      next(error);
    }
  },

  async upload(req: Request, res: Response, next: NextFunction) {
    try {
      if (!req.file) throw BadRequest('No file uploaded. Use field name "file".');
      res
        .status(201)
        .json(await themesService.uploadZip(req.file.buffer, req.file.originalname || 'theme.zip'));
    } catch (error) {
      next(error);
    }
  },

  /** Pages a theme ships in content/ — whether this site installed them yet. */
  async contentStatus(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await themeContentService.status(req.params.slug as string));
    } catch (error) {
      next(error);
    }
  },

  async installContent(req: Request, res: Response, next: NextFunction) {
    try {
      res.status(201).json(await themeContentService.install(authUser(req), req.params.slug as string));
    } catch (error) {
      next(error);
    }
  },

  /** The active theme's ready-made sections for the page editor's Add panel. */
  async sections(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await themeContentService.sections(authUser(req)));
    } catch (error) {
      next(error);
    }
  },

  /** Put the theme's pages back to their shipped design (edits to those pages are replaced). */
  async resetContent(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await themeContentService.reset(authUser(req), req.params.slug as string));
    } catch (error) {
      next(error);
    }
  },

  async remove(req: Request, res: Response, next: NextFunction) {
    try {
      res.json(await themesService.remove(req.params.slug as string));
    } catch (error) {
      next(error);
    }
  },

  /** Public screenshot for Appearance cards. */
  screenshot(req: Request, res: Response, next: NextFunction) {
    try {
      const path = themesService.resolveScreenshotPath(req.params.slug as string);
      if (!path) throw NotFound('Screenshot not found');
      res.setHeader(
        'Content-Type',
        MIME[extname(path).toLowerCase()] ?? 'application/octet-stream',
      );
      res.setHeader('Cache-Control', 'public, max-age=3600');
      // Theme SVGs are third-party files: never let them run script on our origin.
      res.setHeader(
        'Content-Security-Policy',
        "default-src 'none'; style-src 'unsafe-inline'; sandbox",
      );
      createReadStream(path)
        .on('error', () => res.destroy())
        .pipe(res);
    } catch (error) {
      next(error);
    }
  },
};
