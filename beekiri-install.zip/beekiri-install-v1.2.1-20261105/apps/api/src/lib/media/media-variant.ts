import type { NextFunction, Request, Response } from 'express';
import { existsSync, mkdirSync, statSync, writeFileSync } from 'fs';
import { dirname, join, normalize, sep } from 'path';
import sharp from 'sharp';

/** Widths the website asks for (phones: 828 for 1–2× screens, 1290 for 3×; 1600 for 1× desktops). */
export const VARIANT_WIDTHS = new Set([828, 1290, 1600]);

const IMAGE = /^[\w./-]+\.(webp|jpe?g|png)$/i;
const pending = new Map<string, Promise<void>>();

/**
 * GET /uploads/_w{width}/{path}: the upload resized to `width` (never enlarged), as WebP at
 * quality 90. Made on first request and kept in uploads/.variants/, so phones download a
 * fraction of a full-size photo. The source name carries a content hash, so it caches for a year.
 */
export function mediaVariant(uploadsRoot: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const match = /^\/_w(\d{3,4})\/(.+)$/.exec(req.path);
      if (!match) return next();
      const width = Number(match[1]);
      const rel = decodeURIComponent(match[2]);
      if (!VARIANT_WIDTHS.has(width) || !IMAGE.test(rel) || rel.split('/').some((p) => p.startsWith('.'))) return next();
      const source = normalize(join(uploadsRoot, rel));
      if (!source.startsWith(uploadsRoot + sep) || !existsSync(source)) return next();

      const target = join(uploadsRoot, '.variants', `w${width}`, rel.replace(/\.(jpe?g|png)$/i, '.webp'));
      const fresh = existsSync(target) && statSync(target).mtimeMs >= statSync(source).mtimeMs;
      if (!fresh) {
        let job = pending.get(target);
        if (!job) {
          job = (async () => {
            const meta = await sharp(source).metadata();
            mkdirSync(dirname(target), { recursive: true });
            const out = await sharp(source)
              .rotate()
              .resize({ width: Math.min(width, meta.width ?? width), withoutEnlargement: true })
              .webp({ quality: 90, alphaQuality: 100, smartSubsample: true, effort: 5 })
              .toBuffer();
            writeFileSync(target, out);
          })().finally(() => pending.delete(target));
          pending.set(target, job);
        }
        await job;
      }
      res.setHeader('Content-Type', 'image/webp');
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.sendFile(target, { dotfiles: 'allow' });
    } catch (error) {
      next(error);
    }
  };
}
