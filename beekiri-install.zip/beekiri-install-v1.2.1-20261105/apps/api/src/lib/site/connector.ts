/** Connector: AI providers the site can use. */

export const CONNECTOR_PROVIDER_IDS = [
  'beequeen',
  'claude',
  'openai',
  'gemini',
  'grok',
] as const;

export type ConnectorProviderId = (typeof CONNECTOR_PROVIDER_IDS)[number];

export const CONNECTOR_EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max'] as const;

export type ConnectorEffort = (typeof CONNECTOR_EFFORTS)[number];

export const DEFAULT_EFFORT: ConnectorEffort = 'max';

export type ConnectorProviderState = {
  id: ConnectorProviderId;
  enabled: boolean;
  /** Provider API key (never returned in full to the client). */
  apiKey: string;
  /** Preferred model id for this provider. */
  defaultModel: string;
  /** Reasoning effort for providers that support it (Claude, BeeQueen). */
  effort: ConnectorEffort;
  /** BeeQueen only: address of the BeeQueen service (996Agency) this site connects to. */
  serviceUrl: string;
};

/**
 * Where BeeQueen runs (996Agency). Clients never set this: it comes from
 * BEEQUEEN_SERVICE_URL (e.g. https://996agency.com once deployed); local 996ai until then.
 */
export const DEFAULT_BEEQUEEN_URL = (process.env.BEEQUEEN_SERVICE_URL?.trim() || 'http://127.0.0.1:8010').replace(/\/+$/, '');

/** Keys issued by the BeeQueen service for a connected site. */
export const BEEQUEEN_KEY_PREFIX = 'bq_live_';

export type ConnectorOptions = {
  providers: Record<ConnectorProviderId, ConnectorProviderState>;
};

export type ConnectorProviderCatalog = {
  id: ConnectorProviderId;
  name: string;
  vendor: string;
  blurb: string;
  badge?: string;
  docsUrl: string;
  apiKeyLabel: string;
  apiKeyPlaceholder: string;
  models: { id: string; label: string }[];
  /** Offers the reasoning-effort setting. */
  supportsEffort?: boolean;
  /** Not offered on the Connector page for now (BeeQueen only). */
  hidden?: boolean;
};

/** Claude models BeeQueen and the Claude connector can run on (first = default). */
const CLAUDE_MODELS = [
  { id: 'claude-opus-5-5', label: 'Claude Opus 5.5' },
  { id: 'claude-sonnet-5-5', label: 'Claude Sonnet 5.5' },
  { id: 'claude-haiku-5-5', label: 'Claude Haiku 5.5' },
  { id: 'claude-fable-5-1', label: 'Claude Fable 5.1' },
];

/** The stub key older builds saved when BeeQueen was switched on — never a real key. */
const STUB_BEEQUEEN_KEY = 'bq-dev-active';

/** Catalog order = Beekiri agent first, then third-party providers. */
export const CONNECTOR_PROVIDER_CATALOG: ConnectorProviderCatalog[] = [
  {
    id: 'beequeen',
    name: 'BeeQueen',
    vendor: '996Agency',
    blurb:
      'BeeQueen by 996Agency builds layouts, Backend Fields and pages inside your theme. It runs on Claude through 996Agency’s Anthropic API account, and each message is paid from this site’s BeeQueen credits.',
    badge: 'Claude',
    docsUrl: 'https://996agency.com',
    apiKeyLabel: 'BeeQueen site key',
    apiKeyPlaceholder: 'bq_live_…',
    models: CLAUDE_MODELS,
    supportsEffort: true,
  },
  {
    id: 'claude',
    hidden: true,
    name: 'Claude',
    vendor: 'Anthropic',
    blurb: 'Strongest for long writing, editing, and careful site work.',
    docsUrl: 'https://console.anthropic.com/settings/keys',
    apiKeyLabel: 'Anthropic API key',
    apiKeyPlaceholder: 'sk-ant-…',
    models: CLAUDE_MODELS,
    supportsEffort: true,
  },
  {
    id: 'openai',
    hidden: true,
    name: 'ChatGPT',
    vendor: 'OpenAI',
    blurb: 'Versatile models for drafts, ideas, and everyday assistance.',
    docsUrl: 'https://platform.openai.com/api-keys',
    apiKeyLabel: 'OpenAI API key',
    apiKeyPlaceholder: 'sk-…',
    models: [
      { id: 'gpt-5.2', label: 'GPT-5.2' },
      { id: 'gpt-5-mini', label: 'GPT-5 mini' },
      { id: 'gpt-4.1', label: 'GPT-4.1' },
    ],
  },
  {
    id: 'gemini',
    hidden: true,
    name: 'Gemini',
    vendor: 'Google',
    blurb: 'Fast multimodal models with strong research-style answers.',
    docsUrl: 'https://aistudio.google.com/apikey',
    apiKeyLabel: 'Google AI API key',
    apiKeyPlaceholder: 'AIza…',
    models: [
      { id: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro' },
      { id: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash' },
      { id: 'gemini-2.0-flash', label: 'Gemini 2.0 Flash' },
    ],
  },
  {
    id: 'grok',
    hidden: true,
    name: 'Grok',
    vendor: 'xAI',
    blurb: 'Realtime-flavored answers with a bold, conversational style.',
    docsUrl: 'https://console.x.ai/',
    apiKeyLabel: 'xAI API key',
    apiKeyPlaceholder: 'xai-…',
    models: [
      { id: 'grok-3', label: 'Grok 3' },
      { id: 'grok-3-mini', label: 'Grok 3 mini' },
      { id: 'grok-2', label: 'Grok 2' },
    ],
  },
];

function defaultModelFor(id: ConnectorProviderId): string {
  return CONNECTOR_PROVIDER_CATALOG.find((p) => p.id === id)?.models[0]?.id ?? '';
}

function emptyState(id: ConnectorProviderId): ConnectorProviderState {
  return {
    id,
    enabled: false,
    apiKey: '',
    defaultModel: defaultModelFor(id),
    effort: DEFAULT_EFFORT,
    serviceUrl: id === 'beequeen' ? DEFAULT_BEEQUEEN_URL : '',
  };
}

export const DEFAULT_CONNECTOR: ConnectorOptions = {
  providers: {
    beequeen: emptyState('beequeen'),
    claude: emptyState('claude'),
    openai: emptyState('openai'),
    gemini: emptyState('gemini'),
    grok: emptyState('grok'),
  },
};

function asBool(v: unknown, fallback: boolean): boolean {
  return typeof v === 'boolean' ? v : fallback;
}

function asString(v: unknown, fallback = ''): string {
  return typeof v === 'string' ? v : fallback;
}

export function isConnectorProviderId(v: string): v is ConnectorProviderId {
  return (CONNECTOR_PROVIDER_IDS as readonly string[]).includes(v);
}

export function maskApiKey(key: string): string | null {
  const k = key.trim();
  if (!k) return null;
  if (k.length <= 8) return '••••••••';
  return `${k.slice(0, 4)}…${k.slice(-4)}`;
}

export function parseConnector(raw: unknown): ConnectorOptions {
  const o = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
  const providersRaw =
    o.providers && typeof o.providers === 'object'
      ? (o.providers as Record<string, unknown>)
      : {};

  const providers = { ...DEFAULT_CONNECTOR.providers };
  for (const id of CONNECTOR_PROVIDER_IDS) {
    const row = providersRaw[id];
    const r = row && typeof row === 'object' ? (row as Record<string, unknown>) : {};
    const models = CONNECTOR_PROVIDER_CATALOG.find((p) => p.id === id)?.models ?? [];
    const model = asString(r.defaultModel, defaultModelFor(id));
    const apiKey = asString(r.apiKey, '');
    const effort = asString(r.effort, DEFAULT_EFFORT) as ConnectorEffort;
    providers[id] = {
      id,
      enabled: asBool(r.enabled, false),
      apiKey: apiKey === STUB_BEEQUEEN_KEY ? '' : apiKey,
      defaultModel: models.some((m) => m.id === model) ? model : defaultModelFor(id),
      effort: CONNECTOR_EFFORTS.includes(effort) ? effort : DEFAULT_EFFORT,
      serviceUrl: id === 'beequeen' ? normalizeServiceUrl(asString(r.serviceUrl, '')) || DEFAULT_BEEQUEEN_URL : '',
    };
  }

  return { providers };
}

export function normalizeServiceUrl(raw: string): string {
  const v = raw.trim().replace(/\/+$/, '');
  return /^https?:\/\/[^\s/]+(\/[^\s]*)?$/i.test(v) ? v : '';
}

/** Where this site reaches BeeQueen. The environment wins, so a deploy moves every site to 996agency.com at once. */
export function beeQueenServiceUrl(opts: ConnectorOptions): string {
  return process.env.BEEQUEEN_SERVICE_URL?.trim()
    ? DEFAULT_BEEQUEEN_URL
    : opts.providers.beequeen.serviceUrl || DEFAULT_BEEQUEEN_URL;
}

/** This site's BeeQueen connection, when it has a BeeQueen site key. */
export function beeQueenService(opts: ConnectorOptions): { url: string; key: string } | null {
  const key = opts.providers.beequeen.apiKey.trim();
  return key.startsWith(BEEQUEEN_KEY_PREFIX) ? { url: beeQueenServiceUrl(opts), key } : null;
}

/**
 * An Anthropic key for running BeeQueen directly (owner testing without the BeeQueen
 * service): the Claude connector's key, else ANTHROPIC_API_KEY from the environment.
 */
export function anthropicKey(opts: ConnectorOptions): string {
  return opts.providers.claude.apiKey.trim() || (process.env.ANTHROPIC_API_KEY ?? '').trim();
}
