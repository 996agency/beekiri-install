import { Site, SiteSettings } from '../../models';
import {
  DEFAULT_ADMIN_BASE_PATH,
  DEFAULT_ADMIN_LOGIN_SLUG,
  normalizeAdminBasePath,
  normalizeAdminLoginSlug,
} from './admin-login';
import { readOptions } from './site-options';

let cachedBase = DEFAULT_ADMIN_BASE_PATH;
let cachedSlug = DEFAULT_ADMIN_LOGIN_SLUG;
let cachedAt = 0;
let inflight: Promise<string> | null = null;
const TTL_MS = 5_000;

/** Force the next resolveAdminBasePath() to re-read from the DB. */
export function bumpAdminBasePathCache(next?: string) {
  if (next) cachedBase = normalizeAdminBasePath(next);
  cachedAt = 0;
}

/** Current admin SPA mount path (`/admin` by default). Cached briefly for the host. */
export async function resolveAdminBasePath(): Promise<string> {
  const now = Date.now();
  if (now - cachedAt < TTL_MS && cachedAt > 0) return cachedBase;
  if (inflight) return inflight;

  inflight = (async () => {
    try {
      const site = await Site.findOne({
        order: [['createdAt', 'ASC']],
        include: [{ model: SiteSettings, as: 'settings' }],
      });
      const opts = readOptions(site?.settings?.options);
      cachedBase = normalizeAdminBasePath(opts.adminBasePath ?? DEFAULT_ADMIN_BASE_PATH);
      cachedSlug = normalizeAdminLoginSlug(opts.adminLoginSlug ?? DEFAULT_ADMIN_LOGIN_SLUG);
    } catch {
      /* keep previous / default while DB is down */
    } finally {
      cachedAt = Date.now();
      inflight = null;
    }
    return cachedBase;
  })();

  return inflight;
}

/** Admin mount + sign-in slug, for the admin page itself (never a public API). */
export async function resolveAdminEntry(): Promise<{ basePath: string; loginSlug: string }> {
  const basePath = await resolveAdminBasePath();
  return { basePath, loginSlug: cachedSlug };
}

export function peekAdminBasePath(): string {
  return cachedBase;
}
