import { readFileSync } from 'node:fs';
import { join } from 'node:path';

let cached: string | null = null;

/** Public form stylesheet (form.css next to this file; copied into dist by copy-assets). */
export function formCss(): string {
  if (cached === null || process.env.NODE_ENV !== 'production') {
    cached = readFileSync(join(__dirname, 'form.css'), 'utf8');
  }
  return cached;
}

/** Where the editor and the website load the stylesheet from. */
export const FORM_CSS_PATH = '/api/forms/public/assets/form.css';
