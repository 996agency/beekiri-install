import { randomBytes, timingSafeEqual } from 'crypto';
import type { Request, Response } from 'express';
import * as z from 'zod/v4';

import type { BeeQueenTool } from './tools';

/**
 * A minimal MCP server (Streamable HTTP, JSON responses) that hands BeeQueen's tools
 * to a Claude Code process on this machine. Each run gets its own bearer token;
 * the endpoint answers loopback requests only and forgets the token when the run ends.
 */

type McpRun = { tools: BeeQueenTool[] };

const runs = new Map<string, McpRun>();

const PROTOCOL_VERSION = '2025-06-18';

export function openMcpRun(tools: BeeQueenTool[]): { token: string; close: () => void } {
  const token = randomBytes(24).toString('hex');
  runs.set(token, { tools });
  return { token, close: () => runs.delete(token) };
}

function findRun(req: Request): McpRun | null {
  const header = req.get('authorization') ?? '';
  const token = header.startsWith('Bearer ') ? header.slice(7).trim() : '';
  if (!token) return null;
  for (const [key, run] of runs) {
    const a = Buffer.from(key);
    const b = Buffer.from(token);
    if (a.length === b.length && timingSafeEqual(a, b)) return run;
  }
  return null;
}

function isLoopback(req: Request): boolean {
  const ip = req.socket.remoteAddress ?? '';
  return ip === '127.0.0.1' || ip === '::1' || ip === '::ffff:127.0.0.1';
}

type RpcRequest = { jsonrpc?: string; id?: string | number | null; method?: string; params?: Record<string, unknown> };

async function answer(run: McpRun, msg: RpcRequest): Promise<unknown> {
  switch (msg.method) {
    case 'initialize':
      return {
        protocolVersion: typeof msg.params?.protocolVersion === 'string' ? msg.params.protocolVersion : PROTOCOL_VERSION,
        capabilities: { tools: { listChanged: false } },
        serverInfo: { name: 'beequeen', version: '1.0.0' },
      };
    case 'ping':
      return {};
    case 'tools/list':
      return {
        tools: run.tools.map((t) => ({
          name: t.name,
          description: t.description,
          inputSchema: z.toJSONSchema(t.schema),
        })),
      };
    case 'tools/call': {
      const name = String(msg.params?.name ?? '');
      const found = run.tools.find((t) => t.name === name);
      if (!found) return { content: [{ type: 'text', text: `Unknown tool ${name}.` }], isError: true };
      const parsed = found.schema.safeParse(msg.params?.arguments ?? {});
      if (!parsed.success) {
        return { content: [{ type: 'text', text: `Invalid input: ${z.prettifyError(parsed.error)}` }], isError: true };
      }
      const text = await found.run(parsed.data as never);
      return { content: [{ type: 'text', text }], isError: text.startsWith('ERROR:') };
    }
    default:
      throw Object.assign(new Error(`Method not found: ${msg.method}`), { code: -32601 });
  }
}

export async function handleMcp(req: Request, res: Response) {
  if (!isLoopback(req)) {
    res.status(403).json({ message: 'BeeQueen tools are only served to this machine.' });
    return;
  }
  const run = findRun(req);
  if (!run) {
    res.status(401).json({ message: 'Unknown or finished BeeQueen run.' });
    return;
  }
  if (req.method === 'GET') {
    // No server-initiated stream; every reply comes back on the POST.
    res.status(405).set('Allow', 'POST, DELETE').end();
    return;
  }
  if (req.method === 'DELETE') {
    res.status(200).end();
    return;
  }

  const body = req.body as RpcRequest | RpcRequest[];
  const batch = Array.isArray(body) ? body : [body];
  const replies: unknown[] = [];
  for (const msg of batch) {
    // Notifications and responses carry no id and get no reply.
    if (msg?.id === undefined || msg.id === null) continue;
    try {
      replies.push({ jsonrpc: '2.0', id: msg.id, result: await answer(run, msg) });
    } catch (error) {
      const err = error as Error & { code?: number };
      replies.push({ jsonrpc: '2.0', id: msg.id, error: { code: err.code ?? -32603, message: err.message } });
    }
  }
  if (!replies.length) {
    res.status(202).end();
    return;
  }
  res.status(200).json(Array.isArray(body) ? replies : replies[0]);
}
