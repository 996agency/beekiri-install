import { config } from '../../config/env';
import { getSelfUrl } from '../../config/runtime';
import { User } from '../../models';
import { BadGateway, HttpError } from '../../utils/http-error';

/**
 * Talks to the BeeQueen service (996Agency) for this site: its credits, the packs on
 * sale, pack requests, and what a run cost. The site key never leaves the server.
 */

export type BeeQueenServiceConn = { url: string; key: string };

export type BeeQueenAccount = {
  site: { name: string };
  balance: number;
  /** Every credit ever added to the site (packs + grants). */
  granted: number;
  currency: string;
  packs: { id: string; name: string; credits: number; price: number; priceLabel: string; description: string | null }[];
  requests: { id: string; pack: string | null; credits: number | null; status: string; note: string | null; createdAt: string; decidedAt: string | null }[];
  history: { id: string; amount: number; balanceAfter: number; kind: string; description: string | null; model: string | null; runId: string | null; createdAt: string }[];
};

let identity: { at: number; headers: Record<string, string> } | null = null;

/**
 * Who this site is, so 996Agency can see the owner and the address next to the key:
 * the site owner's email and the site's public URL.
 */
async function siteIdentity(): Promise<Record<string, string>> {
  if (identity && Date.now() - identity.at < 5 * 60_000) return identity.headers;
  const owner = await User.findOne({ where: { isOwner: true }, attributes: ['email'], order: [['createdAt', 'ASC']] });
  const url = config.urls.app ?? getSelfUrl() ?? '';
  const headers: Record<string, string> = {};
  if (owner?.email) headers['x-beequeen-owner-email'] = owner.email;
  if (url) headers['x-beequeen-site-url'] = url;
  identity = { at: Date.now(), headers };
  return headers;
}

async function call<T>(conn: BeeQueenServiceConn, path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${conn.url}/api/beequeen/v1${path}`, {
      method: init.method ?? 'GET',
      headers: {
        ...(await siteIdentity().catch(() => ({}))),
        Authorization: `Bearer ${conn.key}`,
        Accept: 'application/json',
        ...(init.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      },
      body: init.body !== undefined ? JSON.stringify(init.body) : undefined,
      signal: AbortSignal.timeout(15_000),
    });
  } catch {
    throw BadGateway(`Could not reach the BeeQueen service at ${conn.url}.`);
  }
  const data = (await res.json().catch(() => ({}))) as T & { error?: { message?: string } };
  if (!res.ok) {
    // The service answers in Claude's error shape; keep its status (401 bad key, 402 no credits…).
    throw new HttpError(res.status === 401 || res.status === 402 || res.status === 403 ? res.status : 502, data.error?.message || `BeeQueen service error ${res.status}.`);
  }
  return data;
}

export const beeQueenServiceClient = {
  account: (conn: BeeQueenServiceConn) => call<BeeQueenAccount>(conn, '/account'),
  requestPack: (conn: BeeQueenServiceConn, pack: string) =>
    call<BeeQueenAccount>(conn, '/pack-requests', { method: 'POST', body: { pack } }),
  runCost: (conn: BeeQueenServiceConn, runId: string) =>
    call<{ credits: number; balance: number; granted: number }>(conn, `/runs/${encodeURIComponent(runId)}`),
};
