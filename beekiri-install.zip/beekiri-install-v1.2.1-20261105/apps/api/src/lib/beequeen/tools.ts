import * as z from 'zod/v4';

import type { CapabilitySlug } from '../cms-types';
import {
  getPage,
  listMedia,
  listThemeFiles,
  readLayout,
  readThemeFile,
  saveLayout,
  savePage,
  siteOverview,
  writeThemeFile,
  type Workspace,
} from './workspace';

/**
 * BeeQueen's tools, defined once and served two ways: to the Claude API through the
 * SDK tool runner, and to Claude Code on this machine over MCP.
 */
export type BeeQueenTool = {
  name: string;
  description: string;
  schema: z.ZodObject;
  run: (input: never) => Promise<string>;
};

/** Runs one tool step: reports it to the chat and turns failures into text the model can act on. */
export type StepRunner = (label: string, work: () => Promise<string>) => Promise<string>;

function tool<S extends z.ZodObject>(def: {
  name: string;
  description: string;
  schema: S;
  run: (input: z.infer<S>) => Promise<string>;
}): BeeQueenTool {
  return def as unknown as BeeQueenTool;
}

export const SYSTEM_PROMPT = `You are BeeQueen, the site-building agent inside Beekiri, a CMS. You work for the site owner in the admin, and you build real things on their site with your tools — you don't just describe them.

# What you can touch
Only the active client (child) theme, Backend Fields field groups that sync into it, pages, and the media library (read-only). Never the Beekiri core, the parent "beekiri" theme (read-only reference), other themes, users, settings, or secrets. If asked for something outside that, say briefly that it's outside BeeQueen's scope and point to the right admin screen.

# How a Beekiri site is built
- A layout is a reusable section: a Backend Fields field group (the editable content) plus a folder in the theme: layouts/{slug}/{slug}.php (or .tsx on React sites), styles.scss (compiled automatically), script.js.
- save_layout creates or updates BOTH halves at once — the field group and the theme files — so they never drift. The slug comes from the title ("About Hero" → about-hero). Saving with the same title updates that layout; never create near-duplicates of a layout that exists.
- A page is a document of blocks. Prefer layout blocks: { "type": "layout", "layout": "about-hero", "fields": { ...values } }. The editor lets the owner change every value afterwards, which is the point — real content lives in fields, not hard-coded in templates.
- Plain editor blocks (section, container, heading, text, button, image, list, divider, spacer, video) exist for small one-off glue; don't build whole pages from them.

# Writing layouts (PHP runtime)
- Start the file with a <?php block that reads every value: $title = get_bee_field('title');
- Repeaters and groups: <?php if (have_bee_rows('items')) : while (have_bee_rows('items')) : the_bee_row(); $label = get_bee_field('label'); ?> … <?php endwhile; endif; ?> — inside the loop get_bee_field reads the row's sub fields.
- Field values as the template receives them: text/textarea/wysiwyg → string; image → array with url, alt, width, height (or a string if returnFormat is "url"); link → array with title, url, target; true_false → bool; select/radio → the chosen value; gallery → array of image arrays.
- Always escape: esc_html(), esc_attr(), esc_url(); bee_esc_html() for textarea/wysiwyg. Guard optional values with if (…) so empty fields render nothing.
- Root element: <section class="section {slug}" data-layout="{slug}">, inner wrappers as needed. Class names: short and scoped — bk-title, bk-text, bk-items, bk-item…; style them nested under .{slug} in styles.scss.
- styles.scss: modern, responsive (mobile-first, clamp() type scales, CSS grid/flex), accessible contrast, hover/focus states. Use the theme's CSS variables when they exist (read style.css and the parent tokens first). No external fonts or CDNs. Keep selectors under .{slug} so layouts never leak into each other.
- script.js only when the section really needs behaviour; wrap it in an IIFE, select [data-layout="{slug}"]:not([data-bk-ready]), set data-bk-ready, and run on load and on window 'bk:navigate'.
- Field definitions: name in snake_case, a clear label, short instructions for the editor. Types: text, textarea, wysiwyg, number, url, email, image, gallery, link, true_false, select (choices "value : Label"), repeater/group (subFields), color_picker, form (a Bee Forms form; render with <?php echo bee_form($field); ?>).
- save_layout checks the draft first (SCSS compile, php -l) and saves nothing if that fails; after saving it test-renders with sample values and checks every field the template reads exists. If it reports a problem, fix it and save again before using the layout.

# Working style
0. Before your first tool call, tell the owner in one short sentence what you're about to do.
1. Look before you build: get_site_overview first, then read the layouts, style.css and header/footer you need, so new work matches the existing design and reuses layouts that already fit.
2. For a page request ("full About Us landing page"): plan the sections (e.g. hero, story, values, team, stats, testimonials, CTA), reuse fitting layouts, create the missing ones with save_layout, then save_page with every field filled in with specific, polished, on-brand copy — never lorem ipsum. Use real media-library images when list_media has suitable ones; otherwise leave image fields empty and mention it.
3. Pages are saved as drafts unless the owner asks to publish.
4. When a request is ambiguous, make sensible choices and state them; ask only when you truly can't proceed.
5. Finish with a short summary in plain language: what you created or changed, what the owner should review, and any image fields to fill. No code in the summary unless asked.`;

export function beeQueenTools(ws: Workspace, step: StepRunner): BeeQueenTool[] {
  /**
   * Writing tools do exactly what the matching admin screen does, so they need that
   * screen's capability: `use_beequeen` alone only reads.
   */
  const needs = <T>(capability: CapabilitySlug, run: (input: T) => Promise<string>) =>
    (input: T) =>
      ws.actor.capabilities.includes(capability)
        ? run(input)
        : Promise.resolve(
            `ERROR: This account does not have the "${capability}" permission, which that change needs. Tell the owner what you wanted to do so they can grant it or make the change.`,
          );
  return [
    tool({
      name: 'get_site_overview',
      description: 'Active theme, frontend runtime, every layout with its fields, and the page list. Call this first.',
      schema: z.object({}),
      run: () => step('Looking at your site', () => siteOverview(ws)),
    }),
    tool({
      name: 'list_theme_files',
      description: 'Text files in the client theme (writable) and its parent theme (read-only reference).',
      schema: z.object({}),
      run: () => step('Listing theme files', () => listThemeFiles()),
    }),
    tool({
      name: 'read_theme_file',
      description:
        'Read a theme file by theme-relative path, e.g. "style.css", "header/header.php", "header/styles.scss". Child theme first, then parent.',
      schema: z.object({ path: z.string().describe('Theme-relative path') }),
      run: ({ path }) => step(`Reading ${path}`, () => readThemeFile(path)),
    }),
    tool({
      name: 'write_theme_file',
      description:
        'Write a file in the client theme (not layouts/ — use save_layout — and not theme.json). For global styles in style.css or header/footer tweaks. Send the whole file content.',
      schema: z.object({
        path: z.string().describe('Theme-relative path, e.g. "style.css"'),
        content: z.string().describe('Complete new file content'),
      }),
      run: needs('edit_theme_options', ({ path, content }) =>
        step(`Saving ${path}`, () => writeThemeFile(ws, path, content)),
      ),
    }),
    tool({
      name: 'read_layout',
      description: 'A layout’s Backend Fields definition, template, SCSS and script.',
      schema: z.object({ slug: z.string() }),
      run: ({ slug }) => step(`Reading layout ${slug}`, () => readLayout(slug)),
    }),
    tool({
      name: 'save_layout',
      description:
        'Create or update a layout: writes the Backend Fields field group AND the theme files (template, styles.scss, script.js), compiles SCSS and test-renders. The same title updates the existing layout.',
      schema: z.object({
        title: z.string().describe('Human title, e.g. "About Hero". Determines the slug.'),
        description: z.string().optional().describe('One line shown in Backend Fields'),
        fields: z
          .array(
            z
              .object({
                type: z.string().describe('Field type, e.g. text, textarea, wysiwyg, image, link, repeater'),
                label: z.string(),
                name: z.string().describe('snake_case, unique in its level'),
                instructions: z.string().optional(),
                required: z.boolean().optional(),
                defaultValue: z.string().optional(),
                choices: z.array(z.string()).optional().describe('select/radio/checkbox: "value : Label"'),
                returnFormat: z.string().optional(),
                subFields: z
                  .array(z.record(z.string(), z.unknown()))
                  .optional()
                  .describe('repeater/group children — same shape as a field'),
              })
              .passthrough(),
          )
          .describe('Backend Fields definitions the template reads with get_bee_field()'),
        template: z.string().describe('Full layout template ({slug}.php on PHP sites, {slug}.tsx on React sites)'),
        scss: z.string().describe('Full styles.scss, scoped under .{slug}'),
        js: z.string().optional().describe('Full script.js, only if the section needs behaviour'),
      }),
      run: needs('manage_fields', (input) =>
        step(`Building layout “${input.title}”`, () =>
          saveLayout(ws, { ...input, fields: input.fields as Record<string, unknown>[] }),
        ),
      ),
    }),
    tool({
      name: 'get_page',
      description: 'A page’s title, slug, status and blocks (the same shape save_page takes).',
      schema: z.object({ id: z.string() }),
      run: ({ id }) => step('Opening page', () => getPage(ws, id)),
    }),
    tool({
      name: 'save_page',
      description:
        'Create a page (no id) or replace an existing page’s title/slug/status/blocks (with id). Blocks: {"type":"layout","layout":"<slug>","fields":{...}} or editor blocks {"type":"section"|"container","style":{},"children":[...]}, {"type":"heading","tag":"h2","text":"…"}, {"type":"text","text":"…"}, {"type":"button","text":"…","href":"/contact"}, {"type":"image","src":"…","alt":"…"}. Field values use stored shapes: image → media id or image URL, link → {"title","url","target"}, repeater → array of row objects, true_false → boolean.',
      schema: z.object({
        id: z.string().optional(),
        title: z.string(),
        slug: z.string().optional(),
        status: z.enum(['draft', 'publish']).optional().describe('Default draft'),
        blocks: z.array(z.record(z.string(), z.unknown())),
      }),
      run: (input) => step(`Saving page “${input.title}”`, () => savePage(ws, input)),
    }),
    tool({
      name: 'list_media',
      description: 'Images in the media library (id, size, alt, url) for image fields.',
      schema: z.object({ search: z.string().optional() }),
      run: ({ search }) => step('Checking the media library', () => listMedia(ws, search)),
    }),
  ];
}
