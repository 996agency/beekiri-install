import { createReadStream, existsSync } from 'fs';
import { createInterface } from 'readline';
import { QueryTypes, Transaction } from 'sequelize';
import { sequelize } from '../../db/sequelize';
import { decryptSecret } from '../shop/secrets';
import type { ArchiveWriter } from './archive';

/** Never copied between sites: sign-ins, one-time tokens and schema bookkeeping. */
export const NEVER_COPIED = new Set([
  'SequelizeMeta',
  'InstallationState',
  'Session',
  'PasswordResetToken',
  'ShopCustomerSession',
  'ShopCustomerToken',
]);

/** Data the receiving site can choose to keep instead of replacing. */
export const KEEP_GROUPS = {
  analytics: ['BeeCookieConsent', 'BeeCookieVisit', 'BeeCookieClick'],
  orders: ['ShopOrder', 'ShopOrderItem', 'ShopOrderNote', 'ShopCustomer', 'ShopPaymentEvent', 'ShopCart'],
  activity: ['AuditLog'],
} as const;
export type KeepGroup = keyof typeof KEEP_GROUPS;
export const KEEP_GROUP_IDS = Object.keys(KEEP_GROUPS) as KeepGroup[];

export function keptTables(groups: readonly KeepGroup[]): Set<string> {
  return new Set(groups.flatMap((g) => [...(KEEP_GROUPS[g] ?? [])]));
}

/** Site options that belong to one site and stay put when another site's database arrives. */
const SITE_OWN_OPTIONS = ['hub', 'connector', 'adminBasePath', 'adminLoginSlug', 'cacheEpoch'];
/** Never run find & replace on these (hashes and tokens). */
const NO_REPLACE_COLUMNS = new Set(['passwordHash', 'tokenHash', 'csrfSecret']);

type Fk = { table: string; column: string; refTable: string; refColumn: string; onDelete: string };

export type DbSchema = {
  tables: string[];
  columns: Map<string, string[]>;
  pk: Map<string, string[]>;
  fks: Fk[];
};

const q = (name: string) => `"${name.replace(/"/g, '""')}"`;

export async function readSchema(transaction?: Transaction): Promise<DbSchema> {
  const tables = (
    await sequelize.query<{ name: string }>(
      `SELECT c.relname AS name FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = 'public' AND c.relkind IN ('r', 'p') ORDER BY c.relname`,
      { type: QueryTypes.SELECT, transaction },
    )
  ).map((r) => r.name);
  const columns = new Map<string, string[]>();
  for (const r of await sequelize.query<{ table: string; column: string }>(
    `SELECT table_name AS table, column_name AS column FROM information_schema.columns
      WHERE table_schema = 'public' AND is_generated = 'NEVER' ORDER BY table_name, ordinal_position`,
    { type: QueryTypes.SELECT, transaction },
  )) {
    columns.set(r.table, [...(columns.get(r.table) ?? []), r.column]);
  }
  const pk = new Map<string, string[]>();
  for (const r of await sequelize.query<{ table: string; column: string }>(
    `SELECT c.relname AS table, a.attname AS column
       FROM pg_index i JOIN pg_class c ON c.oid = i.indrelid JOIN pg_namespace n ON n.oid = c.relnamespace
       JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey)
      WHERE n.nspname = 'public' AND i.indisprimary ORDER BY c.relname, a.attnum`,
    { type: QueryTypes.SELECT, transaction },
  )) {
    pk.set(r.table, [...(pk.get(r.table) ?? []), r.column]);
  }
  const fks = await sequelize.query<Fk>(
    `SELECT c.conrelid::regclass::text AS table, a.attname AS column, c.confrelid::regclass::text AS "refTable",
            ra.attname AS "refColumn", c.confdeltype AS "onDelete"
       FROM pg_constraint c
       JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = c.conkey[1]
       JOIN pg_attribute ra ON ra.attrelid = c.confrelid AND ra.attnum = c.confkey[1]
       JOIN pg_namespace n ON n.oid = c.connamespace
      WHERE c.contype = 'f' AND n.nspname = 'public'`,
    { type: QueryTypes.SELECT, transaction },
  );
  const unquote = (s: string) => s.replace(/^"|"$/g, '').replace(/""/g, '"');
  return {
    tables,
    columns,
    pk,
    fks: fks.map((f) => ({ ...f, table: unquote(f.table), refTable: unquote(f.refTable) })),
  };
}

/** Parents before children, so inserts never point at rows that are not there yet. */
export function parentsFirst(tables: string[], fks: Fk[]): string[] {
  const set = new Set(tables);
  const deps = new Map<string, Set<string>>(tables.map((t) => [t, new Set<string>()]));
  for (const fk of fks) {
    if (set.has(fk.table) && set.has(fk.refTable) && fk.table !== fk.refTable) deps.get(fk.table)!.add(fk.refTable);
  }
  const out: string[] = [];
  const state = new Map<string, 'visiting' | 'done'>();
  const visit = (t: string) => {
    if (state.get(t) === 'done') return;
    if (state.get(t) === 'visiting') throw new Error(`The tables ${t} and another depend on each other.`);
    state.set(t, 'visiting');
    for (const d of [...deps.get(t)!].sort()) visit(d);
    state.set(t, 'done');
    out.push(t);
  };
  for (const t of [...tables].sort()) visit(t);
  return out;
}

export async function appliedMigrations(): Promise<string[]> {
  try {
    const rows = await sequelize.query<{ name: string }>(`SELECT name FROM "SequelizeMeta" ORDER BY name`, {
      type: QueryTypes.SELECT,
    });
    return rows.map((r) => r.name);
  } catch {
    return [];
  }
}

/** The tables a database export will contain, with their columns and (approximate) row counts. */
export async function describeTables(
  skip: Set<string>,
): Promise<{ tables: { name: string; columns: string[]; rows: number }[]; skipped: string[] }> {
  const schema = await readSchema();
  const order = parentsFirst(schema.tables, schema.fks).filter((name) => !NEVER_COPIED.has(name));
  const tables: { name: string; columns: string[]; rows: number }[] = [];
  const skipped: string[] = [];
  for (const name of order) {
    if (skip.has(name)) {
      skipped.push(name);
      continue;
    }
    const [{ n }] = await sequelize.query<{ n: string }>(`SELECT count(*)::text AS n FROM ${q(name)}`, {
      type: QueryTypes.SELECT,
    });
    tables.push({ name, columns: schema.columns.get(name) ?? [], rows: Number(n) || 0 });
  }
  return { tables, skipped };
}

const ROWS_PER_RECORD_BYTES = 2 * 1024 * 1024;

/**
 * Writes every copyable table to the archive from one consistent snapshot of the database.
 * `skip`: tables the receiving site keeps (they are not sent at all).
 */
export async function exportDatabase(
  writer: ArchiveWriter,
  opts: { skip: Set<string>; onTable?: (table: string, index: number, total: number) => void },
): Promise<{ tables: { name: string; columns: string[]; rows: number }[]; skipped: string[] }> {
  return sequelize.transaction({ isolationLevel: Transaction.ISOLATION_LEVELS.REPEATABLE_READ }, async (t) => {
    const schema = await readSchema(t);
    const order = parentsFirst(schema.tables, schema.fks).filter((name) => !NEVER_COPIED.has(name));
    const tables: { name: string; columns: string[]; rows: number }[] = [];
    const skipped: string[] = [];
    const todo = order.filter((name) => !opts.skip.has(name));
    for (const name of order) if (opts.skip.has(name)) skipped.push(name);
    for (const [index, name] of todo.entries()) {
      opts.onTable?.(name, index, todo.length);
      const columns = schema.columns.get(name) ?? [];
      const orderBy = (schema.pk.get(name) ?? columns.slice(0, 1)).map(q).join(', ');
      await sequelize.query(
        `DECLARE bkm_rows NO SCROLL CURSOR FOR
           SELECT row_to_json(x)::text AS r FROM (SELECT ${columns.map(q).join(', ')} FROM ${q(name)} ORDER BY ${orderBy}) x`,
        { transaction: t },
      );
      let rows = 0;
      let lines: string[] = [];
      let bytes = 0;
      const flush = async () => {
        if (!lines.length) return;
        await writer.record({ t: 'rows', table: name, count: lines.length }, `${lines.join('\n')}\n`);
        lines = [];
        bytes = 0;
      };
      for (;;) {
        const batch = await sequelize.query<{ r: string }>(`FETCH 500 FROM bkm_rows`, {
          type: QueryTypes.SELECT,
          transaction: t,
        });
        if (!batch.length) break;
        for (const { r } of batch) {
          lines.push(r);
          bytes += r.length + 1;
          rows += 1;
        }
        if (bytes >= ROWS_PER_RECORD_BYTES) await flush();
      }
      await flush();
      await sequelize.query(`CLOSE bkm_rows`, { transaction: t });
      tables.push({ name, columns, rows });
    }
    return { tables, skipped };
  });
}

/** Rows of the given themes' Backend Fields, as NDJSON. */
export async function exportThemeFieldGroups(theme: string): Promise<{ body: string; count: number }> {
  const rows = await sequelize.query<{ r: string }>(
    `SELECT row_to_json(f)::text AS r FROM "FieldGroup" f
      WHERE f."siteId" = (SELECT id FROM "Site" ORDER BY "createdAt" ASC LIMIT 1) AND f.theme = :theme
      ORDER BY f."menuOrder", f."createdAt"`,
    { type: QueryTypes.SELECT, replacements: { theme } },
  );
  return { body: rows.map((r) => r.r).join('\n') + (rows.length ? '\n' : ''), count: rows.length };
}

export type Replacement = { find: string; replace: string };

/** Find & replace on text, also for JSON-escaped slashes (`https:\/\/…`). */
export function makeReplacer(pairs: Replacement[]): ((s: string) => string) | null {
  const list: Replacement[] = [];
  for (const p of pairs) {
    const find = p.find ?? '';
    if (!find || find === p.replace) continue;
    list.push({ find, replace: p.replace ?? '' });
    if (find.includes('/')) {
      list.push({ find: find.replace(/\//g, '\\/'), replace: (p.replace ?? '').replace(/\//g, '\\/') });
    }
  }
  if (!list.length) return null;
  return (s: string) => {
    let out = s;
    for (const p of list) if (out.includes(p.find)) out = out.split(p.find).join(p.replace);
    return out;
  };
}

export function deepReplace(value: unknown, fn: (s: string) => string): unknown {
  if (typeof value === 'string') return fn(value);
  if (Array.isArray(value)) return value.map((v) => deepReplace(v, fn));
  if (value && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) out[k] = deepReplace(v, fn);
    return out;
  }
  return value;
}

/**
 * Encrypted secrets (payment keys, tokens) only open on the site that wrote them. This site keeps
 * its own value at the same place; a value that opens here too is used when this site had none.
 */
export function keepOwnSecrets(incoming: unknown, current: unknown): unknown {
  if (typeof incoming === 'string' && incoming.startsWith('enc:v1:')) {
    if (typeof current === 'string' && current) return current;
    return decryptSecret(incoming) ? incoming : '';
  }
  if (Array.isArray(incoming)) {
    return incoming.map((v, i) => keepOwnSecrets(v, Array.isArray(current) ? current[i] : undefined));
  }
  if (incoming && typeof incoming === 'object') {
    const cur = current && typeof current === 'object' && !Array.isArray(current) ? (current as Record<string, unknown>) : {};
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(incoming)) out[k] = keepOwnSecrets(v, cur[k]);
    return out;
  }
  return incoming;
}

async function* ndjsonBatches(file: string, maxRows = 400, maxBytes = 1024 * 1024): AsyncGenerator<Record<string, unknown>[]> {
  const lines = createInterface({ input: createReadStream(file, 'utf8'), crlfDelay: Infinity });
  let batch: Record<string, unknown>[] = [];
  let bytes = 0;
  for await (const line of lines) {
    if (!line.trim()) continue;
    batch.push(JSON.parse(line) as Record<string, unknown>);
    bytes += line.length;
    if (batch.length >= maxRows || bytes >= maxBytes) {
      yield batch;
      batch = [];
      bytes = 0;
    }
  }
  if (batch.length) yield batch;
}

async function insertRows(table: string, columns: string[], rows: Record<string, unknown>[], t: Transaction) {
  if (!rows.length) return;
  const cols = columns.map(q).join(', ');
  await sequelize.query(
    `INSERT INTO ${q(table)} (${cols}) SELECT ${cols} FROM json_populate_recordset(NULL::${q(table)}, $1::json)`,
    { bind: [JSON.stringify(rows)], transaction: t },
  );
}

export type DatabaseImport = {
  /** Folder with one `<table>.ndjson` per table. */
  dir: string;
  tables: { name: string; columns: string[]; rows: number }[];
  sourceSiteId: string;
  replacements: Replacement[];
  /** Orders were kept on this site: never move the next order number backwards. */
  keepOrders: boolean;
  onProgress?: (done: number, total: number, table: string) => void;
};

/**
 * Replaces this site's database with the incoming tables in one transaction (all or nothing).
 * This site keeps: its id, sign-ins (moved to the same e-mail address when user ids changed),
 * its own secrets and per-site options, search-engine visibility, and any table not sent.
 */
export async function importDatabase(opts: DatabaseImport): Promise<{ tables: number; rows: number; sessions: number }> {
  return sequelize.transaction(async (t) => {
    await sequelize.query(`SET LOCAL lock_timeout = '30s'`, { transaction: t });
    const schema = await readSchema(t);
    const known = new Set(schema.tables);
    for (const table of opts.tables) {
      if (!known.has(table.name)) {
        throw new Error(`The table ${table.name} does not exist on this site. Update Beekiri on this site first.`);
      }
    }
    const site = await sequelize.query<{ id: string }>(`SELECT id FROM "Site" ORDER BY "createdAt" ASC LIMIT 1`, {
      type: QueryTypes.SELECT,
      transaction: t,
    });
    const siteId = site[0]?.id;
    if (!siteId) throw new Error('This site is not installed yet. Finish the Beekiri setup first.');

    const incoming = new Map(opts.tables.map((tbl) => [tbl.name, tbl]));
    const replaced = new Set([...incoming.keys()].filter((n) => n !== 'Site' && !NEVER_COPIED.has(n)));
    const kept = schema.tables.filter((n) => !replaced.has(n) && n !== 'Site');
    const fksTo = (table: string) => schema.fks.filter((f) => f.table === table);

    // Kept tables whose rows would be deleted with the replaced rows they point at (cascade).
    const affected = new Set<string>();
    for (let changed = true; changed; ) {
      changed = false;
      for (const table of kept) {
        if (affected.has(table)) continue;
        const hit = fksTo(table).some(
          (f) => (replaced.has(f.refTable) && f.onDelete !== 'n') || (affected.has(f.refTable) && f.onDelete === 'c'),
        );
        if (hit) {
          affected.add(table);
          changed = true;
        }
      }
    }
    const rowsOf = async (table: string, where = '') =>
      (
        await sequelize.query<{ r: Record<string, unknown> }>(`SELECT row_to_json(x) AS r FROM ${q(table)} x ${where}`, {
          type: QueryTypes.SELECT,
          transaction: t,
        })
      ).map((row) => row.r);
    const snapshots = new Map<string, Record<string, unknown>[]>();
    for (const table of affected) snapshots.set(table, await rowsOf(table));
    // Kept rows whose link is only cleared (ON DELETE SET NULL): remember the link.
    const links: { fk: Fk; rows: Record<string, unknown>[] }[] = [];
    for (const table of kept) {
      if (affected.has(table)) continue;
      const keyCols = schema.pk.get(table);
      if (!keyCols?.length) continue;
      for (const fk of fksTo(table)) {
        if (fk.onDelete !== 'n' || !replaced.has(fk.refTable)) continue;
        const cols = [...keyCols, fk.column].map(q).join(', ');
        const rows = (
          await sequelize.query<{ r: Record<string, unknown> }>(
            `SELECT row_to_json(x) AS r FROM (SELECT ${cols} FROM ${q(table)} WHERE ${q(fk.column)} IS NOT NULL) x`,
            { type: QueryTypes.SELECT, transaction: t },
          )
        ).map((row) => row.r);
        if (rows.length) links.push({ fk, rows });
      }
    }
    // Users are matched by e-mail address when their ids differ between the two sites.
    const oldEmailById = new Map<string, string>();
    if (replaced.has('User')) {
      for (const u of await sequelize.query<{ id: string; email: string }>(`SELECT id, lower(email) AS email FROM "User"`, {
        type: QueryTypes.SELECT,
        transaction: t,
      })) {
        oldEmailById.set(u.id, u.email);
      }
    }
    const before = {
      settings: (await rowsOf('SiteSettings', `WHERE x."siteId" = '${siteId.replace(/'/g, "''")}'`))[0],
      shop: known.has('ShopSetting')
        ? (await rowsOf('ShopSetting', `WHERE x."siteId" = '${siteId.replace(/'/g, "''")}'`))[0]
        : undefined,
    };

    // Out with the old (children first; kept tables cascade or clear their links).
    const order = parentsFirst([...replaced], schema.fks);
    for (const table of [...affected]) {
      if (fksTo(table).some((f) => replaced.has(f.refTable) && (f.onDelete === 'r' || f.onDelete === 'a'))) {
        await sequelize.query(`DELETE FROM ${q(table)}`, { transaction: t });
      }
    }
    for (const table of [...order].reverse()) await sequelize.query(`DELETE FROM ${q(table)}`, { transaction: t });

    // In with the new.
    const replace = makeReplacer(opts.replacements);
    const siteCols = new Set(schema.fks.filter((f) => f.refTable === 'Site').map((f) => `${f.table}.${f.column}`));
    const total = opts.tables.reduce((n, tbl) => n + tbl.rows, 0) || 1;
    let done = 0;
    let rows = 0;
    const fix = (table: string, row: Record<string, unknown>) => {
      for (const [col, value] of Object.entries(row)) {
        if (siteCols.has(`${table}.${col}`) && value != null) row[col] = siteId;
        else if (replace && !NO_REPLACE_COLUMNS.has(col)) row[col] = deepReplace(value, replace);
      }
      if (table === 'SiteSettings' && before.settings) {
        const own = (before.settings.options ?? {}) as Record<string, unknown>;
        const next = keepOwnSecrets(row.options ?? {}, own) as Record<string, unknown>;
        for (const key of SITE_OWN_OPTIONS) {
          if (key in own) next[key] = own[key];
          else delete next[key];
        }
        row.options = next;
        row.blogPublic = before.settings.blogPublic;
      }
      if (table === 'ShopSetting') {
        row.data = keepOwnSecrets(row.data ?? {}, before.shop?.data);
        if (opts.keepOrders && before.shop) {
          row.nextOrderNumber = Math.max(Number(row.nextOrderNumber) || 1, Number(before.shop.nextOrderNumber) || 1);
        }
      }
      return row;
    };
    for (const table of ['Site', ...order]) {
      const meta = incoming.get(table);
      if (!meta) continue;
      const targetCols = new Set(schema.columns.get(table) ?? []);
      const columns = meta.columns.filter((c) => targetCols.has(c));
      opts.onProgress?.(done, total, table);
      const file = `${opts.dir}/${table}.ndjson`;
      for await (const batch of ndjsonBatchesIfExists(file)) {
        if (table === 'Site') {
          // This site keeps its id; only the name, tagline and language come across.
          const src = fix('Site', { ...batch[0], id: siteId });
          await sequelize.query(`UPDATE "Site" SET title = :title, tagline = :tagline, language = :language, "updatedAt" = now() WHERE id = :id`, {
            replacements: {
              title: String(src.title ?? ''),
              tagline: String(src.tagline ?? ''),
              language: String(src.language ?? 'en_US'),
              id: siteId,
            },
            transaction: t,
          });
          done += batch.length;
          continue;
        }
        await insertRows(table, columns, batch.map((row) => fix(table, row)), t);
        done += batch.length;
        rows += batch.length;
        opts.onProgress?.(done, total, table);
      }
    }

    // Bring back what this site keeps.
    const newIdByEmail = new Map<string, string>();
    if (replaced.has('User')) {
      for (const u of await sequelize.query<{ id: string; email: string }>(`SELECT id, lower(email) AS email FROM "User"`, {
        type: QueryTypes.SELECT,
        transaction: t,
      })) {
        newIdByEmail.set(u.email, u.id);
      }
    }
    const mapUser = (fk: Fk, value: unknown) => {
      if (fk.refTable !== 'User' || typeof value !== 'string') return value;
      const email = oldEmailById.get(value);
      return (email && newIdByEmail.get(email)) || value;
    };
    let sessions = 0;
    for (const table of parentsFirst([...affected], schema.fks)) {
      const snap = snapshots.get(table) ?? [];
      if (!snap.length) continue;
      const tableFks = fksTo(table);
      for (const row of snap) for (const fk of tableFks) row[fk.column] = mapUser(fk, row[fk.column]);
      const cols = schema.columns.get(table) ?? [];
      const pick = cols.map((c) => {
        const fk = tableFks.find((f) => f.column === c);
        if (!fk) return `r.${q(c)}`;
        const exists = `EXISTS (SELECT 1 FROM ${q(fk.refTable)} p WHERE p.${q(fk.refColumn)} = r.${q(c)})`;
        return fk.onDelete === 'n' ? `CASE WHEN ${exists} THEN r.${q(c)} END` : `r.${q(c)}`;
      });
      const must = tableFks
        .filter((fk) => fk.onDelete !== 'n')
        .map((fk) => `(r.${q(fk.column)} IS NULL OR EXISTS (SELECT 1 FROM ${q(fk.refTable)} p WHERE p.${q(fk.refColumn)} = r.${q(fk.column)}))`);
      for (let i = 0; i < snap.length; i += 400) {
        const back = await sequelize.query<{ ok: number }>(
          `INSERT INTO ${q(table)} (${cols.map(q).join(', ')})
           SELECT ${pick.join(', ')} FROM json_populate_recordset(NULL::${q(table)}, $1::json) r
            ${must.length ? `WHERE ${must.join(' AND ')}` : ''}
           ON CONFLICT DO NOTHING RETURNING 1 AS ok`,
          { bind: [JSON.stringify(snap.slice(i, i + 400))], transaction: t, type: QueryTypes.SELECT },
        );
        if (table === 'Session') sessions += back.length;
      }
    }
    for (const { fk, rows: linkRows } of links) {
      const keyCols = schema.pk.get(fk.table) ?? [];
      for (const row of linkRows) row[fk.column] = mapUser(fk, row[fk.column]);
      for (let i = 0; i < linkRows.length; i += 400) {
        await sequelize.query(
          `UPDATE ${q(fk.table)} k SET ${q(fk.column)} = s.${q(fk.column)}
             FROM json_populate_recordset(NULL::${q(fk.table)}, $1::json) s
            WHERE ${keyCols.map((c) => `k.${q(c)} = s.${q(c)}`).join(' AND ')}
              AND EXISTS (SELECT 1 FROM ${q(fk.refTable)} p WHERE p.${q(fk.refColumn)} = s.${q(fk.column)})`,
          { bind: [JSON.stringify(linkRows.slice(i, i + 400))], transaction: t },
        );
      }
    }
    opts.onProgress?.(total, total, '');
    return { tables: replaced.size, rows, sessions };
  });
}

async function* ndjsonBatchesIfExists(file: string) {
  if (!existsSync(file)) return;
  yield* ndjsonBatches(file);
}

/**
 * Replaces one theme's Backend Fields with the incoming ones (same keys on this site are
 * replaced too, since a key is unique per site).
 */
export async function importThemeFieldGroups(
  t: Transaction,
  opts: { theme: string; file: string; replacements: Replacement[] },
): Promise<number> {
  const site = await sequelize.query<{ id: string }>(`SELECT id FROM "Site" ORDER BY "createdAt" ASC LIMIT 1`, {
    type: QueryTypes.SELECT,
    transaction: t,
  });
  const siteId = site[0]?.id;
  if (!siteId) throw new Error('This site is not installed yet.');
  const schema = await readSchema(t);
  const columns = schema.columns.get('FieldGroup') ?? [];
  const rows: Record<string, unknown>[] = [];
  for await (const batch of ndjsonBatchesIfExists(opts.file)) rows.push(...batch);
  const replace = makeReplacer(opts.replacements);
  const ready = rows.map((row) => {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(row)) out[k] = replace && k !== 'siteId' ? deepReplace(v, replace) : v;
    return { ...out, siteId, theme: opts.theme } as Record<string, unknown>;
  });
  await sequelize.query(
    `DELETE FROM "FieldGroup" WHERE "siteId" = :siteId AND (theme = :theme OR key IN (:keys) OR id IN (:ids))`,
    {
      replacements: {
        siteId,
        theme: opts.theme,
        keys: ready.length ? ready.map((r) => String(r.key)) : [''],
        ids: ready.length ? ready.map((r) => String(r.id)) : [''],
      },
      transaction: t,
    },
  );
  const cols = columns.filter((c) => ready.some((r) => c in r));
  for (let i = 0; i < ready.length; i += 200) await insertRows('FieldGroup', cols, ready.slice(i, i + 200), t);
  return ready.length;
}
