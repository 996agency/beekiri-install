import { once } from 'events';
import { createReadStream, createWriteStream } from 'fs';
import type { Readable } from 'stream';
import { pipeline } from 'stream/promises';
import { createGunzip, createGzip, type Gzip } from 'zlib';

/**
 * A Beekiri migration file (`.beekiri`): one gzip stream holding a manifest, database rows
 * (NDJSON), Backend Fields of themes, theme files and media files, read and written as a stream
 * so big media libraries never sit in memory.
 *
 *   MAGIC, then records: u32 header length · header JSON (with `size`) · `size` body bytes
 */
const MAGIC = Buffer.from('BEEKIRI-MIGRATION/1\n', 'utf8');
const MAX_HEADER_BYTES = 1024 * 1024;

export type ArchiveManifest = {
  format: 1;
  createdAt: string;
  purpose: 'migration' | 'backup' | 'export';
  label: string;
  source: {
    url: string;
    name: string;
    version: string;
    siteId: string;
    migrations: string[];
    activeTheme: string;
  };
  /** Whole database (minus sign-ins and per-site secrets). */
  database?: { tables: { name: string; columns: string[]; rows: number }[]; skipped: string[] };
  /** Theme folders, each with its own Backend Fields. */
  themes?: { slug: string; name: string; version: string; files: number; fieldGroups: number }[];
  /** Backups only: themes that did not exist before, removed again on restore. */
  absentThemes?: string[];
  media?: { files: number; bytes: number; mirror: boolean };
};

export type ArchiveHeader =
  | { t: 'manifest'; size: number }
  | { t: 'rows'; table: string; count: number; size: number }
  | { t: 'theme-fields'; theme: string; count: number; size: number }
  | { t: 'file'; area: 'theme' | 'media'; path: string; size: number }
  | { t: 'media-list'; size: number }
  | { t: 'end'; size: number };

type HeaderInput = DistributiveOmit<ArchiveHeader, 'size'>;
type DistributiveOmit<T, K extends keyof T> = T extends unknown ? Omit<T, K> : never;

export class ArchiveWriter {
  private readonly gzip: Gzip;
  private readonly finished: Promise<void>;
  bytesIn = 0;

  constructor(path: string) {
    this.gzip = createGzip({ level: 6 });
    this.finished = pipeline(this.gzip, createWriteStream(path, { mode: 0o600 }));
    // Surface write errors on the next write instead of as an unhandled rejection.
    this.finished.catch(() => undefined);
    this.gzip.write(MAGIC);
  }

  private async push(buf: Buffer) {
    this.bytesIn += buf.length;
    if (!this.gzip.write(buf)) await once(this.gzip, 'drain');
  }

  private async head(header: HeaderInput, size: number) {
    const json = Buffer.from(JSON.stringify({ ...header, size }), 'utf8');
    const len = Buffer.alloc(4);
    len.writeUInt32BE(json.length, 0);
    await this.push(len);
    await this.push(json);
  }

  async record(header: HeaderInput, body: Buffer | string = Buffer.alloc(0)) {
    const buf = typeof body === 'string' ? Buffer.from(body, 'utf8') : body;
    await this.head(header, buf.length);
    if (buf.length) await this.push(buf);
  }

  /** Streams a file from disk; fails if it changes size while being read. */
  async file(header: { area: 'theme' | 'media'; path: string }, absPath: string, size: number) {
    await this.head({ t: 'file', ...header }, size);
    let written = 0;
    for await (const chunk of createReadStream(absPath)) {
      const buf = chunk as Buffer;
      if (written + buf.length > size) throw new Error(`${header.path} changed while it was being packed.`);
      written += buf.length;
      await this.push(buf);
    }
    if (written !== size) throw new Error(`${header.path} changed while it was being packed.`);
  }

  async close() {
    await this.record({ t: 'end' });
    this.gzip.end();
    await this.finished;
  }

  /** Stop writing after a failure (the caller deletes the partial file). */
  async abort() {
    this.gzip.destroy();
    await this.finished.catch(() => undefined);
  }
}

class ByteReader {
  private readonly it: AsyncIterator<Buffer>;
  private buf: Buffer = Buffer.alloc(0);

  constructor(stream: Readable) {
    this.it = stream[Symbol.asyncIterator]() as AsyncIterator<Buffer>;
  }

  private async fill(n: number): Promise<boolean> {
    if (this.buf.length >= n) return true;
    const parts: Buffer[] = [this.buf];
    let len = this.buf.length;
    while (len < n) {
      const r = await this.it.next();
      if (r.done) break;
      parts.push(r.value);
      len += r.value.length;
    }
    this.buf = Buffer.concat(parts, len);
    return len >= n;
  }

  async atEnd(): Promise<boolean> {
    return !(await this.fill(1));
  }

  async exact(n: number): Promise<Buffer> {
    if (!(await this.fill(n))) throw new Error('This migration file is incomplete or damaged.');
    const out = this.buf.subarray(0, n);
    this.buf = this.buf.subarray(n);
    return out;
  }

  async *chunks(n: number): AsyncGenerator<Buffer> {
    let left = n;
    while (left > 0) {
      if (!this.buf.length) {
        const r = await this.it.next();
        if (r.done) throw new Error('This migration file is incomplete or damaged.');
        this.buf = r.value;
      }
      const take = Math.min(left, this.buf.length);
      yield this.buf.subarray(0, take);
      this.buf = this.buf.subarray(take);
      left -= take;
    }
  }
}

export type ArchiveEntry = {
  header: ArchiveHeader;
  /** Whole body in memory (manifest, rows, lists). */
  read(): Promise<Buffer>;
  /** Body streamed to a file on disk. */
  saveTo(absPath: string): Promise<void>;
};

/** Reads a `.beekiri` file record by record. Each entry's body must be used before the next. */
export async function* readArchive(path: string): AsyncGenerator<ArchiveEntry> {
  const source = createReadStream(path);
  const gunzip = createGunzip();
  source.on('error', (e) => gunzip.destroy(e));
  source.pipe(gunzip);
  const reader = new ByteReader(gunzip);
  try {
    const magic = await reader.exact(MAGIC.length).catch(() => Buffer.alloc(0));
    if (!magic.equals(MAGIC)) throw new Error('This is not a Beekiri migration file.');
    let sawEnd = false;
    while (!(await reader.atEnd())) {
      const len = (await reader.exact(4)).readUInt32BE(0);
      if (len <= 0 || len > MAX_HEADER_BYTES) throw new Error('This migration file is damaged.');
      const header = JSON.parse((await reader.exact(len)).toString('utf8')) as ArchiveHeader;
      if (!header || typeof header.t !== 'string' || !Number.isSafeInteger(header.size) || header.size < 0) {
        throw new Error('This migration file is damaged.');
      }
      let used = false;
      const entry: ArchiveEntry = {
        header,
        async read() {
          used = true;
          return Buffer.from(await reader.exact(header.size));
        },
        async saveTo(absPath: string) {
          used = true;
          const out = createWriteStream(absPath, { mode: 0o644 });
          for await (const chunk of reader.chunks(header.size)) {
            if (!out.write(chunk)) await once(out, 'drain');
          }
          out.end();
          await once(out, 'close');
        },
      };
      yield entry;
      if (!used) for await (const _ of reader.chunks(header.size)) void _;
      if (header.t === 'end') {
        sawEnd = true;
        break;
      }
    }
    if (!sawEnd) throw new Error('This migration file is incomplete (it was cut off).');
  } finally {
    source.destroy();
    gunzip.destroy();
  }
}

/** The manifest at the start of a file, without reading the rest. */
export async function readArchiveManifest(path: string): Promise<ArchiveManifest> {
  for await (const entry of readArchive(path)) {
    if (entry.header.t !== 'manifest') break;
    const manifest = JSON.parse((await entry.read()).toString('utf8')) as ArchiveManifest;
    if (manifest?.format !== 1 || !manifest.source) break;
    return manifest;
  }
  throw new Error('This is not a Beekiri migration file.');
}

/** Relative paths inside a theme or the media library: no `..`, no hidden parts, no absolute paths. */
export function isSafeRelPath(rel: string): boolean {
  if (!rel || rel.length > 1024 || rel.includes('\\') || rel.includes('\0') || rel.startsWith('/')) return false;
  return rel.split('/').every((part) => part !== '' && part !== '.' && part !== '..' && !part.startsWith('.'));
}
