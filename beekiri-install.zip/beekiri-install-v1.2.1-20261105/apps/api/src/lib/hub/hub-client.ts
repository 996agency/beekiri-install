import { randomBytes } from 'crypto';
import { readFileSync } from 'fs';
import { join } from 'path';
import { secretsStable } from '../../config/env';
import { User } from '../../models';
import { findPrimarySite, saveSiteOptions } from '../../services/site-context';
import { createLogger } from '../../utils/logger';
import { decryptSecret, encryptSecret } from '../shop/secrets';
import { beeQueenServiceUrl, DEFAULT_BEEQUEEN_URL, normalizeServiceUrl } from '../site/connector';
import { mergeSiteOptions, readOptions, type HubOptions } from '../site/site-options';
import { readCoreManifest } from '../system/core-manifest';
import { siteAddress, siteEnvironment } from '../site/environment';
import { BUILTIN_THEME_SLUGS, listThemeManifests, resolveThemeDir } from '../themes/theme-registry';

/**
 * The Beekiri Hub (996Agency) sees every install and sells themes. Beekiri is free:
 * the install registers itself once (getting an install token) and checks in daily.
 * Nothing here ever blocks the site — when the Hub is unreachable, only the theme store waits.
 */

const log = createLogger('hub');
const DAY_MS = 24 * 60 * 60 * 1000;

export class HubError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
  }
}

/** BEEKIRI_HUB_URL wins; otherwise the same 996Agency service BeeQueen uses. */
export async function hubUrl(): Promise<string> {
  const fromEnv = normalizeServiceUrl(process.env.BEEKIRI_HUB_URL ?? '');
  if (fromEnv) return fromEnv;
  const site = await findPrimarySite();
  const opts = readOptions(site?.settings?.options);
  return opts.connector ? beeQueenServiceUrl(opts.connector) : DEFAULT_BEEQUEEN_URL;
}

/** What the Hub shows for this install (and checks theme licences against: owner e-mail + environment). */
async function details(requestOrigin?: string | null): Promise<Record<string, unknown>> {
  const site = await findPrimarySite();
  const owner = await User.findOne({ where: { isOwner: true }, attributes: ['email'], order: [['createdAt', 'ASC']] });
  return {
    siteUrl: siteAddress(requestOrigin),
    siteName: site?.title?.trim() || null,
    ownerEmail: owner?.email ?? null,
    environment: siteEnvironment(requestOrigin).value,
    version: readCoreManifest().coreVersion,
    meta: { node: process.version, platform: process.platform, themesInstalled: listThemeManifests().length },
  };
}

async function hubFetch(url: string, init: RequestInit & { timeoutMs?: number } = {}): Promise<Response> {
  try {
    return await fetch(url, {
      ...init,
      headers: { Accept: 'application/json', ...(init.body ? { 'Content-Type': 'application/json' } : {}), ...init.headers },
      signal: AbortSignal.timeout(init.timeoutMs ?? 15_000),
    });
  } catch {
    throw new HubError('Could not reach the Beekiri Hub. Check your internet connection and try again.', 503);
  }
}

async function messageOf(res: Response, fallback: string): Promise<string> {
  const data = (await res.json().catch(() => ({}))) as { message?: string };
  return typeof data.message === 'string' && data.message ? data.message : fallback;
}

/** Registers this install with the Hub at `url` and stores the token (encrypted). */
async function register(url: string): Promise<{ url: string; token: string }> {
  const site = await findPrimarySite();
  if (!site) throw new HubError('Finish setting up the site first.', 409);
  const installId = randomBytes(18).toString('base64url');
  const res = await hubFetch(`${url}/api/beekiri/v1/installs`, {
    method: 'POST',
    body: JSON.stringify({ installId, ...(await details()) }),
  });
  if (!res.ok) throw new HubError(await messageOf(res, 'The Beekiri Hub did not accept the registration.'), res.status);
  const data = (await res.json()) as { token?: string };
  if (!data.token) throw new HubError('The Beekiri Hub sent no install token.', 502);

  // Encrypt only with a stable CACHE_FLUSH_SECRET: a per-process key would make the token unreadable
  // after a restart and register the site again. The token only unlocks this site's own themes.
  const token = secretsStable ? encryptSecret(data.token) : data.token;
  const hub: HubOptions = { url, installId, token, registeredAt: new Date().toISOString() };
  const fresh = await findPrimarySite();
  await saveSiteOptions(site.id, mergeSiteOptions(fresh?.settings?.options, { hub }));
  log.info(`Registered with the Beekiri Hub at ${url}.`);
  return { url, token: data.token };
}

let registering: Promise<{ url: string; token: string }> | null = null;

/** This install's Hub address and token, registering first when needed (one at a time). */
async function connection(force = false): Promise<{ url: string; token: string }> {
  const url = await hubUrl();
  if (!force) {
    const site = await findPrimarySite();
    const hub = readOptions(site?.settings?.options).hub;
    const token = hub && hub.url === url ? decryptSecret(hub.token) : '';
    if (token) return { url, token };
  }
  registering ??= register(url).finally(() => {
    registering = null;
  });
  return registering;
}

/** A call to the Hub as this install. An unknown token (Hub data reset) registers again once. */
export async function hubRequest(path: string, init: RequestInit & { timeoutMs?: number } = {}): Promise<Response> {
  let conn = await connection();
  const send = () =>
    hubFetch(`${conn.url}/api/beekiri/v1${path}`, {
      ...init,
      headers: { ...init.headers, Authorization: `Bearer ${conn.token}` },
    });
  let res = await send();
  if (res.status === 401) {
    conn = await connection(true);
    res = await send();
  }
  return res;
}

/** JSON helper: throws HubError with the Hub's message on failure. */
export async function hubJson<T>(path: string, init: RequestInit & { timeoutMs?: number } = {}): Promise<T> {
  const res = await hubRequest(path, init);
  if (!res.ok) throw new HubError(await messageOf(res, 'The Beekiri Hub could not complete that.'), res.status);
  return (await res.json()) as T;
}

export async function heartbeat(): Promise<void> {
  await hubJson('/installs/heartbeat', { method: 'POST', body: JSON.stringify(await details()) });
}

export type ThemeLicence = {
  /** False for themes the Hub does not sell (built-in, free or your own). */
  required: boolean;
  licensed: boolean;
  message?: string;
  code?: string;
  /** Answer from the last successful check, used because the Hub could not be reached. */
  offline?: boolean;
};

/** Store themes say so in theme.json (`"licence": "beekiri-hub"`), so they are recognised offline too. */
export function isStoreThemeFolder(dir: string | null): boolean {
  if (!dir) return false;
  try {
    const meta = JSON.parse(readFileSync(join(dir, 'theme.json'), 'utf8')) as { licence?: unknown };
    return meta.licence === 'beekiri-hub';
  } catch {
    return false;
  }
}

async function cacheLicence(slug: string, value: { required: boolean; licensed: boolean }) {
  const site = await findPrimarySite();
  if (!site) return;
  const hub = readOptions(site.settings?.options).hub;
  if (!hub) return;
  const licences = { ...(hub.licences ?? {}), [slug]: { ...value, checkedAt: new Date().toISOString() } };
  await saveSiteOptions(site.id, mergeSiteOptions(site.settings?.options, { hub: { ...hub, licences } }));
}

/**
 * Asks the Hub whether this site may use a store theme, taking a licence slot for it when one is
 * free (one local, one staging and one production site per licence, same owner e-mail).
 * `themeDir`: the theme's folder (installed or arriving), to recognise store themes offline.
 */
export async function checkThemeLicence(
  slug: string,
  opts: { requestOrigin?: string | null; themeDir?: string | null; activate?: boolean } = {},
): Promise<ThemeLicence> {
  if (BUILTIN_THEME_SLUGS.has(slug)) return { required: false, licensed: true };
  try {
    const res = await hubRequest(`/themes/${encodeURIComponent(slug)}/licence`, {
      method: 'POST',
      body: JSON.stringify({ ...(await details(opts.requestOrigin)), activate: opts.activate !== false }),
    });
    const data = (await res.json().catch(() => ({}))) as Partial<ThemeLicence>;
    if (res.ok || res.status === 402 || res.status === 403) {
      const answer: ThemeLicence = {
        required: data.required !== false,
        licensed: res.ok && data.licensed !== false,
        message: typeof data.message === 'string' ? data.message : undefined,
        code: typeof data.code === 'string' ? data.code : undefined,
      };
      await cacheLicence(slug, { required: answer.required, licensed: answer.licensed }).catch(() => undefined);
      return answer;
    }
    throw new HubError(typeof data.message === 'string' ? data.message : 'The Beekiri Hub could not check the licence.', res.status);
  } catch (error) {
    // Hub unreachable: fall back to the last answer, then to what the theme says about itself.
    const site = await findPrimarySite().catch(() => null);
    const cached = readOptions(site?.settings?.options).hub?.licences?.[slug];
    if (cached) return { required: cached.required, licensed: cached.licensed, offline: true };
    const dir = opts.themeDir === undefined ? resolveThemeDir(slug) : opts.themeDir;
    if (!isStoreThemeFolder(dir)) return { required: false, licensed: true, offline: true };
    log.warn(`Theme licence check for ${slug} failed: ${(error as Error).message}`);
    return {
      required: true,
      licensed: false,
      offline: true,
      message: `Could not reach the Beekiri Hub to check the licence of this theme. Try again when the site is online.`,
    };
  }
}

/** Check in shortly after start, then once a day (BEEKIRI_HUB_DISABLED=1 turns it off). Failures are logged and retried tomorrow. */
export function startHubCheckins(): void {
  if (/^(1|true|yes)$/i.test(process.env.BEEKIRI_HUB_DISABLED ?? '')) return;
  const beat = () =>
    heartbeat()
      .then(checkActiveThemeLicence)
      .catch((error: unknown) => log.warn(`Beekiri Hub check-in skipped: ${(error as Error).message}`));
  setTimeout(beat, 15_000).unref();
  setInterval(beat, DAY_MS).unref();
}

/** Daily: the active theme's licence (takes its slot if free; the answer shows in Appearance). */
async function checkActiveThemeLicence(): Promise<void> {
  const site = await findPrimarySite();
  const active = readOptions(site?.settings?.options).activeTheme?.trim();
  if (!active || BUILTIN_THEME_SLUGS.has(active)) return;
  const answer = await checkThemeLicence(active);
  if (answer.required && !answer.licensed) log.warn(`Theme licence: ${answer.message ?? `${active} is not licensed for this site.`}`);
}
