import { z } from 'zod';
import { opt } from './common';

export const ROLES = [
  'administrator',
  'editor',
  'author',
  'contributor',
  'subscriber',
  'shop_manager',
] as const;

const USERNAME = z
  .string()
  .min(3)
  .max(60)
  .regex(/^[a-zA-Z0-9._-]+$/, 'Username may only contain letters, numbers, ., -, _');

const customField = z
  .object({
    id: opt(z.string().max(40)),
    label: z.string().min(1).max(80),
    value: opt(z.string().max(500)),
  })
  .strict();

export const createUserSchema = z
  .object({
    username: USERNAME,
    email: z.string().email().max(320),
    displayName: opt(z.string().min(1).max(120)),
    password: z.string().min(8).max(128),
    role: z.enum(ROLES),
    jobDescription: opt(z.string().max(2000)),
    customFields: opt(z.array(customField).max(50)),
  })
  .strict();

export const updateUserSchema = z
  .object({
    username: opt(USERNAME),
    email: opt(z.string().email().max(320)),
    displayName: opt(z.string().min(1).max(120)),
    /** Empty string keeps the current password. */
    password: opt(z.union([z.literal(''), z.string().min(8).max(128)])),
    /** Required when changing your own email or password. */
    currentPassword: opt(z.string().min(1).max(1024)),
    role: opt(z.enum(ROLES)),
    jobDescription: opt(z.string().max(2000)),
    customFields: opt(z.array(customField).max(50)),
  })
  .strict();

export const updateUserPermissionsSchema = z
  .object({
    /** Absolute capability set for this user (Owner ignored). */
    capabilities: z.array(z.string().min(1).max(64)).max(64),
  })
  .strict();

export const updateRoleSchema = z
  .object({
    /** Display name shown in the admin (e.g. Contributor → Writer). */
    name: opt(z.string().min(1).max(80)),
    /** Absolute capability set for everyone with this role (plus per-user overrides). */
    capabilities: opt(z.array(z.string().min(1).max(64)).max(64)),
  })
  .strict()
  .refine((v) => v.name !== undefined || v.capabilities !== undefined, {
    message: 'Provide a name and/or capabilities to update.',
  });

export const roleSlugParams = z
  .object({
    slug: z.enum(ROLES),
  })
  .strict();

export type CreateUserInput = z.infer<typeof createUserSchema>;
export type UpdateUserInput = z.infer<typeof updateUserSchema>;
export type UpdateUserPermissionsInput = z.infer<typeof updateUserPermissionsSchema>;
export type UpdateRoleInput = z.infer<typeof updateRoleSchema>;
