import { z } from 'zod';
import { booleanish, jsonObject, opt } from './common';

const STATUS = z.enum(['auto-draft', 'draft', 'publish']);

const editable = {
  title: opt(z.string().max(200)),
  slug: opt(z.string().max(200)),
  /** Visual editor document. */
  beekiricanva: opt(jsonObject),
  /** BeekiriCode page tree document. */
  beekiricode: opt(jsonObject),
  /** @deprecated Alias for beekiricode */
  instatic: opt(jsonObject),
  excerpt: opt(z.string().max(2000)),
  /** Media library id, or empty string to clear. */
  featuredImageId: opt(z.union([z.string().max(128), z.literal('')])),
  /** Per-page SEO settings (see lib/pages/page-seo.ts); null resets to defaults. */
  seo: opt(z.union([jsonObject, z.null()])),
};

export const createPageSchema = z
  .object({
    ...editable,
    status: opt(STATUS),
    content: opt(z.string().max(200_000)),
    /** WordPress-style: create an empty auto-draft immediately. */
    autoDraft: opt(z.boolean()),
  })
  .strict();

export const updatePageSchema = z
  .object({
    ...editable,
    status: opt(STATUS),
    content: opt(z.string().max(200_000)),
  })
  .strict();

export const previewPageSchema = z.object(editable).strict();

export const presenceCursorSchema = z
  .object({
    x: z.number().finite().min(-5000).max(20000),
    y: z.number().finite().min(-5000).max(20000),
    frame: z.string().max(32),
  })
  .strict();

export const presenceSchema = z
  .object({
    clientId: z.string().max(80),
    cursor: presenceCursorSchema.nullable().optional(),
    selectedNodeId: z.string().max(128).nullable().optional(),
  })
  .strict();

export const presenceLeaveQuery = z
  .object({ clientId: z.string().max(80).optional() })
  .passthrough();

export const publicPageQuery = z
  .object({
    preview: z.union([booleanish, z.string().max(10)]).optional(),
    token: z.string().max(200).optional(),
  })
  .passthrough();

export const revisionParams = z
  .object({
    id: z.string().min(1).max(128),
    revisionId: z.string().min(1).max(128),
  })
  .passthrough();

export const setPageTaxonomiesSchema = z
  .object({
    assignments: z
      .array(
        z
          .object({
            taxonomyId: z.string().min(1).max(128),
            termIds: z.array(z.string().min(1).max(128)).max(200),
          })
          .strict(),
      )
      .max(50),
  })
  .strict();

export const createTermSchema = z
  .object({
    name: z.string().min(1).max(120),
    slug: opt(z.string().max(120)),
    parentId: opt(z.string().max(128).nullable()),
  })
  .strict();

export const updateTermSchema = z
  .object({
    name: opt(z.string().min(1).max(120)),
    slug: opt(z.string().max(120)),
    description: opt(z.string().max(2000)),
    parentId: z.string().max(128).nullable().optional(),
    menuOrder: opt(z.number().int().min(0).max(100_000)),
  })
  .strict();

export type CreatePageInput = z.infer<typeof createPageSchema>;
export type UpdatePageInput = z.infer<typeof updatePageSchema>;
export type PreviewPageInput = z.infer<typeof previewPageSchema>;
export type SetPageTaxonomiesInput = z.infer<typeof setPageTaxonomiesSchema>;
export type CreateTermInput = z.infer<typeof createTermSchema>;
