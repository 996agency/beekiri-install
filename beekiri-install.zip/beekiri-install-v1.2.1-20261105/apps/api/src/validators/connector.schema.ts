import { z } from 'zod';
import { CONNECTOR_EFFORTS, CONNECTOR_PROVIDER_IDS } from '../lib/site/connector';
import { opt } from './common';

export const connectorProviderParams = z.object({
  providerId: z.enum(CONNECTOR_PROVIDER_IDS),
});

export const updateConnectorSchema = z
  .object({
    providerId: z.enum(CONNECTOR_PROVIDER_IDS),
    enabled: opt(z.boolean()),
    /** Empty string clears; omit to leave unchanged. */
    apiKey: opt(z.string().max(500)),
    defaultModel: opt(z.string().min(1).max(120)),
    effort: opt(z.enum(CONNECTOR_EFFORTS)),
    /** BeeQueen only: the BeeQueen service address. */
    serviceUrl: opt(z.string().max(300)),
  })
  .strict()
  .refine(
    (v) =>
      v.enabled !== undefined ||
      v.apiKey !== undefined ||
      v.defaultModel !== undefined ||
      v.effort !== undefined ||
      v.serviceUrl !== undefined,
    { message: 'Provide at least one field to update.' },
  );

/** BeeQueen chat turn — continues `chatId`, or starts a new chat without it. */
export const beeQueenAgentSchema = z
  .object({
    prompt: z.string().min(1).max(8000),
    chatId: opt(z.string().min(1).max(64)),
  })
  .strict();

export const beeQueenChatParams = z.object({ chatId: z.string().min(1).max(64) });

export const beeQueenPackRequestSchema = z.object({ pack: z.string().min(1).max(64) }).strict();

export type UpdateConnectorInput = z.infer<typeof updateConnectorSchema>;
export type BeeQueenAgentInput = z.infer<typeof beeQueenAgentSchema>;
