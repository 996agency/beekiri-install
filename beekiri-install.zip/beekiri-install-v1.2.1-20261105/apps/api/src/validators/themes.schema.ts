import { z } from 'zod';

export const themeSlugSchema = z.object({ slug: z.string().min(1).max(80) }).strict();

export const chromeKindParams = z.object({ kind: z.string().max(20) }).passthrough();

export const chromeAssetParams = z
  .object({ kind: z.string().max(20), file: z.string().max(40) })
  .passthrough();

export const themeSlugParams = z.object({ slug: z.string().min(1).max(80) }).passthrough();

/** Theme store slugs (same rule as the Hub). */
export const storeSlugParams = z.object({ slug: z.string().regex(/^[a-z0-9][a-z0-9-]{1,62}$/) }).passthrough();
