import { Router } from 'express';
import { z } from 'zod';
import { shopOrdersController as orders } from '../controllers/shop/orders.controller';
import { shopProductsController as products } from '../controllers/shop/products.controller';
import { shopMetaController as meta } from '../controllers/shop/meta.controller';
import { shopPagesController as pages, shopSettingsController as settings } from '../controllers/shop/settings.controller';
import { storefrontController as storefront } from '../controllers/shop/storefront.controller';
import { accountController as account } from '../controllers/shop/account.controller';
import { requireAnyCapability, requireAuth, requireCapabilities } from '../middleware/authenticate';
import {
  shopCartRateLimit,
  shopCheckoutRateLimit,
  shopViewRateLimit,
  shopWebhookRateLimit,
} from '../middleware/rate-limit';
import { requireShopActive, requireStorefrontRequest, shopConfigWhenInactive } from '../middleware/shop';
import { validate } from '../middleware/validate';
import { idParam, idParams } from '../validators/common';
import {
  cartAddSchema,
  cartCouponSchema,
  cartUpdateSchema,
  catalogQuery,
  checkoutConfirmSchema,
  checkoutSchema,
  couponSchema,
  createProductSchema,
  customerListQuery,
  orderDetailsSchema,
  orderListQuery,
  orderNoteSchema,
  orderRefundSchema,
  orderStatusSchema,
  productBulkSchema,
  productListQuery,
  productLookupQuery,
  removeQuery,
  reportsQuery,
  shippingQuoteSchema,
  shopSettingsSchema,
  updateCouponSchema,
  updateProductSchema,
  viewQuery,
  accountAddressesSchema,
  accountDetailsSchema,
  accountForgotSchema,
  accountLoginSchema,
  accountPasswordSchema,
  accountRegisterSchema,
  accountResetSchema,
  accountTokenSchema,
  cartShippingSchema,
  orderFulfillmentSchema,
} from '../validators/shop.schema';

const slugParams = z.object({ slug: z.string().min(1).max(200) }).passthrough();
const tokenParams = z.object({ token: z.string().min(1).max(200) }).passthrough();
const resendEmailSchema = z.object({ kind: z.string().max(40) }).strict();

/**
 * Shopping extension API (/api/shop). Admin routes need the shop capabilities;
 * everything 404s while the extension is inactive.
 */
export const shopRoutes = Router();
shopRoutes.get('/public/config', shopConfigWhenInactive);
shopRoutes.use(requireShopActive);

const withId = validate({ params: idParams });
const canManage = [requireAuth, requireCapabilities('manage_shop')];
const canEditProducts = [requireAuth, requireCapabilities('edit_products')];

/* Shared admin metadata (any shop capability) */
shopRoutes.get(
  '/meta',
  requireAuth,
  requireAnyCapability('manage_shop', 'edit_products', 'edit_shop_orders', 'view_shop_reports'),
  meta.shopMeta,
);

/* Settings */
shopRoutes.get('/settings', ...canManage, settings.getSettings);
shopRoutes.put('/settings', ...canManage, validate({ body: shopSettingsSchema }), settings.updateSettings);

/* Shop Editor pages (admin) */
const viewParams = validate({ params: z.object({ view: z.string().regex(/^[a-z-]{2,40}$/) }).passthrough() });
shopRoutes.get('/pages', ...canEditProducts, pages.listShopPages);
shopRoutes.post('/pages/:view/reset', ...canEditProducts, viewParams, pages.resetShopPage);

/* Products (admin) */
shopRoutes.get('/products', ...canEditProducts, validate({ query: productListQuery }), products.listProducts);
shopRoutes.get('/products/lookup', ...canEditProducts, validate({ query: productLookupQuery }), products.lookupProducts);
shopRoutes.post('/products', ...canEditProducts, validate({ body: createProductSchema }), products.createProduct);
shopRoutes.post('/products/bulk', ...canEditProducts, validate({ body: productBulkSchema }), products.bulkProducts);
shopRoutes.get('/products/:id', ...canEditProducts, withId, products.getProduct);
shopRoutes.patch(
  '/products/:id',
  ...canEditProducts,
  validate({ params: idParams, body: updateProductSchema }),
  products.updateProduct,
);
shopRoutes.delete(
  '/products/:id',
  ...canEditProducts,
  validate({ params: idParams, query: removeQuery }),
  products.removeProduct,
);
shopRoutes.post('/products/:id/restore', ...canEditProducts, withId, products.restoreProduct);
shopRoutes.post('/products/:id/duplicate', ...canEditProducts, withId, products.duplicateProduct);

/* Orders, customers, coupons, reports (admin) */
const canOrders = [requireAuth, requireCapabilities('edit_shop_orders')];
const canReports = [requireAuth, requireAnyCapability('view_shop_reports', 'edit_shop_orders', 'manage_shop')];

shopRoutes.get('/overview', ...canReports, validate({ query: reportsQuery }), orders.shopOverview);
shopRoutes.get('/orders', ...canOrders, validate({ query: orderListQuery }), orders.listOrders);
shopRoutes.get('/orders/:id', ...canOrders, withId, orders.getOrder);
shopRoutes.patch('/orders/:id', ...canOrders, validate({ params: idParams, body: orderDetailsSchema }), orders.updateOrder);
shopRoutes.post('/orders/:id/status', ...canOrders, validate({ params: idParams, body: orderStatusSchema }), orders.setOrderStatus);
shopRoutes.post('/orders/:id/notes', ...canOrders, validate({ params: idParams, body: orderNoteSchema }), orders.addOrderNote);
shopRoutes.delete('/orders/:id/notes/:noteId', ...canOrders, validate({ params: idParams.extend({ noteId: idParam }) }), orders.removeOrderNote);
shopRoutes.post('/orders/:id/fulfillment', ...canOrders, validate({ params: idParams, body: orderFulfillmentSchema }), orders.setOrderFulfillment);
shopRoutes.post('/orders/:id/refund', ...canOrders, validate({ params: idParams, body: orderRefundSchema }), orders.refundOrder);
shopRoutes.post('/orders/:id/resend-email', ...canOrders, validate({ params: idParams, body: resendEmailSchema }), orders.resendOrderEmail);
shopRoutes.get('/customers', ...canOrders, validate({ query: customerListQuery }), orders.listCustomers);
shopRoutes.get('/customers/:id', ...canOrders, withId, orders.getCustomer);
shopRoutes.get('/coupons', ...canOrders, orders.listCoupons);
shopRoutes.post('/coupons', ...canOrders, validate({ body: couponSchema }), orders.createCoupon);
shopRoutes.get('/coupons/:id', ...canOrders, withId, orders.getCoupon);
shopRoutes.patch('/coupons/:id', ...canOrders, validate({ params: idParams, body: updateCouponSchema }), orders.updateCoupon);
shopRoutes.delete('/coupons/:id', ...canOrders, withId, orders.removeCoupon);

/* Storefront (public) */
const write = [requireStorefrontRequest];
shopRoutes.get('/public/config', shopViewRateLimit, storefront.shopConfig);
shopRoutes.get('/public/catalog', shopViewRateLimit, validate({ query: catalogQuery }), storefront.catalog);
shopRoutes.get('/public/categories', shopViewRateLimit, storefront.categories);
shopRoutes.get('/public/products/:slug', shopViewRateLimit, validate({ params: slugParams }), storefront.product);
shopRoutes.get('/public/cart', shopViewRateLimit, storefront.getCart);
shopRoutes.post('/public/cart/items', shopCartRateLimit, ...write, validate({ body: cartAddSchema }), storefront.addToCart);
shopRoutes.patch('/public/cart/items', shopCartRateLimit, ...write, validate({ body: cartUpdateSchema }), storefront.updateCartItem);
shopRoutes.post('/public/cart/shipping', shopCartRateLimit, ...write, validate({ body: cartShippingSchema }), storefront.cartShipping);
shopRoutes.post('/public/cart/coupon', shopCartRateLimit, ...write, validate({ body: cartCouponSchema }), storefront.applyCoupon);
shopRoutes.delete('/public/cart/coupon', shopCartRateLimit, ...write, storefront.removeCoupon);
shopRoutes.get('/public/checkout', shopViewRateLimit, storefront.checkoutPage);
shopRoutes.post('/public/checkout/shipping', shopCartRateLimit, ...write, validate({ body: shippingQuoteSchema }), storefront.shippingQuote);
shopRoutes.post('/public/checkout', shopCheckoutRateLimit, ...write, validate({ body: checkoutSchema }), storefront.placeOrder);
shopRoutes.post('/public/checkout/confirm', shopCartRateLimit, ...write, validate({ body: checkoutConfirmSchema }), storefront.confirmPayment);
shopRoutes.get('/public/orders/:token', shopViewRateLimit, validate({ params: tokenParams }), storefront.orderByToken);
shopRoutes.get('/public/view/:view', shopViewRateLimit, validate({ query: viewQuery }), storefront.renderView);
shopRoutes.get('/public/pages/:view', shopViewRateLimit, viewParams, storefront.shopPage);
shopRoutes.get('/public/assets/:file', storefront.shopAsset);

/* Shopper accounts (public; writes need the storefront header + same origin) */
shopRoutes.get('/public/account/me', shopViewRateLimit, account.accountMe);
shopRoutes.post('/public/account/register', shopCheckoutRateLimit, ...write, validate({ body: accountRegisterSchema }), account.accountRegister);
shopRoutes.post('/public/account/login', shopCartRateLimit, ...write, validate({ body: accountLoginSchema }), account.accountLogin);
shopRoutes.post('/public/account/logout', shopCartRateLimit, ...write, account.accountLogout);
shopRoutes.post('/public/account/verify', shopCartRateLimit, ...write, validate({ body: accountTokenSchema }), account.accountVerify);
shopRoutes.post('/public/account/verify/resend', shopCartRateLimit, ...write, account.accountResendVerify);
shopRoutes.post('/public/account/forgot', shopCheckoutRateLimit, ...write, validate({ body: accountForgotSchema }), account.accountForgot);
shopRoutes.post('/public/account/reset', shopCartRateLimit, ...write, validate({ body: accountResetSchema }), account.accountReset);
shopRoutes.patch('/public/account/details', shopCartRateLimit, ...write, validate({ body: accountDetailsSchema }), account.accountDetails);
shopRoutes.post('/public/account/password', shopCartRateLimit, ...write, validate({ body: accountPasswordSchema }), account.accountPassword);
shopRoutes.put('/public/account/addresses', shopCartRateLimit, ...write, validate({ body: accountAddressesSchema }), account.accountAddresses);
shopRoutes.get('/public/account/orders', shopViewRateLimit, account.accountOrders);
shopRoutes.get('/public/account/orders/:number', shopViewRateLimit, validate({ params: z.object({ number: z.coerce.number().int().min(1) }).passthrough() }), account.accountOrder);

/* Payment webhooks (signature-verified; no session, no origin check) */
shopRoutes.post('/webhooks/stripe', shopWebhookRateLimit, storefront.stripeWebhook);
