import { Router } from 'express';
import { formsController as c } from '../controllers/forms.controller';
import { requireAnyCapability, requireAuth, requireCapabilities } from '../middleware/authenticate';
import { fixUploadNames, formsConfig, parseSubmission, requireFormRequest, requireFormsActive } from '../middleware/forms';
import { formsSubmitRateLimit, formsViewRateLimit } from '../middleware/rate-limit';
import { validate } from '../middleware/validate';
import { idParams } from '../validators/common';
import {
  entryExportQuery,
  entryFileParams,
  entryIdsSchema,
  entryListQuery,
  entryStatusSchema,
  formBodySchema,
  formListQuery,
  hubspotConnectSchema,
  providerParams,
  publicIdParams,
} from '../validators/forms.schema';

/**
 * Bee Forms API (/api/forms). Admin routes need the forms capabilities; the public ones serve
 * and accept forms on the website. Everything 404s while the extension is inactive.
 */
export const formsRoutes = Router();
formsRoutes.get('/public/config', formsConfig);
formsRoutes.get('/public/assets/form.css', c.publicCss);
formsRoutes.use(requireFormsActive);

const withId = validate({ params: idParams });
const canManage = [requireAuth, requireCapabilities('manage_forms')];
const canViewEntries = [requireAuth, requireCapabilities('view_form_entries')];
/** Any editor may pick a form for a page or a Backend Field. */
const canPick = [requireAuth, requireAnyCapability('manage_forms', 'view_form_entries', 'edit_pages', 'edit_posts', 'manage_fields')];

/* Public (website) */
formsRoutes.get('/public/:id/html', formsViewRateLimit, validate({ params: publicIdParams }), c.publicHtml);
formsRoutes.get('/public/:id/token', formsViewRateLimit, validate({ params: publicIdParams }), c.publicToken);
formsRoutes.post(
  '/public/:id/submit',
  formsSubmitRateLimit,
  requireFormRequest,
  validate({ params: publicIdParams }),
  parseSubmission,
  fixUploadNames,
  c.submit,
);

/* Admin: CRM integrations (connecting an account needs manage_options; forms pick the mapping) */
const canConnect = [requireAuth, requireCapabilities('manage_options')];
formsRoutes.get('/integrations', ...canManage, c.integrations);
formsRoutes.post('/integrations/hubspot/connect', ...canConnect, validate({ body: hubspotConnectSchema }), c.connectHubspot);
formsRoutes.post('/integrations/hubspot/test', ...canConnect, c.testHubspot);
formsRoutes.post('/integrations/hubspot/retry-failed', ...canConnect, c.retryFailedHubspot);
formsRoutes.delete('/integrations/:provider', ...canConnect, validate({ params: providerParams }), c.disconnectIntegration);
formsRoutes.get('/integrations/hubspot/properties', ...canManage, c.hubspotProperties);

/* Admin: forms */
formsRoutes.get('/lookup', ...canPick, c.lookup);
formsRoutes.get('/', ...canManage, validate({ query: formListQuery }), c.list);
formsRoutes.post('/', ...canManage, validate({ body: formBodySchema }), c.create);
formsRoutes.get('/:id', ...canManage, withId, c.get);
formsRoutes.patch('/:id', ...canManage, withId, validate({ body: formBodySchema }), c.update);
formsRoutes.post('/:id/duplicate', ...canManage, withId, c.duplicate);
formsRoutes.delete('/:id', ...canManage, withId, c.remove);
formsRoutes.get('/:id/preview', ...canPick, withId, c.preview);
formsRoutes.get('/:id/entries/export', ...canViewEntries, withId, validate({ query: entryExportQuery }), c.exportEntries);

/* Admin: entries */
formsRoutes.get('/entries/list', ...canViewEntries, validate({ query: entryListQuery }), c.listEntries);
formsRoutes.post('/entries/status', ...canViewEntries, validate({ body: entryStatusSchema }), c.setEntryStatus);
formsRoutes.post('/entries/delete', ...canViewEntries, validate({ body: entryIdsSchema }), c.deleteEntries);
formsRoutes.get('/entries/:id', ...canViewEntries, withId, c.getEntry);
formsRoutes.post('/entries/:id/sync/hubspot', ...canViewEntries, withId, c.syncEntryHubspot);
formsRoutes.get('/entries/:id/files/:fileId', ...canViewEntries, validate({ params: entryFileParams }), c.entryFile);
