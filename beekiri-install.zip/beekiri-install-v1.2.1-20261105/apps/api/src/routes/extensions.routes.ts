import { Router } from 'express';
import { extensionsController as c } from '../controllers/extensions.controller';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import { validate } from '../middleware/validate';
import { z } from 'zod';
import { extensionActionSchema } from '../validators/forms.schema';

/** Beekiri extensions: what is installed, what Beekiri publishes, and install/activate actions. */
export const extensionsRoutes = Router();

const admin = [requireAuth, requireCapabilities('manage_options')];
const slugParams = validate({ params: z.object({ slug: z.string().regex(/^[a-z][a-z0-9-]{0,40}$/) }).passthrough() });

extensionsRoutes.get('/', ...admin, c.list);
extensionsRoutes.get('/active', requireAuth, c.active);
extensionsRoutes.post('/:slug/install', ...admin, slugParams, c.install);
extensionsRoutes.post('/:slug/activate', ...admin, slugParams, c.activate);
extensionsRoutes.post('/:slug/deactivate', ...admin, slugParams, c.deactivate);
extensionsRoutes.post(
  '/:slug/uninstall',
  ...admin,
  slugParams,
  validate({ body: extensionActionSchema }),
  c.uninstall,
);
