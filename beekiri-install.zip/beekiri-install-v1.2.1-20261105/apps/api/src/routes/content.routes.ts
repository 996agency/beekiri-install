import { Router, type NextFunction, type Request, type Response } from 'express';
import {
  createContentController,
  createParamContentController,
} from '../controllers/pages.controller';
import {
  contentKindConfig,
  isBuiltinContentKind,
  RESERVED_CONTENT_SLUGS,
  type ContentKind,
} from '../lib/pages/content-kind';
import { SHOP_EXTENSION_SLUG, SHOP_PAGE_KIND } from '../lib/shop/constants';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import { extensionsService } from '../services/extensions.service';
import { PostType } from '../models';
import { findPrimarySite } from '../services/site-context';
import { NotFound } from '../utils/http-error';
import { validate } from '../middleware/validate';
import { idParams } from '../validators/common';
import {
  createPageSchema,
  presenceLeaveQuery,
  presenceSchema,
  previewPageSchema,
  publicPageQuery,
  revisionParams,
  setPageTaxonomiesSchema,
  updatePageSchema,
} from '../validators/pages.schema';

/** /pages and /posts share one router shape; capabilities follow the content kind. */
function contentRoutes(kind: ContentKind) {
  const c = createContentController(kind);
  const edit = kind === 'page' ? 'edit_pages' : 'edit_posts';
  const del = kind === 'page' ? 'delete_pages' : 'delete_posts';
  const router = Router();
  const canEdit = [requireAuth, requireCapabilities(edit)];
  const withId = validate({ params: idParams });

  // Public (front-end) routes first so ":id" never shadows them.
  if (kind === 'page')
    router.get('/public/front', validate({ query: publicPageQuery }), c.publicFront);
  // Published titles + paths only (sitemap, archives).
  router.get('/public', c.publicList);
  router.get('/public/:slug', validate({ query: publicPageQuery }), c.publicBySlug);

  router.get('/', ...canEdit, c.list);
  router.get('/:id/revisions', ...canEdit, withId, c.listRevisions);
  router.post(
    '/:id/revisions/:revisionId/restore',
    ...canEdit,
    validate({ params: revisionParams }),
    c.restoreRevision,
  );
  router.post(
    '/:id/preview',
    ...canEdit,
    validate({ params: idParams, body: previewPageSchema }),
    c.preview,
  );
  router.get('/:id/presence', ...canEdit, withId, c.getPresence);
  router.post(
    '/:id/presence',
    ...canEdit,
    validate({ params: idParams, body: presenceSchema }),
    c.postPresence,
  );
  router.delete(
    '/:id/presence',
    ...canEdit,
    validate({ params: idParams, query: presenceLeaveQuery }),
    c.deletePresence,
  );
  router.get('/:id/taxonomies', ...canEdit, withId, c.getTaxonomies);
  router.put(
    '/:id/taxonomies',
    ...canEdit,
    validate({ params: idParams, body: setPageTaxonomiesSchema }),
    c.setTaxonomies,
  );
  router.get('/:id', ...canEdit, withId, c.get);
  router.post('/', ...canEdit, validate({ body: createPageSchema }), c.create);
  router.patch(
    '/:id',
    ...canEdit,
    validate({ params: idParams, body: updatePageSchema }),
    c.update,
  );
  router.post(
    '/:id/restore',
    requireAuth,
    requireCapabilities(del),
    withId,
    c.restore,
  );
  router.delete('/:id', requireAuth, requireCapabilities(del), withId, c.remove);
  return router;
}

function paramType(req: Request): string {
  return String((req.params as { type?: string }).type || '')
    .trim()
    .toLowerCase();
}

/** The capability for this kind (shop pages use the shop caps, other CPTs the post caps). */
function requireKindCapability(which: 'edit' | 'delete') {
  return (req: Request, res: Response, next: NextFunction) => {
    const cfg = contentKindConfig(paramType(req));
    requireCapabilities(which === 'edit' ? cfg.editCap : cfg.deleteCap)(req, res, next);
  };
}

async function requireActiveCpt(req: Request, _res: Response, next: NextFunction) {
  try {
    const type = paramType(req);
    // Shop pages (Shop → Shop Editor) exist while Shopping is active; they have no public list.
    if (type === SHOP_PAGE_KIND) {
      const wantsPublic = req.path === '/public' || req.path.startsWith('/public/');
      if (wantsPublic || !(await extensionsService.isActive(SHOP_EXTENSION_SLUG))) {
        throw NotFound('Post type not found.');
      }
      next();
      return;
    }
    if (!type || isBuiltinContentKind(type) || RESERVED_CONTENT_SLUGS.has(type)) {
      throw NotFound('Post type not found.');
    }
    const site = await findPrimarySite();
    if (!site) throw NotFound('Post type not found.');
    // The public reads (/public, /public/:slug) additionally need the type to be public.
    const wantsPublic = req.path === '/public' || req.path.startsWith('/public/');
    const row = await PostType.findOne({
      where: { siteId: site.id, slug: type, active: true, ...(wantsPublic ? { public: true } : {}) },
    });
    if (!row) throw NotFound('Post type not found.');
    next();
  } catch (error) {
    next(error);
  }
}

/** Custom post types: /api/content/:type — same editor API as posts. */
function cptContentRoutes() {
  const c = createParamContentController();
  const router = Router({ mergeParams: true });
  const canEdit = [requireAuth, requireKindCapability('edit')];
  const withId = validate({ params: idParams });

  router.get('/meta', async (req, res, next) => {
    try {
      const type = paramType(req);
      if (!type || isBuiltinContentKind(type) || RESERVED_CONTENT_SLUGS.has(type)) {
        throw NotFound('Post type not found.');
      }
      const site = await findPrimarySite();
      if (!site) throw NotFound('Post type not found.');
      const row = await PostType.findOne({
        where: { siteId: site.id, slug: type, active: true, public: true },
      });
      if (!row) throw NotFound('Post type not found.');
      res.json({
        slug: row.slug,
        singular: row.singular,
        plural: row.plural,
        hasArchive: row.hasArchive,
        archiveDesign: row.archiveDesign || 'list',
        singleDesign: row.singleDesign || 'default',
      });
    } catch (error) {
      next(error);
    }
  });

  router.use(requireActiveCpt);

  router.get('/public', c.publicList);
  router.get('/public/:slug', validate({ query: publicPageQuery }), c.publicBySlug);

  router.get('/', ...canEdit, c.list);
  router.get('/:id/revisions', ...canEdit, withId, c.listRevisions);
  router.post(
    '/:id/revisions/:revisionId/restore',
    ...canEdit,
    validate({ params: revisionParams }),
    c.restoreRevision,
  );
  router.post(
    '/:id/preview',
    ...canEdit,
    validate({ params: idParams, body: previewPageSchema }),
    c.preview,
  );
  router.get('/:id/presence', ...canEdit, withId, c.getPresence);
  router.post(
    '/:id/presence',
    ...canEdit,
    validate({ params: idParams, body: presenceSchema }),
    c.postPresence,
  );
  router.delete(
    '/:id/presence',
    ...canEdit,
    validate({ params: idParams, query: presenceLeaveQuery }),
    c.deletePresence,
  );
  router.get('/:id/taxonomies', ...canEdit, withId, c.getTaxonomies);
  router.put(
    '/:id/taxonomies',
    ...canEdit,
    validate({ params: idParams, body: setPageTaxonomiesSchema }),
    c.setTaxonomies,
  );
  router.get('/:id', ...canEdit, withId, c.get);
  router.post('/', ...canEdit, validate({ body: createPageSchema }), c.create);
  router.patch(
    '/:id',
    ...canEdit,
    validate({ params: idParams, body: updatePageSchema }),
    c.update,
  );
  router.post('/:id/restore', requireAuth, requireKindCapability('delete'), withId, c.restore);
  router.delete('/:id', requireAuth, requireKindCapability('delete'), withId, c.remove);
  return router;
}

export const pagesRoutes = contentRoutes('page');
export const postsRoutes = contentRoutes('post');
export const contentTypeRoutes = cptContentRoutes();

/** GET /api/content-types/public — active, public custom post types (sitemap, menus). */
export const contentTypesPublicRoutes = Router().get('/', async (_req, res, next) => {
  try {
    const site = await findPrimarySite();
    if (!site) return res.json({ types: [] });
    const rows = await PostType.findAll({
      where: { siteId: site.id, active: true, public: true },
      order: [['menuOrder', 'ASC']],
    });
    res.json({
      types: rows.map((r) => ({ slug: r.slug, plural: r.plural, hasArchive: r.hasArchive })),
    });
  } catch (error) {
    next(error);
  }
});
