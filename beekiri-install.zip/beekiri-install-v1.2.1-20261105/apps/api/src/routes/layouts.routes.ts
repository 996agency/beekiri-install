import { Router } from 'express';
import { layoutsController as c } from '../controllers/layouts.controller';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import { layoutRenderRateLimit } from '../middleware/rate-limit';
import { validate } from '../middleware/validate';
import {
  formatFieldsBody,
  layoutSlugParams,
  renderLayoutBody,
  renderLayoutQuery,
} from '../validators/layouts.schema';

export const layoutsRoutes = Router();

const withSlug = validate({ params: layoutSlugParams });
const admin = [requireAuth, requireCapabilities('manage_options')];

layoutsRoutes.post('/sync', ...admin, c.syncAll);
layoutsRoutes.post('/:slug/compile', ...admin, withSlug, c.compile);

// Public: used by the editor canvas and the public site.
layoutsRoutes.get('/', c.list);
layoutsRoutes.get('/:slug/css', withSlug, c.css);
layoutsRoutes.get('/:slug/js', withSlug, c.js);
layoutsRoutes.get(
  '/:slug/render',
  layoutRenderRateLimit,
  validate({ params: layoutSlugParams, query: renderLayoutQuery }),
  c.renderGet,
);
layoutsRoutes.post(
  '/:slug/render',
  layoutRenderRateLimit,
  validate({ params: layoutSlugParams, body: renderLayoutBody }),
  c.renderPost,
);
layoutsRoutes.post(
  '/:slug/fields',
  layoutRenderRateLimit,
  validate({ params: layoutSlugParams, body: formatFieldsBody }),
  c.formatFields,
);
