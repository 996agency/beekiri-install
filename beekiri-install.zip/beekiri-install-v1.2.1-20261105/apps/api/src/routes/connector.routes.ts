import { Router } from 'express';
import { connectorController as c } from '../controllers/connector.controller';
import { handleMcp } from '../lib/beequeen/mcp';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import { validate } from '../middleware/validate';
import {
  beeQueenAgentSchema,
  beeQueenChatParams,
  beeQueenPackRequestSchema,
  connectorProviderParams,
  updateConnectorSchema,
} from '../validators/connector.schema';

export const connectorRoutes = Router();

const admin = [requireAuth, requireCapabilities('manage_options')];
/** Clients chat with BeeQueen on their own credits — they don't need full admin rights. */
const bee = [requireAuth, requireCapabilities('use_beequeen')];

connectorRoutes.get('/', ...admin, c.get);
connectorRoutes.patch('/', ...admin, validate({ body: updateConnectorSchema }), c.update);
/**
 * BeeQueen's tools for Claude Code on this machine (local test engine). Authorized by a
 * per-run bearer token and loopback-only — not by the admin session.
 */
connectorRoutes.all('/mcp', handleMcp);
/** Must be before /:providerId so “agent” is not treated as a provider id. */
connectorRoutes.post('/agent', ...bee, validate({ body: beeQueenAgentSchema }), c.runAgent);
connectorRoutes.get('/beequeen/status', ...bee, c.status);
/** This site's BeeQueen account (credits, packs, history) — the owner's Connector page. */
connectorRoutes.get('/beequeen/account', ...admin, c.beeQueenAccount);
connectorRoutes.post('/beequeen/pack-requests', ...admin, validate({ body: beeQueenPackRequestSchema }), c.requestBeeQueenPack);
/** The signed-in user's BeeQueen chats (each user only ever sees their own). */
connectorRoutes.get('/chats', ...bee, c.listChats);
connectorRoutes.get('/chats/:chatId', ...bee, validate({ params: beeQueenChatParams }), c.getChat);
connectorRoutes.delete('/chats/:chatId', ...bee, validate({ params: beeQueenChatParams }), c.deleteChat);
connectorRoutes.get(
  '/:providerId',
  ...admin,
  validate({ params: connectorProviderParams }),
  c.getProvider,
);
