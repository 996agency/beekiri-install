import { Router } from 'express';
import { analyticsRoutes } from './analytics.routes';
import { authRoutes } from './auth.routes';
import { beeCookiesRoutes } from './bee-cookies.routes';
import { beeSeoRoutes } from './bee-seo.routes';
import { connectorRoutes } from './connector.routes';
import { extensionsRoutes } from './extensions.routes';
import {
  contentTypeRoutes,
  contentTypesPublicRoutes,
  pagesRoutes,
  postsRoutes,
} from './content.routes';
import { fieldsRoutes } from './fields.routes';
import { healthRoutes } from './health.routes';
import { installRoutes } from './install.routes';
import { layoutsRoutes } from './layouts.routes';
import { mediaRoutes } from './media.routes';
import { migrationRoutes } from './migration.routes';
import { formsRoutes } from './forms.routes';
import { shopRoutes } from './shop.routes';
import { siteRoutes } from './site.routes';
import { systemRoutes } from './system.routes';
import { themesRoutes } from './themes.routes';
import { usersRoutes } from './users.routes';

/** Every API module and where it is mounted under `/api` (also drives the OpenAPI document). */
export const apiModules: ReadonlyArray<readonly [path: string, router: Router]> = [
  ['/health', healthRoutes],
  ['/install', installRoutes],
  ['/auth', authRoutes],
  ['/users', usersRoutes],
  ['/media', mediaRoutes],
  ['/pages', pagesRoutes],
  ['/posts', postsRoutes],
  ['/content-types/public', contentTypesPublicRoutes],
  ['/content/:type', contentTypeRoutes],
  ['/fields', fieldsRoutes],
  ['/site', siteRoutes],
  ['/themes', themesRoutes],
  ['/layouts', layoutsRoutes],
  ['/system', systemRoutes],
  ['/migration', migrationRoutes],
  ['/bee-cookies', beeCookiesRoutes],
  ['/analytics', analyticsRoutes],
  ['/bee-seo', beeSeoRoutes],
  ['/connector', connectorRoutes],
  ['/extensions', extensionsRoutes],
  ['/shop', shopRoutes],
  ['/forms', formsRoutes],
];

export const apiRoutes = Router();
for (const [path, router] of apiModules) apiRoutes.use(path, router);
