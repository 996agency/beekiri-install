import { Router } from 'express';
import { installController } from '../controllers/install.controller';
import { requireSetupToken } from '../lib/setup-token';
import { authRateLimit } from '../middleware/rate-limit';
import { validate } from '../middleware/validate';
import { databaseSetupSchema, installSchema } from '../validators/install.schema';

export const installRoutes = Router();

installRoutes.get('/status', installController.status);
installRoutes.post(
  '/database',
  authRateLimit,
  requireSetupToken,
  validate({ body: databaseSetupSchema }),
  installController.database,
);
installRoutes.post(
  '/',
  authRateLimit,
  requireSetupToken,
  validate({ body: installSchema }),
  installController.install,
);
