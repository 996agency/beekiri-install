import { Router } from 'express';
import { themeStoreController as store } from '../controllers/theme-store.controller';
import { themesController as c } from '../controllers/themes.controller';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';
import { singleUpload } from '../middleware/upload';
import { validate } from '../middleware/validate';
import { MAX_UPLOAD_BYTES } from '../services/media.service';
import {
  chromeAssetParams,
  chromeKindParams,
  storeSlugParams,
  themeSlugParams,
  themeSlugSchema,
} from '../validators/themes.schema';

export const themesRoutes = Router();

const canEdit = [requireAuth, requireCapabilities('edit_theme_options')];

// Public (rendered into every page of the site).
themesRoutes.get('/chrome/:kind/render', validate({ params: chromeKindParams }), c.renderChrome);
themesRoutes.get(
  '/chrome/:kind/asset/:file',
  validate({ params: chromeAssetParams }),
  c.chromeAsset,
);
themesRoutes.get('/:slug/screenshot', validate({ params: themeSlugParams }), c.screenshot);

themesRoutes.get('/', ...canEdit, c.list);
// Theme store (Beekiri Hub): browse, buy, install. Slugs are store slugs: lowercase, digits, dashes.
themesRoutes.get('/store', ...canEdit, store.catalog);
themesRoutes.get('/store/:slug/screenshot', ...canEdit, validate({ params: storeSlugParams }), store.screenshot);
themesRoutes.post('/store/:slug/purchase', ...canEdit, validate({ params: storeSlugParams }), store.purchase);
themesRoutes.post('/store/:slug/install', ...canEdit, validate({ params: storeSlugParams }), store.install);
themesRoutes.get(
  '/chrome/:kind/options',
  ...canEdit,
  validate({ params: chromeKindParams }),
  c.listChrome,
);
themesRoutes.post(
  '/chrome/:kind/activate',
  ...canEdit,
  validate({ params: chromeKindParams, body: themeSlugSchema }),
  c.activateChrome,
);
themesRoutes.post('/activate', ...canEdit, validate({ body: themeSlugSchema }), c.activate);
themesRoutes.post('/deactivate', ...canEdit, validate({ body: themeSlugSchema }), c.deactivate);
themesRoutes.post('/upload', ...canEdit, singleUpload(MAX_UPLOAD_BYTES), c.upload);
// Ready-made sections and pages shipped in a theme's content/ folder.
themesRoutes.get('/sections', requireAuth, requireCapabilities('edit_pages'), c.sections);
themesRoutes.get('/:slug/content', ...canEdit, validate({ params: themeSlugParams }), c.contentStatus);
themesRoutes.post('/:slug/content/install', ...canEdit, validate({ params: themeSlugParams }), c.installContent);
themesRoutes.post('/:slug/content/reset', ...canEdit, validate({ params: themeSlugParams }), c.resetContent);
themesRoutes.delete('/:slug', ...canEdit, validate({ params: themeSlugParams }), c.remove);
