import { Router } from 'express';
import {
  SETTINGS_ACCESS_CAPABILITIES,
} from '../lib/auth/role-capabilities';
import { systemController as c } from '../controllers/system.controller';
import {
  requireAuth,
  requireAnyCapability,
  requireCapabilities,
} from '../middleware/authenticate';

export const systemRoutes = Router();

systemRoutes.use(requireAuth);

systemRoutes.get(
  '/version',
  requireAnyCapability('manage_options', 'update_core', ...SETTINGS_ACCESS_CAPABILITIES),
  c.version,
);
systemRoutes.get(
  '/status',
  requireAnyCapability('manage_options', 'update_core', ...SETTINGS_ACCESS_CAPABILITIES),
  c.status,
);
systemRoutes.get('/updates', requireAnyCapability('manage_options', 'update_core'), c.updates);
systemRoutes.post(
  '/updates/apply',
  requireAnyCapability('manage_options', 'update_core'),
  c.applyUpdate,
);
systemRoutes.get(
  '/updates/progress',
  requireAnyCapability('manage_options', 'update_core'),
  c.updateProgress,
);
systemRoutes.get('/lighthouse', requireCapabilities('manage_options'), c.lighthouse);
systemRoutes.post(
  '/cache/flush',
  requireAnyCapability('manage_options', 'manage_settings_cache'),
  c.flushCache,
);
