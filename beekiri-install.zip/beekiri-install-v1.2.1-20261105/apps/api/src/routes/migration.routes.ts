import { Router } from 'express';
import { migrationController as c, verifySiteSignature as signed } from '../controllers/migration.controller';
import { requireAuth, requireCapabilities } from '../middleware/authenticate';

/**
 * Settings → Migration: push or pull theme code, the database and media between Beekiri sites
 * (local → staging → production), export/import files, and backups made before every import.
 */
export const migrationRoutes = Router();

// Requests from another Beekiri site, signed with this site's connection key (no sign-in).
migrationRoutes.post('/remote/hello', signed, c.remote('hello'));
migrationRoutes.post('/remote/media-manifest', signed, c.remote('media-manifest'));
migrationRoutes.post('/remote/uploads', signed, c.remote('uploads'));
migrationRoutes.post('/remote/uploads/:id/chunk', signed, c.remote('chunk'));
migrationRoutes.post('/remote/export', signed, c.remote('export'));
migrationRoutes.post('/remote/import', signed, c.remote('import'));
migrationRoutes.post('/remote/jobs', signed, c.remote('jobs'));
migrationRoutes.post('/remote/jobs/cancel', signed, c.remote('jobs-cancel'));
migrationRoutes.post('/remote/packages/read', signed, c.remote('packages-read'));
migrationRoutes.post('/remote/packages/delete', signed, c.remote('packages-delete'));

// Progress for a browser that was signed out because a pull replaced the users (the id is secret).
migrationRoutes.get('/job-status/:id', c.publicJob);

// Everything else: site administrators only.
migrationRoutes.get('/', requireAuth, requireCapabilities('manage_options'), c.overview);
migrationRoutes.patch('/settings', requireAuth, requireCapabilities('manage_options'), c.settings);
migrationRoutes.post('/settings/key', requireAuth, requireCapabilities('manage_options'), c.regenerateKey);
migrationRoutes.post('/connections', requireAuth, requireCapabilities('manage_options'), c.addConnection);
migrationRoutes.post('/connections/:id/test', requireAuth, requireCapabilities('manage_options'), c.testConnection);
migrationRoutes.patch('/connections/:id', requireAuth, requireCapabilities('manage_options'), c.renameConnection);
migrationRoutes.delete('/connections/:id', requireAuth, requireCapabilities('manage_options'), c.removeConnection);
migrationRoutes.post('/run', requireAuth, requireCapabilities('manage_options'), c.start);
migrationRoutes.post('/export', requireAuth, requireCapabilities('manage_options'), c.exportFile);
migrationRoutes.get('/downloads/:id', requireAuth, requireCapabilities('manage_options'), c.download);
migrationRoutes.post('/uploads', requireAuth, requireCapabilities('manage_options'), c.createUpload);
migrationRoutes.post('/uploads/:id/chunk', requireAuth, requireCapabilities('manage_options'), c.uploadChunk);
migrationRoutes.get('/uploads/:id', requireAuth, requireCapabilities('manage_options'), c.inspect);
migrationRoutes.post('/import', requireAuth, requireCapabilities('manage_options'), c.importFile);
migrationRoutes.post('/backups/:id/restore', requireAuth, requireCapabilities('manage_options'), c.restore);
migrationRoutes.get('/backups/:id/download', requireAuth, requireCapabilities('manage_options'), c.backupDownload);
migrationRoutes.delete('/backups/:id', requireAuth, requireCapabilities('manage_options'), c.deleteBackup);
migrationRoutes.get('/jobs/:id', requireAuth, requireCapabilities('manage_options'), c.job);
migrationRoutes.post('/jobs/:id/cancel', requireAuth, requireCapabilities('manage_options'), c.cancel);
