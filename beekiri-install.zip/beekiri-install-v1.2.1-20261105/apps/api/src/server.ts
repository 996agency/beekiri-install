import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'http';
import type { AddressInfo } from 'net';
import { createApp } from './app';
import { config, configWarnings } from './config/env';
import { setSelfUrl } from './config/runtime';
import { CORE_BUILD } from './core-build';
import { migrationStatus, runMigrations } from './db/migrator';
import { closeDatabase, connectDatabase } from './db/sequelize';
import { createSiteHost, type SiteHost } from './hosting/site-host';
import { layoutSyncService } from './services/layout-sync.service';
import { createLogger } from './utils/logger';

const log = createLogger('server');
const SHUTDOWN_GRACE_MS = 10_000;

/**
 * Listen on PORT, or (first run, before the setup wizard saved one) any free port.
 * Without HOST the server listens on every interface of this machine.
 */
function listen(server: Server, port: number): Promise<number> {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.once('listening', () => resolve((server.address() as AddressInfo).port));
    const { host } = config.server;
    if (host) server.listen(port, host);
    else server.listen(port);
  });
}

/**
 * Bring the schema up to date before serving. When nothing is pending this is a single
 * read of the migration table; otherwise the migrator runs under its advisory lock, so
 * several instances starting together still migrate exactly once.
 */
async function migrateOnStart(): Promise<void> {
  const { pending } = await migrationStatus();
  if (!pending.length) {
    log.info('Database schema is up to date.');
    return;
  }

  log.info(`Applying ${pending.length} pending database migration(s)…`);
  const { adopted, applied } = await runMigrations();
  if (adopted.length)
    log.info(`Recorded ${adopted.length} migration(s) already applied by Prisma.`);
  for (const name of applied) log.info(`Applied migration ${name}`);
}

function handleShutdown(server: Server, site: SiteHost): void {
  let closing = false;
  const shutdown = (signal: string) => {
    if (closing) return;
    closing = true;
    log.info(`${signal} received, shutting down`);
    setTimeout(() => process.exit(1), SHUTDOWN_GRACE_MS).unref();
    server.close(() => {
      Promise.allSettled([site.close(), closeDatabase()]).finally(() => process.exit(0));
    });
    server.closeIdleConnections();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

/** Answers while the website and admin are still loading. */
function starting(_req: IncomingMessage, res: ServerResponse): void {
  res.writeHead(503, { 'Content-Type': 'text/plain; charset=utf-8', 'Retry-After': '3' });
  res.end('Beekiri is starting. Refresh in a few seconds.');
}

async function bootstrap(): Promise<void> {
  for (const warning of configWarnings) log.warn(warning);

  const setupMode = !config.databaseConfigured;
  if (!setupMode) {
    await connectDatabase();
    await migrateOnStart();
    const { seedRolesAndCapabilities } = await import('./services/install.service');
    const { refreshRoleCapabilityCache } = await import('./lib/auth/role-cache');
    await seedRolesAndCapabilities();
    await refreshRoleCapabilityCache();
    await layoutSyncService.bootstrap();
    // Shopping: unpaid card orders release their stock after the hold time.
    const { ordersService } = await import('./services/shop/orders.service');
    const sweep = setInterval(() => void ordersService.sweepExpired(), 10 * 60_000);
    sweep.unref();
    // Bee Forms: CRM syncs that failed for a temporary reason retry on schedule (also after a restart).
    const { integrationsService } = await import('./services/forms/integrations.service');
    void integrationsService.sweep();
    const formsSweep = setInterval(() => void integrationsService.sweep(), 60_000);
    formsSweep.unref();
    // Beekiri Hub: register this install and check in daily (theme store, install list).
    const { startHubCheckins } = await import('./lib/hub/hub-client');
    startHubCheckins();
  }

  let handler: (req: IncomingMessage, res: ServerResponse) => void = starting;
  const server = createServer((req, res) => handler(req, res));
  let port: number;
  try {
    port = await listen(server, config.server.port ?? 0);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'EADDRINUSE') {
      const busy = config.server.port;
      console.error(
        `\nBeekiri: port ${busy} is already used by another process (often an older Beekiri still running).\n` +
          `Close that window or run: npx kill-port ${busy}  then start Beekiri again.\n`,
      );
      process.exit(1);
    }
    throw error;
  }
  server.keepAliveTimeout = 65_000;
  server.headersTimeout = 66_000;
  server.requestTimeout = 5 * 60_000;

  const selfUrl = `http://localhost:${port}`;
  setSelfUrl(selfUrl);
  const site = await createSiteHost({
    dev: config.nodeEnv === 'development',
    server,
    selfUrl,
    website: !setupMode,
  });
  handler = createApp({ mountSite: site.mount });
  if (!setupMode) {
    const { attachPresenceWebSocket } = await import('./lib/pages/pages.presence-ws');
    attachPresenceWebSocket(server);
    // Themes own their pages: only the active theme's pages may be live. Runs once the website
    // is mounted, so the cache flush for any page it hides reaches it.
    const { themesService } = await import('./services/themes.service');
    const { themeSwitchService } = await import('./services/theme-switch.service');
    const activeTheme = await themesService.getActiveSlug().catch(() => '');
    if (activeTheme) await themeSwitchService.reconcile(activeTheme);
    // Heatmaps: re-screenshot clicked pages once a day (first check a few minutes after start).
    const { heatmapSnapshotService } = await import('./services/heatmap-snapshot.service');
    heatmapSnapshotService.startDaily();
  }
  handleShutdown(server, site);

  const address = config.urls.app ?? selfUrl;
  const { clearSetupToken, ensureSetupToken, isSiteInstalled } = await import('./lib/setup-token');
  if (setupMode || !(await isSiteInstalled())) {
    // Only someone who can see this terminal (or the key file) can finish the setup.
    const key = ensureSetupToken();
    const base = setupMode ? selfUrl : address;
    console.log(
      `\nBeekiri is ready to set up. Open this link (it carries your one-time setup key):\n` +
        `  ${base}/admin/install?setup=${key}\n` +
        `The key is also saved in apps/api/.setup-token and stops working once the site is created.\n`,
    );
  } else {
    clearSetupToken();
    console.log(
      `\nBeekiri is running (build ${CORE_BUILD})\n  Website  ${address}\n  Admin    your admin address (Settings → General)\n`,
    );
  }
}

process.on('unhandledRejection', (reason) => {
  log.error('Unhandled promise rejection', reason);
});

bootstrap().catch((error: unknown) => {
  log.error('Beekiri failed to start', error);
  process.exit(1);
});
