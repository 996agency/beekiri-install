import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, int, jsonb, optionalDate, optionalText, text, type Json } from './_shared';
import type { Site } from './site.model';

/** Field groups (Backend Fields). */
export class FieldGroup extends Model<
  InferAttributes<FieldGroup>,
  InferCreationAttributes<FieldGroup>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare title: string;
  /** Unique machine key within the site, e.g. group_hero */
  declare key: string;
  declare description: CreationOptional<string>;
  declare active: CreationOptional<boolean>;
  declare location: CreationOptional<Json>;
  declare fields: CreationOptional<Json>;
  declare menuOrder: CreationOptional<number>;
  /** Soft-delete; null = live. */
  declare trashedAt: CreationOptional<Date | null>;
  /** Client theme this group (and its layout) belongs to; Backend Fields shows the active theme's. */
  declare theme: CreationOptional<string | null>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    FieldGroup.init(
      {
        id: idColumn(),
        siteId: text(),
        title: text(),
        key: text(),
        description: text({ defaultValue: '' }),
        active: bool(true),
        location: jsonb([]),
        fields: jsonb([]),
        menuOrder: int(0),
        trashedAt: optionalDate(),
        theme: optionalText(),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'FieldGroup',
        modelName: 'FieldGroup',
        timestamps: true,
        indexes: [
          { name: 'FieldGroup_siteId_key_key', unique: true, fields: ['siteId', 'key'] },
          { name: 'FieldGroup_siteId_idx', fields: ['siteId'] },
          { name: 'FieldGroup_menuOrder_idx', fields: ['menuOrder'] },
          { name: 'FieldGroup_siteId_trashedAt_idx', fields: ['siteId', 'trashedAt'] },
        ],
      },
    );
  }
}
