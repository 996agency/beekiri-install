import type { Model, ModelStatic } from 'sequelize';
import { sequelize } from '../db/sequelize';
import { AuditLog } from './audit-log.model';
import { BeeCookieClick } from './bee-cookie-click.model';
import { BeeForm } from './bee-form.model';
import { BeeFormEntry } from './bee-form-entry.model';
import { BeeFormIntegration } from './bee-form-integration.model';
import { BeeQueenChat, BeeQueenMessage } from './beequeen-chat.model';
import { BeeCookieConsent } from './bee-cookie-consent.model';
import { BeeCookieVisit } from './bee-cookie-visit.model';
import { Capability } from './capability.model';
import { FieldGroup } from './field-group.model';
import { InstallationState } from './installation-state.model';
import { MediaAsset } from './media-asset.model';
import { OptionsPage } from './options-page.model';
import { PasswordResetToken } from './password-reset-token.model';
import { PostRevision } from './post-revision.model';
import { PostType } from './post-type.model';
import { Post } from './post.model';
import { RoleCapability } from './role-capability.model';
import { Role } from './role.model';
import { Session } from './session.model';
import { ShopCart } from './shop-cart.model';
import { ShopCustomerSession } from './shop-customer-session.model';
import { ShopCustomerToken } from './shop-customer-token.model';
import { ShopCoupon } from './shop-coupon.model';
import { ShopCustomer } from './shop-customer.model';
import { ShopOrderItem } from './shop-order-item.model';
import { ShopOrderNote } from './shop-order-note.model';
import { ShopOrder } from './shop-order.model';
import { ShopPaymentEvent } from './shop-payment-event.model';
import { ShopProductVariant } from './shop-product-variant.model';
import { ShopProduct } from './shop-product.model';
import { ShopSetting } from './shop-setting.model';
import { SiteSettings } from './site-settings.model';
import { Site } from './site.model';
import { Taxonomy } from './taxonomy.model';
import { TermRelationship } from './term-relationship.model';
import { Term } from './term.model';
import { User } from './user.model';

const models = [
  Site,
  SiteSettings,
  Role,
  Capability,
  RoleCapability,
  User,
  Session,
  PasswordResetToken,
  AuditLog,
  InstallationState,
  MediaAsset,
  FieldGroup,
  PostType,
  Taxonomy,
  Term,
  TermRelationship,
  OptionsPage,
  Post,
  PostRevision,
  BeeCookieConsent,
  BeeCookieVisit,
  BeeCookieClick,
  BeeQueenChat,
  BeeQueenMessage,
  BeeForm,
  BeeFormEntry,
  BeeFormIntegration,
  ShopSetting,
  ShopProduct,
  ShopProductVariant,
  ShopCart,
  ShopCustomer,
  ShopOrder,
  ShopOrderItem,
  ShopOrderNote,
  ShopCoupon,
  ShopPaymentEvent,
  ShopCustomerSession,
  ShopCustomerToken,
];

for (const model of models) model.initModel(sequelize);

const cascade = { onDelete: 'CASCADE', onUpdate: 'CASCADE' } as const;
// Soft references: ids are kept for display but the schema has no FK (user deletes must not cascade).
const soft = { constraints: false } as const;

// Site owns everything; deleting a site cascades.
Site.hasOne(SiteSettings, { foreignKey: 'siteId', as: 'settings', ...cascade });
SiteSettings.belongsTo(Site, { foreignKey: 'siteId', as: 'site' });
Site.hasMany(User, { foreignKey: 'siteId', as: 'users', ...cascade });
User.belongsTo(Site, { foreignKey: 'siteId', as: 'site' });
const siteOwned: [ModelStatic<Model>, string][] = [
  [MediaAsset, 'mediaAssets'],
  [FieldGroup, 'fieldGroups'],
  [PostType, 'postTypes'],
  [Taxonomy, 'taxonomies'],
  [Term, 'terms'],
  [OptionsPage, 'optionsPages'],
  [Post, 'posts'],
  [BeeCookieConsent, 'beeCookieConsents'],
  [BeeCookieVisit, 'beeCookieVisits'],
  [BeeCookieClick, 'beeCookieClicks'],
  [BeeQueenChat, 'beeQueenChats'],
  [BeeForm, 'beeForms'],
  [BeeFormEntry, 'beeFormEntries'],
  [BeeFormIntegration, 'beeFormIntegrations'],
  [ShopSetting, 'shopSettings'],
  [ShopProduct, 'shopProducts'],
  [ShopProductVariant, 'shopProductVariants'],
  [ShopCart, 'shopCarts'],
  [ShopCustomer, 'shopCustomers'],
  [ShopOrder, 'shopOrders'],
  [ShopOrderItem, 'shopOrderItems'],
  [ShopOrderNote, 'shopOrderNotes'],
  [ShopCoupon, 'shopCoupons'],
  [ShopPaymentEvent, 'shopPaymentEvents'],
  [ShopCustomerSession, 'shopCustomerSessions'],
  [ShopCustomerToken, 'shopCustomerTokens'],
];
for (const [model, as] of siteOwned) {
  Site.hasMany(model, { foreignKey: 'siteId', as, ...cascade });
  model.belongsTo(Site, { foreignKey: 'siteId', as: 'site' });
}
Site.hasMany(AuditLog, {
  foreignKey: 'siteId',
  as: 'auditLogs',
  onDelete: 'SET NULL',
  onUpdate: 'CASCADE',
});
AuditLog.belongsTo(Site, { foreignKey: 'siteId', as: 'site' });

// Roles & capabilities (many-to-many through the legacy _CapabilityToRole table).
Role.hasMany(User, {
  foreignKey: 'roleId',
  as: 'users',
  onDelete: 'RESTRICT',
  onUpdate: 'CASCADE',
});
User.belongsTo(Role, { foreignKey: 'roleId', as: 'role' });
Role.belongsToMany(Capability, {
  through: RoleCapability,
  foreignKey: 'B',
  otherKey: 'A',
  as: 'capabilities',
  timestamps: false,
});
Capability.belongsToMany(Role, {
  through: RoleCapability,
  foreignKey: 'A',
  otherKey: 'B',
  as: 'roles',
  timestamps: false,
});

// Auth.
User.hasMany(Session, { foreignKey: 'userId', as: 'sessions', ...cascade });
Session.belongsTo(User, { foreignKey: 'userId', as: 'user' });
User.hasMany(PasswordResetToken, { foreignKey: 'userId', as: 'resetTokens', ...cascade });
PasswordResetToken.belongsTo(User, { foreignKey: 'userId', as: 'user' });
User.hasMany(AuditLog, {
  foreignKey: 'userId',
  as: 'auditLogs',
  onDelete: 'SET NULL',
  onUpdate: 'CASCADE',
});
AuditLog.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// BeeQueen chats belong to their user; deleting the user deletes the chats.
User.hasMany(BeeQueenChat, { foreignKey: 'userId', as: 'beeQueenChats', ...cascade });
BeeQueenChat.belongsTo(User, { foreignKey: 'userId', as: 'user' });
BeeQueenChat.hasMany(BeeQueenMessage, { foreignKey: 'chatId', as: 'messages', ...cascade });
BeeQueenMessage.belongsTo(BeeQueenChat, { foreignKey: 'chatId', as: 'chat' });

// Content.
Post.hasMany(PostRevision, { foreignKey: 'postId', as: 'revisions', ...cascade });
PostRevision.belongsTo(Post, { foreignKey: 'postId', as: 'post' });
Post.belongsTo(User, { foreignKey: 'authorId', as: 'author', ...soft });
Post.belongsTo(User, { foreignKey: 'updatedById', as: 'updatedBy', ...soft });
Post.belongsTo(Post, { foreignKey: 'parentId', as: 'parent', ...soft });
Post.hasMany(Post, { foreignKey: 'parentId', as: 'children', ...soft });
PostRevision.belongsTo(User, { foreignKey: 'authorId', as: 'author', ...soft });
MediaAsset.belongsTo(User, { foreignKey: 'uploadedById', as: 'uploadedBy', ...soft });

Taxonomy.hasMany(Term, { foreignKey: 'taxonomyId', as: 'terms', ...cascade });
Term.belongsTo(Taxonomy, { foreignKey: 'taxonomyId', as: 'taxonomy' });
Term.belongsTo(Term, { foreignKey: 'parentId', as: 'parent', ...soft });
Term.hasMany(Term, { foreignKey: 'parentId', as: 'children', ...soft });
Post.belongsToMany(Term, {
  through: TermRelationship,
  foreignKey: 'postId',
  otherKey: 'termId',
  as: 'terms',
  timestamps: false,
});
Term.belongsToMany(Post, {
  through: TermRelationship,
  foreignKey: 'termId',
  otherKey: 'postId',
  as: 'posts',
  timestamps: false,
});
Post.hasMany(TermRelationship, { foreignKey: 'postId', as: 'termRelationships', ...cascade });

// Shopping: commerce data hangs off the product Post; orders own their lines and notes.
Post.hasOne(ShopProduct, { foreignKey: 'postId', as: 'shopProduct', ...cascade });
ShopProduct.belongsTo(Post, { foreignKey: 'postId', as: 'post' });
ShopProduct.hasMany(ShopProductVariant, { foreignKey: 'productId', as: 'variants', ...cascade });
ShopProductVariant.belongsTo(ShopProduct, { foreignKey: 'productId', as: 'product' });
ShopOrder.hasMany(ShopOrderItem, { foreignKey: 'orderId', as: 'items', ...cascade });
ShopOrderItem.belongsTo(ShopOrder, { foreignKey: 'orderId', as: 'order' });
ShopOrder.hasMany(ShopOrderNote, { foreignKey: 'orderId', as: 'notes', ...cascade });
ShopOrderNote.belongsTo(ShopOrder, { foreignKey: 'orderId', as: 'order' });
ShopOrder.belongsTo(ShopCustomer, { foreignKey: 'customerId', as: 'customer', ...soft });
ShopCustomer.hasMany(ShopOrder, { foreignKey: 'customerId', as: 'orders', ...soft });
ShopCustomer.hasMany(ShopCustomerSession, { foreignKey: 'customerId', as: 'sessions', ...cascade });
ShopCustomerSession.belongsTo(ShopCustomer, { foreignKey: 'customerId', as: 'customer' });
ShopCustomer.hasMany(ShopCustomerToken, { foreignKey: 'customerId', as: 'tokens', ...cascade });
ShopOrderItem.belongsTo(ShopProduct, { foreignKey: 'productId', as: 'product', ...soft });
ShopOrderItem.belongsTo(ShopProductVariant, { foreignKey: 'variantId', as: 'variant', ...soft });
BeeForm.hasMany(BeeFormEntry, { foreignKey: 'formId', as: 'entries', ...cascade });
BeeFormEntry.belongsTo(BeeForm, { foreignKey: 'formId', as: 'form' });
TermRelationship.belongsTo(Post, { foreignKey: 'postId', as: 'post' });
Term.hasMany(TermRelationship, { foreignKey: 'termId', as: 'relationships', ...cascade });
TermRelationship.belongsTo(Term, { foreignKey: 'termId', as: 'term' });

export {
  sequelize,
  ShopCart,
  ShopCustomerSession,
  ShopCustomerToken,
  ShopCoupon,
  ShopCustomer,
  ShopOrder,
  ShopOrderItem,
  ShopOrderNote,
  ShopPaymentEvent,
  ShopProduct,
  ShopProductVariant,
  ShopSetting,
  AuditLog,
  BeeForm,
  BeeFormEntry,
  BeeFormIntegration,
  BeeCookieClick,
  BeeCookieConsent,
  BeeCookieVisit,
  BeeQueenChat,
  BeeQueenMessage,
  Capability,
  FieldGroup,
  InstallationState,
  MediaAsset,
  OptionsPage,
  PasswordResetToken,
  Post,
  PostRevision,
  PostType,
  Role,
  RoleCapability,
  Session,
  Site,
  SiteSettings,
  Taxonomy,
  Term,
  TermRelationship,
  User,
};
