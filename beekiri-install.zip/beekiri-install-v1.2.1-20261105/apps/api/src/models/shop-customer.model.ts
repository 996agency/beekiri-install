import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, int, jsonb, optionalDate, optionalText, text, type Json } from './_shared';
import type { Site } from './site.model';

/** A buyer, keyed by lower-cased email (guest checkout; no site login). */
export class ShopCustomer extends Model<
  InferAttributes<ShopCustomer>,
  InferCreationAttributes<ShopCustomer>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare email: string;
  declare firstName: CreationOptional<string>;
  declare lastName: CreationOptional<string>;
  declare phone: CreationOptional<string>;
  declare billing: CreationOptional<Json>;
  declare shipping: CreationOptional<Json>;
  declare ordersCount: CreationOptional<number>;
  declare totalSpent: CreationOptional<number>;
  declare lastOrderAt: CreationOptional<Date | null>;
  /** Set when the shopper registered an account (argon2id). */
  declare passwordHash: CreationOptional<string | null>;
  declare emailVerifiedAt: CreationOptional<Date | null>;
  declare lastLoginAt: CreationOptional<Date | null>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    ShopCustomer.init(
      {
        id: idColumn(),
        siteId: text(),
        email: text(),
        firstName: text({ defaultValue: '' }),
        lastName: text({ defaultValue: '' }),
        phone: text({ defaultValue: '' }),
        billing: jsonb({}),
        shipping: jsonb({}),
        ordersCount: int(0),
        totalSpent: int(0),
        lastOrderAt: optionalDate(),
        passwordHash: optionalText(),
        emailVerifiedAt: optionalDate(),
        lastLoginAt: optionalDate(),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopCustomer',
        modelName: 'ShopCustomer',
        timestamps: true,
        indexes: [{ name: 'ShopCustomer_siteId_email_key', unique: true, fields: ['siteId', 'email'] }],
      },
    );
  }
}
