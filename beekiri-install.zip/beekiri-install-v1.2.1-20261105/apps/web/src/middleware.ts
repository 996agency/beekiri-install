import { NextResponse, type NextRequest } from 'next/server';

/**
 * Keep public routes static (ISR / bfcache-friendly) by rewriting preview
 * queries onto an internal dynamic segment — admin preview URLs stay the same:
 * `/?preview=1&token=…` and `/about?preview=1&token=…`.
 */
export function middleware(request: NextRequest) {
  // Shop account email links (confirm email, reset password) carry their own `token`.
  if (request.nextUrl.pathname === '/account' || request.nextUrl.pathname.startsWith('/account/')) {
    return NextResponse.next();
  }
  const preview = request.nextUrl.searchParams.get('preview');
  const token = request.nextUrl.searchParams.get('token');
  const wantPreview = preview === '1' || preview === 'true' || Boolean(token);
  if (!wantPreview) return NextResponse.next();

  const url = request.nextUrl.clone();
  const path = url.pathname === '/' ? '' : url.pathname;
  url.pathname = `/__preview${path}`;
  return NextResponse.rewrite(url);
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|uploads|runtime|favicon|.*\\..*).*)'],
};
