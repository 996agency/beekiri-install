import { preload } from 'react-dom';
import { Render } from '@beekiri/beekiricanva/rsc';
import {
  isBeekiricanvaData,
  beekiricanvaConfig,
  withLayouts,
  renderBeekiriCodePage,
  isBeekiriCodePublishDoc,
  type LayoutDef,
} from '@beekiri/page-blocks';
import '@beekiri/page-blocks/blocks.css';
import { getI18n } from '../lib/i18n';
import { renderLayout } from '../lib/render-layout';
import { renderFormHtml } from '../lib/forms';

import { API_URL as API } from '@/lib/env';

type Props = {
  content: string;
  beekiricanva?: unknown | null;
  /** BeekiriCode page tree — preferred source for public HTML. */
  beekiricode?: unknown | null;
  /** @deprecated Alias for beekiricode */
  instatic?: unknown | null;
};

async function getLayouts(): Promise<LayoutDef[]> {
  try {
    const res = await fetch(`${API}/api/layouts`, { next: { revalidate: 30 } });
    if (!res.ok) return [];
    const data = (await res.json()) as { layouts?: LayoutDef[] };
    return data.layouts ?? [];
  } catch {
    return [];
  }
}

function absoluteLayoutAsset(url: string): string {
  return url.startsWith('http') ? url : `${API.replace(/\/$/, '')}${url}`;
}

function layoutCssHref(layout: LayoutDef): string {
  return absoluteLayoutAsset(layout.cssUrl);
}

function layoutJsHref(layout: LayoutDef): string | null {
  if (!layout.jsUrl) return null;
  return absoluteLayoutAsset(layout.jsUrl);
}

function layoutStylesheet(layout: LayoutDef) {
  // `precedence` makes React/Next hoist the stylesheet into <head>.
  return (
    <link
      key={layout.slug}
      rel="stylesheet"
      href={layoutCssHref(layout)}
      precedence="beekiri-layouts"
    />
  );
}

/** Resolve BeekiriCode → HTML + layout CSS/JS asset hrefs + page CSS for <head>. */
/** Background image of the page's first top-level element, from the generated page CSS. */
function firstSectionImage(html: string, css: string): string | null {
  const ids = [...html.slice(0, 4000).matchAll(/data-bk="([\w-]+)"/g)].map((m) => m[1]);
  // A styled page root wraps everything in <div class="bk-page">: its first child is the section.
  const id = html.startsWith('<div class="bk-page"') ? ids[1] : ids[0];
  if (!id) return null;
  const rule = css.match(new RegExp(`\\[data-bk="${id}"\\]\\{([^}]*)\\}`))?.[1] ?? '';
  const value = rule.match(/background-image:([^;]+)/)?.[1] ?? '';
  // The original file (resized copies live under /uploads/_w…/).
  const url = [...value.matchAll(/url\((['"]?)([^'")]+)\1\)/g)].map((m) => m[2]).find((u) => !u.includes('/uploads/_w'));
  return url && /^(\/|https?:\/\/)/.test(url) ? url : null;
}

export async function resolveBeekiriCodePage(beekiricode: unknown): Promise<{
  html: string;
  css: string;
  cssHrefs: string[];
  jsHrefs: string[];
} | null> {
  if (!isBeekiriCodePublishDoc(beekiricode)) return null;
  const { html, css } = await renderBeekiriCodePage(beekiricode, renderLayout, renderFormHtml);
  if (!html.trim()) return { html: '', css: '', cssHrefs: [], jsHrefs: [] };
  // A photo behind the first section is usually the largest thing on screen: fetch it with the
  // HTML instead of after the stylesheet is parsed.
  const hero = firstSectionImage(html, css);
  if (hero) {
    // Exactly the copies the page CSS picks (phoneImageSet / screenImageSet): one download per device.
    const upload = hero.match(/^\/uploads\/(.+)$/)?.[1];
    if (upload) {
      preload(`/uploads/_w828/${upload}`, {
        as: 'image',
        fetchPriority: 'high',
        media: '(max-width: 767px)',
        imageSrcSet: `/uploads/_w828/${upload} 2x, /uploads/_w1290/${upload} 3x`,
      });
      preload(`/uploads/_w1600/${upload}`, {
        as: 'image',
        fetchPriority: 'high',
        media: '(min-width: 768px)',
        imageSrcSet: `/uploads/_w1600/${upload} 1x, ${hero} 2x`,
      });
    } else {
      preload(hero, { as: 'image', fetchPriority: 'high' });
    }
  }
  const layouts = await getLayouts();
  const used = new Set(
    [...html.matchAll(/data-layout="([^"]+)"/g)].map((m) => m[1]),
  );
  const usedLayouts = layouts.filter((l) => used.has(l.slug));
  return {
    html,
    css,
    cssHrefs: usedLayouts.map(layoutCssHref),
    jsHrefs: usedLayouts
      .map(layoutJsHref)
      .filter((href): href is string => Boolean(href)),
  };
}

/** Public page body — server Render only (no editor JS bundle). */
export async function PageBody({ content, beekiricanva, beekiricode, instatic }: Props) {
  const layouts = await getLayouts();
  const config = withLayouts(beekiricanvaConfig, layouts);
  const codeDoc = beekiricode ?? instatic;

  // BeekiriCode is handled by the page shell (sections inject into <main>).
  if (isBeekiriCodePublishDoc(codeDoc)) {
    return null;
  }

  const styleLinks = layouts.map(layoutStylesheet);

  if (isBeekiricanvaData(beekiricanva) && beekiricanva.content.length > 0) {
    return (
      <div className="bk-page-body">
        {styleLinks}
        <Render config={config} data={beekiricanva} />
      </div>
    );
  }

  if (content.trim() && /<[a-z][\s\S]*>/i.test(content)) {
    const i18n = await getI18n();
    return (
      <div
        className="bk-page-body"
        dangerouslySetInnerHTML={{ __html: i18n.html(content) }}
      />
    );
  }

  if (content.trim()) {
    const i18n = await getI18n();
    return (
      <div className="bk-page-body">
        <p>{i18n.t(content)}</p>
      </div>
    );
  }

  if (isBeekiricanvaData(beekiricanva)) {
    return (
      <div className="bk-page-body">
        {styleLinks}
        <Render config={config} data={beekiricanva} />
      </div>
    );
  }

  return null;
}
