import { getI18n } from '../lib/i18n';
import type { ShopViewData } from '../lib/shop';
import { shopPageWrap, ShopPageWrapAssets } from './ShopPageWrap';

/**
 * Storefront page body: the theme's PHP markup inside <main>, wrapped by whatever
 * was designed for this page in Shop → Shop Editor (content before / after the
 * "Shop content" block).
 */
export async function ShopMain({ data }: { data: ShopViewData }) {
  const view = data.view === 'category' ? 'shop' : data.view;
  const [i18n, wrap] = await Promise.all([getI18n(), shopPageWrap(view)]);
  return (
    <>
      <ShopPageWrapAssets wrap={wrap} id={view} />
      <main id="main" className={`bk-main bk-shop-main bk-shop-main--${data.view}`}>
        {wrap?.before ? (
          <div className="bk-page bk-shop-page-wrap" style={{ display: 'contents' }} suppressHydrationWarning dangerouslySetInnerHTML={{ __html: i18n.html(wrap.before) }} />
        ) : null}
        <div style={{ display: 'contents' }} suppressHydrationWarning dangerouslySetInnerHTML={{ __html: i18n.html(data.html) }} />
        {wrap?.after ? (
          <div className="bk-page bk-shop-page-wrap" style={{ display: 'contents' }} suppressHydrationWarning dangerouslySetInnerHTML={{ __html: i18n.html(wrap.after) }} />
        ) : null}
      </main>
    </>
  );
}
