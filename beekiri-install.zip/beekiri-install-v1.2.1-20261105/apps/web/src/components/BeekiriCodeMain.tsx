import type { ReactNode } from 'react';
import { getI18n } from '../lib/i18n';

/**
 * Public BeekiriCode body. PHP layout markup + defer layout scripts can tweak
 * attributes before React hydrates — same pattern as SiteChrome.
 */
export async function BeekiriCodeMain({
  html,
  className = 'bk-main',
  before,
}: {
  html: string;
  className?: string;
  before?: ReactNode;
}) {
  const i18n = await getI18n();
  return (
    <main id="main" className={className}>
      {/* Without JavaScript, deferred section photos are shown straight away. */}
      {html.includes('data-bk-bg') ? (
        <noscript dangerouslySetInnerHTML={{ __html: '<style>[data-bk-bg]{background-image:var(--bk-bg)}</style>' }} />
      ) : null}
      {before}
      <div
        style={{ display: 'contents' }}
        suppressHydrationWarning
        dangerouslySetInnerHTML={{ __html: i18n.html(html) }}
      />
    </main>
  );
}
