import type { Metadata } from 'next';
import { API_URL, SITE_URL } from './env';

/** Mirror of apps/api/src/lib/pages/page-seo.ts plus the URLs the API resolves. */
export type PublicSeo = {
  focusKeyword: string;
  metaTitle: string;
  metaDescription: string;
  canonicalUrl: string;
  robotsIndex: boolean;
  robotsFollow: boolean;
  robotsAdvanced: string[];
  excludeFromSitemap: boolean;
  ogTitle: string;
  ogDescription: string;
  ogImageId: string;
  ogImageUrl: string;
  featuredImageUrl: string;
  twitterCard: 'summary_large_image' | 'summary';
  schemaType: string;
  schemaJson: string;
  faq: { question: string; answer: string }[];
};

export type SeoPage = {
  title: string;
  path: string;
  excerpt?: string;
  publishedAt?: string | null;
  updatedAt?: string | null;
  seo?: Partial<PublicSeo> | null;
};

export type SeoSite = { title: string; tagline?: string };

/** Site-relative upload paths come from the API host. */
export function absoluteUrl(url: string | undefined | null): string {
  const v = (url ?? '').trim();
  if (!v) return '';
  if (/^https?:\/\//i.test(v)) return v;
  const base = (v.startsWith('/uploads/') ? API_URL : SITE_URL) || SITE_URL;
  return `${base.replace(/\/$/, '')}${v.startsWith('/') ? v : `/${v}`}`;
}

export function pageUrl(path: string): string {
  const p = path.startsWith('/') ? path : `/${path}`;
  return SITE_URL ? `${SITE_URL}${p === '/' ? '' : p}` : p;
}

function descriptionOf(page: SeoPage, seo: Partial<PublicSeo>): string {
  return (
    seo.metaDescription?.trim() ||
    (page.excerpt || '').trim() ||
    `${page.title} — published with Beekiri.`
  );
}

/** Next.js metadata honouring the page's SEO tab (falls back to title / excerpt). */
export function buildMetadata(page: SeoPage, site?: SeoSite | null): Metadata {
  const seo = page.seo ?? {};
  const description = descriptionOf(page, seo);
  const url = pageUrl(page.path);
  const image = absoluteUrl(seo.ogImageUrl || seo.featuredImageUrl);
  const ogTitle = seo.ogTitle?.trim() || seo.metaTitle?.trim() || page.title;
  const ogDescription = seo.ogDescription?.trim() || description;
  const index = seo.robotsIndex !== false;
  const follow = seo.robotsFollow !== false;
  const adv = new Set(seo.robotsAdvanced ?? []);

  return {
    // A custom meta title is used verbatim; otherwise the layout's "%s · Site" template applies.
    title: seo.metaTitle?.trim() ? { absolute: seo.metaTitle.trim() } : page.title,
    description,
    alternates: { canonical: seo.canonicalUrl?.trim() || url },
    robots: {
      index,
      follow,
      noarchive: adv.has('noarchive'),
      nosnippet: adv.has('nosnippet'),
      noimageindex: adv.has('noimageindex'),
      notranslate: adv.has('notranslate'),
      googleBot: { index, follow },
    },
    openGraph: {
      type: /Article|BlogPosting|NewsArticle/.test(seo.schemaType ?? '') ? 'article' : 'website',
      title: ogTitle,
      description: ogDescription,
      url,
      siteName: site?.title,
      ...(image ? { images: [{ url: image }] } : {}),
      ...(page.publishedAt ? { publishedTime: page.publishedAt } : {}),
      ...(page.updatedAt ? { modifiedTime: page.updatedAt } : {}),
    },
    twitter: {
      card: seo.twitterCard === 'summary' ? 'summary' : 'summary_large_image',
      title: ogTitle,
      description: ogDescription,
      ...(image ? { images: [image] } : {}),
    },
  };
}

/** Structured data: the chosen schema type, FAQ entries and any author-written JSON-LD. */
export function buildJsonLd(page: SeoPage, site?: SeoSite | null): Record<string, unknown>[] {
  const seo = page.seo ?? {};
  const out: Record<string, unknown>[] = [];
  const type = seo.schemaType || 'WebPage';
  const url = pageUrl(page.path);
  const image = absoluteUrl(seo.ogImageUrl || seo.featuredImageUrl);
  const description = descriptionOf(page, seo);

  if (type !== 'none') {
    const base: Record<string, unknown> = {
      '@context': 'https://schema.org',
      '@type': type,
      name: seo.metaTitle?.trim() || page.title,
      headline: page.title,
      description,
      url,
      ...(image ? { image } : {}),
      ...(page.publishedAt ? { datePublished: page.publishedAt } : {}),
      ...(page.updatedAt ? { dateModified: page.updatedAt } : {}),
    };
    if (site?.title) {
      base.publisher = { '@type': 'Organization', name: site.title, url: SITE_URL || undefined };
      if (/Article|BlogPosting|NewsArticle/.test(type)) base.isPartOf = { '@type': 'WebSite', name: site.title, url: SITE_URL || undefined };
    }
    if (type === 'FAQPage' && seo.faq?.length) {
      base.mainEntity = seo.faq.map((f) => ({
        '@type': 'Question',
        name: f.question,
        acceptedAnswer: { '@type': 'Answer', text: f.answer },
      }));
    }
    out.push(base);
  } else if (seo.faq?.length) {
    out.push({
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: seo.faq.map((f) => ({
        '@type': 'Question',
        name: f.question,
        acceptedAnswer: { '@type': 'Answer', text: f.answer },
      })),
    });
  }

  if (seo.schemaJson?.trim()) {
    try {
      const custom = JSON.parse(seo.schemaJson) as unknown;
      if (Array.isArray(custom)) out.push(...(custom.filter((c) => c && typeof c === 'object') as Record<string, unknown>[]));
      else if (custom && typeof custom === 'object') out.push(custom as Record<string, unknown>);
    } catch {
      /* invalid JSON is rejected by the API; ignore defensively */
    }
  }
  return out;
}

/** Breadcrumb list for anything below the home page. */
export function breadcrumbJsonLd(crumbs: { name: string; path: string }[]): Record<string, unknown> | null {
  if (crumbs.length < 2) return null;
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: crumbs.map((c, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: c.name,
      item: pageUrl(c.path),
    })),
  };
}

/** `</script>` inside JSON must never close the tag. */
export function serializeJsonLd(data: unknown): string {
  return JSON.stringify(data).replace(/</g, '\\u003c');
}
