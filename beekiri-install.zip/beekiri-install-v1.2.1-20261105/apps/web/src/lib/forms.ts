import { API_URL as API } from '@/lib/env';

/** True when the Bee Forms extension is active (the root layout then loads bee-forms.js). */
export async function formsConfig(): Promise<boolean> {
  try {
    const res = await fetch(`${API}/api/forms/public/config`, { next: { revalidate: 30 } });
    if (!res.ok) return false;
    const data = (await res.json()) as { active?: boolean };
    return data.active === true;
  } catch {
    return false;
  }
}

/** Server-rendered HTML of a form for the page renderer; '' when missing or inactive. */
export async function renderFormHtml(formId: string): Promise<string> {
  try {
    const res = await fetch(`${API}/api/forms/public/${encodeURIComponent(formId)}/html`, { cache: 'no-store' });
    if (!res.ok) return '';
    const data = (await res.json()) as { html?: string };
    return data.html ?? '';
  } catch {
    return '';
  }
}
