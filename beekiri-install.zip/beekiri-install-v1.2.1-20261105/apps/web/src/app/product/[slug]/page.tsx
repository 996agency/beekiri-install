import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { JsonLd } from '../../../components/JsonLd';
import { ShopMain } from '../../../components/ShopMain';
import { getI18n } from '../../../lib/i18n';
import { breadcrumbJsonLd } from '../../../lib/seo';
import { fetchShopView, productJsonLd, shopMetadata, siteMeta } from '../../../lib/shop';
import { SITE_URL } from '@/lib/env';

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const [data, site] = await Promise.all([fetchShopView('product', { slug }), siteMeta()]);
  return shopMetadata(data, site, 'Product');
}

/** /product/{slug} — single product (Shopping extension). */
export default async function ProductPage({ params }: Props) {
  const { slug } = await params;
  const [data, site, i18n] = await Promise.all([fetchShopView('product', { slug }), siteMeta(), getI18n()]);
  if (!data) notFound();
  return (
    <>
      <JsonLd
        data={[
          productJsonLd(data, SITE_URL),
          breadcrumbJsonLd([
            { name: site?.title || i18n.t('Home'), path: i18n.href('/') },
            { name: i18n.t('Shop'), path: i18n.href('/shop') },
            { name: data.title, path: data.path },
          ]),
        ]}
      />
      <ShopMain data={data} />
    </>
  );
}
