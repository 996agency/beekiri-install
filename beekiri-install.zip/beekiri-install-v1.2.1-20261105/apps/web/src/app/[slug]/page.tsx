import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { BeekiriCodeMain } from '../../components/BeekiriCodeMain';
import { JsonLd } from '../../components/JsonLd';
import { PageBody, resolveBeekiriCodePage } from '../../components/PageBody';
import { breadcrumbJsonLd, buildJsonLd, buildMetadata, type PublicSeo } from '../../lib/seo';
import { getI18n, localizeRecord } from '../../lib/i18n';
import { API_URL as API } from '@/lib/env';

export const revalidate = 10;

type PublicPage = {
  title: string;
  slug: string;
  path: string;
  content: string;
  beekiricanva?: unknown | null;
  beekiricode?: unknown | null;
  instatic?: unknown | null;
  excerpt: string;
  publishedAt?: string | null;
  updatedAt?: string | null;
  seo?: Partial<PublicSeo> | null;
};

type CptMeta = {
  slug: string;
  singular: string;
  plural: string;
  hasArchive: boolean;
  archiveDesign: string;
};

type PublicEntry = {
  title: string;
  slug: string;
  path: string;
  excerpt: string;
  publishedAt: string | null;
};

async function getPage(slug: string): Promise<PublicPage | null> {
  try {
    const res = await fetch(`${API}/api/pages/public/${encodeURIComponent(slug)}`, {
      next: { revalidate: 30 },
    });
    if (res.status === 404) return null;
    if (!res.ok) return null;
    return localizeRecord(await getI18n(), (await res.json()) as PublicPage);
  } catch {
    return null;
  }
}

async function getSiteMeta(): Promise<{ title: string } | null> {
  try {
    const res = await fetch(`${API}/api/site/public`, { next: { revalidate: 30 } });
    if (!res.ok) return null;
    const data = (await res.json()) as { title?: string };
    return { title: (await getI18n()).t((data.title ?? '').trim()) };
  } catch {
    return null;
  }
}

async function getCptMeta(slug: string): Promise<CptMeta | null> {
  try {
    const res = await fetch(`${API}/api/content/${encodeURIComponent(slug)}/meta`, {
      next: { revalidate: 30 },
    });
    if (!res.ok) return null;
    const meta = (await res.json()) as CptMeta;
    const i18n = await getI18n();
    return { ...meta, singular: i18n.t(meta.singular), plural: i18n.t(meta.plural) };
  } catch {
    return null;
  }
}

async function listCpt(slug: string): Promise<PublicEntry[]> {
  try {
    const res = await fetch(`${API}/api/content/${encodeURIComponent(slug)}/public`, {
      next: { revalidate: 30 },
    });
    if (!res.ok) return [];
    const data = (await res.json()) as { items?: PublicEntry[]; posts?: PublicEntry[] };
    const i18n = await getI18n();
    return (data.items ?? data.posts ?? []).map((e) => localizeRecord(i18n, e));
  } catch {
    return [];
  }
}

type Props = {
  params: Promise<{ slug: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const page = await getPage(slug);
  if (page) return buildMetadata(page, await getSiteMeta());
  const meta = await getCptMeta(slug);
  if (meta?.hasArchive) return { title: meta.plural, description: `${meta.plural} archive` };
  return { title: 'Not found' };
}

export default async function ContentPage({ params }: Props) {
  const { slug } = await params;
  const page = await getPage(slug);
  if (page) {
    const codeDoc = page.beekiricode ?? page.instatic;
    const codePage = codeDoc ? await resolveBeekiriCodePage(codeDoc) : null;
    const site = await getSiteMeta();
    const i18n = await getI18n();

    return (
      <>
        <JsonLd
          data={[
            ...buildJsonLd(page, site),
            breadcrumbJsonLd([{ name: site?.title || i18n.t('Home'), path: i18n.href('/') }, { name: page.title, path: page.path }]),
          ]}
        />
        {codePage?.cssHrefs.map((href) => (
          <link key={href} rel="stylesheet" href={href} precedence="beekiri-layouts" />
        ))}
        {codePage?.css ? (
          <style href={`bk-page-${page.slug}`} precedence="beekiri-page">
            {codePage.css}
          </style>
        ) : null}
        {codePage?.jsHrefs.map((href) => (
          <script key={href} src={href} defer />
        ))}
        {codePage ? (
          <BeekiriCodeMain html={codePage.html} />
        ) : (
          <main id="main" className="bk-main">
            <h1>{page.title}</h1>
            <PageBody content={page.content} beekiricanva={page.beekiricanva} beekiricode={null} />
          </main>
        )}
      </>
    );
  }

  const meta = await getCptMeta(slug);
  if (!meta?.hasArchive) notFound();
  const entries = await listCpt(slug);
  const i18n = await getI18n();
  const design = meta.archiveDesign || 'list';

  return (
    <main id="main" className={`bk-main bk-cpt-archive bk-cpt-archive--${design}`}>
      <h1>{meta.plural}</h1>
      {entries.length === 0 ? (
        <p className="bk-lead">{i18n.t(`No ${meta.plural.toLowerCase()} published yet.`)}</p>
      ) : (
        <ul className={`bk-cpt-archive__list bk-cpt-archive__list--${design}`}>
          {entries.map((e) => (
            <li key={e.slug}>
              <Link href={i18n.href(`/${slug}/${e.slug}`)}>{e.title}</Link>
              {e.excerpt ? <p>{e.excerpt}</p> : null}
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
