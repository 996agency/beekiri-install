import type { Metadata } from 'next';
import { BeekiriCodeMain } from '../components/BeekiriCodeMain';
import { JsonLd } from '../components/JsonLd';
import { PageBody, resolveBeekiriCodePage } from '../components/PageBody';
import { buildJsonLd, buildMetadata, pageUrl, type PublicSeo } from '../lib/seo';
import { getI18n, localizeRecord } from '../lib/i18n';

export const revalidate = 10;

import { API_URL as API } from '@/lib/env';

type PublicPage = {
  title: string;
  slug: string;
  path: string;
  content: string;
  beekiricanva?: unknown | null;
  beekiricode?: unknown | null;
  instatic?: unknown | null;
  excerpt: string;
  publishedAt?: string | null;
  updatedAt?: string | null;
  seo?: Partial<PublicSeo> | null;
};

type SitePublic = {
  installed?: boolean;
  title?: string;
  tagline?: string;
  frontPageSlug?: string | null;
};

async function getSite(): Promise<SitePublic | null> {
  try {
    const res = await fetch(`${API}/api/site/public`, { next: { revalidate: 30 } });
    if (!res.ok) return null;
    return (await res.json()) as SitePublic;
  } catch {
    return null;
  }
}

async function getFrontPage(): Promise<PublicPage | null> {
  try {
    const res = await fetch(`${API}/api/pages/public/front`, { next: { revalidate: 30 } });
    if (res.status === 404) return null;
    if (!res.ok) return null;
    return localizeRecord(await getI18n(), (await res.json()) as PublicPage);
  } catch {
    return null;
  }
}

async function FallbackHome({ site }: { site: SitePublic | null }) {
  const i18n = await getI18n();
  const title = i18n.t(site?.installed ? site.title || 'Beekiri' : 'Beekiri');
  const lead = i18n.t(
    site?.installed
      ? site.tagline || 'Set a front page in Admin → Settings → Permalinks, then publish that page.'
      : 'Your site is almost ready. Open the Beekiri installer to finish setup.',
  );

  return (
    <main id="main" className="bk-main">
      <h1>{title}</h1>
      <p className="bk-lead">{lead}</p>
    </main>
  );
}

export async function generateMetadata(): Promise<Metadata> {
  const page = await getFrontPage();
  if (!page) {
    const site = await getSite();
    const i18n = await getI18n();
    return {
      title: i18n.t(site?.title?.trim() || 'Beekiri'),
      description: i18n.t(site?.tagline?.trim() || 'Published with Beekiri.'),
    };
  }
  const site = await getSite();
  const i18n = await getI18n();
  return buildMetadata(
    { ...page, path: i18n.href('/') },
    site?.title ? { title: i18n.t(site.title) } : null,
  );
}

export default async function HomePage() {
  const [site, page] = await Promise.all([getSite(), getFrontPage()]);

  if (!page) {
    return <FallbackHome site={site} />;
  }

  const codeDoc = page.beekiricode ?? page.instatic;
  const codePage = codeDoc ? await resolveBeekiriCodePage(codeDoc) : null;
  const i18n = await getI18n();
  const siteMeta = site?.title ? { title: i18n.t(site.title) } : null;

  return (
    <>
      <JsonLd
        data={[
          // WebSite entity for the home page (sitelinks search box eligibility).
          siteMeta ? { '@context': 'https://schema.org', '@type': 'WebSite', name: siteMeta.title, url: pageUrl(i18n.href('/')) } : null,
          ...buildJsonLd({ ...page, path: i18n.href('/') }, siteMeta),
        ]}
      />
      {codePage?.cssHrefs.map((href) => (
        <link key={href} rel="stylesheet" href={href} precedence="beekiri-layouts" />
      ))}
      {codePage?.css ? (
        <style href={`bk-page-${page.slug}`} precedence="beekiri-page">
          {codePage.css}
        </style>
      ) : null}
      {codePage?.jsHrefs.map((href) => (
        <script key={href} src={href} defer />
      ))}
      {codePage ? (
        <BeekiriCodeMain html={codePage.html} />
      ) : (
        <main id="main" className="bk-main">
          <h1>{page.title}</h1>
          <PageBody content={page.content} beekiricanva={page.beekiricanva} beekiricode={null} />
        </main>
      )}
    </>
  );
}
