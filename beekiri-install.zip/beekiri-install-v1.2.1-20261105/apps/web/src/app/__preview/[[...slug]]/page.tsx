import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { BeekiriCodeMain } from '../../../components/BeekiriCodeMain';
import { PageBody, resolveBeekiriCodePage } from '../../../components/PageBody';

import { API_URL as API } from '@/lib/env';

type PublicPage = {
  title: string;
  slug: string;
  content: string;
  beekiricanva?: unknown | null;
  beekiricode?: unknown | null;
  instatic?: unknown | null;
  excerpt: string;
  preview?: boolean;
};

type Props = {
  params: Promise<{ slug?: string[] }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

function firstParam(value: string | string[] | undefined): string | undefined {
  if (Array.isArray(value)) return value[0];
  return value;
}

async function loadPage(slugParts: string[] | null, token: string): Promise<PublicPage | null> {
  try {
    const qs = `?preview=1&token=${encodeURIComponent(token)}`;
    let path: string;
    if (!slugParts?.length) {
      path = `/api/pages/public/front${qs}`;
    } else if (slugParts[0] === 'blog' && slugParts[1]) {
      path = `/api/posts/public/${encodeURIComponent(slugParts.slice(1).join('/'))}${qs}`;
    } else {
      path = `/api/pages/public/${encodeURIComponent(slugParts.join('/'))}${qs}`;
    }
    const res = await fetch(`${API}${path}`, { cache: 'no-store' });
    if (res.status === 404 || !res.ok) return null;
    return (await res.json()) as PublicPage;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params, searchParams }: Props): Promise<Metadata> {
  const { slug: parts } = await params;
  const sp = await searchParams;
  const token = firstParam(sp.token);
  if (!token) return { title: 'Preview', robots: { index: false, follow: false } };
  const page = await loadPage(parts?.length ? parts : null, token);
  if (!page) return { title: 'Preview', robots: { index: false, follow: false } };
  return {
    title: `${page.title} (Preview)`,
    description: (page.excerpt || '').trim() || undefined,
    robots: { index: false, follow: false },
  };
}

/** Dynamic preview surface — rewritten from `?preview=1&token=` public URLs. */
export default async function PreviewPage({ params, searchParams }: Props) {
  const { slug: parts } = await params;
  const sp = await searchParams;
  const token = firstParam(sp.token);
  if (!token) notFound();
  const page = await loadPage(parts?.length ? parts : null, token);
  if (!page) notFound();

  const codeDoc = page.beekiricode ?? page.instatic;
  const codePage = codeDoc ? await resolveBeekiriCodePage(codeDoc) : null;

  return (
    <>
      {codePage?.cssHrefs.map((href) => (
        <link key={href} rel="stylesheet" href={href} precedence="beekiri-layouts" />
      ))}
      {codePage?.css ? (
        <style href={`bk-preview-${page.slug}`} precedence="beekiri-page">
          {codePage.css}
        </style>
      ) : null}
      {codePage?.jsHrefs.map((href) => (
        <script key={href} src={href} defer />
      ))}
      {codePage ? (
        <BeekiriCodeMain
          html={codePage.html}
          before={
            <p className="bk-preview-banner">Preview — this is not the live published page.</p>
          }
        />
      ) : (
        <main id="main" className="bk-main">
          <p className="bk-preview-banner">Preview — this is not the live published page.</p>
          <h1>{page.title}</h1>
          <PageBody content={page.content} beekiricanva={page.beekiricanva} beekiricode={null} />
        </main>
      )}
    </>
  );
}
