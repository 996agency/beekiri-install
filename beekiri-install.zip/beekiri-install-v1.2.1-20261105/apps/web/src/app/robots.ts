import type { MetadataRoute } from 'next';

import { API_URL as API, SITE_URL as HOST } from '@/lib/env';

export const dynamic = 'force-dynamic';

/**
 * Only the default /admin is listed. A custom admin address is deliberately left out:
 * robots.txt is public, so naming it there would publish it. The admin is kept out of
 * search engines by its own noindex header and meta tag instead.
 */
const ADMIN_DISALLOW = ['/admin', '/admin/'];

export default async function robots(): Promise<MetadataRoute.Robots> {
  let blogPublic = true;
  try {
    const publicRes = await fetch(`${API}/api/site/public`, { next: { revalidate: 60 } });
    if (publicRes.ok) {
      const data = (await publicRes.json()) as { blogPublic?: boolean; installed?: boolean };
      if (data.installed === false) blogPublic = false;
      else if (data.blogPublic === false) blogPublic = false;
    }
  } catch {
    // Fail open for crawlers if API is briefly down during generation.
    blogPublic = true;
  }

  if (!blogPublic) {
    return {
      rules: [{ userAgent: '*', disallow: '/' }],
    };
  }

  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ADMIN_DISALLOW,
      },
    ],
    sitemap: `${HOST}/sitemap.xml`,
  };
}
