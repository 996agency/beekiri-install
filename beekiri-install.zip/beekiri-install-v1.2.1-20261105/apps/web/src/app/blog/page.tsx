import type { Metadata } from 'next';
import { getI18n, localizeRecord } from '../../lib/i18n';

export const revalidate = 30;

import { API_URL as API } from '@/lib/env';

type PublicPost = {
  title: string;
  slug: string;
  path: string;
  excerpt: string;
  publishedAt: string | null;
};

async function listPublishedPosts(): Promise<PublicPost[]> {
  try {
    // Public archive: pull from link-targets-style listing via a lightweight public endpoint.
    // Until a dedicated archive API exists, reuse site public menu is not enough —
    // fetch published posts through the posts public index when available.
    const res = await fetch(`${API}/api/posts/public`, { next: { revalidate: 30 } });
    if (!res.ok) return [];
    const data = (await res.json()) as { posts?: PublicPost[] };
    const i18n = await getI18n();
    return (data.posts ?? []).map((p) => localizeRecord(i18n, p));
  } catch {
    return [];
  }
}

export async function generateMetadata(): Promise<Metadata> {
  const i18n = await getI18n();
  return { title: i18n.t('Blog'), description: i18n.t('Latest posts') };
}

export default async function BlogIndexPage() {
  const posts = await listPublishedPosts();
  const i18n = await getI18n();

  return (
    <main id="main" className="bk-main">
      <h1>{i18n.t('Blog')}</h1>
      <p className="bk-lead">{i18n.t('Single posts from your site.')}</p>
      {posts.length === 0 ? (
        <p className="bk-muted">{i18n.t('No published posts yet.')}</p>
      ) : (
        <ul className="bk-blog-list">
          {posts.map((post) => (
            <li key={post.slug}>
              <a href={post.path || i18n.href(`/blog/${post.slug}`)}>
                <strong>{post.title || '(no title)'}</strong>
              </a>
              {post.excerpt ? <p>{post.excerpt}</p> : null}
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
