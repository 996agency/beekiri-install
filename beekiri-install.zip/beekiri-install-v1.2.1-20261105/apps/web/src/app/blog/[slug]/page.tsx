import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { BeekiriCodeMain } from '../../../components/BeekiriCodeMain';
import { JsonLd } from '../../../components/JsonLd';
import { PageBody, resolveBeekiriCodePage } from '../../../components/PageBody';
import { breadcrumbJsonLd, buildJsonLd, buildMetadata, type PublicSeo } from '../../../lib/seo';
import { getI18n, localizeRecord } from '../../../lib/i18n';

export const revalidate = 30;

import { API_URL as API } from '@/lib/env';

type PublicPage = {
  title: string;
  slug: string;
  path: string;
  content: string;
  beekiricanva?: unknown | null;
  beekiricode?: unknown | null;
  instatic?: unknown | null;
  excerpt: string;
  publishedAt?: string | null;
  updatedAt?: string | null;
  seo?: Partial<PublicSeo> | null;
};

async function getPage(slug: string): Promise<PublicPage | null> {
  try {
    const res = await fetch(`${API}/api/posts/public/${encodeURIComponent(slug)}`, {
      next: { revalidate: 30 },
    });
    if (res.status === 404) return null;
    if (!res.ok) return null;
    return localizeRecord(await getI18n(), (await res.json()) as PublicPage);
  } catch {
    return null;
  }
}

type Props = {
  params: Promise<{ slug: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const page = await getPage(slug);
  if (!page) return { title: 'Not found' };
  // Posts default to BlogPosting schema unless the SEO tab says otherwise.
  return buildMetadata({ ...page, seo: { schemaType: 'BlogPosting', ...(page.seo ?? {}) } }, await getSiteMeta());
}

async function getSiteMeta(): Promise<{ title: string } | null> {
  try {
    const res = await fetch(`${API}/api/site/public`, { next: { revalidate: 30 } });
    if (!res.ok) return null;
    const data = (await res.json()) as { title?: string };
    return { title: (await getI18n()).t((data.title ?? '').trim()) };
  } catch {
    return null;
  }
}

export default async function BlogPostPage({ params }: Props) {
  const { slug } = await params;
  const page = await getPage(slug);
  if (!page) notFound();
  const codeDoc = page.beekiricode ?? page.instatic;
  const codePage = codeDoc ? await resolveBeekiriCodePage(codeDoc) : null;
  const site = await getSiteMeta();
  const seoPage = { ...page, seo: { schemaType: 'BlogPosting', ...(page.seo ?? {}) } };
  const i18n = await getI18n();

  return (
    <>
      <JsonLd
        data={[
          ...buildJsonLd(seoPage, site),
          breadcrumbJsonLd([
            { name: site?.title || i18n.t('Home'), path: i18n.href('/') },
            { name: i18n.t('Blog'), path: i18n.href('/blog') },
            { name: page.title, path: page.path },
          ]),
        ]}
      />
      {codePage?.cssHrefs.map((href) => (
        <link key={href} rel="stylesheet" href={href} precedence="beekiri-layouts" />
      ))}
      {codePage?.css ? (
        <style href={`bk-page-${page.slug}`} precedence="beekiri-page">
          {codePage.css}
        </style>
      ) : null}
      {codePage?.jsHrefs.map((href) => (
        <script key={href} src={href} defer />
      ))}
      {codePage ? (
        <BeekiriCodeMain html={codePage.html} />
      ) : (
        <main id="main" className="bk-main">
          <h1>{page.title}</h1>
          <PageBody content={page.content} beekiricanva={page.beekiricanva} beekiricode={null} />
        </main>
      )}
    </>
  );
}
