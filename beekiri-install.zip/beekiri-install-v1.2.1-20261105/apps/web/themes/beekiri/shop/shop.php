<?php
/**
 * Shop archive (also used for /shop/category/{slug}).
 *
 * Data: shop {title, path, …}, products[], categories[], category|null, query, sort,
 *       sorts[], pagination, base_path. See themes/beekiri/shop/README.md.
 */
$shop = get_bee_field('shop') ?: [];
$products = get_bee_field('products') ?: [];
$categories = get_bee_field('categories') ?: [];
$category = get_bee_field('category');
$query = (string) (get_bee_field('query') ?: '');
$sort = (string) (get_bee_field('sort') ?: 'menu_order');
$sorts = get_bee_field('sorts') ?: [];
$pagination = get_bee_field('pagination') ?: [];
$basePath = (string) (get_bee_field('base_path') ?: ($shop['path'] ?? '/shop'));
$title = is_array($category) ? ($category['name'] ?? '') : ($shop['title'] ?? 'Shop');
$description = is_array($category) ? ($category['description'] ?? '') : ($shop['description'] ?? '');
$crumbs = [['label' => $shop['title'] ?? 'Shop', 'url' => $shop['path'] ?? '/shop']];
if (is_array($category)) $crumbs[] = ['label' => $category['name'] ?? '', 'url' => $category['path'] ?? $basePath];
$total = (int) ($pagination['total'] ?? count($products));
$opts = $shop['options'] ?? [];
$opt = fn(string $k, bool $d = true) => isset($opts[$k]) ? (bool) $opts[$k] : $d;
$columns = max(2, min(4, (int) ($opts['columns'] ?? 3)));
/** Category tiles in the left column ("sidebar" option); parents first, each followed by its children. */
$hasSidebar = $opt('showSidebar') && !empty($shop['show_categories']) && $categories;
$currentSlug = is_array($category) ? ($category['slug'] ?? '') : '';
$catTiles = [];
if ($hasSidebar) {
  $byParent = [];
  foreach ($categories as $c) $byParent[$c['parentId'] ?? ''][] = $c;
  $names = array_column($categories, 'name', 'id');
  $walk = function ($parentId, $depth) use (&$walk, &$catTiles, $byParent, $names) {
    foreach ($byParent[$parentId] ?? [] as $c) {
      if (($c['count'] ?? 0) > 0) $catTiles[] = $c + ['parentName' => $depth ? ($names[$parentId] ?? '') : ''];
      if ($depth < 3) $walk($c['id'], $depth + 1);
    }
  };
  $walk('', 0);
}
?>
<section class="bk-shop bk-shop--archive" data-shop-view="shop" data-archive="<?php echo is_array($category) ? 'category' : 'shop'; ?>" data-archive-slug="<?php echo esc_attr($currentSlug); ?>" data-archive-path="<?php echo esc_url($basePath); ?>">
  <div class="bk-shop__wrap">
    <header class="bk-archive__head">
      <?php if ($opt('showBreadcrumbs')) echo bee_shop_breadcrumbs($crumbs); ?>
      <div class="bk-archive__title-row">
        <h1 class="bk-archive__title"><?php echo esc_html($title); ?></h1>
        <?php if ($opt('showResultCount')) : ?>
          <p class="bk-archive__count" data-archive-count aria-live="polite">
            <?php
            if ($query !== '') echo esc_html(sprintf(bee_shop_t('%d results for “%s”'), $total, $query));
            else echo esc_html(sprintf($total === 1 ? bee_shop_t('%d product') : bee_shop_t('%d products'), $total));
            ?>
          </p>
        <?php endif; ?>
      </div>
      <?php if ($description) : ?><p class="bk-archive__lead"><?php echo esc_html($description); ?></p><?php endif; ?>
    </header>

    <div class="bk-archive<?php echo $catTiles ? ' has-cats' : ''; ?>">
      <?php if ($catTiles) : ?>
        <aside class="bk-archive__side" aria-label="<?php echo esc_attr(bee_shop_t('Categories')); ?>" data-cat-panel>
          <div class="bk-archive__side-head">
            <h2 class="bk-archive__side-title"><?php echo esc_html(bee_shop_t('Categories')); ?></h2>
            <?php if (count($catTiles) > 8) : ?>
              <label class="bk-visually-hidden" for="bk-cat-filter"><?php echo esc_html(bee_shop_t('Filter categories')); ?></label>
              <input id="bk-cat-filter" class="bk-archive__cat-filter" type="search" placeholder="<?php echo esc_attr(bee_shop_t('Filter categories…')); ?>" autocomplete="off" data-cat-filter>
            <?php endif; ?>
          </div>
          <ul class="bk-archive__tiles" role="list">
            <li>
              <a class="bk-archive__tile is-all<?php echo $currentSlug === '' ? ' is-active' : ''; ?>" href="<?php echo esc_url($shop['path'] ?? '/shop'); ?>"<?php echo $currentSlug === '' ? ' aria-current="page"' : ''; ?> data-cat-name="<?php echo esc_attr(bee_shop_t('All products')); ?>">
<?php
                  // "All products": a small collage of category photos (different images first), or a grid icon.
                  $collage = [];
                  foreach ($catTiles as $ct) {
                    $u = $ct['image']['url'] ?? '';
                    if ($u !== '' && !in_array($u, $collage, true)) $collage[] = $u;
                    if (count($collage) === 4) break;
                  }
                ?>
                <span class="bk-archive__tile-media" aria-hidden="true">
                  <?php if (count($collage) >= 2) : ?>
                    <span class="bk-archive__collage is-<?php echo count($collage); ?>">
                      <?php foreach ($collage as $u) : ?><img src="<?php echo esc_url($u); ?>" alt="" loading="lazy" decoding="async"><?php endforeach; ?>
                    </span>
                  <?php else : ?>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/></svg>
                  <?php endif; ?>
                </span>
                <span class="bk-archive__tile-name"><?php echo esc_html(bee_shop_t('All products')); ?></span>
              </a>
            </li>
            <?php foreach ($catTiles as $c) : $on = $c['slug'] === $currentSlug; ?>
              <li>
                <a class="bk-archive__tile<?php echo $on ? ' is-active' : ''; ?>" href="<?php echo esc_url($c['path']); ?>"<?php echo $on ? ' aria-current="page"' : ''; ?> data-cat-name="<?php echo esc_attr(trim(($c['parentName'] ?? '') . ' ' . $c['name'])); ?>">
                  <span class="bk-archive__tile-media" aria-hidden="true">
                    <?php if (!empty($c['image']['url'])) : ?>
                      <img src="<?php echo esc_url($c['image']['url']); ?>" alt="" loading="lazy" decoding="async">
                    <?php else : ?>
                      <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="12" y="14" width="40" height="36" rx="3"/><path d="M12 40l11-10 9 8 7-6 13 11"/><circle cx="40" cy="24" r="3.5"/></svg>
                    <?php endif; ?>
                  </span>
                  <?php if (!empty($c['parentName'])) : ?><span class="bk-archive__tile-parent"><?php echo esc_html($c['parentName']); ?></span><?php endif; ?>
                  <span class="bk-archive__tile-name"><?php echo esc_html($c['name']); ?></span>
                  <span class="bk-archive__tile-count"><?php echo esc_html(sprintf((int) $c['count'] === 1 ? bee_shop_t('%d product') : bee_shop_t('%d products'), (int) $c['count'])); ?></span>
                </a>
              </li>
            <?php endforeach; ?>
          </ul>
          <p class="bk-archive__no-match" data-cat-empty hidden><?php echo esc_html(bee_shop_t('No categories match.')); ?></p>
        </aside>
      <?php endif; ?>

      <div class="bk-archive__main">
        <?php if ($opt('showSearch') || $opt('showSort')) : ?>
          <div class="bk-archive__bar">
            <?php if ($opt('showSearch')) : ?>
              <form class="bk-archive__search" method="get" action="<?php echo esc_url($basePath); ?>" role="search" data-archive-search>
                <?php echo bee_shop_icon('search'); ?>
                <label class="bk-visually-hidden" for="bk-shop-q"><?php echo esc_html(bee_shop_t('Search products')); ?></label>
                <input id="bk-shop-q" type="search" name="q" value="<?php echo esc_attr($query); ?>" autocomplete="off" placeholder="<?php echo esc_attr(is_array($category) ? sprintf(bee_shop_t('Search in %s…'), $category['name'] ?? '') : bee_shop_t('Search products…')); ?>">
              </form>
            <?php endif; ?>
            <?php if ($opt('showSort')) : ?>
              <form class="bk-archive__sort" method="get" action="<?php echo esc_url($basePath); ?>">
                <?php if ($query !== '') : ?><input type="hidden" name="q" value="<?php echo esc_attr($query); ?>"><?php endif; ?>
                <label class="bk-visually-hidden" for="bk-shop-sort"><?php echo esc_html(bee_shop_t('Sort by')); ?></label>
                <select id="bk-shop-sort" name="sort" data-shop-sort>
                  <?php foreach ($sorts as $o) : ?>
                    <option value="<?php echo esc_attr($o['id']); ?>"<?php echo $o['id'] === $sort ? ' selected' : ''; ?>><?php echo esc_html(bee_shop_t($o['label'])); ?></option>
                  <?php endforeach; ?>
                </select>
              </form>
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <div class="bk-archive__results" data-archive-results>
        <?php if ($products) : ?>
          <ul class="bk-products bk-products--cols-<?php echo $columns; ?>">
            <?php foreach ($products as $product) bee_shop_partial('product-card', ['product' => $product]); ?>
          </ul>
          <?php bee_shop_partial('pagination', ['pagination' => $pagination]); ?>
        <?php else : ?>
          <div class="bk-archive__empty">
            <span class="bk-cart-empty__icon" aria-hidden="true"><?php echo bee_shop_icon('search'); ?></span>
            <p><?php echo esc_html($query !== '' ? bee_shop_t('No products matched your search.') : bee_shop_t('No products were found.')); ?></p>
            <?php if ($query !== '' || is_array($category)) : ?>
              <a class="bk-btn bk-btn--ghost" href="<?php echo esc_url($shop['path'] ?? '/shop'); ?>"><?php echo esc_html(bee_shop_t('Browse all products')); ?></a>
            <?php endif; ?>
          </div>
        <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</section>
