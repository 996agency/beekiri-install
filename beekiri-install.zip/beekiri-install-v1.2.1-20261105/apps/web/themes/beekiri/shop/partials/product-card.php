<?php
/**
 * One product in a grid. Expects $product (array from the catalog API).
 * Override: copy to beekiri-child/shop/partials/product-card.php
 */
$product = $product ?? [];
$isVariable = ($product['type'] ?? 'simple') === 'variable';
$canBuy = !$isVariable && !empty($product['inStock']) && !empty($product['price']);
$categories = $product['categories'] ?? [];
/** Up to five colour/finish dots, from the first attribute that has them. */
$dots = [];
foreach ($product['attributes'] ?? [] as $attr) {
  foreach ($attr['options'] ?? [] as $o) {
    $c = bee_shop_swatch((string) ($attr['name'] ?? ''), (string) $o);
    if ($c !== '') $dots[] = ['color' => $c, 'label' => (string) $o];
  }
  if ($dots) break;
}
?>
<li class="bk-product-card<?php echo empty($product['inStock']) ? ' is-out' : ''; ?><?php echo !empty($product['price']['onSale']) ? ' is-sale' : ''; ?>">
  <a class="bk-product-card__media" href="<?php echo esc_url($product['path'] ?? '#'); ?>" aria-label="<?php echo esc_attr($product['title'] ?? ''); ?>">
    <?php echo bee_shop_img($product['image'] ?? null, 'bk-product-card__img', 'lazy', '(min-width: 1024px) 25vw, 50vw'); ?>
    <?php if (!empty($product['price']['onSale'])) : ?>
      <span class="bk-badge bk-badge--sale"><?php echo esc_html(bee_shop_t('Sale')); ?></span>
    <?php elseif (empty($product['inStock'])) : ?>
      <span class="bk-badge bk-badge--out"><?php echo esc_html(bee_shop_t('Sold out')); ?></span>
    <?php endif; ?>
  </a>
  <div class="bk-product-card__body">
    <div class="bk-product-card__info">
      <?php if ($categories && !empty($GLOBALS['__bk_fields']['shop']['show_categories'])) : ?>
        <p class="bk-product-card__cat"><a href="<?php echo esc_url($categories[0]['path'] ?? '#'); ?>"><?php echo esc_html($categories[0]['name'] ?? ''); ?></a></p>
      <?php endif; ?>
      <h3 class="bk-product-card__title"><a href="<?php echo esc_url($product['path'] ?? '#'); ?>"><?php echo esc_html($product['title'] ?? ''); ?></a></h3>
      <?php echo bee_price_html($product['price'] ?? null, 'bk-price bk-product-card__price'); ?>
      <?php if ($dots) : ?>
        <ul class="bk-product-card__dots" aria-label="<?php echo esc_attr(implode(', ', array_column($dots, 'label'))); ?>">
          <?php foreach (array_slice($dots, 0, 5) as $dot) : ?><li style="--swatch: <?php echo esc_attr($dot['color']); ?>" title="<?php echo esc_attr($dot['label']); ?>"></li><?php endforeach; ?>
          <?php if (count($dots) > 5) : ?><li class="is-more">+<?php echo count($dots) - 5; ?></li><?php endif; ?>
        </ul>
      <?php endif; ?>
    </div>
    <div class="bk-product-card__actions">
      <?php if ($canBuy) : ?>
        <form class="bk-add-form" data-shop-add method="post" action="<?php echo esc_url($product['path'] ?? '#'); ?>">
          <input type="hidden" name="productId" value="<?php echo esc_attr($product['id'] ?? ''); ?>">
          <input type="hidden" name="qty" value="1">
          <button type="submit" class="bk-product-card__btn" title="<?php echo esc_attr(bee_shop_t('Add to cart')); ?>"><?php echo bee_shop_icon('cart'); ?><span class="bk-visually-hidden"><?php echo esc_html(sprintf(bee_shop_t('Add %s to cart'), $product['title'] ?? '')); ?></span></button>
        </form>
      <?php else : ?>
        <a class="bk-product-card__btn is-ghost" href="<?php echo esc_url($product['path'] ?? '#'); ?>" title="<?php echo esc_attr($isVariable && !empty($product['inStock']) ? bee_shop_t('Select options') : bee_shop_t('View product')); ?>"><?php echo bee_shop_icon('chevron'); ?><span class="bk-visually-hidden"><?php echo esc_html(($isVariable && !empty($product['inStock']) ? bee_shop_t('Select options') : bee_shop_t('View product')) . ': ' . ($product['title'] ?? '')); ?></span></a>
      <?php endif; ?>
    </div>
  </div>
</li>
