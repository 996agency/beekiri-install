<?php
/**
 * My account. Data: account_page {section, customer|null, nav[], orders{items[], total, …},
 * pagination, order (same shape as order-received), countries[], allow_registration, token}.
 * Sections: dashboard, orders, order, addresses, details (signed in) · login, register,
 * forgot, reset, verify (signed out). Forms are handled by script.js ([data-account-form]).
 */
$shop = get_bee_field('shop') ?: [];
$a = get_bee_field('account_page') ?: [];
$section = (string) ($a['section'] ?? 'login');
$me = $a['customer'] ?? null;
$base = $shop['account_path'] ?? '/account';
$orders = $a['orders']['items'] ?? [];
$countries = $a['countries'] ?? [];

$orderRow = function (array $o) {
  ?>
  <li class="bk-acct-order">
    <a class="bk-acct-order__link" href="<?php echo esc_url($o['path']); ?>">
      <div class="bk-acct-order__thumbs" aria-hidden="true">
        <?php foreach (array_slice($o['items'] ?? [], 0, 3) as $it) echo bee_shop_img(['url' => $it['imageUrl'] ?? '', 'alt' => ''], 'bk-acct-order__thumb'); ?>
      </div>
      <div class="bk-acct-order__main">
        <div class="bk-acct-order__top">
          <strong><?php echo esc_html(bee_shop_t('Order')); ?> <?php echo esc_html($o['numberLabel']); ?></strong>
          <span class="bk-acct-order__date"><?php echo esc_html(date('j M Y', strtotime($o['placedAt']))); ?></span>
        </div>
        <?php bee_shop_partial('tracking', ['tracking' => $o['tracking'] ?? null, 'compact' => true]); ?>
        <div class="bk-acct-order__meta">
          <span><?php echo esc_html(sprintf((int) $o['itemCount'] === 1 ? bee_shop_t('%d item') : bee_shop_t('%d items'), (int) $o['itemCount'])); ?></span>
          <span><?php echo esc_html($o['total']); ?></span>
        </div>
      </div>
      <span class="bk-acct-order__go" aria-hidden="true"><?php echo bee_shop_icon('chevron'); ?></span>
    </a>
  </li>
  <?php
};

$addressForm = function (string $prefix, array $values) use ($countries) {
  $v = fn($k) => esc_attr($values[$k] ?? '');
  ?>
  <div class="bk-form-grid">
    <div class="bk-field is-half"><label for="<?php echo $prefix; ?>-firstName"><?php echo esc_html(bee_shop_t('First name')); ?></label><input id="<?php echo $prefix; ?>-firstName" name="<?php echo $prefix; ?>.firstName" value="<?php echo $v('firstName'); ?>" autocomplete="given-name"></div>
    <div class="bk-field is-half"><label for="<?php echo $prefix; ?>-lastName"><?php echo esc_html(bee_shop_t('Last name')); ?></label><input id="<?php echo $prefix; ?>-lastName" name="<?php echo $prefix; ?>.lastName" value="<?php echo $v('lastName'); ?>" autocomplete="family-name"></div>
    <div class="bk-field"><label for="<?php echo $prefix; ?>-company"><?php echo esc_html(bee_shop_t('Company name')); ?> <span class="bk-opt">(<?php echo esc_html(bee_shop_t('optional')); ?>)</span></label><input id="<?php echo $prefix; ?>-company" name="<?php echo $prefix; ?>.company" value="<?php echo $v('company'); ?>" autocomplete="organization"></div>
    <div class="bk-field"><label for="<?php echo $prefix; ?>-country"><?php echo esc_html(bee_shop_t('Country / Region')); ?></label>
      <select id="<?php echo $prefix; ?>-country" name="<?php echo $prefix; ?>.country" autocomplete="country">
        <option value=""><?php echo esc_html(bee_shop_t('Select a country')); ?></option>
        <?php foreach ($countries as $c) : ?><option value="<?php echo esc_attr($c['code']); ?>"<?php echo ($values['country'] ?? '') === $c['code'] ? ' selected' : ''; ?>><?php echo esc_html($c['name']); ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="bk-field"><label for="<?php echo $prefix; ?>-line1"><?php echo esc_html(bee_shop_t('Street address')); ?></label><input id="<?php echo $prefix; ?>-line1" name="<?php echo $prefix; ?>.line1" value="<?php echo $v('line1'); ?>" autocomplete="address-line1" placeholder="<?php echo esc_attr(bee_shop_t('House number and street name')); ?>"></div>
    <div class="bk-field"><label class="bk-visually-hidden" for="<?php echo $prefix; ?>-line2"><?php echo esc_html(bee_shop_t('Apartment, suite, unit, etc.')); ?></label><input id="<?php echo $prefix; ?>-line2" name="<?php echo $prefix; ?>.line2" value="<?php echo $v('line2'); ?>" autocomplete="address-line2" placeholder="<?php echo esc_attr(bee_shop_t('Apartment, suite, unit, etc. (optional)')); ?>"></div>
    <div class="bk-field is-half"><label for="<?php echo $prefix; ?>-postcode"><?php echo esc_html(bee_shop_t('Postcode / ZIP')); ?></label><input id="<?php echo $prefix; ?>-postcode" name="<?php echo $prefix; ?>.postcode" value="<?php echo $v('postcode'); ?>" autocomplete="postal-code"></div>
    <div class="bk-field is-half"><label for="<?php echo $prefix; ?>-city"><?php echo esc_html(bee_shop_t('Town / City')); ?></label><input id="<?php echo $prefix; ?>-city" name="<?php echo $prefix; ?>.city" value="<?php echo $v('city'); ?>" autocomplete="address-level2"></div>
    <div class="bk-field is-half"><label for="<?php echo $prefix; ?>-state"><?php echo esc_html(bee_shop_t('State / County')); ?></label><input id="<?php echo $prefix; ?>-state" name="<?php echo $prefix; ?>.state" value="<?php echo $v('state'); ?>" autocomplete="address-level1"></div>
    <div class="bk-field is-half"><label for="<?php echo $prefix; ?>-phone"><?php echo esc_html(bee_shop_t('Phone')); ?></label><input id="<?php echo $prefix; ?>-phone" name="<?php echo $prefix; ?>.phone" type="tel" value="<?php echo $v('phone'); ?>" autocomplete="tel"></div>
  </div>
  <?php
};
$message = '<p class="bk-acct-form__msg" data-account-message role="alert" aria-live="polite"></p>';
/** One thin, single-colour icon per account section (inherits the text colour). */
$navIcon = function (string $id): string {
  $paths = [
    'dashboard' => '<rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/>',
    'orders' => '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
    'addresses' => '<path d="M12 21s-7-6.1-7-11.5a7 7 0 0 1 14 0C19 14.9 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
    'details' => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    'logout' => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/>',
  ];
  return '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($paths[$id] ?? $paths['details']) . '</svg>';
};
/** "Rimini, Italy" from a saved address, or '' when nothing is saved. */
$addressSummary = function ($addr) use ($countries): string {
  if (!is_array($addr)) return '';
  $code = (string) ($addr['country'] ?? '');
  $country = '';
  foreach ($countries as $c) if (($c['code'] ?? '') === $code) $country = $c['name'];
  // The country list is only loaded on some sections; fall back to PHP's own region names.
  if ($country === '' && $code !== '' && function_exists('locale_get_display_region')) $country = (string) locale_get_display_region('-' . $code, 'en');
  return implode(', ', array_filter([trim((string) ($addr['city'] ?? '')), $country ?: trim((string) ($addr['country'] ?? ''))]));
};
?>
<section class="bk-shop bk-shop--account" data-shop-view="account" data-account-section="<?php echo esc_attr($section); ?>">
  <div class="bk-shop__wrap">
    <?php if (!$me || $section === 'verify' || $section === 'reset') : ?>
      <!-- Signed out (and email links): sign in / register / password help / confirm email -->
      <!-- Same split card as the admin sign-in (apps/admin/src/screens/AuthShell.tsx) -->
      <div class="bk-acct-auth">
        <div class="bk-acct-auth__card">
          <aside class="bk-acct-auth__visual" aria-hidden="true">
            <div class="bk-acct-auth__glow"></div>
            <div class="bk-acct-auth__brand">
              <img src="/brand/beekiri-logo-white.svg" width="107" height="26" alt="Beekiri" decoding="async">
            </div>
            <div class="bk-acct-auth__copy">
              <p class="bk-acct-auth__visual-title"><?php echo esc_html(bee_shop_t('The Future of Web Creation.')); ?></p>
              <p class="bk-acct-auth__tagline"><?php echo esc_html(bee_shop_t('Where Ideas Take Flight.')); ?></p>
            </div>
            <div class="bk-acct-auth__proof">
              <div class="bk-acct-auth__avatars"><span>BK</span><span>Ed</span><span>Pub</span></div>
              <span class="bk-acct-auth__proof-text"><?php echo esc_html(bee_shop_t('Beekiri CMS — publish with clarity')); ?></span>
            </div>
          </aside>
          <div class="bk-acct-auth__panel">
          <?php if ($section === 'register') : ?>
            <h1 class="bk-acct-auth__title"><?php echo esc_html(bee_shop_t('Create an account')); ?></h1>
            <p class="bk-acct-auth__lead"><?php echo esc_html(bee_shop_t('Track your orders, save your addresses and check out faster.')); ?></p>
            <form class="bk-acct-form" data-account-form="register" novalidate>
              <div class="bk-form-grid">
                <div class="bk-field is-half"><label for="reg-first"><?php echo esc_html(bee_shop_t('First name')); ?></label><input id="reg-first" name="firstName" autocomplete="given-name"></div>
                <div class="bk-field is-half"><label for="reg-last"><?php echo esc_html(bee_shop_t('Last name')); ?></label><input id="reg-last" name="lastName" autocomplete="family-name"></div>
                <div class="bk-field"><label for="reg-email"><?php echo esc_html(bee_shop_t('Email address')); ?> <span class="bk-req" aria-hidden="true">*</span></label><input id="reg-email" name="email" type="email" required autocomplete="email"></div>
                <div class="bk-field"><label for="reg-pass"><?php echo esc_html(bee_shop_t('Password')); ?> <span class="bk-req" aria-hidden="true">*</span></label><input id="reg-pass" name="password" type="password" required minlength="8" autocomplete="new-password"><small class="bk-field__hint"><?php echo esc_html(bee_shop_t('At least 8 characters — mix letters, numbers and symbols.')); ?></small></div>
              </div>
              <?php echo $message; ?>
              <button type="submit" class="bk-btn bk-btn--primary bk-btn--lg bk-btn--block"><?php echo esc_html(bee_shop_t('Create account')); ?></button>
            </form>
            <p class="bk-acct-auth__switch"><?php echo esc_html(bee_shop_t('Already have an account?')); ?> <a href="<?php echo esc_url($base . '/login'); ?>"><?php echo esc_html(bee_shop_t('Sign in')); ?></a></p>

          <?php elseif ($section === 'forgot') : ?>
            <h1 class="bk-acct-auth__title"><?php echo esc_html(bee_shop_t('Forgot your password?')); ?></h1>
            <p class="bk-acct-auth__lead"><?php echo esc_html(bee_shop_t('Enter your email and we will send you a link to choose a new one.')); ?></p>
            <form class="bk-acct-form" data-account-form="forgot" novalidate>
              <div class="bk-field"><label for="fg-email"><?php echo esc_html(bee_shop_t('Email address')); ?></label><input id="fg-email" name="email" type="email" required autocomplete="email"></div>
              <?php echo $message; ?>
              <button type="submit" class="bk-btn bk-btn--primary bk-btn--lg bk-btn--block"><?php echo esc_html(bee_shop_t('Send reset link')); ?></button>
            </form>
            <p class="bk-acct-auth__switch"><a href="<?php echo esc_url($base . '/login'); ?>"><?php echo esc_html(bee_shop_t('Back to sign in')); ?></a></p>

          <?php elseif ($section === 'reset') : ?>
            <h1 class="bk-acct-auth__title"><?php echo esc_html(bee_shop_t('Choose a new password')); ?></h1>
            <form class="bk-acct-form" data-account-form="reset" novalidate>
              <input type="hidden" name="token" value="<?php echo esc_attr($a['token'] ?? ''); ?>">
              <div class="bk-field"><label for="rs-pass"><?php echo esc_html(bee_shop_t('New password')); ?></label><input id="rs-pass" name="password" type="password" required minlength="8" autocomplete="new-password"></div>
              <?php echo $message; ?>
              <button type="submit" class="bk-btn bk-btn--primary bk-btn--lg bk-btn--block"><?php echo esc_html(bee_shop_t('Save password')); ?></button>
            </form>

          <?php elseif ($section === 'verify') : ?>
            <div data-account-verify="<?php echo esc_attr($a['token'] ?? ''); ?>">
              <span class="bk-received__icon is-pending" aria-hidden="true"></span>
              <h1 class="bk-acct-auth__title" data-verify-title><?php echo esc_html(bee_shop_t('Confirming your email…')); ?></h1>
              <p class="bk-acct-auth__lead" data-verify-lead></p>
              <a class="bk-btn bk-btn--primary" href="<?php echo esc_url($base); ?>" data-verify-continue hidden><?php echo esc_html(bee_shop_t('Go to my account')); ?></a>
            </div>

          <?php else : ?>
            <h1 class="bk-acct-auth__title"><?php echo esc_html(bee_shop_t('Sign in')); ?></h1>
            <p class="bk-acct-auth__lead"><?php echo esc_html(bee_shop_t('Welcome back. Sign in to see your orders and where they are.')); ?></p>
            <form class="bk-acct-form" data-account-form="login" novalidate>
              <div class="bk-field"><label for="li-email"><?php echo esc_html(bee_shop_t('Email address')); ?></label><input id="li-email" name="email" type="email" required autocomplete="email" placeholder="you@example.com"></div>
              <div class="bk-field">
                <div class="bk-acct-auth__field-head">
                  <label for="li-pass"><?php echo esc_html(bee_shop_t('Password')); ?></label>
                  <a href="<?php echo esc_url($base . '/forgot'); ?>"><?php echo esc_html(bee_shop_t('Forgot password?')); ?></a>
                </div>
                <div class="bk-acct-auth__pw">
                  <input id="li-pass" name="password" type="password" required autocomplete="current-password" placeholder="••••••••">
                  <button type="button" class="bk-acct-auth__pw-toggle" data-pw-toggle data-show="<?php echo esc_attr(bee_shop_t('Show')); ?>" data-hide="<?php echo esc_attr(bee_shop_t('Hide')); ?>"><?php echo esc_html(bee_shop_t('Show')); ?></button>
                </div>
              </div>
              <label class="bk-check bk-acct-auth__remember"><input type="checkbox" name="remember" checked> <span><?php echo esc_html(bee_shop_t('Keep me signed in')); ?></span></label>
              <?php echo $message; ?>
              <button type="submit" class="bk-btn bk-btn--primary bk-btn--lg bk-btn--block"><?php echo esc_html(bee_shop_t('Sign in')); ?></button>
            </form>
            <?php if (!empty($a['allow_registration'])) : ?>
              <p class="bk-acct-auth__switch"><?php echo esc_html(bee_shop_t('New here?')); ?> <a href="<?php echo esc_url($base . '/register'); ?>"><?php echo esc_html(bee_shop_t('Create an account')); ?></a></p>
            <?php endif; ?>
          <?php endif; ?>
            <p class="bk-acct-auth__footer"><a href="/">&larr; <?php echo esc_html(bee_shop_t('Back to site')); ?></a></p>
          </div>
        </div>
      </div>

    <?php else : ?>
      <!-- Signed in -->
      <header class="bk-acct-head">
        <div class="bk-acct-head__avatar" aria-hidden="true"><?php echo esc_html(strtoupper(mb_substr($me['firstName'] ?: $me['email'], 0, 1))); ?></div>
        <div class="bk-acct-head__text">
          <h1 class="bk-acct-head__name"><?php echo esc_html(sprintf(bee_shop_t('Hi, %s'), $me['firstName'] ?: $me['email'])); ?></h1>
          <p class="bk-acct-head__email"><?php echo esc_html($me['email']); ?></p>
        </div>
      </header>

      <?php if (!empty($me['staff'])) : ?>
        <p class="bk-acct-staff" role="status"><?php echo esc_html(bee_shop_t('Signed in with your Beekiri admin account. Your password and sign-out are managed in the admin.')); ?></p>
      <?php endif; ?>

      <?php if (empty($me['verified'])) : ?>
        <div class="bk-shop-notice is-info bk-acct-verify" role="status">
          <span><?php echo esc_html(sprintf(bee_shop_t('We sent a confirmation link to %s. Confirm your email to see your orders and saved addresses.'), $me['email'])); ?></span>
          <button type="button" class="bk-link-btn" data-account-resend><?php echo esc_html(bee_shop_t('Send it again')); ?></button>
        </div>
      <?php endif; ?>

      <div class="bk-acct">
        <nav class="bk-acct__nav" aria-label="<?php echo esc_attr(bee_shop_t('Account')); ?>">
          <ul>
            <?php foreach ($a['nav'] ?? [] as $item) :
              $active = $item['id'] === $section || ($section === 'order' && $item['id'] === 'orders'); ?>
              <li><a href="<?php echo esc_url($item['url']); ?>" class="<?php echo $active ? 'is-active' : ''; ?>"<?php echo $active ? ' aria-current="page"' : ''; ?>><?php echo $navIcon((string) $item['id']); ?><span><?php echo esc_html(bee_shop_t($item['label'])); ?></span></a></li>
            <?php endforeach; ?>
            <?php if (empty($me['staff'])) : ?>
              <li><button type="button" class="bk-acct__logout" data-account-logout><?php echo $navIcon('logout'); ?><span><?php echo esc_html(bee_shop_t('Sign out')); ?></span></button></li>
            <?php endif; ?>
          </ul>
        </nav>

        <div class="bk-acct__main">
          <?php if ($section === 'dashboard') : ?>
            <?php $count = (int) ($me['ordersCount'] ?? 0); $where = $addressSummary($me['shipping'] ?? null) ?: $addressSummary($me['billing'] ?? null); ?>
            <dl class="bk-acct-overview">
              <div class="bk-acct-overview__item">
                <dt><?php echo $navIcon('orders'); ?><?php echo esc_html(bee_shop_t('Orders')); ?></dt>
                <dd><?php echo esc_html(sprintf($count === 1 ? bee_shop_t('%d order') : bee_shop_t('%d orders'), $count)); ?></dd>
                <dd><a href="<?php echo esc_url($base . '/orders'); ?>"><?php echo esc_html(bee_shop_t('View orders')); ?></a></dd>
              </div>
              <div class="bk-acct-overview__item">
                <dt><?php echo $navIcon('addresses'); ?><?php echo esc_html(bee_shop_t('Address')); ?></dt>
                <dd<?php echo $where === '' ? ' class="is-empty"' : ''; ?>><?php echo esc_html($where !== '' ? $where : bee_shop_t('Not saved yet')); ?></dd>
                <dd><a href="<?php echo esc_url($base . '/addresses'); ?>"><?php echo esc_html($where !== '' ? bee_shop_t('Manage addresses') : bee_shop_t('Add an address')); ?></a></dd>
              </div>
              <div class="bk-acct-overview__item">
                <dt><?php echo $navIcon('details'); ?><?php echo esc_html(bee_shop_t('Account')); ?></dt>
                <dd><?php echo esc_html(trim(($me['firstName'] ?? '') . ' ' . ($me['lastName'] ?? '')) ?: $me['email']); ?></dd>
                <dd><a href="<?php echo esc_url($base . '/details'); ?>"><?php echo esc_html(bee_shop_t('Edit details')); ?></a></dd>
              </div>
            </dl>
            <h2 class="bk-acct__title"><?php echo esc_html(bee_shop_t('Recent orders')); ?></h2>
            <?php if ($orders) : ?>
              <ul class="bk-acct-orders"><?php foreach ($orders as $o) $orderRow($o); ?></ul>
              <p class="bk-acct-more"><a href="<?php echo esc_url($base . '/orders'); ?>"><?php echo esc_html(bee_shop_t('View all orders')); ?> →</a></p>
            <?php else : ?>
              <div class="bk-shop__empty"><p><?php echo esc_html(empty($me['verified']) ? bee_shop_t('Your orders appear here once your email is confirmed.') : bee_shop_t('No orders yet.')); ?></p><a class="bk-btn bk-btn--primary" href="<?php echo esc_url($shop['path'] ?? '/shop'); ?>"><?php echo esc_html(bee_shop_t('Start shopping')); ?></a></div>
            <?php endif; ?>

          <?php elseif ($section === 'orders') : ?>
            <h2 class="bk-acct__title"><?php echo esc_html(bee_shop_t('Orders')); ?></h2>
            <?php if ($orders) : ?>
              <ul class="bk-acct-orders"><?php foreach ($orders as $o) $orderRow($o); ?></ul>
              <?php bee_shop_partial('pagination', ['pagination' => $a['pagination'] ?? []]); ?>
            <?php else : ?>
              <div class="bk-shop__empty"><p><?php echo esc_html(empty($me['verified']) ? bee_shop_t('Your orders appear here once your email is confirmed.') : bee_shop_t('No orders yet.')); ?></p></div>
            <?php endif; ?>

          <?php elseif ($section === 'order' && !empty($a['order'])) : $o = $a['order']; $t = $o['totals'] ?? []; ?>
            <p class="bk-acct-back"><a href="<?php echo esc_url($base . '/orders'); ?>">← <?php echo esc_html(bee_shop_t('All orders')); ?></a></p>
            <div class="bk-acct-order-head">
              <h2 class="bk-acct__title"><?php echo esc_html(bee_shop_t('Order')); ?> <?php echo esc_html($o['numberLabel']); ?></h2>
              <span class="bk-muted"><?php echo esc_html(sprintf(bee_shop_t('Placed %s'), date('j F Y', strtotime($o['placedAt'])))); ?> · <?php echo esc_html($o['paymentMethodTitle']); ?></span>
            </div>
            <?php bee_shop_partial('tracking', ['tracking' => $o['tracking'] ?? null]); ?>
            <table class="bk-review bk-review--received">
              <thead><tr><th scope="col"><?php echo esc_html(bee_shop_t('Product')); ?></th><th scope="col" class="is-right"><?php echo esc_html(bee_shop_t('Total')); ?></th></tr></thead>
              <tbody>
                <?php foreach ($o['items'] ?? [] as $item) : ?>
                  <tr><td class="bk-review__item"><?php echo bee_shop_img(['url' => $item['imageUrl'] ?? '', 'alt' => ''], 'bk-review__img'); ?><div><strong><?php echo esc_html($item['name']); ?></strong> <span class="bk-review__qty">× <?php echo (int) $item['qty']; ?></span><?php if (!empty($item['attributes'])) : ?><small><?php echo esc_html(bee_shop_attrs_text($item['attributes'])); ?></small><?php endif; ?></div></td><td class="is-right"><?php echo esc_html($item['formatted']['total'] ?? ''); ?></td></tr>
                <?php endforeach; ?>
              </tbody>
              <tfoot>
                <tr><th scope="row"><?php echo esc_html(bee_shop_t('Subtotal')); ?></th><td class="is-right"><?php echo esc_html($t['subtotal'] ?? ''); ?></td></tr>
                <?php if (!empty($t['discountTotal'])) : ?><tr><th scope="row"><?php echo esc_html(bee_shop_t('Discount')); ?></th><td class="is-right"><?php echo esc_html($t['discountTotal']); ?></td></tr><?php endif; ?>
                <?php if (!empty($t['shippingTotal'])) : ?><tr><th scope="row"><?php echo esc_html(bee_shop_t('Shipping')); ?><?php echo !empty($o['shippingMethodTitle']) ? ' (' . esc_html($o['shippingMethodTitle']) . ')' : ''; ?></th><td class="is-right"><?php echo esc_html($t['shippingTotal']); ?></td></tr><?php endif; ?>
                <?php if (!empty($t['taxTotal'])) : ?><tr><th scope="row"><?php echo esc_html(!empty($t['taxIncluded']) ? bee_shop_t('Includes tax') : bee_shop_t('Tax')); ?></th><td class="is-right"><?php echo esc_html($t['taxTotal']); ?></td></tr><?php endif; ?>
                <tr class="is-total"><th scope="row"><?php echo esc_html(bee_shop_t('Total')); ?></th><td class="is-right"><?php echo esc_html($t['total'] ?? ''); ?></td></tr>
                <?php if (!empty($t['refundedTotal'])) : ?><tr><th scope="row"><?php echo esc_html(bee_shop_t('Refunded')); ?></th><td class="is-right">−<?php echo esc_html($t['refundedTotal']); ?></td></tr><?php endif; ?>
              </tfoot>
            </table>
            <div class="bk-received__addresses">
              <?php if (!empty($o['billingLines'])) : ?><section><h2><?php echo esc_html(bee_shop_t('Billing address')); ?></h2><?php echo bee_shop_address_html($o['billingLines']); ?></section><?php endif; ?>
              <?php if (!empty($o['shippingLines'])) : ?><section><h2><?php echo esc_html(bee_shop_t('Shipping address')); ?></h2><?php echo bee_shop_address_html($o['shippingLines']); ?></section><?php endif; ?>
            </div>

          <?php elseif ($section === 'addresses') : ?>
            <h2 class="bk-acct__title"><?php echo esc_html(bee_shop_t('Addresses')); ?></h2>
            <?php if (empty($me['verified'])) : ?>
              <p class="bk-muted"><?php echo esc_html(bee_shop_t('Confirm your email address to save addresses.')); ?></p>
            <?php else : ?>
              <p class="bk-muted"><?php echo esc_html(bee_shop_t('These are filled in for you at checkout.')); ?></p>
              <form class="bk-acct-form" data-account-form="addresses" novalidate>
                <div class="bk-acct-addresses">
                  <fieldset><legend><?php echo esc_html(bee_shop_t('Billing address')); ?></legend><?php $addressForm('billing', $me['billing'] ?? []); ?></fieldset>
                  <fieldset><legend><?php echo esc_html(bee_shop_t('Shipping address')); ?></legend><?php $addressForm('shipping', $me['shipping'] ?? []); ?></fieldset>
                </div>
                <?php echo $message; ?>
                <button type="submit" class="bk-btn bk-btn--primary"><?php echo esc_html(bee_shop_t('Save addresses')); ?></button>
              </form>
            <?php endif; ?>

          <?php elseif ($section === 'details') : ?>
            <h2 class="bk-acct__title"><?php echo esc_html(bee_shop_t('Account details')); ?></h2>
            <form class="bk-acct-form bk-acct-form--narrow" data-account-form="details" novalidate>
              <div class="bk-form-grid">
                <div class="bk-field is-half"><label for="ad-first"><?php echo esc_html(bee_shop_t('First name')); ?></label><input id="ad-first" name="firstName" value="<?php echo esc_attr($me['firstName'] ?? ''); ?>" autocomplete="given-name"></div>
                <div class="bk-field is-half"><label for="ad-last"><?php echo esc_html(bee_shop_t('Last name')); ?></label><input id="ad-last" name="lastName" value="<?php echo esc_attr($me['lastName'] ?? ''); ?>" autocomplete="family-name"></div>
                <div class="bk-field"><label for="ad-email"><?php echo esc_html(bee_shop_t('Email address')); ?></label><input id="ad-email" value="<?php echo esc_attr($me['email'] ?? ''); ?>" disabled></div>
                <div class="bk-field"><label for="ad-phone"><?php echo esc_html(bee_shop_t('Phone')); ?></label><input id="ad-phone" name="phone" type="tel" value="<?php echo esc_attr($me['phone'] ?? ''); ?>" autocomplete="tel"></div>
              </div>
              <?php echo $message; ?>
              <button type="submit" class="bk-btn bk-btn--primary"><?php echo esc_html(bee_shop_t('Save details')); ?></button>
            </form>
            <?php if (empty($me['staff'])) : ?>
            <h3 class="bk-acct__subtitle"><?php echo esc_html(bee_shop_t('Change password')); ?></h3>
            <form class="bk-acct-form bk-acct-form--narrow" data-account-form="password" novalidate>
              <div class="bk-field"><label for="pw-current"><?php echo esc_html(bee_shop_t('Current password')); ?></label><input id="pw-current" name="current" type="password" required autocomplete="current-password"></div>
              <div class="bk-field"><label for="pw-new"><?php echo esc_html(bee_shop_t('New password')); ?></label><input id="pw-new" name="password" type="password" required minlength="8" autocomplete="new-password"></div>
              <?php echo $message; ?>
              <button type="submit" class="bk-btn bk-btn--ghost"><?php echo esc_html(bee_shop_t('Change password')); ?></button>
            </form>
            <?php endif; ?>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>
  </div>
</section>
