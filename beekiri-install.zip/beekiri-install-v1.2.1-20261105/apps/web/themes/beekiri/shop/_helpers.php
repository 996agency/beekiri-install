<?php
/**
 * Beekiri Shopping — helpers available in every shop template.
 *
 * Loaded by the server before shop/{view}.php runs. Templates receive their data
 * through get_bee_field() (same API as layouts); these helpers only format it.
 * Copy this file into beekiri-child/shop/ to extend it — the child copy wins.
 */

if (!function_exists('bee_shop_partial')) {
  /** Include shop/partials/{name}.php from the child theme first, then Beekiri. */
  function bee_shop_partial(string $name, array $vars = []): void {
    $dirs = $GLOBALS['__bk_fields']['__shop_dirs'] ?? [];
    foreach ($dirs as $dir) {
      $file = rtrim((string) $dir, '/') . '/partials/' . basename($name) . '.php';
      if (is_file($file)) {
        extract($vars, EXTR_SKIP);
        include $file;
        return;
      }
    }
  }
}

if (!function_exists('bee_shop_t')) {
  /** Translatable storefront string (Settings → Translation picks these up). */
  function bee_shop_t(string $text): string {
    return function_exists('__') ? __($text) : $text;
  }
}

if (!function_exists('bee_price_html')) {
  /** Price markup from a product/variant `price` array (null → "Price on request"). */
  function bee_price_html($price, string $class = 'bk-price'): string {
    if (!is_array($price) || !isset($price['formatted'])) {
      return '<span class="' . esc_attr($class) . ' is-empty">' . esc_html(bee_shop_t('Price on request')) . '</span>';
    }
    $onSale = !empty($price['onSale']) && !empty($price['regularFormatted']);
    $range = isset($price['min'], $price['max']) && $price['min'] !== $price['max'];
    if ($onSale && !$range) {
      return '<span class="' . esc_attr($class) . ' is-sale"><del aria-hidden="true">' . esc_html($price['regularFormatted']) . '</del> <ins>' . esc_html($price['formatted']) . '</ins>'
        . '<span class="bk-visually-hidden">' . esc_html(bee_shop_t('Sale price')) . '</span></span>';
    }
    $text = $range && !empty($price['rangeFormatted']) ? $price['rangeFormatted'] : $price['formatted'];
    return '<span class="' . esc_attr($class) . ($range ? ' is-range' : '') . '">' . esc_html($text) . '</span>';
  }
}

if (!function_exists('bee_stock_html')) {
  /** Stock line for a product array. */
  function bee_stock_html(array $product): string {
    if (empty($product['inStock'])) {
      return '<p class="bk-stock is-out">' . esc_html(bee_shop_t('Out of stock')) . '</p>';
    }
    if (($product['stockStatus'] ?? '') === 'onbackorder') {
      return '<p class="bk-stock is-backorder">' . esc_html(bee_shop_t('Available on backorder')) . '</p>';
    }
    if (isset($product['stockQty']) && $product['stockQty'] !== null) {
      return '<p class="bk-stock is-in">' . esc_html(sprintf(bee_shop_t('%d in stock'), (int) $product['stockQty'])) . '</p>';
    }
    return '<p class="bk-stock is-in">' . esc_html(bee_shop_t('In stock')) . '</p>';
  }
}

if (!function_exists('bee_shop_img')) {
  /** <img> for a media array ({url, alt, width, height}); a placeholder when empty. */
  function bee_shop_img($image, string $class = '', string $loading = 'lazy', string $sizes = ''): string {
    if (!is_array($image) || empty($image['url'])) {
      return '<span class="bk-shop-placeholder ' . esc_attr($class) . '" aria-hidden="true">'
        . '<svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>'
        . '</span>';
    }
    $attrs = ' src="' . esc_url($image['url']) . '" alt="' . esc_attr($image['alt'] ?? '') . '" loading="' . esc_attr($loading) . '" decoding="async"';
    if (!empty($image['width']) && !empty($image['height'])) {
      $attrs .= ' width="' . (int) $image['width'] . '" height="' . (int) $image['height'] . '"';
    }
    if ($class !== '') $attrs .= ' class="' . esc_attr($class) . '"';
    if ($sizes !== '') $attrs .= ' sizes="' . esc_attr($sizes) . '"';
    return '<img' . $attrs . '>';
  }
}

if (!function_exists('bee_shop_attrs_text')) {
  /** "Size: M, Colour: Red" from an attributes map. */
  function bee_shop_attrs_text($attributes): string {
    if (!is_array($attributes) || !$attributes) return '';
    $parts = [];
    foreach ($attributes as $k => $v) {
      $parts[] = $k . ': ' . $v;
    }
    return implode(', ', $parts);
  }
}

if (!function_exists('bee_shop_address_html')) {
  /** Address lines (already formatted by the server) as a <address>. */
  function bee_shop_address_html($lines): string {
    if (!is_array($lines) || !$lines) return '';
    return '<address class="bk-shop-address">' . implode('<br>', array_map('esc_html', $lines)) . '</address>';
  }
}

if (!function_exists('bee_shop_icon')) {
  /** Inline SVG icons used by the shop templates. */
  function bee_shop_icon(string $name): string {
    $icons = [
      'cart' => '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>',
      'check' => '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>',
      'trash' => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
      'chevron' => '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>',
      'lock' => '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
      'search' => '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>',
    ];
    return $icons[$name] ?? '';
  }
}

if (!function_exists('bee_shop_breadcrumbs')) {
  /** <nav> breadcrumbs from [{label, url}] rows. */
  function bee_shop_breadcrumbs(array $items): string {
    if (!$items) return '';
    $html = '<nav class="bk-shop-crumbs" aria-label="' . esc_attr(bee_shop_t('Breadcrumb')) . '"><ol>';
    $html .= '<li><a href="/">' . esc_html(bee_shop_t('Home')) . '</a></li>';
    $last = count($items) - 1;
    foreach ($items as $i => $item) {
      $label = esc_html($item['label'] ?? '');
      if ($i === $last) $html .= '<li aria-current="page">' . $label . '</li>';
      else $html .= '<li><a href="' . esc_url($item['url'] ?? '#') . '">' . $label . '</a></li>';
    }
    return $html . '</ol></nav>';
  }
}

if (!function_exists('bee_shop_swatch')) {
  /**
   * CSS colour for a colour/finish option, or '' when it should stay a text label.
   * Accepts hex codes, CSS colour names and common wood finishes (oak, walnut, …).
   */
  function bee_shop_swatch(string $attr, string $value): string {
    static $css = null;
    $wood = ['natural' => '#e3c29b', 'oak' => '#c8945e', 'walnut' => '#6b4428', 'ebony' => '#2b2320', 'ash' => '#d9c3a1', 'maple' => '#e6c89a', 'cherry' => '#9b4a2c', 'teak' => '#a8743f', 'beech' => '#d7a77a', 'pine' => '#e2bf86', 'mahogany' => '#6e2f1f'];
    $css ??= array_flip(explode(' ', 'aliceblue antiquewhite aqua aquamarine azure beige bisque black blanchedalmond blue blueviolet brown burlywood cadetblue chartreuse chocolate coral cornflowerblue cornsilk crimson cyan darkblue darkcyan darkgoldenrod darkgray darkgreen darkgrey darkkhaki darkmagenta darkolivegreen darkorange darkorchid darkred darksalmon darkseagreen darkslateblue darkslategray darkslategrey darkturquoise darkviolet deeppink deepskyblue dimgray dimgrey dodgerblue firebrick floralwhite forestgreen fuchsia gainsboro ghostwhite gold goldenrod gray green greenyellow grey honeydew hotpink indianred indigo ivory khaki lavender lavenderblush lawngreen lemonchiffon lightblue lightcoral lightcyan lightgoldenrodyellow lightgray lightgreen lightgrey lightpink lightsalmon lightseagreen lightskyblue lightslategray lightslategrey lightsteelblue lightyellow lime limegreen linen magenta maroon mediumaquamarine mediumblue mediumorchid mediumpurple mediumseagreen mediumslateblue mediumspringgreen mediumturquoise mediumvioletred midnightblue mintcream mistyrose moccasin navajowhite navy oldlace olive olivedrab orange orangered orchid palegoldenrod palegreen paleturquoise palevioletred papayawhip peachpuff peru pink plum powderblue purple rebeccapurple red rosybrown royalblue saddlebrown salmon sandybrown seagreen seashell sienna silver skyblue slateblue slategray slategrey snow springgreen steelblue tan teal thistle tomato turquoise violet wheat white whitesmoke yellow yellowgreen'));
    if (!preg_match('/colou?r|finish|wood/i', $attr)) return '';
    $v = strtolower(trim($value));
    if (isset($wood[$v])) return $wood[$v];
    $name = str_replace(' ', '', $v);
    return preg_match('/^#([0-9a-f]{3}|[0-9a-f]{6})$/', $v) || isset($css[$name]) ? $name : '';
  }
}
