<?php
/**
 * Beekiri theme header (PHP frontend) — same markup as header.tsx.
 *
 * Fields: githubUrl, showSearch, showGithub (header.meta.json)
 * Site:   site_title, home_url, menu (rows: label, url, children)
 * Behaviour (search ⌘K, mobile menu, active link) lives in script.js.
 */

$site_title  = get_bee_field('site_title') ?: 'Beekiri';
$home_url    = get_bee_field('home_url') ?: '/';
$logo_url    = get_bee_field('logo_url') ?: '/icon-512.png';
$github_url  = get_bee_field('githubUrl');
$show_search = get_bee_field('showSearch') !== false;
$show_github = get_bee_field('showGithub') !== false && !empty($github_url);

$menu = get_bee_field('menu');
if (!is_array($menu) || !$menu) {
  $menu = [
    ['id' => 'features', 'label' => 'Features', 'url' => '/#features', 'children' => []],
    ['id' => 'testimonials', 'label' => 'Testimonials', 'url' => '/#testimonials', 'children' => []],
    ['id' => 'faq', 'label' => 'FAQ', 'url' => '/#faq', 'children' => []],
    ['id' => 'contact', 'label' => 'Contact', 'url' => '/contact', 'children' => []],
  ];
}
$links = array_slice($menu, 0, 8);

/** Published pages/posts from the API (not only nav menu items). */
$search_pages = get_bee_field('search_pages');
$searchable = [];
$seen_urls = [];
$push_search = function ($label, $url) use (&$searchable, &$seen_urls) {
  $label = is_string($label) ? trim($label) : '';
  $url = is_string($url) ? trim($url) : '';
  if ($label === '' || $url === '') return;
  if (isset($seen_urls[$url])) return;
  $seen_urls[$url] = true;
  $searchable[] = ['label' => $label, 'url' => $url];
};
if (is_array($search_pages)) {
  foreach ($search_pages as $row) {
    if (!is_array($row)) continue;
    $push_search($row['label'] ?? '', $row['url'] ?? '');
  }
}
if (!$searchable) {
  $flatten = function (array $items) use (&$flatten, $push_search) {
    foreach ($items as $item) {
      if (!is_array($item)) continue;
      $push_search($item['label'] ?? '', $item['url'] ?? '/');
      if (!empty($item['children']) && is_array($item['children'])) $flatten($item['children']);
    }
  };
  $flatten($menu);
}

/** Nested menu: dropdowns on desktop (hover / keyboard focus), indented lists on mobile. */
$render_menu = function (array $items, int $depth = 0) use (&$render_menu) {
  foreach ($items as $item) {
    if (!is_array($item)) continue;
    $kids = (!empty($item['children']) && is_array($item['children']) && $depth < 2) ? $item['children'] : [];
    $cls = $kids ? ' class="has-children"' : '';
    echo '<li' . $cls . '>';
    echo '<a href="' . esc_url($item['url'] ?? '/') . '"' . ($kids ? ' aria-haspopup="true"' : '') . '>' . esc_html($item['label'] ?? '');
    if ($kids) {
      echo $depth === 0
        ? '<svg class="bk-nav__caret" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>'
        : '<svg class="bk-nav__caret" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>';
    }
    echo '</a>';
    if ($kids) {
      echo '<ul class="bk-nav__dropdown' . ($depth > 0 ? ' is-sub' : '') . '">';
      $render_menu($kids, $depth + 1);
      echo '</ul>';
    }
    echo '</li>';
  }
};

$icon_search = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>';

/** Shopping extension: cart link with a live count (script.js fills [data-bk-cart-count]). */
$shop = get_bee_field('shop');
$shop_active = is_array($shop) && !empty($shop['active']);
$cart_url = is_array($shop) ? ($shop['cart_path'] ?? '/cart') : '/cart';
$accounts_on = is_array($shop) && !empty($shop['accounts_enabled']);
$account_url = is_array($shop) ? ($shop['account_path'] ?? '/account') : '/account';
$icon_user = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>';
$icon_cart = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>';
?>
<header class="bk-nav" aria-label="Main" data-theme-header="header">
  <div class="bk-nav__bar">
    <a class="bk-nav__brand" href="<?php echo esc_url($home_url); ?>">
      <span class="bk-nav__mark" aria-hidden="true">
        <img src="<?php echo esc_url($logo_url); ?>" alt="" width="28" height="28" decoding="async" />
      </span>
      <span class="bk-nav__wordmark"><?php echo esc_html($site_title); ?></span>
    </a>

    <nav class="bk-nav__links" aria-label="Primary">
      <ul>
        <?php $render_menu($links); ?>
      </ul>
    </nav>

    <div class="bk-nav__actions">
      <?php if ($show_search) : ?>
        <button type="button" class="bk-nav__icon-btn bk-nav__search-mobile" aria-label="Open Search" data-bk-search-open>
          <?php echo $icon_search; ?>
        </button>
        <button type="button" class="bk-nav__search" data-search-full="" data-bk-search-open>
          <?php echo $icon_search; ?>
          <span>Search</span>
          <span class="bk-nav__kbds" aria-hidden="true"><kbd>⌘</kbd><kbd>K</kbd></span>
        </button>
      <?php endif; ?>

      <?php if ($show_github) : ?>
        <a class="bk-nav__icon-btn bk-nav__github" href="<?php echo esc_url($github_url); ?>" target="_blank" rel="noreferrer noopener" aria-label="GitHub">
          <svg role="img" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/></svg>
        </a>
      <?php endif; ?>

      <?php echo bee_language_switcher(['id' => 'bk-nav-lang']); ?>

      <?php if ($shop_active && $accounts_on) : ?>
        <a class="bk-nav__icon-btn bk-nav__account" href="<?php echo esc_url($account_url); ?>" aria-label="My account" data-bk-account-link>
          <?php echo $icon_user; ?>
          <span class="bk-nav__account-name" data-bk-account-name hidden></span>
        </a>
      <?php endif; ?>
      <?php if ($shop_active) : ?>
        <a class="bk-nav__icon-btn bk-nav__cart" href="<?php echo esc_url($cart_url); ?>" aria-label="Bag" aria-haspopup="dialog" aria-expanded="false" data-bk-bag data-checkout="<?php echo esc_url(is_array($shop) ? ($shop['checkout_path'] ?? '/checkout') : '/checkout'); ?>" data-shop="<?php echo esc_url(is_array($shop) ? ($shop['shop_path'] ?? '/shop') : '/shop'); ?>"<?php echo $accounts_on ? ' data-account="' . esc_url($account_url) . '"' : ''; ?>>
          <?php echo $icon_cart; ?>
          <span class="bk-nav__cart-count" data-bk-cart-count hidden>0</span>
        </a>
      <?php endif; ?>

      <button type="button" class="bk-nav__icon-btn bk-nav__menu-toggle" aria-label="Menu" aria-expanded="false" data-bk-menu-toggle>
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>
      </button>
    </div>
  </div>

  <div class="bk-nav__mobile" data-bk-menu hidden>
    <ul>
      <?php $render_menu($links); ?>
    </ul>
  </div>
</header>

<?php if ($show_search) : ?>
<div class="bk-search" role="dialog" aria-modal="true" aria-labelledby="bk-search-input" data-bk-search hidden>
  <form class="bk-search__panel" data-bk-search-form>
    <div class="bk-search__head">
      <?php echo $icon_search; ?>
      <input id="bk-search-input" type="search" placeholder="Search pages…" autocomplete="off" data-bk-search-input />
      <kbd>esc</kbd>
    </div>
    <ul class="bk-search__results">
      <?php foreach ($searchable as $item) : ?>
        <li data-bk-search-item data-q="<?php echo esc_attr(strtolower(($item['label'] ?? '') . ' ' . ($item['url'] ?? ''))); ?>">
          <a href="<?php echo esc_url($item['url'] ?? '/'); ?>">
            <span><?php echo esc_html($item['label'] ?? ''); ?></span>
            <code><?php echo esc_html($item['url'] ?? '/'); ?></code>
          </a>
        </li>
      <?php endforeach; ?>
      <li class="bk-search__empty" data-bk-search-empty hidden>No matches</li>
    </ul>
  </form>
</div>
<?php endif; ?>
