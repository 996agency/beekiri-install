(function () {
 if (window.__bkSiteNav) return;
 window.__bkSiteNav = true;
 var PASSTHROUGH = ['/api/', '/uploads/', '/_next/', '/admin/'];
 var FILE_EXT = /\.[a-z0-9]{1,8}$/i;
 var prefetched = Object.create(null);
 var busy = false;
 function routable(anchor) {
 if (!anchor || anchor.hasAttribute('download') || anchor.hasAttribute('data-bk-reload')) {
 return null;
 }
 var target = anchor.getAttribute('target');
 if (target && target !== '_self') return null;
 var raw = anchor.getAttribute('href');
 if (!raw || raw.charAt(0) === '#' || /^(mailto|tel|javascript):/i.test(raw)) return null;
 var url;
 try {
 url = new URL(anchor.href, location.href);
 } catch (e) {
 return null;
 }
 if (url.origin !== location.origin) return null;
 for (var i = 0; i < PASSTHROUGH.length; i++) {
 var p = PASSTHROUGH[i];
 if (url.pathname === p.slice(0, -1) || url.pathname.indexOf(p) === 0) return null;
 }
 if (FILE_EXT.test(url.pathname)) return null;
 if (url.hash && url.pathname === location.pathname && url.search === location.search) {
 return null;
 }
 return url.pathname + url.search + url.hash;
 }
 function prefetch(href) {
 var path = href.split('#')[0] || '/';
 if (prefetched[path]) return;
 prefetched[path] = true;
 var link = document.createElement('link');
 link.rel = 'prefetch';
 link.as = 'document';
 link.href = path;
 document.head.appendChild(link);
 }
 function adoptStyles(doc) {
 doc.head.querySelectorAll('link[rel="stylesheet"]').forEach(function (node) {
 var href = node.getAttribute('href');
 if (!href) return;
 var abs = new URL(href, location.href).href;
 var found = false;
 document.head.querySelectorAll('link[rel="stylesheet"]').forEach(function (cur) {
 if (cur.href === abs) found = true;
 });
 if (!found) document.head.appendChild(document.importNode(node, true));
 });
 // React hoists <style precedence href> into <head> as data-precedence / data-href.
 // Page rules (bk-page-*) are swapped for the new page's; anything else is added once.
 var wanted = Object.create(null);
 doc.head.querySelectorAll('style[data-href], style[href]').forEach(function (node) {
 var key = styleKey(node);
 if (key) wanted[key] = node;
 });
 var stale = [];
 document.head.querySelectorAll('style[data-href], style[href]').forEach(function (cur) {
 var key = styleKey(cur);
 if (key in wanted) delete wanted[key];
 else if (key.indexOf('bk-page-') === 0) stale.push(cur);
 });
 // New rules take the old page's slot so the cascade matches a full load.
 var anchor = stale.length
 ? stale[stale.length - 1].nextSibling
 : document.head.querySelector('[data-precedence]');
 stale.forEach(function (node) {
 node.remove();
 });
 Object.keys(wanted).forEach(function (key) {
 document.head.insertBefore(document.importNode(wanted[key], true), anchor);
 });
 }
 function styleKey(node) {
 return node.getAttribute('data-href') || node.getAttribute('href') || '';
 }
 function applyDocument(html, href, push) {
 var doc = new DOMParser().parseFromString(html, 'text/html');
 var nextShell = doc.querySelector('.bk-shell');
 var curShell = document.querySelector('.bk-shell');
 if (!nextShell || !curShell) {
 location.assign(href);
 return;
 }
 document.title = doc.title || document.title;
 var lang = doc.documentElement.getAttribute('lang');
 if (lang) document.documentElement.lang = lang;
 var theme = doc.documentElement.getAttribute('data-theme');
 if (theme) document.documentElement.setAttribute('data-theme', theme);
 adoptStyles(doc);
 curShell.replaceWith(document.importNode(nextShell, true));
 if (push) history.pushState({ bk: 1 }, '', href);
 window.dispatchEvent(
 new CustomEvent('bk:navigate', { detail: { pathname: location.pathname } }),
 );
 if (location.hash) {
 var el = document.getElementById(location.hash.slice(1));
 if (el) el.scrollIntoView();
 } else {
 window.scrollTo(0, 0);
 }
 }
 function load(href, push) {
 if (busy) return;
 busy = true;
 var path = href.split('#')[0] || '/';
 var run = function () {
 return fetch(path, {
 credentials: 'same-origin',
 headers: { Accept: 'text/html' },
 })
 .then(function (res) {
 if (!res.ok) throw new Error(String(res.status));
 var ct = res.headers.get('content-type') || '';
 if (ct.indexOf('text/html') === -1) throw new Error('not-html');
 return res.text();
 })
 .then(function (html) {
 applyDocument(html, href, push);
 })
 .catch(function () {
 if (push) location.assign(href);
 else location.reload();
 })
 .finally(function () {
 busy = false;
 });
 };
 if (push && document.startViewTransition) document.startViewTransition(run);
 else run();
 }
 // Language switcher in theme headers (bee_language_switcher): open / close its menu.
 // Capture phase, so the soft navigation below never treats the button as a link.
 function closeLanguageMenus(except) {
 document.querySelectorAll('[data-bk-langsw].is-open').forEach(function (box) {
 if (box === except) return;
 box.classList.remove('is-open');
 var b = box.querySelector('.bk-langsw__btn');
 var m = box.querySelector('.bk-langsw__menu');
 if (b) b.setAttribute('aria-expanded', 'false');
 if (m) m.hidden = true;
 });
 }
 document.addEventListener(
 'click',
 function (e) {
 var t = e.target && e.target.closest ? e.target : null;
 var btn = t && t.closest('[data-bk-langsw] .bk-langsw__btn');
 if (btn) {
 e.preventDefault();
 var box = btn.closest('[data-bk-langsw]');
 var menu = box.querySelector('.bk-langsw__menu');
 var open = !box.classList.contains('is-open');
 closeLanguageMenus(box);
 box.classList.toggle('is-open', open);
 btn.setAttribute('aria-expanded', open ? 'true' : 'false');
 if (menu) menu.hidden = !open;
 return;
 }
 if (!t || !t.closest('[data-bk-langsw]')) closeLanguageMenus(null);
 },
 true,
 );
 document.addEventListener('keydown', function (e) {
 if (e.key !== 'Escape') return;
 var open = document.querySelector('[data-bk-langsw].is-open .bk-langsw__btn');
 closeLanguageMenus(null);
 if (open) open.focus();
 });
 window.addEventListener('bk:navigate', function () {
 closeLanguageMenus(null);
 });
 // Deferred section photos (data-bk-bg): apply each one when it comes within 600px of view.
 var bgObserver = null;
 function lazyBackgrounds() {
 var els = document.querySelectorAll('[data-bk-bg]:not(.bk-bg-in)');
 if (!els.length) return;
 if (!('IntersectionObserver' in window)) {
 els.forEach(function (el) {
 el.classList.add('bk-bg-in');
 });
 return;
 }
 if (!bgObserver) {
 bgObserver = new IntersectionObserver(
 function (entries) {
 entries.forEach(function (entry) {
 if (!entry.isIntersecting) return;
 entry.target.classList.add('bk-bg-in');
 bgObserver.unobserve(entry.target);
 });
 },
 { rootMargin: '600px 0px' },
 );
 }
 els.forEach(function (el) {
 bgObserver.observe(el);
 });
 }
 // Start after the page has loaded, so these never compete with the first screen's photo.
 if (document.readyState === 'complete') lazyBackgrounds();
 else window.addEventListener('load', lazyBackgrounds, { once: true });
 window.addEventListener('bk:navigate', lazyBackgrounds);
 document.addEventListener('click', function (e) {
 if (e.defaultPrevented || e.button !== 0) return;
 if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
 var anchor = e.target && e.target.closest ? e.target.closest('a[href]') : null;
 var href = routable(anchor);
 if (!href) return;
 e.preventDefault();
 load(href, true);
 });
 document.addEventListener(
 'mouseover',
 function (e) {
 var anchor = e.target && e.target.closest ? e.target.closest('a[href]') : null;
 var href = routable(anchor);
 if (href) prefetch(href);
 },
 { passive: true },
 );
 document.addEventListener('focusin', function (e) {
 var anchor = e.target && e.target.closest ? e.target.closest('a[href]') : null;
 var href = routable(anchor);
 if (href) prefetch(href);
 });
 window.addEventListener('popstate', function () {
 load(location.pathname + location.search + location.hash, false);
 });
})();
