import { Injectable, Logger } from '@nestjs/common';
import { readFileSync, existsSync } from 'fs';
import { join } from 'path';
import { PrismaService } from '../prisma/prisma.service';

export type CoreManifest = {
  name: string;
  coreVersion: string;
  releaseRepo: string;
  minNode: string;
  channel: string;
  notes?: string;
};

export type UpdateCheck = {
  currentVersion: string;
  latestVersion: string | null;
  updateAvailable: boolean;
  updateCount: number;
  releaseUrl: string | null;
  downloadUrl: string | null;
  releaseName: string | null;
  publishedAt: string | null;
  checkedAt: string;
  source: 'github' | 'github-tags' | 'manifest-only' | 'error';
  message: string;
  updateSteps: string[];
};

export type SystemStatus = {
  api: { ok: boolean; label: string };
  database: { ok: boolean; label: string };
  uptimeSeconds: number;
  nodeVersion: string;
  environment: string;
  coreVersion: string;
  channel: string;
  checkedAt: string;
};

@Injectable()
export class SystemService {
  private readonly logger = new Logger(SystemService.name);

  constructor(private readonly prisma: PrismaService) {}

  getManifest(): CoreManifest {
    const candidates = [
      join(process.cwd(), 'beekiri.manifest.json'),
      join(process.cwd(), '..', '..', 'beekiri.manifest.json'),
      join(__dirname, '..', '..', '..', '..', 'beekiri.manifest.json'),
    ];
    for (const path of candidates) {
      if (existsSync(path)) {
        try {
          return JSON.parse(readFileSync(path, 'utf8')) as CoreManifest;
        } catch (e) {
          this.logger.warn(`Failed to read manifest at ${path}`);
        }
      }
    }
    return {
      name: 'beekiri-cms',
      coreVersion: process.env.BEEKIRI_CORE_VERSION ?? '0.1.4',
      releaseRepo: process.env.BEEKIRI_RELEASE_REPO ?? '996agency/beekiri-install',
      minNode: '20',
      channel: 'stable',
    };
  }

  getVersionInfo() {
    const manifest = this.getManifest();
    return {
      coreVersion: manifest.coreVersion,
      name: manifest.name,
      channel: manifest.channel,
      releaseRepo: manifest.releaseRepo,
      minNode: manifest.minNode,
      nodeVersion: process.version,
      notes: manifest.notes ?? null,
      environment: process.env.NODE_ENV ?? 'development',
    };
  }

  async getStatus(): Promise<SystemStatus> {
    const manifest = this.getManifest();
    let databaseOk = false;
    try {
      await this.prisma.$queryRaw`SELECT 1`;
      databaseOk = true;
    } catch {
      databaseOk = false;
    }

    return {
      api: { ok: true, label: 'Running' },
      database: {
        ok: databaseOk,
        label: databaseOk ? 'Connected' : 'Unavailable',
      },
      uptimeSeconds: Math.floor(process.uptime()),
      nodeVersion: process.version,
      environment: process.env.NODE_ENV ?? 'development',
      coreVersion: manifest.coreVersion,
      channel: manifest.channel,
      checkedAt: new Date().toISOString(),
    };
  }

  private compareSemver(a: string, b: string): number {
    const pa = a.replace(/^v/, '').split('.').map((n) => Number(n) || 0);
    const pb = b.replace(/^v/, '').split('.').map((n) => Number(n) || 0);
    const len = Math.max(pa.length, pb.length);
    for (let i = 0; i < len; i++) {
      const da = pa[i] ?? 0;
      const db = pb[i] ?? 0;
      if (da > db) return 1;
      if (da < db) return -1;
    }
    return 0;
  }

  private githubHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      Accept: 'application/vnd.github+json',
      'User-Agent': 'Beekiri-CMS-Update-Check',
    };
    const token = process.env.BEEKIRI_GITHUB_TOKEN || process.env.GITHUB_TOKEN;
    if (token) headers.Authorization = `Bearer ${token}`;
    return headers;
  }

  private downloadUrlFor(repo: string, version: string | null): string {
    // Stable public ZIP on main (always latest packaged install)
    if (!version) {
      return `https://github.com/${repo}/raw/main/beekiri-install.zip`;
    }
    return `https://github.com/${repo}/raw/main/beekiri-install-v${version}.zip`;
  }

  private buildResult(opts: {
    currentVersion: string;
    latestVersion: string | null;
    releaseUrl: string | null;
    downloadUrl: string | null;
    releaseName: string | null;
    publishedAt: string | null;
    checkedAt: string;
    source: UpdateCheck['source'];
    updateSteps: string[];
    fallbackMessage?: string;
  }): UpdateCheck {
    const updateAvailable = opts.latestVersion
      ? this.compareSemver(opts.latestVersion, opts.currentVersion) > 0
      : false;
    const updateCount = updateAvailable ? 1 : 0;

    let message = opts.fallbackMessage ?? `Up to date (v${opts.currentVersion}).`;
    if (updateAvailable && opts.latestVersion) {
      message = `You have a new update — Beekiri Core v${opts.latestVersion} is available (you are on v${opts.currentVersion}). Download the install ZIP — no git pull required.`;
    }

    return {
      currentVersion: opts.currentVersion,
      latestVersion: opts.latestVersion,
      updateAvailable,
      updateCount,
      releaseUrl: opts.releaseUrl,
      downloadUrl: opts.downloadUrl,
      releaseName: opts.releaseName,
      publishedAt: opts.publishedAt,
      checkedAt: opts.checkedAt,
      source: opts.source,
      message,
      updateSteps: opts.updateSteps,
    };
  }

  /** Prefer the highest semver among Releases AND tags (tags alone used to be ignored). */
  private async resolveLatestVersion(
    repo: string,
    headers: Record<string, string>,
  ): Promise<{
    latestVersion: string | null;
    releaseUrl: string | null;
    releaseName: string | null;
    publishedAt: string | null;
    source: UpdateCheck['source'];
  }> {
    let latestVersion: string | null = null;
    let releaseUrl: string | null = null;
    let releaseName: string | null = null;
    let publishedAt: string | null = null;
    let source: UpdateCheck['source'] = 'manifest-only';

    const consider = (verRaw: string | undefined | null, meta?: {
      url?: string | null;
      name?: string | null;
      publishedAt?: string | null;
      source?: UpdateCheck['source'];
    }) => {
      const ver = (verRaw || '').replace(/^v/, '');
      if (!/^\d+\.\d+/.test(ver)) return;
      if (!latestVersion || this.compareSemver(ver, latestVersion) > 0) {
        latestVersion = ver;
        if (meta?.url) releaseUrl = meta.url;
        if (meta?.name) releaseName = meta.name;
        if (meta?.publishedAt) publishedAt = meta.publishedAt;
        if (meta?.source) source = meta.source;
      }
    };

    try {
      const releaseRes = await fetch(
        `https://api.github.com/repos/${repo}/releases/latest`,
        { headers },
      );
      if (releaseRes.ok) {
        const data = (await releaseRes.json()) as {
          tag_name?: string;
          name?: string;
          html_url?: string;
          published_at?: string;
        };
        consider(data.tag_name, {
          url: data.html_url,
          name: data.name ?? data.tag_name,
          publishedAt: data.published_at,
          source: 'github',
        });
      }

      // Also scan recent releases (latest endpoint can lag / miss if only tags exist)
      const listRes = await fetch(
        `https://api.github.com/repos/${repo}/releases?per_page=15`,
        { headers },
      );
      if (listRes.ok) {
        const list = (await listRes.json()) as {
          tag_name?: string;
          name?: string;
          html_url?: string;
          published_at?: string;
          draft?: boolean;
        }[];
        for (const item of list) {
          if (item.draft) continue;
          consider(item.tag_name, {
            url: item.html_url,
            name: item.name ?? item.tag_name,
            publishedAt: item.published_at,
            source: 'github',
          });
        }
      }
    } catch (e) {
      this.logger.warn(`Release list failed: ${e instanceof Error ? e.message : e}`);
    }

    try {
      const tagsRes = await fetch(
        `https://api.github.com/repos/${repo}/tags?per_page=30`,
        { headers },
      );
      if (tagsRes.ok) {
        const tags = (await tagsRes.json()) as { name?: string }[];
        for (const tag of tags) {
          consider(tag.name, {
            url: tag.name
              ? `https://github.com/${repo}/releases/tag/${tag.name}`
              : null,
            name: tag.name,
            source: latestVersion ? source : 'github-tags',
          });
          // If tag is newer than release, mark source as tags
          const ver = (tag.name || '').replace(/^v/, '');
          if (latestVersion && ver === latestVersion && source === 'manifest-only') {
            source = 'github-tags';
          }
          if (
            latestVersion &&
            ver === latestVersion &&
            source === 'github' &&
            !releaseUrl?.includes(ver)
          ) {
            // tag won over older release
            source = 'github-tags';
            releaseUrl = `https://github.com/${repo}/releases/tag/v${ver}`;
            releaseName = `v${ver}`;
          }
        }
      }
    } catch (e) {
      this.logger.warn(`Tags list failed: ${e instanceof Error ? e.message : e}`);
    }

    // Fix source when newest came from tags beating an older Release
    if (latestVersion) {
      const tagOnly =
        source === 'github' &&
        releaseUrl &&
        !releaseUrl.includes(`v${latestVersion}`) &&
        !releaseUrl.includes(`/${latestVersion}`);
      if (tagOnly) {
        source = 'github-tags';
        releaseUrl = `https://github.com/${repo}/releases/tag/v${latestVersion}`;
        releaseName = `v${latestVersion}`;
        publishedAt = null;
      }
    }

    return { latestVersion, releaseUrl, releaseName, publishedAt, source };
  }

  async checkUpdates(): Promise<UpdateCheck> {
    const manifest = this.getManifest();
    const currentVersion = manifest.coreVersion;
    const repo = manifest.releaseRepo;
    const releasesPage = `https://github.com/${repo}/releases`;
    const zipLatest = `https://github.com/${repo}/raw/main/beekiri-install.zip`;
    const updateSteps = [
      'Back up the database and .env file (content stays yours).',
      `Download the new install ZIP: ${zipLatest}`,
      'Unzip over this site (keep your existing .env — do not replace it).',
      'Run: pnpm install',
      'Run: pnpm db:migrate',
      'Rebuild and restart API, admin, and web.',
      'Open Settings → Beekiri Core and confirm the new version.',
    ];
    const checkedAt = new Date().toISOString();
    const headers = this.githubHeaders();

    try {
      const resolved = await this.resolveLatestVersion(repo, headers);
      if (!resolved.latestVersion) {
        return this.buildResult({
          currentVersion,
          latestVersion: null,
          releaseUrl: releasesPage,
          downloadUrl: zipLatest,
          releaseName: null,
          publishedAt: null,
          checkedAt,
          source: 'manifest-only',
          updateSteps,
          fallbackMessage: 'No release tags found yet. This install is on the current core.',
        });
      }

      return this.buildResult({
        currentVersion,
        latestVersion: resolved.latestVersion,
        releaseUrl: resolved.releaseUrl ?? releasesPage,
        downloadUrl: this.downloadUrlFor(repo, resolved.latestVersion),
        releaseName: resolved.releaseName,
        publishedAt: resolved.publishedAt,
        checkedAt,
        source: resolved.source,
        updateSteps,
      });
    } catch (e) {
      this.logger.warn(`Update check failed: ${e instanceof Error ? e.message : e}`);
      return this.buildResult({
        currentVersion,
        latestVersion: null,
        releaseUrl: releasesPage,
        downloadUrl: zipLatest,
        releaseName: null,
        publishedAt: null,
        checkedAt,
        source: 'error',
        updateSteps,
        fallbackMessage: 'Could not check for updates right now.',
      });
    }
  }
}
