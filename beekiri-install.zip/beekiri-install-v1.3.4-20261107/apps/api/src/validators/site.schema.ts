import { z } from 'zod';
import {
  DEFAULT_ADMIN_BASE_PATH,
  DEFAULT_ADMIN_LOGIN_SLUG,
  RESERVED_ADMIN_BASE_SEGMENTS,
  RESERVED_ADMIN_LOGIN_SLUGS,
  normalizeAdminBasePath,
  normalizeAdminLoginSlug,
} from '../lib/site/admin-login';
import { SITE_CODE_MAX_CHARS, normalizeSiteCodeHtml } from '../lib/site/site-options';
import { opt } from './common';

export const adminDockQuery = z
  .object({
    path: z.string().max(500).optional(),
  })
  .passthrough();

type MenuItemInput = {
  id: string;
  label: string;
  path: string;
  enabled: boolean;
  source?: string;
  refId?: string;
  children?: MenuItemInput[];
};

const menuItem: z.ZodType<MenuItemInput> = z.lazy(() =>
  z
    .object({
      id: z.string().max(64),
      label: z.string().max(80),
      path: z.string().max(200),
      enabled: z.boolean(),
      source: opt(z.string().max(32)),
      refId: opt(z.string().max(64)),
      children: opt(z.array(menuItem).max(100)),
    })
    .strict(),
);

const mediaFolder = z
  .object({
    id: z.string().max(64),
    name: z.string().max(80),
    slug: z.string().max(80),
    /** null = top-level. Optional for older saved settings. */
    parentId: z.string().max(64).nullable().optional(),
  })
  .strict();

const mediaSettings = z
  .object({
    convertToWebp: opt(z.boolean()),
    webpLossless: opt(z.boolean()),
    webpQuality: opt(z.number().int().min(1).max(100)),
    maxWidth: opt(z.number().int().min(320).max(7680)),
    maxHeight: opt(z.number().int().min(320).max(7680)),
    stripMetadata: opt(z.boolean()),
    keepOriginal: opt(z.boolean()),
    folders: opt(z.array(mediaFolder).max(500)),
  })
  .strict();

const str = (max: number) => opt(z.string().max(max));

export const updateSiteSettingsSchema = z
  .object({
    title: opt(z.string().min(1).max(200)),
    tagline: str(300),
    language: str(32),
    blogPublic: opt(z.boolean()),
    timezone: str(64),
    dateFormat: str(32),
    timeFormat: str(32),
    businessName: str(200),
    businessCategory: str(120),
    businessPhone: str(64),
    businessAddress: str(500),
    businessHours: str(200),
    businessImageUrl: str(2000),
    faviconUrl: str(2000),
    adminBasePath: opt(
      z
        .string()
        .min(2)
        .max(80)
        .transform((v) => normalizeAdminBasePath(v) || DEFAULT_ADMIN_BASE_PATH)
        .refine((v) => {
          const first = v.slice(1).split('/')[0] ?? '';
          return first.length >= 2 && !RESERVED_ADMIN_BASE_SEGMENTS.has(first);
        }, 'That admin path is reserved or invalid.'),
    ),
    adminLoginSlug: opt(
      z
        .string()
        .min(3)
        .max(64)
        .regex(/^[a-zA-Z0-9._-]+$/, 'Use letters, numbers, dots, dashes, or underscores only.')
        .refine((v) => {
          const cleaned = String(v)
            .trim()
            .toLowerCase()
            .replace(/[^a-z0-9._-]+/g, '-')
            .replace(/^-+|-+$/g, '');
          return cleaned.length >= 3 && !RESERVED_ADMIN_LOGIN_SLUGS.has(cleaned);
        }, 'That path is reserved for the admin app.')
        .transform((v) => normalizeAdminLoginSlug(v) || DEFAULT_ADMIN_LOGIN_SLUG),
    ),
    permalinkStructure: opt(z.enum(['plain', 'postname', 'dayname', 'custom'])),
    permalinkCustom: str(120),
    menuItems: opt(z.array(menuItem).max(200)),
    frontPageId: str(64),
    frontPageSlug: str(180),
    media: opt(mediaSettings),
    pageEditorStyle: opt(z.enum(['beekiricode'])),
    /** Read-only after install; a different value returns frontend_runtime_locked. */
    frontendRuntime: opt(z.enum(['react', 'php'])),
    /** Settings → General → Site code (Header / Body / Footer). */
    customHeadHtml: opt(
      z.string().max(SITE_CODE_MAX_CHARS).transform(normalizeSiteCodeHtml),
    ),
    customBodyHtml: opt(
      z.string().max(SITE_CODE_MAX_CHARS).transform(normalizeSiteCodeHtml),
    ),
    customFooterHtml: opt(
      z.string().max(SITE_CODE_MAX_CHARS).transform(normalizeSiteCodeHtml),
    ),
  })
  .strict();

export const dashboardQuery = z
  .object({ range: z.enum(['today', '7d', '30d', 'all']).optional().catch(undefined) })
  .passthrough();

const dashboardWidgetId = z.enum([
  'storage',
  'clock',
  'pages',
  'posts',
  'media',
  'status',
  'activity',
  'publish',
  'fields',
  'users',
]);

export const dashboardLayoutBody = z
  .object({
    layout: z
      .array(
        z
          .object({
            id: dashboardWidgetId,
            span: z.union([
              z.literal(2),
              z.literal(3),
              z.literal(4),
              z.literal(6),
              z.literal(8),
              z.literal(12),
            ]),
          })
          .strict(),
      )
      .max(20),
  })
  .strict();

export type UpdateSiteSettingsInput = z.infer<typeof updateSiteSettingsSchema>;
export type DashboardLayoutBody = z.infer<typeof dashboardLayoutBody>;

const translationText = z.string().max(2000);

export const translationsSchema = z
  .object({
    defaultLanguage: z.string().max(16),
    primaryLanguage: opt(z.string().max(16)),
    languages: z.array(z.string().max(16)).max(60),
    sources: z.array(translationText).max(5000),
    strings: z.record(z.string().max(16), z.record(translationText, translationText)),
  })
  .strict();

export const translationsPublicQuery = z
  .object({
    lang: z.string().max(16).optional(),
  })
  .passthrough();

export const autoTranslateSchema = z
  .object({
    from: z.string().max(16),
    to: z.string().max(16),
    texts: z.array(z.string().min(1).max(500)).min(1).max(20),
  })
  .strict();

export type TranslationsInput = z.infer<typeof translationsSchema>;
export type AutoTranslateInput = z.infer<typeof autoTranslateSchema>;
