import { z } from 'zod';
import { CONNECTOR_EFFORTS, CONNECTOR_PROVIDER_IDS } from '../lib/site/connector';
import { opt } from './common';

export const connectorProviderParams = z.object({
  providerId: z.enum(CONNECTOR_PROVIDER_IDS),
});

export const updateConnectorSchema = z
  .object({
    providerId: z.enum(CONNECTOR_PROVIDER_IDS),
    enabled: opt(z.boolean()),
    /** Empty string clears; omit to leave unchanged. */
    apiKey: opt(z.string().max(500)),
    defaultModel: opt(z.string().min(1).max(120)),
    effort: opt(z.enum(CONNECTOR_EFFORTS)),
    /** BeeQueen only: the BeeQueen service address. */
    serviceUrl: opt(z.string().max(300)),
  })
  .strict()
  .refine(
    (v) =>
      v.enabled !== undefined ||
      v.apiKey !== undefined ||
      v.defaultModel !== undefined ||
      v.effort !== undefined ||
      v.serviceUrl !== undefined,
    { message: 'Provide at least one field to update.' },
  );

/** BeeQueen chat turn — continues `chatId`, or starts a new chat without it. */
export const beeQueenAgentSchema = z
  .object({
    prompt: z.string().min(1).max(8000),
    chatId: opt(z.string().min(1).max(64)),
    /** Section mode: the element selected in the editor (checked again by readScope). */
    scope: opt(
      z.object({
        pageId: z.string().min(1).max(64),
        pageTitle: z.string().max(300).optional(),
        nodeId: z.string().min(1).max(64),
        label: z.string().max(200).optional(),
        viewport: z.string().max(20).optional(),
        tree: z.object({ rootId: z.string().min(1).max(64), nodes: z.record(z.string(), z.unknown()) }),
      }),
    ),
  })
  .strict();

/** The editor's answer to a section preview request: a picture, or why it couldn't take one. */
export const beeQueenPreviewSchema = z
  .object({
    id: z.string().uuid(),
    image: opt(z.string().max(1_900_000)),
    error: opt(z.string().max(300)),
    width: opt(z.number().int().min(1).max(20000)),
    height: opt(z.number().int().min(1).max(40000)),
  })
  .strict();

/** Revert one change (changeId) or every change of one Beekiri message (runId). */
export const beeQueenRevertSchema = z
  .object({
    changeId: opt(z.string().min(1).max(64)),
    runId: opt(z.string().min(1).max(64)),
    force: opt(z.boolean()),
  })
  .strict()
  .refine((v) => Boolean(v.changeId) !== Boolean(v.runId), { message: 'Give either changeId or runId.' });

export const beeQueenChatParams = z.object({ chatId: z.string().min(1).max(64) });

export type UpdateConnectorInput = z.infer<typeof updateConnectorSchema>;
export type BeeQueenAgentInput = z.infer<typeof beeQueenAgentSchema>;

/** A top-up: one of 996Agency's preset amounts (its id), or an amount of the site's own in whole dollars. */
export const beeQueenTopupSchema = z
  .object({
    pack: z.string().regex(/^[A-Za-z0-9]{10,40}$/).optional(),
    amount: z.number().int().positive().max(100000).optional(),
  })
  .strict()
  .refine((v) => Boolean(v.pack) !== (v.amount !== undefined), { message: 'Choose a preset or an amount.' });

/** A history list: today, this week, this month or all time, one page at a time. */
export const historyQuery = z
  .object({
    period: z.enum(['today', 'week', 'month', 'all']).optional(),
    page: z.coerce.number().int().min(1).max(100000).optional(),
  })
  .strict();

/** Keep everything one Beekiri message added to live pages. */
export const beeQueenKeepSchema = z.object({ runId: z.string().min(1).max(64) }).strict();
