import { z } from 'zod';
import {
  CATALOG_VISIBILITIES,
  COUPON_TYPES,
  ORDER_STATUSES,
  PAYMENT_METHODS,
  PRODUCT_TYPES,
  STOCK_STATUSES,
} from '../lib/shop/constants';
import { shopSettingsSchema } from '../lib/shop/settings';
import { jsonObject, opt } from './common';

export { shopSettingsSchema };

const money = z.number().int().min(0).max(1_000_000_000);
const optMoney = money.nullable().optional();
const optInt = z.number().int().min(0).max(1_000_000_000).nullable().optional();
const isoDate = z.string().datetime({ offset: true }).nullable().optional();
const id = z.string().min(1).max(128);
const idList = z.array(id).max(500);

/* ── Products (admin) ─────────────────────────────────────────────────── */

export const productAttributeSchema = z
  .object({
    name: z.string().min(1).max(80),
    options: z.array(z.string().min(1).max(80)).max(100),
    visible: z.boolean().default(true),
    /** Used to build variations (variable products). */
    variation: z.boolean().default(false),
  })
  .strict();

export const productVariantSchema = z
  .object({
    id: opt(id),
    sku: opt(z.string().max(100)),
    attributes: z.record(z.string().max(80), z.string().max(80)).default({}),
    regularPrice: optMoney,
    salePrice: optMoney,
    saleFrom: isoDate,
    saleTo: isoDate,
    manageStock: z.boolean().default(false),
    stockQty: optInt,
    stockStatus: z.enum(STOCK_STATUSES).default('instock'),
    weight: optInt,
    imageId: z.string().max(128).nullable().optional(),
    enabled: z.boolean().default(true),
    menuOrder: z.number().int().min(0).max(100_000).default(0),
  })
  .strict();

export const productCommerceSchema = z
  .object({
    type: opt(z.enum(PRODUCT_TYPES)),
    sku: opt(z.string().max(100)),
    regularPrice: optMoney,
    salePrice: optMoney,
    saleFrom: isoDate,
    saleTo: isoDate,
    manageStock: opt(z.boolean()),
    stockQty: optInt,
    stockStatus: opt(z.enum(STOCK_STATUSES)),
    lowStockThreshold: optInt,
    soldIndividually: opt(z.boolean()),
    weight: optInt,
    length: optInt,
    width: optInt,
    height: optInt,
    virtual: opt(z.boolean()),
    taxable: opt(z.boolean()),
    galleryIds: opt(z.array(z.string().max(128)).max(50)),
    attributes: opt(z.array(productAttributeSchema).max(30)),
    purchaseNote: opt(z.string().max(2000)),
    featured: opt(z.boolean()),
    catalogVisibility: opt(z.enum(CATALOG_VISIBILITIES)),
  })
  .strict();

const PRODUCT_STATUS = z.enum(['draft', 'publish']);

export const createProductSchema = z
  .object({
    title: opt(z.string().max(200)),
    status: opt(PRODUCT_STATUS),
  })
  .strict();

export const updateProductSchema = z
  .object({
    title: opt(z.string().max(200)),
    slug: opt(z.string().max(200)),
    status: opt(PRODUCT_STATUS),
    /** Long description (HTML). */
    description: opt(z.string().max(200_000)),
    /** Short description shown next to the price. */
    shortDescription: opt(z.string().max(5000)),
    featuredImageId: opt(z.union([z.string().max(128), z.literal('')])),
    seo: opt(z.union([jsonObject, z.null()])),
    commerce: opt(productCommerceSchema),
    /** Full replacement of the variant list (missing ids are deleted). */
    variants: opt(z.array(productVariantSchema).max(200)),
    categoryIds: opt(idList),
    tagIds: opt(idList),
  })
  .strict();

export const productListQuery = z
  .object({
    q: z.string().max(200).optional().catch(undefined),
    status: z.enum(['all', 'publish', 'draft', 'trash']).optional().catch(undefined),
    category: z.string().max(128).optional().catch(undefined),
    stock: z.enum(STOCK_STATUSES).optional().catch(undefined),
    type: z.enum(PRODUCT_TYPES).optional().catch(undefined),
    sort: z.enum(['updated', 'title', 'price', 'price-desc', 'sku', 'stock']).optional().catch(undefined),
    page: z.coerce.number().int().min(1).max(10_000).optional().catch(undefined),
    perPage: z.coerce.number().int().min(1).max(100).optional().catch(undefined),
  })
  .passthrough();

export const productBulkSchema = z
  .object({
    ids: idList.min(1),
    action: z.enum(['publish', 'draft', 'trash', 'restore', 'delete']),
  })
  .strict();

export const productLookupQuery = z
  .object({
    q: z.string().max(200).optional().catch(undefined),
    ids: z.string().max(5000).optional().catch(undefined),
  })
  .passthrough();

export const removeQuery = z.object({ force: z.string().optional().catch(undefined) }).passthrough();

/* ── Coupons (admin) ──────────────────────────────────────────────────── */

export const couponSchema = z
  .object({
    code: z
      .string()
      .min(1)
      .max(40)
      .regex(/^[A-Za-z0-9_-]+$/, 'Use letters, numbers, - and _ only'),
    type: z.enum(COUPON_TYPES),
    /** percent: 12.5% = 1250; fixed: minor units */
    amount: z.number().int().min(0).max(1_000_000_000),
    description: opt(z.string().max(500)),
    minSpend: optMoney,
    maxSpend: optMoney,
    usageLimit: optInt,
    usageLimitPerEmail: optInt,
    expiresAt: isoDate,
    productIds: opt(idList),
    excludeProductIds: opt(idList),
    categoryIds: opt(idList),
    freeShipping: opt(z.boolean()),
    active: opt(z.boolean()),
  })
  .strict();

export const updateCouponSchema = couponSchema.partial().strict();

/* ── Orders (admin) ───────────────────────────────────────────────────── */

export const orderListQuery = z
  .object({
    q: z.string().max(200).optional().catch(undefined),
    status: z.enum(['all', ...ORDER_STATUSES]).optional().catch(undefined),
    payment: z.enum(PAYMENT_METHODS).optional().catch(undefined),
    customerId: z.string().max(128).optional().catch(undefined),
    from: z.string().max(40).optional().catch(undefined),
    to: z.string().max(40).optional().catch(undefined),
    page: z.coerce.number().int().min(1).max(10_000).optional().catch(undefined),
    perPage: z.coerce.number().int().min(1).max(100).optional().catch(undefined),
  })
  .passthrough();

export const orderStatusSchema = z
  .object({
    status: z.enum(ORDER_STATUSES),
    /** Optional note shown to the customer in the status email. */
    note: opt(z.string().max(2000)),
  })
  .strict();

export const orderNoteSchema = z
  .object({
    note: z.string().min(1).max(5000),
    isCustomerNote: opt(z.boolean()),
  })
  .strict();

export const orderRefundSchema = z
  .object({
    /** minor units; omitted = full remaining amount */
    amount: opt(money),
    reason: opt(z.string().max(500)),
    /** Try to refund through the payment provider (Stripe). Otherwise mark only. */
    viaProvider: opt(z.boolean()),
    restock: opt(z.boolean()),
  })
  .strict();

export const orderDetailsSchema = z
  .object({
    email: opt(z.string().email().max(320)),
    phone: opt(z.string().max(40)),
    billing: opt(jsonObject),
    shipping: opt(jsonObject),
    customerNote: opt(z.string().max(2000)),
  })
  .strict();

export const customerListQuery = z
  .object({
    q: z.string().max(200).optional().catch(undefined),
    page: z.coerce.number().int().min(1).max(10_000).optional().catch(undefined),
    perPage: z.coerce.number().int().min(1).max(100).optional().catch(undefined),
  })
  .passthrough();

export const reportsQuery = z
  .object({
    range: z.enum(['today', '7d', '30d', '90d', 'year']).optional().catch(undefined),
  })
  .passthrough();

/* ── Storefront (public) ──────────────────────────────────────────────── */

export const cartAddSchema = z
  .object({
    productId: id,
    variantId: opt(id),
    qty: z.number().int().min(1).max(999).default(1),
  })
  .strict();

export const cartUpdateSchema = z
  .object({
    /** Line key as returned by the cart API. */
    key: z.string().min(1).max(300),
    qty: z.number().int().min(0).max(999),
  })
  .strict();

export const cartCouponSchema = z.object({ code: z.string().min(1).max(40) }).strict();

export const checkoutAddressSchema = z
  .object({
    firstName: z.string().min(1).max(80),
    lastName: z.string().min(1).max(80),
    company: z.string().max(120).default(''),
    line1: z.string().min(1).max(200),
    line2: z.string().max(200).default(''),
    city: z.string().min(1).max(100),
    state: z.string().max(100).default(''),
    postcode: z.string().max(32).default(''),
    country: z.string().regex(/^[A-Z]{2}$/),
  })
  .strict();

export const checkoutSchema = z
  .object({
    email: z.string().email().max(320),
    phone: z.string().max(40).default(''),
    billing: checkoutAddressSchema,
    shipToDifferent: z.boolean().default(false),
    shipping: checkoutAddressSchema.optional(),
    shippingMethodId: z.string().max(80).optional(),
    paymentMethod: z.enum(PAYMENT_METHODS),
    customerNote: z.string().max(2000).default(''),
    termsAccepted: z.boolean().default(false),
    /** Values of custom checkout fields keyed by `custom.<slug>` (validated against the settings). */
    extra: z.record(z.string().max(60), z.string().max(2000)).default({}),
    /** Create a shopper account with this order. */
    createAccount: z.boolean().default(false),
    accountPassword: z.string().max(200).optional(),
  })
  .strict();

/* ── Shopper accounts (public) ────────────────────────────────────────── */

const accountAddress = z
  .object({
    firstName: z.string().max(80).default(''),
    lastName: z.string().max(80).default(''),
    company: z.string().max(120).default(''),
    line1: z.string().max(200).default(''),
    line2: z.string().max(200).default(''),
    city: z.string().max(100).default(''),
    state: z.string().max(100).default(''),
    postcode: z.string().max(32).default(''),
    country: z.union([z.literal(''), z.string().regex(/^[A-Z]{2}$/)]).default(''),
    phone: z.string().max(40).default(''),
  })
  .strict();

export const accountRegisterSchema = z
  .object({
    email: z.string().email().max(320),
    password: z.string().min(8).max(200),
    firstName: z.string().max(80).default(''),
    lastName: z.string().max(80).default(''),
    remember: z.boolean().default(true),
  })
  .strict();
/** Shopper sign-in: `login` is an email address or a staff username (`email` still works). */
export const accountLoginSchema = z
  .object({
    login: z.string().trim().min(1).max(320).optional(),
    email: z.string().trim().min(1).max(320).optional(),
    password: z.string().min(1).max(200),
    remember: z.boolean().default(false),
  })
  .strict()
  .refine((v) => Boolean(v.login || v.email), { message: 'Enter your email address or username.', path: ['login'] });
export const accountForgotSchema = z.object({ email: z.string().email().max(320) }).strict();
export const accountTokenSchema = z.object({ token: z.string().min(10).max(200) }).strict();
export const accountResetSchema = z.object({ token: z.string().min(10).max(200), password: z.string().min(8).max(200) }).strict();
export const accountDetailsSchema = z
  .object({ firstName: opt(z.string().max(80)), lastName: opt(z.string().max(80)), phone: opt(z.string().max(40)) })
  .strict();
export const accountPasswordSchema = z.object({ current: z.string().min(1).max(200), password: z.string().min(8).max(200) }).strict();
export const accountAddressesSchema = z.object({ billing: accountAddress.optional(), shipping: accountAddress.optional() }).strict();
export const cartShippingSchema = z
  .object({
    country: z.string().regex(/^[A-Z]{2}$/),
    state: z.string().max(100).default(''),
    postcode: z.string().max(32).default(''),
    shippingMethodId: z.string().max(80).optional(),
  })
  .strict();

/* ── Fulfilment (admin) ───────────────────────────────────────────────── */

export const orderFulfillmentSchema = z
  .object({
    status: z.enum(['unfulfilled', 'packed', 'shipped', 'delivered']),
    carrier: opt(z.string().max(80)),
    trackingNumber: opt(z.string().max(120)),
    trackingUrl: opt(z.union([z.literal(''), z.string().url().max(500).refine((u) => /^https?:\/\//i.test(u), 'Use an http(s) link')])),
    /** Email the customer about this step (shipped / delivered). */
    notify: opt(z.boolean()),
  })
  .strict();

export const checkoutConfirmSchema = z
  .object({ token: z.string().min(1).max(200), sessionId: opt(z.string().max(200)) })
  .strict();

export const shippingQuoteSchema = z
  .object({
    country: z.string().regex(/^[A-Z]{2}$/),
    state: z.string().max(100).default(''),
    postcode: z.string().max(32).default(''),
  })
  .strict();

export const catalogQuery = z
  .object({
    q: z.string().max(200).optional().catch(undefined),
    category: z.string().max(128).optional().catch(undefined),
    tag: z.string().max(128).optional().catch(undefined),
    sort: z
      .enum(['menu_order', 'newest', 'price', 'price-desc', 'popularity', 'title'])
      .optional()
      .catch(undefined),
    page: z.coerce.number().int().min(1).max(10_000).optional().catch(undefined),
    perPage: z.coerce.number().int().min(1).max(60).optional().catch(undefined),
    featured: z.string().optional().catch(undefined),
    /** "1": only products on sale right now. */
    sale: z.string().max(5).optional().catch(undefined),
    /** Attribute filters, `Name:Value,Value|Name:Value` (e.g. `Color:Green,Blue|Material:Oak`). */
    attr: z.string().max(600).optional().catch(undefined),
    /** Price range in the shop's currency, `min-max` (either side may be empty). */
    price: z.string().max(40).optional().catch(undefined),
  })
  .passthrough();

export const viewQuery = catalogQuery
  .extend({
    slug: z.string().max(200).optional().catch(undefined),
    token: z.string().max(200).optional().catch(undefined),
    /** Stripe sends the session id back on the success URL. */
    session_id: z.string().max(200).optional().catch(undefined),
    cancelled: z.string().max(5).optional().catch(undefined),
    /** My account: dashboard | orders | order | details | addresses | login | register | forgot | reset | verify */
    section: z.string().max(20).optional().catch(undefined),
    number: z.coerce.number().int().min(1).max(1_000_000_000).optional().catch(undefined),
  })
  .passthrough();

export const extensionActionSchema = z
  .object({ deleteData: opt(z.boolean()) })
  .strict();

export type ProductCommerceInput = z.infer<typeof productCommerceSchema>;
export type ProductVariantInput = z.infer<typeof productVariantSchema>;
export type UpdateProductInput = z.infer<typeof updateProductSchema>;
export type CreateProductInput = z.infer<typeof createProductSchema>;
export type ProductListInput = z.infer<typeof productListQuery>;
export type CouponInput = z.infer<typeof couponSchema>;
export type UpdateCouponInput = z.infer<typeof updateCouponSchema>;
export type OrderListInput = z.infer<typeof orderListQuery>;
export type CheckoutInput = z.infer<typeof checkoutSchema>;
export type CheckoutAddress = z.infer<typeof checkoutAddressSchema>;
export type CatalogInput = z.infer<typeof catalogQuery>;
export type ViewInput = z.infer<typeof viewQuery>;
