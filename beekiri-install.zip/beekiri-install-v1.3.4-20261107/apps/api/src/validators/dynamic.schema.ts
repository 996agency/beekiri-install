import { z } from 'zod';

/** A dynamic-content query from a page tree (page-blocks `LoopConfig`). */
export const loopSchema = z
  .object({
    source: z.enum(['products', 'posts', 'fields']),
    limit: z.coerce.number().int().min(1).max(60).optional().catch(undefined),
    sort: z.string().max(32).optional().catch(undefined),
    category: z.string().max(128).optional().catch(undefined),
    featured: z.boolean().optional().catch(undefined),
    ids: z.array(z.string().max(64)).max(60).optional().catch(undefined),
    layout: z.string().max(120).optional().catch(undefined),
    repeater: z.string().max(120).optional().catch(undefined),
    rows: z.array(z.record(z.string(), z.unknown())).max(200).optional().catch(undefined),
  })
  .passthrough();

export const dynamicItemsSchema = z.object({ loop: loopSchema }).passthrough();

/** Media-library photo addresses a page shows (/uploads/…), for their width and height. */
export const imageSizesSchema = z.object({ urls: z.array(z.string().max(500)).max(300) }).strict();

export type LoopInput = z.infer<typeof loopSchema>;
