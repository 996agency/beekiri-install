import { z } from 'zod';
import { opt } from './common';

/** Field and settings contents are parsed by lib/forms/schema; zod only bounds the shape. */
export const formBodySchema = z
  .object({
    title: opt(z.string().max(200)),
    status: opt(z.enum(['active', 'inactive'])),
    fields: opt(z.array(z.record(z.unknown())).max(200)),
    settings: opt(z.record(z.unknown())),
  })
  .strict();

export const formListQuery = z.object({ q: z.string().max(200).optional().catch(undefined) }).passthrough();

export const entryListQuery = z
  .object({
    formId: z.string().max(128).optional().catch(undefined),
    status: z.enum(['all', 'inbox', 'unread', 'read', 'spam', 'trash']).optional().catch(undefined),
    q: z.string().max(200).optional().catch(undefined),
    channel: z.string().max(40).optional().catch(undefined),
    source: z.string().max(300).optional().catch(undefined),
    page: z.coerce.number().int().min(1).max(10_000).optional().catch(undefined),
    perPage: z.coerce.number().int().min(1).max(100).optional().catch(undefined),
  })
  .passthrough();

export const entryIdsSchema = z.object({ ids: z.array(z.string().max(128)).min(1).max(500) }).strict();

export const entryStatusSchema = entryIdsSchema.extend({ status: z.enum(['unread', 'read', 'spam', 'trash']) }).strict();

export const entryExportQuery = z
  .object({ status: z.enum(['all', 'inbox', 'unread', 'read', 'spam', 'trash']).optional().catch(undefined) })
  .passthrough();

export const publicIdParams = z.object({ id: z.string().min(1).max(128).regex(/^[A-Za-z0-9_-]+$/) }).passthrough();

export const entryFileParams = z
  .object({ id: z.string().min(1).max(128), fileId: z.string().min(1).max(128).regex(/^[A-Za-z0-9_-]+$/) })
  .passthrough();

export const hubspotConnectSchema = z.object({ token: z.string().min(1).max(500) }).strict();

export const providerParams = z.object({ provider: z.enum(['hubspot', 'brevo', 'mailchimp', 'salesforce']) }).passthrough();

export const extensionActionSchema = z.object({ deleteData: opt(z.boolean()) }).strict();
