import { z } from 'zod';

export const themeSlugSchema = z.object({ slug: z.string().min(1).max(80) }).strict();

/** Activate: `importContent` adds the theme's demo content (pages, products…) when it has some. */
export const activateThemeSchema = z
  .object({
    slug: z.string().min(1).max(80),
    importContent: z.boolean().optional(),
    /** Turn on the extensions the theme is built on (e.g. Shopping) first. */
    enableRequired: z.boolean().optional(),
    /** Switch off extensions only the previous theme needed (e.g. Shopping when leaving a shop theme). */
    disableUnused: z.array(z.string().regex(/^[a-z0-9-]{1,64}$/)).max(10).optional(),
  })
  .strict();

export const chromeKindParams = z.object({ kind: z.string().max(20) }).passthrough();

export const chromeAssetParams = z
  .object({ kind: z.string().max(20), file: z.string().max(40) })
  .passthrough();

export const themeSlugParams = z.object({ slug: z.string().min(1).max(80) }).passthrough();

/** Theme store slugs (same rule as the Hub). */
export const storeSlugParams = z.object({ slug: z.string().regex(/^[a-z0-9][a-z0-9-]{1,62}$/) }).passthrough();
export const storeLicenceKeyBody = z.object({ key: z.string().trim().min(1).max(128) }).strict();
