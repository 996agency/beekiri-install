import { z } from 'zod';
import { opt } from './common';

const SLUG = z.string().min(1).max(63);
const DOMAIN = z.string().max(253);

export const createSiteSchema = z
  .object({
    title: z.string().min(1).max(200),
    slug: SLUG,
    tagline: opt(z.string().max(300)),
    domain: opt(DOMAIN.nullable()),
    theme: opt(z.string().max(80)),
    language: opt(z.string().max(20)),
  })
  .strict();

export const updateSiteSchema = z
  .object({
    title: opt(z.string().min(1).max(200)),
    tagline: opt(z.string().max(300)),
    slug: opt(SLUG),
    domain: opt(DOMAIN.nullable()),
    status: opt(z.enum(['active', 'archived'])),
  })
  .strict();

export const siteAccessSchema = z
  .object({
    enabled: z.boolean(),
    password: opt(z.string().min(4).max(200)),
  })
  .strict();

export const deleteSiteSchema = z.object({ confirm: z.string().max(63) }).strict();

export const networkSettingsSchema = z.object({ baseDomain: opt(DOMAIN.nullable()) }).strict();

export const handoffSchema = z
  .object({
    siteId: z.string().min(1).max(64),
    next: opt(z.string().max(500)),
  })
  .strict();

export type CreateSiteInput = z.infer<typeof createSiteSchema>;
export type UpdateSiteInput = z.infer<typeof updateSiteSchema>;
export type SiteAccessInput = z.infer<typeof siteAccessSchema>;
export type NetworkSettingsInput = z.infer<typeof networkSettingsSchema>;
