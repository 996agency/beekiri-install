import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type NonAttribute,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, int, jsonb, optionalDate, optionalText, text, type Json } from './_shared';
import type { ShopCustomer } from './shop-customer.model';
import type { ShopOrderItem } from './shop-order-item.model';
import type { Site } from './site.model';

/** An order. Every amount is in minor units of `currency`. */
export class ShopOrder extends Model<InferAttributes<ShopOrder>, InferCreationAttributes<ShopOrder>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare number: number;
  /** pending | on-hold | processing | completed | cancelled | refunded | failed */
  declare status: CreationOptional<string>;
  declare currency: CreationOptional<string>;
  declare subtotal: CreationOptional<number>;
  declare discountTotal: CreationOptional<number>;
  declare shippingTotal: CreationOptional<number>;
  declare taxTotal: CreationOptional<number>;
  declare total: CreationOptional<number>;
  declare refundedTotal: CreationOptional<number>;
  declare couponCode: CreationOptional<string | null>;
  declare customerId: CreationOptional<string | null>;
  declare email: CreationOptional<string>;
  declare phone: CreationOptional<string>;
  declare billing: CreationOptional<Json>;
  declare shipping: CreationOptional<Json>;
  declare shipToDifferent: CreationOptional<boolean>;
  /** { id, type, title, cost } or null for virtual-only orders */
  declare shippingMethod: CreationOptional<Json>;
  /** cod | bank_transfer | stripe */
  declare paymentMethod: CreationOptional<string>;
  /** unpaid | paid | refunded | partially_refunded | failed */
  declare paymentStatus: CreationOptional<string>;
  declare transactionId: CreationOptional<string>;
  /** Provider references, e.g. { sessionId, paymentIntentId } */
  declare paymentRef: CreationOptional<Json>;
  declare customerNote: CreationOptional<string>;
  /** Custom checkout fields: { [key]: { label, value } } */
  declare customFields: CreationOptional<Json>;
  /** { status: unfulfilled|packed|shipped|delivered, carrier, trackingNumber, trackingUrl, packedAt, shippedAt, deliveredAt } */
  declare fulfillment: CreationOptional<Json>;
  declare accessToken: string;
  declare ipAddress: CreationOptional<string>;
  declare userAgent: CreationOptional<string>;
  declare cartId: CreationOptional<string | null>;
  declare placedAt: CreationOptional<Date>;
  declare paidAt: CreationOptional<Date | null>;
  declare completedAt: CreationOptional<Date | null>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  declare items?: NonAttribute<ShopOrderItem[]>;
  declare customer?: NonAttribute<ShopCustomer | null>;

  static initModel(sequelize: Sequelize) {
    ShopOrder.init(
      {
        id: idColumn(),
        siteId: text(),
        number: int(),
        status: text({ defaultValue: 'pending' }),
        currency: text({ defaultValue: 'EUR' }),
        subtotal: int(0),
        discountTotal: int(0),
        shippingTotal: int(0),
        taxTotal: int(0),
        total: int(0),
        refundedTotal: int(0),
        couponCode: optionalText(),
        customerId: optionalText(),
        email: text({ defaultValue: '' }),
        phone: text({ defaultValue: '' }),
        billing: jsonb({}),
        shipping: jsonb({}),
        shipToDifferent: bool(false),
        shippingMethod: { ...jsonb(null), allowNull: true },
        paymentMethod: text({ defaultValue: '' }),
        paymentStatus: text({ defaultValue: 'unpaid' }),
        transactionId: text({ defaultValue: '' }),
        paymentRef: jsonb({}),
        customerNote: text({ defaultValue: '' }),
        customFields: jsonb({}),
        fulfillment: jsonb({}),
        accessToken: text(),
        ipAddress: text({ defaultValue: '' }),
        userAgent: text({ defaultValue: '' }),
        cartId: optionalText(),
        placedAt: date(),
        paidAt: optionalDate(),
        completedAt: optionalDate(),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopOrder',
        modelName: 'ShopOrder',
        timestamps: true,
        indexes: [
          { name: 'ShopOrder_siteId_number_key', unique: true, fields: ['siteId', 'number'] },
          { name: 'ShopOrder_accessToken_key', unique: true, fields: ['accessToken'] },
          { name: 'ShopOrder_siteId_status_idx', fields: ['siteId', 'status'] },
          { name: 'ShopOrder_siteId_placedAt_idx', fields: ['siteId', 'placedAt'] },
          { name: 'ShopOrder_siteId_email_idx', fields: ['siteId', 'email'] },
        ],
      },
    );
  }
}
