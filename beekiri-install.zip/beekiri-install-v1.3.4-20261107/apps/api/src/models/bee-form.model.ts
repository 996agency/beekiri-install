import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, int, jsonb, optionalDate, optionalText, text, type Json } from './_shared';
import type { Site } from './site.model';

export type BeeFormStatus = 'active' | 'inactive';

/** A Bee Forms form: its fields and settings (parsed by lib/forms/schema) plus entry counters. */
export class BeeForm extends Model<InferAttributes<BeeForm>, InferCreationAttributes<BeeForm>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare title: string;
  declare status: CreationOptional<BeeFormStatus>;
  declare fields: CreationOptional<Json>;
  declare settings: CreationOptional<Json>;
  declare entryCount: CreationOptional<number>;
  declare unreadCount: CreationOptional<number>;
  declare lastEntryAt: Date | null;
  declare createdById: string | null;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    BeeForm.init(
      {
        id: idColumn(),
        siteId: text(),
        title: text(),
        status: text({ defaultValue: 'active' }),
        fields: jsonb([]),
        settings: jsonb({}),
        entryCount: int(0),
        unreadCount: int(0),
        lastEntryAt: optionalDate(),
        createdById: optionalText(),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'BeeForm',
        modelName: 'BeeForm',
        timestamps: true,
        indexes: [{ name: 'BeeForm_siteId_updatedAt_idx', fields: ['siteId', 'updatedAt'] }],
      },
    );
  }
}
