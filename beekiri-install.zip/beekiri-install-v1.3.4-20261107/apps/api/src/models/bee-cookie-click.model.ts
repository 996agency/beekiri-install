import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { DataTypes } from 'sequelize';
import { date, idColumn, text } from './_shared';
import type { Site } from './site.model';
import type { BeeCookieDevice } from './bee-cookie-consent.model';

export class BeeCookieClick extends Model<
  InferAttributes<BeeCookieClick>,
  InferCreationAttributes<BeeCookieClick>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare visitorId: string;
  declare path: string;
  declare xPct: number;
  declare yPct: number;
  declare device: CreationOptional<BeeCookieDevice>;
  declare viewportW: CreationOptional<number | null>;
  /** Client theme active when the click happened; the heatmap shows the active theme's clicks. */
  declare theme: CreationOptional<string | null>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    BeeCookieClick.init(
      {
        id: idColumn(),
        siteId: text(),
        visitorId: text(),
        path: text(),
        xPct: { type: DataTypes.DOUBLE, allowNull: false },
        yPct: { type: DataTypes.DOUBLE, allowNull: false },
        device: text({ defaultValue: 'unknown' }),
        viewportW: { type: DataTypes.INTEGER, allowNull: true },
        theme: { type: DataTypes.TEXT, allowNull: true },
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'BeeCookieClick',
        modelName: 'BeeCookieClick',
        timestamps: true,
        updatedAt: false,
        indexes: [
          { name: 'BeeCookieClick_siteId_path_createdAt_idx', fields: ['siteId', 'path', 'createdAt'] },
          { name: 'BeeCookieClick_siteId_createdAt_idx', fields: ['siteId', 'createdAt'] },
          { name: 'BeeCookieClick_siteId_theme_createdAt_idx', fields: ['siteId', 'theme', 'createdAt'] },
        ],
      },
    );
  }
}
