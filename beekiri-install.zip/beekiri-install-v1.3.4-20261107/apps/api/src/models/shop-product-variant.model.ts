import {
  DataTypes,
  Model,
  type ModelAttributeColumnOptions,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, int, jsonb, optionalDate, optionalText, text, type Json } from './_shared';
import type { ShopProduct } from './shop-product.model';
import type { Site } from './site.model';

/** Fresh object per column: Sequelize mutates attribute options during init. */
const optInt = (): ModelAttributeColumnOptions => ({ type: DataTypes.INTEGER, allowNull: true });

/** One purchasable combination of a variable product (e.g. Size M / Colour Red). */
export class ShopProductVariant extends Model<
  InferAttributes<ShopProductVariant>,
  InferCreationAttributes<ShopProductVariant>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare productId: ForeignKey<ShopProduct['id']>;
  declare sku: CreationOptional<string>;
  /** { attributeName: option } */
  declare attributes: CreationOptional<Json>;
  declare regularPrice: CreationOptional<number | null>;
  declare salePrice: CreationOptional<number | null>;
  declare saleFrom: CreationOptional<Date | null>;
  declare saleTo: CreationOptional<Date | null>;
  declare manageStock: CreationOptional<boolean>;
  declare stockQty: CreationOptional<number | null>;
  declare stockStatus: CreationOptional<string>;
  declare weight: CreationOptional<number | null>;
  declare imageId: CreationOptional<string | null>;
  declare enabled: CreationOptional<boolean>;
  declare menuOrder: CreationOptional<number>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    ShopProductVariant.init(
      {
        id: idColumn(),
        siteId: text(),
        productId: text(),
        sku: text({ defaultValue: '' }),
        attributes: jsonb({}),
        regularPrice: optInt(),
        salePrice: optInt(),
        saleFrom: optionalDate(),
        saleTo: optionalDate(),
        manageStock: bool(false),
        stockQty: optInt(),
        stockStatus: text({ defaultValue: 'instock' }),
        weight: optInt(),
        imageId: optionalText(),
        enabled: bool(true),
        menuOrder: int(0),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopProductVariant',
        modelName: 'ShopProductVariant',
        timestamps: true,
        indexes: [{ name: 'ShopProductVariant_productId_idx', fields: ['productId'] }],
      },
    );
  }
}
