import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, jsonb, text, type Json } from './_shared';
import type { BeeForm } from './bee-form.model';
import type { Site } from './site.model';

export type BeeFormEntryStatus = 'unread' | 'read' | 'spam' | 'trash';

/** One submission. `data` is keyed by field id; files are `{id,name,mime,size}` lists. */
export class BeeFormEntry extends Model<InferAttributes<BeeFormEntry>, InferCreationAttributes<BeeFormEntry>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare formId: ForeignKey<BeeForm['id']>;
  declare status: CreationOptional<BeeFormEntryStatus>;
  declare data: CreationOptional<Json>;
  declare labels: CreationOptional<Json>;
  declare meta: CreationOptional<Json>;
  declare summary: CreationOptional<string>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  declare form?: BeeForm;

  static initModel(sequelize: Sequelize) {
    BeeFormEntry.init(
      {
        id: idColumn(),
        siteId: text(),
        formId: text(),
        status: text({ defaultValue: 'unread' }),
        data: jsonb({}),
        labels: jsonb({}),
        meta: jsonb({}),
        summary: text({ defaultValue: '' }),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'BeeFormEntry',
        modelName: 'BeeFormEntry',
        timestamps: true,
        indexes: [
          { name: 'BeeFormEntry_formId_createdAt_idx', fields: ['formId', 'createdAt'] },
          { name: 'BeeFormEntry_siteId_status_idx', fields: ['siteId', 'status'] },
        ],
      },
    );
  }
}
