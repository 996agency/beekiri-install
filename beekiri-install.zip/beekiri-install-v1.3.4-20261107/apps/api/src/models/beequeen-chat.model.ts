import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { DataTypes } from 'sequelize';
import { date, idColumn, jsonb, optionalText, text, type Json } from './_shared';
import type { Site } from './site.model';
import type { User } from './user.model';

/** One BeeQueen conversation, private to the user who started it. */
export class BeeQueenChat extends Model<InferAttributes<BeeQueenChat>, InferCreationAttributes<BeeQueenChat>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare userId: ForeignKey<User['id']>;
  declare title: CreationOptional<string>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    BeeQueenChat.init(
      {
        id: idColumn(),
        siteId: text(),
        userId: text(),
        title: text({ defaultValue: '' }),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'BeeQueenChat',
        modelName: 'BeeQueenChat',
        timestamps: true,
        indexes: [{ name: 'BeeQueenChat_siteId_userId_updatedAt_idx', fields: ['siteId', 'userId', 'updatedAt'] }],
      },
    );
  }
}

export type BeeQueenMessageRole = 'user' | 'assistant';
export type BeeQueenMessageState = 'done' | 'error' | 'stopped';

/** One turn in a BeeQueen chat; assistant turns keep their steps, links and token usage. */
export class BeeQueenMessage extends Model<
  InferAttributes<BeeQueenMessage>,
  InferCreationAttributes<BeeQueenMessage>
> {
  declare id: CreationOptional<string>;
  declare chatId: ForeignKey<BeeQueenChat['id']>;
  declare role: BeeQueenMessageRole;
  declare text: CreationOptional<string>;
  declare steps: CreationOptional<Json>;
  declare links: CreationOptional<Json>;
  declare state: CreationOptional<BeeQueenMessageState>;
  declare model: CreationOptional<string | null>;
  declare usage: CreationOptional<Json | null>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    BeeQueenMessage.init(
      {
        id: idColumn(),
        chatId: text(),
        role: text(),
        text: text({ defaultValue: '' }),
        steps: jsonb([]),
        links: jsonb([]),
        state: text({ defaultValue: 'done' }),
        model: optionalText(),
        usage: { type: DataTypes.JSONB, allowNull: true },
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'BeeQueenMessage',
        modelName: 'BeeQueenMessage',
        timestamps: true,
        updatedAt: false,
        indexes: [{ name: 'BeeQueenMessage_chatId_createdAt_idx', fields: ['chatId', 'createdAt'] }],
      },
    );
  }
}
