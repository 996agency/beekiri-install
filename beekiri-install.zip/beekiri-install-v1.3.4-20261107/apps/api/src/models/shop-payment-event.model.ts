import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, jsonb, optionalText, text, type Json } from './_shared';
import type { Site } from './site.model';

/** Every payment-provider webhook we accepted, so a replayed event is a no-op. */
export class ShopPaymentEvent extends Model<
  InferAttributes<ShopPaymentEvent>,
  InferCreationAttributes<ShopPaymentEvent>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare provider: string;
  declare eventId: string;
  declare type: CreationOptional<string>;
  declare orderId: CreationOptional<string | null>;
  declare payload: CreationOptional<Json>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    ShopPaymentEvent.init(
      {
        id: idColumn(),
        siteId: text(),
        provider: text(),
        eventId: text(),
        type: text({ defaultValue: '' }),
        orderId: optionalText(),
        payload: jsonb({}),
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopPaymentEvent',
        modelName: 'ShopPaymentEvent',
        timestamps: true,
        updatedAt: false,
        indexes: [
          { name: 'ShopPaymentEvent_provider_eventId_key', unique: true, fields: ['provider', 'eventId'] },
          { name: 'ShopPaymentEvent_orderId_idx', fields: ['orderId'] },
        ],
      },
    );
  }
}
