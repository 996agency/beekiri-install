import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, jsonb, optionalText, text, type Json } from './_shared';
import type { Site } from './site.model';

/**
 * Server-side cart. The id is an unguessable token kept in the `beekiri_cart`
 * cookie; items hold only ids + quantities, prices are always recomputed.
 */
export class ShopCart extends Model<InferAttributes<ShopCart>, InferCreationAttributes<ShopCart>> {
  declare id: string;
  declare siteId: ForeignKey<Site['id']>;
  /** [{ productId, variantId|null, qty }] */
  declare items: CreationOptional<Json>;
  declare couponCode: CreationOptional<string | null>;
  declare email: CreationOptional<string | null>;
  /** Shipping estimate chosen in the cart: { country, state, postcode, shippingMethodId } */
  declare meta: CreationOptional<Json>;
  declare expiresAt: Date;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    ShopCart.init(
      {
        id: { ...idColumn(), defaultValue: undefined },
        siteId: text(),
        items: jsonb([]),
        couponCode: optionalText(),
        email: optionalText(),
        meta: jsonb({}),
        expiresAt: date(),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopCart',
        modelName: 'ShopCart',
        timestamps: true,
        indexes: [{ name: 'ShopCart_siteId_expiresAt_idx', fields: ['siteId', 'expiresAt'] }],
      },
    );
  }
}
