import {
  DataTypes,
  Model,
  type ModelAttributeColumnOptions,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, int, jsonb, optionalDate, text, type Json } from './_shared';
import type { Site } from './site.model';

/** Fresh object per column: Sequelize mutates attribute options during init. */
const optInt = (): ModelAttributeColumnOptions => ({ type: DataTypes.INTEGER, allowNull: true });

/** A discount code. `amount` is a percentage ×100 (12.5% = 1250) or minor units. */
export class ShopCoupon extends Model<InferAttributes<ShopCoupon>, InferCreationAttributes<ShopCoupon>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  /** Stored upper-case. */
  declare code: string;
  /** percent | fixed_cart | fixed_product */
  declare type: CreationOptional<string>;
  declare amount: CreationOptional<number>;
  declare description: CreationOptional<string>;
  declare minSpend: CreationOptional<number | null>;
  declare maxSpend: CreationOptional<number | null>;
  declare usageLimit: CreationOptional<number | null>;
  declare usageLimitPerEmail: CreationOptional<number | null>;
  declare usageCount: CreationOptional<number>;
  declare expiresAt: CreationOptional<Date | null>;
  declare productIds: CreationOptional<Json>;
  declare excludeProductIds: CreationOptional<Json>;
  declare categoryIds: CreationOptional<Json>;
  declare freeShipping: CreationOptional<boolean>;
  declare active: CreationOptional<boolean>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    ShopCoupon.init(
      {
        id: idColumn(),
        siteId: text(),
        code: text(),
        type: text({ defaultValue: 'percent' }),
        amount: int(0),
        description: text({ defaultValue: '' }),
        minSpend: optInt(),
        maxSpend: optInt(),
        usageLimit: optInt(),
        usageLimitPerEmail: optInt(),
        usageCount: int(0),
        expiresAt: optionalDate(),
        productIds: jsonb([]),
        excludeProductIds: jsonb([]),
        categoryIds: jsonb([]),
        freeShipping: bool(false),
        active: bool(true),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopCoupon',
        modelName: 'ShopCoupon',
        timestamps: true,
        indexes: [{ name: 'ShopCoupon_siteId_code_key', unique: true, fields: ['siteId', 'code'] }],
      },
    );
  }
}
