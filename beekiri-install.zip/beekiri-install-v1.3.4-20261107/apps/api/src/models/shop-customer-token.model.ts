import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, optionalDate, text } from './_shared';
import type { ShopCustomer } from './shop-customer.model';
import type { Site } from './site.model';

/** Single-use email links for shoppers: `verify` (confirm email) and `reset` (new password). */
export class ShopCustomerToken extends Model<InferAttributes<ShopCustomerToken>, InferCreationAttributes<ShopCustomerToken>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare customerId: ForeignKey<ShopCustomer['id']>;
  declare kind: string;
  declare tokenHash: string;
  declare expiresAt: Date;
  declare usedAt: CreationOptional<Date | null>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    ShopCustomerToken.init(
      {
        id: idColumn(),
        siteId: text(),
        customerId: text(),
        kind: text(),
        tokenHash: text(),
        expiresAt: date(),
        usedAt: optionalDate(),
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopCustomerToken',
        modelName: 'ShopCustomerToken',
        timestamps: true,
        updatedAt: false,
        indexes: [
          { name: 'ShopCustomerToken_tokenHash_key', unique: true, fields: ['tokenHash'] },
          { name: 'ShopCustomerToken_customerId_idx', fields: ['customerId'] },
        ],
      },
    );
  }
}
