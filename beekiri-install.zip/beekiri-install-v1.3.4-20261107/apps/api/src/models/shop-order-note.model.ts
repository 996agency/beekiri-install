import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, optionalText, text } from './_shared';
import type { ShopOrder } from './shop-order.model';
import type { Site } from './site.model';

/** Private staff notes and customer-facing notes on an order (plus system events). */
export class ShopOrderNote extends Model<
  InferAttributes<ShopOrderNote>,
  InferCreationAttributes<ShopOrderNote>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare orderId: ForeignKey<ShopOrder['id']>;
  /** null = system */
  declare authorId: CreationOptional<string | null>;
  declare note: CreationOptional<string>;
  declare isCustomerNote: CreationOptional<boolean>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    ShopOrderNote.init(
      {
        id: idColumn(),
        siteId: text(),
        orderId: text(),
        authorId: optionalText(),
        note: text({ defaultValue: '' }),
        isCustomerNote: bool(false),
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopOrderNote',
        modelName: 'ShopOrderNote',
        timestamps: true,
        updatedAt: false,
        indexes: [{ name: 'ShopOrderNote_orderId_idx', fields: ['orderId'] }],
      },
    );
  }
}
