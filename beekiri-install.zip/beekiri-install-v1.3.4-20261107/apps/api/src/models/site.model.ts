import {
  DataTypes,
  Model,
  type CreationOptional,
  type InferAttributes,
  type InferCreationAttributes,
  type NonAttribute,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, optionalText, text } from './_shared';
import type { SiteSettings } from './site-settings.model';
import type { User } from './user.model';

export type SiteAccess = {
  /** argon2 hash of the visitor password. */
  passwordHash: string;
  /** Signs the visitor cookie; a new one signs every visitor out. */
  secret: string;
};

export class Site extends Model<InferAttributes<Site>, InferCreationAttributes<Site>> {
  declare id: CreationOptional<string>;
  declare title: string;
  declare tagline: CreationOptional<string>;
  declare language: CreationOptional<string>;
  /** Sub-domain label (`shop` → shop.<network domain>); null for the primary site. */
  declare slug: CreationOptional<string | null>;
  /** Full host of its own (e.g. shop.example.com); optional. */
  declare domain: CreationOptional<string | null>;
  /** `active` or `archived` (archived sites are not served). */
  declare status: CreationOptional<string>;
  /** The site that answers on APP_URL and holds the network settings. */
  declare isPrimary: CreationOptional<boolean>;
  /** Password protection (see lib/site/site-lock.ts); null = open. Left out of every query unless asked for. */
  declare access: CreationOptional<SiteAccess | null>;
  declare installedAt: CreationOptional<Date>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  declare settings?: NonAttribute<SiteSettings | null>;
  declare users?: NonAttribute<User[]>;

  static initModel(sequelize: Sequelize) {
    Site.init(
      {
        id: idColumn(),
        title: text(),
        tagline: text({ defaultValue: '' }),
        language: text({ defaultValue: 'en_US' }),
        slug: optionalText(),
        domain: optionalText(),
        status: text({ defaultValue: 'active' }),
        isPrimary: bool(false),
        access: { type: DataTypes.JSONB, allowNull: true },
        installedAt: date({ defaultValue: DataTypes.NOW }),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'Site',
        modelName: 'Site',
        timestamps: true,
        // The password hash and link token never ride along with a site by accident.
        defaultScope: { attributes: { exclude: ['access'] } },
        indexes: [
          { name: 'Site_slug_key', unique: true, fields: ['slug'] },
          { name: 'Site_domain_key', unique: true, fields: ['domain'] },
        ],
      },
    );
  }
}
