import {
  DataTypes,
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, text } from './_shared';
import type { ShopCustomer } from './shop-customer.model';
import type { Site } from './site.model';

/** A signed-in shopper (cookie `beekiri_customer`); only the sha256 of the token is stored. */
export class ShopCustomerSession extends Model<InferAttributes<ShopCustomerSession>, InferCreationAttributes<ShopCustomerSession>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare customerId: ForeignKey<ShopCustomer['id']>;
  declare tokenHash: string;
  declare expiresAt: Date;
  declare lastSeenAt: CreationOptional<Date>;
  declare userAgent: CreationOptional<string>;
  declare ip: CreationOptional<string>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    ShopCustomerSession.init(
      {
        id: idColumn(),
        siteId: text(),
        customerId: text(),
        tokenHash: text(),
        expiresAt: date(),
        lastSeenAt: date({ defaultValue: DataTypes.NOW }),
        userAgent: text({ defaultValue: '' }),
        ip: text({ defaultValue: '' }),
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopCustomerSession',
        modelName: 'ShopCustomerSession',
        timestamps: true,
        updatedAt: false,
        indexes: [
          { name: 'ShopCustomerSession_tokenHash_key', unique: true, fields: ['tokenHash'] },
          { name: 'ShopCustomerSession_customerId_idx', fields: ['customerId'] },
        ],
      },
    );
  }
}
