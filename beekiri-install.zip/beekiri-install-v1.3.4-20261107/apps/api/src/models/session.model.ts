import {
  DataTypes,
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type NonAttribute,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, optionalText, text } from './_shared';
import type { Site } from './site.model';
import type { User } from './user.model';

export class Session extends Model<InferAttributes<Session>, InferCreationAttributes<Session>> {
  declare id: CreationOptional<string>;
  declare userId: ForeignKey<User['id']>;
  /** The site the session was opened on; it is only valid there. */
  declare siteId: ForeignKey<Site['id']> | null;
  /** sha256 of the cookie token; the raw token is never stored. */
  declare tokenHash: string;
  declare csrfSecret: string;
  declare createdAt: CreationOptional<Date>;
  declare lastSeenAt: CreationOptional<Date>;
  declare absoluteExpiresAt: Date;
  declare idleExpiresAt: Date;
  declare userAgent: string | null;
  declare ip: string | null;

  declare user?: NonAttribute<User>;

  static initModel(sequelize: Sequelize) {
    Session.init(
      {
        id: idColumn(),
        userId: text(),
        siteId: optionalText(),
        tokenHash: text({ unique: 'Session_tokenHash_key' }),
        csrfSecret: text(),
        createdAt: date(),
        lastSeenAt: date({ defaultValue: DataTypes.NOW }),
        absoluteExpiresAt: date(),
        idleExpiresAt: date(),
        userAgent: optionalText(),
        ip: optionalText(),
      },
      {
        sequelize,
        tableName: 'Session',
        modelName: 'Session',
        timestamps: true,
        updatedAt: false,
        indexes: [
          { name: 'Session_userId_idx', fields: ['userId'] },
          { name: 'Session_siteId_idx', fields: ['siteId'] },
        ],
      },
    );
  }
}
