import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { DataTypes } from 'sequelize';
import { date, idColumn, optionalDate, optionalText, text, type Json } from './_shared';
import type { Site } from './site.model';

export type BeeQueenChangeKind = 'theme_file' | 'layout' | 'page' | 'taxonomy' | 'post_type' | 'product' | 'media';

/**
 * One change the Beekiri agent made outside the page editor (a theme file, a layout, a page,
 * a taxonomy), with what it looked like before and after — so it can be reverted from the
 * Connector page's change history.
 */
export class BeeQueenChange extends Model<InferAttributes<BeeQueenChange>, InferCreationAttributes<BeeQueenChange>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare userId: string;
  declare chatId: CreationOptional<string | null>;
  declare runId: string;
  declare kind: BeeQueenChangeKind;
  declare label: string;
  /** Where the change lives (theme + path, layout slug + group key, page id, taxonomy id). */
  declare target: Json;
  /** Null when the agent created it. */
  declare before: CreationOptional<Json | null>;
  declare after: CreationOptional<Json | null>;
  declare revertedAt: CreationOptional<Date | null>;
  declare revertedById: CreationOptional<string | null>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    BeeQueenChange.init(
      {
        id: idColumn(),
        siteId: text(),
        userId: text(),
        chatId: optionalText(),
        runId: text(),
        kind: text(),
        label: text({ defaultValue: '' }),
        target: { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },
        before: { type: DataTypes.JSONB, allowNull: true },
        after: { type: DataTypes.JSONB, allowNull: true },
        revertedAt: optionalDate(),
        revertedById: optionalText(),
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'BeeQueenChange',
        modelName: 'BeeQueenChange',
        timestamps: true,
        updatedAt: false,
        indexes: [{ name: 'BeeQueenChange_siteId_createdAt_idx', fields: ['siteId', 'createdAt'] }],
      },
    );
  }
}
