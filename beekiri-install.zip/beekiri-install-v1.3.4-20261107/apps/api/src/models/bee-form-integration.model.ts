import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, jsonb, optionalText, text, type Json } from './_shared';
import type { Site } from './site.model';

/** A connected CRM account for Bee Forms. `credentials` is encrypted (lib/shop/secrets). */
export class BeeFormIntegration extends Model<InferAttributes<BeeFormIntegration>, InferCreationAttributes<BeeFormIntegration>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare provider: string;
  declare credentials: CreationOptional<string>;
  declare account: CreationOptional<Json>;
  /** connected | error (the token stopped working; reconnect) */
  declare status: CreationOptional<string>;
  declare lastError: CreationOptional<string>;
  declare connectedById: string | null;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    BeeFormIntegration.init(
      {
        id: idColumn(),
        siteId: text(),
        provider: text(),
        credentials: text({ defaultValue: '' }),
        account: jsonb({}),
        status: text({ defaultValue: 'connected' }),
        lastError: text({ defaultValue: '' }),
        connectedById: optionalText(),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'BeeFormIntegration',
        modelName: 'BeeFormIntegration',
        timestamps: true,
        indexes: [{ name: 'BeeFormIntegration_siteId_provider_key', unique: true, fields: ['siteId', 'provider'] }],
      },
    );
  }
}
