import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, int, jsonb, optionalText, text, type Json } from './_shared';
import type { ShopOrder } from './shop-order.model';
import type { Site } from './site.model';

/** A line of an order: a snapshot of the product at purchase time. */
export class ShopOrderItem extends Model<
  InferAttributes<ShopOrderItem>,
  InferCreationAttributes<ShopOrderItem>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare orderId: ForeignKey<ShopOrder['id']>;
  declare productId: CreationOptional<string | null>;
  declare variantId: CreationOptional<string | null>;
  declare name: CreationOptional<string>;
  declare sku: CreationOptional<string>;
  declare qty: CreationOptional<number>;
  declare unitPrice: CreationOptional<number>;
  declare subtotal: CreationOptional<number>;
  declare total: CreationOptional<number>;
  declare taxTotal: CreationOptional<number>;
  declare attributes: CreationOptional<Json>;
  declare imageUrl: CreationOptional<string>;
  declare virtual: CreationOptional<boolean>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    ShopOrderItem.init(
      {
        id: idColumn(),
        siteId: text(),
        orderId: text(),
        productId: optionalText(),
        variantId: optionalText(),
        name: text({ defaultValue: '' }),
        sku: text({ defaultValue: '' }),
        qty: int(1),
        unitPrice: int(0),
        subtotal: int(0),
        total: int(0),
        taxTotal: int(0),
        attributes: jsonb({}),
        imageUrl: text({ defaultValue: '' }),
        virtual: bool(false),
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopOrderItem',
        modelName: 'ShopOrderItem',
        timestamps: true,
        updatedAt: false,
        indexes: [
          { name: 'ShopOrderItem_orderId_idx', fields: ['orderId'] },
          { name: 'ShopOrderItem_productId_idx', fields: ['productId'] },
        ],
      },
    );
  }
}
