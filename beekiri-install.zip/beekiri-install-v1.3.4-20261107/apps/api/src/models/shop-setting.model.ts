import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, int, jsonb, text, type Json } from './_shared';
import type { Site } from './site.model';

/** One row per site: the Shopping extension's settings bag + order-number counter. */
export class ShopSetting extends Model<
  InferAttributes<ShopSetting>,
  InferCreationAttributes<ShopSetting>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare data: CreationOptional<Json>;
  declare nextOrderNumber: CreationOptional<number>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    ShopSetting.init(
      {
        id: idColumn(),
        siteId: text(),
        data: jsonb({}),
        nextOrderNumber: int(1),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopSetting',
        modelName: 'ShopSetting',
        timestamps: true,
        indexes: [{ name: 'ShopSetting_siteId_key', unique: true, fields: ['siteId'] }],
      },
    );
  }
}
