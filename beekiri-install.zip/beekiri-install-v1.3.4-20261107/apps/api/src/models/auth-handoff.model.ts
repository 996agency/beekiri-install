import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, optionalDate, text } from './_shared';
import type { Site } from './site.model';
import type { User } from './user.model';

/** One-time token that opens a session on another site of the network (switch site). */
export class AuthHandoff extends Model<InferAttributes<AuthHandoff>, InferCreationAttributes<AuthHandoff>> {
  declare id: CreationOptional<string>;
  /** sha256 of the token; the raw token only travels in the redirect. */
  declare tokenHash: string;
  declare userId: ForeignKey<User['id']>;
  /** The site the token may be redeemed on. */
  declare siteId: ForeignKey<Site['id']>;
  declare expiresAt: Date;
  declare usedAt: Date | null;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    AuthHandoff.init(
      {
        id: idColumn(),
        tokenHash: text({ unique: 'AuthHandoff_tokenHash_key' }),
        userId: text(),
        siteId: text(),
        expiresAt: date(),
        usedAt: optionalDate(),
        createdAt: date(),
      },
      { sequelize, tableName: 'AuthHandoff', modelName: 'AuthHandoff', timestamps: true, updatedAt: false },
    );
  }
}
