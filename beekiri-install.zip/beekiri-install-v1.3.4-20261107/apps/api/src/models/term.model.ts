import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, int, optionalText, text } from './_shared';
import type { Site } from './site.model';
import type { Taxonomy } from './taxonomy.model';

/** A single term inside a taxonomy (e.g. a category or tag). */
export class Term extends Model<InferAttributes<Term>, InferCreationAttributes<Term>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare taxonomyId: ForeignKey<Taxonomy['id']>;
  declare name: string;
  declare slug: string;
  declare description: CreationOptional<string>;
  declare parentId: CreationOptional<string | null>;
  declare menuOrder: CreationOptional<number>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    Term.init(
      {
        id: idColumn(),
        siteId: text(),
        taxonomyId: text(),
        name: text(),
        slug: text(),
        description: text({ defaultValue: '' }),
        parentId: optionalText(),
        menuOrder: int(0),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'Term',
        modelName: 'Term',
        timestamps: true,
        indexes: [
          { name: 'Term_siteId_taxonomyId_idx', fields: ['siteId', 'taxonomyId'] },
          { name: 'Term_taxonomyId_slug_key', unique: true, fields: ['taxonomyId', 'slug'] },
        ],
      },
    );
  }
}
