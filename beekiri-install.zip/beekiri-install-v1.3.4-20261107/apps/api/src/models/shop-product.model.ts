import {
  DataTypes,
  Model,
  type ModelAttributeColumnOptions,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type NonAttribute,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, int, jsonb, optionalDate, text, type Json } from './_shared';
import type { Post } from './post.model';
import type { ShopProductVariant } from './shop-product-variant.model';
import type { Site } from './site.model';

/** Fresh object per column: Sequelize mutates attribute options during init. */
const optInt = (): ModelAttributeColumnOptions => ({ type: DataTypes.INTEGER, allowNull: true });

/**
 * Commerce data for a product. Title, slug, description, featured image, SEO and
 * categories live on the `Post` row (type `product`); money is in minor units.
 */
export class ShopProduct extends Model<
  InferAttributes<ShopProduct>,
  InferCreationAttributes<ShopProduct>
> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare postId: ForeignKey<Post['id']>;
  /** simple | variable */
  declare type: CreationOptional<string>;
  declare sku: CreationOptional<string>;
  declare regularPrice: CreationOptional<number | null>;
  declare salePrice: CreationOptional<number | null>;
  declare saleFrom: CreationOptional<Date | null>;
  declare saleTo: CreationOptional<Date | null>;
  declare manageStock: CreationOptional<boolean>;
  declare stockQty: CreationOptional<number | null>;
  /** instock | outofstock | onbackorder */
  declare stockStatus: CreationOptional<string>;
  declare lowStockThreshold: CreationOptional<number | null>;
  declare soldIndividually: CreationOptional<boolean>;
  /** grams */
  declare weight: CreationOptional<number | null>;
  /** millimetres */
  declare length: CreationOptional<number | null>;
  declare width: CreationOptional<number | null>;
  declare height: CreationOptional<number | null>;
  declare virtual: CreationOptional<boolean>;
  declare taxable: CreationOptional<boolean>;
  /** MediaAsset ids */
  declare galleryIds: CreationOptional<Json>;
  /** [{ name, options[], visible, variation }] */
  declare attributes: CreationOptional<Json>;
  declare purchaseNote: CreationOptional<string>;
  declare featured: CreationOptional<boolean>;
  /** visible | catalog | search | hidden */
  declare catalogVisibility: CreationOptional<string>;
  declare totalSales: CreationOptional<number>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  declare post?: NonAttribute<Post>;
  declare variants?: NonAttribute<ShopProductVariant[]>;

  static initModel(sequelize: Sequelize) {
    ShopProduct.init(
      {
        id: idColumn(),
        siteId: text(),
        postId: text(),
        type: text({ defaultValue: 'simple' }),
        sku: text({ defaultValue: '' }),
        regularPrice: optInt(),
        salePrice: optInt(),
        saleFrom: optionalDate(),
        saleTo: optionalDate(),
        manageStock: bool(false),
        stockQty: optInt(),
        stockStatus: text({ defaultValue: 'instock' }),
        lowStockThreshold: optInt(),
        soldIndividually: bool(false),
        weight: optInt(),
        length: optInt(),
        width: optInt(),
        height: optInt(),
        virtual: bool(false),
        taxable: bool(true),
        galleryIds: jsonb([]),
        attributes: jsonb([]),
        purchaseNote: text({ defaultValue: '' }),
        featured: bool(false),
        catalogVisibility: text({ defaultValue: 'visible' }),
        totalSales: int(0),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopProduct',
        modelName: 'ShopProduct',
        timestamps: true,
        indexes: [
          { name: 'ShopProduct_postId_key', unique: true, fields: ['postId'] },
          { name: 'ShopProduct_siteId_idx', fields: ['siteId'] },
          { name: 'ShopProduct_siteId_sku_idx', fields: ['siteId', 'sku'] },
        ],
      },
    );
  }
}
