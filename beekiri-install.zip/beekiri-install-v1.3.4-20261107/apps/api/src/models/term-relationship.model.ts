import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, text } from './_shared';
import type { Post } from './post.model';
import type { Term } from './term.model';

/** Links a post/page to a taxonomy term. */
export class TermRelationship extends Model<
  InferAttributes<TermRelationship>,
  InferCreationAttributes<TermRelationship>
> {
  declare id: CreationOptional<string>;
  declare postId: ForeignKey<Post['id']>;
  declare termId: ForeignKey<Term['id']>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    TermRelationship.init(
      {
        id: idColumn(),
        postId: text(),
        termId: text(),
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'TermRelationship',
        modelName: 'TermRelationship',
        timestamps: true,
        updatedAt: false,
        indexes: [
          { name: 'TermRelationship_postId_idx', fields: ['postId'] },
          {
            name: 'TermRelationship_postId_termId_key',
            unique: true,
            fields: ['postId', 'termId'],
          },
        ],
      },
    );
  }
}
