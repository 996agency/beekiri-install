import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type NonAttribute,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, jsonb, text, type Json } from './_shared';
import type { Role } from './role.model';
import type { Site } from './site.model';
import type { User } from './user.model';

/**
 * A person's access to one site of the network: their role there and the per-user
 * capability grants/denies (`{ capabilityGrants?: string[], capabilityDenies?: string[] }`).
 * The network owner can use every site without a row.
 */
export class UserSite extends Model<InferAttributes<UserSite>, InferCreationAttributes<UserSite>> {
  declare id: CreationOptional<string>;
  declare userId: ForeignKey<User['id']>;
  declare siteId: ForeignKey<Site['id']>;
  declare roleId: ForeignKey<Role['id']>;
  declare profile: CreationOptional<Json>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  declare role?: NonAttribute<Role>;
  declare site?: NonAttribute<Site>;
  declare user?: NonAttribute<User>;

  static initModel(sequelize: Sequelize) {
    UserSite.init(
      {
        id: idColumn(),
        userId: text(),
        siteId: text(),
        roleId: text(),
        profile: jsonb({}),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'UserSite',
        modelName: 'UserSite',
        timestamps: true,
        indexes: [
          { name: 'UserSite_userId_siteId_key', unique: true, fields: ['userId', 'siteId'] },
          { name: 'UserSite_siteId_idx', fields: ['siteId'] },
        ],
      },
    );
  }
}
