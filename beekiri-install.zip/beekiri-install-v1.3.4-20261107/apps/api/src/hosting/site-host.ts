import express, { type Express, type NextFunction, type Request, type Response } from 'express';
import { existsSync, readFileSync } from 'fs';
import type { IncomingMessage, Server, ServerResponse } from 'http';
import { createRequire } from 'module';
import { join } from 'path';
import { pathToFileURL } from 'url';
import { config } from '../config/env';
import { REPO_ROOT } from '../config/paths';
import {
  DEFAULT_ADMIN_BASE_PATH,
  isAdminSpaDocumentPath,
} from '../lib/site/admin-login';
import { resolveAdminBasePath, resolveAdminEntry } from '../lib/site/admin-base-cache';
import { adminDocumentCsp, websiteCsp } from '../middleware/security';
import { translationsService } from '../services/translations.service';

const ADMIN_DIR = join(REPO_ROOT, 'apps/admin');
const WEB_DIR = join(REPO_ROOT, 'apps/web');
/** Built/Vite assets always live under `/admin` (vite base), even if the SPA mount moves. */
const ADMIN_ASSET = /^\/admin(\/.*)?$/;
const BUILD_HINT = 'Run "npm run build" (npm start does this automatically).';

type Handler = (req: IncomingMessage, res: ServerResponse) => unknown;

/** Never language-prefixed: framework assets, the API, uploads, runtime scripts. */
const LANGUAGE_PASSTHROUGH = /^\/(?:_next|api|uploads|runtime|web-api|bk-preview)(?:\/|$)/;

/**
 * Settings → Translation: `/de/about` is served by the website as `/about` with the
 * language in `x-beekiri-lang`; `x-beekiri-path` always carries the neutral path so the
 * language switcher can link every page in every language. `/xx/…` for the primary
 * language permanently redirects to the unprefixed URL.
 */
async function routeLanguage(req: Request, res: Response): Promise<boolean> {
  delete req.headers['x-beekiri-lang'];
  delete req.headers['x-beekiri-path'];
  const qs = req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : '';
  const path = req.path;
  if (LANGUAGE_PASSTHROUGH.test(path)) return false;

  const { primaryLanguage, prefixes } = await translationsService.languageRouting();
  const match = /^\/([^/]+)(\/.*)?$/.exec(path);
  const segment = match?.[1]?.toLowerCase() ?? '';
  const rest = match?.[2] && match[2] !== '' ? match[2] : '/';

  if (segment && segment === primaryLanguage.toLowerCase() && (req.method === 'GET' || req.method === 'HEAD')) {
    res.redirect(301, `${rest}${qs}`);
    return true;
  }
  const code = segment ? prefixes.get(segment) : undefined;
  if (code) {
    req.url = `${rest}${qs}`;
    req.headers['x-beekiri-lang'] = code;
    req.headers['x-beekiri-path'] = rest;
  } else {
    req.headers['x-beekiri-lang'] = primaryLanguage;
    req.headers['x-beekiri-path'] = path;
  }
  return false;
}

export type SiteHost = {
  /** Adds /admin and (when enabled) the website to the Express app, after /api. */
  mount(app: Express): void;
  close(): Promise<void>;
};

type Options = {
  /** Development: live admin (Vite) and website (next dev). Otherwise the production builds. */
  dev: boolean;
  /** The HTTP server, for hot-reload websockets in development. */
  server: Server;
  /** Address of this server, used by the website to call the API in-process. */
  selfUrl: string;
  /** False in setup mode: without a database there is no website to show yet. */
  website: boolean;
};

/** Native ESM import that survives compilation to CommonJS (Vite's Node API is ESM-only). */
const importEsm = new Function('specifier', 'return import(specifier)') as (
  specifier: string,
) => Promise<Record<string, unknown>>;

type AdminEntryMeta = { basePath: string; loginSlug: string };
type AdminPage = (
  req: Request,
  res: Response,
  next: NextFunction,
  entry?: AdminEntryMeta,
) => unknown;

const escapeAttr = (value: string) =>
  value.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

/**
 * The admin learns its own (possibly secret) address from the page that serves it,
 * which is only sent at that address, instead of from a public API anyone can call.
 */
function withAdminEntry(html: string, entry?: AdminEntryMeta): string {
  if (!entry) return html;
  const meta = `<meta name="beekiri-admin-entry" content="${escapeAttr(JSON.stringify(entry))}" />`;
  return html.replace('</head>', `    ${meta}\n  </head>`);
}

async function adminMiddleware(
  dev: boolean,
  server: Server,
): Promise<{
  assets: (req: Request, res: Response, next: NextFunction) => unknown;
  page: AdminPage;
  close: () => Promise<unknown>;
}> {
  if (!dev) {
    const dist = join(ADMIN_DIR, 'dist');
    const indexFile = join(dist, 'index.html');
    if (!existsSync(indexFile)) throw new Error(`The admin is not built. ${BUILD_HINT}`);

    // Mounted at /admin so /admin/assets/x.js resolves to dist/assets/x.js.
    const assets = express.Router();
    assets.use(
      '/admin',
      express.static(dist, {
        index: false,
        // Built file names carry a content hash, so they never change.
        setHeaders(res, path) {
          if (path.includes(`${join(dist, 'assets')}`)) {
            res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
          }
        },
      }),
    );
    return {
      assets: (req: Request, res: Response, next: NextFunction) => assets(req, res, next),
      // Read index.html per request so a mid-run `npm run build -w @beekiri/admin`
      // picks up new hashed asset URLs (stale HTML → 404 JS → white screen).
      page: (req: Request, res: Response, _next: NextFunction, entry?: AdminEntryMeta) => {
        // Missing hashed assets must 404 as text, not fall through to the SPA shell
        // (browsers reject JS/CSS when MIME is text/html → white screen).
        if (req.path.startsWith('/admin/assets/')) {
          res.status(404).type('text').send('Not found');
          return;
        }
        if (!existsSync(indexFile)) {
          res.status(503).type('text').send(`The admin is not built. ${BUILD_HINT}`);
          return;
        }
        const html = withAdminEntry(readFileSync(indexFile, 'utf8'), entry);
        res.setHeader('Cache-Control', 'no-store');
        res.setHeader('X-Robots-Tag', 'noindex, nofollow');
        res.setHeader('Content-Security-Policy', adminDocumentCsp(html, req.get('host')));
        res.type('html').send(html);
      },
      close: async () => undefined,
    };
  }

  const viteDir = join(
    createRequire(join(ADMIN_DIR, 'package.json')).resolve('vite/package.json'),
    '..',
  );
  const { createServer } = (await importEsm(
    pathToFileURL(join(viteDir, 'dist/node/index.js')).href,
  )) as { createServer: (options: object) => Promise<ViteDevServer> };
  const vite = await createServer({
    root: ADMIN_DIR,
    configFile: join(ADMIN_DIR, 'vite.config.ts'),
    appType: 'custom',
    server: { middlewareMode: true, hmr: { server } },
  });
  return {
    assets: (req: Request, res: Response, next: NextFunction) => vite.middlewares(req, res, next),
    page: async (req: Request, res: Response, next: NextFunction, entry?: AdminEntryMeta) => {
      try {
        const html = readFileSync(join(ADMIN_DIR, 'index.html'), 'utf8');
        res.setHeader('X-Robots-Tag', 'noindex, nofollow');
        res.type('html').send(
          withAdminEntry(await vite.transformIndexHtml(req.originalUrl, html), entry),
        );
      } catch (error) {
        next(error);
      }
    },
    close: () => vite.close(),
  };
}

type ViteDevServer = {
  middlewares: (req: IncomingMessage, res: ServerResponse, next: (err?: unknown) => void) => void;
  transformIndexHtml(url: string, html: string): Promise<string>;
  close(): Promise<void>;
};

type NextApp = {
  prepare(): Promise<void>;
  getRequestHandler(): Handler;
  close?(): Promise<void>;
};

async function websiteHandler(dev: boolean, server: Server, selfUrl: string) {
  const distDir = dev ? '.next-dev' : '.next';
  if (!dev && !existsSync(join(WEB_DIR, distDir, 'BUILD_ID'))) {
    throw new Error(`The website is not built. ${BUILD_HINT}`);
  }

  // The website reads these from its own environment (apps/web/src/lib/env.ts).
  process.env.API_URL = selfUrl;
  process.env.APP_URL = config.urls.app ?? selfUrl;
  process.env.NEXT_DIST_DIR = distDir;

  const webRequire = createRequire(join(WEB_DIR, 'package.json'));
  const nextModule = webRequire('next') as { default?: unknown };
  const createNext = (nextModule.default ?? nextModule) as (options: object) => NextApp;
  const port = Number(new URL(selfUrl).port);
  const nextApp = createNext({
    dev,
    dir: WEB_DIR,
    hostname: 'localhost',
    port,
    httpServer: server,
  });
  await nextApp.prepare();
  return { handle: nextApp.getRequestHandler(), close: async () => nextApp.close?.() };
}

/** The admin SPA (customizable mount) + website on the API's own server. */
export async function createSiteHost({
  dev,
  server,
  selfUrl,
  website,
}: Options): Promise<SiteHost> {
  const admin = await adminMiddleware(dev, server);
  const site = website ? await websiteHandler(dev, server, selfUrl) : null;
  // Warm cache so the first document request is fast.
  void resolveAdminBasePath();

  return {
    mount(app) {
      // SPA shell for the configured admin base (default `/admin`, or a secret path).
      // Always also serve `/admin/install` so first-time setup works before options exist.
      app.use(async (req, res, next) => {
        if (req.method !== 'GET' && req.method !== 'HEAD') return next();
        try {
          const base = website
            ? await resolveAdminBasePath()
            : DEFAULT_ADMIN_BASE_PATH;
          const path = req.path;
          const installPath =
            path === '/admin/install' || path.startsWith('/admin/install/');
          if (isAdminSpaDocumentPath(path, base)) {
            // Only a request that already knows the admin address is told the sign-in slug.
            const entry = website ? await resolveAdminEntry() : undefined;
            return admin.page(req, res, next, entry);
          }
          if (installPath) return admin.page(req, res, next);
          // Former `/admin` document URLs (after a custom base move) fall through to
          // the public site → themed 404. Vite/dist assets still match below.
          return next();
        } catch (error) {
          return next(error);
        }
      });

      // Vite (dev) or dist assets (prod) — always under `/admin` (vite `base`).
      // Document paths under /admin (after a custom SPA mount) skip this and hit
      // the public site’s themed 404 instead of a bare “Not Found” response.
      app.use((req, res, next) => {
        if (!ADMIN_ASSET.test(req.path)) return next();
        const path = req.path;
        const assetLike =
          path.startsWith('/admin/assets/') ||
          path.startsWith('/admin/@') ||
          path.startsWith('/admin/src/') ||
          path.startsWith('/admin/node_modules/') ||
          path.startsWith('/admin/connector/') ||
          /\.[a-z0-9]+$/i.test(path);
        if (!assetLike) return next();
        const originalUrl = req.url;
        admin.assets(req, res, (err?: unknown) => {
          if (req.url !== originalUrl) req.url = originalUrl;
          next(err);
        });
      });

      if (site) {
        app.use(async (req, res, next) => {
          try {
            if (await routeLanguage(req, res)) return;
          } catch (error) {
            return next(error);
          }
          if (!res.getHeader('Content-Security-Policy')) {
            res.setHeader('Content-Security-Policy', websiteCsp());
          }
          return site.handle(req, res);
        });
      } else {
        // Setup mode: everything leads to the setup wizard.
        app.get('/', (_req, res) => res.redirect('/admin/install'));
      }
    },
    async close() {
      await Promise.allSettled([admin.close(), site?.close()]);
    },
  };
}
