import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

/** Bee Forms extension: form definitions and their entries. */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.createTable(
      'BeeForm',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        title: { type: DataTypes.TEXT, allowNull: false },
        status: { type: DataTypes.TEXT, allowNull: false, defaultValue: 'active' },
        fields: { type: DataTypes.JSONB, allowNull: false, defaultValue: [] },
        settings: { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },
        entryCount: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        unreadCount: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        lastEntryAt: { type: TIMESTAMP, allowNull: true },
        createdById: { type: DataTypes.TEXT, allowNull: true },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.addIndex('BeeForm', ['siteId', 'updatedAt'], { name: 'BeeForm_siteId_updatedAt_idx', transaction });

    await queryInterface.createTable(
      'BeeFormEntry',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        formId: { type: DataTypes.TEXT, allowNull: false },
        status: { type: DataTypes.TEXT, allowNull: false, defaultValue: 'unread' },
        data: { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },
        /** Field labels at submit time, so old entries still read well after a form changes. */
        labels: { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },
        meta: { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },
        /** Short text for list rows (first text/email answers). */
        summary: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.addIndex('BeeFormEntry', ['formId', 'createdAt'], { name: 'BeeFormEntry_formId_createdAt_idx', transaction });
    await queryInterface.addIndex('BeeFormEntry', ['siteId', 'status'], { name: 'BeeFormEntry_siteId_status_idx', transaction });

    for (const table of ['BeeForm', 'BeeFormEntry']) {
      await queryInterface.addConstraint(table, {
        type: 'foreign key',
        name: `${table}_siteId_fkey`,
        fields: ['siteId'],
        references: { table: 'Site', field: 'id' },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
        transaction,
      });
    }
    await queryInterface.addConstraint('BeeFormEntry', {
      type: 'foreign key',
      name: 'BeeFormEntry_formId_fkey',
      fields: ['formId'],
      references: { table: 'BeeForm', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.dropTable('BeeFormEntry', { transaction });
    await queryInterface.dropTable('BeeForm', { transaction });
  });
}
