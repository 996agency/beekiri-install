import { DataTypes, type QueryInterface } from 'sequelize';

/**
 * Heatmap clicks belong to the theme that was active when they happened (its client slug), so a
 * theme switch starts a fresh heatmap and switching back brings the old one back. Existing
 * clicks: the theme whose ready-made pages were installed most recently before the click, else
 * the Beekiri starter (`beekiri-child`).
 */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.addColumn('BeeCookieClick', 'theme', { type: DataTypes.TEXT, allowNull: true }, { transaction });
    await queryInterface.addIndex('BeeCookieClick', ['siteId', 'theme', 'createdAt'], {
      name: 'BeeCookieClick_siteId_theme_createdAt_idx',
      transaction,
    });
    await queryInterface.sequelize.query(
      `UPDATE "BeeCookieClick" c SET theme = (
          SELECT tc.key FROM "SiteSettings" s, jsonb_each(COALESCE(s.options::jsonb -> 'themeContent', '{}'::jsonb)) tc
           WHERE s."siteId" = c."siteId"
             AND (tc.value ->> 'installedAt') <> ''
             AND (tc.value ->> 'installedAt')::timestamptz <= c."createdAt"
           ORDER BY (tc.value ->> 'installedAt')::timestamptz DESC LIMIT 1)
        WHERE c.theme IS NULL`,
      { transaction },
    );
    await queryInterface.sequelize.query(`UPDATE "BeeCookieClick" SET theme = 'beekiri-child' WHERE theme IS NULL`, { transaction });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.removeIndex('BeeCookieClick', 'BeeCookieClick_siteId_theme_createdAt_idx', { transaction });
    await queryInterface.removeColumn('BeeCookieClick', 'theme', { transaction });
  });
}
