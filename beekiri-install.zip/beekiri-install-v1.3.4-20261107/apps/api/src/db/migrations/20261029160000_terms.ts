import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

/** Taxonomy terms + post ↔ term relationships (categories / tags style). */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.createTable(
      'Term',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        taxonomyId: { type: DataTypes.TEXT, allowNull: false },
        name: { type: DataTypes.TEXT, allowNull: false },
        slug: { type: DataTypes.TEXT, allowNull: false },
        description: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        parentId: { type: DataTypes.TEXT, allowNull: true },
        menuOrder: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false },
      },
      { transaction },
    );

    await queryInterface.createTable(
      'TermRelationship',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        postId: { type: DataTypes.TEXT, allowNull: false },
        termId: { type: DataTypes.TEXT, allowNull: false },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );

    await queryInterface.addIndex('Term', ['siteId', 'taxonomyId'], {
      name: 'Term_siteId_taxonomyId_idx',
      transaction,
    });
    await queryInterface.addIndex('Term', ['taxonomyId', 'slug'], {
      name: 'Term_taxonomyId_slug_key',
      unique: true,
      transaction,
    });
    await queryInterface.addIndex('TermRelationship', ['postId'], {
      name: 'TermRelationship_postId_idx',
      transaction,
    });
    await queryInterface.addIndex('TermRelationship', ['postId', 'termId'], {
      name: 'TermRelationship_postId_termId_key',
      unique: true,
      transaction,
    });

    await queryInterface.addConstraint('Term', {
      type: 'foreign key',
      name: 'Term_siteId_fkey',
      fields: ['siteId'],
      references: { table: 'Site', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
    await queryInterface.addConstraint('Term', {
      type: 'foreign key',
      name: 'Term_taxonomyId_fkey',
      fields: ['taxonomyId'],
      references: { table: 'Taxonomy', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
    await queryInterface.addConstraint('TermRelationship', {
      type: 'foreign key',
      name: 'TermRelationship_postId_fkey',
      fields: ['postId'],
      references: { table: 'Post', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
    await queryInterface.addConstraint('TermRelationship', {
      type: 'foreign key',
      name: 'TermRelationship_termId_fkey',
      fields: ['termId'],
      references: { table: 'Term', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.dropTable('TermRelationship', { transaction });
    await queryInterface.dropTable('Term', { transaction });
  });
}
