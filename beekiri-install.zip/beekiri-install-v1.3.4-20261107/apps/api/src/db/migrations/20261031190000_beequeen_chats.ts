import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

/** BeeQueen chat history: one chat per conversation, owned by the user who started it. */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.createTable(
      'BeeQueenChat',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        userId: { type: DataTypes.TEXT, allowNull: false },
        title: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.addIndex('BeeQueenChat', ['siteId', 'userId', 'updatedAt'], {
      name: 'BeeQueenChat_siteId_userId_updatedAt_idx',
      transaction,
    });
    for (const [field, table] of [
      ['siteId', 'Site'],
      ['userId', 'User'],
    ] as const) {
      await queryInterface.addConstraint('BeeQueenChat', {
        type: 'foreign key',
        name: `BeeQueenChat_${field}_fkey`,
        fields: [field],
        references: { table, field: 'id' },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
        transaction,
      });
    }

    await queryInterface.createTable(
      'BeeQueenMessage',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        chatId: { type: DataTypes.TEXT, allowNull: false },
        role: { type: DataTypes.TEXT, allowNull: false },
        text: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        steps: { type: DataTypes.JSONB, allowNull: false, defaultValue: [] },
        links: { type: DataTypes.JSONB, allowNull: false, defaultValue: [] },
        state: { type: DataTypes.TEXT, allowNull: false, defaultValue: 'done' },
        model: { type: DataTypes.TEXT, allowNull: true },
        /** Token counts for the run (input, output, cache) — the basis for per-user billing. */
        usage: { type: DataTypes.JSONB, allowNull: true },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.addIndex('BeeQueenMessage', ['chatId', 'createdAt'], {
      name: 'BeeQueenMessage_chatId_createdAt_idx',
      transaction,
    });
    await queryInterface.addConstraint('BeeQueenMessage', {
      type: 'foreign key',
      name: 'BeeQueenMessage_chatId_fkey',
      fields: ['chatId'],
      references: { table: 'BeeQueenChat', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.dropTable('BeeQueenMessage');
  await queryInterface.dropTable('BeeQueenChat');
}
