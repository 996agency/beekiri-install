import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

/**
 * BeeQueen pay-as-you-go: a credit balance per user, an append-only credit history,
 * and payment orders (Stripe / PayPal). Also adds the `use_beequeen` capability.
 */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    const fk = async (table: string, field: string, ref: string, onDelete = 'CASCADE') =>
      queryInterface.addConstraint(table, {
        type: 'foreign key',
        name: `${table}_${field}_fkey`,
        fields: [field],
        references: { table: ref, field: 'id' },
        onDelete,
        onUpdate: 'CASCADE',
        transaction,
      });

    await queryInterface.createTable(
      'BeeCreditAccount',
      {
        userId: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        /** Whole credits; may dip below zero after a run that cost more than was left. */
        balance: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await fk('BeeCreditAccount', 'userId', 'User');
    await fk('BeeCreditAccount', 'siteId', 'Site');

    await queryInterface.createTable(
      'BeeCreditTransaction',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        userId: { type: DataTypes.TEXT, allowNull: false },
        /** Signed: purchases and grants add, usage subtracts. */
        amount: { type: DataTypes.INTEGER, allowNull: false },
        balanceAfter: { type: DataTypes.INTEGER, allowNull: false },
        kind: { type: DataTypes.TEXT, allowNull: false },
        description: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        orderId: { type: DataTypes.TEXT, allowNull: true },
        chatId: { type: DataTypes.TEXT, allowNull: true },
        createdById: { type: DataTypes.TEXT, allowNull: true },
        /** Usage details: model, tokens, USD cost — kept for the owner's reports. */
        meta: { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.addIndex('BeeCreditTransaction', ['siteId', 'userId', 'createdAt'], {
      name: 'BeeCreditTransaction_siteId_userId_createdAt_idx',
      transaction,
    });
    await fk('BeeCreditTransaction', 'userId', 'User');
    await fk('BeeCreditTransaction', 'siteId', 'Site');

    await queryInterface.createTable(
      'BeeCreditOrder',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        userId: { type: DataTypes.TEXT, allowNull: false },
        packId: { type: DataTypes.TEXT, allowNull: false },
        packName: { type: DataTypes.TEXT, allowNull: false },
        credits: { type: DataTypes.INTEGER, allowNull: false },
        /** Minor units (cents) in `currency`. */
        amountMinor: { type: DataTypes.INTEGER, allowNull: false },
        currency: { type: DataTypes.TEXT, allowNull: false },
        provider: { type: DataTypes.TEXT, allowNull: false },
        providerRef: { type: DataTypes.TEXT, allowNull: true },
        status: { type: DataTypes.TEXT, allowNull: false, defaultValue: 'pending' },
        paidAt: { type: TIMESTAMP, allowNull: true },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.addIndex('BeeCreditOrder', ['provider', 'providerRef'], {
      name: 'BeeCreditOrder_provider_providerRef_key',
      unique: true,
      transaction,
    });
    await queryInterface.addIndex('BeeCreditOrder', ['siteId', 'createdAt'], {
      name: 'BeeCreditOrder_siteId_createdAt_idx',
      transaction,
    });
    await fk('BeeCreditOrder', 'userId', 'User');
    await fk('BeeCreditOrder', 'siteId', 'Site');

    // `use_beequeen`: on for administrators; the owner grants it to client accounts in User Permissions.
    await queryInterface.sequelize.query(
      `INSERT INTO "Capability" (id, slug, name)
       SELECT 'cap_' || md5(random()::text || clock_timestamp()::text), 'use_beequeen', 'use_beequeen'
       WHERE NOT EXISTS (SELECT 1 FROM "Capability" WHERE slug = 'use_beequeen')`,
      { transaction },
    );
    await queryInterface.sequelize.query(
      `INSERT INTO "_CapabilityToRole" ("A", "B")
       SELECT c.id, r.id FROM "Capability" c, "Role" r
       WHERE c.slug = 'use_beequeen' AND r.slug = 'administrator'
         AND NOT EXISTS (SELECT 1 FROM "_CapabilityToRole" x WHERE x."A" = c.id AND x."B" = r.id)`,
      { transaction },
    );
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.dropTable('BeeCreditOrder');
  await queryInterface.dropTable('BeeCreditTransaction');
  await queryInterface.dropTable('BeeCreditAccount');
  await queryInterface.sequelize.query(
    `DELETE FROM "_CapabilityToRole" WHERE "A" IN (SELECT id FROM "Capability" WHERE slug = 'use_beequeen')`,
  );
  await queryInterface.sequelize.query(`DELETE FROM "Capability" WHERE slug = 'use_beequeen'`);
}
