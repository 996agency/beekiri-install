import type { QueryInterface } from 'sequelize';
import { up as createCreditTables } from './20261031200000_beequeen_credits';

/**
 * BeeQueen billing moved to the BeeQueen service (996Agency): credits and packs live
 * there, per connected site. Drop the short-lived per-user wallet tables; the
 * `use_beequeen` capability from the earlier migration stays.
 */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.dropTable('BeeCreditOrder', { transaction });
    await queryInterface.dropTable('BeeCreditTransaction', { transaction });
    await queryInterface.dropTable('BeeCreditAccount', { transaction });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await createCreditTables(queryInterface);
}
