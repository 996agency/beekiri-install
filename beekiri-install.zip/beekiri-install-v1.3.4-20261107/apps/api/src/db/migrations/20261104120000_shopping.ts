import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

const id = { type: DataTypes.TEXT, allowNull: false, primaryKey: true } as const;
const siteId = { type: DataTypes.TEXT, allowNull: false } as const;
const text = (defaultValue = '') => ({ type: DataTypes.TEXT, allowNull: false, defaultValue });
const optText = { type: DataTypes.TEXT, allowNull: true } as const;
const int = (defaultValue = 0) => ({ type: DataTypes.INTEGER, allowNull: false, defaultValue });
const optInt = { type: DataTypes.INTEGER, allowNull: true } as const;
const bool = (defaultValue: boolean) => ({ type: DataTypes.BOOLEAN, allowNull: false, defaultValue });
const jsonb = (defaultValue: unknown) => ({ type: DataTypes.JSONB, allowNull: false, defaultValue });
const optDate = { type: TIMESTAMP, allowNull: true } as const;
const timestamps = {
  createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
  updatedAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
};

/**
 * Shopping extension: settings, products (1:1 with Post rows of type `product`),
 * variants, carts, customers, orders, coupons and the payment-webhook ledger.
 */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    const fk = (
      table: string,
      field: string,
      ref: string,
      onDelete: 'CASCADE' | 'SET NULL',
    ) =>
      queryInterface.addConstraint(table, {
        type: 'foreign key',
        name: `${table}_${field}_fkey`,
        fields: [field],
        references: { table: ref, field: 'id' },
        onDelete,
        onUpdate: 'CASCADE',
        transaction,
      });
    const index = (table: string, fields: string[], unique = false) =>
      queryInterface.addIndex(table, fields, {
        name: `${table}_${fields.join('_')}_${unique ? 'key' : 'idx'}`,
        unique,
        transaction,
      });

    await queryInterface.createTable(
      'ShopSetting',
      {
        id,
        siteId,
        data: jsonb({}),
        nextOrderNumber: int(1),
        ...timestamps,
      },
      { transaction },
    );
    await index('ShopSetting', ['siteId'], true);
    await fk('ShopSetting', 'siteId', 'Site', 'CASCADE');

    await queryInterface.createTable(
      'ShopProduct',
      {
        id,
        siteId,
        postId: { type: DataTypes.TEXT, allowNull: false },
        type: text('simple'),
        sku: text(''),
        regularPrice: optInt,
        salePrice: optInt,
        saleFrom: optDate,
        saleTo: optDate,
        manageStock: bool(false),
        stockQty: optInt,
        stockStatus: text('instock'),
        lowStockThreshold: optInt,
        soldIndividually: bool(false),
        weight: optInt,
        length: optInt,
        width: optInt,
        height: optInt,
        virtual: bool(false),
        taxable: bool(true),
        galleryIds: jsonb([]),
        attributes: jsonb([]),
        purchaseNote: text(''),
        featured: bool(false),
        catalogVisibility: text('visible'),
        totalSales: int(0),
        ...timestamps,
      },
      { transaction },
    );
    await index('ShopProduct', ['postId'], true);
    await index('ShopProduct', ['siteId']);
    await index('ShopProduct', ['siteId', 'sku']);
    await fk('ShopProduct', 'siteId', 'Site', 'CASCADE');
    await fk('ShopProduct', 'postId', 'Post', 'CASCADE');

    await queryInterface.createTable(
      'ShopProductVariant',
      {
        id,
        siteId,
        productId: { type: DataTypes.TEXT, allowNull: false },
        sku: text(''),
        attributes: jsonb({}),
        regularPrice: optInt,
        salePrice: optInt,
        saleFrom: optDate,
        saleTo: optDate,
        manageStock: bool(false),
        stockQty: optInt,
        stockStatus: text('instock'),
        weight: optInt,
        imageId: optText,
        enabled: bool(true),
        menuOrder: int(0),
        ...timestamps,
      },
      { transaction },
    );
    await index('ShopProductVariant', ['productId']);
    await fk('ShopProductVariant', 'siteId', 'Site', 'CASCADE');
    await fk('ShopProductVariant', 'productId', 'ShopProduct', 'CASCADE');

    await queryInterface.createTable(
      'ShopCart',
      {
        id,
        siteId,
        items: jsonb([]),
        couponCode: optText,
        email: optText,
        expiresAt: { type: TIMESTAMP, allowNull: false },
        ...timestamps,
      },
      { transaction },
    );
    await index('ShopCart', ['siteId', 'expiresAt']);
    await fk('ShopCart', 'siteId', 'Site', 'CASCADE');

    await queryInterface.createTable(
      'ShopCustomer',
      {
        id,
        siteId,
        email: { type: DataTypes.TEXT, allowNull: false },
        firstName: text(''),
        lastName: text(''),
        phone: text(''),
        billing: jsonb({}),
        shipping: jsonb({}),
        ordersCount: int(0),
        totalSpent: int(0),
        lastOrderAt: optDate,
        ...timestamps,
      },
      { transaction },
    );
    await index('ShopCustomer', ['siteId', 'email'], true);
    await fk('ShopCustomer', 'siteId', 'Site', 'CASCADE');

    await queryInterface.createTable(
      'ShopOrder',
      {
        id,
        siteId,
        number: { type: DataTypes.INTEGER, allowNull: false },
        status: text('pending'),
        currency: text('EUR'),
        subtotal: int(0),
        discountTotal: int(0),
        shippingTotal: int(0),
        taxTotal: int(0),
        total: int(0),
        refundedTotal: int(0),
        couponCode: optText,
        customerId: optText,
        email: text(''),
        phone: text(''),
        billing: jsonb({}),
        shipping: jsonb({}),
        shipToDifferent: bool(false),
        shippingMethod: { type: DataTypes.JSONB, allowNull: true },
        paymentMethod: text(''),
        paymentStatus: text('unpaid'),
        transactionId: text(''),
        paymentRef: jsonb({}),
        customerNote: text(''),
        accessToken: { type: DataTypes.TEXT, allowNull: false },
        ipAddress: text(''),
        userAgent: text(''),
        cartId: optText,
        placedAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        paidAt: optDate,
        completedAt: optDate,
        ...timestamps,
      },
      { transaction },
    );
    await index('ShopOrder', ['siteId', 'number'], true);
    await index('ShopOrder', ['accessToken'], true);
    await index('ShopOrder', ['siteId', 'status']);
    await index('ShopOrder', ['siteId', 'placedAt']);
    await index('ShopOrder', ['siteId', 'email']);
    await index('ShopOrder', ['customerId']);
    await fk('ShopOrder', 'siteId', 'Site', 'CASCADE');
    await fk('ShopOrder', 'customerId', 'ShopCustomer', 'SET NULL');

    await queryInterface.createTable(
      'ShopOrderItem',
      {
        id,
        siteId,
        orderId: { type: DataTypes.TEXT, allowNull: false },
        productId: optText,
        variantId: optText,
        name: text(''),
        sku: text(''),
        qty: int(1),
        unitPrice: int(0),
        subtotal: int(0),
        total: int(0),
        taxTotal: int(0),
        attributes: jsonb({}),
        imageUrl: text(''),
        virtual: bool(false),
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await index('ShopOrderItem', ['orderId']);
    await index('ShopOrderItem', ['productId']);
    await fk('ShopOrderItem', 'siteId', 'Site', 'CASCADE');
    await fk('ShopOrderItem', 'orderId', 'ShopOrder', 'CASCADE');
    await fk('ShopOrderItem', 'productId', 'ShopProduct', 'SET NULL');
    await fk('ShopOrderItem', 'variantId', 'ShopProductVariant', 'SET NULL');

    await queryInterface.createTable(
      'ShopOrderNote',
      {
        id,
        siteId,
        orderId: { type: DataTypes.TEXT, allowNull: false },
        authorId: optText,
        note: text(''),
        isCustomerNote: bool(false),
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await index('ShopOrderNote', ['orderId']);
    await fk('ShopOrderNote', 'siteId', 'Site', 'CASCADE');
    await fk('ShopOrderNote', 'orderId', 'ShopOrder', 'CASCADE');

    await queryInterface.createTable(
      'ShopCoupon',
      {
        id,
        siteId,
        code: { type: DataTypes.TEXT, allowNull: false },
        type: text('percent'),
        amount: int(0),
        description: text(''),
        minSpend: optInt,
        maxSpend: optInt,
        usageLimit: optInt,
        usageLimitPerEmail: optInt,
        usageCount: int(0),
        expiresAt: optDate,
        productIds: jsonb([]),
        excludeProductIds: jsonb([]),
        categoryIds: jsonb([]),
        freeShipping: bool(false),
        active: bool(true),
        ...timestamps,
      },
      { transaction },
    );
    await index('ShopCoupon', ['siteId', 'code'], true);
    await fk('ShopCoupon', 'siteId', 'Site', 'CASCADE');

    await queryInterface.createTable(
      'ShopPaymentEvent',
      {
        id,
        siteId,
        provider: text(''),
        eventId: { type: DataTypes.TEXT, allowNull: false },
        type: text(''),
        orderId: optText,
        payload: jsonb({}),
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await index('ShopPaymentEvent', ['provider', 'eventId'], true);
    await index('ShopPaymentEvent', ['orderId']);
    await fk('ShopPaymentEvent', 'siteId', 'Site', 'CASCADE');

    // Shop manager role (capabilities are linked by the boot-time seed).
    await queryInterface.sequelize.query(
      `INSERT INTO "Role" ("id", "slug", "name")
       SELECT 'c' || substr(md5(random()::text), 1, 24), 'shop_manager', 'Shop manager'
       WHERE NOT EXISTS (SELECT 1 FROM "Role" WHERE "slug" = 'shop_manager')`,
      { transaction },
    );
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    for (const table of [
      'ShopPaymentEvent',
      'ShopCoupon',
      'ShopOrderNote',
      'ShopOrderItem',
      'ShopOrder',
      'ShopCustomer',
      'ShopCart',
      'ShopProductVariant',
      'ShopProduct',
      'ShopSetting',
    ]) {
      await queryInterface.dropTable(table, { transaction });
    }
  });
}
