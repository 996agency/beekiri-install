import { DataTypes, type QueryInterface } from 'sequelize';

/**
 * Staff shop accounts are tied to the admin user by id (`ShopCustomer.userId`), never by
 * e-mail: an admin can change their own e-mail without proving the mailbox, so matching on
 * it would hand them a shopper's orders and addresses. Existing rows stay unlinked.
 */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.addColumn('ShopCustomer', 'userId', { type: DataTypes.TEXT, allowNull: true }, { transaction });
    await queryInterface.addIndex('ShopCustomer', ['siteId', 'userId'], { name: 'ShopCustomer_siteId_userId_key', unique: true, transaction });
    await queryInterface.addConstraint('ShopCustomer', {
      type: 'foreign key',
      name: 'ShopCustomer_userId_fkey',
      fields: ['userId'],
      references: { table: 'User', field: 'id' },
      onDelete: 'SET NULL',
      onUpdate: 'CASCADE',
      transaction,
    });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.removeColumn('ShopCustomer', 'userId', { transaction });
  });
}
