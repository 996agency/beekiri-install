import { DataTypes, type QueryInterface } from 'sequelize';

/** Values of custom checkout fields (Shop → Settings → Checkout) stored with the order. */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.addColumn(
      'ShopOrder',
      'customFields',
      { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },
      { transaction },
    );
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.removeColumn('ShopOrder', 'customFields', { transaction });
  });
}
