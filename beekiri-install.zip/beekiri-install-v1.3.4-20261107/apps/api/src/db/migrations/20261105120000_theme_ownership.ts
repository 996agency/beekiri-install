import { DataTypes, type QueryInterface } from 'sequelize';

/**
 * Pages and field groups belong to a theme (its client slug, e.g. `beekiri-child`, `be-clinic`).
 * Only the active theme's pages and Backend Fields are shown; switching themes swaps them.
 * Existing rows: pages a theme's content installed belong to that theme, the rest to the
 * Beekiri starter (`beekiri-child`), which is where all earlier layouts were written.
 */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.addColumn('Post', 'theme', { type: DataTypes.TEXT, allowNull: true }, { transaction });
    await queryInterface.addColumn('FieldGroup', 'theme', { type: DataTypes.TEXT, allowNull: true }, { transaction });
    await queryInterface.addIndex('Post', ['siteId', 'type', 'theme'], { name: 'Post_siteId_type_theme_idx', transaction });

    await queryInterface.sequelize.query(
      `UPDATE "Post" p SET theme = tc.key
         FROM "SiteSettings" s, jsonb_each(COALESCE(s.options::jsonb -> 'themeContent', '{}'::jsonb)) tc
        WHERE p."siteId" = s."siteId" AND p.type = 'page' AND p.theme IS NULL
          AND COALESCE(tc.value -> 'pageIds', '[]'::jsonb) ? p.id`,
      { transaction },
    );
    await queryInterface.sequelize.query(`UPDATE "Post" SET theme = 'beekiri-child' WHERE type = 'page' AND theme IS NULL`, { transaction });
    await queryInterface.sequelize.query(`UPDATE "FieldGroup" SET theme = 'beekiri-child' WHERE theme IS NULL`, { transaction });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.removeIndex('Post', 'Post_siteId_type_theme_idx', { transaction });
    await queryInterface.removeColumn('Post', 'theme', { transaction });
    await queryInterface.removeColumn('FieldGroup', 'theme', { transaction });
  });
}
