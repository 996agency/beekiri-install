import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

/**
 * Shopping: shopper accounts (password + verified email on ShopCustomer, sessions and
 * one-time tokens), order fulfilment tracking, and the shipping choice saved on a cart.
 */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.addColumn('ShopCustomer', 'passwordHash', { type: DataTypes.TEXT, allowNull: true }, { transaction });
    await queryInterface.addColumn('ShopCustomer', 'emailVerifiedAt', { type: TIMESTAMP, allowNull: true }, { transaction });
    await queryInterface.addColumn('ShopCustomer', 'lastLoginAt', { type: TIMESTAMP, allowNull: true }, { transaction });
    await queryInterface.addColumn('ShopOrder', 'fulfillment', { type: DataTypes.JSONB, allowNull: false, defaultValue: {} }, { transaction });
    await queryInterface.addColumn('ShopCart', 'meta', { type: DataTypes.JSONB, allowNull: false, defaultValue: {} }, { transaction });

    await queryInterface.createTable(
      'ShopCustomerSession',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        customerId: { type: DataTypes.TEXT, allowNull: false },
        tokenHash: { type: DataTypes.TEXT, allowNull: false },
        expiresAt: { type: TIMESTAMP, allowNull: false },
        lastSeenAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        userAgent: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        ip: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.addIndex('ShopCustomerSession', ['tokenHash'], { name: 'ShopCustomerSession_tokenHash_key', unique: true, transaction });
    await queryInterface.addIndex('ShopCustomerSession', ['customerId'], { name: 'ShopCustomerSession_customerId_idx', transaction });

    await queryInterface.createTable(
      'ShopCustomerToken',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        customerId: { type: DataTypes.TEXT, allowNull: false },
        kind: { type: DataTypes.TEXT, allowNull: false },
        tokenHash: { type: DataTypes.TEXT, allowNull: false },
        expiresAt: { type: TIMESTAMP, allowNull: false },
        usedAt: { type: TIMESTAMP, allowNull: true },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.addIndex('ShopCustomerToken', ['tokenHash'], { name: 'ShopCustomerToken_tokenHash_key', unique: true, transaction });
    await queryInterface.addIndex('ShopCustomerToken', ['customerId'], { name: 'ShopCustomerToken_customerId_idx', transaction });

    for (const table of ['ShopCustomerSession', 'ShopCustomerToken']) {
      await queryInterface.addConstraint(table, {
        type: 'foreign key',
        name: `${table}_siteId_fkey`,
        fields: ['siteId'],
        references: { table: 'Site', field: 'id' },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
        transaction,
      });
      await queryInterface.addConstraint(table, {
        type: 'foreign key',
        name: `${table}_customerId_fkey`,
        fields: ['customerId'],
        references: { table: 'ShopCustomer', field: 'id' },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
        transaction,
      });
    }
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.dropTable('ShopCustomerToken', { transaction });
    await queryInterface.dropTable('ShopCustomerSession', { transaction });
    await queryInterface.removeColumn('ShopCart', 'meta', { transaction });
    await queryInterface.removeColumn('ShopOrder', 'fulfillment', { transaction });
    await queryInterface.removeColumn('ShopCustomer', 'lastLoginAt', { transaction });
    await queryInterface.removeColumn('ShopCustomer', 'emailVerifiedAt', { transaction });
    await queryInterface.removeColumn('ShopCustomer', 'passwordHash', { transaction });
  });
}
