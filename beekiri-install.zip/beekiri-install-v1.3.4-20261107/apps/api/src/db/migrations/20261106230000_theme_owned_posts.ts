import { QueryTypes, type QueryInterface } from 'sequelize';
import { resolveClientThemeSlug } from '../../lib/themes/theme-registry';

/**
 * Blog posts belong to a theme, like pages: Be Clinic's articles don't show on Be Chair.
 * Existing posts: a theme's demo posts (recorded by its content import) belong to that theme;
 * every other post to the theme that is active now, where it was showing until today.
 * Posts of inactive themes are parked as drafts on the next boot (themeSwitchService.reconcile).
 */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.sequelize.query(
      `UPDATE "Post" p SET theme = tc.key
         FROM "SiteSettings" s, jsonb_each(COALESCE(s.options::jsonb -> 'themeContent', '{}'::jsonb)) tc,
              jsonb_each_text(COALESCE(tc.value -> 'posts', '{}'::jsonb)) dp
        WHERE p."siteId" = s."siteId" AND p.type = 'post' AND p.theme IS NULL AND dp.value = p.id`,
      { transaction },
    );
    const sites = await queryInterface.sequelize.query<{ siteId: string; active: string | null }>(
      `SELECT "siteId", options::jsonb ->> 'activeTheme' AS active FROM "SiteSettings"`,
      { type: QueryTypes.SELECT, transaction },
    );
    for (const site of sites) {
      await queryInterface.sequelize.query(
        `UPDATE "Post" SET theme = :theme WHERE "siteId" = :siteId AND type = 'post' AND theme IS NULL`,
        { replacements: { theme: resolveClientThemeSlug(site.active || ''), siteId: site.siteId }, transaction },
      );
    }
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.query(`UPDATE "Post" SET theme = NULL WHERE type = 'post'`);
}
