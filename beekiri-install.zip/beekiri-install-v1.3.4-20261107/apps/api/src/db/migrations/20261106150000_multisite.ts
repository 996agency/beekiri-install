import { DataTypes, type QueryInterface } from 'sequelize';
import { createId } from '../../utils/ids';

/**
 * Multisite: several sites under one install, each on its own sub-domain (or domain).
 *
 * - `Site.slug` is the sub-domain label (`shop` → shop.<network domain>), `Site.domain` an
 *   optional full host of its own; the primary site (`isPrimary`) answers on APP_URL.
 * - Accounts are network-wide; `UserSite` says which sites a person may use, with the role
 *   and the per-user capability grants/denies for that site.
 * - A session belongs to the site it was opened on; `AuthHandoff` holds the one-time tokens
 *   that open a session on another site without signing in again.
 * - `FieldGroup.network` marks a global layout that every site can use; `sourceKey` records
 *   the global layout a site's own copy was customised from.
 *
 * Existing installs: the oldest site becomes the primary site and every user gets access to
 * it with their current role and permissions, so nothing changes until a second site exists.
 */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    const opts = { transaction };
    await queryInterface.addColumn('Site', 'slug', { type: DataTypes.TEXT, allowNull: true }, opts);
    await queryInterface.addColumn('Site', 'domain', { type: DataTypes.TEXT, allowNull: true }, opts);
    await queryInterface.addColumn('Site', 'status', { type: DataTypes.TEXT, allowNull: false, defaultValue: 'active' }, opts);
    await queryInterface.addColumn('Site', 'isPrimary', { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false }, opts);
    await queryInterface.addIndex('Site', ['slug'], { name: 'Site_slug_key', unique: true, transaction });
    await queryInterface.addIndex('Site', ['domain'], { name: 'Site_domain_key', unique: true, transaction });
    await queryInterface.sequelize.query(
      `UPDATE "Site" SET "isPrimary" = true WHERE id = (SELECT id FROM "Site" ORDER BY "createdAt" ASC LIMIT 1)`,
      opts,
    );

    await queryInterface.addColumn(
      'Session',
      'siteId',
      { type: DataTypes.TEXT, allowNull: true, references: { model: 'Site', key: 'id' }, onDelete: 'CASCADE', onUpdate: 'CASCADE' },
      opts,
    );
    await queryInterface.addIndex('Session', ['siteId'], { name: 'Session_siteId_idx', transaction });

    await queryInterface.createTable(
      'UserSite',
      {
        id: { type: DataTypes.TEXT, primaryKey: true, allowNull: false },
        userId: { type: DataTypes.TEXT, allowNull: false, references: { model: 'User', key: 'id' }, onDelete: 'CASCADE', onUpdate: 'CASCADE' },
        siteId: { type: DataTypes.TEXT, allowNull: false, references: { model: 'Site', key: 'id' }, onDelete: 'CASCADE', onUpdate: 'CASCADE' },
        roleId: { type: DataTypes.TEXT, allowNull: false, references: { model: 'Role', key: 'id' }, onDelete: 'RESTRICT', onUpdate: 'CASCADE' },
        profile: { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },
        createdAt: { type: DataTypes.DATE(3), allowNull: false },
        updatedAt: { type: DataTypes.DATE(3), allowNull: false },
      },
      opts,
    );
    await queryInterface.addIndex('UserSite', ['userId', 'siteId'], { name: 'UserSite_userId_siteId_key', unique: true, transaction });
    await queryInterface.addIndex('UserSite', ['siteId'], { name: 'UserSite_siteId_idx', transaction });

    await queryInterface.createTable(
      'AuthHandoff',
      {
        id: { type: DataTypes.TEXT, primaryKey: true, allowNull: false },
        tokenHash: { type: DataTypes.TEXT, allowNull: false, unique: true },
        userId: { type: DataTypes.TEXT, allowNull: false, references: { model: 'User', key: 'id' }, onDelete: 'CASCADE', onUpdate: 'CASCADE' },
        siteId: { type: DataTypes.TEXT, allowNull: false, references: { model: 'Site', key: 'id' }, onDelete: 'CASCADE', onUpdate: 'CASCADE' },
        expiresAt: { type: DataTypes.DATE(3), allowNull: false },
        usedAt: { type: DataTypes.DATE(3), allowNull: true },
        createdAt: { type: DataTypes.DATE(3), allowNull: false },
      },
      opts,
    );

    await queryInterface.addColumn('FieldGroup', 'network', { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false }, opts);
    await queryInterface.addColumn('FieldGroup', 'sourceKey', { type: DataTypes.TEXT, allowNull: true }, opts);
    // A site can hold its own copy of a global layout under the same key.
    await queryInterface.removeIndex('FieldGroup', 'FieldGroup_siteId_key_key', opts);
    await queryInterface.addIndex('FieldGroup', ['siteId', 'key', 'network'], {
      name: 'FieldGroup_siteId_key_network_key',
      unique: true,
      transaction,
    });

    // Every existing user keeps access to their site with their current role and permissions.
    const [users] = (await queryInterface.sequelize.query(
      `SELECT id, "siteId", "roleId", profile FROM "User"`,
      opts,
    )) as [{ id: string; siteId: string; roleId: string; profile: Record<string, unknown> | null }[], unknown];
    const now = new Date();
    if (users.length) {
      await queryInterface.bulkInsert(
        'UserSite',
        users.map((u) => ({
          id: createId(),
          userId: u.id,
          siteId: u.siteId,
          roleId: u.roleId,
          profile: JSON.stringify({
            ...(Array.isArray(u.profile?.capabilityGrants) ? { capabilityGrants: u.profile.capabilityGrants } : {}),
            ...(Array.isArray(u.profile?.capabilityDenies) ? { capabilityDenies: u.profile.capabilityDenies } : {}),
          }),
          createdAt: now,
          updatedAt: now,
        })),
        opts,
      );
    }
    // Open sessions belong to the site their user was on.
    await queryInterface.sequelize.query(
      `UPDATE "Session" s SET "siteId" = u."siteId" FROM "User" u WHERE s."userId" = u.id`,
      opts,
    );
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    const opts = { transaction };
    await queryInterface.removeIndex('FieldGroup', 'FieldGroup_siteId_key_network_key', opts);
    await queryInterface.addIndex('FieldGroup', ['siteId', 'key'], { name: 'FieldGroup_siteId_key_key', unique: true, transaction });
    await queryInterface.removeColumn('FieldGroup', 'sourceKey', opts);
    await queryInterface.removeColumn('FieldGroup', 'network', opts);
    await queryInterface.dropTable('AuthHandoff', opts);
    await queryInterface.dropTable('UserSite', opts);
    await queryInterface.removeIndex('Session', 'Session_siteId_idx', opts);
    await queryInterface.removeColumn('Session', 'siteId', opts);
    await queryInterface.removeIndex('Site', 'Site_domain_key', opts);
    await queryInterface.removeIndex('Site', 'Site_slug_key', opts);
    for (const column of ['isPrimary', 'status', 'domain', 'slug']) await queryInterface.removeColumn('Site', column, opts);
  });
}
