import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

/** Bee Forms: one row per connected CRM account (HubSpot…), credentials encrypted. */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.createTable(
      'BeeFormIntegration',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        provider: { type: DataTypes.TEXT, allowNull: false },
        credentials: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        account: { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },
        status: { type: DataTypes.TEXT, allowNull: false, defaultValue: 'connected' },
        lastError: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        connectedById: { type: DataTypes.TEXT, allowNull: true },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
        updatedAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.addIndex('BeeFormIntegration', ['siteId', 'provider'], {
      name: 'BeeFormIntegration_siteId_provider_key',
      unique: true,
      transaction,
    });
    await queryInterface.addConstraint('BeeFormIntegration', {
      type: 'foreign key',
      name: 'BeeFormIntegration_siteId_fkey',
      fields: ['siteId'],
      references: { table: 'Site', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.dropTable('BeeFormIntegration');
}
