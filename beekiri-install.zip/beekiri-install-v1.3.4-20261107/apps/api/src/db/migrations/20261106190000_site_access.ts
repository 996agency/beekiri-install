import { DataTypes, type QueryInterface } from 'sequelize';

/**
 * Password protection per site (Settings → Sites → Password): `Site.access` holds the
 * password hash, the token of the client link and the secret visitor cookies are signed
 * with. NULL means the site is open to everyone.
 */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.addColumn('Site', 'access', { type: DataTypes.JSONB, allowNull: true });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.removeColumn('Site', 'access');
}
