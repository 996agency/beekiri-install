import type { QueryInterface } from 'sequelize';

/**
 * Page addresses are unique per theme: Be Clinic and Be Chair can both have /about. Only the
 * active theme's pages are public (the others are parked as drafts), so they never clash.
 * Every other content type keeps one address space (its theme is NULL).
 */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.sequelize.query(`DROP INDEX IF EXISTS "Post_siteId_type_slug_key"`, { transaction });
    await queryInterface.sequelize.query(
      `CREATE UNIQUE INDEX "Post_siteId_type_slug_theme_key" ON "Post" ("siteId", type, slug, (COALESCE(theme, '')))`,
      { transaction },
    );
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.sequelize.query(`DROP INDEX IF EXISTS "Post_siteId_type_slug_theme_key"`, { transaction });
    await queryInterface.sequelize.query(
      `CREATE UNIQUE INDEX "Post_siteId_type_slug_key" ON "Post" ("siteId", type, slug)`,
      { transaction },
    );
  });
}
