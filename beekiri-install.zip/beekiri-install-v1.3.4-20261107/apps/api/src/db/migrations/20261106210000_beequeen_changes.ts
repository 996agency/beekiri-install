import { DataTypes, literal, type QueryInterface } from 'sequelize';

const TIMESTAMP = 'TIMESTAMP(3)';
const NOW = literal('CURRENT_TIMESTAMP');

/** Beekiri change history: every theme file, layout, page or taxonomy the agent changed, revertible. */
export async function up(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.sequelize.transaction(async (transaction) => {
    await queryInterface.createTable(
      'BeeQueenChange',
      {
        id: { type: DataTypes.TEXT, allowNull: false, primaryKey: true },
        siteId: { type: DataTypes.TEXT, allowNull: false },
        userId: { type: DataTypes.TEXT, allowNull: false },
        chatId: { type: DataTypes.TEXT, allowNull: true },
        runId: { type: DataTypes.TEXT, allowNull: false },
        kind: { type: DataTypes.TEXT, allowNull: false },
        label: { type: DataTypes.TEXT, allowNull: false, defaultValue: '' },
        target: { type: DataTypes.JSONB, allowNull: false, defaultValue: {} },
        before: { type: DataTypes.JSONB, allowNull: true },
        after: { type: DataTypes.JSONB, allowNull: true },
        revertedAt: { type: TIMESTAMP, allowNull: true },
        revertedById: { type: DataTypes.TEXT, allowNull: true },
        createdAt: { type: TIMESTAMP, allowNull: false, defaultValue: NOW },
      },
      { transaction },
    );
    await queryInterface.addIndex('BeeQueenChange', ['siteId', 'createdAt'], {
      name: 'BeeQueenChange_siteId_createdAt_idx',
      transaction,
    });
    await queryInterface.addConstraint('BeeQueenChange', {
      type: 'foreign key',
      name: 'BeeQueenChange_siteId_fkey',
      fields: ['siteId'],
      references: { table: 'Site', field: 'id' },
      onDelete: 'CASCADE',
      onUpdate: 'CASCADE',
      transaction,
    });
  });
}

export async function down(queryInterface: QueryInterface): Promise<void> {
  await queryInterface.dropTable('BeeQueenChange');
}
