import { existsSync, readdirSync, rmSync } from 'fs';
import { join } from 'path';
import {
  DEFAULT_THEME_SLUG,
  resolveThemeDir,
  resolveThemesRoot,
  sanitizeThemeSlug,
  themeAncestry,
  writableThemeSlug,
} from '../themes/theme-registry';
import { currentSite } from '../site/current-site';

/**
 * Layouts live inside the theme package:
 * apps/web/themes/{theme}/layouts/{slug}/
 *   {slug}.php | {slug}.tsx
 *   styles.scss → styles.css (or styles.min.css)
 *   script.js
 *   {slug}.meta.json
 */
export function resolveLayoutsRoot(themeSlug: string = DEFAULT_THEME_SLUG): string {
  const clean = sanitizeThemeSlug(themeSlug) || DEFAULT_THEME_SLUG;
  const themeDir = resolveThemeDir(clean) ?? join(resolveThemesRoot(), clean);
  return join(themeDir, 'layouts');
}

/**
 * Multisite: layouts generated for a site other than the primary one live next to the theme's
 * own, under apps/web/themes/{theme}/sites/{siteId}/layouts/{slug}/, so two sites on the same
 * theme never overwrite each other's files.
 */
export function resolveSiteLayoutsRoot(themeSlug: string, siteId: string): string {
  // A store theme's site layouts live in its child, like its own layouts.
  const clean = writableThemeSlug(sanitizeThemeSlug(themeSlug) || DEFAULT_THEME_SLUG);
  const themeDir = resolveThemeDir(clean) ?? join(resolveThemesRoot(), clean);
  return join(themeDir, 'sites', siteId.replace(/[^a-zA-Z0-9_-]/g, ''), 'layouts');
}

/** Global (network) layouts: offered to every site whatever its theme. */
export function resolveNetworkLayoutsRoot(): string {
  return join(resolveThemesRoot(), '_network', 'layouts');
}

/**
 * Where the request's site keeps its own layouts for `themeSlug`: the theme folder for the
 * primary site (as before multisite), its own sites/{id} folder for any other site. A store
 * theme's are in its child folder, so a theme update never removes them.
 */
export function resolveOwnLayoutsRoot(themeSlug: string = DEFAULT_THEME_SLUG): string {
  const site = currentSite();
  if (site && !site.isPrimary) return resolveSiteLayoutsRoot(themeSlug, site.id);
  return resolveLayoutsRoot(writableThemeSlug(themeSlug));
}

/** Removes a deleted site's generated layout files from every theme. */
export function removeSiteLayoutFiles(siteId: string): void {
  const id = siteId.replace(/[^a-zA-Z0-9_-]/g, '');
  if (!id) return;
  const root = resolveThemesRoot();
  let themes: string[] = [];
  try {
    themes = readdirSync(root);
  } catch {
    return;
  }
  for (const theme of themes) {
    rmSync(join(root, theme, 'sites', id), { recursive: true, force: true });
  }
}

/** `group_hero` → `hero`, `M7-Text-And-Media-Cards` key → slug. */
export function layoutSlugFromGroupKey(key: string): string {
  const raw = key
    .trim()
    .toLowerCase()
    .replace(/^group_/, '')
    .replace(/[^a-z0-9_]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .replace(/_{2,}/g, '_')
    .slice(0, 48);
  return raw || `layout_${Math.random().toString(36).slice(2, 8)}`;
}

/** Title → folder slug (m7-text-and-media-cards). */
export function layoutSlugFromTitle(title: string): string {
  const raw = title
    .trim()
    .toLowerCase()
    .replace(/^layout\s*:?\s*/i, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .replace(/-{2,}/g, '-')
    .slice(0, 64);
  return raw || layoutSlugFromGroupKey(title);
}

export function sanitizeLayoutSlug(raw: string): string | null {
  const slug = raw
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
  return slug || null;
}

function pathsAt(root: string, slug: string, themeSlug: string) {
  const dir = join(root, slug);
  return {
    root,
    dir,
    themeSlug: sanitizeThemeSlug(themeSlug) || DEFAULT_THEME_SLUG,
    tsx: join(dir, `${slug}.tsx`),
    php: join(dir, `${slug}.php`),
    scss: join(dir, 'styles.scss'),
    css: join(dir, 'styles.css'),
    cssMin: join(dir, 'styles.min.css'),
    js: join(dir, 'script.js'),
    meta: join(dir, `${slug}.meta.json`),
  };
}

/**
 * Where a layout's files are written: the request's site's own folder for the theme, or the
 * global folder for a network layout.
 */
export function layoutPaths(slug: string, themeSlug: string = DEFAULT_THEME_SLUG, opts: { network?: boolean } = {}) {
  if (opts.network) return pathsAt(resolveNetworkLayoutsRoot(), slug, themeSlug);
  return pathsAt(resolveOwnLayoutsRoot(themeSlug), slug, writableThemeSlug(themeSlug));
}

/**
 * Where a layout's files are read from: the site's own copy (multisite), then the theme and
 * its parents, then the global layouts.
 */
export function resolveLayoutPaths(slug: string, themeSlug: string = DEFAULT_THEME_SLUG) {
  const site = currentSite();
  if (site && !site.isPrimary) {
    const own = pathsAt(resolveSiteLayoutsRoot(themeSlug, site.id), slug, themeSlug);
    if (existsSync(own.dir)) return own;
  }
  for (const theme of themeAncestry(themeSlug)) {
    const paths = pathsAt(resolveLayoutsRoot(theme), slug, theme);
    if (existsSync(paths.dir)) return paths;
  }
  const network = pathsAt(resolveNetworkLayoutsRoot(), slug, themeSlug);
  if (existsSync(network.dir)) return network;
  return layoutPaths(slug, themeSlug);
}
