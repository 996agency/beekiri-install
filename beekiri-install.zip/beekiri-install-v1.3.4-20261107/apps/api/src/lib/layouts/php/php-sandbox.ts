/**
 * Every PHP process Beekiri starts (layouts, header/footer, blog, storefront, the template
 * checker) runs with these limits — defence in depth behind the template checker:
 *
 * - A minimal environment: PATH to find `php`, plus PHP's own ini locations so the same
 *   php.ini is used. Never the server's secrets (database password, Stripe/Hub keys…). The
 *   runner script reads no environment variables at all.
 * - `disable_functions` for everything that starts processes, changes the environment, opens
 *   network connections, sends mail or reads/writes files by name. Templates only print data.
 * - FFI and remote includes switched off.
 */

/** PHP ini locations (Herd keeps one per version, e.g. HERD_PHP_84_INI_SCAN_DIR). */
const PHP_CONFIG_ENV = /^(PHPRC|PHP_INI_SCAN_DIR|HERD_PHP_\d+_INI_SCAN_DIR)$/;

export const PHP_DISABLED_FUNCTIONS = [
  // Processes
  'exec', 'shell_exec', 'system', 'passthru', 'proc_open', 'popen', 'proc_close', 'proc_get_status',
  'proc_nice', 'proc_terminate', 'pcntl_exec', 'pcntl_fork', 'pcntl_rfork', 'pcntl_signal',
  'pcntl_signal_dispatch', 'pcntl_alarm', 'pcntl_waitpid', 'pcntl_wait', 'pcntl_async_signals',
  'pcntl_setpriority', 'pcntl_unshare', 'posix_kill', 'posix_mkfifo', 'posix_setsid', 'posix_setuid',
  'posix_setgid', 'posix_seteuid', 'posix_setegid', 'posix_setpgid',
  // Environment, extensions, runtime settings
  'putenv', 'getenv', 'dl', 'ini_set', 'ini_alter', 'ini_restore', 'set_include_path', 'phpinfo',
  'apache_setenv',
  // Mail and network
  'mail', 'mb_send_mail', 'error_log', 'fsockopen', 'pfsockopen', 'stream_socket_client',
  'stream_socket_server', 'socket_create', 'socket_connect', 'curl_init', 'curl_exec', 'curl_multi_exec',
  'ftp_connect', 'ftp_ssl_connect', 'imap_open', 'imap_mail',
  // Files by name (templates get their data on stdin / argv; includes stay possible for the runner)
  'file_get_contents', 'file_put_contents', 'fopen', 'file', 'readfile', 'fpassthru', 'unlink', 'rename',
  'copy', 'mkdir', 'rmdir', 'symlink', 'link', 'chmod', 'chown', 'chgrp', 'lchown', 'lchgrp', 'touch',
  'tempnam', 'tmpfile', 'move_uploaded_file', 'parse_ini_file', 'highlight_file', 'show_source',
  'scandir', 'opendir', 'glob',
];

/** `-d` flags that go before the script on every PHP command line. */
export function phpSandboxArgs(): string[] {
  return [
    '-d', `disable_functions=${PHP_DISABLED_FUNCTIONS.join(',')}`,
    '-d', 'ffi.enable=0',
    '-d', 'allow_url_fopen=0',
    '-d', 'allow_url_include=0',
  ];
}

/** `php` arguments: the sandbox flags, then the script and its own arguments. */
export function phpArgs(args: string[]): string[] {
  return [...phpSandboxArgs(), ...args];
}

/** The only environment a PHP process gets. */
export function phpEnv(source: NodeJS.ProcessEnv = process.env): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = { PATH: source.PATH ?? '/usr/local/bin:/usr/bin:/bin' };
  for (const [name, value] of Object.entries(source)) {
    if (PHP_CONFIG_ENV.test(name) && typeof value === 'string') env[name] = value;
  }
  return env;
}
