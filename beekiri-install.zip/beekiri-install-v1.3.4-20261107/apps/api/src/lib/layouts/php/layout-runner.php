<?php
/**
 * Beekiri layout runner — executes themes/.../layouts/{slug}/{slug}.php
 * with the Beekiri field API. Values arrive already formatted (field formatters),
 * so get_bee_field() returns the shapes layouts expect.
 *
 * Field API:
 *   get_bee_field() / the_bee_field() / get_bee_fields()
 *   have_bee_rows() / the_bee_row() / get_bee_row() / get_bee_row_index()
 *   get_bee_row_layout() / reset_bee_rows()
 *
 * Usage: php layout-runner.php <layout.php> <fields.json> <slug>
 *        php layout-runner.php <template.php> --stdin <slug> [prelude.php]   (JSON on stdin; the
 *        Shopping storefront uses this because its data outgrows a command-line argument)
 */
declare(strict_types=1);

$layoutPath = $argv[1] ?? '';
$fieldsJson = $argv[2] ?? '{}';
$slug = $argv[3] ?? 'layout';
$preludePath = $argv[4] ?? '';
if ($fieldsJson === '--stdin') {
  $fieldsJson = stream_get_contents(STDIN) ?: '{}';
}

if ($layoutPath === '' || !is_file($layoutPath)) {
  fwrite(STDERR, "Layout file not found.\n");
  exit(1);
}

$fields = json_decode($fieldsJson, true);
if (!is_array($fields)) {
  $fields = [];
}

/** @var array<int, array{name:string, rows:array, i:int}> */
$GLOBALS['__bk_loops'] = [];
$GLOBALS['__bk_fields'] = $fields;
$GLOBALS['__bk_slug'] = $slug;
$GLOBALS['__bk_media'] = [];

function __bk_is_list($v): bool {
  if (!is_array($v)) return false;
  if ($v === []) return true;
  return array_keys($v) === range(0, count($v) - 1);
}

/** Index every formatted image/file array so wp_get_attachment_*() can find it by ID. */
function __bk_index_media($v): void {
  if (!is_array($v)) return;
  if (isset($v['ID'], $v['url'], $v['mime_type']) && $v['ID'] !== '') {
    $GLOBALS['__bk_media'][(string) $v['ID']] = $v;
  }
  foreach ($v as $child) {
    if (is_array($child)) __bk_index_media($child);
  }
}
__bk_index_media($fields);

/** Values for the row currently being looped (or the layout's own fields). */
function __bk_ctx(): array {
  $loops = $GLOBALS['__bk_loops'];
  for ($k = count($loops) - 1; $k >= 0; $k--) {
    $l = $loops[$k];
    if ($l['i'] >= 0 && isset($l['rows'][$l['i']]) && is_array($l['rows'][$l['i']])) {
      return $l['rows'][$l['i']];
    }
  }
  return $GLOBALS['__bk_fields'];
}

/** Repeater / flexible → list of rows; group → single row. */
function __bk_rows($value): array {
  if (!is_array($value) || $value === []) return [];
  if (__bk_is_list($value)) {
    return array_values(array_filter($value, 'is_array'));
  }
  return [$value];
}

function __bk_to_string($v): string {
  if ($v === null || $v === false) return '';
  if ($v === true) return '1';
  if (is_array($v)) {
    if (isset($v['url']) && is_string($v['url'])) return $v['url'];
    if (isset($v['label']) && is_string($v['label'])) return $v['label'];
    return implode(', ', array_map('__bk_to_string', $v));
  }
  return (string) $v;
}

/* —— Beekiri field API (canonical) —— */

if (!function_exists('get_bee_field')) {
  /**
   * Layout / loop field value (root of the layout, or current bee_row).
   */
  function get_bee_field($selector = '', $format_value = true) {
    $ctx = __bk_ctx();
    return array_key_exists($selector, $ctx) ? $ctx[$selector] : null;
  }
}
if (!function_exists('the_bee_field')) {
  function the_bee_field($selector = '', $format_value = true) {
    echo __bk_to_string(get_bee_field($selector));
  }
}
if (!function_exists('get_bee_fields')) {
  function get_bee_fields($format_value = true) {
    return $GLOBALS['__bk_fields'];
  }
}

if (!function_exists('have_bee_rows')) {
  function have_bee_rows($selector, $post_id = false): bool {
    $loops = &$GLOBALS['__bk_loops'];

    // Continuing a loop already on the stack (drop any inner loop left open by `break`).
    for ($k = count($loops) - 1; $k >= 0; $k--) {
      if ($loops[$k]['name'] !== $selector) continue;
      if ($loops[$k]['i'] < 0 && $k !== count($loops) - 1) break;
      array_splice($loops, $k + 1);
      if ($loops[$k]['i'] + 1 < count($loops[$k]['rows'])) return true;
      array_pop($loops);
      return false;
    }

    $ctx = __bk_ctx();
    $rows = __bk_rows($ctx[$selector] ?? null);
    if (!$rows) return false;
    $loops[] = ['name' => (string) $selector, 'rows' => $rows, 'i' => -1];
    return true;
  }
}
if (!function_exists('the_bee_row')) {
  function the_bee_row($format = false) {
    $loops = &$GLOBALS['__bk_loops'];
    $n = count($loops);
    if (!$n) return false;
    $loops[$n - 1]['i']++;
    return $loops[$n - 1]['rows'][$loops[$n - 1]['i']] ?? false;
  }
}
if (!function_exists('get_bee_row')) {
  function get_bee_row($format = false) {
    $loops = $GLOBALS['__bk_loops'];
    $n = count($loops);
    if (!$n) return false;
    return $loops[$n - 1]['rows'][$loops[$n - 1]['i']] ?? false;
  }
}
if (!function_exists('get_bee_row_index')) {
  function get_bee_row_index(): int {
    $loops = $GLOBALS['__bk_loops'];
    $n = count($loops);
    return $n ? $loops[$n - 1]['i'] + 1 : 0;
  }
}
if (!function_exists('get_bee_row_layout')) {
  function get_bee_row_layout() {
    $row = get_bee_row();
    if (is_array($row)) {
      if (isset($row['bee_layout'])) return $row['bee_layout'];
      // Legacy flexible-row key from older imports.
      if (isset($row['acf_fc_layout'])) return $row['acf_fc_layout'];
    }
    // The layout file itself is a flexible row of the page.
    return $GLOBALS['__bk_slug'];
  }
}
if (!function_exists('reset_bee_rows')) {
  function reset_bee_rows(): bool {
    array_pop($GLOBALS['__bk_loops']);
    return true;
  }
}
if (!function_exists('bee_esc_html')) {
  function bee_esc_html($s) {
    return wp_kses_post($s);
  }
}

/* —— Legacy aliases → Bee API (existing templates keep working) —— */

if (!function_exists('get_field')) {
  function get_field($selector, $post_id = false, $format_value = true) {
    $f = $GLOBALS['__bk_fields'];
    return array_key_exists($selector, $f) ? $f[$selector] : null;
  }
}
if (!function_exists('the_field')) {
  function the_field($selector, $post_id = false, $format_value = true) {
    echo __bk_to_string(get_field($selector));
  }
}
if (!function_exists('get_fields')) {
  function get_fields($post_id = false, $format_value = true) {
    return get_bee_fields($format_value);
  }
}
if (!function_exists('get_sub_field')) {
  function get_sub_field($selector = '', $format_value = true) {
    return get_bee_field($selector, $format_value);
  }
}
if (!function_exists('the_sub_field')) {
  function the_sub_field($selector, $format_value = true) {
    the_bee_field($selector, $format_value);
  }
}
if (!function_exists('have_rows')) {
  function have_rows($selector, $post_id = false): bool {
    return have_bee_rows($selector, $post_id);
  }
}
if (!function_exists('the_row')) {
  function the_row($format = false) {
    return the_bee_row($format);
  }
}
if (!function_exists('get_row')) {
  function get_row($format = false) {
    return get_bee_row($format);
  }
}
if (!function_exists('get_row_index')) {
  function get_row_index(): int {
    return get_bee_row_index();
  }
}
if (!function_exists('get_row_layout')) {
  function get_row_layout() {
    return get_bee_row_layout();
  }
}
if (!function_exists('reset_rows')) {
  function reset_rows(): bool {
    return reset_bee_rows();
  }
}
if (!function_exists('acf_esc_html')) {
  function acf_esc_html($s) {
    return bee_esc_html($s);
  }
}

/* —— Common HTML helpers used in layout templates —— */

if (!function_exists('esc_html')) {
  function esc_html($s) {
    return htmlspecialchars(__bk_to_string($s), ENT_QUOTES, 'UTF-8');
  }
}
if (!function_exists('esc_attr')) {
  function esc_attr($s) {
    return htmlspecialchars(__bk_to_string($s), ENT_QUOTES, 'UTF-8');
  }
}
if (!function_exists('esc_textarea')) {
  function esc_textarea($s) {
    return htmlspecialchars(__bk_to_string($s), ENT_QUOTES, 'UTF-8');
  }
}
if (!function_exists('__bk_safe_url')) {
  /**
   * A URL a page may link to or load: http(s), mailto, tel, or relative. Browsers ignore
   * tabs, newlines and control characters inside a scheme ("java\tscript:"), so those
   * are removed before the scheme is checked. Returns null for anything else.
   */
  function __bk_safe_url(string $url): ?string {
    $url = trim($url);
    $probe = preg_replace('/[\x00-\x20\x7f]+/', '', $url) ?? '';
    if ($probe === '') return '';
    if (preg_match('/^([a-z][a-z0-9+.\-]*):/i', $probe, $m)) {
      return in_array(strtolower($m[1]), ['http', 'https', 'mailto', 'tel'], true) ? $url : null;
    }
    return $url;
  }
}
if (!function_exists('esc_url')) {
  function esc_url($s) {
    $u = __bk_safe_url(__bk_to_string($s));
    return $u === null ? '' : htmlspecialchars($u, ENT_QUOTES, 'UTF-8');
  }
}
if (!function_exists('esc_html__')) {
  function esc_html__($s, $domain = 'default') {
    return esc_html($s);
  }
}
if (!function_exists('esc_html_e')) {
  function esc_html_e($s, $domain = 'default') {
    echo esc_html($s);
  }
}
if (!function_exists('esc_attr_e')) {
  function esc_attr_e($s, $domain = 'default') {
    echo esc_attr($s);
  }
}
if (!function_exists('__')) {
  function __($s, $domain = 'default') {
    return $s;
  }
}
if (!function_exists('_e')) {
  function _e($s, $domain = 'default') {
    echo $s;
  }
}
if (!function_exists('__bk_kses')) {
  /**
   * Rich text that is safe to print: an allow-list of formatting tags and attributes,
   * parsed with the DOM (not regular expressions), so tricks like `<img/onerror=…>`,
   * unclosed `<script>` or "java&#x73;cript:" links cannot slip through. Unknown tags
   * keep their text; dangerous containers are dropped with their contents.
   */
  function __bk_kses(string $html): string {
    if ($html === '' || strpbrk($html, '<&') === false) return $html;
    if (!class_exists('DOMDocument')) {
      // No DOM extension: keep only plain formatting, with every attribute removed.
      $text = strip_tags($html, '<p><br><strong><b><em><i><u><s><ul><ol><li><h2><h3><h4><blockquote><code><pre>');
      return preg_replace('/<([a-z0-9]+)\b[^>]*>/i', '<$1>', $text) ?? '';
    }

    static $tags = [
      'a' => ['href', 'title', 'target', 'rel'], 'abbr' => ['title'], 'b' => [], 'blockquote' => ['cite'],
      'br' => [], 'caption' => [], 'cite' => [], 'code' => [], 'dd' => [], 'del' => [], 'div' => [],
      'dl' => [], 'dt' => [], 'em' => [], 'figcaption' => [], 'figure' => [], 'h1' => [], 'h2' => [],
      'h3' => [], 'h4' => [], 'h5' => [], 'h6' => [], 'hr' => [], 'i' => [],
      'img' => ['src', 'alt', 'width', 'height', 'loading', 'decoding'], 'ins' => [], 'kbd' => [],
      'li' => [], 'mark' => [], 'ol' => ['start', 'reversed', 'type'], 'p' => [], 'pre' => [], 'q' => ['cite'],
      's' => [], 'small' => [], 'span' => [], 'strong' => [], 'sub' => [], 'sup' => [], 'table' => [],
      'tbody' => [], 'td' => ['colspan', 'rowspan'], 'tfoot' => [], 'th' => ['colspan', 'rowspan', 'scope'],
      'thead' => [], 'time' => ['datetime'], 'tr' => [], 'u' => [], 'ul' => [],
    ];
    static $global = ['class', 'id', 'title', 'lang', 'dir', 'role', 'style'];
    static $drop = [
      'script', 'style', 'iframe', 'frame', 'frameset', 'object', 'embed', 'applet', 'noscript',
      'noembed', 'noframes', 'template', 'xmp', 'plaintext', 'textarea', 'title', 'select', 'option',
      'svg', 'math', 'base', 'link', 'meta', 'form', 'input', 'button', 'head',
    ];

    $doc = new DOMDocument();
    $previous = libxml_use_internal_errors(true);
    $doc->loadHTML(
      '<?xml encoding="utf-8" ?><html><body><div id="__bk_kses_root">' . $html . '</div></body></html>',
      LIBXML_NONET | LIBXML_COMPACT,
    );
    libxml_clear_errors();
    libxml_use_internal_errors($previous);
    $root = $doc->getElementById('__bk_kses_root');
    if (!$root) return '';

    $clean = function (DOMNode $parent) use (&$clean, $tags, $global, $drop): void {
      foreach (iterator_to_array($parent->childNodes) as $node) {
        if ($node instanceof DOMText) continue;
        if (!$node instanceof DOMElement) {
          $parent->removeChild($node); // comments, processing instructions, CDATA
          continue;
        }
        $name = strtolower($node->nodeName);
        if (in_array($name, $drop, true)) {
          $parent->removeChild($node);
          continue;
        }
        $clean($node);
        if (!isset($tags[$name])) {
          while ($node->firstChild) $parent->insertBefore($node->firstChild, $node);
          $parent->removeChild($node);
          continue;
        }
        foreach (iterator_to_array($node->attributes) as $attr) {
          $attrName = strtolower($attr->nodeName);
          $value = $attr->nodeValue ?? '';
          $keep = in_array($attrName, $tags[$name], true) || in_array($attrName, $global, true)
            || str_starts_with($attrName, 'aria-');
          if ($keep && ($attrName === 'href' || $attrName === 'src' || $attrName === 'cite')) {
            $safe = __bk_safe_url($value);
            $keep = $safe !== null;
            if ($keep) $value = $safe;
          }
          if ($keep && $attrName === 'style') {
            $keep = !preg_match('/expression|javascript|vbscript|behavior|binding|@import|url\s*\(/i', $value);
          }
          if ($keep && $attrName === 'target') {
            $keep = in_array($value, ['_blank', '_self'], true);
          }
          $node->removeAttribute($attr->nodeName);
          if ($keep) $node->setAttribute($attrName, $value);
        }
        if ($name === 'a' && $node->getAttribute('target') === '_blank') {
          $node->setAttribute('rel', 'noopener noreferrer');
        }
      }
    };
    $clean($root);

    $out = '';
    foreach ($root->childNodes as $child) $out .= $doc->saveHTML($child);
    return $out;
  }
}
if (!function_exists('wp_kses_post')) {
  function wp_kses_post($s) {
    return __bk_kses(__bk_to_string($s));
  }
}
if (!function_exists('wpautop')) {
  function wpautop($text) {
    $t = trim(str_replace(["\r\n", "\r"], "\n", (string) $text));
    if ($t === '') return '';
    if (preg_match('/^\s*<(p|div|h[1-6]|ul|ol|table|blockquote|figure|section|pre)[\s>]/i', $t)) return $t;
    $out = [];
    foreach (preg_split('/\n{2,}/', $t) as $block) {
      $out[] = '<p>' . str_replace("\n", "<br />\n", $block) . '</p>';
    }
    return implode("\n", $out);
  }
}
if (!function_exists('sanitize_title')) {
  function sanitize_title($s) {
    $s = strtolower(trim((string) $s));
    $s = preg_replace('/[^a-z0-9]+/', '-', $s) ?? '';
    return trim($s, '-');
  }
}
if (!function_exists('wp_trim_words')) {
  function wp_trim_words($text, $num_words = 55, $more = '&hellip;') {
    $words = preg_split('/\s+/', trim(strip_tags((string) $text))) ?: [];
    if (count($words) <= $num_words) return implode(' ', $words);
    return implode(' ', array_slice($words, 0, $num_words)) . $more;
  }
}
if (!function_exists('get_permalink')) {
  function get_permalink($post = 0) {
    if (is_array($post)) return $post['permalink'] ?? ($post['url'] ?? '');
    return '';
  }
}
if (!function_exists('get_the_title')) {
  function get_the_title($post = 0) {
    if (is_array($post)) return $post['post_title'] ?? '';
    return '';
  }
}
if (!function_exists('wp_get_attachment_url')) {
  function wp_get_attachment_url($id) {
    $m = $GLOBALS['__bk_media'][(string) $id] ?? null;
    return $m ? $m['url'] : false;
  }
}
if (!function_exists('wp_get_attachment_image_url')) {
  function wp_get_attachment_image_url($id, $size = 'thumbnail', $icon = false) {
    return wp_get_attachment_url($id);
  }
}
if (!function_exists('wp_get_attachment_image_src')) {
  function wp_get_attachment_image_src($id, $size = 'thumbnail', $icon = false) {
    $m = $GLOBALS['__bk_media'][(string) $id] ?? null;
    return $m ? [$m['url'], $m['width'] ?? 0, $m['height'] ?? 0, false] : false;
  }
}
if (!function_exists('wp_get_attachment_image')) {
  function wp_get_attachment_image($id, $size = 'thumbnail', $icon = false, $attr = '') {
    if (is_array($id)) $id = $id['ID'] ?? '';
    $m = $GLOBALS['__bk_media'][(string) $id] ?? null;
    if (!$m) return '';
    $a = is_array($attr) ? $attr : [];
    $a += [
      'src' => $m['url'],
      'alt' => $m['alt'] ?? '',
      'loading' => 'lazy',
      'decoding' => 'async',
    ];
    if (!empty($m['width'])) $a += ['width' => $m['width'], 'height' => $m['height']];
    $html = '<img';
    foreach ($a as $k => $v) {
      $html .= ' ' . esc_attr($k) . '="' . ($k === 'src' ? esc_url($v) : esc_attr($v)) . '"';
    }
    return $html . ' />';
  }
}
if (!function_exists('bee_language_switcher')) {
  /**
   * Language switcher for theme headers: a button with the current language and a menu of
   * the site's languages (Settings → Translation; shown even when there is only one).
   * The website points each `#bk-lang=xx` link at the current page in that language and
   * fills in {current_code}; opening and closing comes from the site runtime (site-nav.js).
   * $opts: 'id' (menu id, unique on the page), 'class' (extra classes on the wrapper).
   */
  function bee_language_switcher(array $opts = []): string {
    $langs = get_bee_field('languages');
    if (!is_array($langs) || !$langs) $langs = [['code' => 'en', 'label' => 'English']];
    $id = preg_replace('/[^a-z0-9_-]/i', '', (string) ($opts['id'] ?? 'bk-langsw-menu')) ?: 'bk-langsw-menu';
    $class = trim('bk-langsw ' . preg_replace('/[^a-z0-9_ -]/i', '', (string) ($opts['class'] ?? '')));
    $items = '';
    foreach ($langs as $l) {
      $code = strtolower(preg_replace('/[^a-z-]/i', '', (string) ($l['code'] ?? '')));
      if ($code === '') continue;
      $items .= '<li><a class="bk-langsw__item" href="#bk-lang=' . esc_attr($code) . '">'
        . '<span>' . esc_html($l['label'] ?? strtoupper($code)) . '</span>'
        . '<span class="bk-langsw__code">' . esc_html(strtoupper($code)) . '</span></a></li>';
    }
    $globe = '<svg class="bk-langsw__icon" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>';
    return '<div class="' . esc_attr($class) . '" data-bk-langsw>'
      . '<a class="bk-langsw__btn" href="#bk-lang" role="button" aria-haspopup="true" aria-expanded="false" aria-controls="' . $id . '" aria-label="{current_code}, choose language">'
      . $globe . '<span class="bk-langsw__current">{current_code}</span></a>'
      . '<ul class="bk-langsw__menu" id="' . $id . '" hidden>' . $items . '</ul></div>';
  }
}
if (!function_exists('bee_search_modal')) {
  /**
   * The site's search dialog: pages (from the menu) and, while the Shopping extension is on,
   * products as you type. Print it once in a header and open it from any element that carries
   * `data-bk-search-open` (runtime/site-nav.js does the rest, incl. ⌘K / Ctrl+K and Escape).
   * $opts: placeholder.
   */
  function bee_search_modal(array $opts = []): string {
    $placeholder = (string) ($opts['placeholder'] ?? 'Search…');
    $pages = [];
    $seen = [];
    $push = function ($label, $url) use (&$pages, &$seen) {
      $label = is_string($label) ? trim($label) : '';
      $url = is_string($url) ? trim($url) : '';
      if ($label === '' || $url === '' || isset($seen[$url]) || $url[0] === '#') return;
      $seen[$url] = true;
      $pages[] = ['label' => $label, 'url' => $url];
    };
    $rows = get_bee_field('search_pages');
    if (is_array($rows)) {
      foreach ($rows as $r) if (is_array($r)) $push($r['label'] ?? '', $r['url'] ?? '');
    }
    if (!$pages) {
      $flat = function ($items) use (&$flat, $push) {
        foreach ((array) $items as $i) {
          if (!is_array($i)) continue;
          $push($i['label'] ?? '', $i['url'] ?? '/');
          if (!empty($i['children'])) $flat($i['children']);
        }
      };
      $flat(get_bee_field('menu'));
    }
    $shop = get_bee_field('shop');
    $shopPath = is_array($shop) && !empty($shop['active']) ? (string) ($shop['shop_path'] ?? '/shop') : '';
    // Products come live (with photo and price) while the shop is on — not again as plain pages.
    if ($shopPath !== '') $pages = array_values(array_filter($pages, fn($p) => strpos($p['url'], '/product/') !== 0));
    $icon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>';
    // Grouped and sorted: Pages, then the shop (shop, categories, cart, checkout, account), then the journal.
    $shopBase = $shopPath !== '' ? rtrim($shopPath, '/') : '/shop';
    $groups = ['pages' => ['Pages', []], 'shop' => ['Shop', []], 'journal' => ['Journal', []]];
    foreach ($pages as $p) {
      $u = $p['url'];
      $key = 'pages';
      if ($u === '/blog' || strpos($u, '/blog/') === 0) $key = 'journal';
      elseif ($u === $shopBase || strpos($u, $shopBase . '/') === 0 || strpos($u, '/product/') === 0 || in_array($u, ['/cart', '/checkout', '/account'], true)) $key = 'shop';
      $groups[$key][1][] = $p;
    }
    $lists = '';
    foreach ($groups as $key => [$title, $rows]) {
      if (!$rows) continue;
      usort($rows, fn($a, $b) => strcasecmp($a['label'], $b['label']));
      $items = '';
      foreach ($rows as $p) {
        $items .= '<li data-bk-search-item data-q="' . esc_attr(strtolower($p['label'] . ' ' . $p['url'])) . '"><a href="' . esc_url($p['url']) . '">'
          . '<span>' . esc_html($p['label']) . '</span><code>' . esc_html($p['url']) . '</code></a></li>';
      }
      $lists .= '<p class="bk-search__group" data-bk-search-group="' . $key . '">' . esc_html($title) . '</p>'
        . '<ul class="bk-search__results" data-bk-search-pages="' . $key . '">' . $items . '</ul>';
    }
    return '<div class="bk-search" role="dialog" aria-modal="true" aria-labelledby="bk-search-input" data-bk-search hidden>'
      . '<form class="bk-search__panel" role="search" data-bk-search-form>'
      . '<div class="bk-search__head">' . $icon
      . '<input id="bk-search-input" type="search" placeholder="' . esc_attr($placeholder) . '" autocomplete="off" data-bk-search-input />'
      . '<kbd>esc</kbd></div>'
      . '<div class="bk-search__body">'
      . ($shopPath !== ''
        ? '<p class="bk-search__group" data-bk-search-group="products" hidden>Products</p>'
          . '<ul class="bk-search__results" data-bk-search-products data-shop="' . esc_attr($shopPath) . '" hidden></ul>'
        : '')
      . $lists
      . '<p class="bk-search__empty" data-bk-search-empty hidden>No matches</p>'
      . '</div></form></div>';
  }
}
if (!function_exists('bee_form')) {
  /**
   * HTML of a Bee Forms form. Pass the value of a Form field (array with 'html'), or nothing to
   * use the layout's first Form field. Returns '' when the form is missing or inactive.
   */
  function bee_form($form = null): string {
    if ($form === null) {
      foreach ((array) ($GLOBALS['__bk_fields'] ?? []) as $v) {
        if (is_array($v) && isset($v['html'], $v['ID'])) { $form = $v; break; }
      }
    }
    if (is_array($form) && isset($form['html'])) return (string) $form['html'];
    return '';
  }
  function the_bee_form($form = null): void { echo bee_form($form); }
}
if (!function_exists('get_Section_Override')) {
  function get_Section_Override() {}
}

$args = $fields;
// One clean section class stack: {slug} section (field nodes use bk-{name}).
$classes = [$slug, 'section'];

// Optional shared helpers (e.g. themes/beekiri/shop/_helpers.php) loaded before the template.
if ($preludePath !== '' && is_file($preludePath)) {
  require_once $preludePath;
}

ob_start();
include $layoutPath;
echo ob_get_clean();
