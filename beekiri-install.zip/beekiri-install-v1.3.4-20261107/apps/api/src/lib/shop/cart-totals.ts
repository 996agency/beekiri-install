import { percentOf } from './money';
import type { ShippingMethod, ShopSettings, TaxRate } from './settings';

/**
 * Pure pricing engine: given resolved cart lines (prices already looked up from the
 * database), a coupon, a shipping choice and the shop settings, work out every total.
 * No I/O here, so it is easy to test and impossible for a client to influence.
 */

export type CartLine = {
  key: string;
  /** Public product id (the Post id, as used in URLs and the admin). */
  productId: string;
  /** Internal ShopProduct id (stock rows, order items). */
  commerceId: string;
  variantId: string | null;
  name: string;
  sku: string;
  qty: number;
  /** current unit price (minor units) */
  unitPrice: number;
  regularPrice: number | null;
  taxable: boolean;
  virtual: boolean;
  weight: number | null;
  imageUrl: string;
  attributes: Record<string, string>;
  categoryIds: string[];
  path: string;
};

export type CouponRule = {
  code: string;
  type: 'percent' | 'fixed_cart' | 'fixed_product';
  amount: number;
  minSpend: number | null;
  maxSpend: number | null;
  productIds: string[];
  excludeProductIds: string[];
  categoryIds: string[];
  freeShipping: boolean;
};

export type Destination = { country: string; state: string; postcode: string };

export type ShippingChoice = { id: string; type: string; title: string; cost: number };

export type LineTotals = CartLine & {
  subtotal: number;
  discount: number;
  total: number;
  taxTotal: number;
};

export type CartTotals = {
  lines: LineTotals[];
  itemCount: number;
  subtotal: number;
  discountTotal: number;
  shippingTotal: number;
  shippingTaxTotal: number;
  taxTotal: number;
  total: number;
  needsShipping: boolean;
  pricesIncludeTax: boolean;
  coupon: { code: string; amount: number; freeShipping: boolean } | null;
  couponError: string | null;
  shipping: ShippingChoice | null;
};

function lineEligible(line: CartLine, coupon: CouponRule): boolean {
  if (coupon.excludeProductIds.includes(line.productId)) return false;
  const hasRestriction = coupon.productIds.length > 0 || coupon.categoryIds.length > 0;
  if (!hasRestriction) return true;
  if (coupon.productIds.includes(line.productId)) return true;
  return coupon.categoryIds.some((c) => line.categoryIds.includes(c));
}

/** Share `amount` across lines proportionally to their subtotal; cents never get lost. */
function distribute(amount: number, weights: number[]): number[] {
  const sum = weights.reduce((a, b) => a + b, 0);
  if (sum <= 0 || amount <= 0) return weights.map(() => 0);
  const out = weights.map((w) => Math.floor((amount * w) / sum));
  let remainder = amount - out.reduce((a, b) => a + b, 0);
  for (let i = 0; remainder > 0 && i < out.length; i++) {
    if (weights[i]! > 0) {
      out[i]! += 1;
      remainder -= 1;
    }
  }
  return out;
}

/** First tax rate matching the destination (empty country = everywhere). */
export function findTaxRate(rates: TaxRate[], dest: Destination | null): TaxRate | null {
  if (!rates.length) return null;
  const country = dest?.country?.toUpperCase() ?? '';
  const state = (dest?.state ?? '').trim().toLowerCase();
  for (const rate of rates) {
    const rc = rate.country.toUpperCase();
    if (rc && rc !== country) continue;
    const rs = rate.state.trim().toLowerCase();
    if (rs && rs !== state) continue;
    return rate;
  }
  return null;
}

/** Tax contained in a gross amount at `basisPoints`. */
function taxWithin(gross: number, basisPoints: number): number {
  if (basisPoints <= 0) return 0;
  return gross - Math.round((gross * 10_000) / (10_000 + basisPoints));
}

/** Shipping methods a destination can use (zone match, free-shipping threshold). */
export function availableShippingMethods(
  settings: ShopSettings,
  dest: Destination | null,
  discountedSubtotal: number,
): ShippingChoice[] {
  if (!settings.shipping.enabled) return [];
  const country = dest?.country?.toUpperCase() ?? '';
  const zones = settings.shipping.zones;
  const zone =
    zones.find((z) => z.countries.length > 0 && z.countries.includes(country)) ??
    zones.find((z) => z.countries.length === 0) ??
    null;
  if (!zone) return [];
  return zone.methods
    .filter((m: ShippingMethod) => m.enabled)
    .filter((m) => m.type !== 'free_shipping' || discountedSubtotal >= m.minAmount)
    .map((m) => ({ id: m.id, type: m.type, title: m.title, cost: m.type === 'free_shipping' ? 0 : m.cost }));
}

export function computeTotals(input: {
  lines: CartLine[];
  coupon: CouponRule | null;
  shipping: ShippingChoice | null;
  destination: Destination | null;
  settings: ShopSettings;
}): CartTotals {
  const { settings } = input;
  const includeTax = settings.tax.enabled && settings.tax.pricesIncludeTax;
  const rate = settings.tax.enabled ? findTaxRate(settings.tax.rates, input.destination) : null;
  const bp = rate?.rate ?? 0;

  const subtotals = input.lines.map((l) => l.unitPrice * l.qty);
  const subtotal = subtotals.reduce((a, b) => a + b, 0);
  const needsShipping = settings.shipping.enabled && input.lines.some((l) => !l.virtual);

  // Coupon
  let discounts = input.lines.map(() => 0);
  let coupon: CartTotals['coupon'] = null;
  let couponError: string | null = null;
  if (input.coupon) {
    const c = input.coupon;
    if (c.minSpend !== null && subtotal < c.minSpend) couponError = 'The cart does not reach the minimum spend for this coupon.';
    else if (c.maxSpend !== null && subtotal > c.maxSpend) couponError = 'The cart exceeds the maximum spend for this coupon.';
    else {
      const eligible = input.lines.map((l) => lineEligible(l, c));
      const eligibleSubtotals = subtotals.map((s, i) => (eligible[i] ? s : 0));
      const eligibleSum = eligibleSubtotals.reduce((a, b) => a + b, 0);
      if (eligibleSum <= 0 && c.type !== 'fixed_product') {
        couponError = 'This coupon does not apply to the items in your cart.';
      } else if (c.type === 'percent') {
        discounts = distribute(percentOf(eligibleSum, c.amount), eligibleSubtotals);
      } else if (c.type === 'fixed_cart') {
        discounts = distribute(Math.min(c.amount, eligibleSum), eligibleSubtotals);
      } else {
        discounts = input.lines.map((l, i) => (eligible[i] ? Math.min(subtotals[i]!, c.amount * l.qty) : 0));
        if (!discounts.some((d) => d > 0)) couponError = 'This coupon does not apply to the items in your cart.';
      }
      if (!couponError) {
        coupon = { code: c.code, amount: discounts.reduce((a, b) => a + b, 0), freeShipping: c.freeShipping };
      }
    }
    if (couponError) discounts = input.lines.map(() => 0);
  }
  const discountTotal = discounts.reduce((a, b) => a + b, 0);

  // Lines
  const lines: LineTotals[] = input.lines.map((l, i) => {
    const lineSubtotal = subtotals[i]!;
    const total = lineSubtotal - discounts[i]!;
    const taxable = l.taxable && bp > 0;
    const taxTotal = !taxable ? 0 : includeTax ? taxWithin(total, bp) : percentOf(total, bp);
    return { ...l, subtotal: lineSubtotal, discount: discounts[i]!, total, taxTotal };
  });

  // Shipping
  let shipping: ShippingChoice | null = needsShipping ? input.shipping : null;
  let shippingTotal = shipping ? shipping.cost : 0;
  if (shipping && coupon?.freeShipping) {
    shippingTotal = 0;
    shipping = { ...shipping, cost: 0 };
  }
  const shippingTaxable = Boolean(rate?.shipping) && bp > 0 && shippingTotal > 0;
  const shippingTaxTotal = !shippingTaxable ? 0 : includeTax ? taxWithin(shippingTotal, bp) : percentOf(shippingTotal, bp);

  const itemsTax = lines.reduce((a, l) => a + l.taxTotal, 0);
  const taxTotal = itemsTax + shippingTaxTotal;
  const goods = subtotal - discountTotal;
  const total = includeTax ? goods + shippingTotal : goods + shippingTotal + taxTotal;

  return {
    lines,
    itemCount: lines.reduce((a, l) => a + l.qty, 0),
    subtotal,
    discountTotal,
    shippingTotal,
    shippingTaxTotal,
    taxTotal,
    total: Math.max(0, total),
    needsShipping,
    pricesIncludeTax: includeTax,
    coupon,
    couponError,
    shipping,
  };
}
