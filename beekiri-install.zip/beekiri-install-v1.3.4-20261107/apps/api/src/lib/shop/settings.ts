import { z } from 'zod';
import { SHIPPING_METHOD_TYPES } from './constants';
import { currencyInfo, type MoneyFormat } from './money';
import { decryptSecret, encryptSecret, isMaskedValue, maskSecret } from './secrets';

/**
 * Shopping settings: one JSON document per site (table ShopSetting).
 * `parseShopSettings` always returns a complete object, so callers never
 * check for missing keys; `shopSettingsSchema` validates admin saves.
 */

const str = (max = 200) => z.string().max(max);
const money = z.number().int().min(0).max(1_000_000_000);
const country = z.string().regex(/^[A-Z]{2}$/);

export const addressSchema = z
  .object({
    line1: str(200).default(''),
    line2: str(200).default(''),
    city: str(100).default(''),
    state: str(100).default(''),
    postcode: str(32).default(''),
    country: z.string().max(2).default(''),
  })
  .strict();

export const shippingMethodSchema = z
  .object({
    id: str(40),
    type: z.enum(SHIPPING_METHOD_TYPES),
    title: str(80),
    /** flat_rate / local_pickup cost (minor units) */
    cost: money.default(0),
    /** free_shipping: order subtotal needed (minor units; 0 = always) */
    minAmount: money.default(0),
    enabled: z.boolean().default(true),
  })
  .strict();

export const shippingZoneSchema = z
  .object({
    id: str(40),
    name: str(80),
    /** ISO country codes; empty = everywhere not matched by another zone */
    countries: z.array(country).max(250).default([]),
    methods: z.array(shippingMethodSchema).max(20).default([]),
  })
  .strict();

export const taxRateSchema = z
  .object({
    id: str(40),
    /** empty = any country */
    country: z.string().max(2).default(''),
    state: str(100).default(''),
    /** basis points: 20.00% = 2000 */
    rate: z.number().int().min(0).max(10_000),
    name: str(80).default('Tax'),
    shipping: z.boolean().default(true),
  })
  .strict();

/* ── Checkout fields (built-in ones can be renamed / reordered / made optional; custom ones added) ── */

export const CHECKOUT_FIELD_TYPES = ['text', 'email', 'tel', 'textarea', 'select', 'checkbox'] as const;
export const CHECKOUT_SECTIONS = ['contact', 'billing', 'extra'] as const;

export const checkoutFieldSchema = z
  .object({
    /** Built-in keys: email, phone, billing.firstName … ; custom keys: custom.<slug> */
    key: z.string().min(1).max(60).regex(/^[a-zA-Z][a-zA-Z0-9_.-]*$/),
    label: str(80),
    type: z.enum(CHECKOUT_FIELD_TYPES).default('text'),
    section: z.enum(CHECKOUT_SECTIONS).default('extra'),
    enabled: z.boolean().default(true),
    required: z.boolean().default(false),
    placeholder: str(120).default(''),
    /** select: one option per entry */
    options: z.array(str(80)).max(50).default([]),
    width: z.enum(['full', 'half']).default('full'),
    /** Built-in fields cannot be removed, only hidden (when `locked` is false). */
    builtin: z.boolean().default(false),
    /** Always on and required (name, street, city, country, email). */
    locked: z.boolean().default(false),
  })
  .strict();

export type CheckoutField = z.infer<typeof checkoutFieldSchema>;

/** The WooCommerce-style defaults; `key` decides where the value is stored. */
export const DEFAULT_CHECKOUT_FIELDS: CheckoutField[] = [
  { key: 'email', label: 'Email address', type: 'email', section: 'contact', enabled: true, required: true, placeholder: '', options: [], width: 'half', builtin: true, locked: true },
  { key: 'phone', label: 'Phone', type: 'tel', section: 'contact', enabled: true, required: false, placeholder: '', options: [], width: 'half', builtin: true, locked: false },
  { key: 'billing.firstName', label: 'First name', type: 'text', section: 'billing', enabled: true, required: true, placeholder: '', options: [], width: 'half', builtin: true, locked: true },
  { key: 'billing.lastName', label: 'Last name', type: 'text', section: 'billing', enabled: true, required: true, placeholder: '', options: [], width: 'half', builtin: true, locked: true },
  { key: 'billing.company', label: 'Company name', type: 'text', section: 'billing', enabled: true, required: false, placeholder: '', options: [], width: 'full', builtin: true, locked: false },
  { key: 'billing.country', label: 'Country / Region', type: 'select', section: 'billing', enabled: true, required: true, placeholder: '', options: [], width: 'full', builtin: true, locked: true },
  { key: 'billing.line1', label: 'Street address', type: 'text', section: 'billing', enabled: true, required: true, placeholder: 'House number and street name', options: [], width: 'full', builtin: true, locked: true },
  { key: 'billing.line2', label: 'Apartment, suite, unit, etc.', type: 'text', section: 'billing', enabled: true, required: false, placeholder: 'Apartment, suite, unit, etc. (optional)', options: [], width: 'full', builtin: true, locked: false },
  { key: 'billing.postcode', label: 'Postcode / ZIP', type: 'text', section: 'billing', enabled: true, required: false, placeholder: '', options: [], width: 'half', builtin: true, locked: false },
  { key: 'billing.city', label: 'Town / City', type: 'text', section: 'billing', enabled: true, required: true, placeholder: '', options: [], width: 'half', builtin: true, locked: true },
  { key: 'billing.state', label: 'State / County', type: 'text', section: 'billing', enabled: true, required: false, placeholder: '', options: [], width: 'full', builtin: true, locked: false },
  { key: 'customerNote', label: 'Order notes', type: 'textarea', section: 'extra', enabled: true, required: false, placeholder: 'Notes about your order, e.g. special notes for delivery.', options: [], width: 'full', builtin: true, locked: false },
];

/** Merge stored fields with the built-in list so new built-ins always exist and locked ones stay on. */
export function normalizeCheckoutFields(stored: CheckoutField[]): CheckoutField[] {
  const byKey = new Map(stored.map((f) => [f.key, f]));
  const out: CheckoutField[] = [];
  for (const f of stored) {
    const base = DEFAULT_CHECKOUT_FIELDS.find((d) => d.key === f.key);
    if (base) out.push({ ...base, ...f, type: base.type, section: base.section, builtin: true, locked: base.locked, enabled: base.locked ? true : f.enabled, required: base.locked ? true : f.required });
    else if (f.key.startsWith('custom.')) out.push({ ...f, builtin: false, locked: false, section: 'extra' });
  }
  for (const d of DEFAULT_CHECKOUT_FIELDS) if (!byKey.has(d.key)) out.push({ ...d });
  return out;
}

const pageOptions = z
  .object({
    shop: z
      .object({
        columns: z.number().int().min(2).max(4).default(3),
        showSidebar: z.boolean().default(true),
        showSearch: z.boolean().default(true),
        showSort: z.boolean().default(true),
        showBreadcrumbs: z.boolean().default(true),
        showResultCount: z.boolean().default(true),
      })
      .strict()
      .default({}),
    product: z
      .object({
        showBreadcrumbs: z.boolean().default(true),
        showRelated: z.boolean().default(true),
        showAdditionalInfo: z.boolean().default(true),
        showGalleryThumbs: z.boolean().default(true),
        showMeta: z.boolean().default(true),
      })
      .strict()
      .default({}),
    cart: z.object({ showCoupon: z.boolean().default(true), showContinueShopping: z.boolean().default(true) }).strict().default({}),
    checkout: z.object({ showOrderSummaryImages: z.boolean().default(true) }).strict().default({}),
  })
  .strict();

const emailToggle = (subject: string) =>
  z.object({ enabled: z.boolean().default(true), subject: str(200).default(subject) }).strict();

export const shopSettingsSchema = z
  .object({
    general: z
      .object({
        storeName: str(120).default(''),
        storeEmail: z.union([z.literal(''), z.string().email().max(320)]).default(''),
        address: addressSchema.default({}),
        sellTo: z.enum(['all', 'specific']).default('all'),
        sellToCountries: z.array(country).max(250).default([]),
        currency: z.string().regex(/^[A-Z]{3}$/).default('EUR'),
        currencyPosition: z.enum(['left', 'right', 'left_space', 'right_space']).default('left'),
        thousandSeparator: z.string().max(1).default(','),
        decimalSeparator: z.string().max(1).default('.'),
        /** null → the currency's own decimals */
        decimals: z.number().int().min(0).max(4).nullable().default(null),
      })
      .strict()
      .default({}),
    products: z
      .object({
        shopTitle: str(120).default('Shop'),
        shopDescription: str(500).default(''),
        perPage: z.number().int().min(1).max(100).default(12),
        defaultSort: z
          .enum(['menu_order', 'newest', 'price', 'price-desc', 'popularity', 'title'])
          .default('menu_order'),
        placeholderImageId: str(128).default(''),
        hideOutOfStock: z.boolean().default(false),
        lowStockThreshold: z.number().int().min(0).max(100_000).default(2),
        showCategories: z.boolean().default(true),
        showSku: z.boolean().default(true),
        relatedCount: z.number().int().min(0).max(12).default(4),
      })
      .strict()
      .default({}),
    tax: z
      .object({
        enabled: z.boolean().default(false),
        pricesIncludeTax: z.boolean().default(true),
        rates: z.array(taxRateSchema).max(100).default([]),
        taxBasedOn: z.enum(['shipping', 'billing', 'store']).default('shipping'),
      })
      .strict()
      .default({}),
    shipping: z
      .object({
        enabled: z.boolean().default(true),
        zones: z.array(shippingZoneSchema).max(50).default([]),
      })
      .strict()
      .default({}),
    payments: z
      .object({
        cod: z
          .object({
            enabled: z.boolean().default(true),
            title: str(80).default('Cash on delivery'),
            description: str(500).default('Pay with cash when your order is delivered.'),
            instructions: str(2000).default(''),
          })
          .strict()
          .default({}),
        bankTransfer: z
          .object({
            enabled: z.boolean().default(false),
            title: str(80).default('Direct bank transfer'),
            description: str(500).default(
              'Make your payment directly into our bank account. Your order will ship once the funds have cleared.',
            ),
            instructions: str(2000).default(''),
            accounts: z
              .array(
                z
                  .object({
                    accountName: str(120).default(''),
                    accountNumber: str(64).default(''),
                    bankName: str(120).default(''),
                    sortCode: str(32).default(''),
                    iban: str(64).default(''),
                    bic: str(32).default(''),
                  })
                  .strict(),
              )
              .max(10)
              .default([]),
          })
          .strict()
          .default({}),
        stripe: z
          .object({
            enabled: z.boolean().default(false),
            title: str(80).default('Credit / debit card'),
            description: str(500).default('Pay securely with your card via Stripe.'),
            mode: z.enum(['test', 'live']).default('test'),
            publishableKey: str(255).default(''),
            /** stored encrypted; the API returns a masked value */
            secretKey: str(512).default(''),
            webhookSecret: str(512).default(''),
          })
          .strict()
          .default({}),
      })
      .strict()
      .default({}),
    checkout: z
      .object({
        /** Form fields in display order (see DEFAULT_CHECKOUT_FIELDS). */
        fields: z.array(checkoutFieldSchema).max(60).default(DEFAULT_CHECKOUT_FIELDS).transform(normalizeCheckoutFields),
        termsPageId: str(128).default(''),
        termsRequired: z.boolean().default(false),
        privacyPageId: str(128).default(''),
        thankYouMessage: str(1000).default('Thank you. Your order has been received.'),
      })
      .strict()
      .default({}),
    emails: z
      .object({
        fromName: str(120).default(''),
        adminEmail: z.union([z.literal(''), z.string().email().max(320)]).default(''),
        newOrderAdmin: emailToggle('[{site}] New order #{number}').default({}),
        orderReceived: emailToggle('Your {site} order #{number} has been received').default({}),
        onHold: emailToggle('Your {site} order #{number} is on hold').default({}),
        processing: emailToggle('Your {site} order #{number} is being processed').default({}),
        completed: emailToggle('Your {site} order #{number} is complete').default({}),
        cancelled: emailToggle('Your {site} order #{number} has been cancelled').default({}),
        refunded: emailToggle('Your {site} order #{number} has been refunded').default({}),
        customerNote: emailToggle('A note has been added to your {site} order #{number}').default({}),
        shipped: emailToggle('Your {site} order #{number} is on its way').default({}),
        delivered: emailToggle('Your {site} order #{number} has been delivered').default({}),
        footerText: str(500).default(''),
        accentColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).default('#F2842F'),
      })
      .strict()
      .default({}),
    /** Shopper accounts (My account). */
    accounts: z
      .object({
        enabled: z.boolean().default(true),
        allowRegistration: z.boolean().default(true),
        /** Shoppers must sign in before checkout (otherwise guests can buy). */
        requireAccount: z.boolean().default(false),
        /** Offer "Create an account" with a password field at checkout. */
        createAtCheckout: z.boolean().default(true),
      })
      .strict()
      .default({}),
    /** Shop → Shop Editor: per-page display options (the page content itself is a BeekiriCode document). */
    pages: pageOptions.default({}),
    advanced: z
      .object({
        orderNumberPrefix: str(10).default('#'),
        orderNumberStart: z.number().int().min(1).max(1_000_000_000).default(1000),
        holdStockMinutes: z.number().int().min(5).max(10_080).default(60),
        cartExpiryDays: z.number().int().min(1).max(365).default(30),
        removeDataOnUninstall: z.boolean().default(false),
      })
      .strict()
      .default({}),
  })
  .strict();

export type ShopSettings = z.infer<typeof shopSettingsSchema>;
export type ShippingZone = z.infer<typeof shippingZoneSchema>;
export type ShippingMethod = z.infer<typeof shippingMethodSchema>;
export type TaxRate = z.infer<typeof taxRateSchema>;
export type ShopAddress = z.infer<typeof addressSchema>;

/** Never throws: unknown/invalid parts fall back to defaults. */
export function parseShopSettings(raw: unknown): ShopSettings {
  const result = shopSettingsSchema.safeParse(raw && typeof raw === 'object' ? raw : {});
  if (result.success) return result.data;
  // Salvage valid sections one by one so one bad key does not reset the whole document.
  const obj = (raw ?? {}) as Record<string, unknown>;
  const out: Record<string, unknown> = {};
  for (const key of Object.keys(shopSettingsSchema.shape) as (keyof ShopSettings)[]) {
    const section = shopSettingsSchema.shape[key].safeParse(obj[key]);
    out[key] = section.success ? section.data : shopSettingsSchema.shape[key].parse(undefined);
  }
  return out as ShopSettings;
}

export function defaultShopSettings(): ShopSettings {
  return shopSettingsSchema.parse({});
}

export function moneyFormatOf(settings: ShopSettings): MoneyFormat {
  const g = settings.general;
  return {
    currency: g.currency,
    position: g.currencyPosition,
    thousandSeparator: g.thousandSeparator,
    decimalSeparator: g.decimalSeparator,
    decimals: g.decimals,
  };
}

export function currencyDecimals(settings: ShopSettings): number {
  return currencyInfo(settings.general.currency).decimals;
}

const SECRET_PATHS = ['payments.stripe.secretKey', 'payments.stripe.webhookSecret'] as const;

function getPath(obj: unknown, path: string): unknown {
  return path.split('.').reduce<unknown>((o, k) => (o && typeof o === 'object' ? (o as Record<string, unknown>)[k] : undefined), obj);
}
function setPath(obj: Record<string, unknown>, path: string, value: unknown) {
  const keys = path.split('.');
  let cur: Record<string, unknown> = obj;
  for (const k of keys.slice(0, -1)) cur = cur[k] as Record<string, unknown>;
  cur[keys[keys.length - 1]!] = value;
}

/** Stored form → what the admin may see (secrets masked). */
export function maskShopSettings(stored: ShopSettings): ShopSettings {
  const copy = JSON.parse(JSON.stringify(stored)) as ShopSettings;
  for (const path of SECRET_PATHS) {
    const plain = decryptSecret(String(getPath(copy, path) ?? ''));
    setPath(copy as unknown as Record<string, unknown>, path, maskSecret(plain));
  }
  return copy;
}

/**
 * Admin save → stored form. A blank or masked secret keeps the current value;
 * a new value is encrypted.
 */
export function storableShopSettings(incoming: ShopSettings, current: ShopSettings): ShopSettings {
  const copy = JSON.parse(JSON.stringify(incoming)) as ShopSettings;
  for (const path of SECRET_PATHS) {
    const next = String(getPath(copy, path) ?? '').trim();
    const existing = String(getPath(current, path) ?? '');
    const keep = !next || isMaskedValue(next);
    setPath(copy as unknown as Record<string, unknown>, path, keep ? existing : encryptSecret(next));
  }
  return copy;
}

/** Decrypted secret for server-side use only. */
export function readSecret(settings: ShopSettings, path: (typeof SECRET_PATHS)[number]): string {
  return decryptSecret(String(getPath(settings, path) ?? ''));
}

/** Which payment methods a shopper can pick (configured + enabled). */
export function enabledPaymentMethods(settings: ShopSettings) {
  const p = settings.payments;
  const out: { id: 'cod' | 'bank_transfer' | 'stripe'; title: string; description: string }[] = [];
  if (p.stripe.enabled && readSecret(settings, 'payments.stripe.secretKey')) {
    out.push({ id: 'stripe', title: p.stripe.title, description: p.stripe.description });
  }
  if (p.cod.enabled) out.push({ id: 'cod', title: p.cod.title, description: p.cod.description });
  if (p.bankTransfer.enabled) {
    out.push({ id: 'bank_transfer', title: p.bankTransfer.title, description: p.bankTransfer.description });
  }
  return out;
}
