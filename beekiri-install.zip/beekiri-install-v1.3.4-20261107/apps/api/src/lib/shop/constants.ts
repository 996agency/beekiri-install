/** Shared identifiers for the Shopping extension. */

export const SHOP_EXTENSION_SLUG = 'shopping';

/** Post type that holds products (title, slug, description, image, SEO, terms). */
export const PRODUCT_KIND = 'product';
export const PRODUCT_CATEGORY_TAXONOMY = 'product_cat';
export const PRODUCT_TAG_TAXONOMY = 'product_tag';

/** Storefront paths (fixed; the Next.js routes live at the same places). */
export const SHOP_PATHS = {
  shop: '/shop',
  category: (slug: string) => `/shop/category/${slug}`,
  product: (slug: string) => `/product/${slug}`,
  cart: '/cart',
  checkout: '/checkout',
  orderReceived: (token: string) => `/checkout/order-received/${token}`,
} as const;

/** Post type holding the editable storefront pages (BeekiriCode documents around the shop content). */
export const SHOP_PAGE_KIND = 'shop_page';
export const SHOP_PAGE_VIEWS = ['shop', 'product', 'cart', 'checkout', 'order-received', 'account'] as const;
export type ShopPageView = (typeof SHOP_PAGE_VIEWS)[number];
export const SHOP_PAGE_TITLES: Record<ShopPageView, string> = {
  shop: 'Shop',
  product: 'Product page',
  cart: 'Cart',
  checkout: 'Checkout',
  'order-received': 'Order received',
  account: 'My account',
};
export const SHOP_PAGE_PATHS: Record<ShopPageView, string> = {
  shop: '/shop',
  product: '/product/…',
  cart: '/cart',
  checkout: '/checkout',
  'order-received': '/checkout/order-received/…',
  account: '/account',
};
/** Marker the public renderer emits for the "Shop content" element; the website swaps it for the live content. */
export const SHOP_SLOT_HTML = '<div class="bk-shop-slot" data-shop-slot></div>';

export const CART_COOKIE = 'beekiri_cart';
/** Signed-in shopper (My account). */
export const CUSTOMER_COOKIE = 'beekiri_customer';
export const ACCOUNT_PATH = '/account';

export const FULFILLMENT_STATUSES = ['unfulfilled', 'packed', 'shipped', 'delivered'] as const;
export type FulfillmentStatus = (typeof FULFILLMENT_STATUSES)[number];
/** Browser requests that change a cart or place an order must send this header. */
export const SHOP_REQUEST_HEADER = 'x-beekiri-shop';

export const ORDER_STATUSES = [
  'pending',
  'on-hold',
  'processing',
  'completed',
  'cancelled',
  'refunded',
  'failed',
] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  pending: 'Pending payment',
  'on-hold': 'On hold',
  processing: 'Processing',
  completed: 'Completed',
  cancelled: 'Cancelled',
  refunded: 'Refunded',
  failed: 'Failed',
};

export const PAYMENT_STATUSES = ['unpaid', 'paid', 'partially_refunded', 'refunded', 'failed'] as const;
export type PaymentStatus = (typeof PAYMENT_STATUSES)[number];

export const PAYMENT_METHODS = ['cod', 'bank_transfer', 'stripe'] as const;
export type PaymentMethod = (typeof PAYMENT_METHODS)[number];

export const STOCK_STATUSES = ['instock', 'outofstock', 'onbackorder'] as const;
export type StockStatus = (typeof STOCK_STATUSES)[number];

export const PRODUCT_TYPES = ['simple', 'variable'] as const;
export type ProductType = (typeof PRODUCT_TYPES)[number];

export const CATALOG_VISIBILITIES = ['visible', 'catalog', 'search', 'hidden'] as const;

export const COUPON_TYPES = ['percent', 'fixed_cart', 'fixed_product'] as const;
export type CouponType = (typeof COUPON_TYPES)[number];

export const SHIPPING_METHOD_TYPES = ['flat_rate', 'free_shipping', 'local_pickup'] as const;

/** Orders that still hold stock. */
export const STOCK_HOLDING_STATUSES: readonly string[] = ['pending', 'on-hold', 'processing', 'completed'];
