/**
 * Money is stored as integers in the currency's minor unit (cents, pence…).
 * Formatting follows the shop's settings; currencies without minor units are handled.
 */

export type CurrencyInfo = { code: string; symbol: string; name: string; decimals: number };

export const CURRENCIES: CurrencyInfo[] = [
  { code: 'EUR', symbol: '€', name: 'Euro', decimals: 2 },
  { code: 'USD', symbol: '$', name: 'US Dollar', decimals: 2 },
  { code: 'GBP', symbol: '£', name: 'Pound Sterling', decimals: 2 },
  { code: 'CHF', symbol: 'CHF', name: 'Swiss Franc', decimals: 2 },
  { code: 'SEK', symbol: 'kr', name: 'Swedish Krona', decimals: 2 },
  { code: 'NOK', symbol: 'kr', name: 'Norwegian Krone', decimals: 2 },
  { code: 'DKK', symbol: 'kr', name: 'Danish Krone', decimals: 2 },
  { code: 'PLN', symbol: 'zł', name: 'Polish Złoty', decimals: 2 },
  { code: 'CZK', symbol: 'Kč', name: 'Czech Koruna', decimals: 2 },
  { code: 'HUF', symbol: 'Ft', name: 'Hungarian Forint', decimals: 2 },
  { code: 'RON', symbol: 'lei', name: 'Romanian Leu', decimals: 2 },
  { code: 'BGN', symbol: 'лв', name: 'Bulgarian Lev', decimals: 2 },
  { code: 'ALL', symbol: 'L', name: 'Albanian Lek', decimals: 2 },
  { code: 'MKD', symbol: 'ден', name: 'Macedonian Denar', decimals: 2 },
  { code: 'RSD', symbol: 'din', name: 'Serbian Dinar', decimals: 2 },
  { code: 'BAM', symbol: 'KM', name: 'Bosnia and Herzegovina Mark', decimals: 2 },
  { code: 'TRY', symbol: '₺', name: 'Turkish Lira', decimals: 2 },
  { code: 'CAD', symbol: '$', name: 'Canadian Dollar', decimals: 2 },
  { code: 'AUD', symbol: '$', name: 'Australian Dollar', decimals: 2 },
  { code: 'NZD', symbol: '$', name: 'New Zealand Dollar', decimals: 2 },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen', decimals: 0 },
  { code: 'KRW', symbol: '₩', name: 'South Korean Won', decimals: 0 },
  { code: 'CNY', symbol: '¥', name: 'Chinese Yuan', decimals: 2 },
  { code: 'INR', symbol: '₹', name: 'Indian Rupee', decimals: 2 },
  { code: 'BRL', symbol: 'R$', name: 'Brazilian Real', decimals: 2 },
  { code: 'MXN', symbol: '$', name: 'Mexican Peso', decimals: 2 },
  { code: 'ZAR', symbol: 'R', name: 'South African Rand', decimals: 2 },
  { code: 'AED', symbol: 'د.إ', name: 'UAE Dirham', decimals: 2 },
  { code: 'SAR', symbol: '﷼', name: 'Saudi Riyal', decimals: 2 },
  { code: 'ILS', symbol: '₪', name: 'Israeli New Shekel', decimals: 2 },
  { code: 'SGD', symbol: '$', name: 'Singapore Dollar', decimals: 2 },
  { code: 'HKD', symbol: '$', name: 'Hong Kong Dollar', decimals: 2 },
];

const BY_CODE = new Map(CURRENCIES.map((c) => [c.code, c]));

export function currencyInfo(code: string): CurrencyInfo {
  return BY_CODE.get(code.toUpperCase()) ?? { code: code.toUpperCase(), symbol: code.toUpperCase(), name: code, decimals: 2 };
}

export type MoneyFormat = {
  currency: string;
  position: 'left' | 'right' | 'left_space' | 'right_space';
  thousandSeparator: string;
  decimalSeparator: string;
  /** null → the currency's own number of decimals */
  decimals: number | null;
};

/** 1999 → "€19.99" (never throws; bad input renders as 0). */
export function formatMoney(minor: number | null | undefined, fmt: MoneyFormat): string {
  const info = currencyInfo(fmt.currency);
  const decimals = fmt.decimals ?? info.decimals;
  const amount = Number.isFinite(minor) ? Math.trunc(minor as number) : 0;
  const negative = amount < 0;
  const abs = Math.abs(amount);
  const divisor = 10 ** info.decimals;
  const value = abs / divisor;
  const fixed = value.toFixed(decimals);
  const [intPart, fracPart] = fixed.split('.');
  const grouped = (intPart ?? '0').replace(/\B(?=(\d{3})+(?!\d))/g, fmt.thousandSeparator);
  const number = fracPart !== undefined && decimals > 0 ? `${grouped}${fmt.decimalSeparator}${fracPart}` : grouped;
  const symbol = info.symbol;
  let out: string;
  switch (fmt.position) {
    case 'right':
      out = `${number}${symbol}`;
      break;
    case 'left_space':
      out = `${symbol} ${number}`;
      break;
    case 'right_space':
      out = `${number} ${symbol}`;
      break;
    default:
      out = `${symbol}${number}`;
  }
  return negative ? `-${out}` : out;
}

/** "19.99" (admin input) → 1999 minor units. Returns null for blank/invalid. */
export function parseMoney(input: string | number | null | undefined, currency: string): number | null {
  if (input === null || input === undefined) return null;
  if (typeof input === 'number') return Number.isFinite(input) ? Math.round(input) : null;
  const raw = input.trim().replace(/\s/g, '');
  if (!raw) return null;
  // Accept both "1.234,56" and "1,234.56": the last separator is the decimal point.
  const lastComma = raw.lastIndexOf(',');
  const lastDot = raw.lastIndexOf('.');
  let normalized: string;
  if (lastComma > lastDot) normalized = raw.replace(/\./g, '').replace(',', '.');
  else normalized = raw.replace(/,/g, '');
  if (!/^-?\d*(\.\d*)?$/.test(normalized)) return null;
  const value = Number(normalized);
  if (!Number.isFinite(value)) return null;
  const decimals = currencyInfo(currency).decimals;
  return Math.round(value * 10 ** decimals);
}

/** 1999 → 19.99 as a plain decimal string for inputs. */
export function minorToDecimal(minor: number | null | undefined, currency: string): string {
  if (minor === null || minor === undefined || !Number.isFinite(minor)) return '';
  const decimals = currencyInfo(currency).decimals;
  return (minor / 10 ** decimals).toFixed(decimals);
}

/** Percentage stored ×100 (12.5% = 1250) applied to a minor amount, rounded half-up. */
export function percentOf(minor: number, basisPoints: number): number {
  return Math.round((minor * basisPoints) / 10_000);
}

/** Stripe wants the smallest unit too, but for zero-decimal currencies it must not be ×100. */
export function toStripeAmount(minor: number): number {
  return Math.max(0, Math.trunc(minor));
}
