import type { StockStatus } from './constants';

/** Columns shared by products and variants that decide the current price. */
export type Priced = {
  regularPrice: number | null;
  salePrice: number | null;
  saleFrom?: Date | string | null;
  saleTo?: Date | string | null;
};

export type Stocked = {
  manageStock: boolean;
  stockQty: number | null;
  stockStatus: string;
};

export type EffectivePrice = {
  /** What the shopper pays now (null = no price set, not purchasable). */
  price: number | null;
  regular: number | null;
  onSale: boolean;
};

function toTime(v: Date | string | null | undefined): number | null {
  if (!v) return null;
  const t = v instanceof Date ? v.getTime() : Date.parse(v);
  return Number.isFinite(t) ? t : null;
}

/** Sale price wins while the schedule (if any) is running and it is lower than regular. */
export function effectivePrice(row: Priced, now = Date.now()): EffectivePrice {
  const regular = row.regularPrice ?? null;
  const sale = row.salePrice ?? null;
  if (sale === null || regular === null || sale >= regular) {
    return { price: regular, regular, onSale: false };
  }
  const from = toTime(row.saleFrom);
  const to = toTime(row.saleTo);
  if (from !== null && now < from) return { price: regular, regular, onSale: false };
  if (to !== null && now > to) return { price: regular, regular, onSale: false };
  return { price: sale, regular, onSale: true };
}

/** Lowest/highest current price across enabled variants (for "€10 – €25"). */
export function priceRange(rows: Priced[], now = Date.now()): { min: number; max: number; onSale: boolean } | null {
  let min = Infinity;
  let max = -Infinity;
  let onSale = false;
  for (const row of rows) {
    const p = effectivePrice(row, now);
    if (p.price === null) continue;
    min = Math.min(min, p.price);
    max = Math.max(max, p.price);
    onSale = onSale || p.onSale;
  }
  if (!Number.isFinite(min)) return null;
  return { min, max, onSale };
}

/** Units that can still be sold (Infinity when stock is not tracked). */
export function availableQty(row: Stocked): number {
  if (row.stockStatus === 'outofstock') return 0;
  if (!row.manageStock) return row.stockStatus === 'onbackorder' || row.stockStatus === 'instock' ? Infinity : 0;
  const qty = row.stockQty ?? 0;
  if (qty > 0) return qty;
  return row.stockStatus === 'onbackorder' ? Infinity : 0;
}

export function isInStock(row: Stocked): boolean {
  return availableQty(row) > 0;
}

/** Stock status after a quantity change when stock is managed. */
export function stockStatusFor(qty: number, allowBackorders: boolean): StockStatus {
  if (qty > 0) return 'instock';
  return allowBackorders ? 'onbackorder' : 'outofstock';
}
