import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'crypto';
import { config, secretsStable } from '../../config/env';

/**
 * Payment-provider secrets are encrypted at rest (AES-256-GCM) with a key derived
 * from CACHE_FLUSH_SECRET, so a database dump alone does not expose them.
 * When that secret is missing from .env the key is per-process; the admin shows a warning.
 */
const PREFIX = 'enc:v1:';

function key(): Buffer {
  const secret = config.core.cacheFlushSecret || 'beekiri';
  return createHash('sha256').update(`beekiri-shop:${secret}`).digest();
}

export function encryptSecret(plain: string): string {
  const value = plain.trim();
  if (!value) return '';
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key(), iv);
  const body = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${PREFIX}${Buffer.concat([iv, tag, body]).toString('base64url')}`;
}

/** '' when the value is empty or cannot be decrypted (e.g. the key changed). */
export function decryptSecret(stored: string | null | undefined): string {
  if (!stored) return '';
  if (!stored.startsWith(PREFIX)) return stored;
  try {
    const raw = Buffer.from(stored.slice(PREFIX.length), 'base64url');
    const iv = raw.subarray(0, 12);
    const tag = raw.subarray(12, 28);
    const body = raw.subarray(28);
    const decipher = createDecipheriv('aes-256-gcm', key(), iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(body), decipher.final()]).toString('utf8');
  } catch {
    return '';
  }
}

export function isEncrypted(stored: string | null | undefined): boolean {
  return typeof stored === 'string' && stored.startsWith(PREFIX);
}

/** "sk_live_••••••••abcd" — never the real value. */
export function maskSecret(plain: string): string {
  if (!plain) return '';
  const tail = plain.length > 8 ? plain.slice(-4) : '';
  return `••••••••${tail}`;
}

export function isMaskedValue(v: string): boolean {
  return v.startsWith('••••');
}

/** True when CACHE_FLUSH_SECRET is in .env (so encrypted values survive restarts). */
export function secretsPersist(): boolean {
  return secretsStable;
}
