import type { CheckoutField, ShopSettings } from './settings';

/**
 * Applies Shop → Settings → Checkout field rules to a checkout submission:
 * hidden built-ins are blanked, required ones checked, selects limited to their
 * options, and custom answers collected for storage on the order.
 */

type Address = Record<string, string | undefined>;

export type CheckoutSubmission = {
  email: string;
  phone: string;
  billing: Address;
  shipping?: Address;
  shipToDifferent: boolean;
  customerNote: string;
  extra: Record<string, string>;
};

export type AppliedCheckoutFields = {
  phone: string;
  customerNote: string;
  billing: Address;
  shipping: Address | undefined;
  customFields: Record<string, { label: string; value: string }>;
  errors: string[];
};

const TRUE_VALUES = new Set(['1', 'true', 'on', 'yes']);

function isBlank(v: string | undefined): boolean {
  return !v || !v.trim();
}

/** Built-in fields that the shopper must always fill (the address needs them). */
export const LOCKED_BILLING = ['firstName', 'lastName', 'line1', 'city', 'country'] as const;

export function applyCheckoutFields(settings: ShopSettings, input: CheckoutSubmission): AppliedCheckoutFields {
  const fields = settings.checkout.fields;
  const errors: string[] = [];
  const billing: Address = { ...input.billing };
  const shipping: Address | undefined = input.shipToDifferent && input.shipping ? { ...input.shipping } : undefined;
  let phone = input.phone.trim();
  let customerNote = input.customerNote.trim();
  const customFields: AppliedCheckoutFields['customFields'] = {};

  const field = (key: string): CheckoutField | undefined => fields.find((f) => f.key === key);

  // Phone / note / company… built-ins
  const phoneField = field('phone');
  if (!phoneField?.enabled) phone = '';
  else if (phoneField.required && isBlank(phone)) errors.push(`${phoneField.label} is required.`);

  const noteField = field('customerNote');
  if (!noteField?.enabled) customerNote = '';
  else if (noteField.required && isBlank(customerNote)) errors.push(`${noteField.label} is required.`);

  for (const addr of [billing, shipping].filter((a): a is Address => Boolean(a))) {
    for (const part of ['company', 'line2', 'postcode', 'state'] as const) {
      const f = field(`billing.${part}`);
      if (!f?.enabled) addr[part] = '';
      else if (f.required && isBlank(addr[part])) errors.push(`${f.label} is required.`);
    }
    for (const part of LOCKED_BILLING) {
      if (isBlank(addr[part])) errors.push(`${field(`billing.${part}`)?.label ?? part} is required.`);
    }
  }

  // Custom fields
  for (const f of fields) {
    if (!f.enabled || f.builtin || !f.key.startsWith('custom.')) continue;
    const raw = (input.extra[f.key] ?? '').trim();
    if (f.type === 'checkbox') {
      const checked = TRUE_VALUES.has(raw.toLowerCase());
      if (f.required && !checked) errors.push(`${f.label} must be ticked.`);
      if (checked) customFields[f.key] = { label: f.label, value: 'Yes' };
      continue;
    }
    if (f.required && !raw) {
      errors.push(`${f.label} is required.`);
      continue;
    }
    if (!raw) continue;
    if (f.type === 'select' && f.options.length && !f.options.includes(raw)) {
      errors.push(`${f.label}: choose one of the listed options.`);
      continue;
    }
    if (f.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(raw)) {
      errors.push(`${f.label}: enter a valid email address.`);
      continue;
    }
    customFields[f.key] = { label: f.label, value: raw.slice(0, 2000) };
  }

  return { phone, customerNote, billing, shipping, customFields, errors };
}

/** Fields the checkout template renders, grouped like the form. */
export function checkoutFieldsForTemplate(settings: ShopSettings) {
  const enabled = settings.checkout.fields.filter((f) => f.enabled);
  return {
    contact: enabled.filter((f) => f.section === 'contact'),
    billing: enabled.filter((f) => f.section === 'billing'),
    extra: enabled.filter((f) => f.section === 'extra'),
  };
}
