import type { ShopOrder } from '../../models';
import type { FulfillmentStatus } from './constants';

/**
 * Order progress for shoppers (My account, order page, emails): one timeline built
 * from the order status, payment and fulfilment data. Pure; no I/O.
 */

export type Fulfillment = {
  status: FulfillmentStatus;
  carrier: string;
  trackingNumber: string;
  trackingUrl: string;
  packedAt: string | null;
  shippedAt: string | null;
  deliveredAt: string | null;
};

export function parseFulfillment(raw: unknown): Fulfillment {
  const o = raw && typeof raw === 'object' && !Array.isArray(raw) ? (raw as Record<string, unknown>) : {};
  const status = ['packed', 'shipped', 'delivered'].includes(String(o.status)) ? (o.status as FulfillmentStatus) : 'unfulfilled';
  const str = (v: unknown) => (typeof v === 'string' ? v : '');
  const date = (v: unknown) => (typeof v === 'string' && !Number.isNaN(Date.parse(v)) ? v : null);
  return {
    status,
    carrier: str(o.carrier),
    trackingNumber: str(o.trackingNumber),
    trackingUrl: /^https?:\/\//i.test(str(o.trackingUrl)) ? str(o.trackingUrl) : '',
    packedAt: date(o.packedAt),
    shippedAt: date(o.shippedAt),
    deliveredAt: date(o.deliveredAt),
  };
}

export type TrackingStep = {
  id: 'placed' | 'paid' | 'packed' | 'shipped' | 'delivered';
  label: string;
  /** done | current | upcoming */
  state: 'done' | 'current' | 'upcoming';
  at: string | null;
  detail: string;
};

export type Tracking = {
  steps: TrackingStep[];
  /** Short line for lists ("On its way", "Delivered 4 Nov"). */
  headline: string;
  /** 0–100 for a progress bar. */
  percent: number;
  /** cancelled / refunded / failed end the timeline early. */
  stopped: null | { label: string; tone: 'muted' | 'danger' };
  fulfillment: Fulfillment;
  virtual: boolean;
};

const iso = (d: Date | string | null | undefined) => (d ? new Date(d).toISOString() : null);

export function buildTracking(
  order: Pick<ShopOrder, 'status' | 'paymentMethod' | 'paymentStatus' | 'placedAt' | 'paidAt' | 'completedAt' | 'fulfillment'>,
  opts: { virtual?: boolean } = {},
): Tracking {
  const f = parseFulfillment(order.fulfillment);
  const virtual = Boolean(opts.virtual);
  const completed = order.status === 'completed';
  const paid = order.paymentStatus === 'paid' || order.paymentStatus === 'partially_refunded' || order.paymentStatus === 'refunded';
  const cod = order.paymentMethod === 'cod';
  const delivered = f.status === 'delivered' || completed;
  const shipped = delivered || f.status === 'shipped';
  const packed = shipped || f.status === 'packed';

  const raw: Omit<TrackingStep, 'state'>[] = [
    { id: 'placed', label: 'Order placed', at: iso(order.placedAt), detail: '' },
    {
      id: 'paid',
      label: cod ? 'Pay on delivery' : 'Payment confirmed',
      at: paid ? iso(order.paidAt) : null,
      detail: cod ? 'Cash when your order arrives' : order.paymentMethod === 'bank_transfer' && !paid ? 'Waiting for your bank transfer' : '',
    },
  ];
  if (!virtual) {
    raw.push(
      { id: 'packed', label: 'Packed', at: f.packedAt, detail: '' },
      {
        id: 'shipped',
        label: 'Shipped',
        at: f.shippedAt,
        detail: [f.carrier, f.trackingNumber].filter(Boolean).join(' · '),
      },
      { id: 'delivered', label: 'Delivered', at: f.deliveredAt ?? (completed ? iso(order.completedAt) : null), detail: '' },
    );
  } else {
    raw.push({ id: 'delivered', label: 'Completed', at: completed ? iso(order.completedAt) : null, detail: '' });
  }

  const doneIds = new Set<string>(['placed']);
  if (paid || (cod && order.status !== 'pending')) doneIds.add('paid');
  if (packed) doneIds.add('packed');
  if (shipped) doneIds.add('shipped');
  if (delivered) doneIds.add('delivered');
  // COD is "paid" at the door: mark the step done once the order is delivered.
  if (cod && delivered) doneIds.add('paid');

  let currentSet = false;
  const steps: TrackingStep[] = raw.map((s) => {
    if (doneIds.has(s.id)) return { ...s, state: 'done' };
    if (!currentSet) {
      currentSet = true;
      return { ...s, state: 'current' };
    }
    return { ...s, state: 'upcoming' };
  });

  const stoppedMap: Record<string, Tracking['stopped']> = {
    cancelled: { label: 'Cancelled', tone: 'muted' },
    refunded: { label: 'Refunded', tone: 'muted' },
    failed: { label: 'Payment failed', tone: 'danger' },
  };
  const stopped = stoppedMap[order.status] ?? null;

  const doneCount = steps.filter((s) => s.state === 'done').length;
  const percent = stopped ? 0 : Math.round(((doneCount - 1) / Math.max(1, steps.length - 1)) * 100);

  let headline: string;
  if (stopped) headline = stopped.label;
  else if (delivered) headline = virtual ? 'Completed' : 'Delivered';
  else if (shipped) headline = 'On its way';
  else if (packed) headline = 'Packed and ready to ship';
  else if (order.status === 'pending') headline = 'Waiting for payment';
  else if (order.status === 'on-hold') headline = 'Waiting for your payment';
  else headline = 'Being prepared';

  return { steps, headline, percent, stopped, fulfillment: f, virtual };
}
