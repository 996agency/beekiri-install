import Stripe from 'stripe';
import { BadRequest } from '../../../utils/http-error';
import { SHOP_PATHS } from '../constants';
import { toStripeAmount } from '../money';
import { readSecret, type ShopSettings } from '../settings';
import type { PaymentContext, PaymentProvider } from './types';

/** Stripe Checkout (hosted page). Card data never touches Beekiri. */

export function stripeClient(settings: ShopSettings): Stripe {
  const key = readSecret(settings, 'payments.stripe.secretKey');
  if (!key) throw BadRequest('Stripe is not configured. Add the secret key in Shop → Settings → Payments.');
  return new Stripe(key, { apiVersion: '2025-10-29.clover' as Stripe.LatestApiVersion, maxNetworkRetries: 2 });
}

/** Stripe requires a session to live at least 30 minutes and at most 24 hours. */
function sessionExpiry(holdStockMinutes: number): number {
  const minutes = Math.min(24 * 60, Math.max(30, holdStockMinutes));
  return Math.floor(Date.now() / 1000) + minutes * 60;
}

export const stripeProvider: PaymentProvider = {
  id: 'stripe',

  async start(order, ctx: PaymentContext) {
    const stripe = stripeClient(ctx.settings);
    const currency = order.currency.toLowerCase();
    const lineItems: Stripe.Checkout.SessionCreateParams.LineItem[] = ctx.items.map((item) => ({
      quantity: item.qty,
      price_data: {
        currency,
        unit_amount: toStripeAmount(item.unitPrice),
        product_data: {
          name: item.name.slice(0, 250) || 'Item',
          ...(item.imageUrl && /^https?:\/\//.test(item.imageUrl) ? { images: [item.imageUrl] } : {}),
          ...(item.sku ? { metadata: { sku: item.sku } } : {}),
        },
      },
    }));

    // Tax charged on top of prices is its own line so the Stripe total matches ours exactly.
    const includeTax = ctx.settings.tax.enabled && ctx.settings.tax.pricesIncludeTax;
    if (!includeTax && order.taxTotal > 0) {
      lineItems.push({
        quantity: 1,
        price_data: { currency, unit_amount: toStripeAmount(order.taxTotal), product_data: { name: 'Tax' } },
      });
    }

    const params: Stripe.Checkout.SessionCreateParams = {
      mode: 'payment',
      line_items: lineItems,
      customer_email: order.email,
      client_reference_id: order.id,
      metadata: { orderId: order.id, orderNumber: String(order.number), siteId: order.siteId },
      payment_intent_data: {
        metadata: { orderId: order.id, orderNumber: String(order.number) },
        description: `${ctx.siteTitle} order #${order.number}`,
      },
      success_url: `${ctx.appUrl}${SHOP_PATHS.orderReceived(order.accessToken)}?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${ctx.appUrl}${SHOP_PATHS.checkout}?cancelled=1`,
      expires_at: sessionExpiry(ctx.settings.advanced.holdStockMinutes),
    };

    const method = order.shippingMethod as { title?: string } | null;
    if (method || order.shippingTotal > 0) {
      params.shipping_options = [
        {
          shipping_rate_data: {
            type: 'fixed_amount',
            display_name: (method?.title ?? 'Shipping').slice(0, 100),
            fixed_amount: { amount: toStripeAmount(order.shippingTotal), currency },
          },
        },
      ];
    }

    if (order.discountTotal > 0) {
      const coupon = await stripe.coupons.create({
        amount_off: toStripeAmount(order.discountTotal),
        currency,
        duration: 'once',
        name: order.couponCode ? `Coupon ${order.couponCode}`.slice(0, 40) : 'Discount',
        max_redemptions: 1,
      });
      params.discounts = [{ coupon: coupon.id }];
    }

    const session = await stripe.checkout.sessions.create(params);
    if (!session.url) throw BadRequest('Stripe did not return a checkout page.');
    return {
      kind: 'redirect',
      url: session.url,
      ref: { sessionId: session.id, mode: ctx.settings.payments.stripe.mode },
    };
  },

  async refund(order, amount, ctx, reason) {
    const stripe = stripeClient(ctx.settings);
    const ref = (order.paymentRef ?? {}) as { paymentIntentId?: string };
    if (!ref.paymentIntentId) throw BadRequest('This order has no Stripe payment to refund.');
    const refund = await stripe.refunds.create({
      payment_intent: ref.paymentIntentId,
      amount: toStripeAmount(amount),
      metadata: { orderId: order.id, orderNumber: String(order.number), reason: (reason ?? '').slice(0, 200) },
    });
    return { refundId: refund.id };
  },
};

export type StripeSessionState = {
  id: string;
  paymentStatus: string;
  status: string | null;
  amountTotal: number | null;
  currency: string | null;
  paymentIntentId: string | null;
  orderId: string | null;
};

export async function retrieveStripeSession(settings: ShopSettings, sessionId: string): Promise<StripeSessionState> {
  const stripe = stripeClient(settings);
  const s = await stripe.checkout.sessions.retrieve(sessionId);
  return {
    id: s.id,
    paymentStatus: s.payment_status,
    status: s.status ?? null,
    amountTotal: s.amount_total ?? null,
    currency: s.currency ?? null,
    paymentIntentId: typeof s.payment_intent === 'string' ? s.payment_intent : (s.payment_intent?.id ?? null),
    orderId: s.metadata?.orderId ?? s.client_reference_id ?? null,
  };
}

/** Verify a webhook body against the configured signing secret. Throws on a bad signature. */
export function constructStripeEvent(settings: ShopSettings, rawBody: Buffer, signature: string): Stripe.Event {
  const secret = readSecret(settings, 'payments.stripe.webhookSecret');
  if (!secret) throw BadRequest('Stripe webhook secret is not configured.');
  return Stripe.webhooks.constructEvent(rawBody, signature, secret);
}
