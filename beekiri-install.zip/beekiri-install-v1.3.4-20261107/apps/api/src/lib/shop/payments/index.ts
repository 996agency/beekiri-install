import type { PaymentMethod } from '../constants';
import { bankTransferProvider, codProvider } from './offline';
import { stripeProvider } from './stripe';
import type { PaymentProvider } from './types';

export const PAYMENT_PROVIDERS: Record<PaymentMethod, PaymentProvider> = {
  cod: codProvider,
  bank_transfer: bankTransferProvider,
  stripe: stripeProvider,
};

export function paymentProvider(id: string): PaymentProvider | null {
  return (PAYMENT_PROVIDERS as Record<string, PaymentProvider>)[id] ?? null;
}

export type { PaymentContext, PaymentProvider, PaymentStart } from './types';
