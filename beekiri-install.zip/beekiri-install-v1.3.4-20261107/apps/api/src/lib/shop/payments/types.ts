import type { ShopOrder, ShopOrderItem } from '../../../models';
import type { ShopSettings } from '../settings';

export type PaymentContext = {
  settings: ShopSettings;
  /** Absolute site URL (APP_URL), no trailing slash. */
  appUrl: string;
  siteTitle: string;
  items: ShopOrderItem[];
};

export type PaymentStart =
  /** Send the shopper to the provider's hosted page. */
  | { kind: 'redirect'; url: string; ref: Record<string, unknown> }
  /** Nothing more to do online (cash on delivery, bank transfer). */
  | { kind: 'offline'; ref: Record<string, unknown> };

export interface PaymentProvider {
  readonly id: 'cod' | 'bank_transfer' | 'stripe';
  /** Create whatever the provider needs for this order and say where the shopper goes next. */
  start(order: ShopOrder, ctx: PaymentContext): Promise<PaymentStart>;
  /** Refund `amount` (minor units) of a paid order through the provider. */
  refund?(order: ShopOrder, amount: number, ctx: PaymentContext, reason?: string): Promise<{ refundId: string }>;
}
