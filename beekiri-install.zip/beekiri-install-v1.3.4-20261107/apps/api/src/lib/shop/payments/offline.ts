import type { PaymentProvider } from './types';

/** Cash on delivery: the order is placed as "processing" and paid at the door. */
export const codProvider: PaymentProvider = {
  id: 'cod',
  async start() {
    return { kind: 'offline', ref: {} };
  },
};

/** Bank transfer: the order waits "on hold" until the shop marks it paid. */
export const bankTransferProvider: PaymentProvider = {
  id: 'bank_transfer',
  async start() {
    return { kind: 'offline', ref: {} };
  },
};
