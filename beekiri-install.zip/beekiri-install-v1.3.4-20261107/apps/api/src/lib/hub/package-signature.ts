import { createPublicKey, verify } from 'crypto';

/**
 * Theme packages from the Beekiri Hub are signed with the Hub's Ed25519 key (996ai:
 * `php artisan beekiri:signing-key`). Only a package signed by one of these keys is installed,
 * so whoever answers at the Hub address — or sits in between — cannot ship code to this site.
 * BEEKIRI_HUB_SIGNING_KEY adds a key for a private test Hub; it never replaces these.
 */
const HUB_SIGNING_KEYS = ['8xA4N8JyIijYSQSUeGfVy6o9Gl3zA0HWWEK/ON4OrRs='];

/** Ed25519 public keys travel as 32 raw bytes; Node wants them wrapped as SPKI DER. */
const SPKI_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');

function trustedKeys(): string[] {
  const extra = (process.env.BEEKIRI_HUB_SIGNING_KEY ?? '').split(',').map((k) => k.trim()).filter(Boolean);
  return [...HUB_SIGNING_KEYS, ...extra];
}

/** The signed statement, byte for byte as the Hub builds it (PackageSigner::message). */
export function themeSignatureMessage(slug: string, version: string, sha256: string): string {
  return `beekiri-theme:v1\n${slug}\n${version}\n${sha256.toLowerCase()}`;
}

export function verifyThemeSignature(slug: string, version: string, sha256: string, signatureB64: string): boolean {
  const signature = Buffer.from(signatureB64.trim(), 'base64');
  if (signature.length !== 64) return false;
  const message = Buffer.from(themeSignatureMessage(slug, version, sha256), 'utf8');
  return trustedKeys().some((b64) => {
    const raw = Buffer.from(b64, 'base64');
    if (raw.length !== 32) return false;
    try {
      const key = createPublicKey({ key: Buffer.concat([SPKI_PREFIX, raw]), format: 'der', type: 'spki' });
      return verify(null, message, key, signature);
    } catch {
      return false;
    }
  });
}
