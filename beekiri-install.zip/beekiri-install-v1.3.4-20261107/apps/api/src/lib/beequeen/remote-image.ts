import { lookup as dnsLookup, type LookupAddress } from 'dns';
import { request } from 'https';
import { BlockList, isIP, type LookupFunction } from 'net';

/**
 * Downloads a photo from a link the owner gave Beekiri (e.g. an Unsplash page), safely: HTTPS
 * only, every hop's address must be public (no localhost, private networks, cloud metadata —
 * checked when connecting, so DNS can't be switched in between), images only, size-capped.
 */

const MAX_BYTES = 20 * 1024 * 1024;
const MAX_REDIRECTS = 5;
const TIMEOUT_MS = 20_000;
const IMAGE_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif']);

const blocked = new BlockList();
for (const [net, prefix] of [
  ['0.0.0.0', 8], ['10.0.0.0', 8], ['100.64.0.0', 10], ['127.0.0.0', 8], ['169.254.0.0', 16],
  ['172.16.0.0', 12], ['192.0.0.0', 24], ['192.0.2.0', 24], ['192.168.0.0', 16], ['198.18.0.0', 15],
  ['198.51.100.0', 24], ['203.0.113.0', 24], ['224.0.0.0', 4], ['240.0.0.0', 4],
] as const) blocked.addSubnet(net, prefix, 'ipv4');
for (const [net, prefix] of [
  ['::', 128], ['::1', 128], ['64:ff9b::', 96], ['100::', 64], ['2001:db8::', 32],
  ['fc00::', 7], ['fe80::', 10], ['ff00::', 8],
] as const) blocked.addSubnet(net, prefix, 'ipv6');

export function isPublicAddress(address: string): boolean {
  const family = isIP(address);
  if (!family) return false;
  return !blocked.check(address, family === 6 ? 'ipv6' : 'ipv4');
}

/** DNS lookup that refuses non-public addresses (used for the actual connection). */
const publicLookup: LookupFunction = (hostname, options, callback) => {
  dnsLookup(hostname, { ...options, all: true }, (error, addresses) => {
    if (error) return callback(error, '', 0);
    const list = addresses as unknown as LookupAddress[];
    const bad = list.find((a) => !isPublicAddress(a.address));
    if (!list.length || bad) {
      return callback(Object.assign(new Error(`${hostname} is not a public address.`), { code: 'EPRIVATE' }), '', 0);
    }
    if ((options as { all?: boolean }).all) return (callback as unknown as (e: null, a: LookupAddress[]) => void)(null, list);
    return callback(null, list[0].address, list[0].family);
  });
};

/** An Unsplash photo page → its download address (the photo itself, full size). */
function directUrl(raw: URL): URL {
  if (/(^|\.)unsplash\.com$/i.test(raw.hostname) && !/^images\./i.test(raw.hostname)) {
    const m = raw.pathname.match(/^\/(?:[a-z]{2}(?:-[A-Z]{2})?\/)?photos\/(?:[^/]*-)?([A-Za-z0-9_-]{11})(?:\/|$)/);
    if (m) return new URL(`https://unsplash.com/photos/${m[1]}/download?force=true`);
  }
  return raw;
}

type Fetched = { buffer: Buffer; mimeType: string; finalUrl: string };

function get(url: URL): Promise<{ status: number; location?: string; mimeType: string; body?: Buffer }> {
  return new Promise((resolve, reject) => {
    const req = request(
      url,
      {
        method: 'GET',
        lookup: publicLookup,
        timeout: TIMEOUT_MS,
        headers: { 'user-agent': 'Beekiri/1.0 (+media import)', accept: 'image/avif,image/webp,image/jpeg,image/png,image/*;q=0.8' },
      },
      (res) => {
        const status = res.statusCode ?? 0;
        const mimeType = String(res.headers['content-type'] ?? '').split(';')[0].trim().toLowerCase();
        if (status >= 300 && status < 400) {
          res.resume();
          return resolve({ status, location: res.headers.location, mimeType });
        }
        if (status !== 200) {
          res.resume();
          return resolve({ status, mimeType });
        }
        if (!IMAGE_TYPES.has(mimeType)) {
          res.destroy();
          return reject(new Error(`That link is not a photo (${mimeType || 'unknown type'}). Use a JPEG, PNG, WebP, GIF or AVIF image.`));
        }
        const declared = Number(res.headers['content-length'] ?? 0);
        if (declared > MAX_BYTES) {
          res.destroy();
          return reject(new Error('That photo is larger than 20 MB.'));
        }
        const chunks: Buffer[] = [];
        let size = 0;
        res.on('data', (chunk: Buffer) => {
          size += chunk.length;
          if (size > MAX_BYTES) {
            res.destroy();
            reject(new Error('That photo is larger than 20 MB.'));
          } else chunks.push(chunk);
        });
        res.on('end', () => resolve({ status, mimeType, body: Buffer.concat(chunks) }));
        res.on('error', reject);
      },
    );
    req.on('timeout', () => req.destroy(new Error('The photo took too long to download.')));
    req.on('error', (e: NodeJS.ErrnoException) =>
      reject(e.code === 'EPRIVATE' ? new Error('That link points to a private or local address; only public https links can be imported.') : e),
    );
    req.end();
  });
}

export async function fetchRemoteImage(raw: string): Promise<Fetched> {
  let url: URL;
  try {
    url = directUrl(new URL(raw.trim()));
  } catch {
    throw new Error('That is not a valid link.');
  }
  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    if (url.protocol !== 'https:') throw new Error('Only https links can be imported.');
    if (url.username || url.password) throw new Error('Links with a user name or password are not allowed.');
    if (isIP(url.hostname.replace(/^\[|\]$/g, '')) && !isPublicAddress(url.hostname.replace(/^\[|\]$/g, ''))) {
      throw new Error('That link points to a private or local address; only public https links can be imported.');
    }
    const res = await get(url);
    if (res.location) {
      url = new URL(res.location, url);
      continue;
    }
    if (!res.body) throw new Error(`The photo could not be downloaded (HTTP ${res.status}).`);
    return { buffer: res.body, mimeType: res.mimeType, finalUrl: url.href };
  }
  throw new Error('That link redirects too many times.');
}
