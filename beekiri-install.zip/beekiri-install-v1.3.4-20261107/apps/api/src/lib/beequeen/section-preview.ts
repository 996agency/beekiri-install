import type { AuthUser } from '../../types/auth';
import { Post } from '../../models';
import type { SectionPlacement } from '../pages/pages.content';
import { pagesService } from '../../services/pages.service';
import { pageThemeScope } from '../../services/themes.service';

/**
 * A private preview of a page a site section shows on (the first page it is limited to, else the home
 * page): previews merge site sections in, including what still waits for Keep.
 */
export async function sectionPreview(actor: AuthUser, placement: SectionPlacement): Promise<{ url: string; title: string; livePath: string } | null> {
  try {
    let pageId = placement.pages !== 'all' ? placement.pages[0] : null;
    if (!pageId) {
      const scope = await pageThemeScope('page');
      const front = await pagesService.getPublishedFrontPage().catch(() => null);
      const row =
        (front && (await Post.findOne({ where: { siteId: actor.siteId, type: 'page', slug: front.slug, ...scope }, attributes: ['id'] }))) ||
        // No home page: any published page shows it.
        (await Post.findOne({ where: { siteId: actor.siteId, type: 'page', status: 'publish', ...scope }, attributes: ['id'], order: [['menuOrder', 'ASC'], ['createdAt', 'ASC']] }));
      pageId = row?.id ?? null;
    }
    if (!pageId) return null;
    const preview = await pagesService.createPreview(actor, pageId, {}, 'page');
    const page = preview.page as { title: string; path: string };
    return { url: preview.previewPath, title: page.title, livePath: page.path };
  } catch {
    return null;
  }
}
