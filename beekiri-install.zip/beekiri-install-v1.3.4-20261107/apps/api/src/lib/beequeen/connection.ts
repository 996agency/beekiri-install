import { hubCredentials } from '../hub/hub-client';
import type { BeeQueenServiceConn } from './service-client';

/**
 * How this site reaches 996Agency's Connector: with its Beekiri Hub install token, on the Hub's
 * address. 996Agency's Claude key stays on 996Agency's server; the token only spends this
 * site's own credits and is never sent to the browser. Null when the site isn't registered.
 */
export async function agencyConnection(): Promise<BeeQueenServiceConn | null> {
  const hub = await hubCredentials();
  return hub ? { url: hub.url, key: hub.token } : null;
}
