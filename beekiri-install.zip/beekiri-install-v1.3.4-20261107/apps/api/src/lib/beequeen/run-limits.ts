/**
 * Cost control: how many Beekiri runs may work at once. One per person (a second chat or tab
 * waits for the first to finish) and three per site. Counted in this server process.
 */

export const MAX_RUNS_PER_USER = 1;
export const MAX_RUNS_PER_SITE = 3;

const byUser = new Map<string, number>();
const bySite = new Map<string, number>();

export type RunSlot = { ok: true; release: () => void } | { ok: false; message: string };

const bump = (map: Map<string, number>, key: string, by: number) => {
  const next = (map.get(key) ?? 0) + by;
  if (next > 0) map.set(key, next);
  else map.delete(key);
};

/** Takes a slot for this person's run, or says why it can't start. Call release() exactly once. */
export function startRun(actor: { id: string; siteId: string }): RunSlot {
  if ((byUser.get(actor.id) ?? 0) >= MAX_RUNS_PER_USER) {
    return {
      ok: false,
      message: 'Beekiri is already working on another request of yours (maybe in another tab). Wait for it to finish or stop it, then try again.',
    };
  }
  if ((bySite.get(actor.siteId) ?? 0) >= MAX_RUNS_PER_SITE) {
    return {
      ok: false,
      message: `Beekiri is already working on ${MAX_RUNS_PER_SITE} requests on this site, the most at once. Try again when one has finished.`,
    };
  }
  bump(byUser, actor.id, 1);
  bump(bySite, actor.siteId, 1);
  let released = false;
  return {
    ok: true,
    release: () => {
      if (released) return;
      released = true;
      bump(byUser, actor.id, -1);
      bump(bySite, actor.siteId, -1);
    },
  };
}

/** Runs working right now (for tests and diagnostics). */
export function activeRuns(): { users: number; sites: number } {
  return { users: [...byUser.values()].reduce((a, b) => a + b, 0), sites: bySite.size };
}
