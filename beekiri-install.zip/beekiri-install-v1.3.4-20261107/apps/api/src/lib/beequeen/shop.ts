import { Op } from 'sequelize';
import { Post, Taxonomy, Term } from '../../models';
import { extensionsService } from '../../services/extensions.service';
import { mediaService } from '../../services/media.service';
import { productsService } from '../../services/shop/products.service';
import { shopSettingsService } from '../../services/shop/shop-settings.service';
import type { UpdateProductInput } from '../../validators/shop.schema';
import { createTerm } from '../pages/page-taxonomies';
import { minorToDecimal, parseMoney } from '../shop/money';
import { PRODUCT_CATEGORY_TAXONOMY, PRODUCT_KIND, SHOP_EXTENSION_SLUG } from '../shop/constants';
import { recordChange, snapshots } from './changes';
import { fetchRemoteImage } from './remote-image';
import { untrusted } from './untrusted';
import { addLink, type Workspace } from './workspace';

/**
 * Beekiri's shop and media tools: import a photo from a public link into the media library, and
 * create or edit shop products (simple or variable, with variations). Prices are in the shop's
 * currency as the owner writes them ("200", "19.99"); stored in minor units like the admin does.
 */

// ─── Media ────────────────────────────────────────────────────────────────────

export type ImportImageInput = { url: string; alt: string; name?: string };

export async function importImage(ws: Workspace, input: ImportImageInput): Promise<string> {
  const photo = await fetchRemoteImage(input.url);
  const base =
    (input.name || new URL(input.url).pathname.split('/').filter(Boolean).pop() || 'photo')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 60) || 'photo';
  const ext = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/gif': '.gif', 'image/avif': '.avif' }[photo.mimeType] ?? '';
  const { item } = await mediaService.upload({
    buffer: photo.buffer,
    filename: `${base}${ext}`,
    mimeType: photo.mimeType,
    alt: input.alt.trim().slice(0, 500),
    uploadedById: ws.actor.id,
  });
  await recordChange(ws.change, {
    kind: 'media',
    label: `Photo “${item.originalName}”`,
    target: { mediaId: item.id },
    before: null,
    after: { id: item.id, url: item.url },
  });
  addLink(ws, { kind: 'media', label: item.originalName, admin: 'media' });
  return `Imported the photo into the media library: id ${item.id}, ${item.width ?? '?'}×${item.height ?? '?'}, ${item.url}. Use this id for image fields (featuredImageId, galleryIds, variation imageId, layout image fields).`;
}

// ─── Products ─────────────────────────────────────────────────────────────────

async function requireShop() {
  if (!(await extensionsService.isActive(SHOP_EXTENSION_SLUG))) {
    throw new Error('The Shopping extension is off. Ask the owner to turn it on under Extensions first.');
  }
  return (await shopSettingsService.get()).general.currency;
}

export async function listProducts(ws: Workspace, search?: string): Promise<string> {
  const currency = await requireShop();
  const rows = await Post.findAll({
    where: {
      siteId: ws.actor.siteId,
      type: PRODUCT_KIND,
      status: { [Op.in]: ['draft', 'publish'] },
      ...(search ? { title: { [Op.iLike]: `%${search}%` } } : {}),
    },
    attributes: ['id', 'title', 'status'],
    order: [['updatedAt', 'DESC']],
    limit: 60,
  });
  if (!rows.length) return search ? `No products match "${search}".` : 'No products yet.';
  const lines = await Promise.all(
    rows.map(async (r) => {
      const p = await productsService.get(ws.actor, r.id);
      const price = p.commerce.type === 'variable'
        ? `${p.variants.length} variations`
        : minorToDecimal(p.commerce.salePrice ?? p.commerce.regularPrice, currency) || 'no price';
      return `• ${p.id} — "${p.title}" (${p.commerce.type}, ${price} ${currency}, ${p.status})`;
    }),
  );
  return untrusted('product names', lines.join('\n'));
}

/** A product in the shape save_product takes (prices as decimals, categories by name). */
export async function getProduct(ws: Workspace, id: string): Promise<string> {
  const currency = await requireShop();
  const p = await productsService.get(ws.actor, id);
  const money = (v: number | null) => (v == null ? undefined : minorToDecimal(v, currency));
  const names = new Map(p.categories.map((c) => [c.id, c.name]));
  return untrusted('product content', JSON.stringify(
    {
      id: p.id,
      title: p.title,
      slug: p.slug,
      status: p.status,
      path: p.path,
      currency,
      type: p.commerce.type,
      shortDescription: p.shortDescription,
      description: p.description,
      featuredImageId: p.featuredImageId,
      galleryIds: p.commerce.galleryIds,
      categories: p.categoryIds.map((cid) => names.get(cid)).filter(Boolean),
      sku: p.commerce.sku,
      price: money(p.commerce.regularPrice),
      salePrice: money(p.commerce.salePrice),
      manageStock: p.commerce.manageStock,
      stockQty: p.commerce.stockQty,
      stockStatus: p.commerce.stockStatus,
      attributes: p.commerce.attributes,
      variations: p.variants.map((v) => ({
        id: v.id,
        attributes: v.attributes,
        price: money(v.regularPrice),
        salePrice: money(v.salePrice),
        sku: v.sku,
        manageStock: v.manageStock,
        stockQty: v.stockQty,
        stockStatus: v.stockStatus,
        imageId: v.imageId,
        enabled: v.enabled,
      })),
    },
    null,
    1,
  ));
}

type Money = string | number;
export type SaveProductInput = {
  id?: string;
  title: string;
  status?: 'draft' | 'publish';
  type?: 'simple' | 'variable';
  shortDescription?: string;
  description?: string;
  featuredImageId?: string;
  galleryIds?: string[];
  categories?: string[];
  sku?: string;
  price?: Money;
  salePrice?: Money;
  manageStock?: boolean;
  stockQty?: number;
  attributes?: { name: string; options: string[]; variation?: boolean; visible?: boolean }[];
  variations?: {
    id?: string;
    attributes: Record<string, string>;
    price?: Money;
    salePrice?: Money;
    sku?: string;
    manageStock?: boolean;
    stockQty?: number;
    imageId?: string;
    enabled?: boolean;
  }[];
};

/** Shop categories by name → term ids, creating the ones that don't exist yet. */
async function categoryIds(siteId: string, names: string[]): Promise<string[]> {
  const taxonomy = await Taxonomy.findOne({ where: { siteId, slug: PRODUCT_CATEGORY_TAXONOMY } });
  if (!taxonomy) return [];
  const existing = await Term.findAll({ where: { siteId, taxonomyId: taxonomy.id } });
  const ids: string[] = [];
  for (const raw of names.map((n) => n.trim()).filter(Boolean).slice(0, 10)) {
    const found = existing.find((t) => t.name.toLowerCase() === raw.toLowerCase());
    if (found) {
      ids.push(found.id);
      continue;
    }
    const created = (await createTerm(siteId, taxonomy.id, { name: raw })) as { id?: string; term?: { id: string } };
    const id = created.term?.id ?? created.id;
    if (id) ids.push(id);
  }
  return ids;
}

export async function saveProduct(ws: Workspace, input: SaveProductInput): Promise<string> {
  const currency = await requireShop();
  const money = (v: Money | undefined, what: string) => {
    if (v === undefined || v === '') return undefined;
    const minor = parseMoney(String(v), currency);
    if (minor === null || minor < 0) throw new Error(`${what} "${v}" is not a price — write it like 200 or 19.99.`);
    return minor;
  };
  const type = input.type ?? (input.variations?.length ? 'variable' : undefined);
  const before = input.id ? await snapshots.product(ws.actor, input.id) : null;
  if (input.id && !before) throw new Error('No product with that id — call list_products.');

  const variable = (type ?? before?.commerce.type) === 'variable';
  // The shop checks variations against the attributes sent with them: keep the product's own.
  const keptAttributes =
    !input.attributes && input.variations && before?.commerce.attributes?.length
      ? { attributes: before.commerce.attributes }
      : {};
  const body: UpdateProductInput = {
    title: input.title.trim(),
    ...(input.status ? { status: input.status } : {}),
    ...(input.shortDescription !== undefined ? { shortDescription: input.shortDescription } : {}),
    ...(input.description !== undefined ? { description: input.description } : {}),
    ...(input.featuredImageId !== undefined ? { featuredImageId: input.featuredImageId } : {}),
    ...(input.categories ? { categoryIds: await categoryIds(ws.actor.siteId, input.categories) } : {}),
    commerce: {
      ...(type ? { type } : {}),
      ...(input.sku !== undefined ? { sku: input.sku } : {}),
      ...(input.price !== undefined ? { regularPrice: money(input.price, 'Price') ?? null } : {}),
      ...(input.salePrice !== undefined ? { salePrice: money(input.salePrice, 'Sale price') ?? null } : {}),
      ...(input.manageStock !== undefined ? { manageStock: input.manageStock } : {}),
      ...(input.stockQty !== undefined ? { stockQty: input.stockQty } : {}),
      ...(input.galleryIds ? { galleryIds: input.galleryIds } : {}),
      ...keptAttributes,
      ...(input.attributes
        ? {
            attributes: input.attributes.map((a) => ({
              name: a.name.trim(),
              options: a.options.map((o) => o.trim()).filter(Boolean),
              visible: a.visible ?? true,
              variation: a.variation ?? variable,
            })),
          }
        : {}),
    },
    ...(input.variations
      ? {
          variants: input.variations.map((v, i) => ({
            ...(v.id ? { id: v.id } : {}),
            attributes: v.attributes,
            regularPrice: money(v.price, `Variation ${i + 1} price`) ?? null,
            salePrice: money(v.salePrice, `Variation ${i + 1} sale price`) ?? null,
            sku: v.sku ?? '',
            manageStock: v.manageStock ?? v.stockQty !== undefined,
            stockQty: v.stockQty ?? null,
            stockStatus: 'instock' as const,
            imageId: v.imageId ?? null,
            enabled: v.enabled ?? true,
            menuOrder: i,
          })),
        }
      : {}),
  } as UpdateProductInput;

  const id = input.id ?? (await productsService.create(ws.actor, { title: body.title, status: 'draft' })).id;
  let saved;
  try {
    saved = await productsService.update(ws.actor, id, body);
  } catch (error) {
    // A new product that couldn't be completed goes away again, so no half-made product is left.
    if (!input.id) await productsService.remove(ws.actor, id, { force: true }).catch(() => undefined);
    throw error;
  }
  await recordChange(ws.change, {
    kind: 'product',
    label: `Product “${saved.title}”`,
    target: { productId: id },
    before,
    after: await snapshots.product(ws.actor, id),
  });
  addLink(ws, { kind: 'product', label: saved.title, admin: `shop/products/${id}`, url: saved.status === 'publish' ? saved.path : undefined });
  const variations = saved.variants.length ? `, ${saved.variants.length} variations` : '';
  return `${input.id ? 'Updated' : 'Created'} product "${saved.title}" (id ${id}, ${saved.commerce.type}${variations}, ${saved.status}) at ${saved.path}.`;
}
