import { spawn } from 'child_process';
import { existsSync, mkdtempSync, rmSync } from 'fs';
import { homedir, tmpdir } from 'os';
import { delimiter, join } from 'path';

/**
 * Local test engine: BeeQueen runs through the Claude Code CLI signed in on this
 * machine (the owner's Claude subscription) instead of an API key. Claude Code's own
 * tools are switched off; it only gets BeeQueen's tools over MCP.
 */

let cachedCli: string | null | undefined;

/** The `claude` binary on this machine, or null. */
/**
 * Owner testing: BEEKIRI_AGENT_ENGINE=claude-code (apps/api/.env on this Mac only) runs the
 * agent on Claude Code signed in here — the owner's own Claude account — instead of 996Agency.
 * Nothing is charged to the site's credits. Remove the line to go back to 996Agency.
 */
export function forcedClaudeCode(): boolean {
  return process.env.BEEKIRI_AGENT_ENGINE?.trim().toLowerCase() === 'claude-code' && Boolean(findClaudeCli());
}

export function findClaudeCli(): string | null {
  if (cachedCli !== undefined) return cachedCli;
  const fromEnv = process.env.BEEKIRI_CLAUDE_BIN?.trim();
  const candidates = [
    ...(fromEnv ? [fromEnv] : []),
    ...(process.env.PATH ?? '').split(delimiter).filter(Boolean).map((dir) => join(dir, 'claude')),
    join(homedir(), '.local', 'bin', 'claude'),
    join(homedir(), '.claude', 'local', 'claude'),
    '/opt/homebrew/bin/claude',
    '/usr/local/bin/claude',
  ];
  cachedCli = candidates.find((p) => existsSync(p)) ?? null;
  return cachedCli;
}

export type ClaudeCodeEvent = { type: 'note'; text: string };

export type ClaudeCodeRun = {
  prompt: string;
  systemPrompt: string;
  model: string;
  effort: string;
  mcpUrl: string;
  mcpToken: string;
  signal: AbortSignal;
  onEvent: (event: ClaudeCodeEvent) => void;
};

export type ClaudeCodeResult = {
  ok: boolean;
  text: string;
  model?: string;
  usage?: { inputTokens: number; outputTokens: number; cacheReadTokens: number; cacheWriteTokens: number; costUsd?: number };
};

type StreamLine = {
  type?: string;
  subtype?: string;
  model?: string;
  is_error?: boolean;
  result?: string;
  total_cost_usd?: number;
  usage?: {
    input_tokens?: number;
    output_tokens?: number;
    cache_read_input_tokens?: number;
    cache_creation_input_tokens?: number;
  };
  mcp_servers?: { name: string; status: string }[];
  message?: { model?: string; content?: { type: string; text?: string; thinking?: string }[] };
};

/** Short, single-line progress note from a model block. */
function noteOf(text: string): string {
  const t = text.trim();
  return t.length > 400 ? `${t.slice(0, 400)}…` : t;
}

export function runClaudeCode(opts: ClaudeCodeRun): Promise<ClaudeCodeResult> {
  const cli = findClaudeCli();
  if (!cli) return Promise.resolve({ ok: false, text: 'Claude Code is not installed on this machine.' });

  const mcpConfig = {
    mcpServers: {
      beequeen: { type: 'http', url: opts.mcpUrl, headers: { Authorization: `Bearer ${opts.mcpToken}` } },
    },
  };
  const args = [
    '-p',
    '--output-format', 'stream-json',
    '--verbose',
    '--model', opts.model,
    '--effort', opts.effort,
    '--system-prompt', opts.systemPrompt,
    // No built-in file/shell tools: BeeQueen's MCP tools are the only way to change the site.
    '--tools', '',
    '--strict-mcp-config',
    '--mcp-config', JSON.stringify(mcpConfig),
    '--allowedTools', 'mcp__beequeen',
    '--permission-mode', 'dontAsk',
    '--no-session-persistence',
  ];

  // The Claude subscription login, not an API key or a test base URL, must win.
  const env = { ...process.env };
  for (const key of ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL', 'CLAUDECODE', 'CLAUDE_CODE_ENTRYPOINT']) {
    delete env[key];
  }
  // An empty working folder, so no project instructions ride along.
  const cwd = mkdtempSync(join(tmpdir(), 'beequeen-cc-'));

  return new Promise((resolve) => {
    const child = spawn(cli, args, { cwd, env, stdio: ['pipe', 'pipe', 'pipe'] });
    let buffer = '';
    let stderr = '';
    let result: ClaudeCodeResult | null = null;
    let model: string | undefined;
    let pendingText = '';

    const finish = (value: ClaudeCodeResult) => {
      opts.signal.removeEventListener('abort', onAbort);
      rmSync(cwd, { recursive: true, force: true });
      resolve(value);
    };
    const onAbort = () => child.kill('SIGTERM');
    opts.signal.addEventListener('abort', onAbort);

    const handle = (line: StreamLine) => {
      if (line.type === 'system' && line.subtype === 'init') {
        model = line.model ?? model;
        const server = line.mcp_servers?.find((s) => s.name === 'beequeen');
        if (server && server.status !== 'connected') {
          result = { ok: false, text: `Claude Code could not reach Beekiri's tools (${server.status}).` };
          child.kill('SIGTERM');
        }
        return;
      }
      if (line.type === 'assistant') {
        model = line.message?.model ?? model;
        for (const block of line.message?.content ?? []) {
          if (block.type === 'text' && block.text?.trim()) pendingText = block.text;
          if (block.type === 'thinking' && block.thinking?.trim()) opts.onEvent({ type: 'note', text: noteOf(block.thinking) });
          if (block.type === 'tool_use' && pendingText) {
            // Text written right before a tool call is narration, not the final answer.
            opts.onEvent({ type: 'note', text: noteOf(pendingText) });
            pendingText = '';
          }
        }
        return;
      }
      if (line.type === 'result') {
        const text = (line.result ?? '').trim() || pendingText.trim();
        result = {
          ok: !line.is_error && line.subtype === 'success',
          text: text || 'Claude Code stopped without a reply.',
          model,
          usage: {
            inputTokens: line.usage?.input_tokens ?? 0,
            outputTokens: line.usage?.output_tokens ?? 0,
            cacheReadTokens: line.usage?.cache_read_input_tokens ?? 0,
            cacheWriteTokens: line.usage?.cache_creation_input_tokens ?? 0,
            ...(typeof line.total_cost_usd === 'number' ? { costUsd: line.total_cost_usd } : {}),
          },
        };
      }
    };

    child.stdout.setEncoding('utf8');
    child.stdout.on('data', (chunk: string) => {
      buffer += chunk;
      let nl = buffer.indexOf('\n');
      while (nl >= 0) {
        const raw = buffer.slice(0, nl).trim();
        buffer = buffer.slice(nl + 1);
        if (raw) {
          try {
            handle(JSON.parse(raw) as StreamLine);
          } catch {
            /* not a JSON line */
          }
        }
        nl = buffer.indexOf('\n');
      }
    });
    child.stderr.setEncoding('utf8');
    child.stderr.on('data', (chunk: string) => {
      stderr = (stderr + chunk).slice(-4000);
    });
    child.on('error', (error) => finish({ ok: false, text: `Could not start Claude Code: ${error.message}` }));
    child.on('close', (code) => {
      if (opts.signal.aborted) return finish({ ok: false, text: 'Stopped.' });
      if (result) return finish(result);
      const why = stderr.trim().split('\n').slice(-3).join(' ').trim();
      finish({ ok: false, text: `Claude Code exited (${code ?? 'killed'})${why ? `: ${why}` : '.'}` });
    });

    child.stdin.end(opts.prompt);
  });
}
