import { randomUUID } from 'crypto';

/**
 * Section previews: Beekiri asks the open editor for a picture of the element it just changed
 * (the canvas renders it exactly as the site will), so it can see and fix its own design. The
 * editor posts the image back to /api/connector/agent/preview; only the same user can answer.
 */

export type PreviewImage = { data: string; mediaType: 'image/jpeg' | 'image/png'; width?: number; height?: number };

const MAX_BASE64 = 1_800_000;
const pending = new Map<string, { userId: string; resolve: (v: PreviewImage) => void; reject: (e: Error) => void }>();

export function requestPreview(userId: string, ask: (id: string) => void, timeoutMs = 25_000): Promise<PreviewImage> {
  const id = randomUUID();
  return new Promise<PreviewImage>((resolve, reject) => {
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(new Error('The editor did not send a preview in time (is the page still open?).'));
    }, timeoutMs);
    pending.set(id, {
      userId,
      resolve: (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      reject: (e) => {
        clearTimeout(timer);
        reject(e);
      },
    });
    ask(id);
  });
}

/** The editor's answer: a data URL, or why it couldn't take the picture. False when nothing was waiting. */
export function answerPreview(userId: string, id: string, answer: { image?: string; error?: string; width?: number; height?: number }): boolean {
  const waiting = pending.get(id);
  if (!waiting || waiting.userId !== userId) return false;
  pending.delete(id);
  if (answer.error || !answer.image) {
    waiting.reject(new Error(answer.error || 'The editor sent no picture.'));
    return true;
  }
  const m = answer.image.match(/^data:(image\/(?:jpeg|png));base64,([A-Za-z0-9+/=]+)$/);
  if (!m || m[2].length > MAX_BASE64) {
    waiting.reject(new Error('The preview picture could not be read.'));
    return true;
  }
  waiting.resolve({ data: m[2], mediaType: m[1] as PreviewImage['mediaType'], width: answer.width, height: answer.height });
  return true;
}
