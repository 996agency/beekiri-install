/**
 * Last line of defence for the Beekiri agent: anything that looks like a secret is replaced
 * before the model sees it (tool results) and before anyone sees it (chat text, saved history).
 * The prompt already forbids revealing secrets; this makes sure a mistake can't leak one.
 */

const PATTERNS: RegExp[] = [
  /sk-ant-[A-Za-z0-9_-]{8,}/g, // Anthropic / Claude keys
  /\bbk_inst_[A-Za-z0-9_-]{8,}/g, // Beekiri Hub install tokens (base64url: may hold "-" and "_")
  /\bbq_live_[A-Za-z0-9_-]{8,}/g, // older Connector site keys
  /\b(?:sk|rk|pk)_(?:live|test)_[A-Za-z0-9]{8,}/g, // Stripe keys
  /\bwhsec_[A-Za-z0-9]{8,}/g, // Stripe webhook secrets
  /\bgh[pousr]_[A-Za-z0-9]{20,}/g, // GitHub tokens
  /\bAKIA[0-9A-Z]{16}\b/g, // AWS access keys
  /\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}/g, // bcrypt hashes
  /\$argon2(?:id|i|d)\$[^\s"']{20,}/g, // argon2 hashes
  /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/g,
  /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g, // JWTs
  /\bA21AA[A-Za-z0-9_-]{20,}/g, // PayPal access tokens
  // PayPal REST client secrets: 80 characters starting with "E", standing alone (never a piece of a base64 blob).
  /(?<![A-Za-z0-9+/=_-])E[A-Za-z0-9_-]{79}(?![A-Za-z0-9+/=_-])/g,
];

/** Credentials inside connection strings: postgres://user:pass@host → postgres://[hidden]@host. */
const CONNECTION_STRING = /\b((?:postgres(?:ql)?|mysql|mariadb|mongodb(?:\+srv)?|rediss?|amqps?):\/\/)[^\s:@/"'<>]*:[^\s@/"'<>]+@/gi;

/** A value written next to a secret-looking name: "client_secret": "…", SMTP_PASS=…, password: … */
const NAMED_SECRET =
  /((?:client[_-]?secret|paypal[_-]?secret|secret[_-]?key|api[_-]?key|access[_-]?token|smtp[_-]?pass(?:word)?|db[_-]?pass(?:word)?|password)["']?\s*[:=]\s*["']?)([^\s"',;}{]{6,})/gi;

/** Settings whose value is secret: DB_PASSWORD, SMTP_PASS, any *_PASS / *_PASSWORD / *_SECRET / *_TOKEN / *_KEY… */
const SECRET_ENV_NAME = /(?:^|_)(?:PASS|PASSWD|PASSWORD|SECRET|TOKEN|KEY)$|SECRET|PASSWORD|TOKEN|API_KEY|PRIVATE/i;
/** Values that are settings words, not secrets (redacting "production" everywhere would garble text). */
const NOT_A_SECRET = /^(?:true|false|yes|no|on|off|null|none|production|development|staging|test)$/i;
const MIN_SECRET_LENGTH = 6;

/** Exact values of this server's secret settings (never shown, whatever their shape). */
let envSecrets: string[] | null = null;
function secretValues(): string[] {
  if (envSecrets) return envSecrets;
  envSecrets = Object.entries(process.env)
    .filter(([name, value]) => SECRET_ENV_NAME.test(name) && typeof value === 'string')
    .map(([, value]) => (value as string).trim())
    .filter((value) => value.length >= MIN_SECRET_LENGTH && !NOT_A_SECRET.test(value))
    // Longest first, so a secret that contains another is hidden whole.
    .sort((a, b) => b.length - a.length);
  return envSecrets;
}

/** Tests (and a settings reload) read the environment again. */
export function resetSecretValues() {
  envSecrets = null;
}

export const REDACTED = '[hidden]';

export function redactSecrets(text: string): string {
  if (!text) return text;
  let out = text;
  for (const value of secretValues()) {
    if (out.includes(value)) out = out.split(value).join(REDACTED);
  }
  out = out.replace(CONNECTION_STRING, `$1${REDACTED}@`);
  for (const re of PATTERNS) out = out.replace(re, REDACTED);
  out = out.replace(NAMED_SECRET, (match, label: string, value: string) => (value === REDACTED ? match : `${label}${REDACTED}`));
  return out;
}
