import { config } from '../../config/env';
import { getSelfUrl } from '../../config/runtime';
import { User } from '../../models';
import { BadGateway, HttpError } from '../../utils/http-error';

/**
 * Talks to 996Agency's Connector service for this site: its prepaid dollar balance (what is left,
 * top-ups, what was spent, every message's cost) and what a run cost. The install token never
 * leaves the server.
 */

export type BeeQueenServiceConn = { url: string; key: string };

export type Money = { amount: number; label: string };

/** The site's prepaid account on 996Agency: it tops up a balance first, then each message takes its price. */
export type BeeQueenAccount = {
  site: { name: string };
  billing: 'balance';
  currency: string;
  /** How top-ups are paid: card checkout, or an order 996Agency approves. */
  paymentMethod: 'stripe' | 'paypal' | 'manual';
  balance: Money;
  /** This calendar month so far. */
  month: { month: string; cost: Money; runs: number };
  /** Spent on messages, all time. */
  spent: Money;
  /** Topped up, all time. */
  paid: Money;
  topups: { id: string; amount: Money }[];
  /** An amount of the site's own (whole dollars) within this range. */
  customTopup: { min: number; max: number };
  orders: { id: string; amount: Money; status: string; createdAt: string | null; decidedAt: string | null }[];
  history: { id: string; kind: string; description: string | null; model: string | null; runId: string | null; source: string | null; amount: number; balanceAfter: number; createdAt: string }[];
};

export type HistoryPeriod = 'today' | 'week' | 'month' | 'all';

/** Spending, one row per message, for a period and a page. */
export type BeeQueenHistory = {
  period: HistoryPeriod;
  page: number;
  pages: number;
  perPage: number;
  total: number;
  spent: Money;
  messages: { id: string; createdAt: string; cost: Money; calls: number; model: string | null; test: boolean }[];
};

/** What a run has cost so far, and what is left. */
export type RunCost = { cost: Money; balance: Money; monthCost: Money };

export type RunUsageReport = {
  runId: string;
  model: string;
  usage: { input_tokens: number; output_tokens: number; cache_read_input_tokens: number; cache_creation_input_tokens: number };
};

let identity: { at: number; headers: Record<string, string> } | null = null;

/**
 * Who this site is, so 996Agency can see the owner and the address next to the key:
 * the site owner's email and the site's public URL.
 */
async function siteIdentity(): Promise<Record<string, string>> {
  if (identity && Date.now() - identity.at < 5 * 60_000) return identity.headers;
  const owner = await User.findOne({ where: { isOwner: true }, attributes: ['email'], order: [['createdAt', 'ASC']] });
  const url = config.urls.app ?? getSelfUrl() ?? '';
  const headers: Record<string, string> = {};
  if (owner?.email) headers['x-beequeen-owner-email'] = owner.email;
  if (url) headers['x-beequeen-site-url'] = url;
  identity = { at: Date.now(), headers };
  return headers;
}

async function call<T>(conn: BeeQueenServiceConn, path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${conn.url}/api/beequeen/v1${path}`, {
      method: init.method ?? 'GET',
      headers: {
        ...(await siteIdentity().catch(() => ({}))),
        Authorization: `Bearer ${conn.key}`,
        Accept: 'application/json',
        ...(init.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      },
      body: init.body !== undefined ? JSON.stringify(init.body) : undefined,
      signal: AbortSignal.timeout(15_000),
    });
  } catch {
    throw BadGateway(`Could not reach 996Agency at ${conn.url}.`);
  }
  const data = (await res.json().catch(() => ({}))) as T & { error?: { message?: string } };
  if (!res.ok) {
    // The service answers in Claude's error shape; keep its status (401 bad key, 403 blocked…).
    const message = data.error?.message || (data as { message?: string }).message || `996Agency service error ${res.status}.`;
    throw new HttpError([401, 402, 403, 422].includes(res.status) ? res.status : 502, message);
  }
  return data;
}

export const beeQueenServiceClient = {
  account: (conn: BeeQueenServiceConn) => call<BeeQueenAccount>(conn, '/account'),
  history: (conn: BeeQueenServiceConn, period: HistoryPeriod, page: number) =>
    call<BeeQueenHistory>(conn, `/history?period=${period}&page=${page}`),
  /** Top up: a preset or an amount of the site's own. A checkout link, or an order 996Agency approves. */
  topup: (conn: BeeQueenServiceConn, choice: { pack: string } | { amount: number }, returnUrl: string | null) =>
    call<{ status: 'checkout' | 'pending'; checkoutUrl: string | null; account: BeeQueenAccount }>(conn, '/topups', {
      method: 'POST',
      body: { ...choice, returnUrl },
    }),
  /** What a run has cost so far, and the balance left. */
  runCost: (conn: BeeQueenServiceConn, runId: string) => call<RunCost>(conn, `/runs/${encodeURIComponent(runId)}`),
  /** A run made on Claude Code (owner testing): 996Agency prices it and takes it from the balance like any other. */
  reportUsage: (conn: BeeQueenServiceConn, report: RunUsageReport) => call<RunCost>(conn, '/usage', { method: 'POST', body: report }),
};
