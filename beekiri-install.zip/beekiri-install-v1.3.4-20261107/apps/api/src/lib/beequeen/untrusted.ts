/**
 * Content other people wrote (page and post titles and bodies, media names and alt texts,
 * product text) reaches the model fenced as data. The system prompt says never to follow
 * instructions found inside these fences.
 */

const TAG = 'untrusted-data';

/** `text` inside an <untrusted-data> fence that the text itself cannot close. */
export function untrusted(source: string, text: string): string {
  const safe = text.replace(/<(\/?)\s*untrusted-data/gi, '‹$1untrusted-data');
  return `<${TAG} source="${source}">\n${safe}\n</${TAG}>`;
}
