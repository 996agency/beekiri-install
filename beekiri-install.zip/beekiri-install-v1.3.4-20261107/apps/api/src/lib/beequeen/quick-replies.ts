/**
 * Replies Beekiri gives without calling Claude — so they never cost the site anything:
 * thanks and small talk ("Amazing work", "hi", "ok"), and requests it always refuses (getting
 * around a theme licence, revealing keys or passwords, changing the Beekiri core). Only a
 * message that is clearly one of these is answered here; anything that asks for work goes to Claude.
 */

export type QuickReply = { kind: 'thanks' | 'greeting' | 'ack' | 'refusal'; text: string };

/** Lower case, accents and emoji gone, spaces collapsed: "Amazing work!! 🔥" → "amazing work". */
function normalize(prompt: string): string {
  return prompt
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^\p{L}\p{N}\s'?]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Words that mean the message asks for something — then Claude answers, never a canned reply. */
const ASKS =
  /\?|\b(can|could|would|will|please|pls|plz|add|change|make|create|build|fix|remove|delete|update|edit|move|set|put|show|replace|why|how|what|where|when|but|however|not|dont|don't|doesnt|doesn't|isnt|isn't|cant|can't|wrong|broken|error|again|instead|also|then|next|now|mund|ndrysho|shto|hiq|rregullo|pse|si|por)\b/;

/** Thanks / praise: every word is one of these, and at least one is a real thank-you or compliment. */
const PRAISE = new Set(
  'thanks thank thx ty tysm cheers amazing awesome great perfect nice cool wow excellent brilliant fantastic super superb beautiful lovely bravo good job work done well love looks look looking so very really much a lot you it this that thats it\'s is was again bro man mate buddy beekiri bee team guys indeed totally absolutely exactly what wanted just right job faleminderit flm rrofsh shume mire bukur mrekulli te lumte tlumt shum faleminderit'.split(' '),
);
const PRAISE_CORE =
  /\b(?:thanks?|thx|ty|tysm|cheers|amazing|awesome|great|perfect|nice|cool|wow|excellent|brilliant|fantastic|super|superb|beautiful|lovely|bravo|well done|good (?:job|work)|love|faleminderit|flm|rrofsh|mire|bukur|mrekulli|lumte|tlumt)\b/;
const isPraise = (text: string) => PRAISE_CORE.test(text) && text.split(' ').every((w) => PRAISE.has(w));

const GREETING = /^(?:hi|hello|hey|hiya|good (?:morning|afternoon|evening)|pershendetje|tung|ckemi|mirembrema|miremengjes)(?: (?:there|beekiri|bee))?$/;

const ACK = /^(?:ok|okay|k|got it|alright|all right|sure|fine|noted|understood|mire|ne rregull|ok faleminderit)$/;

/** Requests Beekiri always turns down, with the answer to give. Checked before anything else. */
const REFUSALS: { test: RegExp; text: string }[] = [
  {
    test: /\b(?:bypass|crack|hack|skip|get around|work around|avoid|remove|disable|break|fake|steal)\b.{0,40}\blicen[cs]e|\blicen[cs]e\b.{0,40}\b(?:bypass|crack|hack|for free|without paying|without buying|free of charge|key generator|keygen)|\bnulled\b|\bpirat(?:e|ed)\b|\b(?:activate|use|install|unlock|download)\b.{0,40}\btheme\b.{0,40}\b(?:without (?:a )?licen[cs]e|without paying|without buying|for free)/,
    text:
      'I can’t help get around a theme licence. Store themes are unlocked through Appearance → Templates: buy the theme there, or enter the licence key from the site that bought it (one licence covers your local, staging and production site with the same owner e-mail). If something looks wrong with a licence you paid for, 996Agency will sort it out.',
  },
  {
    test: /\b(?:show|give|reveal|tell|print|send|share|expose|leak|display|copy|paste|export|dump|what(?:'s| is)|where(?:'s| is))\b.{0,40}\b(?:api ?keys?|anthropic keys?|claude keys?|openai keys?|install tokens?|access tokens?|secret keys?|secrets?|passwords?|password hash(?:es)?|\.env|env file|credentials|database (?:password|credentials|url)|stripe keys?|session (?:cookies?|tokens?))\b/,
    text:
      'I can’t share keys, tokens, passwords or other secrets — not even with the site owner, and I don’t have access to them myself. To change a password, use your profile (or Users, for other accounts); payment and e-mail keys are entered in their own settings screens.',
  },
  {
    test: /\b(?:change|edit|modify|rewrite|hack|patch|replace|delete|remove)\b.{0,30}\b(?:beekiri (?:core|source(?: code)?|cms code|admin code|api code)|the core files?|core code)\b|\b(?:remove|hide|replace|change|rebrand|white ?label)\b.{0,30}\b(?:powered by beekiri|beekiri (?:logo|branding|brand|name|credit|footer credit))\b/,
    text:
      'I can’t change Beekiri itself — its core, admin code or branding stay as they are, so updates keep working and your site stays safe. Everything on your site is mine to build, though: themes, layouts, pages, posts, products, popups and content types. Tell me what you’d like it to do and I’ll build it there.',
  },
  {
    test: /\b(?:free (?:credits?|balance|money|usage)|add (?:credits?|balance|money)\b.{0,20}\b(?:for free|myself|without paying)|bypass (?:billing|payment|the balance)|(?:don'?t|do not|stop) charg(?:e|ing))\b/,
    text:
      'I can’t change the balance or how Beekiri is billed. Each message uses only the Claude work it needs; you can add money any time under Connector → Balance ($20, $50, $100 or your own amount).',
  },
];

const THANKS_REPLIES = [
  'Thank you — glad you like it! I’m here whenever you want to build or change the next thing.',
  'Happy to hear that! Whenever you’re ready, tell me what to build or improve next.',
  'Great to hear it’s what you wanted. I’m here to help with anything else on your site.',
  'Thanks! If anything needs a tweak — text, spacing, colours, phones — just tell me.',
];
const GREETING_REPLIES = [
  'Hi! What would you like to build or change today?',
  'Hello! Tell me what you’d like on your site — a new section, a page, a popup, a product…',
];
const ACK_REPLIES = ['Great — tell me whenever you need the next change.', 'Sounds good. I’m here when you need me.'];

const pick = (list: string[], seed: string) => list[[...seed].reduce((n, c) => n + c.charCodeAt(0), 0) % list.length];

/**
 * A reply for a message that needs no work, or null when Claude should answer. `waiting`: an earlier
 * reply in this chat still has changes waiting for Keep — thanks then comes with a reminder.
 */
export function quickReply(prompt: string, opts: { waiting?: boolean } = {}): QuickReply | null {
  const text = normalize(prompt);
  if (!text || text.length > 200) return null;
  for (const r of REFUSALS) if (r.test.test(text)) return { kind: 'refusal', text: r.text };
  // Small talk is short and asks for nothing.
  if (text.length > 80 || ASKS.test(text)) return null;
  const remind = opts.waiting
    ? ' One thing before you go: your last change is still waiting — press Keep under it to make it live for visitors, or Preview to check it first.'
    : '';
  if (isPraise(text)) return { kind: 'thanks', text: pick(THANKS_REPLIES, text) + remind };
  if (GREETING.test(text)) return { kind: 'greeting', text: pick(GREETING_REPLIES, text) };
  if (ACK.test(text)) return { kind: 'ack', text: pick(ACK_REPLIES, text) + remind };
  return null;
}
