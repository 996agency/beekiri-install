import type { NextFunction, Request, Response } from 'express';
import { chmodSync, existsSync, readFileSync, rmSync, writeFileSync } from 'fs';
import { join } from 'path';
import { config } from '../config/env';
import { API_ROOT } from '../config/paths';
import { InstallationState } from '../models';
import { randomToken, safeEqual } from '../utils/crypto';
import { Forbidden } from '../utils/http-error';

/**
 * One-time setup key. Until a site is installed, the setup wizard's write endpoints
 * (database step, create site) only answer to someone holding this key. It is printed in
 * the terminal where Beekiri runs and kept in apps/api/.setup-token (owner-only), so it
 * survives the restart after the database step, and it is deleted once the site exists.
 * Without it, anyone who reached the server before its owner could claim the site.
 */
export const SETUP_TOKEN_HEADER = 'x-setup-token';

function tokenFile(): string {
  return process.env.BEEKIRI_SETUP_TOKEN_FILE || join(API_ROOT, '.setup-token');
}

/** The current setup key, created on first use. */
export function ensureSetupToken(): string {
  const file = tokenFile();
  if (existsSync(file)) {
    const saved = readFileSync(file, 'utf8').trim();
    if (saved.length >= 32) return saved;
  }
  const token = randomToken(24);
  writeFileSync(file, `${token}\n`, { mode: 0o600 });
  chmodSync(file, 0o600);
  return token;
}

/** Called once the site is installed: the key is never valid again. */
export function clearSetupToken(): void {
  rmSync(tokenFile(), { force: true });
}

export async function isSiteInstalled(): Promise<boolean> {
  if (!config.databaseConfigured) return false;
  const state = await InstallationState.findByPk(1);
  return Boolean(state?.installed);
}

/** Guards the setup wizard's write endpoints. Installed sites fall through to their 409. */
export async function requireSetupToken(req: Request, _res: Response, next: NextFunction) {
  try {
    if (await isSiteInstalled()) return next();
    const expected = ensureSetupToken();
    const given = req.get(SETUP_TOKEN_HEADER)?.trim() ?? '';
    if (!given || !safeEqual(given, expected)) {
      throw Forbidden({
        statusCode: 403,
        error: 'Forbidden',
        message:
          'Enter the setup key. It is shown in the terminal where Beekiri runs and saved on the server in apps/api/.setup-token.',
        code: 'setup_key_required',
      });
    }
    next();
  } catch (error) {
    next(error);
  }
}
