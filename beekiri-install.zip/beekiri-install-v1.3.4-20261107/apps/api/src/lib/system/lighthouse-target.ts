import { currentSite, siteUrl } from '../site/current-site';
import { config } from '../../config/env';
import { getSelfUrl } from '../../config/runtime';

export type LighthouseTarget = {
  url: string;
  /** `configured` = LIGHTHOUSE_URL; `site` = this Beekiri site itself. */
  mode: 'configured' | 'site';
  /** Nothing to tear down any more; kept so callers can always call it. */
  cleanup: () => Promise<void>;
};

/**
 * The site is served by this same server, so audit it directly. Scores are only
 * representative under `npm start` (production build), not `npm run dev`.
 */
export async function resolveLighthouseTarget(): Promise<LighthouseTarget> {
  const noop = async () => undefined;
  if (config.lighthouse.url)
    return { url: config.lighthouse.url, mode: 'configured', cleanup: noop };

  // Multisite: another site of the network is tested on its own address.
  const site = currentSite();
  const own = site && !site.isPrimary ? await siteUrl(site) : '';
  const url = own || config.urls.app || getSelfUrl();
  if (!url) throw new Error('The site is not running yet');
  return { url, mode: 'site', cleanup: noop };
}
