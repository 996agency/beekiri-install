import type { Transaction } from 'sequelize';
import { Role, UserSite } from '../../models';
import type { RoleSlug } from '../cms-types';

/** A person's standing on one site: role plus the per-user capability grants/denies. */
export type SiteAccess = {
  role: RoleSlug;
  roleId: string | null;
  capabilityGrants: string[];
  capabilityDenies: string[];
};

function strings(raw: unknown): string[] {
  return Array.isArray(raw) ? raw.filter((v): v is string => typeof v === 'string') : [];
}

export function accessFromRow(row: { roleId: string; profile?: unknown; role?: { slug: string } | null }): SiteAccess {
  const profile = (row.profile && typeof row.profile === 'object' ? row.profile : {}) as Record<string, unknown>;
  return {
    role: (row.role?.slug ?? 'subscriber') as RoleSlug,
    roleId: row.roleId,
    capabilityGrants: strings(profile.capabilityGrants),
    capabilityDenies: strings(profile.capabilityDenies),
  };
}

/**
 * What `user` may do on `siteId`, or null when they have no access there. The network owner
 * can use every site as an administrator (their own row, when there is one, is used as is).
 */
export async function siteAccessFor(
  user: { id: string; isOwner?: boolean | null },
  siteId: string,
  transaction?: Transaction,
): Promise<SiteAccess | null> {
  const row = await UserSite.findOne({
    where: { userId: user.id, siteId },
    include: [{ model: Role, as: 'role' }],
    transaction,
  });
  if (row) return accessFromRow(row);
  if (user.isOwner) return { role: 'administrator', roleId: null, capabilityGrants: [], capabilityDenies: [] };
  return null;
}
