import type { CapabilitySlug, RoleSlug } from '../cms-types';

/** Every capability Beekiri knows about (Owner always receives the full set). */
/** Settings → tabs (Beekiri Core is always shown; updates use `update_core`). */
export const SETTINGS_TAB_CAPABILITIES: CapabilitySlug[] = [
  'manage_settings_general',
  'manage_settings_reading',
  'manage_settings_writing',
  'manage_settings_page_editor',
  'manage_settings_advanced',
  'manage_settings_permalinks',
  'manage_settings_media',
  'manage_settings_cache',
  'manage_settings_instructions',
];

/** Any of these (or `manage_options`) unlocks Settings + Core status. */
export const SETTINGS_ACCESS_CAPABILITIES: CapabilitySlug[] = [
  'update_core',
  ...SETTINGS_TAB_CAPABILITIES,
];

/** Shopping extension (Shop menu, products, orders, reports). */
export const SHOP_CAPABILITIES: CapabilitySlug[] = [
  'manage_shop',
  'edit_products',
  'edit_shop_orders',
  'view_shop_reports',
];

/** Bee Forms extension (form builder, entries). */
export const FORMS_CAPABILITIES: CapabilitySlug[] = ['manage_forms', 'view_form_entries'];

export const ALL_CAPABILITIES: CapabilitySlug[] = [
  'manage_options',
  'edit_users',
  'list_users',
  'create_users',
  'delete_users',
  'edit_posts',
  'edit_others_posts',
  'publish_posts',
  'delete_posts',
  'edit_pages',
  'edit_others_pages',
  'publish_pages',
  'delete_pages',
  'upload_files',
  'moderate_comments',
  'manage_categories',
  'edit_theme_options',
  'customize_dashboard',
  'manage_fields',
  'update_core',
  ...SETTINGS_TAB_CAPABILITIES,
  'use_beequeen',
  'unfiltered_html',
  ...SHOP_CAPABILITIES,
  ...FORMS_CAPABILITIES,
  'read',
];

/** WordPress-equivalent capability sets (independent implementation). */
export const ROLE_CAPABILITIES: Record<RoleSlug, CapabilitySlug[]> = {
  administrator: [
    'manage_options',
    'edit_users',
    'list_users',
    'create_users',
    'delete_users',
    'edit_posts',
    'edit_others_posts',
    'publish_posts',
    'delete_posts',
    'edit_pages',
    'edit_others_pages',
    'publish_pages',
    'delete_pages',
    'upload_files',
    'moderate_comments',
    'manage_categories',
    'edit_theme_options',
    'customize_dashboard',
    'manage_fields',
    'update_core',
    ...SETTINGS_TAB_CAPABILITIES,
    'use_beequeen',
    'unfiltered_html',
    ...SHOP_CAPABILITIES,
    ...FORMS_CAPABILITIES,
    'read',
  ],
  editor: [
    'edit_posts',
    'edit_others_posts',
    'publish_posts',
    'delete_posts',
    'edit_pages',
    'edit_others_pages',
    'publish_pages',
    'delete_pages',
    'upload_files',
    'moderate_comments',
    'manage_categories',
    'customize_dashboard',
    ...FORMS_CAPABILITIES,
    'read',
  ],
  author: [
    'edit_posts',
    'publish_posts',
    'delete_posts',
    'upload_files',
    'customize_dashboard',
    'read',
  ],
  contributor: ['edit_posts', 'customize_dashboard', 'read'],
  subscriber: ['customize_dashboard', 'read'],
  shop_manager: [
    ...SHOP_CAPABILITIES,
    'upload_files',
    'manage_categories',
    'customize_dashboard',
    'read',
  ],
};

export type CapabilityCatalogItem = {
  slug: CapabilitySlug;
  label: string;
  description: string;
  group: string;
};

/** Human labels for the User Permissions screen. */
export const CAPABILITY_CATALOG: CapabilityCatalogItem[] = [
  {
    group: 'Dashboard',
    slug: 'customize_dashboard',
    label: 'Customize dashboard',
    description: 'Reorder and resize Overview widgets.',
  },
  {
    group: 'Backend',
    slug: 'manage_fields',
    label: 'Backend Fields',
    description: 'View and edit field groups, post types, and taxonomies.',
  },
  {
    group: 'Site',
    slug: 'manage_options',
    label: 'Analytics & connectors',
    description: 'Analytics, BeeCookies, SEO tools, Connector, and Hive status.',
  },
  {
    group: 'Site',
    slug: 'edit_theme_options',
    label: 'Appearance',
    description: 'Change themes, header, footer, and templates.',
  },
  {
    group: 'Settings',
    slug: 'update_core',
    label: 'Beekiri Core — check for updates',
    description:
      'Beekiri Core tab is always available in Settings. This allows Check for updates and installing Core updates.',
  },
  {
    group: 'Settings',
    slug: 'manage_settings_general',
    label: 'Settings — General',
    description: 'Site title, tagline, favicon, and admin login URL.',
  },
  {
    group: 'Settings',
    slug: 'manage_settings_reading',
    label: 'Settings — Reading',
    description: 'Search engine visibility and reading options.',
  },
  {
    group: 'Settings',
    slug: 'manage_settings_writing',
    label: 'Settings — Writing',
    description: 'Writing defaults.',
  },
  {
    group: 'Settings',
    slug: 'manage_settings_page_editor',
    label: 'Settings — Page editor',
    description: 'Page editor and frontend runtime options.',
  },
  {
    group: 'Settings',
    slug: 'manage_settings_advanced',
    label: 'Settings — Advanced',
    description: 'Business details and advanced site options.',
  },
  {
    group: 'Settings',
    slug: 'manage_settings_permalinks',
    label: 'Settings — Permalinks',
    description: 'URL structure and site navigation menu.',
  },
  {
    group: 'Settings',
    slug: 'manage_settings_media',
    label: 'Settings — Media',
    description: 'Image sizes and media library options.',
  },
  {
    group: 'Settings',
    slug: 'manage_settings_cache',
    label: 'Settings — Cache',
    description: 'Flush cache and performance cache tools.',
  },
  {
    group: 'Settings',
    slug: 'manage_settings_instructions',
    label: 'Settings — Instructions',
    description: 'View the Instructions tab in Settings.',
  },
  {
    group: 'Connector',
    slug: 'use_beequeen',
    label: 'Use the Beekiri agent',
    description: 'Chat with the Beekiri agent to build layouts and pages. Each message is paid from the site’s prepaid Beekiri balance.',
  },
  {
    group: 'Users',
    slug: 'list_users',
    label: 'List users',
    description: 'See the users list and permissions screen.',
  },
  {
    group: 'Users',
    slug: 'create_users',
    label: 'Create users',
    description: 'Add new accounts.',
  },
  {
    group: 'Users',
    slug: 'edit_users',
    label: 'Edit users',
    description: 'Change profiles, roles, and per-user permissions.',
  },
  {
    group: 'Users',
    slug: 'delete_users',
    label: 'Delete users',
    description: 'Remove accounts (except the Owner).',
  },
  {
    group: 'Pages',
    slug: 'edit_pages',
    label: 'Edit pages',
    description: 'Create and edit pages.',
  },
  {
    group: 'Pages',
    slug: 'unfiltered_html',
    label: 'Raw HTML and scripts',
    description:
      'Save page and post HTML as written, including <script> and embeds. Without it, scripts and event handlers are stripped on save.',
  },
  {
    group: 'Pages',
    slug: 'edit_others_pages',
    label: 'Edit others’ pages',
    description: 'Edit pages created by other people.',
  },
  {
    group: 'Pages',
    slug: 'publish_pages',
    label: 'Publish pages',
    description: 'Publish and unpublish pages.',
  },
  {
    group: 'Pages',
    slug: 'delete_pages',
    label: 'Delete pages',
    description: 'Move pages to trash or delete them.',
  },
  {
    group: 'Posts',
    slug: 'edit_posts',
    label: 'Edit posts',
    description: 'Create and edit posts.',
  },
  {
    group: 'Posts',
    slug: 'edit_others_posts',
    label: 'Edit others’ posts',
    description: 'Edit posts created by other people.',
  },
  {
    group: 'Posts',
    slug: 'publish_posts',
    label: 'Publish posts',
    description: 'Publish and unpublish posts.',
  },
  {
    group: 'Posts',
    slug: 'delete_posts',
    label: 'Delete posts',
    description: 'Move posts to trash or delete them.',
  },
  {
    group: 'Media',
    slug: 'upload_files',
    label: 'Upload media',
    description: 'Upload and manage media files.',
  },
  {
    group: 'Content',
    slug: 'manage_categories',
    label: 'Manage categories',
    description: 'Create and edit taxonomies / categories.',
  },
  {
    group: 'Content',
    slug: 'moderate_comments',
    label: 'Moderate comments',
    description: 'Approve or remove comments.',
  },
  {
    group: 'Shopping',
    slug: 'manage_shop',
    label: 'Shop settings',
    description: 'Change shop settings: payments, shipping, taxes, emails.',
  },
  {
    group: 'Shopping',
    slug: 'edit_products',
    label: 'Products',
    description: 'Create, edit, publish and delete products and product categories.',
  },
  {
    group: 'Shopping',
    slug: 'edit_shop_orders',
    label: 'Orders & customers',
    description: 'View and manage orders, refunds, customers and coupons.',
  },
  {
    group: 'Shopping',
    slug: 'view_shop_reports',
    label: 'Shop reports',
    description: 'See sales figures on the Shop overview and dashboard.',
  },
  {
    group: 'Bee Forms',
    slug: 'manage_forms',
    label: 'Forms',
    description: 'Create and edit forms, their notifications and settings.',
  },
  {
    group: 'Bee Forms',
    slug: 'view_form_entries',
    label: 'Entries',
    description: 'Read, export and delete form entries and their uploaded files.',
  },
  {
    group: 'Access',
    slug: 'read',
    label: 'Sign in',
    description: 'Access the admin (always required).',
  },
];

const CAP_SET = new Set<string>(ALL_CAPABILITIES);

export function isCapabilitySlug(v: unknown): v is CapabilitySlug {
  return typeof v === 'string' && CAP_SET.has(v);
}

/** Live defaults loaded from DB (falls back to ROLE_CAPABILITIES until refreshed). */
const ROLE_CAPS_CACHE: Record<string, CapabilitySlug[]> = Object.fromEntries(
  (Object.keys(ROLE_CAPABILITIES) as RoleSlug[]).map((slug) => [
    slug,
    [...ROLE_CAPABILITIES[slug]!],
  ]),
);

const ROLE_LABEL_CACHE: Record<string, string> = {
  administrator: 'Administrator',
  editor: 'Editor',
  author: 'Author',
  contributor: 'Contributor',
  subscriber: 'Subscriber',
  shop_manager: 'Shop manager',
};

/** Apply DB role names + capability rows into the in-memory cache used at request time. */
export function applyRoleCache(
  rows: { slug: string; name: string; capabilities: CapabilitySlug[] }[],
): void {
  for (const key of Object.keys(ROLE_CAPS_CACHE)) delete ROLE_CAPS_CACHE[key];
  for (const key of Object.keys(ROLE_LABEL_CACHE)) {
    if (!(key in ROLE_CAPABILITIES)) delete ROLE_LABEL_CACHE[key];
  }
  for (const row of rows) {
    const caps = row.capabilities.filter(isCapabilitySlug);
    if (!caps.includes('read')) caps.push('read');
    ROLE_CAPS_CACHE[row.slug] = ALL_CAPABILITIES.filter((c) => caps.includes(c));
    const label = row.name.trim();
    if (label) ROLE_LABEL_CACHE[row.slug] = label.slice(0, 80);
  }
  // Keep built-in fallbacks if a seed row was missing.
  for (const slug of Object.keys(ROLE_CAPABILITIES) as RoleSlug[]) {
    if (!ROLE_CAPS_CACHE[slug]) ROLE_CAPS_CACHE[slug] = [...ROLE_CAPABILITIES[slug]];
    if (!ROLE_LABEL_CACHE[slug]) {
      ROLE_LABEL_CACHE[slug] = slug.charAt(0).toUpperCase() + slug.slice(1);
    }
  }
}

export function roleLabel(role: string): string {
  return ROLE_LABEL_CACHE[role] ?? role.charAt(0).toUpperCase() + role.slice(1);
}

export function listCachedRoles(): { slug: string; name: string; capabilities: CapabilitySlug[] }[] {
  const slugs = Object.keys(ROLE_CAPS_CACHE);
  const order = (Object.keys(ROLE_CAPABILITIES) as string[]).concat(
    slugs.filter((s) => !(s in ROLE_CAPABILITIES)),
  );
  const seen = new Set<string>();
  const out: { slug: string; name: string; capabilities: CapabilitySlug[] }[] = [];
  for (const slug of order) {
    if (seen.has(slug) || !ROLE_CAPS_CACHE[slug]) continue;
    seen.add(slug);
    out.push({
      slug,
      name: roleLabel(slug),
      capabilities: [...ROLE_CAPS_CACHE[slug]],
    });
  }
  return out;
}

export function roleHasCapability(role: RoleSlug, capability: CapabilitySlug): boolean {
  return (ROLE_CAPS_CACHE[role] ?? ROLE_CAPABILITIES[role])?.includes(capability) ?? false;
}

/** Settings sidebar/page: any settings tab, Core updates, or legacy manage_options. */
export function capsAllowSettings(caps: readonly string[] | undefined): boolean {
  const list = caps ?? [];
  if (list.includes('manage_options')) return true;
  return SETTINGS_ACCESS_CAPABILITIES.some((c) => list.includes(c));
}

export function capsAllowCoreUpdates(caps: readonly string[] | undefined): boolean {
  const list = caps ?? [];
  return list.includes('update_core') || list.includes('manage_options');
}

export function capsAllowSettingsTab(
  caps: readonly string[] | undefined,
  tabCap: CapabilitySlug,
): boolean {
  const list = caps ?? [];
  if (list.includes('manage_options')) return true;
  return list.includes(tabCap);
}

export function roleDefaults(role: RoleSlug | string): CapabilitySlug[] {
  return [...(ROLE_CAPS_CACHE[role] ?? ROLE_CAPABILITIES[role as RoleSlug] ?? (['read'] as CapabilitySlug[]))];
}

/**
 * Resolve effective capabilities.
 * Owner always gets everything. Otherwise: role defaults + grants − denies.
 */
export function resolveCapabilities(opts: {
  role: RoleSlug;
  isOwner: boolean;
  grants?: readonly string[];
  denies?: readonly string[];
}): CapabilitySlug[] {
  if (opts.isOwner) return [...ALL_CAPABILITIES];
  const base = new Set<CapabilitySlug>(roleDefaults(opts.role));
  for (const g of opts.grants ?? []) {
    if (isCapabilitySlug(g)) base.add(g);
  }
  for (const d of opts.denies ?? []) {
    if (isCapabilitySlug(d) && d !== 'read') base.delete(d);
  }
  if (!base.has('read')) base.add('read');
  return ALL_CAPABILITIES.filter((c) => base.has(c));
}

/** Build grants/denies so that roleDefaults ± overrides === desired. */
export function diffCapabilities(
  role: RoleSlug,
  desired: readonly CapabilitySlug[],
): { grants: CapabilitySlug[]; denies: CapabilitySlug[] } {
  const defaults = new Set(roleDefaults(role));
  const want = new Set(desired);
  want.add('read');
  const grants: CapabilitySlug[] = [];
  const denies: CapabilitySlug[] = [];
  for (const cap of ALL_CAPABILITIES) {
    const inDefault = defaults.has(cap);
    const inWant = want.has(cap);
    if (inWant && !inDefault) grants.push(cap);
    if (!inWant && inDefault && cap !== 'read') denies.push(cap);
  }
  return { grants, denies };
}

export function assertCapability(
  role: RoleSlug,
  capability: CapabilitySlug,
): asserts role is RoleSlug {
  if (!roleHasCapability(role, capability)) {
    throw new Error(`Missing capability: ${capability}`);
  }
}
