import { createHmac } from 'node:crypto';
import type { CookieOptions, Request } from 'express';
import { config } from '../../config/env';
import { safeEqual } from '../../utils/crypto';

/**
 * "Known device" cookies. The per-account login limit stops a distributed guess at one
 * password, but on its own it lets anyone lock the owner out by typing wrong passwords.
 * A browser that signed in to an account before carries a signed cookie for it, and that
 * browser may still try the password while the account is throttled; every other browser
 * stays throttled. The signature is keyed with the account's password hash (plus the
 * server's flush secret when set), so it can't be forged and a password change voids it.
 */

export const KNOWN_DEVICE_COOKIE = config.auth.cookieSecure ? '__Host-beekiri_device' : 'beekiri_device';
export const KNOWN_SHOP_DEVICE_COOKIE = config.auth.cookieSecure ? '__Host-beekiri_shop_device' : 'beekiri_shop_device';

const MAX_AGE_MS = 365 * 24 * 60 * 60 * 1000;

type Kind = 'user' | 'customer';

function sign(kind: Kind, id: string, passwordHash: string): string {
  const key = `known-device:${config.core.cacheFlushSecret ?? ''}:${passwordHash}`;
  return createHmac('sha256', key).update(`${kind}:${id}`).digest('base64url');
}

/** Cookie value for a browser that just signed in to `id`. */
export function knownDeviceValue(kind: Kind, id: string, passwordHash: string): string {
  return `${id}.${sign(kind, id, passwordHash)}`;
}

/** True when `raw` is this account's known-device cookie. */
export function isKnownDevice(raw: string | undefined, kind: Kind, id: string, passwordHash: string | null | undefined): boolean {
  if (!raw || !passwordHash || raw.length > 200) return false;
  return safeEqual(raw, knownDeviceValue(kind, id, passwordHash));
}

export function knownDeviceCookie(req: Request, name: string): string | undefined {
  const raw: unknown = (req.cookies as Record<string, unknown> | undefined)?.[name];
  return typeof raw === 'string' && raw ? raw : undefined;
}

export function knownDeviceCookieOptions(): CookieOptions {
  return { path: '/', httpOnly: true, sameSite: 'lax', secure: config.auth.cookieSecure, maxAge: MAX_AGE_MS };
}
