import type { NextFunction, Request, Response } from 'express';
import { existsSync, mkdirSync, statSync, writeFileSync } from 'fs';
import { dirname, join, normalize, sep } from 'path';
import sharp from 'sharp';

/**
 * Widths the website asks for: 320–640 for cards and thumbnails (the browser picks by the size a
 * photo really shows at), 828 / 1290 for full-width photos on 1–2× / 3× phones, 1600 for desktops.
 */
export const VARIANT_WIDTHS = new Set([320, 480, 640, 750, 828, 1290, 1600]);

/** WebP quality of the copies: looks the same as 90 for photos, noticeably smaller. */
const QUALITY = 85;
/** AVIF for browsers that take it: about half the bytes of WebP at the same look. */
const AVIF_QUALITY = 60;

const IMAGE = /^[\w./-]+\.(webp|jpe?g|png)$/i;
const pending = new Map<string, Promise<void>>();

/**
 * GET /uploads/_w{width}/{path}: the upload resized to `width` (never enlarged), as AVIF for
 * browsers that accept it, else WebP. Made on first request and kept in uploads/.variants/, so phones download a
 * fraction of a full-size photo. The source name carries a content hash, so it caches for a year.
 */
export function mediaVariant(uploadsRoot: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const match = /^\/_w(\d{3,4})\/(.+)$/.exec(req.path);
      if (!match) return next();
      const width = Number(match[1]);
      const rel = decodeURIComponent(match[2]);
      if (!VARIANT_WIDTHS.has(width) || !IMAGE.test(rel) || rel.split('/').some((p) => p.startsWith('.'))) return next();
      const source = normalize(join(uploadsRoot, rel));
      if (!source.startsWith(uploadsRoot + sep) || !existsSync(source)) return next();

      // Same address, best format the browser takes (caches keep one per format: Vary: Accept).
      const avif = /image\/avif/i.test(String(req.headers.accept ?? ''));
      const format = avif ? 'avif' : 'webp';
      // The quality is part of the folder, so copies made at another quality are made again.
      const folder = avif ? `w${width}-avif-q${AVIF_QUALITY}` : `w${width}-q${QUALITY}`;
      const target = join(uploadsRoot, '.variants', folder, rel.replace(/\.(jpe?g|png|webp)$/i, `.${format}`));
      const fresh = existsSync(target) && statSync(target).mtimeMs >= statSync(source).mtimeMs;
      if (!fresh) {
        let job = pending.get(target);
        if (!job) {
          job = (async () => {
            const meta = await sharp(source).metadata();
            mkdirSync(dirname(target), { recursive: true });
            const resized = sharp(source)
              .rotate()
              .resize({ width: Math.min(width, meta.width ?? width), withoutEnlargement: true });
            const out = await (avif
              ? resized.avif({ quality: AVIF_QUALITY, effort: 4 })
              : resized.webp({ quality: QUALITY, alphaQuality: 100, smartSubsample: true, effort: 5 })
            ).toBuffer();
            writeFileSync(target, out);
          })().finally(() => pending.delete(target));
          pending.set(target, job);
        }
        await job;
      }
      res.setHeader('Content-Type', `image/${format}`);
      // A protected site's copies must not be kept by shared caches (see siteLock).
      res.setHeader('Cache-Control', `${res.locals.siteLocked ? 'private' : 'public'}, max-age=31536000, immutable`);
      res.setHeader('Vary', 'Accept');
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.sendFile(target, { dotfiles: 'allow' });
    } catch (error) {
      next(error);
    }
  };
}
