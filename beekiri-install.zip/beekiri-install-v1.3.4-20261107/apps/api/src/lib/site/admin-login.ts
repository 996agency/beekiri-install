/** Admin mount + sign-in paths. Default mount is `/admin`; login is `{base}/{slug}`. */

export const DEFAULT_ADMIN_BASE_PATH = '/admin';
export const DEFAULT_ADMIN_LOGIN_SLUG = 'login';

/** Top-level segments that must never be used as the login slug under the admin base. */
export const RESERVED_ADMIN_LOGIN_SLUGS = new Set([
  'install',
  'posts',
  'pages',
  'media',
  'users',
  'settings',
  'fields',
  'appearance',
  'analytics',
  'seo',
  'connector',
  'extensions',
  'content',
  'lost-password',
  'lostpassword',
  'reset-password',
  'api',
  'assets',
]);

/** First path segment values that cannot be the entire admin base (collide with public site / API). */
export const RESERVED_ADMIN_BASE_SEGMENTS = new Set([
  'api',
  'blog',
  'assets',
  'uploads',
  'media',
  'wp-admin',
  'wp-json',
  'wp-content',
  'wp-includes',
  'install',
  'health',
  'favicon.ico',
  'robots.txt',
  'sitemap.xml',
]);

export function normalizeAdminLoginSlug(raw: unknown): string {
  const s = String(raw ?? '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
  if (s.length < 3) return DEFAULT_ADMIN_LOGIN_SLUG;
  if (RESERVED_ADMIN_LOGIN_SLUGS.has(s)) return DEFAULT_ADMIN_LOGIN_SLUG;
  return s;
}

/**
 * Normalize a full admin mount path.
 * Accepts `admin`, `/admin`, `/my-secret`, `/panel/v2` → always leading slash, no trailing slash
 * (except we never return empty — fall back to `/admin`).
 */
export function normalizeAdminBasePath(raw: unknown): string {
  let s = String(raw ?? '')
    .trim()
    .toLowerCase()
    .replace(/\\/g, '/')
    .replace(/\/+/g, '/');
  if (!s.startsWith('/')) s = `/${s}`;
  s = s.replace(/\/+$/, '') || DEFAULT_ADMIN_BASE_PATH;
  // Single-segment or multi; only [a-z0-9._-] per segment
  if (!/^\/[a-z0-9._-]+(\/[a-z0-9._-]+)*$/.test(s)) return DEFAULT_ADMIN_BASE_PATH;
  if (s.length < 2 || s.length > 80) return DEFAULT_ADMIN_BASE_PATH;
  const first = s.slice(1).split('/')[0] ?? '';
  if (RESERVED_ADMIN_BASE_SEGMENTS.has(first)) return DEFAULT_ADMIN_BASE_PATH;
  return s;
}

export function adminLoginPath(
  slug?: string | null,
  basePath?: string | null,
): string {
  const base = normalizeAdminBasePath(basePath ?? DEFAULT_ADMIN_BASE_PATH);
  return `${base}/${normalizeAdminLoginSlug(slug ?? DEFAULT_ADMIN_LOGIN_SLUG)}`;
}

export function adminHref(basePath: string | null | undefined, subPath = ''): string {
  const base = normalizeAdminBasePath(basePath ?? DEFAULT_ADMIN_BASE_PATH);
  const sub = String(subPath ?? '')
    .trim()
    .replace(/^\/+/, '');
  return sub ? `${base}/${sub}` : base;
}

/** True when this request path should get the admin SPA HTML shell. */
export function isAdminSpaDocumentPath(path: string, basePath: string): boolean {
  const base = normalizeAdminBasePath(basePath);
  const p = path.length > 1 && path.endsWith('/') ? path.slice(0, -1) : path;
  if (p === base) return true;
  if (!p.startsWith(`${base}/`)) return false;
  // Never treat Vite/dev or hashed assets as SPA documents.
  if (
    p.startsWith(`${base}/@`) ||
    p.startsWith(`${base}/src/`) ||
    p.startsWith(`${base}/node_modules/`) ||
    p.startsWith(`${base}/assets/`)
  ) {
    return false;
  }
  // Asset pipeline stays under /admin even when the SPA mount moves.
  if (
    p.startsWith('/admin/@') ||
    p.startsWith('/admin/src/') ||
    p.startsWith('/admin/node_modules/') ||
    p.startsWith('/admin/assets/')
  ) {
    return false;
  }
  const leaf = p.slice(p.lastIndexOf('/') + 1);
  return leaf.length > 0 && !leaf.includes('.');
}
