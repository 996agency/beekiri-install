import {
  DEFAULT_ADMIN_BASE_PATH,
  DEFAULT_ADMIN_LOGIN_SLUG,
  normalizeAdminBasePath,
  normalizeAdminLoginSlug,
} from './admin-login';
import { parseBeeCookies, type BeeCookiesOptions } from './bee-cookies';
import { parseConnector, type ConnectorOptions } from './connector';
import { parseGoogleAnalytics, type GoogleAnalyticsOptions } from './google-analytics';
import { parseTranslations, type TranslationsOptions } from './translations';

/** SiteSettings.options JSON — General / Google Business / Permalinks / menu / media. */

export type MenuItemOption = {
  id: string;
  label: string;
  path: string;
  enabled: boolean;
  source?: string;
  refId?: string;
  children?: MenuItemOption[];
};

export type MediaFolderOption = {
  id: string;
  name: string;
  slug: string;
  /** null = top-level folder */
  parentId: string | null;
};

/** Upload pipeline defaults: Full HD, WebP. */
export type MediaSettingsOption = {
  convertToWebp: boolean;
  /** Lossless WebP (no quality loss). Prefer this for “full quality”. */
  webpLossless: boolean;
  /** Used when webpLossless is false (1–100). */
  webpQuality: number;
  /** Longest edge max — Full HD = 1920 */
  maxWidth: number;
  maxHeight: number;
  stripMetadata: boolean;
  keepOriginal: boolean;
  folders: MediaFolderOption[];
};

/** Default site favicon (admin + public) when none is configured. */
export const DEFAULT_FAVICON_PATH = '/icon-512.png';
/** Brand files removed in the 2026-11 rebrand; a saved setting that still names one gets the new default. */
const RETIRED_FAVICONS = new Set(['/beekiri-logo.png', '/beeicon.svg', '/favicon.svg']);

export type SiteOptions = {
  businessName?: string;
  businessCategory?: string;
  businessPhone?: string;
  businessAddress?: string;
  businessHours?: string;
  businessImageUrl?: string;
  /** Absolute URL or site-relative path. Empty → DEFAULT_FAVICON_PATH. */
  faviconUrl?: string;
  /**
   * Admin SPA mount path. Default `/admin`. After install you can change this to a
   * secret path (e.g. `/my-hive`) so `/admin` is no longer the entry.
   */
  adminBasePath?: string;
  /**
   * Sign-in URL segment under the admin base: `{adminBasePath}/{adminLoginSlug}`.
   * Default `login`.
   */
  adminLoginSlug?: string;
  permalinkStructure?: 'plain' | 'postname' | 'dayname' | 'custom';
  permalinkCustom?: string;
  menuItems?: MenuItemOption[];
  /** Published page id used as the site home (`/`). */
  frontPageId?: string;
  /** Fallback slug when frontPageId is missing (e.g. `home`). */
  frontPageSlug?: string;
  media?: MediaSettingsOption;
  /** Backend Fields module settings */
  backendFields?: {
    showAdminBar?: boolean;
    exportFormat?: 'php' | 'json';
    deleteWithContent?: boolean;
  };
  /** Active public theme slug (filesystem under /themes). */
  activeTheme?: string;
  /** Active theme header chrome slug (from theme.json headers). */
  activeHeader?: string;
  /** Active theme footer chrome slug (from theme.json footers). */
  activeFooter?: string;
  /** Page editor surface — BeekiriCode only. */
  pageEditorStyle?: 'beekiricode';
  /**
   * Which theme entry files the public site runs (layouts, header, footer):
   * - php — `{slug}.php`
   * - react — `{slug}.tsx`
   * Chosen once in the installer and locked; changing it requires a site reset.
   */
  frontendRuntime?: FrontendRuntime;
  /**
   * Bumped by Settings → Cache full flush so theme/layout asset URLs
   * (`?v=`) change and browsers + CDNs refetch minified CSS/JS.
   */
  cacheEpoch?: number;
  /** Settings → BeeCookies */
  beeCookies?: BeeCookiesOptions;
  /** Analytics → Google Analytics connection */
  googleAnalytics?: GoogleAnalyticsOptions;
  /** Admin → Connector (pay-as-you-go + AI agents) */
  connector?: ConnectorOptions;
  /** Settings → Translation */
  translations?: TranslationsOptions;
  /**
   * Site-wide HTML snippets (Settings → General → Site code).
   * Injected into the public layout for verification metas, JSON-LD, pixels, etc.
   */
  customHeadHtml?: string;
  /** Inserted right after `<body>` opens (e.g. GTM noscript). */
  customBodyHtml?: string;
  /** Inserted before `</body>` (analytics / non-critical scripts). */
  customFooterHtml?: string;
  /** Installed Beekiri extensions (Extensions screen). */
  extensions?: ExtensionsOptions;
  /** Registration with the Beekiri Hub (996Agency): install id + encrypted install token. */
  hub?: HubOptions;
  /** Pages a theme's content/ folder installed on this site, by theme slug. */
  themeContent?: Record<string, ThemeContentRecord>;
  /**
   * Each theme's own site set-up, by client theme slug: saved when you switch away from the
   * theme and put back when you switch to it again (see services/theme-switch.service.ts).
   */
  themeState?: Record<string, ThemeStateRecord>;
  /** Multisite network settings; only read from the primary site. */
  network?: NetworkOptions;
};

export type NetworkOptions = {
  /** Domain sites hang off as sub-domains (`shop.<baseDomain>`); default: APP_URL's host. */
  baseDomain?: string;
};

function parseNetwork(raw: unknown): NetworkOptions | undefined {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return undefined;
  const base = asString((raw as Record<string, unknown>).baseDomain)
    ?.trim()
    .toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/[/:].*$/, '');
  return base ? { baseDomain: base } : {};
}

export type ExtensionState = { installedAt: string; active: boolean };
export type ExtensionsOptions = Record<string, ExtensionState>;

function parseExtensions(raw: unknown): ExtensionsOptions {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const out: ExtensionsOptions = {};
  for (const [slug, value] of Object.entries(raw as Record<string, unknown>)) {
    if (!/^[a-z][a-z0-9-]{0,40}$/.test(slug)) continue;
    if (!value || typeof value !== 'object') continue;
    const v = value as Record<string, unknown>;
    const installedAt = typeof v.installedAt === 'string' ? v.installedAt : new Date(0).toISOString();
    out[slug] = { installedAt, active: v.active === true };
  }
  return out;
}

/** Frontend runtimes the installer can offer. `available: false` = shown as coming soon. */
export const FRONTEND_RUNTIMES = [
  { id: 'php', label: 'PHP', available: true },
  { id: 'react', label: 'React', available: true },
  { id: 'vue', label: 'Vue', available: false },
] as const;

export type FrontendRuntime = 'php' | 'react';

export const AVAILABLE_FRONTEND_RUNTIMES: FrontendRuntime[] = ['php', 'react'];

const DEFAULT_MENU: MenuItemOption[] = [
  { id: 'home', label: 'Home', path: '/', enabled: true, source: 'home' },
  { id: 'blog', label: 'Blog', path: '/blog', enabled: true, source: 'home' },
  {
    id: 'about',
    label: 'About',
    path: '/about',
    enabled: true,
    source: 'custom',
    children: [
      { id: 'about-team', label: 'Team', path: '/about/team', enabled: true, source: 'custom' },
    ],
  },
  { id: 'contact', label: 'Contact', path: '/contact', enabled: false, source: 'custom' },
];

export const DEFAULT_MEDIA: MediaSettingsOption = {
  convertToWebp: true,
  webpLossless: true,
  webpQuality: 100,
  maxWidth: 1920,
  maxHeight: 1920,
  stripMetadata: true,
  keepOriginal: false,
  folders: [
    { id: 'general', name: 'General', slug: 'general', parentId: null },
    { id: 'heroes', name: 'Heroes', slug: 'heroes', parentId: null },
    { id: 'blog', name: 'Blog', slug: 'blog', parentId: null },
  ],
};

function asString(v: unknown): string | undefined {
  return typeof v === 'string' ? v : undefined;
}

/** Cap site-code snippets so a paste cannot balloon SiteSettings.options. */
export const SITE_CODE_MAX_CHARS = 50_000;

export function normalizeSiteCodeHtml(raw: unknown): string {
  if (typeof raw !== 'string') return '';
  return raw.replace(/\u0000/g, '').slice(0, SITE_CODE_MAX_CHARS);
}

function asBool(v: unknown, fallback: boolean): boolean {
  return typeof v === 'boolean' ? v : fallback;
}

function asInt(v: unknown, fallback: number, min: number, max: number): number {
  const n = typeof v === 'number' ? v : Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
}

function parseMenuItem(row: unknown): MenuItemOption | null {
  if (!row || typeof row !== 'object') return null;
  const r = row as Record<string, unknown>;
  const id = asString(r.id);
  const label = asString(r.label);
  const path = asString(r.path);
  if (!id || !label || path === undefined) return null;
  const childrenRaw = Array.isArray(r.children) ? r.children : [];
  const children = childrenRaw.map(parseMenuItem).filter((c): c is MenuItemOption => Boolean(c));
  return {
    id,
    label,
    path,
    enabled: Boolean(r.enabled),
    source: asString(r.source),
    refId: asString(r.refId),
    children: children.length ? children : undefined,
  };
}

function parseMenuItems(raw: unknown): MenuItemOption[] | undefined {
  if (!Array.isArray(raw)) return undefined;
  const items = raw.map(parseMenuItem).filter((c): c is MenuItemOption => Boolean(c));
  return items.length ? items : undefined;
}

function parseFolders(raw: unknown): MediaFolderOption[] {
  if (!Array.isArray(raw)) return [...DEFAULT_MEDIA.folders];
  const out: MediaFolderOption[] = [];
  const ids = new Set<string>();
  for (const row of raw) {
    if (!row || typeof row !== 'object') continue;
    const r = row as Record<string, unknown>;
    const id = asString(r.id);
    const name = asString(r.name);
    const slug = asString(r.slug);
    if (!id || !name || !slug) continue;
    ids.add(id);
    const parentRaw = r.parentId;
    const parentId =
      parentRaw === null || parentRaw === undefined || parentRaw === ''
        ? null
        : (asString(parentRaw) ?? null);
    out.push({ id, name, slug, parentId });
  }
  // Drop broken parent links (orphan → promote to root)
  for (const f of out) {
    if (f.parentId && !ids.has(f.parentId)) f.parentId = null;
  }
  return out.length ? out : [...DEFAULT_MEDIA.folders];
}

export function parseMediaSettings(raw: unknown): MediaSettingsOption {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return { ...DEFAULT_MEDIA, folders: [...DEFAULT_MEDIA.folders] };
  }
  const o = raw as Record<string, unknown>;
  return {
    convertToWebp: asBool(o.convertToWebp, DEFAULT_MEDIA.convertToWebp),
    webpLossless: asBool(o.webpLossless, DEFAULT_MEDIA.webpLossless),
    webpQuality: asInt(o.webpQuality, DEFAULT_MEDIA.webpQuality, 1, 100),
    maxWidth: asInt(o.maxWidth, DEFAULT_MEDIA.maxWidth, 320, 7680),
    maxHeight: asInt(o.maxHeight, DEFAULT_MEDIA.maxHeight, 320, 7680),
    stripMetadata: asBool(o.stripMetadata, DEFAULT_MEDIA.stripMetadata),
    keepOriginal: asBool(o.keepOriginal, DEFAULT_MEDIA.keepOriginal),
    folders: parseFolders(o.folders),
  };
}

export type ThemeContentRecord = {
  installedAt: string;
  pageIds: string[];
  mediaIds: string[];
  /** Demo shop products the theme added, by manifest key → product (post) id. */
  products?: Record<string, string>;
  /** Bee Forms the theme added, by manifest key → form id. */
  forms?: Record<string, string>;
  /** Demo blog posts the theme added, by manifest key → post id (parked with the theme). */
  posts?: Record<string, string>;
  /** sha1 of each shipped photo when it was uploaded (a theme update with new photos refreshes them). */
  imageHashes?: Record<string, string>;
};

function parseThemeContent(raw: unknown): Record<string, ThemeContentRecord> | undefined {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return undefined;
  const out: Record<string, ThemeContentRecord> = {};
  for (const [slug, value] of Object.entries(raw as Record<string, unknown>)) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) continue;
    const v = value as Record<string, unknown>;
    const ids = (list: unknown) => (Array.isArray(list) ? list.filter((x): x is string => typeof x === 'string') : []);
    const keyed = (map: unknown) =>
      map && typeof map === 'object' && !Array.isArray(map)
        ? Object.fromEntries(
            Object.entries(map as Record<string, unknown>).filter((e): e is [string, string] => typeof e[1] === 'string'),
          )
        : undefined;
    out[slug] = {
      installedAt: asString(v.installedAt) ?? '',
      pageIds: ids(v.pageIds),
      mediaIds: ids(v.mediaIds),
      ...(keyed(v.products) ? { products: keyed(v.products) } : {}),
      ...(keyed(v.forms) ? { forms: keyed(v.forms) } : {}),
      ...(keyed(v.posts) ? { posts: keyed(v.posts) } : {}),
      ...(keyed(v.imageHashes) ? { imageHashes: keyed(v.imageHashes) } : {}),
    };
  }
  return Object.keys(out).length ? out : undefined;
}

export type ThemeStateRecord = {
  frontPageId?: string;
  frontPageSlug?: string;
  menuItems?: MenuItemOption[];
  activeHeader?: string;
  activeFooter?: string;
  /** The theme's pages that were hidden (set to draft) when it stopped being active, with their status. */
  parked: { id: string; status: string }[];
};

function parseThemeState(raw: unknown): Record<string, ThemeStateRecord> | undefined {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return undefined;
  const out: Record<string, ThemeStateRecord> = {};
  for (const [slug, value] of Object.entries(raw as Record<string, unknown>)) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) continue;
    const v = value as Record<string, unknown>;
    const parked = Array.isArray(v.parked)
      ? v.parked.flatMap((p) => {
          const r = p as Record<string, unknown> | null;
          return r && typeof r.id === 'string' && typeof r.status === 'string' ? [{ id: r.id, status: r.status }] : [];
        })
      : [];
    out[slug] = {
      frontPageId: asString(v.frontPageId),
      frontPageSlug: asString(v.frontPageSlug),
      menuItems: parseMenuItems(v.menuItems),
      activeHeader: asString(v.activeHeader),
      activeFooter: asString(v.activeFooter),
      parked,
    };
  }
  return Object.keys(out).length ? out : undefined;
}

export type ThemeLicenceCache = { required: boolean; licensed: boolean; checkedAt: string };

export type HubOptions = {
  /** Hub address the token belongs to; a different address means registering again. */
  url: string;
  installId: string;
  /** Encrypted at rest when CACHE_FLUSH_SECRET is set (see lib/shop/secrets). */
  token: string;
  registeredAt: string;
  /** Last licence answer per store theme, used while the Hub cannot be reached. */
  licences?: Record<string, ThemeLicenceCache>;
  /** Store-theme licence keys by slug (encrypted at rest like the token): how this site proves it belongs to the buyer's project. */
  licenceKeys?: Record<string, string>;
};

function parseHub(raw: unknown): HubOptions | undefined {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return undefined;
  const h = raw as Record<string, unknown>;
  const url = asString(h.url) ?? '';
  const installId = asString(h.installId) ?? '';
  const token = asString(h.token) ?? '';
  if (!url || !installId || !token) return undefined;
  const licences: Record<string, ThemeLicenceCache> = {};
  if (h.licences && typeof h.licences === 'object' && !Array.isArray(h.licences)) {
    for (const [slug, raw] of Object.entries(h.licences as Record<string, unknown>)) {
      const l = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
      if (typeof l.licensed === 'boolean') {
        licences[slug] = { required: l.required !== false, licensed: l.licensed, checkedAt: asString(l.checkedAt) ?? '' };
      }
    }
  }
  const licenceKeys: Record<string, string> = {};
  if (h.licenceKeys && typeof h.licenceKeys === 'object' && !Array.isArray(h.licenceKeys)) {
    for (const [slug, key] of Object.entries(h.licenceKeys as Record<string, unknown>)) {
      if (typeof key === 'string' && key) licenceKeys[slug] = key;
    }
  }
  return {
    url,
    installId,
    token,
    registeredAt: asString(h.registeredAt) ?? '',
    ...(Object.keys(licences).length ? { licences } : {}),
    ...(Object.keys(licenceKeys).length ? { licenceKeys } : {}),
  };
}

export function readOptions(raw: unknown): SiteOptions {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const o = raw as Record<string, unknown>;
  const structure = asString(o.permalinkStructure);
  const permalinkStructure =
    structure === 'plain' ||
    structure === 'postname' ||
    structure === 'dayname' ||
    structure === 'custom'
      ? structure
      : undefined;

  return {
    businessName: asString(o.businessName),
    businessCategory: asString(o.businessCategory),
    businessPhone: asString(o.businessPhone),
    businessAddress: asString(o.businessAddress),
    businessHours: asString(o.businessHours),
    businessImageUrl: asString(o.businessImageUrl),
    faviconUrl: asString(o.faviconUrl),
    adminBasePath: o.adminBasePath
      ? normalizeAdminBasePath(o.adminBasePath)
      : DEFAULT_ADMIN_BASE_PATH,
    adminLoginSlug: o.adminLoginSlug
      ? normalizeAdminLoginSlug(o.adminLoginSlug)
      : DEFAULT_ADMIN_LOGIN_SLUG,
    permalinkStructure,
    permalinkCustom: asString(o.permalinkCustom),
    menuItems: parseMenuItems(o.menuItems),
    frontPageId: asString(o.frontPageId),
    frontPageSlug: asString(o.frontPageSlug),
    media: o.media !== undefined ? parseMediaSettings(o.media) : undefined,
    backendFields:
      o.backendFields && typeof o.backendFields === 'object' && !Array.isArray(o.backendFields)
        ? {
            showAdminBar: asBool((o.backendFields as Record<string, unknown>).showAdminBar, true),
            exportFormat:
              (o.backendFields as Record<string, unknown>).exportFormat === 'php' ? 'php' : 'json',
            deleteWithContent: asBool(
              (o.backendFields as Record<string, unknown>).deleteWithContent,
              false,
            ),
          }
        : undefined,
    activeTheme: asString(o.activeTheme),
    activeHeader: asString(o.activeHeader),
    activeFooter: asString(o.activeFooter),
    pageEditorStyle: 'beekiricode',
    // Default PHP. React only when explicitly set.
    frontendRuntime: o.frontendRuntime === 'react' ? 'react' : 'php',
    cacheEpoch: typeof o.cacheEpoch === 'number' && o.cacheEpoch > 0 ? o.cacheEpoch : undefined,
    beeCookies: o.beeCookies !== undefined ? parseBeeCookies(o.beeCookies) : undefined,
    googleAnalytics:
      o.googleAnalytics !== undefined ? parseGoogleAnalytics(o.googleAnalytics) : undefined,
    connector: o.connector !== undefined ? parseConnector(o.connector) : undefined,
    translations: o.translations !== undefined ? parseTranslations(o.translations) : undefined,
    customHeadHtml:
      o.customHeadHtml !== undefined ? normalizeSiteCodeHtml(o.customHeadHtml) : undefined,
    customBodyHtml:
      o.customBodyHtml !== undefined ? normalizeSiteCodeHtml(o.customBodyHtml) : undefined,
    customFooterHtml:
      o.customFooterHtml !== undefined ? normalizeSiteCodeHtml(o.customFooterHtml) : undefined,
    extensions: o.extensions !== undefined ? parseExtensions(o.extensions) : undefined,
    hub: parseHub(o.hub),
    themeContent: parseThemeContent(o.themeContent),
    themeState: parseThemeState(o.themeState),
    network: parseNetwork(o.network),
  };
}

export function resolveFaviconUrl(raw?: string | null): string {
  const v = (raw ?? '').trim();
  return v && !RETIRED_FAVICONS.has(v) ? v : DEFAULT_FAVICON_PATH;
}

export function defaultMenuItems(): MenuItemOption[] {
  return JSON.parse(JSON.stringify(DEFAULT_MENU)) as MenuItemOption[];
}

/** Enabled menu items only (recursive) — what the public site renders. */
export function publicMenuItems(opts: SiteOptions): MenuItemOption[] {
  const prune = (items: MenuItemOption[]): MenuItemOption[] =>
    items
      .filter((m) => m.enabled)
      .map((m) => ({
        ...m,
        children: m.children?.length ? prune(m.children) : undefined,
      }));
  return prune(opts.menuItems?.length ? opts.menuItems : defaultMenuItems());
}

export function defaultMediaSettings(): MediaSettingsOption {
  return JSON.parse(JSON.stringify(DEFAULT_MEDIA)) as MediaSettingsOption;
}

export function mergeSiteOptions(existing: unknown, patch: Partial<SiteOptions>): SiteOptions {
  const base = { ...readOptions(existing) };
  for (const key of Object.keys(patch) as (keyof SiteOptions)[]) {
    if (patch[key] !== undefined) {
      (base as Record<string, unknown>)[key] = patch[key];
    }
  }
  return base;
}
