import { isIP } from 'net';
import { config } from '../../config/env';
import { getSelfUrl } from '../../config/runtime';
import { isLoopbackHost } from '../../utils/loopback';
import { readSettings, writeSettings } from '../migration/storage';

/**
 * Which kind of site this is: local, staging or production. A store theme licence covers one
 * of each (same owner e-mail), so the Hub needs to know. Set in Settings → Migration; until
 * then it is worked out from the site's address. Kept outside the database, so a database
 * migration never turns staging into "production".
 */
export const SITE_ENVIRONMENTS = ['local', 'staging', 'production'] as const;
export type SiteEnvironment = (typeof SITE_ENVIRONMENTS)[number];

export function isSiteEnvironment(value: unknown): value is SiteEnvironment {
  return typeof value === 'string' && (SITE_ENVIRONMENTS as readonly string[]).includes(value);
}

function isPrivateIpv4(host: string): boolean {
  if (isIP(host) !== 4) return false;
  const [a, b] = host.split('.').map(Number);
  return a === 10 || a === 127 || (a === 192 && b === 168) || (a === 172 && b >= 16 && b <= 31) || (a === 169 && b === 254);
}

export function detectEnvironment(url: string | null | undefined): SiteEnvironment {
  let host = '';
  try {
    host = url ? new URL(url).hostname.toLowerCase() : '';
  } catch {
    host = '';
  }
  if (!host || isLoopbackHost(host) || isPrivateIpv4(host) || /\.(local|test|localhost)$/.test(host)) return 'local';
  if (/^(staging|stage|stg|dev|develop|test|testing|uat|qa|preview)[.-]/.test(host) || /[.-](staging|stage|stg)[.-]/.test(host)) {
    return 'staging';
  }
  return 'production';
}

/** The public address of this site: APP_URL, else the address a request came in on, else the local port. */
export function siteAddress(requestOrigin?: string | null): string | null {
  return config.urls.app ?? requestOrigin ?? getSelfUrl() ?? null;
}

export function siteEnvironment(requestOrigin?: string | null): {
  value: SiteEnvironment;
  chosen: SiteEnvironment | null;
  detected: SiteEnvironment;
} {
  const chosen = readSettings().environment ?? null;
  const detected = detectEnvironment(siteAddress(requestOrigin));
  return { value: chosen ?? detected, chosen, detected };
}

export function setSiteEnvironment(value: SiteEnvironment | null) {
  const s = readSettings();
  s.environment = value;
  writeSettings(s);
}
