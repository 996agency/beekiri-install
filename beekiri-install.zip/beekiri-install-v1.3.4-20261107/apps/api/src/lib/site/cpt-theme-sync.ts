import { mkdir, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import {
  DEFAULT_THEME_SLUG,
  PARENT_THEME_SLUG,
  resolveClientThemeDir,
  resolveThemeDir,
  resolveThemesRoot,
} from '../themes/theme-registry';

/** A PHP single-quoted string literal: only \ and ' need escaping, nothing is interpolated. */
function phpString(value: string): string {
  return `'${value.replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;
}

/** Text inside a /* … *\/ docblock must not be able to close it. */
function phpComment(value: string): string {
  return value.replace(/\*\//g, '* /').replace(/[\r\n]+/g, ' ');
}

export type CptThemeMeta = {
  slug: string;
  singular: string;
  plural: string;
  hasArchive: boolean;
  public: boolean;
  archiveDesign: string;
  singleDesign: string;
};

function cptDir(themeDir: string, slug: string) {
  return join(themeDir, 'cpts', slug);
}

async function ensureClientThemeDir(activeSlug?: string | null): Promise<string> {
  const dir = resolveClientThemeDir(activeSlug);
  await mkdir(dir, { recursive: true });
  return dir;
}

/**
 * Write archive + single PHP stubs under the **client** theme (never parent),
 * so Beekiri can ship/update `beekiri` without wiping site-specific CPT files.
 */
export async function syncCptThemeTemplates(
  cpt: CptThemeMeta,
  activeThemeSlug?: string | null,
): Promise<void> {
  if (!cpt.public) {
    await removeCptThemeTemplates(cpt.slug, undefined, activeThemeSlug);
    return;
  }
  const dir = cptDir(await ensureClientThemeDir(activeThemeSlug), cpt.slug);
  await mkdir(dir, { recursive: true });

  const meta = {
    slug: cpt.slug,
    singular: cpt.singular,
    plural: cpt.plural,
    hasArchive: cpt.hasArchive,
    archiveDesign: cpt.archiveDesign || 'list',
    singleDesign: cpt.singleDesign || 'default',
    syncedAt: new Date().toISOString(),
  };

  await writeFile(join(dir, 'meta.json'), `${JSON.stringify(meta, null, 2)}\n`, 'utf8');

  if (cpt.hasArchive) {
    await writeFile(
      join(dir, 'archive.php'),
      `<?php
/**
 * Archive template for ${phpComment(cpt.plural)} (/${cpt.slug}/).
 * Design: ${cpt.archiveDesign || 'list'}
 * Rendered by the Beekiri front app; keep this file for theme sync / PHP hosts.
 */
?>
<main id="main" class="bk-main bk-cpt-archive bk-cpt-archive--${cpt.archiveDesign || 'list'}">
  <h1><?php echo htmlspecialchars(${phpString(cpt.plural)}, ENT_QUOTES, 'UTF-8'); ?></h1>
  <div class="bk-cpt-archive__list">
    <!-- Entries injected by the front renderer -->
  </div>
</main>
`,
      'utf8',
    );
  } else {
    await rm(join(dir, 'archive.php'), { force: true });
  }

  await writeFile(
    join(dir, 'single.php'),
    `<?php
/**
 * Single template for ${phpComment(cpt.singular)} (/${cpt.slug}/{slug}/).
 * Design: ${cpt.singleDesign || 'default'}
 */
?>
<main id="main" class="bk-main bk-cpt-single bk-cpt-single--${cpt.singleDesign || 'default'}">
  <article>
    <h1><?php echo htmlspecialchars($title ?? ${phpString(cpt.singular)}, ENT_QUOTES, 'UTF-8'); ?></h1>
    <div class="bk-cpt-single__body">
      <?php echo $content ?? ''; ?>
    </div>
  </article>
</main>
`,
    'utf8',
  );
}

/** Remove CPT stub folder from client theme (and parent leftovers if any). */
export async function removeCptThemeTemplates(
  slug: string,
  previousSlug?: string,
  activeThemeSlug?: string | null,
): Promise<void> {
  const targets = new Set<string>();
  const clientDir = await ensureClientThemeDir(activeThemeSlug);
  for (const s of [slug, previousSlug].filter(Boolean) as string[]) {
    targets.add(cptDir(clientDir, s));
    const parent = resolveThemeDir(PARENT_THEME_SLUG);
    if (parent) targets.add(cptDir(parent, s));
    targets.add(join(resolveThemesRoot(), DEFAULT_THEME_SLUG, 'cpts', s));
  }
  await Promise.all(
    [...targets].map((dir) => rm(dir, { recursive: true, force: true }).catch(() => undefined)),
  );
}
