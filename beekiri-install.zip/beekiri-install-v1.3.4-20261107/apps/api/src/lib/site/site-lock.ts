import { createHmac } from 'node:crypto';
import cookieParser from 'cookie-parser';
import express, { type NextFunction, type Request, type Response } from 'express';
import rateLimit from 'express-rate-limit';
import { config } from '../../config/env';
import { sessionToken } from '../../middleware/authenticate';
import type { SiteAccess } from '../../models/site.model';
import { authService } from '../../services/auth.service';
import { safeEqual, verifyPassword } from '../../utils/crypto';
import { resolveAdminBasePath } from './admin-base-cache';
import { INTERNAL_HEADER, INTERNAL_TOKEN, siteLockFor, type SiteLock } from './current-site';

/**
 * Password protection per site (Settings → Sites → Password). While it is on, the website and
 * its public API answer only to:
 *
 *   - visitors who typed the password (a signed cookie for this site that lasts 30 days);
 *   - people signed in to this site's admin;
 *   - the website's own server-side calls (internal token).
 *
 * Everyone else gets the password page. The admin, sign-in, webhooks and the built JS/CSS stay
 * reachable. A new password changes the cookie secret, so every visitor has to type it again.
 */

export const ACCESS_COOKIE = config.auth.cookieSecure ? '__Host-beekiri_site_access' : 'beekiri_site_access';
export const UNLOCK_PATH = '/_beekiri/unlock';
/** A path no page has: the website answers it with the theme's 404 page. */
const NOT_FOUND_PATH = '/_beekiri/not-found';
/** The query of the retired client link (`/?access=<token>`). */
const RETIRED_LINK_PARAM = 'access';

const COOKIE_DAYS = 30;

/** Anyone may reach these on a protected site: sign-in, health checks, payment webhooks. */
const OPEN_API = [/^\/api\/auth(\/|$)/, /^\/api\/health(\/|$)/, /^\/api\/install(\/|$)/, /^\/api\/shop\/webhooks\//];
/** Built website assets (no content) and the dev server's live reload. */
const OPEN_ASSETS = [/^\/_next\/static\//, /^\/_next\/webpack-hmr/, /^\/__nextjs/];

const parseCookies = cookieParser();
const parseForm = express.urlencoded({ extended: false, limit: '4kb' });

/** The cookie value that unlocks `siteId` (changes with the site's secret). */
export function accessCookieValue(siteId: string, access: SiteAccess): string {
  // v2: cookies from the retired client link (v1) no longer open the site.
  return createHmac('sha256', access.secret).update(`site-access:v2:${siteId}`).digest('base64url');
}

/** Cookie for tools that visit a protected site as a visitor (heatmap screenshots). */
export async function accessCookieFor(siteId: string): Promise<{ name: string; value: string } | null> {
  const lock = await siteLockFor(siteId);
  return lock ? { name: ACCESS_COOKIE, value: accessCookieValue(siteId, lock.access) } : null;
}

function setAccessCookie(res: Response, siteId: string, access: SiteAccess): void {
  res.cookie(ACCESS_COOKIE, accessCookieValue(siteId, access), {
    path: '/',
    httpOnly: true,
    sameSite: 'lax',
    secure: config.auth.cookieSecure,
    maxAge: COOKIE_DAYS * 24 * 60 * 60 * 1000,
  });
}

function hasAccessCookie(req: Request, siteId: string, access: SiteAccess): boolean {
  const raw: unknown = req.cookies?.[ACCESS_COOKIE];
  return typeof raw === 'string' && raw !== '' && safeEqual(raw, accessCookieValue(siteId, access));
}

function isInternal(req: Request): boolean {
  const token = req.get(INTERNAL_HEADER);
  return Boolean(token && safeEqual(token, INTERNAL_TOKEN));
}

async function isAdminPath(path: string): Promise<boolean> {
  if (path === '/admin' || path.startsWith('/admin/')) return true;
  const base = await resolveAdminBasePath().catch(() => '/admin');
  return path === base || path.startsWith(`${base}/`);
}

/** Only a path on this site (no `//host`), so the form can't send visitors elsewhere. */
function safeNext(raw: unknown): string {
  const next = typeof raw === 'string' ? raw : '/';
  return /^\/(?![/\\])/.test(next) && next.length <= 2000 ? next : '/';
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);
}

function lockPage(res: Response, lock: SiteLock, next: string, message = '', status = 401): void {
  const title = escapeHtml(lock.title || 'This site');
  res
    .status(status)
    .set({
      'Cache-Control': 'no-store',
      'X-Robots-Tag': 'noindex, nofollow',
      'Referrer-Policy': 'no-referrer',
      'Content-Security-Policy':
        "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'",
    })
    .type('html')
    .send(`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>${title} — password required</title>
<style>
  :root { color-scheme: light dark; --bg: #f5f5f7; --card: #fff; --text: #202734; --muted: #5d6370; --line: #d0d0d2; --btn: #202734; --btn-text: #fff; --error: #b42318; }
  @media (prefers-color-scheme: dark) { :root { --bg: #14171d; --card: #1d2129; --text: #f2f3f5; --muted: #a3a8b3; --line: #3a3f4a; --btn: #f2f3f5; --btn-text: #202734; --error: #ff8a80; } }
  * { box-sizing: border-box; }
  body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px 16px; background: var(--bg); color: var(--text); font: 15px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
  main { width: 100%; max-width: 380px; background: var(--card); border: 1px solid var(--line); border-radius: 8px; padding: 32px 28px; }
  h1 { margin: 0 0 4px; font-size: 20px; line-height: 1.3; }
  p { margin: 0 0 20px; color: var(--muted); }
  label { display: block; font-weight: 600; margin-bottom: 6px; }
  input { width: 100%; padding: 10px 12px; font: inherit; color: var(--text); background: transparent; border: 1px solid var(--line); border-radius: 8px; }
  input:focus { outline: 2px solid var(--btn); outline-offset: 1px; }
  button { width: 100%; margin-top: 14px; padding: 11px 14px; font: inherit; font-weight: 600; color: var(--btn-text); background: var(--btn); border: 0; border-radius: 8px; cursor: pointer; }
  .error { margin: 0 0 14px; color: var(--error); }
</style>
</head>
<body>
<main>
  <h1>${title}</h1>
  <p>This site is password protected. Enter the password to view it.</p>
  ${message ? `<p class="error" role="alert">${escapeHtml(message)}</p>` : ''}
  <form method="post" action="${UNLOCK_PATH}">
    <input type="hidden" name="next" value="${escapeHtml(next)}">
    <label for="bk-password">Password</label>
    <input id="bk-password" name="password" type="password" autocomplete="current-password" required autofocus maxlength="200">
    <button type="submit">View site</button>
  </form>
</main>
</body>
</html>`);
}

/** Password tries per address: enough for typos, too few to guess. */
const unlockLimit = rateLimit({
  windowMs: 15 * 60_000,
  limit: 10,
  skipSuccessfulRequests: true,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  handler: (req, res) => {
    void siteLockFor(req.site?.id ?? '').then((lock) => {
      if (lock) lockPage(res, lock, safeNext(req.body?.next), 'Too many tries. Please wait a few minutes and try again.', 429);
      else res.status(429).type('text').send('Too many tries.');
    });
  },
});

async function unlock(req: Request, res: Response, lock: SiteLock): Promise<void> {
  const siteId = req.site!.id;
  const next = safeNext(req.body?.next);
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  if (password && (await verifyPassword(lock.access.passwordHash, password))) {
    setAccessCookie(res, siteId, lock.access);
    res.redirect(303, next);
    return;
  }
  lockPage(res, lock, next, 'That password is not right. Please try again.');
}

/** Mounted right after `siteContext`, before /api, /uploads, the admin and the website. */
export async function siteLock(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const site = req.site;
    if (!site) return next();

    // Sites are opened with the password only: an old client link is a page that doesn't exist.
    if (
      RETIRED_LINK_PARAM in req.query &&
      !req.path.startsWith('/api/') &&
      !isInternal(req) &&
      !(await isAdminPath(req.path))
    ) {
      req.url = NOT_FOUND_PATH;
    }

    const lock = await siteLockFor(site.id);
    if (!lock) return next();
    // What gets past the lock is private: /uploads sends it with `Cache-Control: private`.
    res.locals.siteLocked = true;

    const path = req.path;
    if (isInternal(req) || OPEN_ASSETS.some((re) => re.test(path)) || OPEN_API.some((re) => re.test(path))) return next();
    if (await isAdminPath(path)) return next();

    await new Promise<void>((done, fail) => parseCookies(req, res, (err?: unknown) => (err ? fail(err) : done())));

    if (path === UNLOCK_PATH && req.method === 'POST') {
      await new Promise<void>((done, fail) => parseForm(req, res, (err?: unknown) => (err ? fail(err) : done())));
      unlockLimit(req, res, () => void unlock(req, res, lock).catch(next));
      return;
    }

    if (hasAccessCookie(req, site.id, lock.access)) return next();
    if (await authService.resolveSession(sessionToken(req))) return next();

    if (path === '/robots.txt') {
      res.status(200).type('text').set('Cache-Control', 'no-store').send('User-agent: *\nDisallow: /\n');
      return;
    }
    if (path.startsWith('/api/')) {
      res.status(401).json({ statusCode: 401, error: 'Unauthorized', message: 'This site is password protected.' });
      return;
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.status(401).type('text').send('This site is password protected.');
      return;
    }
    lockPage(res, lock, safeNext(req.originalUrl));
  } catch (error) {
    next(error);
  }
}
