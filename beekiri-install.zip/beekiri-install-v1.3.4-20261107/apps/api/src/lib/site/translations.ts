import { normalizeLanguageCode, worldLanguage, type WorldLanguage } from './languages';

/**
 * Settings → Translation. Local string translation (no external service at runtime):
 * the site is written in `defaultLanguage`, each extra language is served under its
 * own path prefix (`/de/about`) and visible text is swapped from `strings[lang]`.
 */
export type TranslationsOptions = {
  /** Language the content is written in — translations are keyed by its texts. */
  defaultLanguage: string;
  /** Enabled language served on the plain address (`/about`); the rest get `/xx`. */
  primaryLanguage: string;
  /** Enabled languages in switcher order — always includes the default. */
  languages: string[];
  /** Source-language strings collected by "Scan site" or added by hand. */
  sources: string[];
  /** lang → source → translation. */
  strings: Record<string, Record<string, string>>;
};

/** Menu item `source` for the language switcher (Settings → Permalinks). */
export const LANGUAGE_MENU_SOURCE = 'languages';

export const TRANSLATION_LIMITS = {
  languages: 60,
  sources: 5000,
  text: 2000,
} as const;

export const DEFAULT_TRANSLATIONS: TranslationsOptions = {
  defaultLanguage: 'en',
  primaryLanguage: 'en',
  languages: ['en'],
  sources: [],
  strings: {},
};

function cleanText(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const text = raw.replace(/\u0000/g, '').trim();
  if (!text || text.length > TRANSLATION_LIMITS.text) return null;
  return text;
}

export function parseTranslations(raw: unknown): TranslationsOptions {
  const o = raw && typeof raw === 'object' && !Array.isArray(raw) ? (raw as Record<string, unknown>) : {};
  const defaultLanguage = normalizeLanguageCode(o.defaultLanguage) ?? DEFAULT_TRANSLATIONS.defaultLanguage;

  const languages: string[] = [defaultLanguage];
  for (const value of Array.isArray(o.languages) ? o.languages : []) {
    const code = normalizeLanguageCode(value);
    if (code && !languages.includes(code)) languages.push(code);
    if (languages.length >= TRANSLATION_LIMITS.languages) break;
  }

  const sources: string[] = [];
  const seen = new Set<string>();
  for (const value of Array.isArray(o.sources) ? o.sources : []) {
    const text = cleanText(value);
    if (!text || seen.has(text)) continue;
    seen.add(text);
    sources.push(text);
    if (sources.length >= TRANSLATION_LIMITS.sources) break;
  }

  const strings: Record<string, Record<string, string>> = {};
  const rawStrings =
    o.strings && typeof o.strings === 'object' && !Array.isArray(o.strings)
      ? (o.strings as Record<string, unknown>)
      : {};
  for (const [langRaw, mapRaw] of Object.entries(rawStrings)) {
    const lang = normalizeLanguageCode(langRaw);
    // Kept even for switched-off or primary languages, so switching back restores them.
    if (!lang) continue;
    if (!mapRaw || typeof mapRaw !== 'object' || Array.isArray(mapRaw)) continue;
    const map: Record<string, string> = {};
    for (const [src, tr] of Object.entries(mapRaw as Record<string, unknown>)) {
      const source = cleanText(src);
      const translation = cleanText(tr);
      if (source && translation) map[source] = translation;
    }
    if (Object.keys(map).length) strings[lang] = map;
  }

  const primary = normalizeLanguageCode(o.primaryLanguage);
  const primaryLanguage = primary && languages.includes(primary) ? primary : defaultLanguage;

  return { defaultLanguage, primaryLanguage, languages, sources, strings };
}

export type PublicLanguage = Pick<WorldLanguage, 'code' | 'name' | 'native' | 'rtl'> & {
  /** URL prefix: `''` for the default language, `/de` otherwise. */
  prefix: string;
};

export function publicLanguages(opts: TranslationsOptions): PublicLanguage[] {
  return opts.languages
    .map((code) => worldLanguage(code))
    .filter((l): l is WorldLanguage => Boolean(l))
    .map((l) => ({
      code: l.code,
      name: l.name,
      native: l.native,
      rtl: l.rtl,
      prefix: l.code === opts.primaryLanguage ? '' : `/${l.code}`,
    }));
}

/** What the website needs to render one language. */
export function publicTranslations(opts: TranslationsOptions, lang: string | undefined) {
  const code = normalizeLanguageCode(lang);
  const current = code && opts.languages.includes(code) ? code : opts.primaryLanguage;
  return {
    defaultLanguage: opts.defaultLanguage,
    primaryLanguage: opts.primaryLanguage,
    language: current,
    languages: publicLanguages(opts),
    strings: current === opts.defaultLanguage ? {} : (opts.strings[current] ?? {}),
  };
}
