/** ISO country from CDN headers, timezone, or locale. Never stores an IP. */
import { config } from '../../config/env';

const TZ_COUNTRY: Record<string, string> = {
  'Africa/Cairo': 'EG',
  'Africa/Casablanca': 'MA',
  'Africa/Johannesburg': 'ZA',
  'Africa/Lagos': 'NG',
  'Africa/Nairobi': 'KE',
  'America/Argentina/Buenos_Aires': 'AR',
  'America/Bogota': 'CO',
  'America/Caracas': 'VE',
  'America/Chicago': 'US',
  'America/Denver': 'US',
  'America/Los_Angeles': 'US',
  'America/Mexico_City': 'MX',
  'America/New_York': 'US',
  'America/Phoenix': 'US',
  'America/Santiago': 'CL',
  'America/Sao_Paulo': 'BR',
  'America/Toronto': 'CA',
  'America/Vancouver': 'CA',
  'Asia/Bangkok': 'TH',
  'Asia/Dubai': 'AE',
  'Asia/Hong_Kong': 'HK',
  'Asia/Jakarta': 'ID',
  'Asia/Jerusalem': 'IL',
  'Asia/Karachi': 'PK',
  'Asia/Kolkata': 'IN',
  'Asia/Kuwait': 'KW',
  'Asia/Manila': 'PH',
  'Asia/Seoul': 'KR',
  'Asia/Shanghai': 'CN',
  'Asia/Singapore': 'SG',
  'Asia/Taipei': 'TW',
  'Asia/Tokyo': 'JP',
  'Australia/Melbourne': 'AU',
  'Australia/Perth': 'AU',
  'Australia/Sydney': 'AU',
  'Europe/Amsterdam': 'NL',
  'Europe/Athens': 'GR',
  'Europe/Belgrade': 'RS',
  'Europe/Berlin': 'DE',
  'Europe/Bratislava': 'SK',
  'Europe/Brussels': 'BE',
  'Europe/Bucharest': 'RO',
  'Europe/Budapest': 'HU',
  'Europe/Copenhagen': 'DK',
  'Europe/Dublin': 'IE',
  'Europe/Helsinki': 'FI',
  'Europe/Istanbul': 'TR',
  'Europe/Kiev': 'UA',
  'Europe/Kyiv': 'UA',
  'Europe/Lisbon': 'PT',
  'Europe/Ljubljana': 'SI',
  'Europe/London': 'GB',
  'Europe/Luxembourg': 'LU',
  'Europe/Madrid': 'ES',
  'Europe/Malta': 'MT',
  'Europe/Moscow': 'RU',
  'Europe/Oslo': 'NO',
  'Europe/Paris': 'FR',
  'Europe/Podgorica': 'ME',
  'Europe/Prague': 'CZ',
  'Europe/Riga': 'LV',
  'Europe/Rome': 'IT',
  'Europe/Sarajevo': 'BA',
  'Europe/Skopje': 'MK',
  'Europe/Sofia': 'BG',
  'Europe/Stockholm': 'SE',
  'Europe/Tallinn': 'EE',
  'Europe/Tirane': 'AL',
  'Europe/Vienna': 'AT',
  'Europe/Vilnius': 'LT',
  'Europe/Warsaw': 'PL',
  'Europe/Zagreb': 'HR',
  'Europe/Zurich': 'CH',
  'Pacific/Auckland': 'NZ',
  'Pacific/Honolulu': 'US',
  'US/Arizona': 'US',
  'US/Central': 'US',
  'US/Eastern': 'US',
  'US/Mountain': 'US',
  'US/Pacific': 'US',
};

function asIso2(raw: string | undefined | null): string | null {
  const code = (raw ?? '').trim().toUpperCase();
  if (/^[A-Z]{2}$/.test(code) && code !== 'XX' && code !== 'T1' && code !== 'ZZ') return code;
  return null;
}

export function countryFromTimeZone(tz: string | undefined | null): string | null {
  const key = (tz ?? '').trim();
  if (!key) return null;
  return asIso2(TZ_COUNTRY[key] ?? TZ_COUNTRY[key.replace(' ', '_')]);
}

export function countryFromLocale(raw: string | undefined | null): string | null {
  if (!raw) return null;
  const first = raw.split(',')[0]?.trim().split(';')[0] ?? '';
  if (!first) return null;
  try {
    const region = new Intl.Locale(first.replace('_', '-')).region;
    return asIso2(region);
  } catch {
    const m = first.replace('_', '-').match(/-([A-Za-z]{2})$/);
    return asIso2(m?.[1]);
  }
}

export function countryFromRequest(
  headers: { get(name: string): string | undefined },
  hint?: { timeZone?: string; locale?: string },
): string | null {
  // Any client can send these headers; they only mean something when a trusted proxy
  // or CDN in front of Beekiri sets them (TRUST_PROXY set; the 'loopback' default only
  // vouches for a local web server's addresses, not for these).
  const header = config.server.trustProxy && config.server.trustProxy !== 'loopback'
    ? headers.get('cf-ipcountry') ||
      headers.get('x-vercel-ip-country') ||
      headers.get('cloudfront-viewer-country') ||
      headers.get('x-country-code') ||
      headers.get('geoip-country-code')
    : undefined;
  return (
    asIso2(header) ||
    countryFromTimeZone(hint?.timeZone) ||
    countryFromLocale(hint?.locale) ||
    countryFromLocale(headers.get('accept-language'))
  );
}
