/**
 * World languages Settings → Translation can enable. Codes follow the BCP 47 tags the
 * free MyMemory translator accepts; names come from ICU so every entry has its
 * English and native (endonym) label without a hand-kept table.
 */

const CODES = [
  'af', 'sq', 'am', 'ar', 'hy', 'as', 'ay', 'az', 'bm', 'eu', 'be', 'bn', 'bho', 'bs', 'bg',
  'ca', 'ceb', 'ny', 'zh-CN', 'zh-TW', 'co', 'hr', 'cs', 'da', 'dv', 'doi', 'nl', 'en', 'eo',
  'et', 'ee', 'fil', 'fi', 'fr', 'fy', 'gl', 'ka', 'de', 'el', 'gn', 'gu', 'ht', 'ha', 'haw',
  'he', 'hi', 'hmn', 'hu', 'is', 'ig', 'ilo', 'id', 'ga', 'it', 'ja', 'jv', 'kn', 'kk', 'km',
  'rw', 'gom', 'ko', 'kri', 'ku', 'ckb', 'ky', 'lo', 'la', 'lv', 'ln', 'lt', 'lg', 'lb', 'mk',
  'mai', 'mg', 'ms', 'ml', 'mt', 'mi', 'mr', 'mni-Mtei', 'lus', 'mn', 'my', 'ne', 'no', 'or',
  'om', 'ps', 'fa', 'pl', 'pt', 'pt-BR', 'pa', 'qu', 'ro', 'ru', 'sm', 'sa', 'gd', 'nso', 'sr',
  'sr-Latn', 'st', 'sn', 'sd', 'si', 'sk', 'sl', 'so', 'es', 'su', 'sw', 'sv', 'tg', 'ta', 'tt',
  'te', 'th', 'ti', 'ts', 'tr', 'tk', 'ak', 'uk', 'ur', 'ug', 'uz', 'vi', 'cy', 'xh', 'yi',
  'yo', 'zu',
] as const;

const RTL = new Set(['ar', 'he', 'fa', 'ur', 'ps', 'sd', 'ug', 'dv', 'yi', 'ckb']);

/** ICU labels that read oddly in a language menu. */
const OVERRIDES: Record<string, { name?: string; native?: string }> = {
  'zh-CN': { name: 'Chinese (Simplified)', native: '简体中文' },
  'zh-TW': { name: 'Chinese (Traditional)', native: '繁體中文' },
  pt: { name: 'Portuguese (Portugal)', native: 'Português' },
  'pt-BR': { name: 'Portuguese (Brazil)', native: 'Português (Brasil)' },
  no: { name: 'Norwegian', native: 'Norsk' },
  ku: { name: 'Kurdish (Kurmanji)', native: 'Kurdî' },
  ckb: { name: 'Kurdish (Sorani)' },
  'mni-Mtei': { name: 'Meiteilon (Manipuri)' },
};

export type WorldLanguage = {
  code: string;
  /** English name, e.g. `German`. */
  name: string;
  /** Endonym, e.g. `Deutsch`. */
  native: string;
  rtl: boolean;
};

function label(locale: string, code: string): string {
  try {
    return new Intl.DisplayNames([locale], { type: 'language' }).of(code) ?? code;
  } catch {
    return code;
  }
}

function capitalize(text: string, locale: string): string {
  if (!text) return text;
  try {
    return text.charAt(0).toLocaleUpperCase(locale) + text.slice(1);
  } catch {
    return text.charAt(0).toUpperCase() + text.slice(1);
  }
}

export const WORLD_LANGUAGES: readonly WorldLanguage[] = CODES.map((code) => {
  const o = OVERRIDES[code] ?? {};
  return {
    code,
    name: o.name ?? label('en', code),
    native: o.native ?? capitalize(label(code, code), code),
    rtl: RTL.has(code),
  };
}).sort((a, b) => a.name.localeCompare(b.name, 'en'));

const BY_CODE = new Map(WORLD_LANGUAGES.map((l) => [l.code.toLowerCase(), l]));

/** Canonical code (`zh-cn` → `zh-CN`) or null when the language is unknown. */
export function normalizeLanguageCode(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  return BY_CODE.get(raw.trim().toLowerCase())?.code ?? null;
}

export function worldLanguage(code: string): WorldLanguage | null {
  return BY_CODE.get(code.toLowerCase()) ?? null;
}
