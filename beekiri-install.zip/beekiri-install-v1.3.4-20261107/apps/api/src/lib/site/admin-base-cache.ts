import { Site, SiteSettings } from '../../models';
import {
  DEFAULT_ADMIN_BASE_PATH,
  DEFAULT_ADMIN_LOGIN_SLUG,
  normalizeAdminBasePath,
  normalizeAdminLoginSlug,
} from './admin-login';
import { currentSiteId } from './current-site';
import { readOptions } from './site-options';

type Entry = { base: string; slug: string; at: number };

/** Per site (multisite: each site can move its admin); key '' = no request context. */
const cache = new Map<string, Entry>();
const inflight = new Map<string, Promise<Entry>>();
const TTL_MS = 5_000;

/** Force the next resolveAdminBasePath() to re-read from the DB (the current site's entry). */
export function bumpAdminBasePathCache(next?: string) {
  const key = currentSiteId() ?? '';
  const entry = cache.get(key);
  if (entry) {
    if (next) entry.base = normalizeAdminBasePath(next);
    entry.at = 0;
  }
  if (!next) cache.clear();
}

async function load(key: string): Promise<Entry> {
  const hit = cache.get(key);
  if (hit && hit.at > 0 && Date.now() - hit.at < TTL_MS) return hit;
  const running = inflight.get(key);
  if (running) return running;

  const job = (async () => {
    const entry: Entry = hit ?? { base: DEFAULT_ADMIN_BASE_PATH, slug: DEFAULT_ADMIN_LOGIN_SLUG, at: 0 };
    try {
      const include = [{ model: SiteSettings, as: 'settings' }];
      const site = key
        ? await Site.findByPk(key, { include })
        : await Site.findOne({ include, order: [['isPrimary', 'DESC'], ['createdAt', 'ASC']] });
      const opts = readOptions(site?.settings?.options);
      entry.base = normalizeAdminBasePath(opts.adminBasePath ?? DEFAULT_ADMIN_BASE_PATH);
      entry.slug = normalizeAdminLoginSlug(opts.adminLoginSlug ?? DEFAULT_ADMIN_LOGIN_SLUG);
    } catch {
      /* keep previous / default while DB is down */
    } finally {
      entry.at = Date.now();
      cache.set(key, entry);
      inflight.delete(key);
    }
    return entry;
  })();
  inflight.set(key, job);
  return job;
}

/** Current admin SPA mount path (`/admin` by default) of the request's site. */
export async function resolveAdminBasePath(): Promise<string> {
  return (await load(currentSiteId() ?? '')).base;
}

/** Admin mount + sign-in slug, for the admin page itself (never a public API). */
export async function resolveAdminEntry(): Promise<{ basePath: string; loginSlug: string }> {
  const entry = await load(currentSiteId() ?? '');
  return { basePath: entry.base, loginSlug: entry.slug };
}

export function peekAdminBasePath(): string {
  return cache.get(currentSiteId() ?? '')?.base ?? DEFAULT_ADMIN_BASE_PATH;
}
