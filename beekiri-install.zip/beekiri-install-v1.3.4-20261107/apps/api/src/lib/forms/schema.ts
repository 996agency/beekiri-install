/**
 * Bee Forms definitions: field and settings types, and the parser that turns whatever the
 * admin sends into a clean, bounded definition. Pure; no database access.
 */
import { defaultIntegrations, parseIntegrations, type FormIntegrations } from './integrations';

export const FORM_FIELD_TYPES = [
  'text',
  'email',
  'phone',
  'url',
  'textarea',
  'number',
  'select',
  'checkbox',
  'radio',
  'date',
  'hidden',
  'file',
  'consent',
  'section',
  'page',
] as const;

export type FormFieldType = (typeof FORM_FIELD_TYPES)[number];

/** Fields that never carry a value (layout only). */
export const FORM_NO_VALUE_TYPES: ReadonlySet<FormFieldType> = new Set(['section', 'page']);

export const FORM_FIELD_WIDTHS = ['full', 'half', 'third'] as const;
export type FormFieldWidth = (typeof FORM_FIELD_WIDTHS)[number];

export const CONDITION_OPS = ['is', 'is_not', 'contains', 'not_contains', 'empty', 'not_empty', 'gt', 'lt'] as const;
export type ConditionOp = (typeof CONDITION_OPS)[number];

export type ConditionRule = { field: string; op: ConditionOp; value: string };

export type FieldCondition = {
  action: 'show' | 'hide';
  match: 'all' | 'any';
  rules: ConditionRule[];
};

export type FormChoice = { label: string; value: string };

/** File types a visitor may attach; each key expands to a MIME list on the server. */
export const FILE_ACCEPT_KINDS = ['image', 'pdf', 'document', 'spreadsheet', 'archive', 'any'] as const;
export type FileAcceptKind = (typeof FILE_ACCEPT_KINDS)[number];

export type FormField = {
  id: string;
  type: FormFieldType;
  label: string;
  /** Stable key for merge tags and exports (snake_case, unique in the form). */
  name: string;
  placeholder?: string;
  help?: string;
  required?: boolean;
  defaultValue?: string;
  width: FormFieldWidth;
  /** select / checkbox / radio */
  options?: FormChoice[];
  /** select: allow more than one choice */
  multiple?: boolean;
  /** textarea */
  rows?: number;
  /** number / date (ISO date for date) */
  min?: string;
  max?: string;
  /** file */
  accept?: FileAcceptKind[];
  maxFiles?: number;
  /** consent (the sentence next to the box) / section (description under the heading) */
  text?: string;
  /** hidden: 'static' uses defaultValue, the others are filled by the site script */
  hiddenSource?: 'static' | 'page_url' | 'page_title' | 'referrer';
  /** Show the label above the input (default) or hide it (placeholder only). */
  hideLabel?: boolean;
  conditional?: FieldCondition;
};

export type FormConfirmation =
  | { type: 'message'; message: string }
  | { type: 'redirect'; url: string };

export type FormNotification = {
  enabled: boolean;
  /** Comma-separated addresses; may contain merge tags such as {field:email}. */
  to: string;
  subject: string;
  message: string;
  /** Field name whose value becomes Reply-To (usually the visitor's email). */
  replyToField: string;
};

export type FormAutoReply = {
  enabled: boolean;
  /** Field name of the visitor's email (empty = first email field). */
  toField: string;
  subject: string;
  message: string;
};

export type FormSettings = {
  submitLabel: string;
  confirmation: FormConfirmation;
  notification: FormNotification;
  autoReply: FormAutoReply;
  /** Multi-step progress indicator. */
  progress: 'bar' | 'steps' | 'none';
  /** Keep entries in the admin (off = email only). */
  storeEntries: boolean;
  /** Spam: submissions faster than this are refused. */
  minSeconds: number;
  /** Label of the Next / Back buttons on multi-step forms. */
  nextLabel: string;
  backLabel: string;
  /** CRM feeds (HubSpot…). */
  integrations: FormIntegrations;
};

export type FormDefinition = {
  fields: FormField[];
  settings: FormSettings;
};

const LIMITS = { fields: 200, options: 200, rules: 20, label: 200, text: 2000, message: 5000 } as const;

const str = (v: unknown, max: number): string | undefined =>
  typeof v === 'string' ? v.slice(0, max) : typeof v === 'number' ? String(v).slice(0, max) : undefined;
const bool = (v: unknown): boolean | undefined => (typeof v === 'boolean' ? v : undefined);
const num = (v: unknown, min: number, max: number): number | undefined => {
  const n = typeof v === 'number' ? v : typeof v === 'string' && v.trim() ? Number(v) : NaN;
  return Number.isFinite(n) ? Math.min(max, Math.max(min, Math.round(n))) : undefined;
};
const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);

export function randomFieldId(): string {
  return Math.random().toString(36).slice(2, 10);
}

/** snake_case key from a label, e.g. "Your e-mail" → "your_e_mail". */
export function fieldNameFromLabel(label: string): string {
  return label
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 60);
}

function cleanName(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/[^a-z0-9_]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .replace(/^[0-9]+/, '')
    .slice(0, 60);
}

function parseOptions(raw: unknown): FormChoice[] {
  if (!Array.isArray(raw)) return [];
  const out: FormChoice[] = [];
  for (const row of raw.slice(0, LIMITS.options)) {
    if (typeof row === 'string') {
      const label = row.trim().slice(0, LIMITS.label);
      if (label) out.push({ label, value: label });
    } else if (isObj(row)) {
      const label = (str(row.label, LIMITS.label) ?? '').trim();
      const value = (str(row.value, LIMITS.label) ?? '').trim() || label;
      if (label) out.push({ label, value });
    }
  }
  return out;
}

function parseCondition(raw: unknown, knownIds: Set<string>): FieldCondition | undefined {
  if (!isObj(raw) || !Array.isArray(raw.rules)) return undefined;
  const rules: ConditionRule[] = [];
  for (const r of raw.rules.slice(0, LIMITS.rules)) {
    if (!isObj(r)) continue;
    const field = str(r.field, 40) ?? '';
    const op = CONDITION_OPS.includes(r.op as ConditionOp) ? (r.op as ConditionOp) : 'is';
    if (!field || !knownIds.has(field)) continue;
    rules.push({ field, op, value: str(r.value, LIMITS.label) ?? '' });
  }
  if (!rules.length) return undefined;
  return {
    action: raw.action === 'hide' ? 'hide' : 'show',
    match: raw.match === 'any' ? 'any' : 'all',
    rules,
  };
}

export function parseFormFields(raw: unknown): FormField[] {
  if (!Array.isArray(raw)) return [];
  const seenIds = new Set<string>();
  const seenNames = new Set<string>();
  const out: FormField[] = [];
  for (const row of raw.slice(0, LIMITS.fields)) {
    if (!isObj(row)) continue;
    const type: FormFieldType = FORM_FIELD_TYPES.includes(row.type as FormFieldType)
      ? (row.type as FormFieldType)
      : 'text';
    let id = (str(row.id, 40) ?? '').replace(/[^A-Za-z0-9_-]/g, '');
    if (!id || seenIds.has(id)) id = randomFieldId();
    seenIds.add(id);
    const label = (str(row.label, LIMITS.label) ?? '').trim() || defaultLabel(type);
    let name = cleanName(str(row.name, 60) ?? '') || fieldNameFromLabel(label) || type;
    let n = 2;
    const base = name;
    while (seenNames.has(name)) name = `${base}_${n++}`;
    seenNames.add(name);

    const field: FormField = {
      id,
      type,
      label,
      name,
      width: FORM_FIELD_WIDTHS.includes(row.width as FormFieldWidth) ? (row.width as FormFieldWidth) : 'full',
    };
    const opt = <K extends keyof FormField>(k: K, v: FormField[K] | undefined) => {
      if (v !== undefined && v !== '' && v !== false) field[k] = v;
    };
    opt('placeholder', str(row.placeholder, LIMITS.label));
    opt('help', str(row.help, 500));
    opt('required', bool(row.required));
    opt('defaultValue', str(row.defaultValue, LIMITS.text));
    opt('hideLabel', bool(row.hideLabel));
    if (type === 'select' || type === 'checkbox' || type === 'radio') {
      const options = parseOptions(row.options);
      field.options = options.length ? options : [{ label: 'Option 1', value: 'Option 1' }];
      if (type === 'select') opt('multiple', bool(row.multiple));
    }
    if (type === 'textarea') opt('rows', num(row.rows, 2, 20));
    if (type === 'number' || type === 'date') {
      opt('min', str(row.min, 40));
      opt('max', str(row.max, 40));
    }
    if (type === 'file') {
      const accept = Array.isArray(row.accept)
        ? row.accept.filter((a): a is FileAcceptKind => FILE_ACCEPT_KINDS.includes(a as FileAcceptKind))
        : [];
      field.accept = accept.length ? [...new Set(accept)] : ['any'];
      field.maxFiles = num(row.maxFiles, 1, 10) ?? 1;
    }
    if (type === 'consent' || type === 'section') opt('text', str(row.text, LIMITS.text));
    if (type === 'hidden') {
      const src = row.hiddenSource;
      field.hiddenSource =
        src === 'page_url' || src === 'page_title' || src === 'referrer' ? src : 'static';
    }
    out.push(field);
  }
  // Conditions may point at any field, including later ones, so resolve them after the pass.
  const ids = new Set(out.map((f) => f.id));
  for (let i = 0; i < out.length; i++) {
    const rawRow = raw[i];
    if (!isObj(rawRow)) continue;
    const cond = parseCondition(rawRow.conditional, ids);
    if (cond) out[i].conditional = cond;
  }
  return out;
}

export function defaultLabel(type: FormFieldType): string {
  const labels: Record<FormFieldType, string> = {
    text: 'Text',
    email: 'Email',
    phone: 'Phone',
    url: 'Website',
    textarea: 'Message',
    number: 'Number',
    select: 'Dropdown',
    checkbox: 'Checkboxes',
    radio: 'Choice',
    date: 'Date',
    hidden: 'Hidden',
    file: 'File upload',
    consent: 'Consent',
    section: 'Section',
    page: 'Page break',
  };
  return labels[type];
}

export const DEFAULT_NOTIFICATION_MESSAGE = 'New entry for {form_title}\n\n{all_fields}\n\nSent from {page_url} on {date}';
export const DEFAULT_AUTOREPLY_MESSAGE = 'Thanks for getting in touch. We received your message and will get back to you soon.\n\n{all_fields}';
export const DEFAULT_CONFIRMATION = 'Thanks! Your message has been sent.';

export function defaultFormSettings(): FormSettings {
  return {
    submitLabel: 'Send',
    confirmation: { type: 'message', message: DEFAULT_CONFIRMATION },
    notification: {
      enabled: true,
      to: '{admin_email}',
      subject: 'New entry: {form_title}',
      message: DEFAULT_NOTIFICATION_MESSAGE,
      replyToField: '',
    },
    autoReply: {
      enabled: false,
      toField: '',
      subject: 'We received your message',
      message: DEFAULT_AUTOREPLY_MESSAGE,
    },
    progress: 'bar',
    storeEntries: true,
    minSeconds: 3,
    nextLabel: 'Next',
    backLabel: 'Back',
    integrations: defaultIntegrations(),
  };
}

export function parseFormSettings(raw: unknown): FormSettings {
  const d = defaultFormSettings();
  if (!isObj(raw)) return d;
  const c = isObj(raw.confirmation) ? raw.confirmation : {};
  const confirmation: FormConfirmation =
    c.type === 'redirect'
      ? { type: 'redirect', url: (str(c.url, 2000) ?? '').trim() }
      : { type: 'message', message: (str(c.message, LIMITS.message) ?? '').trim() || DEFAULT_CONFIRMATION };
  const n = isObj(raw.notification) ? raw.notification : {};
  const a = isObj(raw.autoReply) ? raw.autoReply : {};
  return {
    submitLabel: (str(raw.submitLabel, 60) ?? '').trim() || d.submitLabel,
    confirmation,
    notification: {
      enabled: bool(n.enabled) ?? d.notification.enabled,
      to: (str(n.to, 1000) ?? '').trim() || d.notification.to,
      subject: (str(n.subject, 300) ?? '').trim() || d.notification.subject,
      message: (str(n.message, LIMITS.message) ?? '').trim() || d.notification.message,
      replyToField: cleanName(str(n.replyToField, 60) ?? ''),
    },
    autoReply: {
      enabled: bool(a.enabled) ?? false,
      toField: cleanName(str(a.toField, 60) ?? ''),
      subject: (str(a.subject, 300) ?? '').trim() || d.autoReply.subject,
      message: (str(a.message, LIMITS.message) ?? '').trim() || d.autoReply.message,
    },
    progress: raw.progress === 'steps' || raw.progress === 'none' ? raw.progress : 'bar',
    storeEntries: bool(raw.storeEntries) ?? true,
    minSeconds: num(raw.minSeconds, 0, 60) ?? d.minSeconds,
    nextLabel: (str(raw.nextLabel, 40) ?? '').trim() || d.nextLabel,
    backLabel: (str(raw.backLabel, 40) ?? '').trim() || d.backLabel,
    integrations: parseIntegrations(raw.integrations),
  };
}

export function parseFormDefinition(raw: { fields?: unknown; settings?: unknown }): FormDefinition {
  return { fields: parseFormFields(raw.fields), settings: parseFormSettings(raw.settings) };
}

/** Fields split into steps at every `page` field (a form without page breaks is one step). */
export function formPages(fields: FormField[]): { title: string; fields: FormField[] }[] {
  const pages: { title: string; fields: FormField[] }[] = [{ title: '', fields: [] }];
  for (const f of fields) {
    if (f.type === 'page') {
      pages.push({ title: f.label === defaultLabel('page') ? '' : f.label, fields: [] });
      continue;
    }
    pages[pages.length - 1].fields.push(f);
  }
  if (pages.length > 1 && !pages[0].title) pages[0].title = 'Step 1';
  return pages;
}

/** Value-carrying fields only. */
export function valueFields(fields: FormField[]): FormField[] {
  return fields.filter((f) => !FORM_NO_VALUE_TYPES.has(f.type));
}

/** A starter contact form for the "New form" button. */
export function starterContactForm(): FormDefinition {
  const fields: FormField[] = [
    { id: randomFieldId(), type: 'text', label: 'Name', name: 'name', width: 'half', required: true, placeholder: 'Your name' },
    { id: randomFieldId(), type: 'email', label: 'Email', name: 'email', width: 'half', required: true, placeholder: 'you@example.com' },
    { id: randomFieldId(), type: 'textarea', label: 'Message', name: 'message', width: 'full', required: true, rows: 5 },
  ];
  const settings = defaultFormSettings();
  settings.notification.replyToField = 'email';
  settings.autoReply.toField = 'email';
  return { fields, settings };
}
