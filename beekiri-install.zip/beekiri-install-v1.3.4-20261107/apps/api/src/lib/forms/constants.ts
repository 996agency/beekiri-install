/** Bee Forms extension constants (shared by the API, middleware and public assets). */

export const FORMS_EXTENSION_SLUG = 'bee-forms';

/** Custom header the public form script sends; a cross-site HTML form cannot set it. */
export const FORMS_REQUEST_HEADER = 'x-beekiri-form';

/** Visitor uploads live under this private dot-folder of the uploads root (never served statically). */
export const FORMS_UPLOAD_DIR = '.forms';

/** Public submit payload limits. */
export const FORMS_MAX_FILES = 10;
export const FORMS_MAX_FILE_BYTES = 10 * 1024 * 1024;
export const FORMS_MAX_FIELDS = 300;

/** Data attribute the form element and PHP helper emit; the site script mounts on it. */
export const FORMS_MOUNT_ATTR = 'data-bee-form';
