import { createHmac, timingSafeEqual } from 'node:crypto';
import { config } from '../../config/env';

/**
 * Spam time-check token: `issuedAt.hmac(formId:issuedAt)`. A submission must arrive at least
 * `minSeconds` after the token was issued (bots post instantly) and within a day.
 */
const MAX_AGE_MS = 24 * 60 * 60 * 1000;

function sign(formId: string, ts: string): string {
  const secret = config.core.cacheFlushSecret || 'beekiri';
  return createHmac('sha256', `bee-forms:${secret}`).update(`${formId}:${ts}`).digest('base64url').slice(0, 32);
}

export function makeFormToken(formId: string, now = Date.now()): string {
  const ts = String(now);
  return `${ts}.${sign(formId, ts)}`;
}

export type TokenCheck = { ok: true; ageMs: number } | { ok: false; reason: 'invalid' | 'too_fast' | 'expired' };

export function checkFormToken(formId: string, token: string, minSeconds: number, now = Date.now()): TokenCheck {
  const [ts, sig] = String(token ?? '').split('.');
  if (!ts || !sig || !/^\d{10,16}$/.test(ts)) return { ok: false, reason: 'invalid' };
  const expected = sign(formId, ts);
  if (sig.length !== expected.length || !timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) {
    return { ok: false, reason: 'invalid' };
  }
  const ageMs = now - Number(ts);
  if (ageMs < 0 || ageMs > MAX_AGE_MS) return { ok: false, reason: 'expired' };
  if (ageMs < minSeconds * 1000) return { ok: false, reason: 'too_fast' };
  return { ok: true, ageMs };
}
