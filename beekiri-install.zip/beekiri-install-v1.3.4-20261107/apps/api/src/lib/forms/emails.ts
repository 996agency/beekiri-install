import { mergeHtml, mergeText, type MergeContext } from './merge';
import { escHtml } from './render';

export type RenderedFormEmail = { subject: string; text: string; html: string };

/** Wraps a merged message in the same plain, inline-styled shell the shop emails use. */
export function renderFormEmail(subject: string, message: string, ctx: MergeContext): RenderedFormEmail {
  const mergedSubject = mergeText(subject, ctx).replace(/\s+/g, ' ').trim().slice(0, 300);
  const text = mergeText(message, ctx);
  const body = mergeHtml(message, ctx);
  const html =
    `<!doctype html><html><body style="margin:0;padding:24px;background:#f0f0f1;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif">` +
    `<div style="max-width:600px;margin:0 auto;background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:28px 32px;color:#202734;font-size:15px;line-height:1.6">` +
    `<p style="margin:0 0 18px;font-size:12px;letter-spacing:.04em;text-transform:uppercase;color:#8c8f94">${escHtml(ctx.siteTitle)}</p>` +
    `<div>${body}</div>` +
    `</div>` +
    `<p style="max-width:600px;margin:14px auto 0;font-size:12px;color:#8c8f94;text-align:center">Sent by Bee Forms on ${escHtml(ctx.siteTitle)}</p>` +
    `</body></html>`;
  return { subject: mergedSubject, text, html };
}
