/**
 * Server-side HTML for a form. One markup for everything that shows a form: the page element,
 * the `form` Backend Field (PHP and React layouts) and the editor preview. The site script
 * (bee-forms.js) adds validation, conditional logic, steps and AJAX submit on top.
 */
import { FORMS_MOUNT_ATTR } from './constants';
import { formPages, type FormDefinition, type FormField } from './schema';

export type RenderFormInput = {
  id: string;
  title: string;
  definition: FormDefinition;
  /** Spam token issued at render time (the script refreshes it on first interaction). */
  token: string;
  /** Absolute or site-relative submit URL. */
  action: string;
  /** Editor preview: inputs are inert and the honeypot is omitted. */
  preview?: boolean;
};

export function escHtml(v: unknown): string {
  return String(v ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

const attr = escHtml;

export function inputName(field: FormField): string {
  return `f_${field.id}`;
}

function requiredMark(f: FormField): string {
  return f.required ? ' <span class="bk-form__req" aria-hidden="true">*</span>' : '';
}

function labelFor(f: FormField, id: string): string {
  if (f.hideLabel) return `<label class="bk-form__label screen-reader-text" for="${id}">${escHtml(f.label)}</label>`;
  return `<label class="bk-form__label" for="${id}">${escHtml(f.label)}${requiredMark(f)}</label>`;
}

function help(f: FormField, id: string): string {
  return f.help ? `<p class="bk-form__help" id="${id}-help">${escHtml(f.help)}</p>` : '';
}

function common(f: FormField, id: string): string {
  const parts = [`id="${id}"`, `name="${inputName(f)}"`, `class="bk-form__input"`];
  if (f.required) parts.push('required', 'aria-required="true"');
  if (f.placeholder) parts.push(`placeholder="${attr(f.placeholder)}"`);
  if (f.help) parts.push(`aria-describedby="${id}-help"`);
  return parts.join(' ');
}

function choices(f: FormField, id: string, type: 'checkbox' | 'radio'): string {
  const name = inputName(f);
  const defaults = new Set((f.defaultValue ?? '').split('\n').map((s) => s.trim()).filter(Boolean));
  const items = (f.options ?? [])
    .map((o, i) => {
      const oid = `${id}-${i}`;
      const checked = defaults.has(o.value) ? ' checked' : '';
      return `<label class="bk-form__choice" for="${oid}"><input type="${type}" id="${oid}" name="${name}" value="${attr(o.value)}"${checked}${type === 'radio' && f.required ? ' required' : ''}><span class="bk-form__choice-box" aria-hidden="true"></span><span>${escHtml(o.label)}</span></label>`;
    })
    .join('');
  const legend = f.hideLabel
    ? `<legend class="screen-reader-text">${escHtml(f.label)}</legend>`
    : `<legend class="bk-form__label">${escHtml(f.label)}${requiredMark(f)}</legend>`;
  return `<fieldset class="bk-form__choices"${f.help ? ` aria-describedby="${id}-help"` : ''}>${legend}<div class="bk-form__choice-list">${items}</div>${help(f, id)}</fieldset>`;
}

function control(f: FormField, id: string, preview: boolean): string {
  const dv = f.defaultValue ?? '';
  switch (f.type) {
    case 'text':
      return `${labelFor(f, id)}<input type="text" ${common(f, id)} value="${attr(dv)}" maxlength="2000">${help(f, id)}`;
    case 'email':
      return `${labelFor(f, id)}<input type="email" ${common(f, id)} value="${attr(dv)}" autocomplete="email" inputmode="email" maxlength="254">${help(f, id)}`;
    case 'phone':
      return `${labelFor(f, id)}<input type="tel" ${common(f, id)} value="${attr(dv)}" autocomplete="tel" inputmode="tel" maxlength="40">${help(f, id)}`;
    case 'url':
      return `${labelFor(f, id)}<input type="url" ${common(f, id)} value="${attr(dv)}" autocomplete="url" inputmode="url" maxlength="2000">${help(f, id)}`;
    case 'number': {
      const minmax = `${f.min ? ` min="${attr(f.min)}"` : ''}${f.max ? ` max="${attr(f.max)}"` : ''}`;
      return `${labelFor(f, id)}<input type="number" ${common(f, id)} value="${attr(dv)}" inputmode="decimal" step="any"${minmax}>${help(f, id)}`;
    }
    case 'date': {
      const minmax = `${f.min ? ` min="${attr(f.min)}"` : ''}${f.max ? ` max="${attr(f.max)}"` : ''}`;
      return `${labelFor(f, id)}<input type="date" ${common(f, id)} value="${attr(dv)}"${minmax}>${help(f, id)}`;
    }
    case 'textarea':
      return `${labelFor(f, id)}<textarea ${common(f, id)} rows="${f.rows ?? 4}" maxlength="20000">${escHtml(dv)}</textarea>${help(f, id)}`;
    case 'select': {
      const multiple = f.multiple ? ' multiple' : '';
      const defaults = new Set(dv.split('\n').map((s) => s.trim()).filter(Boolean));
      const opts = (f.options ?? [])
        .map((o) => `<option value="${attr(o.value)}"${defaults.has(o.value) ? ' selected' : ''}>${escHtml(o.label)}</option>`)
        .join('');
      const placeholder = !f.multiple ? `<option value="">${escHtml(f.placeholder || 'Choose…')}</option>` : '';
      return `${labelFor(f, id)}<select ${common(f, id)}${multiple}>${placeholder}${opts}</select>${help(f, id)}`;
    }
    case 'checkbox':
      return choices(f, id, 'checkbox');
    case 'radio':
      return choices(f, id, 'radio');
    case 'consent': {
      const text = f.text || f.label;
      return `<label class="bk-form__choice bk-form__consent" for="${id}"><input type="checkbox" id="${id}" name="${inputName(f)}" value="1"${f.required !== false ? ' required aria-required="true"' : ''}><span class="bk-form__choice-box" aria-hidden="true"></span><span>${escHtml(text)}${f.required !== false ? requiredMark({ ...f, required: true }) : ''}</span></label>${help(f, id)}`;
    }
    case 'file': {
      const multiple = (f.maxFiles ?? 1) > 1 ? ' multiple' : '';
      const accept = acceptAttr(f);
      return `${labelFor(f, id)}<div class="bk-form__file"><input type="file" ${common(f, id)}${multiple}${accept} data-max-files="${f.maxFiles ?? 1}"><span class="bk-form__file-hint" data-file-hint>${escHtml(fileHint(f))}</span></div>${help(f, id)}`;
    }
    case 'hidden':
      return `<input type="hidden" name="${inputName(f)}" value="${attr(f.hiddenSource === 'static' || !f.hiddenSource ? dv : '')}" data-hidden-source="${attr(f.hiddenSource ?? 'static')}">`;
    case 'section':
      return `<div class="bk-form__section"><h3 class="bk-form__section-title">${escHtml(f.label)}</h3>${f.text ? `<p class="bk-form__section-text">${escHtml(f.text)}</p>` : ''}</div>`;
    default:
      return preview ? '' : '';
  }
}

const ACCEPT_EXT: Record<string, string> = {
  image: 'image/*',
  pdf: '.pdf',
  document: '.pdf,.doc,.docx,.odt,.txt,.rtf',
  spreadsheet: '.csv,.xls,.xlsx,.ods',
  archive: '.zip',
};

function acceptAttr(f: FormField): string {
  const kinds = f.accept ?? ['any'];
  if (kinds.includes('any')) return '';
  return ` accept="${attr([...new Set(kinds.map((k) => ACCEPT_EXT[k]).filter(Boolean))].join(','))}"`;
}

function fileHint(f: FormField): string {
  const kinds = f.accept ?? ['any'];
  const names: Record<string, string> = { image: 'images', pdf: 'PDF', document: 'documents', spreadsheet: 'spreadsheets', archive: 'ZIP' };
  const what = kinds.includes('any') ? 'Any file' : kinds.map((k) => names[k]).join(', ');
  const n = f.maxFiles ?? 1;
  return `${what} · up to 10 MB${n > 1 ? ` · max ${n} files` : ''}`;
}

export function renderFormField(f: FormField, formId: string, preview = false): string {
  const id = `bkf-${formId}-${f.id}`;
  if (f.type === 'page') return '';
  const cls = ['bk-form__field', `is-${f.width}`, `is-type-${f.type}`];
  const cond = f.conditional ? ' data-conditional="1"' : '';
  if (f.type === 'hidden') return `<div class="bk-form__field is-hidden" data-field="${f.id}" data-type="hidden"${cond}>${control(f, id, preview)}</div>`;
  return `<div class="${cls.join(' ')}" data-field="${f.id}" data-type="${f.type}"${cond}>${control(f, id, preview)}<p class="bk-form__error" data-error hidden></p></div>`;
}

/** Definition the site script needs (no labels or help; the DOM has those). */
export function clientDefinition(def: FormDefinition): Record<string, unknown> {
  return {
    fields: def.fields.map((f) => ({
      id: f.id,
      type: f.type,
      name: f.name,
      label: f.label,
      required: Boolean(f.required) || (f.type === 'consent' && f.required !== false),
      multiple: f.type === 'checkbox' || (f.type === 'select' && Boolean(f.multiple)) || (f.type === 'file' && (f.maxFiles ?? 1) > 1),
      ...(f.conditional ? { conditional: f.conditional } : {}),
      ...(f.type === 'file' ? { maxFiles: f.maxFiles ?? 1, accept: f.accept ?? ['any'] } : {}),
      ...(f.type === 'number' || f.type === 'date' ? { min: f.min, max: f.max } : {}),
    })),
    minSeconds: def.settings.minSeconds,
    progress: def.settings.progress,
    confirmation: def.settings.confirmation.type,
  };
}

export function renderForm(input: RenderFormInput): string {
  const { id, definition: def, preview } = input;
  const pages = formPages(def.fields);
  const multi = pages.length > 1;
  const s = def.settings;

  const progress = multi && s.progress !== 'none'
    ? s.progress === 'steps'
      ? `<ol class="bk-form__steps" data-progress>${pages.map((p, i) => `<li class="bk-form__step${i === 0 ? ' is-active' : ''}" data-step="${i}"><span class="bk-form__step-num">${i + 1}</span><span class="bk-form__step-title">${escHtml(p.title || `Step ${i + 1}`)}</span></li>`).join('')}</ol>`
      : `<div class="bk-form__progress" data-progress role="progressbar" aria-valuemin="0" aria-valuemax="${pages.length}" aria-valuenow="1"><span class="bk-form__progress-bar" style="width:${Math.round(100 / pages.length)}%"></span></div>`
    : '';

  const pagesHtml = pages
    .map((p, i) => {
      const fields = p.fields.map((f) => renderFormField(f, id, preview)).join('');
      const title = multi && p.title && s.progress !== 'steps' ? `<h3 class="bk-form__page-title">${escHtml(p.title)}</h3>` : '';
      const nav = multi
        ? `<div class="bk-form__nav">${i > 0 ? `<button type="button" class="bk-form__btn bk-form__btn--back" data-back>${escHtml(s.backLabel)}</button>` : ''}${i < pages.length - 1 ? `<button type="button" class="bk-form__btn bk-form__btn--next" data-next>${escHtml(s.nextLabel)}</button>` : `<button type="submit" class="bk-form__btn bk-form__btn--submit" data-submit>${escHtml(s.submitLabel)}</button>`}</div>`
        : `<div class="bk-form__nav"><button type="submit" class="bk-form__btn bk-form__btn--submit" data-submit>${escHtml(s.submitLabel)}</button></div>`;
      return `<div class="bk-form__page${i === 0 ? ' is-active' : ''}" data-page="${i}"${i === 0 ? '' : ' hidden'}>${title}<div class="bk-form__grid">${fields}</div>${nav}</div>`;
    })
    .join('');

  const honeypot = preview
    ? ''
    : `<div class="bk-form__hp" aria-hidden="true"><label for="bkf-${id}-website">Leave this field empty</label><input type="text" id="bkf-${id}-website" name="_bk_hp" tabindex="-1" autocomplete="off" value=""></div>`;
  const token = `<input type="hidden" name="_bk_t" value="${attr(input.token)}" data-token>`;
  const defJson = JSON.stringify(clientDefinition(def)).replace(/<\//g, '<\\/').replace(/<!--/g, '<\\!--');

  return (
    `<div class="bk-form" ${FORMS_MOUNT_ATTR}="${attr(id)}"${preview ? ' data-bee-form-preview="1"' : ''}>` +
    `<form class="bk-form__form" method="post" action="${attr(input.action)}" enctype="multipart/form-data" novalidate data-bee-form-el aria-label="${attr(input.title)}">` +
    progress +
    pagesHtml +
    honeypot +
    token +
    `<p class="bk-form__status" data-status role="alert" aria-live="polite" hidden></p>` +
    `</form>` +
    `<div class="bk-form__done" data-done hidden tabindex="-1"></div>` +
    `<script type="application/json" data-bee-form-def>${defJson}</script>` +
    `</div>`
  );
}
