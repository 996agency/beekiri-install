import type { FieldCondition, FormField } from './schema';

/** Submitted values keyed by field id (string, list, or file list). */
export type EntryValues = Record<string, unknown>;

function asStrings(v: unknown): string[] {
  if (v == null) return [];
  if (Array.isArray(v)) return v.map((x) => (typeof x === 'string' ? x : isFile(x) ? x.name : String(x ?? '')));
  if (isFile(v)) return [v.name];
  return [String(v)];
}

const isFile = (v: unknown): v is { name: string } =>
  !!v && typeof v === 'object' && typeof (v as { name?: unknown }).name === 'string';

function ruleHolds(op: FieldCondition['rules'][number]['op'], actual: string[], expected: string): boolean {
  const joined = actual.join(', ');
  const has = actual.some((a) => a.trim() !== '');
  switch (op) {
    case 'empty':
      return !has;
    case 'not_empty':
      return has;
    case 'is':
      return actual.some((a) => a === expected);
    case 'is_not':
      return !actual.some((a) => a === expected);
    case 'contains':
      return joined.toLowerCase().includes(expected.toLowerCase());
    case 'not_contains':
      return !joined.toLowerCase().includes(expected.toLowerCase());
    case 'gt':
      return Number(actual[0]) > Number(expected);
    case 'lt':
      return Number(actual[0]) < Number(expected);
    default:
      return false;
  }
}

/**
 * Which fields are visible for the given values. Mirrors the site script, so hidden fields are
 * neither required nor stored. A field whose condition points at a hidden field reads it as empty.
 */
export function visibleFieldIds(fields: FormField[], values: EntryValues): Set<string> {
  const visible = new Set<string>(fields.map((f) => f.id));
  // Up to a few passes so chains (A shows B shows C) settle; cycles just stop changing.
  for (let pass = 0; pass < 4; pass++) {
    let changed = false;
    for (const f of fields) {
      const cond = f.conditional;
      if (!cond) continue;
      const results = cond.rules.map((r) =>
        ruleHolds(r.op, visible.has(r.field) ? asStrings(values[r.field]) : [], r.value),
      );
      const met = cond.match === 'any' ? results.some(Boolean) : results.every(Boolean);
      const show = cond.action === 'show' ? met : !met;
      if (show !== visible.has(f.id)) {
        if (show) visible.add(f.id);
        else visible.delete(f.id);
        changed = true;
      }
    }
    if (!changed) break;
  }
  return visible;
}
