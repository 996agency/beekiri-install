/**
 * Server-side validation of a submission against a form definition. Pure. The site script
 * runs the same rules for instant feedback, but this is the one that counts.
 */
import { visibleFieldIds, type EntryValues } from './conditions';
import { FORM_NO_VALUE_TYPES, valueFields, type FileAcceptKind, type FormField } from './schema';

export type IncomingFile = { fieldId: string; name: string; mime: string; size: number };

export type SubmissionInput = {
  /** Raw text values keyed by field id; repeated keys arrive as arrays. */
  values: Record<string, string | string[] | undefined>;
  files: IncomingFile[];
};

export type FieldError = { field: string; message: string };

export type ValidatedSubmission = {
  /** Clean values keyed by field id (strings, string lists; files stay as IncomingFile lists). */
  values: EntryValues;
  errors: FieldError[];
  visible: Set<string>;
};

export const ACCEPT_MIMES: Record<FileAcceptKind, readonly string[]> = {
  image: ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/heic', 'image/heif'],
  pdf: ['application/pdf'],
  document: [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.oasis.opendocument.text',
    'text/plain',
    'application/rtf',
  ],
  spreadsheet: [
    'text/csv',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.oasis.opendocument.spreadsheet',
  ],
  archive: ['application/zip', 'application/x-zip-compressed'],
  any: [],
};

/** Never accepted, whatever the field allows. */
const BLOCKED_MIMES = new Set([
  'text/html',
  'application/xhtml+xml',
  'image/svg+xml',
  'application/javascript',
  'text/javascript',
  'application/x-msdownload',
  'application/x-sh',
  'application/x-httpd-php',
]);
const BLOCKED_EXT = /\.(html?|xhtml|svg|js|mjs|php\d?|phtml|exe|bat|cmd|sh|ps1|com|scr|jar|msi|dll)$/i;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE_RE = /^[+\d][\d\s().-]{4,29}$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

function first(v: string | string[] | undefined): string {
  return (Array.isArray(v) ? v[0] : v) ?? '';
}
function list(v: string | string[] | undefined): string[] {
  return (Array.isArray(v) ? v : v == null ? [] : [v]).map((s) => String(s));
}

export function mimeAllowed(field: FormField, mime: string, name: string): boolean {
  const m = mime.toLowerCase().split(';')[0].trim();
  if (BLOCKED_MIMES.has(m) || BLOCKED_EXT.test(name)) return false;
  const kinds = field.accept ?? ['any'];
  if (kinds.includes('any')) return true;
  return kinds.some((k) => ACCEPT_MIMES[k].includes(m));
}

export function validateSubmission(fields: FormField[], input: SubmissionInput): ValidatedSubmission {
  const errors: FieldError[] = [];
  const raw: EntryValues = {};
  const byId = new Map(fields.map((f) => [f.id, f]));

  // Pass 1: shape every value so conditions can read them.
  for (const f of valueFields(fields)) {
    if (f.type === 'file') {
      raw[f.id] = input.files.filter((x) => x.fieldId === f.id);
    } else if (f.type === 'checkbox' || (f.type === 'select' && f.multiple)) {
      raw[f.id] = list(input.values[f.id]).map((s) => s.trim().slice(0, 500)).filter(Boolean);
    } else {
      raw[f.id] = first(input.values[f.id]).toString().slice(0, f.type === 'textarea' ? 20_000 : 2000);
      if (f.type !== 'textarea') raw[f.id] = (raw[f.id] as string).trim();
    }
  }
  const visible = visibleFieldIds(fields, raw);
  const values: EntryValues = {};

  for (const f of fields) {
    if (FORM_NO_VALUE_TYPES.has(f.type)) continue;
    if (!visible.has(f.id)) continue; // hidden by conditional logic: dropped, never required
    const v = raw[f.id];
    const err = (message: string) => errors.push({ field: f.id, message });
    const label = f.label;

    if (f.type === 'file') {
      const files = v as { name: string; mime: string; size: number }[];
      if (f.required && !files.length) err(`${label} is required.`);
      if (files.length > (f.maxFiles ?? 1)) err(`${label}: at most ${f.maxFiles ?? 1} file(s).`);
      for (const file of files) {
        if (!mimeAllowed(f, file.mime, file.name)) err(`${label}: "${file.name}" is not an allowed file type.`);
      }
      values[f.id] = files;
      continue;
    }

    if (Array.isArray(v)) {
      const allowed = new Set((f.options ?? []).map((o) => o.value));
      const clean = v.filter((x) => allowed.has(x));
      if (f.required && !clean.length) err(`${label} is required.`);
      values[f.id] = clean;
      continue;
    }

    const s = String(v ?? '');
    if (f.type === 'consent') {
      const on = s === '1' || s === 'true' || s === 'on' || s === 'yes';
      if (f.required !== false && !on) err(`${label} must be accepted.`);
      values[f.id] = on ? 'Yes' : 'No';
      continue;
    }
    if (!s) {
      if (f.required) err(`${label} is required.`);
      values[f.id] = '';
      continue;
    }
    switch (f.type) {
      case 'email':
        if (!EMAIL_RE.test(s) || s.length > 254) err(`${label} must be a valid email address.`);
        break;
      case 'phone':
        if (!PHONE_RE.test(s)) err(`${label} must be a valid phone number.`);
        break;
      case 'url':
        try {
          const u = new URL(/^https?:\/\//i.test(s) ? s : `https://${s}`);
          if (!u.hostname.includes('.')) throw new Error('host');
        } catch {
          err(`${label} must be a valid website address.`);
        }
        break;
      case 'number': {
        const n = Number(s.replace(',', '.'));
        if (!Number.isFinite(n)) err(`${label} must be a number.`);
        else {
          if (f.min !== undefined && f.min !== '' && n < Number(f.min)) err(`${label} must be at least ${f.min}.`);
          if (f.max !== undefined && f.max !== '' && n > Number(f.max)) err(`${label} must be at most ${f.max}.`);
        }
        break;
      }
      case 'date':
        if (!DATE_RE.test(s) || Number.isNaN(Date.parse(s))) err(`${label} must be a valid date.`);
        else {
          if (f.min && s < f.min) err(`${label} must be on or after ${f.min}.`);
          if (f.max && s > f.max) err(`${label} must be on or before ${f.max}.`);
        }
        break;
      case 'select':
      case 'radio': {
        const allowed = new Set((f.options ?? []).map((o) => o.value));
        if (!allowed.has(s)) err(`${label}: choose one of the options.`);
        break;
      }
      default:
        break;
    }
    values[f.id] = s;
  }

  // Files for fields that are hidden or unknown are refused outright (nothing is stored).
  for (const file of input.files) {
    const f = byId.get(file.fieldId);
    if (!f || f.type !== 'file' || !visible.has(f.id)) {
      errors.push({ field: file.fieldId, message: 'Unexpected file.' });
    }
  }

  return { values, errors, visible };
}
