/**
 * Bee Forms → CRM integrations: provider catalogue, the per-form feed definition (which entry
 * values go to which CRM property), and turning an entry into HubSpot contact properties.
 * Pure; no I/O.
 */
import type { Attribution } from './attribution';
import { valueText } from './merge';
import type { FormField } from './schema';

export const INTEGRATION_PROVIDERS = [
  { id: 'hubspot', name: 'HubSpot', status: 'available' },
  { id: 'brevo', name: 'Brevo', status: 'coming-soon' },
  { id: 'mailchimp', name: 'Mailchimp', status: 'coming-soon' },
  { id: 'salesforce', name: 'Salesforce', status: 'coming-soon' },
] as const;

export type IntegrationProvider = (typeof INTEGRATION_PROVIDERS)[number]['id'];

/** Entry values that are not form answers. */
export const META_SOURCES = {
  channel: 'Source: channel (e.g. Paid social)',
  source: 'Source: source (e.g. LinkedIn Ads)',
  campaign: 'Source: campaign (utm_campaign)',
  medium: 'Source: medium (utm_medium)',
  term: 'Source: keyword (utm_term)',
  content: 'Source: ad content (utm_content)',
  click_id: 'Source: ad click type (gclid, li_fat_id…)',
  landing_page: 'Source: landing page',
  referrer: 'Source: came from (referrer)',
  first_channel: 'First visit: channel',
  first_source: 'First visit: source',
  first_campaign: 'First visit: campaign',
  page_url: 'Page the form was sent from',
  country: 'Visitor country (code)',
  device: 'Visitor device',
  form_title: 'Form title',
  entry_id: 'Entry ID',
  submitted_at: 'Date sent',
} as const;

export type MetaSource = keyof typeof META_SOURCES;

export type MappingSource =
  | { kind: 'field'; field: string; part?: 'first' | 'last' }
  | { kind: 'meta'; key: MetaSource }
  | { kind: 'static'; value: string };

export type MappingRow = { property: string; source: MappingSource };

export type HubspotFeed = {
  enabled: boolean;
  mapping: MappingRow[];
  /** Field name of a consent/checkbox field that must be ticked, or '' to always send. */
  consentField: string;
  /** Also save every answer as a note on the contact. */
  addNote: boolean;
};

export type FormIntegrations = { hubspot: HubspotFeed };

export function defaultIntegrations(): FormIntegrations {
  return { hubspot: { enabled: false, mapping: [], consentField: '', addNote: false } };
}

const PROPERTY_RE = /^[a-z0-9_][a-z0-9_\-]{0,99}$/i;
const NAME_RE = /^[a-z0-9_]{1,60}$/;

function parseSource(raw: unknown): MappingSource | null {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  if (r.kind === 'field' && typeof r.field === 'string' && NAME_RE.test(r.field)) {
    const part = r.part === 'first' || r.part === 'last' ? r.part : undefined;
    return part ? { kind: 'field', field: r.field, part } : { kind: 'field', field: r.field };
  }
  if (r.kind === 'meta' && typeof r.key === 'string' && r.key in META_SOURCES) return { kind: 'meta', key: r.key as MetaSource };
  if (r.kind === 'static' && typeof r.value === 'string') return { kind: 'static', value: r.value.slice(0, 2000) };
  return null;
}

export function parseIntegrations(raw: unknown): FormIntegrations {
  const d = defaultIntegrations();
  if (!raw || typeof raw !== 'object') return d;
  const h = (raw as Record<string, unknown>).hubspot;
  if (!h || typeof h !== 'object') return d;
  const r = h as Record<string, unknown>;
  const seen = new Set<string>();
  const mapping: MappingRow[] = [];
  for (const row of Array.isArray(r.mapping) ? r.mapping.slice(0, 100) : []) {
    if (!row || typeof row !== 'object') continue;
    const property = String((row as Record<string, unknown>).property ?? '').trim();
    const source = parseSource((row as Record<string, unknown>).source);
    if (!PROPERTY_RE.test(property) || !source || seen.has(property)) continue;
    seen.add(property);
    mapping.push({ property, source });
  }
  return {
    hubspot: {
      enabled: r.enabled === true,
      mapping,
      consentField: typeof r.consentField === 'string' && NAME_RE.test(r.consentField) ? r.consentField : '',
      addNote: r.addNote === true,
    },
  };
}

/* ── Entry → values ─────────────────────────────────────────────────── */

export type EntryContext = {
  fields: FormField[];
  /** Entry data keyed by field id. */
  values: Record<string, unknown>;
  meta: Record<string, unknown>;
  formTitle: string;
  entryId: string;
  createdAt: Date;
};

function fieldByName(ctx: EntryContext, name: string): FormField | undefined {
  return ctx.fields.find((f) => f.name === name);
}

/** Raw value(s) for one mapping source; arrays stay arrays so multi-select CRM fields work. */
export function sourceValue(source: MappingSource, ctx: EntryContext): string | string[] {
  if (source.kind === 'static') return source.value;
  if (source.kind === 'field') {
    const f = fieldByName(ctx, source.field);
    if (!f) return '';
    const v = ctx.values[f.id];
    if (Array.isArray(v) && v.every((x) => typeof x === 'string')) return source.part ? splitName(v.join(' '), source.part) : (v as string[]);
    const text = valueText(v);
    return source.part ? splitName(text, source.part) : text;
  }
  const meta = ctx.meta;
  const attr = (meta.attribution ?? {}) as { visit?: Partial<Attribution> | null; first?: Partial<Attribution> | null };
  const visit = attr.visit ?? {};
  const first = attr.first ?? {};
  const s = (v: unknown) => (v == null ? '' : String(v));
  switch (source.key) {
    case 'channel': return s(visit.channel);
    case 'source': return s(visit.source);
    case 'campaign': return s(visit.campaign);
    case 'medium': return s(visit.medium);
    case 'term': return s(visit.term);
    case 'content': return s(visit.content);
    case 'click_id': return s(visit.clickId);
    case 'landing_page': return s(visit.landingPage);
    case 'referrer': return s(visit.referrer);
    case 'first_channel': return s(first.channel);
    case 'first_source': return s(first.source);
    case 'first_campaign': return s(first.campaign);
    case 'page_url': return s(meta.pageUrl);
    case 'country': return s(meta.country);
    case 'device': return s(meta.device);
    case 'form_title': return ctx.formTitle;
    case 'entry_id': return ctx.entryId;
    case 'submitted_at': return ctx.createdAt.toISOString();
    default: return '';
  }
}

/** "Ada King Lovelace" → first "Ada", last "King Lovelace". */
export function splitName(full: string, part: 'first' | 'last'): string {
  const words = full.trim().split(/\s+/).filter(Boolean);
  if (part === 'first') return words[0] ?? '';
  return words.slice(1).join(' ');
}

/** True when the feed's consent condition (if any) is met by this entry. */
export function consentGiven(feed: HubspotFeed, ctx: EntryContext): boolean {
  if (!feed.consentField) return true;
  const f = fieldByName(ctx, feed.consentField);
  if (!f) return false;
  const v = ctx.values[f.id];
  if (Array.isArray(v)) return v.length > 0;
  const t = String(v ?? '').toLowerCase();
  return t === 'yes' || t === 'true' || t === '1' || t === 'on';
}

/* ── HubSpot property coercion ───────────────────────────────────────── */

export type HubspotProperty = {
  name: string;
  label: string;
  type: string; // string | number | date | datetime | enumeration | bool | phone_number
  fieldType: string; // text | textarea | select | radio | checkbox | booleancheckbox | number | date | phonenumber…
  groupName?: string;
  options?: { label: string; value: string }[];
  readOnly?: boolean;
};

export type BuiltProperties = { properties: Record<string, string>; warnings: string[] };

const TRUE_WORDS = new Set(['yes', 'true', '1', 'on', 'y', 'ja', 'po', 'oui', 'si', 'sí']);

/** One value as HubSpot expects it for the property's type; null = drop it (with a warning). */
export function coerceForHubspot(prop: HubspotProperty | undefined, value: string | string[]): { value: string | null; warning?: string } {
  const list = (Array.isArray(value) ? value : [value]).map((v) => String(v).trim()).filter(Boolean);
  if (!list.length) return { value: null };
  if (!prop) return { value: list.join(', ').slice(0, 65_000) };
  const label = prop.label || prop.name;
  switch (prop.type) {
    case 'enumeration': {
      if (prop.fieldType === 'booleancheckbox') return { value: TRUE_WORDS.has(list[0].toLowerCase()) ? 'true' : 'false' };
      const options = prop.options ?? [];
      const matched: string[] = [];
      const missed: string[] = [];
      for (const v of list) {
        const opt = options.find((o) => o.value === v) ?? options.find((o) => o.value.toLowerCase() === v.toLowerCase() || o.label.toLowerCase() === v.toLowerCase());
        if (opt) matched.push(opt.value);
        else missed.push(v);
      }
      const multi = prop.fieldType === 'checkbox';
      if (!matched.length) return { value: null, warning: `${label}: “${list.join(', ')}” is not one of its options in HubSpot, so it was left out.` };
      const out = multi ? matched.join(';') : matched[0];
      return missed.length ? { value: out, warning: `${label}: “${missed.join(', ')}” is not an option in HubSpot and was left out.` } : { value: out };
    }
    case 'bool':
      return { value: TRUE_WORDS.has(list[0].toLowerCase()) ? 'true' : 'false' };
    case 'number': {
      const n = Number(list[0].replace(/\s/g, '').replace(',', '.'));
      return Number.isFinite(n) ? { value: String(n) } : { value: null, warning: `${label}: “${list[0]}” is not a number, so it was left out.` };
    }
    case 'date': {
      // HubSpot date properties take midnight UTC as epoch milliseconds.
      const m = list[0].match(/^(\d{4})-(\d{2})-(\d{2})/);
      const ms = m ? Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : NaN;
      if (Number.isFinite(ms)) return { value: String(ms) };
      const d = new Date(list[0]);
      return Number.isNaN(d.getTime()) ? { value: null, warning: `${label}: “${list[0]}” is not a date, so it was left out.` } : { value: String(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate())) };
    }
    case 'datetime': {
      const d = /^\d{10,13}$/.test(list[0]) ? new Date(Number(list[0])) : new Date(list[0]);
      return Number.isNaN(d.getTime()) ? { value: null, warning: `${label}: “${list[0]}” is not a date, so it was left out.` } : { value: String(d.getTime()) };
    }
    default:
      return { value: list.join(prop.fieldType === 'textarea' ? '\n' : ', ').slice(0, 65_000) };
  }
}

/** Contact properties for an entry. `email` is always present when the result is usable. */
export function buildHubspotProperties(feed: HubspotFeed, ctx: EntryContext, schema: Map<string, HubspotProperty>): BuiltProperties {
  const properties: Record<string, string> = {};
  const warnings: string[] = [];
  for (const row of feed.mapping) {
    const prop = schema.get(row.property);
    if (schema.size && !prop) {
      warnings.push(`HubSpot property “${row.property}” no longer exists, so it was skipped.`);
      continue;
    }
    if (prop?.readOnly) {
      warnings.push(`${prop.label || prop.name} is read-only in HubSpot, so it was skipped.`);
      continue;
    }
    const raw = sourceValue(row.source, ctx);
    const { value, warning } = coerceForHubspot(prop, raw);
    if (warning) warnings.push(warning);
    if (value !== null) properties[row.property] = value;
  }
  if (properties.email) properties.email = properties.email.trim().toLowerCase();
  return { properties, warnings };
}

/** Plain-text summary of the entry for a HubSpot note (HubSpot notes accept simple HTML). */
export function noteBody(ctx: EntryContext): string {
  const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const lines = ctx.fields
    .filter((f) => f.type !== 'page' && f.type !== 'section' && f.type !== 'hidden')
    .map((f) => ({ label: f.label, text: valueText(ctx.values[f.id]) }))
    .filter((r) => r.text);
  const attr = ((ctx.meta.attribution ?? {}) as { visit?: Partial<Attribution> | null }).visit ?? {};
  const src = [attr.channel, attr.source, attr.campaign].filter(Boolean).join(' · ');
  return (
    `<p><strong>${esc(ctx.formTitle)}</strong> (Bee Forms)</p>` +
    lines.map((l) => `<p><strong>${esc(l.label)}:</strong> ${esc(l.text).replace(/\n/g, '<br>')}</p>`).join('') +
    (src ? `<p><strong>Source:</strong> ${esc(src)}</p>` : '') +
    (ctx.meta.pageUrl ? `<p><strong>Page:</strong> ${esc(String(ctx.meta.pageUrl))}</p>` : '')
  ).slice(0, 60_000);
}

/** A sensible starting mapping for a form (the builder shows it when HubSpot is first enabled). */
export function suggestHubspotMapping(fields: FormField[]): MappingRow[] {
  const rows: MappingRow[] = [];
  const add = (property: string, source: MappingSource) => {
    if (!rows.some((r) => r.property === property)) rows.push({ property, source });
  };
  const by = (re: RegExp, types?: string[]) => fields.find((f) => (!types || types.includes(f.type)) && (re.test(f.name) || re.test(f.label.toLowerCase())));
  const email = fields.find((f) => f.type === 'email');
  if (email) add('email', { kind: 'field', field: email.name });
  const first = by(/^(first[_ ]?name|firstname|given)/);
  const last = by(/^(last[_ ]?name|lastname|surname|family)/);
  const full = by(/^(name|full[_ ]?name|your[_ ]?name)$/);
  if (first) add('firstname', { kind: 'field', field: first.name });
  if (last) add('lastname', { kind: 'field', field: last.name });
  if (!first && !last && full) {
    add('firstname', { kind: 'field', field: full.name, part: 'first' });
    add('lastname', { kind: 'field', field: full.name, part: 'last' });
  }
  const phone = fields.find((f) => f.type === 'phone') ?? by(/phone|mobile|tel/);
  if (phone) add('phone', { kind: 'field', field: phone.name });
  const company = by(/company|organi[sz]ation|business/);
  if (company) add('company', { kind: 'field', field: company.name });
  const site = fields.find((f) => f.type === 'url') ?? by(/website|site|url/);
  if (site) add('website', { kind: 'field', field: site.name });
  const job = by(/job|title|position|role/, ['text', 'select', 'radio']);
  if (job) add('jobtitle', { kind: 'field', field: job.name });
  const message = fields.find((f) => f.type === 'textarea') ?? by(/message|comment|enquiry|inquiry/);
  if (message) add('message', { kind: 'field', field: message.name });
  add('lifecyclestage', { kind: 'static', value: 'lead' });
  return rows;
}
