import { Op } from 'sequelize';
import { Post, Taxonomy, Term, TermRelationship } from '../../models';
import type { AuthUser } from '../../types/auth';
import { BadRequest, Forbidden, NotFound, toHttpError } from '../../utils/http-error';
import { createId } from '../../utils/ids';
import { PRODUCT_KIND } from '../shop/constants';

function slugify(raw: string): string {
  return raw
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
}

function objectTypesOf(row: Taxonomy): string[] {
  const raw = row.objectTypes;
  if (!Array.isArray(raw)) return [];
  return raw.map((v) => String(v).trim().toLowerCase()).filter(Boolean);
}

function serializeTerm(row: Term) {
  return {
    id: row.id,
    name: row.name,
    slug: row.slug,
    description: row.description,
    parentId: row.parentId ?? null,
    menuOrder: row.menuOrder,
  };
}

/** Taxonomies attached to a content type, with terms + which are selected on this post. */
export async function getPostTaxonomies(postId: string, siteId: string, objectType: string) {
  try {
    const post = await Post.findOne({ where: { id: postId, siteId } });
    if (!post) throw NotFound('Content not found.');

    const taxonomies = await Taxonomy.findAll({
      where: { siteId, active: true },
      order: [
        ['menuOrder', 'ASC'],
        ['plural', 'ASC'],
      ],
    });
    const attached = taxonomies.filter((t) => objectTypesOf(t).includes(objectType));
    if (!attached.length) return { taxonomies: [] };

    const taxonomyIds = attached.map((t) => t.id);
    const terms = await Term.findAll({
      where: { siteId, taxonomyId: { [Op.in]: taxonomyIds } },
      order: [
        ['menuOrder', 'ASC'],
        ['name', 'ASC'],
      ],
    });
    const links = await TermRelationship.findAll({
      where: { postId },
      attributes: ['termId'],
    });
    const selected = new Set(links.map((l) => l.termId));
    const byTax = new Map<string, Term[]>();
    for (const term of terms) {
      const list = byTax.get(term.taxonomyId) ?? [];
      list.push(term);
      byTax.set(term.taxonomyId, list);
    }

    return {
      taxonomies: attached.map((t) => {
        const all = byTax.get(t.id) ?? [];
        return {
          id: t.id,
          slug: t.slug,
          singular: t.singular,
          plural: t.plural,
          hierarchical: t.hierarchical,
          terms: all.map(serializeTerm),
          selectedTermIds: all.filter((term) => selected.has(term.id)).map((term) => term.id),
        };
      }),
    };
  } catch (error) {
    throw toHttpError(error, 'Could not load taxonomies for this content.');
  }
}

export async function setPostTaxonomies(
  postId: string,
  siteId: string,
  objectType: string,
  assignments: { taxonomyId: string; termIds: string[] }[],
) {
  try {
    const post = await Post.findOne({ where: { id: postId, siteId } });
    if (!post) throw NotFound('Content not found.');

    const taxonomies = await Taxonomy.findAll({
      where: { siteId, active: true },
    });
    const allowed = new Map(
      taxonomies
        .filter((t) => objectTypesOf(t).includes(objectType))
        .map((t) => [t.id, t] as const),
    );

    const nextTermIds = new Set<string>();
    for (const row of assignments) {
      if (!allowed.has(row.taxonomyId)) {
        throw BadRequest({ message: 'That taxonomy is not attached to this content type.' });
      }
      for (const id of row.termIds) {
        if (typeof id === 'string' && id.trim()) nextTermIds.add(id.trim());
      }
    }

    if (nextTermIds.size) {
      const valid = await Term.findAll({
        where: {
          siteId,
          id: { [Op.in]: [...nextTermIds] },
          taxonomyId: { [Op.in]: [...allowed.keys()] },
        },
        attributes: ['id'],
      });
      if (valid.length !== nextTermIds.size) {
        throw BadRequest({ message: 'One or more terms are invalid for this content.' });
      }
    }

    const existing = await TermRelationship.findAll({ where: { postId } });
    const existingIds = new Set(existing.map((e) => e.termId));

    // Drop relationships for attached taxonomies that are no longer selected.
    const attachedTermRows = await Term.findAll({
      where: { siteId, taxonomyId: { [Op.in]: [...allowed.keys()] } },
      attributes: ['id'],
    });
    const attachedTermIds = new Set(attachedTermRows.map((t) => t.id));
    const toRemove = existing.filter(
      (e) => attachedTermIds.has(e.termId) && !nextTermIds.has(e.termId),
    );
    if (toRemove.length) {
      await TermRelationship.destroy({
        where: { id: { [Op.in]: toRemove.map((r) => r.id) } },
      });
    }

    const toAdd = [...nextTermIds].filter((id) => !existingIds.has(id));
    if (toAdd.length) {
      await TermRelationship.bulkCreate(
        toAdd.map((termId) => ({
          id: createId(),
          postId,
          termId,
        })),
      );
    }

    return getPostTaxonomies(postId, siteId, objectType);
  } catch (error) {
    throw toHttpError(error, 'Could not save taxonomy terms.');
  }
}

/**
 * Who may add, rename or delete terms (WordPress rules): `manage_categories`; on product
 * taxonomies `edit_products` as well. Writers with `edit_posts` may still add tags on the fly
 * from the post editor: a new term in a flat (non-hierarchical) taxonomy of normal content.
 */
export async function assertTermAccess(
  actor: Pick<AuthUser, 'capabilities'>,
  siteId: string,
  target: { taxonomyId: string } | { termId: string },
  action: 'create' | 'change',
) {
  let taxonomyId: string;
  if ('termId' in target) {
    const term = await Term.findOne({ where: { id: target.termId, siteId }, attributes: ['taxonomyId'] });
    if (!term) throw NotFound('Term not found.');
    taxonomyId = term.taxonomyId;
  } else {
    taxonomyId = target.taxonomyId;
  }
  const taxonomy = await Taxonomy.findOne({ where: { id: taxonomyId, siteId } });
  if (!taxonomy) throw NotFound('Taxonomy not found.');

  const caps = actor.capabilities;
  const types = objectTypesOf(taxonomy);
  const forProducts = types.includes(PRODUCT_KIND);
  if (forProducts && !caps.includes('edit_products')) {
    throw Forbidden('Sorry, you are not allowed to manage product categories and tags.');
  }
  if (forProducts && types.every((t) => t === PRODUCT_KIND)) return;
  if (caps.includes('manage_categories')) return;
  if (action === 'create' && !forProducts && !taxonomy.hierarchical && caps.includes('edit_posts')) return;
  throw Forbidden('Sorry, you are not allowed to manage these terms.');
}

export async function createTerm(
  siteId: string,
  taxonomyId: string,
  input: { name: string; slug?: string; parentId?: string | null },
) {
  try {
    const taxonomy = await Taxonomy.findOne({ where: { id: taxonomyId, siteId } });
    if (!taxonomy) throw NotFound('Taxonomy not found.');
    const name = input.name.trim();
    if (!name) throw BadRequest({ message: 'Term name is required.' });
    let slug = slugify(input.slug?.trim() || name);
    if (!slug) slug = `term-${Date.now().toString(36)}`;

    let parentId: string | null = null;
    if (input.parentId) {
      if (!taxonomy.hierarchical) {
        throw BadRequest({ message: 'This taxonomy is not hierarchical.' });
      }
      const parent = await Term.findOne({
        where: { id: input.parentId, taxonomyId, siteId },
      });
      if (!parent) throw BadRequest({ message: 'Parent term not found.' });
      parentId = parent.id;
    }

    const existing = await Term.findOne({ where: { taxonomyId, slug } });
    if (existing) {
      throw BadRequest({ message: `A term with slug “${slug}” already exists.`, code: 'slug_taken' });
    }

    const count = await Term.count({ where: { taxonomyId } });
    const row = await Term.create({
      siteId,
      taxonomyId,
      name,
      slug,
      description: '',
      parentId,
      menuOrder: count,
    });
    return serializeTerm(row);
  } catch (error) {
    throw toHttpError(error, 'Could not create the term.');
  }
}

/** All terms of a taxonomy (by id or slug), with how many posts use each. */
export async function listTerms(siteId: string, taxonomyIdOrSlug: string) {
  try {
    const taxonomy = await Taxonomy.findOne({
      where: { siteId, [Op.or]: [{ id: taxonomyIdOrSlug }, { slug: taxonomyIdOrSlug }] },
    });
    if (!taxonomy) throw NotFound('Taxonomy not found.');
    const terms = await Term.findAll({
      where: { siteId, taxonomyId: taxonomy.id },
      order: [
        ['menuOrder', 'ASC'],
        ['name', 'ASC'],
      ],
    });
    const counts = await TermRelationship.findAll({
      where: { termId: { [Op.in]: terms.map((t) => t.id) } },
      attributes: ['termId'],
    });
    const countBy = new Map<string, number>();
    for (const c of counts) countBy.set(c.termId, (countBy.get(c.termId) ?? 0) + 1);
    return {
      taxonomy: {
        id: taxonomy.id,
        slug: taxonomy.slug,
        singular: taxonomy.singular,
        plural: taxonomy.plural,
        hierarchical: taxonomy.hierarchical,
      },
      terms: terms.map((t) => ({ ...serializeTerm(t), count: countBy.get(t.id) ?? 0 })),
    };
  } catch (error) {
    throw toHttpError(error, 'Could not load terms.');
  }
}

export async function updateTerm(
  siteId: string,
  termId: string,
  input: { name?: string; slug?: string; description?: string; parentId?: string | null; menuOrder?: number },
) {
  try {
    const term = await Term.findOne({ where: { id: termId, siteId } });
    if (!term) throw NotFound('Term not found.');
    const taxonomy = await Taxonomy.findOne({ where: { id: term.taxonomyId, siteId } });
    if (!taxonomy) throw NotFound('Taxonomy not found.');
    const data: Partial<{ name: string; slug: string; description: string; parentId: string | null; menuOrder: number }> = {};
    if (input.name !== undefined) {
      const name = input.name.trim();
      if (!name) throw BadRequest({ message: 'Term name is required.' });
      data.name = name;
    }
    if (input.slug !== undefined) {
      const slug = slugify(input.slug) || slugify(data.name ?? term.name);
      if (!slug) throw BadRequest({ message: 'Slug is required.' });
      const clash = await Term.findOne({ where: { taxonomyId: taxonomy.id, slug, id: { [Op.ne]: term.id } } });
      if (clash) throw BadRequest({ message: `A term with slug “${slug}” already exists.`, code: 'slug_taken' });
      data.slug = slug;
    }
    if (input.description !== undefined) data.description = input.description.trim();
    if (input.menuOrder !== undefined) data.menuOrder = input.menuOrder;
    if (input.parentId !== undefined) {
      if (!input.parentId) data.parentId = null;
      else {
        if (!taxonomy.hierarchical) throw BadRequest({ message: 'This taxonomy is not hierarchical.' });
        if (input.parentId === term.id) throw BadRequest({ message: 'A term cannot be its own parent.' });
        const parent = await Term.findOne({ where: { id: input.parentId, taxonomyId: taxonomy.id, siteId } });
        if (!parent) throw BadRequest({ message: 'Parent term not found.' });
        // No cycles: walk up from the chosen parent.
        let cursor: Term | null = parent;
        for (let i = 0; cursor && i < 50; i++) {
          if (cursor.parentId === term.id) throw BadRequest({ message: 'That parent is a child of this term.' });
          cursor = cursor.parentId ? await Term.findByPk(cursor.parentId) : null;
        }
        data.parentId = parent.id;
      }
    }
    await term.update(data);
    return serializeTerm(term);
  } catch (error) {
    throw toHttpError(error, 'Could not update the term.');
  }
}

/** Removes the term; children move up to the deleted term's parent. */
export async function deleteTerm(siteId: string, termId: string) {
  try {
    const term = await Term.findOne({ where: { id: termId, siteId } });
    if (!term) throw NotFound('Term not found.');
    await Term.update({ parentId: term.parentId ?? null }, { where: { parentId: term.id, siteId } });
    await term.destroy();
    return { ok: true };
  } catch (error) {
    throw toHttpError(error, 'Could not delete the term.');
  }
}
