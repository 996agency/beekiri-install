/**
 * Per-page SEO settings, stored on the page content document (`content.seo`).
 * Everything is optional: empty strings / defaults mean "derive from the page".
 */

export const SEO_SCHEMA_TYPES = [
  'WebPage',
  'Article',
  'BlogPosting',
  'NewsArticle',
  'Product',
  'FAQPage',
  'AboutPage',
  'ContactPage',
  'Organization',
  'LocalBusiness',
  'Event',
  'none',
] as const;

export type SeoSchemaType = (typeof SEO_SCHEMA_TYPES)[number];

export type PageSeo = {
  focusKeyword: string;
  metaTitle: string;
  metaDescription: string;
  canonicalUrl: string;
  /** Default true: index / follow. */
  robotsIndex: boolean;
  robotsFollow: boolean;
  /** Extra directives: noarchive, nosnippet, noimageindex, notranslate. */
  robotsAdvanced: string[];
  excludeFromSitemap: boolean;
  ogTitle: string;
  ogDescription: string;
  /** Media library id for the social share image. */
  ogImageId: string;
  twitterCard: 'summary_large_image' | 'summary';
  schemaType: SeoSchemaType;
  /** Author-written JSON-LD (object or array), validated as JSON on save. */
  schemaJson: string;
  /** FAQ entries for FAQPage schema. */
  faq: { question: string; answer: string }[];
};

export const EMPTY_SEO: PageSeo = {
  focusKeyword: '',
  metaTitle: '',
  metaDescription: '',
  canonicalUrl: '',
  robotsIndex: true,
  robotsFollow: true,
  robotsAdvanced: [],
  excludeFromSitemap: false,
  ogTitle: '',
  ogDescription: '',
  ogImageId: '',
  twitterCard: 'summary_large_image',
  schemaType: 'WebPage',
  schemaJson: '',
  faq: [],
};

const ROBOTS_ADVANCED = new Set(['noarchive', 'nosnippet', 'noimageindex', 'notranslate']);

const str = (v: unknown, max: number) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const bool = (v: unknown, fallback: boolean) => (typeof v === 'boolean' ? v : fallback);

/** Coerce any stored / submitted value into a well-formed PageSeo (never throws). */
export function parseSeo(raw: unknown): PageSeo {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return { ...EMPTY_SEO };
  const o = raw as Record<string, unknown>;
  const schemaType = SEO_SCHEMA_TYPES.includes(o.schemaType as SeoSchemaType)
    ? (o.schemaType as SeoSchemaType)
    : 'WebPage';
  let schemaJson = str(o.schemaJson, 20_000);
  if (schemaJson) {
    try {
      const parsed = JSON.parse(schemaJson) as unknown;
      if (!parsed || typeof parsed !== 'object') schemaJson = '';
    } catch {
      schemaJson = '';
    }
  }
  const faq = Array.isArray(o.faq)
    ? o.faq
        .slice(0, 50)
        .map((f) => {
          const r = (f && typeof f === 'object' ? f : {}) as Record<string, unknown>;
          return { question: str(r.question, 300), answer: str(r.answer, 2000) };
        })
        .filter((f) => f.question && f.answer)
    : [];
  return {
    focusKeyword: str(o.focusKeyword, 120),
    metaTitle: str(o.metaTitle, 200),
    metaDescription: str(o.metaDescription, 400),
    canonicalUrl: str(o.canonicalUrl, 2000),
    robotsIndex: bool(o.robotsIndex, true),
    robotsFollow: bool(o.robotsFollow, true),
    robotsAdvanced: Array.isArray(o.robotsAdvanced)
      ? [...new Set(o.robotsAdvanced.filter((d): d is string => typeof d === 'string' && ROBOTS_ADVANCED.has(d)))]
      : [],
    excludeFromSitemap: bool(o.excludeFromSitemap, false),
    ogTitle: str(o.ogTitle, 200),
    ogDescription: str(o.ogDescription, 400),
    ogImageId: str(o.ogImageId, 128),
    twitterCard: o.twitterCard === 'summary' ? 'summary' : 'summary_large_image',
    schemaType,
    schemaJson,
    faq,
  };
}

/** True when nothing differs from the defaults — such pages store `seo: null`. */
export function isDefaultSeo(seo: PageSeo): boolean {
  return JSON.stringify(seo) === JSON.stringify(EMPTY_SEO);
}

/** Stored form: null when untouched so old documents stay byte-identical. */
export function seoForStorage(raw: unknown): PageSeo | null {
  const seo = parseSeo(raw);
  return isDefaultSeo(seo) ? null : seo;
}
