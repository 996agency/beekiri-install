/** In-memory live presence for BeekiriCode page editors (who’s on this page + cursors). */

export type PagePresenceCursor = {
  /** Unscaled X inside the frame canvas. */
  x: number;
  /** Unscaled Y inside the frame canvas. */
  y: number;
  /** Breakpoint frame: desktop | tablet | mobile */
  frame: string;
};

export type PagePresencePeer = {
  userId: string;
  name: string;
  color: string;
  clientId: string;
  seenAt: number;
  cursor: PagePresenceCursor | null;
  selectedNodeId: string | null;
};

type PresenceListener = (pageId: string, peers: PagePresencePeer[]) => void;

const TTL_MS = 12_000;

/** pageId → clientId → peer */
const rooms = new Map<string, Map<string, PagePresencePeer>>();
const listeners = new Set<PresenceListener>();

export function onPresenceChange(listener: PresenceListener): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function emit(pageId: string, peers: PagePresencePeer[]) {
  for (const listener of listeners) {
    try {
      listener(pageId, peers);
    } catch {
      /* ignore listener errors */
    }
  }
}

export function peerColor(userId: string): string {
  let hash = 0;
  for (let i = 0; i < userId.length; i++) {
    hash = (hash * 31 + userId.charCodeAt(i)) | 0;
  }
  const hue = ((hash % 360) + 360) % 360;
  return `hsl(${hue} 70% 45%)`;
}

function prune(pageId: string, now = Date.now()) {
  const room = rooms.get(pageId);
  if (!room) return;
  for (const [cid, peer] of room) {
    if (now - peer.seenAt > TTL_MS) room.delete(cid);
  }
  if (room.size === 0) rooms.delete(pageId);
}

export function heartbeatPresence(input: {
  pageId: string;
  userId: string;
  name: string;
  clientId: string;
  cursor?: PagePresenceCursor | null;
  selectedNodeId?: string | null;
}): PagePresencePeer[] {
  const now = Date.now();
  prune(input.pageId, now);
  let room = rooms.get(input.pageId);
  if (!room) {
    room = new Map();
    rooms.set(input.pageId, room);
  }
  const prev = room.get(input.clientId);
  const cursor =
    input.cursor === undefined ? (prev?.cursor ?? null) : input.cursor;
  const selectedNodeId =
    input.selectedNodeId === undefined
      ? (prev?.selectedNodeId ?? null)
      : input.selectedNodeId;
  room.set(input.clientId, {
    userId: input.userId,
    name: input.name,
    color: peerColor(input.userId),
    clientId: input.clientId,
    seenAt: now,
    cursor,
    selectedNodeId,
  });
  const peers = listPresence(input.pageId);
  emit(input.pageId, peers);
  return peers;
}

export function listPresence(pageId: string): PagePresencePeer[] {
  prune(pageId);
  const room = rooms.get(pageId);
  if (!room) return [];
  // One chip per user (multi-tab → keep most recent client).
  const byUser = new Map<string, PagePresencePeer>();
  for (const peer of room.values()) {
    const prev = byUser.get(peer.userId);
    if (!prev || peer.seenAt > prev.seenAt) byUser.set(peer.userId, peer);
  }
  return [...byUser.values()].sort((a, b) => a.name.localeCompare(b.name));
}

export function leavePresence(pageId: string, clientId: string) {
  const room = rooms.get(pageId);
  if (!room) return;
  room.delete(clientId);
  if (room.size === 0) rooms.delete(pageId);
  emit(pageId, listPresence(pageId));
}
