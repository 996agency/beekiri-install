export type PagePreviewDoc = {
  token: string;
  expiresAt: string;
  title: string;
  excerpt: string;
  html: string;
  beekiricanva: unknown | null;
  beekiricode: unknown | null;
};

import { parseSeo, type PageSeo } from './page-seo';

export type PageContentDoc = {
  version: number;
  html: string;
  blocks: unknown[];
  /** Legacy visual editor document (`{ content, root, zones? }`). */
  beekiricanva: unknown | null;
  /** BeekiriCode page tree (`{ version, rootId, nodes }`). */
  beekiricode: unknown | null;
  /** Unpublished snapshot for “Preview changes” (does not replace live publish). */
  preview?: PagePreviewDoc | null;
  /** Per-page SEO (meta, social, robots, schema). Null = all defaults. */
  seo?: PageSeo | null;
  /** Site sections only: where on the site the section shows (see lib/pages/site-sections.ts). */
  placement?: SectionPlacement | null;
};

/** A site section shows at the top or bottom of every page, or only of the pages listed (by id). */
export type SectionPlacement = { position: 'top' | 'bottom'; pages: 'all' | string[] };

export function parsePlacement(raw: unknown): SectionPlacement | null {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const o = raw as Record<string, unknown>;
  const pages = Array.isArray(o.pages) ? o.pages.filter((p): p is string => typeof p === 'string' && p.length > 0 && p.length <= 64).slice(0, 500) : 'all';
  return { position: o.position === 'top' ? 'top' : 'bottom', pages };
}

function readCanvasDoc(raw: unknown): unknown | null {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  return raw;
}

/** Prefer beekiricanva; accept older saves that used a previous key. */
function canvasFromRecord(o: Record<string, unknown>): unknown | null {
  if (o.beekiricanva !== undefined) return readCanvasDoc(o.beekiricanva);
  const legacyKey = String.fromCharCode(112, 117, 99, 107);
  if (o[legacyKey] !== undefined) return readCanvasDoc(o[legacyKey]);
  return null;
}

/** Prefer beekiricode; accept legacy `instatic` key from earlier builds. */
function beekiricodeFromRecord(o: Record<string, unknown>): unknown | null {
  if (o.beekiricode !== undefined) return readCanvasDoc(o.beekiricode);
  if (o.instatic !== undefined) return readCanvasDoc(o.instatic);
  return null;
}

export function emptyContent(): PageContentDoc {
  return {
    version: 2,
    html: '',
    blocks: [],
    beekiricanva: null,
    beekiricode: null,
    preview: null,
    seo: null,
  };
}

function parsePreview(raw: unknown): PagePreviewDoc | null {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const o = raw as Record<string, unknown>;
  if (typeof o.token !== 'string' || !o.token) return null;
  if (typeof o.expiresAt !== 'string' || !o.expiresAt) return null;
  return {
    token: o.token,
    expiresAt: o.expiresAt,
    title: typeof o.title === 'string' ? o.title : '',
    excerpt: typeof o.excerpt === 'string' ? o.excerpt : '',
    html: typeof o.html === 'string' ? o.html : '',
    beekiricanva: canvasFromRecord(o),
    beekiricode: beekiricodeFromRecord(o),
  };
}

export function parseContent(raw: unknown): PageContentDoc {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return emptyContent();
  const o = raw as Record<string, unknown>;
  const beekiricanva = canvasFromRecord(o);
  const beekiricode = beekiricodeFromRecord(o);
  return {
    version: typeof o.version === 'number' ? o.version : beekiricanva || beekiricode ? 2 : 1,
    html: typeof o.html === 'string' ? o.html : typeof o.body === 'string' ? o.body : '',
    blocks: Array.isArray(o.blocks) ? o.blocks : [],
    beekiricanva,
    beekiricode,
    preview: parsePreview(o.preview),
    seo: o.seo && typeof o.seo === 'object' ? parseSeo(o.seo) : null,
    placement: parsePlacement(o.placement),
  };
}

export function contentFromHtml(html: string): PageContentDoc {
  return {
    version: 1,
    html: html ?? '',
    blocks: [],
    beekiricanva: null,
    beekiricode: null,
    preview: null,
  };
}

export function contentFromBeekiricanva(
  doc: unknown,
  html = '',
  beekiricode: unknown | null = null,
): PageContentDoc {
  return {
    version: 2,
    html: html ?? '',
    blocks: [],
    beekiricanva: doc && typeof doc === 'object' ? doc : null,
    beekiricode: beekiricode && typeof beekiricode === 'object' ? beekiricode : null,
    preview: null,
  };
}

export function contentFromBeekiriCode(
  doc: unknown,
  html = '',
  beekiricanva: unknown | null = null,
): PageContentDoc {
  return {
    version: 2,
    html: html ?? '',
    blocks: [],
    beekiricanva: beekiricanva && typeof beekiricanva === 'object' ? beekiricanva : null,
    beekiricode: doc && typeof doc === 'object' ? doc : null,
    preview: null,
  };
}

/** @deprecated Use contentFromBeekiriCode */
export const contentFromInstatic = contentFromBeekiriCode;

export function toSlug(raw: string): string {
  return raw
    .toLowerCase()
    .trim()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 180);
}
