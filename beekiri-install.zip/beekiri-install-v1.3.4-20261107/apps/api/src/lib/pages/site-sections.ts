import { Post, PostType } from '../../models';
import { pageThemeScope } from '../../services/themes.service';
import { parseContent, type SectionPlacement } from './pages.content';
import { withoutPending } from './pending';

/**
 * Site sections: content built once in the page editor (a popup, a banner, a newsletter strip…) that
 * shows on every page, or on the pages chosen, at the top or bottom. Each one is an entry of the
 * built-in "Site sections" content type; published = on, draft = off. The public site merges them
 * into each page it serves, so one edit updates the whole site.
 */

export const SITE_SECTION_KIND = 'site-section';

type Node = { id: string; children?: string[] } & Record<string, unknown>;
type Doc = { rootId: string; nodes: Record<string, Node> } & Record<string, unknown>;

function isDoc(doc: unknown): doc is Doc {
  if (!doc || typeof doc !== 'object') return false;
  const d = doc as Partial<Doc>;
  return typeof d.rootId === 'string' && !!d.nodes && typeof d.nodes === 'object' && !!d.nodes[d.rootId];
}

/** The "Site sections" content type (admin menu + editor), made the first time it is needed. */
export async function ensureSiteSectionType(siteId: string): Promise<void> {
  const existing = await PostType.findOne({ where: { siteId, slug: SITE_SECTION_KIND } });
  if (existing) {
    if (!existing.active) await existing.update({ active: true });
    return;
  }
  await PostType.create({
    siteId,
    slug: SITE_SECTION_KIND,
    singular: 'Site section',
    plural: 'Site sections',
    description: 'Popups, banners and other sections that show on every page (or the pages you choose).',
    public: false,
    hierarchical: false,
    hasArchive: false,
    showInMenu: true,
    supports: ['title', 'editor'],
    active: true,
    menuOrder: 90,
    menuIcon: 'Files',
    archiveDesign: 'list',
    singleDesign: 'default',
  } as never);
}

export function placementOf(raw: unknown): SectionPlacement {
  const p = parseContent(raw).placement;
  return p ?? { position: 'bottom', pages: 'all' };
}

/**
 * The page with this theme's published site sections merged in (those meant for it). Visitors get
 * them without anything still waiting for Keep; the owner's preview (`preview`) includes that too.
 */
export async function withSiteSections<T>(siteId: string, pageId: string, doc: T, opts: { preview?: boolean } = {}): Promise<T> {
  if (!isDoc(doc)) return doc;
  const rows = await Post.findAll({
    where: { siteId, type: SITE_SECTION_KIND, status: 'publish', ...(await pageThemeScope(SITE_SECTION_KIND)) },
    attributes: ['id', 'content'],
    order: [
      ['menuOrder', 'ASC'],
      ['createdAt', 'ASC'],
    ],
  });
  if (!rows.length) return doc;

  const nodes: Record<string, Node> = { ...doc.nodes };
  const top: string[] = [];
  const bottom: string[] = [];
  for (const row of rows) {
    const placement = placementOf(row.content);
    if (placement.pages !== 'all' && !placement.pages.includes(pageId)) continue;
    const raw = parseContent(row.content).beekiricode;
    const section = opts.preview ? raw : withoutPending(raw);
    if (!isDoc(section)) continue;
    // Its own ids, so they never clash with the page's.
    const prefix = `ss${row.id.slice(-8)}_`;
    const copy = (id: string): string | null => {
      const n = section.nodes[id];
      if (!n) return null;
      const nid = `${prefix}${id}`;
      nodes[nid] = { ...n, id: nid, children: (n.children ?? []).map(copy).filter((c): c is string => c !== null) };
      return nid;
    };
    const kids = (section.nodes[section.rootId].children ?? []).map(copy).filter((c): c is string => c !== null);
    (placement.position === 'top' ? top : bottom).push(...kids);
  }
  if (!top.length && !bottom.length) return doc;
  const root = doc.nodes[doc.rootId];
  nodes[doc.rootId] = { ...root, children: [...top, ...(root.children ?? []), ...bottom] };
  return { ...doc, nodes } as T;
}
