import type { IncomingMessage, Server } from 'http';
import { parse as parseUrl } from 'url';
import { WebSocketServer, type WebSocket } from 'ws';
import { isAllowedOrigin } from '../../middleware/security';
import { SESSION_COOKIE, authService } from '../../services/auth.service';
import { pagesService } from '../../services/pages.service';
import { createLogger } from '../../utils/logger';
import type { ContentKind } from './content-kind';
import {
  heartbeatPresence,
  leavePresence,
  onPresenceChange,
  type PagePresenceCursor,
  type PagePresencePeer,
} from './pages.presence';

const log = createLogger('presence-ws');
const MAX_DOC_CHARS = 1_500_000;

type SocketState = {
  pageId: string;
  clientId: string;
  userId: string;
  name: string;
};

type LiveDoc = {
  clientId: string;
  userId: string;
  name: string;
  rev: number;
  doc: unknown;
  at: number;
};

type ClientMsg =
  | {
      type: 'cursor';
      cursor?: PagePresenceCursor | null;
      selectedNodeId?: string | null;
    }
  | {
      type: 'doc';
      rev: number;
      doc: unknown;
    }
  | { type: 'ping' };

/** Latest in-memory live doc per page (not persisted — saves still go through PATCH). */
const liveDocs = new Map<string, LiveDoc>();

function parseCookies(header: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    const k = part.slice(0, i).trim();
    const v = part.slice(i + 1).trim();
    if (k) {
      try {
        out[k] = decodeURIComponent(v);
      } catch {
        out[k] = v;
      }
    }
  }
  return out;
}

function originAllowed(req: IncomingMessage): boolean {
  const origin = req.headers.origin;
  if (!origin) return true;
  if (isAllowedOrigin(origin)) return true;
  const host = req.headers.host;
  if (!host) return false;
  return origin === `http://${host}` || origin === `https://${host}`;
}

function sendJson(ws: WebSocket, payload: unknown) {
  if (ws.readyState !== ws.OPEN) return;
  ws.send(JSON.stringify(payload));
}

function sendPeers(ws: WebSocket, peers: PagePresencePeer[]) {
  sendJson(ws, { type: 'peers', peers });
}

function broadcastDoc(
  sockets: Map<WebSocket, SocketState>,
  pageId: string,
  except: WebSocket | null,
  payload: unknown,
) {
  for (const [ws, state] of sockets) {
    if (state.pageId !== pageId) continue;
    if (except && ws === except) continue;
    sendJson(ws, payload);
  }
}

/**
 * Live cursor + document channel:
 * `ws(s)://{host}/api/presence/ws?pageId=&clientId=&kind=`
 */
export function attachPresenceWebSocket(server: Server): void {
  const wss = new WebSocketServer({ noServer: true });
  const sockets = new Map<WebSocket, SocketState>();

  const stopListen = onPresenceChange((pageId, peers) => {
    for (const [ws, state] of sockets) {
      if (state.pageId === pageId) sendPeers(ws, peers);
    }
  });

  server.on('upgrade', (req, socket, head) => {
    const { pathname, query } = parseUrl(req.url || '', true);
    if (pathname !== '/api/presence/ws') return;

    void (async () => {
      try {
        if (!originAllowed(req)) {
          socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
          socket.destroy();
          return;
        }

        const pageId = typeof query.pageId === 'string' ? query.pageId.trim() : '';
        const clientId = typeof query.clientId === 'string' ? query.clientId.trim() : '';
        const kindRaw = typeof query.kind === 'string' ? query.kind.trim() : 'page';
        const kind = (kindRaw || 'page') as ContentKind;

        if (!pageId || !clientId || clientId.length > 80) {
          socket.write('HTTP/1.1 400 Bad Request\r\n\r\n');
          socket.destroy();
          return;
        }

        const cookies = parseCookies(req.headers.cookie);
        const token = cookies[SESSION_COOKIE];
        const session = token ? await authService.resolveSession(token) : null;
        if (!session?.user) {
          socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
          socket.destroy();
          return;
        }

        // Same gate as the HTTP editor routes: the edit capability for this kind, and
        // ownership (or edit_others_*) of the item itself.
        const editCap = kind === 'page' ? 'edit_pages' : 'edit_posts';
        if (!session.user.capabilities.includes(editCap)) {
          socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
          socket.destroy();
          return;
        }
        await pagesService.assertEditable(session.user, pageId, kind);

        wss.handleUpgrade(req, socket, head, (ws) => {
          const state: SocketState = {
            pageId,
            clientId,
            userId: session.user.id,
            name: session.user.displayName?.trim() || session.user.username,
          };
          sockets.set(ws, state);

          const peers = heartbeatPresence({
            pageId,
            userId: state.userId,
            name: state.name,
            clientId,
            cursor: null,
            selectedNodeId: null,
          });
          sendPeers(ws, peers);

          const existing = liveDocs.get(pageId);
          if (existing) {
            sendJson(ws, {
              type: 'doc',
              clientId: existing.clientId,
              userId: existing.userId,
              name: existing.name,
              rev: existing.rev,
              doc: existing.doc,
            });
          }

          ws.on('message', (raw) => {
            try {
              const text = String(raw);
              if (text.length > MAX_DOC_CHARS + 2000) return;
              const msg = JSON.parse(text) as ClientMsg;
              if (msg.type === 'ping') {
                sendJson(ws, { type: 'pong' });
                return;
              }
              if (msg.type === 'cursor') {
                heartbeatPresence({
                  pageId: state.pageId,
                  userId: state.userId,
                  name: state.name,
                  clientId: state.clientId,
                  cursor: msg.cursor ?? null,
                  selectedNodeId: msg.selectedNodeId ?? null,
                });
                return;
              }
              if (msg.type === 'doc') {
                if (
                  typeof msg.rev !== 'number' ||
                  !Number.isFinite(msg.rev) ||
                  msg.doc == null ||
                  typeof msg.doc !== 'object'
                ) {
                  return;
                }
                const encoded = JSON.stringify(msg.doc);
                if (encoded.length > MAX_DOC_CHARS) return;

                const prev = liveDocs.get(state.pageId);
                if (
                  prev &&
                  prev.clientId === state.clientId &&
                  msg.rev <= prev.rev
                ) {
                  return;
                }

                const next: LiveDoc = {
                  clientId: state.clientId,
                  userId: state.userId,
                  name: state.name,
                  rev: msg.rev,
                  doc: msg.doc,
                  at: Date.now(),
                };
                liveDocs.set(state.pageId, next);
                broadcastDoc(sockets, state.pageId, ws, {
                  type: 'doc',
                  clientId: next.clientId,
                  userId: next.userId,
                  name: next.name,
                  rev: next.rev,
                  doc: next.doc,
                });
              }
            } catch {
              /* ignore bad frames */
            }
          });

          const cleanup = () => {
            if (!sockets.has(ws)) return;
            sockets.delete(ws);
            leavePresence(state.pageId, state.clientId);
            // Drop live doc buffer when the room empties.
            let anyoneLeft = false;
            for (const s of sockets.values()) {
              if (s.pageId === state.pageId) {
                anyoneLeft = true;
                break;
              }
            }
            if (!anyoneLeft) liveDocs.delete(state.pageId);
          };
          ws.on('close', cleanup);
          ws.on('error', cleanup);
        });
      } catch (error) {
        log.warn('Presence websocket upgrade failed', error);
        try {
          socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
        } catch {
          /* ignore */
        }
        socket.destroy();
      }
    })();
  });

  server.on('close', () => {
    stopListen();
    wss.close();
  });
}
