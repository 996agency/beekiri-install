/**
 * Elements Beekiri adds to a live page wait for the owner: they carry `pending` (the Beekiri message,
 * i.e. run id, that added them) and stay out of everything the public site gets until the owner
 * presses Keep. The editor and the owner's preview still show them; Undo removes them.
 */

type Node = { id?: string; pending?: string; children?: string[] } & Record<string, unknown>;
type Doc = { rootId: string; nodes: Record<string, Node> } & Record<string, unknown>;

function isDoc(doc: unknown): doc is Doc {
  if (!doc || typeof doc !== 'object') return false;
  const d = doc as Partial<Doc>;
  return typeof d.rootId === 'string' && !!d.nodes && typeof d.nodes === 'object';
}

/** Does this page hold elements still waiting for Keep (from one message, or any)? */
export function hasPending(doc: unknown, runId?: string): boolean {
  if (!isDoc(doc)) return false;
  return Object.values(doc.nodes).some((n) => n && typeof n.pending === 'string' && (!runId || n.pending === runId));
}

/** The page as the public sees it: pending elements, and everything inside them, left out. */
export function withoutPending<T>(doc: T): T {
  if (!isDoc(doc) || !hasPending(doc)) return doc;
  const nodes: Record<string, Node> = {};
  const visit = (id: string): boolean => {
    const n = doc.nodes[id];
    if (!n || typeof n.pending === 'string' || nodes[id]) return false;
    nodes[id] = { ...n, children: (n.children ?? []).filter(visit) };
    return true;
  };
  visit(doc.rootId);
  return { ...doc, nodes } as T;
}

/** Keep: this message's elements become ordinary (public) ones. Returns the page and how many were kept. */
export function keepPending<T>(doc: T, runId: string): { doc: T; kept: number } {
  if (!isDoc(doc)) return { doc, kept: 0 };
  let kept = 0;
  const nodes: Record<string, Node> = {};
  for (const [id, n] of Object.entries(doc.nodes)) {
    if (n && n.pending === runId) {
      const { pending: _pending, ...rest } = n;
      nodes[id] = rest;
      kept++;
    } else {
      nodes[id] = n;
    }
  }
  return { doc: { ...doc, nodes } as T, kept };
}
