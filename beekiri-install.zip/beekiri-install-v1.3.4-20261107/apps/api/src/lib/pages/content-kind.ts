import type { CapabilitySlug } from '../cms-types';
import { PRODUCT_KIND, SHOP_PAGE_KIND, type ShopPageView } from '../shop/constants';

/** Shared page/post/CPT document kinds on the `Post` model (`type` column). */

export type BuiltinContentKind = 'page' | 'post';
export type ContentKind = BuiltinContentKind | (string & {});

export type ContentKindConfig = {
  kind: ContentKind;
  type: string;
  /** Needed to open the list / create / save items of this kind. */
  editCap: CapabilitySlug;
  publishCap: CapabilitySlug;
  /** Needed to open, change or remove an item someone else created. */
  editOthersCap: CapabilitySlug;
  deleteCap: CapabilitySlug;
  listKey: string;
  itemKey: string;
  label: string;
  labelPlural: string;
  notFound: string;
  conflictSlug: string;
  cannotPublish: string;
  cannotRestorePublish: string;
  defaultSlugBase: string;
  pathOf: (slug: string) => string;
};

export const CONTENT_KINDS: Record<BuiltinContentKind, ContentKindConfig> = {
  page: {
    kind: 'page',
    type: 'page',
    editCap: 'edit_pages',
    publishCap: 'publish_pages',
    editOthersCap: 'edit_others_pages',
    deleteCap: 'delete_pages',
    listKey: 'pages',
    itemKey: 'page',
    label: 'Page',
    labelPlural: 'Pages',
    notFound: 'Page not found.',
    conflictSlug: 'A page with that slug already exists.',
    cannotPublish: 'You cannot publish pages.',
    cannotRestorePublish: 'You cannot restore a published revision.',
    defaultSlugBase: 'page',
    pathOf: (slug) => `/${slug}`,
  },
  post: {
    kind: 'post',
    type: 'post',
    editCap: 'edit_posts',
    publishCap: 'publish_posts',
    editOthersCap: 'edit_others_posts',
    deleteCap: 'delete_posts',
    listKey: 'posts',
    itemKey: 'post',
    label: 'Post',
    labelPlural: 'Posts',
    notFound: 'Post not found.',
    conflictSlug: 'A post with that slug already exists.',
    cannotPublish: 'You cannot publish posts.',
    cannotRestorePublish: 'You cannot restore a published revision.',
    defaultSlugBase: 'post',
    pathOf: (slug) => `/blog/${slug}`,
  },
};

/** Slugs that cannot be registered as custom post types. */
export const RESERVED_CONTENT_SLUGS = new Set([
  'page',
  'pages',
  'post',
  'posts',
  'blog',
  'admin',
  'api',
  'media',
  'login',
  'install',
  'fields',
  'users',
  'settings',
  'analytics',
  'seo',
  'appearance',
  'wp-admin',
  'wp-json',
  'assets',
  'uploads',
  'health',
  'new',
  // Shopping extension storefront paths.
  'shop',
  'product',
  'products',
  'cart',
  'checkout',
  'order',
  'shop_page',
  'account',
  // Bee Forms.
  'form',
  'forms',
]);

/** Storefront pages edited in BeekiriCode (Shop → Shop Editor). Slug = view; the path is fixed. */
const SHOP_PAGE_PATHS: Record<string, string> = {
  shop: '/shop',
  product: '/product',
  cart: '/cart',
  checkout: '/checkout',
  'order-received': '/checkout/order-received',
  account: '/account',
};
const SHOP_PAGE_KIND_CONFIG: ContentKindConfig = {
  kind: SHOP_PAGE_KIND,
  type: SHOP_PAGE_KIND,
  editCap: 'edit_products',
  publishCap: 'edit_products',
  editOthersCap: 'edit_products',
  deleteCap: 'manage_shop',
  listKey: 'items',
  itemKey: 'item',
  label: 'Shop page',
  labelPlural: 'Shop pages',
  notFound: 'Shop page not found.',
  conflictSlug: 'A shop page with that slug already exists.',
  cannotPublish: 'You cannot publish shop pages.',
  cannotRestorePublish: 'You cannot restore a published revision.',
  defaultSlugBase: 'shop-page',
  pathOf: (slug) => SHOP_PAGE_PATHS[slug as ShopPageView] ?? `/shop/${slug}`,
};

/**
 * Products (Shopping extension): the `product` post type is managed by the extension,
 * lives at /product/{slug} and is guarded by `edit_products` instead of the post caps.
 */
const PRODUCT_KIND_CONFIG: ContentKindConfig = {
  kind: PRODUCT_KIND,
  type: PRODUCT_KIND,
  editCap: 'edit_products',
  publishCap: 'edit_products',
  editOthersCap: 'edit_products',
  deleteCap: 'edit_products',
  listKey: 'items',
  itemKey: 'item',
  label: 'Product',
  labelPlural: 'Products',
  notFound: 'Product not found.',
  conflictSlug: 'A product with that slug already exists.',
  cannotPublish: 'You cannot publish products.',
  cannotRestorePublish: 'You cannot restore a published revision.',
  defaultSlugBase: 'product',
  pathOf: (slug) => `/product/${slug}`,
};

export type CptLabels = { singular?: string; plural?: string };

export function contentKindConfig(kind: ContentKind = 'page', labels?: CptLabels): ContentKindConfig {
  if (kind === 'page') return CONTENT_KINDS.page;
  if (kind === 'post') return CONTENT_KINDS.post;
  if (kind === PRODUCT_KIND) return PRODUCT_KIND_CONFIG;
  if (kind === SHOP_PAGE_KIND) return SHOP_PAGE_KIND_CONFIG;

  const singular = (labels?.singular || kind).trim() || kind;
  const plural = (labels?.plural || `${singular}s`).trim() || `${singular}s`;
  return {
    kind,
    type: kind,
    editCap: 'edit_posts',
    publishCap: 'publish_posts',
    editOthersCap: 'edit_others_posts',
    deleteCap: 'delete_posts',
    listKey: 'items',
    itemKey: 'item',
    label: singular,
    labelPlural: plural,
    notFound: `${singular} not found.`,
    conflictSlug: `A ${singular.toLowerCase()} with that slug already exists.`,
    cannotPublish: `You cannot publish ${plural.toLowerCase()}.`,
    cannotRestorePublish: 'You cannot restore a published revision.',
    defaultSlugBase: kind,
    pathOf: (slug) => `/${kind}/${slug}`,
  };
}

export function isBuiltinContentKind(kind: string): kind is BuiltinContentKind {
  return kind === 'page' || kind === 'post';
}
