import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'fs';
import { join } from 'path';
import { REPO_ROOT } from '../../config/paths';

/** Official parent theme. Core updates replace files in this folder. */
export const PARENT_THEME_SLUG = 'beekiri';
/** Default active theme. Site-specific overrides; never overwritten by core updates. */
export const DEFAULT_THEME_SLUG = 'beekiri-child';

/** Themes that ship with the CMS — cannot be deleted. */
export const BUILTIN_THEME_SLUGS = new Set([PARENT_THEME_SLUG, DEFAULT_THEME_SLUG]);

export function resolveThemeSlug(raw: string): string {
  return sanitizeThemeSlug(raw);
}

/** Site-wide theme parts rendered around every page. */
export type ThemeChromeKind = 'header' | 'footer';

export const THEME_CHROME_KINDS: ThemeChromeKind[] = ['header', 'footer'];

export type ThemeChromeEntry = {
  slug: string;
  title: string;
  /** Folder inside the theme, e.g. `header` → themes/{theme}/header/ */
  path: string;
  description?: string;
  default?: boolean;
};

/** @deprecated Use ThemeChromeEntry */
export type ThemeChromeHeader = ThemeChromeEntry;

export type ThemeManifest = {
  slug: string;
  name: string;
  version: string;
  description: string;
  author: string;
  tags: string[];
  /** Parent theme slug (WordPress-style child theme). */
  parent?: string;
  /**
   * Set on the child Beekiri makes for a store theme (`be-chair-child` → `be-chair`): it holds
   * the site's own files for that theme, is read before it, and theme updates never touch it.
   */
  companionOf?: string;
  requires?: string;
  /** Beekiri extensions this theme needs active (e.g. `["shopping"]` for a shop theme). */
  requiresExtensions?: string[];
  screenshot?: string;
  stylesheet?: string;
  chrome?: Partial<Record<ThemeChromeKind, string>>;
  headers?: ThemeChromeEntry[];
  footers?: ThemeChromeEntry[];
  builtin: boolean;
};

/** Built-in fallback when the themes folder is missing. */
const BUILTIN: ThemeManifest[] = [
  {
    slug: PARENT_THEME_SLUG,
    name: 'Beekiri',
    version: '1.0.0',
    description:
      'Official parent theme. Copy a file into Beekiri Child to override it.',
    author: '996agency',
    tags: ['starter', 'parent', 'blog', 'business'],
    requires: '1.0.0',
    screenshot: 'screenshot.svg',
    stylesheet: 'style.css',
    builtin: true,
  },
  {
    slug: DEFAULT_THEME_SLUG,
    name: 'Beekiri Child',
    parent: PARENT_THEME_SLUG,
    version: '1.0.0',
    description:
      'Default theme. Edit files here so core updates do not overwrite your work.',
    author: '996agency',
    tags: ['child', 'custom'],
    requires: '1.0.0',
    screenshot: 'screenshot.svg',
    stylesheet: 'style.css',
    builtin: true,
  },
];

export function resolveThemesRoot(): string {
  // Frontend themes live with the public web app (BEEKIRI_THEMES_DIR moves them, e.g. for tests).
  const override = process.env.BEEKIRI_THEMES_DIR?.trim();
  if (override) return override;
  return join(REPO_ROOT, 'apps/web/themes');
}

export function sanitizeThemeSlug(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/[^a-z0-9-_]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
}

export function isThemeChromeKind(raw: string): raw is ThemeChromeKind {
  return (THEME_CHROME_KINDS as string[]).includes(raw);
}

function parseChromeEntries(raw: unknown): ThemeChromeEntry[] | undefined {
  if (!Array.isArray(raw)) return undefined;
  const out: ThemeChromeEntry[] = [];
  for (const row of raw) {
    if (!row || typeof row !== 'object' || Array.isArray(row)) continue;
    const r = row as Record<string, unknown>;
    const slug = typeof r.slug === 'string' ? sanitizeThemeSlug(r.slug) : '';
    if (!slug) continue;
    const path =
      typeof r.path === 'string' && r.path.trim() ? r.path.trim().replace(/^\/+|\/+$/g, '') : slug;
    if (path.includes('..') || path.includes('\\')) continue;
    out.push({
      slug,
      title: typeof r.title === 'string' && r.title.trim() ? r.title.trim() : slug,
      path,
      description: typeof r.description === 'string' ? r.description.trim() : undefined,
      default: r.default === true,
    });
  }
  return out.length ? out : undefined;
}

function parseChrome(raw: unknown): ThemeManifest['chrome'] {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return undefined;
  const r = raw as Record<string, unknown>;
  const chrome: ThemeManifest['chrome'] = {};
  for (const kind of THEME_CHROME_KINDS) {
    if (typeof r[kind] === 'string') chrome[kind] = sanitizeThemeSlug(r[kind] as string);
  }
  return chrome;
}

function readManifest(dir: string, slug: string): ThemeManifest | null {
  const file = join(dir, 'theme.json');
  if (!existsSync(file)) return null;
  try {
    const raw = JSON.parse(readFileSync(file, 'utf8')) as Record<string, unknown>;
    const name = typeof raw.name === 'string' ? raw.name.trim() : '';
    if (!name) return null;
    const resolvedSlug =
      typeof raw.slug === 'string' && raw.slug.trim()
        ? sanitizeThemeSlug(raw.slug)
        : sanitizeThemeSlug(slug);
    if (!resolvedSlug) return null;
    const parentRaw = typeof raw.parent === 'string' ? resolveThemeSlug(raw.parent) : '';
    const parent = parentRaw && parentRaw !== resolvedSlug ? parentRaw : undefined;
    const companionRaw = typeof raw.companionOf === 'string' ? resolveThemeSlug(raw.companionOf) : '';
    return {
      slug: resolvedSlug,
      name,
      version: typeof raw.version === 'string' ? raw.version : '1.0.0',
      description: typeof raw.description === 'string' ? raw.description : '',
      author: typeof raw.author === 'string' ? raw.author : '',
      tags: Array.isArray(raw.tags)
        ? raw.tags.filter((t): t is string => typeof t === 'string')
        : [],
      parent,
      companionOf: companionRaw && companionRaw === parent ? companionRaw : undefined,
      requires: typeof raw.requires === 'string' ? raw.requires : undefined,
      requiresExtensions: Array.isArray(raw.requiresExtensions)
        ? raw.requiresExtensions.filter((e): e is string => typeof e === 'string' && /^[a-z0-9-]{1,64}$/.test(e))
        : undefined,
      screenshot: typeof raw.screenshot === 'string' ? raw.screenshot : 'screenshot.svg',
      stylesheet: typeof raw.stylesheet === 'string' ? raw.stylesheet : 'style.css',
      chrome: parseChrome(raw.chrome),
      headers: parseChromeEntries(raw.headers),
      footers: parseChromeEntries(raw.footers),
      builtin: BUILTIN_THEME_SLUGS.has(resolvedSlug),
    };
  } catch {
    return null;
  }
}

export function listThemeManifests(): ThemeManifest[] {
  const root = resolveThemesRoot();
  const bySlug = new Map<string, ThemeManifest>();

  for (const theme of BUILTIN) bySlug.set(theme.slug, theme);

  if (existsSync(root)) {
    for (const entry of readdirSync(root, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      if (entry.name.startsWith('.')) continue;
      const manifest = readManifest(join(root, entry.name), entry.name);
      if (!manifest) continue;
      // Prefer filesystem copy for builtins (local edits), keep builtin flag.
      bySlug.set(manifest.slug, {
        ...manifest,
        builtin: BUILTIN_THEME_SLUGS.has(manifest.slug),
      });
    }
  }

  return [...bySlug.values()].sort((a, b) => {
    if (a.slug === DEFAULT_THEME_SLUG) return -1;
    if (b.slug === DEFAULT_THEME_SLUG) return 1;
    return a.name.localeCompare(b.name);
  });
}

export function getThemeManifest(slug: string): ThemeManifest | null {
  const clean = resolveThemeSlug(slug);
  return listThemeManifests().find((t) => t.slug === clean) ?? null;
}

/**
 * Active theme first, then each parent. Used to locate a file the child did not override.
 * A store theme starts at its child (`be-chair` → be-chair-child, be-chair, beekiri), so the
 * site's own files win over the theme's.
 */
export function themeAncestry(slug: string): string[] {
  const manifests = listThemeManifests();
  const seen = new Set<string>();
  const chain: string[] = [];
  const start = resolveThemeSlug(slug);
  let current = manifests.find((t) => t.companionOf === start)?.slug ?? start;
  while (current && !seen.has(current) && chain.length < 5) {
    seen.add(current);
    const manifest = manifests.find((t) => t.slug === current);
    if (!manifest) break;
    chain.push(manifest.slug);
    current = manifest.parent ? resolveThemeSlug(manifest.parent) : '';
  }
  return chain;
}

function isSafeRel(rel: string): boolean {
  return Boolean(rel) && !rel.includes('..') && !rel.includes('\\') && !rel.startsWith('/');
}

/** First existing file along the child → parent chain. */
export function resolveThemePath(slug: string, rel: string): string | null {
  if (!isSafeRel(rel)) return null;
  const root = resolveThemesRoot();
  for (const theme of themeAncestry(slug)) {
    const abs = join(root, theme, rel);
    if (existsSync(abs)) return abs;
  }
  return null;
}

/** Theme folder that contains `rel`, or null. */
export function themeOwningPath(slug: string, rel: string): string | null {
  if (!isSafeRel(rel)) return null;
  const root = resolveThemesRoot();
  for (const theme of themeAncestry(slug)) {
    if (existsSync(join(root, theme, rel))) return theme;
  }
  return null;
}

export function resolveThemeFile(slug: string, file: string): string | null {
  if (!file || file.includes('/') || file.includes('\\') || file.includes('..')) return null;
  return resolveThemePath(slug, file);
}

export function resolveThemeDir(slug: string): string | null {
  const clean = resolveThemeSlug(slug);
  if (!clean) return null;
  const abs = join(resolveThemesRoot(), clean);
  return existsSync(abs) ? abs : null;
}

/**
 * Theme folder for site-specific writes (layouts, CPT stubs, chrome overrides).
 * Never the parent `beekiri` theme — core updates own that tree.
 * Prefer the active theme when it is a child; otherwise `beekiri-child`.
 */
export function resolveClientThemeSlug(activeSlug?: string | null): string {
  const active = resolveThemeSlug((activeSlug ?? '').trim());
  if (active && active !== PARENT_THEME_SLUG) return active;
  return DEFAULT_THEME_SLUG;
}

/** Absolute path for client writes (a store theme's child folder; see writableThemeSlug). */
export function resolveClientThemeDir(activeSlug?: string | null): string {
  return join(resolveThemesRoot(), writableThemeSlug(resolveClientThemeSlug(activeSlug)));
}

/* ── Child themes of store themes ─────────────────────────────────────────── */

/** Folder name of a store theme's child. */
export function companionChildSlug(slug: string): string {
  return `${resolveThemeSlug(slug)}-child`;
}

/**
 * Store themes (anything but the core Beekiri themes, and not a child itself) get a child of
 * their own, like Beekiri has Beekiri Child.
 */
export function wantsCompanionChild(theme: ThemeManifest): boolean {
  return !theme.builtin && !theme.companionOf && (!theme.parent || theme.parent === PARENT_THEME_SLUG);
}

/**
 * Makes the store theme's child folder when it is missing (theme.json, README, layouts/) and
 * returns its slug. An existing folder is never changed.
 */
export function ensureCompanionChild(theme: ThemeManifest): string {
  const slug = companionChildSlug(theme.slug);
  const dir = join(resolveThemesRoot(), slug);
  if (existsSync(join(dir, 'theme.json'))) return slug;
  mkdirSync(join(dir, 'layouts'), { recursive: true });
  const manifest = {
    slug,
    name: `${theme.name} Child`,
    parent: theme.slug,
    companionOf: theme.slug,
    version: '1.0.0',
    description: `Customisations for ${theme.name}. Files in this child theme override the matching files in ${theme.name}. Theme updates and Beekiri Core updates never modify this folder.`,
    author: '',
    tags: ['child', 'custom'],
  };
  writeFileSync(join(dir, 'theme.json'), `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
  writeFileSync(
    join(dir, 'README.md'),
    `# ${theme.name} Child

This child theme stores the site's customisations for **${theme.name}**. Beekiri reads files
from this folder first, then from \`../${theme.slug}\`. Theme updates and Beekiri Core updates
never modify this folder.

- Layouts created in **Backend Fields** are saved to \`layouts/\` automatically.
- To override a theme file, copy it from \`../${theme.slug}/\` to the same path here and edit the
  copy. For a header or footer, copy the entire folder (for example \`header/\`), because its
  styles, scripts and fonts are loaded from that folder.
`,
    'utf8',
  );
  return slug;
}

/**
 * The theme folder the site writes to for `clientSlug`: a store theme's child (made when
 * missing), so updating the theme never removes what the site added. Other themes: itself.
 */
export function writableThemeSlug(clientSlug: string): string {
  const clean = resolveThemeSlug(clientSlug);
  const theme = listThemeManifests().find((t) => t.slug === clean);
  if (!theme || !wantsCompanionChild(theme)) return clean;
  return ensureCompanionChild(theme);
}

export type ThemeChromeField = {
  name: string;
  type: string;
  defaultValue?: unknown;
};

export type ThemeChromeOption = ThemeChromeEntry & {
  kind: ThemeChromeKind;
  theme: string;
  description: string;
  /** Absolute folder on disk (API only — strip before sending to clients). */
  dir: string | null;
  /**
   * The same folder along the child → parent chain (API only). A child can override just its
   * markup and keep the parent's styles, script, fonts and meta.
   */
  dirs: string[];
  fields: ThemeChromeField[];
  hasPhp: boolean;
  hasReact: boolean;
};

/** @deprecated Use ThemeChromeOption */
export type ThemeHeaderOption = ThemeChromeOption;

function readChromeMeta(
  dir: string,
  entry: ThemeChromeEntry,
  kind: ThemeChromeKind,
): { title?: string; description?: string; fields: ThemeChromeField[] } {
  const candidates = [join(dir, `${entry.slug}.meta.json`), join(dir, `${kind}.meta.json`)];
  const file = candidates.find((p) => existsSync(p));
  if (!file) return { fields: [] };
  try {
    const meta = JSON.parse(readFileSync(file, 'utf8')) as {
      title?: unknown;
      description?: unknown;
      fields?: unknown;
    };
    const fields = Array.isArray(meta.fields)
      ? meta.fields
          .filter(
            (f): f is { name: string; type?: unknown; defaultValue?: unknown } =>
              !!f && typeof f === 'object' && typeof (f as { name?: unknown }).name === 'string',
          )
          .map((f) => ({
            name: f.name,
            type: typeof f.type === 'string' ? f.type : 'text',
            defaultValue: f.defaultValue,
          }))
      : [];
    return {
      title: typeof meta.title === 'string' && meta.title.trim() ? meta.title.trim() : undefined,
      description:
        typeof meta.description === 'string' && meta.description.trim()
          ? meta.description.trim()
          : undefined,
      fields,
    };
  } catch {
    return { fields: [] };
  }
}

/** Entry file for one runtime, e.g. header/header.php or header/header.tsx. */
export function chromeEntryFile(
  option: Pick<ThemeChromeOption, 'dir' | 'slug' | 'kind'> & { dirs?: string[] },
  ext: 'php' | 'tsx',
): string | null {
  const dirs = option.dirs?.length ? option.dirs : option.dir ? [option.dir] : [];
  const files = [`${option.slug}.${ext}`, `${option.kind}.${ext}`];
  const dir = chromeDirWith(dirs, files);
  return dir ? (files.map((f) => join(dir, f)).find((p) => existsSync(p)) ?? null) : null;
}

function declaredChrome(theme: ThemeManifest, kind: ThemeChromeKind): ThemeChromeEntry[] {
  const listed = kind === 'header' ? theme.headers : theme.footers;
  if (listed?.length) return listed;
  const fallbackSlug = theme.chrome?.[kind];
  return fallbackSlug
    ? [
        {
          slug: fallbackSlug,
          title: kind === 'header' ? 'Site header' : 'Site footer',
          path: fallbackSlug,
          default: true,
        },
      ]
    : [];
}

/** First folder of a chrome's child → parent chain holding one of `files`. */
export function chromeDirWith(dirs: string[], files: string[]): string | null {
  return dirs.find((d) => files.some((f) => existsSync(join(d, f)))) ?? null;
}

/** Headers / footers from the child, then the parent when the child does not declare them. */
export function listThemeChrome(themeSlug: string, kind: ThemeChromeKind): ThemeChromeOption[] {
  const bySlug = new Map<string, ThemeChromeEntry>();
  for (const slug of [...themeAncestry(themeSlug)].reverse()) {
    const theme = getThemeManifest(slug);
    if (!theme) continue;
    for (const entry of declaredChrome(theme, kind)) bySlug.set(entry.slug, entry);
  }
  if (!bySlug.size) return [];

  return [...bySlug.values()].map((entry) => {
    const dir = resolveThemePath(themeSlug, entry.path);
    const dirs = isSafeRel(entry.path)
      ? themeAncestry(themeSlug)
          .map((theme) => join(resolveThemesRoot(), theme, entry.path))
          .filter((d) => existsSync(d))
      : [];
    const metaDir = chromeDirWith(dirs, [`${entry.slug}.meta.json`, `${kind}.meta.json`]);
    const meta = metaDir ? readChromeMeta(metaDir, entry, kind) : { fields: [] };
    const option: ThemeChromeOption = {
      ...entry,
      kind,
      title: meta.title ?? entry.title,
      description: meta.description ?? entry.description ?? '',
      theme: resolveThemeSlug(themeSlug),
      dir: dir && existsSync(dir) ? dir : null,
      dirs,
      fields: meta.fields,
      hasPhp: false,
      hasReact: false,
    };
    option.hasPhp = Boolean(chromeEntryFile(option, 'php'));
    option.hasReact = Boolean(chromeEntryFile(option, 'tsx'));
    return option;
  });
}

export function resolveDefaultChromeSlug(themeSlug: string, kind: ThemeChromeKind): string | null {
  const options = listThemeChrome(themeSlug, kind);
  if (!options.length) return null;
  return options.find((o) => o.default)?.slug ?? options[0]?.slug ?? null;
}

/** Active option for a kind — honours the saved slug when it still exists in the theme. */
export function resolveActiveChrome(
  themeSlug: string,
  kind: ThemeChromeKind,
  savedSlug?: string | null,
): ThemeChromeOption | null {
  const options = listThemeChrome(themeSlug, kind);
  if (!options.length) return null;
  const wanted = (savedSlug ?? '').trim();
  return (
    (wanted && options.find((o) => o.slug === wanted)) ||
    options.find((o) => o.default) ||
    options[0] ||
    null
  );
}

export function listThemeHeaders(themeSlug: string): ThemeChromeOption[] {
  return listThemeChrome(themeSlug, 'header');
}

export function resolveDefaultHeaderSlug(themeSlug: string): string | null {
  return resolveDefaultChromeSlug(themeSlug, 'header');
}
