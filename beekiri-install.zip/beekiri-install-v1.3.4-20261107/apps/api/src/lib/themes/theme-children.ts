import { existsSync, mkdirSync, readFileSync, readdirSync, renameSync, rmdirSync } from 'fs';
import { join } from 'path';
import { FieldGroup } from '../../models';
import { createLogger } from '../../utils/logger';
import {
  ensureCompanionChild,
  listThemeManifests,
  resolveThemesRoot,
  wantsCompanionChild,
  type ThemeManifest,
} from './theme-registry';

/**
 * Store themes keep the site's own work in a child folder (`be-chair-child`): layouts made in
 * Backend Fields, other sites' layouts (multisite) and custom post type templates. Sites that
 * made those before children existed have them inside the theme folder, where a theme update
 * would replace them; this moves them into the child.
 */

const log = createLogger('themes');

function dirs(path: string): string[] {
  try {
    return readdirSync(path, { withFileTypes: true })
      .filter((e) => e.isDirectory() && !e.name.startsWith('.'))
      .map((e) => e.name);
  } catch {
    return [];
  }
}

/** Moves `from` to `to` unless `to` already exists (the child's copy wins). */
function moveInto(from: string, to: string): boolean {
  if (existsSync(to)) return false;
  mkdirSync(join(to, '..'), { recursive: true });
  renameSync(from, to);
  return true;
}

function removeIfEmpty(path: string): void {
  try {
    if (existsSync(path) && readdirSync(path).length === 0) rmdirSync(path);
  } catch {
    /* not empty, or already gone */
  }
}

function layoutKey(dir: string, name: string): string | null {
  try {
    const meta = JSON.parse(readFileSync(join(dir, name, `${name}.meta.json`), 'utf8')) as { key?: unknown };
    return typeof meta.key === 'string' ? meta.key : null;
  } catch {
    return null;
  }
}

/**
 * Moves the site's files out of a store theme's folder into its child. Layouts count as the
 * site's when a Backend Fields group of that theme has their key; files the theme ships stay.
 * Returns how many folders moved.
 */
export async function adoptSiteFiles(theme: ThemeManifest): Promise<number> {
  if (!wantsCompanionChild(theme)) return 0;
  const root = resolveThemesRoot();
  const own = join(root, theme.slug);
  if (!existsSync(own)) return 0;
  const child = join(root, ensureCompanionChild(theme));
  let moved = 0;

  const groups = await FieldGroup.findAll({ where: { theme: theme.slug }, attributes: ['key'] });
  const keys = new Set(groups.map((g) => g.key));
  const layouts = join(own, 'layouts');
  for (const name of dirs(layouts)) {
    const key = layoutKey(layouts, name);
    if (key && keys.has(key) && moveInto(join(layouts, name), join(child, 'layouts', name))) moved++;
  }

  // Other sites' layouts and custom post type templates are always the site's own.
  for (const siteId of dirs(join(own, 'sites'))) {
    const from = join(own, 'sites', siteId, 'layouts');
    for (const name of dirs(from)) {
      if (moveInto(join(from, name), join(child, 'sites', siteId, 'layouts', name))) moved++;
    }
    removeIfEmpty(from);
    removeIfEmpty(join(own, 'sites', siteId));
  }
  removeIfEmpty(join(own, 'sites'));
  for (const name of dirs(join(own, 'cpts'))) {
    if (moveInto(join(own, 'cpts', name), join(child, 'cpts', name))) moved++;
  }
  removeIfEmpty(join(own, 'cpts'));

  if (moved) log.info(`${theme.name}: moved ${moved} of this site's folder(s) into ${theme.slug}-child.`);
  return moved;
}

/** Boot: every store theme has its child, and the site's files are in it. */
export async function ensureThemeChildren(): Promise<void> {
  for (const theme of listThemeManifests()) {
    if (!wantsCompanionChild(theme)) continue;
    try {
      ensureCompanionChild(theme);
      await adoptSiteFiles(theme);
    } catch (error) {
      log.warn(`${theme.name}: child theme not set up (${(error as Error).message})`);
    }
  }
}
