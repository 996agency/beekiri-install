/**
 * Node fallback for theme header/footer when the PHP CLI is missing or fails.
 * Keeps the public site chrome visible on client machines without PHP installed.
 */

type MenuRow = { id?: string; label?: string; url?: string; children?: MenuRow[] };

function esc(value: unknown): string {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function escUrl(value: unknown): string {
  const raw = String(value ?? '/').trim() || '/';
  if (/^(https?:|mailto:|tel:|\/|#)/i.test(raw)) return esc(raw);
  return esc(`/${raw.replace(/^\/+/, '')}`);
}

function asMenu(data: Record<string, unknown>): MenuRow[] {
  return Array.isArray(data.menu) ? (data.menu as MenuRow[]) : [];
}

function flattenMenu(items: MenuRow[]): MenuRow[] {
  const out: MenuRow[] = [];
  const walk = (rows: MenuRow[]) => {
    for (const row of rows) {
      out.push(row);
      if (row.children?.length) walk(row.children);
    }
  };
  walk(items);
  return out;
}

const ICON_SEARCH = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>`;

export function renderChromeFallbackHtml(
  kind: 'header' | 'footer',
  data: Record<string, unknown>,
): string {
  return kind === 'header' ? renderHeader(data) : renderFooter(data);
}

function renderHeader(data: Record<string, unknown>): string {
  const siteTitle = String(data.site_title ?? 'Beekiri');
  const homeUrl = String(data.home_url ?? '/');
  const logoUrl = String(data.logo_url ?? '/icon-512.png');
  const githubUrl = String(data.githubUrl ?? '').trim();
  const showSearch = data.showSearch !== false;
  const showGithub = data.showGithub !== false && Boolean(githubUrl);
  const menu = asMenu(data).slice(0, 8);
  const searchPages = Array.isArray(data.search_pages)
    ? (data.search_pages as MenuRow[])
    : flattenMenu(asMenu(data));

  const links = menu
    .map((item) => `<li><a href="${escUrl(item.url)}">${esc(item.label)}</a></li>`)
    .join('\n          ');

  const searchItems = searchPages
    .map((item) => {
      const label = String(item.label ?? '');
      const url = String(item.url ?? '/');
      const q = esc(`${label} ${url}`.toLowerCase());
      return `<li data-bk-search-item data-q="${q}">
          <a href="${escUrl(url)}">
            <span>${esc(label)}</span>
            <code>${esc(url)}</code>
          </a>
        </li>`;
    })
    .join('\n        ');

  const searchBtn = showSearch
    ? `<button type="button" class="bk-nav__icon-btn bk-nav__search-mobile" aria-label="Open Search" data-bk-search-open>
          ${ICON_SEARCH}
        </button>
        <button type="button" class="bk-nav__search" data-search-full="" data-bk-search-open>
          ${ICON_SEARCH}
          <span>Search</span>
          <span class="bk-nav__kbds" aria-hidden="true"><kbd>⌘</kbd><kbd>K</kbd></span>
        </button>`
    : '';

  const githubBtn = showGithub
    ? `<a class="bk-nav__icon-btn bk-nav__github" href="${escUrl(githubUrl)}" target="_blank" rel="noreferrer noopener" aria-label="GitHub">
          <svg role="img" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/></svg>
        </a>`
    : '';

  const searchDialog = showSearch
    ? `<div class="bk-search" role="dialog" aria-modal="true" aria-labelledby="bk-search-input" data-bk-search hidden>
  <form class="bk-search__panel" data-bk-search-form>
    <div class="bk-search__head">
      ${ICON_SEARCH}
      <input id="bk-search-input" type="search" placeholder="Search pages…" autocomplete="off" data-bk-search-input />
      <kbd>esc</kbd>
    </div>
    <ul class="bk-search__results">
        ${searchItems}
      <li class="bk-search__empty" data-bk-search-empty hidden>No matches</li>
    </ul>
  </form>
</div>`
    : '';

  return `<header class="bk-nav" aria-label="Main" data-theme-header="header">
  <div class="bk-nav__bar">
    <a class="bk-nav__brand" href="${escUrl(homeUrl)}">
      <span class="bk-nav__mark" aria-hidden="true">
        <img src="${escUrl(logoUrl)}" alt="" width="28" height="28" decoding="async" />
      </span>
      <span class="bk-nav__wordmark">${esc(siteTitle)}</span>
    </a>

    <nav class="bk-nav__links" aria-label="Primary">
      <ul>
          ${links}
      </ul>
    </nav>

    <div class="bk-nav__actions">
      ${searchBtn}
      ${githubBtn}
      <button type="button" class="bk-nav__icon-btn bk-nav__menu-toggle" aria-label="Menu" aria-expanded="false" data-bk-menu-toggle>
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>
      </button>
    </div>
  </div>

  <div class="bk-nav__mobile" data-bk-menu hidden>
    <ul>
          ${links}
    </ul>
  </div>
</header>

${searchDialog}
`;
}

function renderFooter(data: Record<string, unknown>): string {
  const siteTitle = String(data.site_title ?? 'Beekiri');
  const tagline = String(data.site_tagline ?? '').trim();
  const homeUrl = String(data.home_url ?? '/');
  const year = String(data.year ?? new Date().getFullYear());
  const powered = data.showPoweredBy !== false;
  const blogPublic = data.blog_public !== false;
  const links = asMenu(data).slice(0, 8);
  let copyright = String(data.copyright ?? '').trim();
  if (!copyright) copyright = `© ${year} ${siteTitle}. All rights reserved.`;

  const nav = links.length
    ? `<nav class="bk-site-footer__nav" aria-label="Footer">
          <ul>
            ${links
              .map((item) => `<li><a href="${escUrl(item.url)}">${esc(item.label)}</a></li>`)
              .join('\n            ')}
          </ul>
        </nav>`
    : '';

  const metaBits: string[] = [];
  if (powered) metaBits.push('<span>Powered by Beekiri</span>');
  if (!blogPublic) {
    metaBits.push('<span>Search engines are asked not to index this site</span>');
  }
  const meta = metaBits.length
    ? `<p class="bk-site-footer__meta">
          ${metaBits.join('')}
        </p>`
    : '';

  return `<footer class="bk-site-footer" data-theme-footer="footer">
  <div class="bk-site-footer__inner">
    <div class="bk-site-footer__top">
      <div class="bk-site-footer__brand">
        <a href="${escUrl(homeUrl)}">${esc(siteTitle)}</a>
        ${tagline ? `<p>${esc(tagline)}</p>` : ''}
      </div>

      ${nav}
    </div>

    <div class="bk-site-footer__bottom">
      <p>${esc(copyright)}</p>
      ${meta}
    </div>
  </div>
</footer>
`;
}
