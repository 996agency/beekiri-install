import { randomBytes } from 'crypto';
import { chmodSync, existsSync, mkdirSync, readFileSync, readdirSync, renameSync, rmSync, statSync, writeFileSync } from 'fs';
import { join } from 'path';
import { config } from '../../config/env';

/**
 * Migration files live in a private folder next to the media library (`uploads/.migrations`;
 * dot-folders are never served or copied as media). It holds this site's connection key, the
 * sites it is connected to, backups and files in transit. None of it is in the database, so a
 * database migration never carries one site's key or backups to another.
 */
export function migrationRoot(): string {
  const dir = process.env.BEEKIRI_MIGRATIONS_DIR?.trim() || join(config.media.root, '.migrations');
  mkdirSync(dir, { recursive: true, mode: 0o700 });
  return dir;
}

export function migrationDir(name: 'backups' | 'transfers' | 'work'): string {
  const dir = join(migrationRoot(), name);
  mkdirSync(dir, { recursive: true, mode: 0o700 });
  return dir;
}

export type SavedConnection = {
  id: string;
  label: string;
  url: string;
  key: string;
  addedAt: string;
  lastUsedAt?: string;
};

export type MigrationSettings = {
  key: string;
  allowPull: boolean;
  allowPush: boolean;
  connections: SavedConnection[];
  /** Local, staging or production, as chosen in Settings → Migration (null: from the address). */
  environment?: 'local' | 'staging' | 'production' | null;
};

export function newConnectionKey(): string {
  return randomBytes(32).toString('base64url');
}

export function newId(bytes = 12): string {
  return randomBytes(bytes).toString('hex');
}

function settingsPath() {
  return join(migrationRoot(), 'settings.json');
}

export function readSettings(): MigrationSettings {
  try {
    const raw = JSON.parse(readFileSync(settingsPath(), 'utf8')) as Partial<MigrationSettings>;
    if (typeof raw.key === 'string' && raw.key.length >= 32) {
      return {
        key: raw.key,
        allowPull: raw.allowPull === true,
        allowPush: raw.allowPush === true,
        environment:
          raw.environment === 'local' || raw.environment === 'staging' || raw.environment === 'production' ? raw.environment : null,
        connections: Array.isArray(raw.connections)
          ? raw.connections.filter(
              (c): c is SavedConnection =>
                Boolean(c) && typeof c.id === 'string' && typeof c.url === 'string' && typeof c.key === 'string',
            )
          : [],
      };
    }
  } catch {
    // First use: create below.
  }
  const fresh: MigrationSettings = { key: newConnectionKey(), allowPull: false, allowPush: false, connections: [] };
  writeSettings(fresh);
  return fresh;
}

export function writeSettings(next: MigrationSettings) {
  const path = settingsPath();
  const tmp = `${path}.${process.pid}.tmp`;
  writeFileSync(tmp, `${JSON.stringify(next, null, 2)}\n`, { mode: 0o600 });
  renameSync(tmp, path);
  try {
    chmodSync(path, 0o600);
  } catch {
    // Not every file system keeps modes.
  }
}

export type BackupInfo = {
  id: string;
  label: string;
  createdAt: string;
  size: number;
  parts: string[];
};

const BACKUP_ID = /^[a-f0-9]{24}$/;
export const KEEP_BACKUPS = 5;

export function backupPath(id: string): string | null {
  if (!BACKUP_ID.test(id)) return null;
  const path = join(migrationDir('backups'), `${id}.beekiri`);
  return existsSync(path) ? path : null;
}

export function writeBackupMeta(info: BackupInfo) {
  writeFileSync(join(migrationDir('backups'), `${info.id}.json`), `${JSON.stringify(info, null, 2)}\n`, { mode: 0o600 });
}

export function listBackups(): BackupInfo[] {
  const dir = migrationDir('backups');
  const out: BackupInfo[] = [];
  for (const name of readdirSync(dir)) {
    if (!name.endsWith('.json')) continue;
    try {
      const info = JSON.parse(readFileSync(join(dir, name), 'utf8')) as BackupInfo;
      if (!BACKUP_ID.test(info.id) || !existsSync(join(dir, `${info.id}.beekiri`))) continue;
      out.push({ ...info, size: statSync(join(dir, `${info.id}.beekiri`)).size });
    } catch {
      // Skip unreadable entries.
    }
  }
  return out.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function deleteBackup(id: string): boolean {
  if (!BACKUP_ID.test(id)) return false;
  const dir = migrationDir('backups');
  const had = existsSync(join(dir, `${id}.beekiri`));
  rmSync(join(dir, `${id}.beekiri`), { force: true });
  rmSync(join(dir, `${id}.json`), { force: true });
  return had;
}

/** Keep the newest few backups. */
export function pruneBackups(keep = KEEP_BACKUPS) {
  for (const old of listBackups().slice(keep)) deleteBackup(old.id);
}

const TRANSFER_ID = /^[a-f0-9]{24}$/;

/** A file being uploaded to or downloaded from this site. */
export function transferPath(id: string): string | null {
  if (!TRANSFER_ID.test(id)) return null;
  return join(migrationDir('transfers'), `${id}.part`);
}

/** Drop transfers and work folders older than a day (abandoned migrations). */
export function sweepStale(maxAgeMs = 24 * 60 * 60_000) {
  const now = Date.now();
  for (const name of ['transfers', 'work'] as const) {
    const dir = migrationDir(name);
    for (const entry of readdirSync(dir)) {
      const path = join(dir, entry);
      try {
        if (now - statSync(path).mtimeMs > maxAgeMs) rmSync(path, { recursive: true, force: true });
      } catch {
        // Already gone.
      }
    }
  }
}
