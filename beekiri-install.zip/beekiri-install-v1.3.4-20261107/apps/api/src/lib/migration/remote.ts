import { createHash, createHmac, randomBytes, timingSafeEqual } from 'crypto';

/**
 * Site-to-site requests are signed with the receiving site's connection key (HMAC-SHA256 over
 * method, path, time, a one-time nonce and the body hash). The key itself never travels.
 */
export const HEADER_TIME = 'x-beekiri-time';
export const HEADER_NONCE = 'x-beekiri-nonce';
export const HEADER_SIGNATURE = 'x-beekiri-signature';

const MAX_SKEW_MS = 5 * 60_000;
const seen = new Map<string, number>();

function sha256hex(body: Buffer) {
  return createHash('sha256').update(body).digest('hex');
}

export function signRequest(key: string, method: string, path: string, time: string, nonce: string, body: Buffer) {
  return createHmac('sha256', key)
    .update([method.toUpperCase(), path, time, nonce, sha256hex(body)].join('\n'))
    .digest('hex');
}

export type VerifyResult = 'ok' | 'missing' | 'clock' | 'replay' | 'bad';

export function verifyRequest(
  key: string,
  method: string,
  path: string,
  headers: { time?: string; nonce?: string; signature?: string },
  body: Buffer,
): VerifyResult {
  const { time, nonce, signature } = headers;
  if (!time || !nonce || !signature) return 'missing';
  if (!/^\d{10,16}$/.test(time) || !/^[a-f0-9]{32}$/.test(nonce) || !/^[a-f0-9]{64}$/.test(signature)) return 'bad';
  if (Math.abs(Date.now() - Number(time)) > MAX_SKEW_MS) return 'clock';
  const expected = Buffer.from(signRequest(key, method, path, time, nonce, body), 'hex');
  const given = Buffer.from(signature, 'hex');
  if (expected.length !== given.length || !timingSafeEqual(expected, given)) return 'bad';
  const now = Date.now();
  for (const [n, exp] of seen) if (exp < now) seen.delete(n);
  if (seen.has(nonce)) return 'replay';
  seen.set(nonce, now + 2 * MAX_SKEW_MS);
  return 'ok';
}

/** Messages from the other site say "this site" about themselves: name that site instead. */
export function fromRemote(host: string, message: string): string {
  const named = message.replace(/\b[Tt]his site\b/g, host);
  return named.includes(host) ? named : `${host}: ${named}`;
}

export class RemoteError extends Error {
  constructor(
    message: string,
    readonly status = 0,
    readonly retryable = false,
  ) {
    super(message);
  }
}

/** `https://staging.example.com/admin/settings` → `https://staging.example.com`. */
export function normalizeSiteUrl(raw: string): string {
  const text = raw.trim();
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(text) && !/^https?:\/\//i.test(text)) {
    throw new RemoteError('Use an http:// or https:// address.');
  }
  let url: URL;
  try {
    url = new URL(/^https?:\/\//i.test(text) ? text : `https://${text}`);
  } catch {
    throw new RemoteError('That is not a valid site address.');
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new RemoteError('Use an http:// or https:// address.');
  if (url.username || url.password) throw new RemoteError('Leave the user name and password out of the address.');
  return url.origin;
}

/** "Connection info" as shown on the other site: its address and key on two lines. */
export function parseConnectionInfo(raw: string): { url: string; key: string } {
  const parts = raw
    .split(/[\s]+/)
    .map((p) => p.trim())
    .filter(Boolean);
  const keyLike = (p: string) => /^[A-Za-z0-9_-]{40,}$/.test(p);
  const urlPart =
    parts.find((p) => /^https?:\/\//i.test(p)) ?? parts.find((p) => !keyLike(p) && /[.:]/.test(p)) ?? '';
  const key = parts.find((p) => p !== urlPart && keyLike(p)) ?? '';
  if (!urlPart || !key) {
    throw new RemoteError('Paste the connection info from Settings → Migration on the other site (its address and key).');
  }
  return { url: normalizeSiteUrl(urlPart), key };
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function describeNetworkError(host: string, e: unknown): string {
  const err = e as { name?: string; message?: string; cause?: { code?: string; message?: string } };
  const code = err.cause?.code ?? '';
  if (err.name === 'TimeoutError' || err.name === 'AbortError') return `${host} took too long to answer.`;
  if (code === 'ENOTFOUND' || code === 'EAI_AGAIN') return `${host} could not be found. Check the address.`;
  if (code === 'ECONNREFUSED') return `${host} refused the connection. Is the site running?`;
  if (code === 'ECONNRESET' || code === 'UND_ERR_SOCKET') return `The connection to ${host} was interrupted.`;
  if (/certificate|CERT|SSL|TLS/i.test(code + (err.cause?.message ?? ''))) {
    return `${host} has an HTTPS certificate problem (${err.cause?.message ?? code}).`;
  }
  return `Could not reach ${host}: ${err.cause?.message ?? err.message ?? 'network error'}.`;
}

export class RemoteSite {
  readonly host: string;

  constructor(
    readonly url: string,
    private readonly key: string,
  ) {
    this.host = new URL(url).host;
  }

  /** One signed request, retried on network hiccups and busy answers (not on refusals). */
  async request(
    path: string,
    body: Buffer = Buffer.alloc(0),
    opts: { timeoutMs?: number; attempts?: number } = {},
  ): Promise<Response> {
    const attempts = opts.attempts ?? 5;
    let lastError: RemoteError | null = null;
    for (let attempt = 1; attempt <= attempts; attempt++) {
      const fullPath = `/api/migration/remote${path}`;
      const time = String(Date.now());
      const nonce = randomBytes(16).toString('hex');
      try {
        const res = await fetch(`${this.url}${fullPath}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/octet-stream',
            [HEADER_TIME]: time,
            [HEADER_NONCE]: nonce,
            [HEADER_SIGNATURE]: signRequest(this.key, 'POST', fullPath, time, nonce, body),
          },
          body: new Uint8Array(body),
          redirect: 'error',
          signal: AbortSignal.timeout(opts.timeoutMs ?? 120_000),
        });
        if (res.ok) return res;
        const text = await res.text().catch(() => '');
        let message = '';
        try {
          const parsed = JSON.parse(text) as { message?: unknown };
          message = typeof parsed.message === 'string' ? parsed.message : '';
        } catch {
          message = '';
        }
        if (res.status === 404 && !message) {
          throw new RemoteError(`${this.host} does not support migrations yet. Update Beekiri there first.`, 404);
        }
        if (res.status === 401) {
          throw new RemoteError(
            /clock/i.test(message)
              ? `${this.host}: ${message}`
              : `${this.host} did not accept the connection key. Copy the connection info again from Settings → Migration on ${this.host}.`,
            401,
          );
        }
        const retryable = res.status === 429 || res.status === 502 || res.status === 503 || res.status === 504;
        lastError = new RemoteError(
          message ? fromRemote(this.host, message) : `${this.host} answered with an error (${res.status}).`,
          res.status,
          retryable,
        );
        if (!retryable) throw lastError;
      } catch (e) {
        if (e instanceof RemoteError && !e.retryable) throw e;
        lastError = e instanceof RemoteError ? e : new RemoteError(describeNetworkError(this.host, e), 0, true);
      }
      if (attempt < attempts) await sleep(Math.min(8_000, 500 * 2 ** attempt));
    }
    throw lastError ?? new RemoteError(`Could not reach ${this.host}.`);
  }

  async json<T>(path: string, payload: unknown = {}, opts?: { timeoutMs?: number; attempts?: number }): Promise<T> {
    const res = await this.request(path, Buffer.from(JSON.stringify(payload), 'utf8'), opts);
    return (await res.json()) as T;
  }

  async bytes(path: string, payload: unknown = {}): Promise<Buffer> {
    const res = await this.request(path, Buffer.from(JSON.stringify(payload), 'utf8'));
    return Buffer.from(await res.arrayBuffer());
  }
}
