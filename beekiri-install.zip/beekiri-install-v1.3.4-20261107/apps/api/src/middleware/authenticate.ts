import type { NextFunction, Request, Response } from 'express';
import type { CapabilitySlug } from '../lib/cms-types';
import { authService, CSRF_HEADER, SESSION_COOKIE } from '../services/auth.service';
import type { AuthUser } from '../types/auth';
import { Forbidden, Unauthorized } from '../utils/http-error';
import { isAllowedOrigin, selfOrigin } from './security';

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

export function sessionToken(req: Request): string | undefined {
  const raw: unknown = req.cookies?.[SESSION_COOKIE];
  return typeof raw === 'string' && raw ? raw : undefined;
}

function requestOrigin(req: Request): string | null {
  const origin = req.get('origin');
  if (origin) return origin;
  const referer = req.get('referer');
  if (!referer) return null;
  try {
    return new URL(referer).origin;
  } catch {
    return 'invalid';
  }
}

/**
 * Cookie-authenticated writes must come from an allow-listed browser origin (or no
 * browser at all) and carry the session's CSRF token.
 */
export function assertTrustedOrigin(req: Request): void {
  const origin = requestOrigin(req);
  if (!origin || origin === selfOrigin(req) || isAllowedOrigin(origin)) return;
  throw Forbidden('Request origin is not allowed.');
}

export async function requireAuth(req: Request, _res: Response, next: NextFunction) {
  try {
    const session = await authService.resolveSession(sessionToken(req));
    if (!session) throw Unauthorized('You must be logged in.');

    if (!SAFE_METHODS.has(req.method.toUpperCase())) {
      assertTrustedOrigin(req);
      authService.assertCsrf(session, req.get(CSRF_HEADER));
    }

    req.auth = session;
    next();
  } catch (error) {
    next(error);
  }
}

/**
 * For endpoints the public site calls on every page (e.g. the admin dock): visitors who are
 * not signed in get `body` with a 200 instead of a 401 that would show in their console.
 */
export function emptyUnlessSignedIn(body: unknown) {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      if (await authService.resolveSession(sessionToken(req))) return next();
      res.json(body);
    } catch (error) {
      next(error);
    }
  };
}

/** Runs after requireAuth; the capability list stays attached for the OpenAPI document. */
export function requireCapabilities(...required: CapabilitySlug[]) {
  const middleware = (req: Request, _res: Response, next: NextFunction) => {
    const user = req.auth?.user;
    if (!user || !required.every((c) => user.capabilities.includes(c))) {
      next(Forbidden('Sorry, you are not allowed to do that.'));
      return;
    }
    next();
  };
  return Object.assign(middleware, { capabilities: required });
}

/** After requireAuth — user needs at least one of the listed capabilities. */
export function requireAnyCapability(...allowed: CapabilitySlug[]) {
  const middleware = (req: Request, _res: Response, next: NextFunction) => {
    const user = req.auth?.user;
    if (!user || !allowed.some((c) => user.capabilities.includes(c))) {
      next(Forbidden('Sorry, you are not allowed to do that.'));
      return;
    }
    next();
  };
  return Object.assign(middleware, { capabilitiesAny: allowed });
}

/** Site Owner only (User Permissions and similar). */
export function requireOwner(req: Request, _res: Response, next: NextFunction) {
  if (!req.auth?.user?.isOwner) {
    next(Forbidden('Sorry, you are not allowed to do that.'));
    return;
  }
  next();
}

/**
 * Allow the signed-in user to access their own `:id`, or anyone with the
 * listed capability (e.g. list_users / edit_users).
 */
export function requireSelfOrCapability(capability: CapabilitySlug) {
  return (req: Request, _res: Response, next: NextFunction) => {
    const user = req.auth?.user;
    const targetId = typeof req.params.id === 'string' ? req.params.id : '';
    if (!user) {
      next(Forbidden('Sorry, you are not allowed to do that.'));
      return;
    }
    if (user.id === targetId || user.capabilities.includes(capability)) {
      next();
      return;
    }
    next(Forbidden('Sorry, you are not allowed to do that.'));
  };
}

/** The signed-in user, for handlers that run after requireAuth. */
export function authUser(req: Request): AuthUser {
  const user = req.auth?.user;
  if (!user) throw Unauthorized('You must be logged in.');
  return user;
}
