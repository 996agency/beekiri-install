import type { NextFunction, Request, Response } from 'express';
import multer from 'multer';
import { rebindSite } from '../lib/site/current-site';

/**
 * Multipart parser for a single upload kept in memory (files are validated and
 * re-encoded before anything touches disk).
 */
export function singleUpload(maxBytes: number) {
  const parser = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: maxBytes, files: 1, fields: 10, fieldSize: 4 * 1024, parts: 12 },
  }).any();

  const middleware = (req: Request, res: Response, next: NextFunction) => {
    parser(req, res, (err?: unknown) => {
      if (err) return next(err);
      const files = (req.files as Express.Multer.File[] | undefined) ?? [];
      const file = files[0];
      if (file) {
        // Browsers send UTF-8 names; busboy decodes them as latin1.
        file.originalname = Buffer.from(file.originalname, 'latin1').toString('utf8');
        req.file = file;
      }
      // Multipart parsing can resolve outside the request's site context.
      rebindSite(req, res, next);
    });
  };
  // Marks the route as multipart for the OpenAPI document.
  return Object.assign(middleware, { upload: { field: 'file', maxBytes } });
}

export function formField(req: Request, key: string): string | undefined {
  const value = (req.body as Record<string, unknown> | undefined)?.[key];
  if (Array.isArray(value)) return typeof value[0] === 'string' ? value[0] : undefined;
  return typeof value === 'string' ? value : undefined;
}
