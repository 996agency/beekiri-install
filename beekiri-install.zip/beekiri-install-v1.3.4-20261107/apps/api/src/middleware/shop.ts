import type { NextFunction, Request, Response } from 'express';
import { SHOP_EXTENSION_SLUG, SHOP_REQUEST_HEADER } from '../lib/shop/constants';
import { extensionsService } from '../services/extensions.service';
import { Forbidden, NotFound } from '../utils/http-error';
import { assertTrustedOrigin } from './authenticate';

/** Every shop route answers 404 while the extension is not active. */
export async function requireShopActive(_req: Request, _res: Response, next: NextFunction) {
  try {
    if (!(await extensionsService.isActive(SHOP_EXTENSION_SLUG))) {
      throw NotFound('Shopping is not active.');
    }
    next();
  } catch (error) {
    next(error);
  }
}

/**
 * The website asks /public/config on every render whether to load the storefront. While the
 * extension is off it gets a 200 `{ active: false }`, not a 404: the site's fetch cache keeps
 * its last good answer when a refresh fails, so a 404 would leave "active" cached for good.
 */
export async function shopConfigWhenInactive(_req: Request, res: Response, next: NextFunction) {
  try {
    if (await extensionsService.isActive(SHOP_EXTENSION_SLUG)) return next();
    res.json({ active: false });
  } catch (error) {
    next(error);
  }
}

/**
 * Anonymous storefront writes (cart, checkout) have no session CSRF token, so they
 * must come from an allowed origin and carry a custom header a cross-site form
 * cannot set. Both are added by the storefront script.
 */
export function requireStorefrontRequest(req: Request, _res: Response, next: NextFunction) {
  try {
    assertTrustedOrigin(req);
    if (req.get(SHOP_REQUEST_HEADER) !== '1') {
      throw Forbidden('Missing storefront request header.');
    }
    next();
  } catch (error) {
    next(error);
  }
}
