import type { NextFunction, Request, Response } from 'express';
import { brotliCompressSync, constants, gzipSync } from 'zlib';

/**
 * Compresses text responses sent in one piece (res.send / res.json): stylesheets, scripts, JSON.
 * Brotli when the browser takes it, else gzip. Streams (the agent's event stream) write in
 * pieces and are left alone, as are responses that are already encoded (header/footer assets).
 */

const COMPRESSIBLE = /^(?:text\/|application\/(?:json|javascript|xml|ld\+json|manifest\+json)|image\/svg\+xml)/i;
const MIN_BYTES = 1024;

/** Versioned assets (?v=…) come back unchanged: keep their compressed copy. */
const cache = new Map<string, Buffer>();
const CACHE_LIMIT = 200;

function encode(body: Buffer, encoding: 'br' | 'gzip'): Buffer {
  return encoding === 'br'
    ? brotliCompressSync(body, { params: { [constants.BROTLI_PARAM_QUALITY]: 6, [constants.BROTLI_PARAM_SIZE_HINT]: body.length } })
    : gzipSync(body, { level: 6 });
}

export function compressText(req: Request, res: Response, next: NextFunction) {
  const accept = String(req.headers['accept-encoding'] ?? '');
  const encoding = /\bbr\b/.test(accept) ? 'br' : /\bgzip\b/.test(accept) ? 'gzip' : null;
  res.vary('Accept-Encoding');
  if (!encoding || req.method === 'HEAD') return next();

  const send = res.send.bind(res);
  res.send = (body?: unknown) => {
    if (typeof body !== 'string' && !Buffer.isBuffer(body)) return send(body); // objects go through res.json → back here
    if (res.getHeader('Content-Encoding') || res.statusCode < 200 || res.statusCode === 204 || res.statusCode === 304) {
      return send(body);
    }
    if (!res.getHeader('Content-Type') && typeof body === 'string') res.setHeader('Content-Type', 'text/html; charset=utf-8');
    if (!COMPRESSIBLE.test(String(res.getHeader('Content-Type') ?? ''))) return send(body);
    const raw = Buffer.isBuffer(body) ? body : Buffer.from(body, 'utf8');
    if (raw.length < MIN_BYTES) return send(body);

    const versioned = typeof req.query.v === 'string' && /immutable/.test(String(res.getHeader('Cache-Control') ?? ''));
    const key = versioned ? `${encoding}:${req.originalUrl}:${raw.length}` : '';
    let packed = key ? cache.get(key) : undefined;
    if (!packed) {
      packed = encode(raw, encoding);
      if (key) {
        if (cache.size >= CACHE_LIMIT) cache.delete(cache.keys().next().value as string);
        cache.set(key, packed);
      }
    }
    res.setHeader('Content-Encoding', encoding);
    res.removeHeader('Content-Length');
    return send(packed);
  };
  next();
}
