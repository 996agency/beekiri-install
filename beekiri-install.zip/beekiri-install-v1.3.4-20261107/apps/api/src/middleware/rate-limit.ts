import rateLimit from 'express-rate-limit';

const tooMany = (message: string) => ({ statusCode: 429, message, error: 'Too Many Requests' });

/** Coarse flood guard for the whole API (admin polling stays far below this). */
export const apiRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 1_200,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests. Please slow down and try again shortly.'),
});

/** Public BeeCookies consent posts. */
export const beeCookiesRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 30,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many cookie requests. Please try again shortly.'),
});

/** Page-view posts — tight to blunt spam; real nav stays well under this. */
export const beeCookiesVisitRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many visit requests. Please try again shortly.'),
});

/** Live heartbeats (~every 30s). Caps scripted flooders. */
export const beeCookiesHeartbeatRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 12,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many heartbeat requests. Please try again shortly.'),
});

/** Click batches for heatmaps (client flushes every few seconds). */
export const beeCookiesClicksRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 40,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many click requests. Please try again shortly.'),
});

/** Public layout rendering: each call may spawn a PHP process. */
export const layoutRenderRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 120,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many render requests. Please try again shortly.'),
});

/** Unauthenticated auth endpoints (password reset, lost password). */
export const authRateLimit = rateLimit({
  windowMs: 15 * 60_000,
  limit: 30,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many attempts. Please try again later.'),
});

/** Storefront cart changes (add / update / remove / coupon). */
export const shopCartRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 60,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many cart requests. Please try again shortly.'),
});

/** Placing orders: tight, each call may create an order and a payment session. */
export const shopCheckoutRateLimit = rateLimit({
  windowMs: 10 * 60_000,
  limit: 15,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many checkout attempts. Please wait a few minutes and try again.'),
});

/** Payment-provider webhooks (signature-verified; the limit only blunts floods). */
export const shopWebhookRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 240,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many webhook requests.'),
});

/** Bee Forms submissions (each may store files and send mail). */
export const formsSubmitRateLimit = rateLimit({
  windowMs: 10 * 60_000,
  limit: 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many submissions. Please wait a few minutes and try again.'),
});

/** Bee Forms public reads (form HTML, spam tokens). */
export const formsViewRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 120,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests. Please try again shortly.'),
});

/** Dynamic-content items for pages (products, posts, repeater rows). */
export const dynamicItemsRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 300,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests. Please try again shortly.'),
});

/** Storefront reads that may run PHP templates. */
export const shopViewRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 300,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests. Please try again shortly.'),
});
