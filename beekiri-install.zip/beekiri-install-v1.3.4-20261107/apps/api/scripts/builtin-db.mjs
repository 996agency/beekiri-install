// Beekiri's own PostgreSQL, for sites whose owner has no database server: the setup wizard's
// "Set it up for me". PostgreSQL itself (the embedded-postgres package, ~100 MB) is downloaded
// only when chosen, into database/runtime; the data lives in database/data. Both sit outside
// the core, so core updates never touch them. `npm start` starts it before Beekiri and stops it
// after; it only listens on this computer (127.0.0.1) and needs a password.
//
// CLI (run by the setup wizard): BEEKIRI_DB_PASSWORD=… node scripts/builtin-db.mjs prepare
// prints "@@progress {…}" lines and finally "@@done {"port":…}".
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:net';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const API_DIR = join(dirname(fileURLToPath(import.meta.url)), '..');
const ROOT = join(API_DIR, '..', '..');
export const DATABASE_DIR = join(ROOT, 'database');
const RUNTIME_DIR = join(DATABASE_DIR, 'runtime');
const DATA_DIR = join(DATABASE_DIR, 'data');
/** Pinned: a new PostgreSQL major version cannot open an older data folder. */
const PACKAGE = 'embedded-postgres@18.6.0-beta.19';
const ENTRY = join(RUNTIME_DIR, 'node_modules/embedded-postgres/dist/index.js');
export const BUILTIN_DB_NAME = 'beekiri';
export const BUILTIN_DB_USER = 'postgres';
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';

/** Download PostgreSQL for this computer (once). */
export function ensureRuntime(log = () => {}) {
  if (existsSync(ENTRY)) return;
  mkdirSync(RUNTIME_DIR, { recursive: true });
  const manifest = join(RUNTIME_DIR, 'package.json');
  if (!existsSync(manifest)) {
    writeFileSync(manifest, `${JSON.stringify({ name: 'beekiri-database-runtime', private: true }, null, 2)}\n`);
  }
  log('Downloading PostgreSQL for this computer (one time, about 100 MB)…');
  const result = spawnSync(npm, ['install', PACKAGE, '--no-audit', '--no-fund', '--loglevel=error'], {
    cwd: RUNTIME_DIR,
    stdio: ['ignore', 'pipe', 'pipe'],
    shell: process.platform === 'win32',
    encoding: 'utf8',
  });
  if (result.status !== 0 || !existsSync(ENTRY)) {
    const detail = `${result.stderr || ''}${result.error?.message || ''}`.trim().split('\n').slice(-3).join(' ');
    throw new Error(`Could not download PostgreSQL. Check the internet connection and try again.${detail ? ` (${detail})` : ''}`);
  }
}

async function cluster({ port, password }) {
  const { default: EmbeddedPostgres } = await import(pathToFileURL(ENTRY).href);
  return new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    port,
    user: BUILTIN_DB_USER,
    password,
    authMethod: 'scram-sha-256',
    persistent: true,
    // PostgreSQL refuses to run as root (e.g. a fresh VPS): it then runs as a "postgres" system user.
    createPostgresUser: typeof process.getuid === 'function' && process.getuid() === 0,
    initdbFlags: ['--encoding=UTF8', '--locale=C'],
    onLog: () => {},
    onError: () => {},
  });
}

/** Is our PostgreSQL already answering on this port (left running after a crash)? */
async function answers(pg) {
  const client = pg.getPgClient('postgres', '127.0.0.1');
  try {
    await client.connect();
    await client.query('SELECT 1');
    return true;
  } catch (error) {
    if (error?.code === 'ECONNREFUSED') return false;
    // Something else holds the port, or a password that isn't ours.
    throw new Error(`Port ${pg.options.port} is used by another program, so Beekiri's database cannot start. Close that program and start Beekiri again.`);
  } finally {
    await client.end().catch(() => {});
  }
}

async function ensureDatabase(pg) {
  const client = pg.getPgClient('postgres', '127.0.0.1');
  await client.connect();
  try {
    const { rowCount } = await client.query('SELECT 1 FROM pg_database WHERE datname = $1', [BUILTIN_DB_NAME]);
    if (!rowCount) await client.query(`CREATE DATABASE "${BUILTIN_DB_NAME}"`);
  } finally {
    await client.end().catch(() => {});
  }
}

/** pg_ctl of the downloaded PostgreSQL: stops a server an earlier, crashed Beekiri left running. */
function pgCtl() {
  const os = { darwin: 'darwin', win32: 'windows', linux: 'linux' }[process.platform];
  const bin = join(RUNTIME_DIR, `node_modules/@embedded-postgres/${os}-${process.arch}/native/bin`);
  return join(bin, process.platform === 'win32' ? 'pg_ctl.exe' : 'pg_ctl');
}

/**
 * Start Beekiri's database (downloading or creating it first if needed). Returns a handle whose
 * stop() shuts it down cleanly.
 */
export async function startBuiltinDatabase({ port, password, log = () => {} }) {
  if (!port || !password) throw new Error('DB_PORT and DB_PASSWORD are missing from apps/api/.env.');
  ensureRuntime(log);
  const pg = await cluster({ port, password });
  if (!existsSync(join(DATA_DIR, 'PG_VERSION'))) {
    log('Creating the database…');
    await pg.initialise();
  }
  if (await answers(pg)) {
    // Left running after a crash: stop it, so the one started below shuts down with Beekiri.
    log('Restarting the database left running after Beekiri stopped unexpectedly…');
    spawnSync(pgCtl(), ['stop', '-D', DATA_DIR, '-m', 'fast', '-w'], { stdio: 'ignore' });
  }
  await pg.start();
  await ensureDatabase(pg);
  return { stop: () => pg.stop() };
}

/** A free local port for the database, away from PostgreSQL's usual 5432. */
function freePort(from = 54320, to = 54399) {
  return new Promise((resolve, reject) => {
    const tryPort = (port) => {
      if (port > to) return reject(new Error('No free port found for the database.'));
      const probe = createServer();
      probe.once('error', () => tryPort(port + 1));
      probe.once('listening', () => probe.close(() => resolve(port)));
      probe.listen(port, '127.0.0.1');
    };
    tryPort(from);
  });
}

/** Setup wizard: download, create and test the database, then leave it stopped for `npm start`. */
async function prepare() {
  const password = process.env.BEEKIRI_DB_PASSWORD;
  if (!password) throw new Error('BEEKIRI_DB_PASSWORD is not set.');
  const progress = (step, message) => console.log(`@@progress ${JSON.stringify({ step, message })}`);
  progress('download', 'Downloading PostgreSQL for this computer (one time, about 100 MB)…');
  ensureRuntime();
  if (existsSync(join(DATA_DIR, 'PG_VERSION'))) {
    throw new Error(`A database from an earlier setup is already in ${DATA_DIR}. Move or delete that folder, then try again.`);
  }
  const port = await freePort();
  progress('create', 'Creating your database…');
  const db = await startBuiltinDatabase({ port, password });
  await db.stop();
  console.log(`@@done ${JSON.stringify({ port })}`);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1] && process.argv[2] === 'prepare') {
  prepare().then(
    () => process.exit(0),
    (error) => {
      console.error(error instanceof Error ? error.message : String(error));
      process.exit(1);
    },
  );
}
