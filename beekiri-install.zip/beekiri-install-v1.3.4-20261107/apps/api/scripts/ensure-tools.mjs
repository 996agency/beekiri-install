// Beekiri builds and migrates with dev dependencies (tsup, vite, next, typescript, tsx). An install
// made with NODE_ENV=production — e.g. an update from Settings before 1.3.4 — leaves them out:
// put them back. Used by `npm start`, `npm run build` and `npm run db:migrate`.
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const API_DIR = join(dirname(fileURLToPath(import.meta.url)), '..');
const ROOT = join(API_DIR, '..', '..');
const TOOLS = [
  ['apps/admin/vendor/beeseo', 'tsup'],
  ['apps/admin', 'vite'],
  ['apps/web', 'next'],
  ['apps/api', 'typescript'],
  ['apps/api', 'tsx'],
];

export function ensureBuildTools() {
  const missing = TOOLS.filter(([dir, tool]) => {
    try {
      createRequire(join(ROOT, dir, 'package.json')).resolve(`${tool}/package.json`);
      return false;
    } catch {
      return true;
    }
  }).map(([, tool]) => tool);
  if (!missing.length) return;
  console.log(`\nInstalling Beekiri's build tools (${missing.join(', ')} missing)…`);
  const result = spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['install', '--include=dev', '--no-audit', '--no-fund'], {
    cwd: ROOT,
    stdio: 'inherit',
    shell: process.platform === 'win32',
  });
  if (result.status !== 0) process.exit(result.status ?? 1);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) ensureBuildTools();
