// Copies non-TypeScript runtime files into dist/ after `tsc`.
import { cpSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const assets = ['lib/layouts/php/layout-runner.php', 'lib/forms/form.css'];

for (const rel of assets) {
  const to = join(root, 'dist', rel);
  mkdirSync(dirname(to), { recursive: true });
  cpSync(join(root, 'src', rel), to);
}
