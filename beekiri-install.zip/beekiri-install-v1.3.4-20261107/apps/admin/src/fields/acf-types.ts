/** Field definitions (mirror of apps/api/src/lib/fields/fields.types.ts). */

export type FieldType =
  | 'text'
  | 'textarea'
  | 'number'
  | 'range'
  | 'email'
  | 'url'
  | 'password'
  | 'image'
  | 'file'
  | 'wysiwyg'
  | 'oembed'
  | 'gallery'
  | 'select'
  | 'checkbox'
  | 'radio'
  | 'button_group'
  | 'true_false'
  | 'link'
  | 'post_object'
  | 'page_link'
  | 'relationship'
  | 'user'
  | 'form'
  | 'date_picker'
  | 'date_time_picker'
  | 'time_picker'
  | 'color_picker'
  | 'message'
  | 'accordion'
  | 'tab'
  | 'group'
  | 'repeater'
  | 'flexible_content';

export type FlexibleLayout = {
  id: string;
  name: string;
  label: string;
  display: 'block' | 'table' | 'row';
  min?: number;
  max?: number;
  subFields: BackendField[];
};

export type BackendField = {
  id: string;
  type: FieldType;
  label: string;
  name: string;
  required: boolean;
  instructions: string;
  choices: string[];
  defaultValue: string;
  placeholder?: string;
  prepend?: string;
  append?: string;
  maxLength?: number;
  rows?: number;
  newLines?: string;
  min?: number;
  max?: number;
  step?: number;
  returnFormat?: string;
  displayFormat?: string;
  multiple?: boolean;
  allowNull?: boolean;
  layout?: string;
  ui?: boolean;
  onText?: string;
  offText?: string;
  message?: string;
  postTypes?: string[];
  roles?: string[];
  mimeTypes?: string;
  previewSize?: string;
  toolbar?: string;
  mediaUpload?: boolean;
  width?: number;
  subFields?: BackendField[];
  minRows?: number;
  maxRows?: number;
  buttonLabel?: string;
  collapsed?: string;
  layouts?: FlexibleLayout[];
};

export type SettingKey =
  | 'defaultValue'
  | 'placeholder'
  | 'prepend'
  | 'append'
  | 'maxLength'
  | 'rows'
  | 'newLines'
  | 'min'
  | 'max'
  | 'step'
  | 'choices'
  | 'returnFormat'
  | 'multiple'
  | 'allowNull'
  | 'layout'
  | 'ui'
  | 'onText'
  | 'offText'
  | 'message'
  | 'displayFormat'
  | 'postTypes'
  | 'roles'
  | 'mimeTypes'
  | 'previewSize'
  | 'toolbar'
  | 'mediaUpload'
  | 'minRows'
  | 'maxRows'
  | 'buttonLabel'
  | 'collapsed'
  | 'required';

export type Option = { value: string; label: string };

export type FieldTypeDef = {
  type: FieldType;
  label: string;
  category: 'Basic' | 'Content' | 'Choice' | 'Relational' | 'Advanced' | 'Layout';
  general: SettingKey[];
  validation: SettingKey[];
  presentation: SettingKey[];
  returnFormats?: Option[];
  layouts?: Option[];
  /** No value stored (message / accordion / tab). */
  noValue?: boolean;
};

const IMAGE_RETURNS: Option[] = [
  { value: 'array', label: 'Image Array' },
  { value: 'url', label: 'Image URL' },
  { value: 'id', label: 'Image ID' },
];
const FILE_RETURNS: Option[] = [
  { value: 'array', label: 'File Array' },
  { value: 'url', label: 'File URL' },
  { value: 'id', label: 'File ID' },
];
const CHOICE_RETURNS: Option[] = [
  { value: 'value', label: 'Value' },
  { value: 'label', label: 'Label' },
  { value: 'array', label: 'Both (Array)' },
];
const POST_RETURNS: Option[] = [
  { value: 'object', label: 'Post Object' },
  { value: 'id', label: 'Post ID' },
];
const USER_RETURNS: Option[] = [
  { value: 'array', label: 'User Array' },
  { value: 'object', label: 'User Object' },
  { value: 'id', label: 'User ID' },
];

export const FIELD_TYPE_DEFS: FieldTypeDef[] = [
  { type: 'text', label: 'Text', category: 'Basic', general: ['defaultValue'], validation: ['required', 'maxLength'], presentation: ['placeholder', 'prepend', 'append'] },
  { type: 'textarea', label: 'Text Area', category: 'Basic', general: ['defaultValue'], validation: ['required', 'maxLength'], presentation: ['placeholder', 'rows', 'newLines'] },
  { type: 'number', label: 'Number', category: 'Basic', general: ['defaultValue'], validation: ['required', 'min', 'max'], presentation: ['placeholder', 'step', 'prepend', 'append'] },
  { type: 'range', label: 'Range', category: 'Basic', general: ['defaultValue'], validation: ['required', 'min', 'max'], presentation: ['step', 'prepend', 'append'] },
  { type: 'email', label: 'Email', category: 'Basic', general: ['defaultValue'], validation: ['required'], presentation: ['placeholder', 'prepend', 'append'] },
  { type: 'url', label: 'URL', category: 'Basic', general: ['defaultValue'], validation: ['required'], presentation: ['placeholder'] },
  { type: 'password', label: 'Password', category: 'Basic', general: [], validation: ['required'], presentation: ['placeholder', 'prepend', 'append'] },

  { type: 'image', label: 'Image', category: 'Content', general: ['returnFormat'], validation: ['required', 'mimeTypes'], presentation: ['previewSize'], returnFormats: IMAGE_RETURNS },
  { type: 'file', label: 'File', category: 'Content', general: ['returnFormat'], validation: ['required', 'mimeTypes'], presentation: [], returnFormats: FILE_RETURNS },
  { type: 'wysiwyg', label: 'WYSIWYG Editor', category: 'Content', general: ['defaultValue'], validation: ['required'], presentation: ['toolbar', 'mediaUpload'] },
  { type: 'oembed', label: 'oEmbed', category: 'Content', general: [], validation: ['required'], presentation: [] },
  { type: 'gallery', label: 'Gallery', category: 'Content', general: ['returnFormat'], validation: ['required', 'min', 'max', 'mimeTypes'], presentation: ['previewSize'], returnFormats: IMAGE_RETURNS },

  { type: 'select', label: 'Select', category: 'Choice', general: ['choices', 'defaultValue', 'returnFormat', 'multiple', 'allowNull'], validation: ['required'], presentation: ['ui', 'placeholder'], returnFormats: CHOICE_RETURNS },
  { type: 'checkbox', label: 'Checkbox', category: 'Choice', general: ['choices', 'defaultValue', 'returnFormat'], validation: ['required'], presentation: ['layout'], returnFormats: CHOICE_RETURNS, layouts: [{ value: 'vertical', label: 'Vertical' }, { value: 'horizontal', label: 'Horizontal' }] },
  { type: 'radio', label: 'Radio Button', category: 'Choice', general: ['choices', 'defaultValue', 'returnFormat', 'allowNull'], validation: ['required'], presentation: ['layout'], returnFormats: CHOICE_RETURNS, layouts: [{ value: 'vertical', label: 'Vertical' }, { value: 'horizontal', label: 'Horizontal' }] },
  { type: 'button_group', label: 'Button Group', category: 'Choice', general: ['choices', 'defaultValue', 'returnFormat', 'allowNull'], validation: ['required'], presentation: ['layout'], returnFormats: CHOICE_RETURNS, layouts: [{ value: 'horizontal', label: 'Horizontal' }, { value: 'vertical', label: 'Vertical' }] },
  { type: 'true_false', label: 'True / False', category: 'Choice', general: ['message', 'defaultValue'], validation: ['required'], presentation: ['ui', 'onText', 'offText'] },

  { type: 'link', label: 'Link', category: 'Relational', general: ['returnFormat'], validation: ['required'], presentation: [], returnFormats: [{ value: 'array', label: 'Link Array' }, { value: 'url', label: 'Link URL' }] },
  { type: 'post_object', label: 'Post Object', category: 'Relational', general: ['postTypes', 'returnFormat', 'multiple', 'allowNull'], validation: ['required'], presentation: [], returnFormats: POST_RETURNS },
  { type: 'page_link', label: 'Page Link', category: 'Relational', general: ['postTypes', 'multiple', 'allowNull'], validation: ['required'], presentation: [] },
  { type: 'relationship', label: 'Relationship', category: 'Relational', general: ['postTypes', 'returnFormat'], validation: ['required', 'min', 'max'], presentation: [], returnFormats: POST_RETURNS },
  { type: 'user', label: 'User', category: 'Relational', general: ['roles', 'returnFormat', 'multiple', 'allowNull'], validation: ['required'], presentation: [], returnFormats: USER_RETURNS },
  { type: 'form', label: 'Form (Bee Forms)', category: 'Relational', general: ['returnFormat', 'allowNull'], validation: ['required'], presentation: [], returnFormats: [{ value: 'object', label: 'Form (title + HTML)' }, { value: 'id', label: 'Form ID' }] },

  { type: 'date_picker', label: 'Date Picker', category: 'Advanced', general: ['displayFormat', 'returnFormat'], validation: ['required'], presentation: [] },
  { type: 'date_time_picker', label: 'Date Time Picker', category: 'Advanced', general: ['displayFormat', 'returnFormat'], validation: ['required'], presentation: [] },
  { type: 'time_picker', label: 'Time Picker', category: 'Advanced', general: ['displayFormat', 'returnFormat'], validation: ['required'], presentation: [] },
  { type: 'color_picker', label: 'Color Picker', category: 'Advanced', general: ['defaultValue'], validation: ['required'], presentation: [] },

  { type: 'message', label: 'Message', category: 'Layout', general: ['message', 'newLines'], validation: [], presentation: [], noValue: true },
  { type: 'accordion', label: 'Accordion', category: 'Layout', general: [], validation: [], presentation: [], noValue: true },
  { type: 'tab', label: 'Tab', category: 'Layout', general: [], validation: [], presentation: [], noValue: true },
  { type: 'group', label: 'Group', category: 'Layout', general: [], validation: ['required'], presentation: ['layout'], layouts: [{ value: 'block', label: 'Block' }, { value: 'table', label: 'Table' }, { value: 'row', label: 'Row' }] },
  { type: 'repeater', label: 'Repeater', category: 'Layout', general: ['collapsed'], validation: ['required', 'minRows', 'maxRows'], presentation: ['layout', 'buttonLabel'], layouts: [{ value: 'table', label: 'Table' }, { value: 'block', label: 'Block' }, { value: 'row', label: 'Row' }] },
  { type: 'flexible_content', label: 'Flexible Content', category: 'Layout', general: [], validation: ['required', 'min', 'max'], presentation: ['buttonLabel'] },
];

export const FIELD_CATEGORIES: FieldTypeDef['category'][] = [
  'Basic',
  'Content',
  'Choice',
  'Relational',
  'Advanced',
  'Layout',
];

const LEGACY: Record<string, FieldType> = { date: 'date_picker' };

export function typeDef(type: string): FieldTypeDef {
  const t = LEGACY[type] ?? type;
  return FIELD_TYPE_DEFS.find((d) => d.type === t) ?? FIELD_TYPE_DEFS[0];
}

export function typeLabel(type: string) {
  return typeDef(type).label;
}

export const DATE_DEFAULTS: Record<string, { display: string; ret: string }> = {
  date_picker: { display: 'd/m/Y', ret: 'd/m/Y' },
  date_time_picker: { display: 'd/m/Y g:i a', ret: 'd/m/Y g:i a' },
  time_picker: { display: 'g:i a', ret: 'g:i a' },
};

export function newField(type: FieldType = 'text'): BackendField {
  return {
    id: `field_${Math.random().toString(36).slice(2, 11)}`,
    type,
    label: '',
    name: '',
    required: false,
    instructions: '',
    choices: [],
    defaultValue: '',
  };
}

export function newLayout(): FlexibleLayout {
  return {
    id: `layout_${Math.random().toString(36).slice(2, 11)}`,
    name: '',
    label: '',
    display: 'block',
    subFields: [],
  };
}

/** Fresh ids everywhere (duplicate field / layout). */
export function cloneField(f: BackendField): BackendField {
  return {
    ...f,
    id: `field_${Math.random().toString(36).slice(2, 11)}`,
    choices: [...f.choices],
    subFields: f.subFields?.map(cloneField),
    layouts: f.layouts?.map((l) => ({
      ...l,
      id: `layout_${Math.random().toString(36).slice(2, 11)}`,
      subFields: l.subFields.map(cloneField),
    })),
  };
}

export function toFieldName(label: string) {
  return label
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 60);
}

/** "red : Red" → { value: 'red', label: 'Red' } */
export function parseChoice(line: string): Option {
  const idx = line.indexOf(' : ');
  if (idx === -1) return { value: line.trim(), label: line.trim() };
  return { value: line.slice(0, idx).trim(), label: line.slice(idx + 3).trim() };
}

export function choiceOptions(f: BackendField): Option[] {
  return f.choices.map(parseChoice).filter((c) => c.value !== '');
}

/** Initial raw value for a new layout / repeater row. */
export function initialValue(f: BackendField): unknown {
  switch (f.type) {
    case 'repeater':
    case 'flexible_content':
    case 'gallery':
    case 'relationship':
      return [];
    case 'group': {
      const out: Record<string, unknown> = {};
      for (const sf of f.subFields ?? []) {
        if (!typeDef(sf.type).noValue) out[sf.name] = initialValue(sf);
      }
      return out;
    }
    case 'checkbox':
      return f.defaultValue ? f.defaultValue.split(/\s*\n\s*|\s*,\s*/).filter(Boolean) : [];
    case 'true_false':
      return f.defaultValue === '1' || f.defaultValue === 'true';
    case 'select':
      if (f.multiple) return f.defaultValue ? [f.defaultValue] : [];
      return f.defaultValue ?? '';
    case 'link':
    case 'image':
    case 'file':
    case 'post_object':
    case 'page_link':
    case 'user':
    case 'form':
      return f.multiple ? [] : '';
    default:
      return f.defaultValue ?? '';
  }
}

export function initialRow(fields: BackendField[]): Record<string, unknown> {
  const row: Record<string, unknown> = {};
  for (const f of fields) {
    if (!typeDef(f.type).noValue) row[f.name] = initialValue(f);
  }
  return row;
}

/** Snake_case export for JSON import/export. */
export function toAcfJson(field: BackendField): Record<string, unknown> {
  const out: Record<string, unknown> = {
    key: field.id,
    label: field.label,
    name: field.name,
    type: field.type,
    instructions: field.instructions,
    required: field.required ? 1 : 0,
    default_value: field.defaultValue,
  };
  const map: [keyof BackendField, string][] = [
    ['placeholder', 'placeholder'],
    ['prepend', 'prepend'],
    ['append', 'append'],
    ['maxLength', 'maxlength'],
    ['rows', 'rows'],
    ['newLines', 'new_lines'],
    ['min', 'min'],
    ['max', 'max'],
    ['step', 'step'],
    ['returnFormat', 'return_format'],
    ['displayFormat', 'display_format'],
    ['multiple', 'multiple'],
    ['allowNull', 'allow_null'],
    ['layout', 'layout'],
    ['ui', 'ui'],
    ['onText', 'ui_on_text'],
    ['offText', 'ui_off_text'],
    ['message', 'message'],
    ['postTypes', 'post_type'],
    ['roles', 'role'],
    ['mimeTypes', 'mime_types'],
    ['previewSize', 'preview_size'],
    ['toolbar', 'toolbar'],
    ['mediaUpload', 'media_upload'],
    ['minRows', 'min'],
    ['maxRows', 'max'],
    ['buttonLabel', 'button_label'],
    ['collapsed', 'collapsed'],
  ];
  for (const [k, acf] of map) {
    const v = field[k];
    if (v === undefined) continue;
    out[acf] = typeof v === 'boolean' ? (v ? 1 : 0) : v;
  }
  if (field.choices.length) {
    out.choices = Object.fromEntries(choiceOptions(field).map((c) => [c.value, c.label]));
  }
  if (field.width) out.wrapper = { width: String(field.width), class: '', id: '' };
  if (field.subFields) out.sub_fields = field.subFields.map(toAcfJson);
  if (field.layouts) {
    out.layouts = Object.fromEntries(
      field.layouts.map((l) => [
        l.id,
        {
          key: l.id,
          name: l.name,
          label: l.label,
          display: l.display,
          sub_fields: l.subFields.map(toAcfJson),
          min: l.min ?? '',
          max: l.max ?? '',
        },
      ]),
    );
  }
  return out;
}
