import {
  EyeSlash,
  GridFour,
  PaintBucket,
  Square,
  SquaresFour,
  TextAa,
  TextAlignCenter,
  TextAlignJustify,
  TextAlignLeft,
  TextAlignRight,
  TextB,
  TextItalic,
  TextStrikethrough,
  TextT,
  TextUnderline,
} from '@phosphor-icons/react';
import type {
  BlockBackground,
  BlockBorder,
  BlockEffects,
  BlockLayout,
  BlockSpacing,
  BlockTypography,
} from '@beekiri/page-blocks';
import { BoxModel } from './BoxModel';
import { ColorSwatch } from './ColorSwatch';
import { FormatBtn, FormatRow, Segmented } from './Segmented';
import { InspectorCard } from './InspectorCard';
import { UnitInput } from './UnitInput';

const FONTS = [
  { label: 'Inherit', value: 'inherit' },
  {
    label: 'SF Pro',
    value:
      "'SF Pro Text', 'SF Pro Display', -apple-system, BlinkMacSystemFont, 'Helvetica Neue', Helvetica, Arial, sans-serif",
  },
  { label: 'Georgia', value: 'Georgia, "Times New Roman", serif' },
  { label: 'Monospace', value: 'ui-monospace, SFMono-Regular, Menlo, monospace' },
];

const WEIGHTS = [
  { label: '400 — Regular', value: '400' },
  { label: '500 — Medium', value: '500' },
  { label: '600 — Semibold', value: '600' },
  { label: '700 — Bold', value: '700' },
];

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="bk-inspector-row">
      <span className="bk-inspector-label">{label}</span>
      <div className="bk-inspector-row__control">{children}</div>
    </div>
  );
}

function Select({
  value,
  options,
  onChange,
}: {
  value: string;
  options: { label: string; value: string }[];
  onChange: (v: string) => void;
}) {
  return (
    <select className="bk-inspector-select" value={value} onChange={(e) => onChange(e.target.value)}>
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}

export function TypographyPanel({
  value,
  onChange,
}: {
  value: BlockTypography;
  onChange: (v: BlockTypography) => void;
}) {
  const v = value;
  const set = <K extends keyof BlockTypography>(key: K, next: BlockTypography[K]) =>
    onChange({ ...v, [key]: next });

  return (
    <InspectorCard title="Typography" icon={TextT}>
      <Row label="Font">
        <Select
          value={v.fontFamily || 'inherit'}
          options={FONTS}
          onChange={(fontFamily) => set('fontFamily', fontFamily)}
        />
      </Row>
      <Row label="Weight">
        <Select
          value={v.weight || '400'}
          options={WEIGHTS}
          onChange={(weight) => set('weight', weight)}
        />
      </Row>
      <div className="bk-inspector-grid">
        <UnitInput
          label="Size"
          value={v.size ?? 28}
          unit={v.sizeUnit || 'px'}
          units={['px', 'rem', 'em']}
          min={8}
          max={120}
          onChange={(size) => set('size', typeof size === 'number' ? size : 28)}
          onUnitChange={(sizeUnit) => set('sizeUnit', sizeUnit as BlockTypography['sizeUnit'])}
        />
        <UnitInput
          label="Height"
          value={v.lineHeight === 'auto' || v.lineHeight == null ? 'auto' : v.lineHeight}
          unit="×"
          placeholder="Auto"
          allowAuto
          min={0.8}
          max={3}
          step={0.05}
          onChange={(lineHeight) =>
            set('lineHeight', lineHeight === 'auto' ? 'auto' : lineHeight)
          }
        />
      </div>
      <ColorSwatch
        label="Color"
        value={v.color || '#202734'}
        onChange={(color) => onChange({ ...v, color })}
      />
      <Row label="Align">
        <Segmented
          ariaLabel="Text align"
          value={v.align || 'left'}
          onChange={(align) => set('align', align)}
          options={[
            { value: 'left', icon: TextAlignLeft, title: 'Left' },
            { value: 'center', icon: TextAlignCenter, title: 'Center' },
            { value: 'right', icon: TextAlignRight, title: 'Right' },
            { value: 'justify', icon: TextAlignJustify, title: 'Justify' },
          ]}
        />
      </Row>
      <Row label="Format">
        <FormatRow>
          <FormatBtn
            title="Bold"
            active={v.bold || v.weight === '700'}
            onClick={() => {
              const next = !(v.bold || v.weight === '700');
              onChange({ ...v, bold: next, weight: next ? '700' : '400' });
            }}
          >
            <TextB size={16} weight="bold" aria-hidden />
          </FormatBtn>
          <FormatBtn title="Italic" active={!!v.italic} onClick={() => set('italic', !v.italic)}>
            <TextItalic size={16} aria-hidden />
          </FormatBtn>
          <FormatBtn
            title="Underline"
            active={!!v.underline}
            onClick={() => set('underline', !v.underline)}
          >
            <TextUnderline size={16} aria-hidden />
          </FormatBtn>
          <FormatBtn title="Strike" active={!!v.strike} onClick={() => set('strike', !v.strike)}>
            <TextStrikethrough size={16} aria-hidden />
          </FormatBtn>
          <FormatBtn
            title="Uppercase"
            active={!!v.uppercase}
            onClick={() => set('uppercase', !v.uppercase)}
          >
            <TextAa size={16} aria-hidden />
          </FormatBtn>
        </FormatRow>
      </Row>
    </InspectorCard>
  );
}

export function LayoutPanel({
  value,
  onChange,
}: {
  value: BlockLayout;
  onChange: (v: BlockLayout) => void;
}) {
  return (
    <InspectorCard title="Layout" icon={SquaresFour}>
      <Row label="Display">
        <Segmented
          ariaLabel="Display"
          value={value.display || 'block'}
          onChange={(display) => onChange({ ...value, display })}
          options={[
            { value: 'block', icon: Square, title: 'Block' },
            { value: 'flex', icon: SquaresFour, title: 'Flex' },
            { value: 'grid', icon: GridFour, title: 'Grid' },
            { value: 'inline-flex', icon: SquaresFour, title: 'Inline flex' },
            { value: 'none', icon: EyeSlash, title: 'Hidden' },
          ]}
        />
      </Row>
    </InspectorCard>
  );
}

export function SpacingPanel({
  value,
  onChange,
}: {
  value: BlockSpacing;
  onChange: (v: BlockSpacing) => void;
}) {
  return (
    <InspectorCard title="Spacing" icon={Square}>
      <BoxModel
        margin={value.margin}
        padding={value.padding}
        onChange={({ margin, padding }) => onChange({ ...value, margin, padding })}
      />
    </InspectorCard>
  );
}

export function BackgroundPanel({
  value,
  onChange,
}: {
  value: BlockBackground;
  onChange: (v: BlockBackground) => void;
}) {
  const set = <K extends keyof BlockBackground>(key: K, next: BlockBackground[K]) =>
    onChange({ ...value, [key]: next });

  return (
    <InspectorCard title="Background" icon={PaintBucket}>
      <ColorSwatch label="Color" value={value.color || 'transparent'} onChange={(color) => set('color', color)} />
      <Row label="Image">
        <input
          type="text"
          className="bk-inspector-input"
          placeholder="https://… or /media/…"
          value={value.image || ''}
          onChange={(e) => set('image', e.target.value)}
        />
      </Row>
      <Row label="Clipping">
        <Select
          value={value.clip || 'none'}
          onChange={(clip) => set('clip', clip as BlockBackground['clip'])}
          options={[
            { label: 'None', value: 'none' },
            { label: 'Padding box', value: 'padding-box' },
            { label: 'Content box', value: 'content-box' },
            { label: 'Text', value: 'text' },
          ]}
        />
      </Row>
    </InspectorCard>
  );
}

export function BorderPanel({
  value,
  onChange,
}: {
  value: BlockBorder;
  onChange: (v: BlockBorder) => void;
}) {
  const set = <K extends keyof BlockBorder>(key: K, next: BlockBorder[K]) =>
    onChange({ ...value, [key]: next });

  return (
    <InspectorCard title="Border" icon={Square}>
      <div className="bk-inspector-grid">
        <UnitInput
          label="Radius"
          value={value.radius}
          unit="px"
          min={0}
          max={64}
          onChange={(radius) => set('radius', typeof radius === 'number' ? radius : 0)}
        />
        <UnitInput
          label="Width"
          value={value.width}
          unit="px"
          min={0}
          max={32}
          onChange={(width) => set('width', typeof width === 'number' ? width : 0)}
        />
      </div>
      <Row label="Side">
        <div className="bk-border-side" role="group" aria-label="Border side">
          {(['top', 'left', 'all', 'right', 'bottom'] as const).map((side) => (
            <button
              key={side}
              type="button"
              className={`bk-border-side__btn is-${side}${value.side === side ? ' is-active' : ''}`}
              aria-pressed={value.side === side}
              onClick={() => set('side', side)}
              title={side}
            >
              {side === 'all' ? '●' : ''}
            </button>
          ))}
        </div>
      </Row>
      <Row label="Style">
        <Segmented
          ariaLabel="Border style"
          value={(value.style === 'none' ? 'solid' : value.style) as 'solid' | 'dashed' | 'dotted'}
          onChange={(style) => set('style', style)}
          options={[
            { value: 'solid', label: 'Solid' },
            { value: 'dashed', label: 'Dash' },
            { value: 'dotted', label: 'Dot' },
          ]}
        />
      </Row>
      <ColorSwatch label="Color" value={value.color || '#c3c4c7'} onChange={(color) => set('color', color)} />
    </InspectorCard>
  );
}

export function EffectsPanel({
  value,
  onChange,
}: {
  value: BlockEffects;
  onChange: (v: BlockEffects) => void;
}) {
  const opacity = value.opacity ?? 100;
  return (
    <InspectorCard title="Effects" icon={EyeSlash} defaultOpen={false}>
      <Row label="Opacity">
        <div className="bk-opacity">
          <input
            type="range"
            min={0}
            max={100}
            value={opacity}
            onChange={(e) => onChange({ ...value, opacity: Number(e.target.value) })}
            aria-label="Opacity"
          />
          <span className="bk-opacity__val">{opacity}%</span>
        </div>
      </Row>
    </InspectorCard>
  );
}
