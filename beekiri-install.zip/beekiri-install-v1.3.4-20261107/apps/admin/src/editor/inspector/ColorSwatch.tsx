type Props = {
  label?: string;
  value: string;
  onChange: (value: string) => void;
};

const PRESETS = [
  '#202734',
  '#2c3338',
  '#646970',
  '#c3c4c7',
  '#f0f0f1',
  '#ffffff',
  '#F2842F',
  '#d63638',
  '#b7d894',
  '#006199',
  'transparent',
];

export function ColorSwatch({ label, value, onChange }: Props) {
  const hex = value && value !== 'transparent' ? value : '';
  const swatch =
    value && value !== 'transparent'
      ? value
      : 'conic-gradient(#c3c4c7 0 25%, #fff 0 50%, #c3c4c7 0 75%, #fff 0)';

  return (
    <div className="bk-color">
      {label ? <span className="bk-inspector-label">{label}</span> : null}
      <div className="bk-color__row">
        <span className="bk-color__swatch" style={{ background: swatch }} aria-hidden />
        <input
          type="text"
          className="bk-color__text"
          value={hex || (value === 'transparent' ? 'transparent' : '')}
          placeholder="#202734"
          spellCheck={false}
          onChange={(e) => onChange(e.target.value.trim())}
          aria-label={label || 'Color'}
        />
        <label className="bk-color__picker-wrap" title="Pick color">
          <input
            type="color"
            className="bk-color__picker"
            value={hex && /^#[0-9a-fA-F]{6}$/.test(hex) ? hex : '#202734'}
            onChange={(e) => onChange(e.target.value)}
            aria-label="Color picker"
          />
        </label>
      </div>
      <div className="bk-color__presets" role="list">
        {PRESETS.map((c) => (
          <button
            key={c}
            type="button"
            className={`bk-color__preset${value === c ? ' is-active' : ''}`}
            style={{
              background:
                c === 'transparent'
                  ? 'conic-gradient(#c3c4c7 0 25%, #fff 0 50%, #c3c4c7 0 75%, #fff 0)'
                  : c,
            }}
            title={c}
            aria-label={c}
            aria-pressed={value === c}
            onClick={() => onChange(c)}
          />
        ))}
      </div>
    </div>
  );
}
