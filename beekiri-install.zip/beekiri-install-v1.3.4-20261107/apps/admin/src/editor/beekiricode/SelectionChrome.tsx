import {
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type PointerEvent,
  type ReactNode,
} from 'react';
import {
  ArrowDown,
  ArrowElbowLeftUp,
  ArrowUp,
  CopySimple,
  Sparkle,
  Plus,
  Trash,
} from '@phosphor-icons/react';
import { canAcceptChildren, findParentId, type BeekiriCodePageDoc } from './document';
import { nodeMeta, nodeName } from './nodeMeta';
import type { SpacingFocus } from './inspector/BoxModel';

type Box = { top: number; left: number; width: number; height: number };
type Edges = { top: number; right: number; bottom: number; left: number };
type Spacing = { padding: Edges; margin: Edges };

type Props = {
  doc: BeekiriCodePageDoc;
  selectedId: string | null;
  hoveredId: string | null;
  /** Canvas zoom (0.55 = 55%) — the chrome is counter-scaled so it stays legible. */
  scale: number;
  /** Spacing field under the pointer in Props — shows padding / margin areas on the canvas. */
  spacingFocus?: SpacingFocus;
  onSelectParent: (id: string) => void;
  onMove: (id: string, delta: -1 | 1) => void;
  onDuplicate: (id: string) => void;
  onDelete: (id: string) => void;
  /** Open the Add panel targeting this container. */
  onAddInside: (id: string) => void;
  /** Beekiri (Connector) is on: open its chat on this element only. */
  onAskBeekiri?: (id: string) => void;
};

/** Element rect in the frame's own (unscaled) coordinate space. */
function measure(frame: HTMLElement, id: string, scale: number): Box | null {
  const el = frame.querySelector<HTMLElement>(`[data-node-id="${CSS.escape(id)}"]`);
  if (!el) return null;
  const f = frame.getBoundingClientRect();
  const r = el.getBoundingClientRect();
  return {
    top: (r.top - f.top) / scale + frame.scrollTop,
    left: (r.left - f.left) / scale + frame.scrollLeft,
    width: r.width / scale,
    height: r.height / scale,
  };
}

const same = (a: Box | null, b: Box | null) =>
  a === b ||
  (!!a &&
    !!b &&
    Math.abs(a.top - b.top) < 0.5 &&
    Math.abs(a.left - b.left) < 0.5 &&
    Math.abs(a.width - b.width) < 0.5 &&
    Math.abs(a.height - b.height) < 0.5);

/** Computed padding / margin in CSS px (unscaled — same space as the overlay layer). */
function measureSpacing(frame: HTMLElement, id: string): Spacing | null {
  const el = frame.querySelector<HTMLElement>(`[data-node-id="${CSS.escape(id)}"]`);
  if (!el) return null;
  const cs = getComputedStyle(el);
  const px = (v: string) => Math.max(0, parseFloat(v) || 0);
  return {
    padding: {
      top: px(cs.paddingTop),
      right: px(cs.paddingRight),
      bottom: px(cs.paddingBottom),
      left: px(cs.paddingLeft),
    },
    margin: {
      top: px(cs.marginTop),
      right: px(cs.marginRight),
      bottom: px(cs.marginBottom),
      left: px(cs.marginLeft),
    },
  };
}

const sameSpacing = (a: Spacing | null, b: Spacing | null) =>
  a === b || (!!a && !!b && JSON.stringify(a) === JSON.stringify(b));

const EDGE_SIDES = ['top', 'right', 'bottom', 'left'] as const;

/** Four strips for one box: padding inside the element, margin around it. */
function edgeStyles(
  box: 'padding' | 'margin',
  e: Edges,
): Record<(typeof EDGE_SIDES)[number], CSSProperties> {
  if (box === 'padding') {
    return {
      top: { top: 0, left: 0, right: 0, height: e.top },
      bottom: { bottom: 0, left: 0, right: 0, height: e.bottom },
      left: { top: e.top, bottom: e.bottom, left: 0, width: e.left },
      right: { top: e.top, bottom: e.bottom, right: 0, width: e.right },
    };
  }
  return {
    top: { bottom: '100%', left: -e.left, right: -e.right, height: e.top },
    bottom: { top: '100%', left: -e.left, right: -e.right, height: e.bottom },
    left: { top: 0, bottom: 0, right: '100%', width: e.left },
    right: { top: 0, bottom: 0, left: '100%', width: e.right },
  };
}

/** Toolbar buttons never take focus — a focused Delete must not re-fire on Space/Enter. */
const swallow = (e: PointerEvent) => {
  e.preventDefault();
  e.stopPropagation();
};

function ToolBtn({
  title,
  disabled,
  danger,
  onClick,
  children,
}: {
  title: string;
  disabled?: boolean;
  danger?: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      tabIndex={-1}
      title={title}
      aria-label={title}
      disabled={disabled}
      className={danger ? 'is-danger' : undefined}
      onPointerDown={swallow}
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
    >
      {children}
    </button>
  );
}

/**
 * Floating toolbar + outline for the selected node and a name tag for the hovered
 * one. Lives inside each frame canvas; tracks the element every animation frame so
 * async layout previews, fonts and images can't leave it stale.
 */
export function SelectionChrome({
  doc,
  selectedId,
  hoveredId,
  scale,
  spacingFocus = null,
  onSelectParent,
  onMove,
  onDuplicate,
  onDelete,
  onAddInside,
  onAskBeekiri,
}: Props) {
  const layerRef = useRef<HTMLDivElement>(null);
  const [sel, setSel] = useState<Box | null>(null);
  const [hov, setHov] = useState<Box | null>(null);
  const [spacing, setSpacing] = useState<Spacing | null>(null);

  const selNode = selectedId ? doc.nodes[selectedId] : null;
  const isRoot = selectedId === doc.rootId;
  // The page body gets no hover tag — it would always sit under the canvas tools.
  const hovNode =
    hoveredId && hoveredId !== selectedId && hoveredId !== doc.rootId ? doc.nodes[hoveredId] : null;

  useEffect(() => {
    const frame = layerRef.current?.parentElement;
    if (!frame) return;
    let raf = 0;
    let lastSel: Box | null = null;
    let lastHov: Box | null = null;
    let lastSp: Spacing | null = null;
    const tick = () => {
      const s = selectedId && !isRoot ? measure(frame, selectedId, scale) : null;
      const h = hovNode && hoveredId ? measure(frame, hoveredId, scale) : null;
      const sp = s && spacingFocus && selectedId ? measureSpacing(frame, selectedId) : null;
      if (!same(s, lastSel)) {
        lastSel = s;
        setSel(s);
      }
      if (!same(h, lastHov)) {
        lastHov = h;
        setHov(h);
      }
      if (!sameSpacing(sp, lastSp)) {
        lastSp = sp;
        setSpacing(sp);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [selectedId, hoveredId, hovNode, isRoot, scale, spacingFocus]);

  const inv = 1 / scale;
  // Toolbar is ~26px tall on screen → that many unscaled px above the element.
  const barH = 30 * inv;
  /** Above the element when there is room, otherwise below it — never on top of it. */
  const placement = (b: Box) => (b.top < barH ? 'below' : 'above');
  const floatStyle = (b: Box): CSSProperties => ({
    transform: `scale(${inv})`,
    transformOrigin: placement(b) === 'below' ? 'top left' : 'bottom left',
  });

  const parentId = selectedId ? findParentId(doc, selectedId) : null;
  const siblings = parentId ? (doc.nodes[parentId]?.children ?? []) : [];
  const idx = selectedId ? siblings.indexOf(selectedId) : -1;

  return (
    <div ref={layerRef} className="bk-selchrome" aria-hidden>
      {hov && hovNode && hoveredId ? (
        <div className="bk-selchrome__hover" style={boxStyle(hov)}>
          <span className="bk-selchrome__tag" style={floatStyle(hov)} data-flip={placement(hov)}>
            <NodeIcon id={hoveredId} doc={doc} />
            {nodeName(hovNode, false)}
          </span>
        </div>
      ) : null}

      {sel && selNode && selectedId && !isRoot ? (
        <div className="bk-selchrome__sel" style={boxStyle(sel)}>
          {spacing && spacingFocus
            ? (['margin', 'padding'] as const).map((box) => {
                const styles = edgeStyles(box, spacing[box]);
                return EDGE_SIDES.map((side) => {
                  const size = spacing[box][side];
                  if (size <= 0) return null;
                  const active =
                    spacingFocus.box === box && spacingFocus.side.toLowerCase() === side;
                  return (
                    <div
                      key={`${box}-${side}`}
                      className={`bk-selchrome__edge is-${box}${active ? ' is-active' : ''}`}
                      style={styles[side]}
                    >
                      {active ? (
                        <span
                          className="bk-selchrome__edge-label"
                          style={{ transform: `translate(-50%, -50%) scale(${inv})` }}
                        >
                          {Math.round(size)}
                        </span>
                      ) : null}
                    </div>
                  );
                });
              })
            : null}
          <div className="bk-selchrome__bar" style={floatStyle(sel)} data-flip={placement(sel)}>
            <span className="bk-selchrome__name">
              <NodeIcon id={selectedId} doc={doc} />
              {nodeName(selNode, false)}
            </span>
            <span className="bk-selchrome__dims">
              {Math.round(sel.width)} × {Math.round(sel.height)}
            </span>
            <span className="bk-selchrome__sep" />
            {onAskBeekiri ? (
              <ToolBtn title="Ask Beekiri to change this" onClick={() => onAskBeekiri(selectedId)}>
                <Sparkle size={13} weight="fill" />
              </ToolBtn>
            ) : null}
            <ToolBtn
              title="Select parent (Esc)"
              disabled={!parentId}
              onClick={() => parentId && onSelectParent(parentId)}
            >
              <ArrowElbowLeftUp size={13} weight="bold" />
            </ToolBtn>
            <ToolBtn title="Move up" disabled={idx <= 0} onClick={() => onMove(selectedId, -1)}>
              <ArrowUp size={13} weight="bold" />
            </ToolBtn>
            <ToolBtn
              title="Move down"
              disabled={idx < 0 || idx >= siblings.length - 1}
              onClick={() => onMove(selectedId, 1)}
            >
              <ArrowDown size={13} weight="bold" />
            </ToolBtn>
            <ToolBtn title="Duplicate (⌘D)" onClick={() => onDuplicate(selectedId)}>
              <CopySimple size={13} weight="bold" />
            </ToolBtn>
            <ToolBtn title="Delete (⌫)" danger onClick={() => onDelete(selectedId)}>
              <Trash size={13} weight="bold" />
            </ToolBtn>
          </div>

          {canAcceptChildren(selNode, false) ? (
            <button
              type="button"
              tabIndex={-1}
              className="bk-selchrome__add"
              title="Add element inside"
              aria-label="Add element inside"
              style={{ transform: `translate(-50%, 50%) scale(${inv})` }}
              onPointerDown={swallow}
              onClick={(e) => {
                e.stopPropagation();
                onAddInside(selectedId);
              }}
            >
              <Plus size={12} weight="bold" />
            </button>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

function boxStyle(b: Box): CSSProperties {
  return { top: b.top, left: b.left, width: b.width, height: b.height };
}

function NodeIcon({ id, doc }: { id: string; doc: BeekiriCodePageDoc }) {
  const n = doc.nodes[id];
  if (!n) return null;
  const { Icon } = nodeMeta(n, id === doc.rootId);
  return <Icon size={11} weight="bold" />;
}
