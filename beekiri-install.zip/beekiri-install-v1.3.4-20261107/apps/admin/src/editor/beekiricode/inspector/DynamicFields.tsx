import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { ArrowsClockwise, CaretDown, Lightning, MagnifyingGlass, Plus, X } from '@phosphor-icons/react';
import {
  LOOP_FIELDS,
  LOOP_LIMIT_DEFAULT,
  LOOP_LIMIT_MAX,
  LOOP_SOURCE_LABEL,
  type BindField,
  type BindKind,
  type BindProp,
  type LoopConfig,
  type LoopSource,
} from '@beekiri/page-blocks';
import { api } from '../../../api/client';
import { confirmDialog } from '../../../components/ConfirmDialog';
import type { BackendField } from '../../../fields/acf-types';
import { findParentId, type BeekiriCodeNode, type BeekiriCodePageDoc, type ThemeLayout } from '../document';
import { nodeName } from '../nodeMeta';
import { AcfFieldList } from './AcfFieldInputs';
import { Field, SelectField, SubHead, Switch } from './controls';
import { Popover } from './Popover';

/**
 * Dynamic content in Props.
 *
 * - `LoopFields`: on a box — "Repeat for" shop products / journal posts / a Backend Fields
 *   repeater, with the filters for that source. The box's first element becomes the card.
 * - `BindRow`: on an element inside such a card — a ⚡ next to Text / Link / Image that connects
 *   the property to a field of the current item (product name, price, photo…).
 */

export type LoopContext = {
  /** The box that repeats (an ancestor of the selected element). */
  loopId: string;
  loop: LoopConfig;
  fields: BindField[];
};

const IMAGE_TYPES = new Set(['image']);
const URL_TYPES = new Set(['file', 'url', 'link', 'page_link', 'post_object', 'email']);

/** Sub-fields of a Backend Fields repeater as bindable fields. */
function repeaterFields(def: BackendField | undefined): BindField[] {
  return (def?.subFields ?? [])
    .filter((f) => f.name && !['message', 'accordion', 'tab', 'repeater', 'group', 'flexible_content'].includes(f.type))
    .map((f) => ({
      key: f.name,
      label: f.label || f.name,
      kind: IMAGE_TYPES.has(f.type) ? 'image' : URL_TYPES.has(f.type) ? 'url' : 'text',
    }));
}

function repeaterDef(layouts: ThemeLayout[] | undefined, loop: LoopConfig): BackendField | undefined {
  const group = layouts?.find((l) => l.slug === loop.layout);
  return group?.fields.find((f) => f.type === 'repeater' && f.name === loop.repeater);
}

/** Fields the elements inside a loop can bind to. */
export function loopFields(loop: LoopConfig, layouts?: ThemeLayout[]): BindField[] {
  if (loop.source === 'fields') return repeaterFields(repeaterDef(layouts, loop));
  return LOOP_FIELDS[loop.source] ?? [];
}

/** The nearest repeating ancestor of `nodeId` (not the node itself), or null outside a card. */
export function loopContextFor(doc: BeekiriCodePageDoc | undefined, nodeId: string, layouts?: ThemeLayout[]): LoopContext | null {
  if (!doc) return null;
  let cur = findParentId(doc, nodeId);
  while (cur) {
    const n = doc.nodes[cur];
    if (!n) return null;
    if (n.loop && (n.type === 'section' || n.type === 'container')) {
      return { loopId: cur, loop: n.loop, fields: loopFields(n.loop, layouts) };
    }
    if (cur === doc.rootId) return null;
    cur = findParentId(doc, cur);
  }
  return null;
}

/* ── Item sources (box) ─────────────────────────────────────────────────── */

type Category = { id: string; name: string; slug: string; count: number; parentId: string | null };
let categoriesCache: Category[] | null | undefined;

function useCategories(enabled: boolean): Category[] | null {
  const [cats, setCats] = useState<Category[] | null>(categoriesCache ?? null);
  useEffect(() => {
    if (!enabled || categoriesCache !== undefined) return;
    api<{ categories: Category[] }>('/api/shop/public/categories')
      .then((r) => {
        categoriesCache = r.categories ?? [];
        setCats(categoriesCache);
      })
      .catch(() => {
        categoriesCache = [];
        setCats([]);
      });
  }, [enabled]);
  return cats;
}

type ProductHit = { id: string; title: string; image: { url: string } | null; price: { formatted: string } | null; sku: string };
const productCache = new Map<string, ProductHit>();

/** Pick products by hand (search the published catalogue; chosen ones can be reordered). */
function ProductPicker({ value, onChange }: { value: string[]; onChange: (ids: string[]) => void }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [hits, setHits] = useState<ProductHit[]>([]);
  const [loading, setLoading] = useState(false);
  const anchor = useRef<HTMLButtonElement>(null);
  const [, bump] = useState(0);

  // Titles of the chosen products (the catalogue has no by-id lookup, so one page is scanned).
  useEffect(() => {
    const missing = value.filter((id) => !productCache.has(id));
    if (!missing.length) return;
    api<{ items: ProductHit[] }>('/api/shop/public/catalog?perPage=60')
      .then((r) => {
        for (const p of r.items ?? []) productCache.set(p.id, p);
        bump((n) => n + 1);
      })
      .catch(() => undefined);
  }, [value]);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setLoading(true);
    const t = setTimeout(() => {
      api<{ items: ProductHit[] }>(`/api/shop/public/catalog?perPage=24${q ? `&q=${encodeURIComponent(q)}` : ''}`)
        .then((r) => {
          if (cancelled) return;
          for (const p of r.items ?? []) productCache.set(p.id, p);
          setHits(r.items ?? []);
        })
        .catch(() => !cancelled && setHits([]))
        .finally(() => !cancelled && setLoading(false));
    }, 200);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [open, q]);

  const move = (i: number, d: -1 | 1) => {
    const next = [...value];
    const j = i + d;
    if (j < 0 || j >= next.length) return;
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };

  return (
    <div className="bk-acf-picker bk-dyn-picker">
      {value.length ? (
        <ul className="bk-acf-picker__chosen">
          {value.map((id, i) => {
            const p = productCache.get(id);
            return (
              <li key={id}>
                {p?.image?.url ? <img className="bk-dyn-picker__thumb" src={p.image.url} alt="" /> : null}
                <span>
                  <strong>{p?.title ?? '…'}</strong>
                  <small>{p?.price?.formatted ?? p?.sku ?? ''}</small>
                </span>
                {i > 0 ? (
                  <button type="button" aria-label="Move up" onClick={() => move(i, -1)}>
                    ↑
                  </button>
                ) : null}
                {i < value.length - 1 ? (
                  <button type="button" aria-label="Move down" onClick={() => move(i, 1)}>
                    ↓
                  </button>
                ) : null}
                <button type="button" aria-label="Remove" onClick={() => onChange(value.filter((x) => x !== id))}>
                  <X size={11} weight="bold" />
                </button>
              </li>
            );
          })}
        </ul>
      ) : null}
      <button ref={anchor} type="button" className="bk-insp-btn" onClick={() => setOpen((o) => !o)}>
        <Plus size={11} weight="bold" /> {value.length ? 'Add another product' : 'Hand-pick products'}
      </button>
      <Popover anchorRef={anchor} open={open} onClose={() => setOpen(false)} width={300}>
        <div className="bk-acf-picker__panel">
          <label className="bk-acf-picker__search">
            <MagnifyingGlass size={13} />
            <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search products…" />
          </label>
          <ul className="bk-acf-picker__results">
            {loading && !hits.length ? <li className="is-empty">Loading…</li> : null}
            {!loading && !hits.length ? <li className="is-empty">No published products found.</li> : null}
            {hits.map((p) => {
              const on = value.includes(p.id);
              return (
                <li key={p.id}>
                  <button
                    type="button"
                    className={on ? 'is-on' : ''}
                    onClick={() => onChange(on ? value.filter((x) => x !== p.id) : [...value, p.id])}
                  >
                    {p.image?.url ? <img className="bk-dyn-picker__thumb" src={p.image.url} alt="" /> : null}
                    <span>
                      <strong>{p.title}</strong>
                      <small>{p.price?.formatted ?? ''}</small>
                    </span>
                    {on ? <X size={11} weight="bold" /> : <Plus size={11} weight="bold" />}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </Popover>
    </div>
  );
}

const PRODUCT_SORTS = [
  { value: 'menu_order', label: 'Shop order' },
  { value: 'newest', label: 'Newest first' },
  { value: 'title', label: 'Name A–Z' },
  { value: 'price', label: 'Price: low to high' },
  { value: 'price-desc', label: 'Price: high to low' },
  { value: 'popularity', label: 'Best sellers' },
];
const POST_SORTS = [
  { value: 'newest', label: 'Newest first' },
  { value: 'oldest', label: 'Oldest first' },
  { value: 'title', label: 'Title A–Z' },
];

function LimitField({ value, onChange }: { value: number | undefined; onChange: (n: number | undefined) => void }) {
  return (
    <Field label="Show up to">
      <input
        type="number"
        className="bk-insp-input"
        min={1}
        max={LOOP_LIMIT_MAX}
        value={value ?? ''}
        placeholder={String(LOOP_LIMIT_DEFAULT)}
        onChange={(e) => {
          const n = Math.floor(Number(e.target.value));
          onChange(Number.isFinite(n) && n >= 1 ? Math.min(LOOP_LIMIT_MAX, n) : undefined);
        }}
      />
    </Field>
  );
}

const BOX_TYPES = new Set(['container', 'section']);

/** A box's shape: its type and the types of what is inside it (cards built alike match). */
function shapeOf(doc: BeekiriCodePageDoc, id: string): string {
  const n = doc.nodes[id];
  return n ? `${n.type}:${n.children.map((c) => doc.nodes[c]?.type ?? '').join(',')}` : '';
}

/**
 * Where "Repeat for" is offered: a box that already repeats, a box holding two or more cards built
 * the same way (a product grid, a row of journal cards), or a grid with a single card in it. A
 * box of ordinary content (a heading, some text and a button) does not get it.
 */
export function offersLoop(node: BeekiriCodeNode, doc: BeekiriCodePageDoc | undefined): boolean {
  if (node.loop) return true;
  if (!doc || !BOX_TYPES.has(node.type)) return false;
  // Cards are boxes with content; page sections are not cards (the page itself is not a loop).
  const cards = node.children.filter((id) => {
    const child = doc.nodes[id];
    return child?.type === 'container' && child.children.length > 0;
  });
  if (cards.length === 1 && node.children.length === 1) return node.style?.display === 'grid';
  if (cards.length < 2 || cards.length < node.children.length * 0.75) return false;
  const shapes = new Map<string, number>();
  for (const id of cards) {
    const shape = shapeOf(doc, id);
    shapes.set(shape, (shapes.get(shape) ?? 0) + 1);
  }
  return Math.max(...shapes.values()) >= 2;
}

/** "Repeat for" on a section / container. */
export function LoopFields({
  node,
  doc,
  layouts,
  shopActive,
  documentColors,
  onUpdate,
  onRemoveNodes,
}: {
  node: BeekiriCodeNode;
  doc?: BeekiriCodePageDoc;
  layouts?: ThemeLayout[];
  shopActive: boolean;
  documentColors: string[];
  onUpdate: (patch: Partial<BeekiriCodeNode>) => void;
  onRemoveNodes?: (ids: string[]) => void;
}) {
  const loop = node.loop;
  const categories = useCategories(loop?.source === 'products');
  const set = (patch: Partial<LoopConfig>) => loop && onUpdate({ loop: { ...loop, ...patch } });
  const groups = useMemo(() => (layouts ?? []).filter((l) => l.fields.some((f) => f.type === 'repeater')), [layouts]);
  const card = doc && node.children[0] ? doc.nodes[node.children[0]] : undefined;

  const choose = async (source: string) => {
    if (!source) {
      onUpdate({ loop: undefined });
      return;
    }
    const extra = node.children.slice(1);
    if (!loop && extra.length && doc) {
      const first = card ? nodeName(card, false) : 'the first element';
      const ok = await confirmDialog({
        title: `Repeat “${first}” for every item?`,
        message: `The first element inside this box becomes the card that is shown once per ${
          source === 'products' ? 'product' : source === 'posts' ? 'post' : 'row'
        }. The other ${extra.length === 1 ? 'element' : `${extra.length} elements`} inside (${extra
          .map((id) => `“${nodeName(doc.nodes[id], false)}”`)
          .join(', ')}) ${extra.length === 1 ? 'is' : 'are'} removed.`,
        confirmLabel: 'Use it as the card',
        cancelLabel: 'Cancel',
      });
      if (!ok) return;
      onRemoveNodes?.(extra);
    }
    const next: LoopConfig = { source: source as LoopSource, limit: loop?.limit ?? LOOP_LIMIT_DEFAULT };
    if (source === 'fields') {
      const group = groups.find((g) => g.slug === loop?.layout) ?? groups[0];
      const rep = group?.fields.find((f) => f.type === 'repeater');
      if (group && rep) Object.assign(next, { layout: group.slug, repeater: rep.name, rows: [] });
    }
    onUpdate({ loop: next });
  };

  const sources = [
    ...(shopActive ? [{ value: 'products', label: LOOP_SOURCE_LABEL.products }] : []),
    { value: 'posts', label: LOOP_SOURCE_LABEL.posts },
    { value: 'fields', label: `${LOOP_SOURCE_LABEL.fields} (repeater)` },
  ];

  return (
    <div className="bk-dyn">
      <SubHead>
        <ArrowsClockwise size={12} weight="bold" /> Dynamic content
      </SubHead>
      <Field label="Repeat for">
        <SelectField value={loop?.source ?? ''} placeholder="Nothing — static content" options={sources} onChange={(v) => void choose(v)} />
      </Field>
      {!loop ? (
        <p className="bk-insp-note">
          These cards can show live content: the first card repeats for every product, journal post or Backend Fields row.
        </p>
      ) : null}

      {loop?.source === 'products' ? (
        <>
          <ProductPicker value={loop.ids ?? []} onChange={(ids) => set({ ids: ids.length ? ids : undefined })} />
          {loop.ids?.length ? (
            <p className="bk-insp-note">Hand-picked products are shown in this order. Remove them all to filter by category instead.</p>
          ) : (
            <>
              <Field label="Category">
                <SelectField
                  value={loop.category ?? ''}
                  placeholder="All categories"
                  options={(categories ?? []).map((c) => ({ value: c.slug, label: `${c.parentId ? '— ' : ''}${c.name} (${c.count})` }))}
                  onChange={(v) => set({ category: v || undefined })}
                />
              </Field>
              <Switch checked={Boolean(loop.featured)} onChange={(v) => set({ featured: v || undefined })} label="Only featured products" />
              <Field label="Sort by">
                <SelectField value={loop.sort ?? ''} placeholder="Shop order" options={PRODUCT_SORTS} onChange={(v) => set({ sort: v || undefined })} />
              </Field>
              <LimitField value={loop.limit} onChange={(limit) => set({ limit })} />
            </>
          )}
        </>
      ) : null}

      {loop?.source === 'posts' ? (
        <>
          <Field label="Sort by">
            <SelectField value={loop.sort ?? ''} placeholder="Newest first" options={POST_SORTS} onChange={(v) => set({ sort: v || undefined })} />
          </Field>
          <LimitField value={loop.limit} onChange={(limit) => set({ limit })} />
        </>
      ) : null}

      {loop?.source === 'fields' ? (
        <FieldsRows loop={loop} groups={groups} documentColors={documentColors} set={set} />
      ) : null}

      {loop ? (
        <p className="bk-insp-note">
          {card ? (
            <>
              <strong>{nodeName(card, false)}</strong> is the card. Select an element inside it and use <Lightning size={11} weight="fill" /> next to
              its text, link or image to fill it from each {loop.source === 'products' ? 'product' : loop.source === 'posts' ? 'post' : 'row'}.
            </>
          ) : (
            <>Add one element inside this box — it becomes the card that repeats.</>
          )}
        </p>
      ) : null}
    </div>
  );
}

/** Backend Fields source: which group / repeater, and its rows edited right here. */
function FieldsRows({
  loop,
  groups,
  documentColors,
  set,
}: {
  loop: LoopConfig;
  groups: ThemeLayout[];
  documentColors: string[];
  set: (patch: Partial<LoopConfig>) => void;
}) {
  const group = groups.find((g) => g.slug === loop.layout);
  const repeaters = group?.fields.filter((f) => f.type === 'repeater') ?? [];
  const def = repeaters.find((f) => f.name === loop.repeater) ?? repeaters[0];
  if (!groups.length) {
    return (
      <p className="bk-insp-note">
        No field group with a <strong>Repeater</strong> field yet. Add one under <strong>Backend Fields</strong> (for example “Team” with Name,
        Role and Photo), then pick it here.
      </p>
    );
  }
  return (
    <>
      <Field label="Field group">
        <SelectField
          value={group?.slug ?? ''}
          placeholder="Choose a group"
          options={groups.map((g) => ({ value: g.slug, label: g.title }))}
          onChange={(v) => {
            const g = groups.find((x) => x.slug === v);
            const rep = g?.fields.find((f) => f.type === 'repeater');
            set({ layout: v || undefined, repeater: rep?.name, rows: [] });
          }}
        />
      </Field>
      {repeaters.length > 1 ? (
        <Field label="Repeater">
          <SelectField
            value={def?.name ?? ''}
            options={repeaters.map((r) => ({ value: r.name, label: r.label || r.name }))}
            onChange={(v) => set({ repeater: v || undefined, rows: [] })}
          />
        </Field>
      ) : null}
      {def ? (
        <AcfFieldList
          fields={[def]}
          values={{ [def.name]: loop.rows ?? [] }}
          onChange={(v) => set({ rows: Array.isArray(v[def.name]) ? (v[def.name] as Record<string, unknown>[]) : [] })}
          ctx={{ documentColors }}
        />
      ) : null}
    </>
  );
}

/* ── Bindings (elements inside the card) ─────────────────────────────────── */

const KINDS_FOR: Record<BindProp, BindKind[]> = {
  text: ['text'],
  alt: ['text'],
  href: ['url', 'text'],
  src: ['image'],
  bg: ['image'],
};

const PROP_LABEL: Record<BindProp, string> = { text: 'text', alt: 'alt text', href: 'link', src: 'image', bg: 'background photo' };

/**
 * A Props field that can be connected to the current item. Unbound: the ordinary control plus a
 * ⚡ menu of fields. Bound: a chip naming the field, with × to type a value again.
 */
export function BindRow({
  prop,
  label,
  wide,
  ctx,
  node,
  onUpdate,
  children,
}: {
  prop: BindProp;
  label: string;
  wide?: boolean;
  ctx: LoopContext | null;
  node: BeekiriCodeNode;
  onUpdate: (patch: Partial<BeekiriCodeNode>) => void;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const anchor = useRef<HTMLButtonElement>(null);
  if (!ctx) {
    return (
      <Field label={label} wide={wide}>
        {children}
      </Field>
    );
  }
  const kinds = KINDS_FOR[prop];
  const options = ctx.fields.filter((f) => kinds.includes(f.kind));
  const bound = node.bind?.[prop];
  const field = options.find((f) => f.key === bound) ?? ctx.fields.find((f) => f.key === bound);
  const setBind = (key: string | undefined) => {
    const next = { ...(node.bind ?? {}) };
    if (key) next[prop] = key;
    else delete next[prop];
    onUpdate({ bind: Object.keys(next).length ? next : undefined });
    setOpen(false);
  };
  const menu = (
    <Popover anchorRef={anchor} open={open} onClose={() => setOpen(false)} placement="below" width={240} className="bk-dyn-menu">
      <p className="bk-dyn-menu__title">Fill the {PROP_LABEL[prop]} from each {ctx.loop.source === 'products' ? 'product' : ctx.loop.source === 'posts' ? 'post' : 'row'}</p>
      {options.length ? (
        <ul>
          {options.map((f) => (
            <li key={f.key}>
              <button type="button" className={f.key === bound ? 'is-on' : ''} onClick={() => setBind(f.key)}>
                <Lightning size={11} weight="fill" />
                <span>
                  <strong>{f.label}</strong>
                  {f.hint ? <small>{f.hint}</small> : null}
                </span>
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p className="bk-insp-note">No matching field in this source.</p>
      )}
      {bound ? (
        <button type="button" className="bk-dyn-menu__clear" onClick={() => setBind(undefined)}>
          <X size={11} weight="bold" /> Type a value instead
        </button>
      ) : null}
    </Popover>
  );
  if (bound) {
    return (
      <Field label={label} wide={wide}>
        <div className="bk-dyn-chip-row">
          <button ref={anchor} type="button" className="bk-dyn-chip" title="Change the field" onClick={() => setOpen((o) => !o)}>
            <Lightning size={11} weight="fill" />
            <span>{field?.label ?? bound}</span>
            <CaretDown size={9} weight="bold" />
          </button>
          <button type="button" className="bk-insp-icon-btn" title="Type a value instead" aria-label="Disconnect" onClick={() => setBind(undefined)}>
            <X size={11} weight="bold" />
          </button>
        </div>
        {menu}
      </Field>
    );
  }
  return (
    <Field label={label} wide={wide}>
      <div className="bk-dyn-row">
        <div className="bk-dyn-row__control">{children}</div>
        <button
          ref={anchor}
          type="button"
          className={`bk-insp-icon-btn bk-dyn-btn${open ? ' is-open' : ''}`}
          title={`Fill the ${PROP_LABEL[prop]} from each item`}
          aria-label="Use dynamic content"
          onClick={() => setOpen((o) => !o)}
        >
          <Lightning size={12} weight="fill" />
        </button>
      </div>
      {menu}
    </Field>
  );
}
