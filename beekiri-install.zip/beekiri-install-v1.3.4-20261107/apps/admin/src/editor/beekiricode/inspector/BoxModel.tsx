import { useState, type PointerEvent as ReactPointerEvent } from 'react';
import { ArrowsOutLineHorizontal, LinkBreak, LinkSimple } from '@phosphor-icons/react';
import { readBoxSide, type StyleBag } from '../styleHelpers';
import { isValidLength, normalizeLength, parseNumUnit, stepValue } from './css-values';

export type Box = 'margin' | 'padding';
export type Side = 'Top' | 'Right' | 'Bottom' | 'Left';
export type SpacingFocus = { box: Box; side: Side } | null;

const SIDES: Side[] = ['Top', 'Right', 'Bottom', 'Left'];

const allEqual = (style: StyleBag, box: Box) => {
  const v = SIDES.map((s) => readBoxSide(style, box, s));
  return v.every((x) => x && x === v[0]);
};

/**
 * Box model: dashed margin ring around a filled padding ring. Each ring has its own
 * link toggle (linked rings start that way when all four sides already match), values
 * scrub with a horizontal drag, and the hovered / focused side is reported so the canvas
 * can highlight it. Emits longhand patches (shorthand removed) so breakpoint bags stay explicit.
 */
export function BoxModel({
  style,
  onPatch,
  onFocusChange,
}: {
  style: StyleBag;
  onPatch: (patch: Record<string, string | undefined>) => void;
  onFocusChange?: (focus: SpacingFocus) => void;
}) {
  const [linked, setLinked] = useState<Record<Box, boolean>>(() => ({
    padding: allEqual(style, 'padding'),
    margin: allEqual(style, 'margin'),
  }));
  const [focus, setFocus] = useState<SpacingFocus>(null);

  const report = (f: SpacingFocus) => {
    setFocus(f);
    onFocusChange?.(f);
  };

  const write = (box: Box, side: Side, raw: string) => {
    if (!isValidLength(raw)) return;
    const v = normalizeLength(raw);
    const patch: Record<string, string | undefined> = { [box]: undefined };
    const sides = linked[box] ? SIDES : [side];
    for (const s of SIDES) {
      patch[`${box}${s}`] = sides.includes(s)
        ? v || undefined
        : readBoxSide(style, box, s) || undefined;
    }
    onPatch(patch);
  };

  const centered =
    readBoxSide(style, 'margin', 'Left') === 'auto' &&
    readBoxSide(style, 'margin', 'Right') === 'auto';
  const toggleCentered = () => {
    const patch: Record<string, string | undefined> = { margin: undefined };
    for (const s of SIDES) patch[`margin${s}`] = readBoxSide(style, 'margin', s) || undefined;
    patch.marginLeft = centered ? undefined : 'auto';
    patch.marginRight = centered ? undefined : 'auto';
    onPatch(patch);
  };

  const linkButton = (box: Box) => (
    <button
      type="button"
      className={`bk-insp-box__link is-${box}${linked[box] ? ' is-on' : ''}`}
      onClick={() => setLinked((l) => ({ ...l, [box]: !l[box] }))}
      title={
        linked[box]
          ? `${box} sides move together — click to edit each side`
          : `Link all ${box} sides`
      }
      aria-pressed={linked[box]}
    >
      {linked[box] ? <LinkSimple size={12} weight="bold" /> : <LinkBreak size={12} weight="bold" />}
    </button>
  );

  const input = (box: Box, side: Side) => (
    <SideInput
      key={`${box}-${side}`}
      className={`bk-insp-box__in is-${side.toLowerCase()}`}
      value={readBoxSide(style, box, side)}
      onCommit={(v) => write(box, side, v)}
      onHover={(on) => report(on ? { box, side } : null)}
      label={`${box} ${side.toLowerCase()}`}
    />
  );

  return (
    <div
      className="bk-insp-box"
      data-focus={focus ? `${focus.box}-${focus.side.toLowerCase()}` : undefined}
    >
      <div className={`bk-insp-box__margin${linked.margin ? ' is-linked' : ''}`}>
        <span className="bk-insp-box__tag">Margin</span>
        <span className="bk-insp-box__tools">
          <button
            type="button"
            className={`bk-insp-box__auto${centered ? ' is-on' : ''}`}
            onClick={toggleCentered}
            title={
              centered
                ? 'Horizontal margins are auto (centered)'
                : 'Center horizontally (margin auto)'
            }
            aria-pressed={centered}
          >
            <ArrowsOutLineHorizontal size={12} weight="bold" />
          </button>
          {linkButton('margin')}
        </span>
        {SIDES.map((s) => input('margin', s))}
        <div className={`bk-insp-box__padding${linked.padding ? ' is-linked' : ''}`}>
          <span className="bk-insp-box__tag is-padding">Padding</span>
          {SIDES.map((s) => input('padding', s))}
          <span className="bk-insp-box__center">{linkButton('padding')}</span>
        </div>
      </div>
    </div>
  );
}

function SideInput({
  value,
  onCommit,
  onHover,
  className,
  label,
}: {
  value: string;
  onCommit: (v: string) => void;
  onHover: (on: boolean) => void;
  className: string;
  label: string;
}) {
  const [draft, setDraft] = useState<string | null>(null);
  const shown = draft ?? value;

  /** Horizontal drag on an unfocused value scrubs it; a plain click still focuses for typing. */
  const onPointerDown = (e: ReactPointerEvent<HTMLInputElement>) => {
    if (e.button !== 0 || document.activeElement === e.currentTarget) return;
    const el = e.currentTarget;
    const startX = e.clientX;
    const start = parseNumUnit(value);
    if (value && start.num == null) return; // keywords like auto don't scrub
    const base = start.num ?? 0;
    const unit = value ? start.unit : 'px';
    let scrubbing = false;
    const move = (ev: PointerEvent) => {
      const dx = ev.clientX - startX;
      if (!scrubbing) {
        if (Math.abs(dx) < 4) return;
        scrubbing = true;
        el.blur();
        el.setPointerCapture(ev.pointerId);
        onHover(true);
      }
      const mult = ev.shiftKey ? 10 : 1;
      const n = Math.max(0, Math.round(base + Math.round(dx / 2) * mult));
      const next = `${n}${unit}`;
      setDraft(next);
      onCommit(next);
    };
    const up = () => {
      el.removeEventListener('pointermove', move);
      el.removeEventListener('pointerup', up);
      el.removeEventListener('pointercancel', up);
      if (scrubbing) {
        setDraft(null);
        onHover(false);
      }
    };
    el.addEventListener('pointermove', move);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
  };

  return (
    <input
      className={className}
      value={shown}
      placeholder="0"
      aria-label={label}
      title={`${label} — drag to adjust, ↑↓ to step`}
      spellCheck={false}
      onPointerDown={onPointerDown}
      onMouseEnter={() => onHover(true)}
      onMouseLeave={(e) => {
        // A focused field keeps its canvas highlight until blur.
        if (document.activeElement !== e.currentTarget) onHover(false);
      }}
      onFocus={(e) => {
        setDraft(value);
        onHover(true);
        e.target.select();
      }}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={() => {
        if (draft !== null && draft !== value) onCommit(draft);
        setDraft(null);
        onHover(false);
      }}
      onKeyDown={(e) => {
        if (e.key === 'Enter') {
          if (draft !== null && draft !== value) onCommit(draft);
          setDraft(null);
          (e.target as HTMLInputElement).blur();
        }
        if (e.key === 'Escape') {
          setDraft(null);
          (e.target as HTMLInputElement).blur();
        }
        if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
          e.preventDefault();
          const next = stepValue(shown, (e.key === 'ArrowUp' ? 1 : -1) * (e.shiftKey ? 10 : 1));
          setDraft(next);
          onCommit(next);
        }
      }}
    />
  );
}
