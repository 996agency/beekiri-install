import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import {
  ArrowSquareOut,
  CaretDown,
  CaretRight,
  CopySimple,
  DotsSixVertical,
  File as FileIcon,
  Image as ImageIcon,
  LinkSimple,
  ListBullets,
  ListNumbers,
  MagnifyingGlass,
  Plus,
  TextB,
  TextItalic,
  Trash,
  X,
} from '@phosphor-icons/react';
import { api } from '../../../api/client';
import { useAdminEntry } from '../../../lib/AdminEntryContext';
import { adminHref } from '../../../lib/admin-login';
import {
  choiceOptions,
  initialRow,
  typeDef,
  type BackendField,
  type FlexibleLayout,
} from '../../../fields/acf-types';
import { Segmented, SelectField, SliderField, Switch, TextArea, TextField } from './controls';
import { ColorField } from './ColorPicker';
import { MediaPicker, formatBytes, useMediaItem, type MediaItem } from './MediaPicker';
import { safeHref, sanitizeRichText } from '../../../lib/safe-html';

type Values = Record<string, unknown>;
type Ctx = { documentColors: string[] };

const str = (v: unknown) => (typeof v === 'string' ? v : v == null ? '' : String(v));
const arr = (v: unknown): string[] =>
  Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string' && x !== '') : typeof v === 'string' && v ? [v] : [];
const isObj = (v: unknown): v is Values => !!v && typeof v === 'object' && !Array.isArray(v);

/* ── wrapper ─────────────────────────────────────────────────────────────── */

function FieldWrap({ field, children }: { field: BackendField; children: ReactNode }) {
  return (
    <div className={`bk-acf-in bk-acf-in--${field.type}`}>
      <div className="bk-acf-in__label">
        {field.label}
        {field.required ? <span className="bk-acf-in__req">*</span> : null}
      </div>
      {field.instructions ? <p className="bk-acf-in__help">{field.instructions}</p> : null}
      <div className="bk-acf-in__control">{children}</div>
    </div>
  );
}

/* ── media ───────────────────────────────────────────────────────────────── */

function ImageInput({ value, onChange, label }: { value: string; onChange: (v: string) => void; label: string }) {
  const [open, setOpen] = useState(false);
  const item = useMediaItem(value);
  return (
    <>
      {value ? (
        <div className="bk-acf-media">
          <button type="button" className="bk-acf-media__thumb" onClick={() => setOpen(true)} title="Replace image">
            {item ? <img src={item.url} alt={item.alt} /> : <span className="bk-acf-media__loading">Loading…</span>}
          </button>
          <div className="bk-acf-media__meta">
            <span className="bk-acf-media__name">{item?.originalName ?? value}</span>
            {item?.width ? (
              <span className="bk-acf-media__dim">
                {item.width} × {item.height}
              </span>
            ) : null}
            <div className="bk-acf-media__actions">
              <button type="button" onClick={() => setOpen(true)}>Replace</button>
              <button type="button" className="is-danger" onClick={() => onChange('')}>Remove</button>
            </div>
          </div>
        </div>
      ) : (
        <button type="button" className="bk-acf-media-empty" onClick={() => setOpen(true)}>
          <ImageIcon size={20} />
          <span>Add image</span>
        </button>
      )}
      <MediaPicker
        open={open}
        onClose={() => setOpen(false)}
        kind="image"
        selected={value ? [value] : []}
        title={`Select ${label}`}
        onSelect={(items) => items[0] && onChange(items[0].id)}
      />
    </>
  );
}

function FileInput({ value, onChange, label }: { value: string; onChange: (v: string) => void; label: string }) {
  const [open, setOpen] = useState(false);
  const item = useMediaItem(value);
  return (
    <>
      {value ? (
        <div className="bk-acf-media is-file">
          <span className="bk-acf-media__icon">
            <FileIcon size={22} />
          </span>
          <div className="bk-acf-media__meta">
            <a className="bk-acf-media__name" href={item?.url} target="_blank" rel="noreferrer">
              {item?.originalName ?? value}
            </a>
            <span className="bk-acf-media__dim">{formatBytes(item?.size)}</span>
            <div className="bk-acf-media__actions">
              <button type="button" onClick={() => setOpen(true)}>Replace</button>
              <button type="button" className="is-danger" onClick={() => onChange('')}>Remove</button>
            </div>
          </div>
        </div>
      ) : (
        <button type="button" className="bk-acf-media-empty" onClick={() => setOpen(true)}>
          <FileIcon size={20} />
          <span>Add file</span>
        </button>
      )}
      <MediaPicker
        open={open}
        onClose={() => setOpen(false)}
        kind="file"
        selected={value ? [value] : []}
        title={`Select ${label}`}
        onSelect={(items) => items[0] && onChange(items[0].id)}
      />
    </>
  );
}

function GalleryThumb({ id, onRemove }: { id: string; onRemove: () => void }) {
  const item = useMediaItem(id);
  return (
    <span className="bk-acf-gallery__item">
      {item ? <img src={item.url} alt={item.alt} /> : null}
      <button type="button" onClick={onRemove} aria-label="Remove">
        <X size={10} weight="bold" />
      </button>
    </span>
  );
}

function GalleryInput({ field, value, onChange }: { field: BackendField; value: string[]; onChange: (v: string[]) => void }) {
  const [open, setOpen] = useState(false);
  const [drag, setDrag] = useState<number | null>(null);
  const full = field.max != null && value.length >= field.max;
  return (
    <>
      <div className="bk-acf-gallery">
        {value.map((id, i) => (
          <span
            key={`${id}-${i}`}
            draggable
            onDragStart={() => setDrag(i)}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => {
              if (drag == null || drag === i) return;
              const next = [...value];
              const [m] = next.splice(drag, 1);
              next.splice(i, 0, m);
              onChange(next);
              setDrag(null);
            }}
          >
            <GalleryThumb id={id} onRemove={() => onChange(value.filter((_, j) => j !== i))} />
          </span>
        ))}
        {!full ? (
          <button type="button" className="bk-acf-gallery__add" onClick={() => setOpen(true)} aria-label="Add to gallery">
            <Plus size={16} />
          </button>
        ) : null}
      </div>
      <div className="bk-acf-in__meta">
        {value.length} image{value.length === 1 ? '' : 's'}
        {field.max != null ? ` / max ${field.max}` : ''}
        {value.length ? (
          <button type="button" className="bk-acf-linkbtn" onClick={() => onChange([])}>
            Clear
          </button>
        ) : null}
      </div>
      <MediaPicker
        open={open}
        onClose={() => setOpen(false)}
        kind="image"
        multiple
        onSelect={(items: MediaItem[]) => {
          const ids = items.map((i) => i.id).filter((id) => !value.includes(id));
          const room = field.max != null ? Math.max(0, field.max - value.length) : ids.length;
          onChange([...value, ...ids.slice(0, room)]);
        }}
      />
    </>
  );
}

/* ── relational ──────────────────────────────────────────────────────────── */

type FormHit = { id: string; title: string; status: string };
let formsPromise: Promise<FormHit[]> | null = null;

/** Saved Bee Forms (cached per page load; the list is tiny). Empty when the extension is off. */
export function useFormsList(): FormHit[] | null {
  const [items, setItems] = useState<FormHit[] | null>(null);
  useEffect(() => {
    let cancelled = false;
    formsPromise ??= api<{ items: FormHit[] }>('/api/forms/lookup')
      .then((r) => r.items)
      .catch(() => {
        formsPromise = null;
        return [];
      });
    void formsPromise.then((list) => !cancelled && setItems(list));
    return () => {
      cancelled = true;
    };
  }, []);
  return items;
}

export function invalidateFormsList() {
  formsPromise = null;
}

export function FormPicker({ value, onChange, allowNull }: { value: string; onChange: (v: string) => void; allowNull: boolean }) {
  const forms = useFormsList();
  const formsHref = adminHref(useAdminEntry().basePath, 'forms');
  const options = (forms ?? []).map((f) => ({ value: f.id, label: f.status === 'inactive' ? `${f.title} (inactive)` : f.title }));
  return (
    <div className="bk-acf-form-pick">
      <SelectField value={value} onChange={onChange} options={options} placeholder={forms === null ? 'Loading…' : forms.length ? (allowNull ? '- Select a form -' : 'Choose a form') : 'No forms yet'} />
      <a className="bk-insp-link" href={value ? `${formsHref}/${encodeURIComponent(value)}` : formsHref}>{value ? 'Edit this form' : 'Manage forms'}</a>
    </div>
  );
}

type PostHit = { id: string; title: string; slug: string; type: string; status: string };
type UserHit = { id: string; username: string; displayName: string };
const postCache = new Map<string, PostHit>();
const userCache = new Map<string, UserHit>();

function useLookup<T extends { id: string }>(
  endpoint: 'posts' | 'users',
  params: Record<string, string>,
  query: string,
  enabled: boolean,
) {
  const [items, setItems] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);
  const key = JSON.stringify(params);
  useEffect(() => {
    if (!enabled) return;
    const t = window.setTimeout(() => {
      setLoading(true);
      const qs = new URLSearchParams({ ...params, q: query });
      api<{ items: T[] }>(`/api/fields/lookup/${endpoint}?${qs}`)
        .then((r) => {
          for (const it of r.items) (endpoint === 'posts' ? postCache : userCache).set(it.id, it as never);
          setItems(r.items);
        })
        .catch(() => setItems([]))
        .finally(() => setLoading(false));
    }, 200);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [endpoint, key, query, enabled]);
  return { items, loading };
}

/** Make sure labels exist for already-selected ids. */
function useResolve(endpoint: 'posts' | 'users', ids: string[]) {
  const [, tick] = useState(0);
  const missing = ids.filter((id) => !(endpoint === 'posts' ? postCache : userCache).has(id) && !/^(https?:)?\/\//.test(id) && !id.startsWith('/'));
  const key = missing.join(',');
  useEffect(() => {
    if (!key) return;
    api<{ items: { id: string }[] }>(`/api/fields/lookup/${endpoint}?ids=${encodeURIComponent(key)}`)
      .then((r) => {
        for (const it of r.items) (endpoint === 'posts' ? postCache : userCache).set(it.id, it as never);
        tick((n) => n + 1);
      })
      .catch(() => {});
  }, [endpoint, key]);
}

function PickerInput({
  kind,
  field,
  value,
  multiple,
  onChange,
}: {
  kind: 'posts' | 'users';
  field: BackendField;
  value: string[];
  multiple: boolean;
  onChange: (ids: string[]) => void;
}) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const params: Record<string, string> =
    kind === 'posts' ? { types: (field.postTypes ?? []).join(',') } : { roles: (field.roles ?? []).join(',') };
  const { items, loading } = useLookup<PostHit & UserHit>(kind, params, q, open);
  useResolve(kind, value);

  const labelFor = (id: string) => {
    if (kind === 'posts') {
      const p = postCache.get(id);
      return p ? p.title || p.slug : id.startsWith('/') ? id : '…';
    }
    const u = userCache.get(id);
    return u ? u.displayName || u.username : '…';
  };
  const sub = (id: string) => {
    if (kind !== 'posts') return userCache.get(id)?.username ?? '';
    const p = postCache.get(id);
    return p ? `${p.type}${p.status !== 'publish' ? ` · ${p.status}` : ''}` : '';
  };
  const full = multiple && field.max != null && value.length >= field.max;

  const pick = (id: string) => {
    if (!multiple) {
      onChange([id]);
      setOpen(false);
      return;
    }
    onChange(value.includes(id) ? value.filter((x) => x !== id) : full ? value : [...value, id]);
  };

  return (
    <div className="bk-acf-picker">
      {value.length ? (
        <ul className="bk-acf-picker__chosen">
          {value.map((id, i) => (
            <li key={id}>
              <span>
                <strong>{labelFor(id)}</strong>
                <small>{sub(id)}</small>
              </span>
              {multiple && i > 0 ? (
                <button
                  type="button"
                  aria-label="Move up"
                  onClick={() => {
                    const next = [...value];
                    [next[i - 1], next[i]] = [next[i], next[i - 1]];
                    onChange(next);
                  }}
                >
                  ↑
                </button>
              ) : null}
              <button type="button" aria-label="Remove" onClick={() => onChange(value.filter((x) => x !== id))}>
                <X size={10} weight="bold" />
              </button>
            </li>
          ))}
        </ul>
      ) : null}
      {open ? (
        <div className="bk-acf-picker__panel">
          <label className="bk-acf-picker__search">
            <MagnifyingGlass size={12} />
            <input autoFocus placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} />
            <button type="button" onClick={() => setOpen(false)} aria-label="Close">
              <X size={10} weight="bold" />
            </button>
          </label>
          <ul className="bk-acf-picker__results">
            {loading && !items.length ? <li className="is-empty">Searching…</li> : null}
            {!loading && !items.length ? <li className="is-empty">No matches</li> : null}
            {items.map((it) => {
              const on = value.includes(it.id);
              return (
                <li key={it.id}>
                  <button type="button" className={on ? 'is-on' : ''} onClick={() => pick(it.id)}>
                    <strong>{kind === 'posts' ? it.title || it.slug : it.displayName || it.username}</strong>
                    <small>{kind === 'posts' ? `${it.type}${it.status !== 'publish' ? ` · ${it.status}` : ''}` : it.username}</small>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      ) : !full && (multiple || !value.length) ? (
        <button type="button" className="bk-acf-addbtn" onClick={() => setOpen(true)}>
          <Plus size={12} /> {kind === 'posts' ? 'Select post' : 'Select user'}
        </button>
      ) : !multiple ? (
        <button type="button" className="bk-acf-linkbtn" onClick={() => setOpen(true)}>
          Change
        </button>
      ) : null}
    </div>
  );
}

function LinkInput({ value, onChange }: { value: unknown; onChange: (v: unknown) => void }) {
  const link = isObj(value) ? value : typeof value === 'string' && value ? { url: value } : {};
  const url = str(link.url);
  const title = str(link.title);
  const target = str(link.target);
  const set = (p: Values) => {
    const next = { title, url, target, ...p };
    onChange(next.url || next.title ? next : '');
  };
  return (
    <div className="bk-acf-link">
      <div className="bk-acf-link__row">
        <LinkSimple size={13} />
        <TextField value={url} onChange={(v) => set({ url: v })} placeholder="https:// or /page" live />
      </div>
      <TextField value={title} onChange={(v) => set({ title: v })} placeholder="Link text" live />
      <div className="bk-acf-link__foot">
        <Switch label="Open in new tab" checked={target === '_blank'} onChange={(v) => set({ target: v ? '_blank' : '' })} />
        {safeHref(url) ? (
          <a href={safeHref(url)} target="_blank" rel="noreferrer" className="bk-acf-linkbtn" aria-label="Open link">
            <ArrowSquareOut size={12} />
          </a>
        ) : null}
      </div>
    </div>
  );
}

/* ── wysiwyg (light) ─────────────────────────────────────────────────────── */

function WysiwygInput({ value, onChange, basic }: { value: string; onChange: (v: string) => void; basic?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const [html, setHtml] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || document.activeElement === el) return;
    const clean = sanitizeRichText(value);
    if (el.innerHTML !== clean) el.innerHTML = clean;
  }, [value, html]);
  const cmd = (c: string, arg?: string) => {
    ref.current?.focus();
    document.execCommand(c, false, arg);
    if (ref.current) onChange(ref.current.innerHTML);
  };
  return (
    <div className="bk-acf-rte">
      <div className="bk-acf-rte__bar">
        {!html ? (
          <>
            {!basic ? (
              <select
                defaultValue=""
                onChange={(e) => {
                  cmd('formatBlock', e.target.value);
                  e.target.value = '';
                }}
              >
                <option value="" disabled>
                  Format
                </option>
                <option value="p">Paragraph</option>
                <option value="h2">Heading 2</option>
                <option value="h3">Heading 3</option>
                <option value="h4">Heading 4</option>
                <option value="blockquote">Quote</option>
              </select>
            ) : null}
            <button type="button" onMouseDown={(e) => e.preventDefault()} onClick={() => cmd('bold')} aria-label="Bold">
              <TextB size={13} weight="bold" />
            </button>
            <button type="button" onMouseDown={(e) => e.preventDefault()} onClick={() => cmd('italic')} aria-label="Italic">
              <TextItalic size={13} />
            </button>
            <button type="button" onMouseDown={(e) => e.preventDefault()} onClick={() => cmd('insertUnorderedList')} aria-label="Bullet list">
              <ListBullets size={13} />
            </button>
            <button type="button" onMouseDown={(e) => e.preventDefault()} onClick={() => cmd('insertOrderedList')} aria-label="Numbered list">
              <ListNumbers size={13} />
            </button>
            <button
              type="button"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => {
                const url = safeHref(window.prompt('Link URL'));
                if (url) cmd('createLink', url);
              }}
              aria-label="Link"
            >
              <LinkSimple size={13} />
            </button>
          </>
        ) : null}
        <span className="bk-acf-rte__spacer" />
        <button type="button" className={`bk-acf-rte__mode${html ? ' is-on' : ''}`} onClick={() => setHtml((h) => !h)}>
          {html ? 'Visual' : 'HTML'}
        </button>
      </div>
      {html ? (
        <TextArea value={value} onChange={onChange} rows={6} />
      ) : (
        <div
          ref={ref}
          className="bk-acf-rte__area"
          contentEditable
          suppressContentEditableWarning
          onInput={(e) => onChange(sanitizeRichText((e.target as HTMLDivElement).innerHTML))}
        />
      )}
    </div>
  );
}

/* ── dates (storage: Ymd · Y-m-d H:i:s · H:i:s) ─────────────────────── */

const ymdToInput = (v: string) => (/^\d{8}$/.test(v) ? `${v.slice(0, 4)}-${v.slice(4, 6)}-${v.slice(6, 8)}` : v.slice(0, 10));
const inputToYmd = (v: string) => v.replace(/-/g, '');

/* ── repeater / flexible rows ────────────────────────────────────────────── */

function RowShell({
  index,
  title,
  open,
  onToggle,
  onRemove,
  onDuplicate,
  canRemove,
  canAdd,
  dragProps,
  children,
}: {
  index: number;
  title: string;
  open: boolean;
  onToggle: () => void;
  onRemove: () => void;
  onDuplicate: () => void;
  canRemove: boolean;
  canAdd: boolean;
  dragProps: React.HTMLAttributes<HTMLSpanElement> & { draggable: boolean };
  children: ReactNode;
}) {
  return (
    <div className={`bk-acf-row${open ? ' is-open' : ''}`}>
      <div className="bk-acf-row__head">
        <span className="bk-acf-row__grip" {...dragProps} title="Drag to reorder">
          <DotsSixVertical size={12} weight="bold" />
        </span>
        <button type="button" className="bk-acf-row__toggle" onClick={onToggle}>
          {open ? <CaretDown size={10} weight="bold" /> : <CaretRight size={10} weight="bold" />}
          <span className="bk-acf-row__index">{index + 1}</span>
          <span className="bk-acf-row__title">{title}</span>
        </button>
        {canAdd ? (
          <button type="button" className="bk-acf-row__btn" onClick={onDuplicate} aria-label="Duplicate row">
            <CopySimple size={12} />
          </button>
        ) : null}
        {canRemove ? (
          <button type="button" className="bk-acf-row__btn is-danger" onClick={onRemove} aria-label="Remove row">
            <Trash size={12} />
          </button>
        ) : null}
      </div>
      {open ? <div className="bk-acf-row__body">{children}</div> : null}
    </div>
  );
}

function useRowDrag(rows: unknown[], onChange: (rows: Values[]) => void) {
  const [from, setFrom] = useState<number | null>(null);
  return (i: number) => ({
    draggable: true,
    onDragStart: (e: React.DragEvent) => {
      e.stopPropagation();
      setFrom(i);
    },
    onDragOver: (e: React.DragEvent) => from != null && e.preventDefault(),
    onDrop: (e: React.DragEvent) => {
      e.stopPropagation();
      if (from == null || from === i) return;
      const next = [...rows] as Values[];
      const [m] = next.splice(from, 1);
      next.splice(i, 0, m);
      onChange(next);
      setFrom(null);
    },
    onDragEnd: () => setFrom(null),
  });
}

function rowTitle(fields: BackendField[], row: Values, collapsed?: string) {
  const pick = collapsed ? fields.find((f) => f.name === collapsed) : fields.find((f) => ['text', 'textarea', 'email', 'url', 'number', 'select', 'radio'].includes(f.type));
  const v = pick ? row[pick.name] : '';
  const s = typeof v === 'string' || typeof v === 'number' ? String(v).replace(/<[^>]+>/g, '').trim() : '';
  return s.length > 40 ? `${s.slice(0, 40)}…` : s;
}

function RepeaterInput({ field, value, onChange, ctx }: { field: BackendField; value: unknown; onChange: (v: Values[]) => void; ctx: Ctx }) {
  const rows = Array.isArray(value) ? value.filter(isObj) : [];
  const subs = field.subFields ?? [];
  const [open, setOpen] = useState<Record<number, boolean>>({});
  const drag = useRowDrag(rows, onChange);
  const canAdd = field.maxRows == null || rows.length < field.maxRows;
  const canRemove = field.minRows == null || rows.length > field.minRows;

  return (
    <div className="bk-acf-rows">
      {rows.length === 0 ? <p className="bk-acf-in__empty">No rows yet.</p> : null}
      {rows.map((row, i) => (
        <RowShell
          key={i}
          index={i}
          title={rowTitle(subs, row, field.collapsed)}
          open={open[i] ?? rows.length <= 3}
          onToggle={() => setOpen((o) => ({ ...o, [i]: !(o[i] ?? rows.length <= 3) }))}
          onRemove={() => onChange(rows.filter((_, j) => j !== i))}
          onDuplicate={() => {
            const next = [...rows];
            next.splice(i + 1, 0, structuredClone(row));
            onChange(next);
          }}
          canRemove={canRemove}
          canAdd={canAdd}
          dragProps={drag(i)}
        >
          <AcfFieldList fields={subs} values={row} onChange={(r) => onChange(rows.map((x, j) => (j === i ? r : x)))} ctx={ctx} />
        </RowShell>
      ))}
      {canAdd ? (
        <button
          type="button"
          className="bk-acf-addbtn"
          onClick={() => {
            onChange([...rows, initialRow(subs)]);
            setOpen((o) => ({ ...o, [rows.length]: true }));
          }}
        >
          <Plus size={12} /> {field.buttonLabel || 'Add Row'}
        </button>
      ) : null}
      {field.minRows != null || field.maxRows != null ? (
        <div className="bk-acf-in__meta">
          {rows.length} row{rows.length === 1 ? '' : 's'}
          {field.minRows != null ? ` · min ${field.minRows}` : ''}
          {field.maxRows != null ? ` · max ${field.maxRows}` : ''}
        </div>
      ) : null}
    </div>
  );
}

function FlexibleInput({ field, value, onChange, ctx }: { field: BackendField; value: unknown; onChange: (v: Values[]) => void; ctx: Ctx }) {
  const rows = Array.isArray(value) ? value.filter(isObj) : [];
  const layouts = field.layouts ?? [];
  const [open, setOpen] = useState<Record<number, boolean>>({});
  const [menu, setMenu] = useState(false);
  const drag = useRowDrag(rows, onChange);
  const canAdd = field.max == null || rows.length < field.max;
  const countOf = (name: string) => rows.filter((r) => r.acf_fc_layout === name).length;
  const layoutOf = (row: Values) => layouts.find((l) => l.name === row.acf_fc_layout);

  const add = (l: FlexibleLayout) => {
    onChange([...rows, { acf_fc_layout: l.name, ...initialRow(l.subFields) }]);
    setOpen((o) => ({ ...o, [rows.length]: true }));
    setMenu(false);
  };

  return (
    <div className="bk-acf-rows">
      {rows.length === 0 ? <p className="bk-acf-in__empty">Click “{field.buttonLabel || 'Add Row'}” to start creating your layout.</p> : null}
      {rows.map((row, i) => {
        const l = layoutOf(row);
        return (
          <RowShell
            key={i}
            index={i}
            title={`${l?.label ?? String(row.acf_fc_layout)}${l ? ` ${rowTitle(l.subFields, row) ? `— ${rowTitle(l.subFields, row)}` : ''}` : ''}`}
            open={open[i] ?? true}
            onToggle={() => setOpen((o) => ({ ...o, [i]: !(o[i] ?? true) }))}
            onRemove={() => onChange(rows.filter((_, j) => j !== i))}
            onDuplicate={() => {
              const next = [...rows];
              next.splice(i + 1, 0, structuredClone(row));
              onChange(next);
            }}
            canRemove={field.min == null || rows.length > field.min}
            canAdd={canAdd && (!l || l.max == null || countOf(l.name) < l.max)}
            dragProps={drag(i)}
          >
            {l ? (
              <AcfFieldList
                fields={l.subFields}
                values={row}
                onChange={(r) => onChange(rows.map((x, j) => (j === i ? { ...r, acf_fc_layout: l.name } : x)))}
                ctx={ctx}
              />
            ) : (
              <p className="bk-acf-in__empty">Layout “{String(row.acf_fc_layout)}” no longer exists.</p>
            )}
          </RowShell>
        );
      })}
      {canAdd ? (
        <div className="bk-acf-flexadd">
          <button type="button" className="bk-acf-addbtn" onClick={() => setMenu((m) => !m)}>
            <Plus size={12} /> {field.buttonLabel || 'Add Row'}
          </button>
          {menu ? (
            <ul className="bk-acf-flexadd__menu">
              {layouts.map((l) => {
                const full = l.max != null && countOf(l.name) >= l.max;
                return (
                  <li key={l.id}>
                    <button type="button" disabled={full} onClick={() => add(l)}>
                      {l.label}
                      {full ? <small>max reached</small> : null}
                    </button>
                  </li>
                );
              })}
            </ul>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

/* ── one field ───────────────────────────────────────────────────────────── */

export function AcfInput({ field, value, onChange, ctx }: { field: BackendField; value: unknown; onChange: (v: unknown) => void; ctx: Ctx }) {
  const placeholder = field.placeholder || '';
  const affix = (node: ReactNode) =>
    field.prepend || field.append ? (
      <div className="bk-acf-affix">
        {field.prepend ? <span>{field.prepend}</span> : null}
        {node}
        {field.append ? <span>{field.append}</span> : null}
      </div>
    ) : (
      node
    );

  switch (field.type) {
    case 'text':
    case 'email':
    case 'url':
    case 'password':
      return affix(<TextField value={str(value)} onChange={onChange} placeholder={placeholder} live />);
    case 'textarea':
      return <TextArea value={str(value)} onChange={onChange} rows={field.rows ?? 4} placeholder={placeholder} />;
    case 'number':
      return affix(
        <input
          type="number"
          className="bk-insp-input"
          value={str(value)}
          min={field.min}
          max={field.max}
          step={field.step ?? 'any'}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value)}
        />,
      );
    case 'range':
      return (
        <SliderField
          value={str(value)}
          onChange={onChange}
          min={field.min ?? 0}
          max={field.max ?? 100}
          step={field.step ?? 1}
          suffix={field.append}
          fallback={field.min ?? 0}
        />
      );
    case 'image':
      return <ImageInput value={str(value)} onChange={onChange} label={field.label} />;
    case 'file':
      return <FileInput value={str(value)} onChange={onChange} label={field.label} />;
    case 'gallery':
      return <GalleryInput field={field} value={arr(value)} onChange={onChange} />;
    case 'wysiwyg':
      return <WysiwygInput value={str(value)} onChange={onChange} basic={field.toolbar === 'basic'} />;
    case 'oembed':
      return <TextField value={str(value)} onChange={onChange} placeholder="https://youtube.com/watch?v=…" live />;
    case 'select': {
      const opts = choiceOptions(field);
      if (field.multiple) {
        const sel = arr(value);
        return (
          <div className="bk-acf-choices">
            {opts.map((o) => (
              <label key={o.value}>
                <input type="checkbox" checked={sel.includes(o.value)} onChange={(e) => onChange(e.target.checked ? [...sel, o.value] : sel.filter((x) => x !== o.value))} />
                {o.label}
              </label>
            ))}
          </div>
        );
      }
      return <SelectField value={str(value)} onChange={onChange} options={opts} placeholder={field.allowNull || !field.required ? '- Select -' : opts[0]?.label} />;
    }
    case 'checkbox': {
      const sel = arr(value);
      return (
        <div className={`bk-acf-choices${field.layout === 'horizontal' ? ' is-row' : ''}`}>
          {choiceOptions(field).map((o) => (
            <label key={o.value}>
              <input type="checkbox" checked={sel.includes(o.value)} onChange={(e) => onChange(e.target.checked ? [...sel, o.value] : sel.filter((x) => x !== o.value))} />
              {o.label}
            </label>
          ))}
        </div>
      );
    }
    case 'radio':
      return (
        <div className={`bk-acf-choices${field.layout === 'horizontal' ? ' is-row' : ''}`}>
          {choiceOptions(field).map((o) => (
            <label key={o.value}>
              <input type="radio" checked={str(value) === o.value} onChange={() => onChange(o.value)} />
              {o.label}
            </label>
          ))}
          {field.allowNull && str(value) ? (
            <button type="button" className="bk-acf-linkbtn" onClick={() => onChange('')}>
              Clear
            </button>
          ) : null}
        </div>
      );
    case 'button_group':
      return (
        <Segmented
          value={str(value)}
          onChange={onChange}
          options={choiceOptions(field).map((o) => ({ value: o.value, label: o.label }))}
          allowEmpty={field.allowNull}
        />
      );
    case 'true_false': {
      const on = value === true || value === '1' || value === 1;
      const label = field.ui ? (on ? field.onText || 'Yes' : field.offText || 'No') : field.message || field.label;
      return <Switch label={label} checked={on} onChange={(v) => onChange(v)} />;
    }
    case 'link':
      return <LinkInput value={value} onChange={onChange} />;
    case 'post_object':
    case 'page_link':
    case 'relationship': {
      const multiple = field.type === 'relationship' || Boolean(field.multiple);
      return (
        <PickerInput
          kind="posts"
          field={field}
          value={arr(value)}
          multiple={multiple}
          onChange={(ids) => onChange(multiple ? ids : ids[0] ?? '')}
        />
      );
    }
    case 'user':
      return (
        <PickerInput
          kind="users"
          field={field}
          value={arr(value)}
          multiple={Boolean(field.multiple)}
          onChange={(ids) => onChange(field.multiple ? ids : ids[0] ?? '')}
        />
      );
    case 'form':
      return <FormPicker value={str(value)} onChange={onChange} allowNull={Boolean(field.allowNull) || !field.required} />;
    case 'date_picker':
      return (
        <input
          type="date"
          className="bk-insp-input"
          value={ymdToInput(str(value))}
          onChange={(e) => onChange(inputToYmd(e.target.value))}
        />
      );
    case 'date_time_picker':
      return (
        <input
          type="datetime-local"
          className="bk-insp-input"
          value={str(value).replace(' ', 'T').slice(0, 16)}
          onChange={(e) => onChange(e.target.value ? `${e.target.value.replace('T', ' ')}:00` : '')}
        />
      );
    case 'time_picker':
      return (
        <input
          type="time"
          className="bk-insp-input"
          value={str(value).slice(0, 5)}
          onChange={(e) => onChange(e.target.value ? `${e.target.value}:00` : '')}
        />
      );
    case 'color_picker':
      return <ColorField value={str(value)} onChange={onChange} documentColors={ctx.documentColors} />;
    case 'group':
      return (
        <div className="bk-acf-group">
          <AcfFieldList fields={field.subFields ?? []} values={isObj(value) ? value : {}} onChange={onChange} ctx={ctx} />
        </div>
      );
    case 'repeater':
      return <RepeaterInput field={field} value={value} onChange={onChange} ctx={ctx} />;
    case 'flexible_content':
      return <FlexibleInput field={field} value={value} onChange={onChange} ctx={ctx} />;
    default:
      return <TextField value={str(value)} onChange={onChange} live />;
  }
}

/* ── list with tabs + accordions ─────────────────────────────────────────── */

function Accordion({ field, children }: { field: BackendField; children: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className={`bk-acf-acc${open ? ' is-open' : ''}`}>
      <button type="button" className="bk-acf-acc__head" onClick={() => setOpen((o) => !o)}>
        {open ? <CaretDown size={10} weight="bold" /> : <CaretRight size={10} weight="bold" />}
        {field.label}
      </button>
      {open ? <div className="bk-acf-acc__body">{children}</div> : null}
    </div>
  );
}

function renderRun(fields: BackendField[], values: Values, onChange: (v: Values) => void, ctx: Ctx): ReactNode[] {
  const out: ReactNode[] = [];
  let i = 0;
  while (i < fields.length) {
    const f = fields[i];
    if (f.type === 'accordion') {
      const inner: BackendField[] = [];
      i++;
      while (i < fields.length && fields[i].type !== 'accordion') inner.push(fields[i++]);
      out.push(
        <Accordion key={f.id} field={f}>
          {renderRun(inner, values, onChange, ctx)}
        </Accordion>,
      );
      continue;
    }
    if (f.type === 'message') {
      out.push(
        <div key={f.id} className="bk-acf-message">
          {f.label ? <strong>{f.label}</strong> : null}
          {f.message ? <p>{f.message}</p> : null}
        </div>,
      );
    } else if (!typeDef(f.type).noValue) {
      out.push(
        <FieldWrap key={f.id} field={f}>
          <AcfInput field={f} value={values[f.name]} onChange={(v) => onChange({ ...values, [f.name]: v })} ctx={ctx} />
        </FieldWrap>,
      );
    }
    i++;
  }
  return out;
}

export function AcfFieldList({
  fields,
  values,
  onChange,
  ctx,
}: {
  fields: BackendField[];
  values: Values;
  onChange: (v: Values) => void;
  ctx: Ctx;
}) {
  const groups = useMemo(() => {
    const gs: { tab: BackendField | null; fields: BackendField[] }[] = [{ tab: null, fields: [] }];
    for (const f of fields) {
      if (f.type === 'tab') gs.push({ tab: f, fields: [] });
      else gs[gs.length - 1].fields.push(f);
    }
    return gs.filter((g) => g.tab || g.fields.length);
  }, [fields]);
  const tabs = groups.filter((g) => g.tab);
  const [active, setActive] = useState(0);

  if (!tabs.length) return <div className="bk-acf-list">{renderRun(fields, values, onChange, ctx)}</div>;

  const lead = groups[0].tab ? [] : groups[0].fields;
  const current = tabs[Math.min(active, tabs.length - 1)];
  return (
    <div className="bk-acf-list">
      {lead.length ? renderRun(lead, values, onChange, ctx) : null}
      <div className="bk-acf-tabs-in" role="tablist">
        {tabs.map((t, i) => (
          <button key={t.tab!.id} type="button" role="tab" aria-selected={i === active} className={i === active ? 'is-active' : ''} onClick={() => setActive(i)}>
            {t.tab!.label}
          </button>
        ))}
      </div>
      {renderRun(current.fields, values, onChange, ctx)}
    </div>
  );
}
