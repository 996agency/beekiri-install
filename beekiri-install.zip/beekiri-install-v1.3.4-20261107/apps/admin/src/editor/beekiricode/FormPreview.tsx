import { useEffect, useState, type ReactNode } from 'react';
import { api, apiUrl } from '../../api/client';
import { sanitizePreviewHtml } from '../../lib/safe-html';

const CSS_ID = 'bk-form-preview-css';

/** Loads the public form stylesheet once so the canvas preview matches the website. */
function useFormCss() {
  useEffect(() => {
    if (document.getElementById(CSS_ID)) return;
    const link = document.createElement('link');
    link.id = CSS_ID;
    link.rel = 'stylesheet';
    link.href = apiUrl('/api/forms/public/assets/form.css');
    document.head.appendChild(link);
  }, []);
}

/** Read-only rendering of a Bee Forms form inside the page editor. */
export function FormPreview({
  formId,
  interactive,
  placeholder,
}: {
  formId?: string;
  interactive: boolean;
  placeholder: (title: string, hint: string) => ReactNode;
}) {
  useFormCss();
  const [state, setState] = useState<{ id: string; html: string; title: string } | { id: string; error: string } | null>(null);

  useEffect(() => {
    if (!formId) return;
    let cancelled = false;
    api<{ html: string; title: string }>(`/api/forms/${encodeURIComponent(formId)}/preview`)
      .then((r) => !cancelled && setState({ id: formId, html: r.html, title: r.title }))
      .catch((e) => !cancelled && setState({ id: formId, error: e instanceof Error ? e.message : 'Could not load the form.' }));
    return () => {
      cancelled = true;
    };
  }, [formId]);

  if (!formId) return <>{placeholder('Form', 'Pick a form in Props → Content')}</>;
  if (!state || state.id !== formId) return <>{placeholder('Form', 'Loading…')}</>;
  if ('error' in state) return <>{placeholder('Form', interactive ? state.error : '')}</>;
  return <div className="bk-beekiricode__form-preview" dangerouslySetInnerHTML={{ __html: sanitizePreviewHtml(state.html) }} />;
}
