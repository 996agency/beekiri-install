import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { SiteSectionPlacement } from './SiteSectionPlacement';
import {
  ArrowSquareOut,
  CaretDown,
  CaretRight,
  Check,
  MagnifyingGlass,
  Plus,
  Tag,
  TreeStructure,
  X,
} from '@phosphor-icons/react';
import { api, ApiError } from '../../api/client';
import { useAuth } from '../../auth/AuthContext';
import { useAdminHref } from '../../lib/AdminEntryContext';

type TermRow = {
  id: string;
  name: string;
  slug: string;
  parentId: string | null;
};

type TaxonomyBlock = {
  id: string;
  slug: string;
  singular: string;
  plural: string;
  hierarchical: boolean;
  terms: TermRow[];
  selectedTermIds: string[];
};

type Props = {
  pageId: string;
  apiBase: string;
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

/** Content kind from the API base: /api/pages → page, /api/content/book → book. */
function kindFromApiBase(apiBase: string): string {
  if (apiBase.includes('/api/posts')) return 'post';
  const m = apiBase.match(/\/api\/content\/([^/]+)/);
  return m ? m[1] : 'page';
}

/* ── Hierarchical: indented checkbox tree ───────────────────────────────── */

function TermTree({
  terms,
  selected,
  disabled,
  query,
  onToggle,
}: {
  terms: TermRow[];
  selected: Set<string>;
  disabled: boolean;
  query: string;
  onToggle: (id: string) => void;
}) {
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const byParent = useMemo(() => {
    const map = new Map<string | null, TermRow[]>();
    const ids = new Set(terms.map((t) => t.id));
    for (const t of terms) {
      // Orphans (parent deleted) float to the top level.
      const key = t.parentId && ids.has(t.parentId) ? t.parentId : null;
      map.set(key, [...(map.get(key) ?? []), t]);
    }
    return map;
  }, [terms]);
  const q = query.trim().toLowerCase();

  const rows: { term: TermRow; depth: number; hasKids: boolean }[] = [];
  const walk = (parent: string | null, depth: number) => {
    for (const t of byParent.get(parent) ?? []) {
      const kids = byParent.get(t.id) ?? [];
      const matches = !q || t.name.toLowerCase().includes(q);
      const kidMatches = q && kids.some((k) => k.name.toLowerCase().includes(q));
      if (matches || kidMatches) rows.push({ term: t, depth, hasKids: kids.length > 0 });
      if (kids.length && (q || !collapsed[t.id])) walk(t.id, depth + 1);
    }
  };
  walk(null, 0);

  if (!rows.length) return <p className="bk-ptab__empty-row">No terms match “{query}”.</p>;

  return (
    <ul className="bk-ptab__tree" role="group">
      {rows.map(({ term, depth, hasKids }) => {
        const on = selected.has(term.id);
        return (
          <li key={term.id} style={{ ['--depth' as string]: depth }}>
            <span className="bk-ptab__tree-caret">
              {hasKids && !q ? (
                <button
                  type="button"
                  aria-label={collapsed[term.id] ? 'Expand' : 'Collapse'}
                  onClick={() => setCollapsed((c) => ({ ...c, [term.id]: !c[term.id] }))}
                >
                  {collapsed[term.id] ? <CaretRight size={10} weight="bold" /> : <CaretDown size={10} weight="bold" />}
                </button>
              ) : null}
            </span>
            <label className={`bk-ptab__check${on ? ' is-on' : ''}`}>
              <input type="checkbox" checked={on} disabled={disabled} onChange={() => onToggle(term.id)} />
              <span className="bk-ptab__box" aria-hidden>
                {on ? <Check size={10} weight="bold" /> : null}
              </span>
              <span className="bk-ptab__name">{term.name}</span>
            </label>
          </li>
        );
      })}
    </ul>
  );
}

/* ── Flat: chips + combobox ─────────────────────────────────────────────── */

function TermChips({
  block,
  disabled,
  onToggle,
  onCreate,
}: {
  block: TaxonomyBlock;
  disabled: boolean;
  onToggle: (id: string) => void;
  onCreate: (name: string) => Promise<void>;
}) {
  const [draft, setDraft] = useState('');
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const wrapRef = useRef<HTMLDivElement>(null);
  const selected = new Set(block.selectedTermIds);
  const q = draft.trim().toLowerCase();
  const suggestions = block.terms
    .filter((t) => !selected.has(t.id) && (!q || t.name.toLowerCase().includes(q)))
    .slice(0, 8);
  const exact = block.terms.find((t) => t.name.toLowerCase() === q);
  const canCreate = Boolean(q) && !exact;
  const items = [...suggestions.map((t) => ({ kind: 'term' as const, term: t })), ...(canCreate ? [{ kind: 'create' as const }] : [])];

  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('pointerdown', onDown);
    return () => document.removeEventListener('pointerdown', onDown);
  }, [open]);

  const choose = async (i: number) => {
    const it = items[i];
    if (!it) return;
    if (it.kind === 'term') onToggle(it.term.id);
    else if (exact) onToggle(exact.id);
    else await onCreate(draft.trim());
    setDraft('');
    setActive(0);
  };

  return (
    <div className="bk-ptab__chips-wrap" ref={wrapRef}>
      <div className="bk-ptab__chips">
        {block.terms
          .filter((t) => selected.has(t.id))
          .map((t) => (
            <span key={t.id} className="bk-ptab__chip">
              {t.name}
              <button type="button" aria-label={`Remove ${t.name}`} disabled={disabled} onClick={() => onToggle(t.id)}>
                <X size={10} weight="bold" />
              </button>
            </span>
          ))}
        <input
          className="bk-ptab__chip-input"
          value={draft}
          disabled={disabled}
          placeholder={selected.size ? 'Add another…' : `Add ${block.singular.toLowerCase()}…`}
          onFocus={() => setOpen(true)}
          onChange={(e) => {
            setDraft(e.target.value);
            setOpen(true);
            setActive(0);
          }}
          onKeyDown={(e) => {
            if (e.key === 'ArrowDown') {
              e.preventDefault();
              setActive((a) => Math.min(items.length - 1, a + 1));
            } else if (e.key === 'ArrowUp') {
              e.preventDefault();
              setActive((a) => Math.max(0, a - 1));
            } else if (e.key === 'Enter') {
              e.preventDefault();
              if (items.length) void choose(active);
              else if (exact) onToggle(exact.id);
            } else if (e.key === 'Backspace' && !draft && selected.size) {
              onToggle(block.selectedTermIds[block.selectedTermIds.length - 1]!);
            } else if (e.key === 'Escape') {
              setOpen(false);
            }
          }}
        />
      </div>
      {open && items.length ? (
        <ul className="bk-ptab__menu" role="listbox">
          {items.map((it, i) => (
            <li key={it.kind === 'term' ? it.term.id : '__create'}>
              <button
                type="button"
                role="option"
                aria-selected={i === active}
                className={`${i === active ? 'is-active' : ''}${it.kind === 'create' ? ' is-create' : ''}`}
                onMouseEnter={() => setActive(i)}
                onClick={() => void choose(i)}
              >
                {it.kind === 'term' ? (
                  <>
                    <Tag size={12} /> {it.term.name}
                  </>
                ) : (
                  <>
                    <Plus size={12} weight="bold" /> Create “{draft.trim()}”
                  </>
                )}
              </button>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

/* ── Panel ──────────────────────────────────────────────────────────────── */

export function PageSettingsPanel({ pageId, apiBase }: Props) {
  const href = useAdminHref();
  const auth = useAuth();
  // New categories (hierarchical) need manage_categories; anyone who writes may add tags.
  const canAddCategories = auth.user?.capabilities.includes('manage_categories') ?? false;
  const kind = kindFromApiBase(apiBase);
  const [blocks, setBlocks] = useState<TaxonomyBlock[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const [queries, setQueries] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api<{ taxonomies: TaxonomyBlock[] }>(`${apiBase}/${pageId}/taxonomies`);
      setBlocks(res.taxonomies);
    } catch (e) {
      setError(formatError(e));
      setBlocks([]);
    } finally {
      setLoading(false);
    }
  }, [apiBase, pageId]);

  useEffect(() => {
    void load();
  }, [load]);

  const persist = async (next: TaxonomyBlock[]) => {
    setSaving(true);
    setError(null);
    try {
      const res = await api<{ taxonomies: TaxonomyBlock[] }>(`${apiBase}/${pageId}/taxonomies`, {
        method: 'PUT',
        json: { assignments: next.map((b) => ({ taxonomyId: b.id, termIds: b.selectedTermIds })) },
      });
      setBlocks(res.taxonomies);
      setSavedAt(Date.now());
    } catch (e) {
      setError(formatError(e));
    } finally {
      setSaving(false);
    }
  };

  const toggleTerm = (taxonomyId: string, termId: string) => {
    const next = blocks.map((b) =>
      b.id !== taxonomyId
        ? b
        : {
            ...b,
            selectedTermIds: b.selectedTermIds.includes(termId)
              ? b.selectedTermIds.filter((id) => id !== termId)
              : [...b.selectedTermIds, termId],
          },
    );
    setBlocks(next);
    void persist(next);
  };

  const createTerm = async (taxonomyId: string, name: string) => {
    if (!name.trim() || saving) return;
    setSaving(true);
    setError(null);
    try {
      const term = await api<TermRow>(`/api/fields/taxonomies/${taxonomyId}/terms`, {
        method: 'POST',
        json: { name: name.trim() },
      });
      const next = blocks.map((b) =>
        b.id === taxonomyId
          ? { ...b, terms: [...b.terms, term], selectedTermIds: [...b.selectedTermIds, term.id] }
          : b,
      );
      setBlocks(next);
      await persist(next);
    } catch (e) {
      setError(formatError(e));
      setSaving(false);
    }
  };

  const kindLabel = kind === 'page' ? 'pages' : kind === 'post' ? 'posts' : kind;

  if (loading) {
    return (
      <div className="bk-ptab" aria-busy>
        {[0, 1].map((i) => (
          <div key={i} className="bk-ptab__card is-skeleton">
            <span className="bk-ptab__skel" style={{ width: '40%' }} />
            <span className="bk-ptab__skel" />
            <span className="bk-ptab__skel" style={{ width: '70%' }} />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="bk-ptab">
      <div className="bk-ptab__status" aria-live="polite">
        {error ? (
          <span className="is-error">{error}</span>
        ) : saving ? (
          <span>Saving…</span>
        ) : savedAt ? (
          <span className="is-ok">
            <Check size={11} weight="bold" /> Saved
          </span>
        ) : (
          <span>Changes save automatically</span>
        )}
      </div>
      {kind === 'site-section' ? <SiteSectionPlacement apiBase={apiBase} entryId={pageId} /> : null}

      {blocks.length === 0 && kind === 'site-section' ? null : blocks.length === 0 ? (
        <div className="bk-ptab__empty">
          <Tag size={22} aria-hidden />
          <strong>No taxonomies for {kindLabel} yet</strong>
          <span>Create one — categories, tags, regions, anything — and attach it to {kindLabel}.</span>
          <a
            href={href('fields/taxonomies')}
            target="_blank"
            rel="noopener noreferrer"
            className="bk-ptab__btn"
          >
            Open Taxonomies <ArrowSquareOut size={12} />
          </a>
        </div>
      ) : (
        blocks.map((block) => {
          const selected = new Set(block.selectedTermIds);
          const q = queries[block.id] ?? '';
          const Icon = block.hierarchical ? TreeStructure : Tag;
          return (
            <section key={block.id} className="bk-ptab__card">
              <header className="bk-ptab__head">
                <span className="bk-ptab__icon" aria-hidden>
                  <Icon size={14} />
                </span>
                <h3>{block.plural}</h3>
                {selected.size ? <span className="bk-ptab__count">{selected.size}</span> : null}
                <a
                  href={href('fields/taxonomies')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bk-ptab__manage"
                  title={`Manage ${block.plural.toLowerCase()} in Backend Fields (new tab)`}
                >
                  Manage
                </a>
              </header>

              {block.hierarchical ? (
                <>
                  {block.terms.length > 8 ? (
                    <label className="bk-ptab__search">
                      <MagnifyingGlass size={12} aria-hidden />
                      <input
                        type="search"
                        value={q}
                        placeholder={`Filter ${block.plural.toLowerCase()}…`}
                        onChange={(e) => setQueries((s) => ({ ...s, [block.id]: e.target.value }))}
                      />
                    </label>
                  ) : null}
                  {block.terms.length ? (
                    <TermTree
                      terms={block.terms}
                      selected={selected}
                      disabled={saving}
                      query={q}
                      onToggle={(id) => toggleTerm(block.id, id)}
                    />
                  ) : (
                    <p className="bk-ptab__empty-row">No {block.plural.toLowerCase()} yet.</p>
                  )}
                  {canAddCategories ? (
                    <QuickAdd
                      singular={block.singular}
                      disabled={saving}
                      onCreate={(name) => createTerm(block.id, name)}
                    />
                  ) : null}
                </>
              ) : (
                <TermChips
                  block={block}
                  disabled={saving}
                  onToggle={(id) => toggleTerm(block.id, id)}
                  onCreate={(name) => createTerm(block.id, name)}
                />
              )}
            </section>
          );
        })
      )}

    </div>
  );
}

function QuickAdd({
  singular,
  disabled,
  onCreate,
}: {
  singular: string;
  disabled: boolean;
  onCreate: (name: string) => Promise<void>;
}) {
  const [draft, setDraft] = useState('');
  const submit = async () => {
    const name = draft.trim();
    if (!name) return;
    setDraft('');
    await onCreate(name);
  };
  return (
    <div className="bk-ptab__add">
      <input
        value={draft}
        disabled={disabled}
        placeholder={`New ${singular.toLowerCase()}…`}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            void submit();
          }
        }}
      />
      <button type="button" disabled={disabled || !draft.trim()} onClick={() => void submit()} aria-label={`Add ${singular}`}>
        <Plus size={12} weight="bold" />
      </button>
    </div>
  );
}
