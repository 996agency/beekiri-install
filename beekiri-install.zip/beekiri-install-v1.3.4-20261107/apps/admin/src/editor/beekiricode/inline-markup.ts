import { createElement, type ReactNode } from 'react';

/**
 * Inline colour inside a text element: `[color=#F2842F]these words[/color]`.
 *
 * Text stays plain everywhere (no HTML in the document), so it is safe to store and search;
 * the canvas and the site turn the tags into `<span style="color">`. The same grammar lives
 * in @beekiri/page-blocks (beekiricode-html.ts) for the website.
 */

export type InlineSegment = { text: string; color?: string };

const COLOR = /^(#[0-9a-fA-F]{3,8}|[a-zA-Z]+|rgba?\([\d.,\s%]+\)|hsla?\([\d.,\s%]+\))$/;
const TAG = /\[color=([^\]]{1,40})\]([\s\S]*?)\[\/color\]/g;

export function parseInline(markup: string): InlineSegment[] {
  const out: InlineSegment[] = [];
  let last = 0;
  for (const m of markup.matchAll(TAG)) {
    const at = m.index ?? 0;
    if (at > last) out.push({ text: markup.slice(last, at) });
    if (COLOR.test(m[1].trim())) out.push({ text: m[2], color: m[1].trim() });
    else out.push({ text: m[0] });
    last = at + m[0].length;
  }
  if (last < markup.length) out.push({ text: markup.slice(last) });
  return out.filter((s) => s.text);
}

export function serializeInline(segments: InlineSegment[]): string {
  const merged: InlineSegment[] = [];
  for (const s of segments) {
    if (!s.text) continue;
    const prev = merged[merged.length - 1];
    if (prev && (prev.color ?? '') === (s.color ?? '')) prev.text += s.text;
    else merged.push({ ...s });
  }
  return merged.map((s) => (s.color ? `[color=${s.color}]${s.text}[/color]` : s.text)).join('');
}

/** The words only, no tags. */
export function plainText(markup: string): string {
  return parseInline(markup).map((s) => s.text).join('');
}

/** The colour at a plain-text range, when the whole range has one. */
export function colorAt(markup: string, start: number, end: number): string {
  let at = 0;
  let found: string | null = null;
  for (const s of parseInline(markup)) {
    const from = at;
    at += s.text.length;
    if (at <= start || from >= end) continue;
    const c = s.color ?? '';
    if (found === null) found = c;
    else if (found !== c) return '';
  }
  return found ?? '';
}

/** Colours `[start, end)` of the plain text (null = back to the element's colour). */
export function applyColor(markup: string, start: number, end: number, color: string | null): string {
  const next: InlineSegment[] = [];
  let at = 0;
  for (const s of parseInline(markup)) {
    const from = at;
    const to = at + s.text.length;
    at = to;
    const a = Math.max(from, start);
    const b = Math.min(to, end);
    if (a >= b) {
      next.push(s);
      continue;
    }
    if (a > from) next.push({ text: s.text.slice(0, a - from), color: s.color });
    next.push({ text: s.text.slice(a - from, b - from), ...(color ? { color } : {}) });
    if (b < to) next.push({ text: s.text.slice(b - from), color: s.color });
  }
  return serializeInline(next);
}

/** Canvas display: the text with its coloured words as React nodes. */
export function renderInline(markup: string): ReactNode {
  const segs = parseInline(markup);
  if (segs.every((s) => !s.color)) return markup;
  return segs.map((s, i) => (s.color ? createElement('span', { key: i, style: { color: s.color } }, s.text) : s.text));
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/** For the inline editor: HTML with `<span data-color>` for coloured words and `<br>` for new lines. */
export function inlineToEditorHtml(markup: string): string {
  return parseInline(markup)
    .map((s) => {
      const body = escapeHtml(s.text).replace(/\n/g, '<br>');
      return s.color ? `<span data-color="${escapeHtml(s.color)}" style="color:${escapeHtml(s.color)}">${body}</span>` : body;
    })
    .join('');
}

/** Back from the inline editor's DOM: only text, line breaks and our colour spans survive. */
export function editorDomToMarkup(root: Node): string {
  const segs: InlineSegment[] = [];
  const walk = (node: Node, color: string | undefined) => {
    if (node.nodeType === Node.TEXT_NODE) {
      segs.push({ text: node.textContent ?? '', color });
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    const el = node as HTMLElement;
    if (el.tagName === 'BR') {
      segs.push({ text: '\n', color });
      return;
    }
    const own = el.dataset.color && COLOR.test(el.dataset.color) ? el.dataset.color : color;
    const block = /^(DIV|P)$/.test(el.tagName) && segs.length && !segs[segs.length - 1].text.endsWith('\n');
    if (block) segs.push({ text: '\n', color });
    el.childNodes.forEach((c) => walk(c, own));
  };
  root.childNodes.forEach((c) => walk(c, undefined));
  return serializeInline(segs).replace(/\n+$/, '');
}

/** Plain-text offset of a DOM point inside the inline editor (`<br>` counts as one character). */
export function editorOffset(root: Node, container: Node, offset: number): number {
  let count = 0;
  let found = false;
  const walk = (node: Node): void => {
    if (found) return;
    if (node === container) {
      if (node.nodeType === Node.TEXT_NODE) count += offset;
      else for (let i = 0; i < offset && i < node.childNodes.length; i++) walk(node.childNodes[i]);
      found = true;
      return;
    }
    if (node.nodeType === Node.TEXT_NODE) {
      count += (node.textContent ?? '').length;
      return;
    }
    if ((node as HTMLElement).tagName === 'BR') {
      count += 1;
      return;
    }
    node.childNodes.forEach(walk);
  };
  walk(root);
  return count;
}
