import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { api } from '../../api/client';
import { useAuth } from '../../auth/AuthContext';
import { usePageEditorChrome } from '../PageEditorChrome';

export type PresenceCursor = {
  x: number;
  y: number;
  frame: string;
};

export type PresencePeer = {
  userId: string;
  name: string;
  color: string;
  clientId: string;
  cursor: PresenceCursor | null;
  selectedNodeId: string | null;
};

export type RemoteDocEvent = {
  clientId: string;
  userId: string;
  name: string;
  rev: number;
  doc: unknown;
};

type PresenceContextValue = {
  peers: PresencePeer[];
  remotePeers: PresencePeer[];
  clientId: string;
  reportCursor: (cursor: PresenceCursor | null) => void;
  reportSelection: (nodeId: string | null) => void;
  /** Push local canvas document to other editors (debounced). */
  broadcastDoc: (doc: unknown) => void;
  /** Subscribe to remote document updates (ignore own clientId). */
  subscribeRemoteDoc: (handler: (ev: RemoteDocEvent) => void) => () => void;
};

const PresenceContext = createContext<PresenceContextValue | null>(null);

/**
 * Soft mesh-style orb gradients (cyan / violet / coral …) — one per peer.
 */
const MESH_GRADIENTS = [
  'radial-gradient(circle at 32% 38%, #e8fbff 0%, #7dd3fc 28%, #2563eb 62%, #1e3a8a 100%)',
  'radial-gradient(circle at 35% 40%, #f5e8ff 0%, #e879f9 30%, #7c3aed 65%, #4c1d95 100%)',
  'radial-gradient(circle at 38% 36%, #fff1e8 0%, #fdba74 28%, #f97316 60%, #c2410c 100%)',
  'radial-gradient(circle at 30% 42%, #ecfdf5 0%, #6ee7b7 28%, #0d9488 62%, #115e59 100%)',
  'radial-gradient(circle at 40% 35%, #fff1f2 0%, #fb7185 30%, #e11d48 64%, #9f1239 100%)',
  'radial-gradient(circle at 34% 40%, #eef2ff 0%, #a5b4fc 28%, #6366f1 60%, #312e81 100%)',
  'radial-gradient(circle at 36% 38%, #fffbeb 0%, #fcd34d 28%, #f59e0b 60%, #b45309 100%)',
  'radial-gradient(circle at 33% 41%, #f7fee7 0%, #a3e635 28%, #65a30d 62%, #3f6212 100%)',
] as const;

export function peerMesh(userId: string): string {
  let hash = 0;
  for (let i = 0; i < userId.length; i++) {
    hash = (hash * 31 + userId.charCodeAt(i)) | 0;
  }
  const idx = ((hash % MESH_GRADIENTS.length) + MESH_GRADIENTS.length) % MESH_GRADIENTS.length;
  return MESH_GRADIENTS[idx]!;
}

function clientIdForTab(): string {
  const key = 'bk-beekiricode-presence-client';
  try {
    const existing = sessionStorage.getItem(key);
    if (existing) return existing;
    const id = `c_${Math.random().toString(36).slice(2, 12)}`;
    sessionStorage.setItem(key, id);
    return id;
  } catch {
    return `c_${Math.random().toString(36).slice(2, 12)}`;
  }
}

function peerHue(userId: string): string {
  let hash = 0;
  for (let i = 0; i < userId.length; i++) {
    hash = (hash * 31 + userId.charCodeAt(i)) | 0;
  }
  const hue = ((hash % 360) + 360) % 360;
  return `hsl(${hue} 70% 45%)`;
}

function normalizePeers(list: PresencePeer[] | undefined): PresencePeer[] {
  return (list ?? []).map((p) => ({
    ...p,
    color: p.color || peerHue(p.userId),
    cursor: p.cursor ?? null,
    selectedNodeId: p.selectedNodeId ?? null,
  }));
}

function contentKindFromApiBase(apiBase: string): string {
  if (apiBase.includes('/api/posts')) return 'post';
  const m = apiBase.match(/\/api\/content\/([^/]+)/);
  if (m?.[1]) return m[1];
  return 'page';
}

type ProviderProps = {
  pageId: string;
  children: ReactNode;
};

/** Shared presence room: avatars + remote cursors / selection (WebSocket). */
export function EditorPresenceProvider({ pageId, children }: ProviderProps) {
  const auth = useAuth();
  const chrome = usePageEditorChrome();
  const apiBase = chrome.apiBase;
  const clientId = useMemo(() => clientIdForTab(), []);
  const [peers, setPeers] = useState<PresencePeer[]>([]);
  const leaveSent = useRef(false);
  const cursorRef = useRef<PresenceCursor | null>(null);
  const selectionRef = useRef<string | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const wsReady = useRef(false);
  const pendingFlush = useRef(false);
  const flushTimer = useRef<number | null>(null);
  const docRevRef = useRef(0);
  const pendingDoc = useRef<unknown | null>(null);
  const docFlushTimer = useRef<number | null>(null);
  const remoteDocHandlers = useRef(new Set<(ev: RemoteDocEvent) => void>());

  const applyPeers = useCallback((list: PresencePeer[] | undefined) => {
    setPeers(normalizePeers(list));
  }, []);

  const sendWsCursor = useCallback(() => {
    const ws = wsRef.current;
    if (!ws || ws.readyState !== WebSocket.OPEN) return false;
    ws.send(
      JSON.stringify({
        type: 'cursor',
        cursor: cursorRef.current,
        selectedNodeId: selectionRef.current,
      }),
    );
    return true;
  }, []);

  const flushDoc = useCallback(() => {
    const ws = wsRef.current;
    const doc = pendingDoc.current;
    pendingDoc.current = null;
    if (!ws || ws.readyState !== WebSocket.OPEN || doc == null) return;
    docRevRef.current += 1;
    ws.send(
      JSON.stringify({
        type: 'doc',
        rev: docRevRef.current,
        doc,
      }),
    );
  }, []);

  const broadcastDoc = useCallback(
    (doc: unknown) => {
      pendingDoc.current = doc;
      if (docFlushTimer.current) return;
      docFlushTimer.current = window.setTimeout(() => {
        docFlushTimer.current = null;
        flushDoc();
      }, 48);
    },
    [flushDoc],
  );

  const subscribeRemoteDoc = useCallback((handler: (ev: RemoteDocEvent) => void) => {
    remoteDocHandlers.current.add(handler);
    return () => {
      remoteDocHandlers.current.delete(handler);
    };
  }, []);

  /** HTTP fallback when the socket is down. */
  const flushHttp = useCallback(async () => {
    if (!pageId || !auth.user) return;
    try {
      const res = await api<{ peers: PresencePeer[] }>(`${apiBase}/${pageId}/presence`, {
        method: 'POST',
        json: {
          clientId,
          cursor: cursorRef.current,
          selectedNodeId: selectionRef.current,
        },
      });
      if (!wsReady.current) applyPeers(res.peers);
    } catch {
      /* presence is best-effort */
    }
  }, [pageId, clientId, auth.user, apiBase, applyPeers]);

  const scheduleFlush = useCallback(() => {
    if (pendingFlush.current) return;
    pendingFlush.current = true;
    if (flushTimer.current) window.clearTimeout(flushTimer.current);
    flushTimer.current = window.setTimeout(() => {
      flushTimer.current = null;
      pendingFlush.current = false;
      if (!sendWsCursor()) void flushHttp();
    }, 32);
  }, [sendWsCursor, flushHttp]);

  const reportCursor = useCallback(
    (cursor: PresenceCursor | null) => {
      cursorRef.current = cursor;
      scheduleFlush();
    },
    [scheduleFlush],
  );

  const reportSelection = useCallback(
    (nodeId: string | null) => {
      selectionRef.current = nodeId;
      scheduleFlush();
    },
    [scheduleFlush],
  );

  useEffect(() => {
    if (!pageId || !auth.user) return;
    leaveSent.current = false;
    wsReady.current = false;
    let cancelled = false;
    let retryTimer: number | null = null;
    let pingTimer: number | null = null;
    let attempt = 0;

    const leaveHttp = () => {
      if (leaveSent.current) return;
      leaveSent.current = true;
      void api(
        `${apiBase}/${pageId}/presence?clientId=${encodeURIComponent(clientId)}`,
        { method: 'DELETE' },
      ).catch(() => undefined);
    };

    const connect = () => {
      if (cancelled) return;
      const kind = encodeURIComponent(contentKindFromApiBase(apiBase));
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const url =
        `${proto}//${window.location.host}/api/presence/ws` +
        `?pageId=${encodeURIComponent(pageId)}` +
        `&clientId=${encodeURIComponent(clientId)}` +
        `&kind=${kind}`;
      const ws = new WebSocket(url);
      wsRef.current = ws;

      ws.onopen = () => {
        if (cancelled) {
          ws.close();
          return;
        }
        attempt = 0;
        wsReady.current = true;
        sendWsCursor();
        if (pendingDoc.current != null) flushDoc();
        if (pingTimer) window.clearInterval(pingTimer);
        pingTimer = window.setInterval(() => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'ping' }));
          }
        }, 20_000);
      };

      ws.onmessage = (ev) => {
        try {
          const msg = JSON.parse(String(ev.data)) as {
            type?: string;
            peers?: PresencePeer[];
            clientId?: string;
            userId?: string;
            name?: string;
            rev?: number;
            doc?: unknown;
          };
          if (msg.type === 'peers') {
            applyPeers(msg.peers);
            return;
          }
          if (msg.type === 'doc' && msg.doc != null && msg.clientId) {
            if (msg.clientId === clientId) return;
            const event: RemoteDocEvent = {
              clientId: msg.clientId,
              userId: msg.userId || '',
              name: msg.name || 'Editor',
              rev: typeof msg.rev === 'number' ? msg.rev : 0,
              doc: msg.doc,
            };
            for (const handler of remoteDocHandlers.current) {
              try {
                handler(event);
              } catch {
                /* ignore */
              }
            }
          }
        } catch {
          /* ignore */
        }
      };

      ws.onclose = () => {
        wsReady.current = false;
        if (wsRef.current === ws) wsRef.current = null;
        if (pingTimer) {
          window.clearInterval(pingTimer);
          pingTimer = null;
        }
        if (cancelled) return;
        attempt += 1;
        const delay = Math.min(4000, 250 * 2 ** Math.min(attempt, 4));
        retryTimer = window.setTimeout(connect, delay);
        void flushHttp();
      };

      ws.onerror = () => {
        ws.close();
      };
    };

    connect();
    window.addEventListener('pagehide', leaveHttp);
    return () => {
      cancelled = true;
      window.removeEventListener('pagehide', leaveHttp);
      if (retryTimer) window.clearTimeout(retryTimer);
      if (pingTimer) window.clearInterval(pingTimer);
      if (flushTimer.current) window.clearTimeout(flushTimer.current);
      if (docFlushTimer.current) window.clearTimeout(docFlushTimer.current);
      const ws = wsRef.current;
      wsRef.current = null;
      wsReady.current = false;
      if (ws && ws.readyState <= WebSocket.OPEN) ws.close();
      leaveHttp();
    };
  }, [pageId, clientId, auth.user, apiBase, applyPeers, sendWsCursor, flushHttp, flushDoc]);

  const me = auth.user;
  const remotePeers = useMemo(
    () => peers.filter((p) => p.userId !== me?.id),
    [peers, me?.id],
  );

  const value = useMemo<PresenceContextValue>(
    () => ({
      peers,
      remotePeers,
      clientId,
      reportCursor,
      reportSelection,
      broadcastDoc,
      subscribeRemoteDoc,
    }),
    [
      peers,
      remotePeers,
      clientId,
      reportCursor,
      reportSelection,
      broadcastDoc,
      subscribeRemoteDoc,
    ],
  );

  return (
    <PresenceContext.Provider value={value}>{children}</PresenceContext.Provider>
  );
}

export function useEditorPresence(): PresenceContextValue {
  const ctx = useContext(PresenceContext);
  if (!ctx) {
    throw new Error('useEditorPresence must be used within EditorPresenceProvider');
  }
  return ctx;
}

/** Toolbar “who’s editing” stack — soft gradient orbs per user. */
export function PeerAvatarStack() {
  const auth = useAuth();
  const { peers, clientId } = useEditorPresence();
  const me = auth.user;

  const stack = useMemo(() => {
    const list: PresencePeer[] = peers.map((p) => ({ ...p }));
    if (me) {
      const self: PresencePeer = {
        userId: me.id,
        name: me.displayName?.trim() || me.username,
        color: peerHue(me.id),
        clientId,
        cursor: null,
        selectedNodeId: null,
      };
      if (!list.some((p) => p.userId === me.id)) list.unshift(self);
      else {
        const idx = list.findIndex((p) => p.userId === me.id);
        if (idx > 0) {
          const [mine] = list.splice(idx, 1);
          if (mine) list.unshift(mine);
        }
      }
    }
    return list.slice(0, 5);
  }, [peers, me, clientId]);

  if (stack.length === 0) return null;

  const groupLabel =
    stack.length === 1
      ? `${stack[0]!.name} (you) — editing this page`
      : `${stack.length} editing — ${stack.map((p) => p.name).join(', ')}`;

  return (
    <div
      className="bk-beekiricode__peer-stack"
      role="group"
      aria-label={groupLabel}
    >
      {stack.map((peer, index) => {
        const isMe = me?.id === peer.userId;
        const name = isMe ? `${peer.name} (you)` : peer.name;
        return (
          <button
            key={peer.userId}
            type="button"
            className={`bk-beekiricode__peer-avatar${isMe ? ' is-me' : ''}`}
            style={{ zIndex: index + 1 }}
            aria-label={`${name} — editing this page`}
            data-username={name}
          >
            <span
              className="bk-beekiricode__peer-face"
              aria-hidden
              style={{ ['--peer-mesh' as string]: peerMesh(peer.userId) }}
            />
            <span className="bk-beekiricode__peer-tip" role="tooltip">
              {name}
            </span>
          </button>
        );
      })}
    </div>
  );
}

type SmoothCursor = {
  userId: string;
  name: string;
  color: string;
  x: number;
  y: number;
  tx: number;
  ty: number;
};

/** Per-frame follow strength (~catches up in ~50–80ms at 60fps). */
const CURSOR_FOLLOW = 0.42;

/** Labeled pointers — exponential follow toward live WS targets (smooth, low lag). */
export function RemoteCursors({ frame }: { frame: string }) {
  const { remotePeers } = useEditorPresence();
  const cursorsRef = useRef(new Map<string, SmoothCursor>());
  const elsRef = useRef(new Map<string, HTMLDivElement>());
  const rafRef = useRef<number | null>(null);
  const [, bump] = useState(0);

  useEffect(() => {
    const map = cursorsRef.current;
    const seen = new Set<string>();
    let structural = false;

    for (const peer of remotePeers) {
      const c = peer.cursor;
      if (!c || c.frame !== frame) continue;
      seen.add(peer.userId);
      const color = peer.color || peerHue(peer.userId);
      const prev = map.get(peer.userId);
      if (!prev) {
        map.set(peer.userId, {
          userId: peer.userId,
          name: peer.name,
          color,
          x: c.x,
          y: c.y,
          tx: c.x,
          ty: c.y,
        });
        structural = true;
      } else {
        prev.name = peer.name;
        prev.color = color;
        prev.tx = c.x;
        prev.ty = c.y;
      }
    }

    for (const id of [...map.keys()]) {
      if (!seen.has(id)) {
        map.delete(id);
        elsRef.current.delete(id);
        structural = true;
      }
    }

    if (structural) bump((n) => n + 1);
  }, [remotePeers, frame]);

  useEffect(() => {
    const tick = () => {
      for (const cur of cursorsRef.current.values()) {
        cur.x += (cur.tx - cur.x) * CURSOR_FOLLOW;
        cur.y += (cur.ty - cur.y) * CURSOR_FOLLOW;
        if (Math.abs(cur.tx - cur.x) < 0.15) cur.x = cur.tx;
        if (Math.abs(cur.ty - cur.y) < 0.15) cur.y = cur.ty;
        const el = elsRef.current.get(cur.userId);
        if (el) {
          el.style.transform = `translate(${cur.x}px, ${cur.y}px)`;
          el.style.setProperty('--peer-cursor', cur.color);
        }
      }
      rafRef.current = window.requestAnimationFrame(tick);
    };
    rafRef.current = window.requestAnimationFrame(tick);
    return () => {
      if (rafRef.current != null) window.cancelAnimationFrame(rafRef.current);
    };
  }, []);

  const list = [...cursorsRef.current.values()];
  if (list.length === 0) return null;

  return (
    <div className="bk-beekiricode__remote-cursors" aria-hidden>
      {list.map((peer) => (
        <div
          key={peer.userId}
          ref={(el) => {
            if (el) elsRef.current.set(peer.userId, el);
            else elsRef.current.delete(peer.userId);
          }}
          className="bk-beekiricode__remote-cursor"
          style={{
            transform: `translate(${peer.x}px, ${peer.y}px)`,
            ['--peer-cursor' as string]: peer.color,
          }}
        >
          <svg
            className="bk-beekiricode__remote-cursor-ptr"
            width="18"
            height="22"
            viewBox="0 0 18 22"
            fill="none"
          >
            <path
              d="M1.5 1.5L1.5 17.5L6.2 13.4L9.8 20.5L12.6 19.2L9 12.1L15.5 11.8L1.5 1.5Z"
              fill="var(--peer-cursor)"
              stroke="#fff"
              strokeWidth="1.25"
              strokeLinejoin="round"
            />
          </svg>
          <span className="bk-beekiricode__remote-cursor-label">{peer.name}</span>
        </div>
      ))}
    </div>
  );
}
