/** @deprecated Import from `./EditorPresence` — kept for existing import paths. */
export {
  EditorPresenceProvider,
  PeerAvatarStack,
  RemoteCursors,
  peerMesh,
  useEditorPresence,
  type PresenceCursor,
  type PresencePeer,
} from './EditorPresence';
