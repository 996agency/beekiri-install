import type { StyleBag } from './styleHelpers';
import { patchStyle } from './styleHelpers';

/** Canvas / publish breakpoint keys. `base` = desktop default (applies to all). */
export type StyleBreakpoint = 'base' | 'tablet' | 'mobile';

export type BreakpointStyleBags = {
  tablet?: StyleBag;
  mobile?: StyleBag;
};

export type NodeStyleSource = {
  style?: StyleBag;
  stylesByBreakpoint?: BreakpointStyleBags;
};

/** Which bag properties write into for the current canvas viewport. */
export function editTargetForViewMode(
  viewMode: 'multi' | 'desktop' | 'tablet' | 'mobile',
): StyleBreakpoint {
  if (viewMode === 'tablet') return 'tablet';
  if (viewMode === 'mobile') return 'mobile';
  // desktop + all breakpoints → shared default
  return 'base';
}

export function getOverrideBag(
  node: NodeStyleSource | null | undefined,
  bp: StyleBreakpoint,
): StyleBag {
  if (!node) return {};
  if (bp === 'base') return { ...(node.style ?? {}) };
  return { ...(node.stylesByBreakpoint?.[bp] ?? {}) };
}

/** Effective styles for a rendered frame (base ← tablet ← mobile cascade). */
/**
 * `vw` on the site means the visitor's screen; on the canvas the frame plays that screen.
 * Each frame canvas is a size container, so `vw` becomes `cqw` (1% of the frame width) and
 * tablet / mobile frames size text and boxes like the real device.
 */
export function frameUnits(value: string): string {
  return value.includes('vw') ? value.replace(/(\d*\.?\d+)vw\b/g, '$1cqw') : value;
}

export function frameStyle(bag: StyleBag): StyleBag {
  const out: StyleBag = {};
  for (const [k, v] of Object.entries(bag)) out[k] = typeof v === 'string' ? frameUnits(v) : v;
  return out;
}

export function resolveStyleForBreakpoint(
  node: NodeStyleSource | null | undefined,
  frame: 'desktop' | 'tablet' | 'mobile',
): StyleBag {
  if (!node) return {};
  const base = node.style ?? {};
  if (frame === 'desktop') return { ...base };
  if (frame === 'tablet') {
    return { ...base, ...(node.stylesByBreakpoint?.tablet ?? {}) };
  }
  return {
    ...base,
    ...(node.stylesByBreakpoint?.tablet ?? {}),
    ...(node.stylesByBreakpoint?.mobile ?? {}),
  };
}

/**
 * Apply a style patch for the active edit target.
 * - base → writes `style`
 * - tablet/mobile → writes only that override bag (empty keys removed)
 */
export function applyBreakpointStylePatch(
  node: NodeStyleSource,
  target: StyleBreakpoint,
  patch: Record<string, string | undefined>,
): Pick<NodeStyleSource, 'style' | 'stylesByBreakpoint'> {
  if (target === 'base') {
    return {
      style: patchStyle(node.style, patch),
      stylesByBreakpoint: node.stylesByBreakpoint,
    };
  }

  const nextBag = patchStyle(node.stylesByBreakpoint?.[target], patch);
  const nextBreakpoints: BreakpointStyleBags = {
    ...(node.stylesByBreakpoint ?? {}),
  };
  if (Object.keys(nextBag).length === 0) {
    delete nextBreakpoints[target];
  } else {
    nextBreakpoints[target] = nextBag;
  }
  const cleaned =
    nextBreakpoints.tablet || nextBreakpoints.mobile ? nextBreakpoints : undefined;

  return {
    style: node.style,
    stylesByBreakpoint: cleaned,
  };
}

/** Replace entire override/base bag. */
export function replaceBreakpointStyleBag(
  node: NodeStyleSource,
  target: StyleBreakpoint,
  next: StyleBag,
): Pick<NodeStyleSource, 'style' | 'stylesByBreakpoint'> {
  if (target === 'base') {
    return {
      style: { ...next },
      stylesByBreakpoint: node.stylesByBreakpoint,
    };
  }

  const nextBreakpoints: BreakpointStyleBags = {
    ...(node.stylesByBreakpoint ?? {}),
  };
  if (Object.keys(next).length === 0) {
    delete nextBreakpoints[target];
  } else {
    nextBreakpoints[target] = { ...next };
  }
  const cleaned =
    nextBreakpoints.tablet || nextBreakpoints.mobile ? nextBreakpoints : undefined;

  return {
    style: node.style,
    stylesByBreakpoint: cleaned,
  };
}

export function countOverrideKeys(
  node: NodeStyleSource | null | undefined,
  target: StyleBreakpoint,
  keys: string[],
): number {
  const bag = getOverrideBag(node, target);
  return keys.filter((k) => Boolean(bag[k])).length;
}

export function labelForEditTarget(target: StyleBreakpoint): string {
  if (target === 'tablet') return 'Tablet only';
  if (target === 'mobile') return 'Mobile only';
  return 'All breakpoints (default)';
}
