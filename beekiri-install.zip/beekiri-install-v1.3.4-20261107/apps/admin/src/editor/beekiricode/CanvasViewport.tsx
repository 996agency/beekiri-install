import {
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
  forwardRef,
  type PointerEvent as ReactPointerEvent,
  type ReactNode,
} from 'react';

export const ZOOM_MIN = 0.1;
export const ZOOM_MAX = 4;
/** Breathing room around the fitted frames (screen px). */
const FIT_PAD = 48;
const FIT_PAD_TOP = 56;

export type ViewportApi = {
  /** Scale so the design fits the stage width (max 100%) and center it. `animate` glides there. */
  fit: (animate?: boolean) => void;
  /** Zoom to an exact scale around the stage center. */
  zoomTo: (scale: number) => void;
  /** Multiply the current zoom around the stage center. */
  zoomBy: (factor: number) => void;
};

type View = { x: number; y: number; z: number };

type Props = {
  /** Unscaled width of the frames block (one frame, or all frames plus gaps). */
  designWidth: number;
  /** Re-fit whenever this changes (view mode, canvas mode). */
  fitKey: string;
  /** Upper limit for fit (e.g. 0.95 in preview); narrower stages fit the width instead. */
  fitScale?: number;
  /** Called (rAF-throttled) whenever the scale changes — drives the toolbar + selection chrome. */
  onScaleChange: (scale: number) => void;
  className?: string;
  children: ReactNode;
};

const clampZoom = (z: number) => Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, z));

/**
 * Infinite, pannable, zoomable stage (Figma-style). The children render at their
 * natural size inside a "world" layer that is moved with a single transform, so
 * panning never re-renders the page tree.
 *
 * - Trackpad scroll / wheel: pan. ⌘ or Ctrl + wheel (pinch): zoom around the pointer.
 * - Drag on empty space, Space + drag anywhere, or middle mouse: pan.
 * - ⌘0 / Shift+1: fit · Shift+0: 100% · ⌘+ / ⌘−: zoom.
 */
export const CanvasViewport = forwardRef<ViewportApi, Props>(function CanvasViewport(
  { designWidth, fitKey, fitScale, onScaleChange, className, children },
  ref,
) {
  const stageRef = useRef<HTMLDivElement>(null);
  const worldRef = useRef<HTMLDivElement>(null);
  const view = useRef<View>({ x: 0, y: 0, z: 0.55 });
  const raf = useRef(0);
  const [panning, setPanning] = useState(false);
  const [spaceHeld, setSpaceHeld] = useState(false);
  const spaceRef = useRef(false);

  const apply = useCallback(
    (animate = false) => {
      const el = worldRef.current;
      if (!el) return;
      const { x, y, z } = view.current;
      // Programmatic moves (fit / preview) glide; direct manipulation stays instant.
      el.style.transition = animate ? 'transform 0.38s cubic-bezier(0.2, 0.8, 0.2, 1)' : 'none';
      el.style.transform = `translate3d(${x}px, ${y}px, 0) scale(${z})`;
      if (!raf.current) {
        raf.current = requestAnimationFrame(() => {
          raf.current = 0;
          onScaleChange(view.current.z);
        });
      }
    },
    [onScaleChange],
  );

  /** Zoom to `z` keeping the stage point (px, py) fixed under the pointer. */
  const zoomAt = useCallback(
    (z: number, px: number, py: number) => {
      const v = view.current;
      const nz = clampZoom(z);
      const k = nz / v.z;
      view.current = { x: px - (px - v.x) * k, y: py - (py - v.y) * k, z: nz };
      apply();
    },
    [apply],
  );

  const center = () => {
    const r = stageRef.current?.getBoundingClientRect();
    return r ? { x: r.width / 2, y: r.height / 2 } : { x: 0, y: 0 };
  };

  const fit = useCallback(
    (animate = false) => {
      const stage = stageRef.current;
      const world = worldRef.current;
      if (!stage || !world) return;
      const w = stage.clientWidth;
      const h = stage.clientHeight;
      if (w < 10 || h < 10) return;
      // Fit the design to the stage width; `fitScale` (preview) only caps it, so small screens still see it whole.
      const fitWidth = (w - FIT_PAD * 2) / Math.max(1, designWidth);
      const z = clampZoom(Math.min(fitScale ?? 1, fitWidth));
      // World height is its unscaled layout height (frames grow with content).
      const worldH = world.offsetHeight || 900;
      const x = (w - designWidth * z) / 2;
      const scaledH = worldH * z;
      const y = scaledH + FIT_PAD_TOP + FIT_PAD < h ? (h - scaledH) / 2 : FIT_PAD_TOP;
      view.current = { x, y, z };
      apply(animate);
    },
    [designWidth, fitScale, apply],
  );

  useImperativeHandle(
    ref,
    () => ({
      fit,
      zoomTo: (z) => {
        const c = center();
        zoomAt(z, c.x, c.y);
      },
      zoomBy: (f) => {
        const c = center();
        zoomAt(view.current.z * f, c.x, c.y);
      },
    }),
    [fit, zoomAt],
  );

  // Fit on mount, when the view mode changes, and when the stage is resized.
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    // Two frames: let the frames lay out first so their height is known.
    const id = requestAnimationFrame(() => requestAnimationFrame(() => fit(true)));
    const ro = new ResizeObserver(() => fit());
    ro.observe(stage);
    return () => {
      cancelAnimationFrame(id);
      ro.disconnect();
    };
  }, [fit, fitKey]);

  // Wheel: pan, or zoom with ⌘/Ctrl (trackpad pinch arrives as ctrl+wheel).
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const r = stage.getBoundingClientRect();
      if (e.ctrlKey || e.metaKey) {
        // Pixel deltas (trackpad) are small; line deltas (mouse) are ±100ish.
        const delta = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY;
        const factor = Math.exp(-delta * 0.0025);
        zoomAt(view.current.z * factor, e.clientX - r.left, e.clientY - r.top);
        return;
      }
      const dx = e.shiftKey && e.deltaX === 0 ? e.deltaY : e.deltaX;
      const dy = e.shiftKey && e.deltaX === 0 ? 0 : e.deltaY;
      const v = view.current;
      view.current = { ...v, x: v.x - dx, y: v.y - dy };
      apply();
    };
    stage.addEventListener('wheel', onWheel, { passive: false });
    return () => stage.removeEventListener('wheel', onWheel);
  }, [apply, zoomAt]);

  // Space = temporary hand tool; ⌘0 fit, Shift+1 fit, Shift+0 100%, ⌘± zoom.
  useEffect(() => {
    const typing = (t: EventTarget | null) => {
      const el = t as HTMLElement | null;
      return Boolean(
        el &&
        (el.tagName === 'INPUT' ||
          el.tagName === 'TEXTAREA' ||
          el.tagName === 'SELECT' ||
          el.isContentEditable),
      );
    };
    const onDown = (e: KeyboardEvent) => {
      if (typing(e.target)) return;
      if (e.code === 'Space' && !e.repeat) {
        e.preventDefault();
        spaceRef.current = true;
        setSpaceHeld(true);
        return;
      }
      const mod = e.metaKey || e.ctrlKey;
      const c = center();
      if (mod && (e.key === '0' || e.code === 'Digit0')) {
        e.preventDefault();
        fit();
      } else if (mod && (e.key === '=' || e.key === '+')) {
        e.preventDefault();
        zoomAt(view.current.z * 1.2, c.x, c.y);
      } else if (mod && e.key === '-') {
        e.preventDefault();
        zoomAt(view.current.z / 1.2, c.x, c.y);
      } else if (!mod && e.shiftKey && e.code === 'Digit1') {
        e.preventDefault();
        fit();
      } else if (!mod && e.shiftKey && e.code === 'Digit0') {
        e.preventDefault();
        zoomAt(1, c.x, c.y);
      }
    };
    const onUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        spaceRef.current = false;
        setSpaceHeld(false);
      }
    };
    const onBlur = () => {
      spaceRef.current = false;
      setSpaceHeld(false);
    };
    window.addEventListener('keydown', onDown);
    window.addEventListener('keyup', onUp);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onDown);
      window.removeEventListener('keyup', onUp);
      window.removeEventListener('blur', onBlur);
    };
  }, [fit, zoomAt]);

  const onPointerDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    const onFrame = (e.target as HTMLElement).closest('.bk-beekiricode__frame');
    const middle = e.button === 1;
    const hand = e.button === 0 && (spaceRef.current || !onFrame);
    if (!middle && !hand) return;
    e.preventDefault();
    const stage = e.currentTarget;
    stage.setPointerCapture(e.pointerId);
    const start = { x: e.clientX, y: e.clientY, vx: view.current.x, vy: view.current.y };
    let moved = false;
    const move = (ev: PointerEvent) => {
      const dx = ev.clientX - start.x;
      const dy = ev.clientY - start.y;
      if (!moved && Math.hypot(dx, dy) < 2) return;
      if (!moved) {
        moved = true;
        setPanning(true);
      }
      view.current = { ...view.current, x: start.vx + dx, y: start.vy + dy };
      apply();
    };
    const up = () => {
      stage.removeEventListener('pointermove', move);
      stage.removeEventListener('pointerup', up);
      stage.removeEventListener('pointercancel', up);
      setPanning(false);
    };
    stage.addEventListener('pointermove', move);
    stage.addEventListener('pointerup', up);
    stage.addEventListener('pointercancel', up);
  };

  return (
    <div
      ref={stageRef}
      className={`bk-beekiricode__stage-view${panning ? ' is-panning' : spaceHeld ? ' is-hand' : ''}${
        className ? ` ${className}` : ''
      }`}
      onPointerDown={onPointerDown}
      // Space + click must not reach the frames (it would select / edit).
      onClickCapture={(e) => {
        if (spaceRef.current || panning) {
          e.stopPropagation();
          e.preventDefault();
        }
      }}
    >
      <div ref={worldRef} className="bk-beekiricode__world">
        {children}
      </div>
    </div>
  );
});
