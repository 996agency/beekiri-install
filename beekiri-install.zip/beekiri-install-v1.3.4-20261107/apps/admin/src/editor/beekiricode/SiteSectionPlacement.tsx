import { useCallback, useEffect, useState } from 'react';
import { MapPin } from '@phosphor-icons/react';
import { api } from '../../api/client';

type Placement = { position: 'top' | 'bottom'; pages: 'all' | string[] };
type PageRow = { id: string; title: string; status: string; path: string };

/**
 * Site sections: where this section shows — top or bottom of each page, on every page or the pages
 * picked. Saves on every change; published = on, draft = off (the editor's Publish button).
 */
export function SiteSectionPlacement({ apiBase, entryId }: { apiBase: string; entryId: string }) {
  const [placement, setPlacement] = useState<Placement | null>(null);
  const [pages, setPages] = useState<PageRow[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [entry, list] = await Promise.all([
        api<{ placement?: Placement | null } & Record<string, unknown>>(`${apiBase}/${entryId}`),
        api<{ pages: PageRow[] }>('/api/pages'),
      ]);
      const item = ((entry as { item?: { placement?: Placement | null } }).item ?? entry) as { placement?: Placement | null };
      setPlacement(item.placement ?? { position: 'bottom', pages: 'all' });
      setPages(list.pages.filter((p) => p.status === 'publish' || p.status === 'draft'));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load where this section shows.');
    }
  }, [apiBase, entryId]);

  useEffect(() => {
    void load();
  }, [load]);

  const save = async (next: Placement) => {
    setPlacement(next);
    setSaving(true);
    setError(null);
    try {
      await api(`${apiBase}/${entryId}`, { method: 'PATCH', json: { placement: next } });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save.');
    } finally {
      setSaving(false);
    }
  };

  if (!placement) {
    return error ? <p className="bk-ptab__empty is-error">{error}</p> : null;
  }
  const chosen = placement.pages === 'all' ? [] : placement.pages;
  const toggle = (id: string) => {
    const next = chosen.includes(id) ? chosen.filter((p) => p !== id) : [...chosen, id];
    void save({ ...placement, pages: next.length ? next : 'all' });
  };

  return (
    <section className="bk-ptab__card bk-ssp">
      <header className="bk-ptab__head">
        <span className="bk-ptab__icon" aria-hidden>
          <MapPin size={14} />
        </span>
        <h3>Where it shows</h3>
        {saving ? <span className="bk-ptab__count">Saving…</span> : null}
      </header>
      {error ? <p className="bk-ptab__empty is-error">{error}</p> : null}
      <div className="bk-ssp__row" role="radiogroup" aria-label="Position on the page">
        {(['top', 'bottom'] as const).map((pos) => (
          <label key={pos} className="bk-ssp__choice">
            <input type="radio" name="bk-ssp-position" checked={placement.position === pos} onChange={() => void save({ ...placement, position: pos })} />
            {pos === 'top' ? 'Top of the page' : 'Bottom of the page'}
          </label>
        ))}
      </div>
      <div className="bk-ssp__row" role="radiogroup" aria-label="Which pages">
        <label className="bk-ssp__choice">
          <input type="radio" name="bk-ssp-pages" checked={placement.pages === 'all'} onChange={() => void save({ ...placement, pages: 'all' })} />
          Every page
        </label>
        <label className="bk-ssp__choice">
          <input
            type="radio"
            name="bk-ssp-pages"
            checked={placement.pages !== 'all'}
            onChange={() => {
              if (placement.pages === 'all' && pages[0]) void save({ ...placement, pages: [pages[0].id] });
            }}
          />
          Only these pages
        </label>
      </div>
      {placement.pages !== 'all' ? (
        <ul className="bk-ssp__pages">
          {pages.map((p) => (
            <li key={p.id}>
              <label className="bk-ssp__choice">
                <input type="checkbox" checked={chosen.includes(p.id)} onChange={() => toggle(p.id)} />
                {p.title || 'Untitled'} <small>{p.path}</small>
              </label>
            </li>
          ))}
        </ul>
      ) : null}
      <p className="bk-ssp__hint">Publish turns it on across the site; switch to draft to turn it off. Popups and sticky bars place themselves.</p>
    </section>
  );
}
