import { useEffect, useState } from 'react';
// The website's base stylesheet (fonts, line height, links, buttons…), shipped with this release.
import siteBaseCss from '../../../../web/src/app/globals.css?raw';
import { toFrameCss } from './frameCss';

const siteBase = toFrameCss(siteBaseCss, undefined, { scope: true });

/** The website's own base styles, limited to the frames — every page on the site has them. */
export function FrameSiteBase() {
  return <style data-frame-css="site-base">{siteBase}</style>;
}

/** One fetch per stylesheet URL (it carries ?v=, so a changed layout is a new URL). */
const cache = new Map<string, Promise<string>>();

function frameCss(url: string, scope: boolean): Promise<string> {
  const key = `${scope ? 'scoped:' : ''}${url}`;
  let pending = cache.get(key);
  if (!pending) {
    pending = fetch(url, { credentials: 'include' })
      .then((res) => (res.ok ? res.text() : ''))
      .then((css) => toFrameCss(css, url, { scope }))
      .catch(() => '');
    cache.set(key, pending);
  }
  return pending;
}

/**
 * Theme stylesheets for the canvas, made to respond to each frame (see frameCss.ts), so desktop,
 * tablet and mobile frames look exactly like the site on those devices. `scoped` sheets are
 * site-wide ones (the header/footer CSS carries the theme's buttons, fonts and colours): their
 * rules are limited to the frames so they never restyle the admin around them.
 */
export function FrameLayoutStyles({ urls, scoped = false }: { urls: string[]; scoped?: boolean }) {
  const [sheets, setSheets] = useState<Record<string, string>>({});
  const key = urls.join('\n');

  useEffect(() => {
    let live = true;
    for (const url of urls) {
      void frameCss(url, scoped).then((css) => {
        if (live) setSheets((prev) => (prev[url] === css ? prev : { ...prev, [url]: css }));
      });
    }
    return () => {
      live = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- `key` stands for `urls`
  }, [key, scoped]);

  return (
    <>
      {urls.map((url) => (sheets[url] ? <style key={url} data-frame-css={url}>{sheets[url]}</style> : null))}
    </>
  );
}
