import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { gsap } from 'gsap';
import type { BeekiriAgentActivity } from '../../lib/admin-events';

/**
 * Beekiri's cursor on the canvas, like a collaborator's: while it works it drifts over the
 * element it is reading, and when a change arrives it glides to each changed part in turn —
 * text writes itself in, photos fade in, boxes pulse. Screen-space (fixed) so canvas zoom never
 * shrinks it; positions are read from the desktop frame each time it moves.
 */

type Visit = { id: string; kind: 'text' | 'media' | 'box' };

let controller: { visit: (visits: Visit[]) => Promise<void> } | null = null;

/** Play the visits for a change Beekiri just made; resolves when every part is revealed. */
export function playBeekiriVisits(visits: Visit[]): Promise<void> {
  return controller ? controller.visit(visits) : Promise.resolve();
}

export type { Visit as BeekiriVisit };

const TEXT_TYPES = new Set(['heading', 'text', 'button', 'list']);
const MEDIA_TYPES = new Set(['image', 'video', 'divider', 'spacer']);

/** Which parts of a section changed (document order), and how each should appear. */
export function changedParts(
  before: { nodes: Record<string, { type: string; children?: string[] }> } | null,
  after: { rootId: string; nodes: Record<string, { type: string; children?: string[] }> },
): Visit[] {
  const own = (n: { children?: string[] } | undefined) => (n ? JSON.stringify({ ...n, children: undefined }) : '');
  const out: Visit[] = [];
  const walk = (id: string) => {
    const node = after.nodes[id];
    if (!node) return;
    if (!before?.nodes[id] || own(before.nodes[id]) !== own(node)) {
      out.push({ id, kind: TEXT_TYPES.has(node.type) ? 'text' : MEDIA_TYPES.has(node.type) ? 'media' : 'box' });
    }
    for (const child of node.children ?? []) walk(child);
  };
  walk(after.rootId);
  return out;
}

function findEl(id: string): HTMLElement | null {
  const sel = `[data-node-id="${CSS.escape(id)}"]`;
  return (
    document.querySelector<HTMLElement>(`.bk-beekiricode__frame[data-bp="desktop"] ${sel}`) ??
    document.querySelector<HTMLElement>(`.bk-beekiricode__frame-canvas ${sel}`)
  );
}

/** Where the cursor may go: the canvas stage, minus the docked chat. */
function stageBounds() {
  const stage = document.querySelector<HTMLElement>('.bk-beekiricode__stage-view')?.getBoundingClientRect();
  const chat = document.querySelector<HTMLElement>('.bk-bee-chat__panel')?.getBoundingClientRect();
  const left = (stage?.left ?? 0) + 12;
  const top = (stage?.top ?? 0) + 12;
  let right = (stage?.right ?? window.innerWidth) - 140;
  if (chat && chat.left < right + 140) right = chat.left - 150;
  const bottom = (stage?.bottom ?? window.innerHeight) - 40;
  return { left, top, right: Math.max(left, right), bottom: Math.max(top, bottom) };
}

const clamp = (v: number, min: number, max: number) => Math.min(Math.max(v, min), max);

/** A point just inside an element's top-left, kept on screen. */
function pointFor(el: HTMLElement, wander = false) {
  const r = el.getBoundingClientRect();
  const b = stageBounds();
  const x = wander ? r.left + r.width * (0.15 + Math.random() * 0.6) : r.left + Math.min(28, r.width / 3);
  const y = wander ? r.top + Math.min(r.height, 600) * (0.2 + Math.random() * 0.5) : r.top + Math.min(r.height / 2, 30);
  return { x: clamp(x, b.left, b.right), y: clamp(y, b.top, b.bottom) };
}

const calm = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export function BeekiriCursor({ activity }: { activity: BeekiriAgentActivity | null }) {
  const rootRef = useRef<HTMLDivElement>(null);
  const [visiting, setVisiting] = useState(false);
  const shown = Boolean(activity?.running) || visiting;
  const workingId = activity?.nodeId ?? null;
  const step = activity?.step ?? '';

  // Glide helper: smooth, interruptible moves in screen space.
  const moveTo = (x: number, y: number, duration: number, ease = 'power3.inOut') =>
    gsap.to(rootRef.current, { x, y, duration, ease, overwrite: 'auto' });

  // Appear / disappear.
  useEffect(() => {
    const el = rootRef.current;
    if (!el) return;
    if (shown) {
      const start = workingId ? findEl(workingId) : null;
      if (start && !gsap.getProperty(el, 'opacity')) {
        const p = pointFor(start);
        gsap.set(el, { x: p.x + 60, y: p.y + 40 });
      }
      gsap.to(el, { autoAlpha: 1, scale: 1, duration: 0.35, ease: 'back.out(2)' });
    } else {
      gsap.to(el, { autoAlpha: 0, scale: 0.8, duration: 0.3, ease: 'power2.in' });
    }
  }, [shown, workingId]);

  // While Beekiri thinks: drift over the element it is working on, like someone reading it.
  useEffect(() => {
    if (!activity?.running || visiting || !workingId || calm()) return;
    let alive = true;
    let timer = 0;
    const drift = () => {
      if (!alive) return;
      const target = findEl(workingId);
      if (target) {
        const p = pointFor(target, true);
        moveTo(p.x, p.y, 1.6 + Math.random() * 0.8, 'sine.inOut');
      }
      timer = window.setTimeout(drift, 2200 + Math.random() * 900);
    };
    drift();
    return () => {
      alive = false;
      window.clearTimeout(timer);
    };
  }, [activity?.running, visiting, workingId]);

  // The choreography for a change: visit each changed part, then reveal it.
  useEffect(() => {
    controller = {
      visit: (visits) => {
        const els = visits.map((v) => ({ ...v, el: findEl(v.id) })).filter((v): v is Visit & { el: HTMLElement } => Boolean(v.el));
        if (!els.length) return Promise.resolve();
        // Hide the new text and photos first, so the cursor can bring them in.
        const hidden = els.filter((v) => v.kind !== 'box');
        const shownEls = hidden.map((v) => v.el);
        if (calm()) {
          gsap.fromTo(els.map((v) => v.el), { opacity: 0.4 }, { opacity: 1, duration: 0.3, clearProps: 'opacity' });
          return Promise.resolve();
        }
        hidden.forEach((v) =>
          gsap.set(v.el, v.kind === 'text' ? { clipPath: 'inset(0 100% 0 0)' } : { autoAlpha: 0, scale: 0.98 }),
        );
        setVisiting(true);
        const tour = els.slice(0, 10);
        const rest = els.slice(10);
        return new Promise<void>((resolve) => {
          const cursor = rootRef.current;
          const tl = gsap.timeline({
            onComplete: () => {
              gsap.set(shownEls, { clearProps: 'clipPath,opacity,visibility,transform' });
              setVisiting(false);
              resolve();
            },
            onInterrupt: () => {
              gsap.set(shownEls, { clearProps: 'clipPath,opacity,visibility,transform' });
              setVisiting(false);
              resolve();
            },
          });
          tour.forEach((v, i) => {
            tl.add(() => {
              const p = pointFor(v.el);
              moveTo(p.x, p.y, i === 0 ? 0.6 : 0.5);
            });
            tl.to({}, { duration: i === 0 ? 0.6 : 0.5 });
            // A tiny "click", then the part appears.
            if (cursor) tl.to(cursor, { scale: 0.86, duration: 0.08, yoyo: true, repeat: 1, ease: 'power1.inOut' });
            if (v.kind === 'text') {
              tl.to(v.el, { clipPath: 'inset(0 0% 0 0)', duration: 0.55, ease: 'power2.out' });
            } else if (v.kind === 'media') {
              tl.to(v.el, { autoAlpha: 1, scale: 1, duration: 0.5, ease: 'power3.out' });
            } else {
              tl.fromTo(
                v.el,
                { boxShadow: '0 0 0 0 rgba(242, 132, 47, 0)' },
                { boxShadow: '0 0 0 6px rgba(242, 132, 47, 0.35)', duration: 0.25, yoyo: true, repeat: 1, ease: 'sine.inOut', clearProps: 'boxShadow' },
              );
            }
            tl.to({}, { duration: 0.12 });
          });
          if (rest.length) {
            tl.to(rest.map((v) => v.el), {
              clipPath: 'inset(0 0% 0 0)',
              autoAlpha: 1,
              scale: 1,
              duration: 0.45,
              stagger: 0.04,
              ease: 'power2.out',
            });
          }
        });
      },
    };
    return () => {
      controller = null;
    };
  }, []);

  if (typeof document === 'undefined') return null;

  return createPortal(
    <div ref={rootRef} className="bk-beekiri-cursor" aria-hidden style={{ opacity: 0, visibility: 'hidden' }}>
      <svg className="bk-beekiri-cursor__ptr" width="22" height="24" viewBox="0 0 22 24">
        <defs>
          <linearGradient id="bk-beekiri-ptr" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#f6a15f" />
            <stop offset="100%" stopColor="#e8732a" />
          </linearGradient>
        </defs>
        <path
          d="M2.5 1.8 19.6 12.1c.9.6.6 1.9-.4 2.1l-6.6 1.3-3.5 5.9c-.5.9-1.9.7-2.1-.3L2.5 1.8Z"
          fill="url(#bk-beekiri-ptr)"
          stroke="#fff"
          strokeWidth="1.6"
          strokeLinejoin="round"
        />
      </svg>
      <span className="bk-beekiri-cursor__tag">
        <img src="/admin/connector/claude.svg" alt="" width={13} height={13} draggable={false} />
        <strong>Beekiri</strong>
        {step ? <em>{step.length > 34 ? `${step.slice(0, 33)}…` : step}</em> : null}
      </span>
    </div>,
    // In the editor's layer, between the canvas and the docked chat.
    document.querySelector('.bk-page-editor') ?? document.body,
  );
}
