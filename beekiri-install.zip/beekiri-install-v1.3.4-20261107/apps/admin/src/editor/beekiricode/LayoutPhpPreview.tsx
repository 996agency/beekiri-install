import { useEffect, useMemo, useState, type CSSProperties, type HTMLAttributes, type MouseEvent } from 'react';
import { api } from '../../api/client';
import { hasLayoutScaffoldStyle } from './document';
import { sanitizePreviewHtml } from '../../lib/safe-html';

type Props = {
  slug: string;
  fields: Record<string, unknown>;
  selected?: boolean;
  hovered?: boolean;
  interactive?: boolean;
  onSelect: (e: MouseEvent) => void;
  onHover: (e: MouseEvent) => void;
  onLeave: () => void;
  /** Properties-panel overrides — applied onto the PHP <section>, not a padded wrapper. */
  style?: CSSProperties;
  /** Host-only styles (e.g. peer selection accent). */
  hostStyle?: CSSProperties;
  /** Extra host class (e.g. hidden-on-breakpoint ghost). */
  className?: string;
  /** Node id, exposed as data-node-id for the selection chrome. */
  nodeId?: string;
  /** Drag-and-drop handlers from the canvas (palette drops). */
  hostProps?: HTMLAttributes<HTMLDivElement>;
};

/**
 * A popup's <dialog> stays closed until its script opens it on the live site — and the editor runs no
 * layout scripts — so here every dialog is shown open, the way visitors see it.
 */
function openDialogs(html: string): string {
  return html.replace(/<dialog\b(?![^>]*\sopen[\s=>])/gi, '<dialog open data-bk-editor-open');
}

/** Old editor chrome that must not inflate layout boxes vs the live site. */
const CHROME_STYLE_KEYS = new Set([
  'display',
  'flexDirection',
  'flexWrap',
  'alignItems',
  'justifyContent',
  'gap',
  'rowGap',
  'columnGap',
  'padding',
  'paddingTop',
  'paddingRight',
  'paddingBottom',
  'paddingLeft',
  'border',
  'borderWidth',
  'borderStyle',
  'borderColor',
  'borderRadius',
  'minHeight',
]);

function camelToKebab(s: string) {
  return s.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`);
}

/** Keep real overrides; drop chrome only from legacy scaffold bags. */
function layoutOverrideDecls(style: CSSProperties | undefined): string {
  if (!style) return '';
  const scaffold = hasLayoutScaffoldStyle(style as Record<string, string>);
  const decls: Record<string, string> = {};
  for (const [k, v] of Object.entries(style)) {
    if (v == null || v === '') continue;
    if (scaffold && CHROME_STYLE_KEYS.has(k)) continue;
    // Drop old dashed-placeholder gray fill
    if (
      (k === 'background' || k === 'backgroundColor') &&
      String(v).replace(/\s/g, '').toLowerCase() === '#fafafa'
    ) {
      continue;
    }
    decls[k] = String(v);
  }
  // Theme layouts often paint with `background:` gradients. A Props
  // backgroundColor alone sits under those layers — clear images so the color shows.
  if (decls.backgroundColor && !decls.background && !decls.backgroundImage) {
    decls.backgroundImage = 'none';
  }
  return Object.entries(decls)
    .map(([k, v]) => `${camelToKebab(k)}:${v}`)
    .join(';');
}

/** Put Properties styles on the PHP root <section>, matching public output. */
function injectSectionStyle(html: string, decls: string): string {
  if (!decls.trim()) return html;
  return html.replace(/<section\b([^>]*)>/i, (_full, attrs: string) => {
    if (/\sstyle\s*=/.test(attrs)) {
      return `<section${attrs.replace(
        /style\s*=\s*(["'])([\s\S]*?)\1/i,
        (_m, q, existing) => `style=${q}${existing};${decls}${q}`,
      )}>`;
    }
    return `<section${attrs} style="${decls}">`;
  });
}

/** Renders themes/.../layouts/{slug} via the API (PHP or React — same as the public site). */
export function LayoutPhpPreview({
  slug,
  fields,
  selected,
  hovered,
  interactive,
  onSelect,
  onHover,
  onLeave,
  style,
  hostStyle,
  className,
  nodeId,
  hostProps,
}: Props) {
  const [html, setHtml] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const fieldsKey = JSON.stringify(fields);
  const overrideDecls = useMemo(() => layoutOverrideDecls(style), [style]);

  useEffect(() => {
    let cancelled = false;
    setError(null);
    api<{ html: string }>(`/api/layouts/${encodeURIComponent(slug)}/render`, {
      method: 'POST',
      json: { fields: JSON.parse(fieldsKey) as Record<string, unknown> },
    })
      .then((res) => {
        if (!cancelled) setHtml(res.html || '');
      })
      .catch((e) => {
        if (!cancelled) {
          setHtml('');
          setError(e instanceof Error ? e.message : 'Failed to render layout PHP');
        }
      });
    return () => {
      cancelled = true;
    };
  }, [slug, fieldsKey]);

  // Popups (a <dialog> a script opens on the live site) show opened here, centred over a backdrop.
  const overlay = Boolean(html && /<dialog\b/i.test(html));
  const hostCls = [
    'bk-beekiricode__layout-host',
    'bk-beekiricode__node',
    overlay ? 'has-overlay' : '',
    selected ? 'is-selected' : '',
    hovered ? 'is-hovered' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  const handlers = interactive
    ? {
        onClick: onSelect,
        onMouseEnter: onHover,
        onMouseLeave: onLeave,
      }
    : {};

  const host = {
    className: hostCls,
    style: hostStyle,
    'data-layout': slug,
    'data-node-id': nodeId,
    'data-node-type': 'layout',
    ...hostProps,
    ...handlers,
  };

  if (error) {
    return (
      <div {...host}>
        <p className="bk-beekiricode__layout-hint">{error}</p>
      </div>
    );
  }

  if (!html) {
    return (
      <div {...host}>
        <p className="bk-beekiricode__layout-hint">Loading {slug}…</p>
      </div>
    );
  }

  return (
    <div
      {...host}
      dangerouslySetInnerHTML={{ __html: injectSectionStyle(openDialogs(sanitizePreviewHtml(html)), overrideDecls) }}
    />
  );
}
