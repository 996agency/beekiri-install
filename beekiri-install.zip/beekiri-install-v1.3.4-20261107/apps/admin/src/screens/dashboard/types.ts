export type DashboardRange = 'today' | '7d' | '30d' | 'all';

export type WidgetId =
  | 'storage'
  | 'clock'
  | 'pages'
  | 'posts'
  | 'media'
  | 'status'
  | 'activity'
  | 'publish'
  | 'fields'
  | 'users'
  | 'shop';

export type DashboardOverview = {
  title: string;
  range: DashboardRange;
  coreVersion: string | null;
  atAGlance: { users: number; posts: number; pages: number; fieldGroups: number };
  storage: {
    totalBytes: number;
    totalLabel: string;
    dialect: 'postgres' | 'sqlite';
    imageBytes: number;
    videoBytes: number;
    documentBytes: number;
    databaseBytes: number;
    mediaBytes: number;
  };
  pages: {
    published: number;
    drafts: number;
    scheduled: number;
    publishedThisWeek: number;
  };
  posts: {
    total: number;
    published: number;
    drafts: number;
    scheduled: number;
    publishedThisWeek: number;
    categories: number;
  };
  media: {
    files: number;
    bytes: number;
    bytesLabel: string;
    previews: { id: string; url: string; mimeType: string }[];
  };
  status: {
    site: 'live' | string;
    lastPublishAt: string | null;
    lastUpdateAt: string | null;
    coreVersion: string | null;
    fieldGroups: number;
  };
  activity: { id: string; action: string; at: string; actor: string }[];
  publishLineup: {
    id: string;
    title: string;
    slug: string;
    type?: 'page' | 'post';
    updatedAt: string;
  }[];
  users: number;
  fieldGroups: number;
};

/** Allowed column spans on the 12-col Overview grid (narrow → wide). */
export type WidgetSpan = 2 | 3 | 4 | 6 | 8 | 12;

export const SPAN_STEPS: WidgetSpan[] = [2, 3, 4, 6, 8, 12];

export type LayoutItem = {
  id: WidgetId;
  /** Column span on a 12-col grid */
  span: WidgetSpan;
};

export const WIDGET_META: Record<
  WidgetId,
  { title: string; tint: string; defaultSpan: WidgetSpan; description: string }
> = {
  storage: {
    title: 'Storage',
    tint: '#006199',
    defaultSpan: 12,
    description: 'Disk use by media type and database',
  },
  clock: {
    title: 'Date & time',
    tint: '#ff9508',
    defaultSpan: 4,
    description: 'Live local clock with day progress',
  },
  pages: {
    title: 'Pages',
    tint: '#f5a623',
    defaultSpan: 3,
    description: 'Published and draft pages',
  },
  posts: {
    title: 'Posts',
    tint: '#7c6af0',
    defaultSpan: 3,
    description: 'Published and draft posts',
  },
  media: {
    title: 'Media',
    tint: '#e8a07a',
    defaultSpan: 3,
    description: 'Library files and previews',
  },
  status: {
    title: 'Status',
    tint: '#b7d894',
    defaultSpan: 3,
    description: 'Site health and core version',
  },
  activity: {
    title: 'Activity',
    tint: '#e8a07a',
    defaultSpan: 6,
    description: 'Recent audit events',
  },
  publish: {
    title: 'Publish lineup',
    tint: '#006199',
    defaultSpan: 6,
    description: 'Drafts waiting to go live',
  },
  fields: {
    title: 'Fields',
    tint: '#ff6b9d',
    defaultSpan: 3,
    description: 'Backend field groups',
  },
  users: {
    title: 'Users',
    tint: '#b7d894',
    defaultSpan: 3,
    description: 'Team members with access',
  },
  shop: {
    title: 'Shop',
    tint: '#7f54b3',
    defaultSpan: 6,
    description: 'Sales this week and recent orders (Shopping extension)',
  },
};

/** Default Overview for every user until they customize their own layout. */
export const DEFAULT_LAYOUT: LayoutItem[] = [
  { id: 'storage', span: 8 },
  { id: 'clock', span: 4 },
  { id: 'pages', span: 3 },
  { id: 'posts', span: 3 },
  { id: 'media', span: 3 },
  { id: 'status', span: 3 },
  { id: 'activity', span: 6 },
  { id: 'publish', span: 3 },
  { id: 'users', span: 3 },
];

export const STORAGE_KEY = 'beekiri-dashboard-layout-v1';

export function storageKeyForUser(userId: string): string {
  return `${STORAGE_KEY}:${userId}`;
}
