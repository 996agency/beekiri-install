import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../../api/client';
import { useAuth } from '../../auth/AuthContext';
import { canAccessShop } from '../../lib/admin-capabilities';
import { SHOPPING_EXTENSION, useExtensionActive } from '../../lib/extensions-state';
import { ORDER_STATUS_TONE, type ShopOverview } from '../shop/api';
import '../shop/shop.css';

/** Overview widget: this week's sales + the latest orders (Shopping extension). */
export function ShopWidget({ href }: { href: (sub?: string) => string }) {
  const auth = useAuth();
  const active = useExtensionActive(SHOPPING_EXTENSION);
  const allowed = canAccessShop(auth.user?.capabilities);
  const [data, setData] = useState<ShopOverview | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!active || !allowed) return;
    let cancelled = false;
    api<ShopOverview>('/api/shop/overview?range=7d')
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch(() => {
        if (!cancelled) setFailed(true);
      });
    return () => {
      cancelled = true;
    };
  }, [active, allowed]);

  if (!active) {
    return (
      <p className="bk-dash__meta">
        Shopping is not active. <Link to={href('extensions')} className="button-link">Open Extensions</Link>
      </p>
    );
  }
  if (!allowed) return <p className="bk-dash__meta">You do not have access to the shop.</p>;
  if (failed) return <p className="bk-dash__meta">Could not load shop figures.</p>;
  if (!data) return <p className="bk-dash__meta">Loading…</p>;

  return (
    <>
      <p className="bk-dash__stat">{data.totals.revenueFormatted}</p>
      <p className="bk-dash__sub">
        Revenue · last 7 days · {data.totals.orders} {data.totals.orders === 1 ? 'order' : 'orders'}
      </p>
      {data.recentOrders.length ? (
        <ul className="bk-dash__status-list">
          {data.recentOrders.slice(0, 4).map((o) => (
            <li key={o.id}>
              <Link to={href(`shop/orders/${o.id}`)} className="button-link">
                {o.numberLabel}
              </Link>{' '}
              <span className={`bk-shop-pill is-${ORDER_STATUS_TONE[o.status] ?? 'neutral'}`}>{o.statusLabel}</span>{' '}
              <span className="bk-muted">
                {o.customerName} · {o.totalFormatted}
              </span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="bk-dash__meta">No orders yet.</p>
      )}
      <p className="bk-dash__meta">
        <Link to={href('shop')} className="button-link">
          Open the shop overview
        </Link>
      </p>
    </>
  );
}
