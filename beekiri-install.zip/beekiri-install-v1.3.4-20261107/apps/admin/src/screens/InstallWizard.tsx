import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../styles/wp/install.css';
import { api, ApiError } from '../api/client';
import { BrandMark } from '../components/BrandMark';
import { generatePassword, passwordStrength } from '../util/password';

type Status = {
  installed: boolean;
  /** False until the database step below has saved the connection settings. */
  databaseConfigured?: boolean;
  databaseOk: boolean;
  databaseMessage: string;
  canInstall: boolean;
  frontendRuntimes?: FrontendOption[];
  /** "Set it up for me": Beekiri downloads and runs its own PostgreSQL (only under npm start). */
  builtinDatabase?: { available: boolean; state: 'idle' | 'working' | 'ready' | 'failed'; message?: string };
};

type FrontendRuntime = 'php' | 'react';

type FrontendOption = {
  id: string;
  label: string;
  available: boolean;
};

const FRONTEND_DETAILS: Record<string, { tagline: string; detail: string }> = {
  php: {
    tagline: 'Recommended',
    detail:
      'Theme templates are PHP files (header, footer, layouts) that use the Bee field API.',
  },
  react: {
    tagline: 'Components',
    detail: 'Theme templates are React .tsx components rendered by the Next.js frontend.',
  },
  vue: {
    tagline: 'Coming soon',
    detail: 'Vue single-file component themes are on the roadmap.',
  },
};

const DEFAULT_FRONTENDS: FrontendOption[] = [
  { id: 'php', label: 'PHP', available: true },
  { id: 'react', label: 'React', available: true },
  { id: 'vue', label: 'Vue', available: false },
];

type Step = 'language' | 'welcome' | 'frontend' | 'setup' | 'success';

const SETUP_KEY_STORAGE = 'bk-setup-key';

/**
 * The one-time setup key from the link Beekiri prints in its terminal. It is kept for this
 * tab only (the database step restarts the server) and removed from the address bar.
 */
function initialSetupKey(): string {
  try {
    const url = new URL(window.location.href);
    const fromUrl = url.searchParams.get('setup')?.trim();
    if (fromUrl) {
      sessionStorage.setItem(SETUP_KEY_STORAGE, fromUrl);
      url.searchParams.delete('setup');
      window.history.replaceState(window.history.state, '', url.pathname + url.search + url.hash);
      return fromUrl;
    }
    return sessionStorage.getItem(SETUP_KEY_STORAGE) ?? '';
  } catch {
    return '';
  }
}

function isSetupKeyError(e: unknown): boolean {
  return (
    e instanceof ApiError &&
    e.status === 403 &&
    (e.body as { code?: string } | null)?.code === 'setup_key_required'
  );
}

const STEP_ORDER: Step[] = ['language', 'welcome', 'frontend', 'setup', 'success'];

export function InstallWizard() {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>('language');
  const [status, setStatus] = useState<Status | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const [language, setLanguage] = useState('en_US');
  const [siteTitle, setSiteTitle] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [email, setEmail] = useState('');
  const [blogPublic, setBlogPublic] = useState(true);
  const [frontendRuntime, setFrontendRuntime] = useState<FrontendRuntime>('php');
  const [db, setDb] = useState({ host: '', port: '', name: 'beekiri', user: '', password: '' });
  const [dbSaving, setDbSaving] = useState(false);
  const [dbMode, setDbMode] = useState<'builtin' | 'own'>('builtin');
  const [dbProgress, setDbProgress] = useState<string | null>(null);
  const [setupKey, setSetupKey] = useState(initialSetupKey);
  const [keyRejected, setKeyRejected] = useState(false);
  const needKey = !setupKey.trim() || keyRejected;
  const keyHeaders = { 'X-Setup-Token': setupKey.trim() };
  const rememberKey = (value: string) => {
    setSetupKey(value);
    setKeyRejected(false);
    try {
      sessionStorage.setItem(SETUP_KEY_STORAGE, value.trim());
    } catch {
      /* private mode: the key stays in memory */
    }
  };
  const frontends = status?.frontendRuntimes?.length ? status.frontendRuntimes : DEFAULT_FRONTENDS;
  const frontendLabel = frontends.find((f) => f.id === frontendRuntime)?.label ?? 'PHP';

  const refreshStatus = async () => {
    const s = await api<Status>('/api/install/status');
    setStatus(s);
    if (s.installed) navigate('/admin/login', { replace: true });
  };

  useEffect(() => {
    refreshStatus().catch((e) =>
      setError(
        e instanceof ApiError
          ? e.message
          : e instanceof Error
            ? e.message
            : 'This site is temporarily unavailable. Please try again in a moment — your content is safe.',
      ),
    );
  }, []);

  /** Save the database details; the server restarts, so wait until it answers connected. */
  const saveDatabase = async () => {
    setDbSaving(true);
    setError(null);
    try {
      await api('/api/install/database', {
        headers: keyHeaders,
        json: {
          host: db.host.trim() || undefined,
          port: db.port.trim() ? Number(db.port) : undefined,
          name: db.name.trim(),
          user: db.user.trim(),
          password: db.password,
        },
      });
      for (let attempt = 0; attempt < 40; attempt++) {
        await new Promise((r) => setTimeout(r, 1500));
        try {
          const s = await api<Status>('/api/install/status');
          if (s.databaseConfigured && s.databaseOk) {
            setStatus(s);
            return;
          }
        } catch {
          // The server is restarting.
        }
      }
      setError('Beekiri did not come back after saving. Check the terminal where it runs.');
    } catch (e) {
      if (isSetupKeyError(e)) setKeyRejected(true);
      setError(e instanceof ApiError ? e.message : 'Could not save the database settings.');
    } finally {
      setDbSaving(false);
    }
  };

  /** "Set it up for me": PostgreSQL downloads once (about 100 MB), then Beekiri restarts with it. */
  const setUpBuiltinDatabase = async () => {
    setDbSaving(true);
    setError(null);
    setDbProgress('Preparing your database…');
    try {
      await api('/api/install/database/builtin', { method: 'POST', headers: keyHeaders });
      for (let attempt = 0; attempt < 600; attempt++) {
        await new Promise((r) => setTimeout(r, 1500));
        try {
          const s = await api<Status>('/api/install/status');
          if (s.databaseConfigured && s.databaseOk) {
            setStatus(s);
            return;
          }
          const b = s.builtinDatabase;
          if (b?.state === 'failed') {
            setError(b.message ?? 'Could not set up the database.');
            return;
          }
          if (b?.message) setDbProgress(b.message);
        } catch {
          setDbProgress('Restarting Beekiri with your new database…');
        }
      }
      setError('Setting up the database is taking too long. Check the terminal where Beekiri runs.');
    } catch (e) {
      if (isSetupKeyError(e)) setKeyRejected(true);
      setError(e instanceof ApiError ? e.message : 'Could not set up the database.');
    } finally {
      setDbSaving(false);
      setDbProgress(null);
    }
  };

  const builtinAvailable = Boolean(status?.builtinDatabase?.available);
  const databaseMode = builtinAvailable ? dbMode : 'own';

  const strength = passwordStrength(password);
  const stepIndex = STEP_ORDER.indexOf(step);

  const runInstall = async () => {
    setBusy(true);
    setError(null);
    try {
      await api('/api/install', {
        headers: keyHeaders,
        json: { language, siteTitle, username, password, email, blogPublic, frontendRuntime },
      });
      try {
        sessionStorage.removeItem(SETUP_KEY_STORAGE);
      } catch {
        /* ignore */
      }
      setStep('success');
    } catch (e) {
      if (isSetupKeyError(e)) {
        setKeyRejected(true);
        setStep('welcome');
      }
      setError(e instanceof ApiError ? e.message : 'Installation failed');
    } finally {
      setBusy(false);
    }
  };

  const titles: Record<Step, { title: string; subtitle: string }> = {
    language: {
      title: 'Choose a language',
      subtitle: 'Pick the default language for this site’s admin workspace.',
    },
    welcome: {
      title: 'Set up this site',
      subtitle:
        'Every new Beekiri site starts here — on your machine or a client server. Publish pages, manage media, and launch in about a minute.',
    },
    frontend: {
      title: 'Choose your frontend',
      subtitle:
        'How should this site’s theme be built? The CMS stays the same either way — this only decides the language of your theme templates.',
    },
    setup: {
      title: 'Create your site',
      subtitle:
        'Name the site and create the owner account for this client. No default password is ever shipped.',
    },
    success: {
      title: 'Site ready',
      subtitle: `This Beekiri site is installed with the ${frontendLabel} frontend. Sign in with the owner username to open the dashboard.`,
    },
  };

  return (
    <div className="bk-install">
      <div className="bk-install__shell">
        <header className="bk-install__brand">
          <a
            href="/"
            className="bk-install__mark"
            title="Beekiri"
            onClick={(e) => e.preventDefault()}
          >
            <BrandMark variant="logo" size={44} />
          </a>
        </header>

        <main className="bk-install__card">
          <ul className="bk-install__steps" aria-hidden="true">
            {STEP_ORDER.map((s, i) => (
              <li
                key={s}
                className={i < stepIndex ? 'is-done' : i === stepIndex ? 'is-active' : undefined}
              />
            ))}
          </ul>

          <h1 className="bk-install__title">{titles[step].title}</h1>
          <p className="bk-install__subtitle">{titles[step].subtitle}</p>

          {error && (
            <div className="bk-install__alert" role="alert">
              {error}
            </div>
          )}

          {step === 'language' && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setStep('welcome');
              }}
            >
              <div className="bk-install__field">
                <label htmlFor="language">Language</label>
                <select
                  id="language"
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                >
                  <option value="en_US">English (United States)</option>
                  <option value="en_GB">English (UK)</option>
                  <option value="de_DE">Deutsch</option>
                  <option value="fr_FR">Français</option>
                  <option value="es_ES">Español</option>
                </select>
              </div>
              <div className="bk-install__actions">
                <button type="submit" className="bk-install__btn bk-install__btn--primary">
                  Continue
                </button>
              </div>
            </form>
          )}

          {step === 'welcome' && (
            <div>
              {needKey && (
                <div className="bk-install__field">
                  <label htmlFor="setup_key">Setup key</label>
                  <input
                    id="setup_key"
                    autoComplete="off"
                    spellCheck={false}
                    value={setupKey}
                    onChange={(e) => rememberKey(e.target.value)}
                  />
                  <p className="bk-install__note">
                    Only the person running this server can set it up. Use the link Beekiri
                    printed in its terminal, or copy the key from apps/api/.setup-token on the
                    server.
                  </p>
                </div>
              )}
              <div
                className={`bk-install__status ${
                  status?.databaseOk ? 'is-ok' : status ? 'is-bad' : ''
                }`}
              >
                <span className="bk-install__status-dot" />
                <span>
                  <strong style={{ color: '#1d1d1f', fontWeight: 600 }}>Database</strong>
                  <br />
                  {status?.databaseMessage ?? 'Checking connection…'}
                </span>
              </div>

              {status?.databaseConfigured === false && builtinAvailable && (
                <div className="bk-install__choices" role="radiogroup" aria-label="Database">
                  {(
                    [
                      {
                        id: 'builtin',
                        label: 'Set it up for me',
                        tag: 'Recommended',
                        detail:
                          'No database? No problem. Beekiri installs its own PostgreSQL inside this site’s folder and starts it with the site. Nothing else to install.',
                      },
                      {
                        id: 'own',
                        label: 'Use my own PostgreSQL',
                        tag: 'Advanced',
                        detail: 'Connect to a PostgreSQL server you already have, on this computer or hosted.',
                      },
                    ] as const
                  ).map((option) => (
                    <label
                      key={option.id}
                      className={`bk-install__choice${databaseMode === option.id ? ' is-selected' : ''}${
                        dbSaving ? ' is-disabled' : ''
                      }`}
                    >
                      <input
                        type="radio"
                        name="databaseMode"
                        value={option.id}
                        checked={databaseMode === option.id}
                        disabled={dbSaving}
                        onChange={() => setDbMode(option.id)}
                      />
                      <span className="bk-install__choice-body">
                        <span className="bk-install__choice-head">
                          <strong>{option.label}</strong>
                          <span className="bk-install__choice-tag">{option.tag}</span>
                        </span>
                        <span className="bk-install__choice-detail">{option.detail}</span>
                      </span>
                    </label>
                  ))}
                </div>
              )}

              {status?.databaseConfigured === false && databaseMode === 'builtin' && (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    void setUpBuiltinDatabase();
                  }}
                >
                  <p className="bk-install__note" aria-live="polite">
                    {dbProgress ??
                      'The first time, PostgreSQL is downloaded for this computer (about 100 MB). This takes a minute or two.'}
                  </p>
                  <div className="bk-install__actions">
                    <button
                      type="submit"
                      className="bk-install__btn bk-install__btn--primary"
                      disabled={dbSaving || !setupKey.trim()}
                    >
                      {dbSaving ? 'Setting up…' : 'Set up my database'}
                    </button>
                  </div>
                </form>
              )}

              {status?.databaseConfigured === false && databaseMode === 'own' && (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    void saveDatabase();
                  }}
                >
                  <p className="bk-install__subtitle">
                    Beekiri stores your site in PostgreSQL. Enter the database details; if the
                    database does not exist yet, Beekiri creates it.
                  </p>
                  <div className="bk-install__field">
                    <label htmlFor="db_name">Database name</label>
                    <input
                      id="db_name"
                      required
                      pattern="[A-Za-z_][A-Za-z0-9_]*"
                      value={db.name}
                      onChange={(e) => setDb({ ...db, name: e.target.value })}
                    />
                  </div>
                  <div className="bk-install__field">
                    <label htmlFor="db_user">Username</label>
                    <input
                      id="db_user"
                      required
                      autoComplete="off"
                      value={db.user}
                      onChange={(e) => setDb({ ...db, user: e.target.value })}
                    />
                  </div>
                  <div className="bk-install__field">
                    <label htmlFor="db_password">Password</label>
                    <input
                      id="db_password"
                      type="password"
                      autoComplete="off"
                      value={db.password}
                      onChange={(e) => setDb({ ...db, password: e.target.value })}
                    />
                  </div>
                  <div className="bk-install__field">
                    <label htmlFor="db_host">Host (leave empty for this computer)</label>
                    <input
                      id="db_host"
                      placeholder="e.g. db.example.com"
                      value={db.host}
                      onChange={(e) => setDb({ ...db, host: e.target.value })}
                    />
                  </div>
                  <div className="bk-install__field">
                    <label htmlFor="db_port">Port (leave empty for the PostgreSQL default)</label>
                    <input
                      id="db_port"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      value={db.port}
                      onChange={(e) => setDb({ ...db, port: e.target.value })}
                    />
                  </div>
                  <div className="bk-install__actions">
                    <button
                      type="submit"
                      className="bk-install__btn bk-install__btn--primary"
                      disabled={dbSaving || !setupKey.trim()}
                    >
                      {dbSaving ? 'Connecting…' : 'Connect database'}
                    </button>
                  </div>
                </form>
              )}

              {status?.databaseConfigured !== false && !status?.databaseOk && status && (
                <div className="bk-install__alert" role="alert">
                  Beekiri cannot reach its database. Check that PostgreSQL is running, then retry.
                </div>
              )}

              <div className="bk-install__actions bk-install__actions--spread">
                <button
                  type="button"
                  className="bk-install__btn bk-install__btn--ghost"
                  onClick={() => setStep('language')}
                >
                  Back
                </button>
                <div style={{ display: 'flex', gap: 10 }}>
                  {status?.databaseConfigured !== false && !status?.databaseOk && (
                    <button
                      type="button"
                      className="bk-install__btn bk-install__btn--secondary"
                      onClick={() => void refreshStatus()}
                    >
                      Retry
                    </button>
                  )}
                  <button
                    type="button"
                    className="bk-install__btn bk-install__btn--primary"
                    disabled={!status?.canInstall || !setupKey.trim()}
                    onClick={() => setStep('frontend')}
                  >
                    Continue
                  </button>
                </div>
              </div>
            </div>
          )}

          {step === 'frontend' && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setStep('setup');
              }}
            >
              <div className="bk-install__choices" role="radiogroup" aria-label="Frontend">
                {frontends.map((option) => {
                  const details = FRONTEND_DETAILS[option.id];
                  const selected = option.available && option.id === frontendRuntime;
                  return (
                    <label
                      key={option.id}
                      className={`bk-install__choice${selected ? ' is-selected' : ''}${
                        option.available ? '' : ' is-disabled'
                      }`}
                    >
                      <input
                        type="radio"
                        name="frontendRuntime"
                        value={option.id}
                        checked={selected}
                        disabled={!option.available}
                        onChange={() => setFrontendRuntime(option.id as FrontendRuntime)}
                      />
                      <span className="bk-install__choice-body">
                        <span className="bk-install__choice-head">
                          <strong>{option.label}</strong>
                          {details ? (
                            <span className="bk-install__choice-tag">
                              {option.available ? details.tagline : 'Coming soon'}
                            </span>
                          ) : null}
                        </span>
                        {details ? (
                          <span className="bk-install__choice-detail">{details.detail}</span>
                        ) : null}
                      </span>
                    </label>
                  );
                })}
              </div>

              <p className="bk-install__note">
                This choice is permanent for this site. To use a different frontend later, install a
                new site into an empty database.
              </p>

              <div className="bk-install__actions bk-install__actions--spread">
                <button
                  type="button"
                  className="bk-install__btn bk-install__btn--ghost"
                  onClick={() => setStep('welcome')}
                >
                  Back
                </button>
                <button type="submit" className="bk-install__btn bk-install__btn--primary">
                  Continue with {frontendLabel}
                </button>
              </div>
            </form>
          )}

          {step === 'setup' && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                void runInstall();
              }}
            >
              <div className="bk-install__field">
                <label htmlFor="weblog_title">Site title</label>
                <input
                  id="weblog_title"
                  required
                  autoComplete="organization"
                  value={siteTitle}
                  onChange={(e) => setSiteTitle(e.target.value)}
                />
              </div>
              <div className="bk-install__field">
                <label htmlFor="user_login">Username</label>
                <input
                  id="user_login"
                  autoComplete="username"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>
              <div className="bk-install__field">
                <label htmlFor="pass1">Password</label>
                <div className="bk-install__pw">
                  <input
                    id="pass1"
                    type={showPw ? 'text' : 'password'}
                    autoComplete="new-password"
                    required
                    minLength={8}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    className="bk-install__pw-toggle"
                    onClick={() => setShowPw((v) => !v)}
                  >
                    {showPw ? 'Hide' : 'Show'}
                  </button>
                </div>
              </div>
              <div className="bk-install__meta">
                <span className={`bk-install__strength ${strength}`}>
                  {password ? `Strength · ${strength}` : 'Use at least 8 characters'}
                </span>
                <button
                  type="button"
                  className="bk-install__linkish"
                  onClick={() => setPassword(generatePassword())}
                >
                  Generate
                </button>
              </div>
              <div className="bk-install__field">
                <label htmlFor="admin_email">Email</label>
                <input
                  id="admin_email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <label className="bk-install__check">
                <input
                  type="checkbox"
                  checked={blogPublic}
                  onChange={(e) => setBlogPublic(e.target.checked)}
                />
                <span>Allow search engines to index this site</span>
              </label>
              <div className="bk-install__actions bk-install__actions--spread">
                <button
                  type="button"
                  className="bk-install__btn bk-install__btn--ghost"
                  onClick={() => setStep('frontend')}
                >
                  Back
                </button>
                <button
                  type="submit"
                  className="bk-install__btn bk-install__btn--primary"
                  disabled={busy || (password.length > 0 && strength === 'weak')}
                >
                  {busy ? 'Installing…' : 'Install'}
                </button>
              </div>
            </form>
          )}

          {step === 'success' && (
            <div className="bk-install__success">
              <div className="bk-install__success-icon" aria-hidden="true">
                ✓
              </div>
              <div className="bk-install__actions" style={{ justifyContent: 'center' }}>
                <Link to="/admin/login" className="bk-install__btn bk-install__btn--primary">
                  Sign in
                </Link>
              </div>
            </div>
          )}
        </main>

        <p className="bk-install__footer">Beekiri · First-run installer for every new site</p>
      </div>
    </div>
  );
}
