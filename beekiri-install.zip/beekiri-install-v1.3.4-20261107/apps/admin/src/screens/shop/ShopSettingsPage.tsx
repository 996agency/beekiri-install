import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api, ApiError } from '../../api/client';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { MediaPicker, useMediaItem } from '../../editor/beekiricode/inspector/MediaPicker';
import {
  formatMoney,
  invalidateShopMeta,
  moneyToInput,
  parseMoney,
  useShopMeta,
  type CheckoutField,
  type CheckoutFieldSection,
  type CheckoutFieldType,
  type EmailToggle,
  type ShippingMethod,
  type ShippingZone,
  type ShopMeta,
  type ShopSettings,
  type ShopSettingsResponse,
  type TaxRate,
} from './api';
import './shop.css';
import './settings.css';

/* ── Tabs ────────────────────────────────────────────────────────────── */

const TABS = [
  { id: 'general', label: 'General' },
  { id: 'products', label: 'Products' },
  { id: 'tax', label: 'Tax' },
  { id: 'shipping', label: 'Shipping' },
  { id: 'payments', label: 'Payments' },
  { id: 'checkout', label: 'Checkout' },
  { id: 'accounts', label: 'Accounts' },
  { id: 'emails', label: 'Emails' },
  { id: 'advanced', label: 'Advanced' },
] as const;
type TabId = (typeof TABS)[number]['id'];
const TAB_IDS = new Set<string>(TABS.map((t) => t.id));

const SORT_OPTIONS: { value: ShopSettings['products']['defaultSort']; label: string }[] = [
  { value: 'menu_order', label: 'Default sorting (custom order)' },
  { value: 'popularity', label: 'Popularity (sales)' },
  { value: 'newest', label: 'Latest' },
  { value: 'price', label: 'Price: low to high' },
  { value: 'price-desc', label: 'Price: high to low' },
  { value: 'title', label: 'Name' },
];

const EMAIL_ROWS: { key: keyof Pick<ShopSettings['emails'], 'newOrderAdmin' | 'orderReceived' | 'onHold' | 'processing' | 'completed' | 'cancelled' | 'refunded' | 'customerNote' | 'shipped' | 'delivered'>; label: string; to: string }[] = [
  { key: 'newOrderAdmin', label: 'New order', to: 'Shop admin' },
  { key: 'orderReceived', label: 'Order received', to: 'Customer' },
  { key: 'onHold', label: 'Order on hold', to: 'Customer' },
  { key: 'processing', label: 'Processing order', to: 'Customer' },
  { key: 'shipped', label: 'Order shipped', to: 'Customer' },
  { key: 'delivered', label: 'Order delivered', to: 'Customer' },
  { key: 'completed', label: 'Completed order', to: 'Customer' },
  { key: 'cancelled', label: 'Cancelled order', to: 'Customer' },
  { key: 'refunded', label: 'Refunded order', to: 'Customer' },
  { key: 'customerNote', label: 'Customer note', to: 'Customer' },
];

const STRIPE_EVENTS = [
  'checkout.session.completed',
  'checkout.session.async_payment_succeeded',
  'checkout.session.async_payment_failed',
  'checkout.session.expired',
  'charge.refunded',
];

const shortId = () => Math.random().toString(36).slice(2, 10);

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

/* ── Small shared controls ───────────────────────────────────────────── */

function Check({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: ReactNode; disabled?: boolean }) {
  return (
    <label className="bk-check">
      <input type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <span className="bk-check__box" aria-hidden />
      <span className="bk-check__label">{label}</span>
    </label>
  );
}

function Row({ label, htmlFor, children, help }: { label: ReactNode; htmlFor?: string; children: ReactNode; help?: ReactNode }) {
  return (
    <tr>
      <th scope="row">{htmlFor ? <label htmlFor={htmlFor}>{label}</label> : label}</th>
      <td>
        {children}
        {help ? <p className="description">{help}</p> : null}
      </td>
    </tr>
  );
}

/** Text input for a money value; keeps the typed text until blur so "1." is not clobbered. */
function MoneyInput({
  value,
  onChange,
  meta,
  currency,
  id,
  className,
  disabled,
}: {
  value: number | null;
  onChange: (minor: number | null) => void;
  meta: ShopMeta | null;
  currency: string;
  id?: string;
  className?: string;
  disabled?: boolean;
}) {
  const [text, setText] = useState(() => moneyToInput(value, currency, meta?.currencies));
  const lastValue = useRef(value);
  useEffect(() => {
    if (lastValue.current !== value) {
      lastValue.current = value;
      setText(moneyToInput(value, currency, meta?.currencies));
    }
  }, [value, currency, meta?.currencies]);
  return (
    <input
      id={id}
      className={`regular-text ${className ?? ''}`.trim()}
      type="text"
      inputMode="decimal"
      value={text}
      disabled={disabled}
      onChange={(e) => setText(e.target.value)}
      onBlur={() => {
        const minor = parseMoney(text, currency, meta?.currencies);
        lastValue.current = minor;
        onChange(minor);
        setText(moneyToInput(minor, currency, meta?.currencies));
      }}
    />
  );
}

/** Chips + searchable list for ISO country codes. */
function CountryMultiSelect({
  value,
  onChange,
  countries,
  emptyLabel,
}: {
  value: string[];
  onChange: (codes: string[]) => void;
  countries: ShopMeta['countries'];
  emptyLabel?: string;
}) {
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const nameOf = (code: string) => countries.find((c) => c.code === code)?.name ?? code;
  const q = query.trim().toLowerCase();
  const matches = countries
    .filter((c) => !value.includes(c.code))
    .filter((c) => !q || c.name.toLowerCase().includes(q) || c.code.toLowerCase() === q)
    .slice(0, 60);
  return (
    <div className="bk-shop-countries">
      <div className="bk-shop-chips">
        {value.length === 0 && emptyLabel ? <span className="bk-muted">{emptyLabel}</span> : null}
        {value.map((code) => (
          <span key={code} className="bk-shop-chip">
            {nameOf(code)}
            <button type="button" aria-label={`Remove ${nameOf(code)}`} onClick={() => onChange(value.filter((c) => c !== code))}>
              ×
            </button>
          </span>
        ))}
      </div>
      <div className="bk-shop-countries__search">
        <input
          className="regular-text"
          type="search"
          placeholder="Search countries…"
          value={query}
          onFocus={() => setOpen(true)}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
        />
      </div>
      {open || q ? (
        <ul className="bk-shop-countries__list">
          {matches.length === 0 ? <li className="bk-shop-countries__empty">No countries match.</li> : null}
          {matches.map((c) => (
            <li key={c.code}>
              <button
                type="button"
                onClick={() => {
                  onChange([...value, c.code]);
                  setQuery('');
                }}
              >
                {c.name} <span>{c.code}</span>
              </button>
            </li>
          ))}
          <li>
            <button type="button" onClick={() => setOpen(false)}>
              <span>Close list</span>
            </button>
          </li>
        </ul>
      ) : null}
    </div>
  );
}

function CountrySelect({ value, onChange, countries, id, blankLabel }: { value: string; onChange: (code: string) => void; countries: ShopMeta['countries']; id?: string; blankLabel: string }) {
  return (
    <select id={id} value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="">{blankLabel}</option>
      {countries.map((c) => (
        <option key={c.code} value={c.code}>
          {c.name}
        </option>
      ))}
    </select>
  );
}

function PlaceholderImage({ value, onChange }: { value: string; onChange: (id: string) => void }) {
  const [open, setOpen] = useState(false);
  const item = useMediaItem(value);
  return (
    <div className="bk-shop-settings__placeholder">
      {item ? <img src={item.url} alt={item.alt || ''} /> : null}
      <div className="bk-shop-inline">
        <button type="button" className="button" onClick={() => setOpen(true)}>
          {value ? 'Change image' : 'Choose image'}
        </button>
        {value ? (
          <button type="button" className="button" onClick={() => onChange('')}>
            Remove
          </button>
        ) : null}
      </div>
      <MediaPicker
        open={open}
        onClose={() => setOpen(false)}
        kind="image"
        title="Placeholder image"
        onSelect={(items) => {
          if (items[0]) onChange(items[0].id);
          setOpen(false);
        }}
      />
    </div>
  );
}

/* ── Page ────────────────────────────────────────────────────────────── */

export function ShopSettingsPage() {
  const meta = useShopMeta();
  const [params, setParams] = useSearchParams();
  const rawTab = params.get('tab') ?? 'general';
  const tab: TabId = TAB_IDS.has(rawTab) ? (rawTab as TabId) : 'general';
  const selectTab = (id: TabId) => {
    const next = new URLSearchParams(params);
    if (id === 'general') next.delete('tab');
    else next.set('tab', id);
    setParams(next, { replace: true });
  };

  const [saved, setSaved] = useState<ShopSettingsResponse | null>(null);
  const [draft, setDraft] = useState<ShopSettings | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    api<ShopSettingsResponse>('/api/shop/settings')
      .then((res) => {
        if (cancelled) return;
        setSaved(res);
        setDraft(res.settings);
      })
      .catch((e) => {
        if (!cancelled) setError(formatError(e));
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const dirty = useMemo(() => Boolean(draft && saved && JSON.stringify(draft) !== JSON.stringify(saved.settings)), [draft, saved]);

  const update = useCallback(<K extends keyof ShopSettings>(section: K, patch: Partial<ShopSettings[K]>) => {
    setDraft((d) => (d ? { ...d, [section]: { ...d[section], ...patch } } : d));
  }, []);

  const save = async () => {
    if (!draft) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const res = await api<ShopSettingsResponse>('/api/shop/settings', { method: 'PUT', json: draft });
      setSaved(res);
      setDraft(res.settings);
      invalidateShopMeta();
      setNotice('Shop settings saved.');
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const countries = meta?.countries ?? [];
  const currency = draft?.general.currency ?? meta?.currency ?? 'EUR';
  /** Money format of the draft (so the preview follows unsaved changes). */
  const draftMeta: ShopMeta | null = useMemo(() => {
    if (!meta || !draft) return meta;
    const g = draft.general;
    return {
      ...meta,
      currency: g.currency,
      money: { currency: g.currency, position: g.currencyPosition, thousandSeparator: g.thousandSeparator, decimalSeparator: g.decimalSeparator, decimals: g.decimals },
    };
  }, [meta, draft]);

  const saveBar = (
    <div className="bk-shop-settings__save">
      <button type="button" className="button button-primary" disabled={!dirty || busy} onClick={() => void save()}>
        {busy ? 'Saving…' : 'Save changes'}
      </button>
      {dirty ? <span className="bk-muted">You have unsaved changes.</span> : null}
    </div>
  );

  return (
    <div className="wrap wrap--wide bk-shop-settings">
      <PageHeader title="Shop settings" />
      <p className="bk-muted bk-shop-settings__intro">Store details, currency, taxes, shipping, payment methods, checkout fields and order emails.</p>

      <nav className="bk-tabs" aria-label="Shop settings sections">
        {TABS.map(({ id, label }) => (
          <button key={id} type="button" className={`bk-tabs__item${tab === id ? ' is-active' : ''}`} onClick={() => selectTab(id)}>
            {label}
          </button>
        ))}
      </nav>

      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <div className="bk-settings-panel is-in" aria-busy={!draft}>
        {!draft || !saved ? (
          <div className="bk-settings-panel__loading" role="status">
            <span className="bk-settings-panel__spinner" aria-hidden />
            <span>Loading…</span>
          </div>
        ) : (
          <form
            className="bk-stack"
            onSubmit={(e) => {
              e.preventDefault();
              void save();
            }}
          >
            {tab === 'general' ? (
              <GeneralTab s={draft.general} meta={meta} draftMeta={draftMeta} countries={countries} onChange={(p) => update('general', p)} />
            ) : null}
            {tab === 'products' ? <ProductsTab s={draft.products} onChange={(p) => update('products', p)} /> : null}
            {tab === 'tax' ? <TaxTab s={draft.tax} countries={countries} onChange={(p) => update('tax', p)} /> : null}
            {tab === 'shipping' ? <ShippingTab s={draft.shipping} meta={draftMeta} currency={currency} countries={countries} onChange={(p) => update('shipping', p)} /> : null}
            {tab === 'payments' ? <PaymentsTab s={draft.payments} responseMeta={saved.meta} onChange={(p) => update('payments', p)} /> : null}
            {tab === 'checkout' ? <CheckoutTab s={draft.checkout} pages={meta?.pages ?? []} onChange={(p) => update('checkout', p)} /> : null}
            {tab === 'accounts' ? <AccountsTab s={draft.accounts} onChange={(p) => update('accounts', p)} /> : null}
            {tab === 'emails' ? <EmailsTab s={draft.emails} onChange={(p) => update('emails', p)} /> : null}
            {tab === 'advanced' ? <AdvancedTab s={draft.advanced} onChange={(p) => update('advanced', p)} /> : null}
            {saveBar}
          </form>
        )}
      </div>
    </div>
  );
}

/* ── General ─────────────────────────────────────────────────────────── */

function GeneralTab({
  s,
  meta,
  draftMeta,
  countries,
  onChange,
}: {
  s: ShopSettings['general'];
  meta: ShopMeta | null;
  draftMeta: ShopMeta | null;
  countries: ShopMeta['countries'];
  onChange: (p: Partial<ShopSettings['general']>) => void;
}) {
  const setAddress = (p: Partial<ShopSettings['general']['address']>) => onChange({ address: { ...s.address, ...p } });
  const preview = formatMoney(123456, draftMeta, s.currency);
  return (
    <>
      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Store details</h2>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <Row label="Store name" htmlFor="shop-store-name" help="Shown in order emails. Leave blank to use the site title.">
                <input id="shop-store-name" className="regular-text" type="text" value={s.storeName} onChange={(e) => onChange({ storeName: e.target.value })} />
              </Row>
              <Row label="Store email" htmlFor="shop-store-email" help="Contact address shown to customers (order emails are sent from the server's SMTP address).">
                <input id="shop-store-email" className="regular-text" type="email" value={s.storeEmail} onChange={(e) => onChange({ storeEmail: e.target.value })} />
              </Row>
              <Row label="Address line 1" htmlFor="shop-addr-1">
                <input id="shop-addr-1" className="regular-text" type="text" value={s.address.line1} onChange={(e) => setAddress({ line1: e.target.value })} />
              </Row>
              <Row label="Address line 2" htmlFor="shop-addr-2">
                <input id="shop-addr-2" className="regular-text" type="text" value={s.address.line2} onChange={(e) => setAddress({ line2: e.target.value })} />
              </Row>
              <Row label="City" htmlFor="shop-addr-city">
                <input id="shop-addr-city" className="regular-text" type="text" value={s.address.city} onChange={(e) => setAddress({ city: e.target.value })} />
              </Row>
              <Row label="State / County" htmlFor="shop-addr-state">
                <input id="shop-addr-state" className="regular-text" type="text" value={s.address.state} onChange={(e) => setAddress({ state: e.target.value })} />
              </Row>
              <Row label="Postcode" htmlFor="shop-addr-postcode">
                <input id="shop-addr-postcode" className="regular-text bk-shop-settings__medium" type="text" value={s.address.postcode} onChange={(e) => setAddress({ postcode: e.target.value })} />
              </Row>
              <Row label="Country" htmlFor="shop-addr-country" help="Also the default country on the checkout form and the base for store-based tax.">
                <CountrySelect id="shop-addr-country" value={s.address.country} onChange={(country) => setAddress({ country })} countries={countries} blankLabel="Select a country" />
              </Row>
            </tbody>
          </table>
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Selling locations</h2>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <Row label="Sell to" htmlFor="shop-sell-to">
                <select id="shop-sell-to" value={s.sellTo} onChange={(e) => onChange({ sellTo: e.target.value === 'specific' ? 'specific' : 'all' })}>
                  <option value="all">All countries</option>
                  <option value="specific">Specific countries only</option>
                </select>
              </Row>
              {s.sellTo === 'specific' ? (
                <Row label="Countries" help="Checkout rejects billing and shipping addresses outside this list.">
                  <CountryMultiSelect value={s.sellToCountries} onChange={(sellToCountries) => onChange({ sellToCountries })} countries={countries} emptyLabel="No countries selected yet — nobody can check out." />
                </Row>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Currency</h2>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <Row label="Currency" htmlFor="shop-currency" help="Prices are stored in this currency's smallest unit. Changing it does not convert existing prices.">
                <select id="shop-currency" value={s.currency} onChange={(e) => onChange({ currency: e.target.value })}>
                  {(meta?.currencies ?? [{ code: s.currency, name: s.currency, symbol: s.currency, decimals: 2 }]).map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.code} — {c.name} ({c.symbol})
                    </option>
                  ))}
                </select>
              </Row>
              <Row label="Currency position" htmlFor="shop-currency-pos">
                <select id="shop-currency-pos" value={s.currencyPosition} onChange={(e) => onChange({ currencyPosition: e.target.value as ShopSettings['general']['currencyPosition'] })}>
                  <option value="left">Left (€99.99)</option>
                  <option value="right">Right (99.99€)</option>
                  <option value="left_space">Left with space (€ 99.99)</option>
                  <option value="right_space">Right with space (99.99 €)</option>
                </select>
              </Row>
              <Row label="Thousand separator" htmlFor="shop-thousand">
                <input id="shop-thousand" className="regular-text bk-shop-settings__small" type="text" maxLength={1} value={s.thousandSeparator} onChange={(e) => onChange({ thousandSeparator: e.target.value.slice(0, 1) })} />
              </Row>
              <Row label="Decimal separator" htmlFor="shop-decimal">
                <input id="shop-decimal" className="regular-text bk-shop-settings__small" type="text" maxLength={1} value={s.decimalSeparator} onChange={(e) => onChange({ decimalSeparator: e.target.value.slice(0, 1) })} />
              </Row>
              <Row
                label="Number of decimals"
                htmlFor="shop-decimals"
                help={
                  <>
                    Leave blank to use the currency's own number of decimals. Preview: <span className="bk-shop-settings__preview">{preview}</span>
                  </>
                }
              >
                <input
                  id="shop-decimals"
                  className="regular-text bk-shop-settings__small"
                  type="number"
                  min={0}
                  max={4}
                  value={s.decimals ?? ''}
                  onChange={(e) => onChange({ decimals: e.target.value === '' ? null : Math.max(0, Math.min(4, Number(e.target.value) || 0)) })}
                />
              </Row>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

/* ── Products ────────────────────────────────────────────────────────── */

function ProductsTab({ s, onChange }: { s: ShopSettings['products']; onChange: (p: Partial<ShopSettings['products']>) => void }) {
  const int = (v: string, min: number, max: number) => Math.max(min, Math.min(max, Math.trunc(Number(v) || min)));
  return (
    <>
      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Shop page</h2>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <Row label="Shop page title" htmlFor="shop-title" help="Heading of /shop and the breadcrumb root.">
                <input id="shop-title" className="regular-text" type="text" value={s.shopTitle} onChange={(e) => onChange({ shopTitle: e.target.value })} />
              </Row>
              <Row label="Shop description" htmlFor="shop-desc" help="Shown under the title on /shop and used as its meta description.">
                <textarea id="shop-desc" className="regular-text" rows={3} value={s.shopDescription} onChange={(e) => onChange({ shopDescription: e.target.value })} />
              </Row>
              <Row label="Products per page" htmlFor="shop-per-page">
                <input id="shop-per-page" className="regular-text bk-shop-settings__small" type="number" min={1} max={100} value={s.perPage} onChange={(e) => onChange({ perPage: int(e.target.value, 1, 100) })} />
              </Row>
              <Row label="Default sorting" htmlFor="shop-sort">
                <select id="shop-sort" value={s.defaultSort} onChange={(e) => onChange({ defaultSort: e.target.value as ShopSettings['products']['defaultSort'] })}>
                  {SORT_OPTIONS.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </Row>
              <Row label="Placeholder image" help="Used when a product has no image.">
                <PlaceholderImage value={s.placeholderImageId} onChange={(placeholderImageId) => onChange({ placeholderImageId })} />
              </Row>
              <Row label="Display">
                <div className="bk-stack" style={{ gap: 8 }}>
                  <Check checked={s.showCategories} onChange={(showCategories) => onChange({ showCategories })} label="Show the category sidebar and search on the shop page" />
                  <Check checked={s.showSku} onChange={(showSku) => onChange({ showSku })} label="Show SKUs on product and cart pages" />
                  <Check checked={s.hideOutOfStock} onChange={(hideOutOfStock) => onChange({ hideOutOfStock })} label="Hide out-of-stock products from the catalogue" />
                </div>
              </Row>
              <Row label="Related products" htmlFor="shop-related" help="How many related products to show under a product (0 hides the section).">
                <input id="shop-related" className="regular-text bk-shop-settings__small" type="number" min={0} max={12} value={s.relatedCount} onChange={(e) => onChange({ relatedCount: int(e.target.value, 0, 12) })} />
              </Row>
            </tbody>
          </table>
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Inventory</h2>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <Row label="Low stock threshold" htmlFor="shop-low-stock" help="Products at or below this quantity count as low stock on the Shop overview.">
                <input id="shop-low-stock" className="regular-text bk-shop-settings__small" type="number" min={0} max={100000} value={s.lowStockThreshold} onChange={(e) => onChange({ lowStockThreshold: int(e.target.value, 0, 100000) })} />
              </Row>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

/* ── Tax ─────────────────────────────────────────────────────────────── */

function TaxTab({ s, countries, onChange }: { s: ShopSettings['tax']; countries: ShopMeta['countries']; onChange: (p: Partial<ShopSettings['tax']>) => void }) {
  const setRate = (id: string, patch: Partial<TaxRate>) => onChange({ rates: s.rates.map((r) => (r.id === id ? { ...r, ...patch } : r)) });
  const addRate = () => onChange({ rates: [...s.rates, { id: shortId(), country: '', state: '', rate: 2000, name: 'Tax', shipping: true }] });
  const removeRate = (id: string) => onChange({ rates: s.rates.filter((r) => r.id !== id) });
  return (
    <>
      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Tax options</h2>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <Row label="Taxes">
                <Check checked={s.enabled} onChange={(enabled) => onChange({ enabled })} label="Enable taxes and tax calculations" />
              </Row>
              <Row label="Prices entered with tax" help="Inclusive: the tax part is shown inside the price. Exclusive: tax is added on top at checkout.">
                <Check checked={s.pricesIncludeTax} onChange={(pricesIncludeTax) => onChange({ pricesIncludeTax })} label="Product prices already include tax" disabled={!s.enabled} />
              </Row>
              <Row label="Calculate tax based on" htmlFor="shop-tax-basis">
                <select id="shop-tax-basis" value={s.taxBasedOn} disabled={!s.enabled} onChange={(e) => onChange({ taxBasedOn: e.target.value as ShopSettings['tax']['taxBasedOn'] })}>
                  <option value="shipping">Customer shipping address</option>
                  <option value="billing">Customer billing address</option>
                  <option value="store">Shop base address</option>
                </select>
              </Row>
            </tbody>
          </table>
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Tax rates</h2>
        </div>
        <div className="bk-panel__body">
          <p className="bk-muted" style={{ marginTop: 0 }}>
            The first rate whose country (and state, when set) matches the address is applied. A rate with no country applies everywhere else, so put it last.
          </p>
          <div className="bk-shop-table-wrap">
            <table className="bk-shop-table">
              <thead>
                <tr>
                  <th scope="col">Country</th>
                  <th scope="col">State</th>
                  <th scope="col" className="is-narrow">Rate %</th>
                  <th scope="col">Name</th>
                  <th scope="col" className="is-tight">Shipping</th>
                  <th scope="col" className="is-tight">
                    <span className="screen-reader-text">Remove</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {s.rates.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="bk-shop-table__empty">
                      No tax rates yet.
                    </td>
                  </tr>
                ) : null}
                {s.rates.map((r) => (
                  <tr key={r.id}>
                    <td>
                      <CountrySelect value={r.country} onChange={(country) => setRate(r.id, { country })} countries={countries} blankLabel="Everywhere" />
                    </td>
                    <td>
                      <input className="regular-text" type="text" placeholder="Any" value={r.state} onChange={(e) => setRate(r.id, { state: e.target.value })} />
                    </td>
                    <td className="is-narrow">
                      <PercentInput value={r.rate} onChange={(rate) => setRate(r.id, { rate })} />
                    </td>
                    <td>
                      <input className="regular-text" type="text" value={r.name} onChange={(e) => setRate(r.id, { name: e.target.value })} />
                    </td>
                    <td className="is-tight">
                      <Check checked={r.shipping} onChange={(shipping) => setRate(r.id, { shipping })} label="Taxable" />
                    </td>
                    <td className="is-tight">
                      <button type="button" className="bk-shop-settings__link-btn" onClick={() => removeRate(r.id)}>
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <button type="button" className="button" onClick={addRate}>
            Add rate
          </button>
        </div>
      </div>
    </>
  );
}

/** Rate stored in basis points (2000 = 20.00%); edited as a percentage. */
function PercentInput({ value, onChange }: { value: number; onChange: (basisPoints: number) => void }) {
  const [text, setText] = useState(() => (value / 100).toFixed(2));
  const last = useRef(value);
  useEffect(() => {
    if (last.current !== value) {
      last.current = value;
      setText((value / 100).toFixed(2));
    }
  }, [value]);
  return (
    <input
      className="regular-text"
      type="text"
      inputMode="decimal"
      value={text}
      onChange={(e) => setText(e.target.value)}
      onBlur={() => {
        const n = Number(text.replace(',', '.'));
        const bp = Number.isFinite(n) ? Math.max(0, Math.min(10000, Math.round(n * 100))) : value;
        last.current = bp;
        onChange(bp);
        setText((bp / 100).toFixed(2));
      }}
    />
  );
}

/* ── Shipping ────────────────────────────────────────────────────────── */

function ShippingTab({
  s,
  meta,
  currency,
  countries,
  onChange,
}: {
  s: ShopSettings['shipping'];
  meta: ShopMeta | null;
  currency: string;
  countries: ShopMeta['countries'];
  onChange: (p: Partial<ShopSettings['shipping']>) => void;
}) {
  const setZone = (id: string, patch: Partial<ShippingZone>) => onChange({ zones: s.zones.map((z) => (z.id === id ? { ...z, ...patch } : z)) });
  const addZone = () =>
    onChange({
      zones: [...s.zones, { id: shortId(), name: s.zones.length ? `Zone ${s.zones.length + 1}` : 'Domestic', countries: [], methods: [{ id: shortId(), type: 'flat_rate', title: 'Flat rate', cost: 0, minAmount: 0, enabled: true }] }],
    });
  const removeZone = (id: string) => onChange({ zones: s.zones.filter((z) => z.id !== id) });
  const setMethod = (zone: ShippingZone, id: string, patch: Partial<ShippingMethod>) => setZone(zone.id, { methods: zone.methods.map((m) => (m.id === id ? { ...m, ...patch } : m)) });
  const addMethod = (zone: ShippingZone) => setZone(zone.id, { methods: [...zone.methods, { id: shortId(), type: 'flat_rate', title: 'Flat rate', cost: 0, minAmount: 0, enabled: true }] });
  const removeMethod = (zone: ShippingZone, id: string) => setZone(zone.id, { methods: zone.methods.filter((m) => m.id !== id) });

  return (
    <>
      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Shipping options</h2>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <Row label="Shipping" help="When off, checkout skips shipping entirely (useful for virtual-only shops).">
                <Check checked={s.enabled} onChange={(enabled) => onChange({ enabled })} label="Enable shipping and shipping zones" />
              </Row>
            </tbody>
          </table>
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Shipping zones</h2>
        </div>
        <div className="bk-panel__body">
          <p className="bk-muted" style={{ marginTop: 0 }}>
            A customer's address is matched to the first zone that lists their country; otherwise to the zone with no countries ("Everywhere else"). Free shipping becomes available once the order subtotal reaches its minimum.
          </p>
          {s.zones.length === 0 ? (
            <p className="bk-shop-note is-info">No zones yet — customers will not be able to check out physical products until a zone with a shipping method exists.</p>
          ) : null}
          {s.zones.map((zone, index) => (
            <div key={zone.id} className="bk-shop-card">
              <div className="bk-shop-card__head">
                <h3>Zone {index + 1}</h3>
                <input className="regular-text bk-shop-settings__medium" type="text" value={zone.name} placeholder="Zone name" onChange={(e) => setZone(zone.id, { name: e.target.value })} />
              </div>
              <div className="bk-shop-card__body">
                <table className="form-table">
                  <tbody>
                    <Row label="Countries">
                      <CountryMultiSelect value={zone.countries} onChange={(c) => setZone(zone.id, { countries: c })} countries={countries} emptyLabel="Everywhere else (no specific countries)" />
                    </Row>
                    <Row label="Methods">
                      <div className="bk-shop-table-wrap">
                        <table className="bk-shop-table">
                          <thead>
                            <tr>
                              <th scope="col">Type</th>
                              <th scope="col">Title</th>
                              <th scope="col" className="is-narrow">Cost</th>
                              <th scope="col" className="is-narrow">Min. order</th>
                              <th scope="col" className="is-tight">Enabled</th>
                              <th scope="col" className="is-tight">
                                <span className="screen-reader-text">Remove</span>
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            {zone.methods.length === 0 ? (
                              <tr>
                                <td colSpan={6} className="bk-shop-table__empty">
                                  No methods — this zone cannot ship.
                                </td>
                              </tr>
                            ) : null}
                            {zone.methods.map((m) => (
                              <tr key={m.id}>
                                <td>
                                  <select
                                    value={m.type}
                                    onChange={(e) => {
                                      const type = e.target.value as ShippingMethod['type'];
                                      const defaultTitle = type === 'flat_rate' ? 'Flat rate' : type === 'free_shipping' ? 'Free shipping' : 'Local pickup';
                                      const keepTitle = !['Flat rate', 'Free shipping', 'Local pickup', ''].includes(m.title);
                                      setMethod(zone, m.id, { type, title: keepTitle ? m.title : defaultTitle });
                                    }}
                                  >
                                    <option value="flat_rate">Flat rate</option>
                                    <option value="free_shipping">Free shipping</option>
                                    <option value="local_pickup">Local pickup</option>
                                  </select>
                                </td>
                                <td>
                                  <input className="regular-text" type="text" value={m.title} onChange={(e) => setMethod(zone, m.id, { title: e.target.value })} />
                                </td>
                                <td className="is-narrow">
                                  <MoneyInput value={m.cost} meta={meta} currency={currency} disabled={m.type === 'free_shipping'} onChange={(minor) => setMethod(zone, m.id, { cost: minor ?? 0 })} />
                                </td>
                                <td className="is-narrow">
                                  <MoneyInput value={m.minAmount} meta={meta} currency={currency} disabled={m.type !== 'free_shipping'} onChange={(minor) => setMethod(zone, m.id, { minAmount: minor ?? 0 })} />
                                </td>
                                <td className="is-tight">
                                  <Check checked={m.enabled} onChange={(enabled) => setMethod(zone, m.id, { enabled })} label="On" />
                                </td>
                                <td className="is-tight">
                                  <button type="button" className="bk-shop-settings__link-btn" onClick={() => removeMethod(zone, m.id)}>
                                    Remove
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </Row>
                  </tbody>
                </table>
              </div>
              <div className="bk-shop-card__foot">
                <button type="button" className="button" onClick={() => addMethod(zone)}>
                  Add method
                </button>
                <button type="button" className="button" onClick={() => removeZone(zone.id)}>
                  Remove zone
                </button>
              </div>
            </div>
          ))}
          <button type="button" className="button button-primary" onClick={addZone}>
            Add zone
          </button>
        </div>
      </div>
    </>
  );
}

/* ── Payments ────────────────────────────────────────────────────────── */

type PaymentMethodId = 'stripe' | 'cod' | 'bank_transfer';

/** Registry of payment methods the Payments tab can show — add future providers here. */
const PAYMENT_METHOD_DEFS: { id: PaymentMethodId; title: string; subtitle: string; icon: ReactNode }[] = [
  {
    id: 'stripe',
    title: 'Stripe',
    subtitle: 'Cards, Apple Pay, Google Pay — hosted checkout page',
    icon: (
      <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        <rect x="2" y="5" width="20" height="14" rx="2" />
        <path d="M2 10h20" />
        <path d="M6 15h4" />
      </svg>
    ),
  },
  {
    id: 'cod',
    title: 'Cash on delivery',
    subtitle: 'Pay with cash when the order arrives',
    icon: (
      <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        <rect x="2" y="7" width="20" height="10" rx="2" />
        <circle cx="12" cy="12" r="2.5" />
        <path d="M6 12h.01M18 12h.01" />
      </svg>
    ),
  },
  {
    id: 'bank_transfer',
    title: 'Direct bank transfer',
    subtitle: 'Customer pays into your bank account; order waits on hold',
    icon: (
      <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        <path d="M3 10 12 4l9 6" />
        <path d="M5 10v8M9 10v8M15 10v8M19 10v8" />
        <path d="M3 20h18" />
      </svg>
    ),
  },
];

/** CSS-only on/off switch (same semantics as a checkbox). */
function Switch({ checked, onChange, disabled, label }: { checked: boolean; onChange: (v: boolean) => void; disabled?: boolean; label: string }) {
  return (
    <label className={`bk-shop-switch${disabled ? ' is-disabled' : ''}`}>
      <input type="checkbox" role="switch" aria-checked={checked} aria-label={label} checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <span className="bk-shop-switch__track" aria-hidden>
        <span className="bk-shop-switch__knob" />
      </span>
    </label>
  );
}

function PaymentsTab({
  s,
  responseMeta,
  onChange,
}: {
  s: ShopSettings['payments'];
  responseMeta: ShopSettingsResponse['meta'];
  onChange: (p: Partial<ShopSettings['payments']>) => void;
}) {
  const [open, setOpen] = useState<PaymentMethodId | null>(null);
  const [copied, setCopied] = useState(false);
  const cod = (p: Partial<ShopSettings['payments']['cod']>) => onChange({ cod: { ...s.cod, ...p } });
  const bank = (p: Partial<ShopSettings['payments']['bankTransfer']>) => onChange({ bankTransfer: { ...s.bankTransfer, ...p } });
  const stripe = (p: Partial<ShopSettings['payments']['stripe']>) => onChange({ stripe: { ...s.stripe, ...p } });
  const webhookUrl = `${window.location.origin}/api/shop/webhooks/stripe`;
  const accounts = s.bankTransfer.accounts;
  const setAccount = (i: number, patch: Partial<(typeof accounts)[number]>) => bank({ accounts: accounts.map((a, idx) => (idx === i ? { ...a, ...patch } : a)) });
  /** A key typed in this session (not the masked placeholder) counts as "configured" for the toggle. */
  const stripeReady = responseMeta.stripeConfigured || (s.stripe.secretKey.trim() !== '' && !s.stripe.secretKey.startsWith('••••'));

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(webhookUrl);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard unavailable — the URL is still visible */
    }
  };

  const stateOf = (id: PaymentMethodId): { enabled: boolean; set: (v: boolean) => void; status: { label: string; tone: string }; toggleDisabled: boolean; hint: string } => {
    if (id === 'stripe') {
      const enabled = s.stripe.enabled;
      return {
        enabled,
        set: (enabled2) => stripe({ enabled: enabled2 }),
        status: !stripeReady ? { label: 'Needs setup', tone: 'warn' } : enabled ? { label: 'Enabled', tone: 'ok' } : { label: 'Disabled', tone: 'muted' },
        toggleDisabled: !stripeReady,
        hint: !stripeReady ? 'Add your Stripe secret key under Manage to turn this on.' : '',
      };
    }
    if (id === 'cod') {
      return { enabled: s.cod.enabled, set: (enabled) => cod({ enabled }), status: s.cod.enabled ? { label: 'Enabled', tone: 'ok' } : { label: 'Disabled', tone: 'muted' }, toggleDisabled: false, hint: '' };
    }
    return { enabled: s.bankTransfer.enabled, set: (enabled) => bank({ enabled }), status: s.bankTransfer.enabled ? { label: 'Enabled', tone: 'ok' } : { label: 'Disabled', tone: 'muted' }, toggleDisabled: false, hint: '' };
  };

  const enabledCount = [s.stripe.enabled && stripeReady, s.cod.enabled, s.bankTransfer.enabled].filter(Boolean).length;

  return (
    <>
      {!responseMeta.secretsPersist ? (
        <p className="bk-shop-note">
          CACHE_FLUSH_SECRET is not set in apps/api/.env, so encrypted keys will not survive a restart — set it (openssl rand -hex 32) and re-enter the keys.
        </p>
      ) : null}
      {enabledCount === 0 ? <p className="bk-shop-note is-error">No payment method is enabled — shoppers cannot check out until one is on.</p> : null}

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Payment methods</h2>
          <span className="bk-muted">{enabledCount} enabled · shown at checkout in this order</span>
        </div>
        <div className="bk-panel__body bk-shop-methods">
          {PAYMENT_METHOD_DEFS.map((def) => {
            const st = stateOf(def.id);
            const isOpen = open === def.id;
            return (
              <div key={def.id} className={`bk-shop-method${isOpen ? ' is-open' : ''}${st.enabled && !st.toggleDisabled ? ' is-enabled' : ''}`}>
                <div className="bk-shop-method__row">
                  <span className={`bk-shop-method__icon is-${def.id}`} aria-hidden>
                    {def.icon}
                  </span>
                  <div className="bk-shop-method__text">
                    <strong>{def.title}</strong>
                    <span>{def.subtitle}</span>
                    {st.hint ? <em className="bk-shop-method__hint">{st.hint}</em> : null}
                  </div>
                  <span className={`bk-shop-pill is-${st.status.tone}`}>{st.status.label}</span>
                  <Switch checked={st.enabled && !st.toggleDisabled} disabled={st.toggleDisabled} onChange={st.set} label={`Enable ${def.title}`} />
                  <button type="button" className="button" aria-expanded={isOpen} onClick={() => setOpen(isOpen ? null : def.id)}>
                    {isOpen ? 'Close' : 'Manage'}
                  </button>
                </div>

                {isOpen && def.id === 'cod' ? (
                  <div className="bk-shop-method__panel">
                    <table className="form-table">
                      <tbody>
                        <Row label="Title" htmlFor="pay-cod-title" help="What shoppers see at checkout.">
                          <input id="pay-cod-title" className="regular-text" type="text" value={s.cod.title} onChange={(e) => cod({ title: e.target.value })} />
                        </Row>
                        <Row label="Description" htmlFor="pay-cod-desc" help="Shown under the method on the checkout page.">
                          <input id="pay-cod-desc" className="regular-text" type="text" value={s.cod.description} onChange={(e) => cod({ description: e.target.value })} />
                        </Row>
                        <Row label="Instructions" htmlFor="pay-cod-instr" help="Shown on the thank-you page and in the order email.">
                          <textarea id="pay-cod-instr" className="regular-text" rows={3} value={s.cod.instructions} onChange={(e) => cod({ instructions: e.target.value })} />
                        </Row>
                      </tbody>
                    </table>
                  </div>
                ) : null}

                {isOpen && def.id === 'bank_transfer' ? (
                  <div className="bk-shop-method__panel">
                    <table className="form-table">
                      <tbody>
                        <Row label="Title" htmlFor="pay-bank-title">
                          <input id="pay-bank-title" className="regular-text" type="text" value={s.bankTransfer.title} onChange={(e) => bank({ title: e.target.value })} />
                        </Row>
                        <Row label="Description" htmlFor="pay-bank-desc">
                          <input id="pay-bank-desc" className="regular-text" type="text" value={s.bankTransfer.description} onChange={(e) => bank({ description: e.target.value })} />
                        </Row>
                        <Row label="Instructions" htmlFor="pay-bank-instr" help="Shown with the account details on the thank-you page and in the on-hold email.">
                          <textarea id="pay-bank-instr" className="regular-text" rows={3} value={s.bankTransfer.instructions} onChange={(e) => bank({ instructions: e.target.value })} />
                        </Row>
                        <Row label="Bank accounts" help="Shown to the customer after they choose bank transfer. Fill in the fields your bank uses — empty ones are hidden.">
                          <div className="bk-bank-accounts">
                            {accounts.map((a, i) => (
                              <fieldset key={i} className="bk-bank-account">
                                <div className="bk-bank-account__head">
                                  <legend>{a.bankName.trim() || a.accountName.trim() || `Account ${i + 1}`}</legend>
                                  <button type="button" className="bk-shop-settings__link-btn" onClick={() => bank({ accounts: accounts.filter((_, idx) => idx !== i) })}>
                                    Remove
                                  </button>
                                </div>
                                <div className="bk-bank-account__grid">
                                  {(
                                    [
                                      ['accountName', 'Account name', 'e.g. Beekiri Ltd'],
                                      ['bankName', 'Bank', 'e.g. Barclays'],
                                      ['iban', 'IBAN', 'e.g. GB33 BUKB 2020 1555 5555 55'],
                                      ['bic', 'BIC / SWIFT', 'e.g. BUKBGB22'],
                                      ['accountNumber', 'Account number', ''],
                                      ['sortCode', 'Sort code', 'UK only, e.g. 20-00-00'],
                                    ] as const
                                  ).map(([key, label, placeholder]) => (
                                    <div key={key} className="bk-shop-field">
                                      <label htmlFor={`bank-${i}-${key}`}>{label}</label>
                                      <input
                                        id={`bank-${i}-${key}`}
                                        type="text"
                                        value={a[key]}
                                        placeholder={placeholder}
                                        autoComplete="off"
                                        spellCheck={false}
                                        onChange={(e) => setAccount(i, { [key]: e.target.value })}
                                      />
                                    </div>
                                  ))}
                                </div>
                              </fieldset>
                            ))}
                            <button
                              type="button"
                              className="bk-bank-accounts__add"
                              disabled={accounts.length >= 10}
                              onClick={() => bank({ accounts: [...accounts, { accountName: '', accountNumber: '', bankName: '', sortCode: '', iban: '', bic: '' }] })}
                            >
                              + Add bank account
                            </button>
                          </div>
                        </Row>
                      </tbody>
                    </table>
                  </div>
                ) : null}

                {isOpen && def.id === 'stripe' ? (
                  <div className="bk-shop-method__panel">
                    <p className="bk-muted" style={{ marginTop: 0 }}>
                      Customers pay on Stripe's hosted checkout page; card details never reach this site.{' '}
                      <span className={`bk-shop-settings__status${responseMeta.stripeConfigured ? ' is-ok' : ''}`}>{responseMeta.stripeConfigured ? 'Secret key saved' : 'Secret key not set'}</span>
                    </p>
                    <table className="form-table">
                      <tbody>
                        <Row label="Title" htmlFor="pay-stripe-title">
                          <input id="pay-stripe-title" className="regular-text" type="text" value={s.stripe.title} onChange={(e) => stripe({ title: e.target.value })} />
                        </Row>
                        <Row label="Description" htmlFor="pay-stripe-desc">
                          <input id="pay-stripe-desc" className="regular-text" type="text" value={s.stripe.description} onChange={(e) => stripe({ description: e.target.value })} />
                        </Row>
                        <Row label="Mode" htmlFor="pay-stripe-mode" help="Use test keys (sk_test_…) with Test mode. Nothing is charged in test mode.">
                          <select id="pay-stripe-mode" value={s.stripe.mode} onChange={(e) => stripe({ mode: e.target.value === 'live' ? 'live' : 'test' })}>
                            <option value="test">Test mode</option>
                            <option value="live">Live mode</option>
                          </select>
                        </Row>
                        <Row label="Publishable key" htmlFor="pay-stripe-pk">
                          <input id="pay-stripe-pk" className="regular-text" type="text" autoComplete="off" spellCheck={false} placeholder="pk_test_…" value={s.stripe.publishableKey} onChange={(e) => stripe({ publishableKey: e.target.value })} />
                        </Row>
                        <Row label="Secret key" htmlFor="pay-stripe-sk" help="Leave blank to keep the current key. Stored encrypted; never shown again after saving.">
                          <input id="pay-stripe-sk" className="regular-text" type="password" autoComplete="new-password" placeholder={s.stripe.secretKey || 'sk_test_…'} value={s.stripe.secretKey.startsWith('••••') ? '' : s.stripe.secretKey} onChange={(e) => stripe({ secretKey: e.target.value })} />
                        </Row>
                        <Row label="Webhook signing secret" htmlFor="pay-stripe-wh" help="Leave blank to keep the current secret. From the webhook endpoint you create in the Stripe dashboard (whsec_…).">
                          <input id="pay-stripe-wh" className="regular-text" type="password" autoComplete="new-password" placeholder={s.stripe.webhookSecret || 'whsec_…'} value={s.stripe.webhookSecret.startsWith('••••') ? '' : s.stripe.webhookSecret} onChange={(e) => stripe({ webhookSecret: e.target.value })} />
                        </Row>
                        <Row label="Webhook endpoint" help="Add this URL as a webhook endpoint in Stripe and subscribe it to the events below, then paste its signing secret above.">
                          <span className="bk-shop-settings__code">
                            {webhookUrl}
                            <button type="button" className="button" onClick={() => void copy()}>
                              {copied ? 'Copied' : 'Copy'}
                            </button>
                          </span>
                          <ul className="bk-shop-settings__events">
                            {STRIPE_EVENTS.map((ev) => (
                              <li key={ev}>
                                <code>{ev}</code>
                              </li>
                            ))}
                          </ul>
                        </Row>
                      </tbody>
                    </table>
                  </div>
                ) : null}
              </div>
            );
          })}

          <div className="bk-shop-methods__foot">
            <button type="button" className="button" disabled title="More providers are coming — the method list is a registry, so new ones plug in here">
              + Add payment method
            </button>
            <span className="bk-muted">More providers are coming — the method list is a registry, so new ones plug in here.</span>
          </div>
        </div>
      </div>
    </>
  );
}

/* ── Checkout ────────────────────────────────────────────────────────── */

const FIELD_SECTIONS: { id: CheckoutFieldSection; title: string; hint: string }[] = [
  { id: 'contact', title: 'Contact', hint: 'Asked first. Email is always required so the order confirmation can be sent.' },
  { id: 'billing', title: 'Billing details', hint: 'The shipping address form mirrors these fields automatically when a shopper ships elsewhere.' },
  { id: 'extra', title: 'Additional information', hint: 'Your own questions — a gift message, a delivery slot, a VAT number… Answers are saved on the order and sent in the emails.' },
];

const FIELD_TYPES: { value: CheckoutFieldType; label: string }[] = [
  { value: 'text', label: 'Text' },
  { value: 'email', label: 'Email' },
  { value: 'tel', label: 'Phone' },
  { value: 'textarea', label: 'Long text' },
  { value: 'select', label: 'Dropdown' },
  { value: 'checkbox', label: 'Checkbox' },
];

const slugify = (v: string) =>
  v
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 32);

function LockIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <rect x="3" y="11" width="18" height="11" rx="2" />
      <path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </svg>
  );
}

/** Read-only rendering of one field, exactly like the storefront lays it out. */
function PreviewField({ f, countryLabel }: { f: CheckoutField; countryLabel: string }) {
  const mark = f.required ? <span className="bk-shop-fprev__req">*</span> : <span className="bk-shop-fprev__opt">(optional)</span>;
  const cls = `bk-shop-fprev__field${f.width === 'half' ? ' is-half' : ''}`;
  if (f.type === 'checkbox') {
    return (
      <div className={cls}>
        <label className="bk-shop-fprev__check">
          <input type="checkbox" disabled readOnly /> {f.label} {mark}
        </label>
      </div>
    );
  }
  return (
    <div className={cls}>
      <label>
        {f.label} {mark}
      </label>
      {f.key === 'billing.country' ? (
        <select disabled>
          <option>{countryLabel}</option>
        </select>
      ) : f.type === 'select' ? (
        <select disabled>
          <option>{f.placeholder || 'Choose an option'}</option>
        </select>
      ) : f.type === 'textarea' ? (
        <textarea readOnly rows={2} placeholder={f.placeholder} />
      ) : (
        <input type="text" readOnly placeholder={f.placeholder} />
      )}
    </div>
  );
}

function CheckoutTab({ s, pages, onChange }: { s: ShopSettings['checkout']; pages: ShopMeta['pages']; onChange: (p: Partial<ShopSettings['checkout']>) => void }) {
  const meta = useShopMeta();
  const fields = s.fields;
  const setFields = (next: CheckoutField[]) => onChange({ fields: next });
  const patch = (key: string, p: Partial<CheckoutField>) => setFields(fields.map((f) => (f.key === key ? { ...f, ...p } : f)));
  const remove = (key: string) => setFields(fields.filter((f) => f.key !== key));
  const move = (key: string, dir: -1 | 1) => {
    const idx = fields.findIndex((f) => f.key === key);
    if (idx === -1) return;
    const section = fields[idx]!.section;
    // Find the neighbour within the same section (fields of other sections are skipped).
    let j = idx + dir;
    while (j >= 0 && j < fields.length && fields[j]!.section !== section) j += dir;
    if (j < 0 || j >= fields.length) return;
    const next = [...fields];
    [next[idx], next[j]] = [next[j]!, next[idx]!];
    setFields(next);
  };
  const addField = () => {
    if (fields.length >= 60) return;
    const base = 'custom.new-field';
    let key = `${base}-${shortId().slice(0, 4)}`;
    while (fields.some((f) => f.key === key)) key = `${base}-${shortId().slice(0, 4)}`;
    setFields([...fields, { key, label: 'New field', type: 'text', section: 'extra', enabled: true, required: false, placeholder: '', options: [], width: 'full', builtin: false, locked: false }]);
  };
  /** Keep the key readable for the stored answers: it follows the label until first saved. */
  const relabel = (f: CheckoutField, label: string) => {
    const slug = slugify(label);
    const wanted = slug ? `custom.${slug}-${f.key.split('-').pop() ?? shortId().slice(0, 4)}` : f.key;
    const key = !f.builtin && wanted !== f.key && !fields.some((x) => x.key === wanted) ? wanted : f.key;
    setFields(fields.map((x) => (x.key === f.key ? { ...x, key, label: label.slice(0, 80) } : x)));
  };

  const bySection = (id: CheckoutFieldSection) => fields.filter((f) => f.section === id);
  const enabledBySection = (id: CheckoutFieldSection) => bySection(id).filter((f) => f.enabled);
  const defaultCountry = meta?.countries.find((c) => c.code === meta?.countries[0]?.code)?.name ?? 'Country';

  const pageSelect = (id: string, value: string, set: (v: string) => void) => (
    <select id={id} value={value} onChange={(e) => set(e.target.value)}>
      <option value="">— None —</option>
      {pages.map((p) => (
        <option key={p.id} value={p.id}>
          {p.title || p.slug}
        </option>
      ))}
    </select>
  );

  return (
    <>
      <div className="bk-shop-fields">
        <div className="bk-shop-fields__builder">
          {FIELD_SECTIONS.map((sec) => (
            <div key={sec.id} className="bk-shop-card">
              <div className="bk-shop-card__head">
                <h3>{sec.title}</h3>
                <span className="bk-muted">
                  {enabledBySection(sec.id).length} of {bySection(sec.id).length} shown
                </span>
              </div>
              <div className="bk-shop-card__body">
                <p className="bk-muted bk-shop-fields__hint">{sec.hint}</p>
                {bySection(sec.id).length === 0 ? <p className="bk-muted">No fields yet.</p> : null}
                <ul className="bk-shop-flist">
                  {bySection(sec.id).map((f, i, list) => (
                    <li key={f.key} className={`bk-shop-frow${f.enabled ? '' : ' is-off'}`}>
                      <div className="bk-shop-frow__order">
                        <button type="button" className="bk-shop-frow__arrow" aria-label="Move up" disabled={i === 0} onClick={() => move(f.key, -1)}>
                          ▲
                        </button>
                        <button type="button" className="bk-shop-frow__arrow" aria-label="Move down" disabled={i === list.length - 1} onClick={() => move(f.key, 1)}>
                          ▼
                        </button>
                      </div>
                      <div className="bk-shop-frow__toggle" title={f.locked ? 'Needed for the address' : f.enabled ? 'Shown at checkout' : 'Hidden at checkout'}>
                        <Switch checked={f.enabled || f.locked} disabled={f.locked} onChange={(enabled) => patch(f.key, { enabled })} label={`Show ${f.label}`} />
                        {f.locked ? (
                          <span className="bk-shop-frow__lock" title="Needed for the address" aria-label="Needed for the address">
                            <LockIcon />
                          </span>
                        ) : null}
                      </div>
                      <div className="bk-shop-frow__main">
                        <div className="bk-shop-frow__line">
                          <input className="regular-text bk-shop-frow__label" type="text" value={f.label} maxLength={80} aria-label="Field label" onChange={(e) => (f.builtin ? patch(f.key, { label: e.target.value.slice(0, 80) }) : relabel(f, e.target.value))} />
                          {f.builtin ? <span className="bk-shop-pill is-neutral">Built-in</span> : <span className="bk-shop-pill is-info">Custom</span>}
                        </div>
                        <div className="bk-shop-frow__line bk-shop-frow__controls">
                          {!f.builtin ? (
                            <select value={f.type} aria-label="Field type" onChange={(e) => patch(f.key, { type: e.target.value as CheckoutFieldType, options: e.target.value === 'select' ? f.options : [] })}>
                              {FIELD_TYPES.map((t) => (
                                <option key={t.value} value={t.value}>
                                  {t.label}
                                </option>
                              ))}
                            </select>
                          ) : null}
                          {f.type !== 'checkbox' && f.key !== 'billing.country' ? (
                            <input className="regular-text" type="text" value={f.placeholder} maxLength={120} placeholder="Placeholder (optional)" aria-label="Placeholder" onChange={(e) => patch(f.key, { placeholder: e.target.value.slice(0, 120) })} />
                          ) : null}
                          <select value={f.width} aria-label="Width" onChange={(e) => patch(f.key, { width: e.target.value === 'half' ? 'half' : 'full' })}>
                            <option value="full">Full width</option>
                            <option value="half">Half width</option>
                          </select>
                          <Check checked={f.required || f.locked} disabled={f.locked} onChange={(required) => patch(f.key, { required })} label="Required" />
                          {!f.builtin ? (
                            <button type="button" className="bk-shop-settings__link-btn" onClick={() => remove(f.key)}>
                              Remove
                            </button>
                          ) : null}
                        </div>
                        {!f.builtin && f.type === 'select' ? (
                          <div className="bk-shop-frow__line bk-shop-frow__options">
                            <label>
                              Options <span className="bk-muted">(one per line, max 50)</span>
                              <textarea
                                rows={Math.min(6, Math.max(2, f.options.length + 1))}
                                defaultValue={f.options.join('\n')}
                                onBlur={(e) =>
                                  patch(f.key, {
                                    options: [...new Set(e.target.value.split('\n').map((o) => o.trim().slice(0, 80)).filter(Boolean))].slice(0, 50),
                                  })
                                }
                              />
                            </label>
                          </div>
                        ) : null}
                      </div>
                    </li>
                  ))}
                </ul>
                {sec.id === 'extra' ? (
                  <button type="button" className="button" onClick={addField} disabled={fields.length >= 60}>
                    + Add field
                  </button>
                ) : null}
              </div>
            </div>
          ))}

          <div className="bk-shop-card">
            <div className="bk-shop-card__head">
              <h3>Terms &amp; messages</h3>
            </div>
            <div className="bk-shop-card__body">
              <table className="form-table">
                <tbody>
                  <Row label="Terms and conditions page" htmlFor="co-terms" help="Published pages only. Linked from the checkout form.">
                    {pageSelect('co-terms', s.termsPageId, (termsPageId) => onChange({ termsPageId }))}
                    <div style={{ marginTop: 8 }}>
                      <Check checked={s.termsRequired} onChange={(termsRequired) => onChange({ termsRequired })} label="Customers must accept the terms before placing an order" disabled={!s.termsPageId} />
                    </div>
                  </Row>
                  <Row label="Privacy policy page" htmlFor="co-privacy" help="Linked from the privacy note under the payment methods.">
                    {pageSelect('co-privacy', s.privacyPageId, (privacyPageId) => onChange({ privacyPageId }))}
                  </Row>
                  <Row label="Thank-you message" htmlFor="co-thanks" help="Shown at the top of the order-received page.">
                    <textarea id="co-thanks" className="regular-text" rows={2} value={s.thankYouMessage} onChange={(e) => onChange({ thankYouMessage: e.target.value })} />
                  </Row>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <aside className="bk-shop-fields__preview">
          <div className="bk-shop-card">
            <div className="bk-shop-card__head">
              <h3>Preview</h3>
              <span className="bk-muted">What shoppers see</span>
            </div>
            <div className="bk-shop-card__body bk-shop-fprev">
              {FIELD_SECTIONS.map((sec) => {
                const list = enabledBySection(sec.id);
                if (!list.length) return null;
                return (
                  <section key={sec.id} className="bk-shop-fprev__section">
                    <h4>{sec.title}</h4>
                    <div className="bk-shop-fprev__grid">
                      {list.map((f) => (
                        <PreviewField key={f.key} f={f} countryLabel={defaultCountry} />
                      ))}
                    </div>
                  </section>
                );
              })}
              <section className="bk-shop-fprev__section is-ghost">
                <h4>Shipping</h4>
                <label className="bk-shop-fprev__check">
                  <input type="checkbox" disabled readOnly /> Ship to a different address?
                </label>
                <p className="bk-muted">Repeats the billing fields.</p>
              </section>
              {s.termsPageId ? (
                <section className="bk-shop-fprev__section is-ghost">
                  <label className="bk-shop-fprev__check">
                    <input type="checkbox" disabled readOnly /> I have read and agree to the terms {s.termsRequired ? <span className="bk-shop-fprev__req">*</span> : null}
                  </label>
                </section>
              ) : null}
              <div className="bk-shop-fprev__btn">Place order</div>
            </div>
          </div>
        </aside>
      </div>
    </>
  );
}

/* ── Emails ──────────────────────────────────────────────────────────── */

/* ── Accounts ────────────────────────────────────────────────────────── */

function AccountsTab({ s, onChange }: { s: ShopSettings['accounts']; onChange: (p: Partial<ShopSettings['accounts']>) => void }) {
  const rows: { key: keyof ShopSettings['accounts']; label: string; help: string; dependent: boolean }[] = [
    { key: 'enabled', label: 'Customer accounts (My account)', help: 'Adds a My account link to the header and the /account pages.', dependent: false },
    { key: 'allowRegistration', label: 'Shoppers can create an account', help: 'Shows “Create an account” on the sign-in page.', dependent: true },
    { key: 'createAtCheckout', label: 'Offer “Create an account” at checkout', help: 'A checkbox and password field on the checkout form.', dependent: true },
    { key: 'requireAccount', label: 'Require an account to check out', help: 'Guests must sign in or create an account before ordering.', dependent: true },
  ];
  return (
    <div className="bk-panel">
      <div className="bk-panel__head">
        <h2 className="bk-panel__title">Customer accounts</h2>
      </div>
      <div className="bk-panel__body">
        <p className="bk-shop-note is-info">Shoppers see their orders and tracking at /account. Order history appears after they confirm their email address.</p>
        <ul className="bk-shop-account-opts">
          {rows.map((row) => {
            const disabled = row.dependent && !s.enabled;
            return (
              <li key={row.key} className={disabled ? 'is-disabled' : ''}>
                <Switch checked={s[row.key]} disabled={disabled} label={row.label} onChange={(v) => onChange({ [row.key]: v } as Partial<ShopSettings['accounts']>)} />
                <div>
                  <strong>{row.label}</strong>
                  <p className="description">{row.help}</p>
                </div>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

function EmailsTab({ s, onChange }: { s: ShopSettings['emails']; onChange: (p: Partial<ShopSettings['emails']>) => void }) {
  const setToggle = (key: (typeof EMAIL_ROWS)[number]['key'], patch: Partial<EmailToggle>) => onChange({ [key]: { ...s[key], ...patch } } as Partial<ShopSettings['emails']>);
  return (
    <>
      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Sender</h2>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <Row label="From name" htmlFor="em-from" help="Emails are sent from the server's SMTP_FROM address (apps/api/.env).">
                <input id="em-from" className="regular-text" type="text" value={s.fromName} onChange={(e) => onChange({ fromName: e.target.value })} />
              </Row>
              <Row label="New order recipient" htmlFor="em-admin" help="Leave blank to send new-order emails to the site Owner.">
                <input id="em-admin" className="regular-text" type="email" value={s.adminEmail} onChange={(e) => onChange({ adminEmail: e.target.value })} />
              </Row>
            </tbody>
          </table>
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Notifications</h2>
        </div>
        <div className="bk-panel__body">
          <p className="bk-muted" style={{ marginTop: 0 }}>
            Subjects may use <code>{'{site}'}</code> for the site title and <code>{'{number}'}</code> for the order number.
          </p>
          <div className="bk-shop-table-wrap">
            <table className="bk-shop-table">
              <thead>
                <tr>
                  <th scope="col">Email</th>
                  <th scope="col">Recipient</th>
                  <th scope="col" className="is-tight">Enabled</th>
                  <th scope="col">Subject</th>
                </tr>
              </thead>
              <tbody>
                {EMAIL_ROWS.map((row) => (
                  <tr key={row.key}>
                    <td>{row.label}</td>
                    <td className="bk-muted">{row.to}</td>
                    <td className="is-tight">
                      <Check checked={s[row.key].enabled} onChange={(enabled) => setToggle(row.key, { enabled })} label="On" />
                    </td>
                    <td>
                      <input className="regular-text" type="text" value={s[row.key].subject} onChange={(e) => setToggle(row.key, { subject: e.target.value })} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Template</h2>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <Row label="Footer text" htmlFor="em-footer" help="Leave blank for “Site title · site URL”.">
                <input id="em-footer" className="regular-text" type="text" value={s.footerText} onChange={(e) => onChange({ footerText: e.target.value })} />
              </Row>
              <Row label="Accent colour" htmlFor="em-accent" help="Header and buttons in the email template.">
                <input id="em-accent" type="color" value={s.accentColor} onChange={(e) => onChange({ accentColor: e.target.value })} />{' '}
                <code>{s.accentColor}</code>
              </Row>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

/* ── Advanced ────────────────────────────────────────────────────────── */

function AdvancedTab({ s, onChange }: { s: ShopSettings['advanced']; onChange: (p: Partial<ShopSettings['advanced']>) => void }) {
  const int = (v: string, min: number, max: number) => Math.max(min, Math.min(max, Math.trunc(Number(v) || min)));
  return (
    <div className="bk-panel">
      <div className="bk-panel__head">
        <h2 className="bk-panel__title">Advanced</h2>
      </div>
      <div className="bk-panel__body">
        <table className="form-table">
          <tbody>
            <Row label="Order number prefix" htmlFor="adv-prefix" help="Shown in the admin, emails and the thank-you page, e.g. “#1001”.">
              <input id="adv-prefix" className="regular-text bk-shop-settings__small" type="text" maxLength={10} value={s.orderNumberPrefix} onChange={(e) => onChange({ orderNumberPrefix: e.target.value })} />
            </Row>
            <Row label="Order number start" htmlFor="adv-start" help="Only raises the next number; existing orders keep theirs.">
              <input id="adv-start" className="regular-text bk-shop-settings__medium" type="number" min={1} value={s.orderNumberStart} onChange={(e) => onChange({ orderNumberStart: int(e.target.value, 1, 1_000_000_000) })} />
            </Row>
            <Row label="Hold stock (minutes)" htmlFor="adv-hold" help="Unpaid card orders are cancelled and their stock released after this long (5–10080).">
              <input id="adv-hold" className="regular-text bk-shop-settings__small" type="number" min={5} max={10080} value={s.holdStockMinutes} onChange={(e) => onChange({ holdStockMinutes: int(e.target.value, 5, 10080) })} />
            </Row>
            <Row label="Cart expiry (days)" htmlFor="adv-cart" help="How long an untouched cart is remembered (1–365).">
              <input id="adv-cart" className="regular-text bk-shop-settings__small" type="number" min={1} max={365} value={s.cartExpiryDays} onChange={(e) => onChange({ cartExpiryDays: int(e.target.value, 1, 365) })} />
            </Row>
            <Row label="Uninstall" help="Used by Extensions → Uninstall. When unchecked, products, orders, customers and coupons stay in the database for a later reinstall.">
              <Check checked={s.removeDataOnUninstall} onChange={(removeDataOnUninstall) => onChange({ removeDataOnUninstall })} label="Remove all shop data when Shopping is uninstalled" />
            </Row>
          </tbody>
        </table>
      </div>
    </div>
  );
}
