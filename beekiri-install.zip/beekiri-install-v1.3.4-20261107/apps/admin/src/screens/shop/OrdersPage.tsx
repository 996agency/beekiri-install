import { useEffect, useState, type FormEvent } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { api, ApiError } from '../../api/client';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { useAdminHref } from '../../lib/AdminEntryContext';
import {
  buildQuery,
  formatDate,
  ORDER_STATUS_TONE,
  useShopMeta,
  type Customer,
  type OrderList,
  type OrderStatus,
  type OrderListRow,
} from './api';
import './shop.css';
import './orders.css';

export function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

const SHIPPING_PILL: Record<string, { label: string; tone: string }> = {
  unfulfilled: { label: 'Not shipped', tone: 'neutral' },
  packed: { label: 'Packed', tone: 'info' },
  shipped: { label: 'Shipped', tone: 'warn' },
  delivered: { label: 'Delivered', tone: 'ok' },
};

/** Fulfilment pill for the orders list ("—" when the order will never ship). */
export function ShippingPill({ order }: { order: OrderListRow }) {
  if (['cancelled', 'refunded', 'failed'].includes(order.status)) return <span className="bk-muted">—</span>;
  const pill = SHIPPING_PILL[order.fulfillment?.status ?? 'unfulfilled'] ?? SHIPPING_PILL.unfulfilled!;
  return <span className={`bk-shop-pill is-${pill.tone}`}>{pill.label}</span>;
}

/** Order status as a colored pill (shared by the order screens and the overview). */
export function StatusPill({ status, label }: { status: OrderStatus | string; label: string }) {
  const tone = ORDER_STATUS_TONE[status as OrderStatus] ?? 'neutral';
  return <span className={`bk-shop-pill is-${tone}`}>{label}</span>;
}

export const PAYMENT_STATUS_LABELS: Record<string, string> = {
  unpaid: 'Unpaid',
  paid: 'Paid',
  partially_refunded: 'Partially refunded',
  refunded: 'Refunded',
  failed: 'Failed',
};

/** Prev / next pager for server-paginated lists. */
export function Pager({
  page,
  pages,
  total,
  perPage,
  onPage,
  noun,
}: {
  page: number;
  pages: number;
  total: number;
  perPage: number;
  onPage: (page: number) => void;
  noun: string;
}) {
  if (total === 0) return null;
  const from = (page - 1) * perPage + 1;
  const to = Math.min(total, page * perPage);
  return (
    <div className="bk-shop-pager">
      <span>
        {from}–{to} of {total} {noun}
      </span>
      <div className="bk-shop-pager__buttons">
        <button type="button" className="button" disabled={page <= 1} onClick={() => onPage(page - 1)}>
          ‹ Previous
        </button>
        <span style={{ padding: '0 8px', alignSelf: 'center' }}>
          Page {page} of {pages}
        </span>
        <button type="button" className="button" disabled={page >= pages} onClick={() => onPage(page + 1)}>
          Next ›
        </button>
      </div>
    </div>
  );
}

const STATUS_ORDER: OrderStatus[] = ['pending', 'on-hold', 'processing', 'completed', 'cancelled', 'refunded', 'failed'];

export function OrdersPage() {
  const href = useAdminHref();
  const navigate = useNavigate();
  const meta = useShopMeta();
  const [params, setParams] = useSearchParams();
  const status = params.get('status') ?? 'all';
  const q = params.get('q') ?? '';
  const payment = params.get('payment') ?? '';
  const customerId = params.get('customerId') ?? '';
  const page = Math.max(1, Number(params.get('page') ?? '1') || 1);

  const [data, setData] = useState<OrderList | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState(q);
  const [customer, setCustomer] = useState<Customer | null>(null);

  const setParam = (patch: Record<string, string | null>) => {
    const next = new URLSearchParams(params);
    for (const [k, v] of Object.entries(patch)) {
      if (v === null || v === '') next.delete(k);
      else next.set(k, v);
    }
    if (!('page' in patch)) next.delete('page');
    setParams(next);
  };

  useEffect(() => {
    setSearch(q);
  }, [q]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api<OrderList>(
      `/api/shop/orders${buildQuery({ status: status === 'all' ? undefined : status, q, payment, customerId, page, perPage: 25 })}`,
    )
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch((e) => {
        if (!cancelled) setError(formatError(e));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [status, q, payment, customerId, page]);

  useEffect(() => {
    if (!customerId) {
      setCustomer(null);
      return;
    }
    let cancelled = false;
    api<Customer>(`/api/shop/customers/${encodeURIComponent(customerId)}`)
      .then((c) => {
        if (!cancelled) setCustomer(c);
      })
      .catch(() => {
        if (!cancelled) setCustomer(null);
      });
    return () => {
      cancelled = true;
    };
  }, [customerId]);

  const onSearch = (e: FormEvent) => {
    e.preventDefault();
    setParam({ q: search.trim() });
  };

  const counts = data?.counts ?? {};
  const statusLabel = (id: OrderStatus) => data?.statuses.find((s) => s.id === id)?.label ?? id;
  const rows = data?.items ?? [];
  const hasFilters = Boolean(q || payment || customerId || status !== 'all');

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Orders"
        actions={
          hasFilters ? (
            <button type="button" className="button" onClick={() => setParams(new URLSearchParams())}>
              Clear filters
            </button>
          ) : null
        }
      />
      <p className="bk-muted">Every order placed in your shop. Click an order to manage it.</p>
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}

      <ul className="bk-shop-subnav">
        <li>
          <button type="button" className={status === 'all' ? 'is-current' : ''} onClick={() => setParam({ status: null })}>
            All <span className="bk-shop-subnav__count">({counts.all ?? 0})</span>
          </button>
          <span className="bk-shop-subnav__sep">|</span>
        </li>
        {STATUS_ORDER.map((s, i) => (
          <li key={s}>
            <button type="button" className={status === s ? 'is-current' : ''} onClick={() => setParam({ status: s })}>
              {statusLabel(s)} <span className="bk-shop-subnav__count">({counts[s] ?? 0})</span>
            </button>
            {i < STATUS_ORDER.length - 1 ? <span className="bk-shop-subnav__sep">|</span> : null}
          </li>
        ))}
      </ul>

      <form className="bk-shop-toolbar" onSubmit={onSearch}>
        <input
          className="regular-text"
          type="search"
          placeholder="Search order number, email or name…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          aria-label="Search orders"
        />
        <button type="submit" className="button">
          Search
        </button>
        <select value={payment} onChange={(e) => setParam({ payment: e.target.value })} aria-label="Payment method">
          <option value="">All payment methods</option>
          {(meta?.paymentMethods ?? []).map((m) => (
            <option key={m.id} value={m.id}>
              {m.title}
            </option>
          ))}
        </select>
        {customerId ? (
          <span className="bk-shop-filter-chip">
            Showing orders for {customer?.email ?? 'this customer'}
            <button type="button" onClick={() => setParam({ customerId: null })} aria-label="Clear customer filter">
              ✕
            </button>
          </span>
        ) : null}
        <span className="bk-shop-toolbar__spacer" />
        {data ? <span className="bk-shop-toolbar__count">{data.total} {data.total === 1 ? 'order' : 'orders'}</span> : null}
      </form>

      <div className="bk-shop-table-wrap">
        <table className="bk-shop-table">
          <thead>
            <tr>
              <th scope="col">Order</th>
              <th scope="col">Date</th>
              <th scope="col">Status</th>
              <th scope="col">Payment</th>
              <th scope="col">Shipping</th>
              <th scope="col" className="is-right">
                Items
              </th>
              <th scope="col" className="is-right">
                Total
              </th>
            </tr>
          </thead>
          <tbody>
            {loading && !data ? (
              <tr>
                <td colSpan={7} className="bk-shop-table__empty">
                  Loading…
                </td>
              </tr>
            ) : rows.length === 0 ? (
              <tr>
                <td colSpan={7} className="bk-shop-table__empty">
                  {hasFilters ? 'No orders match these filters.' : 'No orders yet. They appear here as soon as someone checks out.'}
                </td>
              </tr>
            ) : (
              rows.map((o) => (
                <tr key={o.id} className="is-clickable" onClick={() => navigate(href(`shop/orders/${o.id}`))}>
                  <td>
                    <Link className="bk-shop-table__primary" to={href(`shop/orders/${o.id}`)} onClick={(e) => e.stopPropagation()}>
                      {o.numberLabel} {o.customerName}
                    </Link>
                    <span className="bk-shop-table__sub">{o.email}</span>
                  </td>
                  <td>{formatDate(o.placedAt)}</td>
                  <td>
                    <StatusPill status={o.status} label={o.statusLabel} />
                  </td>
                  <td>
                    {o.paymentMethodTitle}
                    <span className="bk-shop-table__sub">{PAYMENT_STATUS_LABELS[o.paymentStatus] ?? o.paymentStatus}</span>
                  </td>
                  <td>
                    <ShippingPill order={o} />
                  </td>
                  <td className="is-right">{o.itemCount}</td>
                  <td className="is-right bk-shop-money">
                    {o.formatted.total}
                    {o.refundedTotal > 0 ? <span className="bk-shop-table__sub">−{o.formatted.refundedTotal} refunded</span> : null}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      {data ? (
        <Pager page={data.page} pages={data.pages} total={data.total} perPage={data.perPage} onPage={(p) => setParam({ page: String(p) })} noun="orders" />
      ) : null}
    </div>
  );
}
