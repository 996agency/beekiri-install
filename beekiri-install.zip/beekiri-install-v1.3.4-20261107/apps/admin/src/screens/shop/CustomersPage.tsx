import { useEffect, useState, type FormEvent } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { api } from '../../api/client';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { useAdminHref } from '../../lib/AdminEntryContext';
import { buildQuery, formatDate, formatMoney, useShopMeta, type CustomerList } from './api';
import { formatError, Pager } from './OrdersPage';
import './shop.css';
import './orders.css';

export function CustomersPage() {
  const href = useAdminHref();
  const meta = useShopMeta();
  const [params, setParams] = useSearchParams();
  const q = params.get('q') ?? '';
  const page = Math.max(1, Number(params.get('page') ?? '1') || 1);
  const [search, setSearch] = useState(q);
  const [data, setData] = useState<CustomerList | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setSearch(q);
  }, [q]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api<CustomerList>(`/api/shop/customers${buildQuery({ q, page, perPage: 25 })}`)
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch((e) => {
        if (!cancelled) setError(formatError(e));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [q, page]);

  const setParam = (patch: Record<string, string | null>) => {
    const next = new URLSearchParams(params);
    for (const [k, v] of Object.entries(patch)) {
      if (v === null || v === '') next.delete(k);
      else next.set(k, v);
    }
    if (!('page' in patch)) next.delete('page');
    setParams(next);
  };

  const onSearch = (e: FormEvent) => {
    e.preventDefault();
    setParam({ q: search.trim() });
  };

  const rows = data?.items ?? [];

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Customers"
        actions={
          q ? (
            <button type="button" className="button" onClick={() => setParams(new URLSearchParams())}>
              Clear search
            </button>
          ) : null
        }
      />
      <p className="bk-muted">Everyone who has placed an order. Customers are grouped by email address.</p>
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}

      <form className="bk-shop-toolbar" onSubmit={onSearch}>
        <input
          className="regular-text"
          type="search"
          placeholder="Search name, email or phone…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          aria-label="Search customers"
        />
        <button type="submit" className="button">
          Search
        </button>
        <span className="bk-shop-toolbar__spacer" />
        {data ? <span className="bk-shop-toolbar__count">{data.total} {data.total === 1 ? 'customer' : 'customers'}</span> : null}
      </form>

      <div className="bk-shop-table-wrap">
        <table className="bk-shop-table">
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Phone</th>
              <th scope="col" className="is-right">
                Orders
              </th>
              <th scope="col" className="is-right">
                Total spent
              </th>
              <th scope="col">Last order</th>
              <th scope="col">
                <span className="screen-reader-text">Actions</span>
              </th>
            </tr>
          </thead>
          <tbody>
            {loading && !data ? (
              <tr>
                <td colSpan={7} className="bk-shop-table__empty">
                  Loading…
                </td>
              </tr>
            ) : rows.length === 0 ? (
              <tr>
                <td colSpan={7} className="bk-shop-table__empty">
                  {q ? 'No customers match your search.' : 'No customers yet. They are added automatically when an order is placed.'}
                </td>
              </tr>
            ) : (
              rows.map((c) => (
                <tr key={c.id}>
                  <td>
                    <Link className="bk-shop-table__primary" to={href(`shop/orders?customerId=${encodeURIComponent(c.id)}`)}>
                      {c.name}
                      {c.hasAccount ? (
                        <span className={`bk-shop-pill is-${c.emailVerified ? 'ok' : 'warn'} bk-shop-account-pill`} title={c.emailVerified ? 'Has a My account login' : 'Account created, email not confirmed yet'}>
                          {c.emailVerified ? 'Account' : 'Account · unverified'}
                        </span>
                      ) : null}
                    </Link>
                    <span className="bk-shop-table__sub">Since {formatDate(c.createdAt, false)}</span>
                  </td>
                  <td>
                    <span className="bk-shop-email">{c.email}</span>
                  </td>
                  <td>{c.phone || <span className="bk-muted">—</span>}</td>
                  <td className="is-right">{c.ordersCount}</td>
                  <td className="is-right bk-shop-money">{formatMoney(c.totalSpent, meta)}</td>
                  <td>
                    {c.lastOrderAt ? formatDate(c.lastOrderAt) : <span className="bk-muted">—</span>}
                    {c.hasAccount && c.lastLoginAt ? <span className="bk-shop-table__sub">Last sign-in {formatDate(c.lastLoginAt)}</span> : null}
                  </td>
                  <td className="is-right">
                    <Link to={href(`shop/orders?customerId=${encodeURIComponent(c.id)}`)}>View orders</Link>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      {data ? (
        <Pager page={data.page} pages={data.pages} total={data.total} perPage={data.perPage} onPage={(p) => setParam({ page: String(p) })} noun="customers" />
      ) : null}
    </div>
  );
}
