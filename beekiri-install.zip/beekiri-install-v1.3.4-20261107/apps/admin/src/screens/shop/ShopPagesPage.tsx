import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowSquareOut, PencilSimple } from '@phosphor-icons/react';
import { api } from '../../api/client';
import { useAuth } from '../../auth/AuthContext';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { useAdminHref } from '../../lib/AdminEntryContext';
import { SITE_URL } from '../../config';
import { formatDate, shopError, type ShopPageOptions, type ShopPageRow, type ShopSettingsResponse } from './api';
import './shop.css';
import './products.css';

const PATH_PREVIEW: Record<ShopPageRow['view'], string> = {
  shop: '/shop',
  product: '/shop',
  cart: '/cart',
  checkout: '/checkout',
  'order-received': '/checkout',
  account: '/account',
};

const BLURB: Record<ShopPageRow['view'], string> = {
  shop: 'The product archive — grid, categories, search and sorting.',
  product: 'Every single product page: gallery, price, add to cart, details.',
  cart: 'The basket with quantities, coupons and totals.',
  checkout: 'Addresses, shipping, payment and the Place order button.',
  'order-received': 'The thank-you page after an order, with payment instructions.',
  account: 'My account: sign in, order history with tracking, addresses and details.',
};

type OptionDef = { key: string; label: string; type: 'boolean' | 'columns' };
const OPTIONS: Record<keyof ShopPageOptions, OptionDef[]> = {
  shop: [
    { key: 'columns', label: 'Products per row', type: 'columns' },
    { key: 'showSidebar', label: 'Category sidebar', type: 'boolean' },
    { key: 'showSearch', label: 'Search box', type: 'boolean' },
    { key: 'showSort', label: 'Sorting dropdown', type: 'boolean' },
    { key: 'showResultCount', label: 'Result count', type: 'boolean' },
    { key: 'showBreadcrumbs', label: 'Breadcrumbs', type: 'boolean' },
  ],
  product: [
    { key: 'showBreadcrumbs', label: 'Breadcrumbs', type: 'boolean' },
    { key: 'showGalleryThumbs', label: 'Gallery thumbnails', type: 'boolean' },
    { key: 'showMeta', label: 'SKU, categories and tags', type: 'boolean' },
    { key: 'showAdditionalInfo', label: '“Additional information” tab', type: 'boolean' },
    { key: 'showRelated', label: 'Related products', type: 'boolean' },
  ],
  cart: [
    { key: 'showCoupon', label: 'Coupon form', type: 'boolean' },
    { key: 'showContinueShopping', label: '“Continue shopping” link', type: 'boolean' },
  ],
  checkout: [{ key: 'showOrderSummaryImages', label: 'Product images in the order summary', type: 'boolean' }],
};

/** Shop → Shop Editor: design each storefront page in BeekiriCode and switch its parts on or off. */
export function ShopPagesPage() {
  const href = useAdminHref();
  const auth = useAuth();
  const canManage = auth.user?.capabilities.includes('manage_shop') ?? false;
  const [pages, setPages] = useState<ShopPageRow[] | null>(null);
  const [settings, setSettings] = useState<ShopSettingsResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [p, s] = await Promise.all([
        api<{ pages: ShopPageRow[] }>('/api/shop/pages'),
        canManage ? api<ShopSettingsResponse>('/api/shop/settings') : Promise.resolve(null),
      ]);
      setPages(p.pages);
      setSettings(s);
    } catch (e) {
      setError(shopError(e));
    }
  }, [canManage]);
  useEffect(() => {
    void load();
  }, [load]);

  const reset = async (row: ShopPageRow) => {
    const ok = await confirmDialog({
      title: `Reset “${row.title}” to the default design?`,
      message: 'Everything you added around the shop content on this page is removed. The shop content itself is never affected.',
      confirmLabel: 'Reset page',
      danger: true,
    });
    if (!ok) return;
    setBusy(row.view);
    try {
      const res = await api<{ pages: ShopPageRow[] }>(`/api/shop/pages/${row.view}/reset`, { method: 'POST', json: {} });
      setPages(res.pages);
      setNotice(`“${row.title}” reset.`);
    } catch (e) {
      setError(shopError(e));
    } finally {
      setBusy(null);
    }
  };

  const saveOption = async (view: keyof ShopPageOptions, key: string, value: boolean | number) => {
    if (!settings) return;
    const next: ShopSettingsResponse['settings'] = {
      ...settings.settings,
      pages: { ...settings.settings.pages, [view]: { ...settings.settings.pages[view], [key]: value } },
    };
    setSettings({ ...settings, settings: next });
    try {
      const saved = await api<ShopSettingsResponse>('/api/shop/settings', { method: 'PUT', json: next });
      setSettings(saved);
    } catch (e) {
      setError(shopError(e));
      void load();
    }
  };

  return (
    <div className="wrap wrap--wide">
      <PageHeader title="Shop Editor" />
      <p className="bk-muted">
        Each storefront page is a BeekiriCode page with a <strong>Shop content</strong> block in the middle. Add headings, text, images, theme layouts — anything — above or below it, exactly like a normal page. The parts of the shop content itself are switched on or off here.
      </p>
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      {!pages ? (
        <p className="bk-muted">Loading…</p>
      ) : (
        <div className="bk-stack">
          {pages.map((row) => {
            const optionKey = (row.view === 'order-received' ? 'checkout' : row.view) as keyof ShopPageOptions;
            const opts = row.view === 'account' ? undefined : settings?.settings.pages[optionKey];
            return (
              <section key={row.view} className="bk-panel bk-shop-page">
                <div className="bk-panel__head bk-shop-page__head">
                  <div>
                    <h2 className="bk-panel__title">
                      {row.title}
                      {row.customised ? <span className="bk-table__badge is-accent">Customised</span> : <span className="bk-table__badge">Default design</span>}
                    </h2>
                    <p className="bk-shop-page__blurb">
                      {BLURB[row.view]} <code>{row.path}</code>
                      {row.updatedAt && row.customised ? <span className="bk-muted"> · edited {formatDate(row.updatedAt)}</span> : null}
                    </p>
                  </div>
                  <div className="bk-shop-inline">
                    <a className="button" href={`${SITE_URL}${PATH_PREVIEW[row.view]}`} target="_blank" rel="noopener noreferrer">
                      View <ArrowSquareOut size={13} aria-hidden />
                    </a>
                    {row.customised ? (
                      <button type="button" className="button" disabled={busy === row.view} onClick={() => void reset(row)}>
                        Reset
                      </button>
                    ) : null}
                    {row.id ? (
                      <Link className="button button-primary" to={href(`shop/pages/${row.id}`)}>
                        <PencilSimple size={14} aria-hidden /> Edit with BeekiriCode
                      </Link>
                    ) : null}
                  </div>
                </div>
                {opts && row.view !== 'order-received' ? (
                  <div className="bk-panel__body bk-shop-page__options">
                    {OPTIONS[optionKey].map((def) => (
                      <label key={def.key} className="bk-shop-page__option">
                        {def.type === 'columns' ? (
                          <>
                            <span>{def.label}</span>
                            <select value={Number((opts as Record<string, unknown>)[def.key] ?? 3)} onChange={(e) => void saveOption(optionKey, def.key, Number(e.target.value))}>
                              <option value={2}>2</option>
                              <option value={3}>3</option>
                              <option value={4}>4</option>
                            </select>
                          </>
                        ) : (
                          <>
                            <input type="checkbox" checked={Boolean((opts as Record<string, unknown>)[def.key])} onChange={(e) => void saveOption(optionKey, def.key, e.target.checked)} />
                            <span>{def.label}</span>
                          </>
                        )}
                      </label>
                    ))}
                  </div>
                ) : null}
              </section>
            );
          })}
        </div>
      )}
    </div>
  );
}
