import { useEffect, useMemo, useState } from 'react';
import {
  ArrowSquareOut,
  CaretLeft,
  CaretRight,
  DownloadSimple,
  Faders,
  FolderSimple,
} from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { safeHref } from '../lib/safe-html';

type SeriesPoint = { date: string; label: string; value: number };

type BacklinkRow = {
  sourceHost: string;
  sourceUrl: string;
  targetPath: string;
  anchor: string;
  flags: string[];
  linkCount: number | null;
  da: number | null;
  spam: number | null;
  firstSeen: string | null;
};

type ReferringDomainRow = {
  host: string;
  backlinks: number | null;
  da: number | null;
  spam: number | null;
  firstSeen: string | null;
};

type TopPageRow = {
  path: string;
  backlinks: number | null;
  referringDomains: number | null;
};

type BacklinksResult = {
  domain: string;
  metrics: {
    backlinks: number | null;
    referringDomains: number | null;
    referringPages: number | null;
    rank: number | null;
    backlinkSpamScore: number | null;
    brokenBacklinks: number | null;
    brokenPages: number | null;
    targetSpamScore: number | null;
  };
  growth: {
    backlinks: SeriesPoint[];
    referringDomains: SeriesPoint[];
  };
  attrition: {
    newBacklinks: SeriesPoint[];
    lostBacklinks: SeriesPoint[];
  };
  links: BacklinkRow[];
  referringDomains: ReferringDomainRow[];
  topPages: TopPageRow[];
};

type Tab = 'links' | 'domains' | 'pages';
type LinkMode = 'one' | 'all';

const PAGE_SIZES = [25, 50, 100];

function dash(n: number | null | undefined, digits = 0): string {
  if (n == null) return '—';
  if (digits > 0) return n.toFixed(digits);
  return Intl.NumberFormat('en-US').format(n);
}

function formatDate(iso: string | null): string {
  if (!iso) return '—';
  const t = Date.parse(iso);
  if (!Number.isFinite(t)) return iso;
  return new Date(t).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

function exportCsv(filename: string, headers: string[], rows: string[][]) {
  const esc = (v: string) => `"${v.replace(/"/g, '""')}"`;
  const body = [headers, ...rows].map((r) => r.map(esc).join(',')).join('\n');
  const blob = new Blob([body], { type: 'text/csv;charset=utf-8' });
  const href = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = href;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(href);
}

function DualLineChart({
  title,
  a,
  b,
  aLabel,
  bLabel,
  aClass,
  bClass,
}: {
  title: string;
  a: SeriesPoint[];
  b: SeriesPoint[];
  aLabel: string;
  bLabel: string;
  aClass: string;
  bClass: string;
}) {
  const w = 420;
  const h = 180;
  const pad = { t: 16, r: 12, b: 28, l: 36 };
  const n = Math.max(a.length, b.length, 2);
  const max = Math.max(1, ...a.map((p) => p.value), ...b.map((p) => p.value));
  const x = (i: number) => pad.l + (i / Math.max(1, n - 1)) * (w - pad.l - pad.r);
  const y = (v: number) => pad.t + (1 - v / max) * (h - pad.t - pad.b);

  function path(series: SeriesPoint[]) {
    if (!series.length) return '';
    return series
      .map((p, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)} ${y(p.value).toFixed(1)}`)
      .join(' ');
  }

  const ticks = [0, 0.5, 1].map((t) => Math.round(max * t));
  const labels = a.length ? a : b;
  const labelIdx = [0, Math.floor((n - 1) / 2), n - 1].filter((v, i, arr) => arr.indexOf(v) === i);

  return (
    <div className="bk-bl__chart-card">
      <p className="bk-bl__chart-title">{title}</p>
      <div className="bk-bl__legend">
        <span className={`bk-bl__leg ${aClass}`}>{aLabel}</span>
        <span className={`bk-bl__leg ${bClass}`}>{bLabel}</span>
      </div>
      <svg className="bk-bl__chart" viewBox={`0 0 ${w} ${h}`} role="img" aria-label={title}>
        {ticks.map((tv) => {
          const yy = y(tv);
          return (
            <g key={tv}>
              <line x1={pad.l} x2={w - pad.r} y1={yy} y2={yy} className="bk-bl__grid" />
              <text x={pad.l - 6} y={yy + 3} textAnchor="end" className="bk-bl__tick">
                {tv}
              </text>
            </g>
          );
        })}
        <path d={path(a)} className={`bk-bl__line ${aClass}`} />
        <path d={path(b)} className={`bk-bl__line ${bClass}`} />
        {labelIdx.map((i) => (
          <text key={i} x={x(i)} y={h - 8} textAnchor="middle" className="bk-bl__tick">
            {labels[i]?.label ?? ''}
          </text>
        ))}
      </svg>
    </div>
  );
}

export function BacklinksPanel() {
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<BacklinksResult | null>(null);
  const [tab, setTab] = useState<Tab>('links');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [bestLinks, setBestLinks] = useState(true);
  const [linkMode, setLinkMode] = useState<LinkMode>('one');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  useEffect(() => {
    let cancelled = false;
    setBusy(true);
    setError(null);
    api<BacklinksResult>('/api/bee-seo/backlinks')
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch((err) => {
        if (!cancelled) {
          setError(err instanceof ApiError || err instanceof Error ? err.message : 'Could not load backlinks.');
        }
      })
      .finally(() => {
        if (!cancelled) setBusy(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const filteredLinks = useMemo(() => {
    const q = query.trim().toLowerCase();
    let rows = data?.links ?? [];
    if (linkMode === 'one') {
      const seen = new Set<string>();
      rows = rows.filter((r) => {
        if (seen.has(r.sourceHost)) return false;
        seen.add(r.sourceHost);
        return true;
      });
    }
    if (bestLinks) {
      rows = [...rows].sort((a, b) => (b.da ?? -1) - (a.da ?? -1));
    }
    if (!q) return rows;
    return rows.filter(
      (r) =>
        r.sourceHost.toLowerCase().includes(q) ||
        r.anchor.toLowerCase().includes(q) ||
        r.targetPath.toLowerCase().includes(q),
    );
  }, [data?.links, query, linkMode, bestLinks]);

  const filteredDomains = useMemo(() => {
    const q = query.trim().toLowerCase();
    const rows = data?.referringDomains ?? [];
    if (!q) return rows;
    return rows.filter((r) => r.host.toLowerCase().includes(q));
  }, [data?.referringDomains, query]);

  const filteredPages = useMemo(() => {
    const q = query.trim().toLowerCase();
    const rows = data?.topPages ?? [];
    if (!q) return rows;
    return rows.filter((r) => r.path.toLowerCase().includes(q));
  }, [data?.topPages, query]);

  const listLen =
    tab === 'links' ? filteredLinks.length : tab === 'domains' ? filteredDomains.length : filteredPages.length;
  const totalPages = Math.max(1, Math.ceil(listLen / pageSize));
  const safePage = Math.min(page, totalPages);
  const from = listLen === 0 ? 0 : (safePage - 1) * pageSize + 1;
  const to = Math.min(safePage * pageSize, listLen);

  const pagedLinks = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filteredLinks.slice(start, start + pageSize);
  }, [filteredLinks, safePage, pageSize]);

  const pagedDomains = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filteredDomains.slice(start, start + pageSize);
  }, [filteredDomains, safePage, pageSize]);

  const pagedPages = useMemo(() => {
    const start = (safePage - 1) * pageSize;
    return filteredPages.slice(start, start + pageSize);
  }, [filteredPages, safePage, pageSize]);

  useEffect(() => {
    setPage(1);
  }, [tab, query, pageSize, linkMode, bestLinks]);

  useEffect(() => {
    if (page !== safePage) setPage(safePage);
  }, [page, safePage]);

  function onExport() {
    if (tab === 'links') {
      exportCsv(
        'beekiri-backlinks.csv',
        ['Source', 'Target', 'Anchor', 'Flags', 'Link', 'DA', 'Spam', 'First Seen'],
        filteredLinks.map((r) => [
          r.sourceUrl || r.sourceHost,
          r.targetPath,
          r.anchor,
          r.flags.join('; '),
          r.linkCount == null ? '' : String(r.linkCount),
          r.da == null ? '' : String(r.da),
          r.spam == null ? '' : String(r.spam),
          r.firstSeen ?? '',
        ]),
      );
      return;
    }
    if (tab === 'domains') {
      exportCsv(
        'beekiri-referring-domains.csv',
        ['Domain', 'Backlinks', 'DA', 'Spam', 'First Seen'],
        filteredDomains.map((r) => [
          r.host,
          r.backlinks == null ? '' : String(r.backlinks),
          r.da == null ? '' : String(r.da),
          r.spam == null ? '' : String(r.spam),
          r.firstSeen ?? '',
        ]),
      );
      return;
    }
    exportCsv(
      'beekiri-backlink-pages.csv',
      ['Page', 'Backlinks', 'Referring Domains'],
      filteredPages.map((r) => [
        r.path,
        r.backlinks == null ? '' : String(r.backlinks),
        r.referringDomains == null ? '' : String(r.referringDomains),
      ]),
    );
  }

  if (busy && !data) {
    return (
      <div className="bk-seo__loading">
        <div className="bk-seo__spinner" aria-hidden />
        <p>Loading backlinks…</p>
      </div>
    );
  }

  if (error && !data) {
    return <p className="bk-seo__banner is-error">{error}</p>;
  }

  if (!data) return null;

  const m = data.metrics;
  const emptyLabel =
    tab === 'links'
      ? 'No backlinks match this search.'
      : tab === 'domains'
        ? 'No referring domains match this search.'
        : 'No pages match this search.';

  return (
    <div className="bk-bl">
      <header className="bk-bl__head">
        <h2 className="bk-bl__domain">{data.domain}</h2>
      </header>

      <div className="bk-bl__top">
        <div className="bk-bl__metrics">
          <table>
            <tbody>
              <tr>
                <td>Backlinks</td>
                <td>{dash(m.backlinks)}</td>
              </tr>
              <tr>
                <td>Referring Domains</td>
                <td>{dash(m.referringDomains)}</td>
              </tr>
              <tr>
                <td>Referring Pages</td>
                <td>{dash(m.referringPages)}</td>
              </tr>
              <tr>
                <td>Rank</td>
                <td>{dash(m.rank)}</td>
              </tr>
              <tr>
                <td>Backlink Spam Score</td>
                <td>{dash(m.backlinkSpamScore, 1)}</td>
              </tr>
              <tr>
                <td>Broken Backlinks</td>
                <td>{dash(m.brokenBacklinks)}</td>
              </tr>
              <tr>
                <td>Broken Pages</td>
                <td>{dash(m.brokenPages)}</td>
              </tr>
              <tr>
                <td>Target Spam Score</td>
                <td>{dash(m.targetSpamScore, 1)}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <DualLineChart
          title="Backlinks and referring domains over the last year."
          a={data.growth.backlinks}
          b={data.growth.referringDomains}
          aLabel="Backlinks"
          bLabel="Referring domains"
          aClass="is-a"
          bClass="is-b"
        />

        <DualLineChart
          title="Backlink acquisition and attrition."
          a={data.attrition.newBacklinks}
          b={data.attrition.lostBacklinks}
          aLabel="New backlinks"
          bLabel="Lost backlinks"
          aClass="is-a"
          bClass="is-lost"
        />
      </div>

      <div className="bk-bl__board">
        <div className="bk-tabs is-flush" role="tablist" aria-label="Backlink views">
          {(
            [
              ['links', 'Backlinks'],
              ['domains', 'Referring Domains'],
              ['pages', 'Top Pages'],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={tab === id}
              className={`bk-tabs__item${tab === id ? ' is-active' : ''}`}
              onClick={() => setTab(id)}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="bk-bl__toolbar">
          <div className="bk-bl__toolbar-left">
            <button
              type="button"
              className={`button${filtersOpen || query ? ' button-primary' : ''}`}
              onClick={() => setFiltersOpen((v) => !v)}
              aria-label="Filters"
            >
              <Faders size={16} weight="regular" aria-hidden />
            </button>
            {tab === 'links' ? (
              <>
                <label className="bk-bl__select">
                  Best links:
                  <select
                    value={bestLinks ? 'on' : 'off'}
                    onChange={(e) => setBestLinks(e.target.value === 'on')}
                  >
                    <option value="on">On</option>
                    <option value="off">Off</option>
                  </select>
                </label>
                <div className="bk-bl__seg" role="group" aria-label="Link grouping">
                  <button
                    type="button"
                    className={linkMode === 'one' ? 'is-active' : ''}
                    onClick={() => setLinkMode('one')}
                  >
                    One per domain
                  </button>
                  <button
                    type="button"
                    className={linkMode === 'all' ? 'is-active' : ''}
                    onClick={() => setLinkMode('all')}
                  >
                    All links
                  </button>
                </div>
              </>
            ) : null}
          </div>
          <button type="button" className="button" onClick={onExport} disabled={!listLen}>
            <DownloadSimple size={16} weight="regular" aria-hidden />
            Export
          </button>
        </div>

        {filtersOpen ? (
          <div className="bk-bl__filters">
            <input
              type="search"
              className="bk-bl__filter-input"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={
                tab === 'links'
                  ? 'Filter backlinks…'
                  : tab === 'domains'
                    ? 'Filter domains…'
                    : 'Filter pages…'
              }
            />
          </div>
        ) : null}

        <div className="bk-bl__table-wrap">
          {tab === 'links' ? (
            <table className="bk-bl__table">
              <thead>
                <tr>
                  <th>Source</th>
                  <th>Target</th>
                  <th>Anchor</th>
                  <th>Flags</th>
                  <th>Link</th>
                  <th>DA</th>
                  <th>Spam</th>
                  <th>First Seen</th>
                </tr>
              </thead>
              <tbody>
                {pagedLinks.length === 0 ? (
                  <tr>
                    <td colSpan={8}>
                      <div className="bk-bl__empty">
                        <FolderSimple size={28} weight="regular" aria-hidden />
                        <p>{emptyLabel}</p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  pagedLinks.map((r) => (
                    <tr key={`${r.sourceUrl}-${r.targetPath}-${r.anchor}`}>
                      <td>
                        <a
                          className="bk-bl__source"
                          href={safeHref(r.sourceUrl || `https://${r.sourceHost}`)}
                          target="_blank"
                          rel="noreferrer"
                        >
                          {r.sourceHost}
                          <ArrowSquareOut size={12} weight="regular" aria-hidden />
                        </a>
                      </td>
                      <td>
                        <span className="bk-bl__path">{r.targetPath}</span>
                      </td>
                      <td className="bk-bl__anchor">{r.anchor || '—'}</td>
                      <td>
                        <div className="bk-bl__flags">
                          {r.flags.map((f) => (
                            <span key={f} className="bk-bl__flag">
                              {f}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td>{dash(r.linkCount)}</td>
                      <td>{dash(r.da)}</td>
                      <td>{dash(r.spam)}</td>
                      <td>{formatDate(r.firstSeen)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          ) : null}

          {tab === 'domains' ? (
            <table className="bk-bl__table">
              <thead>
                <tr>
                  <th>Domain</th>
                  <th>Backlinks</th>
                  <th>DA</th>
                  <th>Spam</th>
                  <th>First Seen</th>
                </tr>
              </thead>
              <tbody>
                {pagedDomains.length === 0 ? (
                  <tr>
                    <td colSpan={5}>
                      <div className="bk-bl__empty">
                        <FolderSimple size={28} weight="regular" aria-hidden />
                        <p>{emptyLabel}</p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  pagedDomains.map((r) => (
                    <tr key={r.host}>
                      <td>
                        <a
                          className="bk-bl__source"
                          href={`https://${r.host}`}
                          target="_blank"
                          rel="noreferrer"
                        >
                          {r.host}
                          <ArrowSquareOut size={12} weight="regular" aria-hidden />
                        </a>
                      </td>
                      <td>{dash(r.backlinks)}</td>
                      <td>{dash(r.da)}</td>
                      <td>{dash(r.spam)}</td>
                      <td>{formatDate(r.firstSeen)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          ) : null}

          {tab === 'pages' ? (
            <table className="bk-bl__table">
              <thead>
                <tr>
                  <th>Page</th>
                  <th>Backlinks</th>
                  <th>Referring Domains</th>
                </tr>
              </thead>
              <tbody>
                {pagedPages.length === 0 ? (
                  <tr>
                    <td colSpan={3}>
                      <div className="bk-bl__empty">
                        <FolderSimple size={28} weight="regular" aria-hidden />
                        <p>{emptyLabel}</p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  pagedPages.map((r) => (
                    <tr key={r.path}>
                      <td>
                        <span className="bk-bl__path">{r.path}</span>
                      </td>
                      <td>{dash(r.backlinks)}</td>
                      <td>{dash(r.referringDomains)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          ) : null}
        </div>

        <div className="bk-bl__pager">
          <span>
            {listLen === 0 ? `1–${pageSize}` : `${from}–${to} of ${listLen}`}
          </span>
          <div className="bk-bl__pager-right">
            <label className="bk-bl__pagesize">
              Rows per page
              <select value={pageSize} onChange={(e) => setPageSize(Number(e.target.value))}>
                {PAGE_SIZES.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </label>
            <span>
              Page {safePage} of {totalPages}
            </span>
            <button
              type="button"
              className="button"
              disabled={safePage <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              aria-label="Previous page"
            >
              <CaretLeft size={14} weight="bold" />
            </button>
            <button
              type="button"
              className="button"
              disabled={safePage >= totalPages}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              aria-label="Next page"
            >
              <CaretRight size={14} weight="bold" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
