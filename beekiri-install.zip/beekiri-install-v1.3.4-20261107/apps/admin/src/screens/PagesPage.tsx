import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import {
  AdminDataTable,
  hasActiveAdminFilters,
  type AdminTableColumn,
  type AdminTableFilter,
} from '../components/AdminDataTable';
import { confirmDialog } from '../components/ConfirmDialog';
import {
  lighthouseScoreTone,
  readStoredLighthouseScores,
  writeStoredLighthouseScores,
} from '../components/LighthouseToolbar';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import {
  contentKindConfig,
  type ContentKind,
  type ContentKindConfig,
  type CptLabels,
} from '../content/contentKind';
import { useCptMeta } from '../content/useCptMeta';
import { useAdminEntry, useAdminHref } from '../lib/AdminEntryContext';
import { SITE_URL as LIVE_SITE } from '../config';
import { ErrorNotice } from '../components/ErrorNotice';

export type PageRow = {
  id: string;
  title: string;
  slug: string;
  status: 'auto-draft' | 'draft' | 'publish' | 'trash';
  content: string;
  beekiricanva?: unknown | null;
  /** BeekiriCode page tree (preferred). */
  beekiricode?: unknown | null;
  /** @deprecated Legacy key — read via beekiricode when present. */
  instatic?: unknown | null;
  excerpt: string;
  featuredImageId?: string | null;
  /** Per-page SEO settings (null = defaults). */
  seo?: Record<string, unknown> | null;
  authorId?: string | null;
  authorName?: string | null;
  updatedById?: string | null;
  updatedByName?: string | null;
  revisionCount?: number;
  /** List only: the theme whose demo content added this post (parked while that theme is off). */
  themeName?: string | null;
  parentId?: string | null;
  path: string;
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
};

export type PageRevisionRow = {
  id: string;
  title: string;
  slug: string;
  status: string;
  authorId: string | null;
  authorName: string | null;
  createdAt: string;
};

type ListView = 'all' | 'trash';

const EMPTY_FILTERS = { title: '', status: '' };

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

function displayTitle(row: PageRow) {
  const t = row.title.trim();
  return t || '(no title)';
}

function ContentListPage({ kind, labels }: { kind: ContentKind; labels?: CptLabels }) {
  const { basePath } = useAdminEntry();
  const cfg = contentKindConfig(kind, labels, basePath);
  const auth = useAuth();
  const navigate = useNavigate();
  const canEdit = auth.user?.capabilities.includes(cfg.editCap) ?? false;
  const canDelete = auth.user?.capabilities.includes(cfg.deleteCap) ?? false;

  const [view, setView] = useState<ListView>('all');
  const [rows, setRows] = useState<PageRow[]>([]);
  const [counts, setCounts] = useState({ all: 0, trash: 0 });
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [filterValues, setFilterValues] = useState(EMPTY_FILTERS);
  const [pagespeed, setPagespeed] = useState<number | null>(() => {
    if (typeof window === 'undefined') return null;
    const stored = readStoredLighthouseScores();
    return stored && stored.source !== 'error' ? stored.performance : null;
  });
  const canReadHive = auth.user?.capabilities.includes('manage_options') ?? false;

  const load = useCallback(async () => {
    const q = view === 'trash' ? '?status=trash' : '';
    const res = await api<
      Record<string, PageRow[]> & { counts?: { all: number; trash: number } }
    >(`${cfg.apiBase}${q}`);
    setRows(res[cfg.listKey] ?? []);
    if (res.counts) setCounts(res.counts);
  }, [cfg.apiBase, cfg.listKey, view]);

  useEffect(() => {
    if (!canEdit) {
      setLoading(false);
      return;
    }
    setLoading(true);
    load()
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [canEdit, load]);

  useEffect(() => {
    if (!canReadHive || pagespeed !== null) return;
    let cancelled = false;
    (async () => {
      try {
        const data = await api<{
          performance: number;
          accessibility: number;
          bestPractices: number;
          seo: number;
          url: string;
          checkedAt: string;
          source: 'lighthouse' | 'cached' | 'error';
          message: string;
          allHundred: boolean;
        }>('/api/system/lighthouse');
        if (cancelled || data.source === 'error') return;
        writeStoredLighthouseScores(data);
        setPagespeed(data.performance);
      } catch {
        /* Hive status optional on this list */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [canReadHive, pagespeed]);

  const addNew = async () => {
    if (!canEdit || creating || view === 'trash') return;
    setCreating(true);
    setError(null);
    try {
      const row = await api<PageRow>(cfg.apiBase, {
        method: 'POST',
        json: { title: '', status: 'draft' },
      });
      navigate(`${cfg.listPath}/${row.id}`);
    } catch (e) {
      setError(formatError(e));
      setCreating(false);
    }
  };

  const onTrash = async (row: PageRow) => {
    if (!canDelete) return;
    const ok = await confirmDialog({
      title: 'Move to trash',
      message: `Move “${displayTitle(row)}” to trash? You can restore it later.`,
      confirmLabel: 'Move to trash',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    setError(null);
    try {
      await api(`${cfg.apiBase}/${row.id}`, { method: 'DELETE' });
      setNotice(`${cfg.label} “${displayTitle(row)}” moved to trash.`);
      await load();
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const onRestore = async (row: PageRow) => {
    if (!canDelete) return;
    setBusy(true);
    setError(null);
    try {
      await api(`${cfg.apiBase}/${row.id}/restore`, { method: 'POST' });
      setNotice(`${cfg.label} “${displayTitle(row)}” restored as a draft.`);
      await load();
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const onDeleteForever = async (row: PageRow) => {
    if (!canDelete) return;
    const ok = await confirmDialog({
      title: 'Delete permanently',
      message: `Permanently delete “${displayTitle(row)}”? This cannot be undone.`,
      confirmLabel: 'Delete permanently',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    setError(null);
    try {
      await api(`${cfg.apiBase}/${row.id}?force=1`, { method: 'DELETE' });
      setNotice(`${cfg.label} “${displayTitle(row)}” permanently deleted.`);
      await load();
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const filters: AdminTableFilter[] = useMemo(
    () => [
      { key: 'title', label: 'Title', type: 'text', placeholder: 'Search title…' },
      ...(view === 'all'
        ? [
            {
              key: 'status',
              label: 'Status',
              type: 'select' as const,
              allLabel: 'All statuses',
              options: [
                { value: 'publish', label: 'Published' },
                { value: 'draft', label: 'Draft' },
              ],
            },
          ]
        : []),
    ],
    [view],
  );

  const columns: AdminTableColumn<PageRow>[] = useMemo(
    () => [
      {
        key: 'title',
        header: 'Title',
        render: (row) => (
          <>
            <strong className="bk-table__primary">{displayTitle(row)}</strong>
            {view === 'all' && row.status === 'draft' ? (
              <span className="bk-table__badge">Draft</span>
            ) : null}
            {view === 'all' && row.status === 'publish' ? (
              <span className="bk-table__badge is-accent">Published</span>
            ) : null}
            {row.themeName ? (
              <span
                className="bk-table__badge is-theme"
                title={`Added by the ${row.themeName} theme. It is a draft while ${row.themeName} is not the active theme, and comes back when you switch to it.`}
              >
                Theme: {row.themeName}
              </span>
            ) : null}
            <div className="bk-table__row-actions" onClick={(e) => e.stopPropagation()}>
              {view === 'all' ? (
                <>
                  {canEdit ? (
                    <Link className="button-link" to={`${cfg.listPath}/${row.id}`}>
                      Edit
                    </Link>
                  ) : null}
                  {canEdit && canDelete ? <span className="bk-table__sep">|</span> : null}
                  {canDelete ? (
                    <button
                      type="button"
                      className="button-link is-danger"
                      disabled={busy}
                      onClick={() => void onTrash(row)}
                    >
                      Trash
                    </button>
                  ) : null}
                  {row.status === 'publish' ? (
                    <>
                      <span className="bk-table__sep">|</span>
                      <a
                        className="button-link"
                        href={`${LIVE_SITE}${row.path}`}
                        target="_blank"
                        rel="noreferrer"
                      >
                        View
                      </a>
                    </>
                  ) : null}
                </>
              ) : canDelete ? (
                <>
                  <button
                    type="button"
                    className="button-link"
                    disabled={busy}
                    onClick={() => void onRestore(row)}
                  >
                    Restore
                  </button>
                  <span className="bk-table__sep">|</span>
                  <button
                    type="button"
                    className="button-link is-danger"
                    disabled={busy}
                    onClick={() => void onDeleteForever(row)}
                  >
                    Delete permanently
                  </button>
                </>
              ) : null}
            </div>
          </>
        ),
      },
      {
        key: 'slug',
        header: 'Slug',
        render: (row) => <code>{row.slug}</code>,
      },
      {
        key: 'created',
        header: 'Created',
        render: (row) => formatDate(row.createdAt),
      },
      {
        key: 'updated',
        header: 'Last updated',
        render: (row) => formatDate(row.updatedAt),
      },
      {
        key: 'pagespeed',
        header: 'PageSpeed',
        render: (row) => {
          if (row.status !== 'publish' || pagespeed === null) {
            return <span className="bk-table__muted">—</span>;
          }
          const score = Math.round(pagespeed);
          return (
            <span
              className={`bk-table__pagespeed ${lighthouseScoreTone(score)}`}
              title="Site PageSpeed from Hive status (out of 100)"
            >
              {score}/100
            </span>
          );
        },
      },
    ],
    [busy, canDelete, canEdit, cfg.listPath, pagespeed, view],
  );

  if (!canEdit) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title={cfg.labelPlural} />
        <div className="beekiri-notice is-info">
          <p>
            You need the {cfg.editCap} capability to manage {cfg.labelPlural.toLowerCase()}.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title={cfg.labelPlural}
        actions={
          view === 'all' ? (
            <>
              {hasActiveAdminFilters(filterValues) ? (
                <button
                  type="button"
                  className="button"
                  onClick={() => setFilterValues(EMPTY_FILTERS)}
                >
                  Clear filters
                </button>
              ) : null}
              <button
                type="button"
                className="button button-primary"
                disabled={creating}
                onClick={() => void addNew()}
              >
                {creating ? 'Creating…' : 'Add new'}
              </button>
            </>
          ) : null
        }
      />
      <p className="bk-muted">
        <button
          type="button"
          className="button-link"
          onClick={() => {
            setView('all');
            setFilterValues(EMPTY_FILTERS);
          }}
          style={{ fontWeight: view === 'all' ? 600 : undefined }}
        >
          All ({counts.all})
        </button>
        <span className="bk-table__sep"> | </span>
        <button
          type="button"
          className="button-link"
          onClick={() => {
            setView('trash');
            setFilterValues(EMPTY_FILTERS);
          }}
          style={{ fontWeight: view === 'trash' ? 600 : undefined }}
        >
          Trash ({counts.trash})
        </button>
      </p>
      <p className="bk-muted">
        {view === 'trash'
          ? `Trashed ${cfg.labelPlural.toLowerCase()} can be restored as drafts or deleted permanently.`
          : `${cfg.blurb} ${counts.all} total.`}
      </p>

      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}

      <AdminDataTable
        rows={rows}
        columns={columns}
        getRowId={(row) => row.id}
        filters={filters}
        filterValues={filterValues}
        onFilterChange={(values) => setFilterValues({ ...EMPTY_FILTERS, ...values })}
        filterFn={(row, values) => {
          const q = values.title.trim().toLowerCase();
          const title = displayTitle(row).toLowerCase();
          if (q && !title.includes(q) && !row.slug.toLowerCase().includes(q)) {
            return false;
          }
          if (values.status && row.status !== values.status) return false;
          return true;
        }}
        loading={loading}
        emptyTitle={view === 'trash' ? 'Trash is empty.' : cfg.emptyTitle}
        emptyFilteredTitle={cfg.emptyFilteredTitle}
      />
    </div>
  );
}

export function PagesPage() {
  return <ContentListPage kind="page" />;
}

export function PostsPage() {
  return <ContentListPage kind="post" />;
}

export function CptListPage() {
  const { type } = useParams<{ type: string }>();
  const href = useAdminHref();
  const slug = (type || '').trim().toLowerCase();
  const resolved = useCptMeta(slug);

  if (!slug) return null;

  if (resolved.status === 'loading') {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title="Loading…" />
        <p className="bk-muted">Checking post type…</p>
      </div>
    );
  }

  if (resolved.status === 'missing') {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title="Post type not found" />
        <div className="beekiri-notice is-error" role="alert">
          <p>
            No registered post type with slug <code>{slug}</code>. It may have been deleted or
            renamed.
          </p>
        </div>
        {resolved.all.length > 0 ? (
          <div className="bk-panel" style={{ marginTop: 16 }}>
            <div className="bk-panel__body">
              <p className="bk-muted" style={{ marginTop: 0 }}>
                Open a registered content type:
              </p>
              <ul style={{ margin: 0, paddingLeft: 18 }}>
                {resolved.all.map((p) => (
                  <li key={p.slug}>
                    <Link to={href(`content/${p.slug}`)}>{p.plural}</Link>
                    <code style={{ marginLeft: 8 }}>{href(`content/${p.slug}`)}</code>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ) : null}
        <p style={{ marginTop: 16 }}>
          <Link className="button" to={href('fields/post-types')}>
            Manage post types
          </Link>
        </p>
      </div>
    );
  }

  return <ContentListPage kind={slug} labels={resolved.labels} />;
}

export type { ContentKindConfig };
