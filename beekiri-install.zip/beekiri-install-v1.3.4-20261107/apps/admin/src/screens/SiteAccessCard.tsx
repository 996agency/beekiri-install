import { useEffect, useState } from 'react';
import { api, ApiError } from '../api/client';

/**
 * User Permissions → a person's sites (multisite, owner): which sites of the network they can
 * use and their role on each. Hidden while the network has only one site.
 */

type SiteRow = {
  siteId: string;
  title: string;
  url: string;
  isPrimary: boolean;
  status: string;
  role: string | null;
};
type Access = { userId: string; isOwner: boolean; sites: SiteRow[] };
type Role = { slug: string; label: string };

export function SiteAccessCard({ userId, name }: { userId: string; name: string }) {
  const [access, setAccess] = useState<Access | null>(null);
  const [roles, setRoles] = useState<Role[]>([]);
  const [draft, setDraft] = useState<Record<string, string | null>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    let live = true;
    setAccess(null);
    setError(null);
    setSaved(false);
    Promise.all([api<Access>(`/api/users/${userId}/sites`), api<{ roles: Role[] }>('/api/users/roles')])
      .then(([a, r]) => {
        if (!live) return;
        setAccess(a);
        setRoles(r.roles);
        setDraft(Object.fromEntries(a.sites.map((s) => [s.siteId, s.role])));
      })
      .catch((e) => live && setError(e instanceof ApiError ? e.message : 'Could not load site access.'));
    return () => {
      live = false;
    };
  }, [userId]);

  if (error && !access) {
    return (
      <div className="beekiri-notice is-error" role="alert">
        <p>{error}</p>
      </div>
    );
  }
  if (!access || access.sites.length < 2) return null;

  const changed = access.sites.filter((s) => (draft[s.siteId] ?? null) !== s.role);

  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      const next = await api<Access>(`/api/users/${userId}/sites`, {
        method: 'PUT',
        json: { sites: changed.map((s) => ({ siteId: s.siteId, role: draft[s.siteId] ?? null })) },
      });
      setAccess(next);
      setDraft(Object.fromEntries(next.sites.map((s) => [s.siteId, s.role])));
      setSaved(true);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Could not save site access.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bk-panel bk-perm__sites">
      <div className="bk-panel__head">
        <h2 className="bk-panel__title">Sites</h2>
        <span className="bk-perm__head-meta">
          {access.sites.filter((s) => (draft[s.siteId] ?? null) !== null).length} of {access.sites.length}
        </span>
      </div>
      <div className="bk-panel__body">
        <p className="bk-perm__sites-hint">
          {access.isOwner
            ? 'The owner can use every site of the network as an administrator.'
            : `Choose which sites ${name} can sign in to, and their role on each. Permissions below apply to this site only.`}
        </p>
        {error ? (
          <div className="beekiri-notice is-error" role="alert">
            <p>{error}</p>
          </div>
        ) : null}
        <ul className="bk-perm__sites-list">
          {access.sites.map((site) => {
            const value = draft[site.siteId] ?? '';
            return (
              <li key={site.siteId} className="bk-perm__sites-row">
                <span className="bk-perm__sites-text">
                  <span className="bk-perm__sites-title">
                    {site.title}
                    {site.isPrimary ? <span className="bk-table__badge">Main site</span> : null}
                    {site.status === 'archived' ? <span className="bk-table__badge">Archived</span> : null}
                  </span>
                  <span className="bk-perm__sites-url">{site.url.replace(/^https?:\/\//, '')}</span>
                </span>
                <select
                  aria-label={`Role on ${site.title}`}
                  value={value}
                  disabled={access.isOwner || busy}
                  onChange={(e) => {
                    setSaved(false);
                    setDraft({ ...draft, [site.siteId]: e.target.value || null });
                  }}
                >
                  <option value="">No access</option>
                  {roles.map((r) => (
                    <option key={r.slug} value={r.slug}>
                      {r.label}
                    </option>
                  ))}
                </select>
              </li>
            );
          })}
        </ul>
        {!access.isOwner ? (
          <div className="bk-perm__sites-actions">
            <button type="button" className="button button-primary" disabled={busy || !changed.length} onClick={() => void save()}>
              {busy ? 'Saving…' : 'Save sites'}
            </button>
            {saved && !changed.length ? <span className="bk-perm__sites-saved">Saved</span> : null}
          </div>
        ) : null}
      </div>
    </div>
  );
}
