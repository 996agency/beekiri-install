import { FormEvent, useEffect, useState } from 'react';
import { api, ApiError } from '../../api/client';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { ErrorNotice } from '../../components/ErrorNotice';

type Settings = {
  showAdminBar: boolean;
  exportFormat: 'php' | 'json';
  deleteWithContent: boolean;
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

export function FieldsSettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    api<Settings>('/api/fields/settings')
      .then(setSettings)
      .catch((e) => setError(formatError(e)));
  }, []);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const next = await api<Settings>('/api/fields/settings', {
        method: 'PATCH',
        json: settings,
      });
      setSettings(next);
      setNotice('Backend Fields settings saved.');
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const formId = 'fields-settings-form';

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Backend Fields settings"
        actions={
          <button
            type="submit"
            form={formId}
            className="button button-primary"
            disabled={busy || !settings}
          >
            {busy ? 'Saving…' : 'Save settings'}
          </button>
        }
      />
      <p className="bk-muted">Module preferences for field groups, post types, and taxonomies.</p>

      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}

      {settings ? (
        <form id={formId} className="bk-panel" onSubmit={onSubmit}>
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">General</h2>
          </div>
          <div className="bk-panel__body">
            <table className="form-table">
              <tbody>
                <tr>
                  <th scope="row">Admin bar</th>
                  <td>
                    <label className="bk-check">
                      <input
                        type="checkbox"
                        checked={settings.showAdminBar}
                        onChange={(e) =>
                          setSettings({ ...settings, showAdminBar: e.target.checked })
                        }
                      />
                      <span className="bk-check__box" aria-hidden />
                      <span className="bk-check__label">Show Backend Fields shortcuts</span>
                    </label>
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="bf_export">Export format</label>
                  </th>
                  <td>
                    <select
                      id="bf_export"
                      value={settings.exportFormat}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          exportFormat: e.target.value as 'php' | 'json',
                        })
                      }
                    >
                      <option value="json">JSON</option>
                      <option value="php">PHP (legacy compatibility)</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <th scope="row">Cleanup</th>
                  <td>
                    <label className="bk-check">
                      <input
                        type="checkbox"
                        checked={settings.deleteWithContent}
                        onChange={(e) =>
                          setSettings({ ...settings, deleteWithContent: e.target.checked })
                        }
                      />
                      <span className="bk-check__box" aria-hidden />
                      <span className="bk-check__label">
                        When deleting a post type, also remove its content (dangerous)
                      </span>
                    </label>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </form>
      ) : (
        <p className="bk-muted">Loading…</p>
      )}
    </div>
  );
}
