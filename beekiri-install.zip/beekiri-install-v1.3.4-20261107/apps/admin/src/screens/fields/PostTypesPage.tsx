import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { api, ApiError } from '../../api/client';
import { useAdminHref } from '../../lib/AdminEntryContext';
import { AdminDataTable, type AdminTableColumn } from '../../components/AdminDataTable';
import { IconPicker } from '../../components/IconPicker';
import { confirmDialog } from '../../components/ConfirmDialog';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { notifyPostTypesChanged } from '../../lib/admin-events';
import { ErrorNotice } from '../../components/ErrorNotice';

type PostType = {
  id: string;
  slug: string;
  singular: string;
  plural: string;
  description: string;
  public: boolean;
  hierarchical: boolean;
  hasArchive: boolean;
  showInMenu: boolean;
  supports: string[];
  active: boolean;
  menuIcon: string;
  archiveDesign: string;
  singleDesign: string;
};


const SUPPORT_OPTIONS = [
  { value: 'title', label: 'Title' },
  { value: 'editor', label: 'Editor' },
  { value: 'thumbnail', label: 'Featured image' },
  { value: 'excerpt', label: 'Excerpt' },
  { value: 'custom-fields', label: 'Custom fields' },
];

const EMPTY = {
  slug: '',
  singular: '',
  plural: '',
  description: '',
  public: true,
  hierarchical: false,
  hasArchive: true,
  showInMenu: true,
  supports: ['title', 'editor'] as string[],
  active: true,
  menuIcon: 'Cube',
  archiveDesign: 'list',
  singleDesign: 'default',
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

function toSlug(v: string) {
  return v
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
}

function formFromRow(row: PostType) {
  return {
    slug: row.slug,
    singular: row.singular,
    plural: row.plural,
    description: row.description,
    public: row.public,
    hierarchical: row.hierarchical,
    hasArchive: row.hasArchive,
    showInMenu: row.showInMenu,
    supports: [...row.supports],
    active: row.active,
    menuIcon: row.menuIcon || 'Cube',
    archiveDesign: row.archiveDesign || 'list',
    singleDesign: row.singleDesign || 'default',
  };
}

export function PostTypesPage() {
  const { id } = useParams<{ id?: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const href = useAdminHref();
  const LIST_PATH = href('fields/post-types');
  // `/new` is captured by `:id` (must not use a separate static `/new` route).
  const isNew = id === 'new';
  const isForm = Boolean(id);

  const [rows, setRows] = useState<PostType[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY);
  const [editRow, setEditRow] = useState<PostType | null>(null);

  const load = useCallback(async () => {
    const res = await api<{ postTypes: PostType[] }>('/api/fields/post-types');
    setRows(res.postTypes);
    return res.postTypes;
  }, []);

  useEffect(() => {
    const state = location.state as { notice?: string } | null;
    if (state?.notice) {
      setNotice(state.notice);
      navigate(location.pathname, { replace: true, state: null });
    }
  }, [location.pathname, location.state, navigate]);

  useEffect(() => {
    setLoading(true);
    load()
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [load]);

  useEffect(() => {
    if (!isForm) {
      setEditRow(null);
      return;
    }
    if (isNew) {
      setForm(EMPTY);
      setEditRow(null);
      setError(null);
      return;
    }
    if (loading) return;
    const row = rows.find((r) => r.id === id);
    if (!row) {
      navigate(LIST_PATH, { replace: true });
      return;
    }
    setForm(formFromRow(row));
    setEditRow(row);
    setError(null);
  }, [id, isForm, isNew, loading, rows, navigate]);

  const back = (nextNotice?: string) => {
    navigate(LIST_PATH, nextNotice ? { state: { notice: nextNotice } } : undefined);
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const payload = {
        ...form,
        slug: form.slug.trim().toLowerCase(),
        singular: form.singular.trim(),
        plural: form.plural.trim(),
        description: form.description.trim(),
      };
      if (isNew) {
        await api('/api/fields/post-types', { method: 'POST', json: payload });
        notifyPostTypesChanged();
        back(`Post type “${payload.plural}” created.`);
      } else if (editRow) {
        await api(`/api/fields/post-types/${editRow.id}`, {
          method: 'PATCH',
          json: payload,
        });
        notifyPostTypesChanged();
        back(`Post type “${payload.plural}” updated.`);
      }
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const onDelete = async (row: PostType) => {
    const ok = await confirmDialog({
      title: 'Delete post type',
      message: `Delete post type “${row.plural}”?`,
      confirmLabel: 'Delete',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    try {
      await api(`/api/fields/post-types/${row.id}`, { method: 'DELETE' });
      const msg = `Post type “${row.plural}” deleted.`;
      await load();
      notifyPostTypesChanged();
      if (editRow?.id === row.id) back(msg);
      else setNotice(msg);
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const columns: AdminTableColumn<PostType>[] = useMemo(
    () => [
      {
        key: 'plural',
        header: 'Post type',
        render: (row) => (
          <>
            <strong className="bk-table__primary">{row.plural}</strong>
            {!row.active ? <span className="bk-table__badge">Inactive</span> : null}
            <div className="bk-table__row-actions">
              <Link className="button-link" to={href(`content/${row.slug}`)}>
                View items
              </Link>
              <span className="bk-table__sep">|</span>
              <Link className="button-link" to={`${LIST_PATH}/${row.id}`}>
                Edit
              </Link>
              <span className="bk-table__sep">|</span>
              <button
                type="button"
                className="button-link is-danger"
                disabled={busy}
                onClick={() => onDelete(row)}
              >
                Delete
              </button>
            </div>
          </>
        ),
      },
      { key: 'slug', header: 'Slug', render: (row) => <code>{row.slug}</code> },
      {
        key: 'kind',
        header: 'Type',
        render: (row) => (row.hierarchical ? 'Hierarchical' : 'Flat'),
      },
    ],
    [busy, href],
  );

  if (isForm) {
    const formId = isNew ? 'post-type-form-new' : `post-type-form-${id}`;
    return (
      <div className="wrap wrap--wide">
        <PageHeader
          title={isNew ? 'Add post type' : 'Edit post type'}
          actions={
            <>
              <button type="submit" form={formId} className="button button-primary" disabled={busy}>
                {busy ? 'Saving…' : isNew ? 'Add post type' : 'Update'}
              </button>
              <Link to={LIST_PATH} className="button" aria-disabled={busy}>
                Cancel
              </Link>
            </>
          }
        />
        <p className="bk-acf-breadcrumb">
          <Link to={LIST_PATH}>Post Types</Link> <span>/</span> {isNew ? 'new' : id}
        </p>
        <p className="bk-muted">
          Register a custom content type — like Products, Events, or Team members — then attach
          field groups to it.
        </p>
        {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
        <form id={formId} className="bk-panel" onSubmit={onSubmit}>
          <div className="bk-panel__body">
            <table className="form-table">
              <tbody>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_singular">Singular name</label>
                  </th>
                  <td>
                    <input
                      id="pt_singular"
                      className="regular-text"
                      required
                      value={form.singular}
                      onChange={(e) => {
                        const singular = e.target.value;
                        setForm((f) => {
                          const autoPlural = f.singular ? `${f.singular}s` : '';
                          const pluralStillAuto = !f.plural || f.plural === autoPlural;
                          return {
                            ...f,
                            singular,
                            plural: pluralStillAuto ? (singular ? `${singular}s` : '') : f.plural,
                            slug:
                              isNew && (!f.slug || f.slug === toSlug(f.singular))
                                ? toSlug(singular)
                                : f.slug,
                          };
                        });
                      }}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_plural">Plural name</label>
                  </th>
                  <td>
                    <input
                      id="pt_plural"
                      className="regular-text"
                      required
                      value={form.plural}
                      onChange={(e) => setForm((f) => ({ ...f, plural: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_slug">Slug</label>
                  </th>
                  <td>
                    <input
                      id="pt_slug"
                      className="regular-text"
                      required
                      value={form.slug}
                      onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))}
                    />
                    <p className="description">Used in URLs and field group locations.</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_desc">Description</label>
                  </th>
                  <td>
                    <textarea
                      id="pt_desc"
                      rows={2}
                      value={form.description}
                      onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <span id="pt_icon_label">Menu icon</span>
                  </th>
                  <td>
                    <IconPicker
                      id="pt_icon"
                      value={form.menuIcon}
                      onChange={(menuIcon) => setForm((f) => ({ ...f, menuIcon }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_archive_design">Archive design</label>
                  </th>
                  <td>
                    <select
                      id="pt_archive_design"
                      value={form.archiveDesign}
                      onChange={(e) => setForm((f) => ({ ...f, archiveDesign: e.target.value }))}
                    >
                      <option value="list">List</option>
                      <option value="cards">Cards</option>
                      <option value="grid">Grid</option>
                    </select>
                    <p className="description">
                      Front archive layout at /{form.slug || '…'}/ (theme templates sync on save).
                    </p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_single_design">Single design</label>
                  </th>
                  <td>
                    <select
                      id="pt_single_design"
                      value={form.singleDesign}
                      onChange={(e) => setForm((f) => ({ ...f, singleDesign: e.target.value }))}
                    >
                      <option value="default">Default</option>
                      <option value="full">Full width</option>
                      <option value="compact">Compact</option>
                    </select>
                    <p className="description">
                      Layout for each single entry. Customize further in the page editor per item.
                    </p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">Supports</th>
                  <td>
                    <div className="bk-fields-locations">
                      {SUPPORT_OPTIONS.map((opt) => (
                        <label key={opt.value} className="bk-check">
                          <input
                            type="checkbox"
                            checked={form.supports.includes(opt.value)}
                            onChange={() =>
                              setForm((f) => ({
                                ...f,
                                supports: f.supports.includes(opt.value)
                                  ? f.supports.filter((s) => s !== opt.value)
                                  : [...f.supports, opt.value],
                              }))
                            }
                          />
                          <span className="bk-check__box" aria-hidden />
                          <span className="bk-check__label">{opt.label}</span>
                        </label>
                      ))}
                    </div>
                  </td>
                </tr>
                <tr>
                  <th scope="row">Options</th>
                  <td>
                    <div className="bk-fields-locations">
                      {(
                        [
                          ['public', 'Public'],
                          ['hierarchical', 'Hierarchical (like pages)'],
                          ['hasArchive', 'Has archive'],
                          ['showInMenu', 'Show in admin menu'],
                          ['active', 'Active'],
                        ] as const
                      ).map(([key, label]) => (
                        <label key={key} className="bk-check">
                          <input
                            type="checkbox"
                            checked={form[key]}
                            onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.checked }))}
                          />
                          <span className="bk-check__box" aria-hidden />
                          <span className="bk-check__label">{label}</span>
                        </label>
                      ))}
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Post Types"
        actions={
          <Link to={`${LIST_PATH}/new`} className="button button-primary">
            Add post type
          </Link>
        }
      />
      <p className="bk-muted">
        Register custom content types for your site. {rows.length}{' '}
        registered.
      </p>
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}
      <AdminDataTable
        rows={rows}
        columns={columns}
        getRowId={(r) => r.id}
        loading={loading}
        defaultPageSize={10}
        emptyTitle="No custom post types yet. Add one to create Products, Events, and more."
      />
    </div>
  );
}
