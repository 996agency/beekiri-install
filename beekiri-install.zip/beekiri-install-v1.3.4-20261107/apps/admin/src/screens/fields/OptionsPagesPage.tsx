import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { api, ApiError } from '../../api/client';
import { useAdminHref } from '../../lib/AdminEntryContext';
import { AdminDataTable, type AdminTableColumn } from '../../components/AdminDataTable';
import { confirmDialog } from '../../components/ConfirmDialog';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { ErrorNotice } from '../../components/ErrorNotice';

type OptionsPage = {
  id: string;
  title: string;
  slug: string;
  menuTitle: string;
  description: string;
  parentSlug: string;
  active: boolean;
};


const EMPTY = {
  title: '',
  slug: '',
  menuTitle: '',
  description: '',
  parentSlug: '',
  active: true,
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

function toSlug(v: string) {
  return v
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
}

function formFromRow(row: OptionsPage) {
  return {
    title: row.title,
    slug: row.slug,
    menuTitle: row.menuTitle,
    description: row.description,
    parentSlug: row.parentSlug,
    active: row.active,
  };
}

export function OptionsPagesPage() {
  const { id } = useParams<{ id?: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const href = useAdminHref();
  const LIST_PATH = href('fields/options-pages');
  // `/new` is captured by `:id` (must not use a separate static `/new` route).
  const isNew = id === 'new';
  const isForm = Boolean(id);

  const [rows, setRows] = useState<OptionsPage[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY);
  const [editRow, setEditRow] = useState<OptionsPage | null>(null);

  const load = useCallback(async () => {
    const res = await api<{ optionsPages: OptionsPage[] }>('/api/fields/options-pages');
    setRows(res.optionsPages);
    return res.optionsPages;
  }, []);

  useEffect(() => {
    const state = location.state as { notice?: string } | null;
    if (state?.notice) {
      setNotice(state.notice);
      navigate(location.pathname, { replace: true, state: null });
    }
  }, [location.pathname, location.state, navigate]);

  useEffect(() => {
    setLoading(true);
    load()
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [load]);

  useEffect(() => {
    if (!isForm) {
      setEditRow(null);
      return;
    }
    if (isNew) {
      setForm(EMPTY);
      setEditRow(null);
      setError(null);
      return;
    }
    if (loading) return;
    const row = rows.find((r) => r.id === id);
    if (!row) {
      navigate(LIST_PATH, { replace: true });
      return;
    }
    setForm(formFromRow(row));
    setEditRow(row);
    setError(null);
  }, [id, isForm, isNew, loading, rows, navigate]);

  const back = (nextNotice?: string) => {
    navigate(LIST_PATH, nextNotice ? { state: { notice: nextNotice } } : undefined);
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const payload = {
        title: form.title.trim(),
        slug: form.slug.trim().toLowerCase(),
        menuTitle: (form.menuTitle || form.title).trim(),
        description: form.description.trim(),
        parentSlug: form.parentSlug.trim().toLowerCase(),
        active: form.active,
      };
      if (isNew) {
        await api('/api/fields/options-pages', { method: 'POST', json: payload });
        back(`Options page “${payload.title}” created.`);
      } else if (editRow) {
        await api(`/api/fields/options-pages/${editRow.id}`, {
          method: 'PATCH',
          json: payload,
        });
        back(`Options page “${payload.title}” updated.`);
      }
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const onDelete = async (row: OptionsPage) => {
    const ok = await confirmDialog({
      title: 'Delete options page',
      message: `Delete options page “${row.title}”?`,
      confirmLabel: 'Delete',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    try {
      await api(`/api/fields/options-pages/${row.id}`, { method: 'DELETE' });
      const msg = `Options page “${row.title}” deleted.`;
      await load();
      if (editRow?.id === row.id) back(msg);
      else setNotice(msg);
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const columns: AdminTableColumn<OptionsPage>[] = useMemo(
    () => [
      {
        key: 'title',
        header: 'Options page',
        render: (row) => (
          <>
            <strong className="bk-table__primary">{row.title}</strong>
            {!row.active ? <span className="bk-table__badge">Inactive</span> : null}
            <div className="bk-table__row-actions">
              <Link className="button-link" to={`${LIST_PATH}/${row.id}`}>
                Edit
              </Link>
              <span className="bk-table__sep">|</span>
              <button
                type="button"
                className="button-link is-danger"
                disabled={busy}
                onClick={() => onDelete(row)}
              >
                Delete
              </button>
            </div>
          </>
        ),
      },
      { key: 'slug', header: 'Slug', render: (row) => <code>{row.slug}</code> },
      {
        key: 'parent',
        header: 'Parent',
        render: (row) => row.parentSlug || '—',
      },
    ],
    [busy],
  );

  if (isForm) {
    const formId = isNew ? 'options-page-form-new' : `options-page-form-${id}`;
    const parents = rows.filter((r) => !editRow || r.id !== editRow.id);
    return (
      <div className="wrap wrap--wide">
        <PageHeader
          title={isNew ? 'Add options page' : 'Edit options page'}
          actions={
            <>
              <button type="submit" form={formId} className="button button-primary" disabled={busy}>
                {busy ? 'Saving…' : isNew ? 'Add page' : 'Update'}
              </button>
              <Link to={LIST_PATH} className="button" aria-disabled={busy}>
                Cancel
              </Link>
            </>
          }
        />
        <p className="bk-acf-breadcrumb">
          <Link to={LIST_PATH}>Options Pages</Link> <span>/</span>{' '}
          {isNew ? 'new' : id}
        </p>
        <p className="bk-muted">
          Create site-wide settings screens and attach field groups to them.
        </p>
        {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
        <form id={formId} className="bk-panel" onSubmit={onSubmit}>
          <div className="bk-panel__body">
            <table className="form-table">
              <tbody>
                <tr>
                  <th scope="row">
                    <label htmlFor="op_title">Page title</label>
                  </th>
                  <td>
                    <input
                      id="op_title"
                      className="regular-text"
                      required
                      value={form.title}
                      onChange={(e) => {
                        const title = e.target.value;
                        setForm((f) => {
                          const menuTitleStillAuto = !f.menuTitle || f.menuTitle === f.title;
                          return {
                            ...f,
                            title,
                            menuTitle: menuTitleStillAuto ? title : f.menuTitle,
                            slug:
                              isNew && (!f.slug || f.slug === toSlug(f.title))
                                ? toSlug(title)
                                : f.slug,
                          };
                        });
                      }}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="op_menu">Menu title</label>
                  </th>
                  <td>
                    <input
                      id="op_menu"
                      className="regular-text"
                      value={form.menuTitle}
                      onChange={(e) => setForm((f) => ({ ...f, menuTitle: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="op_slug">Slug</label>
                  </th>
                  <td>
                    <input
                      id="op_slug"
                      className="regular-text"
                      required
                      value={form.slug}
                      onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="op_parent">Parent page</label>
                  </th>
                  <td>
                    <select
                      id="op_parent"
                      value={form.parentSlug}
                      onChange={(e) => setForm((f) => ({ ...f, parentSlug: e.target.value }))}
                    >
                      <option value="">None (top level)</option>
                      {parents.map((p) => (
                        <option key={p.id} value={p.slug}>
                          {p.title}
                        </option>
                      ))}
                    </select>
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="op_desc">Description</label>
                  </th>
                  <td>
                    <textarea
                      id="op_desc"
                      rows={2}
                      value={form.description}
                      onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">Status</th>
                  <td>
                    <label className="bk-check">
                      <input
                        type="checkbox"
                        checked={form.active}
                        onChange={(e) => setForm((f) => ({ ...f, active: e.target.checked }))}
                      />
                      <span className="bk-check__box" aria-hidden />
                      <span className="bk-check__label">Active</span>
                    </label>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Options Pages"
        actions={
          <Link to={`${LIST_PATH}/new`} className="button button-primary">
            Add options page
          </Link>
        }
      />
      <p className="bk-muted">
        Global options screens for site-wide fields. {rows.length} page{rows.length === 1 ? '' : 's'}.
      </p>
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}
      <AdminDataTable
        rows={rows}
        columns={columns}
        getRowId={(r) => r.id}
        loading={loading}
        defaultPageSize={10}
        emptyTitle="No options pages yet. Add Site options, Theme settings, and more."
      />
    </div>
  );
}
