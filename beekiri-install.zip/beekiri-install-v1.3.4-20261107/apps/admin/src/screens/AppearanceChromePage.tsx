import { useCallback, useEffect, useState } from 'react';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';

export type ChromeKind = 'header' | 'footer';

type ChromeOption = {
  slug: string;
  title: string;
  path: string;
  description: string;
  theme: string;
  default?: boolean;
  hasPhp: boolean;
  hasReact: boolean;
  active: boolean;
};

type ChromeResponse = {
  kind: ChromeKind;
  theme: string;
  themeName: string;
  runtime: 'php' | 'react';
  options: ChromeOption[];
  active: string | null;
};

import { SITE_URL as LIVE_SITE } from '../config';
import { ErrorNotice } from '../components/ErrorNotice';

const COPY: Record<ChromeKind, { title: string; noun: string; plural: string; key: string }> = {
  header: { title: 'Header', noun: 'header', plural: 'headers', key: 'headers' },
  footer: { title: 'Footer', noun: 'footer', plural: 'footers', key: 'footers' },
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

/** Appearance → Header / Footer: pick the active chrome from the active theme. */
export function AppearanceChromePage({ kind }: { kind: ChromeKind }) {
  const copy = COPY[kind];
  const auth = useAuth();
  const canEdit = auth.user?.capabilities.includes('edit_theme_options') ?? false;
  const [data, setData] = useState<ChromeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const load = useCallback(async () => {
    setError('');
    setLoading(true);
    try {
      setData(await api<ChromeResponse>(`/api/themes/chrome/${kind}/options`));
    } catch (e) {
      setError(formatError(e));
    } finally {
      setLoading(false);
    }
  }, [kind]);

  useEffect(() => {
    void load();
  }, [load]);

  const activate = async (slug: string) => {
    if (!canEdit || busy || slug === data?.active) return;
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const next = await api<ChromeResponse>(`/api/themes/chrome/${kind}/activate`, {
        method: 'POST',
        json: { slug },
      });
      setData(next);
      const name = next.options.find((o) => o.slug === next.active)?.title ?? slug;
      setNotice(`“${name}” is now the active ${copy.noun}.`);
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const runtime = data?.runtime ?? 'php';
  const ext = runtime === 'react' ? '.tsx' : '.php';
  const options = data?.options ?? [];

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title={copy.title}
        actions={
          <a className="button" href={LIVE_SITE} target="_blank" rel="noreferrer">
            View site
          </a>
        }
      />
      <p className="bk-muted">
        Choose a {copy.noun} from the active theme
        {data?.themeName ? (
          <>
            {' '}
            (<strong>{data.themeName}</strong> · <code>{data.theme}</code>)
          </>
        ) : null}
        . This site runs the <strong>{runtime === 'react' ? 'React' : 'PHP'}</strong> frontend, so
        the {copy.noun} renders from its <code>{ext}</code> file.
      </p>

      {error ? <ErrorNotice message={error} onDismiss={() => setError('')} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice('')} /> : null}

      {!canEdit ? (
        <div className="beekiri-notice is-info">
          <p>You need the edit_theme_options capability to change the {copy.noun}.</p>
        </div>
      ) : null}

      {loading ? (
        <p className="bk-muted">Loading {copy.plural}…</p>
      ) : options.length === 0 ? (
        <div className="beekiri-notice is-info">
          <p>
            This theme has no {copy.noun} options yet. Add a <code>{copy.key}</code> entry in{' '}
            <code>theme.json</code> and a matching <code>{kind}/</code> folder with{' '}
            <code>
              {kind}
              {ext}
            </code>
            .
          </p>
        </div>
      ) : (
        <div className="bk-themes bk-themes--headers">
          {options.map((option) => {
            const supported = runtime === 'react' ? option.hasReact : option.hasPhp;
            return (
              <article
                key={option.slug}
                className={`bk-header-card${option.active ? ' is-active' : ''}`}
              >
                <div className="bk-header-card__preview" aria-hidden>
                  {kind === 'header' ? (
                    <div className="bk-header-card__bar">
                      <span className="bk-header-card__mark" />
                      <span className="bk-header-card__links">
                        <i />
                        <i />
                        <i />
                      </span>
                      <span className="bk-header-card__actions">
                        <i />
                        <i />
                      </span>
                    </div>
                  ) : (
                    <div className="bk-header-card__bar bk-header-card__bar--footer">
                      <span className="bk-header-card__mark" />
                      <span className="bk-header-card__links">
                        <i />
                        <i />
                        <i />
                      </span>
                    </div>
                  )}
                </div>
                <div className="bk-header-card__body">
                  <div className="bk-header-card__meta">
                    <h2 className="bk-header-card__name">
                      {option.title}
                      {option.active ? <span className="bk-theme-card__status">Active</span> : null}
                      {option.default ? (
                        <span className="bk-theme-card__status is-muted">Default</span>
                      ) : null}
                    </h2>
                    <p className="bk-header-card__by">
                      <code>
                        {option.path}/{option.slug}
                        {ext}
                      </code>
                    </p>
                    {option.description ? (
                      <p className="bk-header-card__desc">{option.description}</p>
                    ) : null}
                    {!supported ? (
                      <p className="bk-header-card__desc">
                        Missing <code>{ext}</code> file — can’t be used with this site’s frontend.
                      </p>
                    ) : null}
                  </div>
                  <div className="bk-header-card__actions-row">
                    {option.active ? (
                      <button type="button" className="button" disabled>
                        Active
                      </button>
                    ) : (
                      <button
                        type="button"
                        className="button button-primary"
                        disabled={!canEdit || busy || !supported}
                        onClick={() => void activate(option.slug)}
                      >
                        {busy ? 'Working…' : 'Activate'}
                      </button>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
