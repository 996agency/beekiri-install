import { useCallback, useEffect, useState } from 'react';
import {
  ArrowClockwise,
  ArrowCounterClockwise,
  Check,
  Stack,
  Eye,
  FileCode,
  Image,
  Layout,
  NotePencil,
  ShoppingBag,
  Tag,
} from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import {
  byDay,
  ListPager,
  PeriodTabs,
  timeOf,
  type HistoryPeriod,
} from '../components/HistoryControls';
import './beekiri-change-history.css';

type Change = {
  id: string;
  kind: 'theme_file' | 'layout' | 'page' | 'taxonomy' | 'post_type' | 'product' | 'media';
  label: string;
  created: boolean;
  createdAt: string;
  revertedAt: string | null;
};
/** pending: it added sections to live pages that visitors don't see until you press Keep. */
type Run = {
  runId: string;
  chatTitle: string;
  user: string;
  createdAt: string;
  changes: Change[];
  pending?: boolean;
};
type Page = { runs: Run[]; page: number; pages: number; perPage: number; total: number };

const ICON = {
  post_type: Stack,
  theme_file: FileCode,
  layout: Layout,
  page: NotePencil,
  taxonomy: Tag,
  product: ShoppingBag,
  media: Image,
} as const;

/**
 * What Beekiri changed outside the page editor (theme files, layouts, pages, posts, products, photos, taxonomies), one
 * group per message, with Revert. Section edits in the editor have their own Undo there.
 */
export function BeekiriChangeHistory() {
  const [data, setData] = useState<Page | null>(null);
  const [period, setPeriod] = useState<HistoryPeriod>('all');
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const runs = data?.runs ?? null;
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    setLoading(true);
    try {
      setData(await api<Page>(`/api/connector/changes?period=${period}&page=${page}`));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load the change history.');
    } finally {
      setLoading(false);
    }
  }, [period, page]);

  useEffect(() => {
    void load();
  }, [load]);

  /** Private preview links per message, made on request (visitors don't see what waits for Keep). */
  const [previews, setPreviews] = useState<Record<string, { title: string; url: string }[]>>({});
  const preview = async (run: Run) => {
    setBusy(`preview:${run.runId}`);
    setError(null);
    try {
      const res = await api<{ pages: { title: string; url: string }[] }>(
        '/api/connector/changes/preview',
        {
          method: 'POST',
          json: { runId: run.runId },
        },
      );
      setPreviews((p) => ({ ...p, [run.runId]: res.pages }));
      if (!res.pages.length) setNotice('Nothing from that message is waiting any more.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not make a preview.');
    } finally {
      setBusy(null);
    }
  };

  const keep = async (run: Run) => {
    setBusy(`keep:${run.runId}`);
    setError(null);
    setNotice(null);
    try {
      await api('/api/connector/changes/keep', { method: 'POST', json: { runId: run.runId } });
      setNotice(`Kept — what “${run.chatTitle}” added is live for your visitors now.`);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not keep that.');
    } finally {
      setBusy(null);
    }
  };

  const revert = async (
    target: { changeId?: string; runId?: string },
    what: string,
    force = false,
  ): Promise<void> => {
    if (
      !force &&
      !window.confirm(
        `Revert ${what}? Beekiri's change is undone; pages and layouts it created go to the trash.`,
      )
    )
      return;
    setBusy(target.changeId ?? target.runId ?? null);
    setError(null);
    setNotice(null);
    try {
      const res = await api<{ reverted: number }>('/api/connector/changes/revert', {
        method: 'POST',
        json: { ...target, ...(force ? { force: true } : {}) },
      });
      setNotice(`Reverted ${res.reverted} change${res.reverted === 1 ? '' : 's'}.`);
      await load();
    } catch (e) {
      if (e instanceof ApiError && e.status === 409 && !force) {
        setBusy(null);
        if (window.confirm(`${e.message}\n\nRevert anyway?`)) return revert(target, what, true);
        return;
      }
      setError(e instanceof Error ? e.message : 'Could not revert.');
    } finally {
      setBusy(null);
    }
  };

  return (
    <section className="bk-panel bk-bch">
      <div className="bk-panel__head">
        <h2 className="bk-panel__title">Change history</h2>
        <button type="button" className="button bk-bch__refresh" onClick={() => void load()}>
          <ArrowClockwise size={14} aria-hidden /> Refresh
        </button>
      </div>
      <div className="bk-panel__body">
        <p className="bk-bch__intro">
          Everything Beekiri changed in your theme, layouts, pages, posts, products, photos and
          taxonomies. Made a mistake? Revert one change or a whole message. Section edits in the
          page editor are undone there, with Undo.
        </p>
        {notice ? <p className="bk-bch__notice">{notice}</p> : null}
        {error ? <p className="bk-bch__error">{error}</p> : null}
        <div className="bk-bch__card">
          <PeriodTabs
            value={period}
            label="Change history period"
            onChange={(p) => {
              setPeriod(p);
              setPage(1);
            }}
          />
          {!runs ? (
            <p className="bk-history__empty">Loading…</p>
          ) : runs.length === 0 ? (
            <p className="bk-history__empty">
              No changes {period === 'all' ? 'yet' : 'in this period'}.
            </p>
          ) : (
            <div aria-busy={loading}>
              {byDay(runs, (r) => r.createdAt).map((group) => (
                <div key={group.day}>
                  <p className="bk-history__day">{group.day}</p>
                  <ol className="bk-bch__runs">
                    {group.items.map((run) => {
                      const open = run.changes.filter((c) => !c.revertedAt);
                      return (
                        <li key={run.runId} className="bk-bch__run">
                          <div className="bk-bch__run-head">
                            <div>
                              <strong>{run.chatTitle}</strong>
                              <span>
                                {timeOf(run.createdAt)}
                                {run.user ? ` · ${run.user}` : ''} · {run.changes.length} change
                                {run.changes.length === 1 ? '' : 's'}
                              </span>
                            </div>
                            {open.length ? (
                              <span className="bk-bch__run-actions">
                                {run.pending ? (
                                  <>
                                    <span className="bk-bch__tag is-pending">Not public yet</span>
                                    <button
                                      type="button"
                                      className="button"
                                      disabled={busy !== null}
                                      onClick={() => void preview(run)}
                                    >
                                      <Eye size={14} aria-hidden />{' '}
                                      {busy === `preview:${run.runId}` ? 'Opening…' : 'Preview'}
                                    </button>
                                    <button
                                      type="button"
                                      className="button button-primary"
                                      disabled={busy !== null}
                                      onClick={() => void keep(run)}
                                    >
                                      <Check size={14} aria-hidden />{' '}
                                      {busy === `keep:${run.runId}` ? 'Keeping…' : 'Keep'}
                                    </button>
                                  </>
                                ) : null}
                                <button
                                  type="button"
                                  className="button"
                                  disabled={busy !== null}
                                  onClick={() =>
                                    void revert(
                                      { runId: run.runId },
                                      `all ${open.length} change${open.length === 1 ? '' : 's'} from “${run.chatTitle}”`,
                                    )
                                  }
                                >
                                  <ArrowCounterClockwise size={14} aria-hidden />{' '}
                                  {busy === run.runId ? 'Reverting…' : 'Revert all'}
                                </button>
                              </span>
                            ) : (
                              <span className="bk-bch__tag">Reverted</span>
                            )}
                          </div>
                          {run.pending && previews[run.runId]?.length ? (
                            <p className="bk-bch__previews">
                              Preview (only you can see it, for 24 hours):{' '}
                              {previews[run.runId].map((p, i) => (
                                <span key={p.url}>
                                  {i ? ' · ' : ''}
                                  <a href={p.url} target="_blank" rel="noreferrer">
                                    {p.title} ↗
                                  </a>
                                </span>
                              ))}
                            </p>
                          ) : null}
                          <ul className="bk-bch__changes">
                            {run.changes.map((c) => {
                              const Icon = ICON[c.kind] ?? FileCode;
                              return (
                                <li key={c.id} className={c.revertedAt ? 'is-reverted' : ''}>
                                  <Icon size={15} aria-hidden />
                                  <span className="bk-bch__label">
                                    {c.label}
                                    <small>{c.created ? 'Created' : 'Changed'}</small>
                                  </span>
                                  {c.revertedAt ? (
                                    <span className="bk-bch__tag">Reverted</span>
                                  ) : (
                                    <button
                                      type="button"
                                      className="button-link"
                                      disabled={busy !== null}
                                      onClick={() => void revert({ changeId: c.id }, c.label)}
                                    >
                                      {busy === c.id ? 'Reverting…' : 'Revert'}
                                    </button>
                                  )}
                                </li>
                              );
                            })}
                          </ul>
                        </li>
                      );
                    })}
                  </ol>
                </div>
              ))}
            </div>
          )}
          {data ? (
            <ListPager
              page={data.page}
              pages={data.pages}
              total={data.total}
              perPage={data.perPage}
              noun="messages"
              busy={loading}
              onPage={setPage}
            />
          ) : null}
        </div>
      </div>
    </section>
  );
}
