import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import {
  AdminDataTable,
  type AdminTableColumn,
} from '../components/AdminDataTable';
import { confirmDialog } from '../components/ConfirmDialog';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import { useAdminHref } from '../lib/AdminEntryContext';
import type { FieldGroup } from './fields/FieldGroupEditPage';
import { ErrorNotice } from '../components/ErrorNotice';
import { useAuth } from '../auth/AuthContext';

type LocationOption = { value: string; label: string };

type SyncItem = {
  key: string;
  title: string;
  slug: string;
  theme: string;
  updatedAt: string | null;
  status: 'available' | 'sync';
};

type ListView = 'all' | 'trash';

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

export function BackendFieldsPage() {
  const href = useAdminHref();
  const [view, setView] = useState<ListView>('all');
  const [groups, setGroups] = useState<FieldGroup[]>([]);
  const [counts, setCounts] = useState({ all: 0, trash: 0 });
  const [pending, setPending] = useState<SyncItem[]>([]);
  const [locations, setLocations] = useState<LocationOption[]>([
    { value: 'post', label: 'Posts' },
    { value: 'page', label: 'Pages' },
    { value: 'user', label: 'Users' },
    { value: 'media', label: 'Media' },
  ]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const auth = useAuth();
  const isOwner = Boolean(auth.user?.isOwner);
  /** Sharing layouts with every site only makes sense once the network has a second site. */
  const [multisite, setMultisite] = useState(false);

  useEffect(() => {
    if (!isOwner) return;
    api<{ sites: unknown[] }>('/api/network/my-sites')
      .then((r) => setMultisite(r.sites.length > 1))
      .catch(() => setMultisite(false));
  }, [isOwner]);

  useEffect(() => {
    const n = (location.state as { notice?: string } | null)?.notice;
    if (n) setNotice(n);
  }, [location.key, location.state]);

  const load = useCallback(async () => {
    setError(null);
    const q = view === 'trash' ? '?status=trash' : '';
    const [res, meta, sync] = await Promise.all([
      api<{ groups: FieldGroup[]; counts?: { all: number; trash: number } }>(`/api/fields${q}`),
      api<{ locations: LocationOption[] }>('/api/fields/meta'),
      api<{ items: SyncItem[] }>('/api/fields/sync'),
    ]);
    setGroups(res.groups);
    if (res.counts) setCounts(res.counts);
    setPending(view === 'all' ? sync.items : []);
    if (meta.locations?.length) setLocations(meta.locations);
  }, [view]);

  useEffect(() => {
    setLoading(true);
    load()
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [load]);

  const onSync = async (keys?: string[]) => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const res = await api<{ synced: string[]; groups: FieldGroup[] }>('/api/fields/sync', {
        method: 'POST',
        json: keys?.length ? { keys } : {},
      });
      const n = res.synced.length;
      setNotice(
        n === 1
          ? `Synced “${pending.find((p) => p.key === res.synced[0])?.title ?? res.synced[0]}”.`
          : `Synced ${n} field group${n === 1 ? '' : 's'}.`,
      );
      await load();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const onTrash = async (group: FieldGroup) => {
    const ok = await confirmDialog({
      title: 'Move to trash',
      message: `Move field group “${group.title}” to trash? Theme layout files are kept in trash and can be restored.`,
      confirmLabel: 'Move to trash',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await api(`/api/fields/${group.id}`, { method: 'DELETE' });
      setNotice(`Field group “${group.title}” moved to trash.`);
      await load();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  /** Owner: share with every site, or make a global layout this site's own again. */
  const onSetGlobal = async (group: FieldGroup, global: boolean) => {
    const ok = await confirmDialog(
      global
        ? {
            title: 'Share with all sites',
            message: `Make “${group.title}” a global layout? Every site of the network can then use it with any theme. Sites can still customise their own copy.`,
            confirmLabel: 'Share with all sites',
          }
        : {
            title: 'Keep on this site only',
            message: `Make “${group.title}” this site's own layout again? Other sites stop seeing it (their customised copies stay).`,
            confirmLabel: 'Keep on this site',
            danger: true,
          },
    );
    if (!ok) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await api(`/api/fields/${group.id}/global`, { method: 'POST', json: { global } });
      setNotice(global ? `“${group.title}” is now shared with every site.` : `“${group.title}” is now this site's own layout.`);
      await load();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  /** This site's own copy of a global layout, to change its design for this site and theme. */
  const onCustomise = async (group: FieldGroup) => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const copy = await api<FieldGroup>(`/api/fields/${group.id}/customise`, { method: 'POST' });
      navigate(href(`fields/${copy.id}`), { state: { notice: `This site now has its own copy of “${group.title}”. Changes here stay on this site.` } });
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const onRestore = async (group: FieldGroup) => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await api(`/api/fields/${group.id}/restore`, { method: 'POST' });
      setNotice(`Field group “${group.title}” restored.`);
      await load();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const onDeleteForever = async (group: FieldGroup) => {
    const ok = await confirmDialog({
      title: 'Delete permanently',
      message: `Permanently delete “${group.title}”? Theme layout files in trash will be removed. This cannot be undone.`,
      confirmLabel: 'Delete permanently',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await api(`/api/fields/${group.id}?force=1`, { method: 'DELETE' });
      setNotice(`Field group “${group.title}” permanently deleted.`);
      await load();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const columns: AdminTableColumn<FieldGroup>[] = useMemo(
    () => [
      {
        key: 'title',
        header: 'Group',
        render: (group) => (
          <>
            {view === 'all' ? (
              <Link className="bk-table__primary" to={href(`fields/${group.id}`)}>
                <strong>{group.title}</strong>
              </Link>
            ) : (
              <strong>{group.title}</strong>
            )}
            {!group.active && view === 'all' ? (
              <span className="bk-table__badge">Inactive</span>
            ) : null}
            {group.scope === 'global' ? (
              <span className="bk-table__badge is-accent" title="Shared with every site of the network">
                Global
              </span>
            ) : null}
            {group.scope === 'customised' ? (
              <span className="bk-table__badge" title="This site's own copy of a global layout">
                Customised
              </span>
            ) : null}
            <div className="bk-table__row-actions">
              {view === 'all' && group.scope === 'global' && group.editable === false ? (
                <button type="button" className="button-link" disabled={busy} onClick={() => onCustomise(group)}>
                  Customise for this site
                </button>
              ) : view === 'all' ? (
                <>
                  <Link className="button-link" to={href(`fields/${group.id}`)}>
                    Edit
                  </Link>
                  {group.scope === 'global' ? (
                    <>
                      <span className="bk-table__sep">|</span>
                      <button type="button" className="button-link" disabled={busy} onClick={() => onCustomise(group)}>
                        Customise for this site
                      </button>
                      <span className="bk-table__sep">|</span>
                      <button type="button" className="button-link" disabled={busy} onClick={() => onSetGlobal(group, false)}>
                        Keep on this site only
                      </button>
                    </>
                  ) : isOwner && multisite && group.scope !== 'customised' ? (
                    <>
                      <span className="bk-table__sep">|</span>
                      <button type="button" className="button-link" disabled={busy} onClick={() => onSetGlobal(group, true)}>
                        Share with all sites
                      </button>
                    </>
                  ) : null}
                  <span className="bk-table__sep">|</span>
                  <button
                    type="button"
                    className="button-link is-danger"
                    disabled={busy}
                    onClick={() => onTrash(group)}
                  >
                    {group.scope === 'customised' ? 'Use global design' : 'Trash'}
                  </button>
                </>
              ) : (
                <>
                  <button
                    type="button"
                    className="button-link"
                    disabled={busy}
                    onClick={() => onRestore(group)}
                  >
                    Restore
                  </button>
                  <span className="bk-table__sep">|</span>
                  <button
                    type="button"
                    className="button-link is-danger"
                    disabled={busy}
                    onClick={() => onDeleteForever(group)}
                  >
                    Delete permanently
                  </button>
                </>
              )}
            </div>
          </>
        ),
      },
      {
        key: 'key',
        header: 'Key',
        render: (group) => <code>{group.key}</code>,
      },
      {
        key: 'fields',
        header: 'Fields',
        render: (group) => group.fieldCount,
      },
      {
        key: 'location',
        header: 'Location',
        render: (group) =>
          group.location.length
            ? group.location
                .map((v) => locations.find((o) => o.value === v)?.label ?? v)
                .join(', ')
            : '—',
      },
    ],
    [busy, href, locations, view, isOwner, multisite],
  );

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Field Groups"
        actions={
          view === 'all' ? (
            <button
              type="button"
              className="button button-primary"
              onClick={() => navigate(href('fields/new'))}
            >
              Add New
            </button>
          ) : null
        }
      />
      <p className="bk-muted">
        <button
          type="button"
          className={`button-link${view === 'all' ? ' is-current' : ''}`}
          onClick={() => setView('all')}
          style={{ fontWeight: view === 'all' ? 600 : undefined }}
        >
          All ({counts.all})
        </button>
        <span className="bk-table__sep"> | </span>
        <button
          type="button"
          className={`button-link${view === 'trash' ? ' is-current' : ''}`}
          onClick={() => setView('trash')}
          style={{ fontWeight: view === 'trash' ? 600 : undefined }}
        >
          Trash ({counts.trash})
        </button>
      </p>
      <p className="bk-muted">
        {view === 'trash'
          ? 'Trashed groups and their theme layout files can be restored or deleted permanently.'
          : `Define reusable field groups for pages, posts, and other content. ${counts.all} group${
              counts.all === 1 ? '' : 's'
            }.`}
      </p>

      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}

      {view === 'all' && pending.length ? (
        <div className="beekiri-notice is-warning" style={{ marginBottom: 20 }}>
          <p>
            <strong>Sync available.</strong> {pending.length} field group
            {pending.length === 1 ? '' : 's'} in the theme {pending.length === 1 ? 'is' : 'are'} not
            on this site yet, or {pending.length === 1 ? 'is' : 'are'} newer than the saved group.
          </p>
          <p className="bk-muted" style={{ marginBottom: 10 }}>
            Copy layout folders into the theme, then sync to create the field groups.
          </p>
          <table className="widefat striped" style={{ marginBottom: 12 }}>
            <thead>
              <tr>
                <th>Group</th>
                <th>Key</th>
                <th>Theme</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {pending.map((item) => (
                <tr key={item.key}>
                  <td>
                    <strong>{item.title}</strong>
                  </td>
                  <td>
                    <code>{item.key}</code>
                  </td>
                  <td>
                    <code>{item.theme}</code>
                  </td>
                  <td>{item.status === 'sync' ? 'Update' : 'Available'}</td>
                  <td>
                    <button
                      type="button"
                      className="button"
                      disabled={busy}
                      onClick={() => void onSync([item.key])}
                    >
                      Sync
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <button
            type="button"
            className="button button-primary"
            disabled={busy}
            onClick={() => void onSync()}
          >
            {busy ? 'Syncing…' : 'Sync all'}
          </button>
        </div>
      ) : null}

      <AdminDataTable
        rows={groups}
        columns={columns}
        getRowId={(g) => g.id}
        loading={loading}
        defaultPageSize={10}
        pageSizeOptions={[10, 25, 50]}
        emptyTitle={
          view === 'trash'
            ? 'Trash is empty.'
            : 'No field groups yet. Add one to start collecting custom data.'
        }
      />
    </div>
  );
}
