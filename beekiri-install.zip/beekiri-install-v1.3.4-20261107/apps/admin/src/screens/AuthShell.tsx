import { ReactNode, useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight } from '@phosphor-icons/react';
import '../styles/wp/install.css';
import './login-auth.css';
import { BrandMark } from '../components/BrandMark';
import { useAdminEntry } from '../lib/AdminEntryContext';

import { SITE_URL as SITE } from '../config';

type Props = {
  title: string;
  subtitle: string;
  children: ReactNode;
  brandTo?: string;
  /** Browser tab title; defaults from `title`. */
  documentTitle?: string;
  /** Shown under the form (e.g. "Forgot password?"); "Back to site" follows it. */
  footer?: ReactNode;
};

/** What Beekiri does, one line each, over a photo (Unsplash, licence-free; kept in public/brand/auth). */
const SLIDES = [
  {
    image: 'slide-1.webp',
    text: 'Design every page visually. Sections, layouts and content stay yours to edit, down to the last word.',
    name: 'The Beekiri editor',
    detail: 'Pages, layouts and Backend Fields',
  },
  {
    image: 'slide-2.webp',
    text: 'Shop, forms, SEO and analytics are built in, so there are no plugins to patch and nothing extra to host.',
    name: 'Everything in one place',
    detail: 'Shopping, Bee Forms, SEO and Analytics',
  },
  {
    image: 'slide-3.webp',
    text: 'Theme and core updates never touch your work. Your layouts and changes live in a child theme of their own.',
    name: 'Safe updates',
    detail: 'Child themes and automatic backups',
  },
] as const;

const SLIDE_MS = 7000;

function brandAsset(file: string): string {
  return `${import.meta.env.BASE_URL}brand/auth/${file}`;
}

/** Photo card beside the form: a slow carousel of what Beekiri does. */
function AuthVisual() {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const count = SLIDES.length;
  const go = useCallback((next: number) => setIndex(((next % count) + count) % count), [count]);

  useEffect(() => {
    if (paused || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const id = window.setTimeout(() => go(index + 1), SLIDE_MS);
    return () => window.clearTimeout(id);
  }, [go, index, paused]);

  const slide = SLIDES[index];

  return (
    <aside
      className="bk-auth__visual"
      aria-roledescription="carousel"
      aria-label="About Beekiri"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {SLIDES.map((s, i) => (
        <img
          key={s.image}
          className={`bk-auth__photo${i === index ? ' is-active' : ''}`}
          src={brandAsset(s.image)}
          alt=""
          loading={i === 0 ? 'eager' : 'lazy'}
          decoding="async"
          draggable={false}
        />
      ))}
      <div className="bk-auth__shade" aria-hidden />

      <div className="bk-auth__story">
        <div className="bk-auth__dots" role="tablist" aria-label="Slides">
          {SLIDES.map((s, i) => (
            <button
              key={s.image}
              type="button"
              role="tab"
              aria-selected={i === index}
              aria-label={`Slide ${i + 1}: ${s.name}`}
              className={`bk-auth__dot${i === index ? ' is-active' : ''}`}
              onClick={() => go(i)}
            />
          ))}
        </div>
        <p className="bk-auth__quote" aria-live="polite" key={`q-${index}`}>
          {slide.text}
        </p>
        <div className="bk-auth__by">
          <div key={`b-${index}`}>
            <strong>{slide.name}</strong>
            <span>{slide.detail}</span>
          </div>
          <div className="bk-auth__arrows">
            <button type="button" aria-label="Previous slide" onClick={() => go(index - 1)}>
              <ArrowLeft size={22} weight="light" aria-hidden />
            </button>
            <button type="button" aria-label="Next slide" onClick={() => go(index + 1)}>
              <ArrowRight size={22} weight="light" aria-hidden />
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}

/** Sign in / forgot / reset: the form on a dark panel, a photo card beside it. */
export function AuthShell({ title, subtitle, children, brandTo, documentTitle, footer }: Props) {
  const entry = useAdminEntry();
  const brandHref = brandTo ?? entry.path;
  useEffect(() => {
    const prev = document.title;
    document.title = documentTitle ?? `${title} — Beekiri CMS`;
    return () => {
      document.title = prev;
    };
  }, [documentTitle, title]);

  return (
    <div className="bk-auth">
      <main className="bk-auth__panel">
        <div className="bk-auth__panel-inner">
          <Link className="bk-auth__brand" to={brandHref} title="Beekiri">
            <BrandMark variant="logo" tone="white" size={24} title="Beekiri" />
          </Link>

          <div className="bk-auth__heading">
            <h1 className="bk-auth__title">{title}</h1>
            <p className="bk-auth__subtitle">{subtitle}</p>
          </div>

          {children}

          <div className="bk-auth__footer">
            {footer}
            <a href={SITE}>Back to site</a>
          </div>
        </div>
      </main>

      <AuthVisual />
    </div>
  );
}
