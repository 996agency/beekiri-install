import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { api, apiUrl, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { useThemeSwitch } from '../components/ThemeSwitchOverlay';
import { confirmDialog } from '../components/ConfirmDialog';
import { ErrorNotice } from '../components/ErrorNotice';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import { SITE_URL as LIVE_SITE } from '../config';
import { useAdminHref } from '../lib/AdminEntryContext';
import { activatedMessage, askThemeActivation } from '../lib/theme-activation';
import './theme-store.css';

type StoreTheme = {
  slug: string;
  name: string;
  tagline: string | null;
  description: string | null;
  version: string;
  price: number;
  priceLabel: string;
  free: boolean;
  owned: boolean;
  pending: boolean;
  hasScreenshot: boolean;
  screenshotVersion: string | null;
  demoUrl: string | null;
  tags: string[];
  installed: boolean;
  installedVersion: string | null;
  active: boolean;
  hasContent: boolean;
  contentInstalled: boolean;
  licence: {
    state: 'active' | 'available' | 'full';
    environment: string;
    limit: number;
    message: string | null;
    buyer: string | null;
    sites: { environment: string; domain: string | null; current: boolean }[];
  } | null;
  /** Only for the sites holding this licence: what the project's other sites enter. */
  licenceKey?: string | null;
};

const ENV_LABEL: Record<string, string> = { local: 'Local', staging: 'Staging', production: 'Production' };

type ContentResult = { installed: boolean; pages: { key: string; title: string; slug?: string; id?: string }[] };

type Catalog = {
  available: boolean;
  error?: string;
  currency: string;
  paymentMethod: 'stripe' | 'paypal' | 'manual';
  themes: StoreTheme[];
};

function message(e: unknown): string {
  if (e instanceof ApiError || e instanceof Error) return e.message;
  return 'Something went wrong. Try again.';
}

/** "1.2.0" > "1.10.0"-safe comparison: true when `next` is newer than `current`. */
function isNewer(next: string, current: string | null): boolean {
  if (!current) return false;
  const a = next.split('.').map((n) => parseInt(n, 10) || 0);
  const b = current.split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) > (b[i] ?? 0);
  }
  return false;
}

/** Appearance → Templates: themes from 996Agency. Buy once for this site, install, activate. */
export function AppearanceTemplatesPage() {
  const auth = useAuth();
  const href = useAdminHref();
  const navigate = useNavigate();
  const canEdit = auth.user?.capabilities.includes('edit_theme_options') ?? false;
  const [homeLink, setHomeLink] = useState<string | null>(null);
  const [params, setParams] = useSearchParams();
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  /** Theme whose "Enter licence key" field is open, and what was typed. */
  const [keyFor, setKeyFor] = useState<string | null>(null);
  const [keyValue, setKeyValue] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setCatalog(await api<Catalog>('/api/themes/store'));
    } catch (e) {
      setError(message(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  // Back from Stripe / PayPal: say what happened, then tidy the address bar.
  useEffect(() => {
    const outcome = params.get('purchase');
    if (!outcome) return;
    if (outcome === 'success') setNotice('Payment received — the theme is yours. Install it below.');
    else if (outcome === 'cancelled') setNotice('Checkout cancelled. Nothing was charged.');
    else setNotice('We could not confirm the payment yet. If you paid, the theme unlocks within a few minutes — refresh this page.');
    const next = new URLSearchParams(params);
    next.delete('purchase');
    next.delete('theme');
    setParams(next, { replace: true });
  }, [params, setParams]);

  const { overlay: switchOverlay, run: runSwitch } = useThemeSwitch(LIVE_SITE);

  const run = async (slug: string, fn: () => Promise<void>) => {
    setBusy(slug);
    setError('');
    setNotice('');
    try {
      await fn();
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(null);
    }
  };

  const buy = (t: StoreTheme) =>
    run(t.slug, async () => {
      const manual = catalog?.paymentMethod === 'manual';
      if (manual) {
        const ok = await confirmDialog({
          title: `Request “${t.name}” (${t.priceLabel})?`,
          message: '996Agency will contact you to arrange payment and unlock the theme for this site. You will see it here as soon as it is approved.',
          confirmLabel: 'Send request',
        });
        if (!ok) return;
      }
      const res = await api<{ status: 'owned' | 'pending' | 'checkout'; checkoutUrl: string | null }>(
        `/api/themes/store/${encodeURIComponent(t.slug)}/purchase`,
        { method: 'POST' },
      );
      if (res.status === 'checkout' && res.checkoutUrl) {
        window.location.assign(res.checkoutUrl);
        return;
      }
      setNotice(
        res.status === 'owned'
          ? `“${t.name}” is yours. Install it below.`
          : `Request sent. “${t.name}” unlocks here once 996Agency approves it.`,
      );
      await load();
    });

  const enterKey = (t: StoreTheme) =>
    run(t.slug, async () => {
      const res = await api<{ licensed: boolean; message?: string }>(`/api/themes/store/${encodeURIComponent(t.slug)}/licence-key`, {
        method: 'POST',
        json: { key: keyValue.trim() },
      });
      if (!res.licensed) throw new Error(res.message || 'That licence key does not unlock this theme here.');
      setKeyFor(null);
      setKeyValue('');
      setNotice(`Licence key accepted. Install “${t.name}” below — it takes this site's slot when you install or activate it.`);
      await load();
    });

  const copyKey = async (key: string) => {
    try {
      await navigator.clipboard.writeText(key);
      setNotice('Licence key copied.');
    } catch {
      setError('Could not copy. Select the key and copy it by hand.');
    }
  };

  const install = (t: StoreTheme) =>
    run(t.slug, async () => {
      await api(`/api/themes/store/${encodeURIComponent(t.slug)}/install`, { method: 'POST' });
      setNotice(t.installed ? `“${t.name}” updated to v${t.version}.` : `“${t.name}” installed. Activate it when you are ready.`);
      await load();
    });

  const installPages = async (t: StoreTheme): Promise<boolean> => {
    const ok = await confirmDialog({
      title: `Add the “${t.name}” pages?`,
      message: 'The theme comes with ready-made pages. They are added as new pages, the new Home becomes your front page and the menu points to them. Your existing pages are kept and you can edit everything in the page editor.',
      confirmLabel: 'Add pages',
      cancelLabel: 'Not now',
    });
    if (!ok) return false;
    const res = await api<ContentResult>(`/api/themes/${encodeURIComponent(t.slug)}/content/install`, { method: 'POST' });
    const home = res.pages.find((p) => p.slug === 'home') ?? res.pages[0];
    setHomeLink(home?.id ? href(`pages/${home.id}`) : null);
    setNotice(`“${t.name}” is active and its ${res.pages.length} pages are in. Open a page to start editing.`);
    return true;
  };

  const activate = (t: StoreTheme) =>
    run(t.slug, async () => {
      const choice = await askThemeActivation(t.slug, t.name, {
      openExtensions: () => navigate(href('extensions')),
      canManageExtensions: Boolean(auth.user?.capabilities.includes('manage_options')),
    });
      if (!choice) return;
      setHomeLink(null);
      await runSwitch(t.name, async () => {
        try {
          // Demo content (pages, shop products) only when the person chose to import it.
          const res = await api<Parameters<typeof activatedMessage>[1]>('/api/themes/activate', {
            method: 'POST',
            json: { slug: t.slug, ...choice },
          });
          await load();
          return activatedMessage(t.name, res);
        } catch (e) {
          throw new Error(message(e));
        }
      });
    });

  const addPages = (t: StoreTheme) =>
    run(t.slug, async () => {
      setHomeLink(null);
      await installPages(t);
      await load();
    });

  const deactivate = (t: StoreTheme) =>
    run(t.slug, async () => {
      const ok = await confirmDialog({
        title: `Deactivate “${t.name}”?`,
        message: 'Your site goes back to the Beekiri Child theme and its pages. This theme stays installed and its pages are kept, so they come back when you activate it again.',
        confirmLabel: 'Deactivate',
      });
      if (!ok) return;
      setHomeLink(null);
      await runSwitch('Beekiri Child', async () => {
        try {
          await api('/api/themes/deactivate', { method: 'POST', json: { slug: t.slug } });
          await load();
          return `Your site now shows Beekiri Child with its own pages. ${t.name}’s pages are saved for later.`;
        } catch (e) {
          throw new Error(message(e));
        }
      });
    });

  const resetPages = (t: StoreTheme) =>
    run(t.slug, async () => {
      const ok = await confirmDialog({
        title: `Reset the “${t.name}” pages?`,
        message: 'The pages this theme added go back to their original design and photos. Edits you made to those pages are replaced; your other pages, the menu and the photos already in Media are kept.',
        confirmLabel: 'Reset pages',
        cancelLabel: 'Keep my edits',
      });
      if (!ok) return;
      setHomeLink(null);
      const res = await api<ContentResult>(`/api/themes/${encodeURIComponent(t.slug)}/content/reset`, { method: 'POST' });
      const home = res.pages.find((p) => p.slug === 'home') ?? res.pages[0];
      setHomeLink(home?.id ? href(`pages/${home.id}`) : null);
      setNotice(`The “${t.name}” pages are back to the theme's design.`);
      await load();
    });

  const action = (t: StoreTheme) => {
    const working = busy === t.slug;
    if (!canEdit) return null;
    if (!t.owned) {
      if (t.pending) return <span className="bk-store__status">Waiting for approval</span>;
      return (
        <button type="button" className="button button-primary" disabled={working} onClick={() => void buy(t)}>
          {working ? 'Opening checkout…' : catalog?.paymentMethod === 'manual' ? `Request · ${t.priceLabel}` : `Buy · ${t.priceLabel}`}
        </button>
      );
    }
    if (!t.installed) {
      return (
        <button type="button" className="button button-primary" disabled={working} onClick={() => void install(t)}>
          {working ? 'Installing…' : 'Install'}
        </button>
      );
    }
    return (
      <>
        {isNewer(t.version, t.installedVersion) ? (
          <button type="button" className="button" disabled={working} onClick={() => void install(t)}>
            {working ? 'Updating…' : `Update to v${t.version}`}
          </button>
        ) : null}
        {t.active && t.hasContent && !t.contentInstalled ? (
          <button type="button" className="button" disabled={working} onClick={() => void addPages(t)}>
            {working ? 'Adding pages…' : 'Add its pages'}
          </button>
        ) : null}
        {t.active && t.hasContent && t.contentInstalled ? (
          <button type="button" className="button" disabled={working} onClick={() => void resetPages(t)}>
            {working ? 'Resetting…' : 'Reset its pages'}
          </button>
        ) : null}
        {t.active ? (
          <>
            <span className="bk-store__status is-active">Active</span>
            <button type="button" className="button" disabled={working} onClick={() => void deactivate(t)}>
              {working ? 'Deactivating…' : 'Deactivate'}
            </button>
          </>
        ) : (
          <button type="button" className="button button-primary" disabled={working} onClick={() => void activate(t)}>
            Activate
          </button>
        )}
      </>
    );
  };

  return (
    <div className="wrap wrap--wide bk-store">
      <PageHeader
        title="Templates"
        actions={
          <a className="button" href={LIVE_SITE} target="_blank" rel="noreferrer">
            View site
          </a>
        }
      />
      <p className="bk-store__lead">Themes made by 996Agency. Buy a theme once and it is yours on this site — install it, then activate it when you are ready.</p>

      {error ? <ErrorNotice message={error} onDismiss={() => setError('')} /> : null}
      {notice ? (
        <SuccessNotice
          message={notice}
          onDismiss={() => {
            setNotice('');
            setHomeLink(null);
          }}
        />
      ) : null}
      {switchOverlay}
      {notice && homeLink ? (
        <p className="bk-store__edit">
          <Link className="button button-primary" to={homeLink}>
            Edit the Home page
          </Link>
        </p>
      ) : null}

      {loading && !catalog ? (
        <div className="bk-store__grid" aria-busy="true">
          {[0, 1, 2].map((i) => (
            <div key={i} className="bk-store__card is-skeleton" />
          ))}
        </div>
      ) : catalog && !catalog.available ? (
        <div className="bk-store__empty">
          <strong>The theme store is not reachable right now.</strong>
          <p>{catalog.error} Your installed themes keep working.</p>
          <button type="button" className="button" onClick={() => void load()}>
            Try again
          </button>
        </div>
      ) : catalog && catalog.themes.length === 0 ? (
        <div className="bk-store__empty">
          <strong>No themes in the store yet.</strong>
          <p>New themes from 996Agency appear here.</p>
        </div>
      ) : catalog ? (
        <ul className="bk-store__grid">
          {[...catalog.themes].sort((a, b) => Number(b.active) - Number(a.active)).map((t) => (
            <li key={t.slug} className={`bk-store__card${t.active ? ' is-active' : ''}`}>
              <div className="bk-store__shot">
                {t.hasScreenshot ? (
                  <img src={apiUrl(`/api/themes/store/${encodeURIComponent(t.slug)}/screenshot?v=${encodeURIComponent(t.screenshotVersion ?? t.version)}`)} alt="" loading="lazy" />
                ) : (
                  <span className="bk-store__shot-empty" aria-hidden>
                    {t.name.slice(0, 1)}
                  </span>
                )}
              </div>
              <div className="bk-store__body">
                <div className="bk-store__title-row">
                  <h2 className="bk-store__name">{t.name}</h2>
                  <span className="bk-store__price">{t.owned && !t.free ? 'Owned' : t.priceLabel}</span>
                </div>
                {t.tagline ? <p className="bk-store__tagline">{t.tagline}</p> : null}
                {t.description ? <p className="bk-store__desc">{t.description}</p> : null}
                <p className="bk-store__meta">
                  v{t.version}
                  {t.hasContent ? (t.contentInstalled ? ' · pages added' : ' · includes pages') : ''}
                  {t.installed && t.installedVersion !== t.version ? ` · installed v${t.installedVersion}` : ''}
                  {t.tags.length ? ` · ${t.tags.join(' · ')}` : ''}
                </p>
                <div className="bk-store__actions">
                  {action(t)}
                  {t.demoUrl ? (
                    <a className="bk-store__demo" href={t.demoUrl} target="_blank" rel="noreferrer">
                      Live demo ↗
                    </a>
                  ) : null}
                </div>
                {t.licence && !t.free ? (
                  <div className="bk-store__licence">
                    <p className="bk-store__licence-head">
                      Licence · {t.licence.sites.length} of {t.licence.limit} sites
                      {t.licence.buyer ? <span> · {t.licence.buyer}</span> : null}
                    </p>
                    <ul className="bk-store__slots">
                      {(['local', 'staging', 'production'] as const).map((env) => {
                        const site = t.licence?.sites.find((x) => x.environment === env);
                        return (
                          <li key={env} className={`bk-store__slot${site ? ' is-used' : ''}${site?.current ? ' is-current' : ''}`}>
                            <strong>{ENV_LABEL[env]}</strong>
                            <span>{site ? `${site.domain ?? 'unknown address'}${site.current ? ' (this site)' : ''}` : 'Free'}</span>
                          </li>
                        );
                      })}
                    </ul>
                    {t.licence.message ? <p className="bk-store__note is-warning">{t.licence.message}</p> : null}
                    {t.licenceKey && canEdit ? (
                      <div className="bk-store__key">
                        <p className="bk-store__note">Licence key — enter it on this project's other sites (staging, production) under Templates. Keep it private.</p>
                        <div className="bk-store__key-row">
                          <code className="bk-store__key-value">{t.licenceKey}</code>
                          <button type="button" className="button" onClick={() => void copyKey(t.licenceKey as string)}>
                            Copy
                          </button>
                        </div>
                      </div>
                    ) : null}
                  </div>
                ) : null}
                {canEdit && !t.owned && !t.free && !t.pending ? (
                  keyFor === t.slug ? (
                    <form
                      className="bk-store__key"
                      onSubmit={(e) => {
                        e.preventDefault();
                        void enterKey(t);
                      }}
                    >
                      <label className="bk-store__note" htmlFor={`key-${t.slug}`}>
                        Licence key from the site that bought {t.name} (same owner e-mail address)
                      </label>
                      <div className="bk-store__key-row">
                        <input
                          id={`key-${t.slug}`}
                          className="regular-text"
                          value={keyValue}
                          onChange={(e) => setKeyValue(e.target.value)}
                          placeholder="bkl_…"
                          autoComplete="off"
                          spellCheck={false}
                        />
                        <button type="submit" className="button button-primary" disabled={busy === t.slug || !keyValue.trim()}>
                          {busy === t.slug ? 'Checking…' : 'Use key'}
                        </button>
                        <button type="button" className="button" onClick={() => setKeyFor(null)}>
                          Cancel
                        </button>
                      </div>
                    </form>
                  ) : (
                    <button type="button" className="bk-store__key-link" onClick={() => setKeyFor(t.slug)}>
                      Already bought it for this project? Enter licence key
                    </button>
                  )
                ) : null}
                {t.pending && !t.owned ? (
                  <p className="bk-store__note">996Agency unlocks this theme as soon as your payment is confirmed.</p>
                ) : null}
              </div>
            </li>
          ))}
        </ul>
      ) : null}

      <p className="bk-store__foot">
        Layouts in a theme are imported from Backend Fields — after installing, open <strong>Field Groups</strong> and use <strong>Sync</strong>.
      </p>
    </div>
  );
}
