import { useCallback, useEffect, useMemo, useState } from 'react';
import type { CapabilitySlug, RoleSlug } from '../cms-types';
import { SiteAccessCard } from './SiteAccessCard';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { confirmDialog } from '../components/ConfirmDialog';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import './user-permissions-page.css';

type CatalogItem = {
  slug: CapabilitySlug;
  label: string;
  description: string;
  group: string;
};

type PermUser = {
  id: string;
  username: string;
  displayName: string;
  email: string;
  role: RoleSlug;
  roleLabel: string;
  isOwner: boolean;
  roleDefaults: CapabilitySlug[];
  grants: CapabilitySlug[];
  denies: CapabilitySlug[];
  capabilities: CapabilitySlug[];
};

type RoleDef = {
  slug: RoleSlug;
  name: string;
  capabilities: CapabilitySlug[];
  userCount: number;
  locked: boolean;
};

type Tab = 'people' | 'roles';

type RowTag = { label: string; tone: 'added' | 'removed' | 'locked' };

type RowState = { checked: boolean; locked: boolean; tag: RowTag | null };

type Group = { group: string; items: CatalogItem[] };

/** Administrator always keeps these, so the site stays manageable. */
const ADMIN_REQUIRED = new Set<CapabilitySlug>([
  'read',
  'manage_options',
  'list_users',
  'edit_users',
  'create_users',
]);

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

function groupCatalog(catalog: CatalogItem[]): Group[] {
  const order: string[] = [];
  const map = new Map<string, CatalogItem[]>();
  for (const item of catalog) {
    if (!map.has(item.group)) {
      map.set(item.group, []);
      order.push(item.group);
    }
    map.get(item.group)!.push(item);
  }
  return order.map((group) => ({ group, items: map.get(group)! }));
}

function initials(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length > 1) return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  return name.trim().slice(0, 2).toUpperCase();
}

/** Capabilities on in one set but not the other. */
function countDiff(a: ReadonlySet<CapabilitySlug>, b: readonly CapabilitySlug[]) {
  const other = new Set(b);
  let n = 0;
  for (const slug of a) if (!other.has(slug)) n += 1;
  for (const slug of other) if (!a.has(slug)) n += 1;
  return n;
}

function plural(n: number, one: string, many = `${one}s`) {
  return `${n} ${n === 1 ? one : many}`;
}

function SearchField({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
}) {
  return (
    <label className="bk-perm__search">
      <svg width="13" height="13" viewBox="0 0 256 256" aria-hidden>
        <path
          fill="currentColor"
          d="m229.66 218.34-50.07-50.06a88.11 88.11 0 1 0-11.31 11.31l50.06 50.07a8 8 0 0 0 11.32-11.32ZM40 112a72 72 0 1 1 72 72 72.08 72.08 0 0 1-72-72Z"
        />
      </svg>
      <input
        type="search"
        value={value}
        placeholder={placeholder}
        aria-label={placeholder.replace(/…$/, '')}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}

function Meter({ on, total }: { on: number; total: number }) {
  return (
    <div className="bk-perm__stat">
      <span className="bk-perm__stat-num">
        <strong>{on}</strong> of {total} on
      </span>
      <span className="bk-perm__meter" aria-hidden>
        <span style={{ width: `${total ? (100 * on) / total : 0}%` }} />
      </span>
    </div>
  );
}

function CapabilityGroups({
  idPrefix,
  groups,
  query,
  rowState,
  onToggle,
  onSetGroup,
}: {
  idPrefix: string;
  groups: Group[];
  query: string;
  rowState: (slug: CapabilitySlug) => RowState;
  onToggle: (slug: CapabilitySlug) => void;
  onSetGroup: (slugs: CapabilitySlug[], on: boolean) => void;
}) {
  const q = query.trim().toLowerCase();
  const visible = groups
    .map(({ group, items }) => ({
      group,
      items: q
        ? items.filter((i) => `${i.label} ${i.description} ${group}`.toLowerCase().includes(q))
        : items,
    }))
    .filter((g) => g.items.length > 0);

  if (!visible.length) {
    return <p className="bk-perm__none">No permissions match “{query.trim()}”.</p>;
  }

  return (
    <div className="bk-perm__groups">
      {visible.map(({ group, items }) => {
        const states = items.map((i) => rowState(i.slug));
        const on = states.filter((s) => s.checked).length;
        const editable = items.filter((_, k) => !states[k].locked).map((i) => i.slug);
        const allOn = items.every((_, k) => states[k].locked || states[k].checked);
        return (
          <section key={group} className="bk-panel bk-perm__group">
            <div className="bk-panel__head">
              <h3 className="bk-panel__title">{group}</h3>
              <div className="bk-perm__group-tools">
                <span className="bk-perm__group-count">
                  {on} of {items.length}
                </span>
                {editable.length > 1 ? (
                  <button
                    type="button"
                    className="button-link"
                    onClick={() => onSetGroup(editable, !allOn)}
                  >
                    {allOn ? 'Turn all off' : 'Turn all on'}
                  </button>
                ) : null}
              </div>
            </div>
            <ul className="bk-perm__rows">
              {items.map((item, k) => {
                const s = states[k];
                const id = `${idPrefix}-${item.slug}`;
                return (
                  <li key={item.slug} className={`bk-perm__row${s.locked ? ' is-locked' : ''}`}>
                    <label className="bk-perm__row-text" htmlFor={id}>
                      <span className="bk-perm__row-label">
                        {item.label}
                        {s.tag ? (
                          <span className={`bk-perm__tag is-${s.tag.tone}`}>{s.tag.label}</span>
                        ) : null}
                      </span>
                      <span className="bk-perm__row-desc">{item.description}</span>
                    </label>
                    <button
                      id={id}
                      type="button"
                      role="switch"
                      aria-checked={s.checked}
                      aria-label={item.label}
                      disabled={s.locked}
                      className={`bk-perm__switch${s.checked ? ' is-on' : ''}`}
                      onClick={() => onToggle(item.slug)}
                    >
                      <span />
                    </button>
                  </li>
                );
              })}
            </ul>
          </section>
        );
      })}
    </div>
  );
}

function SaveBar({
  changes,
  target,
  busy,
  saveLabel,
  canSave,
  onDiscard,
  onSave,
}: {
  changes: number;
  target: string;
  busy: boolean;
  saveLabel: string;
  canSave: boolean;
  onDiscard: () => void;
  onSave: () => void;
}) {
  return (
    <div className="bk-perm__savebar" role="region" aria-label="Unsaved changes">
      <p>
        <strong>{plural(changes, 'unsaved change')}</strong> for {target}
      </p>
      <div className="bk-perm__savebar-actions">
        <button type="button" className="button" disabled={busy} onClick={onDiscard}>
          Discard
        </button>
        <button
          type="button"
          className="button button-primary"
          disabled={busy || !canSave}
          onClick={onSave}
        >
          {busy ? 'Saving…' : saveLabel}
        </button>
      </div>
    </div>
  );
}

export function UserPermissionsPage() {
  const auth = useAuth();
  const isOwner = auth.user?.isOwner ?? false;
  const canEdit = isOwner;

  const [tab, setTab] = useState<Tab>('people');
  const [catalog, setCatalog] = useState<CatalogItem[]>([]);
  const [users, setUsers] = useState<PermUser[]>([]);
  const [roles, setRoles] = useState<RoleDef[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedRoleSlug, setSelectedRoleSlug] = useState<RoleSlug | null>(null);
  const [draft, setDraft] = useState<Set<CapabilitySlug>>(new Set());
  const [roleDraftCaps, setRoleDraftCaps] = useState<Set<CapabilitySlug>>(new Set());
  const [roleName, setRoleName] = useState('');
  const [peopleQuery, setPeopleQuery] = useState('');
  const [capQuery, setCapQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const loadPeople = useCallback(async () => {
    const res = await api<{ catalog: CatalogItem[]; users: PermUser[] }>(
      '/api/users/permissions',
    );
    setCatalog(res.catalog);
    setUsers(res.users);
    return res.users;
  }, []);

  const loadRoles = useCallback(async () => {
    const res = await api<{ catalog: CatalogItem[]; roles: RoleDef[] }>(
      '/api/users/roles/manage',
    );
    setCatalog(res.catalog);
    setRoles(res.roles);
    return res.roles;
  }, []);

  useEffect(() => {
    if (!isOwner) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    Promise.all([loadPeople(), loadRoles()])
      .then(([people, roleList]) => {
        setSelectedId((prev) => {
          if (prev && people.some((u) => u.id === prev)) return prev;
          return people[0]?.id ?? null;
        });
        setSelectedRoleSlug((prev) => {
          if (prev && roleList.some((r) => r.slug === prev)) return prev;
          return roleList[0]?.slug ?? null;
        });
      })
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [isOwner, loadPeople, loadRoles]);

  const selected = useMemo(
    () => users.find((u) => u.id === selectedId) ?? null,
    [users, selectedId],
  );

  const selectedRole = useMemo(
    () => roles.find((r) => r.slug === selectedRoleSlug) ?? null,
    [roles, selectedRoleSlug],
  );

  useEffect(() => {
    if (!selected) {
      setDraft(new Set());
      return;
    }
    setDraft(new Set(selected.capabilities));
  }, [selected]);

  useEffect(() => {
    if (!selectedRole) {
      setRoleDraftCaps(new Set());
      setRoleName('');
      return;
    }
    setRoleDraftCaps(new Set(selectedRole.capabilities));
    setRoleName(selectedRole.name);
  }, [selectedRole]);

  const groups = useMemo(() => groupCatalog(catalog), [catalog]);

  const peopleChanges = useMemo(() => {
    if (!selected || selected.isOwner) return 0;
    return countDiff(draft, selected.capabilities);
  }, [draft, selected]);

  const roleChanges = useMemo(() => {
    if (!selectedRole) return 0;
    const nameChanged = roleName.trim() !== selectedRole.name ? 1 : 0;
    return countDiff(roleDraftCaps, selectedRole.capabilities) + nameChanged;
  }, [roleDraftCaps, roleName, selectedRole]);

  const peopleDirty = peopleChanges > 0;
  const roleDirty = roleChanges > 0;

  useEffect(() => {
    if (!peopleDirty && !roleDirty) return;
    const warn = (e: BeforeUnloadEvent) => {
      e.preventDefault();
    };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [peopleDirty, roleDirty]);

  const visibleUsers = useMemo(() => {
    const q = peopleQuery.trim().toLowerCase();
    if (!q) return users;
    return users.filter((u) =>
      `${u.displayName} ${u.username} ${u.email} ${u.roleLabel}`.toLowerCase().includes(q),
    );
  }, [users, peopleQuery]);

  const confirmDiscard = () =>
    confirmDialog({
      title: 'Discard changes?',
      message: 'Your unsaved permission changes will be lost.',
      confirmLabel: 'Discard',
      danger: true,
    });

  const discardPeople = () => {
    if (selected) setDraft(new Set(selected.capabilities));
  };

  const discardRole = () => {
    if (!selectedRole) return;
    setRoleDraftCaps(new Set(selectedRole.capabilities));
    setRoleName(selectedRole.name);
  };

  const switchTab = async (next: Tab) => {
    if (next === tab) return;
    const dirty = tab === 'people' ? peopleDirty : roleDirty;
    if (dirty) {
      if (!(await confirmDiscard())) return;
      if (tab === 'people') discardPeople();
      else discardRole();
    }
    setTab(next);
    setCapQuery('');
    setNotice(null);
    setError(null);
  };

  const selectUser = async (id: string) => {
    if (id === selectedId) return;
    if (peopleDirty && !(await confirmDiscard())) return;
    setSelectedId(id);
    setNotice(null);
    setError(null);
  };

  const selectRole = async (slug: RoleSlug) => {
    if (slug === selectedRoleSlug) return;
    if (roleDirty && !(await confirmDiscard())) return;
    setSelectedRoleSlug(slug);
    setNotice(null);
    setError(null);
  };

  const userLocked = (slug: CapabilitySlug) =>
    !selected || selected.isOwner || !canEdit || slug === 'read';

  const roleLocked = (slug: CapabilitySlug) =>
    !selectedRole ||
    !canEdit ||
    slug === 'read' ||
    (selectedRole.slug === 'administrator' && ADMIN_REQUIRED.has(slug));

  const setCaps = (
    update: (fn: (prev: Set<CapabilitySlug>) => Set<CapabilitySlug>) => void,
    slugs: CapabilitySlug[],
    on: boolean,
  ) => {
    update((prev) => {
      const next = new Set(prev);
      for (const slug of slugs) {
        if (on) next.add(slug);
        else next.delete(slug);
      }
      next.add('read');
      return next;
    });
  };

  const toggleCap = (slug: CapabilitySlug) => {
    if (userLocked(slug)) return;
    setCaps(setDraft, [slug], !draft.has(slug));
  };

  const toggleRoleCap = (slug: CapabilitySlug) => {
    if (roleLocked(slug)) return;
    setCaps(setRoleDraftCaps, [slug], !roleDraftCaps.has(slug));
  };

  const resetToRole = () => {
    if (!selected || selected.isOwner) return;
    setDraft(new Set(selected.roleDefaults));
  };

  const savePeople = async () => {
    if (!selected || selected.isOwner || !canEdit) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const updated = await api<PermUser>(`/api/users/${selected.id}/permissions`, {
        method: 'PATCH',
        json: { capabilities: [...draft] },
      });
      setUsers((list) => list.map((u) => (u.id === updated.id ? updated : u)));
      setNotice(`Permissions saved for ${updated.displayName || updated.username}.`);
      if (updated.id === auth.user?.id) await auth.refresh();
      await loadRoles();
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const saveRole = async () => {
    if (!selectedRole || !canEdit) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const updated = await api<{ slug: RoleSlug; name: string; capabilities: CapabilitySlug[] }>(
        `/api/users/roles/${selectedRole.slug}`,
        {
          method: 'PATCH',
          json: {
            name: roleName.trim(),
            capabilities: [...roleDraftCaps],
          },
        },
      );
      setRoles((list) =>
        list.map((r) =>
          r.slug === updated.slug
            ? { ...r, name: updated.name, capabilities: updated.capabilities }
            : r,
        ),
      );
      setNotice(`Role “${updated.name}” saved. It applies to everyone with that role.`);
      const people = await loadPeople();
      setUsers(people);
      if (auth.user?.role === updated.slug) await auth.refresh();
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  if (!isOwner) {
    return (
      <div className="wrap">
        <PageHeader title="User Permissions" />
        <div className="beekiri-notice is-error" role="alert">
          <p>Only the site Owner can manage user permissions.</p>
        </div>
      </div>
    );
  }

  const onCount = (caps: ReadonlySet<CapabilitySlug>) =>
    catalog.filter((i) => caps.has(i.slug)).length;

  const userRow = (slug: CapabilitySlug): RowState => {
    const checked = selected?.isOwner ? true : draft.has(slug);
    const locked = userLocked(slug);
    if (slug === 'read') return { checked, locked, tag: { label: 'Always on', tone: 'locked' } };
    if (!selected || selected.isOwner) return { checked, locked, tag: null };
    const fromRole = selected.roleDefaults.includes(slug);
    const tag: RowTag | null =
      fromRole === checked
        ? null
        : checked
          ? { label: 'Added', tone: 'added' }
          : { label: 'Removed', tone: 'removed' };
    return { checked, locked, tag };
  };

  const roleRow = (slug: CapabilitySlug): RowState => {
    const checked = roleDraftCaps.has(slug);
    const locked = roleLocked(slug);
    if (slug === 'read') return { checked, locked, tag: { label: 'Always on', tone: 'locked' } };
    if (locked && selectedRole?.slug === 'administrator') {
      return { checked, locked, tag: { label: 'Required', tone: 'locked' } };
    }
    return { checked, locked, tag: null };
  };

  const selectedName = selected ? selected.displayName || selected.username : '';
  const roleDiff = selected && !selected.isOwner ? countDiff(draft, selected.roleDefaults) : 0;

  return (
    <div className="wrap wrap--wide bk-perm">
      <PageHeader title="User Permissions" />
      <p className="bk-muted bk-perm__intro">
        Set what each role can do, then change it for one person when needed. The Owner always has
        every permission.
      </p>

      <nav className="bk-tabs" aria-label="Permissions sections">
        <button
          type="button"
          className={`bk-tabs__item${tab === 'people' ? ' is-active' : ''}`}
          aria-current={tab === 'people' ? 'page' : undefined}
          onClick={() => void switchTab('people')}
        >
          People
          {users.length ? <span className="bk-tabs__count">{users.length}</span> : null}
        </button>
        <button
          type="button"
          className={`bk-tabs__item${tab === 'roles' ? ' is-active' : ''}`}
          aria-current={tab === 'roles' ? 'page' : undefined}
          onClick={() => void switchTab('roles')}
        >
          Roles
          {roles.length ? <span className="bk-tabs__count">{roles.length}</span> : null}
        </button>
      </nav>

      {error ? (
        <div className="beekiri-notice is-error bk-perm__notice" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      {loading ? <p className="bk-muted bk-perm__none">Loading permissions…</p> : null}

      {!loading && tab === 'people' && users.length === 0 ? (
        <p className="bk-muted bk-perm__none">No users to manage yet. Add a user first.</p>
      ) : null}

      {!loading && tab === 'people' && users.length > 0 ? (
        <div className="bk-perm__layout">
          <aside className="bk-panel bk-perm__side" aria-label="People">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">People</h2>
              <span className="bk-perm__head-meta">{users.length}</span>
            </div>
            <div className="bk-perm__side-search">
              <SearchField value={peopleQuery} onChange={setPeopleQuery} placeholder="Search people…" />
            </div>
            {visibleUsers.length === 0 ? (
              <p className="bk-perm__none bk-perm__side-none">No people match “{peopleQuery.trim()}”.</p>
            ) : (
              <ul className="bk-perm__picks">
                {visibleUsers.map((u) => {
                  const name = u.displayName || u.username;
                  const custom = u.isOwner ? 0 : u.grants.length + u.denies.length;
                  return (
                    <li key={u.id}>
                      <button
                        type="button"
                        className={`bk-perm__pick${u.id === selectedId ? ' is-active' : ''}`}
                        aria-current={u.id === selectedId ? 'true' : undefined}
                        onClick={() => void selectUser(u.id)}
                      >
                        <span className="bk-perm__avatar" aria-hidden>
                          {initials(name)}
                        </span>
                        <span className="bk-perm__pick-text">
                          <span className="bk-perm__pick-name">
                            <span className="bk-perm__pick-title">{name}</span>
                            {u.id === auth.user?.id ? (
                              <span className="bk-table__badge">You</span>
                            ) : null}
                            {u.isOwner ? (
                              <span className="bk-table__badge is-accent">Owner</span>
                            ) : null}
                          </span>
                          <span className="bk-perm__pick-meta">
                            @{u.username} · {u.roleLabel}
                          </span>
                        </span>
                        {custom ? (
                          <span
                            className="bk-perm__pick-tag"
                            title={`${plural(custom, 'permission')} differ from the ${u.roleLabel} role`}
                          >
                            {custom} custom
                          </span>
                        ) : null}
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </aside>

          <section className="bk-perm__main" aria-live="polite">
            {!selected ? (
              <p className="bk-muted bk-perm__none">Select a person to manage their permissions.</p>
            ) : (
              <>
                <div className="bk-panel bk-perm__summary">
                  <div className="bk-perm__summary-top">
                    <span className="bk-perm__avatar is-lg" aria-hidden>
                      {initials(selectedName)}
                    </span>
                    <div className="bk-perm__summary-text">
                      <h2>
                        {selectedName}
                        {selected.isOwner ? (
                          <span className="bk-table__badge is-accent">Owner</span>
                        ) : null}
                      </h2>
                      <p>
                        {selected.roleLabel} · @{selected.username}
                        {selected.email ? ` · ${selected.email}` : ''}
                      </p>
                    </div>
                    <Meter
                      on={selected.isOwner ? catalog.length : onCount(draft)}
                      total={catalog.length}
                    />
                  </div>
                  <div className="bk-perm__summary-foot">
                    {selected.isOwner ? (
                      <p>The Owner always has every permission. These can’t be turned off.</p>
                    ) : roleDiff ? (
                      <>
                        <p>
                          {plural(roleDiff, 'permission')} {roleDiff === 1 ? 'differs' : 'differ'} from
                          the <strong>{selected.roleLabel}</strong> role.
                        </p>
                        <button
                          type="button"
                          className="button-link"
                          disabled={busy}
                          onClick={resetToRole}
                        >
                          Reset to role defaults
                        </button>
                      </>
                    ) : (
                      <p>
                        Uses the <strong>{selected.roleLabel}</strong> role’s permissions. Turn one
                        on or off to change it for {selectedName} only.
                      </p>
                    )}
                  </div>
                </div>

                <SiteAccessCard userId={selected.id} name={selectedName} />

                <div className="bk-perm__toolbar">
                  <SearchField value={capQuery} onChange={setCapQuery} placeholder="Search permissions…" />
                </div>

                <CapabilityGroups
                  idPrefix="perm-user"
                  groups={groups}
                  query={capQuery}
                  rowState={userRow}
                  onToggle={toggleCap}
                  onSetGroup={(slugs, on) => setCaps(setDraft, slugs, on)}
                />

                {peopleDirty ? (
                  <SaveBar
                    changes={peopleChanges}
                    target={selectedName}
                    busy={busy}
                    saveLabel="Save permissions"
                    canSave
                    onDiscard={discardPeople}
                    onSave={() => void savePeople()}
                  />
                ) : null}
              </>
            )}
          </section>
        </div>
      ) : null}

      {!loading && tab === 'roles' ? (
        <div className="bk-perm__layout">
          <aside className="bk-panel bk-perm__side" aria-label="Roles">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Roles</h2>
              <span className="bk-perm__head-meta">{roles.length}</span>
            </div>
            <ul className="bk-perm__picks">
              {roles.map((r) => (
                <li key={r.slug}>
                  <button
                    type="button"
                    className={`bk-perm__pick${r.slug === selectedRoleSlug ? ' is-active' : ''}`}
                    aria-current={r.slug === selectedRoleSlug ? 'true' : undefined}
                    onClick={() => void selectRole(r.slug)}
                  >
                    <span className="bk-perm__avatar is-role" aria-hidden>
                      {initials(r.name)}
                    </span>
                    <span className="bk-perm__pick-text">
                      <span className="bk-perm__pick-name">
                        <span className="bk-perm__pick-title">{r.name}</span>
                      </span>
                      <span className="bk-perm__pick-meta">
                        {r.slug} · {plural(r.userCount, 'user')}
                      </span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </aside>

          <section className="bk-perm__main" aria-live="polite">
            {!selectedRole ? (
              <p className="bk-muted bk-perm__none">Select a role to edit.</p>
            ) : (
              <>
                <div className="bk-panel bk-perm__summary">
                  <div className="bk-perm__summary-top">
                    <span className="bk-perm__avatar is-lg is-role" aria-hidden>
                      {initials(selectedRole.name)}
                    </span>
                    <div className="bk-perm__summary-text">
                      <h2>{selectedRole.name}</h2>
                      <p>
                        {selectedRole.slug} · {plural(selectedRole.userCount, 'user')} · applies to
                        everyone with this role
                      </p>
                    </div>
                    <Meter on={onCount(roleDraftCaps)} total={catalog.length} />
                  </div>
                  <div className="bk-perm__summary-foot bk-perm__role-name">
                    <label htmlFor="role_display_name">Display name</label>
                    <input
                      id="role_display_name"
                      type="text"
                      maxLength={80}
                      value={roleName}
                      disabled={!canEdit || busy}
                      onChange={(e) => setRoleName(e.target.value)}
                      placeholder="e.g. Writer"
                    />
                    <p>Shown in user forms and lists. The slug stays {selectedRole.slug}.</p>
                  </div>
                  {selectedRole.locked ? (
                    <div className="bk-perm__summary-foot">
                      <p>
                        Administrator always keeps the permissions marked <strong>Required</strong>,
                        so the site stays manageable.
                      </p>
                    </div>
                  ) : null}
                </div>

                <div className="bk-perm__toolbar">
                  <SearchField value={capQuery} onChange={setCapQuery} placeholder="Search permissions…" />
                </div>

                <CapabilityGroups
                  idPrefix="perm-role"
                  groups={groups}
                  query={capQuery}
                  rowState={roleRow}
                  onToggle={toggleRoleCap}
                  onSetGroup={(slugs, on) => setCaps(setRoleDraftCaps, slugs, on)}
                />

                {roleDirty ? (
                  <SaveBar
                    changes={roleChanges}
                    target={`the ${selectedRole.name} role`}
                    busy={busy}
                    saveLabel="Save role"
                    canSave={Boolean(roleName.trim())}
                    onDiscard={discardRole}
                    onSave={() => void saveRole()}
                  />
                ) : null}
              </>
            )}
          </section>
        </div>
      ) : null}
    </div>
  );
}
