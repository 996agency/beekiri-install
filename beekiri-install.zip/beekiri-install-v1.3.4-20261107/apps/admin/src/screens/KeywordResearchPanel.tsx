import { FormEvent, useMemo, useState } from 'react';
import {
  CaretDown,
  DownloadSimple,
  Faders,
  MagnifyingGlass,
  MapPin,
  X,
} from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { safeHref } from '../lib/safe-html';

type KeywordIntent = 'nav' | 'info' | 'comm' | 'trans';

type KeywordRow = {
  keyword: string;
  volume: number | null;
  cpc: number | null;
  competition: number | null;
  score: number;
  intent: KeywordIntent;
};

type SerpRow = {
  position: number;
  title: string;
  url: string;
  domain: string;
};

type ResearchResult = {
  query: string;
  country: string;
  city: string;
  seed: KeywordRow;
  keywords: KeywordRow[];
  trends: { label: string; values: number[] };
  serp: SerpRow[];
};

type IntentFilter = 'all' | KeywordIntent;
type SortKey = 'keyword' | 'volume' | 'cpc' | 'competition' | 'score';

const COUNTRIES = [
  { code: 'US', label: 'United States' },
  { code: 'GB', label: 'United Kingdom' },
  { code: 'CA', label: 'Canada' },
  { code: 'AU', label: 'Australia' },
  { code: 'DE', label: 'Germany' },
  { code: 'FR', label: 'France' },
  { code: 'NL', label: 'Netherlands' },
  { code: 'ES', label: 'Spain' },
  { code: 'IT', label: 'Italy' },
];

const INTENT_LABEL: Record<KeywordIntent, string> = {
  nav: 'Nav',
  info: 'Info',
  comm: 'Comm',
  trans: 'Trans',
};

function scoreClass(score: number): string {
  if (score >= 70) return 'is-hard';
  if (score >= 40) return 'is-mid';
  return 'is-easy';
}

function formatVol(n: number | null): string {
  if (n == null) return '—';
  return Intl.NumberFormat('en-US').format(n);
}

function formatCpc(n: number | null): string {
  if (n == null) return '—';
  return `$${n.toFixed(2)}`;
}

function formatComp(n: number | null): string {
  if (n == null) return '—';
  return n.toFixed(2);
}

function TrendChart({ values }: { values: number[] }) {
  const w = 420;
  const h = 160;
  const pad = { t: 12, r: 12, b: 24, l: 36 };
  const innerW = w - pad.l - pad.r;
  const innerH = h - pad.t - pad.b;
  const max = Math.max(1, ...values);
  const min = Math.min(...values, 0);
  const span = Math.max(1, max - min);
  const x = (i: number) => pad.l + (values.length <= 1 ? 0 : (i / (values.length - 1)) * innerW);
  const y = (v: number) => pad.t + innerH - ((v - min) / span) * innerH;
  const line = values.map((v, i) => `${i === 0 ? 'M' : 'L'}${x(i)} ${y(v)}`).join(' ');
  const area =
    values.length > 0
      ? `${line} L${x(values.length - 1)} ${pad.t + innerH} L${x(0)} ${pad.t + innerH} Z`
      : '';
  const ticks = [max, Math.round((max + min) / 2), min];

  return (
    <svg className="bk-kw-trend" viewBox={`0 0 ${w} ${h}`} role="img" aria-label="Search trends">
      {ticks.map((t, i) => {
        const yy = y(t);
        return (
          <g key={i}>
            <line x1={pad.l} x2={w - pad.r} y1={yy} y2={yy} className="bk-kw-trend__grid" />
            <text x={pad.l - 6} y={yy + 3} textAnchor="end" className="bk-kw-trend__tick">
              {t >= 1000 ? `${Math.round(t / 1000)}K` : t}
            </text>
          </g>
        );
      })}
      {area ? <path d={area} className="bk-kw-trend__area" /> : null}
      {line ? <path d={line} className="bk-kw-trend__line" /> : null}
      {values.map((v, i) => (
        <circle key={i} cx={x(i)} cy={y(v)} r={2.5} className="bk-kw-trend__dot" />
      ))}
    </svg>
  );
}

function exportCsv(filename: string, headers: string[], rows: string[][]) {
  const esc = (v: string) => `"${v.replace(/"/g, '""')}"`;
  const body = [headers, ...rows].map((r) => r.map(esc).join(',')).join('\n');
  const blob = new Blob([body], { type: 'text/csv;charset=utf-8' });
  const href = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = href;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(href);
}

export function KeywordResearchPanel() {
  const [query, setQuery] = useState('');
  const [country, setCountry] = useState('US');
  const [city, setCity] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ResearchResult | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [intentFilter, setIntentFilter] = useState<IntentFilter>('all');
  const [sortKey, setSortKey] = useState<SortKey>('score');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  const rows = useMemo(() => {
    if (!result) return [] as KeywordRow[];
    let list = result.keywords;
    if (intentFilter !== 'all') list = list.filter((r) => r.intent === intentFilter);
    const dir = sortDir === 'asc' ? 1 : -1;
    return [...list].sort((a, b) => {
      const av = a[sortKey];
      const bv = b[sortKey];
      if (typeof av === 'string' && typeof bv === 'string') return av.localeCompare(bv) * dir;
      const an = av == null ? -1 : Number(av);
      const bn = bv == null ? -1 : Number(bv);
      return (an - bn) * dir;
    });
  }, [result, intentFilter, sortKey, sortDir]);

  async function runSearch(term: string) {
    const q = term.trim();
    if (!q) return;
    setBusy(true);
    setError(null);
    try {
      const data = await api<ResearchResult>('/api/bee-seo/keywords', {
        method: 'POST',
        json: {
          query: q,
          country,
          ...(city.trim() ? { city: city.trim() } : {}),
        },
      });
      setResult(data);
      setTags((prev) => (prev.includes(data.query) ? prev : [...prev, data.query]));
      setSelected(new Set());
      setIntentFilter('all');
    } catch (err) {
      setError(err instanceof ApiError || err instanceof Error ? err.message : 'Search failed.');
    } finally {
      setBusy(false);
    }
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    void runSearch(query);
  }

  function toggleSort(key: SortKey) {
    if (sortKey === key) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else {
      setSortKey(key);
      setSortDir(key === 'keyword' ? 'asc' : 'desc');
    }
  }

  function toggleSelect(keyword: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(keyword)) next.delete(keyword);
      else next.add(keyword);
      return next;
    });
  }

  function toggleSelectAll() {
    if (!rows.length) return;
    if (selected.size === rows.length) setSelected(new Set());
    else setSelected(new Set(rows.map((r) => r.keyword)));
  }

  function onExportKeywords() {
    exportCsv(
      'beekiri-keywords.csv',
      ['Keyword', 'Volume', 'CPC', 'Competition', 'Score', 'Intent'],
      rows.map((r) => [
        r.keyword,
        r.volume == null ? '' : String(r.volume),
        r.cpc == null ? '' : String(r.cpc),
        r.competition == null ? '' : String(r.competition),
        String(r.score),
        INTENT_LABEL[r.intent],
      ]),
    );
  }

  function onExportSerp() {
    if (!result) return;
    exportCsv(
      'beekiri-serp.csv',
      ['Position', 'Title', 'URL', 'Domain'],
      result.serp.map((r) => [String(r.position), r.title, r.url, r.domain]),
    );
  }

  const seed = result?.seed;
  const countryLabel = COUNTRIES.find((c) => c.code === country)?.label ?? country;

  return (
    <div className="bk-kw">
      <header className="bk-kw__head">
        <h2 className="bk-kw__title">Keyword Research</h2>
        <p className="bk-kw__sub">Discover keyword ideas, search demand, and ranking opportunities.</p>
      </header>

      <form className="bk-kw__search" onSubmit={onSubmit}>
        <label className="bk-kw__field bk-kw__field--grow">
          <MagnifyingGlass size={18} weight="regular" aria-hidden />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Enter a keyword"
            disabled={busy}
          />
        </label>
        <label className="bk-kw__field bk-kw__field--country">
          <select value={country} onChange={(e) => setCountry(e.target.value)} disabled={busy}>
            {COUNTRIES.map((c) => (
              <option key={c.code} value={c.code}>
                {c.label}
              </option>
            ))}
          </select>
          <CaretDown size={14} weight="bold" aria-hidden />
        </label>
        <label className="bk-kw__field bk-kw__field--city">
          <MapPin size={16} weight="regular" aria-hidden />
          <input
            type="text"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            placeholder="City (optional)"
            disabled={busy}
          />
        </label>
        <button type="button" className="button bk-kw__options" disabled title="More options soon">
          <Faders size={16} weight="regular" aria-hidden />
          Options
        </button>
        <button type="submit" className="button button-primary bk-kw__go" disabled={busy || !query.trim()}>
          {busy ? 'Searching…' : 'Search'}
        </button>
      </form>

      {tags.length ? (
        <div className="bk-kw__tags">
          {tags.map((t) => (
            <button
              key={t}
              type="button"
              className="bk-kw__tag"
              onClick={() => {
                setQuery(t);
                void runSearch(t);
              }}
            >
              {t}
              <span
                role="button"
                tabIndex={0}
                aria-label={`Remove ${t}`}
                onClick={(e) => {
                  e.stopPropagation();
                  setTags((prev) => prev.filter((x) => x !== t));
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    e.stopPropagation();
                    setTags((prev) => prev.filter((x) => x !== t));
                  }
                }}
              >
                <X size={12} weight="bold" />
              </span>
            </button>
          ))}
        </div>
      ) : null}

      {error ? <p className="bk-seo__banner is-error">{error}</p> : null}

      {!result && !busy ? (
        <div className="bk-kw__empty">
          <p>Search a seed keyword to load ideas, trends, and SERP competitors.</p>
        </div>
      ) : null}

      {result && seed ? (
        <div className="bk-kw__layout">
          <div className="bk-kw__main">
            <div className="bk-kw__summary">
              <strong className="bk-kw__seed">{seed.keyword}</strong>
              <span className={`bk-kw__score ${scoreClass(seed.score)}`}>{seed.score}</span>
              <span className="bk-kw__metric">
                Vol <b>{formatVol(seed.volume)}</b>
              </span>
              <span className="bk-kw__metric">
                CPC <b>{formatCpc(seed.cpc)}</b>
              </span>
              <span className="bk-kw__metric">
                Comp <b>{formatComp(seed.competition)}</b>
              </span>
              <span className={`bk-kw__intent is-${seed.intent}`}>{INTENT_LABEL[seed.intent]}</span>
            </div>

            <div className="bk-kw__table-card">
              <div className="bk-kw__table-bar">
                <div className="bk-kw__table-bar-left">
                  <button
                    type="button"
                    className={`button${filtersOpen || intentFilter !== 'all' ? ' button-primary' : ''}`}
                    onClick={() => setFiltersOpen((v) => !v)}
                  >
                    <Faders size={16} weight="regular" aria-hidden />
                    Filters
                  </button>
                  <span className="bk-kw__showing">Showing {rows.length} keywords</span>
                </div>
                <button type="button" className="button" onClick={onExportKeywords}>
                  <DownloadSimple size={16} weight="regular" aria-hidden />
                  Export
                </button>
              </div>

              {filtersOpen ? (
                <div className="bk-kw__filters">
                  {(
                    [
                      ['all', 'All'],
                      ['nav', 'Nav'],
                      ['info', 'Info'],
                      ['comm', 'Comm'],
                      ['trans', 'Trans'],
                    ] as const
                  ).map(([id, label]) => (
                    <button
                      key={id}
                      type="button"
                      className={`button${intentFilter === id ? ' button-primary' : ''}`}
                      onClick={() => setIntentFilter(id)}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              ) : null}

              <div className="bk-kw__table-wrap">
                <table className="bk-kw__table">
                  <thead>
                    <tr>
                      <th className="bk-kw__check">
                        <input
                          type="checkbox"
                          checked={rows.length > 0 && selected.size === rows.length}
                          onChange={toggleSelectAll}
                          aria-label="Select all"
                        />
                      </th>
                      <th>
                        <button type="button" className="bk-kw__sort" onClick={() => toggleSort('keyword')}>
                          Keyword{sortKey === 'keyword' ? (sortDir === 'asc' ? ' ↑' : ' ↓') : ''}
                        </button>
                      </th>
                      <th>
                        <button type="button" className="bk-kw__sort" onClick={() => toggleSort('volume')}>
                          Volume{sortKey === 'volume' ? (sortDir === 'asc' ? ' ↑' : ' ↓') : ''}
                        </button>
                      </th>
                      <th>
                        <button type="button" className="bk-kw__sort" onClick={() => toggleSort('cpc')}>
                          CPC{sortKey === 'cpc' ? (sortDir === 'asc' ? ' ↑' : ' ↓') : ''}
                        </button>
                      </th>
                      <th>
                        <button type="button" className="bk-kw__sort" onClick={() => toggleSort('competition')}>
                          Comp.{sortKey === 'competition' ? (sortDir === 'asc' ? ' ↑' : ' ↓') : ''}
                        </button>
                      </th>
                      <th>
                        <button type="button" className="bk-kw__sort" onClick={() => toggleSort('score')}>
                          Score{sortKey === 'score' ? (sortDir === 'asc' ? ' ↑' : ' ↓') : ''}
                        </button>
                      </th>
                      <th>Intent</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r) => (
                      <tr key={r.keyword}>
                        <td className="bk-kw__check">
                          <input
                            type="checkbox"
                            checked={selected.has(r.keyword)}
                            onChange={() => toggleSelect(r.keyword)}
                            aria-label={`Select ${r.keyword}`}
                          />
                        </td>
                        <td>
                          <button
                            type="button"
                            className="bk-kw__kw"
                            onClick={() => {
                              setQuery(r.keyword);
                              void runSearch(r.keyword);
                            }}
                          >
                            {r.keyword}
                          </button>
                        </td>
                        <td>{formatVol(r.volume)}</td>
                        <td>{formatCpc(r.cpc)}</td>
                        <td>{formatComp(r.competition)}</td>
                        <td>
                          <span className={`bk-kw__score-pill ${scoreClass(r.score)}`}>{r.score}</span>
                        </td>
                        <td>
                          <span className={`bk-kw__intent is-${r.intent}`}>{INTENT_LABEL[r.intent]}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="bk-kw__footnote">
                Ideas from Google Suggest · {countryLabel}
                {city ? ` · ${city}` : ''}. Volume / CPC / competition need a paid keyword dataset
                (not connected). Score & intent are first-party estimates.
              </p>
            </div>
          </div>

          <aside className="bk-kw__side">
            <div className="bk-kw__card">
              <h3 className="bk-kw__card-title">Search Trends</h3>
              <p className="bk-kw__card-sub">{result.trends.label}</p>
              <TrendChart values={result.trends.values} />
              <p className="bk-kw__footnote">Illustrative trend shape — not live search volume.</p>
            </div>

            <div className="bk-kw__card">
              <div className="bk-kw__card-head">
                <div>
                  <h3 className="bk-kw__card-title">SERP Analysis · {result.query}</h3>
                  <p className="bk-kw__card-sub">{result.serp.length} organic results</p>
                </div>
                <button type="button" className="button" onClick={onExportSerp} disabled={!result.serp.length}>
                  <DownloadSimple size={16} weight="regular" aria-hidden />
                  Export
                </button>
              </div>
              {result.serp.length === 0 ? (
                <p className="bk-kw__empty-inline">No SERP results returned for this query.</p>
              ) : (
                <ol className="bk-kw__serp">
                  {result.serp.map((r) => (
                    <li key={`${r.position}-${r.url}`}>
                      <span className="bk-kw__serp-pos">{r.position}</span>
                      <div className="bk-kw__serp-body">
                        <a href={safeHref(r.url)} target="_blank" rel="noreferrer">
                          {r.title}
                        </a>
                        <span>{r.domain}</span>
                      </div>
                    </li>
                  ))}
                </ol>
              )}
            </div>
          </aside>
        </div>
      ) : null}
    </div>
  );
}
