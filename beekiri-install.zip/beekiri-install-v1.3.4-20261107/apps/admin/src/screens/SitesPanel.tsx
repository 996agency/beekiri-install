import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { api, ApiError } from '../api/client';
import { confirmDialog } from '../components/ConfirmDialog';
import { useAuth } from '../auth/AuthContext';
import './sites-panel.css';

/** Settings → Sites (owner): the sites of this Beekiri network, each on its own sub-domain. */

type NetworkSite = {
  id: string;
  title: string;
  slug: string | null;
  domain: string | null;
  status: 'active' | 'archived' | string;
  isPrimary: boolean;
  url: string;
  adminUrl: string;
  theme: string;
  pages: number;
  people: number;
  /** Password protection: visitors must type the password to see the site. */
  protection: { enabled: boolean };
  createdAt: string;
};
type SitesResponse = { baseDomain: string; sites: NetworkSite[] };
type ThemesResponse = { themes: { slug: string; name: string; child?: { slug: string } }[]; active: string };
type Draft = { title: string; slug: string; domain: string };

const SLUG = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;

function slugify(title: string): string {
  return title
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 63);
}

function messageOf(error: unknown, fallback: string): string {
  return error instanceof ApiError || error instanceof Error ? error.message : fallback;
}

/** Opens another site's admin already signed in (one-time handoff link). */
export async function switchToSite(siteId: string, next?: string): Promise<void> {
  const { url } = await api<{ url: string }>('/api/network/handoff', { json: { siteId, ...(next ? { next } : {}) } });
  window.location.assign(url);
}

export function SitesPanel() {
  const auth = useAuth();
  const [data, setData] = useState<SitesResponse | null>(null);
  const [themes, setThemes] = useState<ThemesResponse['themes']>([]);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const [adding, setAdding] = useState(false);
  const [title, setTitle] = useState('');
  const [slug, setSlug] = useState('');
  const [slugTouched, setSlugTouched] = useState(false);
  const [theme, setTheme] = useState('');

  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft>({ title: '', slug: '', domain: '' });

  const [protecting, setProtecting] = useState<string | null>(null);
  const [password, setPassword] = useState('');

  const [domainDraft, setDomainDraft] = useState('');
  const [domainEditing, setDomainEditing] = useState(false);

  const load = useCallback(async () => {
    try {
      const [sites, themeList] = await Promise.all([
        api<SitesResponse>('/api/network/sites'),
        api<ThemesResponse>('/api/themes').catch(() => ({ themes: [], active: '' })),
      ]);
      setData(sites);
      setThemes(themeList.themes);
      setError(null);
    } catch (e) {
      setError(messageOf(e, 'Could not load the sites.'));
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const base = data?.baseDomain || window.location.hostname;
  const port = window.location.port ? `:${window.location.port}` : '';
  const slugOk = SLUG.test(slug);
  const preview = `${window.location.protocol}//${slug || 'your-site'}.${base}${port}`;

  const currentSiteId = auth.user?.siteId;
  const counts = useMemo(() => {
    const sites = data?.sites ?? [];
    return { all: sites.length, active: sites.filter((s) => s.status === 'active').length };
  }, [data]);

  const onTitle = (value: string) => {
    setTitle(value);
    if (!slugTouched) setSlug(slugify(value));
  };

  const resetAdd = () => {
    setAdding(false);
    setTitle('');
    setSlug('');
    setSlugTouched(false);
    setTheme('');
  };

  const create = async (event: FormEvent) => {
    event.preventDefault();
    if (!title.trim() || !slugOk) return;
    setBusy(true);
    setError(null);
    try {
      const { site } = await api<{ site: NetworkSite }>('/api/network/sites', {
        json: { title: title.trim(), slug, ...(theme ? { theme } : {}) },
      });
      setNotice(`${site.title} is ready at ${site.url}.`);
      resetAdd();
      await load();
    } catch (e) {
      setError(messageOf(e, 'Could not create the site.'));
    } finally {
      setBusy(false);
    }
  };

  const startEdit = (site: NetworkSite) => {
    setEditing(site.id);
    setDraft({ title: site.title, slug: site.slug ?? '', domain: site.domain ?? '' });
  };

  const saveEdit = async (site: NetworkSite) => {
    setBusy(true);
    setError(null);
    try {
      await api(`/api/network/sites/${site.id}`, {
        method: 'PATCH',
        json: {
          title: draft.title.trim(),
          ...(site.isPrimary ? {} : { slug: draft.slug.trim(), domain: draft.domain.trim() || null }),
        },
      });
      setEditing(null);
      setNotice('Site saved.');
      await load();
    } catch (e) {
      setError(messageOf(e, 'Could not save the site.'));
    } finally {
      setBusy(false);
    }
  };

  const setStatus = async (site: NetworkSite, status: 'active' | 'archived') => {
    if (status === 'archived') {
      const ok = await confirmDialog({
        title: `Archive ${site.title}?`,
        message: 'Visitors and editors can no longer open it. Nothing is deleted, and you can turn it back on at any time.',
        confirmLabel: 'Archive site',
      });
      if (!ok) return;
    }
    setBusy(true);
    try {
      await api(`/api/network/sites/${site.id}`, { method: 'PATCH', json: { status } });
      setNotice(status === 'archived' ? `${site.title} is archived.` : `${site.title} is live again.`);
      await load();
    } catch (e) {
      setError(messageOf(e, 'Could not change the site.'));
    } finally {
      setBusy(false);
    }
  };

  const openProtection = (site: NetworkSite) => {
    setEditing(null);
    setPassword('');
    setProtecting(protecting === site.id ? null : site.id);
  };

  const saveProtection = async (
    site: NetworkSite,
    change: { enabled: boolean; password?: string },
    done: string,
  ) => {
    setBusy(true);
    setError(null);
    try {
      await api(`/api/network/sites/${site.id}/access`, { method: 'PUT', json: change });
      setPassword('');
      setNotice(done);
      await load();
    } catch (e) {
      setError(messageOf(e, 'Could not change the password protection.'));
    } finally {
      setBusy(false);
    }
  };

  const turnOffProtection = async (site: NetworkSite) => {
    const ok = await confirmDialog({
      title: `Remove the password from ${site.title}?`,
      message: 'Everyone can visit the site again without a password.',
      confirmLabel: 'Remove password',
    });
    if (ok) await saveProtection(site, { enabled: false }, `${site.title} is open to everyone again.`);
  };

  const remove = async (site: NetworkSite) => {
    const typed = window.prompt(
      `Delete ${site.title} and everything in it (pages, media, forms, shop, analytics)? This cannot be undone.\n\nType “${site.slug}” to confirm:`,
    );
    if (typed === null) return;
    setBusy(true);
    setError(null);
    try {
      await api(`/api/network/sites/${site.id}`, { method: 'DELETE', json: { confirm: typed } });
      setNotice(`${site.title} was deleted.`);
      await load();
    } catch (e) {
      setError(messageOf(e, 'Could not delete the site.'));
    } finally {
      setBusy(false);
    }
  };

  const saveDomain = async () => {
    setBusy(true);
    setError(null);
    try {
      await api('/api/network/settings', { method: 'PUT', json: { baseDomain: domainDraft.trim() || null } });
      setDomainEditing(false);
      setNotice('Network domain saved.');
      await load();
    } catch (e) {
      setError(messageOf(e, 'Could not save the network domain.'));
    } finally {
      setBusy(false);
    }
  };

  const open = async (site: NetworkSite) => {
    if (site.id === currentSiteId) {
      window.location.assign(site.adminUrl);
      return;
    }
    try {
      await switchToSite(site.id);
    } catch (e) {
      setError(messageOf(e, 'Could not open that site.'));
    }
  };

  if (!data && !error) return <div className="bk-sites__loading" aria-busy="true" />;

  return (
    <div className="bk-stack bk-sites">
      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      {notice ? (
        <div className="beekiri-notice is-success" role="status">
          <p>{notice}</p>
        </div>
      ) : null}

      <div className="bk-panel">
        <div className="bk-panel__head bk-sites__head">
          <div>
            <h2 className="bk-panel__title">Sites</h2>
            <p className="bk-sites__hint">
              Each site has its own pages, menus, media, settings, forms and shop, and lives on its own sub-domain. People
              sign in once and switch between the sites they can use.
            </p>
          </div>
          {!adding ? (
            <button type="button" className="button button-primary" onClick={() => setAdding(true)}>
              Add site
            </button>
          ) : null}
        </div>

        {adding ? (
          <form className="bk-sites__add" onSubmit={(e) => void create(e)}>
            <div className="bk-sites__grid">
              <label className="bk-sites__field">
                <span>Site name</span>
                <input value={title} onChange={(e) => onTitle(e.target.value)} placeholder="Shop" autoFocus maxLength={200} />
              </label>
              <label className="bk-sites__field">
                <span>Sub-domain</span>
                <span className="bk-sites__slug">
                  <input
                    value={slug}
                    onChange={(e) => {
                      setSlugTouched(true);
                      setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''));
                    }}
                    placeholder="shop"
                    maxLength={63}
                    aria-invalid={slug !== '' && !slugOk}
                  />
                  <span className="bk-sites__suffix">.{base}</span>
                </span>
              </label>
              <label className="bk-sites__field">
                <span>Theme</span>
                <select value={theme} onChange={(e) => setTheme(e.target.value)}>
                  <option value="">Beekiri starter</option>
                  {themes
                    .filter((t) => t.slug !== 'beekiri' && t.slug !== 'beekiri-child')
                    .map((t) => (
                      <option key={t.slug} value={t.slug}>
                        {t.name}
                      </option>
                    ))}
                </select>
              </label>
            </div>
            <p className="bk-sites__hint">
              Address: <strong>{preview}</strong>
              {slug && !slugOk ? ' — use lower-case letters, numbers and dashes (not at the start or end).' : ''}
            </p>
            <div className="bk-sites__actions">
              <button type="submit" className="button button-primary" disabled={busy || !title.trim() || !slugOk}>
                {busy ? 'Creating…' : 'Create site'}
              </button>
              <button type="button" className="button" onClick={resetAdd} disabled={busy}>
                Cancel
              </button>
            </div>
          </form>
        ) : null}

        <div className="bk-sites__list" role="list">
          {(data?.sites ?? []).map((site) => {
            const isEditing = editing === site.id;
            const isProtecting = protecting === site.id && !isEditing;
            const archived = site.status === 'archived';
            const locked = site.protection?.enabled;
            const passwordOk = password.trim().length >= 4;
            return (
              <div key={site.id} role="listitem" className={`bk-sites__row${archived ? ' is-archived' : ''}`}>
                {isEditing ? (
                  <div className="bk-sites__edit">
                    <div className="bk-sites__grid">
                      <label className="bk-sites__field">
                        <span>Site name</span>
                        <input value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} maxLength={200} />
                      </label>
                      {!site.isPrimary ? (
                        <>
                          <label className="bk-sites__field">
                            <span>Sub-domain</span>
                            <span className="bk-sites__slug">
                              <input
                                value={draft.slug}
                                onChange={(e) => setDraft({ ...draft, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '') })}
                                maxLength={63}
                              />
                              <span className="bk-sites__suffix">.{base}</span>
                            </span>
                          </label>
                          <label className="bk-sites__field">
                            <span>Own domain (optional)</span>
                            <input
                              value={draft.domain}
                              onChange={(e) => setDraft({ ...draft, domain: e.target.value })}
                              placeholder="shop.example.com"
                              maxLength={253}
                            />
                          </label>
                        </>
                      ) : null}
                    </div>
                    {!site.isPrimary ? (
                      <p className="bk-sites__hint">
                        An own domain must point to this server (DNS) before you save it here; the sub-domain keeps working too.
                      </p>
                    ) : null}
                    <div className="bk-sites__actions">
                      <button type="button" className="button button-primary" disabled={busy || !draft.title.trim()} onClick={() => void saveEdit(site)}>
                        Save
                      </button>
                      <button type="button" className="button" onClick={() => setEditing(null)} disabled={busy}>
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="bk-sites__main">
                      <div className="bk-sites__name">
                        <strong>{site.title}</strong>
                        {site.isPrimary ? <span className="bk-sites__tag">Main site</span> : null}
                        {site.id === currentSiteId ? <span className="bk-sites__tag is-here">You are here</span> : null}
                        {archived ? <span className="bk-sites__tag is-off">Archived</span> : null}
                        {locked ? <span className="bk-sites__tag">Password protected</span> : null}
                      </div>
                      <a className="bk-sites__url" href={site.url} target="_blank" rel="noreferrer">
                        {site.url.replace(/^https?:\/\//, '')}
                      </a>
                      <div className="bk-sites__meta">
                        <span>Theme: {themes.find((t) => t.slug === site.theme || t.child?.slug === site.theme)?.name ?? site.theme}</span>
                        <span>
                          {site.pages} page{site.pages === 1 ? '' : 's'}
                        </span>
                        <span>
                          {site.people} {site.people === 1 ? 'person' : 'people'}
                        </span>
                      </div>
                    </div>
                    <div className="bk-sites__buttons">
                      {!archived ? (
                        <button type="button" className="button" onClick={() => void open(site)}>
                          Open admin
                        </button>
                      ) : null}
                      <button
                        type="button"
                        className="button"
                        onClick={() => openProtection(site)}
                        disabled={busy}
                        aria-expanded={isProtecting}
                      >
                        Password
                      </button>
                      <button
                        type="button"
                        className="button"
                        onClick={() => {
                          setProtecting(null);
                          startEdit(site);
                        }}
                        disabled={busy}
                      >
                        Edit
                      </button>
                      {!site.isPrimary ? (
                        <>
                          <button type="button" className="button" onClick={() => void setStatus(site, archived ? 'active' : 'archived')} disabled={busy}>
                            {archived ? 'Turn on' : 'Archive'}
                          </button>
                          {site.id !== currentSiteId ? (
                            <button type="button" className="button bk-sites__delete" onClick={() => void remove(site)} disabled={busy}>
                              Delete
                            </button>
                          ) : null}
                        </>
                      ) : null}
                    </div>
                    {isProtecting ? (
                      <div className="bk-sites__protect">
                        <p className="bk-sites__hint bk-sites__hint--top">
                          {locked
                            ? `Visitors must type the password to see ${site.url.replace(/^https?:\/\//, '')}; after that their browser remembers it for 30 days. Search engines stay out. You see the site as normal while you are signed in here.`
                            : 'Hide this site behind a password while you build it. Send your client the site address and the password; everyone else, search engines included, sees a password page.'}
                        </p>
                        <form
                          className="bk-sites__actions"
                          onSubmit={(e) => {
                            e.preventDefault();
                            if (!passwordOk) return;
                            void saveProtection(
                              site,
                              { enabled: true, password: password.trim() },
                              locked
                                ? 'Password changed. Visitors must type the new password.'
                                : `${site.title} is now password protected.`,
                            );
                          }}
                        >
                          <label className="bk-sites__field bk-sites__password">
                            <span>{locked ? 'New password' : 'Password'}</span>
                            <input
                              type="text"
                              value={password}
                              onChange={(e) => setPassword(e.target.value)}
                              placeholder="At least 4 characters"
                              autoComplete="off"
                              spellCheck={false}
                              maxLength={200}
                              autoFocus={!locked}
                            />
                          </label>
                          <button type="submit" className="button button-primary" disabled={busy || !passwordOk}>
                            {locked ? 'Change password' : 'Turn on password'}
                          </button>
                          {locked ? (
                            <button type="button" className="button" onClick={() => void turnOffProtection(site)} disabled={busy}>
                              Remove password
                            </button>
                          ) : null}
                          <button type="button" className="button" onClick={() => setProtecting(null)} disabled={busy}>
                            Close
                          </button>
                        </form>
                      </div>
                    ) : null}
                  </>
                )}
              </div>
            );
          })}
        </div>
        <p className="bk-sites__foot">
          {counts.all} site{counts.all === 1 ? '' : 's'} · {counts.active} live · Give people access to a site in Users → User Permissions.
        </p>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Network domain</h2>
        </div>
        <div className="bk-panel__body">
          <p className="bk-sites__hint bk-sites__hint--top">
            New sites get an address under this domain, for example <strong>shop.{base}</strong>. Point a wildcard DNS record
            (<code>*.{base}</code>) to this server so every new sub-domain works straight away. Locally, <code>*.localhost</code> works without any set-up.
          </p>
          {domainEditing ? (
            <div className="bk-sites__domain">
              <input value={domainDraft} onChange={(e) => setDomainDraft(e.target.value)} placeholder={base} maxLength={253} />
              <button type="button" className="button button-primary" disabled={busy} onClick={() => void saveDomain()}>
                Save
              </button>
              <button type="button" className="button" onClick={() => setDomainEditing(false)} disabled={busy}>
                Cancel
              </button>
            </div>
          ) : (
            <div className="bk-sites__domain">
              <code className="bk-sites__domain-value">{base}</code>
              <button
                type="button"
                className="button"
                onClick={() => {
                  setDomainDraft(data?.baseDomain ?? '');
                  setDomainEditing(true);
                }}
              >
                Change
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
