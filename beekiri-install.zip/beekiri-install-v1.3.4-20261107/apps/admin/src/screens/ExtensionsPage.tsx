import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Link, useSearchParams } from 'react-router-dom';
import { CheckCircle, MagnifyingGlass, Plus, ClipboardText, ShoppingCart, X, type Icon } from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { ErrorNotice } from '../components/ErrorNotice';
import { PageHeader } from '../components/PageHeader';
import { useCoreUpdate } from '../core/CoreUpdateContext';
import { useAdminHref } from '../lib/AdminEntryContext';
import { confirmDialog } from '../components/ConfirmDialog';
import { notifyExtensionsChanged } from '../lib/admin-events';
import './extensions.css';

type Extension = {
  slug: string;
  name: string;
  tagline: string;
  description: string[];
  features: string[];
  version: string;
  requires: string;
  author: string;
  category: string;
  icon: string;
  color: string;
  kind: 'built-in' | 'package';
  status: 'active' | 'inactive' | 'available' | 'coming-soon';
  settingsPath?: string;
  changelog: { version: string; notes: string[] }[];
};

const ICONS: Record<string, Icon> = {
  cart: ShoppingCart,
  form: ClipboardText,
};

/** What each extension keeps in the database (for the uninstall prompts). */
const DATA_WORDS: Record<string, string> = {
  shopping: 'every product, order, customer and coupon',
  'bee-forms': 'every form, entry and uploaded file',
};
const dataWords = (slug: string) => DATA_WORDS[slug] ?? 'all of its data';
const HIDE_WORDS: Record<string, string> = {
  shopping: 'The shop pages and the Shop menu are hidden',
  'bee-forms': 'Forms stop showing on the website and the Forms menu is hidden',
};
const hideWords = (slug: string) => HIDE_WORDS[slug] ?? 'Its screens are hidden';

const isInstalled = (e: Extension) => e.status === 'active' || e.status === 'inactive';

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

/** -1, 0 or 1 for dotted version strings (1.10.0 > 1.9.2). */
function compareVersions(a: string, b: string) {
  const pa = a.split('.').map((n) => parseInt(n, 10) || 0);
  const pb = b.split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

export function ExtensionIcon({ ext, size = 'md' }: { ext: Extension; size?: 'sm' | 'md' | 'lg' }) {
  const IconCmp = ICONS[ext.icon] ?? null;
  return (
    <span className={`bk-ext-icon is-${size}`} style={{ ['--ext-color' as string]: ext.color }} aria-hidden>
      {IconCmp ? <IconCmp weight="duotone" /> : <img src="/admin/icon-192.png" alt="" draggable={false} />}
    </span>
  );
}

function useExtensions() {
  const [list, setList] = useState<Extension[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    api<{ extensions: Extension[] }>('/api/extensions')
      .then((res) => setList(res.extensions))
      .catch((e) => setError(formatError(e)));
  }, []);
  return { list, error, setError, setList };
}

/** `?details=slug` opens the details window on either screen. */
function useDetails() {
  const [params, setParams] = useSearchParams();
  const slug = params.get('details');
  const open = useCallback(
    (s: string) => {
      const next = new URLSearchParams(params);
      next.set('details', s);
      setParams(next);
    },
    [params, setParams],
  );
  const close = useCallback(() => {
    const next = new URLSearchParams(params);
    next.delete('details');
    setParams(next);
  }, [params, setParams]);
  return { slug, open, close };
}

type ExtensionAction = 'install' | 'activate' | 'deactivate' | 'uninstall';

/** Runs one extension action against the API and hands the fresh list back. */
async function runExtensionAction(ext: Extension, action: ExtensionAction, deleteData = false) {
  const res = await api<{ extensions: Extension[] }>(`/api/extensions/${ext.slug}/${action}`, {
    method: 'POST',
    json: action === 'uninstall' ? { deleteData } : {},
  });
  notifyExtensionsChanged();
  return res.extensions;
}

function StatusAction({
  ext,
  onNavigate,
  onChange,
  onError,
}: {
  ext: Extension;
  onNavigate?: () => void;
  onChange?: (list: Extension[]) => void;
  onError?: (message: string) => void;
}) {
  const href = useAdminHref();
  const [busy, setBusy] = useState<ExtensionAction | null>(null);
  const run = async (action: ExtensionAction) => {
    let deleteData = false;
    if (action === 'uninstall') {
      const ok = await confirmDialog({
        title: `Uninstall ${ext.name}?`,
        message: `${ext.name} will be removed from the Extensions list. Its data stays in the database unless you choose to delete it in the next step.`,
        confirmLabel: 'Uninstall',
        danger: true,
      });
      if (!ok) return;
      deleteData = await confirmDialog({
        title: 'Delete all data too?',
        message: `Choose “Delete data” to permanently remove ${dataWords(ext.slug)} created by ${ext.name}. Choose “Keep data” to keep them for a later reinstall.`,
        confirmLabel: 'Delete data',
        cancelLabel: 'Keep data',
        danger: true,
      });
    }
    if (action === 'deactivate') {
      const ok = await confirmDialog({
        title: `Deactivate ${ext.name}?`,
        message: `${hideWords(ext.slug)} until you activate it again. Nothing is deleted.`,
        confirmLabel: 'Deactivate',
      });
      if (!ok) return;
    }
    setBusy(action);
    try {
      onChange?.(await runExtensionAction(ext, action, deleteData));
    } catch (e) {
      onError?.(formatError(e));
    } finally {
      setBusy(null);
    }
  };
  if (ext.status === 'coming-soon') {
    return (
      <button type="button" className="button" disabled>
        Coming soon
      </button>
    );
  }
  if (ext.status === 'active') {
    return (
      <span className="bk-ext__action-row">
        {ext.settingsPath ? (
          <Link className="button button-primary" to={href(ext.settingsPath)} onClick={onNavigate}>
            Open {ext.name}
          </Link>
        ) : (
          <span className="bk-ext-active">
            <CheckCircle size={16} weight="fill" aria-hidden /> Active
          </span>
        )}
        {ext.kind === 'package' ? (
          <button type="button" className="button" disabled={busy !== null} onClick={() => void run('deactivate')}>
            {busy === 'deactivate' ? 'Deactivating…' : 'Deactivate'}
          </button>
        ) : null}
      </span>
    );
  }
  if (ext.status === 'inactive') {
    return (
      <span className="bk-ext__action-row">
        <button type="button" className="button button-primary" disabled={busy !== null} onClick={() => void run('activate')}>
          {busy === 'activate' ? 'Activating…' : 'Activate'}
        </button>
        <button type="button" className="button" disabled={busy !== null} onClick={() => void run('uninstall')}>
          {busy === 'uninstall' ? 'Uninstalling…' : 'Uninstall'}
        </button>
      </span>
    );
  }
  return (
    <button type="button" className="button button-primary" disabled={busy !== null} onClick={() => void run('install')}>
      {busy === 'install' ? 'Installing…' : 'Install now'}
    </button>
  );
}

function Badge({ ext }: { ext: Extension }) {
  if (ext.status === 'coming-soon') return <span className="bk-ext-badge is-soon">Coming soon</span>;
  if (ext.kind === 'built-in') return <span className="bk-ext-badge is-builtin">Built-in</span>;
  if (ext.status === 'active') return <span className="bk-ext-badge is-active">Active</span>;
  return null;
}

function Compatibility({ ext }: { ext: Extension }) {
  const { updates } = useCoreUpdate();
  const current = updates?.currentVersion ?? '1.0.0';
  const ok = compareVersions(current, ext.requires) >= 0;
  return ok ? (
    <span className="bk-ext-compat is-ok">
      <CheckCircle size={14} weight="fill" aria-hidden /> Compatible with your version of Beekiri
    </span>
  ) : (
    <span className="bk-ext-compat is-bad">Needs Beekiri {ext.requires} or newer (you have {current})</span>
  );
}

/** WordPress-style "View details": banner, tabs, and a facts sidebar. */
function DetailsModal({
  ext,
  onClose,
  onChange,
  onError,
}: {
  ext: Extension;
  onClose: () => void;
  onChange?: (list: Extension[]) => void;
  onError?: (message: string) => void;
}) {
  const [tab, setTab] = useState<'description' | 'changelog'>('description');
  const { updates } = useCoreUpdate();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  return createPortal(
    <div
      className="bk-ext-modal"
      role="dialog"
      aria-modal="true"
      aria-label={`${ext.name} details`}
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="bk-ext-modal__panel">
        <button type="button" className="bk-ext-modal__close" aria-label="Close" onClick={onClose}>
          <X size={18} aria-hidden />
        </button>
        <div className="bk-ext-modal__banner" style={{ ['--ext-color' as string]: ext.color }}>
          <ExtensionIcon ext={ext} size="lg" />
          <div>
            <h2>{ext.name}</h2>
            <p>By {ext.author}</p>
          </div>
        </div>
        <div className="bk-tabs is-flush" role="tablist" aria-label="Extension details">
          {(['description', 'changelog'] as const).map((t) => (
            <button
              key={t}
              type="button"
              role="tab"
              aria-selected={tab === t}
              className={`bk-tabs__item${tab === t ? ' is-active' : ''}`}
              onClick={() => setTab(t)}
            >
              {t === 'description' ? 'Description' : 'Changelog'}
            </button>
          ))}
        </div>
        <div className="bk-ext-modal__body">
          <div className="bk-ext-modal__main">
            {tab === 'description' ? (
              <>
                <p className="bk-ext-modal__lead">{ext.tagline}</p>
                {ext.description.map((p) => (
                  <p key={p}>{p}</p>
                ))}
                <h3>What it adds</h3>
                <ul className="bk-ext-features">
                  {ext.features.map((f) => (
                    <li key={f}>
                      <CheckCircle size={15} weight="fill" aria-hidden /> {f}
                    </li>
                  ))}
                </ul>
              </>
            ) : (
              ext.changelog.map((c) => (
                <section key={c.version} className="bk-ext-changelog">
                  <h3>{c.version}</h3>
                  <ul>
                    {c.notes.map((n) => (
                      <li key={n}>{n}</li>
                    ))}
                  </ul>
                </section>
              ))
            )}
          </div>
          <aside className="bk-ext-modal__facts">
            <dl>
              <dt>Version</dt>
              <dd>{ext.version}</dd>
              <dt>Requires Beekiri</dt>
              <dd>{ext.requires} or newer</dd>
              <dt>Your Beekiri</dt>
              <dd>{updates?.currentVersion ?? '1.0.0'}</dd>
              <dt>Category</dt>
              <dd>{ext.category}</dd>
              <dt>Type</dt>
              <dd>{ext.kind === 'built-in' ? 'Built into Beekiri' : 'Beekiri extension'}</dd>
            </dl>
            <Compatibility ext={ext} />
            <div className="bk-ext-modal__action">
              <StatusAction ext={ext} onNavigate={onClose} onChange={onChange} onError={onError} />
            </div>
          </aside>
        </div>
      </div>
    </div>,
    document.body,
  );
}

function Shell({
  title,
  action,
  intro,
  children,
}: {
  title: string;
  action?: ReactNode;
  intro: string;
  children: ReactNode;
}) {
  return (
    <div className="wrap wrap--wide bk-ext">
      <PageHeader title={title} actions={action} />
      <p className="bk-muted bk-ext__intro">{intro}</p>
      {children}
    </div>
  );
}

/** Installed extensions — a WordPress Plugins-style table. */
export function ExtensionsPage() {
  const href = useAdminHref();
  const { list, error, setError, setList } = useExtensions();
  const details = useDetails();
  const [filter, setFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [query, setQuery] = useState('');

  const installed = useMemo(() => (list ?? []).filter(isInstalled), [list]);
  const counts = {
    all: installed.length,
    active: installed.filter((e) => e.status === 'active').length,
    inactive: installed.filter((e) => e.status === 'inactive').length,
  };
  const rows = installed
    .filter((e) => filter === 'all' || e.status === filter)
    .filter((e) => {
      const q = query.trim().toLowerCase();
      return !q || `${e.name} ${e.tagline} ${e.category}`.toLowerCase().includes(q);
    });
  const open = list?.find((e) => e.slug === details.slug);

  return (
    <Shell
      title="Extensions"
      intro="Extensions add bigger features to Beekiri, like Shopping. Every extension is made and published by Beekiri."
      action={
        <Link className="button button-primary bk-ext__add" to={href('extensions/new')}>
          <Plus size={14} weight="bold" aria-hidden /> Add New Extension
        </Link>
      }
    >
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      <div className="bk-ext__bar">
        <ul className="bk-ext__filters">
          {(['all', 'active', 'inactive'] as const).map((f, i) => (
            <li key={f}>
              {i ? <span aria-hidden>|</span> : null}
              <button type="button" className={filter === f ? 'is-current' : ''} onClick={() => setFilter(f)}>
                {f === 'all' ? 'All' : f === 'active' ? 'Active' : 'Inactive'} <span>({counts[f]})</span>
              </button>
            </li>
          ))}
        </ul>
        <label className="bk-ext__search">
          <span className="screen-reader-text">Search installed extensions</span>
          <MagnifyingGlass size={15} aria-hidden />
          <input type="search" placeholder="Search installed extensions…" value={query} onChange={(e) => setQuery(e.target.value)} />
        </label>
      </div>

      {!list ? (
        <p className="bk-muted">Loading…</p>
      ) : (
        <div className="bk-ext__table-wrap">
          <table className="bk-ext__table">
            <thead>
              <tr>
                <th scope="col">Extension</th>
                <th scope="col">Description</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={2} className="bk-ext__empty">
                    {installed.length === 0 ? (
                      <>
                        <strong>No extensions installed yet.</strong>
                        <br />
                        <Link to={href('extensions/new')}>Browse Beekiri extensions</Link> — Shopping is on its way.
                      </>
                    ) : (
                      <>
                        No extensions match. <Link to={href('extensions/new')}>Browse Beekiri extensions</Link>
                      </>
                    )}
                  </td>
                </tr>
              ) : (
                rows.map((e) => (
                  <tr key={e.slug} className={e.status === 'active' ? 'is-active' : ''}>
                    <td className="bk-ext__name">
                      <div className="bk-ext__name-row">
                        <ExtensionIcon ext={e} size="sm" />
                        <strong>{e.name}</strong>
                      </div>
                      <div className="bk-ext__actions">
                        {e.status === 'active' && e.settingsPath ? <Link to={href(e.settingsPath)}>Settings</Link> : null}
                        {e.status === 'active' && e.settingsPath ? <span aria-hidden>|</span> : null}
                        <button type="button" onClick={() => details.open(e.slug)}>
                          View details
                        </button>
                        {e.kind === 'package' ? (
                          <>
                            <span aria-hidden>|</span>
                            <InlineExtensionAction ext={e} onChange={setList} onError={setError} />
                          </>
                        ) : null}
                        {e.kind === 'built-in' ? (
                          <>
                            <span aria-hidden>|</span>
                            <span className="bk-ext__locked" title="Built-in extensions come with Beekiri core and stay on">
                              Always on
                            </span>
                          </>
                        ) : null}
                      </div>
                    </td>
                    <td className="bk-ext__desc">
                      <p>{e.tagline}</p>
                      <p className="bk-ext__meta">
                        <Badge ext={e} />
                        Version {e.version} <span aria-hidden>|</span> By {e.author} <span aria-hidden>|</span>{' '}
                        <button type="button" onClick={() => details.open(e.slug)}>
                          View details
                        </button>
                      </p>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
      {open ? <DetailsModal ext={open} onClose={details.close} onChange={setList} onError={setError} /> : null}
    </Shell>
  );
}

/** Text links in the installed table: Deactivate / Activate | Uninstall. */
function InlineExtensionAction({
  ext,
  onChange,
  onError,
}: {
  ext: Extension;
  onChange: (list: Extension[]) => void;
  onError: (message: string) => void;
}) {
  const [busy, setBusy] = useState(false);
  const run = async (action: ExtensionAction) => {
    let deleteData = false;
    if (action === 'deactivate') {
      const ok = await confirmDialog({ title: `Deactivate ${ext.name}?`, message: `${hideWords(ext.slug)} until you activate it again. Nothing is deleted.`, confirmLabel: 'Deactivate' });
      if (!ok) return;
    }
    if (action === 'uninstall') {
      const ok = await confirmDialog({ title: `Uninstall ${ext.name}?`, message: `${ext.name} will be removed from the Extensions list.`, confirmLabel: 'Uninstall', danger: true });
      if (!ok) return;
      deleteData = await confirmDialog({ title: 'Delete all data too?', message: `Choose “Delete data” to permanently remove ${dataWords(ext.slug)} created by ${ext.name}. Choose “Keep data” to keep them for a later reinstall.`, confirmLabel: 'Delete data', cancelLabel: 'Keep data', danger: true });
    }
    setBusy(true);
    try {
      onChange(await runExtensionAction(ext, action, deleteData));
    } catch (e) {
      onError(formatError(e));
    } finally {
      setBusy(false);
    }
  };
  if (ext.status === 'active') {
    return (
      <button type="button" disabled={busy} onClick={() => void run('deactivate')}>
        Deactivate
      </button>
    );
  }
  return (
    <>
      <button type="button" disabled={busy} onClick={() => void run('activate')}>
        Activate
      </button>
      <span aria-hidden>|</span>
      <button type="button" className="is-danger" disabled={busy} onClick={() => void run('uninstall')}>
        Uninstall
      </button>
    </>
  );
}

/** Add New — the Beekiri extension directory as a card grid. */
export function ExtensionsDirectoryPage() {
  const href = useAdminHref();
  const { list, error, setError, setList } = useExtensions();
  const details = useDetails();
  const [tab, setTab] = useState<'all' | 'coming-soon'>('all');
  const [category, setCategory] = useState('all');
  const [query, setQuery] = useState('');

  const categories = useMemo(() => [...new Set((list ?? []).map((e) => e.category))].sort(), [list]);
  const cards = (list ?? [])
    .filter((e) => tab === 'all' || e.status === 'coming-soon')
    .filter((e) => category === 'all' || e.category === category)
    .filter((e) => {
      const q = query.trim().toLowerCase();
      return !q || `${e.name} ${e.tagline} ${e.category} ${e.features.join(' ')}`.toLowerCase().includes(q);
    });
  const open = list?.find((e) => e.slug === details.slug);

  return (
    <Shell
      title="Add Extensions"
      intro="Extensions from Beekiri. New ones are published here as they are released."
      action={
        <Link className="button bk-ext__add" to={href('extensions')}>
          Installed extensions
        </Link>
      }
    >
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      <div className="bk-tabs" role="tablist" aria-label="Extensions">
        {(['all', 'coming-soon'] as const).map((t) => (
          <button key={t} type="button" role="tab" aria-selected={tab === t} className={`bk-tabs__item${tab === t ? ' is-active' : ''}`} onClick={() => setTab(t)}>
            {t === 'all' ? 'All' : 'Coming soon'}
          </button>
        ))}
      </div>
      <div className="bk-ext__bar">
        <div className="bk-ext__tools">
          <select value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Category">
            <option value="all">All categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <label className="bk-ext__search">
            <span className="screen-reader-text">Search extensions</span>
            <MagnifyingGlass size={15} aria-hidden />
            <input type="search" placeholder="Search extensions…" value={query} onChange={(e) => setQuery(e.target.value)} />
          </label>
        </div>
      </div>

      {!list ? (
        <p className="bk-muted">Loading…</p>
      ) : cards.length === 0 ? (
        <p className="bk-muted">No extensions match your search.</p>
      ) : (
        <div className="bk-ext__grid">
          {cards.map((e) => (
            <article key={e.slug} className="bk-ext-card">
              <div className="bk-ext-card__top">
                <button type="button" className="bk-ext-card__icon-btn" onClick={() => details.open(e.slug)} aria-label={`${e.name} details`}>
                  <ExtensionIcon ext={e} />
                </button>
                <div className="bk-ext-card__head">
                  <h3>
                    <button type="button" onClick={() => details.open(e.slug)}>
                      {e.name}
                    </button>
                  </h3>
                  <p className="bk-ext-card__tagline">{e.tagline}</p>
                  <p className="bk-ext-card__by">
                    By <strong>{e.author}</strong>
                  </p>
                </div>
                <div className="bk-ext-card__cta">
                  <StatusAction ext={e} onChange={setList} onError={setError} />
                  <button type="button" className="bk-ext-card__more" onClick={() => details.open(e.slug)}>
                    More details
                  </button>
                </div>
              </div>
              <div className="bk-ext-card__foot">
                <span>
                  <Badge ext={e} /> {e.category} · Version {e.version}
                </span>
                <Compatibility ext={e} />
              </div>
            </article>
          ))}
        </div>
      )}
      {open ? <DetailsModal ext={open} onClose={details.close} onChange={setList} onError={setError} /> : null}
    </Shell>
  );
}
