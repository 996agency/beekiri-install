import { FormEvent, useState } from 'react';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { ApiError } from '../api/client';
import { useAdminEntry } from '../lib/AdminEntryContext';
import { LoginWelcome } from '../components/LoginWelcome';
import { clearIdleSignOut, wasIdleSignOut } from '../lib/idle-session';
import { AuthShell } from './AuthShell';
import { ResetPasswordScreen } from './ResetPasswordScreen';
import { LostPasswordScreen } from './LostPasswordScreen';

/** `redirect_to` must stay on this site: a single-slash path, never `//host` or a scheme. */
function localPath(raw: string | null, fallback: string): string {
  const v = (raw || '').trim();
  if (!/^\/(?![\/\\])/.test(v)) return fallback;
  try {
    return new URL(v, window.location.origin).origin === window.location.origin ? v : fallback;
  } catch {
    return fallback;
  }
}

export function LoginScreen() {
  const auth = useAuth();
  const entry = useAdminEntry();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const action = params.get('action');
  const [idleFlag] = useState(wasIdleSignOut);
  const idleSignedOut = params.get('reason') === 'idle' || idleFlag;
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [welcome, setWelcome] = useState(false);
  const [pendingRedirect, setPendingRedirect] = useState(entry.basePath);

  if (action === 'lostpassword') return <LostPasswordScreen />;
  if (action === 'rp' || action === 'reset') return <ResetPasswordScreen />;

  if (welcome) {
    return (
      <LoginWelcome
        onDone={() => {
          navigate(pendingRedirect, { replace: true });
        }}
      />
    );
  }

  if (auth.authenticated) {
    return <Navigate to={localPath(params.get('redirect_to'), entry.basePath)} replace />;
  }

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await auth.login(login, password, remember);
      clearIdleSignOut();
      setPendingRedirect(localPath(params.get('redirect_to'), entry.basePath));
      setWelcome(true);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Invalid username or password.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell
      title="Welcome back to Beekiri"
      subtitle="Please enter your details to sign in to your account."
      brandTo={entry.path}
      documentTitle="Sign in — Beekiri CMS"
    >
      {idleSignedOut ? (
        <div className="bk-auth__ok" role="status">
          For your security, you were signed out after 20 minutes without activity. Sign in again to continue
          where you left off.
        </div>
      ) : null}
      {error ? (
        <div className="bk-auth__alert" role="alert">
          {error}
        </div>
      ) : null}

      <form onSubmit={onSubmit}>
        <div className="bk-install__field">
          <label htmlFor="user_login">Email or username</label>
          <input
            className="regular-text"
            type="text"
            id="user_login"
            autoComplete="username"
            required
            placeholder="you@example.com"
            value={login}
            onChange={(e) => setLogin(e.target.value)}
          />
        </div>
        <div className="bk-install__field">
          <label htmlFor="user_pass">Password</label>
          <div className="bk-auth__pw">
            <input
              className="regular-text"
              type={showPw ? 'text' : 'password'}
              id="user_pass"
              autoComplete="current-password"
              required
              placeholder="Your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              type="button"
              className="bk-auth__pw-toggle"
              onClick={() => setShowPw((v) => !v)}
            >
              {showPw ? 'Hide' : 'Show'}
            </button>
          </div>
        </div>
        <label className="bk-install__check">
          <input
            type="checkbox"
            checked={remember}
            onChange={(e) => setRemember(e.target.checked)}
          />
          <span>Keep me signed in</span>
        </label>

        <div className="bk-auth__actions">
          <button
            type="submit"
            className="bk-install__btn bk-install__btn--primary"
            disabled={busy}
          >
            {busy ? 'Signing in…' : 'Sign in'}
          </button>
          <Link to={`${entry.basePath}/lost-password`} className="bk-auth__link">
            Forgot password?
          </Link>
        </div>
      </form>
    </AuthShell>
  );
}
