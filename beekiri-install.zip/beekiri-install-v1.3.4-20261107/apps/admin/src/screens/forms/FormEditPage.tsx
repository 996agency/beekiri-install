import { useEffect, useMemo, useRef, useState, type DragEvent, type ReactNode } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowDown, ArrowUp, ArrowsOutCardinal, Copy, Trash } from '@phosphor-icons/react';
import { api } from '../../api/client';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { useAuth } from '../../auth/AuthContext';
import { useAdminHref } from '../../lib/AdminEntryContext';
import { invalidateFormsList } from '../../editor/beekiricode/inspector/AcfFieldInputs';
import {
  CHOICE_TYPES,
  FIELD_GROUPS,
  FIELD_TYPES,
  MERGE_TAGS,
  NO_VALUE_TYPES,
  fieldMeta,
  formsError,
  nameFromLabel,
  newField,
  uniqueName,
  type ConditionOp,
  type ConditionRule,
  type FieldCondition,
  type FileAcceptKind,
  type FormDetail,
  type FormField,
  type FormFieldType,
  type FormSettings,
} from './api';
import { FormIntegrationsTab } from './FormIntegrationsTab';
import './forms.css';

type Tab = 'fields' | 'settings' | 'notifications' | 'integrations';
type Draft = { title: string; status: 'active' | 'inactive'; fields: FormField[]; settings: FormSettings };

const OPS: { value: ConditionOp; label: string; needsValue: boolean }[] = [
  { value: 'is', label: 'is', needsValue: true },
  { value: 'is_not', label: 'is not', needsValue: true },
  { value: 'contains', label: 'contains', needsValue: true },
  { value: 'not_contains', label: 'does not contain', needsValue: true },
  { value: 'empty', label: 'is empty', needsValue: false },
  { value: 'not_empty', label: 'is filled in', needsValue: false },
  { value: 'gt', label: 'is greater than', needsValue: true },
  { value: 'lt', label: 'is less than', needsValue: true },
];

const ACCEPT_KINDS: { id: FileAcceptKind; label: string }[] = [
  { id: 'image', label: 'Images' },
  { id: 'pdf', label: 'PDF' },
  { id: 'document', label: 'Documents' },
  { id: 'spreadsheet', label: 'Spreadsheets' },
  { id: 'archive', label: 'ZIP' },
];

const DRAG_MIME = 'application/x-beekiri-form-field';

function Switch({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <label className={`bk-fm-switch${disabled ? ' is-disabled' : ''}`}>
      <input type="checkbox" role="switch" checked={checked} disabled={disabled} aria-label={label} onChange={(e) => onChange(e.target.checked)} />
      <span className="bk-fm-switch__track" aria-hidden>
        <span className="bk-fm-switch__knob" />
      </span>
    </label>
  );
}

function Row({ label, hint, children, inline }: { label: string; hint?: string; children: ReactNode; inline?: boolean }) {
  return (
    <div className={`bk-fm-row${inline ? ' is-inline' : ''}`}>
      <div className="bk-fm-row__text">
        <span className="bk-fm-row__label">{label}</span>
        {hint ? <span className="bk-fm-row__hint">{hint}</span> : null}
      </div>
      <div className="bk-fm-row__control">{children}</div>
    </div>
  );
}

function Seg<T extends string>({ value, options, onChange }: { value: T; options: { value: T; label: string }[]; onChange: (v: T) => void }) {
  return (
    <div className="bk-fm-seg" role="group">
      {options.map((o) => (
        <button key={o.value} type="button" className={o.value === value ? 'is-active' : ''} aria-pressed={o.value === value} onClick={() => onChange(o.value)}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

/** Same rules as the server: a form without page breaks is one step. */
function previewCols(fields: FormField[]): FormField[][] {
  const pages: FormField[][] = [[]];
  for (const f of fields) {
    if (f.type === 'page') pages.push([]);
    else pages[pages.length - 1].push(f);
  }
  return pages;
}

export function FormEditPage() {
  const { id } = useParams<{ id: string }>();
  const isNew = !id;
  const href = useAdminHref();
  const navigate = useNavigate();
  const auth = useAuth();
  const canEntries = auth.user?.capabilities.includes('view_form_entries') ?? false;

  const [saved, setSaved] = useState<Draft | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [formId, setFormId] = useState<string | null>(id ?? null);
  const [summary, setSummary] = useState<{ entryCount: number; unreadCount: number }>({ entryCount: 0, unreadCount: 0 });
  const [tab, setTab] = useState<Tab>('fields');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  /** Insert position while dragging (index in draft.fields), and the field being moved. */
  const [dropAt, setDropAt] = useState<number | null>(null);
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const dragPayload = useRef<string | null>(null);
  const canvasRef = useRef<HTMLElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const titleRef = useRef<HTMLInputElement>(null);

  const apply = (d: FormDetail) => {
    const next: Draft = { title: d.title, status: d.status, fields: d.fields, settings: d.settings };
    setSaved(next);
    setDraft(next);
    setFormId(d.id);
    setSummary({ entryCount: d.entryCount, unreadCount: d.unreadCount });
  };

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        // New forms start from the server's starter contact form, so the builder is never empty.
        const d = isNew ? await api<FormDetail>('/api/forms', { method: 'POST', json: { title: 'Untitled form' } }) : await api<FormDetail>(`/api/forms/${id}`);
        if (cancelled) return;
        apply(d);
        if (isNew) {
          invalidateFormsList();
          navigate(href(`forms/${d.id}`), { replace: true });
          window.setTimeout(() => titleRef.current?.select(), 50);
        }
      } catch (e) {
        if (!cancelled) setError(formsError(e));
      }
    };
    void load();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- load once per id
  }, [id]);

  const dirty = useMemo(() => Boolean(draft && saved && JSON.stringify(draft) !== JSON.stringify(saved)), [draft, saved]);

  useEffect(() => {
    if (!dirty) return;
    const warn = (e: BeforeUnloadEvent) => {
      e.preventDefault();
    };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [dirty]);

  const update = (patch: Partial<Draft>) => setDraft((d) => (d ? { ...d, ...patch } : d));
  const updateSettings = (patch: Partial<FormSettings>) => setDraft((d) => (d ? { ...d, settings: { ...d.settings, ...patch } } : d));
  const updateField = (fid: string, patch: Partial<FormField>) =>
    setDraft((d) => (d ? { ...d, fields: d.fields.map((f) => (f.id === fid ? { ...f, ...patch } : f)) } : d));

  const selected = draft?.fields.find((f) => f.id === selectedId) ?? null;

  const addField = (type: FormFieldType, at?: number) => {
    if (!draft) return;
    const f = newField(type, draft.fields);
    const fields = [...draft.fields];
    const index = at ?? (selectedId ? fields.findIndex((x) => x.id === selectedId) + 1 : fields.length);
    fields.splice(index < 0 ? fields.length : index, 0, f);
    update({ fields });
    setSelectedId(f.id);
  };

  const moveField = (fid: string, to: number) => {
    if (!draft) return;
    const from = draft.fields.findIndex((f) => f.id === fid);
    if (from < 0) return;
    const target = to > from ? to - 1 : to;
    if (target === from) return;
    const fields = [...draft.fields];
    const [item] = fields.splice(from, 1);
    fields.splice(target, 0, item);
    update({ fields });
  };

  const nudgeField = (fid: string, dir: -1 | 1) => {
    if (!draft) return;
    const from = draft.fields.findIndex((f) => f.id === fid);
    const to = from + dir;
    if (from < 0 || to < 0 || to >= draft.fields.length) return;
    const fields = [...draft.fields];
    [fields[from], fields[to]] = [fields[to], fields[from]];
    update({ fields });
  };

  const duplicateField = (fid: string) => {
    if (!draft) return;
    const src = draft.fields.find((f) => f.id === fid);
    if (!src) return;
    const copy: FormField = { ...src, id: Math.random().toString(36).slice(2, 10), label: `${src.label} (copy)` };
    copy.name = uniqueName(nameFromLabel(copy.label), draft.fields, copy.id);
    delete copy.conditional;
    const fields = [...draft.fields];
    fields.splice(fields.findIndex((f) => f.id === fid) + 1, 0, copy);
    update({ fields });
    setSelectedId(copy.id);
  };

  const removeField = (fid: string) => {
    if (!draft) return;
    const fields = draft.fields
      .filter((f) => f.id !== fid)
      .map((f) => (f.conditional ? { ...f, conditional: pruneCondition(f.conditional, fid) } : f));
    update({ fields });
    if (selectedId === fid) setSelectedId(null);
  };

  const save = async () => {
    if (!draft || !formId) return;
    if (!draft.title.trim()) {
      setError('Give the form a title.');
      titleRef.current?.focus();
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const d = await api<FormDetail>(`/api/forms/${formId}`, { method: 'PATCH', json: draft });
      apply(d);
      invalidateFormsList();
      setNotice('Form saved.');
    } catch (e) {
      setError(formsError(e));
    } finally {
      setBusy(false);
    }
  };

  const discard = () => saved && setDraft(saved);

  /* ── Drag and drop ──────────────────────────────────────────────────── */

  // One dragover handler on the whole canvas: the insert position comes from the nearest field
  // and which half of it the pointer is over, so there are no thin targets to aim for and the
  // layout never shifts under the pointer.
  const onDragStart = (e: DragEvent, payload: string) => {
    e.dataTransfer.setData(DRAG_MIME, payload);
    e.dataTransfer.effectAllowed = payload.startsWith('new:') ? 'copy' : 'move';
    dragPayload.current = payload;
    if (payload.startsWith('move:')) {
      const id = payload.slice(5);
      // Let the browser take its drag image before the card fades.
      window.requestAnimationFrame(() => setDraggingId(id));
    }
  };
  const endDrag = () => {
    dragPayload.current = null;
    setDropAt(null);
    setDraggingId(null);
  };
  useEffect(() => {
    window.addEventListener('dragend', endDrag);
    window.addEventListener('drop', endDrag);
    return () => {
      window.removeEventListener('dragend', endDrag);
      window.removeEventListener('drop', endDrag);
    };
  }, []);

  const dropIndexAt = (x: number, y: number): number => {
    const els = canvasRef.current ? [...canvasRef.current.querySelectorAll<HTMLElement>('[data-drop-index]')] : [];
    let best: { el: HTMLElement; d: number } | null = null;
    for (const el of els) {
      const r = el.getBoundingClientRect();
      const dx = Math.max(r.left - x, 0, x - r.right);
      const dy = Math.max(r.top - y, 0, y - r.bottom);
      const d = dy * 1000 + dx; // same row first, then closest column
      if (!best || d < best.d) best = { el, d };
    }
    if (!best) return 0;
    const r = best.el.getBoundingClientRect();
    const index = Number(best.el.dataset.dropIndex);
    const before = best.el.dataset.dropAxis === 'x' ? x < r.left + r.width / 2 : y < r.top + r.height / 2;
    return before ? index : index + 1;
  };
  const onCanvasDragOver = (e: DragEvent) => {
    if (!dragPayload.current) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = dragPayload.current.startsWith('new:') ? 'copy' : 'move';
    const index = dropIndexAt(e.clientX, e.clientY);
    if (index !== dropAt) setDropAt(index);
  };
  const onCanvasDragLeave = (e: DragEvent) => {
    const next = e.relatedTarget as Node | null;
    if (!next || !canvasRef.current?.contains(next)) setDropAt(null);
  };
  const onCanvasDrop = (e: DragEvent) => {
    e.preventDefault();
    const payload = dragPayload.current ?? e.dataTransfer.getData(DRAG_MIME);
    const index = dropAt ?? dropIndexAt(e.clientX, e.clientY);
    endDrag();
    if (!payload) return;
    if (payload.startsWith('new:')) addField(payload.slice(4) as FormFieldType, index);
    else if (payload.startsWith('move:')) moveField(payload.slice(5), index);
  };
  /** Where to draw the insert line: before field `dropAt`, or after the last one. */
  const dropMark = (index: number): string => {
    if (dropAt === null || !draft) return '';
    if (dropAt === index) return ' is-drop-before';
    if (dropAt === draft.fields.length && index === draft.fields.length - 1) return ' is-drop-after';
    return '';
  };

  if (!draft) {
    return (
      <div className="wrap wrap--wide bk-fm">
        <PageHeader title={isNew ? 'New form' : 'Edit form'} />
        {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : <p className="bk-muted">Loading…</p>}
      </div>
    );
  }

  const pages = previewCols(draft.fields);
  const valueFields = draft.fields.filter((f) => !NO_VALUE_TYPES.has(f.type));
  const emailFields = valueFields.filter((f) => f.type === 'email');

  return (
    <div className="wrap wrap--wide bk-fm bk-fm-edit">
      <PageHeader
        title={isNew ? 'New form' : 'Edit form'}
        actions={
          <>
            {canEntries && formId ? (
              <Link className="button" to={href(`forms/entries?formId=${formId}`)}>
                Entries{summary.unreadCount ? <span className="bk-fm-badge">{summary.unreadCount} new</span> : summary.entryCount ? ` (${summary.entryCount})` : ''}
              </Link>
            ) : null}
            <button type="button" className="button button-primary" disabled={busy || !dirty} onClick={() => void save()}>
              {busy ? 'Saving…' : 'Save form'}
            </button>
          </>
        }
      />
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <div className="bk-fm-titlebar">
        <input ref={titleRef} className="bk-fm-title" type="text" value={draft.title} placeholder="Form title" maxLength={200} onChange={(e) => update({ title: e.target.value })} aria-label="Form title" />
        <label className="bk-fm-status">
          <Switch checked={draft.status === 'active'} onChange={(v) => update({ status: v ? 'active' : 'inactive' })} label="Form is active" />
          <span>{draft.status === 'active' ? 'Active' : 'Inactive — not shown on the site'}</span>
        </label>
      </div>

      <nav className="bk-tabs" aria-label="Form sections">
        {(
          [
            ['fields', 'Fields'],
            ['settings', 'Settings'],
            ['notifications', 'Notifications'],
            ['integrations', 'Integrations'],
          ] as const
        ).map(([t, label]) => (
          <button key={t} type="button" className={`bk-tabs__item${tab === t ? ' is-active' : ''}`} onClick={() => setTab(t)}>
            {label}
            {t === 'fields' ? <span className="bk-tabs__count">{valueFields.length}</span> : null}
            {t === 'integrations' && draft.settings.integrations.hubspot.enabled ? <span className="bk-tabs__count">HubSpot</span> : null}
          </button>
        ))}
      </nav>

      {tab === 'fields' ? (
        <div className="bk-fm-builder">
          <aside className="bk-panel bk-fm-palette" aria-label="Add a field">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Add a field</h2>
            </div>
            <div className="bk-fm-palette__body">
              <p className="bk-fm-palette__hint">Click to add after the selected field, or drag into place.</p>
              {FIELD_GROUPS.map((g) => (
                <div key={g} className="bk-fm-palette__group">
                  <h3>{g}</h3>
                  <div className="bk-fm-palette__grid">
                    {FIELD_TYPES.filter((t) => t.group === g).map((t) => (
                      <button key={t.type} type="button" className="bk-fm-palette__item" draggable onDragStart={(e) => onDragStart(e, `new:${t.type}`)} onDragEnd={endDrag} onClick={() => addField(t.type)} title={t.hint}>
                        <t.Icon size={16} weight="regular" aria-hidden />
                        <span>{t.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </aside>

          <section
            ref={canvasRef}
            className={`bk-fm-canvas${dropAt !== null ? ' is-dragging' : ''}`}
            aria-label="Form fields"
            onClick={(e) => e.target === e.currentTarget && setSelectedId(null)}
            onDragOver={onCanvasDragOver}
            onDragLeave={onCanvasDragLeave}
            onDrop={onCanvasDrop}
          >
            {draft.fields.length === 0 ? (
              <div className={`bk-fm-canvas__empty${dropAt !== null ? ' is-over' : ''}`}>
                <p>No fields yet. Click a field type on the left, or drag one here.</p>
              </div>
            ) : null}
            {(() => {
              let index = 0;
              const last = draft.fields.length - 1;
              return pages.map((pageFields, p) => {
                const pageBreak = p > 0 ? draft.fields[index] : null;
                const items: ReactNode[] = [];
                if (p > 0 && pageBreak && pageBreak.type === 'page') {
                  const pb = pageBreak;
                  const i = index;
                  items.push(
                    <div
                      key={pb.id}
                      className={`bk-fm-break${selectedId === pb.id ? ' is-selected' : ''}${draggingId === pb.id ? ' is-dragging' : ''}${dropMark(i)}`}
                      data-drop-index={i}
                      data-drop-axis="y"
                      draggable
                      onDragStart={(e) => onDragStart(e, `move:${pb.id}`)}
                      onDragEnd={endDrag}
                      onClick={() => setSelectedId(pb.id)}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => e.key === 'Enter' && setSelectedId(pb.id)}
                    >
                      <span className="bk-fm-break__line" />
                      <span className="bk-fm-break__label">
                        Step {p + 1}: {pb.label}
                      </span>
                      <span className="bk-fm-break__line" />
                    </div>,
                  );
                  index += 1;
                }
                items.push(
                  <div key={`page-${p}`} className="bk-fm-canvas__grid">
                    {pageFields.map((f) => {
                      const i = index++;
                      const meta = fieldMeta(f.type);
                      return (
                        <div
                          key={f.id}
                          className={`bk-fm-item-wrap is-${f.width}${dropMark(i)}${f.width === 'full' ? '' : ' is-axis-x'}`}
                          data-drop-index={i}
                          data-drop-axis={f.width === 'full' ? 'y' : 'x'}
                        >
                          <div
                            className={`bk-fm-item${selectedId === f.id ? ' is-selected' : ''}${f.conditional ? ' has-logic' : ''}${draggingId === f.id ? ' is-dragging' : ''}`}
                            draggable
                            onDragStart={(e) => onDragStart(e, `move:${f.id}`)}
                            onDragEnd={endDrag}
                            onClick={() => setSelectedId(f.id)}
                            role="button"
                            tabIndex={0}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') setSelectedId(f.id);
                              if (e.altKey && e.key === 'ArrowUp') { e.preventDefault(); nudgeField(f.id, -1); }
                              if (e.altKey && e.key === 'ArrowDown') { e.preventDefault(); nudgeField(f.id, 1); }
                            }}
                          >
                            <div className="bk-fm-item__head">
                              <ArrowsOutCardinal size={14} className="bk-fm-item__grip" aria-hidden />
                              <meta.Icon size={14} aria-hidden />
                              <span className="bk-fm-item__label">
                                {f.label}
                                {f.required ? <span className="bk-fm-item__req">*</span> : null}
                              </span>
                              <span className="bk-fm-item__type">{meta.label}</span>
                              <span className="bk-fm-item__tools">
                                <button type="button" title="Move up (Alt+↑)" aria-label="Move field up" disabled={i === 0} onClick={(e) => { e.stopPropagation(); nudgeField(f.id, -1); }}>
                                  <ArrowUp size={14} aria-hidden />
                                </button>
                                <button type="button" title="Move down (Alt+↓)" aria-label="Move field down" disabled={i === last} onClick={(e) => { e.stopPropagation(); nudgeField(f.id, 1); }}>
                                  <ArrowDown size={14} aria-hidden />
                                </button>
                                <button type="button" title="Duplicate" aria-label="Duplicate field" onClick={(e) => { e.stopPropagation(); duplicateField(f.id); }}>
                                  <Copy size={14} aria-hidden />
                                </button>
                                <button type="button" title="Delete" aria-label="Delete field" onClick={(e) => { e.stopPropagation(); removeField(f.id); }}>
                                  <Trash size={14} aria-hidden />
                                </button>
                              </span>
                            </div>
                            <FieldGhost field={f} />
                          </div>
                        </div>
                      );
                    })}
                  </div>,
                );
                return <div key={`p-${p}`} className="bk-fm-page">{items}</div>;
              });
            })()}
          </section>

          <aside className="bk-panel bk-fm-inspector" aria-label="Field settings">
            {selected ? (
              <FieldSettings key={selected.id} field={selected} fields={draft.fields} onChange={(patch) => updateField(selected.id, patch)} onRemove={() => removeField(selected.id)} />
            ) : (
              <>
                <div className="bk-panel__head">
                  <h2 className="bk-panel__title">Field settings</h2>
                </div>
                <div className="bk-panel__body bk-fm-inspector__empty">
                  <p>Select a field to change its label, options, width and logic.</p>
                  <p className="bk-fm-inspector__tip">
                    Tip: put short fields like name and email <strong>half</strong> width so they sit side by side.
                  </p>
                </div>
              </>
            )}
          </aside>
        </div>
      ) : null}

      {tab === 'settings' ? (
        <div className="bk-fm-settings">
          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">After sending</h2>
            </div>
            <div className="bk-panel__body bk-fm-rows">
              <Row label="Submit button" hint="Text on the send button.">
                <input type="text" className="regular-text" value={draft.settings.submitLabel} maxLength={60} onChange={(e) => updateSettings({ submitLabel: e.target.value })} />
              </Row>
              <Row label="Then" hint="What the visitor sees after a successful send.">
                <Seg
                  value={draft.settings.confirmation.type}
                  options={[
                    { value: 'message', label: 'Show a message' },
                    { value: 'redirect', label: 'Go to a page' },
                  ]}
                  onChange={(v) =>
                    updateSettings({
                      confirmation: v === 'redirect' ? { type: 'redirect', url: draft.settings.confirmation.type === 'redirect' ? draft.settings.confirmation.url : '' } : { type: 'message', message: draft.settings.confirmation.type === 'message' ? draft.settings.confirmation.message : 'Thanks! Your message has been sent.' },
                    })
                  }
                />
              </Row>
              {draft.settings.confirmation.type === 'message' ? (
                <Row label="Thank-you message" hint="Merge tags work here, e.g. Thanks {field:name}!">
                  <textarea className="bk-fm-textarea" rows={3} value={draft.settings.confirmation.message} onChange={(e) => updateSettings({ confirmation: { type: 'message', message: e.target.value } })} />
                </Row>
              ) : (
                <Row label="Redirect to" hint="A page on this site (/thank-you) or a full address.">
                  <input type="text" className="regular-text" value={draft.settings.confirmation.url} placeholder="/thank-you" onChange={(e) => updateSettings({ confirmation: { type: 'redirect', url: e.target.value } })} />
                </Row>
              )}
            </div>
          </div>

          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Steps</h2>
              <span className="bk-fm-head-meta">{pages.length > 1 ? `${pages.length} steps` : 'Add a Page break field to split the form'}</span>
            </div>
            <div className="bk-panel__body bk-fm-rows">
              <Row label="Progress" hint="Shown above multi-step forms.">
                <Seg
                  value={draft.settings.progress}
                  options={[
                    { value: 'bar', label: 'Bar' },
                    { value: 'steps', label: 'Numbered steps' },
                    { value: 'none', label: 'None' },
                  ]}
                  onChange={(v) => updateSettings({ progress: v })}
                />
              </Row>
              <Row label="Buttons" inline>
                <div className="bk-fm-inline-inputs">
                  <input type="text" className="regular-text" value={draft.settings.nextLabel} maxLength={40} onChange={(e) => updateSettings({ nextLabel: e.target.value })} aria-label="Next button" />
                  <input type="text" className="regular-text" value={draft.settings.backLabel} maxLength={40} onChange={(e) => updateSettings({ backLabel: e.target.value })} aria-label="Back button" />
                </div>
              </Row>
            </div>
          </div>

          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Entries and spam</h2>
            </div>
            <div className="bk-panel__body bk-fm-rows">
              <Row label="Keep entries in the admin" hint="Turn off to only send emails. Uploaded files are always kept so the email links work." inline>
                <Switch checked={draft.settings.storeEntries} onChange={(v) => updateSettings({ storeEntries: v })} label="Keep entries" />
              </Row>
              <Row label="Minimum fill time" hint="Submissions faster than this are treated as bots. A honeypot and rate limits are always on." inline>
                <div className="bk-fm-inline-inputs">
                  <input type="number" min={0} max={60} value={draft.settings.minSeconds} onChange={(e) => updateSettings({ minSeconds: Math.max(0, Math.min(60, Number(e.target.value) || 0)) })} aria-label="Seconds" style={{ width: 80 }} />
                  <span className="bk-muted">seconds</span>
                </div>
              </Row>
            </div>
          </div>
        </div>
      ) : null}

      {tab === 'notifications' ? (
        <div className="bk-fm-settings">
          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Notification email</h2>
              <Switch checked={draft.settings.notification.enabled} onChange={(v) => updateSettings({ notification: { ...draft.settings.notification, enabled: v } })} label="Send a notification" />
            </div>
            <div className={`bk-panel__body bk-fm-rows${draft.settings.notification.enabled ? '' : ' is-off'}`}>
              <Row label="Send to" hint="One or more addresses, separated by commas. {admin_email} is the site owner.">
                <input type="text" className="regular-text" value={draft.settings.notification.to} onChange={(e) => updateSettings({ notification: { ...draft.settings.notification, to: e.target.value } })} />
              </Row>
              <Row label="Reply to" hint="Replying to the notification goes to this field's address.">
                <select value={draft.settings.notification.replyToField} onChange={(e) => updateSettings({ notification: { ...draft.settings.notification, replyToField: e.target.value } })}>
                  <option value="">Nobody (the site's own address)</option>
                  {emailFields.map((f) => (
                    <option key={f.id} value={f.name}>
                      {f.label}
                    </option>
                  ))}
                </select>
              </Row>
              <Row label="Subject">
                <input type="text" className="regular-text" value={draft.settings.notification.subject} maxLength={300} onChange={(e) => updateSettings({ notification: { ...draft.settings.notification, subject: e.target.value } })} />
              </Row>
              <Row label="Message">
                <textarea className="bk-fm-textarea" rows={7} value={draft.settings.notification.message} onChange={(e) => updateSettings({ notification: { ...draft.settings.notification, message: e.target.value } })} />
              </Row>
            </div>
          </div>

          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Auto-reply to the visitor</h2>
              <Switch checked={draft.settings.autoReply.enabled} onChange={(v) => updateSettings({ autoReply: { ...draft.settings.autoReply, enabled: v } })} label="Send an auto-reply" />
            </div>
            <div className={`bk-panel__body bk-fm-rows${draft.settings.autoReply.enabled ? '' : ' is-off'}`}>
              {emailFields.length === 0 ? <p className="beekiri-notice is-info bk-fm-notice">Add an Email field so there is an address to reply to.</p> : null}
              <Row label="Send to" hint="The visitor's email field.">
                <select value={draft.settings.autoReply.toField} onChange={(e) => updateSettings({ autoReply: { ...draft.settings.autoReply, toField: e.target.value } })}>
                  <option value="">First email field</option>
                  {emailFields.map((f) => (
                    <option key={f.id} value={f.name}>
                      {f.label}
                    </option>
                  ))}
                </select>
              </Row>
              <Row label="Subject">
                <input type="text" className="regular-text" value={draft.settings.autoReply.subject} maxLength={300} onChange={(e) => updateSettings({ autoReply: { ...draft.settings.autoReply, subject: e.target.value } })} />
              </Row>
              <Row label="Message">
                <textarea className="bk-fm-textarea" rows={7} value={draft.settings.autoReply.message} onChange={(e) => updateSettings({ autoReply: { ...draft.settings.autoReply, message: e.target.value } })} />
              </Row>
            </div>
          </div>

          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Merge tags</h2>
            </div>
            <div className="bk-panel__body">
              <p className="bk-muted bk-fm-tags__intro">Use these in subjects, messages and the thank-you text. They are replaced with the visitor's answers.</p>
              <ul className="bk-fm-tags">
                {valueFields.map((f) => (
                  <li key={f.id}>
                    <code>{`{field:${f.name}}`}</code>
                    <span>{f.label}</span>
                  </li>
                ))}
                {MERGE_TAGS.map((t) => (
                  <li key={t.tag}>
                    <code>{t.tag}</code>
                    <span>{t.label}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      ) : null}

      {tab === 'integrations' ? (
        <FormIntegrationsTab fields={draft.fields} feed={draft.settings.integrations.hubspot} onChange={(hubspot) => updateSettings({ integrations: { ...draft.settings.integrations, hubspot } })} />
      ) : null}

      {dirty ? (
        <div className="bk-fm-savebar" role="region" aria-label="Unsaved changes">
          <p>
            <strong>Unsaved changes</strong> to {draft.title.trim() || 'this form'}
          </p>
          <div className="bk-fm-savebar__actions">
            <button type="button" className="button" disabled={busy} onClick={discard}>
              Discard
            </button>
            <button type="button" className="button button-primary" disabled={busy} onClick={() => void save()}>
              {busy ? 'Saving…' : 'Save form'}
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function pruneCondition(c: FieldCondition, removedId: string): FieldCondition | undefined {
  const rules = c.rules.filter((r) => r.field !== removedId);
  return rules.length ? { ...c, rules } : undefined;
}

/** What the field looks like on the site, drawn simply so the canvas reads at a glance. */
function FieldGhost({ field: f }: { field: FormField }) {
  switch (f.type) {
    case 'textarea':
      return <div className="bk-fm-ghost bk-fm-ghost--area">{f.placeholder || ''}</div>;
    case 'select':
      return <div className="bk-fm-ghost bk-fm-ghost--select">{f.placeholder || 'Choose…'}</div>;
    case 'radio':
    case 'checkbox':
      return (
        <div className="bk-fm-ghost--choices">
          {(f.options ?? []).slice(0, 4).map((o, i) => (
            <span key={i} className={`bk-fm-ghost__choice is-${f.type}`}>
              <i /> {o.label}
            </span>
          ))}
          {(f.options ?? []).length > 4 ? <span className="bk-fm-ghost__more">+{(f.options ?? []).length - 4} more</span> : null}
        </div>
      );
    case 'consent':
      return (
        <div className="bk-fm-ghost--choices">
          <span className="bk-fm-ghost__choice is-checkbox">
            <i /> {f.text || f.label}
          </span>
        </div>
      );
    case 'file':
      return <div className="bk-fm-ghost bk-fm-ghost--file">Choose file{(f.maxFiles ?? 1) > 1 ? 's' : ''}…</div>;
    case 'hidden':
      return <div className="bk-fm-ghost bk-fm-ghost--hidden">Hidden · {f.hiddenSource === 'static' ? `"${f.defaultValue ?? ''}"` : (f.hiddenSource ?? 'static').replace('_', ' ')}</div>;
    case 'section':
      return <div className="bk-fm-ghost--section">{f.text || 'Description…'}</div>;
    default:
      return <div className="bk-fm-ghost">{f.placeholder || ''}</div>;
  }
}

function FieldSettings({ field: f, fields, onChange, onRemove }: { field: FormField; fields: FormField[]; onChange: (p: Partial<FormField>) => void; onRemove: () => void }) {
  const meta = fieldMeta(f.type);
  const [nameTouched, setNameTouched] = useState(() => f.name !== nameFromLabel(f.label));
  const others = fields.filter((x) => x.id !== f.id && !NO_VALUE_TYPES.has(x.type) && x.type !== 'file');

  const setLabel = (label: string) => {
    const patch: Partial<FormField> = { label };
    if (!nameTouched) patch.name = uniqueName(nameFromLabel(label), fields, f.id);
    onChange(patch);
  };

  const setOptionsText = (text: string) => {
    const options = text
      .split('\n')
      .map((line) => {
        const [label, value] = line.split('|').map((s) => s.trim());
        return label ? { label, value: value || label } : null;
      })
      .filter((o): o is { label: string; value: string } => Boolean(o));
    onChange({ options });
  };
  const [optionsText, setOptionsText_] = useState(() => (f.options ?? []).map((o) => (o.value !== o.label ? `${o.label} | ${o.value}` : o.label)).join('\n'));

  const cond = f.conditional;
  const setCond = (patch: Partial<FieldCondition> | null) => {
    if (patch === null) return onChange({ conditional: undefined });
    const base: FieldCondition = cond ?? { action: 'show', match: 'all', rules: [] };
    onChange({ conditional: { ...base, ...patch } });
  };
  const setRule = (i: number, patch: Partial<ConditionRule>) => {
    const rules = (cond?.rules ?? []).map((r, k) => (k === i ? { ...r, ...patch } : r));
    setCond({ rules });
  };
  const addRule = () => setCond({ rules: [...(cond?.rules ?? []), { field: others[0]?.id ?? '', op: 'is', value: '' }] });
  const ruleValueOptions = (r: ConditionRule) => {
    const target = fields.find((x) => x.id === r.field);
    return target && CHOICE_TYPES.has(target.type) ? (target.options ?? []) : null;
  };

  const isLayout = NO_VALUE_TYPES.has(f.type);

  return (
    <>
      <div className="bk-panel__head">
        <h2 className="bk-panel__title">
          <meta.Icon size={15} aria-hidden /> {meta.label}
        </h2>
        <button type="button" className="button-link is-danger" onClick={onRemove}>
          Delete
        </button>
      </div>
      <div className="bk-panel__body bk-fm-field-settings">
        <label className="bk-fm-field">
          <span>{f.type === 'page' ? 'Step title' : f.type === 'section' ? 'Heading' : 'Label'}</span>
          <input type="text" value={f.label} maxLength={200} onChange={(e) => setLabel(e.target.value)} />
        </label>

        {f.type === 'section' || f.type === 'consent' ? (
          <label className="bk-fm-field">
            <span>{f.type === 'consent' ? 'Text next to the box' : 'Description'}</span>
            <textarea rows={3} value={f.text ?? ''} maxLength={2000} onChange={(e) => onChange({ text: e.target.value })} />
          </label>
        ) : null}

        {!isLayout && f.type !== 'hidden' && f.type !== 'consent' ? (
          <>
            {f.type !== 'checkbox' && f.type !== 'radio' && f.type !== 'file' && f.type !== 'date' ? (
              <label className="bk-fm-field">
                <span>Placeholder</span>
                <input type="text" value={f.placeholder ?? ''} maxLength={200} onChange={(e) => onChange({ placeholder: e.target.value })} />
              </label>
            ) : null}
            <label className="bk-fm-field">
              <span>Help text</span>
              <input type="text" value={f.help ?? ''} maxLength={500} placeholder="Shown under the field" onChange={(e) => onChange({ help: e.target.value })} />
            </label>
          </>
        ) : null}

        {!isLayout ? (
          <div className="bk-fm-field">
            <span>Width</span>
            <Seg
              value={f.width}
              options={[
                { value: 'full', label: 'Full' },
                { value: 'half', label: '1/2' },
                { value: 'third', label: '1/3' },
              ]}
              onChange={(v) => onChange({ width: v })}
            />
          </div>
        ) : null}

        {!isLayout && f.type !== 'hidden' ? (
          <div className="bk-fm-checks">
            <label className="bk-fm-check">
              <input type="checkbox" checked={Boolean(f.required)} onChange={(e) => onChange({ required: e.target.checked })} />
              <span>Required</span>
            </label>
            {f.type !== 'consent' ? (
              <label className="bk-fm-check">
                <input type="checkbox" checked={Boolean(f.hideLabel)} onChange={(e) => onChange({ hideLabel: e.target.checked })} />
                <span>Hide label (placeholder only)</span>
              </label>
            ) : null}
            {f.type === 'select' ? (
              <label className="bk-fm-check">
                <input type="checkbox" checked={Boolean(f.multiple)} onChange={(e) => onChange({ multiple: e.target.checked })} />
                <span>Allow several choices</span>
              </label>
            ) : null}
          </div>
        ) : null}

        {CHOICE_TYPES.has(f.type) ? (
          <label className="bk-fm-field">
            <span>Options</span>
            <textarea
              rows={Math.min(10, Math.max(4, optionsText.split('\n').length + 1))}
              value={optionsText}
              onChange={(e) => {
                setOptionsText_(e.target.value);
                setOptionsText(e.target.value);
              }}
              onBlur={() => setOptionsText_((f.options ?? []).map((o) => (o.value !== o.label ? `${o.label} | ${o.value}` : o.label)).join('\n'))}
              placeholder={'One per line\nLabel | value (optional)'}
            />
            <small>One option per line. Add “| value” to save a different value than the label.</small>
          </label>
        ) : null}

        {f.type === 'textarea' ? (
          <label className="bk-fm-field is-short">
            <span>Rows</span>
            <input type="number" min={2} max={20} value={f.rows ?? 4} onChange={(e) => onChange({ rows: Math.max(2, Math.min(20, Number(e.target.value) || 4)) })} />
          </label>
        ) : null}

        {f.type === 'number' || f.type === 'date' ? (
          <div className="bk-fm-field-pair">
            <label className="bk-fm-field">
              <span>Min</span>
              <input type={f.type === 'date' ? 'date' : 'number'} value={f.min ?? ''} onChange={(e) => onChange({ min: e.target.value })} />
            </label>
            <label className="bk-fm-field">
              <span>Max</span>
              <input type={f.type === 'date' ? 'date' : 'number'} value={f.max ?? ''} onChange={(e) => onChange({ max: e.target.value })} />
            </label>
          </div>
        ) : null}

        {f.type === 'file' ? (
          <>
            <div className="bk-fm-field">
              <span>Allowed files</span>
              <div className="bk-fm-checks">
                <label className="bk-fm-check">
                  <input type="checkbox" checked={(f.accept ?? ['any']).includes('any')} onChange={(e) => onChange({ accept: e.target.checked ? ['any'] : ['image', 'pdf'] })} />
                  <span>Any file (except scripts)</span>
                </label>
                {!(f.accept ?? ['any']).includes('any')
                  ? ACCEPT_KINDS.map((k) => (
                      <label key={k.id} className="bk-fm-check">
                        <input
                          type="checkbox"
                          checked={(f.accept ?? []).includes(k.id)}
                          onChange={(e) => {
                            const set = new Set(f.accept ?? []);
                            if (e.target.checked) set.add(k.id);
                            else set.delete(k.id);
                            onChange({ accept: set.size ? [...set] : ['any'] });
                          }}
                        />
                        <span>{k.label}</span>
                      </label>
                    ))
                  : null}
              </div>
              <small>Up to 10 MB each. Files are private; only admins can download them.</small>
            </div>
            <label className="bk-fm-field is-short">
              <span>Max files</span>
              <input type="number" min={1} max={10} value={f.maxFiles ?? 1} onChange={(e) => onChange({ maxFiles: Math.max(1, Math.min(10, Number(e.target.value) || 1)) })} />
            </label>
          </>
        ) : null}

        {f.type === 'hidden' ? (
          <>
            <label className="bk-fm-field">
              <span>Value</span>
              <select value={f.hiddenSource ?? 'static'} onChange={(e) => onChange({ hiddenSource: e.target.value as FormField['hiddenSource'] })}>
                <option value="page_url">Page the form was sent from</option>
                <option value="page_title">Page title</option>
                <option value="referrer">Referrer</option>
                <option value="static">Fixed text</option>
              </select>
            </label>
            {(f.hiddenSource ?? 'static') === 'static' ? (
              <label className="bk-fm-field">
                <span>Fixed text</span>
                <input type="text" value={f.defaultValue ?? ''} onChange={(e) => onChange({ defaultValue: e.target.value })} />
              </label>
            ) : null}
          </>
        ) : !isLayout && f.type !== 'file' && f.type !== 'consent' ? (
          <label className="bk-fm-field">
            <span>Default value</span>
            {CHOICE_TYPES.has(f.type) && f.type !== 'select' ? (
              <input type="text" value={f.defaultValue ?? ''} placeholder="Option value(s), one per line for checkboxes" onChange={(e) => onChange({ defaultValue: e.target.value })} />
            ) : (
              <input type="text" value={f.defaultValue ?? ''} onChange={(e) => onChange({ defaultValue: e.target.value })} />
            )}
          </label>
        ) : null}

        {!isLayout || f.type === 'section' ? (
          <div className="bk-fm-logic">
            <div className="bk-fm-logic__head">
              <span className="bk-fm-field__label">Conditional logic</span>
              <Switch checked={Boolean(cond)} onChange={(v) => (v ? setCond({ rules: [{ field: others[0]?.id ?? '', op: 'is', value: '' }] }) : setCond(null))} label="Enable conditional logic" disabled={!others.length} />
            </div>
            {!others.length ? <small>Add another field first to build a rule on it.</small> : null}
            {cond ? (
              <div className="bk-fm-logic__body">
                <div className="bk-fm-logic__sentence">
                  <select value={cond.action} onChange={(e) => setCond({ action: e.target.value as 'show' | 'hide' })} aria-label="Action">
                    <option value="show">Show</option>
                    <option value="hide">Hide</option>
                  </select>
                  <span>this field if</span>
                  <select value={cond.match} onChange={(e) => setCond({ match: e.target.value as 'all' | 'any' })} aria-label="Match">
                    <option value="all">all</option>
                    <option value="any">any</option>
                  </select>
                  <span>of these match:</span>
                </div>
                {cond.rules.map((r, i) => {
                  const choices = ruleValueOptions(r);
                  const op = OPS.find((o) => o.value === r.op) ?? OPS[0];
                  return (
                    <div key={i} className="bk-fm-rule">
                      <select value={r.field} onChange={(e) => setRule(i, { field: e.target.value, value: '' })} aria-label="Field">
                        {others.map((o) => (
                          <option key={o.id} value={o.id}>
                            {o.label}
                          </option>
                        ))}
                      </select>
                      <select value={r.op} onChange={(e) => setRule(i, { op: e.target.value as ConditionOp })} aria-label="Condition">
                        {OPS.map((o) => (
                          <option key={o.value} value={o.value}>
                            {o.label}
                          </option>
                        ))}
                      </select>
                      {op.needsValue ? (
                        choices ? (
                          <select value={r.value} onChange={(e) => setRule(i, { value: e.target.value })} aria-label="Value">
                            <option value="">—</option>
                            {choices.map((c) => (
                              <option key={c.value} value={c.value}>
                                {c.label}
                              </option>
                            ))}
                          </select>
                        ) : (
                          <input type="text" value={r.value} onChange={(e) => setRule(i, { value: e.target.value })} aria-label="Value" />
                        )
                      ) : null}
                      <button type="button" className="button-link is-danger" onClick={() => (cond.rules.length === 1 ? setCond(null) : setCond({ rules: cond.rules.filter((_, k) => k !== i) }))} aria-label="Remove rule">
                        ×
                      </button>
                    </div>
                  );
                })}
                <button type="button" className="button-link" onClick={addRule}>
                  + Add rule
                </button>
              </div>
            ) : null}
          </div>
        ) : null}

        {!isLayout ? (
          <label className="bk-fm-field bk-fm-field--name">
            <span>Field key</span>
            <input
              type="text"
              value={f.name}
              onChange={(e) => {
                setNameTouched(true);
                onChange({ name: uniqueName(nameFromLabel(e.target.value) || 'field', fields, f.id) });
              }}
            />
            <small>Used in merge tags: {`{field:${f.name}}`}</small>
          </label>
        ) : null}
      </div>
    </>
  );
}
