import { useEffect, useState, type FormEvent } from 'react';
import { Check, Copy } from '@phosphor-icons/react';
import { api } from '../../api/client';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { useAuth } from '../../auth/AuthContext';
import { BrandLogo } from './BrandLogo';
import { formatDate, formsError, type IntegrationProviderInfo, type IntegrationsInfo } from './api';
import './forms.css';

const BLURB: Record<IntegrationProviderInfo['id'], string> = {
  hubspot: 'Create or update a HubSpot contact for every entry, with the answers and where the visitor came from.',
  brevo: 'Add people to Brevo contact lists and trigger your email automations.',
  mailchimp: 'Subscribe people to a Mailchimp audience with tags and merge fields.',
  salesforce: 'Create Salesforce leads or contacts from form entries.',
};


function CopyChip({ text }: { text: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      className="bk-fm-copychip"
      onClick={() => {
        void navigator.clipboard?.writeText(text).then(() => {
          setDone(true);
          window.setTimeout(() => setDone(false), 1500);
        });
      }}
      title="Copy"
    >
      <code>{text}</code>
      {done ? <Check size={13} aria-hidden /> : <Copy size={13} aria-hidden />}
    </button>
  );
}

export function IntegrationsPage() {
  const auth = useAuth();
  const canConnect = auth.user?.capabilities.includes('manage_options') ?? false;
  const [info, setInfo] = useState<IntegrationsInfo | null>(null);
  const [token, setToken] = useState('');
  const [replacing, setReplacing] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = async () => {
    try {
      setInfo(await api<IntegrationsInfo>('/api/forms/integrations'));
    } catch (e) {
      setError(formsError(e));
    }
  };
  useEffect(() => {
    void load();
  }, []);

  const connect = async (e: FormEvent) => {
    e.preventDefault();
    if (!token.trim()) return;
    setBusy('connect');
    setError(null);
    try {
      setInfo(await api<IntegrationsInfo>('/api/forms/integrations/hubspot/connect', { method: 'POST', json: { token: token.trim() } }));
      setToken('');
      setReplacing(false);
      setNotice('HubSpot connected. Turn it on per form in the form’s Integrations tab.');
    } catch (err) {
      setError(formsError(err));
    } finally {
      setBusy(null);
    }
  };

  const test = async () => {
    setBusy('test');
    try {
      const r = await api<{ ok: boolean; message: string }>('/api/forms/integrations/hubspot/test', { method: 'POST' });
      if (r.ok) setNotice(r.message);
      else setError(r.message);
      await load();
    } catch (e) {
      setError(formsError(e));
    } finally {
      setBusy(null);
    }
  };

  const retryFailed = async () => {
    setBusy('retry');
    try {
      const r = await api<{ queued: number }>('/api/forms/integrations/hubspot/retry-failed', { method: 'POST' });
      setNotice(r.queued ? `${r.queued} ${r.queued === 1 ? 'entry is' : 'entries are'} being sent again.` : 'No failed entries in the last 30 days.');
    } catch (e) {
      setError(formsError(e));
    } finally {
      setBusy(null);
    }
  };

  const disconnect = async () => {
    const ok = await confirmDialog({
      title: 'Disconnect HubSpot?',
      message: 'Forms stop sending entries to HubSpot until you connect it again. Entries and your field mappings are kept; nothing is deleted in HubSpot.',
      confirmLabel: 'Disconnect',
      danger: true,
    });
    if (!ok) return;
    setBusy('disconnect');
    try {
      setInfo(await api<IntegrationsInfo>('/api/forms/integrations/hubspot', { method: 'DELETE' }));
      setNotice('HubSpot disconnected.');
    } catch (e) {
      setError(formsError(e));
    } finally {
      setBusy(null);
    }
  };

  const hubspot = info?.providers.find((p) => p.id === 'hubspot');
  const others = info?.providers.filter((p) => p.id !== 'hubspot') ?? [];
  const scopes = info?.scopes ?? [];
  const showForm = hubspot && (!hubspot.connected || replacing);

  return (
    <div className="wrap wrap--wide bk-fm">
      <PageHeader title="Integrations" />
      <p className="bk-muted">Send form entries to your CRM or email marketing tool. Connect an account here, then choose per form which answers go where.</p>
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      {info && info.keysPersist === false ? (
        <div className="beekiri-notice is-warning bk-fm-int__warn" role="status">
          <p>
            <strong>Keys won’t survive a restart.</strong> Add a line <code>CACHE_FLUSH_SECRET=</code> with a long random value to <code>apps/api/.env</code> (for example the output of <code>openssl rand -hex 32</code>), restart Beekiri, then connect.
          </p>
        </div>
      ) : null}
      {!info ? (
        <p className="bk-muted">Loading…</p>
      ) : (
        <div className="bk-fm-integrations">
          {hubspot ? (
            <section className="bk-panel bk-fm-int">
              <div className="bk-fm-int__head">
                <BrandLogo id="hubspot" />
                <div className="bk-fm-int__title">
                  <h2>HubSpot</h2>
                  <p>{BLURB.hubspot}</p>
                </div>
                {hubspot.connected ? (
                  <span className={`bk-fm-pill ${hubspot.health === 'connected' ? 'is-ok' : 'is-danger'}`}>{hubspot.health === 'connected' ? 'Connected' : 'Needs attention'}</span>
                ) : hubspot.unreadable ? (
                  <span className="bk-fm-pill is-danger">Reconnect needed</span>
                ) : (
                  <span className="bk-fm-pill is-muted">Not connected</span>
                )}
              </div>
              {hubspot.unreadable ? <p className="beekiri-notice is-error bk-fm-int__notice">{hubspot.lastError}</p> : null}

              {hubspot.connected && hubspot.health !== 'connected' && hubspot.lastError ? <p className="beekiri-notice is-error bk-fm-int__notice">{hubspot.lastError}</p> : null}

              {hubspot.connected ? (
                <div className="bk-fm-int__body">
                  <dl className="bk-fm-infolist">
                    <div className="bk-fm-info">
                      <dt>HubSpot account</dt>
                      <dd>{hubspot.account?.portalId ? `#${hubspot.account.portalId}` : '—'}</dd>
                    </div>
                    <div className="bk-fm-info">
                      <dt>Data location</dt>
                      <dd>{hubspot.account?.dataHostingLocation ? hubspot.account.dataHostingLocation.toUpperCase() : '—'}</dd>
                    </div>
                    <div className="bk-fm-info">
                      <dt>Access token</dt>
                      <dd>
                        <code>{hubspot.tokenHint}</code>
                      </dd>
                    </div>
                    <div className="bk-fm-info">
                      <dt>Connected</dt>
                      <dd>{formatDate(hubspot.connectedAt)}</dd>
                    </div>
                  </dl>
                  <p className="bk-fm-int__hint">Turn HubSpot on for a form under <strong>Forms → (a form) → Integrations</strong>. Contacts with the same email are updated, never duplicated.</p>
                  {canConnect ? (
                    <div className="bk-fm-int__actions">
                      <button type="button" className="button" disabled={busy !== null} onClick={() => void test()}>
                        {busy === 'test' ? 'Testing…' : 'Test connection'}
                      </button>
                      <button type="button" className="button" disabled={busy !== null} onClick={() => void retryFailed()}>
                        {busy === 'retry' ? 'Queuing…' : 'Retry failed entries'}
                      </button>
                      <button type="button" className="button-link" onClick={() => setReplacing((v) => !v)}>
                        {replacing ? 'Cancel' : 'Replace token'}
                      </button>
                      <button type="button" className="button-link is-danger" disabled={busy !== null} onClick={() => void disconnect()}>
                        Disconnect
                      </button>
                    </div>
                  ) : null}
                </div>
              ) : null}

              {showForm ? (
                canConnect ? (
                  <form className="bk-fm-int__connect" onSubmit={(e) => void connect(e)}>
                    <ol className="bk-fm-steps">
                      <li>
                        In HubSpot, click the <strong>settings</strong> icon, then <strong>Integrations → Private Apps</strong> and <strong>Create a private app</strong>. In newer accounts it is under <strong>Development → Legacy apps → Create → Private</strong>.
                      </li>
                      <li>
                        Name it <em>Beekiri</em>. On the <strong>Scopes</strong> tab, add these three:
                        <span className="bk-fm-scopes">
                          {scopes.map((s) => (
                            <CopyChip key={s} text={s} />
                          ))}
                        </span>
                      </li>
                      <li>
                        Click <strong>Create app</strong>, then <strong>Show token</strong> and copy the access token (it starts with <code>pat-</code>).
                      </li>
                    </ol>
                    <label className="bk-fm-field">
                      <span>Access token</span>
                      <input type="password" autoComplete="off" spellCheck={false} value={token} placeholder="pat-eu1-…" onChange={(e) => setToken(e.target.value)} />
                      <small>Stored encrypted. Beekiri checks it with HubSpot before saving.</small>
                    </label>
                    <div className="bk-fm-int__actions">
                      <button type="submit" className="button button-primary" disabled={busy !== null || !token.trim()}>
                        {busy === 'connect' ? 'Checking with HubSpot…' : hubspot.connected ? 'Save new token' : hubspot.unreadable ? 'Reconnect HubSpot' : 'Connect HubSpot'}
                      </button>
                    </div>
                  </form>
                ) : (
                  <p className="bk-fm-int__hint">Ask an administrator to connect HubSpot.</p>
                )
              ) : null}
            </section>
          ) : null}

          <h2 className="bk-fm-int__soon-title">Coming soon</h2>
          <div className="bk-fm-int__soon">
            {others.map((p) => (
              <section key={p.id} className="bk-panel bk-fm-int is-soon">
                <div className="bk-fm-int__head">
                  <BrandLogo id={p.id} />
                  <div className="bk-fm-int__title">
                    <h2>{p.name}</h2>
                    <p>{BLURB[p.id]}</p>
                  </div>
                  <span className="bk-fm-pill is-muted">Coming soon</span>
                </div>
              </section>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
