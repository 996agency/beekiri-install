import type { ComponentType } from 'react';
import {
  ArrowSquareIn,
  EnvelopeSimple,
  FacebookLogo,
  Globe,
  Handshake,
  InstagramLogo,
  LinkedinLogo,
  MagnifyingGlass,
  Megaphone,
  MetaLogo,
  PinterestLogo,
  Question,
  RedditLogo,
  SnapchatLogo,
  TelegramLogo,
  ThreadsLogo,
  TiktokLogo,
  WhatsappLogo,
  XLogo,
  YoutubeLogo,
  type IconProps,
} from '@phosphor-icons/react';

/** Google's four-colour "G". */
function GoogleG({ size }: { size: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden focusable="false">
      <path fill="#4285F4" d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z" />
      <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z" />
      <path fill="#FBBC05" d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z" />
      <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z" />
    </svg>
  );
}

/** Microsoft's four squares (Microsoft Ads / Bing). */
function MicrosoftSquares({ size }: { size: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden focusable="false">
      <rect x="1" y="1" width="10.5" height="10.5" fill="#F25022" />
      <rect x="12.5" y="1" width="10.5" height="10.5" fill="#7FBA00" />
      <rect x="1" y="12.5" width="10.5" height="10.5" fill="#00A4EF" />
      <rect x="12.5" y="12.5" width="10.5" height="10.5" fill="#FFB900" />
    </svg>
  );
}

type Mark = { kind: 'custom'; render: (size: number) => JSX.Element } | { kind: 'icon'; Icon: ComponentType<IconProps>; color: string; weight?: IconProps['weight'] };

const BRANDS: [RegExp, Mark][] = [
  [/google|youtube ads|gclid/i, { kind: 'custom', render: (s) => <GoogleG size={s} /> }],
  [/microsoft|bing/i, { kind: 'custom', render: (s) => <MicrosoftSquares size={s} /> }],
  [/linkedin/i, { kind: 'icon', Icon: LinkedinLogo, color: '#0A66C2', weight: 'fill' }],
  [/meta/i, { kind: 'icon', Icon: MetaLogo, color: '#0866FF', weight: 'bold' }],
  [/facebook|\bfb\b/i, { kind: 'icon', Icon: FacebookLogo, color: '#0866FF', weight: 'fill' }],
  [/instagram/i, { kind: 'icon', Icon: InstagramLogo, color: '#E4405F', weight: 'bold' }],
  [/tiktok/i, { kind: 'icon', Icon: TiktokLogo, color: '#111111', weight: 'fill' }],
  [/^x( ads)?$|twitter/i, { kind: 'icon', Icon: XLogo, color: '#111111', weight: 'bold' }],
  [/youtube/i, { kind: 'icon', Icon: YoutubeLogo, color: '#FF0000', weight: 'fill' }],
  [/pinterest/i, { kind: 'icon', Icon: PinterestLogo, color: '#BD081C', weight: 'fill' }],
  [/snapchat/i, { kind: 'icon', Icon: SnapchatLogo, color: '#111111', weight: 'fill' }],
  [/reddit/i, { kind: 'icon', Icon: RedditLogo, color: '#FF4500', weight: 'fill' }],
  [/whatsapp/i, { kind: 'icon', Icon: WhatsappLogo, color: '#25D366', weight: 'fill' }],
  [/telegram/i, { kind: 'icon', Icon: TelegramLogo, color: '#229ED9', weight: 'fill' }],
  [/threads/i, { kind: 'icon', Icon: ThreadsLogo, color: '#111111', weight: 'bold' }],
];

const CHANNELS: Record<string, Mark> = {
  Email: { kind: 'icon', Icon: EnvelopeSimple, color: '#646970', weight: 'bold' },
  Direct: { kind: 'icon', Icon: ArrowSquareIn, color: '#8c8f94', weight: 'bold' },
  Referral: { kind: 'icon', Icon: Globe, color: '#646970', weight: 'bold' },
  'Organic search': { kind: 'icon', Icon: MagnifyingGlass, color: '#646970', weight: 'bold' },
  Affiliate: { kind: 'icon', Icon: Handshake, color: '#646970', weight: 'bold' },
  Campaign: { kind: 'icon', Icon: Megaphone, color: '#646970', weight: 'bold' },
  Paid: { kind: 'icon', Icon: Megaphone, color: '#006199', weight: 'bold' },
  Display: { kind: 'icon', Icon: Megaphone, color: '#006199', weight: 'bold' },
};

function markFor(channel: string | null | undefined, source: string | null | undefined): Mark {
  const s = source ?? '';
  for (const [re, mark] of BRANDS) if (re.test(s)) return mark;
  if (channel && CHANNELS[channel]) return CHANNELS[channel];
  if (channel === 'Paid search' || channel === 'Paid social') return CHANNELS.Paid;
  if (channel === 'Social') return { kind: 'icon', Icon: Globe, color: '#646970', weight: 'bold' };
  return { kind: 'icon', Icon: Question, color: '#a7aaad', weight: 'bold' };
}

/** Small logo of where a visit came from, in a soft round tile. */
export function SourceIcon({ channel, source, size = 28 }: { channel?: string | null; source?: string | null; size?: number }) {
  const mark = markFor(channel, source);
  const inner = Math.round(size * 0.55);
  return (
    <span className="bk-fm-srcicon" style={{ width: size, height: size }} aria-hidden>
      {mark.kind === 'custom' ? mark.render(inner) : <mark.Icon size={inner} weight={mark.weight ?? 'regular'} color={mark.color} />}
    </span>
  );
}
