import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { api, apiUrl } from '../../api/client';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { useAdminHref } from '../../lib/AdminEntryContext';
import {
  buildQuery,
  channelTone,
  countryName,
  flagEmoji,
  formatDate,
  formsError,
  type EntryList,
  type EntryStatus,
  type FormSummary,
  type SourceCount,
} from './api';
import { SquaresFour } from '@phosphor-icons/react';
import { SourceIcon } from './SourceIcon';
import './forms.css';

type Tab = 'inbox' | 'unread' | 'spam' | 'trash';
const TABS: { id: Tab; label: string }[] = [
  { id: 'inbox', label: 'Inbox' },
  { id: 'unread', label: 'Unread' },
  { id: 'spam', label: 'Spam' },
  { id: 'trash', label: 'Trash' },
];

const NOT_RECORDED = 'Not recorded';

/** Channel totals, and the top sources across all channels, from the grouped counts. */
function summarizeSources(rows: SourceCount[]) {
  const channels = new Map<string, number>();
  for (const r of rows) channels.set(r.channel ?? 'none', (channels.get(r.channel ?? 'none') ?? 0) + r.count);
  const total = rows.reduce((n, r) => n + r.count, 0);
  return {
    total,
    channels: [...channels.entries()].map(([channel, count]) => ({ channel, count })).sort((a, b) => b.count - a.count),
    sources: rows.filter((r) => r.channel && r.source).slice(0, 8),
  };
}

/** Logo + source name, with the channel (and campaign) underneath. */
export function SourceBadge({ channel, source, campaign }: { channel?: string | null; source?: string | null; campaign?: string | null }) {
  if (!channel) {
    return (
      <span className="bk-fm-srccell is-muted">
        <SourceIcon channel={null} source={null} size={28} />
        <span className="bk-fm-srccell__text">
          <span className="bk-fm-srccell__name">{NOT_RECORDED}</span>
        </span>
      </span>
    );
  }
  const same = !source || source === channel;
  const sub = [same ? '' : channel, campaign ?? ''].filter(Boolean).join(' · ');
  return (
    <span className={`bk-fm-srccell is-${channelTone(channel)}`} title={[channel, same ? '' : source, campaign].filter(Boolean).join(' · ')}>
      <SourceIcon channel={channel} source={source} size={28} />
      <span className="bk-fm-srccell__text">
        <span className="bk-fm-srccell__name">{same ? channel : source}</span>
        {sub ? <span className="bk-fm-srccell__sub">{sub}</span> : null}
      </span>
    </span>
  );
}

export function EntriesPage() {
  const href = useAdminHref();
  const navigate = useNavigate();
  const location = useLocation();
  const [params, setParams] = useSearchParams();
  const tab = (TABS.some((t) => t.id === params.get('status')) ? params.get('status') : 'inbox') as Tab;
  const formId = params.get('formId') ?? '';
  const channel = params.get('channel') ?? '';
  const source = params.get('source') ?? '';
  const page = Math.max(1, Number(params.get('page') ?? 1) || 1);
  const q = params.get('q') ?? '';

  const [forms, setForms] = useState<FormSummary[]>([]);
  const [list, setList] = useState<EntryList | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [draftQ, setDraftQ] = useState(q);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const setParam = (patch: Record<string, string | undefined>) => {
    const next = new URLSearchParams(params);
    for (const [k, v] of Object.entries(patch)) {
      if (v === undefined || v === '') next.delete(k);
      else next.set(k, v);
    }
    setParams(next, { replace: true });
  };

  const load = useCallback(async () => {
    try {
      const res = await api<EntryList>(`/api/forms/entries/list${buildQuery({ status: tab, formId, channel, source, page, q, perPage: 25 })}`);
      setList(res);
      setSelected(new Set());
    } catch (e) {
      setError(formsError(e));
    }
  }, [tab, formId, channel, source, page, q]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    api<{ items: FormSummary[] }>('/api/forms/lookup')
      .then((r) => setForms(r.items))
      .catch(() => {});
  }, []);

  useEffect(() => {
    const state = location.state as { notice?: string } | null;
    if (state?.notice) {
      setNotice(state.notice);
      navigate(`${location.pathname}${location.search}`, { replace: true, state: null });
    }
  }, [location, navigate]);

  const openEntry = (id: string) =>
    navigate(href(`forms/entries/${id}${formId ? `?formId=${encodeURIComponent(formId)}` : ''}`), { state: { from: location.search } });

  const act = async (ids: string[], status: EntryStatus | 'delete') => {
    if (!ids.length) return;
    if (status === 'delete') {
      const ok = await confirmDialog({
        title: ids.length === 1 ? 'Delete entry' : `Delete ${ids.length} entries`,
        message: 'Deleted entries and their uploaded files cannot be recovered.',
        confirmLabel: 'Delete',
        danger: true,
      });
      if (!ok) return;
    }
    setBusy(true);
    try {
      if (status === 'delete') await api('/api/forms/entries/delete', { method: 'POST', json: { ids } });
      else await api('/api/forms/entries/status', { method: 'POST', json: { ids, status } });
      setNotice(
        status === 'delete'
          ? `${ids.length === 1 ? 'Entry' : `${ids.length} entries`} deleted.`
          : status === 'trash'
            ? 'Moved to trash.'
            : status === 'spam'
              ? 'Marked as spam.'
              : status === 'unread'
                ? 'Marked as unread.'
                : 'Restored to the inbox.',
      );
      await load();
    } catch (e) {
      setError(formsError(e));
    } finally {
      setBusy(false);
    }
  };

  const submitSearch = (e: FormEvent) => {
    e.preventDefault();
    setParam({ q: draftQ.trim(), page: undefined });
  };

  const allChecked = useMemo(() => Boolean(list?.items.length) && list!.items.every((e) => selected.has(e.id)), [list, selected]);
  const toggleAll = () => setSelected(allChecked ? new Set() : new Set(list?.items.map((e) => e.id)));
  const toggle = (id: string) =>
    setSelected((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  const counts = list?.counts ?? { unread: 0, inbox: 0, spam: 0, trash: 0 };
  const countFor = (t: Tab) => (t === 'inbox' ? counts.inbox : t === 'unread' ? counts.unread : t === 'spam' ? counts.spam : counts.trash);
  const exportHref = formId ? apiUrl(`/api/forms/${formId}/entries/export${buildQuery({ status: tab })}`) : null;
  const summary = useMemo(() => summarizeSources(list?.sources ?? []), [list]);
  const filtered = Boolean(channel || source);
  const colCount = formId ? 5 : 6;

  return (
    <div className="wrap wrap--wide bk-fm">
      <PageHeader
        title="Entries"
        actions={
          exportHref ? (
            <a className="button" href={exportHref}>
              Export CSV
            </a>
          ) : null
        }
      />
      <p className="bk-muted">Everything visitors sent through your forms, with where each visitor came from. Pick a form to export its entries as CSV.</p>

      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <nav className="bk-tabs" aria-label="Entry status">
        {TABS.map((t) => (
          <button key={t.id} type="button" className={`bk-tabs__item${tab === t.id ? ' is-active' : ''}`} onClick={() => setParam({ status: t.id === 'inbox' ? undefined : t.id, page: undefined })}>
            {t.label}
            <span className="bk-tabs__count">{countFor(t.id)}</span>
          </button>
        ))}
      </nav>

      {summary.total > 0 ? (
        <section className="bk-panel bk-fm-sources" aria-label="Where entries come from">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Where entries come from</h2>
            <span className="bk-fm-head-meta">{filtered ? 'Showing one source · pick All to see everything' : 'Click a row to filter'}</span>
          </div>
          <div className="bk-fm-sources__grid">
            <div>
              <h3 className="bk-fm-sources__title">Channels</h3>
              <ul className="bk-fm-bars">
                <li>
                  <button type="button" className={`bk-fm-bar is-all${!channel ? ' is-active' : ''}`} onClick={() => setParam({ channel: undefined, source: undefined, page: undefined })} aria-pressed={!channel}>
                    <span className="bk-fm-bar__label">
                      <span className="bk-fm-srcicon bk-fm-srcicon--all" style={{ width: 18, height: 18 }} aria-hidden>
                        <SquaresFour size={12} weight="bold" />
                      </span>
                      All channels
                    </span>
                    <span className="bk-fm-bar__value">
                      {summary.total}
                      <em>100%</em>
                    </span>
                  </button>
                </li>
                {summary.channels.map((c) => {
                  const value = c.channel === 'none' ? 'none' : c.channel;
                  const active = channel === value && !source;
                  return (
                    <li key={c.channel}>
                      <button type="button" className={`bk-fm-bar${active ? ' is-active' : ''}`} onClick={() => setParam({ channel: active ? undefined : value, source: undefined, page: undefined })}>
                        <span className={`bk-fm-bar__fill is-${channelTone(c.channel === 'none' ? null : c.channel)}`} style={{ width: `${Math.max(3, (100 * c.count) / summary.total)}%` }} aria-hidden />
                        <span className="bk-fm-bar__label">
                          <SourceIcon channel={c.channel === 'none' ? null : c.channel} source={null} size={18} />
                          {c.channel === 'none' ? NOT_RECORDED : c.channel}
                        </span>
                        <span className="bk-fm-bar__value">
                          {c.count}
                          <em>{Math.round((100 * c.count) / summary.total)}%</em>
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
            <div>
              <h3 className="bk-fm-sources__title">Top sources</h3>
              {summary.sources.length ? (
                <ul className="bk-fm-bars">
                <li>
                  <button type="button" className={`bk-fm-bar is-all${!source && !channel ? ' is-active' : ''}`} onClick={() => setParam({ channel: undefined, source: undefined, page: undefined })} aria-pressed={!source && !channel}>
                    <span className="bk-fm-bar__label">
                      <span className="bk-fm-srcicon bk-fm-srcicon--all" style={{ width: 18, height: 18 }} aria-hidden>
                        <SquaresFour size={12} weight="bold" />
                      </span>
                      All sources
                    </span>
                    <span className="bk-fm-bar__value">
                      {summary.total}
                      <em>100%</em>
                    </span>
                  </button>
                </li>
                  {summary.sources.map((s) => {
                    const active = channel === s.channel && source === s.source;
                    return (
                      <li key={`${s.channel}|${s.source}`}>
                        <button type="button" className={`bk-fm-bar${active ? ' is-active' : ''}`} onClick={() => setParam({ channel: active ? undefined : s.channel ?? undefined, source: active ? undefined : s.source ?? undefined, page: undefined })}>
                          <span className={`bk-fm-bar__fill is-${channelTone(s.channel)}`} style={{ width: `${Math.max(3, (100 * s.count) / summary.total)}%` }} aria-hidden />
                          <span className="bk-fm-bar__label">
                            <SourceIcon channel={s.channel} source={s.source} size={18} />
                            {s.source}
                            {s.source !== s.channel ? <small>{s.channel}</small> : null}
                          </span>
                          <span className="bk-fm-bar__value">{s.count}</span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <p className="bk-fm-sources__empty">Sources appear here as new entries arrive.</p>
              )}
            </div>
          </div>
        </section>
      ) : null}

      <form className="bk-fm-toolbar" onSubmit={submitSearch}>
        <select value={formId} onChange={(e) => setParam({ formId: e.target.value, page: undefined })} aria-label="Form">
          <option value="">All forms</option>
          {forms.map((f) => (
            <option key={f.id} value={f.id}>
              {f.title}
            </option>
          ))}
        </select>
        <input type="search" className="regular-text" placeholder="Search entries…" value={draftQ} onChange={(e) => setDraftQ(e.target.value)} aria-label="Search entries" />
        <button type="submit" className="button">
          Search
        </button>
        {filtered ? (
          <span className="bk-fm-chip">
            {source ? `${source} · ${channel}` : channel === 'none' ? NOT_RECORDED : channel}
            <button type="button" aria-label="Remove source filter" onClick={() => setParam({ channel: undefined, source: undefined, page: undefined })}>
              ×
            </button>
          </span>
        ) : null}
        {selected.size ? (
          <div className="bk-fm-bulk">
            <span>{selected.size} selected</span>
            {tab === 'inbox' || tab === 'unread' ? (
              <>
                <button type="button" className="button-link" disabled={busy} onClick={() => void act([...selected], 'read')}>Mark read</button>
                <button type="button" className="button-link" disabled={busy} onClick={() => void act([...selected], 'unread')}>Mark unread</button>
                <button type="button" className="button-link" disabled={busy} onClick={() => void act([...selected], 'spam')}>Spam</button>
                <button type="button" className="button-link" disabled={busy} onClick={() => void act([...selected], 'trash')}>Trash</button>
              </>
            ) : (
              <>
                <button type="button" className="button-link" disabled={busy} onClick={() => void act([...selected], 'read')}>Restore</button>
                <button type="button" className="button-link is-danger" disabled={busy} onClick={() => void act([...selected], 'delete')}>Delete forever</button>
              </>
            )}
          </div>
        ) : (
          <span className="bk-fm-toolbar__count">{list ? `${list.total} ${list.total === 1 ? 'entry' : 'entries'}` : ''}</span>
        )}
      </form>

      <div className="bk-fm-table-wrap">
        <table className="bk-fm-table bk-fm-table--entries">
          <thead>
            <tr>
              <th className="is-check">
                <input type="checkbox" checked={allChecked} onChange={toggleAll} aria-label="Select all" disabled={!list?.items.length} />
              </th>
              <th>Entry</th>
              {!formId ? <th>Form</th> : null}
              <th>Source</th>
              <th>Country</th>
              <th>Received</th>
            </tr>
          </thead>
          <tbody>
            {!list ? (
              <tr>
                <td colSpan={colCount} className="bk-fm-table__empty">Loading…</td>
              </tr>
            ) : list.items.length === 0 ? (
              <tr>
                <td colSpan={colCount} className="bk-fm-table__empty">
                  {q ? `No entries match “${q}”.` : filtered ? 'No entries from this source here.' : tab === 'inbox' ? 'No entries yet. They appear here as soon as someone sends a form.' : `Nothing in ${tab}.`}
                </td>
              </tr>
            ) : (
              list.items.map((e) => {
                const visit = e.meta.attribution?.visit ?? null;
                return (
                  <tr
                    key={e.id}
                    className={`is-clickable${e.status === 'unread' ? ' is-unread' : ''}`}
                    onClick={() => openEntry(e.id)}
                    tabIndex={0}
                    onKeyDown={(ev) => ev.key === 'Enter' && openEntry(e.id)}
                  >
                    <td className="is-check" onClick={(ev) => ev.stopPropagation()}>
                      <input type="checkbox" checked={selected.has(e.id)} onChange={() => toggle(e.id)} aria-label="Select entry" />
                    </td>
                    <td>
                      <span className="bk-fm-table__primary">{e.summary || '(no text answers)'}</span>
                    </td>
                    {!formId ? <td className="bk-fm-table__muted">{e.formTitle}</td> : null}
                    <td>
                      <SourceBadge channel={visit?.channel} source={visit?.source} campaign={visit?.campaign} />
                    </td>
                    <td className="bk-fm-table__muted">{e.meta.country ? `${flagEmoji(e.meta.country)} ${countryName(e.meta.country)}` : '—'}</td>
                    <td className="bk-fm-table__muted">{formatDate(e.createdAt)}</td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
        {list && list.pages > 1 ? (
          <div className="bk-fm-pager">
            <span>
              Page {list.page} of {list.pages}
            </span>
            <div>
              <button type="button" className="button" disabled={page <= 1} onClick={() => setParam({ page: String(page - 1) })}>‹ Previous</button>
              <button type="button" className="button" disabled={page >= list.pages} onClick={() => setParam({ page: String(page + 1) })}>Next ›</button>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
