/**
 * Bee Forms — admin API types and helpers. Mirrors apps/api/src/lib/forms/schema.ts and
 * services/forms/*.service.ts response shapes.
 */
import type { ComponentType } from 'react';
import {
  At,
  Calendar,
  CaretCircleDown,
  CheckSquare,
  Envelope,
  EyeSlash,
  File,
  Hash,
  Link,
  ListChecks,
  Paperclip,
  Phone,
  RadioButton,
  ShieldCheck,
  TextAa,
  TextAlignLeft,
  TextT,
  type IconProps,
} from '@phosphor-icons/react';
import { ApiError } from '../../api/client';

export function formsError(e: unknown): string {
  if (e instanceof ApiError) {
    const body = e.body as { message?: unknown } | undefined;
    if (Array.isArray(body?.message)) return (body!.message as unknown[]).map(String).join(' ');
    return e.message;
  }
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

export function formatDate(iso: string | null | undefined, withTime = true): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return withTime
    ? d.toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
    : d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

export function buildQuery(params: Record<string, string | number | undefined | null>): string {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && String(v) !== '') qs.set(k, String(v));
  }
  const s = qs.toString();
  return s ? `?${s}` : '';
}

/* ── Definition ─────────────────────────────────────────────────────── */

export type FormFieldType =
  | 'text' | 'email' | 'phone' | 'url' | 'textarea' | 'number' | 'select' | 'checkbox' | 'radio'
  | 'date' | 'hidden' | 'file' | 'consent' | 'section' | 'page';

export type FormFieldWidth = 'full' | 'half' | 'third';
export type ConditionOp = 'is' | 'is_not' | 'contains' | 'not_contains' | 'empty' | 'not_empty' | 'gt' | 'lt';
export type FileAcceptKind = 'image' | 'pdf' | 'document' | 'spreadsheet' | 'archive' | 'any';

export type ConditionRule = { field: string; op: ConditionOp; value: string };
export type FieldCondition = { action: 'show' | 'hide'; match: 'all' | 'any'; rules: ConditionRule[] };
export type FormChoice = { label: string; value: string };

export type FormField = {
  id: string;
  type: FormFieldType;
  label: string;
  name: string;
  placeholder?: string;
  help?: string;
  required?: boolean;
  defaultValue?: string;
  width: FormFieldWidth;
  options?: FormChoice[];
  multiple?: boolean;
  rows?: number;
  min?: string;
  max?: string;
  accept?: FileAcceptKind[];
  maxFiles?: number;
  text?: string;
  hiddenSource?: 'static' | 'page_url' | 'page_title' | 'referrer';
  hideLabel?: boolean;
  conditional?: FieldCondition;
};

export type FormConfirmation = { type: 'message'; message: string } | { type: 'redirect'; url: string };

export type FormSettings = {
  submitLabel: string;
  confirmation: FormConfirmation;
  notification: { enabled: boolean; to: string; subject: string; message: string; replyToField: string };
  autoReply: { enabled: boolean; toField: string; subject: string; message: string };
  progress: 'bar' | 'steps' | 'none';
  storeEntries: boolean;
  minSeconds: number;
  nextLabel: string;
  backLabel: string;
  integrations: { hubspot: HubspotFeed };
};

/* ── CRM integrations (mirrors apps/api/src/lib/forms/integrations.ts) ── */

export type MetaSource =
  | 'channel' | 'source' | 'campaign' | 'medium' | 'term' | 'content' | 'click_id' | 'landing_page' | 'referrer'
  | 'first_channel' | 'first_source' | 'first_campaign' | 'page_url' | 'country' | 'device' | 'form_title' | 'entry_id' | 'submitted_at';

export const META_SOURCE_LABELS: Record<MetaSource, string> = {
  channel: 'Channel (e.g. Paid social)',
  source: 'Source (e.g. LinkedIn Ads)',
  campaign: 'Campaign (utm_campaign)',
  medium: 'Medium (utm_medium)',
  term: 'Keyword (utm_term)',
  content: 'Ad content (utm_content)',
  click_id: 'Ad click type (gclid, li_fat_id…)',
  landing_page: 'Landing page',
  referrer: 'Came from (referrer)',
  first_channel: 'First visit: channel',
  first_source: 'First visit: source',
  first_campaign: 'First visit: campaign',
  page_url: 'Page the form was sent from',
  country: 'Country code',
  device: 'Device',
  form_title: 'Form title',
  entry_id: 'Entry ID',
  submitted_at: 'Date sent',
};

export type MappingSource =
  | { kind: 'field'; field: string; part?: 'first' | 'last' }
  | { kind: 'meta'; key: MetaSource }
  | { kind: 'static'; value: string };

export type MappingRow = { property: string; source: MappingSource };

export type HubspotFeed = { enabled: boolean; mapping: MappingRow[]; consentField: string; addNote: boolean };

export type HubspotProperty = {
  name: string;
  label: string;
  type: string;
  fieldType: string;
  groupName?: string;
  options?: { label: string; value: string }[];
  readOnly?: boolean;
};

export type IntegrationProviderInfo = {
  id: 'hubspot' | 'brevo' | 'mailchimp' | 'salesforce';
  name: string;
  status: 'available' | 'coming-soon';
  connected: boolean;
  health: 'connected' | 'error' | null;
  lastError: string;
  tokenHint: string;
  account: { portalId: number | null; uiDomain: string; timeZone: string; dataHostingLocation: string } | null;
  connectedAt: string | null;
  /** A token is saved but can't be decrypted (server secret changed): paste it again. */
  unreadable?: boolean;
};

export type IntegrationsInfo = { scopes: string[]; keysPersist?: boolean; providers: IntegrationProviderInfo[] };

export type HubspotSyncState = {
  status: 'pending' | 'synced' | 'failed' | 'skipped';
  attempts: number;
  nextAt: string | null;
  contactId: string;
  contactUrl: string;
  created: boolean;
  error: string;
  warnings: string[];
  syncedAt: string | null;
  updatedAt: string;
};

/** Same suggestions as the API (suggestHubspotMapping), so enabling HubSpot starts pre-filled. */
export function suggestHubspotMapping(fields: FormField[]): MappingRow[] {
  const rows: MappingRow[] = [];
  const add = (property: string, source: MappingSource) => {
    if (!rows.some((r) => r.property === property)) rows.push({ property, source });
  };
  const by = (re: RegExp, types?: FormFieldType[]) => fields.find((f) => (!types || types.includes(f.type)) && (re.test(f.name) || re.test(f.label.toLowerCase())));
  const email = fields.find((f) => f.type === 'email');
  if (email) add('email', { kind: 'field', field: email.name });
  const first = by(/^(first[_ ]?name|firstname|given)/);
  const last = by(/^(last[_ ]?name|lastname|surname|family)/);
  const full = by(/^(name|full[_ ]?name|your[_ ]?name)$/);
  if (first) add('firstname', { kind: 'field', field: first.name });
  if (last) add('lastname', { kind: 'field', field: last.name });
  if (!first && !last && full) {
    add('firstname', { kind: 'field', field: full.name, part: 'first' });
    add('lastname', { kind: 'field', field: full.name, part: 'last' });
  }
  const phone = fields.find((f) => f.type === 'phone') ?? by(/phone|mobile|tel/);
  if (phone) add('phone', { kind: 'field', field: phone.name });
  const company = by(/company|organi[sz]ation|business/);
  if (company) add('company', { kind: 'field', field: company.name });
  const site = fields.find((f) => f.type === 'url') ?? by(/website|site|url/);
  if (site) add('website', { kind: 'field', field: site.name });
  const job = by(/job|title|position|role/, ['text', 'select', 'radio']);
  if (job) add('jobtitle', { kind: 'field', field: job.name });
  const message = fields.find((f) => f.type === 'textarea') ?? by(/message|comment|enquiry|inquiry/);
  if (message) add('message', { kind: 'field', field: message.name });
  add('lifecyclestage', { kind: 'static', value: 'lead' });
  return rows;
}

export type FormSummary = {
  id: string;
  title: string;
  status: 'active' | 'inactive';
  fieldCount: number;
  entryCount: number;
  unreadCount: number;
  lastEntryAt: string | null;
  createdAt: string;
  updatedAt: string;
};

export type FormDetail = FormSummary & { fields: FormField[]; settings: FormSettings };

export type EntryStatus = 'unread' | 'read' | 'spam' | 'trash';

export type EntryAnswer = { fieldId: string; name: string; label: string; type: string; value: unknown; text: string };

/** Where a visit came from (mirrors apps/api/src/lib/forms/attribution.ts). */
export type Attribution = {
  channel: string;
  source: string;
  medium: string;
  campaign: string;
  term: string;
  content: string;
  clickId: string;
  landingPage: string;
  referrer: string;
  referrerHost: string;
  at: string | null;
};

export type EntryMeta = {
  ip?: string;
  userAgent?: string;
  pageUrl?: string;
  pageTitle?: string;
  referrer?: string;
  fillSeconds?: number;
  attribution?: { visit: Attribution | null; first: Attribution | null };
  country?: string;
  device?: string;
  browser?: string;
  os?: string;
  language?: string;
  timeZone?: string;
  screen?: string;
  viewport?: string;
  pagesViewed?: number | null;
  timeOnSiteSeconds?: number | null;
  integrations?: { hubspot?: HubspotSyncState };
};

export type Entry = {
  id: string;
  formId: string;
  formTitle: string;
  status: EntryStatus;
  summary: string;
  answers: EntryAnswer[];
  meta: EntryMeta;
  createdAt: string;
};

export type EntryDetail = Entry & { newerId: string | null; olderId: string | null };

export type SourceCount = { channel: string | null; source: string | null; count: number };

export type EntryList = {
  items: Entry[];
  total: number;
  page: number;
  perPage: number;
  pages: number;
  counts: { unread: number; inbox: number; spam: number; trash: number };
  sources: SourceCount[];
};

/* ── Source / visitor display ────────────────────────────────────────── */

export function flagEmoji(code: string | undefined): string {
  if (!code || !/^[A-Z]{2}$/.test(code)) return '';
  return String.fromCodePoint(...[...code].map((c) => 0x1f1e6 + c.charCodeAt(0) - 65));
}

export function countryName(code: string | undefined): string {
  if (!code) return '';
  try {
    return new Intl.DisplayNames(['en'], { type: 'region' }).of(code) || code;
  } catch {
    return code;
  }
}

/** Pill tone per channel: paid = blue, earned = green, the rest neutral. */
export function channelTone(channel: string | null | undefined): 'paid' | 'earned' | 'neutral' | 'muted' {
  if (!channel) return 'muted';
  if (/^Paid|Display/.test(channel)) return 'paid';
  if (channel === 'Organic search' || channel === 'Social' || channel === 'Email' || channel === 'Referral') return 'earned';
  if (channel === 'Direct') return 'muted';
  return 'neutral';
}

export const CLICK_ID_NAMES: Record<string, string> = {
  gclid: 'Google Ads click (gclid)',
  gbraid: 'Google Ads click (gbraid)',
  wbraid: 'Google Ads click (wbraid)',
  dclid: 'Google Display click (dclid)',
  msclkid: 'Microsoft Ads click (msclkid)',
  li_fat_id: 'LinkedIn Ads click (li_fat_id)',
  ttclid: 'TikTok Ads click (ttclid)',
  twclid: 'X Ads click (twclid)',
  epik: 'Pinterest Ads click (epik)',
  sccid: 'Snapchat Ads click (sccid)',
  fbclid: 'Facebook / Instagram link (fbclid)',
};

export function duration(seconds: number | null | undefined): string {
  if (seconds == null || !Number.isFinite(seconds)) return '';
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  if (m < 60) return `${m}m ${seconds % 60}s`;
  const h = Math.floor(m / 60);
  if (h < 48) return `${h}h ${m % 60}m`;
  return `${Math.floor(h / 24)} days`;
}

export const DEVICE_LABEL: Record<string, string> = { desktop: 'Desktop', mobile: 'Mobile', tablet: 'Tablet', unknown: 'Unknown' };

export type StoredFile = { id: string; name: string; mime: string; size: number };

export const isFileList = (v: unknown): v is StoredFile[] =>
  Array.isArray(v) && v.length > 0 && v.every((x) => x && typeof x === 'object' && typeof (x as StoredFile).id === 'string');

/* ── Field palette ───────────────────────────────────────────────────── */

type Icon = ComponentType<IconProps>;

export type FieldTypeMeta = {
  type: FormFieldType;
  label: string;
  hint: string;
  Icon: Icon;
  group: 'Standard' | 'Choices' | 'Advanced' | 'Layout';
};

export const FIELD_TYPES: FieldTypeMeta[] = [
  { type: 'text', label: 'Text', hint: 'Single line', Icon: TextT, group: 'Standard' },
  { type: 'email', label: 'Email', hint: 'Checked address', Icon: Envelope, group: 'Standard' },
  { type: 'phone', label: 'Phone', hint: 'Phone number', Icon: Phone, group: 'Standard' },
  { type: 'url', label: 'Website', hint: 'Web address', Icon: Link, group: 'Standard' },
  { type: 'textarea', label: 'Message', hint: 'Multiple lines', Icon: TextAlignLeft, group: 'Standard' },
  { type: 'number', label: 'Number', hint: 'Digits only', Icon: Hash, group: 'Standard' },
  { type: 'date', label: 'Date', hint: 'Date picker', Icon: Calendar, group: 'Standard' },
  { type: 'select', label: 'Dropdown', hint: 'Pick from a list', Icon: CaretCircleDown, group: 'Choices' },
  { type: 'radio', label: 'Choice', hint: 'Pick one', Icon: RadioButton, group: 'Choices' },
  { type: 'checkbox', label: 'Checkboxes', hint: 'Pick several', Icon: ListChecks, group: 'Choices' },
  { type: 'consent', label: 'Consent', hint: 'Must be ticked', Icon: ShieldCheck, group: 'Choices' },
  { type: 'file', label: 'File upload', hint: 'Attach files', Icon: Paperclip, group: 'Advanced' },
  { type: 'hidden', label: 'Hidden', hint: 'Not shown', Icon: EyeSlash, group: 'Advanced' },
  { type: 'section', label: 'Section', hint: 'Heading + text', Icon: TextAa, group: 'Layout' },
  { type: 'page', label: 'Page break', hint: 'Next step', Icon: File, group: 'Layout' },
];

export const FIELD_GROUPS: FieldTypeMeta['group'][] = ['Standard', 'Choices', 'Advanced', 'Layout'];

export const fieldMeta = (type: FormFieldType): FieldTypeMeta =>
  FIELD_TYPES.find((t) => t.type === type) ?? FIELD_TYPES[0];

export const NO_VALUE_TYPES = new Set<FormFieldType>(['section', 'page']);
export const CHOICE_TYPES = new Set<FormFieldType>(['select', 'radio', 'checkbox']);

export const CheckIcon = CheckSquare;
export const AtIcon = At;

export function randomId(): string {
  return Math.random().toString(36).slice(2, 10);
}

export function nameFromLabel(label: string): string {
  return label
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 60);
}

/** Unique snake_case key among the other fields. */
export function uniqueName(base: string, fields: FormField[], excludeId: string): string {
  const taken = new Set(fields.filter((f) => f.id !== excludeId).map((f) => f.name));
  let name = base || 'field';
  let n = 2;
  while (taken.has(name)) name = `${base || 'field'}_${n++}`;
  return name;
}

export function newField(type: FormFieldType, fields: FormField[]): FormField {
  const meta = fieldMeta(type);
  const label = type === 'page' ? `Step ${fields.filter((f) => f.type === 'page').length + 2}` : meta.label;
  const id = randomId();
  const f: FormField = { id, type, label, name: uniqueName(nameFromLabel(label), fields, id), width: 'full' };
  if (CHOICE_TYPES.has(type)) f.options = [{ label: 'Option 1', value: 'Option 1' }, { label: 'Option 2', value: 'Option 2' }];
  if (type === 'textarea') f.rows = 5;
  if (type === 'file') {
    f.accept = ['any'];
    f.maxFiles = 1;
  }
  if (type === 'consent') {
    f.text = 'I agree to the privacy policy.';
    f.required = true;
  }
  if (type === 'hidden') f.hiddenSource = 'page_url';
  if (type === 'email' || type === 'text' || type === 'textarea') f.required = true;
  return f;
}

export const MERGE_TAGS: { tag: string; label: string }[] = [
  { tag: '{all_fields}', label: 'All answers' },
  { tag: '{form_title}', label: 'Form title' },
  { tag: '{site_title}', label: 'Site title' },
  { tag: '{entry_id}', label: 'Entry ID' },
  { tag: '{date}', label: 'Date and time' },
  { tag: '{page_url}', label: 'Page the form was on' },
  { tag: '{admin_email}', label: 'Site owner email' },
];
