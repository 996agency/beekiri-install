import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Trash } from '@phosphor-icons/react';
import { api } from '../../api/client';
import { useAdminHref } from '../../lib/AdminEntryContext';
import {
  META_SOURCE_LABELS,
  NO_VALUE_TYPES,
  formsError,
  suggestHubspotMapping,
  type FormField,
  type HubspotFeed,
  type HubspotProperty,
  type IntegrationsInfo,
  type MappingRow,
  type MappingSource,
  type MetaSource,
} from './api';
import { BrandLogo } from './BrandLogo';

function encodeSource(s: MappingSource): string {
  if (s.kind === 'field') return `field:${s.field}${s.part ? `:${s.part}` : ''}`;
  if (s.kind === 'meta') return `meta:${s.key}`;
  return 'static';
}

function decodeSource(v: string, prev: MappingSource): MappingSource {
  const [kind, a, b] = v.split(':');
  if (kind === 'field') return b === 'first' || b === 'last' ? { kind: 'field', field: a, part: b } : { kind: 'field', field: a };
  if (kind === 'meta') return { kind: 'meta', key: a as MetaSource };
  return { kind: 'static', value: prev.kind === 'static' ? prev.value : '' };
}

const SOON = [
  { id: 'brevo', name: 'Brevo' },
  { id: 'mailchimp', name: 'Mailchimp' },
  { id: 'salesforce', name: 'Salesforce' },
];

export function FormIntegrationsTab({ fields, feed, onChange }: { fields: FormField[]; feed: HubspotFeed; onChange: (feed: HubspotFeed) => void }) {
  const href = useAdminHref();
  const [info, setInfo] = useState<IntegrationsInfo | null>(null);
  const [props, setProps] = useState<HubspotProperty[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const hubspot = info?.providers.find((p) => p.id === 'hubspot');
  const connected = Boolean(hubspot?.connected);

  useEffect(() => {
    api<IntegrationsInfo>('/api/forms/integrations')
      .then(setInfo)
      .catch((e) => setError(formsError(e)));
  }, []);

  const loadProps = (refresh = false) => {
    setError(null);
    api<{ items: HubspotProperty[] }>(`/api/forms/integrations/hubspot/properties${refresh ? '?refresh=1' : ''}`)
      .then((r) => setProps(r.items))
      .catch((e) => setError(formsError(e)));
  };
  useEffect(() => {
    if (connected) loadProps();
  }, [connected]);

  const valueFields = fields.filter((f) => !NO_VALUE_TYPES.has(f.type));
  const emailFields = valueFields.filter((f) => f.type === 'email');
  const consentFields = valueFields.filter((f) => f.type === 'consent' || f.type === 'checkbox');
  const byName = useMemo(() => new Map((props ?? []).map((p) => [p.name, p])), [props]);
  const groups = useMemo(() => {
    const m = new Map<string, HubspotProperty[]>();
    for (const p of props ?? []) {
      if (p.readOnly) continue;
      const g = (p.groupName || 'other').replace(/_/g, ' ');
      if (!m.has(g)) m.set(g, []);
      m.get(g)!.push(p);
    }
    for (const list of m.values()) list.sort((a, b) => a.label.localeCompare(b.label));
    return [...m.entries()].sort(([a], [b]) => (a === 'contactinformation' ? -1 : b === 'contactinformation' ? 1 : a.localeCompare(b)));
  }, [props]);

  const set = (patch: Partial<HubspotFeed>) => onChange({ ...feed, ...patch });
  const setRow = (i: number, row: MappingRow) => set({ mapping: feed.mapping.map((r, k) => (k === i ? row : r)) });
  const removeRow = (i: number) => set({ mapping: feed.mapping.filter((_, k) => k !== i) });
  const addRow = () => {
    const used = new Set(feed.mapping.map((r) => r.property));
    const next = (props ?? []).find((p) => !p.readOnly && !used.has(p.name));
    set({ mapping: [...feed.mapping, { property: next?.name ?? '', source: valueFields[0] ? { kind: 'field', field: valueFields[0].name } : { kind: 'static', value: '' } }] });
  };

  const enable = (on: boolean) => {
    if (on && !feed.mapping.length) set({ enabled: true, mapping: suggestHubspotMapping(fields) });
    else set({ enabled: on });
  };

  const emailRow = feed.mapping.find((r) => r.property === 'email');
  const problems: string[] = [];
  if (feed.enabled) {
    if (!emailFields.length) problems.push('Add an Email field to the form. HubSpot needs an email address to create the contact.');
    else if (!emailRow || emailRow.source.kind !== 'field') problems.push('Map the HubSpot “Email” property to the form’s Email field.');
    for (const r of feed.mapping) {
      if (!r.property) problems.push('A row has no HubSpot property chosen.');
      else if (props && !byName.has(r.property)) problems.push(`“${r.property}” is not a contact property in your HubSpot account any more.`);
      if (r.source.kind === 'field' && !valueFields.some((f) => f.name === (r.source as { field: string }).field)) problems.push(`The field used for “${byName.get(r.property)?.label ?? r.property}” was removed from the form.`);
    }
  }

  return (
    <div className="bk-fm-settings">
      {error ? <p className="beekiri-notice is-error bk-fm-notice">{error}</p> : null}

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title bk-fm-int__paneltitle">
            <BrandLogo id="hubspot" size={22} />
            HubSpot
          </h2>
          {connected ? (
            <label className="bk-fm-status">
              <span>{feed.enabled ? 'Sending entries' : 'Off'}</span>
              <span className="bk-fm-switch">
                <input type="checkbox" role="switch" checked={feed.enabled} onChange={(e) => enable(e.target.checked)} aria-label="Send entries to HubSpot" />
                <span className="bk-fm-switch__track" aria-hidden>
                  <span className="bk-fm-switch__knob" />
                </span>
              </span>
            </label>
          ) : null}
        </div>

        {!info ? (
          <div className="bk-panel__body">
            <p className="bk-muted">Loading…</p>
          </div>
        ) : !connected ? (
          <div className="bk-panel__body bk-fm-int__empty">
            <p>
              {hubspot?.unreadable
                ? 'HubSpot needs to be reconnected: paste the token again under Forms → Integrations. This form’s mapping below is kept.'
                : 'Connect your HubSpot account first. It takes about two minutes and works with every HubSpot plan, including the free one.'}
            </p>
            <Link className="button button-primary" to={href('forms/integrations')}>
              {hubspot?.unreadable ? 'Reconnect HubSpot' : 'Connect HubSpot'}
            </Link>
          </div>
        ) : !feed.enabled ? (
          <div className="bk-panel__body bk-fm-int__empty">
            <p>Turn this on to create or update a HubSpot contact for every entry of this form. We’ll suggest which fields go where; you can change everything.</p>
          </div>
        ) : (
          <>
            {problems.length ? (
              <ul className="beekiri-notice is-error bk-fm-problems">
                {problems.map((p) => (
                  <li key={p}>{p}</li>
                ))}
              </ul>
            ) : null}
            <div className="bk-fm-map">
              <div className="bk-fm-map__head">
                <span>HubSpot contact property</span>
                <span aria-hidden />
                <span>Value from this form</span>
                <span aria-hidden />
              </div>
              {feed.mapping.map((row, i) => {
                const prop = byName.get(row.property);
                const isEmail = row.property === 'email';
                const options = prop?.type === 'enumeration' && prop.options?.length ? prop.options : null;
                return (
                  <div key={i} className="bk-fm-map__row">
                    <select
                      value={row.property}
                      disabled={isEmail}
                      onChange={(e) => setRow(i, { ...row, property: e.target.value, source: row.source.kind === 'static' ? { kind: 'static', value: '' } : row.source })}
                      aria-label="HubSpot property"
                    >
                      {!props ? <option value={row.property}>{row.property || 'Loading…'}</option> : null}
                      {row.property && props && !byName.has(row.property) ? <option value={row.property}>{row.property} (missing)</option> : null}
                      {!row.property ? <option value="">Choose a property…</option> : null}
                      {groups.map(([g, list]) => (
                        <optgroup key={g} label={g === 'contactinformation' ? 'Contact information' : g}>
                          {list
                            .filter((p) => p.name === row.property || !feed.mapping.some((r) => r.property === p.name) || false)
                            .filter((p) => p.name !== 'email' || isEmail)
                            .map((p) => (
                              <option key={p.name} value={p.name}>
                                {p.label}
                              </option>
                            ))}
                        </optgroup>
                      ))}
                    </select>
                    <span className="bk-fm-map__arrow" aria-hidden>
                      ←
                    </span>
                    <div className="bk-fm-map__source">
                      <select value={encodeSource(row.source)} onChange={(e) => setRow(i, { ...row, source: decodeSource(e.target.value, row.source) })} aria-label="Value">
                        <optgroup label="Form fields">
                          {(isEmail ? emailFields : valueFields).map((f) => (
                            <option key={f.id} value={`field:${f.name}`}>
                              {f.label}
                            </option>
                          ))}
                          {!isEmail
                            ? valueFields
                                .filter((f) => f.type === 'text')
                                .flatMap((f) => [
                                  <option key={`${f.id}-first`} value={`field:${f.name}:first`}>
                                    {f.label} — first word
                                  </option>,
                                  <option key={`${f.id}-last`} value={`field:${f.name}:last`}>
                                    {f.label} — the rest
                                  </option>,
                                ])
                            : null}
                        </optgroup>
                        {!isEmail ? (
                          <>
                            <optgroup label="Where the visitor came from">
                              {(Object.keys(META_SOURCE_LABELS) as MetaSource[]).map((k) => (
                                <option key={k} value={`meta:${k}`}>
                                  {META_SOURCE_LABELS[k]}
                                </option>
                              ))}
                            </optgroup>
                            <optgroup label="Other">
                              <option value="static">Fixed value…</option>
                            </optgroup>
                          </>
                        ) : null}
                      </select>
                      {row.source.kind === 'static' ? (
                        options ? (
                          <select value={row.source.value} onChange={(e) => setRow(i, { ...row, source: { kind: 'static', value: e.target.value } })} aria-label="Fixed value">
                            <option value="">Choose…</option>
                            {options.map((o) => (
                              <option key={o.value} value={o.value}>
                                {o.label}
                              </option>
                            ))}
                          </select>
                        ) : (
                          <input type="text" value={row.source.value} placeholder="Fixed text" onChange={(e) => setRow(i, { ...row, source: { kind: 'static', value: e.target.value } })} aria-label="Fixed value" />
                        )
                      ) : null}
                    </div>
                    {isEmail ? (
                      <span className="bk-fm-map__lock" title="Required: HubSpot finds the contact by email">
                        Required
                      </span>
                    ) : (
                      <button type="button" className="bk-fm-map__remove" onClick={() => removeRow(i)} aria-label="Remove row" title="Remove">
                        <Trash size={14} aria-hidden />
                      </button>
                    )}
                  </div>
                );
              })}
              <div className="bk-fm-map__foot">
                <button type="button" className="button" onClick={addRow} disabled={!props}>
                  <Plus size={13} aria-hidden /> Add a property
                </button>
                <button type="button" className="button-link" onClick={() => set({ mapping: suggestHubspotMapping(fields) })}>
                  Reset to suggested
                </button>
                <button type="button" className="button-link" onClick={() => loadProps(true)}>
                  Reload HubSpot properties
                </button>
              </div>
            </div>

            <div className="bk-panel__body bk-fm-rows bk-fm-rows--flush">
              <div className="bk-fm-row is-inline">
                <div className="bk-fm-row__text">
                  <span className="bk-fm-row__label">Only send when</span>
                  <span className="bk-fm-row__hint">For marketing consent: entries where this box is not ticked stay in Beekiri only.</span>
                </div>
                <div className="bk-fm-row__control">
                  <select value={feed.consentField} onChange={(e) => set({ consentField: e.target.value })}>
                    <option value="">Always send</option>
                    {consentFields.map((f) => (
                      <option key={f.id} value={f.name}>
                        “{f.label}” is ticked
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="bk-fm-row is-inline">
                <div className="bk-fm-row__text">
                  <span className="bk-fm-row__label">Add the entry as a note</span>
                  <span className="bk-fm-row__hint">Every answer, the source and the page, on the contact’s timeline in HubSpot.</span>
                </div>
                <div className="bk-fm-row__control">
                  <label className="bk-fm-switch">
                    <input type="checkbox" role="switch" checked={feed.addNote} onChange={(e) => set({ addNote: e.target.checked })} aria-label="Add a note" />
                    <span className="bk-fm-switch__track" aria-hidden>
                      <span className="bk-fm-switch__knob" />
                    </span>
                  </label>
                </div>
              </div>
            </div>
            <p className="bk-fm-int__hint bk-fm-int__hint--pad">
              Contacts with the same email are updated, never duplicated. Values HubSpot can’t accept (e.g. an option that doesn’t exist there) are left out and noted on the entry; the rest is still saved. If HubSpot is unreachable, Beekiri retries automatically.
            </p>
          </>
        )}
      </div>

      <div className="bk-fm-int__soon is-compact">
        {SOON.map((p) => (
          <div key={p.id} className="bk-panel bk-fm-int is-soon">
            <div className="bk-fm-int__head">
              <BrandLogo id={p.id as 'brevo' | 'mailchimp' | 'salesforce'} size={28} />
              <div className="bk-fm-int__title">
                <h2>{p.name}</h2>
              </div>
              <span className="bk-fm-pill is-muted">Coming soon</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
