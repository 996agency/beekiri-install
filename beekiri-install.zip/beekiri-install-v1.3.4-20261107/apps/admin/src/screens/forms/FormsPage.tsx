import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { api } from '../../api/client';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { useAuth } from '../../auth/AuthContext';
import { useAdminHref } from '../../lib/AdminEntryContext';
import { invalidateFormsList } from '../../editor/beekiricode/inspector/AcfFieldInputs';
import { formatDate, formsError, type FormDetail, type FormSummary } from './api';
import './forms.css';

export function FormsPage() {
  const href = useAdminHref();
  const navigate = useNavigate();
  const location = useLocation();
  const auth = useAuth();
  const canEntries = auth.user?.capabilities.includes('view_form_entries') ?? false;
  const [items, setItems] = useState<FormSummary[] | null>(null);
  const [q, setQ] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      const res = await api<{ items: FormSummary[] }>('/api/forms');
      setItems(res.items);
    } catch (e) {
      setError(formsError(e));
      setItems([]);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  useEffect(() => {
    const state = location.state as { notice?: string } | null;
    if (state?.notice) {
      setNotice(state.notice);
      navigate(location.pathname, { replace: true, state: null });
    }
  }, [location, navigate]);

  const duplicate = async (f: FormSummary) => {
    setBusy(true);
    try {
      const copy = await api<FormDetail>(`/api/forms/${f.id}/duplicate`, { method: 'POST' });
      invalidateFormsList();
      setNotice(`“${f.title}” duplicated.`);
      await load();
      navigate(href(`forms/${copy.id}`));
    } catch (e) {
      setError(formsError(e));
    } finally {
      setBusy(false);
    }
  };

  const remove = async (f: FormSummary) => {
    const ok = await confirmDialog({
      title: 'Delete form',
      message: `Delete “${f.title}”${f.entryCount ? ` and its ${f.entryCount} ${f.entryCount === 1 ? 'entry' : 'entries'}` : ''}? Pages that show it will show nothing there. This cannot be undone.`,
      confirmLabel: 'Delete',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    try {
      await api(`/api/forms/${f.id}`, { method: 'DELETE' });
      invalidateFormsList();
      setNotice(`“${f.title}” deleted.`);
      await load();
    } catch (e) {
      setError(formsError(e));
    } finally {
      setBusy(false);
    }
  };

  const term = q.trim().toLowerCase();
  const visible = (items ?? []).filter((f) => !term || f.title.toLowerCase().includes(term));

  return (
    <div className="wrap wrap--wide bk-fm">
      <PageHeader
        title="Forms"
        actions={
          <Link className="button button-primary" to={href('forms/new')}>
            Add new form
          </Link>
        }
      />
      <p className="bk-muted">
        Build a form, then add it to any page with the <strong>Form</strong> element in the page editor, or let a theme layout pick one through a <strong>Form</strong> Backend Field.
      </p>

      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      {items && items.length > 0 ? (
        <div className="bk-fm-toolbar">
          <input type="search" className="regular-text" placeholder="Search forms…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search forms" />
          <span className="bk-fm-toolbar__count">
            {items.length} {items.length === 1 ? 'form' : 'forms'}
          </span>
        </div>
      ) : null}

      {!items ? (
        <p className="bk-muted">Loading…</p>
      ) : items.length === 0 ? (
        <div className="bk-fm-empty">
          <h2>Your first form</h2>
          <p>Start with a ready-made contact form (name, email, message) and change anything you like.</p>
          <Link className="button button-primary" to={href('forms/new')}>
            Create a form
          </Link>
        </div>
      ) : (
        <div className="bk-fm-table-wrap">
          <table className="bk-fm-table">
            <thead>
              <tr>
                <th>Form</th>
                <th>Fields</th>
                <th>Entries</th>
                <th>Status</th>
                <th>Last entry</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((f) => (
                <tr key={f.id}>
                  <td>
                    <Link className="bk-fm-table__primary" to={href(`forms/${f.id}`)}>
                      {f.title}
                    </Link>
                    <div className="bk-fm-table__actions">
                      <Link to={href(`forms/${f.id}`)}>Edit</Link>
                      {canEntries ? (
                        <>
                          <span className="sep">|</span>
                          <Link to={href(`forms/entries?formId=${f.id}`)}>Entries</Link>
                        </>
                      ) : null}
                      <span className="sep">|</span>
                      <button type="button" disabled={busy} onClick={() => void duplicate(f)}>
                        Duplicate
                      </button>
                      <span className="sep">|</span>
                      <button type="button" className="is-danger" disabled={busy} onClick={() => void remove(f)}>
                        Delete
                      </button>
                    </div>
                  </td>
                  <td>{f.fieldCount}</td>
                  <td>
                    {canEntries ? (
                      <Link className="bk-fm-table__count" to={href(`forms/entries?formId=${f.id}`)}>
                        {f.entryCount}
                        {f.unreadCount ? <span className="bk-fm-badge">{f.unreadCount} new</span> : null}
                      </Link>
                    ) : (
                      <span className="bk-fm-table__count">{f.entryCount}</span>
                    )}
                  </td>
                  <td>
                    <span className={`bk-fm-pill ${f.status === 'active' ? 'is-ok' : 'is-muted'}`}>{f.status === 'active' ? 'Active' : 'Inactive'}</span>
                  </td>
                  <td className="bk-fm-table__muted">{formatDate(f.lastEntryAt)}</td>
                </tr>
              ))}
              {visible.length === 0 ? (
                <tr>
                  <td colSpan={5} className="bk-fm-table__empty">
                    No forms match “{q.trim()}”.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
