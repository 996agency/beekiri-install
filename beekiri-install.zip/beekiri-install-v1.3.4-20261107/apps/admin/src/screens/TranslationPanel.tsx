import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowSquareOut,
  Check,
  Copy,
  MagnifyingGlass,
  Plus,
  Sparkle,
  Trash,
  X,
} from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { SITE_URL as LIVE } from '../config';
import './translation-panel.css';

type WorldLanguage = { code: string; name: string; native: string; rtl: boolean };

type Translations = {
  /** Original language the texts are written in (English by default). */
  defaultLanguage: string;
  /** Added language served on the plain address. */
  primaryLanguage: string;
  languages: string[];
  sources: string[];
  strings: Record<string, Record<string, string>>;
};

type TranslationsResponse = Translations & { catalog: WorldLanguage[] };

type LinkTarget = { id: string; label: string; path: string };
type LinkTargetsResponse = { system: LinkTarget[]; pages: LinkTarget[]; posts: LinkTarget[] };

type Filter = 'all' | 'missing' | 'done';

type Props = {
  onNotice: (message: string) => void;
  onError: (message: string | null) => void;
  /** Opens Settings → Permalinks (menu builder). */
  onOpenMenu: () => void;
};

/** Rows rendered per step while scrolling — keeps 1000+ texts fast. */
const RENDER_STEP = 100;
/** The auto-translate endpoint takes this many strings per call. */
const AUTO_BATCH = 10;
const AUTO_MAX_CHARS = 500;

const SHORTCODES = [
  { code: '[beekiri_language_switcher]', hint: 'Dropdown with native names (Deutsch, Shqip…)' },
  { code: '[beekiri_language_switcher style="list"]', hint: 'Inline links side by side' },
  { code: '[beekiri_language_switcher style="list" show="code"]', hint: 'Compact: EN · DE · SQ' },
  { code: '[beekiri_language_switcher show="both"]', hint: 'Deutsch (DE)' },
];

/** Same normalisation the website uses to match texts. */
const normalize = (text: string) => text.replace(/[\s ]+/g, ' ').trim();

const SKIP_SELECTOR =
  'script,style,noscript,template,svg,code,pre,kbd,samp,textarea,[translate="no"],.notranslate,.bk-admin-dock';

/** Visible texts of one rendered page — text nodes + the attributes people read. */
function collectTexts(doc: Document): string[] {
  const out: string[] = [];
  const root = doc.querySelector('.bk-shell') ?? doc.body;
  if (!root) return out;
  const keep = (raw: string | null | undefined) => {
    const text = normalize(raw ?? '');
    if (text.length < 2 || text.length > 2000 || !/\p{L}/u.test(text) || text === '{current}') return;
    out.push(text);
  };
  const walker = doc.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    if (node.parentElement?.closest(SKIP_SELECTOR)) continue;
    keep(node.nodeValue);
  }
  root.querySelectorAll('[title],[alt],[placeholder],[aria-label]').forEach((el) => {
    if (el.closest(SKIP_SELECTOR)) return;
    for (const attr of ['title', 'alt', 'placeholder', 'aria-label']) keep(el.getAttribute(attr));
  });
  keep(doc.querySelector('meta[name="description"]')?.getAttribute('content'));
  return out;
}

function sameJson(a: unknown, b: unknown) {
  return JSON.stringify(a) === JSON.stringify(b);
}

export function TranslationPanel({ onNotice, onError, onOpenMenu }: Props) {
  const [catalog, setCatalog] = useState<WorldLanguage[]>([]);
  const [data, setData] = useState<Translations | null>(null);
  const saved = useRef<Translations | null>(null);
  const [busy, setBusy] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [target, setTarget] = useState<string>('');
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [limit, setLimit] = useState(RENDER_STEP);
  const [newText, setNewText] = useState('');

  const [picker, setPicker] = useState('');
  const [pickerOpen, setPickerOpen] = useState(false);
  const pickerRef = useRef<HTMLDivElement>(null);

  const [scan, setScan] = useState<string | null>(null);
  const [auto, setAuto] = useState<{ done: number; total: number } | null>(null);
  const cancelAuto = useRef(false);
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    api<TranslationsResponse>('/api/site/translations')
      .then(({ catalog: list, ...rest }) => {
        const loaded = { ...rest, primaryLanguage: rest.primaryLanguage || rest.defaultLanguage };
        setCatalog(list);
        setData(loaded);
        saved.current = loaded;
      })
      .catch((e) => setLoadError(e instanceof ApiError ? e.message : 'Could not load translations.'));
  }, []);

  useEffect(() => {
    if (!pickerOpen) return;
    const close = (e: MouseEvent) => {
      if (!pickerRef.current?.contains(e.target as Node)) setPickerOpen(false);
    };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [pickerOpen]);

  const byCode = useMemo(() => new Map(catalog.map((l) => [l.code, l])), [catalog]);
  const dirty = Boolean(data && saved.current && !sameJson(data, saved.current));

  // Leaving with unsaved translations asks first.
  useEffect(() => {
    if (!dirty) return;
    const warn = (e: BeforeUnloadEvent) => e.preventDefault();
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [dirty]);

  const extra = data ? data.languages.filter((c) => c !== data.defaultLanguage) : [];
  const activeTarget = extra.includes(target) ? target : (extra[0] ?? '');

  /** Every text with a row: collected sources plus anything translated by hand. */
  const rows = useMemo(() => {
    if (!data) return [];
    const list = [...data.sources];
    const seen = new Set(list);
    for (const src of Object.keys(data.strings[activeTarget] ?? {})) {
      if (!seen.has(src)) {
        seen.add(src);
        list.push(src);
      }
    }
    return list;
  }, [data, activeTarget]);

  const progress = (code: string) => {
    if (!data) return { done: 0, total: 0 };
    const map = data.strings[code] ?? {};
    const all = new Set([...data.sources, ...Object.keys(map)]);
    let done = 0;
    all.forEach((s) => {
      if (map[s]?.trim()) done++;
    });
    return { done, total: all.size };
  };

  const visible = useMemo(() => {
    const map = data?.strings[activeTarget] ?? {};
    const q = query.trim().toLowerCase();
    return rows.filter((src) => {
      const tr = map[src] ?? '';
      if (filter === 'missing' && tr.trim()) return false;
      if (filter === 'done' && !tr.trim()) return false;
      return !q || src.toLowerCase().includes(q) || tr.toLowerCase().includes(q);
    });
  }, [rows, data, activeTarget, query, filter]);

  const shown = visible.slice(0, limit);

  useEffect(() => setLimit(RENDER_STEP), [query, filter, activeTarget]);

  if (loadError) {
    return (
      <div className="bk-panel">
        <div className="bk-panel__body">
          <p className="bk-tr__muted">{loadError}</p>
        </div>
      </div>
    );
  }
  if (!data) {
    return (
      <div className="bk-panel">
        <div className="bk-panel__body">
          <p className="bk-tr__muted">Loading translations…</p>
        </div>
      </div>
    );
  }

  const patch = (next: Partial<Translations>) => setData({ ...data, ...next });

  const setTranslation = (src: string, value: string) => {
    const map = { ...(data.strings[activeTarget] ?? {}) };
    if (value) map[src] = value;
    else delete map[src];
    patch({ strings: { ...data.strings, [activeTarget]: map } });
  };

  const removeSource = (src: string) => {
    const strings: Translations['strings'] = {};
    for (const [code, map] of Object.entries(data.strings)) {
      const { [src]: _gone, ...rest } = map;
      strings[code] = rest;
    }
    patch({ sources: data.sources.filter((s) => s !== src), strings });
  };

  const addSources = (texts: string[]) => {
    const seen = new Set(data.sources);
    const fresh = texts.map(normalize).filter((t) => t && !seen.has(t) && (seen.add(t), true));
    if (fresh.length) patch({ sources: [...data.sources, ...fresh] });
    return fresh.length;
  };

  const addLanguage = (code: string) => {
    if (data.languages.includes(code)) return;
    patch({ languages: [...data.languages, code] });
    setTarget(code);
    setPicker('');
    setPickerOpen(false);
  };

  /** Translations stay stored, so adding the language back restores them. */
  const removeLanguage = (code: string) => {
    patch({
      languages: data.languages.filter((c) => c !== code),
      primaryLanguage: data.primaryLanguage === code ? data.defaultLanguage : data.primaryLanguage,
    });
  };

  /** Only changes which language sits on the plain address — no texts change. */
  const setPrimary = (code: string) => patch({ primaryLanguage: code });

  const save = async () => {
    setBusy(true);
    onError(null);
    try {
      const { catalog: _c, ...next } = await api<TranslationsResponse>('/api/site/translations', {
        method: 'PUT',
        json: data,
      });
      setData(next);
      saved.current = next;
      onNotice('Translations saved. The live site updates within a few seconds.');
    } catch (e) {
      onError(e instanceof ApiError ? e.message : 'Could not save translations.');
    } finally {
      setBusy(false);
    }
  };

  const scanSite = async () => {
    onError(null);
    setScan('Finding pages…');
    try {
      const targets = await api<LinkTargetsResponse>('/api/site/link-targets');
      const paths = [
        ...new Set(['/', '/blog', ...[...targets.system, ...targets.pages, ...targets.posts].map((t) => t.path)]),
      ].filter((p) => p.startsWith('/') && !p.startsWith('//'));
      const found: string[] = [...targets.pages, ...targets.posts].map((t) => t.label);
      let done = 0;
      for (const path of paths) {
        setScan(`Reading ${path} (${done + 1}/${paths.length})…`);
        try {
          const res = await fetch(`${LIVE}${path}`, { headers: { Accept: 'text/html' } });
          if (res.ok) {
            const doc = new DOMParser().parseFromString(await res.text(), 'text/html');
            found.push(...collectTexts(doc));
          }
        } catch {
          // One unreachable page should not stop the scan.
        }
        done++;
      }
      const added = addSources(found);
      onNotice(
        added
          ? `Found ${added} new text${added === 1 ? '' : 's'} on ${paths.length} pages. Save to keep them.`
          : `Scanned ${paths.length} pages — nothing new to translate.`,
      );
    } catch (e) {
      onError(e instanceof ApiError ? e.message : 'Could not scan the site.');
    } finally {
      setScan(null);
    }
  };

  const autoTranslate = async () => {
    const lang = activeTarget;
    const map = data.strings[lang] ?? {};
    const missing = rows.filter((s) => !map[s]?.trim() && s.length <= AUTO_MAX_CHARS);
    if (!lang || !missing.length) return;
    onError(null);
    cancelAuto.current = false;
    setAuto({ done: 0, total: missing.length });
    const results: Record<string, string> = {};
    let failed = 0;
    for (let i = 0; i < missing.length && !cancelAuto.current; i += AUTO_BATCH) {
      const texts = missing.slice(i, i + AUTO_BATCH);
      try {
        const res = await api<{ translations: Record<string, string>; failed: number }>(
          '/api/site/translations/auto',
          { method: 'POST', json: { from: data.defaultLanguage, to: lang, texts } },
        );
        Object.assign(results, res.translations);
        failed += res.failed;
      } catch {
        failed += texts.length;
      }
      setAuto({ done: Math.min(i + AUTO_BATCH, missing.length), total: missing.length });
      // Show progress live without touching texts edited meanwhile.
      setData((cur) => {
        if (!cur) return cur;
        const curMap = { ...(cur.strings[lang] ?? {}) };
        for (const [src, tr] of Object.entries(results)) if (!curMap[src]?.trim()) curMap[src] = tr;
        return { ...cur, strings: { ...cur.strings, [lang]: curMap } };
      });
    }
    setAuto(null);
    const got = Object.keys(results).length;
    const name = byCode.get(lang)?.name ?? lang;
    if (got) onNotice(`Suggested ${got} ${name} translation${got === 1 ? '' : 's'}. Review them, then save.`);
    if (failed) onError(`${failed} text${failed === 1 ? '' : 's'} could not be translated automatically (the free service may be busy). Try again later or type them in.`);
  };

  const copy = (text: string) => {
    void navigator.clipboard?.writeText(text).then(() => {
      setCopied(text);
      window.setTimeout(() => setCopied((c) => (c === text ? null : c)), 1400);
    });
  };

  const def = byCode.get(data.defaultLanguage);
  const q = picker.trim().toLowerCase();
  const options = catalog.filter(
    (l) =>
      !data.languages.includes(l.code) &&
      (!q || l.name.toLowerCase().includes(q) || l.native.toLowerCase().includes(q) || l.code.toLowerCase() === q),
  );
  const targetLang = byCode.get(activeTarget);
  const targetMap = data.strings[activeTarget] ?? {};
  const missingCount = rows.filter((s) => !targetMap[s]?.trim()).length;

  return (
    <div className="bk-tr">
      <div className="bk-tr__bar">
        <div>
          <h2>Translation</h2>
          <p>
            Serve your site in more languages. Each language gets its own address (<code>/de/about</code>) and
            uses the translations you keep here — no plugin, no external service at runtime.
          </p>
        </div>
        <div className="bk-tr__bar-actions">
          {dirty ? (
            <span className="bk-tr__dirty">Unsaved changes</span>
          ) : (
            <span className="bk-tr__saved">
              <Check size={12} weight="bold" /> Saved
            </span>
          )}
          {dirty ? (
            <button type="button" className="button" onClick={() => saved.current && setData(saved.current)}>
              Discard
            </button>
          ) : null}
          <button type="button" className="button button-primary" disabled={busy || !dirty} onClick={() => void save()}>
            {busy ? 'Saving…' : 'Save translations'}
          </button>
        </div>
      </div>

      {/* ── Languages ─────────────────────────────────────────────────── */}
      <div className="bk-panel">
        <div className="bk-panel__head">
          <h3 className="bk-panel__title">Languages</h3>
          <span className="bk-tr__muted">{data.languages.length} enabled</span>
        </div>
        <div className="bk-panel__body bk-tr__langs">
          <label className="bk-tr__field">
            <span>Primary language</span>
            <select value={data.primaryLanguage} onChange={(e) => setPrimary(e.target.value)}>
              {data.languages.map((code) => {
                const l = byCode.get(code);
                return (
                  <option key={code} value={code}>
                    {l ? `${l.native} — ${l.name}` : code}
                  </option>
                );
              })}
            </select>
            <em>
              What visitors get on the plain address (<code>/about</code>) and what search engines treat as the
              default. Your original texts stay in {def?.name ?? 'English'} and no translation is changed.
            </em>
          </label>

          <ul className="bk-tr__lang-list">
            {data.languages.map((code) => {
              const l = byCode.get(code);
              const isDefault = code === data.defaultLanguage;
              const isPrimary = code === data.primaryLanguage;
              const p = progress(code);
              const pct = p.total ? Math.round((p.done / p.total) * 100) : 0;
              return (
                <li key={code} className="bk-tr__lang">
                  <span className="bk-tr__code">{code}</span>
                  <span className="bk-tr__lang-name">
                    <strong lang={code} dir={l?.rtl ? 'rtl' : undefined}>
                      {l?.native ?? code}
                    </strong>
                    <em>{l?.name ?? code}</em>
                  </span>
                  <span className="bk-tr__prefix">{isPrimary ? '/' : `/${code}/`}</span>
                  {isDefault ? (
                    <span className="bk-tr__badges">
                      <span className="bk-tr__badge">Original</span>
                      {isPrimary ? <span className="bk-tr__badge is-primary">Primary</span> : null}
                    </span>
                  ) : (
                    <span className="bk-tr__meter" title={`${p.done} of ${p.total} texts translated`}>
                      <span className="bk-tr__meter-track">
                        <span style={{ width: `${pct}%` }} />
                      </span>
                      <span className="bk-tr__meter-label">{pct}%</span>
                    </span>
                  )}
                  <span className="bk-tr__lang-actions">
                    {isPrimary ? (
                      isDefault ? null : <span className="bk-tr__badge is-primary">Primary</span>
                    ) : (
                      <button
                        type="button"
                        className="bk-tr__text-btn"
                        onClick={() => setPrimary(code)}
                        title="Make this the primary language (served without a prefix)"
                      >
                        Make primary
                      </button>
                    )}
                    <a
                      className="bk-tr__icon-btn"
                      href={`${LIVE}${isPrimary ? '/' : `/${code}`}`}
                      target="_blank"
                      rel="noreferrer"
                      title="View the site in this language"
                    >
                      <ArrowSquareOut size={14} />
                    </a>
                    {isDefault ? null : (
                      <button
                        type="button"
                        className="bk-tr__icon-btn is-danger"
                        onClick={() => removeLanguage(code)}
                        title="Turn this language off (translations are kept)"
                      >
                        <X size={14} />
                      </button>
                    )}
                  </span>
                </li>
              );
            })}
          </ul>

          <div className="bk-tr__picker" ref={pickerRef}>
            <label className="bk-tr__search">
              <Plus size={13} aria-hidden />
              <input
                type="text"
                value={picker}
                placeholder={`Add a language — search ${catalog.length} languages`}
                onFocus={() => setPickerOpen(true)}
                onChange={(e) => {
                  setPicker(e.target.value);
                  setPickerOpen(true);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && options[0]) {
                    e.preventDefault();
                    addLanguage(options[0].code);
                  }
                  if (e.key === 'Escape') setPickerOpen(false);
                }}
              />
            </label>
            {pickerOpen ? (
              <ul className="bk-tr__options" role="listbox">
                {options.length ? (
                  options.map((l) => (
                    <li key={l.code}>
                      <button type="button" onClick={() => addLanguage(l.code)}>
                        <span className="bk-tr__code">{l.code}</span>
                        <span>{l.name}</span>
                        <em lang={l.code} dir={l.rtl ? 'rtl' : undefined}>
                          {l.native}
                        </em>
                      </button>
                    </li>
                  ))
                ) : (
                  <li className="bk-tr__muted bk-tr__options-empty">No language matches “{picker}”.</li>
                )}
              </ul>
            ) : null}
          </div>
        </div>
      </div>

      {/* ── Strings ───────────────────────────────────────────────────── */}
      <div className="bk-panel">
        <div className="bk-panel__head">
          <h3 className="bk-panel__title">Texts</h3>
          <div className="bk-tr__head-actions">
            <button type="button" className="button" disabled={Boolean(scan) || Boolean(auto)} onClick={() => void scanSite()}>
              <MagnifyingGlass size={13} /> {scan ? 'Scanning…' : 'Scan site'}
            </button>
            {activeTarget ? (
              auto ? (
                <button type="button" className="button" onClick={() => (cancelAuto.current = true)}>
                  Stop ({auto.done}/{auto.total})
                </button>
              ) : (
                <button
                  type="button"
                  className="button"
                  disabled={!missingCount || Boolean(scan)}
                  onClick={() => void autoTranslate()}
                  title="Suggest translations for every missing text (MyMemory, free)"
                >
                  <Sparkle size={13} /> Auto-translate missing
                </button>
              )
            ) : null}
          </div>
        </div>

        {scan ? <div className="bk-tr__status">{scan}</div> : null}
        {auto ? (
          <div className="bk-tr__status">
            Translating into {targetLang?.name} — {auto.done} of {auto.total}
            <span className="bk-tr__status-track">
              <span style={{ width: `${Math.round((auto.done / Math.max(1, auto.total)) * 100)}%` }} />
            </span>
          </div>
        ) : null}

        {!extra.length ? (
          <div className="bk-panel__body">
            <p className="bk-tr__empty">
              Add a language above to start translating. Your {def?.name ?? 'original'} texts stay as they are.
            </p>
          </div>
        ) : (
          <>
            <div className="bk-tabs is-flush" role="tablist" aria-label="Languages">
              {extra.map((code) => {
                const p = progress(code);
                return (
                  <button
                    key={code}
                    type="button"
                    role="tab"
                    aria-selected={code === activeTarget}
                    className={`bk-tabs__item${code === activeTarget ? ' is-active' : ''}`}
                    onClick={() => setTarget(code)}
                  >
                    {byCode.get(code)?.native ?? code}
                    <span className="bk-tabs__count">
                      {p.done}/{p.total}
                    </span>
                  </button>
                );
              })}
            </div>
            <div className="bk-tr__toolbar">
              <div className="bk-tr__filters">
                <label className="bk-tr__search is-small">
                  <MagnifyingGlass size={13} aria-hidden />
                  <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search texts…" />
                </label>
                <select value={filter} onChange={(e) => setFilter(e.target.value as Filter)} aria-label="Show">
                  <option value="all">All ({rows.length})</option>
                  <option value="missing">Missing ({missingCount})</option>
                  <option value="done">Translated ({rows.length - missingCount})</option>
                </select>
              </div>
            </div>

            <form
              className="bk-tr__add"
              onSubmit={(e) => {
                e.preventDefault();
                if (addSources([newText])) setNewText('');
              }}
            >
              <input
                type="text"
                value={newText}
                onChange={(e) => setNewText(e.target.value)}
                placeholder={`Add a text by hand (in ${def?.name ?? 'the site language'}), exactly as it appears on the site`}
              />
              <button type="submit" className="button" disabled={!normalize(newText)}>
                <Plus size={13} weight="bold" /> Add text
              </button>
            </form>

            {rows.length === 0 ? (
              <div className="bk-panel__body">
                <p className="bk-tr__empty">
                  No texts yet. <strong>Scan site</strong> collects every heading, button, menu label and paragraph from
                  your published pages.
                </p>
              </div>
            ) : (
              <div
                className="bk-tr__scroll"
                onScroll={(e) => {
                  const el = e.currentTarget;
                  if (limit < visible.length && el.scrollTop + el.clientHeight > el.scrollHeight - 400) {
                    setLimit((n) => n + RENDER_STEP);
                  }
                }}
              >
              <table className="bk-tr__table">
                <thead>
                  <tr>
                    <th>{def?.name ?? 'Original'}</th>
                    <th>{targetLang?.name ?? activeTarget}</th>
                    <th aria-label="Actions" />
                  </tr>
                </thead>
                <tbody>
                  {shown.map((src) => {
                    const value = targetMap[src] ?? '';
                    return (
                      <tr key={src} className={value.trim() ? '' : 'is-missing'}>
                        <td className="bk-tr__src" lang={data.defaultLanguage}>
                          {src}
                        </td>
                        <td>
                          <textarea
                            value={value}
                            rows={Math.min(6, Math.max(1, Math.ceil(src.length / 60)))}
                            lang={activeTarget}
                            dir={targetLang?.rtl ? 'rtl' : undefined}
                            placeholder="Missing — type the translation"
                            onChange={(e) => setTranslation(src, e.target.value)}
                          />
                        </td>
                        <td className="bk-tr__row-actions">
                          <button
                            type="button"
                            className="bk-tr__icon-btn is-danger"
                            onClick={() => removeSource(src)}
                            title="Remove this text from every language"
                          >
                            <Trash size={14} />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                  {!shown.length ? (
                    <tr>
                      <td colSpan={3} className="bk-tr__muted bk-tr__none">
                        Nothing matches this filter.
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
              </div>
            )}

            {rows.length ? (
              <div className="bk-tr__pager">
                <span className="bk-tr__muted">
                  {visible.length === rows.length
                    ? `${rows.length} texts`
                    : `${visible.length} of ${rows.length} texts match`}
                </span>
              </div>
            ) : null}
          </>
        )}
      </div>

      {/* ── Switcher ──────────────────────────────────────────────────── */}
      <div className="bk-panel">
        <div className="bk-panel__head">
          <h3 className="bk-panel__title">Language switcher</h3>
        </div>
        <div className="bk-panel__body bk-tr__use">
          <div className="bk-tr__use-block">
            <h4>In the menu</h4>
            <p>
              Settings → Permalinks → <strong>Languages</strong> → Add language switcher. It shows as a dropdown in
              your header, on desktop and mobile.
            </p>
            <button type="button" className="button" onClick={onOpenMenu}>
              Open navigation
            </button>
          </div>
          <div className="bk-tr__use-block">
            <h4>As a shortcode</h4>
            <p>Paste into Site code (General), a page’s HTML / text element, or your theme header and footer.</p>
            <ul className="bk-tr__codes">
              {SHORTCODES.map((s) => (
                <li key={s.code}>
                  <code>{s.code}</code>
                  <span className="bk-tr__muted">{s.hint}</span>
                  <button type="button" className="bk-tr__icon-btn" onClick={() => copy(s.code)} title="Copy">
                    {copied === s.code ? <Check size={14} weight="bold" /> : <Copy size={14} />}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          <p className="bk-tr__muted bk-tr__fine">
            Tip: wrap anything that must never be translated (brand names, code) in an element with{' '}
            <code>translate="no"</code>.
          </p>
        </div>
      </div>
    </div>
  );
}
