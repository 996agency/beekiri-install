import { useCallback, useEffect, useState } from 'react';
import { api, ApiError } from '../api/client';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import { notifyConnectorChanged } from '../lib/admin-events';
import { BeeQueenAccount } from './BeeQueenAccount';
import { BeekiriChangeHistory } from './BeekiriChangeHistory';
import { PoweredByClaude } from '../components/PoweredByClaude';
import './connector-page.css';
import { ErrorNotice } from '../components/ErrorNotice';

type ProviderDetail = {
  id: 'beequeen';
  name: string;
  blurb: string;
  enabled: boolean;
  /** What the agent runs on: 996Agency, or a local testing fallback. */
  keySource: 'service' | 'claude' | 'env' | 'claude-code' | null;
};

const STATUS: Record<NonNullable<ProviderDetail['keySource']> | 'none', { tone: 'ok' | 'test' | 'off'; text: string }> = {
  service: { tone: 'ok', text: 'Connected to 996Agency' },
  'claude-code': { tone: 'test', text: 'Testing mode — runs through Claude Code on this machine' },
  claude: { tone: 'test', text: 'Testing mode — runs on the Claude connector’s Anthropic key' },
  env: { tone: 'test', text: 'Testing mode — runs on ANTHROPIC_API_KEY from the server environment' },
  none: { tone: 'off', text: 'Not connected yet — the site connects to 996Agency by itself once it has registered with the Beekiri Hub' },
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

/**
 * Connector: the Beekiri agent. It runs on Claude through 996Agency's Anthropic API account and
 * the site signs in with its Hub install token, so there is no key, model or API setup here.
 * Prepaid: the site tops up a dollar balance with 996Agency; the balance and spend are shown below.
 */
export function ConnectorProviderPage() {
  const [data, setData] = useState<ProviderDetail | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(async () => {
    setData(await api<ProviderDetail>('/api/connector/beequeen'));
  }, []);

  useEffect(() => {
    load().catch((e) => setError(formatError(e)));
  }, [load]);

  const setEnabled = async (enabled: boolean) => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await api('/api/connector', { method: 'PATCH', json: { providerId: 'beequeen', enabled } });
      notifyConnectorChanged();
      await load();
      setNotice(enabled ? 'Beekiri is on.' : 'Beekiri is off — the chat bee is hidden until you turn it on.');
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  if (!data) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title="Connector" />
        {error ? (
          <div className="beekiri-notice is-error" role="alert">
            <p>{error}</p>
          </div>
        ) : (
          <p className="bk-muted">Loading…</p>
        )}
      </div>
    );
  }

  const status = STATUS[data.keySource ?? 'none'];

  return (
    <div className="wrap wrap--wide bk-conn">
      <PageHeader
        title="Connector"
        actions={
          <button
            type="button"
            className={data.enabled ? 'button' : 'button button-primary'}
            disabled={busy}
            onClick={() => void setEnabled(!data.enabled)}
          >
            {data.enabled ? 'Turn off' : 'Turn on'}
          </button>
        }
      />
      <p className="bk-muted" style={{ marginTop: 0 }}>
        {data.blurb}
      </p>
      <PoweredByClaude />

      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}

      <p className={`bk-conn-status is-${status.tone}`}>
        <span className="bk-conn-status__dot" aria-hidden />
        <span>{status.text}</span>
      </p>

      <BeeQueenAccount reloadKey={0} />
      <BeekiriChangeHistory />
    </div>
  );
}
