import { FormEvent, useCallback, useEffect, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import type { RoleSlug } from '../cms-types';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import { useAdminHref } from '../lib/AdminEntryContext';
import { generatePassword, passwordStrength } from '../util/password';
import { ErrorNotice } from '../components/ErrorNotice';

type RoleOption = { slug: RoleSlug; label: string };

type CustomField = { id: string; label: string; value: string };

type SiteUser = {
  id: string;
  username: string;
  email: string;
  displayName: string;
  role: RoleSlug;
  roleLabel: string;
  isOwner: boolean;
  jobDescription?: string;
  customFields?: CustomField[];
  createdAt: string;
  updatedAt: string;
};

const EMPTY_FORM = {
  username: '',
  email: '',
  displayName: '',
  password: '',
  currentPassword: '',
  role: 'subscriber' as RoleSlug,
  jobDescription: '',
  customFields: [] as CustomField[],
};

function newCustomField(): CustomField {
  return {
    id: `cf-${Math.random().toString(36).slice(2, 9)}`,
    label: '',
    value: '',
  };
}

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

const ROLE_LABELS: Record<RoleSlug, string> = {
  administrator: 'Administrator',
  editor: 'Editor',
  author: 'Author',
  contributor: 'Contributor',
  subscriber: 'Subscriber',
  shop_manager: 'Shop manager',
};

export function UserEditPage() {
  const { id } = useParams<{ id: string }>();
  const isNew = !id || id === 'new';
  const auth = useAuth();
  const href = useAdminHref();
  const navigate = useNavigate();
  const location = useLocation();

  const [roles, setRoles] = useState<RoleOption[]>([]);
  const [user, setUser] = useState<SiteUser | null>(null);
  const [loading, setLoading] = useState(!isNew);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [showPw, setShowPw] = useState(isNew);

  useEffect(() => {
    const state = location.state as { notice?: string } | null;
    if (state?.notice) {
      setNotice(state.notice);
      navigate(location.pathname, { replace: true, state: null });
    }
  }, [location.pathname, location.state, navigate]);

  const canCreate = auth.user?.capabilities.includes('create_users') ?? false;
  const canEdit = auth.user?.capabilities.includes('edit_users') ?? false;
  const canList = auth.user?.capabilities.includes('list_users') ?? false;
  const isSelf = Boolean(id && auth.user?.id === id);
  const allowed = isNew ? canCreate : canEdit || isSelf;
  const canChangeRole = canEdit && !isSelf;
  const backTo = canList ? href('users') : href();
  const pageTitle = isNew
    ? 'Add new user'
    : isSelf
      ? 'Your profile'
      : 'Edit user';

  const loadRoles = useCallback(async () => {
    if (!canList) return;
    const res = await api<{ roles: RoleOption[] }>('/api/users/roles');
    setRoles(res.roles);
  }, [canList]);

  useEffect(() => {
    if (!allowed) return;
    let cancelled = false;
    (async () => {
      try {
        setError(null);
        await loadRoles();
        if (isNew) {
          if (!cancelled) {
            setForm({ ...EMPTY_FORM, password: generatePassword(16), customFields: [] });
            setShowPw(true);
            setUser(null);
            setLoading(false);
          }
          return;
        }
        setLoading(true);
        const row = await api<SiteUser>(`/api/users/${id}`);
        if (cancelled) return;
        setUser(row);
        setForm({
          username: row.username,
          email: row.email,
          displayName: row.displayName,
          password: '',
          currentPassword: '',
          role: row.role,
          jobDescription: row.jobDescription ?? '',
          customFields: (row.customFields ?? []).map((f) => ({ ...f })),
        });
        setShowPw(false);
      } catch (e) {
        if (!cancelled) setError(formatError(e));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [allowed, id, isNew, loadRoles]);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!allowed) return;
    setBusy(true);
    setError(null);
    try {
      const profilePayload = {
        jobDescription: form.jobDescription.trim(),
        customFields: form.customFields
          .map((f) => ({
            id: f.id,
            label: f.label.trim(),
            value: f.value.trim(),
          }))
          .filter((f) => f.label),
      };
      if (isNew) {
        const created = await api<SiteUser>('/api/users', {
          method: 'POST',
          json: {
            username: form.username.trim(),
            email: form.email.trim(),
            displayName: form.displayName.trim() || form.username.trim(),
            password: form.password,
            role: form.role,
            ...profilePayload,
          },
        });
        navigate(href(`users/${created.id}`), {
          replace: true,
          state: { notice: `User “${created.username}” created.` },
        });
        return;
      }

      if (!id) return;
      const payload: Record<string, unknown> = {
        username: form.username.trim(),
        email: form.email.trim(),
        displayName: form.displayName.trim() || form.username.trim(),
        ...profilePayload,
      };
      if (canChangeRole) payload.role = form.role;
      if (form.password.trim()) payload.password = form.password.trim();
      if (isSelf && form.currentPassword) payload.currentPassword = form.currentPassword;
      const updated = await api<SiteUser>(`/api/users/${id}`, {
        method: 'PATCH',
        json: payload,
      });
      setUser(updated);
      setForm((f) => ({ ...f, password: '', currentPassword: '' }));
      const notice =
        form.password.trim() && updated.id === auth.user?.id
          ? `Profile updated. Your password changed — you may need to sign in again.`
          : isSelf
            ? 'Your profile was updated.'
            : `User “${updated.username}” updated.`;
      if (isSelf && !canList) {
        setNotice(notice);
      } else {
        navigate(backTo, { state: { notice } });
      }
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  if (!allowed) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title={pageTitle} />
        <div className="beekiri-notice is-error" role="alert">
          <p>You do not have permission to {isNew ? 'create' : 'edit'} users.</p>
        </div>
        <p>
          <Link to={backTo} className="button">
            {canList ? 'Back to users' : 'Back to dashboard'}
          </Link>
        </p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title={pageTitle} />
        <p className="bk-muted">Loading…</p>
      </div>
    );
  }

  if (!isNew && !user && error) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title={pageTitle} />
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
        <p>
          <Link to={backTo} className="button">
            {canList ? 'Back to users' : 'Back to dashboard'}
          </Link>
        </p>
      </div>
    );
  }

  const formId = 'user-form';
  const editing = user;
  const strength = form.password ? passwordStrength(form.password) : null;
  const roleLabel =
    roles.find((r) => r.slug === form.role)?.label ?? ROLE_LABELS[form.role] ?? form.role;

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title={
          editing
            ? isSelf
              ? 'Your profile'
              : `Edit user · ${editing.username}`
            : 'Add new user'
        }
        actions={
          <>
            <button type="submit" form={formId} className="button button-primary" disabled={busy}>
              {busy ? 'Saving…' : editing ? (isSelf ? 'Update profile' : 'Update user') : 'Add user'}
            </button>
            <Link to={backTo} className="button" aria-disabled={busy}>
              Cancel
            </Link>
          </>
        }
      />
      <p className="bk-muted">
        {editing ? (
          isSelf ? (
            <>
              Update your account details
              {editing.isOwner ? ' · site owner' : ''}
              {' · '}
              role <strong>{roleLabel}</strong>
            </>
          ) : (
            <>
              Editing <strong>{editing.username}</strong>
              {editing.isOwner ? ' · site owner' : ''}
              {' · '}
              User ID <code className="bk-user-id">{editing.id}</code>
            </>
          )
        ) : (
          'Create an account for someone who needs access to this site.'
        )}
      </p>

      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}

      <form id={formId} className="bk-panel" onSubmit={onSubmit}>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              {editing ? (
                <tr>
                  <th scope="row">
                    <span id="user_id_label">User ID</span>
                  </th>
                  <td>
                    <code className="bk-user-id" aria-labelledby="user_id_label">
                      {editing.id}
                    </code>
                    <p className="description">Stable id for this account — also in the URL.</p>
                  </td>
                </tr>
              ) : null}
              <tr>
                <th scope="row">
                  <label htmlFor="user_username">Username</label>
                </th>
                <td>
                  <input
                    id="user_username"
                    className="regular-text"
                    type="text"
                    autoComplete="off"
                    required
                    minLength={3}
                    maxLength={60}
                    value={form.username}
                    onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))}
                  />
                  <p className="description">Letters, numbers, and . - _ only.</p>
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="user_email">Email</label>
                </th>
                <td>
                  <input
                    id="user_email"
                    className="regular-text"
                    type="email"
                    autoComplete="off"
                    required
                    value={form.email}
                    onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                  />
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="user_display">Display name</label>
                </th>
                <td>
                  <input
                    id="user_display"
                    className="regular-text"
                    type="text"
                    autoComplete="off"
                    maxLength={120}
                    value={form.displayName}
                    placeholder={form.username || 'Shown publicly'}
                    onChange={(e) => setForm((f) => ({ ...f, displayName: e.target.value }))}
                  />
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="user_job">Job description</label>
                </th>
                <td>
                  <textarea
                    id="user_job"
                    rows={3}
                    maxLength={2000}
                    value={form.jobDescription}
                    placeholder="Optional — role, team, or what this person does"
                    onChange={(e) => setForm((f) => ({ ...f, jobDescription: e.target.value }))}
                  />
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <span id="user_custom_label">Custom fields</span>
                </th>
                <td>
                  <div className="bk-user-custom" aria-labelledby="user_custom_label">
                    {form.customFields.map((field, index) => (
                      <div key={field.id} className="bk-user-custom__row">
                        <input
                          className="regular-text"
                          type="text"
                          maxLength={80}
                          placeholder="Label"
                          aria-label={`Custom field ${index + 1} label`}
                          value={field.label}
                          onChange={(e) => {
                            const label = e.target.value;
                            setForm((f) => ({
                              ...f,
                              customFields: f.customFields.map((row) =>
                                row.id === field.id ? { ...row, label } : row,
                              ),
                            }));
                          }}
                        />
                        <input
                          className="regular-text"
                          type="text"
                          maxLength={500}
                          placeholder="Value"
                          aria-label={`Custom field ${index + 1} value`}
                          value={field.value}
                          onChange={(e) => {
                            const value = e.target.value;
                            setForm((f) => ({
                              ...f,
                              customFields: f.customFields.map((row) =>
                                row.id === field.id ? { ...row, value } : row,
                              ),
                            }));
                          }}
                        />
                        <button
                          type="button"
                          className="button-link is-danger"
                          aria-label={`Remove custom field ${index + 1}`}
                          onClick={() =>
                            setForm((f) => ({
                              ...f,
                              customFields: f.customFields.filter((row) => row.id !== field.id),
                            }))
                          }
                        >
                          Remove
                        </button>
                      </div>
                    ))}
                    <button
                      type="button"
                      className="button"
                      onClick={() =>
                        setForm((f) => ({
                          ...f,
                          customFields: [...f.customFields, newCustomField()],
                        }))
                      }
                    >
                      + Add field
                    </button>
                    <p className="description">
                      Optional extras for this user only — department, phone, notes, etc.
                    </p>
                  </div>
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="user_role">Role</label>
                </th>
                <td>
                  {canChangeRole ? (
                    <>
                      <select
                        id="user_role"
                        value={form.role}
                        disabled={Boolean(editing?.isOwner)}
                        onChange={(e) =>
                          setForm((f) => ({ ...f, role: e.target.value as RoleSlug }))
                        }
                      >
                        {roles.map((r) => (
                          <option key={r.slug} value={r.slug}>
                            {r.label}
                          </option>
                        ))}
                      </select>
                      {editing?.isOwner ? (
                        <p className="description">The site owner stays an administrator.</p>
                      ) : (
                        <p className="description">
                          Administrators can manage settings and users. Editors manage content.
                        </p>
                      )}
                    </>
                  ) : (
                    <>
                      <input
                        id="user_role"
                        className="regular-text"
                        type="text"
                        value={roleLabel}
                        disabled
                        readOnly
                      />
                      <p className="description">
                        {isSelf
                          ? 'Your role is set by the site Owner.'
                          : editing?.isOwner
                            ? 'The site owner stays an administrator.'
                            : 'Role cannot be changed here.'}
                      </p>
                    </>
                  )}
                </td>
              </tr>
              {isSelf ? (
                <tr>
                  <th scope="row">
                    <label htmlFor="user_current_password">Current password</label>
                  </th>
                  <td>
                    <input
                      id="user_current_password"
                      className="regular-text"
                      type="password"
                      autoComplete="current-password"
                      value={form.currentPassword}
                      onChange={(e) =>
                        setForm((f) => ({ ...f, currentPassword: e.target.value }))
                      }
                    />
                    <p className="description">
                      Required to change your email address or password.
                    </p>
                  </td>
                </tr>
              ) : null}
              <tr>
                <th scope="row">
                  <label htmlFor="user_password">{editing ? 'New password' : 'Password'}</label>
                </th>
                <td>
                  <div className="bk-user-pw">
                    <input
                      id="user_password"
                      className="regular-text"
                      type={showPw ? 'text' : 'password'}
                      autoComplete="new-password"
                      required={!editing}
                      minLength={editing && !form.password ? undefined : 8}
                      value={form.password}
                      placeholder={editing ? 'Leave blank to keep current password' : ''}
                      onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
                    />
                    <button type="button" className="button" onClick={() => setShowPw((v) => !v)}>
                      {showPw ? 'Hide' : 'Show'}
                    </button>
                    <button
                      type="button"
                      className="button"
                      onClick={() => {
                        setForm((f) => ({ ...f, password: generatePassword(16) }));
                        setShowPw(true);
                      }}
                    >
                      Generate
                    </button>
                  </div>
                  {strength ? (
                    <p className={`bk-pw-strength is-${strength}`}>Strength: {strength}</p>
                  ) : editing ? (
                    <p className="description">Leave blank to keep the current password.</p>
                  ) : null}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </form>
    </div>
  );
}
