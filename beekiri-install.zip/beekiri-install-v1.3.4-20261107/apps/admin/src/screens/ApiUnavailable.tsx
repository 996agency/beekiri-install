import { BrandMark } from '../components/BrandMark';

type Props = {
  onRetry: () => void;
  detail?: string | null;
};

/**
 * Client-safe downtime screen. Never exposes ports, paths, or CLI commands
 * to end users. Dev-only technical notes stay collapsed when DEV is on.
 */
export function ApiUnavailable({ onRetry, detail }: Props) {
  const isDev = Boolean(import.meta.env.DEV);

  return (
    <div className="bk-down">
      <div className="bk-down__card">
        <div className="bk-down__brand">
          <BrandMark variant="logo" size={32} />
        </div>

        <h1 className="bk-down__title">We&apos;ll be back as soon as possible</h1>
        <p className="bk-down__lead">
          We&apos;re doing a quick update behind the scenes. Nothing is lost — please check back in
          a moment.
        </p>

        <button type="button" className="bk-down__btn" onClick={onRetry}>
          Try again
        </button>

        <p className="bk-down__foot">Thank you for your patience.</p>

        {isDev ? (
          <details className="bk-down__dev">
            <summary>Developer notes</summary>
            <p>
              Local API is unreachable. Start it from the project root, then click Try again — no
              reinstall needed.
            </p>
            <code>pnpm --filter @beekiri/api dev</code>
            <code>pnpm dev</code>
            {detail ? <p className="bk-down__dev-detail">{detail}</p> : null}
          </details>
        ) : null}
      </div>

      <style>{`
        .bk-down {
          min-height: 100vh;
          display: grid;
          place-items: center;
          padding: 32px 20px;
          background:
            radial-gradient(ellipse 80% 60% at 50% -10%, rgba(242, 132, 47, 0.12), transparent 55%),
            #f0f0f1;
          font-family: 'SF Pro Text', 'SF Pro Display', -apple-system, BlinkMacSystemFont,
            'Helvetica Neue', Helvetica, Arial, sans-serif;
          color: #202734;
        }
        .bk-down__card {
          width: 100%;
          max-width: 420px;
          text-align: center;
          padding: 36px 28px 28px;
          background: #fff;
          border: 1px solid #0000001A;
          border-radius: 16px;
          box-shadow: 0 12px 40px rgba(0, 0, 0, 0.06);
        }
        .bk-down__brand {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 22px;
        }
        .bk-down__name {
          font-size: 18px;
          font-weight: 600;
          letter-spacing: -0.02em;
        }
        .bk-down__title {
          margin: 0 0 10px;
          font-size: 26px;
          font-weight: 600;
          letter-spacing: -0.03em;
          line-height: 1.2;
        }
        .bk-down__lead {
          margin: 0 0 24px;
          font-size: 15px;
          font-weight: 300;
          line-height: 1.55;
          color: #646970;
        }
        .bk-down__btn {
          appearance: none;
          border: 1px solid #F2842F;
          background: #F2842F;
          color: #2f2f2f;
          border-radius: 6px;
          padding: 10px 20px;
          font: inherit;
          font-size: 14px;
          font-weight: 300;
          cursor: pointer;
        }
        .bk-down__btn:hover {
          background: #F4954A;
          border-color: #F4954A;
        }
        .bk-down__foot {
          margin: 18px 0 0;
          font-size: 13px;
          font-weight: 300;
          color: #86868b;
        }
        .bk-down__dev {
          margin-top: 28px;
          padding-top: 16px;
          border-top: 1px solid #0000001A;
          text-align: left;
          font-size: 12px;
          color: #646970;
        }
        .bk-down__dev summary {
          cursor: pointer;
          font-weight: 500;
          color: #86868b;
          list-style: none;
        }
        .bk-down__dev summary::-webkit-details-marker { display: none; }
        .bk-down__dev[open] summary { margin-bottom: 10px; }
        .bk-down__dev p { margin: 0 0 8px; line-height: 1.45; font-weight: 300; }
        .bk-down__dev code {
          display: block;
          margin: 0 0 6px;
          padding: 8px 10px;
          border-radius: 6px;
          background: #f5f5f7;
          font-size: 11px;
          word-break: break-all;
        }
        .bk-down__dev-detail {
          margin-top: 10px !important;
          padding: 8px 10px;
          border-radius: 6px;
          background: #fcf0f1;
          color: #6e2a2c;
          font-size: 11px;
        }
      `}</style>
    </div>
  );
}
