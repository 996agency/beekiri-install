import { FormEvent, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import { useAdminHref } from '../lib/AdminEntryContext';
import { formatRelative } from '../editor/pageStats';
import './analytics-page.css';
import {
  AnalyticsRankCard,
  Sparkline,
  compactNumber,
  formatDay,
  formatNumber,
  niceCeiling,
  smoothPath,
} from './analytics-ui';
import { ErrorNotice } from '../components/ErrorNotice';

type Range = 'today' | '7d' | '30d' | '90d' | 'all';
type Source = 'beekiri' | 'google';

type Kpi = { value: number; prev: number; deltaPct: number | null };

type Report = {
  source: Source;
  range: Range;
  tracking: { enabled: boolean; pageViews: boolean };
  live: number;
  generatedAt: string;
  kpis: {
    users: Kpi;
    newUsers: Kpi;
    sessions: Kpi;
    views: Kpi;
    viewsPerSession: Kpi;
    bounceRate: Kpi;
    avgDurationSec: Kpi;
    engagedSessions: Kpi;
  };
  trend: { date: string; users: number; sessions: number; views: number }[];
  pages: { path: string; views: number; users: number }[];
  landing: { path: string; sessions: number }[];
  exits: { path: string; sessions: number }[];
  sources: { name: string; sessions: number }[];
  channels: { name: string; sessions: number }[];
  countries: { code: string; users: number }[];
  devices: { key: string; users: number }[];
  browsers: { name: string; users: number }[];
  os: { name: string; users: number }[];
};

type LivePayload = {
  live: number;
  paths: { path: string; secondsAgo: number }[];
  generatedAt: string;
};

const LIVE_POLL_MS = 8_000;
const REPORT_POLL_MS = 20_000;

type GaSettings = {
  measurementId: string;
  propertyId: string;
  connected: boolean;
  clientEmail: string;
};

const RANGES: { value: Range; label: string }[] = [
  { value: 'today', label: 'Today' },
  { value: '7d', label: '7 days' },
  { value: '30d', label: '30 days' },
  { value: '90d', label: '90 days' },
  { value: 'all', label: 'All time' },
];

function pageLabel(path: string) {
  if (!path || path === '/' || path === '(not set)') return 'Home';
  return path;
}

function titleCase(key: string) {
  return key ? key[0].toUpperCase() + key.slice(1) : key;
}

function flagEmoji(code: string) {
  if (!/^[A-Z]{2}$/.test(code)) return '';
  return String.fromCodePoint(...[...code].map((c) => 127397 + c.charCodeAt(0)));
}

function countryName(code: string) {
  if (!code || code === 'Unknown' || code === '(not set)') return 'Not detected';
  if (!/^[A-Z]{2}$/.test(code)) return code;
  try {
    return new Intl.DisplayNames(['en'], { type: 'region' }).of(code) || code;
  } catch {
    return code;
  }
}

function formatDuration(sec: number) {
  if (!sec) return '0s';
  const m = Math.floor(sec / 60);
  const s = Math.round(sec % 60);
  if (m >= 60) return `${Math.floor(m / 60)}h ${m % 60}m`;
  if (m) return `${m}m ${s}s`;
  return `${s}s`;
}

function formatKpi(key: keyof Report['kpis'], value: number) {
  if (key === 'bounceRate') return `${value}%`;
  if (key === 'avgDurationSec') return formatDuration(value);
  if (key === 'viewsPerSession') return value.toFixed(1);
  return Intl.NumberFormat('en-GB').format(value);
}

type LiveSample = { at: number; users: number };

const LIVE_WINDOW_MS = 30 * 60_000;
const LIVE_STEP_MS = 60_000;
/** One point per minute for the last 30 minutes; carry forward last known live count. */
function minuteSeries(samples: LiveSample[], now = Date.now()): LiveSample[] {
  const start = now - LIVE_WINDOW_MS;
  const sorted = [...samples].sort((a, b) => a.at - b.at);
  let si = 0;
  let last = 0;
  const out: LiveSample[] = [];
  for (let i = 0; i <= 30; i++) {
    const at = start + i * LIVE_STEP_MS;
    while (si < sorted.length && sorted[si]!.at <= at) {
      last = sorted[si]!.users;
      si += 1;
    }
    out.push({ at, users: last });
  }
  return out;
}

type TrendMetric = 'users' | 'sessions' | 'views';

const TREND_METRICS: { key: TrendMetric; label: string }[] = [
  { key: 'users', label: 'Users' },
  { key: 'sessions', label: 'Sessions' },
  { key: 'views', label: 'Views' },
];

/** Traffic over the selected range — area line with gridlines and a hover readout. */
function TrendChart({ trend, metric }: { trend: Report['trend']; metric: TrendMetric }) {
  const [hover, setHover] = useState<number | null>(null);
  const w = 960;
  const h = 260;
  const pad = { t: 16, r: 16, b: 30, l: 44 };
  const innerW = w - pad.l - pad.r;
  const innerH = h - pad.t - pad.b;
  const values = trend.map((p) => p[metric]);
  const max = niceCeiling(Math.max(1, ...values));
  const n = trend.length;
  const x = (i: number) => pad.l + (n > 1 ? (innerW * i) / (n - 1) : innerW / 2);
  const y = (v: number) => pad.t + innerH - (v / max) * innerH;
  const pts = values.map((v, i) => ({ x: x(i), y: y(v) }));
  const line = smoothPath(pts);
  const area = line ? `${line} L${x(n - 1)} ${y(0)} L${x(0)} ${y(0)} Z` : '';
  const yTicks = [0, 0.25, 0.5, 0.75, 1].map((f) => Math.round(max * f));
  const labelEvery = Math.max(1, Math.ceil(n / 7));
  const total = values.reduce((s, v) => s + v, 0);
  const hovered = hover !== null ? trend[hover] : null;

  if (n < 2) {
    return <p className="bk-an__empty bk-an-trend__empty">Not enough days in this range to draw a trend yet.</p>;
  }

  return (
    <div className="bk-an-trend__plot">
      <svg
        className="bk-an__svg bk-an-trend__svg"
        viewBox={`0 0 ${w} ${h}`}
        preserveAspectRatio="none"
        role="img"
        aria-label={`${TREND_METRICS.find((m) => m.key === metric)?.label} per day, ${formatNumber(total)} total`}
        onMouseMove={(e) => {
          const r = e.currentTarget.getBoundingClientRect();
          const px = ((e.clientX - r.left) / r.width) * w;
          const i = Math.round(((px - pad.l) / innerW) * (n - 1));
          setHover(Math.min(n - 1, Math.max(0, i)));
        }}
        onMouseLeave={() => setHover(null)}
      >
        {yTicks.map((tick) => (
          <g key={tick}>
            <line x1={pad.l} x2={w - pad.r} y1={y(tick)} y2={y(tick)} stroke="#f0f0f1" strokeWidth="1" vectorEffect="non-scaling-stroke" />
            <text x={pad.l - 10} y={y(tick) + 4} textAnchor="end" fontSize="11" fill="#8c8f94">
              {compactNumber(tick)}
            </text>
          </g>
        ))}
        <defs>
          <linearGradient id="bk-an-trend-fill" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#006199" stopOpacity="0.22" />
            <stop offset="100%" stopColor="#006199" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={area} fill="url(#bk-an-trend-fill)" />
        <path d={line} fill="none" stroke="#006199" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
        {trend.map((p, i) =>
          i % labelEvery === 0 || i === n - 1 ? (
            <text key={p.date} x={x(i)} y={h - 8} textAnchor={i === n - 1 ? 'end' : i === 0 ? 'start' : 'middle'} fontSize="11" fill="#8c8f94">
              {formatDay(p.date)}
            </text>
          ) : null,
        )}
        {hover !== null ? (
          <g>
            <line x1={x(hover)} x2={x(hover)} y1={pad.t} y2={pad.t + innerH} stroke="#c3c4c7" strokeDasharray="3 3" vectorEffect="non-scaling-stroke" />
            <circle cx={x(hover)} cy={y(values[hover]!)} r="5" fill="#fff" stroke="#006199" strokeWidth="2.5" vectorEffect="non-scaling-stroke" />
          </g>
        ) : null}
      </svg>
      {hovered ? (
        <div
          className="bk-an-trend__tip"
          style={{ left: `${(x(hover!) / w) * 100}%` }}
          data-side={hover! > n / 2 ? 'left' : 'right'}
        >
          <span>{formatDay(hovered.date)}</span>
          <strong>{formatNumber(hovered[metric])}</strong>
          <em>{TREND_METRICS.find((m) => m.key === metric)?.label.toLowerCase()}</em>
        </div>
      ) : null}
    </div>
  );
}

const EXCLUDE_INTERNAL_KEY = 'beekiri.analytics.excludeInternal';

function isInternalTraffic(value: string) {
  const v = value.toLowerCase();
  return (
    v.includes('localhost') ||
    v.includes('127.0.0.1') ||
    v.includes('0.0.0.0') ||
    v.includes('auto-draft') ||
    v.includes('/draft') ||
    v.includes('preview=true') ||
    /[?&]preview=/.test(v)
  );
}

function liveAgo(secondsAgo: number) {
  if (secondsAgo < 5) return 'just now';
  if (secondsAgo < 60) return `${secondsAgo}s ago`;
  return `${Math.floor(secondsAgo / 60)}m ago`;
}

const KPI_ORDER: Array<{ key: keyof Report['kpis']; label: string }> = [
  { key: 'users', label: 'Users' },
  { key: 'newUsers', label: 'New users' },
  { key: 'sessions', label: 'Sessions' },
  { key: 'views', label: 'Views' },
  { key: 'viewsPerSession', label: 'Views per session' },
  { key: 'bounceRate', label: 'Bounce rate' },
  { key: 'avgDurationSec', label: 'Avg. session duration' },
  { key: 'engagedSessions', label: 'Engaged sessions' },
];

export function AnalyticsPage() {
  const href = useAdminHref();
  const [range, setRange] = useState<Range>('30d');
  const [source, setSource] = useState<Source>('beekiri');
  const [report, setReport] = useState<Report | null>(null);
  const [live, setLive] = useState(0);
  const [livePaths, setLivePaths] = useState<LivePayload['paths']>([]);
  const [liveSeries, setLiveSeries] = useState<LiveSample[]>([]);
  const [updatedAt, setUpdatedAt] = useState<string | null>(null);
  const [ga, setGa] = useState<GaSettings | null>(null);
  const [connectOpen, setConnectOpen] = useState(false);
  const [form, setForm] = useState({ measurementId: '', propertyId: '', serviceAccountJson: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [trendMetric, setTrendMetric] = useState<TrendMetric>('users');
  const [excludeInternal, setExcludeInternal] = useState(() => {
    try {
      return window.localStorage.getItem(EXCLUDE_INTERNAL_KEY) === '1';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    api<GaSettings>('/api/analytics/settings')
      .then((s) => {
        setGa(s);
        setForm({
          measurementId: s.measurementId,
          propertyId: s.propertyId,
          serviceAccountJson: '',
        });
      })
      .catch((e) => setError(e instanceof ApiError ? e.message : 'Could not load Analytics.'));
  }, []);

  useEffect(() => {
    let cancelled = false;
    const loadReport = (soft: boolean) => {
      if (!soft) setError(null);
      api<Report>(`/api/analytics/report?range=${range}&source=${source}`)
        .then((data) => {
          if (cancelled) return;
          setReport(data);
          setLive(data.live ?? 0);
          setUpdatedAt(data.generatedAt);
          setLiveSeries((prev) =>
            prev.length ? prev : [{ at: Date.now(), users: data.live ?? 0 }],
          );
        })
        .catch((e) => {
          if (cancelled || soft) return;
          setReport(null);
          setError(e instanceof ApiError ? e.message : 'Could not load analytics.');
        });
    };
    loadReport(false);
    const onTick = () => {
      if (document.visibilityState === 'hidden') return;
      loadReport(true);
    };
    const id = window.setInterval(onTick, REPORT_POLL_MS);
    document.addEventListener('visibilitychange', onTick);
    return () => {
      cancelled = true;
      window.clearInterval(id);
      document.removeEventListener('visibilitychange', onTick);
    };
  }, [range, source]);

  useEffect(() => {
    let cancelled = false;
    const loadLive = () => {
      if (document.visibilityState === 'hidden') return;
      api<LivePayload>('/api/analytics/live')
        .then((data) => {
          if (cancelled) return;
          const at = Date.now();
          setLive(data.live);
          setLivePaths(data.paths);
          setUpdatedAt(data.generatedAt);
          setLiveSeries((prev) => {
            const next = [...prev, { at, users: data.live }];
            const cutoff = at - LIVE_WINDOW_MS;
            return next.filter((s) => s.at >= cutoff);
          });
        })
        .catch(() => {
          /* keep last live count */
        });
    };
    loadLive();
    const id = window.setInterval(loadLive, LIVE_POLL_MS);
    document.addEventListener('visibilitychange', loadLive);
    return () => {
      cancelled = true;
      window.clearInterval(id);
      document.removeEventListener('visibilitychange', loadLive);
    };
  }, []);

  const saveConnect = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const saved = await api<GaSettings>('/api/analytics/settings', {
        method: 'PATCH',
        json: form,
      });
      setGa(saved);
      setForm((f) => ({ ...f, serviceAccountJson: '' }));
      setNotice('Google Analytics connection saved.');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Save failed');
    } finally {
      setBusy(false);
    }
  };

  const trackingOff = report && (!report.tracking.enabled || !report.tracking.pageViews);

  const kpis = useMemo(() => report?.kpis, [report]);

  const filtered = useMemo(() => {
    if (!report) return null;
    const keepPath = (path: string) => !excludeInternal || !isInternalTraffic(path);
    const keepName = (name: string) => !excludeInternal || !isInternalTraffic(name);
    return {
      pages: report.pages.filter((r) => keepPath(r.path)),
      landing: report.landing.filter((r) => keepPath(r.path)),
      exits: (report.exits ?? []).filter((r) => keepPath(r.path)),
      channels: report.channels ?? [],
      sources: report.sources.filter((r) => keepName(r.name)),
      countries: report.countries,
      browsers: report.browsers ?? [],
      os: report.os ?? [],
      devices: report.devices,
      livePaths: livePaths.filter((r) => keepPath(r.path)),
    };
  }, [report, livePaths, excludeInternal]);

  function toggleExcludeInternal() {
    setExcludeInternal((prev) => {
      const next = !prev;
      try {
        window.localStorage.setItem(EXCLUDE_INTERNAL_KEY, next ? '1' : '0');
      } catch {
        /* ignore */
      }
      return next;
    });
  }

  const rangeLabel = RANGES.find((r) => r.value === range)?.label ?? '';
  const compareLabel =
    range === 'all' ? '' : range === 'today' ? 'vs yesterday' : `vs previous ${rangeLabel}`;
  const trendValues = (key: TrendMetric) => (report?.trend ?? []).map((p) => p[key]);
  const liveMinutes = minuteSeries(liveSeries).map((p) => p.users);

  return (
    <div className="bk-an">
      <PageHeader
        title="Analytics"
        actions={
          <div className="bk-an__tools">
            <div className="bk-tabs is-inline" role="tablist" aria-label="Data source">
              <button
                type="button"
                role="tab"
                aria-selected={source === 'beekiri'}
                className={`bk-tabs__item${source === 'beekiri' ? ' is-active' : ''}`}
                onClick={() => setSource('beekiri')}
              >
                Beekiri
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={source === 'google'}
                className={`bk-tabs__item${source === 'google' ? ' is-active' : ''}`}
                onClick={() => setSource('google')}
                disabled={!ga?.connected}
                title={ga?.connected ? 'Google Analytics 4' : 'Connect Google Analytics first'}
              >
                Google Analytics
              </button>
            </div>
            <div className="bk-tabs is-inline" role="tablist" aria-label="Date range">
              {RANGES.map((r) => (
                <button
                  key={r.value}
                  type="button"
                  role="tab"
                  aria-selected={range === r.value}
                  className={`bk-tabs__item${range === r.value ? ' is-active' : ''}`}
                  onClick={() => setRange(r.value)}
                >
                  {r.label}
                </button>
              ))}
            </div>
            <button type="button" className="button" onClick={() => setConnectOpen((open) => !open)}>
              {ga?.connected ? 'Google connection' : 'Connect Google Analytics'}
            </button>
          </div>
        }
      />

      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}

      {trackingOff && source === 'beekiri' ? (
        <p className="bk-an__banner">
          Beekiri records visits only after a visitor accepts analytics cookies.{' '}
          <Link to={href('analytics/cookies')}>Turn on BeeCookies</Link> to collect this report.
        </p>
      ) : null}

      {connectOpen ? (
        <form className="bk-an-connect" onSubmit={(e) => void saveConnect(e)}>
          <h2>Google Analytics</h2>
          <p>
            Optional. Add a GA4 measurement ID to send consented visits to Google, and a property
            plus service account if you want Google’s numbers in this report.
          </p>
          <table className="form-table">
            <tbody>
              <tr>
                <th scope="row">
                  <label htmlFor="ga-mid">Measurement ID</label>
                </th>
                <td>
                  <input
                    id="ga-mid"
                    className="regular-text"
                    placeholder="G-XXXXXXXX"
                    value={form.measurementId}
                    onChange={(e) => setForm({ ...form, measurementId: e.target.value })}
                  />
                  <p className="description">
                    Loaded on the public site only after analytics cookies are accepted.
                  </p>
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="ga-prop">Property ID</label>
                </th>
                <td>
                  <input
                    id="ga-prop"
                    className="regular-text"
                    placeholder="123456789"
                    value={form.propertyId}
                    onChange={(e) => setForm({ ...form, propertyId: e.target.value })}
                  />
                  <p className="description">Numeric GA4 property ID, not the G- measurement ID.</p>
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="ga-sa">Service account</label>
                </th>
                <td>
                  <textarea
                    id="ga-sa"
                    className="large-text"
                    placeholder={
                      ga?.clientEmail
                        ? `Connected as ${ga.clientEmail}. Paste a new JSON key to replace it.`
                        : 'Paste the service account JSON key'
                    }
                    value={form.serviceAccountJson}
                    onChange={(e) => setForm({ ...form, serviceAccountJson: e.target.value })}
                  />
                  <p className="description">
                    Create a service account in Google Cloud, download its JSON key, and add it as a
                    Viewer on the GA4 property. The key is stored on this site and never shown
                    again.
                  </p>
                </td>
              </tr>
            </tbody>
          </table>
          <p className="submit">
            <button type="submit" className="button button-primary" disabled={busy}>
              {busy ? 'Saving…' : 'Save connection'}
            </button>
          </p>
        </form>
      ) : null}

      {/* ── KPIs ─────────────────────────────────────────────────────── */}
      {kpis ? (
        <div className="bk-an__kpis">
          {KPI_ORDER.map(({ key, label }) => {
            const item = kpis[key];
            const delta = item.deltaPct;
            // Lower bounce rate is the good direction.
            const good = key === 'bounceRate' ? (delta ?? 0) < 0 : (delta ?? 0) > 0;
            const deltaClass =
              delta === null || delta === 0 ? 'is-flat' : good ? 'is-up' : 'is-down';
            const spark =
              key === 'users' || key === 'sessions' || key === 'views' ? trendValues(key) : null;
            return (
              <div key={key} className="bk-an__kpi">
                <div className="bk-an__kpi-top">
                  <span className="bk-an__kpi-label">{label}</span>
                  {range !== 'all' && delta !== null ? (
                    <em className={`bk-an__delta ${deltaClass}`} title={`${compareLabel}: ${formatKpi(key, item.prev)}`}>
                      {delta > 0 ? '▲' : delta < 0 ? '▼' : '•'} {Math.abs(delta)}%
                    </em>
                  ) : null}
                </div>
                <strong className="bk-an__kpi-value">{formatKpi(key, item.value)}</strong>
                <div className="bk-an__kpi-foot">
                  <span>
                    {range !== 'all'
                      ? `${compareLabel} · ${formatKpi(key, item.prev)}`
                      : 'All time'}
                  </span>
                  {spark && spark.length > 1 ? <Sparkline values={spark} /> : null}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bk-an__kpis" aria-busy>
          {KPI_ORDER.map(({ key }) => (
            <div key={key} className="bk-an__kpi is-skeleton">
              <span className="bk-an__skel" style={{ width: '40%' }} />
              <span className="bk-an__skel is-big" />
              <span className="bk-an__skel" style={{ width: '60%' }} />
            </div>
          ))}
        </div>
      )}

      {report ? (
        <>
          {/* ── Trend + Live ─────────────────────────────────────────── */}
          <div className="bk-an__row">
            <section className="bk-an-trend">
              <div className="bk-an-trend__head">
                <div>
                  <h2>Traffic</h2>
                  <p>
                    {rangeLabel}
                    {source === 'google' ? ' · Google Analytics' : ' · Beekiri'}
                  </p>
                </div>
                <div className="bk-tabs is-inline" role="tablist" aria-label="Metric">
                  {TREND_METRICS.map((m) => (
                    <button
                      key={m.key}
                      type="button"
                      role="tab"
                      aria-selected={trendMetric === m.key}
                      className={`bk-tabs__item${trendMetric === m.key ? ' is-active' : ''}`}
                      onClick={() => setTrendMetric(m.key)}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>
              <TrendChart trend={report.trend} metric={trendMetric} />
            </section>

            <aside className="bk-an-live" aria-live="polite">
              <div className="bk-an-live__head">
                <span className={`bk-an__live-dot${live > 0 ? ' is-on' : ''}`} aria-hidden />
                <span>Live</span>
                <em>last 30 min</em>
              </div>
              <strong className="bk-an-live__count">{live}</strong>
              <span className="bk-an-live__label">
                {live === 1 ? 'visitor on the site right now' : 'visitors on the site right now'}
              </span>
              <div className="bk-an-live__spark">
                <Sparkline values={liveMinutes} color="#4f7a26" height={44} />
              </div>
              <ul className="bk-an-live__pages">
                {(filtered?.livePaths ?? []).slice(0, 4).map((r, i) => (
                  <li key={`${r.path}-${i}`}>
                    <span>{pageLabel(r.path)}</span>
                    <em>{liveAgo(r.secondsAgo)}</em>
                  </li>
                ))}
                {!filtered?.livePaths.length ? (
                  <li className="is-empty">No one in the last 5 minutes.</li>
                ) : null}
              </ul>
            </aside>
          </div>

          {/* ── Breakdowns ───────────────────────────────────────────── */}
          {filtered ? (
            <div className="bk-an__pair">
              <AnalyticsRankCard
                ariaLabel="Page traffic"
                tabs={[
                  {
                    id: 'pages',
                    label: 'Pages',
                    dim: 'Page',
                    metric: 'Views',
                    noun: 'pages',
                    rows: filtered.pages.map((r) => ({
                      key: r.path,
                      label: pageLabel(r.path),
                      n: r.views,
                    })),
                  },
                  {
                    id: 'landing',
                    label: 'Landing',
                    dim: 'Page',
                    metric: 'Sessions',
                    noun: 'landing pages',
                    rows: filtered.landing.map((r) => ({
                      key: r.path,
                      label: pageLabel(r.path),
                      n: r.sessions,
                    })),
                  },
                  {
                    id: 'exits',
                    label: 'Exit pages',
                    dim: 'Page',
                    metric: 'Sessions',
                    noun: 'exit pages',
                    rows: filtered.exits.map((r) => ({
                      key: r.path,
                      label: pageLabel(r.path),
                      n: r.sessions,
                    })),
                  },
                ]}
              />

              <AnalyticsRankCard
                ariaLabel="Acquisition"
                tabs={[
                  {
                    id: 'channels',
                    label: 'Channels',
                    dim: 'Channel',
                    metric: 'Sessions',
                    noun: 'channels',
                    rows: filtered.channels.map((r) => ({
                      key: r.name,
                      label: r.name,
                      n: r.sessions,
                    })),
                  },
                  {
                    id: 'referrers',
                    label: 'Referrers',
                    dim: 'Referrer',
                    metric: 'Sessions',
                    noun: 'referrers',
                    rows: filtered.sources.map((r) => ({
                      key: r.name,
                      label: r.name,
                      n: r.sessions,
                    })),
                  },
                ]}
              />

              <AnalyticsRankCard
                ariaLabel="Audience"
                tabs={[
                  {
                    id: 'country',
                    label: 'Country',
                    dim: 'Country',
                    metric: 'Users',
                    noun: 'countries',
                    rows: filtered.countries.map((r) => ({
                      key: r.code,
                      label: `${flagEmoji(r.code) ? `${flagEmoji(r.code)} ` : ''}${countryName(r.code)}`,
                      n: r.users,
                    })),
                  },
                  {
                    id: 'device',
                    label: 'Device',
                    dim: 'Device',
                    metric: 'Users',
                    noun: 'devices',
                    rows: filtered.devices.map((r) => ({
                      key: r.key,
                      label: titleCase(r.key),
                      n: r.users,
                    })),
                  },
                  {
                    id: 'browser',
                    label: 'Browser',
                    dim: 'Browser',
                    metric: 'Users',
                    noun: 'browsers',
                    rows: filtered.browsers.map((r) => ({
                      key: r.name,
                      label: r.name,
                      n: r.users,
                    })),
                  },
                  {
                    id: 'os',
                    label: 'OS',
                    dim: 'OS',
                    metric: 'Users',
                    noun: 'operating systems',
                    rows: filtered.os.map((r) => ({
                      key: r.name,
                      label: r.name,
                      n: r.users,
                    })),
                  },
                ]}
              />
            </div>
          ) : null}

          <div className="bk-an__foot">
            <label className="bk-an__exclude">
              <input type="checkbox" checked={excludeInternal} onChange={toggleExcludeInternal} />
              <span>Exclude internal traffic (localhost, auto-draft pages)</span>
            </label>
            {updatedAt ? (
              <span className="bk-an__updated">
                Updated {formatRelative(updatedAt)} · refreshes automatically
              </span>
            ) : null}
          </div>
        </>
      ) : null}
    </div>
  );
}
