import { useCallback, useEffect, useState } from 'react';
import { ArrowClockwise } from '@phosphor-icons/react';
import { useSearchParams } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import { confirmDialog } from '../components/ConfirmDialog';
import {
  byDay,
  ListPager,
  PeriodTabs,
  timeOf,
  type HistoryPeriod,
} from '../components/HistoryControls';
import { notifyConnectorChanged } from '../lib/admin-events';
import { formatMoney } from '../lib/money';
import './beequeen-account.css';

type Money = { amount: number; label: string };

type Account =
  | { connected: false }
  | {
      connected: true;
      currency: string;
      paymentMethod: 'stripe' | 'paypal' | 'manual';
      balance: Money;
      month: { month: string; cost: Money; runs: number };
      spent: Money;
      paid: Money;
      topups: { id: string; amount: Money }[];
      customTopup: { min: number; max: number };
      orders: {
        id: string;
        amount: Money;
        status: string;
        createdAt: string | null;
        decidedAt: string | null;
      }[];
      history: {
        id: string;
        kind: string;
        description: string | null;
        model: string | null;
        runId: string | null;
        source: string | null;
        amount: number;
        createdAt: string;
      }[];
    };

type Tab = 'usage' | 'topups';

/** Spending, one row per message, for a period and a page (paged on 996Agency). */
type History = {
  period: HistoryPeriod;
  page: number;
  pages: number;
  perPage: number;
  total: number;
  spent: Money;
  messages: {
    id: string;
    createdAt: string;
    cost: Money;
    calls: number;
    model: string | null;
    test: boolean;
  }[];
};

const PERIOD_SPENT: Record<HistoryPeriod, string> = {
  today: 'Spent today',
  week: 'Spent this week',
  month: 'Spent this month',
  all: 'Spent in total',
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

const when = (iso: string) =>
  new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });

/** Model id → short name ("claude-opus-5-5" → "Opus 5.5"). */
function modelName(id: string | null) {
  const m = id?.match(/^claude-([a-z]+)-(\d+)-(\d+)/);
  return m ? `${m[1][0].toUpperCase()}${m[1].slice(1)} ${m[2]}.${m[3]}` : (id ?? '');
}

const TOPUP_STATUS: Record<string, string> = {
  pending: 'Waiting for payment',
  approved: 'Added',
  rejected: 'Declined',
};

/** This site's prepaid Beekiri balance on 996Agency: what's left, adding money, what was spent and every message's cost. */
export function BeeQueenAccount({ reloadKey }: { reloadKey: number }) {
  const [account, setAccount] = useState<Account | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [custom, setCustom] = useState('');
  const [tab, setTab] = useState<Tab>('usage');
  const [params, setParams] = useSearchParams();
  const [period, setPeriod] = useState<HistoryPeriod>('month');
  const [page, setPage] = useState(1);
  const [history, setHistory] = useState<History | null>(null);
  const [historyBusy, setHistoryBusy] = useState(false);
  const [historyError, setHistoryError] = useState<string | null>(null);

  const loadHistory = useCallback(async (p: HistoryPeriod, n: number) => {
    setHistoryBusy(true);
    setHistoryError(null);
    try {
      setHistory(await api<History>(`/api/connector/beequeen/history?period=${p}&page=${n}`));
    } catch (e) {
      setHistoryError(formatError(e));
    } finally {
      setHistoryBusy(false);
    }
  }, []);

  useEffect(() => {
    void loadHistory(period, page);
  }, [loadHistory, period, page, reloadKey]);

  const load = useCallback(async () => {
    setError(null);
    setRefreshing(true);
    try {
      setAccount(await api<Account>('/api/connector/beequeen/account'));
    } catch (e) {
      setAccount(null);
      setError(formatError(e));
    } finally {
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load, reloadKey]);

  // Back from Stripe / PayPal: say what happened, then tidy the address bar.
  useEffect(() => {
    const outcome = params.get('topup');
    if (!outcome) return;
    if (outcome === 'success') setNotice('Payment received — your balance is topped up.');
    else if (outcome === 'cancelled') setNotice('Checkout cancelled. Nothing was charged.');
    else
      setNotice(
        'We could not confirm the payment yet. If you paid, your balance is topped up within a few minutes — refresh this page.',
      );
    const next = new URLSearchParams(params);
    next.delete('topup');
    setParams(next, { replace: true });
    notifyConnectorChanged();
  }, [params, setParams]);

  const topup = async (
    choice: { pack: string } | { amount: number },
    label: string,
    manual: boolean,
  ) => {
    if (manual) {
      const ok = await confirmDialog({
        title: `Add ${label} to the Beekiri balance?`,
        message:
          '996Agency will contact you to arrange payment. The money is added here as soon as it is paid.',
        confirmLabel: 'Send request',
      });
      if (!ok) return;
    }
    setBusy('pack' in choice ? choice.pack : 'custom');
    setError(null);
    setNotice(null);
    try {
      const res = await api<{
        status: 'checkout' | 'pending';
        checkoutUrl: string | null;
        account: Account;
      }>('/api/connector/beequeen/topup', {
        method: 'POST',
        json: choice,
      });
      if (res.status === 'checkout' && res.checkoutUrl) {
        window.location.assign(res.checkoutUrl);
        return;
      }
      setAccount(res.account);
      setCustom('');
      setNotice(`Request sent. ${label} is added once 996Agency confirms the payment.`);
      setTab('topups');
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(null);
    }
  };

  const head = (
    <div className="bk-panel__head">
      <h2 className="bk-panel__title">Balance</h2>
      <button
        type="button"
        className="button bk-bqa__refresh"
        disabled={refreshing}
        onClick={() => void load()}
      >
        <ArrowClockwise size={14} aria-hidden className={refreshing ? 'is-spinning' : undefined} />
        <span>Refresh</span>
      </button>
    </div>
  );

  const message = (text: string, isError = false) => (
    <section className="bk-panel bk-bqa">
      {head}
      <div className="bk-panel__body">
        <p className={isError ? 'bk-bqa__error' : 'bk-muted'} style={{ margin: 0 }}>
          {text}
        </p>
      </div>
    </section>
  );

  if (error && !account) return message(error, true);
  if (!account) return message('Loading balance…');
  if (!account.connected)
    return message('The balance appears here once this site is connected to 996Agency.');
  if (!('topups' in account) || typeof account.balance !== 'object')
    return message('996Agency is still on the older billing. Refresh after it has been updated.');

  const money = (v: number, fine = false) => formatMoney(v, account.currency, fine);
  const added = account.orders;
  const manual = account.paymentMethod === 'manual';
  const empty = account.balance.amount <= 0;
  const { min, max } = account.customTopup;
  const customAmount = Number(custom);
  const customOk = Number.isInteger(customAmount) && customAmount >= min && customAmount <= max;

  return (
    <section className="bk-panel bk-bqa">
      {head}
      <div className="bk-panel__body bk-bqa__body">
        {error ? <p className="bk-bqa__error">{error}</p> : null}
        {notice ? <p className="bk-bqa__how">{notice}</p> : null}

        <div className="bk-bqa__stats">
          <div className={`bk-bqa__stat is-main${empty ? ' is-due' : ''}`}>
            <p className="bk-bqa__stat-label">
              Balance
              {empty ? <span className="bk-bqa__flag is-due">Empty</span> : null}
            </p>
            <p className="bk-bqa__stat-value">{money(account.balance.amount)}</p>
            <p className="bk-bqa__stat-sub">left to spend on Beekiri</p>
            <p className="bk-bqa__stat-foot">
              {empty ? 'Beekiri pauses until you add money' : 'Use it whenever you need'}
            </p>
          </div>
          <div className="bk-bqa__stat">
            <p className="bk-bqa__stat-label">Spent this month</p>
            <p className="bk-bqa__stat-value">{money(account.month.cost.amount)}</p>
            <p className="bk-bqa__stat-sub">
              {account.month.runs.toLocaleString()} message{account.month.runs === 1 ? '' : 's'}
            </p>
            <p className="bk-bqa__stat-foot">&nbsp;</p>
          </div>
          <div className="bk-bqa__stat">
            <p className="bk-bqa__stat-label">Spent in total</p>
            <p className="bk-bqa__stat-value">{money(account.spent.amount)}</p>
            <p className="bk-bqa__stat-sub">{money(account.paid.amount)} added in total</p>
            <p className="bk-bqa__stat-foot">&nbsp;</p>
          </div>
        </div>

        <p className="bk-bqa__how">
          <strong>Prepaid.</strong> Add money first, then each Beekiri message takes only the Claude
          work it does — a small edit costs cents, a full page more. The balance never expires and
          there is no subscription.
        </p>

        <div className="bk-bqa__topup">
          <p className="bk-bqa__topup-title">Add money</p>
          <div className="bk-bqa__topup-row">
            {account.topups.map((t) => (
              <button
                key={t.id}
                type="button"
                className="button bk-bqa__topup-amount"
                disabled={busy !== null}
                onClick={() => void topup({ pack: t.id }, money(t.amount.amount), manual)}
              >
                {busy === t.id ? 'Opening…' : money(t.amount.amount)}
              </button>
            ))}
            <form
              className="bk-bqa__topup-custom"
              onSubmit={(e) => {
                e.preventDefault();
                if (customOk) void topup({ amount: customAmount }, money(customAmount), manual);
              }}
            >
              <label className="screen-reader-text" htmlFor="bqa-custom">
                Other amount
              </label>
              <span className="bk-bqa__topup-currency" aria-hidden>
                $
              </span>
              <input
                id="bqa-custom"
                type="number"
                inputMode="numeric"
                min={min}
                max={max}
                step={1}
                placeholder="Other amount"
                value={custom}
                onChange={(e) => setCustom(e.target.value)}
              />
              <button
                type="submit"
                className="button button-primary"
                disabled={busy !== null || !customOk}
              >
                {busy === 'custom' ? 'Opening…' : 'Add'}
              </button>
            </form>
          </div>
          <p className="bk-muted bk-bqa__fine">
            {`Other amount: whole dollars from ${money(min)} to ${money(max)}. `}
            {manual
              ? '996Agency confirms each top-up by hand for now; the money is added as soon as it is paid.'
              : 'Paid securely by card through 996Agency. The money is added as soon as the payment goes through.'}
          </p>
        </div>

        <div className="bk-bqa__tabs-card">
          <div className="bk-tabs is-flush" role="tablist">
            {(
              [
                ['usage', 'Spent', null],
                ['topups', 'Added', added.length || null],
              ] as [Tab, string, number | null][]
            ).map(([id, label, count]) => (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={tab === id}
                className={`bk-tabs__item${tab === id ? ' is-active' : ''}`}
                onClick={() => setTab(id)}
              >
                {label}
                {count !== null ? <span className="bk-tabs__count">{count}</span> : null}
              </button>
            ))}
          </div>

          {tab === 'usage' ? (
            <>
              <PeriodTabs
                value={period}
                label="Spending period"
                onChange={(p) => {
                  setPeriod(p);
                  setPage(1);
                }}
              />
              <div className="bk-history__summary" aria-live="polite">
                <span>{PERIOD_SPENT[period]}</span>
                <span>
                  <strong>{history ? money(history.spent.amount) : '…'}</strong>
                  {history
                    ? ` · ${history.total.toLocaleString()} message${history.total === 1 ? '' : 's'}`
                    : ''}
                </span>
              </div>
              {historyError ? (
                <p className="bk-history__empty bk-bqa__error">{historyError}</p>
              ) : !history ? (
                <p className="bk-history__empty">Loading…</p>
              ) : history.messages.length === 0 ? (
                <p className="bk-history__empty">
                  No messages {period === 'all' ? 'yet' : 'in this period'}.
                </p>
              ) : (
                <div className="bk-bqa__table-wrap" aria-busy={historyBusy}>
                  {byDay(history.messages, (m) => m.createdAt).map((group) => (
                    <div key={group.day}>
                      <p className="bk-history__day">{group.day}</p>
                      <table className="bk-bqa__table bk-history__table">
                        <colgroup>
                          <col className="bk-history__col-time" />
                          <col />
                          <col className="bk-history__col-cost" />
                        </colgroup>
                        <thead className="screen-reader-text">
                          <tr>
                            <th scope="col">Time</th>
                            <th scope="col">Message</th>
                            <th scope="col">Cost</th>
                          </tr>
                        </thead>
                        <tbody>
                          {group.items.map((r) => (
                            <tr key={r.id}>
                              <td className="bk-bqa__date">{timeOf(r.createdAt)}</td>
                              <td>
                                <span className="bk-bqa__what">Beekiri message</span>
                                <span className="bk-bqa__sub bk-bqa__sub--flat">
                                  {[
                                    modelName(r.model),
                                    r.calls > 1 ? `${r.calls} Claude calls` : '',
                                    r.test ? 'test run on Claude Code' : '',
                                  ]
                                    .filter(Boolean)
                                    .join(' · ')}
                                </span>
                              </td>
                              <td className="is-num">{money(r.cost.amount, true)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ))}
                </div>
              )}
              {history ? (
                <ListPager
                  page={history.page}
                  pages={history.pages}
                  total={history.total}
                  perPage={history.perPage}
                  noun="messages"
                  busy={historyBusy}
                  onPage={setPage}
                />
              ) : null}
            </>
          ) : null}

          {tab === 'topups' ? (
            added.length === 0 ? (
              <div className="bk-bqa__pane">
                <p className="bk-muted" style={{ margin: 0 }}>
                  No money added yet.
                </p>
              </div>
            ) : (
              <ul className="bk-bqa__requests">
                {added.map((o) => (
                  <li key={o.id}>
                    <span className="bk-bqa__req-pack">
                      {money(o.amount.amount)}
                      <span className="bk-bqa__sub">{o.createdAt ? when(o.createdAt) : ''}</span>
                    </span>
                    <span className={`bk-bqa__status is-${o.status}`}>
                      {TOPUP_STATUS[o.status] ?? o.status}
                    </span>
                  </li>
                ))}
              </ul>
            )
          ) : null}
        </div>
      </div>
    </section>
  );
}
