import { ChangeEvent, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { api, ApiError, getCsrfToken } from '../api/client';
import { confirmDialog } from '../components/ConfirmDialog';
import './migration-panel.css';

type ThemeInfo = { slug: string; name: string; version: string; builtin: boolean };
type RemoteInfo = {
  name: string;
  url: string;
  version: string;
  migrations: string[];
  activeTheme: string;
  themes: ThemeInfo[];
  allowPull: boolean;
  allowPush: boolean;
  busy: boolean;
  environment?: EnvName;
};
type EnvName = 'local' | 'staging' | 'production';
type Connection = { id: string; label: string; url: string; addedAt: string; lastUsedAt?: string };
type Backup = { id: string; label: string; createdAt: string; size: number; parts: string[] };
type StepState = 'waiting' | 'active' | 'done' | 'error';
type Job = {
  id: string;
  kind: string;
  title: string;
  state: 'running' | 'done' | 'error' | 'cancelled';
  percent: number;
  steps: { key: string; label: string; state: StepState }[];
  detail: string;
  log: { at: string; text: string }[];
  startedAt: string;
  finishedAt?: string;
  error?: string;
  result?: {
    lines: string[];
    downloadId?: string;
    downloadName?: string;
    size?: number;
    backupId?: string;
    signedOut?: boolean;
    url?: string;
  };
  cancellable: boolean;
};
type Overview = {
  siteUrl: string;
  connectionInfo: string;
  allowPull: boolean;
  allowPush: boolean;
  environment: { value: EnvName; chosen: EnvName | null; detected: EnvName };
  connections: Connection[];
  backups: Backup[];
  job: Job | null;
  site: { name: string; version: string; activeTheme: string; themes: ThemeInfo[] };
};
type Manifest = {
  createdAt: string;
  purpose: string;
  source: { url: string; name: string; version: string; activeTheme: string };
  database: { tables: number; rows: number; kept: string[] } | null;
  themes: { slug: string; name: string; version: string; files: number; fieldGroups: number }[];
  media: { files: number; bytes: number; mirror: boolean } | null;
};
type Mode = 'push' | 'pull' | 'export' | 'import';
type Scope = 'theme' | 'database';
type Pair = { find: string; replace: string };
type KeepGroup = 'analytics' | 'orders' | 'activity';

const MODES: { id: Mode; label: string; hint: string }[] = [
  { id: 'push', label: 'Push', hint: 'Send this site to another site' },
  { id: 'pull', label: 'Pull', hint: 'Bring another site here' },
  { id: 'export', label: 'Export file', hint: 'Download a migration file' },
  { id: 'import', label: 'Import file', hint: 'Upload a migration file' },
];

const KEEP: { id: KeepGroup; label: string; hint: string }[] = [
  { id: 'analytics', label: 'Analytics, heatmaps and cookie consents', hint: 'Visits and clicks recorded on that site' },
  { id: 'orders', label: 'Orders, customers and carts', hint: 'Shop orders placed on that site' },
  { id: 'activity', label: 'Activity log', hint: 'Who changed what on that site' },
];

const CHUNK = 4 * 1024 * 1024;

const ENV_LABEL: Record<EnvName, string> = { local: 'Local', staging: 'Staging', production: 'Production' };

function errorMessage(e: unknown, fallback: string) {
  return e instanceof ApiError || e instanceof Error ? e.message || fallback : fallback;
}

function bytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`;
  return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

function when(iso: string) {
  try {
    return new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
  } catch {
    return iso;
  }
}

function hostOf(url: string) {
  try {
    return new URL(url).host;
  } catch {
    return url;
  }
}

function duration(job: Job) {
  if (!job.finishedAt) return '';
  const s = Math.max(1, Math.round((Date.parse(job.finishedAt) - Date.parse(job.startedAt)) / 1000));
  return s < 60 ? `${s}s` : `${Math.floor(s / 60)}m ${s % 60}s`;
}

/** `//old.host` → `//new.host`, plus the protocol when only one side uses https. */
function suggestedPairs(from: string, to: string): Pair[] {
  try {
    const a = new URL(from);
    const b = new URL(to);
    if (a.origin === b.origin) return [];
    const pairs: Pair[] = [{ find: `//${a.host}`, replace: `//${b.host}` }];
    if (a.protocol !== b.protocol) pairs.push({ find: `${a.protocol}//${b.host}`, replace: `${b.protocol}//${b.host}` });
    return pairs;
  } catch {
    return [];
  }
}

function Switch({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <label className={`bk-mig-switch${disabled ? ' is-disabled' : ''}`}>
      <input type="checkbox" role="switch" checked={checked} disabled={disabled} aria-label={label} onChange={(e) => onChange(e.target.checked)} />
      <span className="bk-mig-switch__track" aria-hidden>
        <span className="bk-mig-switch__knob" />
      </span>
    </label>
  );
}

function Check({ checked, onChange, label, hint, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; hint?: string; disabled?: boolean }) {
  return (
    <label className="bk-check bk-mig__check">
      <input type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <span className="bk-check__box" aria-hidden />
      <span className="bk-check__label">
        {label}
        {hint ? <span className="bk-mig__hint">{hint}</span> : null}
      </span>
    </label>
  );
}

const ICON_CHECK = (
  <svg viewBox="0 0 16 16" width="12" height="12" aria-hidden>
    <path d="M3.5 8.5l3 3 6-7" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
const ICON_X = (
  <svg viewBox="0 0 16 16" width="12" height="12" aria-hidden>
    <path d="M4.5 4.5l7 7m0-7l-7 7" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

function JobView({
  job,
  signedOut,
  onCancel,
  onClose,
  targetUrl,
}: {
  job: Job;
  signedOut: boolean;
  onCancel: () => void;
  onClose: () => void;
  targetUrl: string | null;
}) {
  const [showLog, setShowLog] = useState(false);
  const running = job.state === 'running';
  const lastLog = useRef<HTMLOListElement>(null);
  useEffect(() => {
    if (showLog && lastLog.current) lastLog.current.scrollTop = lastLog.current.scrollHeight;
  }, [showLog, job.log.length]);

  return (
    <div className={`bk-mig-job is-${job.state}`}>
      <div className="bk-mig-job__head">
        <div>
          <h3 className="bk-mig-job__title">{job.title}</h3>
          <p className="bk-mig-job__detail" aria-live="polite">
            {running ? job.detail : job.state === 'done' ? `Finished in ${duration(job)}` : job.state === 'cancelled' ? 'Cancelled' : 'Stopped'}
          </p>
        </div>
        <span className="bk-mig-job__pct">{job.percent}%</span>
      </div>
      <div
        className="bk-mig-job__bar"
        role="progressbar"
        aria-label={job.title}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={job.percent}
      >
        <span style={{ width: `${job.percent}%` }} />
      </div>
      <ol className="bk-mig-steps">
        {job.steps.map((s) => (
          <li key={s.key} className={`bk-mig-steps__item is-${s.state}`}>
            <span className="bk-mig-steps__icon" aria-hidden>
              {s.state === 'done' ? ICON_CHECK : s.state === 'error' ? ICON_X : null}
            </span>
            <span>{s.label}</span>
          </li>
        ))}
      </ol>

      {job.state === 'done' && job.result ? (
        <div className="beekiri-notice is-success bk-mig-job__result">
          {job.result.lines.length ? (
            <ul>
              {job.result.lines.map((line) => (
                <li key={line}>{line}</li>
              ))}
            </ul>
          ) : (
            <p>All done.</p>
          )}
        </div>
      ) : null}
      {signedOut ? (
        <div className="beekiri-notice is-info">
          <p>
            The users came over with the database, so you were signed out here. Sign in again with your account from the
            other site.
          </p>
        </div>
      ) : null}
      {job.state === 'error' || job.state === 'cancelled' ? (
        <div className={`beekiri-notice ${job.state === 'error' ? 'is-error' : 'is-info'}`} role="alert">
          <p>{job.error}</p>
        </div>
      ) : null}

      <div className="bk-mig-job__actions">
        {running && job.cancellable ? (
          <button type="button" className="button" onClick={onCancel}>
            Cancel
          </button>
        ) : null}
        {job.state === 'done' && job.result?.downloadId ? (
          <a className="button button-primary" href={`/api/migration/downloads/${job.result.downloadId}`} download={job.result.downloadName}>
            Download file{job.result.size ? ` (${bytes(job.result.size)})` : ''}
          </a>
        ) : null}
        {job.state === 'done' && targetUrl ? (
          <a className="button button-primary" href={targetUrl} target="_blank" rel="noreferrer">
            Open {hostOf(targetUrl)}
          </a>
        ) : null}
        {signedOut ? (
          <button type="button" className="button button-primary" onClick={() => window.location.reload()}>
            Sign in again
          </button>
        ) : null}
        {!running && !signedOut ? (
          <button type="button" className="button" onClick={onClose}>
            {job.state === 'done' ? 'Done' : 'Back'}
          </button>
        ) : null}
        {job.log.length ? (
          <button type="button" className="bk-mig__link" aria-expanded={showLog} onClick={() => setShowLog((v) => !v)}>
            {showLog ? 'Hide details' : 'Show details'}
          </button>
        ) : null}
      </div>
      {showLog ? (
        <ol className="bk-mig-job__log" ref={lastLog}>
          {job.log.map((l, i) => (
            <li key={`${l.at}-${i}`}>
              <time>{new Date(l.at).toLocaleTimeString()}</time> {l.text}
            </li>
          ))}
        </ol>
      ) : null}
    </div>
  );
}

export function MigrationPanel() {
  const [ov, setOv] = useState<Overview | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [mode, setMode] = useState<Mode>('push');
  const [connectionId, setConnectionId] = useState('');
  const [remotes, setRemotes] = useState<Record<string, RemoteInfo | { error: string }>>({});
  const [checking, setChecking] = useState(false);
  const [adding, setAdding] = useState(false);
  const [addInfo, setAddInfo] = useState('');
  const [addLabel, setAddLabel] = useState('');
  const [addBusy, setAddBusy] = useState(false);
  const [addError, setAddError] = useState<string | null>(null);
  const [scope, setScope] = useState<Scope>('theme');
  const [themes, setThemes] = useState<string[]>([]);
  const [activate, setActivate] = useState(false);
  const [withThemes, setWithThemes] = useState(true);
  const [withMedia, setWithMedia] = useState(true);
  const [mirror, setMirror] = useState(false);
  const [keep, setKeep] = useState<KeepGroup[]>(['analytics', 'orders']);
  const [pairs, setPairs] = useState<Pair[]>([]);
  const [pairsTouched, setPairsTouched] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [job, setJob] = useState<Job | null>(null);
  const [jobTarget, setJobTarget] = useState<string | null>(null);
  const [signedOut, setSignedOut] = useState(false);
  const [starting, setStarting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [upload, setUpload] = useState<{ name: string; size: number; sent: number; id?: string; manifest?: Manifest; error?: string } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      const data = await api<Overview>('/api/migration');
      setOv(data);
      setLoadError(null);
      return data;
    } catch (e) {
      setLoadError(errorMessage(e, 'Could not load the migration settings.'));
      return null;
    }
  }, []);

  useEffect(() => {
    void load().then((data) => {
      if (!data) return;
      if (data.connections[0]) setConnectionId(data.connections[0].id);
      if (data.job && data.job.state === 'running') setJob(data.job);
    });
  }, [load]);

  // Follow a running job.
  const jobId = job?.id;
  const jobRunning = job?.state === 'running';
  useEffect(() => {
    if (!jobId || !jobRunning) return;
    let stop = false;
    let timer = 0;
    const tick = async () => {
      try {
        const next = await api<Job>(`/api/migration/jobs/${jobId}`);
        if (stop) return;
        setJob(next);
        if (next.state !== 'running') {
          if (next.result?.signedOut) setSignedOut(true);
          void load();
          return;
        }
      } catch (e) {
        if (e instanceof ApiError && (e.status === 401 || e.status === 403)) {
          // The database (and its users) were replaced while we watched: follow the public status.
          try {
            const res = await fetch(`/api/migration/job-status/${jobId}`, { credentials: 'include' });
            const pub = (await res.json()) as Partial<Job> & { signedOut?: boolean };
            if (stop) return;
            setJob((cur) => (cur ? { ...cur, ...pub, log: cur.log, result: cur.result } as Job : cur));
            if (pub.state && pub.state !== 'running') {
              setSignedOut(true);
              return;
            }
          } catch {
            // Keep trying.
          }
        }
      }
      if (!stop) timer = window.setTimeout(() => void tick(), 700);
    };
    timer = window.setTimeout(() => void tick(), 500);
    return () => {
      stop = true;
      window.clearTimeout(timer);
    };
  }, [jobId, jobRunning, load]);

  const connection = ov?.connections.find((c) => c.id === connectionId) ?? null;
  const remoteEntry = connectionId ? remotes[connectionId] : undefined;
  const remote = remoteEntry && !('error' in remoteEntry) ? remoteEntry : null;
  const remoteError = remoteEntry && 'error' in remoteEntry ? remoteEntry.error : null;
  const remoteName = connection?.label || (connection ? hostOf(connection.url) : 'the other site');

  const checkRemote = useCallback(async (id: string) => {
    if (!id) return;
    setChecking(true);
    try {
      const res = await api<{ remote: RemoteInfo }>(`/api/migration/connections/${id}/test`, { method: 'POST' });
      setRemotes((m) => ({ ...m, [id]: res.remote }));
    } catch (e) {
      setRemotes((m) => ({ ...m, [id]: { error: errorMessage(e, 'Could not reach that site.') } }));
    } finally {
      setChecking(false);
    }
  }, []);

  useEffect(() => {
    if ((mode === 'push' || mode === 'pull') && connectionId && !remotes[connectionId]) void checkRemote(connectionId);
  }, [mode, connectionId, remotes, checkRemote]);

  // Source and target of the data, for theme lists and find & replace.
  const sourceUrl =
    mode === 'push' || mode === 'export'
      ? ov?.siteUrl ?? ''
      : mode === 'pull'
        ? remote?.url ?? connection?.url ?? ''
        : upload?.manifest?.source.url ?? '';
  const targetUrl = mode === 'push' ? remote?.url ?? connection?.url ?? '' : mode === 'export' ? '' : ov?.siteUrl ?? '';
  const sourceThemes = useMemo(
    () => (mode === 'pull' ? remote?.themes ?? [] : ov?.site.themes ?? []),
    [mode, remote, ov],
  );
  const sourceActive = mode === 'pull' ? remote?.activeTheme ?? '' : ov?.site.activeTheme ?? '';

  // Sensible defaults whenever the direction or the other site changes.
  const defaultsKey = `${mode}|${connectionId}|${sourceActive}|${sourceThemes.map((t) => t.slug).join(',')}`;
  useEffect(() => {
    if (mode === 'import') return;
    const active = sourceThemes.find((t) => t.slug === sourceActive && t.slug !== 'beekiri');
    setThemes(active ? [active.slug] : []);
    setActivate(false);
    setKeep(mode === 'push' ? ['analytics', 'orders'] : []);
    setMirror(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- reset only when the key changes
  }, [defaultsKey]);

  useEffect(() => {
    if (!pairsTouched) setPairs(sourceUrl && targetUrl ? suggestedPairs(sourceUrl, targetUrl) : []);
  }, [sourceUrl, targetUrl, pairsTouched]);

  const targetLabel = mode === 'push' ? remoteName : 'this site';
  const sourceLabel = mode === 'pull' ? remoteName : 'this site';
  const themeNames = (slugs: string[]) =>
    slugs.map((s) => sourceThemes.find((t) => t.slug === s)?.name ?? s).join(', ');

  const plan = () => ({
    database: scope === 'database',
    themes: scope === 'theme' || withThemes ? themes : [],
    media: scope === 'database' && withMedia,
    mediaMirror: scope === 'database' && withMedia && mirror,
    keep: scope === 'database' ? keep : [],
    replacements: pairs.filter((p) => p.find.trim()),
    activateTheme: activate && themes[0] ? themes[0] : null,
  });

  const missingActive =
    scope === 'database' && sourceActive && sourceActive !== 'beekiri' && !(withThemes && themes.includes(sourceActive))
      ? (mode === 'push' ? !remote?.themes.some((t) => t.slug === sourceActive) : mode === 'pull' ? !ov?.site.themes.some((t) => t.slug === sourceActive) : false)
      : false;

  const blocked =
    mode === 'push'
      ? !connection || !remote || !remote.allowPush
      : mode === 'pull'
        ? !connection || !remote || !remote.allowPull
        : false;
  const nothing = scope === 'theme' ? themes.length === 0 : false;

  const begin = async () => {
    setError(null);
    const p = plan();
    if (mode === 'push' || mode === 'pull') {
      const target = mode === 'push' ? remoteName : 'this site';
      const Target = mode === 'push' ? remoteName : 'This site';
      const sourceOwn = mode === 'push' ? "this site's" : `${remoteName}'s`;
      const source = mode === 'push' ? 'this site' : remoteName;
      const extras = [
        p.themes.length ? `the ${themeNames(p.themes)} theme` : null,
        p.media ? 'new or changed media files' : null,
      ].filter(Boolean);
      const message =
        scope === 'database'
          ? `The database of ${target} (pages, posts, menus, settings and users) is replaced with ${sourceOwn}${extras.length ? `, together with ${extras.join(' and ')}` : ''}. ${Target} is backed up first, and you can restore that backup in Settings → Migration.`
          : `The ${themeNames(p.themes)} theme on ${target} (files, layouts and Backend Fields) is replaced with the one from ${source}. Content, users and settings stay as they are. ${Target} is backed up first.`;
      const ok = await confirmDialog({
        title: mode === 'push' ? `Push to ${remoteName}?` : `Pull from ${remoteName}?`,
        message,
        confirmLabel: mode === 'push' ? `Push to ${remoteName}` : `Pull from ${remoteName}`,
        danger: scope === 'database',
      });
      if (!ok) return;
    }
    setStarting(true);
    try {
      let started: Job;
      if (mode === 'export') {
        started = await api<Job>('/api/migration/export', { method: 'POST', json: { plan: p } });
        setJobTarget(null);
      } else {
        started = await api<Job>('/api/migration/run', { method: 'POST', json: { mode, connectionId, plan: p } });
        setJobTarget(mode === 'push' ? remote?.url ?? connection?.url ?? null : null);
      }
      setSignedOut(false);
      setJob(started);
    } catch (e) {
      setError(errorMessage(e, 'Could not start the migration.'));
    } finally {
      setStarting(false);
    }
  };

  const cancelJob = async () => {
    if (!job) return;
    try {
      setJob(await api<Job>(`/api/migration/jobs/${job.id}/cancel`, { method: 'POST' }));
    } catch (e) {
      setError(errorMessage(e, 'Could not cancel.'));
    }
  };

  const closeJob = () => {
    setJob(null);
    setUpload(null);
    void load();
  };

  const addConnection = async () => {
    setAddBusy(true);
    setAddError(null);
    try {
      const res = await api<{ connection: Connection; remote: RemoteInfo }>('/api/migration/connections', {
        method: 'POST',
        json: { info: addInfo, label: addLabel },
      });
      setRemotes((m) => ({ ...m, [res.connection.id]: res.remote }));
      await load();
      setConnectionId(res.connection.id);
      setAdding(false);
      setAddInfo('');
      setAddLabel('');
    } catch (e) {
      setAddError(errorMessage(e, 'Could not connect to that site.'));
    } finally {
      setAddBusy(false);
    }
  };

  const removeConnection = async () => {
    if (!connection) return;
    const ok = await confirmDialog({
      title: 'Remove this site?',
      message: `${connection.label || hostOf(connection.url)} is removed from this list. Nothing changes on that site.`,
      confirmLabel: 'Remove',
      danger: true,
    });
    if (!ok) return;
    try {
      await api(`/api/migration/connections/${connection.id}`, { method: 'DELETE' });
      const data = await load();
      setConnectionId(data?.connections[0]?.id ?? '');
    } catch (e) {
      setError(errorMessage(e, 'Could not remove the site.'));
    }
  };

  const setAllow = async (patch: { allowPull?: boolean; allowPush?: boolean; environment?: EnvName | 'auto' }) => {
    try {
      const res = await api<{ allowPull: boolean; allowPush: boolean; environment: Overview['environment'] }>('/api/migration/settings', {
        method: 'PATCH',
        json: patch,
      });
      setOv((cur) => (cur ? { ...cur, ...res } : cur));
    } catch (e) {
      setError(errorMessage(e, 'Could not save.'));
    }
  };

  const resetKey = async () => {
    const ok = await confirmDialog({
      title: 'Reset the connection key?',
      message: 'Sites that use the current key can no longer push to or pull from this site until you paste the new connection info there.',
      confirmLabel: 'Reset key',
      danger: true,
    });
    if (!ok) return;
    try {
      const res = await api<{ connectionInfo: string }>('/api/migration/settings/key', { method: 'POST' });
      setOv((cur) => (cur ? { ...cur, connectionInfo: res.connectionInfo } : cur));
    } catch (e) {
      setError(errorMessage(e, 'Could not reset the key.'));
    }
  };

  const copyInfo = async () => {
    if (!ov) return;
    try {
      await navigator.clipboard.writeText(ov.connectionInfo);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setError('Copy failed. Select the text and copy it by hand.');
    }
  };

  const pickFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setUpload({ name: file.name, size: file.size, sent: 0 });
    setPairsTouched(false);
    try {
      const { uploadId } = await api<{ uploadId: string }>('/api/migration/uploads', {
        method: 'POST',
        json: { size: file.size, name: file.name },
      });
      let offset = 0;
      while (offset < file.size) {
        const res = await fetch(`/api/migration/uploads/${uploadId}/chunk?offset=${offset}`, {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/octet-stream', 'X-CSRF-Token': getCsrfToken() ?? '' },
          body: file.slice(offset, offset + CHUNK),
        });
        const body = (await res.json().catch(() => ({}))) as { received?: number; message?: string };
        if (!res.ok || typeof body.received !== 'number') throw new Error(body.message || `Upload failed (${res.status}).`);
        offset = body.received;
        setUpload((u) => (u ? { ...u, sent: offset } : u));
      }
      const { manifest } = await api<{ manifest: Manifest }>(`/api/migration/uploads/${uploadId}`);
      setUpload({ name: file.name, size: file.size, sent: file.size, id: uploadId, manifest });
      setActivate(false);
      setThemes(manifest.themes.map((t) => t.slug));
    } catch (err) {
      setUpload((u) => (u ? { ...u, error: errorMessage(err, 'Upload failed.') } : u));
    }
  };

  const startImport = async () => {
    if (!upload?.id || !upload.manifest) return;
    const m = upload.manifest;
    const parts = [
      m.database ? 'the database' : null,
      m.themes.length ? `the ${m.themes.map((t) => t.name).join(', ')} theme` : null,
      m.media ? 'media files' : null,
    ].filter(Boolean);
    const ok = await confirmDialog({
      title: 'Import this file?',
      message: `This replaces ${parts.join(', ')} on this site with the contents of ${upload.name}. This site is backed up first.`,
      confirmLabel: 'Import',
      danger: Boolean(m.database),
    });
    if (!ok) return;
    setStarting(true);
    setError(null);
    try {
      const started = await api<Job>('/api/migration/import', {
        method: 'POST',
        json: {
          uploadId: upload.id,
          replacements: pairs.filter((p) => p.find.trim()),
          activateTheme: activate && m.themes[0] ? m.themes[0].slug : null,
        },
      });
      setJobTarget(null);
      setSignedOut(false);
      setJob(started);
    } catch (e) {
      setError(errorMessage(e, 'Could not start the import.'));
    } finally {
      setStarting(false);
    }
  };

  const restore = async (b: Backup) => {
    const ok = await confirmDialog({
      title: 'Restore this backup?',
      message: `This puts back ${b.parts.join(', ') || 'what was saved'} as it was on ${when(b.createdAt)}. The current state is backed up first.`,
      confirmLabel: 'Restore',
      danger: true,
    });
    if (!ok) return;
    setError(null);
    try {
      const started = await api<Job>(`/api/migration/backups/${b.id}/restore`, { method: 'POST' });
      setJobTarget(null);
      setSignedOut(false);
      setJob(started);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (e) {
      setError(errorMessage(e, 'Could not start the restore.'));
    }
  };

  const removeBackup = async (b: Backup) => {
    const ok = await confirmDialog({
      title: 'Delete this backup?',
      message: `The backup from ${when(b.createdAt)} is deleted for good.`,
      confirmLabel: 'Delete',
      danger: true,
    });
    if (!ok) return;
    try {
      const res = await api<{ backups: Backup[] }>(`/api/migration/backups/${b.id}`, { method: 'DELETE' });
      setOv((cur) => (cur ? { ...cur, backups: res.backups } : cur));
    } catch (e) {
      setError(errorMessage(e, 'Could not delete the backup.'));
    }
  };

  if (loadError) {
    return (
      <div className="beekiri-notice is-error" role="alert">
        <p>{loadError}</p>
      </div>
    );
  }
  if (!ov) return <div className="bk-panel bk-mig__loading" aria-busy="true" />;

  const busy = Boolean(job && job.state === 'running');
  const themeChoices = sourceThemes.filter((t) => t.slug !== 'beekiri');

  const findReplace = (
    <div className="bk-mig__block">
      <div className="bk-mig__block-head">
        <h4>Find &amp; replace</h4>
        {pairsTouched ? (
          <button
            type="button"
            className="bk-mig__link"
            onClick={() => {
              setPairsTouched(false);
            }}
          >
            Use suggested
          </button>
        ) : null}
      </div>
      <p className="bk-mig__hint">Addresses inside the content are changed so links and images point at the new site.</p>
      <div className="bk-mig-pairs">
        {pairs.map((p, i) => (
          <div className="bk-mig-pairs__row" key={i}>
            <input
              type="text"
              aria-label={`Find ${i + 1}`}
              value={p.find}
              placeholder="Find"
              onChange={(e) => {
                setPairsTouched(true);
                setPairs((list) => list.map((x, j) => (j === i ? { ...x, find: e.target.value } : x)));
              }}
            />
            <span className="bk-mig-pairs__arrow" aria-hidden>
              →
            </span>
            <input
              type="text"
              aria-label={`Replace ${i + 1}`}
              value={p.replace}
              placeholder="Replace with"
              onChange={(e) => {
                setPairsTouched(true);
                setPairs((list) => list.map((x, j) => (j === i ? { ...x, replace: e.target.value } : x)));
              }}
            />
            <button
              type="button"
              className="bk-mig-pairs__remove"
              aria-label="Remove this row"
              onClick={() => {
                setPairsTouched(true);
                setPairs((list) => list.filter((_, j) => j !== i));
              }}
            >
              {ICON_X}
            </button>
          </div>
        ))}
        {!pairs.length ? <p className="bk-mig__hint">Nothing to replace: both sites use the same address.</p> : null}
        <button
          type="button"
          className="bk-mig__link"
          onClick={() => {
            setPairsTouched(true);
            setPairs((list) => [...list, { find: '', replace: '' }]);
          }}
        >
          Add a row
        </button>
      </div>
    </div>
  );

  const themePicker = (
    <div className="bk-mig-themes" role="group" aria-label="Themes">
      {themeChoices.map((t) => {
        const on = themes.includes(t.slug);
        return (
          <label key={t.slug} className={`bk-mig-theme${on ? ' is-on' : ''}`}>
            <input
              type="checkbox"
              checked={on}
              onChange={(e) => setThemes((list) => (e.target.checked ? [...list, t.slug] : list.filter((s) => s !== t.slug)))}
            />
            <span className="bk-mig-theme__name">{t.name}</span>
            <span className="bk-mig-theme__meta">
              v{t.version}
              {t.slug === sourceActive ? <span className="bk-mig-badge">Active</span> : null}
            </span>
          </label>
        );
      })}
      {!themeChoices.length ? <p className="bk-mig__hint">No themes found.</p> : null}
    </div>
  );

  const scopeCards = (
    <div className="bk-mig-scope" role="radiogroup" aria-label="What to migrate">
      <label className={`bk-mig-scope__card${scope === 'theme' ? ' is-on' : ''}`}>
        <input type="radio" name="bk-mig-scope" checked={scope === 'theme'} onChange={() => setScope('theme')} />
        <span className="bk-mig-scope__title">Theme code</span>
        <span className="bk-mig-scope__text">Theme files, layouts and the theme&apos;s Backend Fields. Content, users and settings stay as they are.</span>
      </label>
      <label className={`bk-mig-scope__card${scope === 'database' ? ' is-on' : ''}`}>
        <input type="radio" name="bk-mig-scope" checked={scope === 'database'} onChange={() => setScope('database')} />
        <span className="bk-mig-scope__title">Full database</span>
        <span className="bk-mig-scope__text">All pages, posts, menus, settings, users and shop data, optionally with theme and media files.</span>
      </label>
    </div>
  );

  return (
    <div className="bk-stack bk-mig">
      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">This site</h2>
        </div>
        <div className="bk-panel__body">
          <p className="bk-mig__hint bk-mig__intro">
            Paste this into Settings → Migration on another Beekiri site to push to or pull from this site. Keep it private:
            it works like a password.
          </p>
          <div className="bk-mig-info">
            <textarea className="bk-mig__mono" readOnly rows={2} value={ov.connectionInfo} aria-label="Connection info" onFocus={(e) => e.target.select()} />
            <div className="bk-mig__row">
              <button type="button" className="button button-primary" onClick={() => void copyInfo()}>
                {copied ? 'Copied' : 'Copy'}
              </button>
              <button type="button" className="button" onClick={() => void resetKey()}>
                Reset key
              </button>
            </div>
          </div>
          <div className="bk-mig-env">
            <label className="bk-mig__label" htmlFor="bk-mig-env">
              This site is
            </label>
            <select
              id="bk-mig-env"
              value={ov.environment.chosen ?? 'auto'}
              onChange={(e) => void setAllow({ environment: e.target.value as EnvName | 'auto' })}
            >
              <option value="auto">{`Detect from the address (${ENV_LABEL[ov.environment.detected]})`}</option>
              <option value="local">Local</option>
              <option value="staging">Staging</option>
              <option value="production">Production</option>
            </select>
            <span className="bk-mig__hint">
              A store theme licence covers one local, one staging and one production site with the same owner e-mail address.
              Further sites need a new Beekiri install and a new licence.
            </span>
          </div>
          <div className="bk-mig-allow">
            <div className="bk-mig-allow__row">
              <Switch checked={ov.allowPull} onChange={(v) => void setAllow({ allowPull: v })} label="Allow pull" />
              <div>
                <strong>Allow pull</strong>
                <span className="bk-mig__hint">Other sites with the key can copy this site&apos;s theme code, database and media.</span>
              </div>
            </div>
            <div className="bk-mig-allow__row">
              <Switch checked={ov.allowPush} onChange={(v) => void setAllow({ allowPush: v })} label="Allow push" />
              <div>
                <strong>Allow push</strong>
                <span className="bk-mig__hint">
                  Other sites with the key can replace this site&apos;s theme code, database and media. Turn it on for a staging
                  site; on a live site, only while you deploy.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Migrate</h2>
        </div>
        <div className="bk-panel__body">
          {job ? (
            <JobView job={job} signedOut={signedOut} onCancel={() => void cancelJob()} onClose={closeJob} targetUrl={jobTarget} />
          ) : (
            <>
              <div className="bk-mig-modes" role="tablist" aria-label="Migration type">
                {MODES.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    role="tab"
                    aria-selected={mode === m.id}
                    className={`bk-mig-modes__item${mode === m.id ? ' is-active' : ''}`}
                    onClick={() => {
                      setMode(m.id);
                      setPairsTouched(false);
                      setError(null);
                    }}
                  >
                    <span className="bk-mig-modes__label">{m.label}</span>
                    <span className="bk-mig-modes__hint">{m.hint}</span>
                  </button>
                ))}
              </div>

              {mode === 'push' || mode === 'pull' ? (
                <div className="bk-mig__block">
                  <div className="bk-mig__block-head">
                    <h4>{mode === 'push' ? 'Push to' : 'Pull from'}</h4>
                    {!adding && ov.connections.length ? (
                      <button type="button" className="bk-mig__link" onClick={() => setAdding(true)}>
                        Connect a site
                      </button>
                    ) : null}
                  </div>
                  {adding || !ov.connections.length ? (
                    <div className="bk-mig-add">
                      <label className="bk-mig__label" htmlFor="bk-mig-info">
                        Connection info of the other site
                      </label>
                      <textarea
                        id="bk-mig-info"
                        className="bk-mig__mono"
                        rows={3}
                        value={addInfo}
                        placeholder={'https://staging.example.com\nIts connection key'}
                        onChange={(e) => setAddInfo(e.target.value)}
                      />
                      <p className="bk-mig__hint">
                        Find it on the other site in Settings → Migration → Connection info. Turn on &quot;Allow push&quot; or
                        &quot;Allow pull&quot; there too.
                      </p>
                      <label className="bk-mig__label" htmlFor="bk-mig-label">
                        Name (optional)
                      </label>
                      <input
                        id="bk-mig-label"
                        type="text"
                        value={addLabel}
                        placeholder="Staging"
                        onChange={(e) => setAddLabel(e.target.value)}
                      />
                      {addError ? (
                        <div className="beekiri-notice is-error" role="alert">
                          <p>{addError}</p>
                        </div>
                      ) : null}
                      <div className="bk-mig__row">
                        <button type="button" className="button button-primary" disabled={addBusy || !addInfo.trim()} onClick={() => void addConnection()}>
                          {addBusy ? 'Connecting…' : 'Connect'}
                        </button>
                        {ov.connections.length ? (
                          <button type="button" className="button" onClick={() => setAdding(false)}>
                            Cancel
                          </button>
                        ) : null}
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="bk-mig__row">
                        <select aria-label="Site" value={connectionId} onChange={(e) => setConnectionId(e.target.value)}>
                          {ov.connections.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.label ? `${c.label} (${hostOf(c.url)})` : hostOf(c.url)}
                            </option>
                          ))}
                        </select>
                        <button type="button" className="button" disabled={checking} onClick={() => void checkRemote(connectionId)}>
                          {checking ? 'Checking…' : 'Check connection'}
                        </button>
                        <button type="button" className="bk-mig__link is-danger" onClick={() => void removeConnection()}>
                          Remove
                        </button>
                      </div>
                      {remote ? (
                        <div className="bk-mig-remote">
                          <span className="bk-mig-remote__dot" aria-hidden />
                          <span>
                            <strong>{remote.name}</strong>
                            {remote.environment ? ` (${ENV_LABEL[remote.environment]})` : ''} · {hostOf(remote.url)} · Beekiri {remote.version}
                            {remote.activeTheme ? ` · Theme: ${remote.themes.find((t) => t.slug === remote.activeTheme)?.name ?? remote.activeTheme}` : ''}
                          </span>
                        </div>
                      ) : null}
                      {checking && !remote ? <p className="bk-mig__hint">Connecting…</p> : null}
                      {remoteError ? (
                        <div className="beekiri-notice is-error" role="alert">
                          <p>{remoteError}</p>
                        </div>
                      ) : null}
                      {remote && mode === 'push' && !remote.allowPush ? (
                        <div className="beekiri-notice is-info">
                          <p>
                            Push is turned off on {remoteName}. Turn on &quot;Allow push&quot; in Settings → Migration on that site,
                            then check the connection again.
                          </p>
                        </div>
                      ) : null}
                      {remote && mode === 'pull' && !remote.allowPull ? (
                        <div className="beekiri-notice is-info">
                          <p>
                            Pull is turned off on {remoteName}. Turn on &quot;Allow pull&quot; in Settings → Migration on that site,
                            then check the connection again.
                          </p>
                        </div>
                      ) : null}
                    </>
                  )}
                </div>
              ) : null}

              {mode === 'import' ? (
                <div className="bk-mig__block">
                  <h4>Migration file</h4>
                  <input ref={fileRef} type="file" accept=".beekiri" hidden onChange={(e) => void pickFile(e)} />
                  {!upload ? (
                    <button type="button" className="bk-mig-drop" onClick={() => fileRef.current?.click()}>
                      <strong>Choose a .beekiri file</strong>
                      <span>Made with Export file on another Beekiri site</span>
                    </button>
                  ) : (
                    <div className="bk-mig-upload">
                      <div className="bk-mig-upload__head">
                        <strong>{upload.name}</strong>
                        <span>{upload.manifest ? bytes(upload.size) : `${bytes(upload.sent)} of ${bytes(upload.size)}`}</span>
                      </div>
                      {!upload.manifest && !upload.error ? (
                        <div className="bk-mig-job__bar" role="progressbar" aria-label="Uploading" aria-valuenow={Math.round((100 * upload.sent) / upload.size)}>
                          <span style={{ width: `${(100 * upload.sent) / upload.size}%` }} />
                        </div>
                      ) : null}
                      {upload.error ? (
                        <div className="beekiri-notice is-error" role="alert">
                          <p>{upload.error}</p>
                        </div>
                      ) : null}
                      {upload.manifest ? (
                        <ul className="bk-mig-summary">
                          <li>
                            From <strong>{upload.manifest.source.name}</strong>
                            {upload.manifest.source.url ? ` (${hostOf(upload.manifest.source.url)})` : ''}, Beekiri {upload.manifest.source.version},{' '}
                            {when(upload.manifest.createdAt)}
                          </li>
                          {upload.manifest.database ? (
                            <li>Database: {upload.manifest.database.tables} tables, {upload.manifest.database.rows} rows</li>
                          ) : null}
                          {upload.manifest.themes.map((t) => (
                            <li key={t.slug}>
                              Theme {t.name} {t.version}: {t.files} {t.files === 1 ? 'file' : 'files'}, {t.fieldGroups} Backend Field {t.fieldGroups === 1 ? 'group' : 'groups'}
                            </li>
                          ))}
                          {upload.manifest.media ? (
                            <li>
                              Media: {upload.manifest.media.files} files ({bytes(upload.manifest.media.bytes)})
                            </li>
                          ) : null}
                        </ul>
                      ) : null}
                      <button type="button" className="bk-mig__link" onClick={() => setUpload(null)}>
                        Choose another file
                      </button>
                    </div>
                  )}
                </div>
              ) : null}

              {mode !== 'import' ? (
                <div className="bk-mig__block">
                  <h4>What to {mode === 'export' ? 'export' : 'migrate'}</h4>
                  {scopeCards}
                  {scope === 'theme' ? (
                    <>
                      {themePicker}
                      {mode !== 'export' && themes.length ? (
                        <Check
                          checked={activate}
                          onChange={setActivate}
                          label={`Make ${themeNames(themes.slice(0, 1))} the active theme on ${targetLabel}`}
                          hint="Leave off to only update the files of the theme."
                        />
                      ) : null}
                    </>
                  ) : (
                    <div className="bk-mig__options">
                      <Check checked={withThemes} onChange={setWithThemes} label="Include theme files" hint="The selected themes, with their layouts." />
                      {withThemes ? themePicker : null}
                      <Check
                        checked={withMedia}
                        onChange={setWithMedia}
                        label="Include media files"
                        hint={mode === 'export' ? 'Every file in the media library.' : 'Only files that are new or changed are sent.'}
                      />
                      {missingActive ? (
                        <div className="beekiri-notice is-info">
                          <p>
                            The active theme {themeNames([sourceActive])} is not on {targetLabel}. Include its theme files so the site
                            looks the same.
                          </p>
                        </div>
                      ) : null}
                    </div>
                  )}
                </div>
              ) : null}

              {(mode === 'push' || mode === 'pull') && scope === 'database' ? findReplace : null}
              {mode === 'import' && upload?.manifest?.database ? findReplace : null}
              {mode === 'import' && upload?.manifest?.themes.length ? (
                <Check
                  checked={activate}
                  onChange={setActivate}
                  label={`Make ${upload.manifest.themes[0].name} the active theme`}
                  hint="Leave off to only update the files of the theme."
                />
              ) : null}

              {(mode === 'push' || mode === 'pull') && scope === 'database' ? (
                <div className="bk-mig__block">
                  <button type="button" className="bk-mig__link" aria-expanded={showAdvanced} onClick={() => setShowAdvanced((v) => !v)}>
                    {showAdvanced ? 'Hide advanced options' : 'Advanced options'}
                  </button>
                  {showAdvanced ? (
                    <div className="bk-mig__options">
                      <p className="bk-mig__label">Keep on {targetLabel} (not replaced)</p>
                      {KEEP.map((k) => (
                        <Check
                          key={k.id}
                          checked={keep.includes(k.id)}
                          onChange={(v) => setKeep((list) => (v ? [...list, k.id] : list.filter((x) => x !== k.id)))}
                          label={k.label}
                          hint={k.hint}
                        />
                      ))}
                      {withMedia ? (
                        <Check
                          checked={mirror}
                          onChange={setMirror}
                          label={`Delete media files on ${targetLabel} that are not on ${sourceLabel}`}
                          hint="They are backed up first."
                        />
                      ) : null}
                    </div>
                  ) : null}
                  <p className="bk-mig__hint bk-mig__keeps">
                    Each site always keeps its own sign-ins, connection key, Hub connection, admin address, search engine
                    visibility and payment keys.
                  </p>
                </div>
              ) : null}

              <div className="bk-mig__go">
                {mode === 'import' ? (
                  <button
                    type="button"
                    className="button button-primary"
                    disabled={!upload?.manifest || starting || busy}
                    onClick={() => void startImport()}
                  >
                    {starting ? 'Starting…' : 'Import'}
                  </button>
                ) : (
                  <button
                    type="button"
                    className="button button-primary"
                    disabled={blocked || nothing || starting || busy}
                    onClick={() => void begin()}
                  >
                    {starting
                      ? 'Starting…'
                      : mode === 'push'
                        ? `Push to ${remoteName}`
                        : mode === 'pull'
                          ? `Pull from ${remoteName}`
                          : 'Export file'}
                  </button>
                )}
                {mode !== 'export' ? <span className="bk-mig__hint">A backup is made before anything is replaced.</span> : null}
              </div>
            </>
          )}
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Backups</h2>
        </div>
        <div className="bk-panel__body">
          {ov.backups.length ? (
            <table className="bk-mig-backups">
              <thead>
                <tr>
                  <th scope="col">Made</th>
                  <th scope="col">Contains</th>
                  <th scope="col">Size</th>
                  <th scope="col">
                    <span className="screen-reader-text">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {ov.backups.map((b) => (
                  <tr key={b.id}>
                    <td>
                      <strong>{when(b.createdAt)}</strong>
                      <span className="bk-mig__hint">{b.label}</span>
                    </td>
                    <td>{b.parts.join(', ') || 'Nothing (only new items arrived)'}</td>
                    <td>{bytes(b.size)}</td>
                    <td className="bk-mig-backups__actions">
                      <button type="button" className="button" disabled={busy} onClick={() => void restore(b)}>
                        Restore
                      </button>
                      <a className="button" href={`/api/migration/backups/${b.id}/download`}>
                        Download
                      </a>
                      <button type="button" className="bk-mig__link is-danger" onClick={() => void removeBackup(b)}>
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="bk-mig__hint">A backup is made here automatically before every push, pull, import or restore that changes this site. The newest 5 are kept.</p>
          )}
        </div>
      </div>
    </div>
  );
}
