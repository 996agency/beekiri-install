import { Fragment, useEffect, useLayoutEffect, useRef, useState, type KeyboardEvent, type ReactNode } from 'react';
import { gsap } from 'gsap';
import { createPortal } from 'react-dom';
import { Link } from 'react-router-dom';
import {
  ArrowCounterClockwise,
  ArrowSquareOut,
  Eye,
  Files,
  Stack,
  Article,
  ArrowUp,
  CaretDown,
  Check,
  CheckCircle,
  ClockCounterClockwise,
  FileCode,
  Image,
  Layout,
  NotePencil,
  Plus,
  SelectionForeground,
  ShoppingBag,
  Stop,
  Trash,
  WarningCircle,
  X,
} from '@phosphor-icons/react';
import { useAuth } from '../auth/AuthContext';
import { useAdminHref } from '../lib/AdminEntryContext';
import { CubeBee } from './CubeBee';
import type { BeeLink, BeeMessage, useBeeQueenChat } from './useBeeQueenChat';
import './bee-agent-chat.css';
import { formatMoney } from '../lib/money';
import { safeHref } from '../lib/safe-html';

type Props = {
  open: boolean;
  agentName: string;
  /** e.g. "Claude Opus 5.5 · Max effort" */
  engineLabel: string;
  chat: ReturnType<typeof useBeeQueenChat>;
  onClose: () => void;
};

const SUGGESTIONS = [
  'Create a full About Us landing page',
  'Build a testimonials section editors can fill in',
  'Make a pricing section with three plans',
  'Review my layouts and make the hero feel more premium',
];

/** Section mode (one element from the editor). */
const SECTION_SUGGESTIONS = [
  'Rewrite the text so it sounds more confident',
  'Swap the image for a better one from the media library',
  'Give this a completely different layout',
  'Make it look great on mobile',
];

/** "3m ago", "Yesterday", "Oct 12" — for the chat history list. */
function when(iso: string): string {
  const then = new Date(iso);
  const mins = Math.round((Date.now() - then.getTime()) / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  if (mins < 60 * 24) return `${Math.round(mins / 60)}h ago`;
  if (mins < 60 * 48) return 'Yesterday';
  return then.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

/** **bold** and `code` inside one line of text. */
function inline(text: string): ReactNode[] {
  return text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**') && part.length > 4) return <strong key={i}>{part.slice(2, -2)}</strong>;
    if (part.startsWith('`') && part.endsWith('`') && part.length > 2) return <code key={i}>{part.slice(1, -1)}</code>;
    return <Fragment key={i}>{part}</Fragment>;
  });
}

/** Small markdown subset for replies: paragraphs, headings, bullet and numbered lists. */
function RichText({ text }: { text: string }) {
  const blocks: ReactNode[] = [];
  const lines = text.replace(/\r/g, '').split('\n');
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) {
      i++;
      continue;
    }
    const bullet = /^\s*[-*•]\s+/;
    const numbered = /^\s*\d+[.)]\s+/;
    if (bullet.test(line) || numbered.test(line)) {
      const ordered = numbered.test(line);
      const re = ordered ? numbered : bullet;
      const items: string[] = [];
      while (i < lines.length && re.test(lines[i])) items.push(lines[i++].replace(re, ''));
      const ListTag = ordered ? 'ol' : 'ul';
      blocks.push(
        <ListTag key={blocks.length}>
          {items.map((item, k) => (
            <li key={k}>{inline(item)}</li>
          ))}
        </ListTag>,
      );
      continue;
    }
    const heading = line.match(/^#{1,4}\s+(.*)$/);
    if (heading) {
      blocks.push(
        <p key={blocks.length} className="bk-bee-chat__h">
          {inline(heading[1])}
        </p>,
      );
      i++;
      continue;
    }
    const para: string[] = [];
    while (i < lines.length && lines[i].trim() && !bullet.test(lines[i]) && !numbered.test(lines[i]) && !/^#{1,4}\s/.test(lines[i])) {
      para.push(lines[i++]);
    }
    blocks.push(<p key={blocks.length}>{inline(para.join(' '))}</p>);
  }
  return <>{blocks}</>;
}

const LINK_ICONS: Record<BeeLink['kind'], typeof FileCode> = {
  page: NotePencil,
  post: Article,
  product: ShoppingBag,
  media: Image,
  layout: Layout,
  file: FileCode,
  type: Stack,
  entry: Files,
};
const LINK_KINDS: Record<BeeLink['kind'], string> = {
  page: 'Page',
  post: 'Blog post',
  product: 'Product',
  media: 'Photo',
  layout: 'Layout',
  file: 'Theme file',
  type: 'Content type',
  entry: 'Entry',
};

function LinkChip({ link, onNavigate }: { link: BeeLink; onNavigate: () => void }) {
  const href = useAdminHref();
  const Icon = LINK_ICONS[link.kind] ?? FileCode;
  const kind = LINK_KINDS[link.kind] ?? 'Theme file';
  return (
    <span className="bk-bee-chat__link">
      <Icon size={15} aria-hidden />
      <span className="bk-bee-chat__link-text">
        <small>{link.preview ? `${kind} · not public yet` : kind}</small>
        {link.label}
      </span>
      {link.admin ? (
        <Link to={href(link.admin)} onClick={onNavigate} className="bk-bee-chat__link-action">
          {link.kind === 'page' || link.kind === 'post' || link.kind === 'product' ? 'Edit' : 'Open'}
        </Link>
      ) : null}
      {link.url ? (
        <a
          href={safeHref(link.url)}
          target="_blank"
          rel="noreferrer"
          className="bk-bee-chat__link-action"
          aria-label={`${link.preview ? 'Preview' : 'View'} ${link.label}`}
          title={link.preview ? 'A private preview with what is waiting for Keep — visitors don’t see it yet' : undefined}
        >
          {link.preview ? 'Preview' : 'View'} <ArrowSquareOut size={12} aria-hidden />
        </a>
      ) : null}
    </span>
  );
}

function AssistantMessage({
  message,
  onNavigate,
  canManage,
  onKeep,
  onUndo,
  onPreview,
}: {
  message: BeeMessage;
  onNavigate: () => void;
  canManage: boolean;
  /** Section mode: keep or undo this reply's change (only on the latest change). */
  onKeep?: () => void;
  onUndo?: () => void;
  onPreview?: () => void;
}) {
  const href = useAdminHref();
  const [showSteps, setShowSteps] = useState(false);
  const steps = message.steps ?? [];
  const running = message.state === 'running';
  const current = steps[steps.length - 1];

  return (
    <div className={`bk-bee-chat__msg is-assistant is-${message.state ?? 'done'}`}>
      <span className="bk-bee-chat__avatar" aria-hidden>
        <span className="bk-bee-chat__scene">
          <CubeBee brand="beequeen" />
        </span>
      </span>
      <div className="bk-bee-chat__body">
        {running ? (
          <div className="bk-bee-chat__live" aria-live="polite">
            <ol className="bk-bee-chat__steps">
              {steps.slice(-6).map((s, i, arr) => (
                <li key={steps.length - arr.length + i} className={`is-${s.kind}${i === arr.length - 1 ? ' is-current' : ''}`}>
                  {s.text}
                </li>
              ))}
            </ol>
            <p className="bk-bee-chat__thinking">
              <span className="bk-bee-chat__dots" aria-hidden>
                <i />
                <i />
                <i />
              </span>
              <span className="bk-bee-chat__shimmer">{current?.kind === 'status' ? `${current.text}…` : 'Thinking…'}</span>
            </p>
          </div>
        ) : (
          <>
            {message.state === 'error' ? (
              <div className="bk-bee-chat__error">
                <WarningCircle size={16} weight="fill" aria-hidden />
                <span>{message.text}</span>
                {message.needsCredits && canManage ? (
                  <Link to={href('connector')} onClick={onNavigate} className="bk-bee-chat__link-action">
                    Open Connector
                  </Link>
                ) : null}
              </div>
            ) : (
              <div className="bk-bee-chat__text">
                <RichText text={message.text} />
              </div>
            )}
            {(message.applied || message.changed) && !message.decision && onKeep && onUndo ? (
              <div className="bk-bee-chat__decide" role="group" aria-label="Keep or undo this change">
                <span className="bk-bee-chat__decide-icon" aria-hidden>
                  <Check size={15} weight="bold" />
                </span>
                <span className="bk-bee-chat__decide-copy">
                  <strong>{message.applied ? 'Applied in the editor' : 'Waiting for you'}</strong>
                  <small>
                    {message.applied
                      ? 'Keep it, or undo to put the section back.'
                      : 'New sections stay hidden from visitors until you keep them. Undo puts everything back as it was.'}
                  </small>
                </span>
                <span className="bk-bee-chat__decide-actions">
                  {onPreview && !message.applied && !message.links?.some((l) => l.preview) ? (
                    <button type="button" className="bk-bee-chat__decide-undo" onClick={onPreview}>
                      <Eye size={14} aria-hidden /> Preview
                    </button>
                  ) : null}
                  <button type="button" className="bk-bee-chat__decide-undo" onClick={onUndo}>
                    <ArrowCounterClockwise size={14} aria-hidden /> Undo
                  </button>
                  <button type="button" className="bk-bee-chat__decide-keep" onClick={onKeep}>
                    <Check size={14} weight="bold" aria-hidden /> Keep
                  </button>
                </span>
              </div>
            ) : message.applied || (message.changed && message.decision) ? (
              <p className="bk-bee-chat__applied">
                <CheckCircle size={13} weight="fill" aria-hidden />{' '}
                {message.decision === 'kept' ? 'Kept' : message.decision === 'undone' ? 'Undone' : 'Applied in the editor'}
              </p>
            ) : null}
            {message.links?.length ? (
              <div className="bk-bee-chat__links">
                {message.links.map((l) => (
                  <LinkChip key={`${l.kind}:${l.label}`} link={l} onNavigate={onNavigate} />
                ))}
              </div>
            ) : null}
            {steps.length || message.cost ? (
              <div className="bk-bee-chat__trace">
                <button
                  type="button"
                  className="bk-bee-chat__trace-toggle"
                  aria-expanded={showSteps}
                  onClick={() => setShowSteps((v) => !v)}
                >
                  {message.state === 'done' ? <CheckCircle size={13} weight="fill" aria-hidden /> : null}
                  {steps.filter((s) => s.kind === 'status').length} steps
                  <CaretDown size={11} aria-hidden className={showSteps ? 'is-open' : ''} />
                </button>
                {message.cost ? (
                  <span className="bk-bee-chat__cost" title="What this message cost, taken from the Beekiri balance">
                    <img src="/admin/connector/claude.svg" alt="" width={12} height={12} draggable={false} /> {formatMoney(message.cost, 'USD', true)}
                  </span>
                ) : null}
                {showSteps ? (
                  <ol className="bk-bee-chat__steps is-done">
                    {steps.map((s, i) => (
                      <li key={i} className={`is-${s.kind}`}>
                        {s.text}
                      </li>
                    ))}
                  </ol>
                ) : null}
              </div>
            ) : null}
          </>
        )}
      </div>
    </div>
  );
}

/** Beekiri chat — Claude builds layouts, Backend Fields and pages inside the active theme. */
export function BeeAgentChat({ open, agentName, engineLabel, chat, onClose }: Props) {
  const auth = useAuth();
  const canManage = Boolean(auth.user?.isOwner || auth.user?.capabilities.includes('manage_options'));
  const [draft, setDraft] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const [showHistory, setShowHistory] = useState(false);
  /** The history drawer stays mounted while it slides out. */
  const [historyMounted, setHistoryMounted] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const drawerRef = useRef<HTMLElement>(null);
  const seenRef = useRef(0);
  const { messages, running, loading, send, stop, newChat, openChat, deleteChat, chats, chatId, load, section } = chat;
  /** Keep / Undo is offered on the latest change only (a whole reply's saves need an admin to undo). */
  const lastAppliedId =
    [...messages]
      .reverse()
      .find((m) => m.role === 'assistant' && !m.decision && (m.applied || (m.changed && m.runId && canManage)))?.id ?? null;
  const lastSteps = messages[messages.length - 1]?.steps?.length ?? 0;

  useEffect(() => {
    if (open) void load();
  }, [open, load]);

  // ── Motion (GSAP) — calm and quick; nothing moves when the OS asks for reduced motion.
  const calm = () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  useLayoutEffect(() => {
    const panel = panelRef.current;
    if (!open || !panel || calm()) return;
    const tween = gsap.fromTo(
      panel,
      { autoAlpha: 0, x: 32, scale: 0.985 },
      { autoAlpha: 1, x: 0, y: 0, scale: 1, duration: 0.5, ease: 'expo.out', clearProps: 'transform,opacity,visibility' },
    );
    return () => {
      tween.kill();
    };
    // Only when the chat opens.
  }, [open]);

  // New messages rise in; opening an old chat brings its last few in with a short stagger.
  useLayoutEffect(() => {
    const list = scrollRef.current?.querySelectorAll<HTMLElement>('.bk-bee-chat__msg');
    const count = list?.length ?? 0;
    if (!list || calm() || count <= seenRef.current) {
      seenRef.current = count;
      return;
    }
    const fresh = Array.from(list).slice(Math.max(seenRef.current, count - 4));
    seenRef.current = count;
    gsap.fromTo(
      fresh,
      { autoAlpha: 0, y: 12 },
      { autoAlpha: 1, y: 0, duration: 0.45, ease: 'power3.out', stagger: 0.06, clearProps: 'transform,opacity,visibility' },
    );
  }, [messages.length, open]);

  // The empty state: hero, title, text, then the suggestions one after another.
  const isEmpty = !loading && messages.length === 0;
  useLayoutEffect(() => {
    if (!open || !isEmpty || calm()) return;
    const root = scrollRef.current?.querySelector('.bk-bee-chat__empty');
    if (!root) return;
    const tl = gsap.timeline({ defaults: { ease: 'power3.out', clearProps: 'transform,opacity,visibility' } });
    tl.fromTo(root.querySelector('.bk-bee-chat__hero'), { autoAlpha: 0, scale: 0.8 }, { autoAlpha: 1, scale: 1, duration: 0.6, ease: 'back.out(1.6)' })
      .fromTo(root.querySelectorAll('h2, p'), { autoAlpha: 0, y: 10 }, { autoAlpha: 1, y: 0, duration: 0.45, stagger: 0.07 }, '-=0.35')
      .fromTo(root.querySelectorAll('.bk-bee-chat__suggestions button'), { autoAlpha: 0, y: 14 }, { autoAlpha: 1, y: 0, duration: 0.45, stagger: 0.06 }, '-=0.25');
    return () => {
      tl.kill();
    };
  }, [open, isEmpty, section?.nodeId]);

  // Keep / Undo pops in once, when a change lands.
  useLayoutEffect(() => {
    if (!lastAppliedId || calm()) return;
    const card = scrollRef.current?.querySelector('.bk-bee-chat__decide');
    if (card) gsap.fromTo(card, { autoAlpha: 0, scale: 0.96, y: 6 }, { autoAlpha: 1, scale: 1, y: 0, duration: 0.5, ease: 'back.out(1.8)', clearProps: 'transform,opacity,visibility' });
  }, [lastAppliedId]);

  // History drawer slides over the conversation, and back out before it unmounts.
  useEffect(() => {
    if (showHistory) setHistoryMounted(true);
  }, [showHistory]);
  useLayoutEffect(() => {
    const drawer = drawerRef.current;
    if (!historyMounted || !drawer) return;
    if (calm()) {
      if (!showHistory) setHistoryMounted(false);
      return;
    }
    const items = drawer.querySelectorAll('li');
    const tween = showHistory
      ? gsap
          .timeline()
          .fromTo(drawer, { xPercent: -100 }, { xPercent: 0, duration: 0.42, ease: 'expo.out' })
          .fromTo(items, { autoAlpha: 0, x: -10 }, { autoAlpha: 1, x: 0, duration: 0.3, stagger: 0.03, ease: 'power2.out' }, '-=0.25')
      : gsap.to(drawer, { xPercent: -100, duration: 0.3, ease: 'power3.in', onComplete: () => setHistoryMounted(false) });
    return () => {
      tween.kill();
    };
  }, [showHistory, historyMounted]);

  useEffect(() => {
    if (!open) return;
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [open, messages.length, lastSteps, running]);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  useEffect(() => {
    const el = inputRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 180)}px`;
  }, [draft]);

  if (!open || typeof document === 'undefined') return null;

  const submit = (text = draft) => {
    if (!text.trim() || running) return;
    void send(text);
    setDraft('');
  };

  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      submit();
    }
  };

  return createPortal(
    <div
      // Always docked on the right, so the page stays visible while Beekiri works.
      className="bk-bee-chat is-docked"
      role="dialog"
      aria-modal="false"
      aria-label={`${agentName} assistant`}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bk-bee-chat__panel" ref={panelRef}>
        <div className="bk-bee-chat__bar">
          <div className="bk-bee-chat__titles">
            <strong>{agentName}</strong>
            <span className="bk-bee-chat__engine">
              <img src="/admin/connector/claude.svg" alt="" width={12} height={12} draggable={false} />
              {engineLabel}
            </span>
          </div>
          <div className="bk-bee-chat__bar-actions">
            <button
              type="button"
              className={`bk-bee-chat__icon-btn${showHistory ? ' is-active' : ''}`}
              aria-expanded={showHistory}
              aria-label="Your chats"
              title="Your chats"
              onClick={() => setShowHistory((v) => !v)}
            >
              <ClockCounterClockwise size={17} aria-hidden />
            </button>
            <button
              type="button"
              className="bk-bee-chat__icon-btn"
              onClick={() => {
                newChat();
                setShowHistory(false);
              }}
              disabled={running || messages.length === 0}
              aria-label="New chat"
              title="New chat"
            >
              <NotePencil size={17} aria-hidden />
            </button>
            <button type="button" className="bk-bee-chat__icon-btn" aria-label="Close" title="Close (Esc)" onClick={onClose}>
              <X size={17} aria-hidden />
            </button>
          </div>
        </div>

        <div className="bk-bee-chat__body-wrap">
        {historyMounted ? (
          <aside className="bk-bee-chat__history" aria-label="Your chats" ref={drawerRef}>
            <div className="bk-bee-chat__history-head">
              <strong>Your chats</strong>
              <button
                type="button"
                className="bk-bee-chat__history-new"
                disabled={running}
                onClick={() => {
                  newChat();
                  setShowHistory(false);
                }}
              >
                <Plus size={14} weight="bold" aria-hidden /> New chat
              </button>
            </div>
            {chats.length === 0 ? (
              <p className="bk-bee-chat__history-empty">No saved chats yet. Your conversations with Beekiri appear here.</p>
            ) : (
              <ul>
                {chats.map((c) => (
                  <li key={c.id} className={c.id === chatId ? 'is-current' : ''}>
                    <button
                      type="button"
                      className="bk-bee-chat__history-open"
                      disabled={running}
                      onClick={() => {
                        void openChat(c.id);
                        setShowHistory(false);
                      }}
                    >
                      <span>{c.title || 'Untitled chat'}</span>
                      <small>{when(c.updatedAt)}</small>
                    </button>
                    <button
                      type="button"
                      className="bk-bee-chat__history-delete"
                      aria-label={`Delete “${c.title}”`}
                      title="Delete chat"
                      disabled={running && c.id === chatId}
                      onClick={() => {
                        if (window.confirm(`Delete “${c.title || 'this chat'}”? This can't be undone.`)) void deleteChat(c.id);
                      }}
                    >
                      <Trash size={14} aria-hidden />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </aside>
        ) : null}
        <div className="bk-bee-chat__scroll" ref={scrollRef}>
          {loading ? (
            <p className="bk-bee-chat__loading">
              <span className="bk-bee-chat__spinner" aria-hidden /> Opening chat…
            </p>
          ) : messages.length === 0 ? (
            <div className="bk-bee-chat__empty">
              <span className="bk-bee-chat__hero" aria-hidden>
                <span className="bk-bee-chat__scene">
                  <CubeBee brand="beequeen" />
                </span>
              </span>
              <h2>{section ? `What should change in “${section.label}”?` : 'What should we build?'}</h2>
              <p>
                {section
                  ? 'Beekiri works only on this element: its text, images, layout and style. Changes appear in the editor right away, and Undo takes them back.'
                  : 'Beekiri designs sections for your theme, adds their Backend Fields, and assembles pages you can keep editing in the page editor.'}
              </p>
              <div className="bk-bee-chat__suggestions">
                {(section ? SECTION_SUGGESTIONS : SUGGESTIONS).map((s) => (
                  <button key={s} type="button" onClick={() => submit(s)}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((m) =>
              m.role === 'user' ? (
                <div key={m.id} className="bk-bee-chat__msg is-user">
                  <div className="bk-bee-chat__bubble">{m.text}</div>
                </div>
              ) : (
                <AssistantMessage
                  key={m.id}
                  message={m}
                  onNavigate={onClose}
                  canManage={canManage}
                  {...(m.id === lastAppliedId && !running
                    ? {
                        onKeep: () => (m.applied ? chat.keepChange(m.id) : void chat.keepRun(m.id)),
                        onUndo: () => (m.applied ? chat.undoChange(m.id) : void chat.undoRun(m.id)),
                        onPreview: () => void chat.previewRun(m.id),
                      }
                    : {})}
                />
              ),
            )
          )}
        </div>
        </div>

        {section ? (
          <div className="bk-bee-chat__scope">
            <SelectionForeground size={14} aria-hidden />
            <span>
              Editing <strong>{section.label}</strong> only
            </span>
            <button
              type="button"
              className="bk-bee-chat__scope-close"
              onClick={chat.leaveSection}
              disabled={running}
              aria-label="Stop working on this element"
              title="Work on the whole site instead"
            >
              <X size={12} aria-hidden />
            </button>
          </div>
        ) : null}
        <form
          className="bk-bee-chat__composer"
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
        >
          <textarea
            ref={inputRef}
            rows={1}
            value={draft}
            placeholder={
              running
                ? `${agentName} is working…`
                : section
                  ? `Tell ${agentName} what to change in ${section.label}`
                  : `Ask ${agentName} to build or change something`
            }
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={onKeyDown}
            aria-label={`Message ${agentName}`}
          />
          {running ? (
            <button type="button" className="bk-bee-chat__send is-stop" onClick={stop} aria-label="Stop">
              <Stop size={16} weight="fill" aria-hidden />
            </button>
          ) : (
            <button type="submit" className="bk-bee-chat__send" disabled={!draft.trim()} aria-label="Send">
              <ArrowUp size={16} weight="bold" aria-hidden />
            </button>
          )}
        </form>
        <p className="bk-bee-chat__hint">
          {section
            ? 'Changes land in the editor as one step — Undo takes them back. They save with your draft.'
            : 'Works only inside your theme, Backend Fields and pages. New pages are saved as drafts.'}
        </p>
      </div>
    </div>,
    // Inside the full-screen page editor's own layer when it is open, so the editor's menus
    // and dialogs stack above the chat and the canvas below it.
    document.querySelector('.bk-page-editor') ?? document.body,
  );
}
