import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { BEEQUEEN_CREDITS, CONNECTOR_CHANGED, openBeekiriChat, type BeeQueenCreditsDetail } from '../lib/admin-events';
import { CONNECTOR_COMING_SOON } from '../lib/features';
import { formatMoney } from '../lib/money';
import './credits-toolbar.css';

type Status = { usage?: { enabled: boolean; balance?: number; currency?: string } };

/**
 * Toolbar: the site's prepaid Beekiri balance ("Balance $18.40"), and while Beekiri works,
 * what the current message has cost so far.
 */
export function CreditsToolbar() {
  const auth = useAuth();
  const allowed =
    !CONNECTOR_COMING_SOON && Boolean(auth.user?.isOwner || auth.user?.capabilities.includes('use_beequeen'));
  const [balance, setBalance] = useState<{ amount: number; currency: string } | null>(null);
  const [run, setRun] = useState<{ running: boolean; cost: number } | null>(null);
  const fadeRef = useRef<number | null>(null);

  const load = useCallback(() => {
    if (!allowed) return;
    api<Status>('/api/connector/beequeen/status')
      .then((s) => {
        const u = s.usage;
        setBalance(u?.enabled && typeof u.balance === 'number' ? { amount: u.balance, currency: u.currency || 'USD' } : null);
      })
      .catch(() => setBalance(null));
  }, [allowed]);

  useEffect(() => {
    load();
    window.addEventListener(CONNECTOR_CHANGED, load);
    return () => window.removeEventListener(CONNECTOR_CHANGED, load);
  }, [load]);

  useEffect(() => {
    const onUsage = (e: Event) => {
      const d = (e as CustomEvent<BeeQueenCreditsDetail>).detail;
      if (typeof d.balance === 'number') {
        const amount = d.balance;
        setBalance((b) => (b ? { ...b, amount } : b));
      }
      if (fadeRef.current) window.clearTimeout(fadeRef.current);
      // A reply that cost nothing (thanks, small talk) shows no "this message" badge.
      if (!d.running && !d.runCost) {
        setRun(null);
        return;
      }
      setRun({ running: d.running, cost: typeof d.runCost === 'number' ? d.runCost : 0 });
      // Keep "this message" in view for a moment after the run, then settle back to the balance.
      if (!d.running) {
        fadeRef.current = window.setTimeout(() => setRun(null), 8000);
        load();
      }
    };
    window.addEventListener(BEEQUEEN_CREDITS, onUsage);
    return () => {
      window.removeEventListener(BEEQUEEN_CREDITS, onUsage);
      if (fadeRef.current) window.clearTimeout(fadeRef.current);
    };
  }, [load]);

  if (!balance) return null;
  const empty = balance.amount <= 0;
  const left = formatMoney(Math.max(0, balance.amount), balance.currency);

  const body = (
    <>
      <img src="/admin/connector/claude.svg" alt="" width={14} height={14} draggable={false} className="bk-credits__icon" />
      <span className="bk-credits__label">Balance</span>
      <span className="bk-credits__value">
        <strong>{left}</strong>
        {empty ? <span className="bk-credits__total"> — add money</span> : null}
      </span>
      {run ? (
        <span className={`bk-credits__run${run.running ? ' is-live' : ''}`} aria-live="polite">
          {run.running
            ? run.cost
              ? `−${formatMoney(run.cost, balance.currency, true)} so far`
              : 'working…'
            : `−${formatMoney(run.cost, balance.currency, true)} this message`}
        </span>
      ) : null}
    </>
  );
  const title = empty
    ? 'The Beekiri balance is empty — an administrator can add money under Connector'
    : `${left} left on the Beekiri balance — prepaid, each message takes its cost`;
  const className = `bk-credits${run?.running ? ' is-running' : ''}${empty ? ' is-empty' : ''}`;

  // Clicking opens the Beekiri chat (the balance and top-ups live on the Connector page).
  return (
    <button type="button" className={className} title={`${title}. Click to open Beekiri.`} onClick={openBeekiriChat}>
      {body}
    </button>
  );
}
