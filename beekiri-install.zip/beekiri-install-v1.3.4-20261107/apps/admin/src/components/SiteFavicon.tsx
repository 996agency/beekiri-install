import { useEffect } from 'react';
import { api } from '../api/client';

const DEFAULT_FAVICON = '/icon-512.png';

function applyFavicon(href: string) {
  const url = href.trim() || DEFAULT_FAVICON;

  const ensure = (rel: string, attrs: Record<string, string> = {}) => {
    let link = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`);
    if (!link) {
      link = document.createElement('link');
      link.rel = rel;
      document.head.appendChild(link);
    }
    for (const [key, value] of Object.entries(attrs)) {
      link.setAttribute(key, value);
    }
    link.href = url;
  };

  // Drop alternate icon formats so the tab always shows the same mark as the public site.
  document
    .querySelectorAll<HTMLLinkElement>('link[rel="icon"], link[rel="shortcut icon"]')
    .forEach((el) => el.remove());

  ensure('icon', { type: 'image/png' });
  ensure('shortcut icon', { type: 'image/png' });
  ensure('apple-touch-icon');
}

/** Keeps admin tab favicon in sync with Settings → General (same as the public site). */
export function SiteFavicon() {
  useEffect(() => {
    applyFavicon(DEFAULT_FAVICON);
    let cancelled = false;
    api<{ faviconResolved?: string; faviconUrl?: string }>('/api/site/settings')
      .then((s) => {
        if (cancelled) return;
        applyFavicon(s.faviconResolved || s.faviconUrl || DEFAULT_FAVICON);
      })
      .catch(() => {
        /* keep default */
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return null;
}
