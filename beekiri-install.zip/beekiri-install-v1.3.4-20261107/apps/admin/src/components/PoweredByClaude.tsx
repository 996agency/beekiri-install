import './powered-by-claude.css';

/** "Powered by Claude" mark for the Beekiri agent — it runs on Anthropic's Claude API. */
export function PoweredByClaude({ detailed = false }: { detailed?: boolean }) {
  return (
    <p className={`bk-powered${detailed ? ' is-detailed' : ''}`}>
      <img src="/admin/connector/claude.svg" alt="" width={16} height={16} draggable={false} />
      <span>
        Powered by <strong>Claude</strong>
        {detailed ? ' · Anthropic API — Claude Opus 5.5, Sonnet 5.5, Haiku 5.5 and Fable 5.1' : ''}
      </span>
    </p>
  );
}
