import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';

const DISMISS_MS = 5000;

/** Viewport-fixed bottom toast for errors; auto-hides after 5s (hover keeps it open). */
export function ErrorNotice({ message, onDismiss }: { message: string; onDismiss: () => void }) {
  const onDismissRef = useRef(onDismiss);
  onDismissRef.current = onDismiss;
  const timer = useRef<number | null>(null);

  const arm = () => {
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => onDismissRef.current(), DISMISS_MS);
  };

  useEffect(() => {
    arm();
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
    };
  }, [message]);

  if (typeof document === 'undefined') return null;

  return createPortal(
    <div
      className="beekiri-notice is-error bk-toast-notice"
      role="alert"
      onMouseEnter={() => timer.current && window.clearTimeout(timer.current)}
      onMouseLeave={arm}
    >
      <p>{message}</p>
      <button type="button" className="bk-toast-notice__close" aria-label="Dismiss" onClick={() => onDismissRef.current()}>
        ×
      </button>
    </div>,
    document.body,
  );
}
