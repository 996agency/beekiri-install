import { useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { useAdminEntry } from '../lib/AdminEntryContext';

const STORAGE_KEY = 'bk-enter-from-site';
const READY_EVENT = 'beekiri:site-enter-ready';

function clearFromSiteQuery(pathname: string, search: string): string | null {
  const params = new URLSearchParams(search);
  if (!params.has('from') || params.get('from') !== 'site') return null;
  params.delete('from');
  const next = params.toString();
  return next ? `${pathname}?${next}` : pathname;
}

function escapeRe(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function isEditorPath(pathname: string, base: string): boolean {
  const b = escapeRe(base);
  return (
    new RegExp(`^${b}/pages/[^/]+/?$`).test(pathname) ||
    new RegExp(`^${b}/posts/[^/]+/?$`).test(pathname) ||
    new RegExp(`^${b}/content/[^/]+/[^/]+/?$`).test(pathname)
  );
}

function readySelector(pathname: string, base: string): string {
  if (isEditorPath(pathname, base)) return '.bk-page-editor.is-fullscreen';
  if (pathname.startsWith(`${base}/settings`)) return '.bk-tabs, #bk-body .form-table';
  return '#bk-body .wrap, #bk-body .bk-dashboard, #dashboard-widgets';
}

function coverLabel(pathname: string, base: string): string {
  if (isEditorPath(pathname, base)) return 'Opening editor…';
  if (pathname.startsWith(`${base}/settings`)) return 'Opening settings…';
  return 'Opening admin…';
}

function dismissEnterCover() {
  try {
    sessionStorage.removeItem(STORAGE_KEY);
  } catch {
    /* ignore */
  }
  document.documentElement.classList.remove('bk-from-site');
  const el = document.getElementById('bk-site-enter');
  if (!el) return;
  el.style.transition = 'opacity 0.28s ease';
  el.style.opacity = '0';
  window.setTimeout(() => el.remove(), 300);
}

function syncCoverLabel(pathname: string, base: string) {
  const label = document.querySelector('#bk-site-enter .bk-site-enter__label');
  if (label) label.textContent = coverLabel(pathname, base);
}

/**
 * Keeps the site→admin handoff cover up until the destination UI is actually painted
 * (editor canvas / settings / dashboard) — not merely until auth resolves.
 */
export function SiteEnterCover() {
  const auth = useAuth();
  const { basePath } = useAdminEntry();
  const location = useLocation();
  const navigate = useNavigate();
  const started = useRef(Date.now());
  const cleanedQuery = useRef(false);
  const dismissed = useRef(false);

  useEffect(() => {
    const fromFlag =
      typeof sessionStorage !== 'undefined' &&
      sessionStorage.getItem(STORAGE_KEY) === '1';
    const fromQuery = new URLSearchParams(location.search).get('from') === 'site';
    if (!fromFlag && !fromQuery) {
      if (!dismissed.current) {
        document.documentElement.classList.remove('bk-from-site');
        document.getElementById('bk-site-enter')?.remove();
      }
      return;
    }

    dismissed.current = false;
    started.current = Date.now();
    syncCoverLabel(location.pathname, basePath);

    if (!cleanedQuery.current && fromQuery) {
      cleanedQuery.current = true;
      const next = clearFromSiteQuery(location.pathname, location.search);
      if (next) navigate(next, { replace: true });
    }

    if (auth.loading) return;

    const minMs = 420;
    const maxMs = 8000;
    let done = false;
    let raf = 0;
    let timer = 0;

    const finish = () => {
      if (done || dismissed.current) return;
      done = true;
      dismissed.current = true;
      window.cancelAnimationFrame(raf);
      window.clearTimeout(timer);
      dismissEnterCover();
    };

    const onReady = () => finish();
    window.addEventListener(READY_EVENT, onReady);

    const tick = () => {
      const elapsed = Date.now() - started.current;
      if (elapsed >= maxMs) {
        finish();
        return;
      }
      const sel = readySelector(location.pathname, basePath);
      if (elapsed >= minMs && document.querySelector(sel)) {
        finish();
        return;
      }
      raf = window.requestAnimationFrame(tick);
    };
    raf = window.requestAnimationFrame(tick);
    timer = window.setTimeout(finish, maxMs);

    return () => {
      window.removeEventListener(READY_EVENT, onReady);
      window.cancelAnimationFrame(raf);
      window.clearTimeout(timer);
    };
  }, [
    auth.loading,
    basePath,
    location.pathname,
    location.search,
    navigate,
  ]);

  return null;
}

/** Call when a destination screen has painted its main UI. */
export function signalSiteEnterReady() {
  window.dispatchEvent(new Event(READY_EVENT));
}
