import { useEffect, useRef } from 'react';
import { BeekiriGlassReveal } from './glass-logo-reveal';
import './login-welcome.css';

/** Post-sign-in glass preloader duration. */
const WELCOME_MS = 1400;
const REDUCED_MS = 500;

type Props = {
  onDone: () => void;
};

/** Silent post-sign-in preloader — logo glass reveal only, then dashboard. */
export function LoginWelcome({ onDone }: Props) {
  const doneRef = useRef(false);

  const finish = () => {
    if (doneRef.current) return;
    doneRef.current = true;
    onDone();
  };

  useEffect(() => {
    const reduced =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const t = window.setTimeout(finish, reduced ? REDUCED_MS : WELCOME_MS);
    return () => {
      window.clearTimeout(t);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- mount-once welcome
  }, []);

  return (
    <div className="bk-login-welcome" role="status" aria-label="Loading Beekiri" aria-live="polite">
      <BeekiriGlassReveal className="bk-glass-reveal" />
    </div>
  );
}
