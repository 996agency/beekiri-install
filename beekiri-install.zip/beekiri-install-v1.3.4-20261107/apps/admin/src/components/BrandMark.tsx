type Props = {
  /** Logo height in px; the width follows the artwork. */
  size?: number;
  className?: string;
  title?: string;
  /** `mark` = short "bee" logo (default), `logo` = full "beekiri" wordmark. */
  variant?: 'mark' | 'logo';
  /** `white` for dark backgrounds. */
  tone?: 'primary' | 'white';
};

/** Artwork aspect ratios (width / height) of the brand SVGs in public/brand/. */
const RATIO = { mark: 964 / 429, logo: 1677 / 407 };

/** Beekiri brand logo (navy + orange; see public/brand/). */
export function BrandMark({ size = 56, className, title = 'Beekiri', variant = 'mark', tone = 'primary' }: Props) {
  const file = `beekiri-${variant}${tone === 'white' ? '-white' : ''}.svg`;
  return (
    <img
      src={`${import.meta.env.BASE_URL}brand/${file}`}
      alt={title}
      width={Math.round(size * RATIO[variant])}
      height={size}
      className={className}
      decoding="async"
      style={{ width: 'auto', height: size, display: 'block' }}
    />
  );
}
