import { useCallback, useEffect, useRef, useState } from 'react';
import { api, API_BASE, ApiError, getCsrfToken } from '../api/client';
import { confirmDialog } from './ConfirmDialog';
import {
  applyBeekiriSection,
  BEEKIRI_SECTION_PREVIEW,
  type BeekiriSectionPreviewDetail,
  type BeekiriSectionScope,
  notifyBeeQueenCredits,
  notifyBeekiriActivity,
  snapshotBeekiriSection,
  type BeekiriSectionTarget,
  type BeekiriSectionUpdateDetail,
} from '../lib/admin-events';

/** preview: `url` is a private preview of what waits for Keep; `livePath` is the page itself. */
export type BeeLink = {
  kind: 'layout' | 'page' | 'post' | 'product' | 'media' | 'file' | 'type' | 'entry';
  label: string;
  admin?: string;
  url?: string;
  preview?: boolean;
  livePath?: string;
};

export type BeeStep = { kind: 'status' | 'note'; text: string };

export type BeeMessage = {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  steps?: BeeStep[];
  links?: BeeLink[];
  state?: 'running' | 'done' | 'error' | 'stopped';
  model?: string | null;
  /** What this run cost (USD, taken from the prepaid balance). */
  cost?: number;
  /** The run this reply belongs to: Undo reverts every change it recorded. */
  runId?: string;
  /** Outside section mode: this reply saved changes (pages, layouts, products…), so Keep / Undo is offered. */
  changed?: boolean;
  /** The run could not start because the account is out of credits. */
  needsCredits?: boolean;
  /** Section mode: times this reply changed the element in the editor. */
  applied?: number;
  /** Section mode: the element as it was before this reply, so Undo can put it back. */
  before?: { pageId: string; nodeId: string; tree: BeekiriSectionScope['tree'] };
  /** The owner's verdict on the change. */
  decision?: 'kept' | 'undone';
};

export type BeeChatSummary = { id: string; title: string; updatedAt: string };

type BeeEvent =
  | { type: 'chat'; chatId: string; title: string; runId?: string }
  | { type: 'status'; text: string }
  | { type: 'note'; text: string }
  | { type: 'done'; reply: string; links: BeeLink[]; model: string }
  | { type: 'error'; message: string; needsCredits?: boolean }
  | { type: 'charge'; cost: number; balance?: number; monthCost: number; final?: boolean }
  | ({ type: 'section' } & BeekiriSectionUpdateDetail)
  | ({ type: 'preview' } & BeekiriSectionPreviewDetail);

class StartError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
  }
}

/** Which chat to reopen in this browser (the chats themselves live on the server). */
const LAST_CHAT_KEY = 'bk-beequeen-last-chat';
/** Set while the remembered chat is about an element in the page editor. */
const EDITOR_CHAT_KEY = 'bk-beequeen-last-chat-editor';

const uid = () => Math.random().toString(36).slice(2, 10);

function readLastChat(): string | null {
  try {
    return localStorage.getItem(LAST_CHAT_KEY);
  } catch {
    return null;
  }
}

function writeLastChat(id: string | null) {
  try {
    if (id) localStorage.setItem(LAST_CHAT_KEY, id);
    else localStorage.removeItem(LAST_CHAT_KEY);
  } catch {
    /* storage blocked — the chat still works, it just won't reopen by itself */
  }
}

function readEditorChat(): boolean {
  try {
    return localStorage.getItem(EDITOR_CHAT_KEY) === '1';
  } catch {
    return false;
  }
}

function writeEditorChat(on: boolean) {
  try {
    if (on) localStorage.setItem(EDITOR_CHAT_KEY, '1');
    else localStorage.removeItem(EDITOR_CHAT_KEY);
  } catch {
    /* storage blocked */
  }
}

async function readError(res: Response): Promise<string> {
  try {
    const data = (await res.json()) as { message?: unknown };
    if (Array.isArray(data.message)) return data.message.map(String).join(' ');
    if (data.message) return String(data.message);
  } catch {
    /* not JSON */
  }
  return res.statusText || 'BeeQueen could not start.';
}

/**
 * BeeQueen conversations, saved on the server per user. Lives in the floating widget,
 * so closing the chat keeps a run going until it finishes or is stopped.
 */
export function useBeeQueenChat() {
  const [chatId, setChatId] = useState<string | null>(readLastChat);
  const [messages, setMessages] = useState<BeeMessage[]>([]);
  const [chats, setChats] = useState<BeeChatSummary[]>([]);
  const [running, setRunning] = useState(false);
  const [loading, setLoading] = useState(false);
  /** This month's spend, as the last billed run reported it (null until one does). */
  const [monthCost, setMonthCost] = useState<number | null>(null);
  /** What the current (or last) run has cost so far — counts up while Beekiri works. */
  const [runCost, setRunCost] = useState<number | null>(null);
  /** Section mode: Beekiri works on this one element of the page open in the editor. */
  const [section, setSection] = useState<BeekiriSectionTarget | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const loadedRef = useRef<string | null>(null);

  useEffect(() => () => abortRef.current?.abort(), []);

  const refreshChats = useCallback(async () => {
    try {
      const res = await api<{ chats: BeeChatSummary[] }>('/api/connector/chats');
      setChats(res.chats ?? []);
    } catch {
      /* the list is a convenience; the current chat still works */
    }
  }, []);

  const openChat = useCallback(async (id: string) => {
    if (abortRef.current) return;
    setLoading(true);
    try {
      const res = await api<{ id: string; messages: BeeMessage[] }>(`/api/connector/chats/${encodeURIComponent(id)}`);
      setMessages(res.messages ?? []);
      setChatId(res.id);
      loadedRef.current = res.id;
      writeLastChat(res.id);
    } catch {
      // Deleted elsewhere or no longer ours — start fresh.
      setMessages([]);
      setChatId(null);
      loadedRef.current = null;
      writeLastChat(null);
    } finally {
      setLoading(false);
    }
  }, []);

  /** First open: list the chats and bring back the one this browser used last. */
  const load = useCallback(async () => {
    void refreshChats();
    if (chatId && loadedRef.current !== chatId && !abortRef.current) await openChat(chatId);
  }, [chatId, openChat, refreshChats]);

  const patch = useCallback((id: string, update: (m: BeeMessage) => BeeMessage) => {
    setMessages((list) => list.map((m) => (m.id === id ? update(m) : m)));
  }, []);

  const send = useCallback(
    async (raw: string) => {
      const prompt = raw.trim();
      if (!prompt || running) return;
      // The element as it is right now in the editor (the owner may have edited it since).
      const scope = section ? snapshotBeekiriSection(section) : null;
      if (section && !scope) {
        setMessages((list) => [
          ...list,
          { id: uid(), role: 'user', text: prompt },
          {
            id: uid(),
            role: 'assistant',
            text: 'That element is no longer open in the editor. Select it again and choose Ask Beekiri.',
            state: 'error',
          },
        ]);
        setSection(null);
        return;
      }
      const replyId = uid();
      setMessages((list) => [
        ...list,
        { id: uid(), role: 'user', text: prompt },
        {
          id: replyId,
          role: 'assistant',
          text: '',
          steps: [],
          state: 'running',
          ...(scope ? { before: { pageId: scope.pageId, nodeId: scope.nodeId, tree: scope.tree } } : {}),
        },
      ]);
      // Sending again means the last section edit is fine. Saved changes wait for an explicit Keep:
      // what they added to live pages stays hidden from visitors until then (Change history has Keep too).
      setMessages((list) => list.map((m) => (m.applied && !m.decision && m.id !== replyId ? { ...m, decision: 'kept' } : m)));
      setRunning(true);
      writeEditorChat(Boolean(scope));
      notifyBeeQueenCredits({ running: true, runCost: 0 });
      const where = scope ? { pageId: scope.pageId, nodeId: scope.nodeId, label: scope.label } : {};
      notifyBeekiriActivity({ running: true, ...where, step: 'Getting started' });
      setRunCost(0);
      let runCost = 0;

      const abort = new AbortController();
      abortRef.current = abort;
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      const csrf = getCsrfToken();
      if (csrf) headers['X-CSRF-Token'] = csrf;

      const apply = (event: BeeEvent) => {
        if (event.type === 'chat') {
          if (event.runId) patch(replyId, (m) => ({ ...m, runId: event.runId }));
          setChatId(event.chatId);
          loadedRef.current = event.chatId;
          writeLastChat(event.chatId);
          setChats((list) => [
            { id: event.chatId, title: event.title, updatedAt: new Date().toISOString() },
            ...list.filter((c) => c.id !== event.chatId),
          ]);
        } else if (event.type === 'status' || event.type === 'note') {
          patch(replyId, (m) => ({ ...m, steps: [...(m.steps ?? []), { kind: event.type, text: event.text }] }));
          if (event.type === 'status') notifyBeekiriActivity({ running: true, ...where, step: event.text });
        } else if (event.type === 'charge') {
          if (typeof event.cost !== 'number' || typeof event.monthCost !== 'number') return;
          runCost = event.cost;
          setRunCost(event.cost);
          setMonthCost(event.monthCost);
          patch(replyId, (m) => ({ ...m, cost: event.cost }));
          notifyBeeQueenCredits({
            monthCost: event.monthCost,
            balance: event.balance,
            running: !event.final,
            runCost: event.cost,
          });
        } else if (event.type === 'preview') {
          window.dispatchEvent(
            new CustomEvent<BeekiriSectionPreviewDetail>(BEEKIRI_SECTION_PREVIEW, {
              detail: { id: event.id, pageId: event.pageId, nodeId: event.nodeId },
            }),
          );
        } else if (event.type === 'section') {
          applyBeekiriSection({ pageId: event.pageId, nodeId: event.nodeId, tree: event.tree });
          patch(replyId, (m) => ({ ...m, applied: (m.applied ?? 0) + 1 }));
        } else if (event.type === 'done') {
          // Links are what the reply saved; in section mode the editor's own Keep / Undo covers the element.
          patch(replyId, (m) => ({ ...m, text: event.reply, links: event.links, model: event.model, state: 'done', changed: !m.applied && event.links.length > 0 }));
        } else {
          patch(replyId, (m) => ({ ...m, text: event.message, state: 'error', needsCredits: Boolean(event.needsCredits) }));
        }
      };

      try {
        const res = await fetch(`${API_BASE}/api/connector/agent`, {
          method: 'POST',
          headers,
          credentials: 'include',
          body: JSON.stringify({ prompt, ...(chatId ? { chatId } : {}), ...(scope ? { scope } : {}) }),
          signal: abort.signal,
        });
        if (!res.ok || !res.body) throw new StartError(await readError(res), res.status);

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        for (;;) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          let nl = buffer.indexOf('\n');
          while (nl >= 0) {
            const line = buffer.slice(0, nl).trim();
            buffer = buffer.slice(nl + 1);
            if (line) apply(JSON.parse(line) as BeeEvent);
            nl = buffer.indexOf('\n');
          }
        }
        if (buffer.trim()) apply(JSON.parse(buffer) as BeeEvent);
        // The stream ended without a verdict (server restarted, connection dropped).
        patch(replyId, (m) =>
          m.state === 'running' ? { ...m, text: 'The connection closed before BeeQueen finished.', state: 'error' } : m,
        );
      } catch (error) {
        const stopped = abort.signal.aborted;
        patch(replyId, (m) => ({
          ...m,
          text: stopped ? m.text || 'Stopped.' : error instanceof Error ? error.message : 'BeeQueen stopped.',
          state: stopped ? 'stopped' : 'error',
          needsCredits: error instanceof StartError && error.status === 402,
        }));
      } finally {
        if (abortRef.current === abort) abortRef.current = null;
        setRunning(false);
        notifyBeeQueenCredits({ running: false, runCost });
        notifyBeekiriActivity({ running: false, ...where });
      }
    },
    [chatId, patch, running, section],
  );

  const stop = useCallback(() => abortRef.current?.abort(), []);

  const newChat = useCallback(() => {
    if (abortRef.current) return;
    setMessages([]);
    setChatId(null);
    loadedRef.current = null;
    writeLastChat(null);
    writeEditorChat(false);
  }, []);

  const deleteChat = useCallback(
    async (id: string) => {
      await api(`/api/connector/chats/${encodeURIComponent(id)}`, { method: 'DELETE' });
      setChats((list) => list.filter((c) => c.id !== id));
      if (id === chatId) newChat();
    },
    [chatId, newChat],
  );

  /** Start a fresh chat about one element (from the editor's Ask Beekiri). */
  const enterSection = useCallback(
    (target: BeekiriSectionTarget) => {
      if (abortRef.current) return false;
      if (!section || section.pageId !== target.pageId || section.nodeId !== target.nodeId) newChat();
      setSection(target);
      return true;
    },
    [newChat, section],
  );

  const leaveSection = useCallback(() => setSection(null), []);

  /** Opened outside the page editor: an element conversation doesn't belong there, so start fresh. */
  const leaveEditor = useCallback(() => {
    if (abortRef.current) return;
    setSection(null);
    if (readEditorChat()) newChat();
  }, [newChat]);

  /** The editor's selection moved: keep the conversation, work on the newly selected element. */
  const followSection = useCallback((target: BeekiriSectionTarget | null) => {
    if (abortRef.current) return;
    setSection((current) =>
      !target ? null : current?.pageId === target.pageId && current.nodeId === target.nodeId ? current : target,
    );
  }, []);

  /** Keep Beekiri's change to the element. */
  const keepChange = useCallback(
    (messageId: string) => patch(messageId, (m) => ({ ...m, decision: 'kept' })),
    [patch],
  );

  /**
   * Undo Beekiri's change: the element goes back to how it was before that message (one more
   * step in the editor's history), and a fresh chat starts so the next try begins clean.
   */
  const undoChange = useCallback(
    (messageId: string) => {
      if (abortRef.current) return;
      const message = messages.find((m) => m.id === messageId);
      if (!message?.before) return;
      applyBeekiriSection(message.before);
      newChat();
      setMessages([
        {
          id: uid(),
          role: 'assistant',
          text: 'Undone — the element is back to how it was. Tell me what to try instead.',
          state: 'done',
        },
      ]);
    },
    [messages, newChat],
  );

  /** Fresh private preview links for what a reply added that still waits for Keep: its View links become Preview. */
  const previewRun = useCallback(
    async (messageId: string) => {
      const message = messages.find((m) => m.id === messageId);
      if (!message?.runId) return;
      try {
        const res = await api<{ pages: { title: string; url: string }[] }>('/api/connector/changes/preview', {
          method: 'POST',
          json: { runId: message.runId },
        });
        patch(messageId, (m) => {
          const links = [...(m.links ?? [])];
          for (const p of res.pages) {
            const i = links.findIndex((l) => (l.kind === 'page' || l.kind === 'post' || l.kind === 'entry') && p.title.startsWith(l.label.replace(/^Site section “|”$/g, '')));
            if (i >= 0) links[i] = { ...links[i], url: p.url, preview: true, livePath: links[i].livePath ?? links[i].url };
            else links.push({ kind: 'page', label: p.title, url: p.url, preview: true });
          }
          return { ...m, links };
        });
      } catch (e) {
        setMessages((list) => [
          ...list,
          { id: uid(), role: 'assistant', text: e instanceof Error ? `Could not make a preview: ${e.message}` : 'Could not make a preview.', state: 'error' },
        ]);
      }
    },
    [messages, patch],
  );

  /** Keep a whole reply outside section mode: what it added to live pages goes public now. */
  const keepRun = useCallback(
    async (messageId: string) => {
      const message = messages.find((m) => m.id === messageId);
      if (!message?.runId) return;
      try {
        const res = await api<{ kept: number }>('/api/connector/changes/keep', { method: 'POST', json: { runId: message.runId } });
        // Kept: the pages themselves show it now, so the links go back to them.
        patch(messageId, (m) => ({
          ...m,
          decision: 'kept',
          links: m.links?.map((l) => (l.preview ? { ...l, url: l.livePath ?? l.url, preview: false } : l)),
        }));
        if (res.kept) {
          setMessages((list) => [...list, { id: uid(), role: 'assistant', text: 'Kept — it’s live for your visitors now.', state: 'done' }]);
        }
      } catch (e) {
        setMessages((list) => [
          ...list,
          { id: uid(), role: 'assistant', text: e instanceof Error ? `Could not keep it: ${e.message}` : 'Could not keep that.', state: 'error' },
        ]);
      }
    },
    [messages, patch],
  );

  /**
   * Undo a whole reply outside section mode: every change it saved (pages, layouts, products…) goes back
   * to how it was, through Beekiri's change history. Something edited since asks before it is undone too.
   */
  const undoRun = useCallback(
    async (messageId: string) => {
      if (abortRef.current) return;
      const message = messages.find((m) => m.id === messageId);
      if (!message?.runId) return;
      const revert = (force: boolean) => api('/api/connector/changes/revert', { method: 'POST', json: { runId: message.runId, force } });
      try {
        try {
          await revert(false);
        } catch (e) {
          if (!(e instanceof ApiError) || e.status !== 409) throw e;
          const ok = await confirmDialog({
            title: 'Undo anyway?',
            message: `${e.message} Undo anyway?`,
            confirmLabel: 'Undo anyway',
          });
          if (!ok) return;
          await revert(true);
        }
        patch(messageId, (m) => ({ ...m, decision: 'undone' }));
        setMessages((list) => [
          ...list,
          { id: uid(), role: 'assistant', text: 'Undone — everything that message changed is back to how it was. Tell me what to try instead.', state: 'done' },
        ]);
        // An open page editor still holds the old version: reload it so it can't save that back.
        if (/\/pages\/[^/]+/.test(window.location.pathname)) window.setTimeout(() => window.location.reload(), 1200);
      } catch (e) {
        setMessages((list) => [
          ...list,
          { id: uid(), role: 'assistant', text: e instanceof Error ? `Could not undo: ${e.message}` : 'Could not undo that.', state: 'error' },
        ]);
      }
    },
    [messages, patch],
  );

  return {
    chatId,
    messages,
    chats,
    running,
    loading,
    monthCost,
    runCost,
    section,
    load,
    send,
    stop,
    newChat,
    openChat,
    deleteChat,
    enterSection,
    leaveSection,
    leaveEditor,
    followSection,
    keepChange,
    undoChange,
    keepRun,
    previewRun,
    undoRun,
  };
}
