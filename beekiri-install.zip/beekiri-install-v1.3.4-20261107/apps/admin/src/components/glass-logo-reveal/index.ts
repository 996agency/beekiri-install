export {
  GlassIconReveal,
  BeekiriGlassReveal,
  type GlassIconRevealProps,
  type BeekiriGlassRevealProps,
} from './GlassIconReveal';
