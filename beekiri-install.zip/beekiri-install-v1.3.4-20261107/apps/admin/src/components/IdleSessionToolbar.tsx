import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { useAdminEntry } from '../lib/AdminEntryContext';
import {
  IDLE_TIMEOUT_MS,
  IDLE_WARN_MS,
  formatIdleCountdown,
  idleAnnounceIntervalMs,
  markIdleSignOut,
} from '../lib/idle-session';

const ACTIVITY_EVENTS: (keyof DocumentEventMap)[] = [
  'pointerdown',
  'keydown',
  'mousemove',
  'wheel',
  'touchstart',
  'scroll',
];

/** Once the warning is up, only a deliberate click, tap or key press counts as "still here". */
const DELIBERATE_EVENTS = new Set(['pointerdown', 'keydown', 'touchstart']);

/** Shared by every admin tab, so working in one tab keeps the others signed in too. */
const ACTIVITY_KEY = 'beekiri-admin-activity';
const SIGNED_OUT_KEY = 'beekiri-admin-idle-signout';

function readShared(key: string): number {
  try {
    return Number(window.localStorage.getItem(key)) || 0;
  } catch {
    return 0;
  }
}

function writeShared(key: string, value: number): void {
  try {
    window.localStorage.setItem(key, String(value));
  } catch {
    /* private mode: this tab still keeps its own timer */
  }
}

/**
 * Inactivity sign-out (20 minutes). Two minutes before, a dialog and the toolbar show a
 * countdown with "Stay signed in"; the tab title counts down too. On time-out the person lands
 * on the sign-in page with the reason, and returns to the same screen after signing in.
 */
export function IdleSessionToolbar() {
  const auth = useAuth();
  const entry = useAdminEntry();
  const navigate = useNavigate();
  const location = useLocation();
  const [remainingMs, setRemainingMs] = useState(IDLE_TIMEOUT_MS);
  const [announce, setAnnounce] = useState('');
  const lastActivityRef = useRef(Date.now());
  const lastBumpAtRef = useRef(0);
  const lastSharedAtRef = useRef(0);
  const timedOutRef = useRef(false);
  const lastAnnounceAtRef = useRef(0);
  const warningShownRef = useRef(false);
  const hereRef = useRef(`${location.pathname}${location.search}`);
  hereRef.current = `${location.pathname}${location.search}`;

  const bump = useCallback(() => {
    const now = Date.now();
    lastActivityRef.current = now;
    timedOutRef.current = false;
    warningShownRef.current = false;
    if (now - lastSharedAtRef.current > 5000) {
      lastSharedAtRef.current = now;
      writeShared(ACTIVITY_KEY, now);
    }
  }, []);

  const staySignedIn = useCallback(() => {
    lastSharedAtRef.current = 0;
    bump();
    setRemainingMs(IDLE_TIMEOUT_MS);
    setAnnounce('Session extended. You will stay signed in.');
    lastAnnounceAtRef.current = Date.now();
    void auth.refresh().catch(() => {
      /* local timer still reset */
    });
  }, [auth, bump]);

  const leave = useCallback(
    (reason: 'idle' | 'manual') => {
      timedOutRef.current = true;
      if (reason === 'idle') {
        markIdleSignOut();
        writeShared(SIGNED_OUT_KEY, Date.now());
      }
      void (async () => {
        try {
          await auth.logout();
        } catch {
          /* still leave the shell */
        }
        const back = encodeURIComponent(hereRef.current);
        navigate(reason === 'idle' ? `${entry.path}?reason=idle&redirect_to=${back}` : entry.path, { replace: true });
      })();
    },
    [auth, entry.path, navigate],
  );

  useEffect(() => {
    if (!auth.authenticated) return;
    lastSharedAtRef.current = 0;
    bump();

    const onActivity = (event: Event) => {
      // The dialog's own buttons decide for themselves (else "Sign out now" would extend first).
      if ((event.target as Element | null)?.closest?.('[data-idle-dialog]')) return;
      const now = Date.now();
      const idleFor = now - lastActivityRef.current;
      const wasWarning = idleFor >= IDLE_TIMEOUT_MS - IDLE_WARN_MS;
      if (wasWarning && !DELIBERATE_EVENTS.has(event.type)) return;
      if (!wasWarning && now - lastBumpAtRef.current < 800) return;
      lastBumpAtRef.current = now;
      if (wasWarning) lastSharedAtRef.current = 0;
      bump();
      if (wasWarning) {
        setRemainingMs(IDLE_TIMEOUT_MS);
        setAnnounce('Session extended. You will stay signed in.');
        lastAnnounceAtRef.current = now;
        void auth.refresh().catch(() => undefined);
      }
    };

    // Another admin tab was used, or timed out.
    const onStorage = (event: StorageEvent) => {
      if (event.key === ACTIVITY_KEY) {
        const at = Number(event.newValue) || 0;
        if (at > lastActivityRef.current) {
          lastActivityRef.current = at;
          warningShownRef.current = false;
          setRemainingMs(IDLE_TIMEOUT_MS - (Date.now() - at));
        }
      } else if (event.key === SIGNED_OUT_KEY && !timedOutRef.current) {
        timedOutRef.current = true;
        markIdleSignOut();
        navigate(`${entry.path}?reason=idle&redirect_to=${encodeURIComponent(hereRef.current)}`, { replace: true });
        void auth.refresh().catch(() => undefined);
      }
    };

    for (const ev of ACTIVITY_EVENTS) {
      document.addEventListener(ev, onActivity, { capture: true, passive: true });
    }
    window.addEventListener('storage', onStorage);

    const tick = window.setInterval(() => {
      if (timedOutRef.current) return;
      const shared = readShared(ACTIVITY_KEY);
      if (shared > lastActivityRef.current) lastActivityRef.current = shared;
      const left = IDLE_TIMEOUT_MS - (Date.now() - lastActivityRef.current);
      setRemainingMs(Math.max(0, left));

      if (left <= IDLE_WARN_MS && left > 0) {
        const now = Date.now();
        if (!warningShownRef.current) {
          warningShownRef.current = true;
          setAnnounce(`You will be signed out in ${formatIdleCountdown(left)} due to inactivity.`);
          lastAnnounceAtRef.current = now;
        } else if (now - lastAnnounceAtRef.current >= idleAnnounceIntervalMs(left)) {
          setAnnounce(`You will be signed out in ${formatIdleCountdown(left)}.`);
          lastAnnounceAtRef.current = now;
        }
      }

      if (left <= 0) {
        setAnnounce('Signed out due to inactivity.');
        leave('idle');
      }
    }, 1000);

    return () => {
      for (const ev of ACTIVITY_EVENTS) {
        document.removeEventListener(ev, onActivity, true);
      }
      window.removeEventListener('storage', onStorage);
      window.clearInterval(tick);
    };
  }, [auth, bump, entry.path, leave, navigate]);

  const warning = auth.authenticated && remainingMs <= IDLE_WARN_MS && remainingMs > 0;
  const countdown = formatIdleCountdown(remainingMs);

  // The tab title counts down too, for when the admin is in a background tab.
  useEffect(() => {
    if (!warning) return;
    const original = document.title;
    document.title = `(${countdown}) Signing out soon · ${original.replace(/^\(\d+:\d{2}\) Signing out soon · /, '')}`;
    return () => {
      document.title = original;
    };
  }, [warning, countdown]);

  if (!warning && !announce) {
    return <span className="screen-reader-text" aria-live="polite" aria-atomic="true" />;
  }

  return (
    <>
      <span className="screen-reader-text" aria-live="polite" aria-atomic="true">
        {announce}
      </span>
      {warning ? (
        <>
          <div className="bk-toolbar-idle" role="status" aria-label={`Inactivity warning: signed out in ${countdown}`}>
            <span className="bk-toolbar-idle__msg">
              Signed out in{' '}
              <time className="bk-toolbar-idle__count" dateTime={`PT${Math.ceil(remainingMs / 1000)}S`}>
                {countdown}
              </time>{' '}
              if inactive
            </span>
            <button type="button" className="bk-toolbar-idle__btn" onClick={staySignedIn}>
              Stay signed in
            </button>
          </div>
          {createPortal(
            <div className="bk-confirm" data-idle-dialog role="alertdialog" aria-modal="true" aria-labelledby="bk-idle-title" aria-describedby="bk-idle-text">
              <div className="bk-confirm__panel">
                <div className="bk-confirm__head">
                  <h2 id="bk-idle-title" className="bk-confirm__title">
                    Are you still there?
                  </h2>
                </div>
                <div className="bk-confirm__body">
                  <p id="bk-idle-text" className="bk-confirm__message">
                    For your security, you will be signed out in{' '}
                    <strong className="bk-idle__count">{countdown}</strong> because there has been no activity for a while.
                    Unsaved changes may be lost.
                  </p>
                </div>
                <div className="bk-confirm__actions">
                  <button type="button" className="button" onClick={() => leave('manual')}>
                    Sign out now
                  </button>
                  <button type="button" className="button button-primary" onClick={staySignedIn} autoFocus>
                    Stay signed in
                  </button>
                </div>
              </div>
            </div>,
            document.body,
          )}
        </>
      ) : null}
    </>
  );
}
