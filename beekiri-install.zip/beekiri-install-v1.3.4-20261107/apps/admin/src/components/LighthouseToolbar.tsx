import { useCallback, useEffect, useState } from 'react';
import { api, ApiError } from '../api/client';

type Scores = {
  url: string;
  performance: number;
  accessibility: number;
  bestPractices: number;
  seo: number;
  checkedAt: string;
  source: 'lighthouse' | 'cached' | 'error';
  message: string;
  allHundred: boolean;
};

export const LIGHTHOUSE_STORAGE_KEY = 'beekiri.lighthouse.scores.v1';

const METRICS = [
  {
    key: 'P',
    field: 'performance' as const,
    name: 'Pagespeed',
    tip: 'How fast your public site loads and feels to visitors.',
  },
  {
    key: 'A',
    field: 'accessibility' as const,
    name: 'Accessibility',
    tip: 'How usable the site is for everyone, including assistive tech.',
  },
  {
    key: 'B',
    field: 'bestPractices' as const,
    name: 'Best practices',
    tip: 'Security, modern web standards, and healthy page hygiene.',
  },
  {
    key: 'S',
    field: 'seo' as const,
    name: 'SEO',
    tip: 'How well the site is set up to be found in search.',
  },
];

export function lighthouseScoreTone(score: number) {
  if (score >= 90) return 'is-good';
  if (score >= 50) return 'is-ok';
  return 'is-bad';
}

export function readStoredLighthouseScores(): Scores | null {
  try {
    const raw = sessionStorage.getItem(LIGHTHOUSE_STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as Scores;
  } catch {
    return null;
  }
}

export function writeStoredLighthouseScores(scores: Scores) {
  try {
    sessionStorage.setItem(LIGHTHOUSE_STORAGE_KEY, JSON.stringify(scores));
  } catch {
    /* ignore quota */
  }
}

export function LighthouseToolbar() {
  const [scores, setScores] = useState<Scores | null>(() =>
    typeof window !== 'undefined' ? readStoredLighthouseScores() : null,
  );
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [ranThisSession, setRanThisSession] = useState(() =>
    Boolean(typeof window !== 'undefined' ? readStoredLighthouseScores() : null),
  );
  const load = useCallback(async (refresh: boolean) => {
    setBusy(true);
    setError(null);
    try {
      const path = refresh ? '/api/system/lighthouse?refresh=1' : '/api/system/lighthouse';
      const data = await api<Scores>(path);
      setScores(data);
      writeStoredLighthouseScores(data);
      setRanThisSession(true);
      if (data.source === 'error') setError(data.message);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Could not check hive status');
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    if (ranThisSession) return;
    void load(false);
  }, [load, ranThisSession]);

  const items = scores
    ? METRICS.map((m) => ({
        ...m,
        value: scores[m.field],
      }))
    : null;

  return (
    <div className="bk-lh">
      <span className="bk-lh__label">Hive status</span>
      {items ? (
        <ul className="bk-lh__scores">
          {items.map((item) => (
            <li
              key={item.key}
              className={`bk-lh__score ${lighthouseScoreTone(item.value)}`}
              aria-label={`${item.name}: ${item.value} out of 100`}
            >
              <span className="bk-lh__key">{item.key}</span>
              <span className="bk-lh__val">{item.value}</span>
              <span className="bk-lh__tip" role="tooltip">
                <span className="bk-lh__tip-title">{item.name}</span>
                <span className="bk-lh__tip-body">{item.tip}</span>
                <span className="bk-lh__tip-score">{item.value} / 100</span>
              </span>
            </li>
          ))}
        </ul>
      ) : (
        <span className="bk-lh__waiting">{busy ? 'Checking hive…' : '—'}</span>
      )}
      <button
        type="button"
        className="bk-lh__refresh"
        disabled={busy}
        onClick={() => void load(true)}
        aria-label="Re-check hive status"
        title="Re-check hive status"
      >
        {busy ? '…' : '↻'}
      </button>
      {error ? <span className="bk-lh__err" aria-live="polite">{error}</span> : null}
    </div>
  );
}
