import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CaretDown, GearSix } from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { useAdminHref } from '../lib/AdminEntryContext';
import { switchToSite } from '../screens/SitesPanel';
import './site-switcher.css';

type MySite = { id: string; title: string; url: string; adminUrl: string; isPrimary: boolean };

function initial(title: string): string {
  return (title.trim()[0] ?? '?').toUpperCase();
}

function host(url: string): string {
  return url.replace(/^https?:\/\//, '').replace(/\/$/, '');
}

/**
 * Toolbar "My sites" (multisite): the sites this person may use. Picking one opens its admin
 * already signed in. Hidden while there is only one site.
 */
export function SiteSwitcher() {
  const auth = useAuth();
  const href = useAdminHref();
  const [sites, setSites] = useState<MySite[]>([]);
  const [current, setCurrent] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!auth.user) return;
    api<{ current: string; sites: MySite[] }>('/api/network/my-sites')
      .then((r) => {
        setSites(r.sites);
        setCurrent(r.current);
      })
      .catch(() => setSites([]));
  }, [auth.user]);

  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent | KeyboardEvent) => {
      if (e instanceof KeyboardEvent ? e.key === 'Escape' : !ref.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', close);
    document.addEventListener('keydown', close);
    return () => {
      document.removeEventListener('mousedown', close);
      document.removeEventListener('keydown', close);
    };
  }, [open]);

  if (sites.length < 2) return null;
  const here = sites.find((s) => s.id === current);

  const go = async (site: MySite) => {
    if (site.id === current) {
      setOpen(false);
      return;
    }
    setBusy(site.id);
    setError(null);
    try {
      await switchToSite(site.id);
    } catch (e) {
      setBusy(null);
      setError(e instanceof ApiError ? e.message : `Could not open ${site.title}.`);
    }
  };

  return (
    <div className="bk-sitesw" ref={ref}>
      <button
        type="button"
        className="bk-sitesw__btn"
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => {
          setError(null);
          setOpen((v) => !v);
        }}
        title="Switch site"
      >
        <span className="bk-sitesw__tile is-small" aria-hidden>
          {initial(here?.title ?? 'S')}
        </span>
        <span className="bk-sitesw__name">{here?.title ?? 'My sites'}</span>
        <CaretDown size={11} weight="bold" aria-hidden className="bk-sitesw__caret" />
      </button>
      {open ? (
        <div className="bk-sitesw__menu" role="menu" aria-label="Your sites">
          <div className="bk-sitesw__head">
            <span>Your sites</span>
            <span className="bk-sitesw__count">{sites.length}</span>
          </div>
          <div className="bk-sitesw__list">
            {sites.map((site) => {
              const isCurrent = site.id === current;
              const opening = busy === site.id;
              return (
                <button
                  key={site.id}
                  type="button"
                  role="menuitem"
                  className={`bk-sitesw__item${isCurrent ? ' is-current' : ''}`}
                  disabled={busy !== null && !opening}
                  aria-current={isCurrent ? 'true' : undefined}
                  onClick={() => void go(site)}
                >
                  <span className="bk-sitesw__tile" aria-hidden>
                    {initial(site.title)}
                  </span>
                  <span className="bk-sitesw__item-text">
                    <span className="bk-sitesw__item-title">
                      {site.title}
                      {site.isPrimary ? <span className="bk-sitesw__main">Main</span> : null}
                    </span>
                    <span className="bk-sitesw__item-url">{host(site.url)}</span>
                  </span>
                  {isCurrent ? (
                    <span className="bk-sitesw__state">Current</span>
                  ) : opening ? (
                    <span className="bk-sitesw__state is-busy">Opening…</span>
                  ) : (
                    <ArrowRight size={14} aria-hidden className="bk-sitesw__go" />
                  )}
                </button>
              );
            })}
          </div>
          {error ? (
            <p className="bk-sitesw__error" role="alert">
              {error}
            </p>
          ) : null}
          {auth.user?.isOwner ? (
            <Link className="bk-sitesw__foot" to={href('settings?tab=sites')} onClick={() => setOpen(false)}>
              <GearSix size={14} aria-hidden />
              Manage sites
            </Link>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
