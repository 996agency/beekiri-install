/** Admin config so Pages, Posts, and custom post types share the same list/editor UX. */

import type { CapabilitySlug } from '../cms-types';
import { DEFAULT_ADMIN_BASE_PATH, adminHref } from '../lib/admin-login';

export type BuiltinContentKind = 'page' | 'post';
export type ContentKind = BuiltinContentKind | (string & {});

export type ContentKindConfig = {
  kind: ContentKind;
  apiBase: string;
  listPath: string;
  listKey: string;
  itemKey: string;
  editCap: CapabilitySlug;
  publishCap: CapabilitySlug;
  deleteCap: CapabilitySlug;
  label: string;
  labelLower: string;
  labelPlural: string;
  pathPrefix: string;
  blurb: string;
  emptyTitle: string;
  emptyFilteredTitle: string;
};

export type CptLabels = { singular?: string; plural?: string };

export function contentKindConfig(
  kind: ContentKind,
  labels?: CptLabels,
  basePath: string = DEFAULT_ADMIN_BASE_PATH,
): ContentKindConfig {
  if (kind === 'page') {
    return {
      kind: 'page',
      apiBase: '/api/pages',
      listPath: adminHref(basePath, 'pages'),
      listKey: 'pages',
      itemKey: 'page',
      editCap: 'edit_pages',
      publishCap: 'publish_pages',
      deleteCap: 'delete_pages',
      label: 'Page',
      labelLower: 'page',
      labelPlural: 'Pages',
      pathPrefix: '/',
      blurb: 'Create and publish pages for your site.',
      emptyTitle: 'No pages yet. Click Add new to start.',
      emptyFilteredTitle: 'No pages match these filters.',
    };
  }
  if (kind === 'post') {
    return {
      kind: 'post',
      apiBase: '/api/posts',
      listPath: adminHref(basePath, 'posts'),
      listKey: 'posts',
      itemKey: 'post',
      editCap: 'edit_posts',
      publishCap: 'publish_posts',
      deleteCap: 'delete_posts',
      label: 'Post',
      labelLower: 'post',
      labelPlural: 'Posts',
      pathPrefix: '/blog/',
      blurb: 'Create and publish single blog posts.',
      emptyTitle: 'No posts yet. Click Add new to start.',
      emptyFilteredTitle: 'No posts match these filters.',
    };
  }

  if (kind === 'shop_page') {
    return {
      kind,
      apiBase: '/api/content/shop_page',
      listPath: adminHref(basePath, 'shop/pages'),
      listKey: 'items',
      itemKey: 'item',
      editCap: 'edit_products',
      publishCap: 'edit_products',
      deleteCap: 'manage_shop',
      label: 'Shop page',
      labelLower: 'shop page',
      labelPlural: 'Shop pages',
      pathPrefix: '/',
      blurb: 'Design the storefront pages around the shop content.',
      emptyTitle: 'No shop pages.',
      emptyFilteredTitle: 'No shop pages match.',
    };
  }

  const singular = (labels?.singular || kind).trim() || kind;
  const plural = (labels?.plural || `${singular}s`).trim() || `${singular}s`;
  const lower = singular.toLowerCase();
  return {
    kind,
    apiBase: `/api/content/${kind}`,
    listPath: adminHref(basePath, `content/${kind}`),
    listKey: 'items',
    itemKey: 'item',
    editCap: 'edit_posts',
    publishCap: 'publish_posts',
    deleteCap: 'delete_posts',
    label: singular,
    labelLower: lower,
    labelPlural: plural,
    pathPrefix: `/${kind}/`,
    blurb: `Create and publish ${plural.toLowerCase()}.`,
    emptyTitle: `No ${plural.toLowerCase()} yet. Click Add new to start.`,
    emptyFilteredTitle: `No ${plural.toLowerCase()} match these filters.`,
  };
}
