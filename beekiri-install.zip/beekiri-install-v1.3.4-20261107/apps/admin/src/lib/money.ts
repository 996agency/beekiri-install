/**
 * Money amounts (packs, totals). `fine` shows small per-message prices to a tenth of a cent
 * ("$0.042"), and anything under a cent as "<$0.01".
 */
export function formatMoney(amount: number, currency = 'USD', fine = false): string {
  const fmt = (v: number, digits: number) => {
    try {
      return new Intl.NumberFormat(undefined, { style: 'currency', currency, minimumFractionDigits: digits, maximumFractionDigits: digits }).format(v);
    } catch {
      return `$${v.toFixed(digits)}`;
    }
  };
  if (fine && amount > 0 && amount < 0.01) return `<${fmt(0.01, 2)}`;
  return fmt(amount, fine && amount < 1 ? 3 : 2);
}

