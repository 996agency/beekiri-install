/**
 * Client-side admin inactivity lock.
 * 20 minutes total, warn with ≥2 minutes left (WCAG 2.2.1 / GOV.UK timeout pattern).
 */
export const IDLE_TIMEOUT_MS = 20 * 60 * 1000;
export const IDLE_WARN_MS = 2 * 60 * 1000;

/**
 * Set just before an inactivity sign-out and shown by the sign-in page until the next sign-in.
 * Signing out makes the admin redirect to sign-in by itself (the page can load twice), which can
 * win over our own `?reason=idle` link, so the reason travels in this tab's session storage.
 */
const IDLE_FLAG = 'beekiri-idle-signout';
const IDLE_FLAG_TTL_MS = 2 * 60 * 60 * 1000;

export function markIdleSignOut(): void {
  try {
    window.sessionStorage.setItem(IDLE_FLAG, String(Date.now()));
  } catch {
    /* the ?reason=idle link still carries it */
  }
}

export function wasIdleSignOut(): boolean {
  try {
    const at = Number(window.sessionStorage.getItem(IDLE_FLAG)) || 0;
    return at > 0 && Date.now() - at < IDLE_FLAG_TTL_MS;
  } catch {
    return false;
  }
}

export function clearIdleSignOut(): void {
  try {
    window.sessionStorage.removeItem(IDLE_FLAG);
  } catch {
    /* nothing stored */
  }
}

export function formatIdleCountdown(ms: number): string {
  const totalSec = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

/** How often aria-live should re-announce remaining time. */
export function idleAnnounceIntervalMs(remainingMs: number): number {
  if (remainingMs <= 60_000) return 20_000;
  return 30_000;
}
