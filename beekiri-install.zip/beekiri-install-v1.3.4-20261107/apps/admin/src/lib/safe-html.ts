import DOMPurify from 'dompurify';

/**
 * Server-rendered layout markup shown inside the admin. Scripts, event handlers and
 * javascript: URLs are removed before it touches the admin page, so a theme that prints
 * a field without escaping cannot run code with an administrator's session.
 */
export function sanitizePreviewHtml(html: string): string {
  return DOMPurify.sanitize(html, {
    // Keep a layout's leading <style> block (it would otherwise be hoisted and dropped).
    FORCE_BODY: true,
    ADD_TAGS: ['iframe'],
    ADD_ATTR: ['target', 'allow', 'allowfullscreen', 'frameborder', 'loading'],
    FORBID_ATTR: ['srcdoc'],
  });
}

/** Rich-text field values in the editor: formatting only. */
export function sanitizeRichText(html: string): string {
  return DOMPurify.sanitize(html, {
    USE_PROFILES: { html: true },
    FORBID_TAGS: ['style', 'iframe', 'form', 'input', 'button', 'textarea', 'select'],
    ADD_ATTR: ['target'],
  });
}

/** Links opened from the admin: http(s), mailto, tel or same-site paths only. */
export function safeHref(raw: string | null | undefined): string | undefined {
  const value = (raw ?? '').trim();
  if (!value) return undefined;
  // Browsers ignore tabs, newlines and control characters inside a scheme.
  const probe = value.replace(/[\u0000- \u007f]+/g, '');
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(probe)?.[1]?.toLowerCase();
  if (!scheme) return value;
  return ['http', 'https', 'mailto', 'tel'].includes(scheme) ? value : undefined;
}
