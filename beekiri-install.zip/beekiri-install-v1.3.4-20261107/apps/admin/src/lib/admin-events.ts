/** Cross-screen signals so the shell can refresh without a full page reload. */

export const POST_TYPES_CHANGED = 'beekiri:post-types-changed';
export const CONNECTOR_CHANGED = 'beekiri:connector-changed';
export const EXTENSIONS_CHANGED = 'beekiri:extensions-changed';

export function notifyPostTypesChanged() {
  window.dispatchEvent(new Event(POST_TYPES_CHANGED));
}

export function notifyConnectorChanged() {
  window.dispatchEvent(new Event(CONNECTOR_CHANGED));
}

/** An extension was installed, activated, deactivated or removed. */
export function notifyExtensionsChanged() {
  window.dispatchEvent(new Event(EXTENSIONS_CHANGED));
}

export const BEEQUEEN_CREDITS = 'beekiri:beequeen-credits';

/** Live balance news from the chat, for the toolbar. */
export type BeeQueenCreditsDetail = {
  /** This month's spend so far (USD), when known. */
  monthCost?: number;
  /** Balance left (USD), when known. */
  balance?: number;
  /** A run is in progress. */
  running: boolean;
  /** What the current (or just finished) run has cost so far (USD). */
  runCost: number;
};

export function notifyBeeQueenCredits(detail: BeeQueenCreditsDetail) {
  window.dispatchEvent(new CustomEvent<BeeQueenCreditsDetail>(BEEQUEEN_CREDITS, { detail }));
}

/* ── Beekiri in the editor: work on one selected element ─────────────────── */

/** The editor asks to open Beekiri on one element (section mode). */
export const BEEKIRI_ASK_SECTION = 'beekiri:ask-section';
/** The chat asks the open editor for the element's current tree, right before sending. */
export const BEEKIRI_SECTION_SNAPSHOT = 'beekiri:section-snapshot';
/** Beekiri's new version of the element, for the editor to apply. */
export const BEEKIRI_SECTION_UPDATE = 'beekiri:section-update';

export type BeekiriSectionTarget = { pageId: string; nodeId: string; label: string };

export type BeekiriSectionScope = BeekiriSectionTarget & {
  pageTitle: string;
  viewport: string;
  tree: { rootId: string; nodes: Record<string, unknown> };
};

/** The editor fills `scope` while handling the event (it runs synchronously). */
export type BeekiriSectionSnapshotDetail = { pageId: string; nodeId: string; scope?: BeekiriSectionScope };

export type BeekiriSectionUpdateDetail = { pageId: string; nodeId: string; tree: { rootId: string; nodes: Record<string, unknown> } };

export function askBeekiriAboutSection(target: BeekiriSectionTarget) {
  window.dispatchEvent(new CustomEvent<BeekiriSectionTarget>(BEEKIRI_ASK_SECTION, { detail: target }));
}

/** Null when the editor is gone or the element no longer exists. */
export function snapshotBeekiriSection(target: BeekiriSectionTarget): BeekiriSectionScope | null {
  const detail: BeekiriSectionSnapshotDetail = { pageId: target.pageId, nodeId: target.nodeId };
  window.dispatchEvent(new CustomEvent<BeekiriSectionSnapshotDetail>(BEEKIRI_SECTION_SNAPSHOT, { detail }));
  return detail.scope ?? null;
}

export function applyBeekiriSection(detail: BeekiriSectionUpdateDetail) {
  window.dispatchEvent(new CustomEvent<BeekiriSectionUpdateDetail>(BEEKIRI_SECTION_UPDATE, { detail }));
}

/** Beekiri asks the open editor for a picture of the element (it answers at /api/connector/agent/preview). */
export const BEEKIRI_SECTION_PREVIEW = 'beekiri:section-preview';
export type BeekiriSectionPreviewDetail = { id: string; pageId: string; nodeId: string };

/** Open the Beekiri chat (e.g. from the Usage pill in the toolbar). */
export const BEEKIRI_OPEN_CHAT = 'beekiri:open-chat';

export function openBeekiriChat() {
  window.dispatchEvent(new Event(BEEKIRI_OPEN_CHAT));
}

/** What Beekiri is doing right now, for the editor's presence avatar and canvas highlight. */
export const BEEKIRI_AGENT_ACTIVITY = 'beekiri:agent-activity';
export type BeekiriAgentActivity = {
  running: boolean;
  /** Section mode: the page and element Beekiri is working on. */
  pageId?: string;
  nodeId?: string;
  label?: string;
  /** The current step ("Updating the section"). */
  step?: string;
};

export function notifyBeekiriActivity(detail: BeekiriAgentActivity) {
  window.dispatchEvent(new CustomEvent<BeekiriAgentActivity>(BEEKIRI_AGENT_ACTIVITY, { detail }));
}

/** The editor's selection changed: an open Beekiri chat follows it (nodeId null = whole page). */
export const BEEKIRI_FOLLOW_SELECTION = 'beekiri:follow-selection';
export type BeekiriFollowSelection = { pageId: string; nodeId: string | null; label: string };

export function followBeekiriSelection(detail: BeekiriFollowSelection) {
  window.dispatchEvent(new CustomEvent<BeekiriFollowSelection>(BEEKIRI_FOLLOW_SELECTION, { detail }));
}

/** The Beekiri chat just opened: the editor reports its current selection again. */
export const BEEKIRI_CHAT_OPENED = 'beekiri:chat-opened';
