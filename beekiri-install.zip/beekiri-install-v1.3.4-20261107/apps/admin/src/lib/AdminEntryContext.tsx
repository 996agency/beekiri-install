import { createContext, useCallback, useContext, useMemo } from 'react';
import {
  DEFAULT_ADMIN_BASE_PATH,
  DEFAULT_ADMIN_LOGIN_SLUG,
  adminHref,
  adminLoginPath,
  normalizeAdminBasePath,
} from './admin-login';

export type AdminEntry = {
  /** Admin SPA mount, e.g. `/admin` or `/my-hive`. */
  basePath: string;
  /** Login slug under the base, e.g. `login`. */
  slug: string;
  /** Full sign-in path, e.g. `/admin/login` or `/my-hive/login`. */
  path: string;
};

const DEFAULT: AdminEntry = {
  basePath: DEFAULT_ADMIN_BASE_PATH,
  slug: DEFAULT_ADMIN_LOGIN_SLUG,
  path: adminLoginPath(DEFAULT_ADMIN_LOGIN_SLUG, DEFAULT_ADMIN_BASE_PATH),
};

const AdminEntryContext = createContext<AdminEntry>(DEFAULT);

export function AdminEntryProvider({
  value,
  children,
}: {
  value: AdminEntry;
  children: React.ReactNode;
}) {
  return <AdminEntryContext.Provider value={value}>{children}</AdminEntryContext.Provider>;
}

export function useAdminEntry() {
  return useContext(AdminEntryContext);
}

/** Build a path under the current admin base (`href('pages')` → `/admin/pages`). */
export function useAdminHref() {
  const { basePath } = useAdminEntry();
  return useCallback((subPath = '') => adminHref(basePath, subPath), [basePath]);
}

export function useAdminBasePath() {
  const { basePath } = useAdminEntry();
  return useMemo(() => normalizeAdminBasePath(basePath), [basePath]);
}
