/** Mirrors API — admin mount + sign-in path helpers. */

export const DEFAULT_ADMIN_BASE_PATH = '/admin';
export const DEFAULT_ADMIN_LOGIN_SLUG = 'login';

export function normalizeAdminBasePath(raw?: string | null): string {
  let s = String(raw ?? '')
    .trim()
    .toLowerCase()
    .replace(/\\/g, '/')
    .replace(/\/+/g, '/');
  if (!s.startsWith('/')) s = `/${s}`;
  s = s.replace(/\/+$/, '') || DEFAULT_ADMIN_BASE_PATH;
  if (!/^\/[a-z0-9._-]+(\/[a-z0-9._-]+)*$/.test(s)) return DEFAULT_ADMIN_BASE_PATH;
  if (s.length < 2 || s.length > 80) return DEFAULT_ADMIN_BASE_PATH;
  return s;
}

export function normalizeAdminLoginSlug(raw?: string | null): string {
  const s = String(raw ?? '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
  return s.length >= 3 ? s : DEFAULT_ADMIN_LOGIN_SLUG;
}

export function adminLoginPath(slug?: string | null, basePath?: string | null): string {
  const base = normalizeAdminBasePath(basePath ?? DEFAULT_ADMIN_BASE_PATH);
  return `${base}/${normalizeAdminLoginSlug(slug ?? DEFAULT_ADMIN_LOGIN_SLUG)}`;
}

/** Join admin base with a subpath (`pages`, `/settings`, `` → base). */
export function adminHref(basePath: string | null | undefined, subPath = ''): string {
  const base = normalizeAdminBasePath(basePath ?? DEFAULT_ADMIN_BASE_PATH);
  const sub = String(subPath ?? '')
    .trim()
    .replace(/^\/+/, '');
  return sub ? `${base}/${sub}` : base;
}
