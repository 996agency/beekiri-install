import { api } from '../api/client';
import { confirmDialog, confirmWithOption } from '../components/ConfirmDialog';

type Need = { slug: string; name: string; active: boolean };
type ThemeRow = { slug: string; name: string; active: boolean; needs?: Need[] };
type ContentStatus = {
  hasContent: boolean;
  installed: boolean;
  pages: { title: string }[];
  products?: { title: string }[];
  forms?: { title: string }[];
  posts?: { title: string }[];
};

export type ThemeActivationChoice = {
  importContent: boolean;
  /** Turn on the extensions the theme is built on (e.g. Shopping). */
  enableRequired: boolean;
  /** Extensions only the previous theme needed, to switch off (data is kept). */
  disableUnused: string[];
};

function list(items: string[]): string {
  return items.length < 2 ? (items[0] ?? '') : `${items.slice(0, -1).join(', ')} and ${items[items.length - 1]}`;
}

/**
 * Before a theme is activated. One dialog covers everything a client needs to decide:
 * - a theme built on an extension (a shop theme and Shopping) turns that extension on;
 * - leaving such a theme offers to switch the extension off again (products and orders stay);
 * - the theme's demo content (pages, shop products, menu) can be imported or left out.
 * People who may not manage extensions are told to ask an administrator instead. Null = cancelled.
 */
export async function askThemeActivation(
  slug: string,
  name: string,
  opts: { openExtensions: () => void; canManageExtensions: boolean },
): Promise<ThemeActivationChoice | null> {
  const themes = (await api<{ themes: ThemeRow[] }>('/api/themes').catch(() => ({ themes: [] as ThemeRow[] }))).themes;
  const target = themes.find((t) => t.slug === slug);
  const current = themes.find((t) => t.active);
  const missing = (target?.needs ?? []).filter((n) => !n.active);
  const targetNeeds = new Set((target?.needs ?? []).map((n) => n.slug));
  const unused = (current?.needs ?? []).filter((n) => n.active && !targetNeeds.has(n.slug));

  if (missing.length && !opts.canManageExtensions) {
    const names = list(missing.map((n) => n.name));
    const open = await confirmDialog({
      title: `${name} needs ${names}`,
      message: `This theme is built on the ${names} extension${missing.length > 1 ? 's' : ''} from Beekiri. Ask an administrator to turn ${missing.length > 1 ? 'them' : 'it'} on in Extensions, then activate ${name} again.`,
      confirmLabel: 'Open Extensions',
      cancelLabel: 'Not now',
    });
    if (open) opts.openExtensions();
    return null;
  }

  const status = await api<ContentStatus>(`/api/themes/${encodeURIComponent(slug)}/content`).catch(() => null);
  const offerImport = Boolean(status?.hasContent && !status.installed);
  const parts: string[] = [];
  if (status?.pages.length) parts.push(`${status.pages.length} page${status.pages.length === 1 ? '' : 's'} (${list(status.pages.map((p) => p.title))})`);
  if (status?.products?.length) parts.push(`${status.products.length} shop product${status.products.length === 1 ? '' : 's'}`);
  if (status?.posts?.length) parts.push(`${status.posts.length} journal ${status.posts.length === 1 ? 'story' : 'stories'}`);
  if (status?.forms?.length) parts.push(`a ${status.forms.map((f) => f.title.toLowerCase()).join(' and ')} form (turns on Bee Forms)`);
  parts.push('the menu, header and footer');

  const needsLine = missing.length
    ? `\n\n${name} is built on the ${list(missing.map((n) => n.name))} extension from Beekiri — it is switched on for you.`
    : '';
  const answer = await confirmWithOption({
    title: `Activate “${name}”?`,
    message: `Your site switches to this theme together with its own pages, menu, header and footer. The pages you have now are kept and come back when you switch back.${needsLine}`,
    confirmLabel: missing.length ? `Turn on ${list(missing.map((n) => n.name))} & activate` : 'Activate',
    options: [
      ...(offerImport
        ? [
            {
              key: 'import',
              label: 'Import the demo content',
              hint: `Adds ${list(parts)}, with photos. Everything stays editable in the page editor and the shop.`,
              checked: true,
            },
          ]
        : []),
      ...(unused.length && opts.canManageExtensions
        ? [
            {
              key: 'disable',
              label: `Switch off ${list(unused.map((n) => n.name))}`,
              hint: `${name} doesn’t use ${unused.length > 1 ? 'them' : 'it'}. Your products, orders and settings are kept — turn ${unused.length > 1 ? 'them' : 'it'} back on any time in Extensions.`,
              checked: true,
            },
          ]
        : []),
    ],
  });
  if (!answer.ok) return null;
  return {
    importContent: offerImport && Boolean(answer.values.import),
    enableRequired: missing.length > 0,
    disableUnused: answer.values.disable ? unused.map((n) => n.slug) : [],
  };
}

type ActivationResult = { pagesAdded?: number; productsAdded?: number; extensionsEnabled?: string[]; extensionsDisabled?: string[] };

/** The notice after activating, from what the API did. */
export function activatedMessage(name: string, data: ActivationResult): string {
  const products = data.productsAdded ? ` and ${data.productsAdded} shop products` : '';
  const base = data.pagesAdded
    ? `Your site now shows ${name} with its ${data.pagesAdded} ready-made pages${products}, menu, header and footer.`
    : `Your site now shows ${name} with its own pages, menu, header and footer.`;
  const on = data.extensionsEnabled?.length ? ` ${list(data.extensionsEnabled)} is on.` : '';
  const off = data.extensionsDisabled?.length ? ` ${list(data.extensionsDisabled)} is switched off (its data is kept).` : '';
  return base + on + off;
}
