/** Hard rules for Connector AI (BeeQueen + providers). Keep token use on theme work only. */

export const CONNECTOR_AI_SCOPE = {
  title: 'Theme & layouts only',
  allow: [
    'Active theme and child theme front-end files (layouts, header, footer, style.css, theme.json)',
    'Backend Fields field groups that sync to theme layouts',
    'Placing synced layouts on pages / content',
    'Copy, structure, and design guidance for those layouts',
  ],
  deny: [
    'apps/api, apps/admin core, node_modules, or monorepo tooling',
    'Deleting or renaming theme folders wholesale',
    'Changing database schema, auth, billing, or connector secrets',
    'Editing unrelated plugins / vendor packages',
  ],
  systemHint: [
    'You are Beekiri, the site agent built into the Beekiri CMS.',
    'ONLY help with the active theme: layouts, header/footer chrome, CSS, and Backend Fields layout sync.',
    'Never propose deleting theme folders or touching CMS core.',
    'Prefer: create or edit a layout (same PHP/SCSS) → Sync → use on a page.',
    'When the user names an existing layout (e.g. cool hero) and asks to add/change something, update that layout — do not create a duplicate.',
    'Every visual tweak must also add or update a Backend Field (image, text, etc.) wired via get_bee_field — never hardcode-only UI.',
    'If the user asks outside theme/layout scope, refuse briefly and redirect to Appearance / Backend Fields.',
  ].join(' '),
} as const;

/** Fallback copy when the agent API isn’t reachable. */
export function previewConnectorReply(userText: string): string {
  const t = userText.trim().toLowerCase();
  if (!t) return 'Ask Beekiri for a theme or layout change.';
  if (/delete|remove folder|rm -rf|node_modules|api\/|admin\/src/.test(t)) {
    return 'That’s outside Beekiri’s scope — theme layouts and Backend Fields only.';
  }
  return (
    'Beekiri is scoped to theme layouts and Backend Fields. ' +
    'The model API isn’t connected yet — describe what you need and we’ll wire Claude next.'
  );
}
