<?php
/**
 * Order progress timeline. Expects $tracking ({steps[], headline, percent, stopped, fulfillment})
 * and optional $compact (true in order lists: progress bar + headline only).
 */
$tracking = $tracking ?? null;
$compact = !empty($compact);
if (!is_array($tracking) || empty($tracking['steps'])) return;
$stopped = $tracking['stopped'] ?? null;
$f = $tracking['fulfillment'] ?? [];
$fmtDate = function ($iso) {
  if (!$iso) return '';
  $t = strtotime((string) $iso);
  return $t ? date('j M, H:i', $t) : '';
};
?>
<?php if ($compact) : ?>
  <div class="bk-track bk-track--compact<?php echo $stopped ? ' is-stopped is-' . esc_attr($stopped['tone']) : ''; ?>">
    <div class="bk-track__bar" aria-hidden="true"><span style="width: <?php echo (int) ($tracking['percent'] ?? 0); ?>%"></span></div>
    <span class="bk-track__headline"><?php echo esc_html(bee_shop_t($tracking['headline'] ?? '')); ?></span>
  </div>
<?php else : ?>
  <section class="bk-track<?php echo $stopped ? ' is-stopped is-' . esc_attr($stopped['tone']) : ''; ?>" aria-label="<?php echo esc_attr(bee_shop_t('Order progress')); ?>">
    <header class="bk-track__head">
      <h2 class="bk-track__title"><?php echo esc_html(bee_shop_t($tracking['headline'] ?? '')); ?></h2>
      <?php if (!$stopped && !empty($f['trackingUrl'])) : ?>
        <a class="bk-btn bk-btn--primary bk-btn--sm" href="<?php echo esc_url($f['trackingUrl']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html(bee_shop_t('Track parcel')); ?></a>
      <?php endif; ?>
    </header>
    <?php if ($stopped) : ?>
      <p class="bk-track__stopped"><?php echo esc_html(sprintf(bee_shop_t('This order was %s.'), strtolower(bee_shop_t($stopped['label'])))); ?></p>
    <?php else : ?>
      <ol class="bk-track__steps" style="--bk-track-p: <?php echo number_format(((int) ($tracking['percent'] ?? 0)) / 100, 3, '.', ''); ?>">
        <?php foreach ($tracking['steps'] as $step) : ?>
          <li class="bk-track__step is-<?php echo esc_attr($step['state']); ?>"<?php echo $step['state'] === 'current' ? ' aria-current="step"' : ''; ?>>
            <span class="bk-track__dot" aria-hidden="true"><?php echo $step['state'] === 'done' ? bee_shop_icon('check') : ''; ?></span>
            <span class="bk-track__label"><?php echo esc_html(bee_shop_t($step['label'])); ?></span>
            <?php if (!empty($step['at'])) : ?><span class="bk-track__at"><?php echo esc_html($fmtDate($step['at'])); ?></span><?php endif; ?>
            <?php if (!empty($step['detail'])) : ?><span class="bk-track__detail"><?php echo esc_html(bee_shop_t($step['detail'])); ?></span><?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ol>
      <?php if (!empty($f['carrier']) || !empty($f['trackingNumber'])) : ?>
        <dl class="bk-track__parcel">
          <?php if (!empty($f['carrier'])) : ?><div><dt><?php echo esc_html(bee_shop_t('Carrier')); ?></dt><dd><?php echo esc_html($f['carrier']); ?></dd></div><?php endif; ?>
          <?php if (!empty($f['trackingNumber'])) : ?><div><dt><?php echo esc_html(bee_shop_t('Tracking number')); ?></dt><dd><code><?php echo esc_html($f['trackingNumber']); ?></code></dd></div><?php endif; ?>
        </dl>
      <?php endif; ?>
    <?php endif; ?>
  </section>
<?php endif; ?>
