<?php
/** Page links. Expects $pagination ({page, pages, prev_url, next_url, links[]}). */
$pagination = $pagination ?? [];
if (($pagination['pages'] ?? 1) <= 1) return;
$page = (int) ($pagination['page'] ?? 1);
$pages = (int) ($pagination['pages'] ?? 1);
?>
<nav class="bk-shop-pagination" aria-label="<?php echo esc_attr(bee_shop_t('Pagination')); ?>">
  <?php if (!empty($pagination['prev_url'])) : ?>
    <a class="bk-shop-pagination__arrow" href="<?php echo esc_url($pagination['prev_url']); ?>" rel="prev" aria-label="<?php echo esc_attr(bee_shop_t('Previous page')); ?>">‹</a>
  <?php endif; ?>
  <ul>
    <?php foreach ($pagination['links'] ?? [] as $link) :
      $n = (int) ($link['page'] ?? 0);
      // Keep the list short: first, last, and a window around the current page.
      if ($pages > 7 && $n !== 1 && $n !== $pages && abs($n - $page) > 2) {
        if (abs($n - $page) === 3) echo '<li class="bk-shop-pagination__gap" aria-hidden="true">…</li>';
        continue;
      }
    ?>
      <li>
        <?php if (!empty($link['current'])) : ?>
          <span aria-current="page"><?php echo $n; ?></span>
        <?php else : ?>
          <a href="<?php echo esc_url($link['url'] ?? '#'); ?>"><?php echo $n; ?></a>
        <?php endif; ?>
      </li>
    <?php endforeach; ?>
  </ul>
  <?php if (!empty($pagination['next_url'])) : ?>
    <a class="bk-shop-pagination__arrow" href="<?php echo esc_url($pagination['next_url']); ?>" rel="next" aria-label="<?php echo esc_attr(bee_shop_t('Next page')); ?>">›</a>
  <?php endif; ?>
</nav>
