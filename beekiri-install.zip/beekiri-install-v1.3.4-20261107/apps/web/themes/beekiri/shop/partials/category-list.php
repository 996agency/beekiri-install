<?php
/** Nested category links for the shop sidebar. Expects $categories (flat rows with parentId) and $current (slug or ''). */
$categories = $categories ?? [];
$current = $current ?? '';
if (!$categories) return;
$byParent = [];
foreach ($categories as $c) {
  $byParent[$c['parentId'] ?? ''][] = $c;
}
$renderList = function ($parentId, $depth) use (&$renderList, $byParent, $current) {
  if (empty($byParent[$parentId])) return;
  echo '<ul class="bk-shop-cats' . ($depth ? ' is-sub' : '') . '">';
  foreach ($byParent[$parentId] as $c) {
    if (($c['count'] ?? 0) === 0 && empty($byParent[$c['id']])) continue;
    $active = $c['slug'] === $current ? ' is-active' : '';
    echo '<li class="bk-shop-cats__item' . $active . '"><a href="' . esc_url($c['path']) . '"' . ($active ? ' aria-current="page"' : '') . '>'
      . esc_html($c['name']) . '<span class="bk-shop-cats__count">' . (int) ($c['count'] ?? 0) . '</span></a>';
    if ($depth < 3) $renderList($c['id'], $depth + 1);
    echo '</li>';
  }
  echo '</ul>';
};
$renderList('', 0);
