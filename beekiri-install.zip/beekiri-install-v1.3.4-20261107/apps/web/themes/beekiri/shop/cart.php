<?php
/**
 * Cart page. Data: cart {items[], itemCount, formatted{…}, coupon, couponError, messages[],
 * needsShipping, estimate {country, state, postcode, options[{id,title,cost,formatted,selected}]}},
 * shop.options {showCoupon, showContinueShopping}, countries[].
 * The inner <div data-cart-region> is swapped by script.js after each change.
 */
$shop = get_bee_field('shop') ?: [];
$cart = get_bee_field('cart') ?: [];
$countries = get_bee_field('countries') ?: [];
$items = $cart['items'] ?? [];
$fmt = $cart['formatted'] ?? [];
$opts = $shop['options'] ?? [];
$showCoupon = !isset($opts['showCoupon']) || $opts['showCoupon'];
$showContinue = !isset($opts['showContinueShopping']) || $opts['showContinueShopping'];
$estimate = $cart['estimate'] ?? [];
$shipOptions = $estimate['options'] ?? [];
$countryName = '';
foreach ($countries as $c) if (($c['code'] ?? '') === ($estimate['country'] ?? '')) $countryName = $c['name'];
?>
<section class="bk-shop bk-shop--cart" data-shop-view="cart">
  <div class="bk-shop__wrap">
    <header class="bk-cart-head">
      <?php echo bee_shop_breadcrumbs([['label' => $shop['title'] ?? 'Shop', 'url' => $shop['path'] ?? '/shop'], ['label' => bee_shop_t('Shopping cart'), 'url' => $shop['cart_path'] ?? '/cart']]); ?>
      <h1 class="bk-cart-head__title"><?php echo esc_html(bee_shop_t('Shopping cart')); ?></h1>
    </header>

    <div data-cart-region>
      <?php foreach ($cart['messages'] ?? [] as $msg) : ?>
        <p class="bk-shop-notice is-info" role="status"><?php echo esc_html($msg); ?></p>
      <?php endforeach; ?>

      <?php if (!$items) : ?>
        <div class="bk-cart-empty">
          <span class="bk-cart-empty__icon" aria-hidden="true"><?php echo bee_shop_icon('cart'); ?></span>
          <h2><?php echo esc_html(bee_shop_t('Your cart is empty')); ?></h2>
          <p><?php echo esc_html(bee_shop_t('Looks like you have not added anything yet.')); ?></p>
          <a class="bk-btn bk-btn--primary bk-btn--lg" href="<?php echo esc_url($shop['path'] ?? '/shop'); ?>"><?php echo esc_html(bee_shop_t('Go shopping')); ?></a>
        </div>
      <?php else : ?>
        <div class="bk-cart2">
          <div class="bk-cart2__items">
            <div class="bk-cart2__panel">
            <table class="bk-cart2__table">
              <thead>
                <tr>
                  <th scope="col"><?php echo esc_html(bee_shop_t('Product')); ?></th>
                  <th scope="col"><?php echo esc_html(bee_shop_t('Price')); ?></th>
                  <th scope="col"><?php echo esc_html(bee_shop_t('Quantity')); ?></th>
                  <th scope="col"><?php echo esc_html(bee_shop_t('Total')); ?></th>
                  <th scope="col"><span class="bk-visually-hidden"><?php echo esc_html(bee_shop_t('Remove')); ?></span></th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($items as $item) : $f = $item['formatted'] ?? []; ?>
                  <tr class="bk-cart2__row" data-cart-key="<?php echo esc_attr($item['key']); ?>">
                    <td class="bk-cart2__product">
                      <a class="bk-cart2__thumb" href="<?php echo esc_url($item['path']); ?>"><?php echo bee_shop_img(['url' => $item['imageUrl'] ?? '', 'alt' => $item['name']], 'bk-cart2__img'); ?></a>
                      <div class="bk-cart2__info">
                        <a class="bk-cart2__name" href="<?php echo esc_url($item['path']); ?>"><?php echo esc_html($item['name']); ?></a>
                        <?php if (!empty($item['attributes'])) : ?><span class="bk-cart2__attrs"><?php echo esc_html(bee_shop_attrs_text($item['attributes'])); ?></span><?php endif; ?>
                        <?php if (!empty($shop['show_sku']) && !empty($item['sku'])) : ?><span class="bk-cart2__sku"><?php echo esc_html(bee_shop_t('SKU')); ?> <?php echo esc_html($item['sku']); ?></span><?php endif; ?>
                      </div>
                    </td>
                    <td class="bk-cart2__price" data-label="<?php echo esc_attr(bee_shop_t('Price')); ?>">
                      <?php if (!empty($item['onSale'])) : ?><del><?php echo esc_html($f['regularPrice'] ?? ''); ?></del><?php endif; ?>
                      <span><?php echo esc_html($f['unitPrice'] ?? ''); ?></span>
                    </td>
                    <td class="bk-cart2__qty" data-label="<?php echo esc_attr(bee_shop_t('Quantity')); ?>">
                      <div class="bk-qty" data-qty>
                        <button type="button" class="bk-qty__btn" data-qty-dec aria-label="<?php echo esc_attr(bee_shop_t('Decrease quantity')); ?>">−</button>
                        <input type="number" value="<?php echo (int) $item['qty']; ?>" min="1" <?php echo isset($item['maxQty']) && $item['maxQty'] !== null ? 'max="' . (int) $item['maxQty'] . '"' : ''; ?> inputmode="numeric" data-cart-qty="<?php echo esc_attr($item['key']); ?>" data-cart-qty-initial="<?php echo (int) $item['qty']; ?>" aria-label="<?php echo esc_attr(bee_shop_t('Quantity')); ?>">
                        <button type="button" class="bk-qty__btn" data-qty-inc aria-label="<?php echo esc_attr(bee_shop_t('Increase quantity')); ?>">+</button>
                      </div>
                    </td>
                    <td class="bk-cart2__total" data-label="<?php echo esc_attr(bee_shop_t('Total')); ?>"><?php echo esc_html($f['subtotal'] ?? ''); ?></td>
                    <td class="bk-cart2__remove">
                      <button type="button" class="bk-cart2__x" data-cart-remove="<?php echo esc_attr($item['key']); ?>" aria-label="<?php echo esc_attr(sprintf(bee_shop_t('Remove %s'), $item['name'])); ?>">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>
                      </button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>

            <div class="bk-cart2__actions">
              <?php if ($showCoupon || !empty($cart['coupon'])) : ?>
                <form class="bk-cart2__coupon" data-coupon-form>
                  <?php if (!empty($cart['coupon'])) : ?>
                    <p class="bk-coupon__applied"><?php echo bee_shop_icon('check'); ?> <?php echo esc_html(sprintf(bee_shop_t('Coupon %s applied'), $cart['coupon']['code'])); ?> <button type="button" class="bk-link-btn" data-coupon-remove><?php echo esc_html(bee_shop_t('Remove')); ?></button></p>
                  <?php else : ?>
                    <label class="bk-visually-hidden" for="bk-coupon-code"><?php echo esc_html(bee_shop_t('Coupon code')); ?></label>
                    <input id="bk-coupon-code" type="text" name="code" placeholder="<?php echo esc_attr(bee_shop_t('Coupon code')); ?>" autocomplete="off">
                    <button type="submit" class="bk-cart2__coupon-go"><?php echo esc_html(bee_shop_t('Apply')); ?></button>
                  <?php endif; ?>
                  <p class="bk-coupon__msg" data-coupon-message role="alert"><?php echo esc_html($cart['couponError'] ?? ''); ?></p>
                </form>
              <?php endif; ?>
              <button type="button" class="bk-btn bk-btn--ghost bk-cart2__update" data-cart-update disabled>
                <?php echo esc_html(bee_shop_t('Update cart')); ?>
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></svg>
              </button>
            </div>
            </div>
          </div>

          <aside class="bk-cart2__summary" aria-labelledby="bk-cart-totals-title">
            <div class="bk-cart2__card">
              <h2 id="bk-cart-totals-title" class="bk-cart2__card-title"><?php echo esc_html(bee_shop_t('Order summary')); ?></h2>
              <table class="bk-cart2__totals">
                <tbody>
                  <tr class="is-subtotal"><th scope="row"><?php echo esc_html(bee_shop_t('Subtotal')); ?></th><td><?php echo esc_html($fmt['subtotal'] ?? ''); ?></td></tr>
                  <?php if (!empty($cart['coupon'])) : ?>
                    <tr class="is-discount"><th scope="row"><?php echo esc_html(bee_shop_t('Discount')); ?> <small>(<?php echo esc_html($cart['coupon']['code']); ?>)</small></th><td>−<?php echo esc_html($cart['coupon']['formatted'] ?? ''); ?></td></tr>
                  <?php endif; ?>
                  <?php if (!empty($cart['needsShipping'])) : ?>
                    <tr class="is-shipping-head"><th scope="row" colspan="2"><?php echo esc_html(bee_shop_t('Shipping')); ?></th></tr>
                    <tr class="is-shipping"><td colspan="2">
                      <?php if ($shipOptions) : ?>
                        <ul class="bk-cart2__ship" data-cart-ship-options>
                          <?php foreach ($shipOptions as $o) : ?>
                            <li><label class="bk-cart2__ship-opt">
                              <input type="radio" name="cart-shipping" value="<?php echo esc_attr($o['id']); ?>" <?php echo !empty($o['selected']) ? 'checked' : ''; ?> data-cart-ship>
                              <span class="bk-cart2__ship-title"><?php echo esc_html($o['title']); ?></span>
                              <span class="bk-cart2__ship-cost"><?php echo esc_html($o['cost'] === 0 ? bee_shop_t('Free') : $o['formatted']); ?></span>
                            </label></li>
                          <?php endforeach; ?>
                        </ul>
                      <?php else : ?>
                        <p class="bk-cart2__ship-none"><?php echo esc_html(($estimate['country'] ?? '') ? bee_shop_t('No shipping options for this address.') : bee_shop_t('Choose your country to see shipping options.')); ?></p>
                      <?php endif; ?>
                      <details class="bk-cart2__estimate"<?php echo empty($estimate['country']) ? ' open' : ''; ?>>
                        <summary>
                          <?php if ($countryName) : ?><?php echo esc_html(sprintf(bee_shop_t('Estimate for %s'), $countryName)); ?> · <?php endif; ?>
                          <span><?php echo esc_html(bee_shop_t('Change address')); ?></span>
                        </summary>
                        <form class="bk-cart2__estimate-form" data-cart-estimate>
                          <label class="bk-visually-hidden" for="bk-est-country"><?php echo esc_html(bee_shop_t('Country / Region')); ?></label>
                          <select id="bk-est-country" name="country" required>
                            <option value=""><?php echo esc_html(bee_shop_t('Select a country')); ?></option>
                            <?php foreach ($countries as $c) : ?><option value="<?php echo esc_attr($c['code']); ?>"<?php echo ($estimate['country'] ?? '') === $c['code'] ? ' selected' : ''; ?>><?php echo esc_html($c['name']); ?></option><?php endforeach; ?>
                          </select>
                          <div class="bk-cart2__estimate-row">
                            <input name="state" placeholder="<?php echo esc_attr(bee_shop_t('State / County')); ?>" value="<?php echo esc_attr($estimate['state'] ?? ''); ?>">
                            <input name="postcode" placeholder="<?php echo esc_attr(bee_shop_t('Postcode')); ?>" value="<?php echo esc_attr($estimate['postcode'] ?? ''); ?>">
                          </div>
                          <button type="submit" class="bk-btn bk-btn--ghost bk-btn--sm"><?php echo esc_html(bee_shop_t('Update')); ?></button>
                        </form>
                      </details>
                    </td></tr>
                  <?php endif; ?>
                  <?php if (!empty($cart['taxTotal']) && !empty($cart['pricesIncludeTax'])) : ?>
                    <tr class="is-muted"><th scope="row"><?php echo esc_html(bee_shop_t('Includes tax')); ?></th><td><?php echo esc_html($fmt['taxTotal'] ?? ''); ?></td></tr>
                  <?php elseif (!empty($cart['taxTotal'])) : ?>
                    <tr><th scope="row"><?php echo esc_html(bee_shop_t('Tax')); ?></th><td><?php echo esc_html($fmt['taxTotal'] ?? ''); ?></td></tr>
                  <?php endif; ?>
                  <tr class="is-total"><th scope="row"><?php echo esc_html(bee_shop_t('Total')); ?></th><td><?php echo esc_html($fmt['total'] ?? ''); ?></td></tr>
                </tbody>
              </table>
              <a class="bk-btn bk-btn--lg bk-btn--block bk-cart2__checkout" href="<?php echo esc_url($shop['checkout_path'] ?? '/checkout'); ?>" data-bk-reload>
                <?php echo bee_shop_icon('lock'); ?> <?php echo esc_html(bee_shop_t('Proceed to checkout')); ?>
              </a>
              <p class="bk-cart2__secure"><?php echo esc_html(bee_shop_t('Secure, encrypted checkout. Your payment details are never stored on this site.')); ?></p>
            </div>
            <?php if ($showContinue) : ?>
              <a class="bk-cart2__continue" href="<?php echo esc_url($shop['path'] ?? '/shop'); ?>">← <?php echo esc_html(bee_shop_t('Continue shopping')); ?></a>
            <?php endif; ?>
          </aside>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>
