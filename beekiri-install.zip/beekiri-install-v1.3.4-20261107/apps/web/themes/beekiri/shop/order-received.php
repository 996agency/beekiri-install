<?php
/**
 * Thank-you / order view. Data: order {numberLabel, status, statusLabel, paymentStatus,
 * paymentMethodTitle, paymentInstructions, bankAccounts[], items[], totals{…}, billingLines[],
 * shippingLines[], shippingMethodTitle, email, placedAt, thankYouMessage}, confirm_token, session_id.
 */
$shop = get_bee_field('shop') ?: [];
$order = get_bee_field('order') ?: [];
$confirmToken = (string) (get_bee_field('confirm_token') ?: '');
$sessionId = (string) (get_bee_field('session_id') ?: '');
$t = $order['totals'] ?? [];
$paid = ($order['paymentStatus'] ?? '') === 'paid';
$failed = in_array($order['status'] ?? '', ['cancelled', 'failed'], true);
$date = !empty($order['placedAt']) ? date('j F Y', strtotime($order['placedAt'])) : '';
?>
<section class="bk-shop bk-shop--received" data-shop-view="order-received" <?php echo $confirmToken ? 'data-confirm-token="' . esc_attr($confirmToken) . '" data-confirm-session="' . esc_attr($sessionId) . '"' : ''; ?>>
  <div class="bk-shop__wrap bk-shop__wrap--narrow">
    <header class="bk-shop__head bk-received__head">
      <?php if ($failed) : ?>
        <h1 class="bk-shop__title"><?php echo esc_html(bee_shop_t('Order')); ?> <?php echo esc_html($order['numberLabel'] ?? ''); ?></h1>
        <p class="bk-shop-notice is-error"><?php echo esc_html(sprintf(bee_shop_t('This order is %s.'), strtolower($order['statusLabel'] ?? ''))); ?> <a href="<?php echo esc_url($shop['path'] ?? '/shop'); ?>"><?php echo esc_html(bee_shop_t('Return to shop')); ?></a></p>
      <?php elseif ($confirmToken) : ?>
        <span class="bk-received__icon is-pending" aria-hidden="true"></span>
        <h1 class="bk-shop__title" data-confirm-title><?php echo esc_html(bee_shop_t('Confirming your payment…')); ?></h1>
        <p class="bk-shop__lead" data-confirm-lead><?php echo esc_html(bee_shop_t('This only takes a moment. Please keep this page open.')); ?></p>
      <?php else : ?>
        <span class="bk-received__icon" aria-hidden="true"><?php echo bee_shop_icon('check'); ?></span>
        <h1 class="bk-shop__title"><?php echo esc_html(bee_shop_t('Thank you')); ?></h1>
        <p class="bk-shop__lead"><?php echo esc_html($order['thankYouMessage'] ?? bee_shop_t('Your order has been received.')); ?></p>
      <?php endif; ?>
    </header>

    <ul class="bk-received__facts">
      <li><span><?php echo esc_html(bee_shop_t('Order number')); ?></span><strong><?php echo esc_html($order['numberLabel'] ?? ''); ?></strong></li>
      <li><span><?php echo esc_html(bee_shop_t('Date')); ?></span><strong><?php echo esc_html($date); ?></strong></li>
      <li><span><?php echo esc_html(bee_shop_t('Email')); ?></span><strong><?php echo esc_html($order['email'] ?? ''); ?></strong></li>
      <li><span><?php echo esc_html(bee_shop_t('Total')); ?></span><strong><?php echo esc_html($t['total'] ?? ''); ?></strong></li>
      <li><span><?php echo esc_html(bee_shop_t('Payment method')); ?></span><strong><?php echo esc_html($order['paymentMethodTitle'] ?? ''); ?></strong></li>
      <li><span><?php echo esc_html(bee_shop_t('Status')); ?></span><strong data-order-status><?php echo esc_html($order['statusLabel'] ?? ''); ?></strong></li>
    </ul>

    <?php if (!$confirmToken) bee_shop_partial('tracking', ['tracking' => $order['tracking'] ?? null]); ?>

    <?php if (!$paid && !$failed && (!empty($order['paymentInstructions']) || !empty($order['bankAccounts']))) : ?>
      <section class="bk-received__pay" aria-labelledby="bk-pay-title">
        <h2 id="bk-pay-title"><?php echo esc_html(bee_shop_t('Payment instructions')); ?></h2>
        <?php if (!empty($order['paymentInstructions'])) : ?><p><?php echo nl2br(esc_html($order['paymentInstructions'])); ?></p><?php endif; ?>
        <?php foreach ($order['bankAccounts'] ?? [] as $acc) : ?>
          <dl class="bk-received__bank">
            <?php foreach (['accountName' => 'Account name', 'bankName' => 'Bank', 'accountNumber' => 'Account number', 'sortCode' => 'Sort code', 'iban' => 'IBAN', 'bic' => 'BIC / SWIFT'] as $k => $label) : if (empty($acc[$k])) continue; ?>
              <div><dt><?php echo esc_html(bee_shop_t($label)); ?></dt><dd><?php echo esc_html($acc[$k]); ?></dd></div>
            <?php endforeach; ?>
          </dl>
        <?php endforeach; ?>
      </section>
    <?php endif; ?>

    <section class="bk-received__details" aria-labelledby="bk-details-title">
      <h2 id="bk-details-title"><?php echo esc_html(bee_shop_t('Order details')); ?></h2>
      <table class="bk-review bk-review--received">
        <thead><tr><th scope="col"><?php echo esc_html(bee_shop_t('Product')); ?></th><th scope="col" class="is-right"><?php echo esc_html(bee_shop_t('Total')); ?></th></tr></thead>
        <tbody>
          <?php foreach ($order['items'] ?? [] as $item) : ?>
            <tr>
              <td class="bk-review__item">
                <?php echo bee_shop_img(['url' => $item['imageUrl'] ?? '', 'alt' => ''], 'bk-review__img'); ?>
                <div><strong><?php echo esc_html($item['name']); ?></strong> <span class="bk-review__qty">× <?php echo (int) $item['qty']; ?></span>
                  <?php if (!empty($item['attributes'])) : ?><small><?php echo esc_html(bee_shop_attrs_text($item['attributes'])); ?></small><?php endif; ?></div>
              </td>
              <td class="is-right"><?php echo esc_html($item['formatted']['total'] ?? ''); ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr><th scope="row"><?php echo esc_html(bee_shop_t('Subtotal')); ?></th><td class="is-right"><?php echo esc_html($t['subtotal'] ?? ''); ?></td></tr>
          <?php if (!empty($t['discountTotal'])) : ?><tr><th scope="row"><?php echo esc_html(bee_shop_t('Discount')); ?><?php echo !empty($order['couponCode']) ? ' (' . esc_html($order['couponCode']) . ')' : ''; ?></th><td class="is-right"><?php echo esc_html($t['discountTotal']); ?></td></tr><?php endif; ?>
          <?php if (!empty($t['shippingTotal'])) : ?><tr><th scope="row"><?php echo esc_html(bee_shop_t('Shipping')); ?><?php echo !empty($order['shippingMethodTitle']) ? ' (' . esc_html($order['shippingMethodTitle']) . ')' : ''; ?></th><td class="is-right"><?php echo esc_html($t['shippingTotal']); ?></td></tr><?php endif; ?>
          <?php if (!empty($t['taxTotal'])) : ?><tr><th scope="row"><?php echo esc_html(!empty($t['taxIncluded']) ? bee_shop_t('Includes tax') : bee_shop_t('Tax')); ?></th><td class="is-right"><?php echo esc_html($t['taxTotal']); ?></td></tr><?php endif; ?>
          <tr class="is-total"><th scope="row"><?php echo esc_html(bee_shop_t('Total')); ?></th><td class="is-right"><?php echo esc_html($t['total'] ?? ''); ?></td></tr>
          <?php if (!empty($t['refundedTotal'])) : ?><tr><th scope="row"><?php echo esc_html(bee_shop_t('Refunded')); ?></th><td class="is-right">−<?php echo esc_html($t['refundedTotal']); ?></td></tr><?php endif; ?>
        </tfoot>
      </table>
      <?php if (!empty($order['customerNote'])) : ?><p class="bk-received__note"><strong><?php echo esc_html(bee_shop_t('Note')); ?>:</strong> <?php echo esc_html($order['customerNote']); ?></p><?php endif; ?>
      <?php foreach ($order['customFields'] ?? [] as $cf) : ?>
        <p class="bk-received__note"><strong><?php echo esc_html($cf['label']); ?>:</strong> <?php echo esc_html($cf['value']); ?></p>
      <?php endforeach; ?>
    </section>

    <div class="bk-received__addresses">
      <?php if (!empty($order['billingLines'])) : ?>
        <section><h2><?php echo esc_html(bee_shop_t('Billing address')); ?></h2><?php echo bee_shop_address_html($order['billingLines']); ?><?php if (!empty($order['phone'])) : ?><p><?php echo esc_html($order['phone']); ?></p><?php endif; ?></section>
      <?php endif; ?>
      <?php if (!empty($order['shippingLines'])) : ?>
        <section><h2><?php echo esc_html(bee_shop_t('Shipping address')); ?></h2><?php echo bee_shop_address_html($order['shippingLines']); ?></section>
      <?php endif; ?>
    </div>

    <p class="bk-received__back"><a class="bk-btn bk-btn--ghost" href="<?php echo esc_url($shop['path'] ?? '/shop'); ?>"><?php echo esc_html(bee_shop_t('Continue shopping')); ?></a></p>
  </div>
</section>
