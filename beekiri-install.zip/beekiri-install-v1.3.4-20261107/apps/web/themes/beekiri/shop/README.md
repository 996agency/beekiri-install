# Shop templates

Storefront pages of the **Shopping** extension. Beekiri renders them with PHP (the same
runner as layouts), fills them with data from `/api/shop`, and the website shows the
result inside the theme header and footer.

```
shop/
  _helpers.php          helpers loaded before every template (bee_shop_partial, bee_price_html, …)
  shop.php              /shop                     — product grid, categories, search, sorting
  category.php          /shop/category/{slug}     — includes shop.php by default
  product.php           /product/{slug}           — gallery, price, variations, add to cart, tabs, related
  cart.php              /cart                     — items, quantities, coupon, totals
  checkout.php          /checkout                 — addresses, shipping, payment, place order
  order-received.php    /checkout/order-received/{token} — thank-you page + payment instructions + tracking
  account.php           /account/…               — sign in / register / password help, dashboard, orders, addresses, details
  partials/             product-card, pagination, category-list, tracking (order progress timeline)
  styles.scss           → styles.css + styles.min.css (compiled by the server when it changes)
  script.js             add to cart, variations, cart editing, checkout, Stripe return
```

## Override a template

Copy any file to the same path in **Beekiri Child** (`../../beekiri-child/shop/`) and edit
the copy. Resolution is per file: a child `product.php` is used together with the parent's
`cart.php`, helpers and partials. Core updates never touch the child theme.

Keep these hooks when you change markup — `script.js` relies on them:

| Attribute | Where | Purpose |
|---|---|---|
| `data-shop-view="shop\|product\|cart\|checkout\|order-received"` | root element | tells the script which page it is on |
| `form[data-shop-add]` with `[name=productId]`, `[name=qty]`, `[data-variant-input]` | product card, product page | add to cart |
| `[data-variation-attr="Name"]`, `data-variants='[…]'` | product page | variation picking |
| `[data-cart-region]`, `[data-cart-qty]`, `[data-cart-remove]`, `[data-coupon-form]` | cart | cart editing (the region is re-rendered after each change) |
| `form[data-checkout-form]`, `[data-shipping-list]`, `[data-checkout-totals]`, `[data-place-order]` | checkout | shipping quotes and placing the order |
| `[data-confirm-token]` | order received | confirms a Stripe payment after the redirect |
| `[data-bk-cart-count]` | header | live cart count |
| `[data-bk-account-link]`, `[data-bk-account-name]` | header | account link + first name |
| `form[data-account-form="login\|register\|forgot\|reset\|details\|password\|addresses"]`, `[data-account-logout]`, `[data-account-resend]`, `[data-account-verify]` | account | My account forms |
| `[data-cart-update]`, `[data-cart-ship]`, `form[data-cart-estimate]` | cart | Update cart button, shipping estimate |

## Data

Every template reads its data with `get_bee_field('name')` (same API as layouts).

| Template | Fields |
|---|---|
| all | `site {title, tagline, url}`, `shop {title, description, path, cart_path, checkout_path, currency, show_sku, show_categories, prices_include_tax}` |
| shop / category | `products[]`, `categories[]`, `category` (or null), `query`, `sort`, `sorts[]`, `pagination {page, pages, total, prev_url, next_url, links[]}`, `base_path` |
| product | `product`, `related[]`, `breadcrumbs[]`, `variants_json` |
| cart | `cart` |
| checkout | `checkout {cart, shippingOptions[], shippingRequired, paymentMethods[], countries[], defaultCountry, fields, termsPage, privacyPage}`, `cancelled` |
| order-received | `order`, `confirm_token`, `session_id` |

A product looks like:

```json
{
  "id": "…", "slug": "hoodie", "path": "/product/hoodie", "title": "Hoodie",
  "shortDescription": "…", "description": "<p>…</p>",
  "image": { "url": "/uploads/…", "alt": "", "width": 1200, "height": 1200 }, "gallery": [],
  "type": "variable", "sku": "HD-1", "featured": false,
  "inStock": true, "stockStatus": "instock", "stockQty": null,
  "price": { "min": 2999, "max": 3499, "regular": null, "onSale": false,
             "formatted": "€29.99", "regularFormatted": "", "rangeFormatted": "€29.99 – €34.99" },
  "categories": [{ "id": "…", "name": "Clothing", "slug": "clothing", "path": "/shop/category/clothing" }],
  "attributes": [{ "name": "Size", "options": ["S", "M", "L"], "variation": true }],
  "variants": [{ "id": "…", "sku": "HD-1-S", "attributes": { "Size": "S" }, "price": { … }, "inStock": true, "stockQty": 4, "image": null }]
}
```

Prices are formatted by the server with the shop's currency settings; amounts (`min`,
`max`) are integers in the currency's minor unit (cents).

## Helpers (`_helpers.php`)

- `bee_shop_partial('product-card', ['product' => $p])` — include a partial (child first)
- `bee_price_html($price)` — `<span class="bk-price">` with sale/range handling
- `bee_stock_html($product)` — in stock / out of stock / backorder line
- `bee_shop_img($image, $class, $loading)` — `<img>` or a placeholder
- `bee_shop_breadcrumbs([...])`, `bee_shop_address_html($lines)`, `bee_shop_attrs_text($attrs)`, `bee_shop_icon('cart')`
- `bee_shop_t('Add to cart')` — translatable string (Settings → Translation)

Plus everything layouts have: `esc_html`, `esc_attr`, `esc_url`, `bee_esc_html`, `wpautop`, `sanitize_title`, …

## Styles and script

`styles.scss` is compiled on the server when it is newer than `styles.min.css`, and served
at `/api/shop/public/assets/styles.css`. `script.js` is served minified at
`/api/shop/public/assets/script.js`. Both are loaded on every page while Shopping is active,
so the header cart count and "add to cart" work from any page.

The script talks to `/api/shop/public/*` with `credentials: 'same-origin'` and the header
`X-Beekiri-Shop: 1` (required on every request that changes the cart or places an order).
