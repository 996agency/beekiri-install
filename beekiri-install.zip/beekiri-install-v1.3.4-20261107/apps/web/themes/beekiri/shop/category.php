<?php
/**
 * Category archive — same markup as the shop page. Copy shop.php here (or into
 * beekiri-child/shop/category.php) to give categories their own design.
 */
$dirs = $GLOBALS['__bk_fields']['__shop_dirs'] ?? [];
foreach ($dirs as $dir) {
  $file = rtrim((string) $dir, '/') . '/shop.php';
  if (is_file($file)) {
    include $file;
    return;
  }
}
