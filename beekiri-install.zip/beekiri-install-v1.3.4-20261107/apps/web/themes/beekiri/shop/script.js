/**
 * Beekiri Shopping — storefront behaviour (served at /api/shop/public/assets/script.js).
 *
 * Add to cart, variation picking, cart editing, coupons, shipping quotes, placing
 * orders and the Stripe return. Uses document-level delegation so it keeps working
 * after the site's soft navigation (`bk:navigate`). Talks to /api/shop/public/*.
 * Override by copying this file into beekiri-child/shop/script.js.
 */
(function () {
  if (window.__bkShop) return;
  window.__bkShop = true;

  var API = '/api/shop/public';
  var HEADERS = { 'Content-Type': 'application/json', 'X-Beekiri-Shop': '1', Accept: 'application/json' };

  function t(text) {
    var dict = window.__bkShopI18n || {};
    return dict[text] || text;
  }

  function request(method, path, body) {
    return fetch(API + path, {
      method: method,
      headers: HEADERS,
      credentials: 'same-origin',
      body: body === undefined ? undefined : JSON.stringify(body),
    }).then(function (res) {
      return res
        .json()
        .catch(function () {
          return {};
        })
        .then(function (data) {
          if (!res.ok) {
            var msg = data && (data.message || data.error);
            if (Array.isArray(msg)) msg = msg.join(' ');
            throw new Error(msg || t('Something went wrong. Please try again.'));
          }
          return data;
        });
    });
  }

  /* ── Cart count in the header ─────────────────────────────────────── */
  function setCount(n) {
    bagFetched = 0; // any cart change makes the cached bag stale
    document.querySelectorAll('[data-bk-cart-count]').forEach(function (el) {
      el.textContent = String(n);
      el.hidden = !(n > 0);
    });
  }
  function refreshCount() {
    request('GET', '/config')
      .then(function (cfg) {
        setCount(cfg.cartCount || 0);
      })
      .catch(function () {});
  }

  /* ── Toasts ───────────────────────────────────────────────────────── */
  var toastTimer = null;
  function toast(message, kind, action) {
    var el = document.querySelector('[data-bk-shop-toast]');
    if (!el) {
      el = document.createElement('div');
      el.className = 'bk-shop-toast';
      el.setAttribute('data-bk-shop-toast', '');
      el.setAttribute('role', 'status');
      el.setAttribute('aria-live', 'polite');
      document.body.appendChild(el);
    }
    el.className = 'bk-shop-toast is-' + (kind || 'info') + ' is-open';
    el.innerHTML = '';
    var text = document.createElement('span');
    text.textContent = message;
    el.appendChild(text);
    if (action) {
      var a = document.createElement('a');
      a.href = action.href;
      a.textContent = action.label;
      a.className = 'bk-shop-toast__link';
      el.appendChild(a);
    }
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      el.classList.remove('is-open');
    }, 4500);
  }

  function busy(el, on) {
    if (!el) return;
    el.classList.toggle('is-busy', !!on);
    el.querySelectorAll('button, input, select').forEach(function (c) {
      if (on) c.setAttribute('data-was-disabled', c.disabled ? '1' : '');
      c.disabled = on ? true : c.getAttribute('data-was-disabled') === '1';
    });
  }

  /* ── Quantity steppers ────────────────────────────────────────────── */
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-qty-inc],[data-qty-dec]');
    if (!btn) return;
    var wrap = btn.closest('[data-qty]');
    var input = wrap && wrap.querySelector('input[type="number"]');
    if (!input) return;
    var step = btn.hasAttribute('data-qty-inc') ? 1 : -1;
    var min = Number(input.min || 0);
    var max = input.max ? Number(input.max) : Infinity;
    var next = Math.min(max, Math.max(min, (Number(input.value) || 0) + step));
    if (next !== Number(input.value)) {
      input.value = String(next);
      input.dispatchEvent(new Event('change', { bubbles: true }));
    }
  });
  /* Typed quantities: whole numbers only, kept between min and max. */
  function clampQty(input) {
    var min = Number(input.min || 1);
    var max = input.max ? Number(input.max) : Infinity;
    var raw = String(input.value).trim();
    var n = raw !== '' && isFinite(Number(raw)) ? Math.floor(Number(raw)) : parseInt(raw.replace(/[^0-9]/g, ''), 10);
    var next = String(Math.min(max, Math.max(min, isNaN(n) ? min : n)));
    if (input.value !== next) input.value = next;
  }
  document.addEventListener('keydown', function (e) {
    if (!e.target.closest || !e.target.closest('[data-qty] input[type="number"]')) return;
    if (['-', '+', 'e', 'E', '.', ','].indexOf(e.key) !== -1) e.preventDefault();
  });
  document.addEventListener('input', function (e) {
    var input = e.target.closest && e.target.closest('[data-qty] input[type="number"]');
    // An empty box is allowed while typing; anything else must already be a valid number.
    if (input && input.value !== '' && !/^[0-9]+$/.test(input.value)) clampQty(input);
  });
  document.addEventListener(
    'change',
    function (e) {
      var input = e.target.closest && e.target.closest('[data-qty] input[type="number"]');
      if (input) clampQty(input);
    },
    true
  );
  document.addEventListener(
    'blur',
    function (e) {
      var input = e.target.closest && e.target.closest('[data-qty] input[type="number"]');
      if (input) clampQty(input);
    },
    true
  );

  /* ── Variations (product page) ────────────────────────────────────── */
  function matchVariant(form) {
    var variants = [];
    try {
      variants = JSON.parse(form.getAttribute('data-variants') || '[]');
    } catch (e) {
      variants = [];
    }
    var chosen = {};
    var complete = true;
    form.querySelectorAll('[data-variation-attr]').forEach(function (sel) {
      if (!sel.value) complete = false;
      chosen[sel.getAttribute('data-variation-attr')] = sel.value;
    });
    if (!complete) return { complete: false, variant: null };
    var found = variants.filter(function (v) {
      return Object.keys(chosen).every(function (k) {
        return !v.attributes[k] || v.attributes[k] === chosen[k];
      });
    })[0];
    return { complete: true, variant: found || null };
  }

  function applyVariant(form) {
    var hasAttrs = form.querySelector('[data-variation-attr]');
    if (!hasAttrs) return;
    var result = matchVariant(form);
    var input = form.querySelector('[data-variant-input]');
    var info = form.querySelector('[data-variation-info]');
    var priceEl = form.querySelector('[data-variation-price]');
    var stockEl = form.querySelector('[data-variation-stock]');
    var btn = form.querySelector('[data-add-button]');
    var reset = form.querySelector('[data-variation-reset]');
    var root = form.closest('[data-shop-view="product"]');
    var stage = root && root.querySelector('.bk-product__img');
    var anyChosen = Array.prototype.some.call(form.querySelectorAll('[data-variation-attr]'), function (s) {
      return s.value;
    });
    if (reset) reset.hidden = !anyChosen;
    if (!result.complete) {
      if (input) input.value = '';
      if (info) info.hidden = true;
      if (btn) {
        btn.disabled = true;
        btn.querySelector('span').textContent = t('Choose options');
      }
      return;
    }
    var v = result.variant;
    if (!v) {
      if (input) input.value = '';
      if (info) {
        info.hidden = false;
        if (priceEl) priceEl.textContent = '';
        if (stockEl) stockEl.textContent = t('This combination is not available.');
      }
      if (btn) {
        btn.disabled = true;
        btn.querySelector('span').textContent = t('Unavailable');
      }
      return;
    }
    if (input) input.value = v.id;
    if (info) {
      info.hidden = false;
      if (priceEl) {
        priceEl.innerHTML = '';
        if (v.price) {
          if (v.price.onSale && v.price.regularFormatted) {
            var del = document.createElement('del');
            del.textContent = v.price.regularFormatted;
            var ins = document.createElement('ins');
            ins.textContent = v.price.formatted;
            priceEl.appendChild(del);
            priceEl.appendChild(document.createTextNode(' '));
            priceEl.appendChild(ins);
          } else priceEl.textContent = v.price.formatted;
        }
      }
      if (stockEl) {
        stockEl.textContent = v.inStock
          ? v.stockQty !== null && v.stockQty !== undefined
            ? v.stockQty + ' ' + t('in stock')
            : t('In stock')
          : t('Out of stock');
        stockEl.className = v.inStock ? 'is-in' : 'is-out';
      }
    }
    var qty = form.querySelector('input[name="qty"]');
    if (qty && qty.type === 'number') qty.max = v.stockQty !== null && v.stockQty !== undefined ? String(v.stockQty) : '999';
    if (btn) {
      btn.disabled = !v.inStock || !v.price;
      btn.querySelector('span').textContent = v.inStock ? t('Add to cart') : t('Out of stock');
    }
    if (stage && v.image && v.image.url) {
      stage.src = v.image.url;
      stage.alt = v.image.alt || '';
      root.querySelectorAll('[data-gallery-thumb]').forEach(function (b) {
        b.classList.toggle('is-active', b.getAttribute('data-gallery-thumb') === v.image.url);
      });
    }
    var sku = root && root.querySelector('[data-product-sku]');
    if (sku && v.sku) sku.textContent = v.sku;
  }

  /* Option buttons and variant tiles mirror the (hidden) selects. */
  function syncVariantUi(form) {
    var root = form.closest('[data-shop-view="product"]') || form;
    var chosen = {};
    form.querySelectorAll('[data-variation-attr]').forEach(function (sel) {
      chosen[sel.getAttribute('data-variation-attr')] = sel.value;
    });
    root.querySelectorAll('[data-attr-chip]').forEach(function (chip) {
      var on = chosen[chip.getAttribute('data-attr-chip')] === chip.getAttribute('data-value');
      chip.classList.toggle('is-active', on);
      chip.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    var input = form.querySelector('[data-variant-input]');
    var id = input ? input.value : '';
    root.querySelectorAll('[data-variant-tile]').forEach(function (tile) {
      tile.classList.toggle('is-active', !!id && tile.getAttribute('data-variant-tile') === id);
    });
  }
  function setVariation(form, values) {
    form.querySelectorAll('[data-variation-attr]').forEach(function (sel) {
      var name = sel.getAttribute('data-variation-attr');
      if (Object.prototype.hasOwnProperty.call(values, name) && values[name]) sel.value = values[name];
    });
    applyVariant(form);
    syncVariantUi(form);
  }
  document.addEventListener('click', function (e) {
    var chip = e.target.closest('[data-attr-chip]');
    var tile = !chip && e.target.closest('[data-variant-tile]');
    if (!chip && !tile) return;
    var root = (chip || tile).closest('[data-shop-view="product"]');
    var form = root && root.querySelector('[data-shop-add]');
    if (!form) return;
    if (chip) {
      var values = {};
      values[chip.getAttribute('data-attr-chip')] = chip.getAttribute('data-value');
      setVariation(form, values);
      return;
    }
    try {
      setVariation(form, JSON.parse(tile.getAttribute('data-variant-attrs') || '{}'));
    } catch (err) {
      /* malformed attrs: leave the selection as it is */
    }
  });

  document.addEventListener('change', function (e) {
    var sel = e.target.closest('[data-variation-attr]');
    if (!sel) return;
    applyVariant(sel.closest('form'));
    syncVariantUi(sel.closest('form'));
  });
  document.addEventListener('click', function (e) {
    var reset = e.target.closest('[data-variation-reset]');
    if (!reset) return;
    var form = reset.closest('form');
    form.querySelectorAll('[data-variation-attr]').forEach(function (s) {
      s.value = '';
    });
    applyVariant(form);
    syncVariantUi(form);
  });

  /* ── Bag dropdown (header cart icon) ──────────────────────────────── */
  var BAG_ICONS = {
    orders: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
    account: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    signin: '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="m10 17 5-5-5-5M15 12H3"/>',
    signout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/>',
  };
  var bag = null;
  var bagTrigger = null;
  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined && text !== null) node.textContent = text;
    return node;
  }
  function bagIcon(name) {
    var span = el('span', 'bk-bag__link-icon');
    span.setAttribute('aria-hidden', 'true');
    span.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + BAG_ICONS[name] + '</svg>';
    return span;
  }
  function ensureBag() {
    if (bag) return bag;
    bag = el('div', 'bk-bag');
    bag.hidden = true;
    var scrim = el('div', 'bk-bag__scrim');
    scrim.setAttribute('data-bag-close', '');
    var panel = el('div', 'bk-bag__panel');
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', t('Bag'));
    panel.tabIndex = -1;
    panel.appendChild(el('div', 'bk-bag__inner'));
    bag.appendChild(scrim);
    bag.appendChild(panel);
    document.body.appendChild(bag);
    return bag;
  }
  function renderBag(cart, me) {
    var inner = bag.querySelector('.bk-bag__inner');
    var d = bagTrigger.dataset;
    inner.innerHTML = '';
    var items = (cart && cart.items) || [];
    var count = (cart && cart.itemCount) || 0;
    var main = el('div', 'bk-bag__main');
    if (!items.length) {
      main.appendChild(el('h2', 'bk-bag__title', t('Your bag is empty.')));
      if (d.account && !(me && me.signedIn)) {
        var hint = el('p', 'bk-bag__lead');
        var signLink = el('a', '', t('Sign in'));
        signLink.href = d.account + '/login';
        hint.appendChild(signLink);
        hint.appendChild(document.createTextNode(' ' + t('to see your orders and saved details.')));
        main.appendChild(hint);
      }
      var shopLink = el('a', 'bk-bag__btn is-ghost', t('Continue shopping'));
      shopLink.href = d.shop || '/shop';
      main.appendChild(shopLink);
    } else {
      var head = el('div', 'bk-bag__head');
      var titles = el('div');
      titles.appendChild(el('h2', 'bk-bag__title', t('Bag')));
      titles.appendChild(el('p', 'bk-bag__lead', count === 1 ? t('1 item') : count + ' ' + t('items')));
      head.appendChild(titles);
      var checkout = el('a', 'bk-bag__btn', t('Check out'));
      checkout.href = d.checkout || '/checkout';
      head.appendChild(checkout);
      main.appendChild(head);
      var list = el('ul', 'bk-bag__items');
      items.slice(0, 4).forEach(function (it) {
        var li = el('li');
        var a = el('a', 'bk-bag__item');
        a.href = it.path || '#';
        var media = el('span', 'bk-bag__thumb');
        if (it.imageUrl) {
          var img = el('img');
          img.src = it.imageUrl;
          img.alt = '';
          img.loading = 'lazy';
          media.appendChild(img);
        }
        a.appendChild(media);
        var info = el('span', 'bk-bag__info');
        info.appendChild(el('span', 'bk-bag__name', it.name));
        var attrs = Object.keys(it.attributes || {}).map(function (k) {
          return it.attributes[k];
        }).filter(Boolean).join(' · ');
        info.appendChild(el('span', 'bk-bag__meta', (attrs ? attrs + ' · ' : '') + t('Qty') + ' ' + it.qty));
        a.appendChild(info);
        a.appendChild(el('span', 'bk-bag__price', (it.formatted && it.formatted.subtotal) || ''));
        li.appendChild(a);
        list.appendChild(li);
      });
      main.appendChild(list);
      var foot = el('div', 'bk-bag__foot');
      var more = items.length > 4 ? items.length - 4 : 0;
      var view = el('a', 'bk-bag__view', more ? '+' + more + ' ' + t('more in your bag') : t('View bag'));
      view.href = bagTrigger.getAttribute('href') || '/cart';
      foot.appendChild(view);
      var sub = el('p', 'bk-bag__subtotal');
      sub.appendChild(el('span', '', t('Subtotal')));
      sub.appendChild(el('strong', '', (cart.formatted && cart.formatted.subtotal) || ''));
      foot.appendChild(sub);
      main.appendChild(foot);
    }
    inner.appendChild(main);

    if (d.account) {
      var profile = el('nav', 'bk-bag__profile');
      profile.setAttribute('aria-label', t('My profile'));
      profile.appendChild(el('h3', 'bk-bag__profile-title', t('My profile')));
      var links = el('ul', 'bk-bag__links');
      var add = function (icon, label, href, onClick) {
        var li = el('li');
        var a = el(href ? 'a' : 'button', 'bk-bag__link');
        if (href) a.href = href;
        else a.type = 'button';
        a.appendChild(bagIcon(icon));
        a.appendChild(el('span', '', label));
        if (onClick) a.addEventListener('click', onClick);
        li.appendChild(a);
        links.appendChild(li);
      };
      add('orders', t('Orders'), d.account + '/orders');
      add('account', t('Account'), d.account);
      if (me && me.signedIn) {
        add('signout', t('Sign out'), null, function () {
          request('POST', '/account/logout', {}).finally(function () {
            location.reload();
          });
        });
      } else {
        add('signin', t('Sign in'), d.account + '/login');
      }
      profile.appendChild(links);
      inner.appendChild(profile);
    }
  }
  /* Bag data is fetched before the panel opens (and prefetched on hover), so it opens once at its final height. */
  var bagData = null;
  var bagFetched = 0;
  var bagPending = null;
  var bagCloseTimer = null;
  function fetchBag(trigger) {
    if (bagPending) return bagPending;
    var d = trigger.dataset;
    bagPending = Promise.all([
      request('GET', '/cart'),
      d.account ? request('GET', '/account/me').catch(function () { return null; }) : Promise.resolve(null),
    ])
      .then(function (res) {
        setCount((res[0] && res[0].itemCount) || 0);
        bagData = res;
        bagFetched = Date.now();
        return res;
      })
      .finally(function () {
        bagPending = null;
      });
    return bagPending;
  }
  function showBag(trigger) {
    clearTimeout(bagCloseTimer);
    var header = trigger.closest('header, .bk-nav') || trigger;
    bag.style.setProperty('--bag-top', Math.max(0, header.getBoundingClientRect().bottom) + 'px');
    bag.hidden = false;
    void bag.offsetHeight; // start the transition from the closed state
    bag.classList.add('is-open');
    trigger.setAttribute('aria-expanded', 'true');
    bag.querySelector('.bk-bag__panel').focus({ preventScroll: true });
  }
  function openBag(trigger) {
    bagTrigger = trigger;
    ensureBag();
    // Fresh enough: open straight away and refresh quietly. Otherwise wait for the data first.
    if (bagData && Date.now() - bagFetched < 15000) {
      renderBag(bagData[0], bagData[1]);
      showBag(trigger);
      fetchBag(trigger).then(function (res) {
        if (bag.classList.contains('is-open')) renderBag(res[0], res[1]);
      }).catch(function () {});
      return;
    }
    trigger.classList.add('is-loading');
    fetchBag(trigger)
      .then(function (res) {
        renderBag(res[0], res[1]);
      })
      .catch(function () {
        var inner = bag.querySelector('.bk-bag__inner');
        inner.innerHTML = '';
        inner.appendChild(el('p', 'bk-bag__lead', t('Could not load your bag.')));
      })
      .finally(function () {
        trigger.classList.remove('is-loading');
        if (bagTrigger === trigger) showBag(trigger);
      });
  }
  function closeBag(restoreFocus) {
    if (!bag || bag.hidden || !bag.classList.contains('is-open')) return;
    bag.classList.remove('is-open');
    if (bagTrigger) {
      bagTrigger.setAttribute('aria-expanded', 'false');
      if (restoreFocus) bagTrigger.focus();
    }
    clearTimeout(bagCloseTimer);
    bagCloseTimer = setTimeout(function () {
      if (!bag.classList.contains('is-open')) bag.hidden = true;
    }, 300);
  }
  ['pointerenter', 'focusin'].forEach(function (type) {
    document.addEventListener(
      type,
      function (e) {
        var trigger = e.target.closest && e.target.closest('[data-bk-bag]');
        if (trigger && (!bagData || Date.now() - bagFetched > 15000)) fetchBag(trigger).catch(function () {});
      },
      true
    );
  });
  // Capture phase: runs before the site's soft navigation, which skips clicks already handled.
  document.addEventListener(
    'click',
    function (e) {
      var trigger = e.target.closest && e.target.closest('[data-bk-bag]');
      if (!trigger || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
      e.preventDefault();
      if (bag && bag.classList.contains('is-open')) closeBag(false);
      else openBag(trigger);
    },
    true
  );
  document.addEventListener('click', function (e) {
    if (!bag || bag.hidden || e.target.closest('[data-bk-bag]')) return;
    if (e.target.closest('[data-bag-close]') || e.target.closest('.bk-bag a')) closeBag(false);
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeBag(true);
  });
  // Width changes only: phones fire resize while scrolling as the address bar hides.
  var bagWidth = window.innerWidth;
  window.addEventListener('resize', function () {
    if (window.innerWidth === bagWidth) return;
    bagWidth = window.innerWidth;
    closeBag(false);
  });
  window.addEventListener('bk:navigate', function () {
    closeBag(false);
  });

  /* ── Shop archive: search, sort and paging without a page reload ──── */
  var archiveRequest = null;
  var archiveTimer = null;
  function priceState(root) {
    var box = root.querySelector('[data-price-range]');
    if (!box) return null;
    var lo = box.querySelector('[data-price-min]');
    var hi = box.querySelector('[data-price-max]');
    if (!lo || !hi) return null;
    var min = Number(lo.min);
    var max = Number(lo.max);
    var a = Math.min(Number(lo.value), Number(hi.value));
    var b = Math.max(Number(lo.value), Number(hi.value));
    return { box: box, lo: lo, hi: hi, min: min, max: max, a: a, b: b, active: a > min || b < max };
  }
  function money(box, n) {
    var sym = box.getAttribute('data-symbol') || '';
    var pos = box.getAttribute('data-position') || 'left';
    var num = String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    if (pos === 'right') return num + sym;
    if (pos === 'right_space') return num + ' ' + sym;
    if (pos === 'left_space') return sym + ' ' + num;
    return sym + num;
  }
  function paintPrice(root) {
    var p = priceState(root);
    if (!p) return;
    var span = Math.max(1, p.max - p.min);
    p.box.style.setProperty('--lo', ((p.a - p.min) / span) * 100 + '%');
    p.box.style.setProperty('--hi', ((p.b - p.min) / span) * 100 + '%');
    var l1 = root.querySelector('[data-price-min-label]');
    var l2 = root.querySelector('[data-price-max-label]');
    if (l1) l1.textContent = money(p.box, p.a);
    if (l2) l2.textContent = money(p.box, p.b);
  }
  function archiveParams(root) {
    var input = root.querySelector('[data-archive-search] input[name="q"]');
    var sort = root.querySelector('[data-shop-sort]');
    var page = new URLSearchParams(location.search).get('page') || '';
    // Sidebar filters: "On sale", any values per attribute (Color:Green,Blue|Material:Oak) and the price range.
    var sale = root.querySelector('[data-archive-filter="sale"]');
    var groups = {};
    var order = [];
    root.querySelectorAll('[data-archive-filter="attr"]').forEach(function (c) {
      if (!c.checked) return;
      var name = c.getAttribute('data-attr-name');
      if (!groups[name]) {
        groups[name] = [];
        order.push(name);
      }
      groups[name].push(c.value);
    });
    var attr = order.map(function (name) {
      return name + ':' + groups[name].join(',');
    });
    var p = priceState(root);
    return {
      q: input ? input.value.trim() : '',
      sort: sort ? sort.value : '',
      page: page,
      sale: sale && sale.checked ? '1' : '',
      attr: attr.join('|'),
      price: p && p.active ? (p.a > p.min ? p.a : '') + '-' + (p.b < p.max ? p.b : '') : '',
    };
  }
  function loadArchive(root, changes, push) {
    var params = archiveParams(root);
    Object.keys(changes || {}).forEach(function (k) {
      params[k] = changes[k];
    });
    var view = root.getAttribute('data-archive');
    var api = new URLSearchParams();
    if (view === 'category') api.set('slug', root.getAttribute('data-archive-slug') || '');
    var visible = new URLSearchParams();
    ['q', 'sort', 'sale', 'attr', 'price', 'page'].forEach(function (k) {
      if (!params[k] || (k === 'sort' && params[k] === 'menu_order') || (k === 'page' && params[k] === '1')) return;
      api.set(k, params[k]);
      visible.set(k, params[k]);
    });
    if (archiveRequest) archiveRequest.abort();
    var ctrl = 'AbortController' in window ? new AbortController() : null;
    archiveRequest = ctrl;
    var results = root.querySelector('[data-archive-results]');
    root.classList.add('is-loading');
    return fetch(API + '/view/' + view + '?' + api.toString(), {
      credentials: 'same-origin',
      headers: { Accept: 'application/json' },
      signal: ctrl ? ctrl.signal : undefined,
    })
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      })
      .then(function (data) {
        var doc = new DOMParser().parseFromString(data.html || '', 'text/html');
        var nextResults = doc.querySelector('[data-archive-results]');
        if (!nextResults) throw new Error('No results region');
        var nextCount = doc.querySelector('[data-archive-count]');
        var count = root.querySelector('[data-archive-count]');
        if (nextResults && results) results.replaceWith(nextResults);
        if (nextCount && count) count.textContent = nextCount.textContent;
        var url = (root.getAttribute('data-archive-path') || location.pathname) + (visible.toString() ? '?' + visible.toString() : '');
        history[push ? 'pushState' : 'replaceState']({ bkArchive: true }, '', url);
        if (changes && changes.page) root.scrollIntoView({ behavior: 'smooth', block: 'start' });
      })
      .catch(function (err) {
        if (err && err.name === 'AbortError') return;
        toast(t('Could not load products. Please try again.'), 'error');
      })
      .finally(function () {
        if (archiveRequest === ctrl) {
          archiveRequest = null;
          root.classList.remove('is-loading');
        }
      });
  }
  document.addEventListener('input', function (e) {
    var input = e.target.closest('[data-archive-search] input[name="q"]');
    if (!input) return;
    var root = input.closest('[data-archive]');
    clearTimeout(archiveTimer);
    archiveTimer = setTimeout(function () {
      loadArchive(root, { page: '' }, false);
    }, 250);
  });
  document.addEventListener('submit', function (e) {
    var form = e.target.closest('[data-archive-search]');
    var root = form && form.closest('[data-archive]');
    if (!root) return;
    e.preventDefault();
    clearTimeout(archiveTimer);
    loadArchive(root, { page: '' }, false);
  });
  document.addEventListener('click', function (e) {
    var link = e.target.closest('[data-archive-results] .bk-shop-pagination a');
    var root = link && link.closest('[data-archive]');
    if (!root || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
    e.preventDefault();
    loadArchive(root, { page: new URL(link.href, location.href).searchParams.get('page') || '' }, true);
  });
  window.addEventListener('popstate', function (e) {
    var root = document.querySelector('[data-archive]');
    if (!root || !e.state || !e.state.bkArchive) return;
    var sp = new URLSearchParams(location.search);
    var input = root.querySelector('[data-archive-search] input[name="q"]');
    var sort = root.querySelector('[data-shop-sort]');
    if (input) input.value = sp.get('q') || '';
    if (sort) sort.value = sp.get('sort') || 'menu_order';
    var sale = root.querySelector('[data-archive-filter="sale"]');
    if (sale) sale.checked = sp.get('sale') === '1';
    var picked = {};
    (sp.get('attr') || '').split('|').forEach(function (pair) {
      var i = pair.indexOf(':');
      if (i > 0) picked[pair.slice(0, i)] = pair.slice(i + 1).split(',');
    });
    root.querySelectorAll('[data-archive-filter="attr"]').forEach(function (c) {
      var vals = picked[c.getAttribute('data-attr-name')] || [];
      c.checked = vals.indexOf(c.value) !== -1;
    });
    var p = priceState(root);
    if (p) {
      var pr = (sp.get('price') || '').split('-');
      p.lo.value = pr[0] !== undefined && pr[0] !== '' ? pr[0] : String(p.min);
      p.hi.value = pr[1] !== undefined && pr[1] !== '' ? pr[1] : String(p.max);
    }
    paintFilters(root);
    loadArchive(root, { page: sp.get('page') || '' }, false);
  });

  /* ── Shop archive: filter the category tiles ─────────────────────── */
  document.addEventListener('input', function (e) {
    var input = e.target.closest('[data-cat-filter]');
    if (!input) return;
    var panel = input.closest('[data-cat-panel]');
    var q = input.value.trim().toLowerCase();
    var shown = 0;
    panel.querySelectorAll('[data-cat-name]').forEach(function (tile) {
      var hit = !q || tile.getAttribute('data-cat-name').toLowerCase().indexOf(q) !== -1;
      tile.parentNode.hidden = !hit;
      if (hit) shown++;
    });
    var empty = panel.querySelector('[data-cat-empty]');
    if (empty) empty.hidden = shown > 0;
  });

  /* ── Product page scroll: card fades in, stage eases back as the card covers it ── */
  var motionQueued = false;
  function updateProductMotion() {
    motionQueued = false;
    document.querySelectorAll('.bk-pdp.js-motion').forEach(function (pdp) {
      var stage = pdp.querySelector('.bk-pdp__stage');
      var card = pdp.querySelector('.bk-pdp__card');
      if (getComputedStyle(stage).position !== 'sticky') {
        pdp.style.removeProperty('--pdp-p');
        return;
      }
      var s = stage.getBoundingClientRect();
      var p = (s.bottom - card.getBoundingClientRect().top) / Math.max(s.height, 1);
      pdp.style.setProperty('--pdp-p', Math.min(1, Math.max(0, p)).toFixed(3));
    });
  }
  function queueProductMotion() {
    if (motionQueued) return;
    motionQueued = true;
    requestAnimationFrame(updateProductMotion);
  }
  window.addEventListener('scroll', queueProductMotion, { passive: true });
  window.addEventListener('resize', queueProductMotion);
  function initProductMotion() {
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce || !('IntersectionObserver' in window)) return;
    document.querySelectorAll('.bk-pdp:not(.js-motion)').forEach(function (pdp) {
      var card = pdp.querySelector('.bk-pdp__card');
      if (!card || !pdp.querySelector('.bk-pdp__stage')) return;
      pdp.classList.add('js-motion');
      new IntersectionObserver(
        function (entries, io) {
          if (!entries.some(function (en) { return en.isIntersecting; })) return;
          card.classList.add('is-in');
          io.disconnect();
        },
        { rootMargin: '0px 0px -60px 0px' }
      ).observe(card);
    });
    updateProductMotion();
  }

  /* ── Gallery thumbs ───────────────────────────────────────────────── */
  document.addEventListener('click', function (e) {
    var thumb = e.target.closest('[data-gallery-thumb]');
    if (!thumb) return;
    var gallery = thumb.closest('[data-gallery]');
    var img = gallery && gallery.querySelector('.bk-product__img');
    if (!img) return;
    img.src = thumb.getAttribute('data-gallery-thumb');
    img.alt = thumb.getAttribute('data-gallery-alt') || '';
    gallery.querySelectorAll('[data-gallery-thumb]').forEach(function (b) {
      b.classList.toggle('is-active', b === thumb);
    });
  });

  /* ── Tabs ─────────────────────────────────────────────────────────── */
  document.addEventListener('click', function (e) {
    var tab = e.target.closest('[data-tab]');
    if (!tab) return;
    var root = tab.closest('[data-tabs]');
    var id = tab.getAttribute('data-tab');
    root.querySelectorAll('[data-tab]').forEach(function (b) {
      var on = b === tab;
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    root.querySelectorAll('[data-tab-panel]').forEach(function (p) {
      p.classList.toggle('is-active', p.getAttribute('data-tab-panel') === id);
    });
  });

  /* ── Add to cart ──────────────────────────────────────────────────── */
  document.addEventListener('submit', function (e) {
    var form = e.target.closest('[data-shop-add]');
    if (!form) return;
    e.preventDefault();
    var productId = form.querySelector('[name="productId"]').value;
    var variantInput = form.querySelector('[data-variant-input]');
    var variantId = variantInput ? variantInput.value : '';
    var qtyInput = form.querySelector('[name="qty"]');
    var qty = Math.max(1, Number(qtyInput && qtyInput.value) || 1);
    var msg = form.querySelector('[data-add-message]');
    if (form.querySelector('[data-variation-attr]') && !variantId) {
      if (msg) msg.textContent = t('Please choose the product options first.');
      return;
    }
    busy(form, true);
    request('POST', '/cart/items', { productId: productId, variantId: variantId || undefined, qty: qty })
      .then(function (cart) {
        setCount(cart.itemCount || 0);
        if (msg) msg.textContent = '';
        var cartPath = (window.__bkShopPaths && window.__bkShopPaths.cart) || '/cart';
        toast(t('Added to your cart.'), 'success', { href: cartPath, label: t('View cart') });
      })
      .catch(function (err) {
        if (msg) msg.textContent = err.message;
        else toast(err.message, 'error');
      })
      .finally(function () {
        busy(form, false);
      });
  });

  /* A page-editor link bound to "Add to cart" (data-add-to-cart="productId") adds the product
     without leaving the page. Themes that handle such links themselves preventDefault first. */
  document.addEventListener('click', function (e) {
    var link = e.target.closest('a[data-add-to-cart]');
    if (!link || e.defaultPrevented) return;
    var productId = link.getAttribute('data-add-to-cart');
    if (!productId) return;
    e.preventDefault();
    if (link.classList.contains('is-busy')) return;
    link.classList.add('is-busy');
    request('POST', '/cart/items', { productId: productId, qty: 1 })
      .then(function (cart) {
        setCount(cart.itemCount || 0);
        var cartPath = (window.__bkShopPaths && window.__bkShopPaths.cart) || '/cart';
        toast(t('Added to your cart.'), 'success', { href: cartPath, label: t('View cart') });
      })
      .catch(function (err) {
        toast(err.message, 'error');
      })
      .finally(function () {
        link.classList.remove('is-busy');
      });
  });

  /* ── Cart page ────────────────────────────────────────────────────── */
  function reloadCartRegion() {
    var region = document.querySelector('[data-shop-view="cart"] [data-cart-region]');
    if (!region) return Promise.resolve();
    return fetch(API + '/view/cart', { credentials: 'same-origin', headers: { Accept: 'application/json' } })
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        var doc = new DOMParser().parseFromString(data.html || '', 'text/html');
        var next = doc.querySelector('[data-cart-region]');
        if (next) region.replaceWith(next);
      });
  }

  /* Quantities are edited freely; "Update cart" saves every changed row at once. */
  function markCartDirty() {
    var btn = document.querySelector('[data-cart-update]');
    if (!btn) return;
    var dirty = Array.prototype.some.call(document.querySelectorAll('[data-cart-qty]'), function (i) {
      return String(Number(i.value) || 0) !== i.getAttribute('data-cart-qty-initial');
    });
    btn.disabled = !dirty;
    btn.classList.toggle('is-dirty', dirty);
  }
  document.addEventListener('change', function (e) {
    if (e.target.closest('[data-cart-qty]')) markCartDirty();
  });
  document.addEventListener('input', function (e) {
    if (e.target.closest('[data-cart-qty]')) markCartDirty();
  });
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-cart-update]');
    if (!btn) return;
    var changed = Array.prototype.filter.call(document.querySelectorAll('[data-cart-qty]'), function (i) {
      return String(Number(i.value) || 0) !== i.getAttribute('data-cart-qty-initial');
    });
    if (!changed.length) return;
    busy(btn.closest('[data-cart-region]'), true);
    changed
      .reduce(function (p, input) {
        return p.then(function () {
          return request('PATCH', '/cart/items', { key: input.getAttribute('data-cart-qty'), qty: Math.max(0, Number(input.value) || 0) });
        });
      }, Promise.resolve())
      .then(function (cart) {
        if (cart) setCount(cart.itemCount || 0);
        toast(t('Cart updated.'), 'success');
      })
      .catch(function (err) {
        toast(err.message, 'error');
      })
      .then(reloadCartRegion);
  });

  /* Cart shipping estimate: country + chosen method (re-checked at checkout). */
  function saveEstimate(extra) {
    var form = document.querySelector('[data-cart-estimate]');
    var country = form && form.querySelector('[name="country"]').value;
    if (!country) {
      toast(t('Choose your country first.'), 'error');
      return;
    }
    var body = { country: country, state: form.querySelector('[name="state"]').value.trim(), postcode: form.querySelector('[name="postcode"]').value.trim() };
    var picked = document.querySelector('[data-cart-ship]:checked');
    if (extra && extra.methodId) body.shippingMethodId = extra.methodId;
    else if (picked) body.shippingMethodId = picked.value;
    busy(document.querySelector('.bk-cart2__summary'), true);
    request('POST', '/cart/shipping', body)
      .catch(function (err) {
        toast(err.message, 'error');
      })
      .then(reloadCartRegion);
  }
  document.addEventListener('change', function (e) {
    var radio = e.target.closest('[data-cart-ship]');
    if (radio) saveEstimate({ methodId: radio.value });
  });
  document.addEventListener('submit', function (e) {
    var form = e.target.closest('[data-cart-estimate]');
    if (!form) return;
    e.preventDefault();
    saveEstimate();
  });

  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-cart-remove]');
    if (!btn) return;
    var key = btn.getAttribute('data-cart-remove');
    busy(btn.closest('[data-cart-key]'), true);
    request('PATCH', '/cart/items', { key: key, qty: 0 })
      .then(function (cart) {
        setCount(cart.itemCount || 0);
        return reloadCartRegion();
      })
      .catch(function (err) {
        toast(err.message, 'error');
        return reloadCartRegion();
      });
  });

  document.addEventListener('submit', function (e) {
    var form = e.target.closest('[data-coupon-form]');
    if (!form) return;
    e.preventDefault();
    var code = form.querySelector('[name="code"]');
    var msg = form.querySelector('[data-coupon-message]');
    if (!code || !code.value.trim()) return;
    busy(form, true);
    request('POST', '/cart/coupon', { code: code.value.trim() })
      .then(function () {
        toast(t('Coupon applied.'), 'success');
        return reloadCartRegion();
      })
      .catch(function (err) {
        if (msg) msg.textContent = err.message;
        busy(form, false);
      });
  });
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-coupon-remove]');
    if (!btn) return;
    request('DELETE', '/cart/coupon')
      .then(reloadCartRegion)
      .catch(function (err) {
        toast(err.message, 'error');
      });
  });

  /* ── Checkout ─────────────────────────────────────────────────────── */
  function formData(form) {
    var data = { billing: {}, shipping: {}, extra: {} };
    Array.prototype.forEach.call(form.elements, function (el) {
      if (!el.name) return;
      if (el.type === 'radio' && !el.checked) return;
      if (el.name.indexOf('extra.') === 0) {
        // Custom checkout fields (Shop → Settings → Checkout): sent as strings, validated server-side.
        data.extra[el.name.slice(6)] = el.type === 'checkbox' ? (el.checked ? '1' : '') : el.value.trim();
        return;
      }
      if (el.type === 'checkbox') {
        data[el.name] = el.checked;
        return;
      }
      var parts = el.name.split('.');
      if (parts.length === 2 && (parts[0] === 'billing' || parts[0] === 'shipping')) data[parts[0]][parts[1]] = el.value.trim();
      else data[el.name] = el.value.trim();
    });
    data.shipToDifferent = !!data.shipToDifferent;
    if (!data.shipToDifferent) delete data.shipping;
    data.termsAccepted = !!data.termsAccepted;
    data.createAccount = !!data.createAccount;
    if (!data.createAccount) delete data.accountPassword;
    return data;
  }

  function destinationOf(form) {
    var d = formData(form);
    var a = d.shipToDifferent && d.shipping ? d.shipping : d.billing;
    if (!a.country) return null;
    return { country: a.country, state: a.state || '', postcode: a.postcode || '' };
  }

  function renderTotals(form, cart, options) {
    var totals = form.querySelector('[data-checkout-totals]');
    if (!totals || !cart) return;
    var set = function (key, value, hidden) {
      var row = totals.querySelector('[data-total="' + key + '"]');
      if (!row) return;
      row.hidden = !!hidden;
      var cell = row.querySelector('td');
      if (cell) {
        cell.textContent = value;
        cell.classList.remove('is-muted');
      }
    };
    set('subtotal', cart.formatted.subtotal);
    set('discount', cart.coupon ? '−' + cart.coupon.formatted : '', !cart.coupon);
    var ship = cart.shipping ? (cart.shipping.cost === 0 ? t('Free') : cart.shipping.formatted) : '—';
    set('shipping', ship, !cart.needsShipping);
    set('tax', cart.formatted.taxTotal, !cart.taxTotal);
    set('total', cart.formatted.total);
    var placeTotal = form.querySelector('[data-place-total]');
    if (placeTotal) placeTotal.textContent = cart.formatted.total;

    var list = form.querySelector('[data-shipping-list]');
    var placeholder = form.querySelector('[data-shipping-placeholder]');
    if (list) {
      list.innerHTML = '';
      var current = form.querySelector('[name="shippingMethodId"]:checked');
      var currentId = current ? current.value : list.getAttribute('data-preferred') || null;
      (options || []).forEach(function (o, i) {
        var li = document.createElement('li');
        var label = document.createElement('label');
        label.className = 'bk-option';
        var radio = document.createElement('input');
        radio.type = 'radio';
        radio.name = 'shippingMethodId';
        radio.value = o.id;
        radio.checked = currentId ? currentId === o.id : i === 0;
        var body = document.createElement('span');
        body.className = 'bk-option__body';
        var title = document.createElement('span');
        title.className = 'bk-option__title';
        title.textContent = o.title;
        var price = document.createElement('span');
        price.className = 'bk-option__price';
        price.textContent = o.cost === 0 ? t('Free') : o.formatted;
        body.appendChild(title);
        body.appendChild(price);
        label.appendChild(radio);
        label.appendChild(body);
        li.appendChild(label);
        list.appendChild(li);
      });
      var has = (options || []).length > 0;
      list.hidden = !has;
      if (placeholder) {
        placeholder.hidden = has;
        if (!has && destinationOf(form)) placeholder.textContent = t('Sorry, we cannot ship to that address.');
      }
    }
  }

  var quoteTimer = null;
  function quote(form) {
    var dest = destinationOf(form);
    if (!dest || !form.querySelector('[data-shipping-options]')) return;
    clearTimeout(quoteTimer);
    quoteTimer = setTimeout(function () {
      request('POST', '/checkout/shipping', dest)
        .then(function (page) {
          var chosen = form.querySelector('[name="shippingMethodId"]:checked');
          var options = page.shippingOptions || [];
          var cart = page.cart;
          // The server quoted with the cheapest option; reflect the shopper's choice locally.
          if (chosen && options.length) {
            var pick = options.filter(function (o) {
              return o.id === chosen.value;
            })[0];
            if (pick && cart.shipping && pick.id !== cart.shipping.id) {
              var delta = pick.cost - cart.shipping.cost;
              cart.shipping = { id: pick.id, cost: pick.cost, formatted: pick.formatted, title: pick.title };
              cart.total += delta;
              cart.formatted.total = pick.cost === 0 && cart.total === 0 ? t('Free') : cart.formatted.total; // best effort; the server recomputes on place order
            }
          }
          renderTotals(form, cart, options);
          form.__bkOptions = options;
        })
        .catch(function (err) {
          toast(err.message, 'error');
        });
    }, 300);
  }

  document.addEventListener('change', function (e) {
    var form = e.target.closest('[data-checkout-form]');
    if (!form) return;
    if (e.target.matches('[data-ship-different]')) {
      var fields = form.querySelector('[data-ship-fields]');
      if (fields) {
        fields.hidden = !e.target.checked;
        fields.querySelectorAll('input, select').forEach(function (el) {
          if (el.hasAttribute('data-req') || el.required) el.required = e.target.checked && el.getAttribute('data-req') !== '0';
        });
      }
      quote(form);
      return;
    }
    if (e.target.matches('[name="shippingMethodId"]')) {
      // Re-quote so the totals show the chosen method's price.
      quote(form);
      return;
    }
    if (/\.(country|state|postcode)$/.test(e.target.name || '')) quote(form);
  });

  function showCheckoutError(form, message) {
    var box = form.querySelector('[data-checkout-error]');
    if (!box) return;
    box.textContent = message;
    box.hidden = !message;
    if (message) box.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }

  document.addEventListener('submit', function (e) {
    var form = e.target.closest('[data-checkout-form]');
    if (!form) return;
    e.preventDefault();
    showCheckoutError(form, '');
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }
    var data = formData(form);
    if (form.querySelector('[data-shipping-options]') && !data.shippingMethodId) {
      showCheckoutError(form, t('Please choose a shipping method.'));
      return;
    }
    busy(form, true);
    var btn = form.querySelector('[data-place-order]');
    var label = form.querySelector('[data-place-label]');
    if (label) label.textContent = t('Placing order…');
    request('POST', '/checkout', data)
      .then(function (result) {
        setCount(0);
        if (result.redirectUrl) window.location.assign(result.redirectUrl);
      })
      .catch(function (err) {
        showCheckoutError(form, err.message);
        busy(form, false);
        if (btn) btn.disabled = false;
        if (label) label.textContent = t('Place order');
      });
  });

  function initCheckout(root) {
    var form = root.querySelector('[data-checkout-form]');
    if (!form || form.__bkInit) return;
    form.__bkInit = true;
    var ship = form.querySelector('[data-ship-fields]');
    if (ship) {
      ship.querySelectorAll('input, select').forEach(function (el) {
        el.setAttribute('data-req', el.required ? '1' : '0');
        el.required = false;
      });
    }
    quote(form);
  }

  /* ── Order received (Stripe return) ───────────────────────────────── */
  function initReceived(root) {
    var token = root.getAttribute('data-confirm-token');
    if (!token || root.__bkConfirm) return;
    root.__bkConfirm = true;
    var session = root.getAttribute('data-confirm-session') || undefined;
    var attempts = 0;
    var title = root.querySelector('[data-confirm-title]');
    var lead = root.querySelector('[data-confirm-lead]');
    var status = root.querySelector('[data-order-status]');
    var done = function (paid) {
      if (paid) {
        if (title) title.textContent = t('Thank you');
        if (lead) lead.textContent = t('Your payment was received and your order is being processed.');
        root.querySelector('.bk-received__icon').className = 'bk-received__icon';
        if (status) status.textContent = t('Processing');
        setTimeout(function () {
          location.reload();
        }, 1200);
      } else {
        if (title) title.textContent = t('Payment pending');
        if (lead) lead.textContent = t('We have not received a payment confirmation yet. If you completed the payment, this page will update shortly; otherwise your cart is still available.');
      }
    };
    var tick = function () {
      attempts += 1;
      request('POST', '/checkout/confirm', { token: token, sessionId: session })
        .then(function (r) {
          if (r.paid) done(true);
          else if (attempts < 6) setTimeout(tick, 2000);
          else done(false);
        })
        .catch(function () {
          if (attempts < 6) setTimeout(tick, 2500);
          else done(false);
        });
    };
    tick();
  }

  /* ── Toolbar filters (On sale, attributes) reload the grid ───────── */
  function paintFilters(root) {
    var params = archiveParams(root);
    var active = (params.sale ? 1 : 0) + (params.attr ? params.attr.split('|').length : 0) + (params.price ? 1 : 0);
    root.querySelectorAll('[data-archive-clear]').forEach(function (clear) {
      clear.hidden = active === 0;
    });
    var badge = root.querySelector('[data-filter-count]');
    if (badge) {
      badge.textContent = String(active);
      badge.hidden = active === 0;
    }
    paintPrice(root);
    // Each dropdown button names what is picked: "Price: 100 – 480", "Oak", "Finish · 2".
    root.querySelectorAll('[data-facet]').forEach(function (f) {
      var kind = f.getAttribute('data-facet');
      var label = f.querySelector('[data-facet-label]');
      var on = false;
      if (kind === 'price') {
        var p = priceState(root);
        on = !!p && p.active;
        if (label) label.textContent = on ? money(p.box, p.a) + ' – ' + money(p.box, p.b) : label.getAttribute('data-facet-label');
      } else if (kind === 'attr') {
        var picked = [];
        f.querySelectorAll('[data-archive-filter="attr"]').forEach(function (c) {
          if (c.checked) picked.push(c.value);
        });
        on = picked.length > 0;
        if (label) label.textContent = picked.length === 1 ? picked[0] : picked.length > 1 ? label.getAttribute('data-facet-label') + ' · ' + picked.length : label.getAttribute('data-facet-label');
      } else {
        var c = f.querySelector('[data-archive-filter]');
        on = !!c && c.checked;
      }
      f.classList.toggle('is-on', on);
    });
  }
  /* ── Phone filter drawer: the category list and the filter panels slide in from the left ── */
  var drawerHomes = [];
  var drawerOverflow = '';
  function setDrawer(open) {
    var drawer = document.querySelector('[data-drawer]');
    if (!drawer || open === !drawer.hidden) return;
    var body = drawer.querySelector('[data-drawer-body]');
    var btn = document.querySelector('[data-drawer-open]');
    if (open) {
      closeFacets(null);
      drawerHomes = [];
      ['.bk-archive__side', '.bk-facets'].forEach(function (sel) {
        var el = document.querySelector('[data-archive] ' + sel);
        if (!el || drawer.contains(el)) return;
        var home = document.createComment('bk-drawer-home');
        el.parentNode.insertBefore(home, el);
        drawerHomes.push({ el: el, home: home });
        body.appendChild(el);
      });
      drawer.hidden = false;
      drawerOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      requestAnimationFrame(function () {
        drawer.classList.add('is-open');
      });
      if (btn) btn.setAttribute('aria-expanded', 'true');
      drawer.querySelector('.bk-drawer__panel').focus();
    } else {
      drawer.classList.remove('is-open');
      document.body.style.overflow = drawerOverflow;
      if (btn) btn.setAttribute('aria-expanded', 'false');
      setTimeout(function () {
        drawerHomes.forEach(function (h) {
          h.home.parentNode.replaceChild(h.el, h.home);
        });
        drawerHomes = [];
        drawer.hidden = true;
      }, 260);
    }
  }
  document.addEventListener('click', function (e) {
    if (e.target.closest('[data-drawer-open]')) {
      setDrawer(true);
      return;
    }
    if (e.target.closest('[data-drawer-close]')) setDrawer(false);
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') setDrawer(false);
  });
  window.addEventListener('resize', function () {
    if (window.innerWidth >= 1024) setDrawer(false);
  });
  window.addEventListener('bk:navigate', function () {
    var drawer = document.querySelector('[data-drawer]');
    if (drawer && !drawer.hidden) {
      drawer.classList.remove('is-open');
      drawer.hidden = true;
      document.body.style.overflow = drawerOverflow;
      drawerHomes = [];
    }
  });

  function closeFacets(except) {
    document.querySelectorAll('[data-facet].is-open').forEach(function (f) {
      if (f === except) return;
      f.classList.remove('is-open');
      var panel = f.querySelector('.bk-facet__panel');
      var btn = f.querySelector('.bk-facet__btn[aria-expanded]');
      if (panel) panel.hidden = true;
      if (btn) btn.setAttribute('aria-expanded', 'false');
    });
  }
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('.bk-facet__btn[aria-expanded]');
    if (btn) {
      var f = btn.closest('[data-facet]');
      var open = !f.classList.contains('is-open');
      closeFacets(f);
      f.classList.toggle('is-open', open);
      f.querySelector('.bk-facet__panel').hidden = !open;
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      return;
    }
    if (!e.target.closest('[data-facet]')) closeFacets(null);
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeFacets(null);
  });
  window.addEventListener('bk:navigate', function () {
    closeFacets(null);
  });
  document.addEventListener('change', function (e) {
    var ctl = e.target.closest('[data-archive-filter]');
    var root = ctl && ctl.closest('[data-archive]');
    if (!root) return;
    paintFilters(root);
    loadArchive(root, { page: '' }, true);
  });
  // The price slider repaints as it moves and reloads once the thumb rests.
  var priceTimer = null;
  document.addEventListener('input', function (e) {
    var ctl = e.target.closest('[data-price-min], [data-price-max]');
    var root = ctl && ctl.closest('[data-archive]');
    if (!root) return;
    var p = priceState(root);
    if (p && Number(p.lo.value) > Number(p.hi.value)) {
      if (ctl === p.lo) p.hi.value = p.lo.value;
      else p.lo.value = p.hi.value;
    }
    // While dragging only the slider itself repaints: changing the pill's text would reflow the
    // row and move the panel under the pointer. The pill and the grid update once the thumb rests.
    paintPrice(root);
    clearTimeout(priceTimer);
    priceTimer = setTimeout(function () {
      paintFilters(root);
      loadArchive(root, { page: '' }, true);
    }, 400);
  });
  document.addEventListener('click', function (e) {
    var clear = e.target.closest('[data-archive-clear]');
    var root = clear && clear.closest('[data-archive]');
    if (!root || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
    e.preventDefault();
    root.querySelectorAll('[data-archive-filter]').forEach(function (c) {
      c.checked = false;
    });
    var p = priceState(root);
    if (p) {
      p.lo.value = String(p.min);
      p.hi.value = String(p.max);
    }
    paintFilters(root);
    loadArchive(root, { page: '' }, true);
  });

  /* ── Sort select submits its form ─────────────────────────────────── */
  document.addEventListener('change', function (e) {
    var sel = e.target.closest('[data-shop-sort]');
    if (!sel || !sel.form) return;
    var archive = sel.closest('[data-archive]');
    if (archive) loadArchive(archive, { sort: sel.value, page: '' }, true);
    else if (sel.form.requestSubmit) sel.form.requestSubmit();
    else sel.form.submit();
  });

  /* ── Init on load and after soft navigation ───────────────────────── */
  /* ── My account ─────────────────────────────────────────────────── */
  function safeRedirect() {
    var r = new URLSearchParams(location.search).get('redirect') || '';
    return /^\/[a-z0-9/_-]*$/i.test(r) && r.indexOf('//') === -1 ? r : '/account';
  }
  function accountMessage(form, text, ok) {
    var el = form.querySelector('[data-account-message]');
    if (!el) return toast(text, ok ? 'success' : 'error');
    el.textContent = text;
    el.classList.toggle('is-ok', !!ok);
  }
  function addressFrom(form, prefix) {
    var out = {};
    form.querySelectorAll('[name^="' + prefix + '."]').forEach(function (el) {
      out[el.name.slice(prefix.length + 1)] = el.value.trim();
    });
    return out;
  }
  var ACCOUNT_FORMS = {
    login: function (form) {
      return request('POST', '/account/login', {
        login: form.login.value.trim(),
        password: form.password.value,
        remember: !!(form.remember && form.remember.checked),
      }).then(function () {
        location.assign(safeRedirect());
      });
    },
    register: function (form) {
      return request('POST', '/account/register', {
        email: form.email.value.trim(),
        password: form.password.value,
        firstName: form.firstName.value.trim(),
        lastName: form.lastName.value.trim(),
        remember: true,
      }).then(function () {
        location.assign(safeRedirect());
      });
    },
    forgot: function (form) {
      return request('POST', '/account/forgot', { email: form.email.value.trim() }).then(function () {
        accountMessage(form, t('If an account exists for that email, a reset link is on its way.'), true);
        form.reset();
      });
    },
    reset: function (form) {
      return request('POST', '/account/reset', { token: form.token.value, password: form.password.value }).then(function () {
        accountMessage(form, t('Your password was changed. Taking you to sign in…'), true);
        setTimeout(function () {
          location.assign('/account/login');
        }, 1400);
      });
    },
    details: function (form) {
      return request('PATCH', '/account/details', {
        firstName: form.firstName.value.trim(),
        lastName: form.lastName.value.trim(),
        phone: form.phone.value.trim(),
      }).then(function () {
        accountMessage(form, t('Your details were saved.'), true);
        refreshAccount();
      });
    },
    password: function (form) {
      return request('POST', '/account/password', { current: form.current.value, password: form.password.value }).then(function () {
        accountMessage(form, t('Password changed. Other devices were signed out.'), true);
        form.reset();
      });
    },
    addresses: function (form) {
      return request('PUT', '/account/addresses', { billing: addressFrom(form, 'billing'), shipping: addressFrom(form, 'shipping') }).then(function () {
        accountMessage(form, t('Addresses saved.'), true);
      });
    },
  };
  document.addEventListener('submit', function (e) {
    var form = e.target.closest('[data-account-form]');
    if (!form) return;
    e.preventDefault();
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }
    var handler = ACCOUNT_FORMS[form.getAttribute('data-account-form')];
    if (!handler) return;
    accountMessage(form, '', true);
    busy(form, true);
    handler(form)
      .catch(function (err) {
        accountMessage(form, err.message, false);
      })
      .finally(function () {
        busy(form, false);
      });
  });
  document.addEventListener('click', function (e) {
    var pw = e.target.closest('[data-pw-toggle]');
    if (pw) {
      var input = pw.parentNode.querySelector('input');
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      pw.textContent = pw.getAttribute(show ? 'data-hide' : 'data-show');
      return;
    }
    if (e.target.closest('[data-account-logout]')) {
      request('POST', '/account/logout', {}).finally(function () {
        location.assign('/account/login');
      });
    }
    var resend = e.target.closest('[data-account-resend]');
    if (resend) {
      resend.disabled = true;
      request('POST', '/account/verify/resend', {})
        .then(function () {
          toast(t('Confirmation email sent.'), 'success');
        })
        .catch(function (err) {
          toast(err.message, 'error');
          resend.disabled = false;
        });
    }
  });
  /* Checkout: "Create an account" reveals the password field. */
  document.addEventListener('change', function (e) {
    var box = e.target.closest('[data-create-account]');
    if (!box) return;
    var form = box.closest('form');
    var fields = form && form.querySelector('[data-create-account-fields]');
    if (!fields) return;
    fields.hidden = !box.checked;
    var pass = fields.querySelector('input');
    if (pass) pass.required = box.checked;
  });
  function initVerify(root) {
    var el = root.querySelector('[data-account-verify]');
    if (!el || el.__bkDone) return;
    el.__bkDone = true;
    var title = el.querySelector('[data-verify-title]');
    var lead = el.querySelector('[data-verify-lead]');
    var go = el.querySelector('[data-verify-continue]');
    var icon = el.querySelector('.bk-received__icon');
    request('POST', '/account/verify', { token: el.getAttribute('data-account-verify') })
      .then(function () {
        if (title) title.textContent = t('Email confirmed');
        if (lead) lead.textContent = t('Your orders and saved addresses are now available in your account.');
        if (icon) icon.className = 'bk-received__icon';
      })
      .catch(function (err) {
        if (title) title.textContent = t('This link did not work');
        if (lead) lead.textContent = err.message;
        if (icon) icon.className = 'bk-received__icon is-error';
      })
      .finally(function () {
        if (go) go.hidden = false;
      });
  }
  /* Header: show the shopper's first name next to the account icon. */
  function refreshAccount() {
    var links = document.querySelectorAll('[data-bk-account-link]');
    if (!links.length) return;
    request('GET', '/account/me')
      .then(function (me) {
        links.forEach(function (a) {
          var label = a.querySelector('[data-bk-account-name]');
          var name = me.signedIn && me.customer ? me.customer.firstName || t('Account') : '';
          a.classList.toggle('is-signed-in', !!me.signedIn);
          a.setAttribute('aria-label', me.signedIn ? t('My account') : t('Sign in'));
          a.title = me.signedIn ? t('My account') : t('Sign in');
          if (label) {
            label.textContent = name;
            label.hidden = !name;
          }
        });
      })
      .catch(function () {});
  }

  function init() {
    document.querySelectorAll('[data-shop-view="product"] [data-shop-add]').forEach(applyVariant);
    initProductMotion();
    document.querySelectorAll('[data-shop-view="account"]').forEach(initVerify);
    refreshAccount();
    document.querySelectorAll('[data-shop-view="checkout"]').forEach(initCheckout);
    document.querySelectorAll('[data-shop-view="order-received"]').forEach(initReceived);
    refreshCount();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
  window.addEventListener('bk:navigate', init);
})();
