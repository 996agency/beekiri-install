<?php
/**
 * Single product.
 *
 * Data: product (id, title, path, description, shortDescription, image, gallery[],
 *       price, inStock, stockQty, sku, type, attributes[], variants[], categories[],
 *       tags[], purchaseNote, weight, dimensions), related[], breadcrumbs[], variants_json.
 */
$shop = get_bee_field('shop') ?: [];
$p = get_bee_field('product') ?: [];
$related = get_bee_field('related') ?: [];
$crumbs = get_bee_field('breadcrumbs') ?: [];
$isVariable = ($p['type'] ?? 'simple') === 'variable';
$variationAttrs = array_values(array_filter($p['attributes'] ?? [], fn($a) => !empty($a['variation'])));
$visibleAttrs = array_values(array_filter($p['attributes'] ?? [], fn($a) => !empty($a['options'])));
$gallery = array_values(array_filter(array_merge([$p['image'] ?? null], $p['gallery'] ?? []), fn($g) => is_array($g) && !empty($g['url'])));
$dims = $p['dimensions'] ?? [];
$hasDims = !empty($dims['length']) || !empty($dims['width']) || !empty($dims['height']);
$canBuy = !empty($p['inStock']) && (!empty($p['price']) || $isVariable);
$opts = $shop['options'] ?? [];
$opt = fn(string $k, bool $d = true) => isset($opts[$k]) ? (bool) $opts[$k] : $d;
$maxQty = isset($p['stockQty']) && $p['stockQty'] !== null ? (int) $p['stockQty'] : 999;
if (!empty($p['soldIndividually'])) $maxQty = 1;
$variants = $p['variants'] ?? [];
/** Left column: only for products with variants; everything else uses the full width. */
$sideVariants = $isVariable && $variationAttrs && $variants;
$variantLabel = fn(array $v) => implode(' / ', array_filter(array_map('strval', array_values($v['attributes'] ?? [])))) ?: bee_shop_t('Any option');
$hasInfo = $opt('showAdditionalInfo') && ($visibleAttrs || !empty($p['weight']) || $hasDims);
?>
<article class="bk-shop bk-shop--product" data-shop-view="product" data-product-id="<?php echo esc_attr($p['id'] ?? ''); ?>">
  <div class="bk-shop__wrap">
    <?php if ($opt('showBreadcrumbs')) echo bee_shop_breadcrumbs($crumbs); ?>

    <div class="bk-pdp<?php echo $sideVariants ? ' has-side' : ''; ?>">
      <?php if ($sideVariants) : ?>
        <aside class="bk-pdp__side" aria-label="<?php echo esc_attr(bee_shop_t('Options')); ?>">
          <ul class="bk-pdp__tiles" role="list">
            <?php foreach ($variants as $v) : ?>
              <li>
                <button type="button" class="bk-pdp__tile<?php echo empty($v['inStock']) ? ' is-out' : ''; ?>" data-variant-tile="<?php echo esc_attr($v['id']); ?>" data-variant-attrs="<?php echo esc_attr(json_encode((object) ($v['attributes'] ?? []))); ?>">
                  <span class="bk-pdp__tile-media"><?php echo bee_shop_img(!empty($v['image']['url']) ? $v['image'] : ($p['image'] ?? null), '', 'lazy', '160px'); ?></span>
                  <span class="bk-pdp__tile-name"><?php echo esc_html($variantLabel($v)); ?></span>
                  <span class="bk-pdp__tile-meta"><?php echo esc_html(empty($v['inStock']) ? bee_shop_t('Out of stock') : ($v['price']['formatted'] ?? '')); ?></span>
                </button>
              </li>
            <?php endforeach; ?>
          </ul>
        </aside>
      <?php endif; ?>

      <div class="bk-pdp__main">
        <form class="bk-pdp__form bk-add-form" data-shop-add data-variants='<?php echo esc_attr(get_bee_field('variants_json') ?: '[]'); ?>' method="post" action="<?php echo esc_url($p['path'] ?? '#'); ?>">
          <input type="hidden" name="productId" value="<?php echo esc_attr($p['id'] ?? ''); ?>">
          <input type="hidden" name="variantId" value="" data-variant-input>

          <div class="bk-pdp__stage" data-gallery>
            <?php if (count($gallery) > 1 && $opt('showGalleryThumbs')) : ?>
              <ul class="bk-pdp__thumbs" role="list">
                <?php foreach ($gallery as $i => $img) : ?>
                  <li><button type="button" class="bk-pdp__thumb<?php echo $i === 0 ? ' is-active' : ''; ?>" data-gallery-thumb="<?php echo esc_attr($img['url']); ?>" data-gallery-alt="<?php echo esc_attr($img['alt'] ?? ''); ?>" aria-label="<?php echo esc_attr(sprintf(bee_shop_t('Image %d'), $i + 1)); ?>"><?php echo bee_shop_img($img, '', 'lazy', '64px'); ?></button></li>
                <?php endforeach; ?>
              </ul>
            <?php endif; ?>
            <div class="bk-pdp__image">
              <?php echo bee_shop_img($gallery[0] ?? null, 'bk-product__img', 'eager', '(min-width: 1024px) 50vw, 100vw'); ?>
              <?php if (!empty($p['price']['onSale'])) : ?><span class="bk-badge bk-badge--sale"><?php echo esc_html(bee_shop_t('Sale')); ?></span><?php endif; ?>
            </div>

            <?php if ($isVariable && $variationAttrs) : ?>
              <div class="bk-pdp__options">
                <?php foreach ($variationAttrs as $attr) : $id = 'bk-attr-' . sanitize_title($attr['name']); ?>
                  <div class="bk-pdp__option">
                    <label for="<?php echo esc_attr($id); ?>" class="bk-pdp__option-label"><?php echo esc_html($attr['name']); ?></label>
                    <select id="<?php echo esc_attr($id); ?>" class="bk-visually-hidden" data-variation-attr="<?php echo esc_attr($attr['name']); ?>" required tabindex="-1">
                      <option value=""><?php echo esc_html(bee_shop_t('Choose an option')); ?></option>
                      <?php foreach ($attr['options'] as $o) : ?><option value="<?php echo esc_attr($o); ?>"><?php echo esc_html($o); ?></option><?php endforeach; ?>
                    </select>
                    <div class="bk-pdp__chips" role="group" aria-label="<?php echo esc_attr($attr['name']); ?>">
                      <?php foreach ($attr['options'] as $o) : $color = bee_shop_swatch($attr['name'], (string) $o); ?>
                        <button type="button" class="bk-pdp__chip<?php echo $color ? ' is-swatch' : ''; ?>" data-attr-chip="<?php echo esc_attr($attr['name']); ?>" data-value="<?php echo esc_attr($o); ?>" aria-pressed="false" title="<?php echo esc_attr($o); ?>"<?php echo $color ? ' style="--swatch: ' . esc_attr($color) . '"' : ''; ?>>
                          <?php if ($color) : ?><span class="bk-visually-hidden"><?php echo esc_html($o); ?></span><?php else : ?><?php echo esc_html($o); ?><?php endif; ?>
                        </button>
                      <?php endforeach; ?>
                    </div>
                  </div>
                <?php endforeach; ?>
                <button type="button" class="bk-pdp__reset" data-variation-reset hidden><?php echo esc_html(bee_shop_t('Clear')); ?></button>
              </div>
            <?php endif; ?>
          </div>

          <div class="bk-pdp__card">
            <div class="bk-pdp__head">
              <div class="bk-pdp__heading">
                <h1 class="bk-pdp__title"><?php echo esc_html($p['title'] ?? ''); ?></h1>
                <div class="bk-pdp__price" data-product-price><?php echo bee_price_html($p['price'] ?? null, 'bk-price'); ?></div>
                <div class="bk-pdp__variation" data-variation-info hidden>
                  <div data-variation-price></div>
                  <div data-variation-stock></div>
                </div>
                <div class="bk-pdp__stock" data-product-stock><?php echo bee_stock_html($p); ?></div>
              </div>
              <div class="bk-pdp__buy">
                <?php if (empty($p['soldIndividually'])) : ?>
                  <div class="bk-qty" data-qty>
                    <button type="button" class="bk-qty__btn" data-qty-dec aria-label="<?php echo esc_attr(bee_shop_t('Decrease quantity')); ?>">−</button>
                    <input type="number" name="qty" value="1" min="1" max="<?php echo (int) $maxQty; ?>" inputmode="numeric" aria-label="<?php echo esc_attr(bee_shop_t('Quantity')); ?>">
                    <button type="button" class="bk-qty__btn" data-qty-inc aria-label="<?php echo esc_attr(bee_shop_t('Increase quantity')); ?>">+</button>
                  </div>
                <?php else : ?>
                  <input type="hidden" name="qty" value="1">
                <?php endif; ?>
                <button type="submit" class="bk-btn bk-pdp__add" data-add-button <?php echo $canBuy ? '' : 'disabled'; ?>>
                  <?php echo bee_shop_icon('cart'); ?><span><?php echo esc_html($canBuy ? bee_shop_t('Add to cart') : bee_shop_t('Out of stock')); ?></span>
                </button>
              </div>
            </div>
            <p class="bk-add-form__msg" data-add-message role="status" aria-live="polite"></p>

            <?php if (!empty($p['shortDescription']) || !empty($p['description'])) : ?>
              <div class="bk-pdp__desc bk-prose">
                <?php if (!empty($p['shortDescription'])) echo wpautop(esc_html($p['shortDescription'])); ?>
                <?php if (!empty($p['description'])) echo bee_esc_html($p['description']); ?>
              </div>
            <?php endif; ?>

            <?php if ($hasInfo || ($opt('showMeta') && ((!empty($shop['show_sku']) && !empty($p['sku'])) || !empty($p['categories']) || !empty($p['tags'])))) : ?>
              <table class="bk-pdp__info">
                <tbody>
                  <?php if ($hasInfo) : ?>
                    <?php foreach ($visibleAttrs as $attr) : ?>
                      <tr><th scope="row"><?php echo esc_html($attr['name']); ?></th><td><?php echo esc_html(implode(', ', $attr['options'])); ?></td></tr>
                    <?php endforeach; ?>
                    <?php if (!empty($p['weight'])) : ?>
                      <tr><th scope="row"><?php echo esc_html(bee_shop_t('Weight')); ?></th><td><?php echo esc_html(rtrim(rtrim(number_format($p['weight'] / 1000, 3, '.', ''), '0'), '.')); ?> kg</td></tr>
                    <?php endif; ?>
                    <?php if ($hasDims) : ?>
                      <tr><th scope="row"><?php echo esc_html(bee_shop_t('Dimensions')); ?></th><td><?php echo esc_html(implode(' × ', array_map(fn($v) => rtrim(rtrim(number_format(((int) $v) / 10, 1, '.', ''), '0'), '.'), array_filter([$dims['length'] ?? 0, $dims['width'] ?? 0, $dims['height'] ?? 0])))); ?> cm</td></tr>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if ($opt('showMeta')) : ?>
                    <?php if (!empty($shop['show_sku']) && !empty($p['sku'])) : ?>
                      <tr><th scope="row"><?php echo esc_html(bee_shop_t('SKU')); ?></th><td data-product-sku><?php echo esc_html($p['sku']); ?></td></tr>
                    <?php endif; ?>
                    <?php if (!empty($p['categories'])) : ?>
                      <tr><th scope="row"><?php echo esc_html(bee_shop_t('Categories')); ?></th><td><?php foreach ($p['categories'] as $i => $c) : ?><?php echo $i ? ', ' : ''; ?><a href="<?php echo esc_url($c['path']); ?>"><?php echo esc_html($c['name']); ?></a><?php endforeach; ?></td></tr>
                    <?php endif; ?>
                    <?php if (!empty($p['tags'])) : ?>
                      <tr><th scope="row"><?php echo esc_html(bee_shop_t('Tags')); ?></th><td><?php echo esc_html(implode(', ', array_map(fn($t) => $t['name'], $p['tags']))); ?></td></tr>
                    <?php endif; ?>
                  <?php endif; ?>
                </tbody>
              </table>
            <?php endif; ?>
          </div>
        </form>
      </div>
    </div>

    <?php if ($related && $opt('showRelated')) : ?>
      <section class="bk-shop__related" aria-labelledby="bk-related-title">
        <h2 id="bk-related-title" class="bk-shop__section-title"><?php echo esc_html(bee_shop_t('Related products')); ?></h2>
        <ul class="bk-products bk-products--related">
          <?php foreach ($related as $product) bee_shop_partial('product-card', ['product' => $product]); ?>
        </ul>
      </section>
    <?php endif; ?>
  </div>
</article>
