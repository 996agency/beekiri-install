<?php
/**
 * Checkout. Data: checkout {cart, shippingOptions[], shippingRequired, paymentMethods[],
 * countries[], defaultCountry, fields {contact[], billing[], extra[], termsRequired},
 * termsPage, privacyPage} | null, cancelled, shop.options {showOrderSummaryImages}.
 *
 * Fields come from Shop → Settings → Checkout (labels, order, required, custom fields);
 * script.js re-quotes shipping when the address changes and places the order.
 */
$shop = get_bee_field('shop') ?: [];
$opts = $shop['options'] ?? [];
$checkout = get_bee_field('checkout');
$cart = is_array($checkout) ? ($checkout['cart'] ?? []) : [];
$items = $cart['items'] ?? [];
$fields = is_array($checkout) ? ($checkout['fields'] ?? []) : [];
$countries = is_array($checkout) ? ($checkout['countries'] ?? []) : [];
$defaultCountry = is_array($checkout) ? ($checkout['defaultCountry'] ?? '') : '';
$methods = is_array($checkout) ? ($checkout['paymentMethods'] ?? []) : [];
$terms = is_array($checkout) ? ($checkout['termsPage'] ?? null) : null;
$privacy = is_array($checkout) ? ($checkout['privacyPage'] ?? null) : null;
$cancelled = (bool) get_bee_field('cancelled');
$fmt = $cart['formatted'] ?? [];
$showImages = !isset($opts['showOrderSummaryImages']) || $opts['showOrderSummaryImages'];
$acct = is_array($checkout) ? ($checkout['account'] ?? []) : [];
$me = $acct['customer'] ?? null;
$accountPath = $shop['account_path'] ?? '/account';
/** Values filled in from the signed-in shopper's account. */
$prefill = [];
if (is_array($me)) {
  $prefill['email'] = $me['email'] ?? '';
  $prefill['phone'] = $me['phone'] ?: ($me['billing']['phone'] ?? '');
  foreach (($me['billing'] ?? []) as $k => $val) $prefill['billing.' . $k] = $val;
  $prefill['billing.firstName'] = ($me['billing']['firstName'] ?? '') ?: ($me['firstName'] ?? '');
  $prefill['billing.lastName'] = ($me['billing']['lastName'] ?? '') ?: ($me['lastName'] ?? '');
  if (!empty($me['billing']['country'])) $defaultCountry = $me['billing']['country'];
}

/** Input name for a field definition, optionally remapped to the shipping address. */
$nameFor = function (array $f, string $prefix = '') : string {
  $key = (string) $f['key'];
  if ($prefix !== '' && str_starts_with($key, 'billing.')) return $prefix . '.' . substr($key, 8);
  if (str_starts_with($key, 'custom.')) return 'extra.' . $key;
  return $key;
};

/** One form control from a field definition. */
$renderField = function (array $f, string $prefix = '') use ($countries, $defaultCountry, $nameFor, $prefill) {
  $value = $prefix === '' ? (string) ($prefill[$f['key']] ?? '') : '';
  $name = $nameFor($f, $prefix);
  $id = 'bk-f-' . preg_replace('/[^a-z0-9]+/i', '-', $name);
  $required = !empty($f['required']);
  $label = (string) ($f['label'] ?? $f['key']);
  $placeholder = (string) ($f['placeholder'] ?? '');
  $width = ($f['width'] ?? 'full') === 'half' ? ' is-half' : '';
  $mark = $required ? ' <span class="bk-req" aria-hidden="true">*</span>' : ' <span class="bk-opt">(' . esc_html(bee_shop_t('optional')) . ')</span>';
  $auto = [
    'email' => 'email', 'phone' => 'tel', 'billing.firstName' => 'given-name', 'billing.lastName' => 'family-name',
    'billing.company' => 'organization', 'billing.line1' => 'address-line1', 'billing.line2' => 'address-line2',
    'billing.city' => 'address-level2', 'billing.state' => 'address-level1', 'billing.postcode' => 'postal-code', 'billing.country' => 'country',
  ][$f['key']] ?? 'off';
  echo '<div class="bk-field' . $width . '">';
  if (($f['type'] ?? 'text') === 'checkbox') {
    echo '<label class="bk-check"><input type="checkbox" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="1"' . ($required ? ' required' : '') . '> <span>' . esc_html($label) . $mark . '</span></label>';
    echo '</div>';
    return;
  }
  echo '<label for="' . esc_attr($id) . '">' . esc_html($label) . $mark . '</label>';
  if ($f['key'] === 'billing.country') {
    echo '<select id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" required autocomplete="country">';
    echo '<option value="">' . esc_html(bee_shop_t('Select a country')) . '</option>';
    foreach ($countries as $c) {
      echo '<option value="' . esc_attr($c['code']) . '"' . ($c['code'] === $defaultCountry ? ' selected' : '') . '>' . esc_html($c['name']) . '</option>';
    }
    echo '</select>';
  } elseif (($f['type'] ?? '') === 'select') {
    echo '<select id="' . esc_attr($id) . '" name="' . esc_attr($name) . '"' . ($required ? ' required' : '') . '>';
    echo '<option value="">' . esc_html($placeholder !== '' ? $placeholder : bee_shop_t('Choose an option')) . '</option>';
    foreach ($f['options'] ?? [] as $o) echo '<option value="' . esc_attr($o) . '">' . esc_html($o) . '</option>';
    echo '</select>';
  } elseif (($f['type'] ?? '') === 'textarea') {
    echo '<textarea id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" rows="3" placeholder="' . esc_attr($placeholder) . '"' . ($required ? ' required' : '') . '>' . esc_textarea($value) . '</textarea>';
  } else {
    $type = in_array($f['type'] ?? 'text', ['email', 'tel', 'text'], true) ? $f['type'] : 'text';
    $mode = $type === 'email' ? ' inputmode="email"' : ($type === 'tel' ? ' inputmode="tel"' : '');
    echo '<input id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" type="' . esc_attr($type) . '" value="' . esc_attr($value) . '" placeholder="' . esc_attr($placeholder) . '" autocomplete="' . esc_attr($auto) . '"' . $mode . ($required ? ' required' : '') . '>';
  }
  echo '</div>';
};

$renderGroup = function (array $list, string $prefix = '') use ($renderField) {
  echo '<div class="bk-form-grid">';
  foreach ($list as $f) $renderField($f, $prefix);
  echo '</div>';
};
?>
<section class="bk-shop bk-shop--checkout" data-shop-view="checkout">
  <div class="bk-shop__wrap">
    <header class="bk-cart-head">
      <?php echo bee_shop_breadcrumbs([['label' => $shop['title'] ?? 'Shop', 'url' => $shop['path'] ?? '/shop'], ['label' => bee_shop_t('Shopping cart'), 'url' => $shop['cart_path'] ?? '/cart'], ['label' => bee_shop_t('Checkout'), 'url' => $shop['checkout_path'] ?? '/checkout']]); ?>
      <h1 class="bk-cart-head__title"><?php echo esc_html(bee_shop_t('Checkout')); ?></h1>
    </header>

    <?php if ($cancelled) : ?>
      <p class="bk-shop-notice is-info" role="status"><?php echo esc_html(bee_shop_t('Your payment was cancelled. Your cart is still here — try again when you are ready.')); ?></p>
    <?php endif; ?>

    <?php if (!$items) : ?>
      <div class="bk-shop__empty">
        <p><?php echo esc_html(bee_shop_t('Your cart is empty — there is nothing to check out yet.')); ?></p>
        <a class="bk-btn bk-btn--primary" href="<?php echo esc_url($shop['path'] ?? '/shop'); ?>"><?php echo esc_html(bee_shop_t('Return to shop')); ?></a>
      </div>
    <?php else : ?>
      <form class="bk-checkout" data-checkout-form novalidate>
        <div class="bk-checkout__details">
          <?php if (!empty($acct['enabled'])) : ?>
            <div class="bk-checkout__account">
              <?php if ($me) : ?>
                <span class="bk-checkout__avatar" aria-hidden="true"><?php echo esc_html(strtoupper(mb_substr(($me['firstName'] ?? '') ?: $me['email'], 0, 1))); ?></span>
                <span><?php echo esc_html(sprintf(bee_shop_t('Signed in as %s'), $me['email'])); ?> · <?php echo esc_html(bee_shop_t('your order will appear in My account.')); ?></span>
              <?php else : ?>
                <span class="bk-checkout__account-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg></span>
                <span><?php echo esc_html(bee_shop_t('Returning customer?')); ?> <a href="<?php echo esc_url($accountPath . '/login?redirect=/checkout'); ?>" data-bk-reload><?php echo esc_html(bee_shop_t('Sign in')); ?></a><?php echo !empty($acct['requireAccount']) ? ' — ' . esc_html(bee_shop_t('an account is needed to order.')) : ''; ?></span>
              <?php endif; ?>
            </div>
          <?php endif; ?>
          <?php if (!empty($fields['contact'])) : ?>
            <section class="bk-checkout__section" aria-labelledby="bk-contact-title">
              <h2 id="bk-contact-title"><?php echo esc_html(bee_shop_t('Contact')); ?></h2>
              <?php $renderGroup($fields['contact']); ?>
            </section>
          <?php endif; ?>

          <section class="bk-checkout__section" aria-labelledby="bk-billing-title">
            <h2 id="bk-billing-title"><?php echo esc_html(bee_shop_t('Billing details')); ?></h2>
            <?php $renderGroup($fields['billing'] ?? []); ?>
          </section>

          <?php if (!empty($checkout['shippingRequired'])) : ?>
            <section class="bk-checkout__section" aria-labelledby="bk-shipping-title">
              <h2 id="bk-shipping-title"><?php echo esc_html(bee_shop_t('Shipping')); ?></h2>
              <label class="bk-check"><input type="checkbox" name="shipToDifferent" data-ship-different> <span><?php echo esc_html(bee_shop_t('Ship to a different address?')); ?></span></label>
              <div class="bk-checkout__ship-fields" data-ship-fields hidden>
                <?php $renderGroup($fields['billing'] ?? [], 'shipping'); ?>
              </div>
            </section>
          <?php endif; ?>

          <?php if (!empty($acct['createAtCheckout'])) : ?>
            <section class="bk-checkout__section" aria-labelledby="bk-create-title">
              <h2 id="bk-create-title" class="bk-visually-hidden"><?php echo esc_html(bee_shop_t('Account')); ?></h2>
              <label class="bk-check"><input type="checkbox" name="createAccount" data-create-account<?php echo !empty($acct['requireAccount']) ? ' checked' : ''; ?>> <span><?php echo esc_html(bee_shop_t('Create an account to track this order')); ?></span></label>
              <div class="bk-field" data-create-account-fields<?php echo !empty($acct['requireAccount']) ? '' : ' hidden'; ?>>
                <label for="bk-acct-pass"><?php echo esc_html(bee_shop_t('Choose a password')); ?></label>
                <input id="bk-acct-pass" name="accountPassword" type="password" minlength="8" autocomplete="new-password">
              </div>
            </section>
          <?php endif; ?>

          <?php if (!empty($fields['extra'])) : ?>
            <section class="bk-checkout__section" aria-labelledby="bk-notes-title">
              <h2 id="bk-notes-title"><?php echo esc_html(bee_shop_t('Additional information')); ?></h2>
              <?php $renderGroup($fields['extra']); ?>
            </section>
          <?php endif; ?>
        </div>

        <aside class="bk-checkout__summary">
          <section class="bk-checkout__section" aria-labelledby="bk-review-title">
            <h2 id="bk-review-title"><?php echo esc_html(bee_shop_t('Your order')); ?></h2>
            <table class="bk-review">
              <tbody>
                <?php foreach ($items as $item) : ?>
                  <tr>
                    <td class="bk-review__item">
                      <?php if ($showImages) echo bee_shop_img(['url' => $item['imageUrl'] ?? '', 'alt' => ''], 'bk-review__img'); ?>
                      <div><strong><?php echo esc_html($item['name']); ?></strong> <span class="bk-review__qty">× <?php echo (int) $item['qty']; ?></span>
                        <?php if (!empty($item['attributes'])) : ?><small><?php echo esc_html(bee_shop_attrs_text($item['attributes'])); ?></small><?php endif; ?></div>
                    </td>
                    <td class="is-right"><?php echo esc_html($item['formatted']['total'] ?? ''); ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>

            <?php if (!empty($checkout['shippingRequired'])) : ?>
              <div class="bk-checkout__shipping" data-shipping-options>
                <h3><?php echo esc_html(bee_shop_t('Shipping method')); ?></h3>
                <p class="is-muted" data-shipping-placeholder><?php echo esc_html(bee_shop_t('Enter your address to see shipping options.')); ?></p>
                <ul class="bk-options" data-shipping-list data-preferred="<?php echo esc_attr($checkout['preferredShippingMethodId'] ?? ''); ?>" hidden></ul>
              </div>
            <?php endif; ?>

            <table class="bk-totals" data-checkout-totals>
              <tbody>
                <tr data-total="subtotal"><th scope="row"><?php echo esc_html(bee_shop_t('Subtotal')); ?></th><td><?php echo esc_html($fmt['subtotal'] ?? ''); ?></td></tr>
                <tr data-total="discount" class="is-discount" <?php echo empty($cart['coupon']) ? 'hidden' : ''; ?>><th scope="row"><?php echo esc_html(bee_shop_t('Discount')); ?></th><td>−<?php echo esc_html($cart['coupon']['formatted'] ?? ''); ?></td></tr>
                <tr data-total="shipping" <?php echo empty($checkout['shippingRequired']) ? 'hidden' : ''; ?>><th scope="row"><?php echo esc_html(bee_shop_t('Shipping')); ?></th><td class="is-muted">—</td></tr>
                <tr data-total="tax" <?php echo empty($cart['taxTotal']) ? 'hidden' : ''; ?>><th scope="row"><?php echo esc_html(!empty($cart['pricesIncludeTax']) ? bee_shop_t('Includes tax') : bee_shop_t('Tax')); ?></th><td><?php echo esc_html($fmt['taxTotal'] ?? ''); ?></td></tr>
                <tr data-total="total" class="is-total"><th scope="row"><?php echo esc_html(bee_shop_t('Total')); ?></th><td><?php echo esc_html($fmt['total'] ?? ''); ?></td></tr>
              </tbody>
            </table>
          </section>

          <section class="bk-checkout__section" aria-labelledby="bk-payment-title">
            <h2 id="bk-payment-title"><?php echo esc_html(bee_shop_t('Payment')); ?></h2>
            <?php if (!$methods) : ?>
              <p class="bk-shop-notice is-error"><?php echo esc_html(bee_shop_t('No payment methods are available right now. Please contact us.')); ?></p>
            <?php else : ?>
              <ul class="bk-options bk-options--payment">
                <?php foreach ($methods as $i => $m) : ?>
                  <li>
                    <label class="bk-option">
                      <input type="radio" name="paymentMethod" value="<?php echo esc_attr($m['id']); ?>" <?php echo $i === 0 ? 'checked' : ''; ?> required>
                      <span class="bk-option__body">
                        <span class="bk-option__title"><?php echo esc_html($m['title']); ?><?php if ($m['id'] === 'stripe') echo ' ' . bee_shop_icon('lock'); ?></span>
                        <?php if (!empty($m['description'])) : ?><span class="bk-option__desc"><?php echo esc_html($m['description']); ?></span><?php endif; ?>
                      </span>
                    </label>
                  </li>
                <?php endforeach; ?>
              </ul>
            <?php endif; ?>

            <?php if ($privacy) : ?>
              <p class="bk-checkout__privacy"><?php echo esc_html(bee_shop_t('Your personal data will be used to process your order and support your experience, as described in our')); ?> <a href="<?php echo esc_url($privacy['path']); ?>" target="_blank" rel="noopener"><?php echo esc_html($privacy['title']); ?></a>.</p>
            <?php endif; ?>
            <?php if ($terms) : ?>
              <label class="bk-check bk-checkout__terms"><input type="checkbox" name="termsAccepted" <?php echo !empty($fields['termsRequired']) ? 'required' : ''; ?>> <span><?php echo esc_html(bee_shop_t('I have read and agree to the')); ?> <a href="<?php echo esc_url($terms['path']); ?>" target="_blank" rel="noopener"><?php echo esc_html($terms['title']); ?></a><?php if (!empty($fields['termsRequired'])) : ?> <span class="bk-req" aria-hidden="true">*</span><?php endif; ?></span></label>
            <?php endif; ?>

            <p class="bk-checkout__error" data-checkout-error role="alert" hidden></p>
            <button type="submit" class="bk-btn bk-btn--lg bk-btn--block bk-checkout__place" data-place-order <?php echo $methods ? '' : 'disabled'; ?>>
              <?php echo bee_shop_icon('lock'); ?>
              <span data-place-label><?php echo esc_html(bee_shop_t('Place order')); ?></span>
              <span class="bk-checkout__total" data-place-total><?php echo esc_html($fmt['total'] ?? ''); ?></span>
            </button>
            <p class="bk-checkout__secure"><?php echo esc_html(bee_shop_t('Secure, encrypted checkout. Your payment details are never stored on this site.')); ?></p>
          </section>
          <a class="bk-cart2__continue bk-checkout__back" href="<?php echo esc_url($shop['cart_path'] ?? '/cart'); ?>">← <?php echo esc_html(bee_shop_t('Back to cart')); ?></a>
        </aside>
      </form>
    <?php endif; ?>
  </div>
</section>
