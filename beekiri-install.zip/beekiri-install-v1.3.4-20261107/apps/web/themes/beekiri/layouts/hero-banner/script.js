/* @beekiri-managed — remove this line to keep your custom file */
/*
 * Hero Banner Layout
 * Served at /api/layouts/hero-banner/js — edit + save + refresh (no gulp for JS).
 * Gulp only compiles styles.scss → styles.css.
 * Pages change without a full reload, so init runs after paint and on `bk:navigate`
 * (avoid mutating DOM before React hydrates).
 */
(function () {
  function init() {
    document
      .querySelectorAll('[data-layout="hero-banner"]:not([data-bk-ready])')
      .forEach(function (root) {
        root.setAttribute('data-bk-ready', '');
        // hero-banner
      });
  }
  function boot() {
    init();
    window.addEventListener('bk:navigate', init);
  }
  // Defer past first paint / React hydrate so we don't trip hydration mismatches.
  if (typeof requestIdleCallback === 'function') {
    requestIdleCallback(boot, { timeout: 400 });
  } else {
    setTimeout(boot, 0);
  }
})();
