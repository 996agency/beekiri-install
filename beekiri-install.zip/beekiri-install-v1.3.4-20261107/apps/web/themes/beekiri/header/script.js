/**
 * Beekiri theme header — behaviour for the PHP frontend (header.php).
 * Mobile menu and active-link state (the search dialog is runtime/site-nav.js + bee_search_modal()).
 * Uses document-level delegation so it keeps working across client-side
 * navigations (the site dispatches `bk:navigate` after each route change).
 */
(function () {
  if (window.__bkThemeHeader) return;
  window.__bkThemeHeader = true;

  var $ = function (sel) {
    return document.querySelector(sel);
  };

  function normalizePath(p) {
    if (!p) return '/';
    var clean = p.split('#')[0].split('?')[0] || '/';
    return clean.length > 1 ? clean.replace(/\/+$/, '') : clean;
  }

  function setMenu(open) {
    var menu = $('[data-bk-menu]');
    var toggle = $('[data-bk-menu-toggle]');
    if (!menu || !toggle) return;
    menu.hidden = !open;
    toggle.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  }


  function markActive() {
    var here = normalizePath(window.location.pathname);
    document.querySelectorAll('.bk-nav__links a, .bk-nav__mobile a').forEach(function (a) {
      var href = a.getAttribute('href') || '';
      if (href.charAt(0) !== '/' || href.indexOf('#') !== -1) {
        a.removeAttribute('aria-current');
        return;
      }
      if (normalizePath(href) === here) a.setAttribute('aria-current', 'page');
      else a.removeAttribute('aria-current');
    });
  }

  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!(t instanceof Element)) return;

    if (t.closest('[data-bk-menu-toggle]')) {
      var menu = $('[data-bk-menu]');
      setMenu(!!menu && menu.hidden);
      return;
    }
    if (t.closest('[data-bk-menu] a')) setMenu(false);
  });



  document.addEventListener('keydown', function (e) {
    var t = e.target;
    if (e.key === 'Escape') setMenu(false);
  });

  window.addEventListener('bk:navigate', function () {
    setMenu(false);
    markActive();
  });
  window.addEventListener('popstate', markActive);

  // After paint / hydrate — avoid mutating the PHP header before React hydrates.
  function scheduleMark() {
    if (typeof requestAnimationFrame === 'function') {
      requestAnimationFrame(function () {
        setTimeout(markActive, 0);
      });
    } else {
      setTimeout(markActive, 0);
    }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scheduleMark);
  } else {
    scheduleMark();
  }
})();
