/**
 * Dynamic content for BeekiriCode pages.
 *
 * A box (section / container) can repeat its first child for every item of a source — shop
 * products, journal posts or the rows of a Backend Fields repeater. Elements inside that card
 * bind their text, link, photo or background to a field of the current item, so a "Collection"
 * grid shows live products without anyone typing prices or links.
 *
 * The page tree stores only the query (`loop`) and the bindings (`bind`); the API turns the query
 * into flat items (`LoopItem`) when the page is rendered or previewed.
 */

export type LoopSource = 'products' | 'posts' | 'fields';

export type LoopConfig = {
  source: LoopSource;
  /** How many items at most (1–60). */
  limit?: number;
  /** products: menu_order | newest | title | price | price-desc | popularity · posts: newest | oldest | title */
  sort?: string;
  /** products: category slug. */
  category?: string;
  /** products: only those marked featured. */
  featured?: boolean;
  /** products: hand-picked product ids, shown in this order (other filters are ignored). */
  ids?: string[];
  /** fields: the Backend Fields layout (field group) and its repeater field. */
  layout?: string;
  repeater?: string;
  /** fields: the repeater rows (raw field values, edited in Props). */
  rows?: Record<string, unknown>[];
};

/** Which element property a binding fills. `bg` = background photo of a box. */
export type BindProp = 'text' | 'href' | 'src' | 'alt' | 'bg';
export type Bindings = Partial<Record<BindProp, string>>;

/** One repeated item: flat text values keyed by field. Reserved keys: `id`, `addToCartId`. */
export type LoopItem = Record<string, string>;

export type BindKind = 'text' | 'url' | 'image';
export type BindField = { key: string; label: string; kind: BindKind; hint?: string };

/** The fields each built-in source offers (Backend Fields repeaters list their sub-fields). */
export const LOOP_FIELDS: Record<'products' | 'posts', BindField[]> = {
  products: [
    { key: 'title', label: 'Product name', kind: 'text' },
    { key: 'price', label: 'Price', kind: 'text', hint: 'The sale price while on sale' },
    { key: 'regularPrice', label: 'Regular price', kind: 'text', hint: 'Only while on sale, for a strike-through' },
    { key: 'shortDescription', label: 'Short description', kind: 'text' },
    { key: 'category', label: 'Category', kind: 'text' },
    { key: 'sku', label: 'SKU', kind: 'text' },
    { key: 'stock', label: 'Stock status', kind: 'text', hint: '“In stock” or “Out of stock”' },
    { key: 'url', label: 'Product page', kind: 'url' },
    { key: 'addToCart', label: 'Add to cart', kind: 'url', hint: 'Adds the product to the cart; products with options open their page' },
    { key: 'categoryUrl', label: 'Category page', kind: 'url' },
    { key: 'image', label: 'Product photo', kind: 'image' },
  ],
  posts: [
    { key: 'title', label: 'Title', kind: 'text' },
    { key: 'excerpt', label: 'Excerpt', kind: 'text' },
    { key: 'date', label: 'Date', kind: 'text' },
    { key: 'author', label: 'Author', kind: 'text' },
    { key: 'readingTime', label: 'Reading time', kind: 'text', hint: '“4 min read”' },
    { key: 'url', label: 'Story page', kind: 'url' },
    { key: 'image', label: 'Featured photo', kind: 'image' },
  ],
};

export const LOOP_SOURCE_LABEL: Record<LoopSource, string> = {
  products: 'Shop products',
  posts: 'Journal posts',
  fields: 'Backend Fields',
};

export const LOOP_LIMIT_MAX = 60;
export const LOOP_LIMIT_DEFAULT = 6;

type Bindable = {
  text?: string;
  href?: string;
  src?: string;
  alt?: string;
  style?: Record<string, string>;
  bind?: Bindings;
};

/** The upload path of a media URL (`/uploads/2026/11/x.webp` → `2026/11/x.webp`), or null. */
export function uploadPath(url: string): string | null {
  const m = url.match(/^\/uploads\/(?!_w\d+\/)(.+)$/);
  return m ? m[1] : null;
}

/**
 * The node with the item's values in place of its bound properties. Unbound properties keep
 * what was typed; a bound property with no value becomes empty (not the placeholder text).
 * The background photo lands in `style.backgroundImage` so both the canvas and the published
 * page paint it.
 */
export function applyBindings<T extends Bindable>(node: T, item: LoopItem): T {
  const bind = node.bind;
  if (!bind) return node;
  const next: T = { ...node };
  const value = (key: string | undefined) => (key ? (item[key] ?? '') : undefined);
  if (bind.text !== undefined) next.text = value(bind.text);
  if (bind.href !== undefined) next.href = value(bind.href) || '#';
  if (bind.src !== undefined) next.src = value(bind.src);
  if (bind.alt !== undefined) next.alt = value(bind.alt);
  else if (bind.src !== undefined && item.imageAlt !== undefined) next.alt = item.imageAlt;
  if (bind.bg !== undefined) {
    const url = value(bind.bg);
    next.style = { ...(node.style ?? {}), backgroundImage: url ? `url("${url}")` : 'none' };
    // The photo is published as a real <img>: give it the item's own description.
    if (bind.alt === undefined && item.imageAlt !== undefined) next.alt = item.imageAlt;
  }
  return next;
}

/** Every binding on the node that still has a field name. */
export function hasBindings(node: { bind?: Bindings } | undefined): boolean {
  return Boolean(node?.bind && Object.values(node.bind).some((v) => typeof v === 'string' && v));
}
