import { API_URL as API } from './env';
import { apiFetch } from './api';

/**
 * Every media-library photo on a page, whoever wrote the markup (a theme layout, the editor, a
 * header/footer, a blog template, Beekiri): gets its real width/height (no layout shift while it
 * loads) and, when it has none, responsive copies (/uploads/_w{width}/…) so phones download the
 * size they show. Done on the server, so visitors run no extra script.
 */

/** Copies the server makes of a photo (api/src/lib/media/media-variant.ts). */
const WIDTHS = [320, 480, 640, 750, 828, 1290, 1600];
const IMG = /<img\b[^>]*>/gi;
/** Same-site photo address: /uploads/… (or absolute on any host), not already a resized copy. */
const UPLOAD = /^(?:https?:\/\/[^/"]+)?(\/uploads\/(?!_w\d)[^"?#]+\.(?:jpe?g|png|webp))(?:[?#][^"]*)?$/i;

const attr = (tag: string, name: string) => tag.match(new RegExp(`\\s${name}\\s*=\\s*"([^"]*)"`, 'i'))?.[1];

async function sizesOf(paths: string[]): Promise<Record<string, [number, number]>> {
  try {
    const res = await apiFetch(`${API}/api/dynamic/image-sizes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ urls: paths.slice(0, 300) }),
      cache: 'no-store',
    });
    if (!res.ok) return {};
    return ((await res.json()) as { sizes?: Record<string, [number, number]> }).sizes ?? {};
  } catch {
    return {};
  }
}

export async function withImageSizes(html: string): Promise<string> {
  if (!html || !html.includes('/uploads/')) return html;
  const tags = html.match(IMG) ?? [];
  const pathOf = (tag: string) => {
    const src = attr(tag, 'src');
    return src ? (UPLOAD.exec(src)?.[1] ?? null) : null;
  };
  const paths = [...new Set(tags.map(pathOf).filter((p): p is string => Boolean(p)))];
  if (!paths.length) return html;
  const sizes = await sizesOf(paths);

  return html.replace(IMG, (tag) => {
    const path = pathOf(tag);
    const size = path ? sizes[path] : undefined;
    if (!path || !size) return tag;
    const [width, height] = size;
    let extra = '';
    if (!attr(tag, 'width') && !attr(tag, 'height')) extra += ` width="${width}" height="${height}"`;
    if (!attr(tag, 'srcset')) {
      const set = WIDTHS.filter((w) => w < width).map((w) => `/uploads/_w${w}${path.slice('/uploads'.length)} ${w}w`);
      if (set.length) {
        const lazy = /\sloading\s*=\s*"lazy"/i.test(tag);
        // Lazy photos: the browser picks by the size the photo really shows at.
        extra += ` srcset="${[...set, `${path} ${width}w`].join(', ')}"${attr(tag, 'sizes') ? '' : ` sizes="${lazy ? 'auto, ' : ''}100vw"`}`;
      }
    }
    return extra ? tag.replace(/\s*\/?>$/, (end) => `${extra}${end}`) : tag;
  });
}
