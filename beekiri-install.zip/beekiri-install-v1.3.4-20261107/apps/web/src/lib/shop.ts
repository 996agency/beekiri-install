import type { Metadata } from 'next';
import { cookies } from 'next/headers';
import { API_URL as API } from '@/lib/env';
import { buildMetadata, type SeoSite } from './seo';
import { apiFetch } from './api';

/** Mirrors apps/api/src/services/shop/storefront-render.service.ts `RenderedView`. */
export type ShopViewData = {
  view: 'shop' | 'category' | 'product' | 'cart' | 'checkout' | 'order-received' | 'account';
  html: string;
  title: string;
  description: string;
  image: string;
  noindex: boolean;
  path: string;
  status: number;
  cssUrl: string;
  jsUrl: string;
  structured?: {
    name: string;
    sku: string;
    description: string;
    image: string;
    currency: string;
    price: number | null;
    priceDecimal: string;
    inStock: boolean;
  } | null;
};

export type ShopConfig = {
  active: boolean;
  cssUrl: string;
  jsUrl: string;
  paths: { shop: string; cart: string; checkout: string };
  shopTitle: string;
};

const CART_COOKIE = 'beekiri_cart';
const CUSTOMER_COOKIE = 'beekiri_customer';

/** null when the extension is inactive (404) or the API is unreachable. */
export async function shopConfig(): Promise<ShopConfig | null> {
  try {
    const res = await apiFetch(`${API}/api/shop/public/config`, { next: { revalidate: 30 } });
    if (!res.ok) return null;
    const data = (await res.json()) as ShopConfig;
    return data.active ? data : null;
  } catch {
    return null;
  }
}

/**
 * A storefront page rendered by the theme's PHP templates.
 * `withCart` forwards the shopper's cart cookie and disables caching (cart, checkout, order).
 */
export async function fetchShopView(
  view: ShopViewData['view'],
  params: Record<string, string | string[] | undefined> = {},
  opts: { withCart?: boolean } = {},
): Promise<ShopViewData | null> {
  const qs = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    const v = Array.isArray(value) ? value[0] : value;
    if (v !== undefined && v !== '') qs.set(key, v);
  }
  const headers: Record<string, string> = { Accept: 'application/json' };
  let init: RequestInit & { next?: { revalidate: number } } = { headers, next: { revalidate: 30 } };
  if (opts.withCart) {
    // Per-visitor pages forward the cart and the signed-in shopper (never cached).
    const jar = await cookies();
    // The admin session too: staff are signed in to the shop with the same login.
    const parts = [CART_COOKIE, CUSTOMER_COOKIE, 'beekiri_session', '__Host-beekiri_session']
      .map((name) => [name, jar.get(name)?.value] as const)
      .filter((pair): pair is readonly [string, string] => Boolean(pair[1] && /^[A-Za-z0-9_-]+$/.test(pair[1])))
      .map(([name, value]) => `${name}=${value}`);
    if (parts.length) headers.Cookie = parts.join('; ');
    init = { headers, cache: 'no-store' };
  }
  try {
    const url = `${API}/api/shop/public/view/${view}${qs.size ? `?${qs}` : ''}`;
    const res = await apiFetch(url, init);
    if (!res.ok) return null;
    return (await res.json()) as ShopViewData;
  } catch {
    return null;
  }
}

export function shopMetadata(data: ShopViewData | null, site: SeoSite | null, fallbackTitle: string): Metadata {
  if (!data) return { title: fallbackTitle, robots: { index: false, follow: false } };
  return buildMetadata(
    {
      title: data.title,
      path: data.path,
      excerpt: data.description,
      seo: {
        metaTitle: data.title,
        metaDescription: data.description,
        robotsIndex: !data.noindex,
        robotsFollow: true,
        excludeFromSitemap: data.noindex,
        ogImageUrl: data.image,
        featuredImageUrl: data.image,
      },
    },
    site,
  );
}

export async function siteMeta(): Promise<SeoSite | null> {
  try {
    const res = await apiFetch(`${API}/api/site/public`, { next: { revalidate: 30 } });
    if (!res.ok) return null;
    const data = (await res.json()) as { title?: string; tagline?: string; url?: string };
    return { title: (data.title ?? '').trim() || 'Beekiri', tagline: data.tagline, url: data.url };
  } catch {
    return null;
  }
}

/** schema.org Product for the single product page. */
export function productJsonLd(data: ShopViewData, siteUrl: string): Record<string, unknown> | null {
  const s = data.structured;
  if (!s) return null;
  const abs = (u: string) => (u && !/^https?:\/\//.test(u) ? `${siteUrl}${u}` : u);
  return {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: s.name,
    ...(s.sku ? { sku: s.sku } : {}),
    ...(s.description ? { description: s.description } : {}),
    ...(s.image ? { image: [abs(s.image)] } : {}),
    url: `${siteUrl}${data.path}`,
    ...(s.price !== null
      ? {
          offers: {
            '@type': 'Offer',
            priceCurrency: s.currency,
            price: s.priceDecimal,
            availability: s.inStock ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
            url: `${siteUrl}${data.path}`,
          },
        }
      : {}),
  };
}
