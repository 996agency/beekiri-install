import { API_URL as API } from './env';
import { apiFetch } from './api';

/** The active theme's blog design (blog/archive.php, blog/single.php), when it has one. */
export type BlogView = {
  template: boolean;
  html?: string;
  title?: string;
  description?: string;
  image?: string;
  /** Single post: where the post body goes in `html`. */
  marker?: string;
};

export async function blogView(view: 'archive' | 'single', query: Record<string, string | number | undefined>): Promise<BlogView | null> {
  try {
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) if (v !== undefined && v !== '') qs.set(k, String(v));
    const res = await apiFetch(`${API}/api/posts/public/view/${view}${qs.size ? `?${qs}` : ''}`, { next: { revalidate: 30 } });
    if (!res.ok) return null;
    const data = (await res.json()) as BlogView;
    return data.template && data.html ? data : null;
  } catch {
    return null;
  }
}
