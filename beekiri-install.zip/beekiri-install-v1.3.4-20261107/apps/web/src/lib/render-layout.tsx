import { createElement, type ComponentType, type ReactElement } from 'react';
import { createRequire } from 'node:module';

import { API_URL as API } from '@/lib/env';
import { apiFetch } from './api';

// App Router forbids static `react-dom/server` imports in the RSC graph.
// Node require keeps renderToStaticMarkup available for HTML (editor + fallback).
const nodeRequire = createRequire(import.meta.url);

function toStaticMarkup(element: ReactElement): string {
  const mod = nodeRequire('react-dom/server') as typeof import('react-dom/server');
  return mod.renderToStaticMarkup(element);
}

export type FrontendRuntime = 'php' | 'react';

type SitePublicRuntime = {
  frontendRuntime?: string;
  theme?: string;
};

export async function getPublicRuntime(): Promise<{
  runtime: FrontendRuntime;
  theme: string;
}> {
  try {
    const res = await apiFetch(`${API.replace(/\/$/, '')}/api/site/public`, {
      cache: 'no-store',
    });
    if (!res.ok) return { runtime: 'php', theme: 'beekiri-child' };
    const data = (await res.json()) as SitePublicRuntime;
    return {
      runtime: data.frontendRuntime === 'react' ? 'react' : 'php',
      theme: (data.theme || 'beekiri-child').trim() || 'beekiri-child',
    };
  } catch {
    return { runtime: 'php', theme: 'beekiri-child' };
  }
}

async function formatLayoutFields(
  slug: string,
  fields: Record<string, unknown>,
): Promise<Record<string, unknown>> {
  try {
    const res = await apiFetch(
      `${API.replace(/\/$/, '')}/api/layouts/${encodeURIComponent(slug)}/fields`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fields }),
        cache: 'no-store',
      },
    );
    if (!res.ok) return fields;
    const data = (await res.json()) as { fields?: Record<string, unknown> };
    return data.fields && typeof data.fields === 'object' ? data.fields : fields;
  } catch {
    return fields;
  }
}

const THEME_FALLBACKS: Record<string, string> = {
  'beekiri-child': 'beekiri',
};

export async function loadLayoutComponent(
  theme: string,
  slug: string,
): Promise<ComponentType<Record<string, unknown>> | null> {
  // A store theme's own layouts (made in Backend Fields) live in its child folder.
  const child = theme.endsWith('-child') || THEME_FALLBACKS[`${theme}-child`] ? null : `${theme}-child`;
  const candidates = [child, theme, THEME_FALLBACKS[theme]].filter(
    (value, index, all): value is string => Boolean(value) && all.indexOf(value) === index,
  );
  for (const slugTheme of candidates) {
    try {
      const mod = (await import(
        /* webpackMode: "lazy" */
        `../../themes/${slugTheme}/layouts/${slug}/${slug}.tsx`
      )) as { default?: ComponentType<Record<string, unknown>> };
      if (mod.default) return mod.default;
    } catch {
      // try the parent theme
    }
  }
  console.error(`[beekiri] Failed to load React layout ${theme}/${slug}`);
  return null;
}

/** Render themes/.../layouts/{slug}/{slug}.tsx to an HTML string. */
export async function renderLayoutReact(
  slug: string,
  fields: Record<string, unknown>,
  theme = 'beekiri-child',
): Promise<string | null> {
  const Comp = await loadLayoutComponent(theme, slug);
  if (!Comp) return null;
  const props = await formatLayoutFields(slug, fields);
  try {
    return toStaticMarkup(createElement(Comp, props));
  } catch (e) {
    console.error(`[beekiri] React layout render failed for ${slug}:`, e);
    return null;
  }
}

/** Load + format props for rendering a layout as a Server Component. */
export async function resolveLayoutReactElement(
  slug: string,
  fields: Record<string, unknown>,
  theme = 'beekiri-child',
): Promise<ReactElement | null> {
  const Comp = await loadLayoutComponent(theme, slug);
  if (!Comp) return null;
  const props = await formatLayoutFields(slug, fields);
  return createElement(Comp, props);
}

export async function renderLayoutPhp(
  slug: string,
  fields: Record<string, unknown>,
): Promise<string | null> {
  try {
    const res = await apiFetch(
      `${API.replace(/\/$/, '')}/api/layouts/${encodeURIComponent(slug)}/render`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fields, runtime: 'php' }),
        cache: 'no-store',
      },
    );
    if (!res.ok) return null;
    const data = (await res.json()) as { html?: string };
    return typeof data.html === 'string' ? data.html : null;
  } catch {
    return null;
  }
}

/**
 * Public-site layout renderer — honors Settings → frontend runtime.
 * Nest calls this via the Next route when runtime is react (editor preview).
 */
export async function renderLayout(
  slug: string,
  fields: Record<string, unknown>,
): Promise<string | null> {
  const { runtime, theme } = await getPublicRuntime();
  if (runtime === 'react') {
    const html = await renderLayoutReact(slug, fields, theme);
    if (html && html.trim()) return html;
  }
  return renderLayoutPhp(slug, fields);
}
