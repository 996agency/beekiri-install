import { API_URL as API } from '@/lib/env';
import { apiFetch } from './api';

/**
 * Bee Forms when its extension is active (the root layout then loads bee-forms.js and the
 * stylesheet, at its versioned address), else null.
 */
export async function formsConfig(): Promise<{ cssUrl: string } | null> {
  try {
    const res = await apiFetch(`${API}/api/forms/public/config`, { next: { revalidate: 30 } });
    if (!res.ok) return null;
    const data = (await res.json()) as { active?: boolean; cssUrl?: string };
    return data.active === true ? { cssUrl: data.cssUrl || '/api/forms/public/assets/form.css' } : null;
  } catch {
    return null;
  }
}

/** Server-rendered HTML of a form for the page renderer; '' when missing or inactive. */
export async function renderFormHtml(formId: string): Promise<string> {
  try {
    const res = await apiFetch(`${API}/api/forms/public/${encodeURIComponent(formId)}/html`, { cache: 'no-store' });
    if (!res.ok) return '';
    const data = (await res.json()) as { html?: string };
    return data.html ?? '';
  } catch {
    return '';
  }
}
