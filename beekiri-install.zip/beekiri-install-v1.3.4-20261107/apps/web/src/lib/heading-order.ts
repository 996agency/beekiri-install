/**
 * Headings must not skip a level (h1 → h3) for screen readers and search engines. Designs often
 * pick a heading tag for its look, so the tag stays (same styling) and a skipped level gets
 * `aria-level` with the level it really has in the page outline.
 */
const HEADING = /<h([1-6])\b([^>]*)>/gi;

export function fixHeadingOrder(html: string): string {
  if (!html) return html;
  // The open outline: each written level with the level it really has.
  const open: { written: number; level: number }[] = [];
  return html.replace(HEADING, (tag, digit: string, attrs: string) => {
    const written = Number(digit);
    while (open.length && open[open.length - 1].written >= written) open.pop();
    const set = /\saria-level\s*=\s*"(\d)"/i.exec(attrs);
    const parent = open[open.length - 1];
    // Before the first heading there is nothing to skip from; siblings keep the same level.
    const level = set ? Number(set[1]) : parent ? Math.min(written, parent.level + 1) : written;
    open.push({ written, level });
    return set || level === written ? tag : `<h${digit}${attrs} aria-level="${level}">`;
  });
}
