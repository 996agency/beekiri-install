import { createElement, type CSSProperties, type ReactNode } from 'react';

type AttrMap = Record<string, string | boolean | undefined>;

const HEAD_TAGS = new Set(['meta', 'link', 'script', 'style', 'noscript', 'base']);
const VOID_TAGS = new Set(['meta', 'link', 'base']);

const CONTENTS: CSSProperties = { display: 'contents' };

function reactAttrName(name: string): string {
  const lower = name.toLowerCase();
  if (lower === 'class') return 'className';
  if (lower === 'for') return 'htmlFor';
  if (lower === 'charset') return 'charSet';
  if (lower === 'httpequiv' || lower === 'http-equiv') return 'httpEquiv';
  if (lower === 'crossorigin') return 'crossOrigin';
  if (lower === 'fetchpriority') return 'fetchPriority';
  if (lower === 'referrerpolicy') return 'referrerPolicy';
  if (lower.startsWith('data-') || lower.startsWith('aria-')) return lower;
  // Keep camelCase for known boolean-ish script attrs
  if (lower === 'async' || lower === 'defer' || lower === 'nomodule') return lower;
  return lower;
}

function parseAttrs(raw: string | undefined): AttrMap {
  if (!raw) return {};
  const attrs: AttrMap = {};
  const re = /([^\s=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(raw))) {
    const name = m[1];
    if (!name || name === '/') continue;
    const key = reactAttrName(name);
    const value = m[2] ?? m[3] ?? m[4];
    attrs[key] = value === undefined ? true : value;
  }
  return attrs;
}

type Piece =
  | { kind: 'element'; tag: string; attrs: AttrMap; children?: string }
  | { kind: 'html'; html: string };

/**
 * Split a trusted admin HTML snippet into React-renderable pieces.
 * Scripts/styles keep their own tags so they execute / apply; other markup
 * is rendered via dangerouslySetInnerHTML.
 */
function splitHtml(html: string, headOnly: boolean): Piece[] {
  let cleaned = html.replace(/\u0000/g, '');
  if (headOnly) {
    const inner = cleaned.match(/<head\b[^>]*>([\s\S]*?)<\/head>/i);
    if (inner) cleaned = inner[1];
    // Next/Beekiri own these — strip if pasted so we don't emit duplicates.
    cleaned = cleaned
      .replace(/<meta\b[^>]*\bcharset\b[^>]*>/gi, '')
      .replace(/<meta\b[^>]*http-equiv=["']?content-type["']?[^>]*>/gi, '')
      .replace(/<meta\b[^>]*name=["']viewport["'][^>]*>/gi, '')
      .replace(/<title\b[^>]*>[\s\S]*?<\/title>/gi, '');
  }
  cleaned = cleaned.replace(/<\/?(?:html|head|body)\b[^>]*>/gi, '').trim();
  if (!cleaned) return [];

  const pieces: Piece[] = [];
  const tagRe =
    /<(script|style|noscript|meta|link|base)(\s[^>]*)?\s*(?:\/>|>([\s\S]*?)<\/\1\s*>|>)/gi;
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = tagRe.exec(cleaned))) {
    if (m.index > last) {
      const between = cleaned.slice(last, m.index).trim();
      if (between && !headOnly) pieces.push({ kind: 'html', html: between });
    }
    const tag = m[1].toLowerCase();
    if (headOnly && !HEAD_TAGS.has(tag)) {
      last = m.index + m[0].length;
      continue;
    }
    const attrs = parseAttrs(m[2]);
    if (VOID_TAGS.has(tag) || m[0].endsWith('/>') || m[3] === undefined) {
      pieces.push({ kind: 'element', tag, attrs });
    } else {
      pieces.push({ kind: 'element', tag, attrs, children: m[3] });
    }
    last = m.index + m[0].length;
  }
  if (last < cleaned.length) {
    const rest = cleaned.slice(last).trim();
    if (rest && !headOnly) pieces.push({ kind: 'html', html: rest });
  }
  return pieces;
}

function renderPieces(pieces: Piece[], keyPrefix: string): ReactNode[] {
  return pieces.map((piece, i) => {
    const key = `${keyPrefix}-${i}`;
    if (piece.kind === 'html') {
      return (
        <div
          key={key}
          style={CONTENTS}
          suppressHydrationWarning
          dangerouslySetInnerHTML={{ __html: piece.html }}
        />
      );
    }
    const { tag, attrs, children } = piece;
    if (children !== undefined) {
      return createElement(tag, {
        key,
        ...attrs,
        suppressHydrationWarning: true,
        dangerouslySetInnerHTML: { __html: children },
      });
    }
    return createElement(tag, { key, ...attrs, suppressHydrationWarning: true });
  });
}

/** SSR-safe `<head>` injection — metas/links/scripts land in the first HTML response. */
export function SiteCodeHead({ html }: { html: string }) {
  if (!html?.trim()) return null;
  return <>{renderPieces(splitHtml(html, true), 'head')}</>;
}

/** Right after `<body>` opens (GTM noscript, etc.). */
export function SiteCodeBody({ html }: { html: string }) {
  if (!html?.trim()) return null;
  return <>{renderPieces(splitHtml(html, false), 'body')}</>;
}

/** Before `</body>` — analytics and non-critical scripts. */
export function SiteCodeFooter({ html }: { html: string }) {
  if (!html?.trim()) return null;
  return <>{renderPieces(splitHtml(html, false), 'footer')}</>;
}
