import { getI18n } from '../lib/i18n';
import { fixHeadingOrder } from '../lib/heading-order';
import { withImageSizes } from '../lib/image-sizes';
import type { ShopViewData } from '../lib/shop';
import { shopPageWrap, ShopPageWrapAssets } from './ShopPageWrap';

/**
 * Storefront page body: the theme's PHP markup inside <main>, wrapped by whatever
 * was designed for this page in Shop → Shop Editor (content before / after the
 * "Shop content" block).
 */
export async function ShopMain({ data }: { data: ShopViewData }) {
  const view = data.view === 'category' ? 'shop' : data.view;
  const [i18n, wrapRaw, sized] = await Promise.all([getI18n(), shopPageWrap(view), withImageSizes(data.html)]);
  // The heading outline runs through the whole page: designed content before, the shop, after.
  const SPLIT = '<!--bk:shop-part-->';
  const [before, html, after] = fixHeadingOrder(
    [wrapRaw ? await withImageSizes(wrapRaw.before) : '', sized, wrapRaw ? await withImageSizes(wrapRaw.after) : ''].join(SPLIT),
  ).split(SPLIT);
  const wrap = wrapRaw ? { ...wrapRaw, before, after } : wrapRaw;
  return (
    <>
      <ShopPageWrapAssets wrap={wrap} id={view} />
      <main id="main" className={`bk-main bk-shop-main bk-shop-main--${data.view}`}>
        {wrap?.before ? (
          <div className="bk-page bk-shop-page-wrap" style={{ display: 'contents' }} suppressHydrationWarning dangerouslySetInnerHTML={{ __html: i18n.html(wrap.before) }} />
        ) : null}
        <div style={{ display: 'contents' }} suppressHydrationWarning dangerouslySetInnerHTML={{ __html: i18n.html(html) }} />
        {wrap?.after ? (
          <div className="bk-page bk-shop-page-wrap" style={{ display: 'contents' }} suppressHydrationWarning dangerouslySetInnerHTML={{ __html: i18n.html(wrap.after) }} />
        ) : null}
      </main>
    </>
  );
}
