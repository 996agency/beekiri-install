import { SHOP_SLOT_HTML } from '@beekiri/page-blocks';
import { LayoutStylesheets } from './LayoutStylesheets';
import { API_URL as API } from '@/lib/env';
import { resolveBeekiriCodePage } from './PageBody';
import { apiFetch } from '@/lib/api';

/**
 * Shop → Shop Editor: the BeekiriCode document designed around a storefront page.
 * Rendered once per request and split at the "Shop content" marker so the live
 * markup (products, cart, checkout…) lands exactly where the designer put it.
 */
export type ShopPageWrap = {
  before: string;
  after: string;
  css: string;
  cssHrefs: string[];
  jsHrefs: string[];
};

export async function shopPageWrap(view: string): Promise<ShopPageWrap | null> {
  try {
    const res = await apiFetch(`${API}/api/shop/public/pages/${encodeURIComponent(view)}`, { next: { revalidate: 30 } });
    if (!res.ok) return null;
    const data = (await res.json()) as { beekiricode?: unknown };
    if (!data.beekiricode) return null;
    const page = await resolveBeekiriCodePage(data.beekiricode);
    if (!page || !page.html.trim()) return null;
    const at = page.html.indexOf(SHOP_SLOT_HTML);
    // No marker: the whole document goes above the shop content.
    const before = at === -1 ? page.html : page.html.slice(0, at);
    const after = at === -1 ? '' : page.html.slice(at + SHOP_SLOT_HTML.length);
    if (!before.trim() && !after.trim()) return null;
    return { before, after, css: page.css, cssHrefs: page.cssHrefs, jsHrefs: page.jsHrefs };
  } catch {
    return null;
  }
}

/** <head> assets for the wrap (layout CSS/JS + page CSS), same pattern as pages. */
export function ShopPageWrapAssets({ wrap, id }: { wrap: ShopPageWrap | null; id: string }) {
  if (!wrap) return null;
  return (
    <>
      <LayoutStylesheets hrefs={wrap.cssHrefs} />
      {wrap.css ? (
        <style href={`bk-shop-page-${id}`} precedence="beekiri-page">
          {wrap.css}
        </style>
      ) : null}
      {wrap.jsHrefs.map((href) => (
        <script key={href} src={href} defer />
      ))}
    </>
  );
}
