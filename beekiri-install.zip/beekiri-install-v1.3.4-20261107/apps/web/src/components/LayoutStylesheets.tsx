import { apiFetch } from '@/lib/api';

/** Layout CSS is small: inline it, so the page never waits on a separate request to paint. */
const INLINE_MAX = 60 * 1024;

async function inlineCss(href: string): Promise<string | null> {
  try {
    const res = await apiFetch(href, { next: { revalidate: 30 } });
    if (!res.ok) return null;
    const css = await res.text();
    // Relative url(...) would point somewhere else once inlined: keep those as a link.
    if (css.length > INLINE_MAX || /url\(\s*['"]?(?!data:|https?:|\/|#)/i.test(css)) return null;
    return css;
  } catch {
    return null;
  }
}

/**
 * The page's theme layout stylesheets (React hoists them into <head>, deduplicated by href),
 * inlined like the header/footer CSS, or linked when they can't be.
 */
export async function LayoutStylesheets({ hrefs }: { hrefs: string[] | undefined }) {
  if (!hrefs?.length) return null;
  const sheets = await Promise.all(hrefs.map(async (href) => ({ href, css: await inlineCss(href) })));
  return (
    <>
      {sheets.map(({ href, css }) =>
        css !== null ? (
          <style key={href} href={href} precedence="beekiri-layouts">
            {css}
          </style>
        ) : (
          <link key={href} rel="stylesheet" href={href} precedence="beekiri-layouts" />
        ),
      )}
    </>
  );
}
