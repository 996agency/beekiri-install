'use client';

import { useEffect, useState, type MouseEvent } from 'react';
import { createPortal } from 'react-dom';
import './admin-dock.css';

type DockItem = {
  id: string;
  label: string;
  href: string;
};

function IconEdit() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M4 20h4.5L19 9.5 14.5 5 4 15.5V20z"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinejoin="round"
      />
      <path d="M12.5 7l4.5 4.5" stroke="currentColor" strokeWidth="1.75" />
    </svg>
  );
}

function IconSettings() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden>
      <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.75" />
      <path
        d="M12 3.5v2.2M12 18.3v2.2M4.9 6.5l1.6 1.6M17.5 15.9l1.6 1.6M3.5 12h2.2M18.3 12h2.2M4.9 17.5l1.6-1.6M17.5 8.1l1.6-1.6"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
      />
    </svg>
  );
}

function IconAdmin() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden>
      <rect x="3.5" y="3.5" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.75" />
      <rect x="13.5" y="3.5" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.75" />
      <rect x="3.5" y="13.5" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.75" />
      <rect x="13.5" y="13.5" width="7" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.75" />
    </svg>
  );
}

function iconFor(id: string) {
  if (id === 'edit') return <IconEdit />;
  if (id === 'settings') return <IconSettings />;
  return <IconAdmin />;
}

function withFromSite(href: string): string {
  try {
    const url = new URL(href, window.location.origin);
    url.searchParams.set('from', 'site');
    return url.pathname + url.search + url.hash;
  } catch {
    return href.includes('?') ? `${href}&from=site` : `${href}?from=site`;
  }
}

/**
 * Top-right hover dock for signed-in editors — same reveal pattern as Cookie settings.
 * Clicks show a center loader, then hand off to admin with a matching enter cover.
 */
export function AdminDock() {
  const [items, setItems] = useState<DockItem[]>([]);
  const [mounted, setMounted] = useState(false);
  const [leaving, setLeaving] = useState<string | null>(null);

  useEffect(() => {
    setMounted(true);
    if (typeof window === 'undefined') return;

    let cancelled = false;

    const load = () => {
      if (window.location.pathname.startsWith('/admin')) {
        setItems([]);
        return;
      }
      const path = window.location.pathname || '/';
      fetch(`/api/site/admin-dock?path=${encodeURIComponent(path)}`, {
        credentials: 'same-origin',
      })
        .then(async (res) => {
          if (!res.ok) return null;
          return (await res.json()) as { items?: DockItem[] };
        })
        .then((data) => {
          if (cancelled) return;
          setItems(data?.items?.length ? data.items.slice(0, 3) : []);
        })
        .catch(() => {
          if (!cancelled) setItems([]);
        });
    };

    load();
    window.addEventListener('bk:navigate', load);
    window.addEventListener('popstate', load);
    return () => {
      cancelled = true;
      window.removeEventListener('bk:navigate', load);
      window.removeEventListener('popstate', load);
    };
  }, []);

  const openAdmin = (e: MouseEvent<HTMLAnchorElement>, item: DockItem) => {
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
    e.preventDefault();
    if (leaving) return;
    const label =
      item.id === 'edit'
        ? 'Opening editor…'
        : item.id === 'settings'
          ? 'Opening settings…'
          : 'Opening admin…';
    setLeaving(label);
    try {
      sessionStorage.setItem('bk-enter-from-site', '1');
    } catch {
      /* ignore */
    }
    const href = withFromSite(item.href);
    // Let the overlay paint before unloading the document.
    window.setTimeout(() => {
      window.location.assign(href);
    }, 80);
  };

  if (!mounted || (items.length === 0 && !leaving)) return null;

  return createPortal(
    <>
      {items.length > 0 && !leaving ? (
        <div
          className="bk-admin-dock"
          data-beekiri="admin-dock"
          role="navigation"
          aria-label="Admin shortcuts"
        >
          <div className="bk-admin-dock__list">
            {items.map((item) => (
              <a
                key={item.id}
                className="bk-admin-dock__item"
                href={item.href}
                aria-label={item.label}
                onClick={(e) => openAdmin(e, item)}
              >
                <span className="bk-admin-dock__icon">{iconFor(item.id)}</span>
                <span className="bk-admin-dock__tip">{item.label}</span>
              </a>
            ))}
          </div>
        </div>
      ) : null}

      {leaving ? (
        <div className="bk-admin-dock__leave" role="status" aria-live="polite" aria-busy="true">
          <div className="bk-admin-dock__leave-card">
            <span className="bk-admin-dock__leave-spin" aria-hidden />
            <p className="bk-admin-dock__leave-label">{leaving}</p>
          </div>
        </div>
      ) : null}
    </>,
    document.body,
  );
}
