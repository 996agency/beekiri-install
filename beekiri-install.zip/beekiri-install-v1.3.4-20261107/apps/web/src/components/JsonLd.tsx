import { serializeJsonLd } from '../lib/seo';

/** Emits one <script type="application/ld+json"> per structured-data object. */
export function JsonLd({ data }: { data: (Record<string, unknown> | null)[] }) {
  const items = data.filter((d): d is Record<string, unknown> => Boolean(d));
  if (!items.length) return null;
  return (
    <>
      {items.map((item, i) => (
        <script
          key={i}
          type="application/ld+json"
          // Serialised with `<` escaped, so the payload can't break out of the tag.
          dangerouslySetInnerHTML={{ __html: serializeJsonLd(item) }}
        />
      ))}
    </>
  );
}
