import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { ShopMain } from '../../components/ShopMain';
import { fetchShopView, shopMetadata, siteMeta } from '../../lib/shop';

export const dynamic = 'force-dynamic';

export async function generateMetadata(): Promise<Metadata> {
  return shopMetadata(await fetchShopView('cart', {}, { withCart: true }), await siteMeta(), 'Cart');
}

/** /cart — the shopper's cart (per-visitor, never cached). */
export default async function CartPage() {
  const data = await fetchShopView('cart', {}, { withCart: true });
  if (!data) notFound();
  return <ShopMain data={data} />;
}
