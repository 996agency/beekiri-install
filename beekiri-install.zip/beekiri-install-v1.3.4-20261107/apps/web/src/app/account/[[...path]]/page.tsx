import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { ShopMain } from '../../../components/ShopMain';
import { fetchShopView, shopMetadata, siteMeta } from '../../../lib/shop';

export const dynamic = 'force-dynamic';

type Props = {
  params: Promise<{ path?: string[] }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

const SECTIONS = new Set(['orders', 'details', 'addresses', 'login', 'register', 'forgot', 'reset', 'verify']);

/** /account, /account/orders, /account/orders/1001, /account/login … → the account view. */
async function load(props: Props) {
  const [{ path = [] }, sp] = await Promise.all([props.params, props.searchParams]);
  const [first, second] = path;
  if (path.length > 2) return null;
  let section = 'dashboard';
  let number: string | undefined;
  if (first === 'orders' && second) {
    if (!/^\d{1,10}$/.test(second)) return null;
    section = 'order';
    number = second;
  } else if (first) {
    if (!SECTIONS.has(first) || second) return null;
    section = first;
  }
  return fetchShopView('account', { section, number, token: sp.token, page: sp.page }, { withCart: true });
}

export async function generateMetadata(props: Props): Promise<Metadata> {
  return shopMetadata(await load(props), await siteMeta(), 'My account');
}

/** My account (Shopping extension): orders with tracking, addresses, details, sign in. */
export default async function AccountPage(props: Props) {
  const data = await load(props);
  if (!data) notFound();
  return <ShopMain data={data} />;
}
