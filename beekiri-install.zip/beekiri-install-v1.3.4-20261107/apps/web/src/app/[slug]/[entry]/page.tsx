import type { Metadata } from 'next';
import { LayoutStylesheets } from '../../../components/LayoutStylesheets';
import { notFound } from 'next/navigation';
import { BeekiriCodeMain } from '../../../components/BeekiriCodeMain';
import { JsonLd } from '../../../components/JsonLd';
import { PageBody, resolveBeekiriCodePage } from '../../../components/PageBody';
import { getI18n, localizeRecord } from '../../../lib/i18n';
import { breadcrumbJsonLd, buildJsonLd, buildMetadata, type PublicSeo } from '../../../lib/seo';
import { API_URL as API } from '@/lib/env';
import { apiFetch } from '@/lib/api';

export const revalidate = 30;

type CptMeta = {
  slug: string;
  singular: string;
  plural: string;
  singleDesign: string;
};

type PublicEntry = {
  title: string;
  slug: string;
  path: string;
  content: string;
  beekiricanva?: unknown | null;
  beekiricode?: unknown | null;
  instatic?: unknown | null;
  excerpt: string;
  publishedAt?: string | null;
  updatedAt?: string | null;
  seo?: Partial<PublicSeo> | null;
};

async function getSiteMeta(): Promise<{ title: string; url?: string } | null> {
  try {
    const res = await apiFetch(`${API}/api/site/public`, { next: { revalidate: 30 } });
    if (!res.ok) return null;
    const data = (await res.json()) as { title?: string; url?: string };
    return { title: (await getI18n()).t((data.title ?? '').trim()), url: data.url };
  } catch {
    return null;
  }
}

async function getMeta(type: string): Promise<CptMeta | null> {
  try {
    const res = await apiFetch(`${API}/api/content/${encodeURIComponent(type)}/meta`, {
      next: { revalidate: 30 },
    });
    if (!res.ok) return null;
    return (await res.json()) as CptMeta;
  } catch {
    return null;
  }
}

async function getEntry(type: string, entry: string): Promise<PublicEntry | null> {
  try {
    const res = await apiFetch(
      `${API}/api/content/${encodeURIComponent(type)}/public/${encodeURIComponent(entry)}`,
      { next: { revalidate: 30 } },
    );
    if (res.status === 404) return null;
    if (!res.ok) return null;
    return localizeRecord(await getI18n(), (await res.json()) as PublicEntry);
  } catch {
    return null;
  }
}

type Props = {
  params: Promise<{ slug: string; entry: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug, entry } = await params;
  const item = await getEntry(slug, entry);
  if (!item) return { title: 'Not found' };
  return buildMetadata(item, await getSiteMeta());
}

export default async function CptSinglePage({ params }: Props) {
  const { slug, entry } = await params;
  const [meta, item] = await Promise.all([getMeta(slug), getEntry(slug, entry)]);
  if (!meta || !item) notFound();

  const codeDoc = item.beekiricode ?? item.instatic;
  const codePage = codeDoc ? await resolveBeekiriCodePage(codeDoc) : null;
  const design = meta.singleDesign || 'default';
  const site = await getSiteMeta();
  const i18n = await getI18n();

  return (
    <>
      <JsonLd
        data={[
          ...buildJsonLd(item, site),
          breadcrumbJsonLd([
            { name: site?.title || i18n.t('Home'), path: i18n.href('/') },
            { name: i18n.t(meta.plural), path: i18n.href(`/${meta.slug}`) },
            { name: item.title, path: item.path },
          ], site?.url),
        ]}
      />
      <LayoutStylesheets hrefs={codePage?.cssHrefs} />
      {codePage?.css ? (
        <style href={`bk-cpt-${slug}-${item.slug}`} precedence="beekiri-page">
          {codePage.css}
        </style>
      ) : null}
      {codePage?.jsHrefs.map((href) => (
        <script key={href} src={href} defer />
      ))}
      {codePage ? (
        <BeekiriCodeMain
          html={codePage.html}
          className={`bk-main bk-cpt-single bk-cpt-single--${design}`}
        />
      ) : (
        <main id="main" className={`bk-main bk-cpt-single bk-cpt-single--${design}`}>
          <article>
            <h1>{item.title}</h1>
            <PageBody content={item.content} beekiricanva={item.beekiricanva} beekiricode={null} />
          </article>
        </main>
      )}
    </>
  );
}
