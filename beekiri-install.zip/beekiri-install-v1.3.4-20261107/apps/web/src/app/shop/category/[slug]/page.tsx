import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { ShopMain } from '../../../../components/ShopMain';
import { fetchShopView, shopMetadata, siteMeta } from '../../../../lib/shop';

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

async function load(props: Props) {
  const [{ slug }, sp] = await Promise.all([props.params, props.searchParams]);
  return fetchShopView('category', { slug, q: sp.q, sort: sp.sort, page: sp.page });
}

export async function generateMetadata(props: Props): Promise<Metadata> {
  const [data, site] = await Promise.all([load(props), siteMeta()]);
  return shopMetadata(data, site, 'Shop');
}

/** /shop/category/{slug} — products in a category (and its children). */
export default async function ShopCategoryPage(props: Props) {
  const data = await load(props);
  if (!data) notFound();
  return <ShopMain data={data} />;
}
