import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { ShopMain } from '../../components/ShopMain';
import { fetchShopView, shopMetadata, siteMeta } from '../../lib/shop';

type Props = { searchParams: Promise<Record<string, string | string[] | undefined>> };

function pick(sp: Record<string, string | string[] | undefined>) {
  return { q: sp.q, sort: sp.sort, page: sp.page };
}

export async function generateMetadata({ searchParams }: Props): Promise<Metadata> {
  const [data, site] = await Promise.all([fetchShopView('shop', pick(await searchParams)), siteMeta()]);
  return shopMetadata(data, site, 'Shop');
}

/** /shop — product archive (Shopping extension). */
export default async function ShopPage({ searchParams }: Props) {
  const data = await fetchShopView('shop', pick(await searchParams));
  if (!data) notFound();
  return <ShopMain data={data} />;
}
