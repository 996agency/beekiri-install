import type { MetadataRoute } from 'next';

import { API_URL as API } from '@/lib/env';
import { apiFetch, requestSiteUrl } from '@/lib/api';

export const dynamic = 'force-dynamic';

type PublicRow = {
  path: string;
  updatedAt?: string | null;
  publishedAt?: string | null;
  noindex?: boolean;
  excludeFromSitemap?: boolean;
};

type PublicType = { slug: string; hasArchive: boolean };

async function getJson<T>(url: string): Promise<T | null> {
  try {
    const res = await apiFetch(url, { next: { revalidate: 300 } });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

function rows(data: Record<string, unknown> | null): PublicRow[] {
  if (!data) return [];
  const list = Object.values(data).find((v) => Array.isArray(v)) as PublicRow[] | undefined;
  return list ?? [];
}

function entry(SITE: string, path: string, row?: PublicRow, priority = 0.7): MetadataRoute.Sitemap[number] {
  const p = path.startsWith('/') ? path : `/${path}`;
  const last = row?.updatedAt || row?.publishedAt;
  return {
    url: `${SITE}${p === '/' ? '' : p}`,
    lastModified: last ? new Date(last) : new Date(),
    changeFrequency: 'weekly',
    priority,
  };
}

/** Published pages, posts and public custom post types — minus anything marked noindex / excluded. */
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [site, pages, posts, types] = await Promise.all([
    getJson<{ blogPublic?: boolean; installed?: boolean }>(`${API}/api/site/public`),
    getJson<Record<string, unknown>>(`${API}/api/pages/public`),
    getJson<Record<string, unknown>>(`${API}/api/posts/public`),
    getJson<{ types?: PublicType[] }>(`${API}/api/content-types/public`),
  ]);
  if (site?.installed === false) return [];
  // Multisite: this site's own address.
  const SITE = await requestSiteUrl();

  const keep = (r: PublicRow) => !r.noindex && !r.excludeFromSitemap;
  const out: MetadataRoute.Sitemap = [entry(SITE, '/', undefined, 1)];
  const seen = new Set<string>(['/']);
  const add = (path: string, row?: PublicRow, priority?: number) => {
    const p = path.startsWith('/') ? path : `/${path}`;
    if (seen.has(p)) return;
    seen.add(p);
    out.push(entry(SITE, p, row, priority));
  };

  for (const r of rows(pages).filter(keep)) add(r.path, r, 0.8);
  if (site?.blogPublic !== false) {
    const blog = rows(posts).filter(keep);
    if (blog.length) add('/blog', undefined, 0.6);
    for (const r of blog) add(r.path, r, 0.6);
  }
  const cpts = (types?.types ?? []).filter((t) => t.slug);
  const lists = await Promise.all(
    cpts.map((t) => getJson<Record<string, unknown>>(`${API}/api/content/${encodeURIComponent(t.slug)}/public`)),
  );
  cpts.forEach((t, i) => {
    const items = rows(lists[i] ?? null).filter(keep);
    if (t.hasArchive && items.length) add(`/${t.slug}`, undefined, 0.6);
    for (const r of items) add(r.path, r, 0.6);
  });

  // Shopping extension: shop, categories and published products.
  const shop = await getJson<{ active?: boolean }>(`${API}/api/shop/public/config`);
  if (shop?.active) {
    add('/shop', undefined, 0.7);
    const cats = await getJson<{ categories?: { path: string; count: number }[] }>(`${API}/api/shop/public/categories`);
    for (const c of cats?.categories ?? []) if (c.count > 0) add(c.path, undefined, 0.5);
    for (let page = 1; page <= 50; page++) {
      const list = await getJson<{ items?: { path: string; publishedAt?: string | null }[]; pages?: number }>(
        `${API}/api/shop/public/catalog?perPage=60&page=${page}`,
      );
      for (const p of list?.items ?? []) add(p.path, { path: p.path, publishedAt: p.publishedAt }, 0.6);
      if (!list || page >= (list.pages ?? 1)) break;
    }
  }
  return out;
}
