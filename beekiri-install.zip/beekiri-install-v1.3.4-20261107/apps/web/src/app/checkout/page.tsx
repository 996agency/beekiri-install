import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { ShopMain } from '../../components/ShopMain';
import { fetchShopView, shopMetadata, siteMeta } from '../../lib/shop';

export const dynamic = 'force-dynamic';

type Props = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export async function generateMetadata(): Promise<Metadata> {
  return shopMetadata(await fetchShopView('checkout', {}, { withCart: true }), await siteMeta(), 'Checkout');
}

/** /checkout — addresses, shipping, payment (per-visitor, never cached). */
export default async function CheckoutPage({ searchParams }: Props) {
  const sp = await searchParams;
  const data = await fetchShopView('checkout', { cancelled: sp.cancelled }, { withCart: true });
  if (!data) notFound();
  return <ShopMain data={data} />;
}
