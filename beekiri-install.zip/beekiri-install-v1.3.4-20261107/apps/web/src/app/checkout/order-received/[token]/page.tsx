import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { ShopMain } from '../../../../components/ShopMain';
import { fetchShopView, shopMetadata, siteMeta } from '../../../../lib/shop';

export const dynamic = 'force-dynamic';

type Props = {
  params: Promise<{ token: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

async function load(props: Props) {
  const [{ token }, sp] = await Promise.all([props.params, props.searchParams]);
  return fetchShopView('order-received', { token, session_id: sp.session_id }, { withCart: true });
}

export async function generateMetadata(props: Props): Promise<Metadata> {
  return shopMetadata(await load(props), await siteMeta(), 'Order');
}

/** /checkout/order-received/{token} — thank-you page; the token is the only key to the order. */
export default async function OrderReceivedPage(props: Props) {
  const data = await load(props);
  if (!data) notFound();
  return <ShopMain data={data} />;
}
