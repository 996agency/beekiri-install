import type { Metadata } from 'next';
import Link from 'next/link';
import { getI18n } from '../lib/i18n';

export async function generateMetadata(): Promise<Metadata> {
  const i18n = await getI18n();
  return {
    title: i18n.t('Page not found'),
    robots: { index: false, follow: false },
  };
}

/** Theme-chrome 404 (header/footer from root layout). */
export default async function NotFoundPage() {
  const i18n = await getI18n();
  return (
    <main id="main" className="bk-main bk-404">
      <p className="bk-404__code" aria-hidden="true">
        404
      </p>
      <h1>{i18n.t('Page not found')}</h1>
      <p className="bk-lead">
        {i18n.t('That address is not on this site. It may have moved, or the link is out of date.')}
      </p>
      <p>
        <Link href={i18n.href('/')} className="bk-404__home">
          {i18n.t('Back to home')}
        </Link>
      </p>
    </main>
  );
}
