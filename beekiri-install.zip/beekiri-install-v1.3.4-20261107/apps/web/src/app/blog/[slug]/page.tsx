import type { Metadata } from 'next';
import { LayoutStylesheets } from '../../../components/LayoutStylesheets';
import { notFound } from 'next/navigation';
import { BeekiriCodeMain } from '../../../components/BeekiriCodeMain';
import { JsonLd } from '../../../components/JsonLd';
import { layoutAssetsFor, PageBody, resolveBeekiriCodePage } from '../../../components/PageBody';
import { breadcrumbJsonLd, buildJsonLd, buildMetadata, type PublicSeo } from '../../../lib/seo';
import { blogView } from '../../../lib/blog';
import { getI18n, localizeRecord } from '../../../lib/i18n';
import { apiFetch } from '@/lib/api';

export const revalidate = 30;

import { API_URL as API } from '@/lib/env';

type PublicPage = {
  title: string;
  slug: string;
  path: string;
  content: string;
  beekiricanva?: unknown | null;
  beekiricode?: unknown | null;
  instatic?: unknown | null;
  excerpt: string;
  publishedAt?: string | null;
  updatedAt?: string | null;
  seo?: Partial<PublicSeo> | null;
};

async function getPage(slug: string): Promise<PublicPage | null> {
  try {
    const res = await apiFetch(`${API}/api/posts/public/${encodeURIComponent(slug)}`, {
      next: { revalidate: 30 },
    });
    if (res.status === 404) return null;
    if (!res.ok) return null;
    return localizeRecord(await getI18n(), (await res.json()) as PublicPage);
  } catch {
    return null;
  }
}

type Props = {
  params: Promise<{ slug: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const page = await getPage(slug);
  if (!page) return { title: 'Not found' };
  // Posts default to BlogPosting schema unless the SEO tab says otherwise.
  return buildMetadata({ ...page, seo: { schemaType: 'BlogPosting', ...(page.seo ?? {}) } }, await getSiteMeta());
}

async function getSiteMeta(): Promise<{ title: string; url?: string } | null> {
  try {
    const res = await apiFetch(`${API}/api/site/public`, { next: { revalidate: 30 } });
    if (!res.ok) return null;
    const data = (await res.json()) as { title?: string; url?: string };
    return { title: (await getI18n()).t((data.title ?? '').trim()), url: data.url };
  } catch {
    return null;
  }
}

export default async function BlogPostPage({ params }: Props) {
  const { slug } = await params;
  const page = await getPage(slug);
  if (!page) notFound();
  const codeDoc = page.beekiricode ?? page.instatic;
  const codePage = codeDoc ? await resolveBeekiriCodePage(codeDoc) : null;
  const site = await getSiteMeta();
  const seoPage = { ...page, seo: { schemaType: 'BlogPosting', ...(page.seo ?? {}) } };
  const i18n = await getI18n();
  // The active theme's single-post design (blog/single.php): the post body goes at its marker.
  const themed = await blogView('single', { slug });
  const at = themed?.html && themed.marker ? themed.html.indexOf(themed.marker) : -1;
  const framed =
    themed?.html && themed.marker && at !== -1
      ? themed.html.slice(0, at) + (codePage?.html ?? page.content ?? '') + themed.html.slice(at + themed.marker.length)
      : null;
  // Layouts the template itself prints (data-layout), besides the ones in the post body.
  const frame = framed ? await layoutAssetsFor(themed?.html ?? '') : { cssHrefs: [], jsHrefs: [] };
  const cssHrefs = [...new Set([...(codePage?.cssHrefs ?? []), ...frame.cssHrefs])];
  const jsHrefs = [...new Set([...(codePage?.jsHrefs ?? []), ...frame.jsHrefs])];

  return (
    <>
      <JsonLd
        data={[
          ...buildJsonLd(seoPage, site),
          breadcrumbJsonLd([
            { name: site?.title || i18n.t('Home'), path: i18n.href('/') },
            { name: i18n.t('Blog'), path: i18n.href('/blog') },
            { name: page.title, path: page.path },
          ], site?.url),
        ]}
      />
      <LayoutStylesheets hrefs={cssHrefs} />
      {codePage?.css ? (
        <style href={`bk-page-${page.slug}`} precedence="beekiri-page">
          {codePage.css}
        </style>
      ) : null}
      {jsHrefs.map((href) => (
        <script key={href} src={href} defer />
      ))}
      {framed ? (
        <BeekiriCodeMain html={framed} className="bk-main bk-blog-view" />
      ) : codePage ? (
        <BeekiriCodeMain html={codePage.html} />
      ) : (
        <main id="main" className="bk-main">
          <h1>{page.title}</h1>
          <PageBody content={page.content} beekiricanva={page.beekiricanva} beekiricode={null} />
        </main>
      )}
    </>
  );
}
