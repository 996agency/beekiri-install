import type { Metadata } from 'next';
import { LayoutStylesheets } from '../../components/LayoutStylesheets';
import { BeekiriCodeMain } from '../../components/BeekiriCodeMain';
import { layoutAssetsFor } from '../../components/PageBody';
import { blogView } from '../../lib/blog';
import { getI18n, localizeRecord } from '../../lib/i18n';
import { apiFetch } from '@/lib/api';

export const revalidate = 30;

import { API_URL as API } from '@/lib/env';

type PublicPost = {
  title: string;
  slug: string;
  path: string;
  excerpt: string;
  publishedAt: string | null;
};

async function listPublishedPosts(): Promise<PublicPost[]> {
  try {
    // Public archive: pull from link-targets-style listing via a lightweight public endpoint.
    // Until a dedicated archive API exists, reuse site public menu is not enough —
    // fetch published posts through the posts public index when available.
    const res = await apiFetch(`${API}/api/posts/public`, { next: { revalidate: 30 } });
    if (!res.ok) return [];
    const data = (await res.json()) as { posts?: PublicPost[] };
    const i18n = await getI18n();
    return (data.posts ?? []).map((p) => localizeRecord(i18n, p));
  } catch {
    return [];
  }
}

type Props = { searchParams: Promise<{ page?: string }> };

const pageOf = async (searchParams: Props['searchParams']) => Math.max(1, Number((await searchParams).page) || 1);

export async function generateMetadata({ searchParams }: Props): Promise<Metadata> {
  const i18n = await getI18n();
  const themed = await blogView('archive', { page: await pageOf(searchParams) });
  if (themed) return { title: i18n.t(themed.title || 'Blog'), description: i18n.t(themed.description || '') || undefined };
  return { title: i18n.t('Blog'), description: i18n.t('Latest posts') };
}

export default async function BlogIndexPage({ searchParams }: Props) {
  // The active theme's own blog design, when it ships blog/archive.php.
  const themed = await blogView('archive', { page: await pageOf(searchParams) });
  if (themed?.html) {
    // A template can print a theme layout's markup (data-layout) to reuse its design.
    const assets = await layoutAssetsFor(themed.html);
    return (
      <>
        <LayoutStylesheets hrefs={assets.cssHrefs} />
        {assets.jsHrefs.map((href) => (
          <script key={href} src={href} defer />
        ))}
        <BeekiriCodeMain html={themed.html} className="bk-main bk-blog-view" />
      </>
    );
  }

  const posts = await listPublishedPosts();
  const i18n = await getI18n();

  return (
    <main id="main" className="bk-main">
      <h1>{i18n.t('Blog')}</h1>
      <p className="bk-lead">{i18n.t('Single posts from your site.')}</p>
      {posts.length === 0 ? (
        <p className="bk-muted">{i18n.t('No published posts yet.')}</p>
      ) : (
        <ul className="bk-blog-list">
          {posts.map((post) => (
            <li key={post.slug}>
              <a href={post.path || i18n.href(`/blog/${post.slug}`)}>
                <strong>{post.title || '(no title)'}</strong>
              </a>
              {post.excerpt ? <p>{post.excerpt}</p> : null}
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
