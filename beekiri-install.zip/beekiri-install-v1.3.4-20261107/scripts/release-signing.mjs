#!/usr/bin/env node
/**
 * Signs Beekiri Core release packages, so the in-place updater and the npx installer only run
 * code 996agency published (their pinned public key must match). The private key lives outside
 * the repository, on the publishing machine only.
 *
 *   node scripts/release-signing.mjs keygen                 make the key once, print the public key
 *   node scripts/release-signing.mjs sign <zip> <version>   write <zip>.sig next to the package
 *   node scripts/release-signing.mjs public                 print the public key again
 *
 * BEEKIRI_RELEASE_KEY overrides the key path (default ~/.beekiri/release-signing-key.pem).
 * Back the key up somewhere safe: without it no update can be published that sites accept.
 */
import { createHash, createPrivateKey, createPublicKey, generateKeyPairSync, sign } from 'node:crypto';
import { chmodSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';

const KEY_PATH = process.env.BEEKIRI_RELEASE_KEY || join(homedir(), '.beekiri', 'release-signing-key.pem');
const [command, ...args] = process.argv.slice(2);

/** What gets signed, byte for byte as scripts/core-update.mjs and the installer rebuild it. */
const message = (version, sha256) => Buffer.from(`beekiri-core:v1\n${version}\n${sha256}`, 'utf8');

function publicKeyB64(privatePem) {
  // Raw 32-byte Ed25519 key: the last 32 bytes of its SPKI DER encoding.
  const der = createPublicKey(createPrivateKey(privatePem)).export({ type: 'spki', format: 'der' });
  return der.subarray(der.length - 32).toString('base64');
}

function readKey() {
  if (!existsSync(KEY_PATH)) {
    console.error(`No release signing key at ${KEY_PATH}. Run: node scripts/release-signing.mjs keygen`);
    process.exit(1);
  }
  return readFileSync(KEY_PATH, 'utf8');
}

if (command === 'keygen') {
  if (existsSync(KEY_PATH)) {
    console.error(`A key already exists at ${KEY_PATH}; refusing to replace it (sites trust that one).`);
    process.exit(1);
  }
  const { privateKey } = generateKeyPairSync('ed25519');
  const pem = privateKey.export({ type: 'pkcs8', format: 'pem' });
  mkdirSync(dirname(KEY_PATH), { recursive: true, mode: 0o700 });
  writeFileSync(KEY_PATH, pem, { mode: 0o600 });
  chmodSync(KEY_PATH, 0o600);
  console.log(publicKeyB64(pem));
} else if (command === 'public') {
  console.log(publicKeyB64(readKey()));
} else if (command === 'sign') {
  const [zip, version] = args;
  if (!zip || !version) {
    console.error('Usage: node scripts/release-signing.mjs sign <zip> <version>');
    process.exit(1);
  }
  const sha256 = createHash('sha256').update(readFileSync(zip)).digest('hex');
  const signature = sign(null, message(version, sha256), createPrivateKey(readKey())).toString('base64');
  writeFileSync(`${zip}.sig`, `${JSON.stringify({ version, sha256, signature }, null, 2)}\n`);
  console.log(`Signed ${zip} (v${version}, sha256 ${sha256.slice(0, 12)}…)`);
} else {
  console.error('Usage: node scripts/release-signing.mjs keygen | public | sign <zip> <version>');
  process.exit(1);
}
