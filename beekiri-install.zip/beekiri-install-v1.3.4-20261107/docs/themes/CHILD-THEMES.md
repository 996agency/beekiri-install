# Child themes and safe updates

Every theme has a child, where the site's own changes to it live. Beekiri looks in the child first, then in the theme, then in Beekiri.

| Theme | Its child | Who changes it |
|---|---|---|
| Beekiri (parent) | `beekiri-child` | Core updates replace Beekiri; never the child |
| Be Chair, Be Clinic, any store or uploaded theme | `be-chair-child`, `be-clinic-child`, … | Theme updates replace the theme; never the child |

## What goes into a store theme's child

Beekiri makes the child automatically: when the theme is installed, and at start-up for themes installed earlier. You don't have to activate it. Activating **Be Chair** uses `be-chair-child` on top.

- **Backend Fields layouts** made while the theme is active are saved in `be-chair-child/layouts/`. They still belong to Be Chair in Backend Fields.
- **Layouts of the other sites** of a network go into `be-chair-child/sites/<site id>/layouts/`.
- **Custom post type templates** go into `be-chair-child/cpts/`.
- **BeeQueen** writes theme files into the child.
- **To change a theme file**, copy it from `be-chair/` into the same path in `be-chair-child/` and edit the copy. For a header or footer, copy the whole folder (for example `header/`), because its styles, script and fonts are read from that folder.

Sites that already had layouts inside a store theme's folder have them moved into the child once, at start-up. A layout counts as the site's own when a Backend Fields group of that theme has its key. Layouts the theme ships stay in the theme.

## Updating a theme

Installing a new version from **Appearance → Templates** (theme store) or by uploading its ZIP:

1. Moves any site files still in the theme folder into the child.
2. Moves the old theme folder to `themes/.backups/<slug>-<version>-<time>`. The three newest backups of each theme are kept.
3. Unpacks the new version. If it can't be read, the previous version is put back.

The child is never touched. An upload can't replace a child folder.

Deleting a theme keeps its child. Install the theme again and the child is used again.

## Updating Beekiri

A core update only copies Beekiri's own files over the install and never deletes site files. Under `apps/web/themes` it only updates the Beekiri parent theme. It leaves alone every `*-child` folder, every store theme, the global layouts (`_network`), theme backups, and every `layouts/`, `sites/` and `cpts/` folder. The old core files are backed up in `backups/core-v<version>-<time>` first.

## Settings → Migration

Copying a store theme to another site also copies its child, so the layouts and changes go with it.
