# Multisite

One Beekiri install can run several websites. Each site has its own address, pages, menus, media, settings, forms, shop and analytics. People sign in once and switch between the sites they are allowed to use.

## Add a site

1. Sign in as the **owner** and open **Settings → Sites**.
2. Click **Add site**, enter a name and a sub-domain (for example `shop`), and pick a theme.
3. Click **Create site**. The new site is live at `shop.<network domain>` straight away, with the theme's ready-made pages if it has any.

From the same list you can open a site's admin, rename it, change its sub-domain, give it its own domain, archive it (nothing is deleted) or delete it (you type the sub-domain to confirm).

## Password protection

Any site, including the main one, can be hidden behind a password while you build it: **Settings → Sites → Password** on that site's row.

- Visitors (and search engines) see a password page instead of the site; `robots.txt` tells crawlers to stay out.
- Send your client the site's address and the password. After typing it once, their browser remembers it for 30 days. There is no link that skips the password.
- **Change password** asks everyone who typed the old password to type the new one.
- People signed in to that site's admin always see the site as normal.
- The admin, sign-in and payment webhooks keep working. Uploaded files (`/uploads/…`) are not behind the password.
- Ten wrong passwords from one address in 15 minutes lock that address out for a while.

## Addresses

| Site | Address |
|---|---|
| Main site | your `APP_URL`, for example `https://example.com` |
| Other sites | `https://<sub-domain>.<network domain>`, for example `https://shop.example.com` |
| A site with its own domain | that domain, for example `https://myshop.com` (the sub-domain keeps working too) |

The **network domain** is your main site's domain unless you change it in **Settings → Sites → Network domain**.

**Locally**, sub-domains of `localhost` work without any set-up in Chrome, Edge and Firefox: `http://shop.localhost:8788`.

**On a server**, add one wildcard DNS record so every new sub-domain reaches Beekiri:

```
*.example.com   A   <your server's IP>
```

Your reverse proxy (nginx, Caddy, your host's panel) must send all of those names to Beekiri with the original `Host` header and serve a certificate that covers them (a wildcard certificate, or Caddy's on-demand TLS). Example for nginx:

```nginx
server {
  server_name example.com *.example.com;
  location / {
    proxy_pass http://127.0.0.1:8788;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
  }
}
```

An address that does not belong to any site answers *There is no site at this address*, so a typo never shows another site's content.

## People and permissions

- Every person has **one account** for the whole network.
- In **Users → User Permissions**, the owner picks a person and sets, in the **Sites** card, which sites they can use and their role on each one (or **No access**). The permissions below that card apply to the site you are on.
- Someone added under **Users → Add New** on a site gets an account with access to that site only.
- Removing someone on a site only takes away their access to that site; their account is deleted only when they have no other site.
- The **owner** can use every site as an administrator.
- An administrator of one site cannot change the e-mail, username or password of someone who also uses other sites; only that person or the owner can.

**Switching sites:** the **My sites** menu in the admin bar lists the sites you can use. Picking one opens its admin already signed in (a one-time link that works once, for one minute, on that site only).

## Layouts on several sites

- A layout from **Backend Fields** belongs to the site and theme it was made on.
- The owner can **Share with all sites**: it becomes a **global** layout that every site can use, whatever its theme.
- On any site, **Customise for this site** makes that site's own copy of a global layout. The copy starts from the global design and can then be changed freely; other sites keep the global version. **Use global design** removes the copy again.
- Only the owner can change a global layout itself.

## Themes and licences

Any installed theme can be active on any number of sites. A paid theme bought from the Beekiri Hub is licensed for the whole network: one licence covers every site of the install.

## Good to know

- **Settings → Migration** copies theme code and media for the site you are on. A full database copy is only offered while the install has a single site.
- Media uploaded on another site is stored under `/uploads/sites/<site id>/`.
- Deleting a site deletes its pages, media, forms, shop data and analytics. Accounts stay.
