# Bee Forms — developer guide

## 1. Architecture

| Layer | Files |
|---|---|
| Pure logic | `apps/api/src/lib/forms/schema.ts` (types, `parseFormFields`, `parseFormSettings`, `formPages`), `conditions.ts` (`visibleFieldIds`), `validate.ts` (`validateSubmission`, MIME allow-lists), `render.ts` (`renderForm` HTML), `merge.ts` (merge tags), `emails.ts`, `token.ts` (spam time token), `constants.ts`, `form.css` (public styles) |
| Data | migration `20261106090000_bee_forms`, models `bee-form.model.ts`, `bee-form-entry.model.ts` |
| Services | `services/forms/forms.service.ts` (CRUD, public render), `entries.service.ts` (inbox, files, CSV), `submit.service.ts` (spam checks, validation, storage, emails), `forms-install.service.ts` (extension hooks) |
| HTTP | `routes/forms.routes.ts`, `controllers/forms.controller.ts`, `middleware/forms.ts` (`requireFormsActive`, `requireFormRequest`, multipart parser), rate limits in `middleware/rate-limit.ts` |
| Website | `apps/web/public/runtime/bee-forms.js` (validation, logic, steps, AJAX submit, slot filling), `apps/web/src/lib/forms.ts`, root layout loads the script + `/api/forms/public/assets/form.css` when active, `page-blocks/beekiricode-html.ts` renders the `form` node through a `renderForm` callback |
| Admin | `screens/forms/{FormsPage,FormEditPage,EntriesPage}.tsx`, `api.ts`, `forms.css`; editor element in `editor/beekiricode/{document,nodeMeta,AddPanel,BeekiriCodeCanvas,PropertiesPanel,FormPreview}.tsx`; Backend Field picker in `inspector/AcfFieldInputs.tsx` (`FormPicker`) |
| Backend Field `form` | `lib/fields/fields.types.ts`, `acf-format.ts` (`forms` lookup → `{ID,title,html}`), `layout-sync.service.ts` (lookup wiring), `layout-templates.ts` (PHP/TSX generators), `layout-runner.php` (`bee_form()`, `the_bee_form()`) |

Everything hangs off the extension slug `bee-forms` (`FORMS_EXTENSION_SLUG`). The catalog entry is in `lib/extensions/catalog.ts`; hooks in `services/extensions.service.ts`.

## 2. Data model

**BeeForm**: `title`, `status` (`active|inactive`), `fields` (jsonb `FormField[]`), `settings` (jsonb `FormSettings`), `entryCount`, `unreadCount`, `lastEntryAt`, `createdById`.

**BeeFormEntry**: `formId`, `status` (`unread|read|spam|trash`), `data` (jsonb keyed by **field id**; strings, string lists, or `{id,name,mime,size}[]` for files), `labels` (snapshot of label/name/type per field id, so entries outlive field renames), `meta` (ip, userAgent, pageUrl, pageTitle, referrer, fillSeconds), `summary` (list-row text).

Uploads: `<uploads root>/.forms/<entryId>/<fileId>` (no extension). The `.forms` dot-folder is never served by `express.static` (`dotfiles: 'deny'`); the only way out is `GET /api/forms/entries/:id/files/:fileId` with `view_form_entries`.

## 3. API

Public (404 while inactive, except `config`):

| Route | Notes |
|---|---|
| `GET /api/forms/public/config` | `{active}` — the website checks this on every render |
| `GET /api/forms/public/assets/form.css` | stylesheet |
| `GET /api/forms/public/:id/html` | `{html,title}` with a fresh token; `no-store` |
| `GET /api/forms/public/:id/token` | fresh spam token (the script asks on first focus) |
| `POST /api/forms/public/:id/submit` | multipart; needs `Origin` from an allowed origin and `X-Beekiri-Form: 1`; 200 `{ok:true,entryId,confirmation}` or 422 `{ok:false,errors:[{field,message}]}` |

Admin (`manage_forms` unless noted): `GET/POST /api/forms`, `GET/PATCH/DELETE /api/forms/:id`, `POST /:id/duplicate`, `GET /:id/preview` (any editor), `GET /api/forms/lookup` (any editor). Entries (`view_form_entries`): `GET /entries/list`, `GET /entries/:id` (marks read), `POST /entries/status`, `POST /entries/delete`, `GET /entries/:id/files/:fileId`, `GET /:id/entries/export` (CSV).

## 4. Submission pipeline (`submit.service.ts`)

1. Form must be active and the extension on.
2. Spam: honeypot `_bk_hp` must be empty; `_bk_t` token must verify, be ≥ `minSeconds` old and < 24 h; `isLikelyBot(user-agent)`; per-IP (10 / 10 min) and per-form (120 / min) buckets. Spam gets the normal success body and is dropped.
3. Inputs are named `f_<fieldId>`; files the same. `validateSubmission` evaluates conditional logic server-side, drops hidden fields, validates each type, and refuses blocked MIME types / extensions whatever the field allows.
4. Files are written first (rolled back on failure), then the entry row, then counters.
5. Emails are fire-and-forget: notification (merged recipients, optional Reply-To from a field) and auto-reply (to the chosen or first email field).

## 5. Markup contract

`renderForm()` emits `<div class="bk-form" data-bee-form="ID">` containing the `<form data-bee-form-el>`, pages (`.bk-form__page[data-page]`), fields (`.bk-form__field[data-field][data-type]`), the honeypot, the token input, `[data-status]`, `[data-done]`, and a `<script type="application/json" data-bee-form-def>` with the subset the script needs (ids, types, required, conditional rules, min/max). The script mounts on every `[data-bee-form]`, re-runs on `bk:navigate`, and fills `[data-bee-form-slot="ID"]` placeholders by fetching the HTML (used when a page was rendered without the server callback).

The editor preview (`/api/forms/:id/preview`) is the same markup with `preview: true` (no honeypot, inert via CSS) and is sanitized with DOMPurify before insertion.

## 6. Extending

- New field type: add it to `FORM_FIELD_TYPES`, `parseFormFields`, `validateSubmission`, `render.ts` (`control()`), the admin `FIELD_TYPES` palette and `FieldSettings`, and `bee-forms.js` `readValue`/`validateField`.
- New merge tag: `simpleTags()` in `merge.ts`.
- Tests: `apps/api/test/forms.lib.test.ts` covers parsing, conditions, validation, token, merge tags and rendering (`npx vitest run test/forms.lib.test.ts`).
