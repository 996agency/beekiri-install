# Shopping — user guide

Shopping is the Beekiri extension that turns a site into a shop. This guide is for the people
who run the shop day to day. For code, templates and the API see the
[developer guide](./DEVELOPER-GUIDE.md).

## 1. Install and activate

1. Go to **Extensions → Add New**, find **Shopping** and click **Install now**.
2. Shopping is active straight away. A **Shop** section appears in the sidebar with
   Overview, Products, Categories, Tags, Orders, Customers, Coupons and Settings.
3. On the website, `/shop`, `/cart` and `/checkout` now exist, and the header shows a cart icon.

**Deactivate** (Extensions → Installed) hides the shop pages and the Shop menu but keeps every
product and order. **Uninstall** removes it from the list; you are asked whether to delete the
data as well (Settings → Advanced → *Remove data on uninstall* has the same effect).

Who can do what:

| Capability | Lets a user… | Default roles |
|---|---|---|
| Products (`edit_products`) | create, edit, publish, delete products, categories and tags | Administrator, Shop manager |
| Orders & customers (`edit_shop_orders`) | manage orders, refunds, customers and coupons | Administrator, Shop manager |
| Shop settings (`manage_shop`) | change payments, shipping, taxes, emails | Administrator, Shop manager |
| Shop reports (`view_shop_reports`) | see sales figures | Administrator, Shop manager |

The **Shop manager** role has all four plus media uploads. Adjust per user under
Users → User Permissions.

## 2. First settings (Shop → Settings)

Do these before you sell anything:

- **General:** store name and address (the address decides the default country at checkout),
  which countries you sell to, and the **currency** with its number format.
- **Payments:** turn on at least one method.
  - *Cash on delivery* — on by default; the order is created as **Processing** and marked paid
    when you complete it.
  - *Direct bank transfer* — add your bank details; the order waits **On hold** until you move it
    to Processing after the money arrives.
  - *Stripe* — paste the publishable key and the secret key from your Stripe dashboard. For
    live payments also create a webhook in Stripe pointing at the URL shown on the Payments
    tab, subscribe to the listed events, and paste the signing secret. Use **Test** mode first.
- **Shipping:** add a zone (for example "Kosovo", "Europe", or leave the countries empty for
  "everywhere else") and give it one or more methods: flat rate, free shipping (optionally above
  a minimum order amount) or local pickup. If a shopper's country matches no zone and there is
  no catch-all zone, they cannot check out.
- **Tax** (optional): enable taxes, say whether your prices already include tax, and add rates
  by country. Products are taxable by default; you can switch a product to "None".
- **Checkout:** the checkout form itself. Every field (name, company, phone, address lines…) can be
  renamed, reordered, made optional or hidden, and you can **add your own fields** — a delivery
  time select, a gift message, a "how did you hear about us" question, a consent checkbox. Answers
  are stored with the order, shown in the order emails and on the order page. The shipping address
  form mirrors the billing fields. Also here: the terms and privacy pages and the thank-you text.
- **Emails:** who receives the "new order" email (blank = site owner) and the subject lines.

Order numbers start at the number set under **Advanced** (default 1000) with the prefix `#`.

## 3. Products

**Shop → Products → Add product** opens an editor similar to WooCommerce:

- **Name**, **permalink** (`/product/your-slug`), **description** and **short description**.
- **Product data**
  - *Simple product* — one price. *Variable product* — several versions (sizes, colours…).
  - **General:** regular price, sale price and an optional sale schedule, tax status.
  - **Inventory:** SKU, stock tracking with quantity and a low-stock threshold, whether to allow
    backorders, "sold individually" (one per order).
  - **Shipping:** weight and dimensions (hidden for virtual products).
  - **Attributes:** e.g. *Size* with values `S | M | L`. Tick **Used for variations** to build
    variations from it; tick **Visible** to show it under "Additional information".
  - **Variations** (variable products): **Generate variations** creates every combination; open
    each one to set its price, SKU, stock and image. Disable a variation to hide it.
  - **Advanced:** purchase note, catalog visibility (shop and search / shop only / search only /
    hidden), featured.
- Sidebar: **Publish** (Save draft / Publish / Update, Move to trash), **Product image**,
  **Product gallery**, **Categories** (with "add new"), **Tags**.

Only **published** products are visible on the site. Out-of-stock products stay listed (greyed)
unless *Hide out-of-stock products* is on in Settings → Products.

**Categories** and **Tags** have their own screens (Shop → Categories / Tags). Categories can be
nested; a category page lists its own products and those of its sub-categories.

The products list supports searching by name or SKU, filtering by status, category, stock and
type, sorting, bulk publish / draft / trash, duplicate, and a trash with restore.

## 4. Orders

**Shop → Orders** lists every order with its status:

| Status | Meaning |
|---|---|
| Pending payment | Card payment started but not confirmed yet (stock is held for the time set in Settings → Advanced, then the order is cancelled automatically) |
| On hold | Waiting for a bank transfer |
| Processing | Paid (or cash on delivery) — prepare and ship it |
| Completed | Done. Cash-on-delivery orders are marked paid here |
| Cancelled | Cancelled by you, by an expired payment, or by the shopper abandoning the card payment |
| Refunded | Fully refunded |
| Failed | The payment failed |

Open an order to see the items, totals, addresses, payment details and notes, and to:

- **Change the status** (with an optional note that goes into the customer's email).
  Moving to *Processing* marks a bank transfer as paid. Moving to *Cancelled* or *Refunded*
  puts the items back in stock.
- **Add notes** — private (staff only) or a note to the customer (emailed).
- **Refund** — full or partial. For Stripe orders tick *Refund via Stripe* to refund the card;
  for other methods refund the money yourself and record it here. *Restock items* returns the
  quantities to stock on a full refund.
- **Resend** any of the order emails.
- Edit the customer's email, phone or addresses.

Shoppers can always open their order from the link in their emails (the link contains a long
secret token; no login is needed).

### Shipping and tracking

Every order has a **Shipping & tracking** panel: mark it **Packed**, then **Shipped** (add the
carrier, tracking number and tracking link), then **Delivered** (which completes the order).
Shipped and Delivered can email the customer. Customers see a progress timeline — Order placed →
Payment → Packed → Shipped → Delivered — in My account and on their order page, with a
**Track parcel** button when you added a link.

## 5. Customer accounts (My account)

Shoppers can create an account at `/account` (or tick "Create an account" at checkout). The
header shows an account icon next to the cart, with their first name once signed in.

In My account they see:
- **Dashboard** — recent orders with a progress bar and status ("On its way", "Delivered").
- **Orders** — every order; open one for the full tracking timeline, items, totals and addresses.
- **Addresses** — saved billing and shipping addresses, filled in at checkout automatically.
- **Account details** — name, phone and password.

**Staff use their admin login.** If you are signed in to the admin (Owner, administrator, shop
manager…), the shop treats you as signed in too — My account shows your orders under your admin
email, and sign-out / password changes stay in the admin. Shop accounts created on the website are
for customers only and never give access to the admin.

My account, its header icon and all shop pages exist only while Shopping is **active**;
deactivate it in Extensions and they disappear (the addresses answer "page not found").

For privacy, order history and saved addresses appear only after the shopper **confirms their
email** (a link is emailed when they register). Without that, anyone could register with
someone else's email and see their past guest orders. A guest who orders with the email of an
existing account cannot change that account's saved details.

Settings → Accounts: turn accounts on or off, allow registration, offer "Create an account" at
checkout, or require an account to buy.

## 6. Customers and coupons

**Customers** lists everyone who has ordered, with their spend and last order; click through to
their orders.

**Coupons** are codes shoppers enter in the cart:

- Type: **percentage**, **fixed cart discount** or **fixed product discount** (per item).
- Restrictions: minimum / maximum spend, only for certain products or categories, excluded
  products, free shipping.
- Limits: total uses, uses per email address, expiry date.

Usage is counted when the order is placed (card orders: when the payment is confirmed).

## 7. The shop on the website

| Page | Address |
|---|---|
| Shop (all products, search, sorting, categories) | `/shop` |
| Category | `/shop/category/<slug>` |
| Product | `/product/<slug>` |
| Cart | `/cart` |
| Checkout | `/checkout` |
| Order received | `/checkout/order-received/<token>` |
| My account | `/account` (`/account/orders`, `/account/orders/<number>`, `/account/addresses`, `/account/details`, `/account/login`, `/account/register`) |

The pages use your theme's colours and buttons. A designer can change any of them by copying the
template from `apps/web/themes/beekiri/shop/` into `apps/web/themes/beekiri-child/shop/`
(see the developer guide). Text on the pages can be translated under Settings → Translation.

Add a link to `/shop` to your menu under Settings → General → Menu.

## 8. Shop Editor — design the shop pages

**Shop → Shop Editor** lists the five storefront pages (Shop, Product page, Cart, Checkout, Order
received). Each one is a BeekiriCode page like any other, with one special block in the middle:
**Shop content** — the place where the live products, product details, cart or checkout form is
rendered by the theme.

- Click **Edit with BeekiriCode** to open the page editor. Add headings, text, images, buttons or
  theme layouts above and below the Shop content block (a hero banner on the shop page, a trust
  bar on the checkout, a "you may also like" section under the product details…). The Shop
  content block cannot be edited — it always shows the live shop.
- Toggle the parts of the shop content itself per page: products per row, sidebar, search,
  sorting, breadcrumbs, gallery thumbnails, related products, coupon form, and more.
- **Reset** returns a page to the plain design. **View** opens it on the site.

The design of the shop content (grid, buttons, colours) follows the theme; a developer can change
it by overriding the templates in Beekiri Child (see the developer guide).

## 9. Overview and dashboard

**Shop → Overview** shows revenue, orders, average order value, items sold and new customers for
today / 7 / 30 / 90 days / a year, a daily revenue chart, orders by status, top products, low-stock
warnings and recent orders. The **Shop** widget on the Dashboard shows the last seven days.

## 10. Troubleshooting

- *Shoppers cannot check out / "We cannot ship to that address"* — no shipping zone matches their
  country. Add the country to a zone or create a zone with no countries ("everywhere else").
- *Card payments stay "Pending payment"* — in test mode without a webhook, the order is confirmed
  when the shopper returns to the thank-you page. For live sites add the Stripe webhook so
  payments are confirmed even if the shopper closes the browser.
- *Stripe keys disappear after a restart* — set `CACHE_FLUSH_SECRET` in `apps/api/.env`
  (the Payments tab shows a warning while it is missing) and enter the keys again.
- *Shoppers do not see their orders* — they have not confirmed their email yet; My account shows
  a "Send it again" link.
- *No emails* — Beekiri sends mail through the `SMTP_*` settings in `apps/api/.env`. Without
  them, emails are written to the server log instead.
- *The shop pages are blank* — the website needs the PHP command-line binary (`php`) on the
  server, like layouts do. The page shows a short notice when a template cannot run.
