# Shopping — developer guide

How the Shopping extension is built, where things live, and how to extend it safely.
Read the [user guide](./USER-GUIDE.md) first for what the shop does.

## 1. Architecture

Shopping is a native Beekiri extension: it ships inside the core package and is switched on per
site. There is no separate service or database.

```
apps/api/src
  lib/extensions/catalog.ts            catalog entry (what the Extensions screen shows)
  services/extensions.service.ts       install / activate / deactivate / uninstall + hooks
  lib/shop/                            pure logic, no I/O
    constants.ts   slugs, paths, statuses, cookie + header names
    money.ts       currencies, formatMoney / parseMoney (integer minor units)
    pricing.ts     effective price, price ranges, available stock
    cart-totals.ts coupons, shipping choice, taxes, totals (pure function)
    settings.ts    zod schema + defaults for ShopSetting.data, secret masking/encryption
    secrets.ts     AES-256-GCM for provider secrets
    emails.ts      transactional email templates (escaped HTML + text)
    countries.ts   ISO country list
    payments/      PaymentProvider interface: offline (cod, bank_transfer) and stripe
  services/shop/
    shop-install.service.ts    product post type, taxonomies, settings row, data removal
    shop-settings.service.ts   read/write settings (secrets masked for the admin)
    products.service.ts        admin product CRUD (Post + ShopProduct + variants + terms)
    catalog.service.ts         public catalog (published products, categories, related)
    cart.service.ts            cookie cart → priced lines → totals
    coupons.service.ts         coupon CRUD + validation
    customers.service.ts       customer upsert + stats
    orders.service.ts          status machine, stock holds, emails, refunds, admin list
    checkout.service.ts        place order, Stripe confirm + webhooks, public order view
    reports.service.ts         overview numbers
    storefront-render.service.ts  runs the theme's shop/*.php with data
  controllers/shop/*, routes/shop.routes.ts, validators/shop.schema.ts
  models/shop-*.model.ts, db/migrations/20261104120000_shopping.ts
apps/web
  themes/beekiri/shop/           PHP templates, SCSS, script (see its README)
  src/app/{shop,product,cart,checkout}/…  Next.js routes that call the render API
  src/lib/shop.ts                fetch helpers for those routes
apps/admin/src
  screens/shop/*                 admin screens (api.ts holds the shared types)
  lib/extensions-state.ts        active-extension hook (menu, Spotlight, route guards)
docs/shopping/                   this documentation
```

### Data model

| Table | Purpose |
|---|---|
| `Post` (type `product`) | title, slug, description (content.html), short description (excerpt), featured image, SEO, revisions, categories/tags via `TermRelationship` |
| `ShopProduct` | 1:1 with the post: type, SKU, prices, stock, dimensions, gallery ids, attributes, visibility, total sales |
| `ShopProductVariant` | one purchasable combination of a variable product |
| `ShopCart` | server-side cart; the id is the `beekiri_cart` cookie token; items are `{productId, variantId, qty}` only |
| `ShopCustomer` | one row per email |
| `ShopOrder`, `ShopOrderItem`, `ShopOrderNote` | orders (snapshots of prices and addresses), lines, notes |
| `ShopCoupon` | discount codes |
| `ShopPaymentEvent` | every accepted webhook event id (idempotency) |
| `ShopSetting` | one row per site: settings JSON + next order number |

Every table has `siteId` and cascades from `Site`. Money is stored as **integers in the
currency's minor unit** (1999 = €19.99). Never store or compute money as floats.

The `product` post type, `product_cat` and `product_tag` taxonomies are ordinary rows created on
install; the slugs `product`, `shop`, `cart`, `checkout` are reserved so pages cannot collide.
`lib/pages/content-kind.ts` maps the `product` kind to the `edit_products` capability and the
`/product/{slug}` path, so `pagesService` (revisions, sanitising, slugs) is reused unchanged.

### Extension lifecycle

`extensionsService` keeps `SiteOptions.extensions[slug] = { installedAt, active }` and calls the
hooks in `services/shop/shop-install.service.ts`:

- `install` / `activate` → `ensureStructure()` (idempotent): post type, taxonomies, settings row.
- `deactivate` → marks the post type inactive (products stay), storefront + admin 404/hide.
- `uninstall({ deleteData })` → removes every shop row when asked (or when
  Settings → Advanced → *Remove data on uninstall* is on).

Everything under `/api/shop` passes `requireShopActive` and answers 404 while inactive. The admin
reads `GET /api/extensions/active` (any signed-in user) to show the Shop menu; the website reads
`GET /api/shop/public/config`.

## 2. API

Full route list with schemas: `apps/api/src/routes/shop.routes.ts` and
`validators/shop.schema.ts`; the OpenAPI document at `/api/docs` (administrators) includes them.

### Admin (session + capability)

| Method / path | Capability |
|---|---|
| `GET /api/shop/meta` | any shop cap — currency format, statuses, countries, taxonomy ids, published pages |
| `GET` / `PUT /api/shop/settings` | `manage_shop` |
| `GET /api/shop/products`, `POST`, `GET/PATCH/DELETE /:id`, `POST /:id/restore`, `/:id/duplicate`, `POST /products/bulk`, `GET /products/lookup` | `edit_products` |
| `GET /api/fields/taxonomies/:id/terms`, `PATCH/DELETE /api/fields/terms/:id` | `edit_products` (also pages/posts caps) |
| `GET /api/shop/orders`, `GET /:id`, `PATCH /:id`, `POST /:id/status`, `/:id/notes`, `DELETE /:id/notes/:noteId`, `POST /:id/refund`, `/:id/resend-email` | `edit_shop_orders` |
| `GET /api/shop/customers[/:id]`, `GET/POST /api/shop/coupons`, `GET/PATCH/DELETE /coupons/:id` | `edit_shop_orders` |
| `GET /api/shop/overview?range=` | `view_shop_reports` (or orders / settings caps) |

Product writes go through one endpoint: `PATCH /api/shop/products/:id` takes content fields
(`title`, `slug`, `status`, `description`, `shortDescription`, `featuredImageId`, `seo`),
`commerce` (prices, stock, attributes…), the full `variants` list (missing ids are deleted) and
`categoryIds` / `tagIds`.

### Storefront (public)

| Method / path | Notes |
|---|---|
| `GET /public/config` | active flag, paths, asset URLs, cart count |
| `GET /public/catalog?q&category&tag&sort&page&perPage&featured` | published products |
| `GET /public/categories`, `GET /public/products/:slug` | |
| `GET /public/cart` | |
| `POST /public/cart/items` `{productId, variantId?, qty}` | write |
| `PATCH /public/cart/items` `{key, qty}` (qty 0 removes) | write |
| `POST` / `DELETE /public/cart/coupon` | write |
| `GET /public/checkout`, `POST /public/checkout/shipping` `{country,state,postcode}` | shipping options for an address |
| `POST /public/checkout` (see `checkoutSchema`) | places the order → `{ redirectUrl, token, number }` |
| `POST /public/checkout/confirm` `{token, sessionId?}` | Stripe return: verifies the session server-side |
| `GET /public/orders/:token` | the shopper's order |
| `GET /public/view/:view` | rendered HTML for the website (shop, category, product, cart, checkout, order-received) |
| `GET /public/assets/styles.css`, `/script.js` | theme shop assets |
| `POST /webhooks/stripe` | Stripe events (signature verified) |

The cart lives in the HttpOnly cookie `beekiri_cart` (SameSite=Lax, Secure on https).
**Write** requests must send the header `X-Beekiri-Shop: 1` and come from the site's origin
(`requireStorefrontRequest`); plain cross-site forms therefore cannot change a cart or place an
order. Rate limits: cart 60/min, checkout 15 per 10 min, views 300/min.

## 3. Checkout and payments

`checkoutService.placeOrder` runs inside one database transaction:

1. re-validate the coupon under a row lock;
2. **reserve stock** — `ordersService.reserveStock` locks the product/variant rows
   (`FOR UPDATE`), checks quantities and decrements them;
3. take the next order number from the locked `ShopSetting` row;
4. upsert the customer, create the order and its line items (price snapshots);
5. for offline methods, move the order straight to *Processing* (COD) or *On hold* (bank
   transfer) and count the coupon use.

Only then is the payment provider called (network), outside the transaction. If the provider
fails, the order is marked *Failed* and the stock is released.

### Order status machine (`ordersService.transition`)

Stock is held while an order is `pending`, `on-hold`, `processing` or `completed`
(`STOCK_HOLDING_STATUSES`). Moving out of that set releases the quantities; moving back into it
reserves them again (and fails loudly if stock ran out). Product sales counters follow
`processing` / `completed`. Every transition writes a system note. Emails are sent by the caller
through `ordersService.notifyStatus` so transactions never wait on SMTP.

### Payment providers (`lib/shop/payments`)

```ts
interface PaymentProvider {
  id: 'cod' | 'bank_transfer' | 'stripe';
  start(order, ctx): Promise<{ kind: 'redirect'; url; ref } | { kind: 'offline'; ref }>;
  refund?(order, amountMinor, ctx, reason?): Promise<{ refundId }>;
}
```

To add a provider: implement the interface, register it in `payments/index.ts`, add its id to
`PAYMENT_METHODS` in `constants.ts`, its settings to `settings.ts`, its title in
`ordersService.paymentTitle`, and a card on the Settings → Payments screen.

**Stripe** uses hosted Checkout Sessions: line items at our unit prices, shipping as a
`shipping_options` entry, discounts as a one-off coupon, tax as a line when prices exclude tax.
The order is marked paid in two independent, idempotent ways:

- the **webhook** (`checkout.session.completed` / `async_payment_succeeded`): the signature is
  verified against the raw body (kept by `express.json({ verify })` in `app.ts`), each event id
  is stored once in `ShopPaymentEvent`, and the session's amount and currency must equal the
  order's;
- the **return URL**: the thank-you page calls `POST /public/checkout/confirm`, which retrieves
  the session from Stripe (never trusting query parameters) and applies the same checks.

`checkout.session.expired` and the periodic `sweepExpired` job (every 10 minutes, hold time from
Settings → Advanced) cancel unpaid card orders and release stock. `charge.refunded` keeps refund
totals in sync when a refund is made in the Stripe dashboard.

Provider secrets are stored encrypted (`lib/shop/secrets.ts`, key derived from
`CACHE_FLUSH_SECRET`) and returned masked to the admin; a blank or masked value on save keeps
the stored one.

## 4. Storefront rendering

The website's shop routes (`apps/web/src/app/shop`, `product/[slug]`, `cart`, `checkout`,
`checkout/order-received/[token]`) call `GET /api/shop/public/view/:view`. The API builds the
data, resolves `shop/{view}.php` from the active theme chain (child first) and runs it with the
same PHP runner as layouts (`lib/layouts/php/layout-runner.php`, now with a `--stdin` mode so
large payloads do not hit the command-line limit, and an optional prelude file:
`shop/_helpers.php`). The HTML is injected inside the site's header and footer; cart, checkout
and order pages forward the cart cookie and are never cached.

Template contract, data shapes and the hooks `script.js` depends on are documented in
`apps/web/themes/beekiri/shop/README.md`. `styles.scss` is compiled by the server when it
changes; both assets are loaded on every page while the shop is active (root layout), so the
header cart count and add-to-cart work anywhere.

The header template receives `shop { active, cart_path, shop_path }` and renders the cart link
with `[data-bk-cart-count]`.

### Shop pages designed in the editor (Shop → Shop Editor)

Every storefront page has a `Post` of type `shop_page` (slug = view: `shop`, `product`, `cart`,
`checkout`, `order-received`) created on activate (`shopPagesService.ensurePages`). Its
BeekiriCode document starts as a wrapper holding one **`shop_content`** node. The editor offers the
"Shop content" element only on shop pages (`AddPanel shopPage`), the public renderer
(`@beekiri/page-blocks`) emits `SHOP_SLOT_HTML` for it, and `components/ShopPageWrap.tsx` renders
the document, splits it at that marker and places the live template markup in between
(`ShopMain`). Documents without the marker render entirely above the shop content.
Routes: `GET /api/shop/pages` (list + "customised" flag), `POST /api/shop/pages/:view/reset`,
`GET /api/shop/public/pages/:view` (published document). The generic content routes
(`/api/content/shop_page/:id`) serve the editor; they use the kind's own capabilities
(`requireKindCapability`) and the slug is locked to the view name.

Per-page display options live in `settings.pages` and reach the templates as
`get_bee_field('shop')['options']` (columns, sidebar, breadcrumbs, related products…).

### Checkout fields

`settings.checkout.fields` (`checkoutFieldSchema`) defines the form: built-in fields
(`email`, `phone`, `billing.*`, `customerNote`) can be relabelled, reordered, hidden or made
required; custom fields (`custom.<slug>`, types text/email/tel/textarea/select/checkbox) are
added in the "Additional information" section. `lib/shop/checkout-fields.ts` applies the rules
on the server (`applyCheckoutFields`: hidden built-ins blanked, required checked, select options
enforced) and collects custom answers into `ShopOrder.customFields` (`{ [key]: { label, value } }`),
which the admin order detail, the public order page and the emails display. The checkout
template renders the form from `checkout.fields` (`checkoutFieldsForTemplate`); the storefront
script sends custom values as `extra[key]`.

### Shopper accounts

Shoppers are `ShopCustomer` rows with a `passwordHash` (argon2id) — never admin `User`s.
`services/shop/accounts.service.ts` handles register / login / logout / verify / forgot / reset /
details / addresses / orders. Sessions live in `ShopCustomerSession` (sha256 of the
`beekiri_customer` HttpOnly cookie, 24 h or 30 days with "keep me signed in"); one-time email links
in `ShopCustomerToken` (`verify` 48 h, `reset` 1 h, single use). Public routes are under
`/api/shop/public/account/*`, writes behind `requireStorefrontRequest` and rate limits (per IP and
per email for login).

Staff single sign-on: `currentCustomer(req)` first resolves the shopper cookie, then a valid
admin session (`beekiri_session` / `__Host-beekiri_session`) → `accountsService.forStaff(user)`,
which find-or-creates the customer row with the admin email (marked verified) and flags it
`staff` for the request; shop sign-out and password change are refused for staff. The website
forwards the admin cookie to the view API for that reason. Shopper sessions never authenticate
admin routes.

Privacy rule: because guest orders are linked by email, **order history and saved addresses are
returned only when `emailVerifiedAt` is set** (`accountsService.serialize` / `orders`). Password
reset counts as verification. `customersService.upsertFromOrder` never overwrites the profile of
a registered customer from a guest checkout; a signed-in checkout attaches the order to the
account (`placeOrder(…, signedIn)`), and "Create an account" at checkout registers first.

The website forwards both cookies for per-visitor views (`fetchShopView(…, { withCart: true })`);
`/account/[[...path]]` maps URLs to `view=account&section=…`. `shop/account.php` renders every
section; `script.js` posts the `[data-account-form]` forms and fills `[data-bk-account-name]` in
the header from `GET /public/account/me`.

### Fulfilment and tracking

`ShopOrder.fulfillment` (`unfulfilled → packed → shipped → delivered`, carrier, tracking number,
http(s) tracking link, timestamps) is set with `POST /api/shop/orders/:id/fulfillment`
(`ordersService.setFulfillment`; delivered completes the order, shipping an on-hold order moves it
to processing, emails `shipped` / `delivered`). `lib/shop/tracking.ts` (`buildTracking`) turns
status + payment + fulfilment into the shopper timeline used by My account, the order page and the
admin; `shop/partials/tracking.php` renders it (full or `compact`).

### Cart shipping estimate

`ShopCart.meta` stores the country and shipping method chosen on the cart page
(`POST /public/cart/shipping`); the cart view returns `estimate.options` and the checkout
preselects the method (`preferredShippingMethodId`). Prices are always recomputed at checkout.

## 5. Admin

Screens live in `apps/admin/src/screens/shop/`; `api.ts` holds the shared TypeScript types,
`useShopMeta()` (currency format, statuses, taxonomy ids) and money helpers. Styling reuses the
admin primitives (`.bk-panel`, `.form-table`, `.button`) plus `shop.css`.

Registration points touched for the Shop menu: `shell/AdminShell.tsx` (menu group, shown while
the extension is active and the user has a shop capability), `App.tsx` (`RequireShop` route
guard), `components/AdminSpotlightSearch.tsx` (items with `extension: 'shopping'`),
`lib/admin-capabilities.ts` (area caps), `screens/dashboard/*` (`shop` widget).

## 6. Capabilities and roles

`manage_shop`, `edit_products`, `edit_shop_orders`, `view_shop_reports` are defined in
`lib/auth/role-capabilities.ts` (API) and `cms-types.ts` (both apps). Administrators get all of
them; the `shop_manager` role (created by the migration) gets them plus `upload_files`,
`manage_categories`, `customize_dashboard`. The capability catalog group "Shopping" drives the
User Permissions screen.

## 7. Security notes

- Prices, totals, stock and coupon validity are always computed server-side from the database;
  the client only sends ids and quantities.
- Stock changes happen under row locks inside transactions; concurrent checkouts cannot oversell.
- Card data never touches Beekiri (hosted Stripe Checkout). Webhooks are signature-verified over
  the raw body and deduplicated; amounts and currency are compared to the order.
- Order pages are reachable only through a 32-byte random token; admin access needs
  `edit_shop_orders`.
- Public writes need the custom header + same-origin check; all endpoints are rate-limited.
- Product descriptions go through the same HTML sanitiser as pages for users without
  `unfiltered_html`. Email templates escape every value.
- Admin actions are written to the audit log (`extension.*`, `shop.settings_updated`,
  `product.*`, `order.status_changed`, `order.refunded`, `coupon.*`).

## 8. Tests

```bash
cd apps/api
npx vitest run test/shop.pricing.test.ts            # pure pricing / money / totals (no database)
TEST_DB_NAME=beekiri_shop_test npx vitest run test/shop.checkout.test.ts   # end-to-end on a throwaway DB
```

The integration test installs a site, installs the extension, creates a product, goes through the
public cart and checkout with cash on delivery, and checks stock, permissions, the storefront
header requirement and webhook signature rejection.

## 9. Extending

- **Another payment provider:** see §3.
- **Different shop design:** copy templates into the child theme (§4); keep the `data-*` hooks.
- **Extra product fields:** add columns to `ShopProduct` (migration + model), extend
  `productCommerceSchema`, `productsService.update/get`, the `ProductCommerce` type in the admin
  and the Product data tabs; expose them in `catalogService.serialize` for templates.
- **Customer accounts, downloads, reviews:** not in 1.0; the data model leaves room
  (`ShopCustomer`, `virtual` products).
