--
-- PostgreSQL database dump
--

\restrict uJeTKsCPESvZyq5pzdYoXTpHOjith4kenaCNmDxrdXgJwiDq2hnLmuFiT8nkAoI

-- Dumped from database version 16.14 (Homebrew)
-- Dumped by pg_dump version 16.14 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "siteId" text,
    "userId" text,
    action text NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    ip text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Capability; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Capability" (
    id text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL
);


--
-- Name: FieldGroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FieldGroup" (
    id text NOT NULL,
    "siteId" text NOT NULL,
    title text NOT NULL,
    key text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    location jsonb DEFAULT '[]'::jsonb NOT NULL,
    fields jsonb DEFAULT '[]'::jsonb NOT NULL,
    "menuOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: InstallationState; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."InstallationState" (
    id integer DEFAULT 1 NOT NULL,
    installed boolean DEFAULT false NOT NULL,
    "installedAt" timestamp(3) without time zone,
    "lockedAt" timestamp(3) without time zone,
    "lockOwner" text
);


--
-- Name: MediaAsset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MediaAsset" (
    id text NOT NULL,
    "siteId" text NOT NULL,
    filename text NOT NULL,
    "originalName" text NOT NULL,
    "mimeType" text NOT NULL,
    size integer NOT NULL,
    width integer,
    height integer,
    url text NOT NULL,
    "storagePath" text NOT NULL,
    "folderId" text,
    alt text DEFAULT ''::text NOT NULL,
    "uploadedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: OptionsPage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."OptionsPage" (
    id text NOT NULL,
    "siteId" text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    "menuTitle" text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "parentSlug" text DEFAULT ''::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "menuOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PasswordResetToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Post; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Post" (
    id text NOT NULL,
    "siteId" text NOT NULL,
    type text DEFAULT 'page'::text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    content jsonb DEFAULT '{"html": "", "version": 1}'::jsonb NOT NULL,
    excerpt text DEFAULT ''::text NOT NULL,
    "authorId" text,
    "parentId" text,
    "menuOrder" integer DEFAULT 0 NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "updatedById" text
);


--
-- Name: PostRevision; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PostRevision" (
    id text NOT NULL,
    "postId" text NOT NULL,
    "siteId" text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    status text NOT NULL,
    content jsonb NOT NULL,
    excerpt text DEFAULT ''::text NOT NULL,
    "authorId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PostType; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PostType" (
    id text NOT NULL,
    "siteId" text NOT NULL,
    slug text NOT NULL,
    singular text NOT NULL,
    plural text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    public boolean DEFAULT true NOT NULL,
    hierarchical boolean DEFAULT false NOT NULL,
    "hasArchive" boolean DEFAULT true NOT NULL,
    "showInMenu" boolean DEFAULT true NOT NULL,
    supports jsonb DEFAULT '["title", "editor"]'::jsonb NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "menuOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Role" (
    id text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL
);


--
-- Name: Session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "csrfSecret" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastSeenAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "absoluteExpiresAt" timestamp(3) without time zone NOT NULL,
    "idleExpiresAt" timestamp(3) without time zone NOT NULL,
    "userAgent" text,
    ip text
);


--
-- Name: Site; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Site" (
    id text NOT NULL,
    title text NOT NULL,
    tagline text DEFAULT ''::text NOT NULL,
    language text DEFAULT 'en_US'::text NOT NULL,
    "installedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: SiteSettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SiteSettings" (
    id text NOT NULL,
    "siteId" text NOT NULL,
    "blogPublic" boolean DEFAULT true NOT NULL,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    "dateFormat" text DEFAULT 'F j, Y'::text NOT NULL,
    "timeFormat" text DEFAULT 'g:i a'::text NOT NULL,
    options jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: Taxonomy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Taxonomy" (
    id text NOT NULL,
    "siteId" text NOT NULL,
    slug text NOT NULL,
    singular text NOT NULL,
    plural text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    hierarchical boolean DEFAULT true NOT NULL,
    public boolean DEFAULT true NOT NULL,
    "objectTypes" jsonb DEFAULT '["post"]'::jsonb NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "menuOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "siteId" text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    "displayName" text NOT NULL,
    "passwordHash" text NOT NULL,
    "roleId" text NOT NULL,
    "isOwner" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    profile jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: _CapabilityToRole; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."_CapabilityToRole" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditLog" (id, "siteId", "userId", action, meta, ip, "createdAt") FROM stdin;
cmvp4o99r001cs78vg88pidp8	cmvp4o9990017s78vudcddjbv	cmvp4o999001as78v5manxit3	site.installed	{"language": "en_US", "blogPublic": true}	127.0.0.1	2026-10-26 10:42:47.151
cmvp4xn550000s7py865d0t16	\N	\N	auth.login_failed	{"login": "beekiritest"}	127.0.0.1	2026-10-26 10:50:05.033
cmvp4yedr0004s7pybzb997nw	cmvp4o9990017s78vudcddjbv	cmvp4o999001as78v5manxit3	auth.login	{"remember": false}	127.0.0.1	2026-10-26 10:50:40.335
cmvp9889w0000s7mlqqn65z90	\N	\N	auth.login_failed	{"login": "Altin"}	127.0.0.1	2026-10-26 12:50:17.444
cmvp98cyx0001s7ml3cak8c9a	\N	\N	auth.login_failed	{"login": "Altin"}	127.0.0.1	2026-10-26 12:50:23.53
cmvp98eio0002s7mlv9h1jnig	\N	\N	auth.login_failed	{"login": "Altin"}	127.0.0.1	2026-10-26 12:50:25.536
cmvp98gi80003s7mlzqugj05m	\N	\N	auth.login_failed	{"login": "Altin"}	127.0.0.1	2026-10-26 12:50:28.112
cmvp98h2v0007s7ml7uuq03k9	cmvp4o9990017s78vudcddjbv	cmvp4o999001as78v5manxit3	auth.login	{"remember": false}	127.0.0.1	2026-10-26 12:50:28.856
cmvpg5thk0003s7f2mg7tj4fa	cmvp4o9990017s78vudcddjbv	cmvp4o999001as78v5manxit3	user.created	{"role": "editor", "username": "TestUser", "targetUserId": "cmvpg5th90001s7f2cncbl1b3"}	\N	2026-10-26 16:04:22.28
cmvph1vau0003s7zaagstkvnr	cmvp4o9990017s78vudcddjbv	cmvp4o999001as78v5manxit3	field_group.created	{"key": "group_hero", "groupId": "cmvph1vap0001s7zae1ttdv0v"}	\N	2026-10-26 16:29:17.622
cmvpoqgmq0003s7yauv5hbnov	cmvp4o9990017s78vudcddjbv	cmvp4o999001as78v5manxit3	field_group.updated	{"key": "group_hero", "groupId": "cmvph1vap0001s7zae1ttdv0v"}	\N	2026-10-26 20:04:22.323
cmvps2l780002s7mmc5zjs0zj	cmvp4o9990017s78vudcddjbv	cmvp4o999001as78v5manxit3	field_group.updated	{"key": "group_hero", "groupId": "cmvph1vap0001s7zae1ttdv0v"}	\N	2026-10-26 21:37:46.964
cmvpvfi2p0005s7hafj72asml	cmvp4o9990017s78vudcddjbv	cmvp4o999001as78v5manxit3	field_group.created	{"key": "group_acf_demo", "groupId": "cmvpvfi2i0003s7haf7wr506h"}	\N	2026-10-26 23:11:48.289
cmvpvim5l0007s7halvn4kmce	cmvp4o9990017s78vudcddjbv	cmvp4o999001as78v5manxit3	field_group.deleted	{"key": "group_acf_demo", "groupId": "cmvpvfi2i0003s7haf7wr506h"}	\N	2026-10-26 23:14:13.546
cmvpvm4rh0007s7m37crxfiab	cmvp4o9990017s78vudcddjbv	cmvp4o999001as78v5manxit3	field_group.updated	{"key": "group_hero", "groupId": "cmvph1vap0001s7zae1ttdv0v"}	\N	2026-10-26 23:16:57.63
cmvqkkqff0000s7cq91uraxms	\N	\N	auth.login_failed	{"login": "altin"}	127.0.0.1	2026-10-27 10:55:42.795
cmvqkmemz0001s7cq20k5i47i	\N	\N	auth.login_failed	{"login": "Altin"}	127.0.0.1	2026-10-27 10:57:00.828
cmvqkmle00005s7cqyz0v7cbd	cmvp4o9990017s78vudcddjbv	cmvp4o999001as78v5manxit3	auth.login	{"remember": false}	127.0.0.1	2026-10-27 10:57:09.577
cmvqkrwig0009s7cqzm1b22pz	cmvp4o9990017s78vudcddjbv	cmvp4o999001as78v5manxit3	field_group.updated	{"key": "group_hero", "groupId": "cmvph1vap0001s7zae1ttdv0v"}	\N	2026-10-27 11:01:17.273
cmvqmn8al0003s75e0s9kylhn	cmvp4o9990017s78vudcddjbv	cmvp4o999001as78v5manxit3	auth.login	{"remember": false}	127.0.0.1	2026-10-27 11:53:38.493
\.


--
-- Data for Name: Capability; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Capability" (id, slug, name) FROM stdin;
cmvp4o96f0001s78vsen8wrh9	manage_options	manage_options
cmvp4o96s0002s78vr4cbp7ru	edit_users	edit_users
cmvp4o96w0003s78v2cbap9w0	list_users	list_users
cmvp4o96y0004s78vixegk2ss	create_users	create_users
cmvp4o9700005s78vjko2ggpw	delete_users	delete_users
cmvp4o9720006s78vap61g2iu	edit_posts	edit_posts
cmvp4o9740007s78vgznd2zl3	edit_others_posts	edit_others_posts
cmvp4o9750008s78vcd525y07	publish_posts	publish_posts
cmvp4o9770009s78v0ox47m0f	delete_posts	delete_posts
cmvp4o978000as78v325aqsbq	edit_pages	edit_pages
cmvp4o979000bs78vv2jbrd2c	edit_others_pages	edit_others_pages
cmvp4o97b000cs78vvglzdou3	publish_pages	publish_pages
cmvp4o97c000ds78v5gazgyaa	delete_pages	delete_pages
cmvp4o97d000es78vf1wikjcx	upload_files	upload_files
cmvp4o97e000fs78vtxy17kp9	moderate_comments	moderate_comments
cmvp4o97h000gs78v5wxbc2je	manage_categories	manage_categories
cmvp4o97i000hs78vhnxz333z	edit_theme_options	edit_theme_options
cmvp4o97k000is78vsli30im0	read	read
\.


--
-- Data for Name: FieldGroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."FieldGroup" (id, "siteId", title, key, description, active, location, fields, "menuOrder", "createdAt", "updatedAt") FROM stdin;
cmvph1vap0001s7zae1ttdv0v	cmvp4o9990017s78vudcddjbv	Hero	group_hero		t	["post", "page"]	[{"id": "field_sx0cftt", "name": "title", "type": "text", "label": "Title", "choices": [], "required": false, "defaultValue": "", "instructions": ""}, {"id": "field_fvy9isp", "name": "image", "type": "image", "label": "Image", "choices": [], "required": false, "defaultValue": "", "instructions": ""}, {"id": "field_6b6q0fk3i", "name": "repeater_test", "type": "repeater", "label": "Repeater Test", "choices": [], "required": false, "subFields": [{"id": "field_bqm0h33w0", "name": "title", "type": "wysiwyg", "label": "Title", "choices": [], "required": false, "defaultValue": "", "instructions": ""}], "defaultValue": "", "instructions": ""}]	0	2026-10-26 16:29:17.617	2026-10-27 11:01:17.271
\.


--
-- Data for Name: InstallationState; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."InstallationState" (id, installed, "installedAt", "lockedAt", "lockOwner") FROM stdin;
1	t	2026-10-26 10:42:47.149	\N	\N
\.


--
-- Data for Name: MediaAsset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."MediaAsset" (id, "siteId", filename, "originalName", "mimeType", size, width, height, url, "storagePath", "folderId", alt, "uploadedById", "createdAt", "updatedAt") FROM stdin;
cmvphgpzo0005s7zapcrp7whl	cmvp4o9990017s78vudcddjbv	screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp	Screenshot 2026-10-26 at 16.31.18.png	image/webp	320838	1307	850	/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp	2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp	\N		cmvp4o999001as78v5manxit3	2026-10-26 16:40:50.58	2026-10-26 16:48:08.065
\.


--
-- Data for Name: OptionsPage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."OptionsPage" (id, "siteId", title, slug, "menuTitle", description, "parentSlug", active, "menuOrder", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PasswordResetToken" (id, "userId", "tokenHash", "expiresAt", "usedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: Post; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Post" (id, "siteId", type, title, slug, status, content, excerpt, "authorId", "parentId", "menuOrder", "publishedAt", "createdAt", "updatedAt", "updatedById") FROM stdin;
cmvqmnz810001s779022zi89z	cmvp4o9990017s78vudcddjbv	post	Hello Post	hello-post	publish	{"html": "<p>Hello from a single post.</p>", "preview": null, "version": 2, "beekiricode": {"nodes": {"t1": {"id": "t1", "tag": "h1", "text": "Hello Post", "type": "heading", "children": []}, "root": {"id": "root", "type": "root", "children": ["t1"]}}, "rootId": "root", "version": 1}, "beekiricanva": null}	A single post	\N	\N	0	2026-10-27 11:54:13.392	2026-10-27 11:54:13.393	2026-10-27 11:54:13.393	\N
cmvqn61mo0001s7w0hul9la88	cmvp4o9990017s78vudcddjbv	page	Home	home	publish	{"html": "<section class=\\"bk-section\\"><h1 class=\\"bk-heading\\">This is homepage test 1</h1><p class=\\"bk-text\\">Double-click text to edit. Use Add to drop modules onto the canvas.</p></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"h_ukitld9i": {"id": "h_ukitld9i", "tag": "h1", "text": "This is homepage test 1", "type": "heading", "style": {"margin": "0", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_dn3xq1in": {"id": "t_dn3xq1in", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas.", "type": "text", "style": {"color": "#444444", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "sec_z6rrz7c1": {"id": "sec_z6rrz7c1", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "flexDirection": "column"}, "children": ["h_ukitld9i", "t_dn3xq1in"]}, "root_y1cfc4qw": {"id": "root_y1cfc4qw", "tag": "div", "type": "section", "style": {"gap": "24px", "color": "#111111", "width": "100%", "display": "flex", "minHeight": "100%", "background": "#ffffff", "paddingTop": "48px", "paddingLeft": "32px", "paddingRight": "32px", "flexDirection": "column", "paddingBottom": "48px"}, "children": ["sec_z6rrz7c1"]}}, "rootId": "root_y1cfc4qw", "version": 1}, "beekiricanva": null}		cmvp4o999001as78v5manxit3	\N	0	2026-10-27 12:08:31.113	2026-10-27 12:08:16.318	2026-10-27 12:33:32.921	cmvp4o999001as78v5manxit3
cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	page	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">Amazing workf</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"height": "50px", "display": "flex", "minHeight": "50px", "textAlign": "center", "alignItems": "center", "justifyContent": "center"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "Amazing workf", "repeater_test": [{"title": "Amazing work"}, {"title": "Test"}]}, "stylesByBreakpoint": {"tablet": {"backgroundColor": "#B8420F"}}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "0px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "0px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	\N	0	2026-10-26 17:21:34.922	2026-10-26 17:21:34.923	2026-10-27 11:03:16.881	cmvp4o999001as78v5manxit3
\.


--
-- Data for Name: PostRevision; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PostRevision" (id, "postId", "siteId", title, slug, status, content, excerpt, "authorId", "createdAt") FROM stdin;
cmvpql4al000gs72fjfzf4uu9	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<main style=\\"gap:12;color:#111111;display:flex;min-height:100%;background:#ffffff;padding-top:48px 24px;padding-left:48px 24px;padding-right:48px 24px;flex-direction:column;padding-bottom:24px\\"><section style=\\"gap:12px;display:flex;max-width:720px;flex-direction:column\\"><h1 style=\\"margin:0;padding:;font-size:40px;font-weight:650;line-height:1.15;color:#c44545\\">New section asfasfasfasf</h1><p style=\\"color:#d67a7a;margin:0;font-size:16px;line-height:1.55\\">Double-click text to edit. Use Add to drop modules onto the canvas. asfsafasf</p></section><a href=\\"#\\" style=\\"color:#ffffff;width:fit-content;display:inline-flex;padding:10px 18px;font-size:14px;align-items:center;background:#111111;font-weight:600;border-radius:6px;justify-content:center;text-decoration:none\\">Button</a><img src=\\"\\" alt=\\"\\" style=\\"width:100%;height:auto;display:block;max-width:640px;object-fit:cover\\" /></main>", "blocks": [], "preview": null, "version": 2, "instatic": {"nodes": {"h_mc66v4by": {"id": "h_mc66v4by", "tag": "h1", "text": "New section asfasfasfasf", "type": "heading", "style": {"color": "#c44545", "margin": "0", "padding": "", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_j2klqn9d": {"id": "t_j2klqn9d", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas. asfsafasf", "type": "text", "style": {"color": "#d67a7a", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "btn_2bph1ccg": {"id": "btn_2bph1ccg", "tag": "a", "href": "#", "text": "Button", "type": "button", "style": {"color": "#ffffff", "width": "fit-content", "display": "inline-flex", "padding": "10px 18px", "fontSize": "14px", "alignItems": "center", "background": "#111111", "fontWeight": "600", "borderRadius": "6px", "justifyContent": "center", "textDecoration": "none"}, "children": []}, "img_rt2qp0lv": {"id": "img_rt2qp0lv", "alt": "", "src": "", "tag": "img", "type": "image", "style": {"width": "100%", "height": "auto", "display": "block", "maxWidth": "640px", "objectFit": "cover"}, "children": []}, "sec_n6l31r0t": {"id": "sec_n6l31r0t", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_mc66v4by", "t_j2klqn9d"]}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "background": "#ffffff", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px"}, "children": ["sec_n6l31r0t", "btn_2bph1ccg", "img_rt2qp0lv"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 20:56:12.285
cmvpql7d6000is72f9g0bh22i	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	draft	{"html": "<main style=\\"gap:12;color:#111111;display:flex;min-height:100%;background:#ffffff;padding-top:48px 24px;padding-left:48px 24px;padding-right:48px 24px;flex-direction:column;padding-bottom:24px\\"><section style=\\"gap:12px;display:flex;max-width:720px;flex-direction:column\\"><h1 style=\\"color:#c44545;margin:0;padding:;font-size:40px;font-weight:650;line-height:1.15\\">New section asfasfasfasf</h1><p style=\\"color:#d67a7a;margin:0;font-size:16px;line-height:1.55\\">Double-click text to edit. Use Add to drop modules onto the canvas. asfsafasf</p></section><a href=\\"#\\" style=\\"color:#ffffff;width:fit-content;display:inline-flex;padding:10px 18px;font-size:14px;align-items:center;background:#111111;font-weight:600;border-radius:6px;justify-content:center;text-decoration:none\\">Button</a><img src=\\"\\" alt=\\"\\" style=\\"width:100%;height:auto;display:block;max-width:640px;object-fit:cover\\" /></main>", "blocks": [], "preview": null, "version": 2, "instatic": {"nodes": {"h_mc66v4by": {"id": "h_mc66v4by", "tag": "h1", "text": "New section asfasfasfasf", "type": "heading", "style": {"color": "#c44545", "margin": "0", "padding": "", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_j2klqn9d": {"id": "t_j2klqn9d", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas. asfsafasf", "type": "text", "style": {"color": "#d67a7a", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "btn_2bph1ccg": {"id": "btn_2bph1ccg", "tag": "a", "href": "#", "text": "Button", "type": "button", "style": {"color": "#ffffff", "width": "fit-content", "display": "inline-flex", "padding": "10px 18px", "fontSize": "14px", "alignItems": "center", "background": "#111111", "fontWeight": "600", "borderRadius": "6px", "justifyContent": "center", "textDecoration": "none"}, "children": []}, "img_rt2qp0lv": {"id": "img_rt2qp0lv", "alt": "", "src": "", "tag": "img", "type": "image", "style": {"width": "100%", "height": "auto", "display": "block", "maxWidth": "640px", "objectFit": "cover"}, "children": []}, "sec_n6l31r0t": {"id": "sec_n6l31r0t", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_mc66v4by", "t_j2klqn9d"]}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "background": "#ffffff", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px"}, "children": ["sec_n6l31r0t", "btn_2bph1ccg", "img_rt2qp0lv"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 20:56:16.266
cmvpql7yf000ks72fkwx9rdp6	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<main style=\\"gap:12;color:#111111;display:flex;min-height:100%;background:#ffffff;padding-top:48px 24px;padding-left:48px 24px;padding-right:48px 24px;flex-direction:column;padding-bottom:24px\\"><section style=\\"gap:12px;display:flex;max-width:720px;flex-direction:column\\"><h1 style=\\"color:#c44545;margin:0;padding:;font-size:40px;font-weight:650;line-height:1.15\\">New section asfasfasfasf</h1><p style=\\"color:#d67a7a;margin:0;font-size:16px;line-height:1.55\\">Double-click text to edit. Use Add to drop modules onto the canvas. asfsafasf</p></section><a href=\\"#\\" style=\\"color:#ffffff;width:fit-content;display:inline-flex;padding:10px 18px;font-size:14px;align-items:center;background:#111111;font-weight:600;border-radius:6px;justify-content:center;text-decoration:none\\">Button</a><img src=\\"\\" alt=\\"\\" style=\\"width:100%;height:auto;display:block;max-width:640px;object-fit:cover\\" /></main>", "blocks": [], "preview": null, "version": 2, "instatic": {"nodes": {"h_mc66v4by": {"id": "h_mc66v4by", "tag": "h1", "text": "New section asfasfasfasf", "type": "heading", "style": {"color": "#c44545", "margin": "0", "padding": "", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_j2klqn9d": {"id": "t_j2klqn9d", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas. asfsafasf", "type": "text", "style": {"color": "#d67a7a", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "btn_2bph1ccg": {"id": "btn_2bph1ccg", "tag": "a", "href": "#", "text": "Button", "type": "button", "style": {"color": "#ffffff", "width": "fit-content", "display": "inline-flex", "padding": "10px 18px", "fontSize": "14px", "alignItems": "center", "background": "#111111", "fontWeight": "600", "borderRadius": "6px", "justifyContent": "center", "textDecoration": "none"}, "children": []}, "img_rt2qp0lv": {"id": "img_rt2qp0lv", "alt": "", "src": "", "tag": "img", "type": "image", "style": {"width": "100%", "height": "auto", "display": "block", "maxWidth": "640px", "objectFit": "cover"}, "children": []}, "sec_n6l31r0t": {"id": "sec_n6l31r0t", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_mc66v4by", "t_j2klqn9d"]}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "background": "#ffffff", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px"}, "children": ["sec_n6l31r0t", "btn_2bph1ccg", "img_rt2qp0lv"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 20:56:17.031
cmvpqwyl9000ms72fr5gg2n2m	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<main style=\\"gap:12;color:#111111;display:flex;min-height:100%;background:#ffffff;padding-top:48px 24px;padding-left:48px 24px;padding-right:48px 24px;flex-direction:column;padding-bottom:24px\\"><section style=\\"gap:12px;display:flex;max-width:720px;flex-direction:column\\"><h1 style=\\"color:#c44545;margin:0;padding:;font-size:40px;font-weight:650;line-height:1.15\\">New section asfasfasfasf</h1><p style=\\"color:#d67a7a;margin:0;font-size:16px;line-height:1.55\\">Double-click text to edit. Use Add to drop modules onto the canvas. asfsafasf</p></section><a href=\\"#\\" style=\\"color:#ffffff;width:fit-content;display:inline-flex;padding:10px 18px;font-size:14px;align-items:center;background:#111111;font-weight:600;border-radius:6px;justify-content:center;text-decoration:none\\">Button</a><img src=\\"\\" alt=\\"\\" style=\\"width:100%;height:auto;display:block;max-width:640px;object-fit:cover\\" /></main>", "blocks": [], "preview": null, "version": 2, "instatic": {"nodes": {"h_mc66v4by": {"id": "h_mc66v4by", "tag": "h1", "text": "New section asfasfasfasf", "type": "heading", "style": {"color": "#c44545", "margin": "0", "padding": "", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_j2klqn9d": {"id": "t_j2klqn9d", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas. asfsafasf", "type": "text", "style": {"color": "#d67a7a", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "btn_2bph1ccg": {"id": "btn_2bph1ccg", "tag": "a", "href": "#", "text": "Button", "type": "button", "style": {"color": "#ffffff", "width": "fit-content", "display": "inline-flex", "padding": "10px 18px", "fontSize": "14px", "alignItems": "center", "background": "#111111", "fontWeight": "600", "borderRadius": "6px", "justifyContent": "center", "textDecoration": "none"}, "children": []}, "img_rt2qp0lv": {"id": "img_rt2qp0lv", "alt": "", "src": "", "tag": "img", "type": "image", "style": {"width": "100%", "height": "auto", "display": "block", "maxWidth": "640px", "objectFit": "cover"}, "children": []}, "sec_n6l31r0t": {"id": "sec_n6l31r0t", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_mc66v4by", "t_j2klqn9d"]}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "background": "#ffffff", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px"}, "children": ["sec_n6l31r0t", "btn_2bph1ccg", "img_rt2qp0lv"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 21:05:24.765
cmvprcnl2000os72fht6anuof	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<style>.bk-in-root_ev8or7fp{gap:12;color:#111111;display:flex;min-height:100%;padding-top:48px 24px;padding-left:48px 24px;padding-right:48px 24px;flex-direction:column;padding-bottom:24px;background-color:#bb6868}.bk-in-sec_n6l31r0t{gap:12px;display:flex;max-width:720px;flex-direction:column}.bk-in-h_mc66v4by{color:#c44545;margin:0;padding:;font-size:40px;font-weight:650;line-height:1.15}.bk-in-t_j2klqn9d{color:#d67a7a;margin:0;font-size:16px;line-height:1.55}.bk-in-btn_2bph1ccg{color:#ffffff;width:fit-content;display:inline-flex;padding:10px 18px;font-size:14px;align-items:center;background:#111111;font-weight:600;border-radius:6px;justify-content:center;text-decoration:none}.bk-in-img_rt2qp0lv{width:100%;height:auto;display:block;max-width:640px;object-fit:cover}</style><main class=\\"bk-in-root_ev8or7fp\\"><section class=\\"bk-in-sec_n6l31r0t\\"><h1 class=\\"bk-in-h_mc66v4by\\">New section asfasfasfasf</h1><p class=\\"bk-in-t_j2klqn9d\\">Double-click text to edit. Use Add to drop modules onto the canvas. asfsafasf</p></section><a href=\\"#\\" class=\\"bk-in-btn_2bph1ccg\\">Button</a><img src=\\"\\" alt=\\"\\" class=\\"bk-in-img_rt2qp0lv\\" /></main>", "blocks": [], "preview": null, "version": 2, "instatic": {"nodes": {"h_mc66v4by": {"id": "h_mc66v4by", "tag": "h1", "text": "New section asfasfasfasf", "type": "heading", "style": {"color": "#c44545", "margin": "0", "padding": "", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_j2klqn9d": {"id": "t_j2klqn9d", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas. asfsafasf", "type": "text", "style": {"color": "#d67a7a", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "btn_2bph1ccg": {"id": "btn_2bph1ccg", "tag": "a", "href": "#", "text": "Button", "type": "button", "style": {"color": "#ffffff", "width": "fit-content", "display": "inline-flex", "padding": "10px 18px", "fontSize": "14px", "alignItems": "center", "background": "#111111", "fontWeight": "600", "borderRadius": "6px", "justifyContent": "center", "textDecoration": "none"}, "children": []}, "img_rt2qp0lv": {"id": "img_rt2qp0lv", "alt": "", "src": "", "tag": "img", "type": "image", "style": {"width": "100%", "height": "auto", "display": "block", "maxWidth": "640px", "objectFit": "cover"}, "children": []}, "sec_n6l31r0t": {"id": "sec_n6l31r0t", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_mc66v4by", "t_j2klqn9d"]}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px", "backgroundColor": "#bb6868"}, "children": ["sec_n6l31r0t", "btn_2bph1ccg", "img_rt2qp0lv"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 21:17:36.998
cmvpsgj0p0001s7isb9txwl5l	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<style>.bk-in-root_ev8or7fp{gap:12;color:#111111;display:flex;min-height:100%;padding-top:48px 24px;padding-left:48px 24px;padding-right:48px 24px;flex-direction:column;padding-bottom:24px;background-color:#bb6868}.bk-in-sec_n6l31r0t{gap:12px;display:flex;max-width:720px;flex-direction:column}.bk-in-h_mc66v4by{color:#c44545;margin:0;padding:;font-size:40px;font-weight:400;line-height:1.15;font-style:italic}.bk-in-t_j2klqn9d{color:#d67a7a;margin:0;font-size:16px;line-height:1.55}.bk-in-btn_2bph1ccg{color:#ffffff;width:fit-content;display:inline-flex;padding:10px 18px;font-size:14px;align-items:center;background:#111111;font-weight:600;border-radius:6px;justify-content:center;text-decoration:none}.bk-in-img_rt2qp0lv{width:100%;height:auto;display:block;max-width:640px;object-fit:cover}</style><main class=\\"bk-in-root_ev8or7fp\\"><section class=\\"bk-in-sec_n6l31r0t\\"><h1 class=\\"bk-in-h_mc66v4by\\">New section asfasfasfasf</h1><p class=\\"bk-in-t_j2klqn9d\\">Double-click text to edit. Use Add to drop modules onto the canvas. asfsafasf</p></section><a href=\\"#\\" class=\\"bk-in-btn_2bph1ccg\\">Button</a><img src=\\"\\" alt=\\"\\" class=\\"bk-in-img_rt2qp0lv\\" /></main>", "blocks": [], "preview": null, "version": 2, "instatic": {"nodes": {"h_mc66v4by": {"id": "h_mc66v4by", "tag": "h1", "text": "New section asfasfasfasf", "type": "heading", "style": {"color": "#c44545", "margin": "0", "padding": "", "fontSize": "40px", "fontStyle": "italic", "fontWeight": "400", "lineHeight": "1.15"}, "children": []}, "t_j2klqn9d": {"id": "t_j2klqn9d", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas. asfsafasf", "type": "text", "style": {"color": "#d67a7a", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "btn_2bph1ccg": {"id": "btn_2bph1ccg", "tag": "a", "href": "#", "text": "Button", "type": "button", "style": {"color": "#ffffff", "width": "fit-content", "display": "inline-flex", "padding": "10px 18px", "fontSize": "14px", "alignItems": "center", "background": "#111111", "fontWeight": "600", "borderRadius": "6px", "justifyContent": "center", "textDecoration": "none"}, "children": []}, "img_rt2qp0lv": {"id": "img_rt2qp0lv", "alt": "", "src": "", "tag": "img", "type": "image", "style": {"width": "100%", "height": "auto", "display": "block", "maxWidth": "640px", "objectFit": "cover"}, "children": []}, "sec_n6l31r0t": {"id": "sec_n6l31r0t", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_mc66v4by", "t_j2klqn9d"]}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px", "backgroundColor": "#bb6868"}, "children": ["sec_n6l31r0t", "btn_2bph1ccg", "img_rt2qp0lv"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 21:48:37.32
cmvptk6s50001s7a0wixzdjbl	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<style>.bk-in-root_ev8or7fp{gap:12;color:#111111;display:flex;min-height:100%;padding-top:48px 24px;padding-left:48px 24px;padding-right:48px 24px;flex-direction:column;padding-bottom:24px;background-color:#bb6868}.bk-in-sec_n6l31r0t{gap:12px;display:flex;max-width:720px;flex-direction:column}.bk-in-h_mc66v4by{color:#c44545;margin:0;padding:;font-size:40px;font-style:italic;font-weight:400;line-height:1.15}.bk-in-t_j2klqn9d{color:#d67a7a;margin:0;font-size:16px;line-height:1.55}.bk-in-lay_wcfmd34c{display:flex;flex-direction:column;gap:12px;padding:32px 24px;border:1px dashed #c5c5c5;border-radius:4px;background:#fafafa}.bk-in-btn_2bph1ccg{color:#ffffff;width:fit-content;display:inline-flex;padding:10px 18px;font-size:14px;align-items:center;background:#111111;font-weight:600;border-radius:6px;justify-content:center;text-decoration:none}.bk-in-img_rt2qp0lv{width:100%;height:auto;display:block;max-width:640px;object-fit:cover}</style><main class=\\"bk-in-root_ev8or7fp\\"><section class=\\"bk-in-sec_n6l31r0t\\"><h1 class=\\"bk-in-h_mc66v4by\\">New section asfasfasfasf</h1><p class=\\"bk-in-t_j2klqn9d\\">Double-click text to edit. Use Add to drop modules onto the canvas. asfsafasf</p><section class=\\"hero section bk-layout bk-layout--hero bk-in-lay_wcfmd34c\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><p class=\\"bk-layout__label\\">Hero</p></div></div></section></section><a href=\\"#\\" class=\\"bk-in-btn_2bph1ccg\\">Button</a><img src=\\"\\" alt=\\"\\" class=\\"bk-in-img_rt2qp0lv\\" /></main>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"h_mc66v4by": {"id": "h_mc66v4by", "tag": "h1", "text": "New section asfasfasfasf", "type": "heading", "style": {"color": "#c44545", "margin": "0", "padding": "", "fontSize": "40px", "fontStyle": "italic", "fontWeight": "400", "lineHeight": "1.15"}, "children": []}, "t_j2klqn9d": {"id": "t_j2klqn9d", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas. asfsafasf", "type": "text", "style": {"color": "#d67a7a", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "btn_2bph1ccg": {"id": "btn_2bph1ccg", "tag": "a", "href": "#", "text": "Button", "type": "button", "style": {"color": "#ffffff", "width": "fit-content", "display": "inline-flex", "padding": "10px 18px", "fontSize": "14px", "alignItems": "center", "background": "#111111", "fontWeight": "600", "borderRadius": "6px", "justifyContent": "center", "textDecoration": "none"}, "children": []}, "img_rt2qp0lv": {"id": "img_rt2qp0lv", "alt": "", "src": "", "tag": "img", "type": "image", "style": {"width": "100%", "height": "auto", "display": "block", "maxWidth": "640px", "objectFit": "cover"}, "children": []}, "lay_wcfmd34c": {"id": "lay_wcfmd34c", "tag": "section", "text": "Hero", "type": "layout", "style": {"gap": "12px", "border": "1px dashed #c5c5c5", "display": "flex", "padding": "32px 24px", "background": "#fafafa", "borderRadius": "4px", "flexDirection": "column"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": ""}}, "sec_n6l31r0t": {"id": "sec_n6l31r0t", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_mc66v4by", "t_j2klqn9d", "lay_wcfmd34c"]}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px", "backgroundColor": "#bb6868"}, "children": ["sec_n6l31r0t", "btn_2bph1ccg", "img_rt2qp0lv"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 22:19:27.701
cmvpto0000003s7a06qlysokw	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><p class=\\"bk-layout__label\\">Hero</p></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": ""}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px", "backgroundColor": "#bb6868"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 22:22:25.535
cmvptohkw0005s7a01e3lbc42	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><p class=\\"bk-layout__label\\">Hero</p></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": ""}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 22:22:48.321
cmvptvfof0001s7f2exnkh8ag	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "This is tEsttt"}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 22:28:12.447
cmvpuif620003s7f28l211p5f	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "This is tEsttt"}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 22:46:04.874
cmvpuj75l0005s7f2qajy7v96	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"height": "50px", "display": "block", "minHeight": "50px"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "This is tEsttt"}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 22:46:41.145
cmvpukd4b0007s7f2dnbesfh9	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"height": "50px", "display": "flex", "minHeight": "50px", "alignItems": "center", "justifyContent": "center"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "This is tEsttt"}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 22:47:35.531
cmvpukosu0009s7f2t37d78hr	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"height": "50px", "display": "flex", "minHeight": "50px", "alignItems": "center", "justifyContent": "center", "backgroundColor": "#0284C7"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "This is tEsttt"}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 22:47:50.67
cmvpuljci000bs7f2rn2v1au5	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"height": "50px", "display": "flex", "minHeight": "50px", "alignItems": "center", "justifyContent": "center"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "This is tEsttt"}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "48px 24px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "24px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 22:48:30.258
cmvpumfx7000ds7f2wklqlei2	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"height": "50px", "display": "flex", "minHeight": "50px", "textAlign": "center", "alignItems": "center", "justifyContent": "center"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "This is tEsttt"}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "0px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "0px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 22:49:12.476
cmvpurrt9000fs7f2tb5h4g4a	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "blocks": [], "preview": {"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "title": "About", "token": "b5c0976751fd4563d104a29ba0da5c257bbed073be344f80", "excerpt": "", "expiresAt": "2026-10-27T22:52:52.859Z", "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"color": "#A1A1AA", "height": "50px", "display": "flex", "minHeight": "50px", "textAlign": "center", "alignItems": "center", "justifyContent": "center"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "This is tEsttt"}, "stylesByBreakpoint": {"tablet": {"backgroundColor": "#B8420F"}}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "0px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "0px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"height": "50px", "display": "flex", "minHeight": "50px", "textAlign": "center", "alignItems": "center", "justifyContent": "center"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "This is tEsttt"}, "stylesByBreakpoint": {"tablet": {"backgroundColor": "#B8420F"}}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "0px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "0px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 22:53:21.166
cmvpvdqsl0001s7hap6mvlwgw	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"color": "#A1A1AA", "height": "50px", "display": "flex", "minHeight": "50px", "textAlign": "center", "alignItems": "center", "justifyContent": "center"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "This is tEsttt"}, "stylesByBreakpoint": {"tablet": {"backgroundColor": "#B8420F"}}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "0px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "0px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 23:10:26.277
cmvpvko710001s7m393xqo9ji	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"color": "#A1A1AA", "height": "50px", "display": "flex", "minHeight": "50px", "textAlign": "center", "alignItems": "center", "justifyContent": "center"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "This is tEsttt"}, "stylesByBreakpoint": {"tablet": {"backgroundColor": "#B8420F"}}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "0px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "0px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 23:15:49.501
cmvpvkuob0003s7m3t7u49ms1	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><figure class=\\"bk-layout__field bk-layout__field--image\\"><img src=\\"cmvphgpzo0005s7zapcrp7whl\\" alt=\\"\\" loading=\\"lazy\\" decoding=\\"async\\" /></figure><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"color": "#A1A1AA", "height": "50px", "display": "flex", "minHeight": "50px", "textAlign": "center", "alignItems": "center", "justifyContent": "center"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "cmvphgpzo0005s7zapcrp7whl", "title": "This is tEsttt"}, "stylesByBreakpoint": {"tablet": {"backgroundColor": "#B8420F"}}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "0px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "0px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 23:15:57.899
cmvpvlo9e0005s7m38g0a6z30	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"color": "#A1A1AA", "height": "50px", "display": "flex", "minHeight": "50px", "textAlign": "center", "alignItems": "center", "justifyContent": "center"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "This is tEsttt"}, "stylesByBreakpoint": {"tablet": {"backgroundColor": "#B8420F"}}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "0px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "0px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 23:16:36.242
cmvpvypqs0001s72jhef7ul3h	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"color": "#A1A1AA", "height": "50px", "display": "flex", "minHeight": "50px", "textAlign": "center", "alignItems": "center", "justifyContent": "center"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "This is tEsttt"}, "stylesByBreakpoint": {"tablet": {"backgroundColor": "#B8420F"}}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "0px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "0px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-26 23:26:44.692
cmvqkp7ld0007s7cqmpmwvrdv	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">This is tEsttt</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"height": "50px", "display": "flex", "minHeight": "50px", "textAlign": "center", "alignItems": "center", "justifyContent": "center"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "This is tEsttt"}, "stylesByBreakpoint": {"tablet": {"backgroundColor": "#B8420F"}}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "0px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "0px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-27 10:59:11.665
cmvqkshh9000bs7cqaozkkq5w	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">Amazing work</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"height": "50px", "display": "flex", "minHeight": "50px", "textAlign": "center", "alignItems": "center", "justifyContent": "center"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "Amazing work"}, "stylesByBreakpoint": {"tablet": {"backgroundColor": "#B8420F"}}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "0px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "0px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-27 11:01:44.445
cmvqkugsr000es7cqrom37ozs	cmvpix4230001s7nwpgpr20pl	cmvp4o9990017s78vudcddjbv	About	about	publish	{"html": "<section class=\\"hero section bk-layout bk-layout--hero\\" data-layout=\\"hero\\"><div class=\\"wrapper\\"><div class=\\"inner\\"><div class=\\"bk-layout__field bk-layout__field--title\\">Amazing work</div></div></div></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"lay_oad5r7ao": {"id": "lay_oad5r7ao", "tag": "section", "text": "Hero", "type": "layout", "style": {"height": "50px", "display": "flex", "minHeight": "50px", "textAlign": "center", "alignItems": "center", "justifyContent": "center"}, "children": [], "layoutSlug": "hero", "layoutTitle": "Hero", "layoutFields": {"image": "", "title": "Amazing work", "repeater_test": [{"title": "Amazing work"}, {"title": "Test"}]}, "stylesByBreakpoint": {"tablet": {"backgroundColor": "#B8420F"}}}, "root_ev8or7fp": {"id": "root_ev8or7fp", "tag": "main", "type": "section", "style": {"gap": "12", "color": "#111111", "display": "flex", "minHeight": "100%", "paddingTop": "0px", "paddingLeft": "48px 24px", "paddingRight": "48px 24px", "flexDirection": "column", "paddingBottom": "0px", "backgroundColor": "#FFFFFF"}, "children": ["lay_oad5r7ao"]}}, "rootId": "root_ev8or7fp", "version": 1}, "beekiricanva": {"root": {"props": {}}, "zones": {}, "content": [{"type": "Hero", "props": {"id": "Hero-83957c8e-e549-49de-8685-9eda7278ccbe", "image": "/uploads/2026/10/screenshot-2026-10-26-at-16.31.18-cba2762b0489.webp", "title": "Taaa"}}]}}		cmvp4o999001as78v5manxit3	2026-10-27 11:03:16.875
cmvqn6mrk0003s7w0i96e42wx	cmvqn61mo0001s7w0hul9la88	cmvp4o9990017s78vudcddjbv		auto-draft-1793102896277	publish	{"html": "<section class=\\"bk-section\\"><h1 class=\\"bk-heading\\">This is homepage</h1><p class=\\"bk-text\\">Double-click text to edit. Use Add to drop modules onto the canvas.</p></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"h_ukitld9i": {"id": "h_ukitld9i", "tag": "h1", "text": "This is homepage", "type": "heading", "style": {"margin": "0", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_dn3xq1in": {"id": "t_dn3xq1in", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas.", "type": "text", "style": {"color": "#444444", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "sec_z6rrz7c1": {"id": "sec_z6rrz7c1", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_ukitld9i", "t_dn3xq1in"]}, "root_y1cfc4qw": {"id": "root_y1cfc4qw", "tag": "div", "type": "section", "style": {"gap": "24px", "color": "#111111", "display": "flex", "padding": "48px 24px", "minHeight": "100%", "background": "#ffffff", "flexDirection": "column"}, "children": ["sec_z6rrz7c1"]}}, "rootId": "root_y1cfc4qw", "version": 1}, "beekiricanva": null}		cmvp4o999001as78v5manxit3	2026-10-27 12:08:43.713
cmvqn9zus0005s7w0z0wby4h2	cmvqn61mo0001s7w0hul9la88	cmvp4o9990017s78vudcddjbv		auto-draft-1793102896277	publish	{"html": "<section class=\\"bk-section\\"><h1 class=\\"bk-heading\\">This is homepage</h1><p class=\\"bk-text\\">Double-click text to edit. Use Add to drop modules onto the canvas.</p></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"h_ukitld9i": {"id": "h_ukitld9i", "tag": "h1", "text": "This is homepage", "type": "heading", "style": {"margin": "0", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_dn3xq1in": {"id": "t_dn3xq1in", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas.", "type": "text", "style": {"color": "#444444", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "sec_z6rrz7c1": {"id": "sec_z6rrz7c1", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_ukitld9i", "t_dn3xq1in"]}, "root_y1cfc4qw": {"id": "root_y1cfc4qw", "tag": "div", "type": "section", "style": {"gap": "24px", "color": "#111111", "display": "flex", "padding": "48px 24px", "minHeight": "100%", "background": "#ffffff", "flexDirection": "column"}, "children": ["sec_z6rrz7c1"]}}, "rootId": "root_y1cfc4qw", "version": 1}, "beekiricanva": null}		cmvp4o999001as78v5manxit3	2026-10-27 12:11:20.645
cmvqncobw0007s7w0mks11xht	cmvqn61mo0001s7w0hul9la88	cmvp4o9990017s78vudcddjbv	Home	h	publish	{"html": "<section class=\\"bk-section\\"><h1 class=\\"bk-heading\\">This is homepage</h1><p class=\\"bk-text\\">Double-click text to edit. Use Add to drop modules onto the canvas.</p></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"h_ukitld9i": {"id": "h_ukitld9i", "tag": "h1", "text": "This is homepage", "type": "heading", "style": {"margin": "0", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_dn3xq1in": {"id": "t_dn3xq1in", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas.", "type": "text", "style": {"color": "#444444", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "sec_z6rrz7c1": {"id": "sec_z6rrz7c1", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_ukitld9i", "t_dn3xq1in"]}, "root_y1cfc4qw": {"id": "root_y1cfc4qw", "tag": "div", "type": "section", "style": {"gap": "24px", "color": "#111111", "display": "flex", "padding": "48px 24px", "minHeight": "100%", "background": "#ffffff", "flexDirection": "column"}, "children": ["sec_z6rrz7c1"]}}, "rootId": "root_y1cfc4qw", "version": 1}, "beekiricanva": null}		cmvp4o999001as78v5manxit3	2026-10-27 12:13:25.677
cmvqnel5z0009s7w0qo8cv732	cmvqn61mo0001s7w0hul9la88	cmvp4o9990017s78vudcddjbv	Home	h	publish	{"html": "<section class=\\"bk-section\\"><h1 class=\\"bk-heading\\">This is homepage</h1><p class=\\"bk-text\\">Double-click text to edit. Use Add to drop modules onto the canvas.</p></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"h_ukitld9i": {"id": "h_ukitld9i", "tag": "h1", "text": "This is homepage", "type": "heading", "style": {"margin": "0", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_dn3xq1in": {"id": "t_dn3xq1in", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas.", "type": "text", "style": {"color": "#444444", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "sec_z6rrz7c1": {"id": "sec_z6rrz7c1", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_ukitld9i", "t_dn3xq1in"]}, "root_y1cfc4qw": {"id": "root_y1cfc4qw", "tag": "div", "type": "section", "style": {"gap": "24px", "color": "#111111", "display": "flex", "padding": "48px 24px", "minHeight": "100%", "background": "#ffffff", "flexDirection": "column"}, "children": ["sec_z6rrz7c1"]}}, "rootId": "root_y1cfc4qw", "version": 1}, "beekiricanva": null}		cmvp4o999001as78v5manxit3	2026-10-27 12:14:54.888
cmvqnhq8i000es7w0m684n1ce	cmvqn61mo0001s7w0hul9la88	cmvp4o9990017s78vudcddjbv	Home	h	publish	{"html": "<section class=\\"bk-section\\"><h1 class=\\"bk-heading\\">This is homepage</h1><p class=\\"bk-text\\">Double-click text to edit. Use Add to drop modules onto the canvas.</p></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"h_ukitld9i": {"id": "h_ukitld9i", "tag": "h1", "text": "This is homepage", "type": "heading", "style": {"margin": "0", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_dn3xq1in": {"id": "t_dn3xq1in", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas.", "type": "text", "style": {"color": "#444444", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "sec_z6rrz7c1": {"id": "sec_z6rrz7c1", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_ukitld9i", "t_dn3xq1in"]}, "root_y1cfc4qw": {"id": "root_y1cfc4qw", "tag": "div", "type": "section", "style": {"gap": "24px", "color": "#111111", "display": "flex", "padding": "48px 24px", "minHeight": "100%", "background": "#ffffff", "flexDirection": "column"}, "children": ["sec_z6rrz7c1"]}}, "rootId": "root_y1cfc4qw", "version": 1}, "beekiricanva": null}		cmvp4o999001as78v5manxit3	2026-10-27 12:17:21.425
cmvqni3jx000gs7w0dr11kumg	cmvqn61mo0001s7w0hul9la88	cmvp4o9990017s78vudcddjbv	Home	h	publish	{"html": "<section class=\\"bk-section\\"><h1 class=\\"bk-heading\\">This is homepage test</h1><p class=\\"bk-text\\">Double-click text to edit. Use Add to drop modules onto the canvas.</p></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"h_ukitld9i": {"id": "h_ukitld9i", "tag": "h1", "text": "This is homepage test", "type": "heading", "style": {"margin": "0", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_dn3xq1in": {"id": "t_dn3xq1in", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas.", "type": "text", "style": {"color": "#444444", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "sec_z6rrz7c1": {"id": "sec_z6rrz7c1", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_ukitld9i", "t_dn3xq1in"]}, "root_y1cfc4qw": {"id": "root_y1cfc4qw", "tag": "div", "type": "section", "style": {"gap": "24px", "color": "#111111", "display": "flex", "padding": "48px 24px", "minHeight": "100%", "background": "#ffffff", "flexDirection": "column"}, "children": ["sec_z6rrz7c1"]}}, "rootId": "root_y1cfc4qw", "version": 1}, "beekiricanva": null}		cmvp4o999001as78v5manxit3	2026-10-27 12:17:38.685
cmvqnoqxg000is7w0qnp9q8fd	cmvqn61mo0001s7w0hul9la88	cmvp4o9990017s78vudcddjbv	Home	home	publish	{"html": "<section class=\\"bk-section\\"><h1 class=\\"bk-heading\\">This is homepage test</h1><p class=\\"bk-text\\">Double-click text to edit. Use Add to drop modules onto the canvas.</p></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"h_ukitld9i": {"id": "h_ukitld9i", "tag": "h1", "text": "This is homepage test", "type": "heading", "style": {"margin": "0", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_dn3xq1in": {"id": "t_dn3xq1in", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas.", "type": "text", "style": {"color": "#444444", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "sec_z6rrz7c1": {"id": "sec_z6rrz7c1", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_ukitld9i", "t_dn3xq1in"]}, "root_y1cfc4qw": {"id": "root_y1cfc4qw", "tag": "div", "type": "section", "style": {"gap": "24px", "color": "#111111", "display": "flex", "padding": "48px 24px", "minHeight": "100%", "background": "#ffffff", "flexDirection": "column"}, "children": ["sec_z6rrz7c1"]}}, "rootId": "root_y1cfc4qw", "version": 1}, "beekiricanva": null}		cmvp4o999001as78v5manxit3	2026-10-27 12:22:48.916
cmvqnphh6000ks7w02t07u9h3	cmvqn61mo0001s7w0hul9la88	cmvp4o9990017s78vudcddjbv	Home	home	publish	{"html": "<section class=\\"bk-section\\"><h1 class=\\"bk-heading\\">This is homepage test</h1><p class=\\"bk-text\\">Double-click text to edit. Use Add to drop modules onto the canvas.</p></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"h_ukitld9i": {"id": "h_ukitld9i", "tag": "h1", "text": "This is homepage test", "type": "heading", "style": {"margin": "0", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_dn3xq1in": {"id": "t_dn3xq1in", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas.", "type": "text", "style": {"color": "#444444", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "sec_z6rrz7c1": {"id": "sec_z6rrz7c1", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "maxWidth": "720px", "flexDirection": "column"}, "children": ["h_ukitld9i", "t_dn3xq1in"]}, "root_y1cfc4qw": {"id": "root_y1cfc4qw", "tag": "div", "type": "section", "style": {"gap": "24px", "color": "#111111", "width": "100%", "display": "flex", "padding": "48px 24px", "minHeight": "100%", "background": "#ffffff", "flexDirection": "column"}, "children": ["sec_z6rrz7c1"]}}, "rootId": "root_y1cfc4qw", "version": 1}, "beekiricanva": null}		cmvp4o999001as78v5manxit3	2026-10-27 12:23:23.323
cmvqo2ayh000ms7w08l92flab	cmvqn61mo0001s7w0hul9la88	cmvp4o9990017s78vudcddjbv	Home	home	publish	{"html": "<section class=\\"bk-section\\"><h1 class=\\"bk-heading\\">This is homepage test</h1><p class=\\"bk-text\\">Double-click text to edit. Use Add to drop modules onto the canvas.</p></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"h_ukitld9i": {"id": "h_ukitld9i", "tag": "h1", "text": "This is homepage test", "type": "heading", "style": {"margin": "0", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_dn3xq1in": {"id": "t_dn3xq1in", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas.", "type": "text", "style": {"color": "#444444", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "sec_z6rrz7c1": {"id": "sec_z6rrz7c1", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "flexDirection": "column"}, "children": ["h_ukitld9i", "t_dn3xq1in"]}, "root_y1cfc4qw": {"id": "root_y1cfc4qw", "tag": "div", "type": "section", "style": {"gap": "24px", "color": "#111111", "width": "100%", "display": "flex", "padding": "48px 24px", "minHeight": "100%", "background": "#ffffff", "flexDirection": "column"}, "children": ["sec_z6rrz7c1"]}}, "rootId": "root_y1cfc4qw", "version": 1}, "beekiricanva": null}		cmvp4o999001as78v5manxit3	2026-10-27 12:33:21.399
cmvqo2juc000os7w00uhxgisi	cmvqn61mo0001s7w0hul9la88	cmvp4o9990017s78vudcddjbv	Home	home	publish	{"html": "<section class=\\"bk-section\\"><h1 class=\\"bk-heading\\">This is homepage test 1</h1><p class=\\"bk-text\\">Double-click text to edit. Use Add to drop modules onto the canvas.</p></section>", "blocks": [], "preview": null, "version": 2, "beekiricode": {"nodes": {"h_ukitld9i": {"id": "h_ukitld9i", "tag": "h1", "text": "This is homepage test 1", "type": "heading", "style": {"margin": "0", "fontSize": "40px", "fontWeight": "650", "lineHeight": "1.15"}, "children": []}, "t_dn3xq1in": {"id": "t_dn3xq1in", "tag": "p", "text": "Double-click text to edit. Use Add to drop modules onto the canvas.", "type": "text", "style": {"color": "#444444", "margin": "0", "fontSize": "16px", "lineHeight": "1.55"}, "children": []}, "sec_z6rrz7c1": {"id": "sec_z6rrz7c1", "tag": "section", "type": "section", "style": {"gap": "12px", "display": "flex", "flexDirection": "column"}, "children": ["h_ukitld9i", "t_dn3xq1in"]}, "root_y1cfc4qw": {"id": "root_y1cfc4qw", "tag": "div", "type": "section", "style": {"gap": "24px", "color": "#111111", "width": "100%", "display": "flex", "padding": "48px 24px", "minHeight": "100%", "background": "#ffffff", "flexDirection": "column"}, "children": ["sec_z6rrz7c1"]}}, "rootId": "root_y1cfc4qw", "version": 1}, "beekiricanva": null}		cmvp4o999001as78v5manxit3	2026-10-27 12:33:32.917
\.


--
-- Data for Name: PostType; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PostType" (id, "siteId", slug, singular, plural, description, public, hierarchical, "hasArchive", "showInMenu", supports, active, "menuOrder", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Role" (id, slug, name) FROM stdin;
cmvp4o9640000s78vdyy8hm2n	administrator	Administrator
cmvp4o97m000js78vh2e3bd79	editor	Editor
cmvp4o982000ws78vcgxk0fjj	author	Author
cmvp4o98a0012s78vmp6yg2bi	contributor	Contributor
cmvp4o98d0015s78vx5lg6l9g	subscriber	Subscriber
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Session" (id, "userId", "tokenHash", "csrfSecret", "createdAt", "lastSeenAt", "absoluteExpiresAt", "idleExpiresAt", "userAgent", ip) FROM stdin;
cmvp98h2q0005s7ml7bajf6cc	cmvp4o999001as78v5manxit3	6aa19fc7134b0a36e00c89877d19c0849d2299c99e5a66e558a12cdce50ba6a5	CV202AsoHFP7UEiwf01x6Ck_rpPilKgt	2026-10-26 12:50:28.85	2026-10-26 23:45:34.712	2026-11-02 12:50:28.849	2026-10-27 23:45:34.712	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/3.24.9 Chrome/148.0.7778.280 Electron/42.10.0 Safari/537.36	127.0.0.1
cmvqmn8a60001s75ekt03l1x2	cmvp4o999001as78v5manxit3	1682d8a71c95949881515e58fe4df0aba2576dfdb8ee9017f5978719bff984f9	9ObdGiV2jPkoQ1LdYyztOwvW0Sf7K7rG	2026-10-27 11:53:38.478	2026-10-27 11:53:38.511	2026-11-03 11:53:38.477	2026-10-28 11:53:38.511	curl/8.7.1	127.0.0.1
cmvp4yedi0002s7pys8b83rpp	cmvp4o999001as78v5manxit3	18115a68384c06dc0cc80d4fa605e434e9f9259281d9ecd664736483b065674e	u7PtPUX_SvXPWPsUM8_Uy6R9pO9Hwfgh	2026-10-26 10:50:40.326	2026-10-27 10:48:04.738	2026-11-02 10:50:40.325	2026-10-28 10:48:04.738	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36	127.0.0.1
cmvqkmldr0003s7cq61cesqpr	cmvp4o999001as78v5manxit3	06ee1633eac2cbc5fb17426ce9e265c76f789030733e3602d0eb6e0c42850362	MAe5WiZN8Vxe18YsUUd3_UQVT4cM_N6j	2026-10-27 10:57:09.568	2026-10-27 13:29:38.554	2026-11-03 10:57:09.566	2026-10-28 13:29:38.554	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36	127.0.0.1
\.


--
-- Data for Name: Site; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Site" (id, title, tagline, language, "installedAt", "createdAt", "updatedAt") FROM stdin;
cmvp4o9990017s78vudcddjbv	BeekiriTest		en_US	2026-10-26 10:42:47.133	2026-10-26 10:42:47.133	2026-10-26 10:42:47.133
\.


--
-- Data for Name: SiteSettings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SiteSettings" (id, "siteId", "blogPublic", timezone, "dateFormat", "timeFormat", options) FROM stdin;
cmvp4o9990018s78vpxk5bcae	cmvp4o9990017s78vudcddjbv	t	UTC	F j, Y	g:i a	{"media": {"folders": [{"id": "general", "name": "General", "slug": "general", "parentId": null}], "maxWidth": 1920, "maxHeight": 1920, "webpQuality": 100, "keepOriginal": false, "webpLossless": true, "convertToWebp": true, "stripMetadata": true}, "menuItems": [{"id": "item-vgpic2i", "path": "/", "label": "Home", "refId": "home", "source": "home", "enabled": true}, {"id": "blog", "path": "/blog", "label": "Blog", "source": "home", "enabled": true}, {"id": "about", "path": "/about", "label": "About", "source": "custom", "enabled": true, "children": [{"id": "about-team", "path": "/about/team", "label": "Team", "source": "custom", "enabled": true, "children": [{"id": "item-sjdlvug", "path": "/about/team/test", "label": "test", "source": "custom", "enabled": true}]}]}, {"id": "contact", "path": "/contact", "label": "Contact", "source": "custom", "enabled": false}], "frontPageId": "home", "frontPageSlug": "home", "frontendRuntime": "php", "pageEditorStyle": "beekiricode", "permalinkCustom": "/%postname%/", "permalinkStructure": "postname"}
\.


--
-- Data for Name: Taxonomy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Taxonomy" (id, "siteId", slug, singular, plural, description, hierarchical, public, "objectTypes", active, "menuOrder", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, "siteId", username, email, "displayName", "passwordHash", "roleId", "isOwner", "createdAt", "updatedAt", profile) FROM stdin;
cmvpg5th90001s7f2cncbl1b3	cmvp4o9990017s78vudcddjbv	TestUser	test@test.local	Test User	$argon2id$v=19$m=19456,t=2,p=1$N34x/SXajXePCc7ISxMFhw$JS6S4MNci1SFWsA8U+JavSeVo0NRKceHya8NSWE2MjM	cmvp4o97m000js78vh2e3bd79	f	2026-10-26 16:04:22.268	2026-10-26 16:04:22.268	{}
cmvp4o999001as78v5manxit3	cmvp4o9990017s78vudcddjbv	Altin	dev@996agency.com	Altin	$argon2id$v=19$m=19456,t=2,p=1$Yv/aUWjqyXR4wY9/FWi4hw$agUOSmeqwRvSYwaWgJiy7kD/yQfYNGvpHmFWAtp/UEk	cmvp4o9640000s78vdyy8hm2n	t	2026-10-26 10:42:47.133	2026-10-27 10:57:05.664	{}
\.


--
-- Data for Name: _CapabilityToRole; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."_CapabilityToRole" ("A", "B") FROM stdin;
cmvp4o96f0001s78vsen8wrh9	cmvp4o9640000s78vdyy8hm2n
cmvp4o96s0002s78vr4cbp7ru	cmvp4o9640000s78vdyy8hm2n
cmvp4o96w0003s78v2cbap9w0	cmvp4o9640000s78vdyy8hm2n
cmvp4o96y0004s78vixegk2ss	cmvp4o9640000s78vdyy8hm2n
cmvp4o9700005s78vjko2ggpw	cmvp4o9640000s78vdyy8hm2n
cmvp4o9720006s78vap61g2iu	cmvp4o9640000s78vdyy8hm2n
cmvp4o9740007s78vgznd2zl3	cmvp4o9640000s78vdyy8hm2n
cmvp4o9750008s78vcd525y07	cmvp4o9640000s78vdyy8hm2n
cmvp4o9770009s78v0ox47m0f	cmvp4o9640000s78vdyy8hm2n
cmvp4o978000as78v325aqsbq	cmvp4o9640000s78vdyy8hm2n
cmvp4o979000bs78vv2jbrd2c	cmvp4o9640000s78vdyy8hm2n
cmvp4o97b000cs78vvglzdou3	cmvp4o9640000s78vdyy8hm2n
cmvp4o97c000ds78v5gazgyaa	cmvp4o9640000s78vdyy8hm2n
cmvp4o97d000es78vf1wikjcx	cmvp4o9640000s78vdyy8hm2n
cmvp4o97e000fs78vtxy17kp9	cmvp4o9640000s78vdyy8hm2n
cmvp4o97h000gs78v5wxbc2je	cmvp4o9640000s78vdyy8hm2n
cmvp4o97i000hs78vhnxz333z	cmvp4o9640000s78vdyy8hm2n
cmvp4o97k000is78vsli30im0	cmvp4o9640000s78vdyy8hm2n
cmvp4o9720006s78vap61g2iu	cmvp4o97m000js78vh2e3bd79
cmvp4o9740007s78vgznd2zl3	cmvp4o97m000js78vh2e3bd79
cmvp4o9750008s78vcd525y07	cmvp4o97m000js78vh2e3bd79
cmvp4o9770009s78v0ox47m0f	cmvp4o97m000js78vh2e3bd79
cmvp4o978000as78v325aqsbq	cmvp4o97m000js78vh2e3bd79
cmvp4o979000bs78vv2jbrd2c	cmvp4o97m000js78vh2e3bd79
cmvp4o97b000cs78vvglzdou3	cmvp4o97m000js78vh2e3bd79
cmvp4o97c000ds78v5gazgyaa	cmvp4o97m000js78vh2e3bd79
cmvp4o97d000es78vf1wikjcx	cmvp4o97m000js78vh2e3bd79
cmvp4o97e000fs78vtxy17kp9	cmvp4o97m000js78vh2e3bd79
cmvp4o97h000gs78v5wxbc2je	cmvp4o97m000js78vh2e3bd79
cmvp4o97k000is78vsli30im0	cmvp4o97m000js78vh2e3bd79
cmvp4o9720006s78vap61g2iu	cmvp4o982000ws78vcgxk0fjj
cmvp4o9750008s78vcd525y07	cmvp4o982000ws78vcgxk0fjj
cmvp4o9770009s78v0ox47m0f	cmvp4o982000ws78vcgxk0fjj
cmvp4o97d000es78vf1wikjcx	cmvp4o982000ws78vcgxk0fjj
cmvp4o97k000is78vsli30im0	cmvp4o982000ws78vcgxk0fjj
cmvp4o9720006s78vap61g2iu	cmvp4o98a0012s78vmp6yg2bi
cmvp4o97k000is78vsli30im0	cmvp4o98a0012s78vmp6yg2bi
cmvp4o97k000is78vsli30im0	cmvp4o98d0015s78vx5lg6l9g
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
aae9f48d-8ce8-4cf6-b185-4d15a60cc5af	ee6a430216fc976e0ef576b1b9b085a67c4f522e35549203a6263ea3fab52632	2026-10-26 10:05:42.675732+01	20261026090542_init	\N	\N	2026-10-26 10:05:42.197793+01	1
82e45e86-babd-4296-be13-55eb7864fb31	3f68b448c4892d8f91046927084e81eb9fb1f359942f554d7e4166f8a9f02fa7	2026-10-26 16:12:16.050752+01	20261026151216_media_assets	\N	\N	2026-10-26 16:12:16.043349+01	1
311f020c-3478-4325-9372-d69b7be3ba0b	df53542d38eec34cb710eb72c20dba5b70b2921a80fe884d81bdc0fbbe44d2fd	2026-10-26 16:52:56.369285+01	20261026155256_user_profile	\N	\N	2026-10-26 16:52:56.367634+01	1
dd9d64a1-986c-4ff3-9668-9b14479b3e77	d7fbf2812c553cf32ff7b2667c15417125414e89358746fb5d520b433d420753	2026-10-26 17:13:24.821054+01	20261026161324_field_groups	\N	\N	2026-10-26 17:13:24.812144+01	1
887ac64a-a2d6-4a5e-836c-9177fb9477c7	d02e66e78da2bd50ddcb6e37ad29cc5127c8f49e42ebf7dd3cc1ca6a8755ab8f	2026-10-26 17:25:03.934005+01	20261026162503_fields_structure	\N	\N	2026-10-26 17:25:03.911146+01	1
839d59f7-4905-4fa9-bdd5-0c0340c21305	a2d9f998a31a6654f4b075208637d7007d8219117352d52691c4fef2a4745021	2026-10-26 18:20:04.718709+01	20261026172004_add_posts_pages	\N	\N	2026-10-26 18:20:04.704349+01	1
5bd11106-f0d4-4c06-a8d9-618383965e10	ed319a94628bacf3b2803aa71e3f38ccf94032feb0013ec7c31b1ef524b536e8	2026-10-26 19:26:50.878508+01	20261026182645_post_revisions_updated_by	\N	\N	2026-10-26 19:26:50.873425+01	1
\.


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: Capability Capability_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Capability"
    ADD CONSTRAINT "Capability_pkey" PRIMARY KEY (id);


--
-- Name: FieldGroup FieldGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FieldGroup"
    ADD CONSTRAINT "FieldGroup_pkey" PRIMARY KEY (id);


--
-- Name: InstallationState InstallationState_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InstallationState"
    ADD CONSTRAINT "InstallationState_pkey" PRIMARY KEY (id);


--
-- Name: MediaAsset MediaAsset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MediaAsset"
    ADD CONSTRAINT "MediaAsset_pkey" PRIMARY KEY (id);


--
-- Name: OptionsPage OptionsPage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OptionsPage"
    ADD CONSTRAINT "OptionsPage_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: PostRevision PostRevision_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PostRevision"
    ADD CONSTRAINT "PostRevision_pkey" PRIMARY KEY (id);


--
-- Name: PostType PostType_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PostType"
    ADD CONSTRAINT "PostType_pkey" PRIMARY KEY (id);


--
-- Name: Post Post_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_pkey" PRIMARY KEY (id);


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: SiteSettings SiteSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SiteSettings"
    ADD CONSTRAINT "SiteSettings_pkey" PRIMARY KEY (id);


--
-- Name: Site Site_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Site"
    ADD CONSTRAINT "Site_pkey" PRIMARY KEY (id);


--
-- Name: Taxonomy Taxonomy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Taxonomy"
    ADD CONSTRAINT "Taxonomy_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _CapabilityToRole _CapabilityToRole_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."_CapabilityToRole"
    ADD CONSTRAINT "_CapabilityToRole_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AuditLog_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_action_idx" ON public."AuditLog" USING btree (action);


--
-- Name: AuditLog_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_createdAt_idx" ON public."AuditLog" USING btree ("createdAt");


--
-- Name: Capability_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Capability_slug_key" ON public."Capability" USING btree (slug);


--
-- Name: FieldGroup_menuOrder_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "FieldGroup_menuOrder_idx" ON public."FieldGroup" USING btree ("menuOrder");


--
-- Name: FieldGroup_siteId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "FieldGroup_siteId_idx" ON public."FieldGroup" USING btree ("siteId");


--
-- Name: FieldGroup_siteId_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "FieldGroup_siteId_key_key" ON public."FieldGroup" USING btree ("siteId", key);


--
-- Name: MediaAsset_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "MediaAsset_createdAt_idx" ON public."MediaAsset" USING btree ("createdAt");


--
-- Name: MediaAsset_folderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "MediaAsset_folderId_idx" ON public."MediaAsset" USING btree ("folderId");


--
-- Name: MediaAsset_siteId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "MediaAsset_siteId_idx" ON public."MediaAsset" USING btree ("siteId");


--
-- Name: OptionsPage_siteId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "OptionsPage_siteId_idx" ON public."OptionsPage" USING btree ("siteId");


--
-- Name: OptionsPage_siteId_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "OptionsPage_siteId_slug_key" ON public."OptionsPage" USING btree ("siteId", slug);


--
-- Name: PasswordResetToken_tokenHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PasswordResetToken_tokenHash_key" ON public."PasswordResetToken" USING btree ("tokenHash");


--
-- Name: PasswordResetToken_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PasswordResetToken_userId_idx" ON public."PasswordResetToken" USING btree ("userId");


--
-- Name: PostRevision_postId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PostRevision_postId_createdAt_idx" ON public."PostRevision" USING btree ("postId", "createdAt");


--
-- Name: PostRevision_siteId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PostRevision_siteId_idx" ON public."PostRevision" USING btree ("siteId");


--
-- Name: PostType_siteId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PostType_siteId_idx" ON public."PostType" USING btree ("siteId");


--
-- Name: PostType_siteId_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PostType_siteId_slug_key" ON public."PostType" USING btree ("siteId", slug);


--
-- Name: Post_siteId_type_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Post_siteId_type_slug_key" ON public."Post" USING btree ("siteId", type, slug);


--
-- Name: Post_siteId_type_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Post_siteId_type_status_idx" ON public."Post" USING btree ("siteId", type, status);


--
-- Name: Post_siteId_type_updatedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Post_siteId_type_updatedAt_idx" ON public."Post" USING btree ("siteId", type, "updatedAt");


--
-- Name: Role_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Role_slug_key" ON public."Role" USING btree (slug);


--
-- Name: Session_tokenHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Session_tokenHash_key" ON public."Session" USING btree ("tokenHash");


--
-- Name: Session_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Session_userId_idx" ON public."Session" USING btree ("userId");


--
-- Name: SiteSettings_siteId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SiteSettings_siteId_key" ON public."SiteSettings" USING btree ("siteId");


--
-- Name: Taxonomy_siteId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Taxonomy_siteId_idx" ON public."Taxonomy" USING btree ("siteId");


--
-- Name: Taxonomy_siteId_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Taxonomy_siteId_slug_key" ON public."Taxonomy" USING btree ("siteId", slug);


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_siteId_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_siteId_email_key" ON public."User" USING btree ("siteId", email);


--
-- Name: User_siteId_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_siteId_username_key" ON public."User" USING btree ("siteId", username);


--
-- Name: User_username_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_username_idx" ON public."User" USING btree (username);


--
-- Name: _CapabilityToRole_B_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "_CapabilityToRole_B_index" ON public."_CapabilityToRole" USING btree ("B");


--
-- Name: AuditLog AuditLog_siteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES public."Site"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FieldGroup FieldGroup_siteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FieldGroup"
    ADD CONSTRAINT "FieldGroup_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES public."Site"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MediaAsset MediaAsset_siteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MediaAsset"
    ADD CONSTRAINT "MediaAsset_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES public."Site"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OptionsPage OptionsPage_siteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OptionsPage"
    ADD CONSTRAINT "OptionsPage_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES public."Site"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PasswordResetToken PasswordResetToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PostRevision PostRevision_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PostRevision"
    ADD CONSTRAINT "PostRevision_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PostType PostType_siteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PostType"
    ADD CONSTRAINT "PostType_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES public."Site"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Post Post_siteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES public."Site"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SiteSettings SiteSettings_siteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SiteSettings"
    ADD CONSTRAINT "SiteSettings_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES public."Site"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Taxonomy Taxonomy_siteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Taxonomy"
    ADD CONSTRAINT "Taxonomy_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES public."Site"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: User User_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_siteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES public."Site"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _CapabilityToRole _CapabilityToRole_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."_CapabilityToRole"
    ADD CONSTRAINT "_CapabilityToRole_A_fkey" FOREIGN KEY ("A") REFERENCES public."Capability"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _CapabilityToRole _CapabilityToRole_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."_CapabilityToRole"
    ADD CONSTRAINT "_CapabilityToRole_B_fkey" FOREIGN KEY ("B") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict uJeTKsCPESvZyq5pzdYoXTpHOjith4kenaCNmDxrdXgJwiDq2hnLmuFiT8nkAoI

