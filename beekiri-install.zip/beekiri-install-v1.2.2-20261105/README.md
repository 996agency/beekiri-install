# Beekiri CMS

**A free, self-hosted CMS for websites, shops and forms.** Structured content fields, a visual page editor, media, SEO, analytics, a shop and a form builder in one application. It installs with one command and is set up entirely from the browser.

Beekiri is **free to use, forever**, for personal sites, client work and commercial projects, on as many sites as you like. Optional premium themes are sold in the Beekiri theme store.

| | |
|---|---|
| **Current version** | 1.2.2 |
| **Stack** | React · Express · Sequelize · PostgreSQL · Next.js · TypeScript |
| **Releases** | [996agency/beekiri-install](https://github.com/996agency/beekiri-install/releases) |
| **License** | [Beekiri License](./LICENSE): free to use, build themes and extensions; no rebranding or clones |

---

## Contents

- [Quick start](#quick-start)
- [Requirements](#requirements)
- [Other ways to install](#other-ways-to-install)
- [First-run setup](#first-run-setup)
- [Features](#features)
- [Themes and extensions](#themes-and-extensions)
- [What is free, what is paid](#what-is-free-what-is-paid)
- [Configuration](#configuration)
- [Updating](#updating)
- [Development](#development)
- [Project structure](#project-structure)
- [Security](#security)
- [License and trademarks](#license-and-trademarks)

---

## Quick start

With [Node.js 20+](https://nodejs.org) and PostgreSQL installed, run:

```bash
npx github:996agency/beekiri-install my-site
```

This downloads the latest Beekiri release into `my-site`, installs it, and starts it. The terminal then prints a **setup link**: open it, enter your database details, and create your site and admin account.

After that, start Beekiri any time with:

```bash
cd my-site
npm start
```

Installer options: `--no-start` (install but don't start), `--no-install` (download only), `--help`.

---

## Requirements

| Software | Version | Notes |
|----------|---------|-------|
| Node.js | 20 or later | LTS recommended; includes npm and npx |
| PostgreSQL | 14 or later | Local or hosted; one empty database per site |
| PHP CLI | 8 or later | Optional; for PHP theme layouts and the Shopping storefront |

**Getting PostgreSQL**

| | |
|---|---|
| macOS | `brew install postgresql@16 && brew services start postgresql@16`, or [Postgres.app](https://postgresapp.com) |
| Ubuntu / Debian | `sudo apt install postgresql` |
| Windows | [PostgreSQL installer](https://www.postgresql.org/download/windows/) |
| Hosted | Any provider (Neon, Supabase, your hosting company…). Copy its host, port, database, user and password into the setup wizard. |

The setup wizard can create the database for you if the user has permission; otherwise create an empty one first (`createdb my_site`).

---

## Other ways to install

**Download the ZIP.** Get [beekiri-install.zip](https://github.com/996agency/beekiri-install/raw/main/beekiri-install.zip), unzip it, and in that folder run:

```bash
npm install
npm start
```

**On a server (VPS).** Same as above, then keep it running with a process manager and put it behind your web server (Nginx, Caddy) with HTTPS:

```bash
npm install -g pm2
pm2 start npm --name my-site -- start
pm2 save
```

Set `APP_URL`, `NODE_ENV=production` and `TRUST_PROXY=1` in `apps/api/.env` (see [Configuration](#configuration)).

---

## First-run setup

The first start builds the application and opens in setup mode. The setup wizard then:

1. Asks for the PostgreSQL connection details and verifies them.
2. Saves them to `apps/api/.env`, generates the encryption secret and restarts Beekiri.
3. Applies the database migrations.
4. Creates the site and the owner account.

For safety, the setup link printed in the terminal contains a one-time key; nobody else who reaches the server can complete the setup.

Once setup is complete, Beekiri is available at:

| | Path |
|---|---|
| Public website | `/` |
| Admin | `/admin` |
| API reference (OpenAPI) | `/api/docs` |

---

## Features

**Content**
- Pages and posts with revisions
- Backend Fields: field groups with repeaters, groups and flexible content
- Media library with automatic Full HD resizing and WebP conversion

**Editing**
- Visual page editor (BeekiriCode) with elements, sections and theme layouts
- Layouts generated from Backend Fields, with PHP or React output
- Parent and child themes under `apps/web/themes`

**Marketing**
- BeeSEO site audit, keyword research and backlinks
- Analytics, heatmaps and BeeCookies consent, first-party
- Translations with a language switcher

**Administration**
- Customizable overview dashboard
- Users, roles and per-user permissions
- One-click core updates and site migration (push/pull between local, staging and production)

**Extensions (free, made by Beekiri)**
- **Shopping**: products with variations and stock, cart, coupons, shipping, taxes, Stripe Checkout / bank transfer / cash on delivery, orders, customers and a sales overview. See [`docs/shopping`](./docs/shopping/USER-GUIDE.md).
- **Bee Forms**: drag-and-drop form builder with conditional logic, multi-step forms, file uploads, notification and auto-reply emails, an entries inbox with visitor source tracking (UTM tags, ad clicks, country), CSV export, and a HubSpot integration. See [`docs/bee-forms`](./docs/bee-forms/USER-GUIDE.md).

---

## Themes and extensions

Your work lives **outside the core**, so core updates never overwrite it:

| | Where | Notes |
|---|---|---|
| Themes | `apps/web/themes/<your-theme>/` | Start from **Beekiri Child**, or copy the default **Beekiri** theme. A theme has a `theme.json`, a header, a footer and layouts. |
| Layouts | `apps/web/themes/<theme>/layouts/<name>/` | Created automatically from **Backend Fields** (PHP or React), then yours to edit. Remove the `@beekiri-managed` line to stop regeneration. |
| Extensions | Built in today | Beekiri's own extensions (Shopping, Bee Forms) ship with the core. A public extension API so developers can publish their own is planned. |

You may build themes and extensions for yourself or for clients, and **share or sell them** under your own terms, as long as they don't include the Beekiri core. See the [LICENSE](./LICENSE).

---

## What is free, what is paid

| | |
|---|---|
| **Beekiri CMS** | Free. Every feature, every extension made by Beekiri, unlimited sites. |
| **Default themes** | Free. Use them as they are or as the starting point for your own. |
| **Premium themes** | Paid, in **Appearance → Theme store**. A theme licence covers one local, one staging and one production site with the same owner email. |

---

## Configuration

All settings live in `apps/api/.env`. The setup wizard creates this file; edit it only to configure a server by hand. Every available setting is documented in [`apps/api/.env.example`](./apps/api/.env.example).

A typical production configuration:

```env
NODE_ENV=production
PORT=8080
APP_URL=https://www.example.com

DB_HOST=db.example.com
DB_NAME=beekiri
DB_USER=beekiri
DB_PASSWORD=change-me
DB_SSL=verify-full

CACHE_FLUSH_SECRET=<output of: openssl rand -hex 32>
TRUST_PROXY=1

SMTP_HOST=smtp.example.com
SMTP_FROM=noreply@example.com
```

Behaviour to be aware of:

- **Setup mode:** without database settings, Beekiri serves only the setup wizard.
- **Validation:** an invalid value stops Beekiri at start, and every problem is listed at once.
- **Production warnings:** risky but working settings, such as a remote database without SSL, are logged on start.
- **Email:** without `SMTP_HOST`, emails such as password resets are written to the log instead of being sent.
- **Older installs:** settings in a repository-root `.env`, including `DATABASE_URL`, are still read.

---

## Updating

Sites update themselves from the admin:

1. Go to **Settings → Beekiri Core** and click **Check for updates**.
2. If a new version is available, click **Update**.

The updater downloads the release, backs up the current core files to `backups/`, installs the new version, applies database migrations and restarts Beekiri. Content, media, layouts generated by the site, and `apps/api/.env` are never overwritten.

### Publishing a release (996agency)

1. Raise the version in `package.json`, `beekiri.manifest.json`, `apps/api/beekiri.manifest.json` and `installer/package.json`; they must match.
2. Run:

   ```bash
   npm run publish:release
   ```

This builds the install package and publishes it, together with the `npx` installer from `installer/`, to [beekiri-install](https://github.com/996agency/beekiri-install/releases), where existing sites detect it on their next update check. Publishing requires the [GitHub CLI](https://cli.github.com/), signed in with write access to the release repository.

The release scripts (`scripts/pack-release.sh` and `scripts/publish-release.sh`) are kept on 996agency machines only. They are excluded from Git and from the install package.

---

## Development

```bash
npm run dev                          # Run Beekiri with live reload
npm run build                        # Build the admin, website and API
npm start                            # Run the production build (builds anything missing first)
npm test                             # API tests (TEST_DB_NAME=<throwaway db> for the integration suites)
npm run typecheck                    # Type-check every workspace
npm run db:migrate                   # Apply pending migrations
npm run db:migrate:status            # Show applied and pending migrations
npm run db:migrate:create -- <name>  # Create a new migration
```

---

## Project structure

```
apps/
  admin/     Admin interface (Vite + React), served at /admin
  api/       Express server: routes, controllers, services, zod validators,
             Sequelize models and migrations; hosts the admin and the website
  web/       Public website (Next.js), themes and shared editor modules
docs/        Extension documentation (shopping, bee-forms: user + developer guides)
installer/   The npx installer (create-beekiri), published with every release
scripts/     Core updater, run by Settings → Beekiri Core → Update
```

---

## Security

- Passwords are hashed with **Argon2id**; new passwords must not be weak (install, reset and user edit all apply the same rule).
- Sessions are stored server-side in **HttpOnly** cookies, marked Secure (with the `__Host-` prefix) on `https://` sites. Changing a password closes every session of that account.
- State-changing requests are protected against **CSRF** (allow-listed Origin plus a per-session token).
- Login is throttled per address and per account; password-reset links are single-use, expire after one hour, and are always built from `APP_URL` (never from the request's Host header), so set `APP_URL` on every production site.
- Changing your own email or password requires your current password. Only administrators can create, edit or delete administrator accounts; only the Owner can edit the Owner account; nobody can change their own role.
- Authors and contributors can only open and change their own items, cannot change items that are already published, and have scripts and event handlers stripped from the HTML they save. The `unfiltered_html` capability (administrators by default) stores HTML as written. Note that the admin and the public site share one origin, so anyone allowed to put scripts on the site can act as any administrator who visits it.
- Settings tabs delegated to a user only unlock that tab's fields; the site-code slots (head/body/footer HTML) stay with full administrators.
- Rich text printed by theme templates (`bee_esc_html()` / `wp_kses_post()`) goes through a DOM-based allow-list, and `esc_url()` refuses script URLs, including obfuscated ones. Field values saved by users without `unfiltered_html` are cleaned on save as well, and the editor sanitizes layout previews before showing them.
- The admin page carries a strict **Content-Security-Policy**: scripts load only from the site itself. Website pages get a baseline policy (no plugins, no `<base>` hijacking, no framing by other sites); scripts stay open there because owners add analytics and widgets through Settings.
- **First-time setup needs a one-time setup key.** Beekiri prints a link containing it in the terminal and saves it in `apps/api/.setup-token`; it stops working once the site is created. Nobody who merely reaches the server can claim it.
- A custom admin address stays private: it is not returned by any public endpoint or listed in `robots.txt`. The API reference at `/api/docs` is only available to signed-in administrators.
- Security headers via **Helmet**, and **rate limiting** on the API, including the public layout render endpoints.
- `apps/api/.env` is written with owner-only file permissions. Never commit it or share production secrets.

To report a vulnerability, contact 996agency directly rather than opening a public issue.

---

## License and trademarks

Beekiri is **free to use** under the [Beekiri License](./LICENSE):

- ✅ Use it on any number of sites, for yourself or for clients, including commercial work.
- ✅ Create and change themes, and create extensions. Share or sell them under your own terms.
- ✅ Hosting providers may offer unmodified Beekiri to their customers.
- ❌ No rebranding: the Beekiri name, logo and notices in the admin, sign-in, setup and update screens stay.
- ❌ No clones: don't publish or sell Beekiri, or a changed version of it, as your own product.

Your public websites never need to show Beekiri branding. The name and logo are covered by the [trademark policy](./TRADEMARKS.md): *"built with Beekiri"* and *"… for Beekiri"* are welcome.

© 2026 996agency.
