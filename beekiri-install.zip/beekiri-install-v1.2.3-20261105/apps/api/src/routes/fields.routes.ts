import { Router } from 'express';
import { fieldsController as c } from '../controllers/fields.controller';
import { requireAnyCapability, requireAuth, requireCapabilities } from '../middleware/authenticate';
import { validate } from '../middleware/validate';
import { idParams } from '../validators/common';
import {
  createFieldGroupSchema,
  lookupPostsQuery,
  lookupUsersQuery,
  syncFieldGroupsSchema,
  updateFieldGroupSchema,
} from '../validators/fields.schema';
import {
  createOptionsPageSchema,
  createPostTypeSchema,
  createTaxonomySchema,
  fieldsSettingsSchema,
  updateOptionsPageSchema,
  updatePostTypeSchema,
  updateTaxonomySchema,
} from '../validators/structure.schema';
import { createTermSchema, updateTermSchema } from '../validators/pages.schema';

export const fieldsRoutes = Router();

const admin = requireCapabilities('manage_fields');
const withId = validate({ params: idParams });

fieldsRoutes.use(requireAuth);

fieldsRoutes.get('/meta', admin, c.meta);
fieldsRoutes.get(
  '/lookup/posts',
  requireCapabilities('read'),
  validate({ query: lookupPostsQuery }),
  c.lookupPosts,
);
fieldsRoutes.get(
  '/lookup/users',
  requireCapabilities('read'),
  validate({ query: lookupUsersQuery }),
  c.lookupUsers,
);

/** List is readable for nav/content routes; mutating post types stays on manage_fields. */
fieldsRoutes.get('/post-types', requireCapabilities('read'), c.listPostTypes);
fieldsRoutes.post('/post-types', admin, validate({ body: createPostTypeSchema }), c.createPostType);
fieldsRoutes.patch(
  '/post-types/:id',
  admin,
  validate({ params: idParams, body: updatePostTypeSchema }),
  c.updatePostType,
);
fieldsRoutes.delete('/post-types/:id', admin, withId, c.removePostType);

fieldsRoutes.get('/taxonomies', admin, c.listTaxonomies);
fieldsRoutes.post('/taxonomies', admin, validate({ body: createTaxonomySchema }), c.createTaxonomy);
fieldsRoutes.patch(
  '/taxonomies/:id',
  admin,
  validate({ params: idParams, body: updateTaxonomySchema }),
  c.updateTaxonomy,
);
fieldsRoutes.delete('/taxonomies/:id', admin, withId, c.removeTaxonomy);
fieldsRoutes.post(
  '/taxonomies/:id/terms',
  requireAnyCapability('edit_pages', 'edit_posts', 'manage_fields', 'edit_products'),
  validate({ params: idParams, body: createTermSchema }),
  c.createTerm,
);
fieldsRoutes.get(
  '/taxonomies/:id/terms',
  requireAnyCapability('edit_pages', 'edit_posts', 'manage_fields', 'edit_products'),
  withId,
  c.listTerms,
);
fieldsRoutes.patch(
  '/terms/:id',
  requireAnyCapability('edit_pages', 'edit_posts', 'manage_fields', 'edit_products'),
  validate({ params: idParams, body: updateTermSchema }),
  c.updateTerm,
);
fieldsRoutes.delete(
  '/terms/:id',
  requireAnyCapability('edit_pages', 'edit_posts', 'manage_fields', 'edit_products'),
  withId,
  c.removeTerm,
);

fieldsRoutes.get('/options-pages', admin, c.listOptionsPages);
fieldsRoutes.post(
  '/options-pages',
  admin,
  validate({ body: createOptionsPageSchema }),
  c.createOptionsPage,
);
fieldsRoutes.patch(
  '/options-pages/:id',
  admin,
  validate({ params: idParams, body: updateOptionsPageSchema }),
  c.updateOptionsPage,
);
fieldsRoutes.delete('/options-pages/:id', admin, withId, c.removeOptionsPage);

fieldsRoutes.get('/settings', admin, c.getSettings);
fieldsRoutes.patch('/settings', admin, validate({ body: fieldsSettingsSchema }), c.updateSettings);

// Field groups (":id" last so the named routes above win).
fieldsRoutes.get('/', admin, c.list);
fieldsRoutes.get('/sync', admin, c.listSync);
fieldsRoutes.post('/sync', admin, validate({ body: syncFieldGroupsSchema }), c.applySync);
fieldsRoutes.get('/:id', admin, withId, c.get);
fieldsRoutes.post('/', admin, validate({ body: createFieldGroupSchema }), c.create);
fieldsRoutes.patch(
  '/:id',
  admin,
  validate({ params: idParams, body: updateFieldGroupSchema }),
  c.update,
);
fieldsRoutes.post('/:id/restore', admin, withId, c.restore);
fieldsRoutes.delete('/:id', admin, withId, c.remove);
