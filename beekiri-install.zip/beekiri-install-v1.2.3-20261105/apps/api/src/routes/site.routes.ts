import { Router } from 'express';
import { SETTINGS_ACCESS_CAPABILITIES } from '../lib/auth/role-capabilities';
import { siteController as c } from '../controllers/site.controller';
import { translationsController as tr } from '../controllers/translations.controller';
import { usersController } from '../controllers/users.controller';
import {
  requireAuth,
  requireAnyCapability,
  requireCapabilities,
  emptyUnlessSignedIn,
} from '../middleware/authenticate';
import { validate } from '../middleware/validate';
import {
  adminDockQuery,
  autoTranslateSchema,
  dashboardLayoutBody,
  dashboardQuery,
  translationsPublicQuery,
  translationsSchema,
  updateSiteSettingsSchema,
} from '../validators/site.schema';

export const siteRoutes = Router();

const admin = [requireAuth, requireCapabilities('manage_options')];
const settingsAccess = [
  requireAuth,
  requireAnyCapability('manage_options', ...SETTINGS_ACCESS_CAPABILITIES),
];

siteRoutes.get('/public', c.publicSite);
siteRoutes.get(
  '/admin-dock',
  emptyUnlessSignedIn({ items: [] }),
  requireAuth,
  requireCapabilities('read'),
  validate({ query: adminDockQuery }),
  c.adminDock,
);
siteRoutes.get('/link-targets', ...admin, c.linkTargets);
siteRoutes.get('/page-editor', requireAuth, requireCapabilities('edit_pages'), c.pageEditor);
siteRoutes.get(
  '/dashboard',
  requireAuth,
  requireCapabilities('read'),
  validate({ query: dashboardQuery }),
  c.dashboard,
);
/** Per-user Overview layout — any signed-in user manages their own only. */
siteRoutes.get('/dashboard-layout', requireAuth, usersController.getDashboardLayout);
siteRoutes.put(
  '/dashboard-layout',
  requireAuth,
  validate({ body: dashboardLayoutBody }),
  usersController.setDashboardLayout,
);
siteRoutes.get('/settings', ...settingsAccess, c.getSettings);
siteRoutes.patch(
  '/settings',
  ...settingsAccess,
  validate({ body: updateSiteSettingsSchema }),
  c.updateSettings,
);

/** Settings → Translation (same access as the Advanced tab). */
const translationsAccess = [
  requireAuth,
  requireAnyCapability('manage_options', 'manage_settings_advanced'),
];
siteRoutes.get('/translations/public', validate({ query: translationsPublicQuery }), tr.publicConfig);
siteRoutes.get('/translations', ...translationsAccess, tr.getSettings);
siteRoutes.put(
  '/translations',
  ...translationsAccess,
  validate({ body: translationsSchema }),
  tr.updateSettings,
);
siteRoutes.post(
  '/translations/auto',
  ...translationsAccess,
  validate({ body: autoTranslateSchema }),
  tr.autoTranslate,
);
