import { createReadStream } from 'node:fs';
import { rm, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { Op, type WhereOptions } from 'sequelize';
import { FORMS_UPLOAD_DIR } from '../../lib/forms/constants';
import type { StoredFile } from '../../lib/forms/merge';
import { valueText } from '../../lib/forms/merge';
import { parseFormFields, valueFields, type FormField } from '../../lib/forms/schema';
import { resolveUploadsRoot } from '../../lib/media/media.paths';
import { BeeForm, BeeFormEntry, sequelize } from '../../models';
import type { BeeFormEntryStatus } from '../../models/bee-form-entry.model';
import type { AuthUser } from '../../types/auth';
import { BadRequest, NotFound, toHttpError } from '../../utils/http-error';

export type EntryListInput = {
  formId?: string;
  status?: 'all' | 'inbox' | BeeFormEntryStatus;
  q?: string;
  /** Channel of the visit ("Paid search", "Direct"…), or "none" for entries sent before tracking. */
  channel?: string;
  /** Source within the channel ("Google Ads", "linkedin.com"…). */
  source?: string;
  page?: number;
  perPage?: number;
};

export type EntryDto = {
  id: string;
  formId: string;
  formTitle: string;
  status: BeeFormEntryStatus;
  summary: string;
  /** Ordered like the form's current fields; fields removed since keep their saved label. */
  answers: { fieldId: string; name: string; label: string; type: string; value: unknown; text: string }[];
  meta: Record<string, unknown>;
  createdAt: string;
};

const STATUSES: BeeFormEntryStatus[] = ['unread', 'read', 'spam', 'trash'];

/** `meta.attribution.visit.<key>` as SQL text. */
const visitAttr = (key: 'channel' | 'source') =>
  sequelize.fn('jsonb_extract_path_text', sequelize.col('BeeFormEntry.meta'), 'attribution', 'visit', key);

export function entryFileDir(entryId: string): string {
  return join(resolveUploadsRoot(), FORMS_UPLOAD_DIR, entryId.replace(/[^A-Za-z0-9_-]/g, ''));
}

function isFileList(v: unknown): v is StoredFile[] {
  return Array.isArray(v) && v.every((x) => x && typeof x === 'object' && typeof (x as StoredFile).id === 'string');
}

export function entryDto(row: BeeFormEntry, formFields: FormField[], formTitle: string): EntryDto {
  const data = (row.data ?? {}) as Record<string, unknown>;
  const labels = (row.labels ?? {}) as Record<string, { label?: string; name?: string; type?: string }>;
  const byId = new Map(valueFields(formFields).map((f) => [f.id, f]));
  const order = [...byId.keys(), ...Object.keys(data).filter((k) => !byId.has(k))];
  const answers = order
    .filter((id) => id in data)
    .map((id) => {
      const f = byId.get(id);
      const saved = labels[id] ?? {};
      return {
        fieldId: id,
        name: f?.name ?? saved.name ?? id,
        label: f?.label ?? saved.label ?? id,
        type: f?.type ?? saved.type ?? 'text',
        value: data[id],
        text: valueText(data[id]),
      };
    });
  return {
    id: row.id,
    formId: row.formId,
    formTitle,
    status: STATUSES.includes(row.status) ? row.status : 'unread',
    summary: row.summary,
    answers,
    meta: (row.meta ?? {}) as Record<string, unknown>,
    createdAt: row.createdAt.toISOString(),
  };
}

function attrColumns(meta: Record<string, unknown>): string[] {
  const a = (meta.attribution ?? {}) as { visit?: Record<string, unknown> | null; first?: Record<string, unknown> | null };
  const v = a.visit ?? {};
  const f = a.first ?? {};
  const s = (x: unknown) => (x == null ? '' : String(x));
  return [
    s(v.channel), s(v.source), s(v.medium), s(v.campaign), s(v.term), s(v.content), s(v.clickId), s(v.landingPage), s(v.referrer),
    s(f.channel), s(f.source), s(f.campaign), s(meta.country), s(meta.device), s(meta.browser), s(meta.os),
  ];
}

async function recount(formId: string) {
  const [entryCount, unreadCount] = await Promise.all([
    BeeFormEntry.count({ where: { formId, status: { [Op.in]: ['unread', 'read'] } } }),
    BeeFormEntry.count({ where: { formId, status: 'unread' } }),
  ]);
  await BeeForm.update({ entryCount, unreadCount }, { where: { id: formId } });
}

export class EntriesService {
  private async forms(actor: AuthUser): Promise<Map<string, BeeForm>> {
    const rows = await BeeForm.findAll({ where: { siteId: actor.siteId } });
    return new Map(rows.map((r) => [r.id, r]));
  }

  /** Shared filters (form, status, search); the source filter is added by `list` on top. */
  private baseWhere(actor: AuthUser, query: EntryListInput): WhereOptions {
    const where: WhereOptions = { siteId: actor.siteId };
    if (query.formId) Object.assign(where, { formId: query.formId });
    const status = query.status ?? 'inbox';
    if (status === 'inbox') Object.assign(where, { status: { [Op.in]: ['unread', 'read'] } });
    else if (status !== 'all') Object.assign(where, { status });
    const q = (query.q ?? '').trim();
    if (q) {
        const like = `%${q.replace(/[%_\\]/g, '\\$&')}%`;
        Object.assign(where, {
          [Op.or]: [
            { summary: { [Op.iLike]: like } },
            sequelize.where(sequelize.cast(sequelize.col('BeeFormEntry.data'), 'text'), { [Op.iLike]: like }),
          ],
        });
      }
    return where;
  }

  async list(actor: AuthUser, query: EntryListInput) {
    try {
      const page = query.page ?? 1;
      const perPage = query.perPage ?? 25;
      const base = this.baseWhere(actor, query);
      const sourceFilters: WhereOptions[] = [];
      if (query.channel === 'none') sourceFilters.push(sequelize.where(visitAttr('channel'), Op.is, null));
      else if (query.channel) sourceFilters.push(sequelize.where(visitAttr('channel'), query.channel));
      if (query.source) sourceFilters.push(sequelize.where(visitAttr('source'), query.source));
      const where: WhereOptions = sourceFilters.length ? { [Op.and]: [base, ...sourceFilters] } : base;
      const [{ rows, count }, forms, counts, sources] = await Promise.all([
        BeeFormEntry.findAndCountAll({ where, order: [['createdAt', 'DESC']], limit: perPage, offset: (page - 1) * perPage }),
        this.forms(actor),
        this.counts(actor, query.formId),
        this.sources(base),
      ]);
      const items = rows.map((row) => {
        const form = forms.get(row.formId);
        return entryDto(row, form ? parseFormFields(form.fields) : [], form?.title ?? 'Deleted form');
      });
      return { items, total: count, page, perPage, pages: Math.max(1, Math.ceil(count / perPage)), counts, sources };
    } catch (error) {
      throw toHttpError(error, 'Could not load the entries.');
    }
  }

  /** Entries per channel + source for the current form/status/search (ignores the source filter). */
  private async sources(where: WhereOptions): Promise<{ channel: string | null; source: string | null; count: number }[]> {
    const rows = (await BeeFormEntry.findAll({
      attributes: [
        [visitAttr('channel'), 'channel'],
        [visitAttr('source'), 'source'],
        [sequelize.fn('COUNT', sequelize.col('BeeFormEntry.id')), 'count'],
      ],
      where,
      group: ['channel', 'source'],
      raw: true,
    })) as unknown as { channel: string | null; source: string | null; count: string | number }[];
    return rows
      .map((r) => ({ channel: r.channel, source: r.source, count: Number(r.count) || 0 }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 50);
  }

  private async counts(actor: AuthUser, formId?: string) {
    const base: WhereOptions = { siteId: actor.siteId, ...(formId ? { formId } : {}) };
    const [unread, inbox, spam, trash] = await Promise.all([
      BeeFormEntry.count({ where: { ...base, status: 'unread' } }),
      BeeFormEntry.count({ where: { ...base, status: { [Op.in]: ['unread', 'read'] } } }),
      BeeFormEntry.count({ where: { ...base, status: 'spam' } }),
      BeeFormEntry.count({ where: { ...base, status: 'trash' } }),
    ]);
    return { unread, inbox, spam, trash };
  }

  private async row(actor: AuthUser, id: string): Promise<BeeFormEntry> {
    const row = await BeeFormEntry.findOne({ where: { id, siteId: actor.siteId } });
    if (!row) throw NotFound('Entry not found.');
    return row;
  }

  /**
   * One entry (marks it read) plus the newer/older entry ids for Previous/Next. The neighbours
   * follow the list the user came from: same form filter, and the entry's own status group.
   */
  async get(actor: AuthUser, id: string, scope: { formId?: string } = {}): Promise<EntryDto & { newerId: string | null; olderId: string | null }> {
    try {
      const row = await this.row(actor, id);
      const wasUnread = row.status === 'unread';
      if (wasUnread) {
        await row.update({ status: 'read' });
        await recount(row.formId);
      }
      const form = await BeeForm.findByPk(row.formId);
      const group = row.status === 'read' || row.status === 'unread' ? { [Op.in]: ['unread', 'read'] } : row.status;
      const near: WhereOptions = { siteId: actor.siteId, status: group, ...(scope.formId ? { formId: scope.formId } : {}) };
      const [newer, older] = await Promise.all([
        BeeFormEntry.findOne({ where: { ...near, createdAt: { [Op.gt]: row.createdAt } }, order: [['createdAt', 'ASC']], attributes: ['id'] }),
        BeeFormEntry.findOne({ where: { ...near, createdAt: { [Op.lt]: row.createdAt } }, order: [['createdAt', 'DESC']], attributes: ['id'] }),
      ]);
      return {
        ...entryDto(row, form ? parseFormFields(form.fields) : [], form?.title ?? 'Deleted form'),
        newerId: newer?.id ?? null,
        olderId: older?.id ?? null,
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load the entry.');
    }
  }

  async setStatus(actor: AuthUser, ids: string[], status: BeeFormEntryStatus): Promise<{ ok: true }> {
    try {
      if (!STATUSES.includes(status)) throw BadRequest('Unknown status.');
      const rows = await BeeFormEntry.findAll({ where: { id: { [Op.in]: ids }, siteId: actor.siteId } });
      await BeeFormEntry.update({ status }, { where: { id: { [Op.in]: rows.map((r) => r.id) } } });
      for (const formId of new Set(rows.map((r) => r.formId))) await recount(formId);
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not update the entries.');
    }
  }

  async remove(actor: AuthUser, ids: string[]): Promise<{ ok: true }> {
    try {
      const rows = await BeeFormEntry.findAll({ where: { id: { [Op.in]: ids }, siteId: actor.siteId } });
      for (const row of rows) {
        await rm(entryFileDir(row.id), { recursive: true, force: true });
        await row.destroy();
      }
      for (const formId of new Set(rows.map((r) => r.formId))) await recount(formId);
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not delete the entries.');
    }
  }

  /** Stored upload for an entry; the route streams it with the saved name and type. */
  async file(actor: AuthUser, entryId: string, fileId: string) {
    try {
      const row = await this.row(actor, entryId);
      const data = (row.data ?? {}) as Record<string, unknown>;
      let found: StoredFile | null = null;
      for (const v of Object.values(data)) {
        if (isFileList(v)) found = v.find((f) => f.id === fileId) ?? found;
      }
      if (!found) throw NotFound('File not found.');
      const path = join(entryFileDir(row.id), found.id);
      const info = await stat(path).catch(() => null);
      if (!info?.isFile()) throw NotFound('File not found.');
      return { file: found, stream: createReadStream(path), size: info.size };
    } catch (error) {
      throw toHttpError(error, 'Could not load the file.');
    }
  }

  /** CSV of one form's entries (inbox by default). */
  async exportCsv(actor: AuthUser, formId: string, status: EntryListInput['status'] = 'inbox'): Promise<{ filename: string; csv: string }> {
    try {
      const form = await BeeForm.findOne({ where: { id: formId, siteId: actor.siteId } });
      if (!form) throw NotFound('Form not found.');
      const fields = valueFields(parseFormFields(form.fields));
      const where: WhereOptions = { formId };
      if (status === 'inbox') Object.assign(where, { status: { [Op.in]: ['unread', 'read'] } });
      else if (status && status !== 'all') Object.assign(where, { status });
      const rows = await BeeFormEntry.findAll({ where, order: [['createdAt', 'DESC']], limit: 10_000 });
      const cell = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
      const head = [
        'Entry ID', 'Date', 'Status', ...fields.map((f) => f.label), 'Page URL',
        'Channel', 'Source', 'Medium', 'Campaign', 'Term', 'Content', 'Ad click ID', 'Landing page', 'Referrer',
        'First visit channel', 'First visit source', 'First visit campaign', 'Country', 'Device', 'Browser', 'OS',
      ];
      const lines = [head.map(cell).join(',')];
      for (const row of rows) {
        const data = (row.data ?? {}) as Record<string, unknown>;
        const meta = (row.meta ?? {}) as Record<string, unknown>;
        lines.push(
          [
            row.id, row.createdAt.toISOString(), row.status, ...fields.map((f) => valueText(data[f.id])), String(meta.pageUrl ?? ''),
            ...attrColumns(meta),
          ]
            .map(cell)
            .join(','),
        );
      }
      const slug = form.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'form';
      return { filename: `${slug}-entries.csv`, csv: `﻿${lines.join('\r\n')}` };
    } catch (error) {
      throw toHttpError(error, 'Could not export the entries.');
    }
  }
}

export const entriesService = new EntriesService();
