import { Op, type WhereOptions } from 'sequelize';
import { FORMS_EXTENSION_SLUG } from '../../lib/forms/constants';
import {
  parseFormDefinition,
  parseFormFields,
  parseFormSettings,
  starterContactForm,
  type FormDefinition,
} from '../../lib/forms/schema';
import { renderForm } from '../../lib/forms/render';
import { makeFormToken } from '../../lib/forms/token';
import { AuditLog, BeeForm, BeeFormEntry } from '../../models';
import type { AuthUser } from '../../types/auth';
import { BadRequest, NotFound, toHttpError } from '../../utils/http-error';
import { extensionsService } from '../extensions.service';
import { findPrimarySite } from '../site-context';

export type FormSummary = {
  id: string;
  title: string;
  status: 'active' | 'inactive';
  fieldCount: number;
  entryCount: number;
  unreadCount: number;
  lastEntryAt: string | null;
  createdAt: string;
  updatedAt: string;
};

export type FormDetail = FormSummary & FormDefinition;

export type FormInput = { title?: string; status?: string; fields?: unknown; settings?: unknown };

export function definitionOf(row: BeeForm): FormDefinition {
  return { fields: parseFormFields(row.fields), settings: parseFormSettings(row.settings) };
}

export function summarize(row: BeeForm): FormSummary {
  return {
    id: row.id,
    title: row.title,
    status: row.status === 'inactive' ? 'inactive' : 'active',
    fieldCount: parseFormFields(row.fields).filter((f) => f.type !== 'page' && f.type !== 'section').length,
    entryCount: row.entryCount,
    unreadCount: row.unreadCount,
    lastEntryAt: row.lastEntryAt ? row.lastEntryAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export function detail(row: BeeForm): FormDetail {
  return { ...summarize(row), ...definitionOf(row) };
}

export const PUBLIC_SUBMIT_PATH = (id: string) => `/api/forms/public/${encodeURIComponent(id)}/submit`;

export class FormsService {
  async list(actor: AuthUser, q = ''): Promise<{ items: FormSummary[] }> {
    try {
      const where: WhereOptions = { siteId: actor.siteId };
      const term = q.trim();
      if (term) Object.assign(where, { title: { [Op.iLike]: `%${term.replace(/[%_\\]/g, '\\$&')}%` } });
      const rows = await BeeForm.findAll({ where, order: [['updatedAt', 'DESC']] });
      return { items: rows.map(summarize) };
    } catch (error) {
      throw toHttpError(error, 'Could not load the forms.');
    }
  }

  /** id + title only, for pickers (editor element, Backend Field). */
  async lookup(actor: AuthUser): Promise<{ items: { id: string; title: string; status: string }[] }> {
    try {
      const rows = await BeeForm.findAll({
        where: { siteId: actor.siteId },
        attributes: ['id', 'title', 'status'],
        order: [['title', 'ASC']],
      });
      return { items: rows.map((r) => ({ id: r.id, title: r.title, status: r.status })) };
    } catch (error) {
      throw toHttpError(error, 'Could not load the forms.');
    }
  }

  private async row(actor: AuthUser, id: string): Promise<BeeForm> {
    const row = await BeeForm.findOne({ where: { id, siteId: actor.siteId } });
    if (!row) throw NotFound('Form not found.');
    return row;
  }

  async get(actor: AuthUser, id: string): Promise<FormDetail> {
    try {
      return detail(await this.row(actor, id));
    } catch (error) {
      throw toHttpError(error, 'Could not load the form.');
    }
  }

  async create(actor: AuthUser, input: FormInput): Promise<FormDetail> {
    try {
      const title = (input.title ?? '').trim().slice(0, 200) || 'Untitled form';
      const def = input.fields === undefined && input.settings === undefined ? starterContactForm() : parseFormDefinition(input);
      const row = await BeeForm.create({
        siteId: actor.siteId,
        title,
        status: input.status === 'inactive' ? 'inactive' : 'active',
        fields: def.fields,
        settings: def.settings,
        lastEntryAt: null,
        createdById: actor.id,
      });
      await this.audit(actor, 'form.created', row);
      return detail(row);
    } catch (error) {
      throw toHttpError(error, 'Could not create the form.');
    }
  }

  async update(actor: AuthUser, id: string, input: FormInput): Promise<FormDetail> {
    try {
      const row = await this.row(actor, id);
      const patch: Partial<{ title: string; status: 'active' | 'inactive'; fields: unknown; settings: unknown }> = {};
      if (input.title !== undefined) patch.title = input.title.trim().slice(0, 200) || row.title;
      if (input.status !== undefined) patch.status = input.status === 'inactive' ? 'inactive' : 'active';
      if (input.fields !== undefined) patch.fields = parseFormFields(input.fields);
      if (input.settings !== undefined) patch.settings = parseFormSettings(input.settings);
      await row.update(patch as never);
      await this.audit(actor, 'form.updated', row);
      return detail(row);
    } catch (error) {
      throw toHttpError(error, 'Could not save the form.');
    }
  }

  async duplicate(actor: AuthUser, id: string): Promise<FormDetail> {
    try {
      const src = await this.row(actor, id);
      const def = definitionOf(src);
      const row = await BeeForm.create({
        siteId: actor.siteId,
        title: `${src.title} (copy)`.slice(0, 200),
        status: 'active',
        fields: def.fields,
        settings: def.settings,
        lastEntryAt: null,
        createdById: actor.id,
      });
      await this.audit(actor, 'form.created', row, { copiedFrom: src.id });
      return detail(row);
    } catch (error) {
      throw toHttpError(error, 'Could not duplicate the form.');
    }
  }

  async remove(actor: AuthUser, id: string): Promise<{ ok: true }> {
    try {
      const row = await this.row(actor, id);
      await BeeFormEntry.destroy({ where: { formId: row.id } });
      await row.destroy();
      await this.audit(actor, 'form.deleted', row);
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not delete the form.');
    }
  }

  /** Editor preview HTML (inert inputs). */
  async previewHtml(actor: AuthUser, id: string): Promise<{ html: string; title: string }> {
    try {
      const row = await this.row(actor, id);
      return {
        title: row.title,
        html: renderForm({
          id: row.id,
          title: row.title,
          definition: definitionOf(row),
          token: '',
          action: PUBLIC_SUBMIT_PATH(row.id),
          preview: true,
        }),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not render the form.');
    }
  }

  /* ── Public ─────────────────────────────────────────────────────────── */

  /** Active form for the public site; null when missing, inactive or the extension is off. */
  async publicRow(id: string): Promise<BeeForm | null> {
    if (!(await extensionsService.isActive(FORMS_EXTENSION_SLUG))) return null;
    const site = await findPrimarySite();
    if (!site) return null;
    const row = await BeeForm.findOne({ where: { id, siteId: site.id, status: 'active' } });
    return row;
  }

  /** Rendered HTML for the website (page element, Backend Field, PHP helper). */
  async publicHtml(id: string): Promise<{ html: string; title: string } | null> {
    const row = await this.publicRow(id);
    if (!row) return null;
    return {
      title: row.title,
      html: renderForm({
        id: row.id,
        title: row.title,
        definition: definitionOf(row),
        token: makeFormToken(row.id),
        action: PUBLIC_SUBMIT_PATH(row.id),
      }),
    };
  }

  /** Several at once (Backend Field formatting). Unknown or inactive ids are skipped. */
  async publicHtmlMany(ids: string[]): Promise<Map<string, { id: string; title: string; html: string }>> {
    const out = new Map<string, { id: string; title: string; html: string }>();
    if (!ids.length || !(await extensionsService.isActive(FORMS_EXTENSION_SLUG))) return out;
    const rows = await BeeForm.findAll({ where: { id: { [Op.in]: ids }, status: 'active' } });
    for (const row of rows) {
      out.set(row.id, {
        id: row.id,
        title: row.title,
        html: renderForm({
          id: row.id,
          title: row.title,
          definition: definitionOf(row),
          token: makeFormToken(row.id),
          action: PUBLIC_SUBMIT_PATH(row.id),
        }),
      });
    }
    return out;
  }

  async publicToken(id: string): Promise<{ token: string }> {
    const row = await this.publicRow(id);
    if (!row) throw NotFound('Form not found.');
    return { token: makeFormToken(row.id) };
  }

  private async audit(actor: AuthUser, action: string, row: BeeForm, extra: Record<string, unknown> = {}) {
    try {
      await AuditLog.create({ siteId: actor.siteId, userId: actor.id, action, meta: { formId: row.id, title: row.title, ...extra } });
    } catch {
      /* audit must never block the action */
    }
  }

  assertTitle(title: unknown) {
    if (typeof title !== 'string' || !title.trim()) throw BadRequest('Give the form a title.');
  }
}

export const formsService = new FormsService();
