import type { HubspotProperty } from '../../lib/forms/integrations';

/**
 * Minimal HubSpot CRM v3 client for a private app access token. Every call has a timeout and
 * returns a typed error, so callers can tell "fix the token" from "try again later".
 */

/** Test servers point this at a local mock; real sites never set it. */
const API_BASE = (process.env.BEEKIRI_HUBSPOT_API_BASE || 'https://api.hubapi.com').replace(/\/+$/, '');
const TIMEOUT_MS = 15_000;

export const HUBSPOT_SCOPES = ['crm.objects.contacts.read', 'crm.objects.contacts.write', 'crm.schemas.contacts.read'] as const;

export type HubspotErrorKind = 'auth' | 'scope' | 'validation' | 'conflict' | 'not_found' | 'rate_limit' | 'server' | 'network';

export class HubspotError extends Error {
  constructor(
    readonly kind: HubspotErrorKind,
    message: string,
    readonly status = 0,
    readonly body: unknown = null,
  ) {
    super(message);
  }

  /** Worth retrying later (HubSpot busy or unreachable). */
  get retryable(): boolean {
    return this.kind === 'rate_limit' || this.kind === 'server' || this.kind === 'network';
  }
}

type Body = { message?: string; category?: string; errors?: { message?: string; context?: { propertyName?: string[] } }[]; [k: string]: unknown };

function describe(status: number, body: Body | null): HubspotError {
  const msg = (body?.message || '').toString();
  if (status === 401) return new HubspotError('auth', 'HubSpot did not accept the access token. Create a new token and reconnect.', status, body);
  if (status === 403) {
    return new HubspotError('scope', `The HubSpot private app is missing a permission (${HUBSPOT_SCOPES.join(', ')}). ${msg}`.trim(), status, body);
  }
  if (status === 404) return new HubspotError('not_found', msg || 'Not found in HubSpot.', status, body);
  if (status === 409) return new HubspotError('conflict', msg || 'The record already exists in HubSpot.', status, body);
  if (status === 429) return new HubspotError('rate_limit', 'HubSpot is rate limiting requests right now.', status, body);
  if (status >= 500) return new HubspotError('server', `HubSpot had a problem (${status}).`, status, body);
  return new HubspotError('validation', msg || `HubSpot rejected the request (${status}).`, status, body);
}

export async function hubspotRequest<T>(token: string, method: string, path: string, body?: unknown): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  let res: Response;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json',
        ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
  } catch (error) {
    const aborted = (error as Error).name === 'AbortError';
    throw new HubspotError('network', aborted ? 'HubSpot did not answer in time.' : `Could not reach HubSpot: ${(error as Error).message}`);
  } finally {
    clearTimeout(timer);
  }
  const text = await res.text();
  let json: unknown = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = null;
  }
  if (!res.ok) throw describe(res.status, json as Body | null);
  return json as T;
}

/* ── Calls ───────────────────────────────────────────────────────────── */

export type HubspotAccount = { portalId: number | null; uiDomain: string; timeZone: string; dataHostingLocation: string };

export async function accountDetails(token: string): Promise<HubspotAccount> {
  const d = await hubspotRequest<{ portalId?: number; uiDomain?: string; timeZone?: string; dataHostingLocation?: string }>(token, 'GET', '/account-info/v3/details');
  return {
    portalId: typeof d?.portalId === 'number' ? d.portalId : null,
    uiDomain: d?.uiDomain || 'app.hubspot.com',
    timeZone: d?.timeZone || '',
    dataHostingLocation: d?.dataHostingLocation || '',
  };
}

type RawProperty = {
  name: string;
  label?: string;
  type?: string;
  fieldType?: string;
  groupName?: string;
  hidden?: boolean;
  calculated?: boolean;
  options?: { label?: string; value?: string; hidden?: boolean }[];
  modificationMetadata?: { readOnlyValue?: boolean };
};

/** Contact properties a form can write (hidden, calculated and read-only ones are left out). */
export async function contactProperties(token: string): Promise<HubspotProperty[]> {
  const d = await hubspotRequest<{ results?: RawProperty[] }>(token, 'GET', '/crm/v3/properties/contacts?archived=false');
  return (d?.results ?? [])
    .map((p) => ({
      name: p.name,
      label: p.label || p.name,
      type: p.type || 'string',
      fieldType: p.fieldType || 'text',
      groupName: p.groupName || '',
      options: (p.options ?? []).filter((o) => !o.hidden && o.value != null).map((o) => ({ label: o.label || String(o.value), value: String(o.value) })),
      readOnly: Boolean(p.modificationMetadata?.readOnlyValue || p.calculated),
      hidden: Boolean(p.hidden),
    }))
    .filter((p) => !p.hidden || p.name === 'email')
    .map(({ hidden: _hidden, ...p }) => p);
}

/** Property names HubSpot complained about in a validation error, if it said. */
export function invalidProperties(error: HubspotError): string[] {
  const body = (error.body ?? {}) as Body;
  const names = new Set<string>();
  for (const e of body.errors ?? []) for (const n of e.context?.propertyName ?? []) names.add(n);
  // Older shape: message text like 'Property values were not valid: [{"isValid":false,"name":"phone",...}]'
  for (const m of String(body.message ?? '').matchAll(/"name":"([a-z0-9_\-]+)"/gi)) names.add(m[1]);
  return [...names];
}

/**
 * Create or update the contact with this email. Updates first (by email), creates when there
 * is none, and handles the race where someone else created it in between.
 */
export async function upsertContact(token: string, email: string, properties: Record<string, string>): Promise<{ id: string; created: boolean }> {
  const props = { ...properties, email };
  try {
    const updated = await hubspotRequest<{ id: string }>(token, 'PATCH', `/crm/v3/objects/contacts/${encodeURIComponent(email)}?idProperty=email`, { properties: props });
    return { id: String(updated.id), created: false };
  } catch (error) {
    if (!(error instanceof HubspotError) || error.kind !== 'not_found') throw error;
  }
  try {
    const created = await hubspotRequest<{ id: string }>(token, 'POST', '/crm/v3/objects/contacts', { properties: props });
    return { id: String(created.id), created: true };
  } catch (error) {
    if (error instanceof HubspotError && error.kind === 'conflict') {
      const existing = String((error.body as Body | null)?.message ?? '').match(/Existing ID:\s*(\d+)/i)?.[1];
      if (existing) {
        const updated = await hubspotRequest<{ id: string }>(token, 'PATCH', `/crm/v3/objects/contacts/${existing}`, { properties: props });
        return { id: String(updated.id), created: false };
      }
    }
    throw error;
  }
}

/** A note on the contact's timeline (association type 202 = note → contact). */
export async function addContactNote(token: string, contactId: string, html: string): Promise<string> {
  const note = await hubspotRequest<{ id: string }>(token, 'POST', '/crm/v3/objects/notes', {
    properties: { hs_timestamp: new Date().toISOString(), hs_note_body: html },
    associations: [{ to: { id: contactId }, types: [{ associationCategory: 'HUBSPOT_DEFINED', associationTypeId: 202 }] }],
  });
  return String(note.id);
}
