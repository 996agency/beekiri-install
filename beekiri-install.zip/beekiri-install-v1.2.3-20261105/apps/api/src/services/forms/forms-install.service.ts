import { rm } from 'node:fs/promises';
import { join } from 'node:path';
import { FORMS_UPLOAD_DIR } from '../../lib/forms/constants';
import { resolveUploadsRoot } from '../../lib/media/media.paths';
import { revalidatePublicPaths } from '../../lib/revalidate-public';
import { BeeForm, BeeFormEntry } from '../../models';
import type { AuthUser } from '../../types/auth';
import { toHttpError } from '../../utils/http-error';
import { createLogger } from '../../utils/logger';

const log = createLogger('forms');

/** Extension lifecycle for Bee Forms. Forms and entries are plain rows: nothing to set up. */
export class FormsInstallService {
  async activate(_actor: AuthUser): Promise<void> {
    void revalidatePublicPaths(['/']);
  }

  async deactivate(_actor: AuthUser): Promise<void> {
    void revalidatePublicPaths(['/']);
  }

  /** With deleteData: every form, entry and uploaded file goes. */
  async uninstall(actor: AuthUser, opts: { deleteData: boolean }): Promise<void> {
    if (!opts.deleteData) return;
    try {
      await BeeFormEntry.destroy({ where: { siteId: actor.siteId } });
      await BeeForm.destroy({ where: { siteId: actor.siteId } });
      await rm(join(resolveUploadsRoot(), FORMS_UPLOAD_DIR), { recursive: true, force: true });
      log.warn('Bee Forms data removed on uninstall.');
    } catch (error) {
      throw toHttpError(error, 'Could not remove the forms data.');
    }
  }
}

export const formsInstallService = new FormsInstallService();
