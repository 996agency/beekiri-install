import { Op } from 'sequelize';
import {
  INTEGRATION_PROVIDERS,
  buildHubspotProperties,
  consentGiven,
  noteBody,
  type EntryContext,
  type HubspotFeed,
  type HubspotProperty,
} from '../../lib/forms/integrations';
import { parseFormFields, parseFormSettings } from '../../lib/forms/schema';
import { decryptSecret, encryptSecret, maskSecret, secretsPersist } from '../../lib/shop/secrets';
import { AuditLog, BeeForm, BeeFormEntry, sequelize } from '../../models';
import { BeeFormIntegration } from '../../models/bee-form-integration.model';
import type { AuthUser } from '../../types/auth';
import { BadRequest, NotFound, toHttpError } from '../../utils/http-error';
import { createLogger } from '../../utils/logger';
import {
  HUBSPOT_SCOPES,
  HubspotError,
  accountDetails,
  addContactNote,
  contactProperties,
  invalidProperties,
  upsertContact,
  type HubspotAccount,
} from './hubspot.client';

const log = createLogger('forms:hubspot');

/** Wait before attempt 2, 3, … (attempt 1 runs right after the entry is saved). */
const RETRY_DELAYS_MS = [60_000, 5 * 60_000, 30 * 60_000, 2 * 3600_000, 6 * 3600_000];
const MAX_ATTEMPTS = RETRY_DELAYS_MS.length + 1;

export type SyncStatus = 'pending' | 'synced' | 'failed' | 'skipped';

export type HubspotSyncState = {
  status: SyncStatus;
  attempts: number;
  nextAt: string | null;
  contactId: string;
  contactUrl: string;
  created: boolean;
  error: string;
  warnings: string[];
  syncedAt: string | null;
  updatedAt: string;
};

type Conn = { row: BeeFormIntegration; token: string; account: HubspotAccount };

const statusPath = (key: 'status' | 'nextAt') =>
  sequelize.fn('jsonb_extract_path_text', sequelize.col('BeeFormEntry.meta'), 'integrations', 'hubspot', key);

function contactUrl(account: Partial<HubspotAccount>, contactId: string): string {
  if (!account.portalId || !contactId) return '';
  return `https://${account.uiDomain || 'app.hubspot.com'}/contacts/${account.portalId}/record/0-1/${contactId}`;
}

export class IntegrationsService {
  private propertyCache = new Map<string, { at: number; props: HubspotProperty[] }>();
  private inFlight = new Set<string>();

  /* ── Connections ───────────────────────────────────────────────────── */

  private async connection(siteId: string): Promise<Conn | null> {
    const row = await BeeFormIntegration.findOne({ where: { siteId, provider: 'hubspot' } });
    if (!row) return null;
    const token = decryptSecret(row.credentials);
    if (!token) return null;
    return { row, token, account: (row.account ?? {}) as HubspotAccount };
  }

  async list(actor: AuthUser) {
    try {
      const rows = await BeeFormIntegration.findAll({ where: { siteId: actor.siteId } });
      return {
        scopes: HUBSPOT_SCOPES,
        /** False when keys would be lost on restart (no CACHE_FLUSH_SECRET in .env, file not writable). */
        keysPersist: secretsPersist(),
        providers: INTEGRATION_PROVIDERS.map((p) => {
          const row = rows.find((r) => r.provider === p.id);
          const token = row ? decryptSecret(row.credentials) : '';
          const account = (row?.account ?? {}) as Partial<HubspotAccount>;
          return {
            id: p.id,
            name: p.name,
            status: p.status,
            connected: Boolean(row && token),
            health: row ? (token ? row.status : 'error') : null,
            lastError: row ? (token ? row.lastError : 'Your saved HubSpot token can no longer be read: the server’s encryption secret changed (it was not saved in .env before). Paste the token again to reconnect; your form mappings are kept.') : '',
            unreadable: Boolean(row && !token),
            tokenHint: token ? maskSecret(token) : '',
            account: row ? { portalId: account.portalId ?? null, uiDomain: account.uiDomain ?? '', timeZone: account.timeZone ?? '', dataHostingLocation: account.dataHostingLocation ?? '' } : null,
            connectedAt: row ? row.createdAt.toISOString() : null,
          };
        }),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load the integrations.');
    }
  }

  /** Checks the token can read the account and contact properties before saving it. */
  private async verify(token: string): Promise<{ account: HubspotAccount; properties: HubspotProperty[] }> {
    try {
      const properties = await contactProperties(token);
      let account: HubspotAccount = { portalId: null, uiDomain: 'app.hubspot.com', timeZone: '', dataHostingLocation: '' };
      try {
        account = await accountDetails(token);
      } catch (error) {
        // Account details are nice to have (contact links); the token itself works.
        log.warn(`HubSpot account details unavailable: ${(error as Error).message}`);
      }
      return { account, properties };
    } catch (error) {
      if (error instanceof HubspotError) {
        if (error.kind === 'auth') throw BadRequest('HubSpot did not accept this token. Copy the access token of the private app again (it starts with “pat-”).');
        if (error.kind === 'scope') throw BadRequest(`This private app is missing permissions. In HubSpot, give it these scopes: ${HUBSPOT_SCOPES.join(', ')}.`);
        throw BadRequest(error.message);
      }
      throw error;
    }
  }

  async connectHubspot(actor: AuthUser, rawToken: string) {
    try {
      const token = rawToken.trim();
      if (token.length < 20 || /\s/.test(token)) throw BadRequest('Paste the whole access token of the HubSpot private app.');
      const { account, properties } = await this.verify(token);
      const existing = await BeeFormIntegration.findOne({ where: { siteId: actor.siteId, provider: 'hubspot' } });
      const data = { credentials: encryptSecret(token), account, status: 'connected', lastError: '', connectedById: actor.id };
      if (existing) await existing.update(data);
      else await BeeFormIntegration.create({ siteId: actor.siteId, provider: 'hubspot', ...data });
      this.propertyCache.set(actor.siteId, { at: Date.now(), props: properties });
      await this.audit(actor, 'forms.integration.connected', { provider: 'hubspot', portalId: account.portalId });
      return this.list(actor);
    } catch (error) {
      throw toHttpError(error, 'Could not connect HubSpot.');
    }
  }

  async testHubspot(actor: AuthUser) {
    try {
      const conn = await this.connection(actor.siteId);
      if (!conn) throw BadRequest('HubSpot is not connected.');
      try {
        const { account, properties } = await this.verify(conn.token);
        await conn.row.update({ account, status: 'connected', lastError: '' });
        this.propertyCache.set(actor.siteId, { at: Date.now(), props: properties });
        return { ok: true as const, message: `Connected to HubSpot account ${account.portalId ?? ''}. ${properties.length} contact properties available.`.replace('  ', ' ') };
      } catch (error) {
        const message = (error as Error).message;
        await conn.row.update({ status: 'error', lastError: message });
        return { ok: false as const, message };
      }
    } catch (error) {
      throw toHttpError(error, 'Could not test the connection.');
    }
  }

  async disconnect(actor: AuthUser, provider: string) {
    try {
      await BeeFormIntegration.destroy({ where: { siteId: actor.siteId, provider } });
      this.propertyCache.delete(actor.siteId);
      await this.audit(actor, 'forms.integration.disconnected', { provider });
      return this.list(actor);
    } catch (error) {
      throw toHttpError(error, 'Could not disconnect.');
    }
  }

  async hubspotProperties(actor: AuthUser, refresh = false): Promise<{ items: HubspotProperty[] }> {
    try {
      const conn = await this.connection(actor.siteId);
      if (!conn) throw NotFound('HubSpot is not connected.');
      return { items: await this.properties(conn, actor.siteId, refresh) };
    } catch (error) {
      if (error instanceof HubspotError) throw BadRequest(error.message);
      throw toHttpError(error, 'Could not load the HubSpot properties.');
    }
  }

  private async properties(conn: Conn, siteId: string, refresh = false): Promise<HubspotProperty[]> {
    const cached = this.propertyCache.get(siteId);
    if (!refresh && cached && Date.now() - cached.at < 10 * 60_000) return cached.props;
    const props = await contactProperties(conn.token);
    this.propertyCache.set(siteId, { at: Date.now(), props });
    return props;
  }

  /* ── Sync ──────────────────────────────────────────────────────────── */

  private feedReady(feed: HubspotFeed): boolean {
    return feed.mapping.some((m) => m.property === 'email');
  }

  /** Called right after an entry is stored. Never throws. */
  async onEntryCreated(entryId: string): Promise<void> {
    try {
      const entry = await BeeFormEntry.findByPk(entryId);
      if (!entry) return;
      const form = await BeeForm.findByPk(entry.formId);
      const feed = parseFormSettings(form?.settings).integrations.hubspot;
      if (!form || !feed.enabled || !this.feedReady(feed)) return;
      if (!(await this.connection(entry.siteId))) return;
      await this.writeState(entry, { status: 'pending', attempts: 0, nextAt: new Date().toISOString() });
      await this.syncEntry(entry.id);
    } catch (error) {
      log.warn(`Could not queue entry ${entryId} for HubSpot: ${(error as Error).message}`);
    }
  }

  /** For forms that do not keep entries: one attempt, nothing stored. */
  async syncTransient(siteId: string, form: BeeForm, ctx: EntryContext): Promise<void> {
    try {
      const feed = parseFormSettings(form.settings).integrations.hubspot;
      if (!feed.enabled || !this.feedReady(feed) || !consentGiven(feed, ctx)) return;
      const conn = await this.connection(siteId);
      if (!conn) return;
      await this.send(conn, siteId, feed, ctx);
    } catch (error) {
      log.warn(`HubSpot sync failed for an unsaved entry of “${form.title}”: ${(error as Error).message}`);
    }
  }

  /** Admin "Send to HubSpot" / "Retry". */
  async retry(actor: AuthUser, entryId: string) {
    try {
      const entry = await BeeFormEntry.findOne({ where: { id: entryId, siteId: actor.siteId } });
      if (!entry) throw NotFound('Entry not found.');
      const conn = await this.connection(actor.siteId);
      if (!conn) throw BadRequest('Connect HubSpot first (Forms → Integrations).');
      const form = await BeeForm.findByPk(entry.formId);
      const feed = parseFormSettings(form?.settings).integrations.hubspot;
      if (!this.feedReady(feed)) throw BadRequest('Map an Email field to the HubSpot “Email” property in this form’s Integrations tab first.');
      await this.writeState(entry, { status: 'pending', attempts: 0, nextAt: new Date().toISOString(), error: '' });
      return { state: await this.syncEntry(entry.id, true) };
    } catch (error) {
      throw toHttpError(error, 'Could not send the entry to HubSpot.');
    }
  }

  /** Re-queue entries that failed in the last 30 days (after fixing the token or the mapping). */
  async retryFailed(actor: AuthUser) {
    try {
      const rows = await BeeFormEntry.findAll({
        where: {
          siteId: actor.siteId,
          createdAt: { [Op.gt]: new Date(Date.now() - 30 * 86_400_000) },
          [Op.and]: [sequelize.where(statusPath('status'), 'failed')],
        },
        attributes: ['id', 'meta'],
        limit: 1000,
      });
      for (const row of rows) await this.writeState(row, { status: 'pending', attempts: 0, nextAt: new Date().toISOString(), error: '' });
      void this.sweep();
      return { queued: rows.length };
    } catch (error) {
      throw toHttpError(error, 'Could not retry the failed entries.');
    }
  }

  /** Runs due retries (every minute, and once at boot so pending work survives restarts). */
  async sweep(): Promise<void> {
    try {
      const rows = await BeeFormEntry.findAll({
        where: {
          createdAt: { [Op.gt]: new Date(Date.now() - 3 * 86_400_000) },
          [Op.and]: [sequelize.where(statusPath('status'), 'pending'), sequelize.where(statusPath('nextAt'), { [Op.lte]: new Date().toISOString() })],
        },
        attributes: ['id'],
        order: [['createdAt', 'ASC']],
        limit: 25,
      });
      for (const row of rows) await this.syncEntry(row.id);
    } catch (error) {
      log.warn(`HubSpot retry sweep failed: ${(error as Error).message}`);
    }
  }

  private async writeState(entry: BeeFormEntry, patch: Partial<HubspotSyncState>): Promise<HubspotSyncState> {
    const fresh = (await BeeFormEntry.findByPk(entry.id)) ?? entry;
    const meta = (fresh.meta ?? {}) as Record<string, unknown>;
    const ints = (meta.integrations ?? {}) as Record<string, Partial<HubspotSyncState>>;
    const prev = ints.hubspot ?? {};
    const state: HubspotSyncState = {
      status: 'pending',
      attempts: 0,
      nextAt: null,
      contactId: '',
      contactUrl: '',
      created: false,
      error: '',
      warnings: [],
      syncedAt: null,
      ...prev,
      ...patch,
      updatedAt: new Date().toISOString(),
    };
    await fresh.update({ meta: { ...meta, integrations: { ...ints, hubspot: state } } });
    return state;
  }

  private async contextFor(entry: BeeFormEntry): Promise<{ ctx: EntryContext; feed: HubspotFeed } | null> {
    const form = await BeeForm.findByPk(entry.formId);
    if (!form) return null;
    return {
      feed: parseFormSettings(form.settings).integrations.hubspot,
      ctx: {
        fields: parseFormFields(form.fields),
        values: (entry.data ?? {}) as Record<string, unknown>,
        meta: (entry.meta ?? {}) as Record<string, unknown>,
        formTitle: form.title,
        entryId: entry.id,
        createdAt: entry.createdAt,
      },
    };
  }

  /** One attempt for one stored entry; records the outcome on the entry. */
  async syncEntry(entryId: string, manual = false): Promise<HubspotSyncState | null> {
    if (this.inFlight.has(entryId)) return null;
    this.inFlight.add(entryId);
    try {
      const entry = await BeeFormEntry.findByPk(entryId);
      if (!entry) return null;
      const prev = (((entry.meta ?? {}) as Record<string, unknown>).integrations as Record<string, HubspotSyncState> | undefined)?.hubspot;
      const attempts = (prev?.attempts ?? 0) + 1;
      const conn = await this.connection(entry.siteId);
      if (!conn) return this.writeState(entry, { status: 'failed', attempts, nextAt: null, error: 'HubSpot is not connected. Connect it under Forms → Integrations, then retry.' });
      const loaded = await this.contextFor(entry);
      if (!loaded) return this.writeState(entry, { status: 'failed', attempts, nextAt: null, error: 'The form was deleted.' });
      const { ctx, feed } = loaded;
      if (!manual && !consentGiven(feed, ctx)) return this.writeState(entry, { status: 'skipped', attempts, nextAt: null, error: 'Not sent: the visitor did not tick the consent field.' });

      try {
        const result = await this.send(conn, entry.siteId, feed, ctx);
        if (conn.row.status !== 'connected') await conn.row.update({ status: 'connected', lastError: '' });
        return this.writeState(entry, {
          status: result.skipped ? 'skipped' : 'synced',
          attempts,
          nextAt: null,
          contactId: result.contactId,
          contactUrl: contactUrl(conn.account, result.contactId),
          created: result.created,
          error: result.skipped ?? '',
          warnings: result.warnings,
          syncedAt: result.skipped ? null : new Date().toISOString(),
        });
      } catch (error) {
        const e = error instanceof HubspotError ? error : new HubspotError('network', (error as Error).message);
        if (e.kind === 'auth' || e.kind === 'scope') await conn.row.update({ status: 'error', lastError: e.message });
        const retry = e.retryable && attempts < MAX_ATTEMPTS;
        log.warn(`HubSpot sync of entry ${entry.id} failed (attempt ${attempts}): ${e.message}`);
        return this.writeState(entry, {
          status: retry ? 'pending' : 'failed',
          attempts,
          nextAt: retry ? new Date(Date.now() + RETRY_DELAYS_MS[attempts - 1]).toISOString() : null,
          error: retry ? `${e.message} Retrying automatically.` : e.message,
        });
      }
    } finally {
      this.inFlight.delete(entryId);
    }
  }

  /** Builds the properties, upserts the contact (dropping values HubSpot rejects), adds the note. */
  private async send(conn: Conn, siteId: string, feed: HubspotFeed, ctx: EntryContext) {
    let schema = new Map<string, HubspotProperty>();
    try {
      schema = new Map((await this.properties(conn, siteId)).map((p) => [p.name, p]));
    } catch (error) {
      if (error instanceof HubspotError && (error.kind === 'auth' || error.kind === 'scope')) throw error;
      // Property list unavailable: send plain values, HubSpot still validates them.
    }
    const { properties, warnings } = buildHubspotProperties(feed, ctx, schema);
    const email = properties.email ?? '';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
      return { contactId: '', created: false, warnings, skipped: 'Not sent: this entry has no valid email address for HubSpot.' };
    }
    delete properties.email;
    let result: { id: string; created: boolean };
    try {
      result = await upsertContact(conn.token, email, properties);
    } catch (error) {
      if (!(error instanceof HubspotError) || error.kind !== 'validation') throw error;
      // Drop the properties HubSpot named (or, if it named none, everything but the email) and try once more.
      const bad = invalidProperties(error).filter((n) => n !== 'email');
      const keep = bad.length ? Object.fromEntries(Object.entries(properties).filter(([k]) => !bad.includes(k))) : {};
      const dropped = bad.length ? bad : Object.keys(properties);
      if (!dropped.length) throw error;
      warnings.push(`HubSpot rejected ${dropped.map((n) => schema.get(n)?.label ?? n).join(', ')} (${error.message}); the contact was saved without ${dropped.length === 1 ? 'it' : 'them'}.`);
      result = await upsertContact(conn.token, email, keep);
    }
    if (feed.addNote) {
      try {
        await addContactNote(conn.token, result.id, noteBody(ctx));
      } catch (error) {
        warnings.push(`The contact was saved, but the note could not be added: ${(error as Error).message}`);
      }
    }
    return { contactId: result.id, created: result.created, warnings, skipped: undefined as string | undefined };
  }

  private async audit(actor: AuthUser, action: string, meta: Record<string, unknown>) {
    try {
      await AuditLog.create({ siteId: actor.siteId, userId: actor.id, action, meta });
    } catch {
      /* never blocks */
    }
  }
}

export const integrationsService = new IntegrationsService();
