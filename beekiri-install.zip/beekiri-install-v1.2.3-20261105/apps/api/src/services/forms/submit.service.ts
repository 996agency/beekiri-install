import { mkdir, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { config } from '../../config/env';
import { attributionOf, parseTouch } from '../../lib/forms/attribution';
import { renderFormEmail } from '../../lib/forms/emails';
import { answeredFields, mergeRecipients, mergeText, type MergeContext, type StoredFile } from '../../lib/forms/merge';
import { valueFields, type FormDefinition, type FormField } from '../../lib/forms/schema';
import { checkFormToken } from '../../lib/forms/token';
import { validateSubmission, type IncomingFile } from '../../lib/forms/validate';
import { isLikelyBot } from '../../lib/site/bee-cookies-bots';
import { countryFromRequest } from '../../lib/site/bee-cookies-geo';
import { browserOf, osOf } from '../../lib/site/bee-cookies-ua';
import { BeeForm, BeeFormEntry, User } from '../../models';
import { BadRequest, NotFound, UnprocessableEntity } from '../../utils/http-error';
import { createId } from '../../utils/ids';
import { createLogger } from '../../utils/logger';
import { rateLimit } from '../../utils/rate-limit';
import { mailService } from '../mail.service';
import { findPrimarySite } from '../site-context';
import { entryFileDir } from './entries.service';
import { definitionOf, formsService } from './forms.service';
import { integrationsService } from './integrations.service';

const log = createLogger('forms');

export type SubmitRequest = {
  formId: string;
  /** Text fields keyed by input name (`f_<fieldId>`), repeated keys as arrays. */
  body: Record<string, string | string[] | undefined>;
  files: { fieldname: string; originalname: string; mimetype: string; size: number; buffer: Buffer }[];
  ip: string;
  userAgent: string;
  /** Page the form was on (sent by the script). */
  pageUrl: string;
  pageTitle: string;
  referrer: string;
  /** JSON the site script sends: this visit's and the first visit's source, plus client hints. */
  attribution: string;
  /** Request header reader (country from CDN headers, Accept-Language, Host). */
  header: (name: string) => string | undefined;
};

export type SubmitResult =
  | { ok: true; entryId: string; confirmation: { type: 'message'; message: string } | { type: 'redirect'; url: string } }
  | { ok: false; errors: { field: string; message: string }[] };

const PREFIX = 'f_';

export class SubmitService {
  async submit(req: SubmitRequest): Promise<SubmitResult> {
    const row = await formsService.publicRow(req.formId);
    if (!row) throw NotFound('This form is not available.');
    const def = definitionOf(row);

    // Spam: honeypot, time token, bots, per-IP and per-form floods.
    const hp = req.body._bk_hp;
    if ((Array.isArray(hp) ? hp.join('') : hp ?? '') !== '') return this.spamOk(def);
    const tokenRaw = req.body._bk_t;
    const check = checkFormToken(row.id, Array.isArray(tokenRaw) ? tokenRaw[0] : tokenRaw ?? '', def.settings.minSeconds);
    if (!check.ok) {
      if (check.reason === 'too_fast') return this.spamOk(def);
      throw BadRequest({ message: 'This form took too long to send. Please try again.', code: 'token' });
    }
    if (isLikelyBot(req.userAgent)) return this.spamOk(def);
    const flood = rateLimit(`forms:${req.ip}`, 10, 10 * 60_000);
    if (!flood.ok) throw BadRequest('Too many submissions. Please wait a few minutes and try again.');
    const formFlood = rateLimit(`forms:form:${row.id}`, 120, 60_000);
    if (!formFlood.ok) throw BadRequest('This form is busy right now. Please try again shortly.');

    // Values + files → validation.
    const values: Record<string, string | string[] | undefined> = {};
    for (const [k, v] of Object.entries(req.body)) {
      if (k.startsWith(PREFIX)) values[k.slice(PREFIX.length)] = v;
    }
    const incoming: IncomingFile[] = req.files
      .filter((f) => f.fieldname.startsWith(PREFIX))
      .map((f) => ({ fieldId: f.fieldname.slice(PREFIX.length), name: safeName(f.originalname), mime: f.mimetype, size: f.size }));
    const result = validateSubmission(def.fields, { values, files: incoming });
    if (result.errors.length) return { ok: false, errors: result.errors };

    // Persist (files to the private folder, then the row).
    const entryId = createId();
    const data: Record<string, unknown> = {};
    const fileFields = valueFields(def.fields).filter((f) => f.type === 'file');
    try {
      for (const f of valueFields(def.fields)) {
        if (!(f.id in result.values)) continue;
        if (f.type === 'file') {
          data[f.id] = await this.storeFiles(entryId, req.files.filter((x) => x.fieldname === PREFIX + f.id));
        } else {
          data[f.id] = result.values[f.id];
        }
      }
    } catch (error) {
      await rm(entryFileDir(entryId), { recursive: true, force: true });
      throw error;
    }

    const site = await findPrimarySite();
    const owner = site ? await User.findOne({ where: { siteId: site.id, isOwner: true }, attributes: ['email'] }) : null;
    const meta = { ...visitorMeta(req), fillSeconds: Math.round(check.ageMs / 1000) };
    const ctx: MergeContext = {
      formTitle: row.title,
      fields: def.fields,
      values: data,
      entryId,
      pageUrl: meta.pageUrl,
      siteTitle: site?.title?.trim() || 'Beekiri',
      adminEmail: owner?.email ?? '',
      date: new Date(),
      fileUrl: (file) => `${(config.urls.app ?? '').replace(/\/+$/, '')}/api/forms/entries/${entryId}/files/${file.id}`,
    };

    if (def.settings.storeEntries || fileFields.length) {
      await BeeFormEntry.create({
        id: entryId,
        siteId: row.siteId,
        formId: row.id,
        status: 'unread',
        data,
        labels: Object.fromEntries(valueFields(def.fields).map((f) => [f.id, { label: f.label, name: f.name, type: f.type }])),
        meta,
        summary: summaryOf(def.fields, data),
      });
      await BeeForm.update(
        { entryCount: row.entryCount + 1, unreadCount: row.unreadCount + 1, lastEntryAt: new Date() },
        { where: { id: row.id } },
      );
      // CRM feeds (HubSpot…) run after the entry is safe; a CRM problem never fails the form.
      void integrationsService.onEntryCreated(entryId);
    } else {
      await BeeForm.update({ entryCount: row.entryCount + 1, lastEntryAt: new Date() }, { where: { id: row.id } });
      void integrationsService.syncTransient(row.siteId, row, { fields: def.fields, values: data, meta, formTitle: row.title, entryId, createdAt: new Date() });
    }

    void this.sendEmails(def, ctx);

    const c = def.settings.confirmation;
    return {
      ok: true,
      entryId,
      confirmation:
        c.type === 'redirect' && c.url
          ? { type: 'redirect', url: mergeText(c.url, ctx) }
          : { type: 'message', message: mergeText(c.type === 'message' ? c.message : 'Thanks! Your message has been sent.', ctx) },
    };
  }

  /** Bots get the normal success answer so they learn nothing; nothing is stored or sent. */
  private spamOk(def: FormDefinition): SubmitResult {
    const c = def.settings.confirmation;
    return {
      ok: true,
      entryId: createId(),
      confirmation: c.type === 'redirect' && c.url ? { type: 'redirect', url: c.url } : { type: 'message', message: c.type === 'message' ? c.message : 'Thanks!' },
    };
  }

  private async storeFiles(entryId: string, files: SubmitRequest['files']): Promise<StoredFile[]> {
    const dir = entryFileDir(entryId);
    const out: StoredFile[] = [];
    if (!files.length) return out;
    await mkdir(dir, { recursive: true });
    for (const f of files) {
      const id = createId();
      await writeFile(join(dir, id), f.buffer, { flag: 'wx' });
      out.push({ id, name: safeName(f.originalname), mime: f.mimetype.toLowerCase().split(';')[0], size: f.size });
    }
    return out;
  }

  private async sendEmails(def: FormDefinition, ctx: MergeContext) {
    const n = def.settings.notification;
    if (n.enabled) {
      try {
        const to = mergeRecipients(n.to, ctx);
        if (to.length) {
          const rendered = renderFormEmail(n.subject, n.message, ctx);
          const replyField = def.fields.find((f) => f.name === n.replyToField);
          const replyTo = replyField ? String(ctx.values[replyField.id] ?? '') : '';
          for (const addr of to) {
            await mailService.sendMail({ to: addr, subject: rendered.subject, text: rendered.text, html: rendered.html, ...(replyTo ? { replyTo } : {}) });
          }
        }
      } catch (error) {
        log.warn(`Notification email failed for entry ${ctx.entryId}: ${(error as Error).message}`);
      }
    }
    const a = def.settings.autoReply;
    if (a.enabled) {
      try {
        const field =
          (a.toField ? def.fields.find((f) => f.name === a.toField && f.type === 'email') : undefined) ??
          def.fields.find((f) => f.type === 'email');
        const to = field ? String(ctx.values[field.id] ?? '').trim() : '';
        if (to && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(to)) {
          const rendered = renderFormEmail(a.subject, a.message, ctx);
          await mailService.sendMail({ to, subject: rendered.subject, text: rendered.text, html: rendered.html });
        }
      } catch (error) {
        log.warn(`Auto-reply failed for entry ${ctx.entryId}: ${(error as Error).message}`);
      }
    }
  }
}

/** Source of the visit, first visit (when the visitor allowed it), and who/where they are. */
export function visitorMeta(req: SubmitRequest) {
  let hints: Record<string, unknown> = {};
  try {
    const parsed = JSON.parse(req.attribution || '{}') as unknown;
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) hints = parsed as Record<string, unknown>;
  } catch {
    hints = {};
  }
  const str = (v: unknown, max: number) => (typeof v === 'string' ? v.slice(0, max) : '');
  const siteHost = (req.header('host') ?? '').split(':')[0];
  // The page the form was sent from wins when it carries tracking tags the recorded visit lacks
  // (e.g. a tagged link opened in a tab that already had an older visit).
  const pageTouch = parseTouch({ landingUrl: req.pageUrl, referrer: req.referrer, params: paramsOf(req.pageUrl), at: Date.now() });
  const recorded = parseTouch(hints.visit);
  const pageTagged = Boolean(pageTouch?.params && Object.keys(pageTouch.params).length);
  const usePage = pageTagged && JSON.stringify(pageTouch?.params) !== JSON.stringify(recorded?.params ?? {});
  const visitTouch = usePage ? pageTouch : (recorded ?? pageTouch);
  const firstTouch = parseTouch(hints.first);
  const visit = attributionOf(visitTouch, siteHost);
  const first = firstTouch ? attributionOf(firstTouch, siteHost) : null;
  const pagesRaw = usePage ? 1 : (hints.visit as { pages?: unknown } | undefined)?.pages;
  const timeZone = str(hints.timeZone, 64);
  const language = str(hints.language, 40);
  return {
    ip: req.ip,
    userAgent: req.userAgent.slice(0, 300),
    pageUrl: req.pageUrl.slice(0, 2000),
    pageTitle: req.pageTitle.slice(0, 300),
    referrer: req.referrer.slice(0, 2000),
    attribution: { visit, first },
    country: countryFromRequest({ get: req.header }, { timeZone, locale: language }) ?? '',
    device: deviceOf(req.userAgent),
    browser: browserOf(req.userAgent),
    os: osOf(req.userAgent),
    language,
    timeZone,
    screen: str(hints.screen, 20),
    viewport: str(hints.viewport, 20),
    pagesViewed: typeof pagesRaw === 'number' && Number.isFinite(pagesRaw) ? Math.min(10_000, Math.max(1, Math.round(pagesRaw))) : null,
    timeOnSiteSeconds: visit.at ? Math.max(0, Math.round((Date.now() - Date.parse(visit.at)) / 1000)) : null,
  };
}

function paramsOf(url: string): Record<string, string> {
  try {
    return Object.fromEntries(new URL(url).searchParams);
  } catch {
    return {};
  }
}

function deviceOf(ua: string): 'desktop' | 'mobile' | 'tablet' | 'unknown' {
  if (/iPad|Tablet|PlayBook/i.test(ua)) return 'tablet';
  if (/Mobi|Android|iPhone|iPod|webOS|BlackBerry/i.test(ua)) return 'mobile';
  return ua ? 'desktop' : 'unknown';
}

function safeName(name: string): string {
  const base = name.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').trim().slice(0, 150);
  return base || 'file';
}

function summaryOf(fields: FormField[], data: Record<string, unknown>): string {
  const parts: string[] = [];
  for (const f of valueFields(fields)) {
    if (f.type === 'hidden' || f.type === 'consent' || f.type === 'file') continue;
    const v = data[f.id];
    const text = Array.isArray(v) ? v.join(', ') : String(v ?? '');
    if (text.trim()) parts.push(text.trim().replace(/\s+/g, ' '));
    if (parts.join(' · ').length > 140) break;
  }
  return parts.join(' · ').slice(0, 200);
}

export { answeredFields, UnprocessableEntity };
export const submitService = new SubmitService();
