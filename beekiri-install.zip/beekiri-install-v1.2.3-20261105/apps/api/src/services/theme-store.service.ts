import { createHash } from 'crypto';
import { readFileSync, writeFileSync } from 'fs';
import { join } from 'path';
import { config } from '../config/env';
import { getSelfUrl } from '../config/runtime';
import { HubError, hubJson, hubRequest, hubUrl } from '../lib/hub/hub-client';
import { readOptions } from '../lib/site/site-options';
import { getThemeManifest, resolveThemeDir } from '../lib/themes/theme-registry';
import { HttpError } from '../utils/http-error';
import { findPrimarySite } from './site-context';
import { themeContentService } from './theme-content.service';
import { themesService } from './themes.service';

/** Same cap the Hub applies to theme packages. */
const MAX_PACKAGE_BYTES = 100 * 1024 * 1024;

type HubTheme = {
  slug: string;
  name: string;
  tagline: string | null;
  description: string | null;
  version: string;
  price: number;
  priceLabel: string;
  free: boolean;
  owned: boolean;
  pending: boolean;
  screenshotUrl: string | null;
  demoUrl: string | null;
  tags: string[];
  size: number;
  /** This site's licence: which sites use it (local / staging / production) and whether this one may. */
  licence: {
    state: 'active' | 'available' | 'full';
    environment: string;
    limit: number;
    message: string | null;
    buyer: string | null;
    sites: { environment: string; domain: string | null; current: boolean }[];
  } | null;
};

export type StoreTheme = Omit<HubTheme, 'screenshotUrl'> & {
  /** Served through this site (/api/themes/store/:slug/screenshot). */
  hasScreenshot: boolean;
  /** Changes when the Hub gets a new screenshot, so the admin's cached copy is replaced. */
  screenshotVersion: string | null;
  installed: boolean;
  installedVersion: string | null;
  active: boolean;
  /** The theme ships ready-made pages (content/), and whether this site installed them. */
  hasContent: boolean;
  contentInstalled: boolean;
};

export type StoreCatalog = {
  available: boolean;
  error?: string;
  currency: string;
  paymentMethod: 'stripe' | 'paypal' | 'manual';
  themes: StoreTheme[];
};

function asHttp(error: unknown): HttpError {
  if (error instanceof HubError) return new HttpError(error.status >= 500 || error.status < 400 ? 502 : error.status, { message: error.message });
  if (error instanceof HttpError) return error;
  return new HttpError(502, { message: 'The theme store is unavailable right now.' });
}

/** The theme store in Appearance → Templates: the Hub's catalog merged with what is installed here. */
export class ThemeStoreService {
  async catalog(): Promise<StoreCatalog> {
    let data: { currency: string; paymentMethod: StoreCatalog['paymentMethod']; themes: HubTheme[] };
    try {
      data = await hubJson('/themes');
    } catch (error) {
      return { available: false, error: asHttp(error).message, currency: 'USD', paymentMethod: 'manual', themes: [] };
    }
    const active = await themesService.getActiveSlug();
    const themes = await Promise.all(
      data.themes.map(async ({ screenshotUrl, ...t }) => {
        const local = getThemeManifest(t.slug);
        const content = local ? await themeContentService.status(t.slug).catch(() => null) : null;
        return {
          ...t,
          hasScreenshot: Boolean(screenshotUrl),
          screenshotVersion: screenshotUrl?.match(/[?&]v=([\w-]+)/)?.[1] ?? null,
          installed: Boolean(local),
          installedVersion: local?.version ?? null,
          active: active === t.slug,
          hasContent: content?.hasContent ?? false,
          contentInstalled: content?.installed ?? false,
        };
      }),
    );
    return { available: true, currency: data.currency, paymentMethod: data.paymentMethod, themes };
  }

  /** Starts buying a theme. Card payments return a checkout link; otherwise the purchase waits for 996Agency. */
  async purchase(slug: string): Promise<{ status: 'owned' | 'pending' | 'checkout'; checkoutUrl: string | null }> {
    try {
      return await hubJson(`/themes/${encodeURIComponent(slug)}/purchase`, {
        method: 'POST',
        body: JSON.stringify({ returnUrl: await this.returnUrl() }),
      });
    } catch (error) {
      throw asHttp(error);
    }
  }

  /** Downloads an owned theme from the Hub, checks it, and installs it like an uploaded ZIP. */
  async install(slug: string) {
    let res: Response;
    try {
      res = await hubRequest(`/themes/${encodeURIComponent(slug)}/download`, { timeoutMs: 120_000 });
    } catch (error) {
      throw asHttp(error);
    }
    if (!res.ok) {
      const data = (await res.json().catch(() => ({}))) as { message?: string };
      throw new HttpError([402, 403, 404].includes(res.status) ? res.status : 502, {
        message: data.message || 'The theme could not be downloaded.',
      });
    }
    const declared = Number(res.headers.get('content-length') ?? 0);
    if (declared > MAX_PACKAGE_BYTES) throw new HttpError(413, { message: 'That theme package is too large.' });
    const buffer = Buffer.from(await res.arrayBuffer());
    if (buffer.length > MAX_PACKAGE_BYTES) throw new HttpError(413, { message: 'That theme package is too large.' });

    // The Hub states the package checksum; a mismatch means a broken or altered download.
    const expected = (res.headers.get('x-theme-sha256') ?? '').trim().toLowerCase();
    if (expected && createHash('sha256').update(buffer).digest('hex') !== expected) {
      throw new HttpError(502, { message: 'The downloaded theme did not match its checksum. Try again.' });
    }

    const result = await themesService.uploadZip(buffer, `${slug}.zip`);
    if (result.installed !== slug) {
      throw new HttpError(502, { message: 'The theme package has an unexpected name. Contact 996Agency.' });
    }
    // Mark it as a store theme, so its licence is checked wherever the folder goes (migrations too).
    const dir = resolveThemeDir(slug);
    if (dir) {
      try {
        const file = join(dir, 'theme.json');
        const meta = JSON.parse(readFileSync(file, 'utf8')) as Record<string, unknown>;
        if (meta.licence !== 'beekiri-hub') writeFileSync(file, `${JSON.stringify({ ...meta, licence: 'beekiri-hub' }, null, 2)}\n`, 'utf8');
      } catch {
        // theme.json was validated by uploadZip; nothing else to do.
      }
    }
    return result;
  }

  /** Proxies a store screenshot so the admin never loads images from another origin. */
  async screenshot(slug: string): Promise<{ type: string; body: Buffer } | null> {
    try {
      const res = await fetch(`${await hubUrl()}/api/beekiri/v1/themes/${encodeURIComponent(slug)}/screenshot`, {
        signal: AbortSignal.timeout(15_000),
      });
      const type = res.headers.get('content-type') ?? '';
      if (!res.ok || !/^image\/(png|jpe?g|webp)/i.test(type)) return null;
      const body = Buffer.from(await res.arrayBuffer());
      return body.length <= 10 * 1024 * 1024 ? { type, body } : null;
    } catch {
      return null;
    }
  }

  /** Where checkout sends the admin back: Appearance → Templates on this site. */
  private async returnUrl(): Promise<string | null> {
    const base = (config.urls.app ?? getSelfUrl() ?? '').replace(/\/+$/, '');
    if (!base) return null;
    const site = await findPrimarySite();
    const admin = readOptions(site?.settings?.options).adminBasePath || '/admin';
    return `${base}${admin}/appearance/templates`;
  }
}

export const themeStoreService = new ThemeStoreService();
