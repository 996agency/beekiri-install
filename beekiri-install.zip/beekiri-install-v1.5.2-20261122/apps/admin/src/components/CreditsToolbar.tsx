import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import {
  BEEKIRI_AGENT_ACTIVITY,
  BEEQUEEN_CREDITS,
  CONNECTOR_CHANGED,
  currentBeekiriActivity,
  openBeekiriChat,
  type BeekiriAgentActivity,
  type BeeQueenCreditsDetail,
} from '../lib/admin-events';
import { CONNECTOR_COMING_SOON } from '../lib/features';
import { formatMoney } from '../lib/money';
import { BeekiriOrb } from './BeekiriOrb';
import './credits-toolbar.css';

type Status = { usage?: { enabled: boolean; balance?: number; currency?: string } };

/**
 * Toolbar: the site's prepaid Beekiri balance ("Balance $18.40"). While Beekiri works — on any
 * page, even after moving away from the chat — it shows that it is working, the current step,
 * and what the message has cost so far.
 */
export function CreditsToolbar() {
  const auth = useAuth();
  const allowed =
    !CONNECTOR_COMING_SOON && Boolean(auth.user?.isOwner || auth.user?.capabilities.includes('use_beequeen'));
  const [balance, setBalance] = useState<{ amount: number; currency: string } | null>(null);
  const [run, setRun] = useState<{ running: boolean; cost: number } | null>(null);
  const fadeRef = useRef<number | null>(null);
  /** Starts from what is going on now: the toolbar may appear mid-run (opening the page editor). */
  const [working, setWorking] = useState<BeekiriAgentActivity>(currentBeekiriActivity);

  useEffect(() => {
    const onActivity = (e: Event) => setWorking((e as CustomEvent<BeekiriAgentActivity>).detail);
    window.addEventListener(BEEKIRI_AGENT_ACTIVITY, onActivity);
    return () => window.removeEventListener(BEEKIRI_AGENT_ACTIVITY, onActivity);
  }, []);

  const load = useCallback(() => {
    if (!allowed) return;
    api<Status>('/api/connector/beequeen/status')
      .then((s) => {
        const u = s.usage;
        setBalance(u?.enabled && typeof u.balance === 'number' ? { amount: u.balance, currency: u.currency || 'USD' } : null);
      })
      .catch(() => setBalance(null));
  }, [allowed]);

  useEffect(() => {
    load();
    window.addEventListener(CONNECTOR_CHANGED, load);
    return () => window.removeEventListener(CONNECTOR_CHANGED, load);
  }, [load]);

  useEffect(() => {
    const onUsage = (e: Event) => {
      const d = (e as CustomEvent<BeeQueenCreditsDetail>).detail;
      if (typeof d.balance === 'number') {
        const amount = d.balance;
        setBalance((b) => (b ? { ...b, amount } : b));
      }
      if (fadeRef.current) window.clearTimeout(fadeRef.current);
      // A reply that cost nothing (thanks, small talk) shows no "this message" badge.
      if (!d.running && !d.runCost) {
        setRun(null);
        return;
      }
      setRun({ running: d.running, cost: typeof d.runCost === 'number' ? d.runCost : 0 });
      // Keep "this message" in view for a moment after the run, then settle back to the balance.
      if (!d.running) {
        fadeRef.current = window.setTimeout(() => setRun(null), 8000);
        load();
      }
    };
    window.addEventListener(BEEQUEEN_CREDITS, onUsage);
    return () => {
      window.removeEventListener(BEEQUEEN_CREDITS, onUsage);
      if (fadeRef.current) window.clearTimeout(fadeRef.current);
    };
  }, [load]);

  if (!allowed || (!balance && !working.running)) return null;

  // Working: on every page, with or without a prepaid balance — click to watch it in the chat.
  if (working.running) {
    const step = working.step && working.step !== 'Getting started' ? working.step : '';
    return (
      <button
        type="button"
        className="bk-credits is-running is-working"
        title="Beekiri is working and keeps going while you use other pages. Click to open the chat."
        onClick={openBeekiriChat}
        aria-live="polite"
      >
        <BeekiriOrb size={16} busy />
        <span className="bk-credits__label">Beekiri is working</span>
        {step ? <span className="bk-credits__step">{step}</span> : null}
        {balance && run?.cost ? (
          <span className="bk-credits__run is-live">−{formatMoney(run.cost, balance.currency, true)} so far</span>
        ) : null}
      </button>
    );
  }
  if (!balance) return null;

  const empty = balance.amount <= 0;
  const left = formatMoney(Math.max(0, balance.amount), balance.currency);

  const body = (
    <>
      <img src="/admin/connector/claude.svg" alt="" width={14} height={14} draggable={false} className="bk-credits__icon" />
      <span className="bk-credits__label">Balance</span>
      <span className="bk-credits__value">
        <strong>{left}</strong>
        {empty ? <span className="bk-credits__total"> — add money</span> : null}
      </span>
      {run ? (
        <span className={`bk-credits__run${run.running ? ' is-live' : ''}`} aria-live="polite">
          {run.running
            ? run.cost
              ? `−${formatMoney(run.cost, balance.currency, true)} so far`
              : 'working…'
            : `−${formatMoney(run.cost, balance.currency, true)} this message`}
        </span>
      ) : null}
    </>
  );
  const title = empty
    ? 'Your Beekiri balance is empty. An administrator can add money on the Connector page'
    : `${left} left on your Beekiri balance. Each message is paid from this balance`;
  const className = `bk-credits${run?.running ? ' is-running' : ''}${empty ? ' is-empty' : ''}`;

  // Clicking opens the Beekiri chat (the balance and top-ups live on the Connector page).
  return (
    <button type="button" className={className} title={`${title}. Click to open Beekiri.`} onClick={openBeekiriChat}>
      {body}
    </button>
  );
}
