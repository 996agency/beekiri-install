import { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import './human-check.css';

/**
 * The "are you human" check: Cloudflare Turnstile, Google reCAPTCHA v2 (the "I'm not a robot"
 * box) or reCAPTCHA v3 (invisible; Google scores the visitor when the form is sent). Used on the
 * sign-in screens and to test keys in Settings → Security. Each service's script loads once.
 */

export type CaptchaProvider = 'turnstile' | 'recaptcha-v2' | 'recaptcha-v3';

type WidgetApi = {
  render: (el: HTMLElement, options: Record<string, unknown>) => string | number;
  reset: (id?: string | number) => void;
  remove?: (id: string | number) => void;
  getResponse?: (id?: string | number) => string;
  execute?: (siteKey: string, options: { action: string }) => Promise<string>;
  ready?: (cb: () => void) => void;
};

declare global {
  interface Window {
    turnstile?: WidgetApi;
    grecaptcha?: WidgetApi;
    __bkHumanTs?: () => void;
    __bkHumanRc?: () => void;
    __bkHumanRc3?: () => void;
  }
}

const loading = new Map<string, Promise<WidgetApi>>();

function load(provider: CaptchaProvider, siteKey: string): Promise<WidgetApi> {
  const key = provider === 'recaptcha-v3' ? `${provider}:${siteKey}` : provider;
  const running = loading.get(key);
  if (running) return running;
  const job = new Promise<WidgetApi>((resolve, reject) => {
    let src: string;
    if (provider === 'turnstile') {
      if (window.turnstile) return resolve(window.turnstile);
      window.__bkHumanTs = () => (window.turnstile ? resolve(window.turnstile) : reject(new Error('turnstile')));
      src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=__bkHumanTs';
    } else if (provider === 'recaptcha-v2') {
      window.__bkHumanRc = () => (window.grecaptcha ? resolve(window.grecaptcha) : reject(new Error('recaptcha')));
      src = 'https://www.google.com/recaptcha/api.js?render=explicit&onload=__bkHumanRc';
    } else {
      window.__bkHumanRc3 = () => window.grecaptcha?.ready?.(() => resolve(window.grecaptcha!));
      src = `https://www.google.com/recaptcha/api.js?render=${encodeURIComponent(siteKey)}&onload=__bkHumanRc3`;
    }
    const script = document.createElement('script');
    script.src = src;
    script.async = true;
    script.onerror = () => {
      loading.delete(key);
      reject(new Error('Couldn’t load the security check. Check your connection and refresh the page.'));
    };
    document.head.appendChild(script);
  });
  loading.set(key, job);
  return job;
}

export type HumanCheckHandle = {
  /** The answer to send ('' when the visitor hasn't completed the check). */
  getToken: () => Promise<string>;
  reset: () => void;
};

type Props = {
  provider: CaptchaProvider;
  siteKey: string;
  theme?: 'light' | 'dark';
  /** reCAPTCHA v3: what is being done (login, password_reset, settings_test). */
  action?: string;
  onError?: (message: string) => void;
};

export const HumanCheck = forwardRef<HumanCheckHandle, Props>(function HumanCheck({ provider, siteKey, theme = 'light', action = 'login', onError }, ref) {
  const box = useRef<HTMLDivElement>(null);
  const widget = useRef<string | number | null>(null);
  const api = useRef<WidgetApi | null>(null);
  const errorCb = useRef(onError);
  errorCb.current = onError;

  useImperativeHandle(
    ref,
    () => ({
      getToken: async () => {
        const a = api.current ?? (await load(provider, siteKey).catch(() => null));
        if (!a) return '';
        if (provider === 'recaptcha-v3') return (await a.execute?.(siteKey, { action }).catch(() => '')) ?? '';
        return widget.current !== null ? (a.getResponse?.(widget.current) ?? '') : '';
      },
      reset: () => {
        if (provider !== 'recaptcha-v3' && widget.current !== null) api.current?.reset(widget.current);
      },
    }),
    [provider, siteKey, action],
  );

  useEffect(() => {
    let live = true;
    load(provider, siteKey)
      .then((a) => {
        if (!live) return;
        api.current = a;
        if (provider === 'recaptcha-v3' || !box.current) return;
        widget.current = a.render(box.current, {
          sitekey: siteKey,
          theme,
          ...(provider === 'turnstile' ? { size: 'flexible' } : {}),
          'error-callback': () => errorCb.current?.('The security check couldn’t start. Refresh the page and try again.'),
        });
      })
      .catch((e: Error) => errorCb.current?.(e.message));
    return () => {
      live = false;
      const id = widget.current;
      if (id !== null && provider === 'turnstile') {
        try {
          api.current?.remove?.(id);
        } catch {
          /* already gone */
        }
      }
      widget.current = null;
    };
  }, [provider, siteKey, theme]);

  if (provider === 'recaptcha-v3') {
    return (
      <p className="bk-human is-invisible">
        Protected by reCAPTCHA. Google’s{' '}
        <a href="https://policies.google.com/privacy" target="_blank" rel="noreferrer">
          Privacy Policy
        </a>{' '}
        and{' '}
        <a href="https://policies.google.com/terms" target="_blank" rel="noreferrer">
          Terms
        </a>{' '}
        apply.
      </p>
    );
  }
  return <div ref={box} className="bk-human" />;
});
