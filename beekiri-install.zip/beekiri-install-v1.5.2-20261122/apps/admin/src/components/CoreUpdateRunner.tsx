import { useCallback, useEffect, useRef, useState } from 'react';
import { api, ApiError } from '../api/client';
import { confirmDialog } from './ConfirmDialog';

type UpdateJob = {
  state?: 'running' | 'done' | 'error';
  step?: string;
  progress?: number;
  message?: string;
  detail?: string;
  version?: string;
  restartRequired?: boolean;
  updatedAt?: string;
};

/** `restartable`: Beekiri restarts itself onto the new version (it runs with `npm start`). */
type Progress = { currentVersion: string; job: UpdateJob | null; restartable?: boolean };

const POLL_MS = 1200;

export function CoreUpdateRunner({ latestVersion }: { latestVersion: string }) {
  const [job, setJob] = useState<UpdateJob | null>(null);
  const [restartable, setRestartable] = useState(true);
  const [restarting, setRestarting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [starting, setStarting] = useState(false);
  const timer = useRef<number | null>(null);

  const stop = () => {
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = null;
  };

  const poll = useCallback(async () => {
    try {
      const p = await api<Progress>('/api/system/updates/progress');
      setRestarting(false);
      setJob(p.job);
      setRestartable(p.restartable !== false);
      if (p.job?.state === 'error') {
        setError(p.job.message ?? 'The update didn’t finish. Try again in a moment.');
        return;
      }
      if (p.job?.state === 'done' && p.job.version && p.currentVersion === p.job.version) {
        window.setTimeout(() => window.location.reload(), 1500);
        return;
      }
      // Installed, and only a restart by whoever manages the server makes it live.
      if (p.job?.state === 'done' && p.job.restartRequired && p.restartable === false) return;
    } catch {
      // API restarts while core files change.
      setRestarting(true);
    }
    timer.current = window.setTimeout(() => void poll(), POLL_MS);
  }, []);

  useEffect(() => {
    void api<Progress>('/api/system/updates/progress')
      .then((p) => {
        setRestartable(p.restartable !== false);
        if (p.job?.state === 'running') {
          setJob(p.job);
          void poll();
        }
      })
      .catch(() => undefined);
    return stop;
  }, [poll]);

  const start = async () => {
    const ok = await confirmDialog({
      title: 'Update Beekiri',
      message:
        `Update Beekiri to v${latestVersion}?\n\nYour pages, media, users and settings stay as they are. Beekiri makes a backup before it starts` +
        (restartable
          ? ' and restarts by itself when the new version is ready.'
          : '.\n\nThis server can’t restart Beekiri by itself, so ask whoever manages it to restart Beekiri once the update is installed.'),
      confirmLabel: 'Update Beekiri',
    });
    if (!ok) return;
    setError(null);
    setStarting(true);
    try {
      await api('/api/system/updates/apply', { method: 'POST' });
      setJob({ state: 'running', progress: 1, message: 'Starting update…' });
      stop();
      void poll();
    } catch (e) {
      if (e instanceof ApiError && e.status === 404) {
        setError(
          'Beekiri needs to restart once before one-click updates work. Restart Beekiri (or ask whoever manages your server), then try again.',
        );
      } else {
        setError(e instanceof ApiError ? e.message : 'Couldn’t start the update. Try again in a moment.');
      }
    } finally {
      setStarting(false);
    }
  };

  const waitingForRestart = job?.state === 'done' && job.restartRequired && !restartable;
  const running = (job?.state === 'running' || job?.state === 'done') && !waitingForRestart;
  const pct = Math.max(0, Math.min(100, job?.progress ?? 0));
  const label = restarting
    ? 'Restarting Beekiri…'
    : job?.state === 'done'
      ? waitingForRestart
        ? `v${job.version} is installed. It goes live once Beekiri restarts: ask whoever manages your server to restart it.`
        : job.restartRequired
          ? `v${job.version} is installed. Restarting Beekiri…`
          : `v${job.version} is installed. Reloading…`
      : (job?.message ?? '');

  if (job && job.state !== 'error') {
    return (
      <div className="bk-core-update" role="status" aria-live="polite">
        <div className="bk-core-update__label">
          <span>{label}</span>
          <span>{pct}%</span>
        </div>
        <div
          className="bk-core-update__bar"
          role="progressbar"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={pct}
        >
          <span style={{ width: `${pct}%` }} />
        </div>
        {running ? (
          <p className="bk-muted" style={{ margin: '8px 0 0' }}>
            {restartable
              ? 'You can leave this page: Beekiri finishes the update and restarts by itself. Your content isn’t affected.'
              : 'Your content isn’t affected.'}
          </p>
        ) : null}
      </div>
    );
  }

  return (
    <>
      <button
        type="button"
        className="button button-primary"
        disabled={starting}
        onClick={() => void start()}
      >
        {starting ? 'Starting…' : `Update to v${latestVersion}`}
      </button>
      {error ? (
        <div className="beekiri-notice is-error" style={{ marginTop: 12, width: '100%' }}>
          <p style={{ margin: 0 }}>{error}</p>
          {job?.detail ? (
            <pre style={{ margin: '8px 0 0', whiteSpace: 'pre-wrap', fontSize: 11 }}>{job.detail}</pre>
          ) : null}
        </div>
      ) : null}
    </>
  );
}
