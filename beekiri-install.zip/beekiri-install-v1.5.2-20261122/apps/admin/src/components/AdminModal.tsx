import { useEffect, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { X } from '@phosphor-icons/react';
import './admin-modal.css';

/**
 * A dialog over the admin: title, body, and a footer of actions (the same look as the admin search
 * and the Bee Bookings dialogs). Esc or a click on the backdrop closes it.
 */
export function AdminModal({ title, onClose, children, footer, wide }: { title: ReactNode; onClose: () => void; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return createPortal(
    <div
      className="bk-modal"
      role="dialog"
      aria-modal="true"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className={`bk-modal__box${wide ? ' is-wide' : ''}`}>
        <div className="bk-modal__head">
          <h2>{title}</h2>
          <button type="button" className="bk-modal__close" onClick={onClose} aria-label="Close">
            <X size={16} aria-hidden />
          </button>
        </div>
        <div className="bk-modal__body">{children}</div>
        {footer ? <div className="bk-modal__foot">{footer}</div> : null}
      </div>
    </div>,
    document.getElementById('beekiri-admin') ?? document.body,
  );
}
