import { useState } from 'react';
import { ArrowsClockwise } from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { ErrorNotice } from './ErrorNotice';
import { SuccessNotice } from './SuccessNotice';

type FlushResult = { ok: boolean; cacheEpoch: number; web: { ok: boolean; message: string } };

/**
 * "Clear cache" in the toolbar: new addresses for theme and layout CSS/JS (browsers and CDNs
 * fetch them again), the website's page cache refreshed, and the PageSpeed scores in the toolbar dropped.
 */
export function ClearCacheToolbar() {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const clear = async () => {
    if (busy) return;
    setBusy(true);
    setDone(null);
    setError(null);
    try {
      const res = await api<FlushResult>('/api/system/cache/flush', { method: 'POST' });
      setDone(
        res.web.ok
          ? 'Cache cleared. Visitors now see the latest version of your website.'
          : `Cache partly cleared. Some pages may show the previous version for a little while: ${res.web.message}.`,
      );
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Couldn’t clear the cache. Try again in a moment.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <button
        type="button"
        className={`ab-item bk-toolbar-cache${busy ? ' is-busy' : ''}`}
        disabled={busy}
        aria-busy={busy}
        title="Clear the cache so visitors see your latest changes"
        onClick={() => void clear()}
      >
        <ArrowsClockwise size={18} aria-hidden />
        <span className="bk-toolbar-cache__label">{busy ? 'Clearing…' : 'Clear cache'}</span>
      </button>
      {done ? <SuccessNotice message={done} onDismiss={() => setDone(null)} /> : null}
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
    </>
  );
}
