import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { PublicUser } from '../cms-types';
import { api, setCsrfToken } from '../api/client';

/** What signing in with a password led to: in, or a code from the authenticator app comes next. */
export type LoginResult =
  | { done: true }
  | { done: false; mode: 'verify' | 'setup'; challenge: string };

/** The server's answer once someone is signed in. */
export type SignedIn = { user: PublicUser; csrfToken: string; recoveryCodes?: string[]; recoveryCodesLeft?: number };

type AuthState = {
  loading: boolean;
  authenticated: boolean;
  user: PublicUser | null;
  refresh: () => Promise<void>;
  login: (login: string, password: string, remember: boolean, humanToken?: string) => Promise<LoginResult>;
  /** Takes the session the server just opened (after the two-step code). */
  signedIn: (res: SignedIn) => void;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [loading, setLoading] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);
  const [user, setUser] = useState<PublicUser | null>(null);

  const refresh = useCallback(async () => {
    const me = await api<{
      authenticated: boolean;
      user?: PublicUser;
      csrfToken?: string;
    }>('/api/auth/me');
    setAuthenticated(me.authenticated);
    setUser(me.user ?? null);
    setCsrfToken(me.csrfToken ?? null);
  }, []);

  useEffect(() => {
    refresh()
      .catch(() => {
        setAuthenticated(false);
        setUser(null);
        setCsrfToken(null);
      })
      .finally(() => setLoading(false));
  }, [refresh]);

  const signedIn = useCallback((res: SignedIn) => {
    setCsrfToken(res.csrfToken);
    setUser(res.user);
    setAuthenticated(true);
  }, []);

  const login = useCallback(
    async (loginName: string, password: string, remember: boolean, humanToken?: string): Promise<LoginResult> => {
      const res = await api<SignedIn | { twoFactor: { mode: 'verify' | 'setup'; challenge: string } }>('/api/auth/login', {
        json: { login: loginName, password, remember, ...(humanToken ? { humanToken } : {}) },
      });
      if ('twoFactor' in res) return { done: false, ...res.twoFactor };
      signedIn(res);
      return { done: true };
    },
    [signedIn],
  );

  const logout = useCallback(async () => {
    await api('/api/auth/logout', { method: 'POST' });
    setCsrfToken(null);
    setUser(null);
    setAuthenticated(false);
  }, []);

  return (
    <AuthContext.Provider value={{ loading, authenticated, user, refresh, login, signedIn, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth outside provider');
  return ctx;
}
