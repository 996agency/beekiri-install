import { FormEvent, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import { HumanCheck, type CaptchaProvider, type HumanCheckHandle } from '../components/HumanCheck';
import { useAdminEntry } from '../lib/AdminEntryContext';
import { AuthShell } from './AuthShell';

export function LostPasswordScreen() {
  const entry = useAdminEntry();
  const [userLogin, setUserLogin] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const [devLink, setDevLink] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [human, setHuman] = useState<{ provider: CaptchaProvider; siteKey: string } | null>(null);
  const humanRef = useRef<HumanCheckHandle>(null);

  useEffect(() => {
    let live = true;
    api<{ humanCheck: { provider: CaptchaProvider; siteKey: string } | null }>('/api/auth/sign-in-options')
      .then((o) => live && setHuman(o.humanCheck))
      .catch(() => undefined);
    return () => {
      live = false;
    };
  }, []);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setMessage(null);
    setDevLink(null);
    try {
      const humanToken = human ? await humanRef.current?.getToken() : '';
      if (human && !humanToken) {
        setError('Complete the security check to continue.');
        return;
      }
      const res = await api<{ message: string; devResetLink?: string }>('/api/auth/lost-password', {
        json: { userLogin, ...(humanToken ? { humanToken } : {}) },
      });
      setMessage(res.message);
      if (res.devResetLink) setDevLink(res.devResetLink);
    } catch (err) {
      const body = err instanceof ApiError ? (err.body as { code?: string; provider?: CaptchaProvider; siteKey?: string } | null) : null;
      if (body?.code === 'human_check' && body.provider && body.siteKey) setHuman({ provider: body.provider, siteKey: body.siteKey });
      setError(err instanceof ApiError ? err.message : 'Couldn’t send the reset link. Check your connection and try again.');
    } finally {
      humanRef.current?.reset();
      setBusy(false);
    }
  };

  return (
    <AuthShell
      title="Forgot your password?"
      subtitle="Enter your email or username and we’ll send you a link to choose a new password."
      brandTo={entry.path}
      documentTitle="Reset password — Beekiri"
    >
      {error ? (
        <div className="bk-auth__alert" role="alert">
          {error}
        </div>
      ) : null}
      {message ? (
        <div className="bk-auth__ok" role="status">
          {message}
          {devLink ? (
            <>
              <br />
              <a href={devLink}>Open the reset link (test sites only)</a>
            </>
          ) : null}
        </div>
      ) : null}

      <form onSubmit={onSubmit}>
        <div className="bk-install__field">
          <label htmlFor="user_login">Email or username</label>
          <input
            className="regular-text"
            type="text"
            id="user_login"
            required
            value={userLogin}
            onChange={(e) => setUserLogin(e.target.value)}
          />
        </div>
        {human ? (
          <div className="bk-auth__human">
            <HumanCheck ref={humanRef} provider={human.provider} siteKey={human.siteKey} theme="dark" action="password_reset" onError={setError} />
          </div>
        ) : null}
        <div className="bk-auth__actions">
          <button
            type="submit"
            className="bk-install__btn bk-install__btn--primary"
            disabled={busy}
          >
            {busy ? 'Sending…' : 'Send reset link'}
          </button>
          <Link to={entry.path} className="bk-install__btn bk-install__btn--ghost">
            Back to sign in
          </Link>
        </div>
      </form>
    </AuthShell>
  );
}
