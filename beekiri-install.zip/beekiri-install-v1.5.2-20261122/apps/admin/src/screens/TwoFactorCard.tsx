import { useCallback, useEffect, useState, type KeyboardEvent } from 'react';
import { ShieldCheck, ShieldWarning } from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { RecoveryCodes } from './RecoveryCodes';

type OwnStatus = { enabled: boolean; enabledAt: string | null; recoveryCodesLeft: number; required: boolean };
type OtherStatus = { enabled: boolean; enabledAt: string | null; canReset: boolean };
type Setup = { secret: string; qrSvg: string; issuer: string; account: string };

/** What the card is doing right now (your own account). */
type Mode =
  | { kind: 'idle' }
  | { kind: 'password'; then: 'setup' | 'codes' }
  | { kind: 'scan'; setup: Setup }
  | { kind: 'codes'; codes: string[] }
  | { kind: 'disable' };

const message = (e: unknown, fallback: string) => (e instanceof ApiError ? e.message : fallback);
const day = (iso: string | null) =>
  iso ? new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' }) : '';

/** Enter inside the card must not save the whole profile form around it. */
const stopEnter = (run: () => void) => (e: KeyboardEvent<HTMLInputElement>) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    run();
  }
};

/**
 * Users → Edit: two-step sign-in. On your own profile you set it up (QR code, first code,
 * recovery codes), make new recovery codes or turn it off. On someone else's you see whether
 * they use it, and may turn it off for them when they lost their phone.
 */
export function TwoFactorCard({ userId, isSelf, name }: { userId: string; isSelf: boolean; name: string }) {
  const [own, setOwn] = useState<OwnStatus | null>(null);
  const [other, setOther] = useState<OtherStatus | null>(null);
  const [mode, setMode] = useState<Mode>({ kind: 'idle' });
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      if (isSelf) setOwn(await api<OwnStatus>('/api/auth/two-factor'));
      else setOther(await api<OtherStatus>(`/api/users/${encodeURIComponent(userId)}/two-factor`));
    } catch (e) {
      setError(message(e, 'Couldn’t load two-step sign-in. Refresh the page to try again.'));
    }
  }, [isSelf, userId]);

  useEffect(() => {
    void load();
  }, [load]);

  const reset = () => {
    setMode({ kind: 'idle' });
    setPassword('');
    setCode('');
    setError(null);
  };

  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await fn();
    } catch (e) {
      setError(message(e, 'That didn’t work. Check what you entered and try again.'));
    } finally {
      setBusy(false);
    }
  };

  const confirmPassword = () =>
    run(async () => {
      if (mode.kind !== 'password') return;
      if (mode.then === 'setup') {
        const setup = await api<Setup>('/api/auth/two-factor/setup', { json: { currentPassword: password } });
        setPassword('');
        setMode({ kind: 'scan', setup });
      } else {
        const res = await api<{ recoveryCodes: string[] }>('/api/auth/two-factor/recovery-codes', { json: { currentPassword: password } });
        setPassword('');
        setMode({ kind: 'codes', codes: res.recoveryCodes });
        await load();
      }
    });

  const turnOn = () =>
    run(async () => {
      const res = await api<{ recoveryCodes: string[] }>('/api/auth/two-factor/enable', { json: { code: code.trim() } });
      setCode('');
      setMode({ kind: 'codes', codes: res.recoveryCodes });
      await load();
    });

  const turnOff = () =>
    run(async () => {
      setOwn(await api<OwnStatus>('/api/auth/two-factor/disable', { json: { currentPassword: password, code: code.trim() } }));
      reset();
      setNotice('Two-step sign-in turned off. You now sign in with your password only.');
    });

  const resetOther = () =>
    run(async () => {
      if (!window.confirm(`Turn off two-step sign-in for ${name}? They’ll be signed out, and can then sign in with their password only until they set it up again.`)) return;
      setOther(await api<OtherStatus>(`/api/users/${encodeURIComponent(userId)}/two-factor`, { method: 'DELETE' }));
      setNotice(`Two-step sign-in turned off for ${name}. They’ve been signed out on every device.`);
    });

  const status = isSelf ? own : other;
  const on = Boolean(status?.enabled);

  return (
    <section className="bk-panel bk-2fa">
      <div className="bk-panel__head">
        <h2 className="bk-panel__title">Two-step sign-in</h2>
      </div>
      <div className="bk-panel__body bk-user-stack">
        {error ? (
          <p className="bk-2fa__error" role="alert">
            {error}
          </p>
        ) : null}
        {notice ? (
          <p className="bk-2fa__ok" role="status">
            {notice}
          </p>
        ) : null}

        {!status ? (
          <p className="description">Loading…</p>
        ) : (
          <p className={`bk-2fa__state${on ? ' is-on' : ''}`}>
            {on ? <ShieldCheck size={18} weight="fill" aria-hidden /> : <ShieldWarning size={18} aria-hidden />}
            <span>
              {on ? (
                <>
                  <strong>On</strong> since {day(status.enabledAt)}
                  {isSelf && own ? ` · ${own.recoveryCodesLeft} recovery code${own.recoveryCodesLeft === 1 ? '' : 's'} left` : ''}
                </>
              ) : (
                <>
                  <strong>Off</strong>
                </>
              )}
            </span>
          </p>
        )}

        {/* ── Someone else ── */}
        {!isSelf && other ? (
          <>
            <p className="description">
              {other.enabled
                ? `${name} confirms every sign-in with a code from an authenticator app.`
                : `${name} signs in with a password only. They can turn on two-step sign-in on their own profile.`}
            </p>
            {other.canReset ? (
              <button type="button" className="button" disabled={busy} onClick={() => void resetOther()}>
                Turn off for {name}
              </button>
            ) : null}
          </>
        ) : null}

        {/* ── Your own: idle ── */}
        {isSelf && own && mode.kind === 'idle' ? (
          <>
            <p className="description">
              {own.enabled
                ? 'When you sign in on a new browser, you enter your password and then a code from your authenticator app.'
                : 'After your password, you also enter a code from your phone, so a stolen password alone can’t open your account.'}
            </p>
            {own.required && !own.enabled ? (
              <p className="description">
                <strong>This site requires it for your account.</strong>
              </p>
            ) : null}
            {own.enabled ? (
              <div className="bk-2fa__actions">
                <button type="button" className="button" disabled={busy} onClick={() => setMode({ kind: 'password', then: 'codes' })}>
                  New recovery codes
                </button>
                {own.required ? null : (
                  <button type="button" className="button" disabled={busy} onClick={() => setMode({ kind: 'disable' })}>
                    Turn off
                  </button>
                )}
              </div>
            ) : (
              <button type="button" className="button button-primary" disabled={busy} onClick={() => setMode({ kind: 'password', then: 'setup' })}>
                Set up two-step sign-in
              </button>
            )}
            {own.enabled && own.required ? <p className="description">This site requires it for your account, so it stays on.</p> : null}
          </>
        ) : null}

        {/* ── Your own: confirm the password ── */}
        {isSelf && mode.kind === 'password' ? (
          <>
            <div className="bk-field">
              <label htmlFor="twofa_password">Your current password</label>
              <input
                id="twofa_password"
                type="password"
                autoComplete="current-password"
                autoFocus
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={stopEnter(() => void confirmPassword())}
              />
              <p className="description">
                {mode.then === 'setup' ? 'This confirms it’s you before you connect an app.' : 'Your current recovery codes will stop working.'}
              </p>
            </div>
            <div className="bk-2fa__actions">
              <button type="button" className="button button-primary" disabled={busy || !password} onClick={() => void confirmPassword()}>
                {busy ? 'Checking…' : 'Continue'}
              </button>
              <button type="button" className="button" disabled={busy} onClick={reset}>
                Cancel
              </button>
            </div>
          </>
        ) : null}

        {/* ── Your own: scan and confirm ── */}
        {isSelf && mode.kind === 'scan' ? (
          <>
            <p className="description">
              1. In your authenticator app (Google Authenticator, Microsoft Authenticator, 1Password, Authy…), add an account by scanning this code.
            </p>
            <div className="bk-2fa__qr">
              <img src={`data:image/svg+xml;charset=utf-8,${encodeURIComponent(mode.setup.qrSvg)}`} alt="QR code for your authenticator app" width={168} height={168} />
            </div>
            <p className="description">
              Can’t scan it? Enter this key: <code className="bk-2fa__key">{mode.setup.secret}</code>
            </p>
            <div className="bk-field">
              <label htmlFor="twofa_code">2. Enter the 6-digit code the app shows</label>
              <input
                id="twofa_code"
                className="bk-2fa__code"
                type="text"
                inputMode="numeric"
                autoComplete="one-time-code"
                maxLength={7}
                placeholder="123 456"
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/[^0-9 ]/g, ''))}
                onKeyDown={stopEnter(() => void turnOn())}
              />
            </div>
            <div className="bk-2fa__actions">
              <button type="button" className="button button-primary" disabled={busy || code.replace(/\s/g, '').length !== 6} onClick={() => void turnOn()}>
                {busy ? 'Checking…' : 'Turn on'}
              </button>
              <button type="button" className="button" disabled={busy} onClick={reset}>
                Cancel
              </button>
            </div>
          </>
        ) : null}

        {/* ── Your own: recovery codes (shown once) ── */}
        {isSelf && mode.kind === 'codes' ? (
          <>
            <p className="description">
              <strong>Save these recovery codes now.</strong> If you lose your phone, each one signs you in once. They won’t be shown again.
            </p>
            <RecoveryCodes codes={mode.codes} />
            <button type="button" className="button button-primary" onClick={reset}>
              I saved them
            </button>
          </>
        ) : null}

        {/* ── Your own: turn off ── */}
        {isSelf && mode.kind === 'disable' ? (
          <>
            <div className="bk-field">
              <label htmlFor="twofa_off_password">Your current password</label>
              <input id="twofa_off_password" type="password" autoComplete="current-password" autoFocus value={password} onChange={(e) => setPassword(e.target.value)} onKeyDown={stopEnter(() => void turnOff())} />
            </div>
            <div className="bk-field">
              <label htmlFor="twofa_off_code">A code from your app (or a recovery code)</label>
              <input id="twofa_off_code" type="text" autoComplete="one-time-code" value={code} onChange={(e) => setCode(e.target.value)} onKeyDown={stopEnter(() => void turnOff())} />
            </div>
            <div className="bk-2fa__actions">
              <button type="button" className="button" disabled={busy || !password || !code.trim()} onClick={() => void turnOff()}>
                {busy ? 'Turning off…' : 'Turn off two-step sign-in'}
              </button>
              <button type="button" className="button" disabled={busy} onClick={reset}>
                Cancel
              </button>
            </div>
          </>
        ) : null}
      </div>
    </section>
  );
}
