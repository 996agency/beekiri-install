import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowClockwise } from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { AdminDataTable, type AdminTableColumn, type AdminTableFilter } from '../components/AdminDataTable';
import { ErrorNotice } from '../components/ErrorNotice';
import { HumanCheck, type CaptchaProvider, type HumanCheckHandle } from '../components/HumanCheck';
import { SuccessNotice } from '../components/SuccessNotice';
import { useAdminHref } from '../lib/AdminEntryContext';
import './security-panel.css';

type Level = 'off' | 'balanced' | 'strict';
type Require = 'off' | 'admins' | 'everyone';
type Rule = { value: string; note: string; addedAt?: string };
type Ban = { ip: string; label: string; until: string; offenses: number; atCloudflare: boolean; bannedAt: string };
type Person = { id: string; name: string; email: string; role: string; isOwner: boolean; enabled: boolean; required: boolean };

/** GET /api/security: never a secret, only whether one is saved. */
type View = {
  shield: { level: Level; blockAttackTools: boolean; blockProbes: boolean; floodProtection: boolean; notify: boolean; blocked: Rule[]; allowed: Rule[] };
  twoFactor: { require: Require; youHaveIt: boolean; people: Person[] };
  captcha: { provider: CaptchaProvider; siteKey: string; hasSecret: boolean; signIn: boolean; forms: boolean; minScore: number };
  cloudflare: {
    detected: boolean;
    onlyCloudflare: boolean;
    api: { connected: boolean; zoneId: string; zoneName: string; edgeBans: boolean };
  };
  you: { ip: string; key: string; local: boolean; proxyWarning: boolean };
  stats: { blockedSinceStart: number; bansSinceStart: number; since: string; bans24h: number; failedLogins24h: number };
  bans: Ban[];
  secretsPersist: boolean;
  signedOut?: number;
};

type Activity = {
  id: string;
  at: string;
  action: string;
  category: 'bans' | 'sign-ins' | 'two-step' | 'settings';
  text: string;
  tone: 'danger' | 'warning' | 'info' | 'ok';
  ip: string | null;
};

type Section = 'shield' | 'bot-check' | 'cloudflare' | 'two-factor' | 'activity';
const SECTIONS: { id: Section; label: string }[] = [
  { id: 'shield', label: 'Beekiri Shield' },
  { id: 'bot-check', label: 'Bot check' },
  { id: 'cloudflare', label: 'Cloudflare' },
  { id: 'two-factor', label: 'Two-step sign-in' },
  { id: 'activity', label: 'Activity' },
];

const LEVELS: { id: Level; label: string; hint: string }[] = [
  { id: 'off', label: 'Off', hint: 'Only your block list applies. Nothing is banned automatically.' },
  {
    id: 'balanced',
    label: 'Balanced',
    hint: 'Recommended. Bans hacking tools, scanners, password guessers and floods. Real visitors and search engines never notice it.',
  },
  {
    id: 'strict',
    label: 'Strict',
    hint: 'Bans after half as many warning signs and at lower traffic. Use it while your site is under attack: visitors who click very fast may be paused briefly.',
  },
];

const PROVIDERS: { id: CaptchaProvider; label: string; keysFrom: ReactNode }[] = [
  {
    id: 'turnstile',
    label: 'Cloudflare Turnstile',
    keysFrom: (
      <>
        Free. In the Cloudflare dashboard open <strong>Turnstile → Add widget</strong>, add this site’s domain and copy the site key and secret key.{' '}
        <a href="https://dash.cloudflare.com/?to=/:account/turnstile" target="_blank" rel="noreferrer">
          Open Turnstile
        </a>
      </>
    ),
  },
  {
    id: 'recaptcha-v2',
    label: 'reCAPTCHA v2',
    keysFrom: (
      <>
        The “I’m not a robot” box. In the reCAPTCHA admin, create a site with type <strong>Challenge (v2) → “I’m not a robot” Checkbox</strong> and add this
        site’s domain.{' '}
        <a href="https://www.google.com/recaptcha/admin/create" target="_blank" rel="noreferrer">
          Open reCAPTCHA admin
        </a>
      </>
    ),
  },
  {
    id: 'recaptcha-v3',
    label: 'reCAPTCHA v3',
    keysFrom: (
      <>
        Invisible: Google scores each visitor and nobody has to click anything. In the reCAPTCHA admin, create a site with type <strong>Score based (v3)</strong> and add
        this site’s domain.{' '}
        <a href="https://www.google.com/recaptcha/admin/create" target="_blank" rel="noreferrer">
          Open reCAPTCHA admin
        </a>
      </>
    ),
  },
];

const REQUIRE: { id: Require; label: string; hint: string }[] = [
  { id: 'off', label: 'Optional', hint: 'Everyone chooses for themselves on their profile.' },
  { id: 'admins', label: 'Administrators', hint: 'The owner and administrators must use it. Recommended.' },
  { id: 'everyone', label: 'Everyone', hint: 'Everyone who signs in to this site must use it.' },
];

const CATEGORY_LABEL: Record<Activity['category'], string> = {
  bans: 'Shield',
  'sign-ins': 'Sign-in',
  'two-step': 'Two-step',
  settings: 'Settings',
};

const message = (e: unknown, fallback: string) => (e instanceof ApiError ? e.message : fallback);
const num = (n: number) => n.toLocaleString();

function timeLeft(iso: string): string {
  const ms = new Date(iso).getTime() - Date.now();
  if (ms <= 0) return 'Ending now';
  const min = Math.ceil(ms / 60_000);
  if (min < 60) return `${min} min left`;
  const h = Math.round(min / 60);
  return `${h} hour${h === 1 ? '' : 's'} left`;
}

function dateTime(iso?: string): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime()) || d.getTime() === 0) return '—';
  return d.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

type Save = (key: string, path: string, method: 'PUT' | 'POST' | 'DELETE', json: unknown, done: string | ((v: View) => string)) => Promise<boolean>;

/**
 * Settings → Security (the owner only): Beekiri Shield, the bot check on sign-in and forms,
 * Cloudflare, two-step sign-in for the people of this site, and what happened lately.
 */
export function SecuritySettingsPanel() {
  const [params, setParams] = useSearchParams();
  const raw = params.get('section');
  const section: Section = SECTIONS.some((s) => s.id === raw) ? (raw as Section) : 'shield';
  const [view, setView] = useState<View | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setView(await api<View>('/api/security'));
    } catch (e) {
      setError(message(e, 'Couldn’t load the security settings. Refresh the page to try again.'));
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const open = (id: Section) =>
    setParams(
      (prev) => {
        const next = new URLSearchParams(prev);
        next.set('section', id);
        return next;
      },
      { replace: true },
    );

  /** Runs a change; the server answers with the whole new view. */
  const save: Save = async (key, path, method, json, done) => {
    setBusy(key);
    setError(null);
    setNotice(null);
    try {
      const v = await api<View>(path, { method, ...(json === undefined ? {} : { json }) });
      setView(v);
      setNotice(typeof done === 'string' ? done : done(v));
      return true;
    } catch (e) {
      setError(message(e, 'Couldn’t save the change. Try again.'));
      return false;
    } finally {
      setBusy(null);
    }
  };

  if (!view) {
    return error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : <p className="bk-muted">Loading…</p>;
  }

  const peopleWith = view.twoFactor.people.filter((p) => p.enabled).length;
  const captchaOn = view.captcha.signIn || view.captcha.forms;

  return (
    <div className="bk-stack bk-sec">
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      {view.you.proxyWarning ? (
        <div className="beekiri-notice is-error">
          <p>
            Beekiri Shield can’t ban attackers yet. Your visit seems to come from <strong>{view.you.ip}</strong>, an address on this server’s own
            network, which means another server in front of Beekiri hides the real visitor addresses. Ask whoever manages your server to set{' '}
            <code>TRUST_PROXY</code> in <code>apps/api/.env</code> to that server’s address and restart Beekiri.
          </p>
        </div>
      ) : null}
      {!view.secretsPersist ? (
        <div className="beekiri-notice is-error">
          <p>Saved keys and two-step sign-in will be lost the next time the server restarts. Ask whoever manages your server to set CACHE_FLUSH_SECRET in apps/api/.env and restart Beekiri.</p>
        </div>
      ) : null}

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Overview</h2>
        </div>
        <div className="bk-panel__body">
          <dl className="bk-sec__stats">
            <div>
              <dt>Beekiri Shield</dt>
              <dd>{LEVELS.find((l) => l.id === view.shield.level)?.label}</dd>
            </div>
            <div>
              <dt>Banned right now</dt>
              <dd>{num(view.bans.length)}</dd>
            </div>
            <div>
              <dt>Bans (24 hours)</dt>
              <dd>{num(view.stats.bans24h)}</dd>
            </div>
            <div>
              <dt>Wrong passwords (24 hours)</dt>
              <dd>{num(view.stats.failedLogins24h)}</dd>
            </div>
            <div>
              <dt>Bot check</dt>
              <dd>{captchaOn ? PROVIDERS.find((p) => p.id === view.captcha.provider)?.label : 'Off'}</dd>
            </div>
            <div>
              <dt>Two-step sign-in</dt>
              <dd>
                {peopleWith} of {view.twoFactor.people.length}
              </dd>
            </div>
          </dl>
        </div>
      </div>

      <nav className="bk-tabs" role="tablist" aria-label="Security sections">
        {SECTIONS.map((s) => (
          <button
            key={s.id}
            type="button"
            role="tab"
            aria-selected={section === s.id}
            className={`bk-tabs__item${section === s.id ? ' is-active' : ''}`}
            onClick={() => open(s.id)}
          >
            {s.label}
            {s.id === 'shield' && view.bans.length ? <span className="bk-tabs__count">{view.bans.length}</span> : null}
          </button>
        ))}
      </nav>

      {section === 'shield' ? <ShieldSection view={view} busy={busy} save={save} /> : null}
      {section === 'bot-check' ? <BotCheckSection view={view} busy={busy} save={save} onError={setError} /> : null}
      {section === 'cloudflare' ? <CloudflareSection view={view} busy={busy} save={save} onError={setError} onNotice={setNotice} /> : null}
      {section === 'two-factor' ? <TwoFactorSection view={view} busy={busy} save={save} /> : null}
      {section === 'activity' ? <ActivitySection view={view} busy={busy} save={save} /> : null}
    </div>
  );
}

/** A panel like every other Settings panel: title, body. */
function Panel({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="bk-panel">
      <div className="bk-panel__head">
        <h2 className="bk-panel__title">{title}</h2>
      </div>
      <div className="bk-panel__body">{children}</div>
    </div>
  );
}

function Check({ checked, disabled, onChange, children }: { checked: boolean; disabled?: boolean; onChange: (v: boolean) => void; children: ReactNode }) {
  return (
    <label className={`bk-check${disabled ? ' is-disabled' : ''}`}>
      <input type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <span className="bk-check__box" aria-hidden />
      <span className="bk-check__label">{children}</span>
    </label>
  );
}

function Choice<T extends string>({ value, options, onChange, label }: { value: T; options: { id: T; label: string }[]; onChange: (v: T) => void; label: string }) {
  return (
    <div className="bk-tabs is-inline" role="tablist" aria-label={label}>
      {options.map((o) => (
        <button
          key={o.id}
          type="button"
          role="tab"
          aria-selected={value === o.id}
          className={`bk-tabs__item${value === o.id ? ' is-active' : ''}`}
          onClick={() => onChange(o.id)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

/* ── Beekiri Shield ──────────────────────────────────────────────────────── */

function ShieldSection({ view, busy, save }: { view: View; busy: string | null; save: Save }) {
  const [draft, setDraft] = useState(() => ({ ...view.shield }));
  useEffect(() => setDraft({ ...view.shield }), [view.shield]);

  const dirty =
    draft.level !== view.shield.level ||
    draft.blockAttackTools !== view.shield.blockAttackTools ||
    draft.blockProbes !== view.shield.blockProbes ||
    draft.floodProtection !== view.shield.floodProtection ||
    draft.notify !== view.shield.notify;
  const off = draft.level === 'off';

  /** Lists are saved the moment something is added or removed. */
  const saveLists = (blocked: Rule[], allowed: Rule[], done: string) =>
    save(
      'lists',
      '/api/security/lists',
      'PUT',
      { blocked: blocked.map(({ value, note }) => ({ value, note })), allowed: allowed.map(({ value, note }) => ({ value, note })) },
      done,
    );

  const banColumns: AdminTableColumn<Ban>[] = [
    {
      key: 'ip',
      header: 'Address',
      render: (b) => (
        <>
          <span className="bk-table__primary">{b.ip}</span>
          {b.atCloudflare ? <span className="bk-table__badge">Also at Cloudflare</span> : null}
          <div className="bk-table__row-actions">
            <button type="button" className="button-link" disabled={busy !== null} onClick={() => void save(`unban:${b.ip}`, '/api/security/unban', 'POST', { ip: b.ip }, `Ban lifted for ${b.ip}.`)}>
              Lift ban
            </button>
            {b.ip.includes('/') || view.shield.blocked.some((r) => r.value === b.ip) ? null : (
              <>
                <span className="bk-table__sep">|</span>
                <button
                  type="button"
                  className="button-link is-danger"
                  disabled={busy !== null}
                  onClick={() => void saveLists([...view.shield.blocked, { value: b.ip, note: b.label }], view.shield.allowed, `${b.ip} is now blocked permanently.`)}
                >
                  Block permanently
                </button>
              </>
            )}
          </div>
        </>
      ),
    },
    { key: 'why', header: 'Reason', render: (b) => b.label },
    { key: 'times', header: 'This week', render: (b) => `${b.offenses}×` },
    { key: 'since', header: 'Banned', render: (b) => dateTime(b.bannedAt) },
    { key: 'ends', header: 'Ends', render: (b) => timeLeft(b.until) },
  ];

  return (
    <>
      <Panel title="Beekiri Shield">
        <p className="bk-sec__intro">
          Watches every visit to this site. Addresses that use hacking tools, scan for weak spots, guess passwords or flood the site are banned for 15 minutes,
          then for 1, 6 and 24 hours if they come back. Browsers that have signed in to this admin before are never locked out.
        </p>
        <table className="form-table">
          <tbody>
            <tr>
              <th scope="row">Protection</th>
              <td>
                <Choice label="Protection level" value={draft.level} options={LEVELS} onChange={(level) => setDraft({ ...draft, level })} />
                <p className="description">{LEVELS.find((l) => l.id === draft.level)?.hint}</p>
              </td>
            </tr>
            <tr>
              <th scope="row">Watch for</th>
              <td>
                <div className="bk-sec__checks">
                  <Check checked={draft.blockAttackTools} disabled={off} onChange={(v) => setDraft({ ...draft, blockAttackTools: v })}>
                    Hacking tools (sqlmap, Nikto, WPScan, Nmap…): refused and banned straight away
                  </Check>
                  <Check checked={draft.blockProbes} disabled={off} onChange={(v) => setDraft({ ...draft, blockProbes: v })}>
                    Scanners and break-in attempts (looking for /wp-login.php, /.env or /.git, or code hidden in the address)
                  </Check>
                  <Check checked={draft.floodProtection} disabled={off} onChange={(v) => setDraft({ ...draft, floodProtection: v })}>
                    Request floods (more than {draft.level === 'strict' ? '120' : '300'} requests a minute from one address)
                  </Check>
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">Notifications</th>
              <td>
                <Check checked={draft.notify} onChange={(v) => setDraft({ ...draft, notify: v })}>
                  Tell me in the notification bell when an address is banned
                </Check>
              </td>
            </tr>
          </tbody>
        </table>
        <p className="submit bk-sec__submit">
          <button
            type="button"
            className="button button-primary"
            disabled={!dirty || busy !== null}
            onClick={() => void save('shield', '/api/security/shield', 'PUT', draft, 'Beekiri Shield settings saved.')}
          >
            {busy === 'shield' ? 'Saving…' : 'Save changes'}
          </button>
        </p>
      </Panel>

      <Panel title="Banned right now">
        <AdminDataTable rows={view.bans} columns={banColumns} getRowId={(b) => b.ip} emptyTitle="No addresses are banned right now. Bans appear here as soon as they happen." />
      </Panel>

      <RuleList
        title="Block list"
        intro="These addresses and networks can never open this site."
        placeholder="203.0.113.7 or 203.0.113.0/24"
        rules={view.shield.blocked}
        busy={busy}
        onChange={(blocked, done) => saveLists(blocked, view.shield.allowed, done)}
      />
      <RuleList
        title="Never block"
        intro="Your office or your own servers: the Shield never bans these, whatever they do."
        placeholder="Your office address"
        rules={view.shield.allowed}
        busy={busy}
        myAddress={view.you.ip && !view.you.local ? view.you.ip : undefined}
        onChange={(allowed, done) => saveLists(view.shield.blocked, allowed, done)}
      />
    </>
  );
}

function RuleList({
  title,
  intro,
  placeholder,
  rules,
  busy,
  myAddress,
  onChange,
}: {
  title: string;
  intro: string;
  placeholder: string;
  rules: Rule[];
  busy: string | null;
  myAddress?: string;
  onChange: (rules: Rule[], done: string) => Promise<boolean>;
}) {
  const [value, setValue] = useState('');
  const [note, setNote] = useState('');

  const add = async (v = value.trim(), n = note.trim()) => {
    if (!v) return;
    if (rules.some((r) => r.value === v)) {
      setValue('');
      setNote('');
      return;
    }
    if (await onChange([...rules, { value: v, note: n }], `${v} added to “${title}”.`)) {
      setValue('');
      setNote('');
    }
  };

  const columns: AdminTableColumn<Rule>[] = [
    {
      key: 'value',
      header: 'Address or network',
      render: (r) => (
        <>
          <span className="bk-table__primary">{r.value}</span>
          {r.value === myAddress ? <span className="bk-table__badge">You</span> : null}
          <div className="bk-table__row-actions">
            <button
              type="button"
              className="button-link is-danger"
              disabled={busy !== null}
              onClick={() => void onChange(rules.filter((x) => x.value !== r.value), `${r.value} removed from “${title}”.`)}
            >
              Remove
            </button>
          </div>
        </>
      ),
    },
    { key: 'note', header: 'Note', render: (r) => r.note || <span className="bk-table__muted">—</span> },
    { key: 'added', header: 'Added', render: (r) => dateTime(r.addedAt) },
  ];

  return (
    <Panel title={title}>
      <p className="bk-sec__intro">{intro}</p>
      <form
        className="bk-sec__add"
        onSubmit={(e) => {
          e.preventDefault();
          void add();
        }}
      >
        <input className="regular-text" placeholder={placeholder} aria-label={`${title}: address`} value={value} onChange={(e) => setValue(e.target.value)} />
        <input className="regular-text" placeholder="Note (optional)" aria-label={`${title}: note`} value={note} onChange={(e) => setNote(e.target.value)} />
        <button type="submit" className="button" disabled={!value.trim() || busy !== null}>
          Add
        </button>
        {myAddress && !rules.some((r) => r.value === myAddress) ? (
          <button type="button" className="button" disabled={busy !== null} onClick={() => void add(myAddress, 'My address')}>
            Add my address ({myAddress})
          </button>
        ) : null}
      </form>
      <AdminDataTable rows={rules} columns={columns} getRowId={(r) => r.value} emptyTitle="No addresses added yet." />
    </Panel>
  );
}

/* ── Bot check (Turnstile / reCAPTCHA) ───────────────────────────────────── */

function BotCheckSection({ view, busy, save, onError }: { view: View; busy: string | null; save: Save; onError: (m: string | null) => void }) {
  const c = view.captcha;
  const [draft, setDraft] = useState({ provider: c.provider, siteKey: c.siteKey, secretKey: '', signIn: c.signIn, forms: c.forms, minScore: c.minScore });
  const [needsTest, setNeedsTest] = useState(false);
  const testRef = useRef<HumanCheckHandle>(null);

  useEffect(() => {
    setDraft({ provider: c.provider, siteKey: c.siteKey, secretKey: '', signIn: c.signIn, forms: c.forms, minScore: c.minScore });
    setNeedsTest(false);
  }, [c]);

  const keysChanged = draft.provider !== c.provider || draft.siteKey.trim() !== c.siteKey || draft.secretKey.trim() !== '';
  const turningOn = (draft.signIn && !c.signIn) || (draft.forms && !c.forms);
  const dirty = keysChanged || draft.signIn !== c.signIn || draft.forms !== c.forms || draft.minScore !== c.minScore;
  const on = draft.signIn || draft.forms;
  // The test shows as soon as a check would be switched on with new or unproven keys.
  const showTest = on && (keysChanged || turningOn || needsTest) && /^[A-Za-z0-9_-]{10,}$/.test(draft.siteKey.trim());
  const provider = PROVIDERS.find((p) => p.id === draft.provider)!;

  const submit = async () => {
    let testToken = '';
    if (showTest) {
      testToken = (await testRef.current?.getToken()) ?? '';
      if (!testToken) {
        onError(draft.provider === 'recaptcha-v3' ? 'reCAPTCHA v3 didn’t respond. Check the site key, and that this domain is added to it in the reCAPTCHA admin.' : 'Complete the test check first.');
        return;
      }
    }
    const ok = await save(
      'captcha',
      '/api/security/captcha',
      'PUT',
      {
        provider: draft.provider,
        siteKey: draft.siteKey.trim(),
        ...(draft.secretKey.trim() ? { secretKey: draft.secretKey.trim() } : {}),
        signIn: draft.signIn,
        forms: draft.forms,
        minScore: draft.minScore,
        ...(testToken ? { testToken } : {}),
      },
      (v) =>
        v.captcha.signIn || v.captcha.forms
          ? `${provider.label} is on for ${[v.captcha.signIn && 'sign-in', v.captcha.forms && 'Bee Forms'].filter(Boolean).join(' and ')}.`
          : 'Bot check saved. It’s turned off.',
    );
    if (!ok) {
      setNeedsTest(true);
      testRef.current?.reset();
    }
  };

  return (
    <Panel title="Bot check">
      <p className="bk-sec__intro">
        Stops bots before they reach the sign-in page or your forms. Real people pass with one click or none at all. Pick a service, paste its two keys, and test
        them once: Beekiri switches the check on only after the service confirms the keys work, so a wrong key can never lock you out.
      </p>
      <table className="form-table">
        <tbody>
          <tr>
            <th scope="row">Service</th>
            <td>
              <Choice label="Bot check service" value={draft.provider} options={PROVIDERS} onChange={(p) => setDraft({ ...draft, provider: p })} />
              <p className="description">{provider.keysFrom}</p>
            </td>
          </tr>
          <tr>
            <th scope="row">
              <label htmlFor="captcha-site">Site key</label>
            </th>
            <td>
              <input id="captcha-site" className="regular-text" autoComplete="off" value={draft.siteKey} onChange={(e) => setDraft({ ...draft, siteKey: e.target.value })} />
            </td>
          </tr>
          <tr>
            <th scope="row">
              <label htmlFor="captcha-secret">Secret key</label>
            </th>
            <td>
              <input
                id="captcha-secret"
                className="regular-text"
                type="password"
                autoComplete="new-password"
                value={draft.secretKey}
                placeholder={c.hasSecret && draft.provider === c.provider ? 'Saved. Type a new one to replace it' : ''}
                onChange={(e) => setDraft({ ...draft, secretKey: e.target.value })}
              />
              <p className="description">Stored encrypted and never shown again.</p>
            </td>
          </tr>
          {draft.provider === 'recaptcha-v3' ? (
            <tr>
              <th scope="row">
                <label htmlFor="captcha-score">Minimum score</label>
              </th>
              <td>
                <select id="captcha-score" value={draft.minScore} onChange={(e) => setDraft({ ...draft, minScore: Number(e.target.value) })}>
                  <option value={0.3}>0.3 (lenient)</option>
                  <option value={0.5}>0.5 (recommended)</option>
                  <option value={0.7}>0.7 (strict)</option>
                  <option value={0.9}>0.9 (very strict)</option>
                </select>
                <p className="description">Google scores each visit from 0 (a bot) to 1 (a person). Lower scores are refused.</p>
              </td>
            </tr>
          ) : null}
          <tr>
            <th scope="row">Use it on</th>
            <td>
              <div className="bk-sec__checks">
                <Check checked={draft.signIn} onChange={(v) => setDraft({ ...draft, signIn: v })}>
                  Admin sign-in and “Forgot password”
                </Check>
                <Check checked={draft.forms} onChange={(v) => setDraft({ ...draft, forms: v })}>
                  Bee Forms on the website
                </Check>
              </div>
            </td>
          </tr>
          {showTest ? (
            <tr>
              <th scope="row">Test the keys</th>
              <td>
                <HumanCheck
                  key={`${draft.provider}:${draft.siteKey.trim()}`}
                  ref={testRef}
                  provider={draft.provider}
                  siteKey={draft.siteKey.trim()}
                  action="settings_test"
                  onError={(m) => onError(m)}
                />
                <p className="description">
                  {draft.provider === 'recaptcha-v3'
                    ? 'Beekiri asks Google for a score with these keys when you save.'
                    : 'Complete the check once with these keys, then save.'}
                </p>
              </td>
            </tr>
          ) : null}
        </tbody>
      </table>
      <p className="submit bk-sec__submit">
        <button type="button" className="button button-primary" disabled={!dirty || busy !== null} onClick={() => void submit()}>
          {busy === 'captcha' ? 'Checking the keys…' : 'Save changes'}
        </button>
      </p>
    </Panel>
  );
}

/* ── Cloudflare ──────────────────────────────────────────────────────────── */

function CloudflareSection({
  view,
  busy,
  save,
  onError,
  onNotice,
}: {
  view: View;
  busy: string | null;
  save: Save;
  onError: (m: string | null) => void;
  onNotice: (m: string | null) => void;
}) {
  const cf = view.cloudflare;
  const [apiDraft, setApiDraft] = useState({ token: '', zoneId: cf.api.zoneId, edgeBans: cf.api.connected ? cf.api.edgeBans : true });
  const [attack, setAttack] = useState<{ on: boolean } | null>(null);
  const [attackBusy, setAttackBusy] = useState(false);

  useEffect(() => {
    setApiDraft({ token: '', zoneId: cf.api.zoneId, edgeBans: cf.api.connected ? cf.api.edgeBans : true });
  }, [cf.api]);

  useEffect(() => {
    if (!cf.api.connected) {
      setAttack(null);
      return;
    }
    let live = true;
    api<{ on: boolean }>('/api/security/cloudflare/under-attack')
      .then((a) => live && setAttack(a))
      .catch(() => live && setAttack(null));
    return () => {
      live = false;
    };
  }, [cf.api.connected, cf.api.zoneId]);

  const toggleAttack = async (on: boolean) => {
    setAttackBusy(true);
    onError(null);
    onNotice(null);
    try {
      setAttack(await api<{ on: boolean }>('/api/security/cloudflare/under-attack', { method: 'PUT', json: { on } }));
      onNotice(on ? 'Under Attack mode is on: every visitor gets a short check from Cloudflare first.' : 'Under Attack mode is off.');
    } catch (e) {
      onError(message(e, 'Cloudflare didn’t accept the change. Check that the API token is still valid and try again.'));
    } finally {
      setAttackBusy(false);
    }
  };

  return (
    <>
      <Panel title="Cloudflare">
        <table className="form-table">
          <tbody>
            <tr>
              <th scope="row">Your visit</th>
              <td>
                <span className={`bk-table__badge ${cf.detected ? 'is-ok' : ''}`}>{cf.detected ? 'Through Cloudflare' : 'Not through Cloudflare'}</span>
                <p className="description">
                  {cf.detected
                    ? 'Beekiri sees each visitor’s real address through Cloudflare, so bans hit the attacker, never Cloudflare itself. There’s nothing to set up.'
                    : 'If your domain uses Cloudflare, switch on the orange cloud (proxy) for it in Cloudflare → DNS. Beekiri recognises Cloudflare by itself.'}
                </p>
              </td>
            </tr>
            <tr>
              <th scope="row">Direct visits</th>
              <td>
                <Check
                  checked={cf.onlyCloudflare}
                  disabled={busy !== null || (!cf.detected && !cf.onlyCloudflare)}
                  onChange={(v) =>
                    void save('origin', '/api/security/cloudflare/origin', 'PUT', { onlyCloudflare: v }, v ? 'Only visits through Cloudflare are allowed now.' : 'Direct visits are allowed again.')
                  }
                >
                  Refuse visits that skip Cloudflare
                </Check>
                <p className="description">
                  Attackers who find this server’s own address can go around Cloudflare. This can only be switched on while your own visit comes through Cloudflare,
                  so you can’t lock yourself out.
                </p>
              </td>
            </tr>
          </tbody>
        </table>
      </Panel>

      <Panel title="Cloudflare API">
        {cf.api.connected ? (
          <table className="form-table">
            <tbody>
              <tr>
                <th scope="row">Domain</th>
                <td>
                  <div className="bk-sec__inline">
                    <strong>{cf.api.zoneName || cf.api.zoneId}</strong>
                    <button
                      type="button"
                      className="button"
                      disabled={busy !== null}
                      onClick={() => void save('api-off', '/api/security/cloudflare/api', 'DELETE', undefined, 'Cloudflare disconnected and the API token deleted.')}
                    >
                      Disconnect
                    </button>
                  </div>
                </td>
              </tr>
              <tr>
                <th scope="row">Under Attack mode</th>
                <td>
                  {attack ? (
                    <button type="button" className={`button${attack.on ? '' : ' button-primary'}`} disabled={attackBusy} onClick={() => void toggleAttack(!attack.on)}>
                      {attackBusy ? 'Asking Cloudflare…' : attack.on ? 'Turn off Under Attack mode' : 'Turn on Under Attack mode'}
                    </button>
                  ) : null}
                  <p className="description">
                    {attack
                      ? attack.on
                        ? 'On: every visitor sees a short Cloudflare check before the site. Turn it off when the attack is over.'
                        : 'For a large attack from many addresses at once: Cloudflare checks every visitor for a few seconds first.'
                      : 'Couldn’t read the current mode from Cloudflare. Check that the API token has the “Zone Settings: Edit” permission.'}
                  </p>
                </td>
              </tr>
              <tr>
                <th scope="row">Block at Cloudflare</th>
                <td>
                  <Check
                    checked={cf.api.edgeBans}
                    disabled={busy !== null}
                    onChange={(v) => void save('api', '/api/security/cloudflare/api', 'PUT', { edgeBans: v }, v ? 'Shield bans now also go to Cloudflare.' : 'Shield bans stay on this server only.')}
                  >
                    Send every Shield ban to Cloudflare too
                  </Check>
                  <p className="description">The attacker is stopped before reaching this server. The block is removed at Cloudflare when the ban ends.</p>
                </td>
              </tr>
            </tbody>
          </table>
        ) : (
          <>
            <p className="bk-sec__intro">
              Optional. With an API token Beekiri can switch on Cloudflare’s Under Attack mode and block attackers at Cloudflare. Create one under{' '}
              <strong>My Profile → API Tokens → Create Token → Custom token</strong> with <strong>Zone · Zone Settings · Edit</strong> and{' '}
              <strong>Zone · Firewall Services · Edit</strong>, for this site’s domain only.
            </p>
            <table className="form-table">
              <tbody>
                <tr>
                  <th scope="row">
                    <label htmlFor="cf-token">API token</label>
                  </th>
                  <td>
                    <input id="cf-token" className="regular-text" type="password" autoComplete="new-password" value={apiDraft.token} onChange={(e) => setApiDraft({ ...apiDraft, token: e.target.value })} />
                    <p className="description">Stored encrypted and never shown again.</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="cf-zone">Zone ID</label>
                  </th>
                  <td>
                    <input id="cf-zone" className="regular-text" value={apiDraft.zoneId} onChange={(e) => setApiDraft({ ...apiDraft, zoneId: e.target.value })} />
                    <p className="description">Leave it empty and Beekiri finds this site’s domain by itself.</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">Block at Cloudflare</th>
                  <td>
                    <Check checked={apiDraft.edgeBans} onChange={(v) => setApiDraft({ ...apiDraft, edgeBans: v })}>
                      Send every Shield ban to Cloudflare too
                    </Check>
                  </td>
                </tr>
              </tbody>
            </table>
            <p className="submit bk-sec__submit">
              <button
                type="button"
                className="button button-primary"
                disabled={!apiDraft.token.trim() || busy !== null}
                onClick={() =>
                  void save(
                    'api',
                    '/api/security/cloudflare/api',
                    'PUT',
                    { token: apiDraft.token.trim(), ...(apiDraft.zoneId.trim() ? { zoneId: apiDraft.zoneId.trim() } : {}), edgeBans: apiDraft.edgeBans },
                    (v) => `Connected to Cloudflare (${v.cloudflare.api.zoneName}).`,
                  )
                }
              >
                {busy === 'api' ? 'Checking with Cloudflare…' : 'Connect Cloudflare'}
              </button>
            </p>
          </>
        )}
      </Panel>
    </>
  );
}

/* ── Two-step sign-in ────────────────────────────────────────────────────── */

function TwoFactorSection({ view, busy, save }: { view: View; busy: string | null; save: Save }) {
  const auth = useAuth();
  const href = useAdminHref();
  const [rule, setRule] = useState<Require>(view.twoFactor.require);
  useEffect(() => setRule(view.twoFactor.require), [view.twoFactor.require]);
  const needs = (p: Person) => rule === 'everyone' || (rule === 'admins' && (p.isOwner || p.role === 'administrator'));
  const missing = view.twoFactor.people.filter((p) => !p.enabled && needs(p) && p.id !== auth.user?.id);

  const filters: AdminTableFilter[] = useMemo(
    () => [
      { key: 'name', label: 'Name', type: 'text', placeholder: 'Filter name or email…' },
      {
        key: 'state',
        label: 'Two-step',
        type: 'select',
        allLabel: 'Everyone',
        options: [
          { value: 'on', label: 'On' },
          { value: 'off', label: 'Off' },
          { value: 'due', label: 'Required, not set up' },
        ],
      },
    ],
    [],
  );

  const columns: AdminTableColumn<Person>[] = [
    {
      key: 'name',
      header: 'Name',
      render: (p) => (
        <>
          <Link to={href(`users/${p.id}`)} className="bk-table__primary">
            {p.name}
          </Link>
          {p.id === auth.user?.id ? <span className="bk-table__badge">You</span> : null}
          {p.isOwner ? <span className="bk-table__badge is-accent">Owner</span> : null}
        </>
      ),
    },
    { key: 'email', header: 'Email', render: (p) => <span style={{ overflowWrap: 'anywhere' }}>{p.email}</span> },
    { key: 'role', header: 'Role', render: (p) => (p.isOwner ? 'Owner' : p.role.charAt(0).toUpperCase() + p.role.slice(1)) },
    {
      key: 'state',
      header: 'Two-step sign-in',
      render: (p) =>
        p.enabled ? (
          <span className="bk-table__badge is-ok">On</span>
        ) : p.required ? (
          <span className="bk-table__badge is-danger">Required, not set up</span>
        ) : (
          <span className="bk-table__badge">Off</span>
        ),
    },
  ];

  return (
    <>
      <Panel title="Two-step sign-in">
        <p className="bk-sec__intro">
          After the password, people enter a 6-digit code from an authenticator app on their phone, so a stolen or guessed password alone no longer opens the
          admin. Each person sets it up on their own profile; recovery codes cover a lost phone.
        </p>
        {!view.twoFactor.youHaveIt ? (
          <div className="beekiri-notice is-info">
            <p>
              Start with your own account: <Link to={auth.user ? href(`users/${auth.user.id}`) : href('users')}>Your profile → Two-step sign-in</Link>. You can
              require it of others once yours is on.
            </p>
          </div>
        ) : null}
        <table className="form-table">
          <tbody>
            <tr>
              <th scope="row">Required for</th>
              <td>
                <Choice label="Who must use two-step sign-in" value={rule} options={REQUIRE} onChange={setRule} />
                <p className="description">{REQUIRE.find((r) => r.id === rule)?.hint}</p>
                {rule !== view.twoFactor.require && missing.length ? (
                  <p className="description">
                    {missing.length} {missing.length === 1 ? 'person' : 'people'} without it will be signed out and set it up at their next sign-in.
                  </p>
                ) : null}
              </td>
            </tr>
          </tbody>
        </table>
        <p className="submit bk-sec__submit">
          <button
            type="button"
            className="button button-primary"
            disabled={rule === view.twoFactor.require || busy !== null}
            onClick={() =>
              void save('two-factor', '/api/security/two-factor', 'PUT', { require: rule }, (v) =>
                v.signedOut ? `Settings saved. ${v.signedOut} session${v.signedOut === 1 ? '' : 's'} ended. Those people will set it up the next time they sign in.` : 'Two-step sign-in settings saved.',
              )
            }
          >
            {busy === 'two-factor' ? 'Saving…' : 'Save changes'}
          </button>
        </p>
      </Panel>

      <Panel title="People on this site">
        <AdminDataTable
          rows={view.twoFactor.people}
          columns={columns}
          getRowId={(p) => p.id}
          filters={filters}
          filterFn={(p, v) => {
            const q = v.name?.trim().toLowerCase() ?? '';
            if (q && !p.name.toLowerCase().includes(q) && !p.email.toLowerCase().includes(q)) return false;
            if (v.state === 'on' && !p.enabled) return false;
            if (v.state === 'off' && p.enabled) return false;
            if (v.state === 'due' && (p.enabled || !p.required)) return false;
            return true;
          }}
          emptyTitle="Nobody has access to this site yet."
          emptyFilteredTitle="Nobody matches these filters."
        />
      </Panel>
    </>
  );
}

/* ── Activity ────────────────────────────────────────────────────────────── */

function ActivitySection({ view, busy, save }: { view: View; busy: string | null; save: Save }) {
  const [items, setItems] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setItems((await api<{ items: Activity[] }>('/api/security/activity')).items);
    } catch (e) {
      setError(message(e, 'Couldn’t load the activity. Click Refresh to try again.'));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load, view.bans.length, view.shield.blocked.length]);

  const blocked = new Set(view.shield.blocked.map((r) => r.value));
  const block = (ip: string, why: string) =>
    save(
      `block:${ip}`,
      '/api/security/lists',
      'PUT',
      {
        blocked: [...view.shield.blocked.map(({ value, note }) => ({ value, note })), { value: ip, note: why.slice(0, 120) }],
        allowed: view.shield.allowed.map(({ value, note }) => ({ value, note })),
      },
      `${ip} is now blocked permanently.`,
    );

  const filters: AdminTableFilter[] = useMemo(
    () => [
      { key: 'q', label: 'Search', type: 'text', placeholder: 'Address or words…' },
      {
        key: 'category',
        label: 'Type',
        type: 'select',
        allLabel: 'All types',
        options: (Object.keys(CATEGORY_LABEL) as Activity['category'][]).map((k) => ({ value: k, label: CATEGORY_LABEL[k] })),
      },
    ],
    [],
  );

  const columns: AdminTableColumn<Activity>[] = [
    { key: 'at', header: 'When', className: 'bk-sec__nowrap', render: (i) => dateTime(i.at) },
    {
      key: 'type',
      header: 'Type',
      render: (i) => <span className={`bk-table__badge${i.tone === 'danger' ? ' is-danger' : i.tone === 'ok' ? ' is-ok' : ''}`}>{CATEGORY_LABEL[i.category]}</span>,
    },
    { key: 'text', header: 'What happened', render: (i) => <span style={{ overflowWrap: 'anywhere' }}>{i.text}</span> },
    {
      key: 'ip',
      header: 'Address',
      render: (i) =>
        i.ip ? (
          <>
            <span>{i.ip}</span>
            {(i.tone === 'danger' || i.tone === 'warning') && !blocked.has(i.ip) && i.ip !== view.you.ip && !i.ip.includes('/') ? (
              <div className="bk-table__row-actions">
                <button type="button" className="button-link is-danger" disabled={busy !== null} onClick={() => void block(i.ip!, i.text)}>
                  Block
                </button>
              </div>
            ) : null}
          </>
        ) : (
          <span className="bk-table__muted">—</span>
        ),
    },
  ];

  return (
    <Panel title="Activity">
      {error ? <p className="bk-sec__intro">{error}</p> : null}
      <AdminDataTable
        rows={items}
        columns={columns}
        getRowId={(i) => i.id}
        filters={filters}
        filterFn={(i, v) => {
          const q = v.q?.trim().toLowerCase() ?? '';
          if (q && !i.text.toLowerCase().includes(q) && !(i.ip ?? '').includes(q)) return false;
          if (v.category && i.category !== v.category) return false;
          return true;
        }}
        loading={loading}
        actions={
          <button type="button" className="button" disabled={loading} onClick={() => void load()}>
            <ArrowClockwise size={14} aria-hidden />
            Refresh
          </button>
        }
        emptyTitle="No security events yet. Bans, sign-ins and setting changes appear here."
        emptyFilteredTitle="No events match these filters."
      />
    </Panel>
  );
}

