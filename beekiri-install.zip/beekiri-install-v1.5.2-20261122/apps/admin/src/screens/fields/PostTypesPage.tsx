import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { api, ApiError } from '../../api/client';
import { useAdminHref } from '../../lib/AdminEntryContext';
import { AdminDataTable, type AdminTableColumn } from '../../components/AdminDataTable';
import { IconPicker } from '../../components/IconPicker';
import { confirmDialog } from '../../components/ConfirmDialog';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';
import { notifyPostTypesChanged } from '../../lib/admin-events';
import { ErrorNotice } from '../../components/ErrorNotice';

type PostType = {
  id: string;
  slug: string;
  singular: string;
  plural: string;
  description: string;
  public: boolean;
  hierarchical: boolean;
  hasArchive: boolean;
  showInMenu: boolean;
  supports: string[];
  active: boolean;
  menuIcon: string;
  archiveDesign: string;
  singleDesign: string;
  trashedAt: string | null;
};

type ListView = 'all' | 'trash';


const SUPPORT_OPTIONS = [
  { value: 'title', label: 'Title' },
  { value: 'editor', label: 'Editor' },
  { value: 'thumbnail', label: 'Featured image' },
  { value: 'excerpt', label: 'Excerpt' },
  { value: 'custom-fields', label: 'Custom fields' },
];

const EMPTY = {
  slug: '',
  singular: '',
  plural: '',
  description: '',
  public: true,
  hierarchical: false,
  hasArchive: true,
  showInMenu: true,
  supports: ['title', 'editor'] as string[],
  active: true,
  menuIcon: 'Cube',
  archiveDesign: 'list',
  singleDesign: 'default',
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong. Try again.';
}

function toSlug(v: string) {
  return v
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
}

function formFromRow(row: PostType) {
  return {
    slug: row.slug,
    singular: row.singular,
    plural: row.plural,
    description: row.description,
    public: row.public,
    hierarchical: row.hierarchical,
    hasArchive: row.hasArchive,
    showInMenu: row.showInMenu,
    supports: [...row.supports],
    active: row.active,
    menuIcon: row.menuIcon || 'Cube',
    archiveDesign: row.archiveDesign || 'list',
    singleDesign: row.singleDesign || 'default',
  };
}

export function PostTypesPage() {
  const { id } = useParams<{ id?: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const href = useAdminHref();
  const LIST_PATH = href('fields/post-types');
  // `/new` is captured by `:id` (must not use a separate static `/new` route).
  const isNew = id === 'new';
  const isForm = Boolean(id);

  const [rows, setRows] = useState<PostType[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY);
  const [editRow, setEditRow] = useState<PostType | null>(null);
  const [view, setView] = useState<ListView>('all');
  const [counts, setCounts] = useState({ all: 0, trash: 0 });

  const load = useCallback(async () => {
    // The edit form always looks up the live (not trashed) post types.
    const q = view === 'trash' && !isForm ? '?status=trash' : '';
    const res = await api<{ postTypes: PostType[]; counts?: { all: number; trash: number } }>(`/api/fields/post-types${q}`);
    setRows(res.postTypes);
    if (res.counts) setCounts(res.counts);
    return res.postTypes;
  }, [view, isForm]);

  useEffect(() => {
    const state = location.state as { notice?: string } | null;
    if (state?.notice) {
      setNotice(state.notice);
      navigate(location.pathname, { replace: true, state: null });
    }
  }, [location.pathname, location.state, navigate]);

  useEffect(() => {
    setLoading(true);
    load()
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [load]);

  useEffect(() => {
    if (!isForm) {
      setEditRow(null);
      return;
    }
    if (isNew) {
      setForm(EMPTY);
      setEditRow(null);
      setError(null);
      return;
    }
    if (loading) return;
    const row = rows.find((r) => r.id === id);
    if (!row) {
      navigate(LIST_PATH, { replace: true });
      return;
    }
    setForm(formFromRow(row));
    setEditRow(row);
    setError(null);
  }, [id, isForm, isNew, loading, rows, navigate]);

  const back = (nextNotice?: string) => {
    navigate(LIST_PATH, nextNotice ? { state: { notice: nextNotice } } : undefined);
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const payload = {
        ...form,
        slug: form.slug.trim().toLowerCase(),
        singular: form.singular.trim(),
        plural: form.plural.trim(),
        description: form.description.trim(),
      };
      if (isNew) {
        await api('/api/fields/post-types', { method: 'POST', json: payload });
        notifyPostTypesChanged();
        back(`Post type “${payload.plural}” created.`);
      } else if (editRow) {
        await api(`/api/fields/post-types/${editRow.id}`, {
          method: 'PATCH',
          json: payload,
        });
        notifyPostTypesChanged();
        back(`Post type “${payload.plural}” updated.`);
      }
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  /** Runs a list action, reloads the list and the admin menu, and says what happened. */
  const act = async (run: () => Promise<unknown>, done: string) => {
    setBusy(true);
    setError(null);
    try {
      await run();
      await load();
      notifyPostTypesChanged();
      setNotice(done);
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const onTrash = async (row: PostType) => {
    const ok = await confirmDialog({
      title: 'Move to trash',
      message: `Move “${row.plural}” to the trash? It disappears from the admin menu and the website. Its entries and page designs are kept, and you can restore it from the trash at any time.`,
      confirmLabel: 'Move to trash',
      danger: true,
    });
    if (!ok) return;
    await act(() => api(`/api/fields/post-types/${row.id}`, { method: 'DELETE' }), `“${row.plural}” moved to the trash.`);
  };

  const onToggleActive = (row: PostType) =>
    act(
      () => api(`/api/fields/post-types/${row.id}`, { method: 'PATCH', json: { active: !row.active } }),
      row.active
        ? `“${row.plural}” deactivated. It’s hidden from the admin menu and the website; nothing was deleted.`
        : `“${row.plural}” is active again.`,
    );

  const onRestore = (row: PostType) =>
    act(() => api(`/api/fields/post-types/${row.id}/restore`, { method: 'POST' }), `“${row.plural}” restored. It is active again.`);

  const onDeletePermanently = async (row: PostType) => {
    const ok = await confirmDialog({
      title: 'Delete permanently',
      message: `Delete “${row.plural}” permanently? Its page designs are removed from your theme. Its entries are kept and come back if you create a post type with the slug “${row.slug}” again. This can't be undone.`,
      confirmLabel: 'Delete permanently',
      danger: true,
    });
    if (!ok) return;
    await act(() => api(`/api/fields/post-types/${row.id}?force=1`, { method: 'DELETE' }), `“${row.plural}” deleted permanently.`);
  };

  const columns: AdminTableColumn<PostType>[] = useMemo(
    () => [
      {
        key: 'plural',
        header: 'Post type',
        render: (row) =>
          row.trashedAt ? (
            <>
              <strong className="bk-table__primary">{row.plural}</strong>
              <div className="bk-table__row-actions">
                <button type="button" className="button-link" disabled={busy} onClick={() => void onRestore(row)}>
                  Restore
                </button>
                <span className="bk-table__sep">|</span>
                <button type="button" className="button-link is-danger" disabled={busy} onClick={() => void onDeletePermanently(row)}>
                  Delete permanently
                </button>
              </div>
            </>
          ) : (
            <>
              <Link className="bk-table__primary" to={`${LIST_PATH}/${row.id}`}>
                {row.plural}
              </Link>
              {row.active && !row.showInMenu ? <span className="bk-table__badge">Hidden from menu</span> : null}
              <div className="bk-table__row-actions">
                <Link className="button-link" to={href(`content/${row.slug}`)}>
                  View entries
                </Link>
                <span className="bk-table__sep">|</span>
                <Link className="button-link" to={`${LIST_PATH}/${row.id}`}>
                  Edit
                </Link>
                <span className="bk-table__sep">|</span>
                <button type="button" className="button-link" disabled={busy} onClick={() => void onToggleActive(row)}>
                  {row.active ? 'Deactivate' : 'Activate'}
                </button>
                <span className="bk-table__sep">|</span>
                <button type="button" className="button-link is-danger" disabled={busy} onClick={() => void onTrash(row)}>
                  Trash
                </button>
              </div>
            </>
          ),
      },
      { key: 'slug', header: 'Slug', render: (row) => <code>{row.slug}</code> },
      {
        key: 'kind',
        header: 'Type',
        render: (row) => (row.hierarchical ? 'Hierarchical' : 'Flat'),
      },
      {
        key: 'status',
        header: 'Status',
        render: (row) =>
          row.trashedAt ? (
            <span className="bk-table__badge">In trash</span>
          ) : row.active ? (
            <span className="bk-table__badge is-ok">Active</span>
          ) : (
            <span className="bk-table__badge">Inactive</span>
          ),
      },
    ],
    [busy, href],
  );

  if (isForm) {
    const formId = isNew ? 'post-type-form-new' : `post-type-form-${id}`;
    return (
      <div className="wrap wrap--wide">
        <PageHeader
          title={isNew ? 'Add post type' : 'Edit post type'}
          actions={
            <>
              <button type="submit" form={formId} className="button button-primary" disabled={busy}>
                {busy ? 'Saving…' : isNew ? 'Add post type' : 'Update'}
              </button>
              <Link to={LIST_PATH} className="button" aria-disabled={busy}>
                Cancel
              </Link>
            </>
          }
        />
        <p className="bk-acf-breadcrumb">
          <Link to={LIST_PATH}>Post Types</Link> <span>/</span> {isNew ? 'New post type' : id}
        </p>
        <p className="bk-muted">
          Create your own type of content, such as Products, Events or Team members, then add fields
          to it with a field group.
        </p>
        {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
        <form id={formId} className="bk-panel" onSubmit={onSubmit}>
          <div className="bk-panel__body">
            <table className="form-table">
              <tbody>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_singular">Singular name</label>
                  </th>
                  <td>
                    <input
                      id="pt_singular"
                      className="regular-text"
                      required
                      value={form.singular}
                      onChange={(e) => {
                        const singular = e.target.value;
                        setForm((f) => {
                          const autoPlural = f.singular ? `${f.singular}s` : '';
                          const pluralStillAuto = !f.plural || f.plural === autoPlural;
                          return {
                            ...f,
                            singular,
                            plural: pluralStillAuto ? (singular ? `${singular}s` : '') : f.plural,
                            slug:
                              isNew && (!f.slug || f.slug === toSlug(f.singular))
                                ? toSlug(singular)
                                : f.slug,
                          };
                        });
                      }}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_plural">Plural name</label>
                  </th>
                  <td>
                    <input
                      id="pt_plural"
                      className="regular-text"
                      required
                      value={form.plural}
                      onChange={(e) => setForm((f) => ({ ...f, plural: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_slug">Slug</label>
                  </th>
                  <td>
                    <input
                      id="pt_slug"
                      className="regular-text"
                      required
                      value={form.slug}
                      onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))}
                    />
                    <p className="description">The short name used in its web address (for example /events/) and to show field groups on it.</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_desc">Description</label>
                  </th>
                  <td>
                    <textarea
                      id="pt_desc"
                      rows={2}
                      value={form.description}
                      onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <span id="pt_icon_label">Menu icon</span>
                  </th>
                  <td>
                    <IconPicker
                      id="pt_icon"
                      value={form.menuIcon}
                      onChange={(menuIcon) => setForm((f) => ({ ...f, menuIcon }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_archive_design">Archive design</label>
                  </th>
                  <td>
                    <select
                      id="pt_archive_design"
                      value={form.archiveDesign}
                      onChange={(e) => setForm((f) => ({ ...f, archiveDesign: e.target.value }))}
                    >
                      <option value="list">List</option>
                      <option value="cards">Cards</option>
                      <option value="grid">Grid</option>
                    </select>
                    <p className="description">
                      How the list of all entries looks on your website at /{form.slug || '…'}/. Saving updates the design in your theme.
                    </p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_single_design">Single design</label>
                  </th>
                  <td>
                    <select
                      id="pt_single_design"
                      value={form.singleDesign}
                      onChange={(e) => setForm((f) => ({ ...f, singleDesign: e.target.value }))}
                    >
                      <option value="default">Default</option>
                      <option value="full">Full width</option>
                      <option value="compact">Compact</option>
                    </select>
                    <p className="description">
                      How each entry’s own page looks. You can adjust any entry further in the page editor.
                    </p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">Supports</th>
                  <td>
                    <div className="bk-fields-locations">
                      {SUPPORT_OPTIONS.map((opt) => (
                        <label key={opt.value} className="bk-check">
                          <input
                            type="checkbox"
                            checked={form.supports.includes(opt.value)}
                            onChange={() =>
                              setForm((f) => ({
                                ...f,
                                supports: f.supports.includes(opt.value)
                                  ? f.supports.filter((s) => s !== opt.value)
                                  : [...f.supports, opt.value],
                              }))
                            }
                          />
                          <span className="bk-check__box" aria-hidden />
                          <span className="bk-check__label">{opt.label}</span>
                        </label>
                      ))}
                    </div>
                  </td>
                </tr>
                <tr>
                  <th scope="row">Options</th>
                  <td>
                    <div className="bk-fields-locations">
                      {(
                        [
                          ['public', 'Public (shown on the website)'],
                          ['hierarchical', 'Hierarchical (like pages)'],
                          ['hasArchive', 'Has a list page'],
                          ['showInMenu', 'Show in admin menu'],
                          ['active', 'Active'],
                        ] as const
                      ).map(([key, label]) => (
                        <label key={key} className="bk-check">
                          <input
                            type="checkbox"
                            checked={form[key]}
                            onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.checked }))}
                          />
                          <span className="bk-check__box" aria-hidden />
                          <span className="bk-check__label">{label}</span>
                        </label>
                      ))}
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Post Types"
        actions={
          <Link to={`${LIST_PATH}/new`} className="button button-primary">
            Add post type
          </Link>
        }
      />
      <p className="bk-muted">
        <button
          type="button"
          className={`button-link${view === 'all' ? ' is-current' : ''}`}
          onClick={() => setView('all')}
          style={{ fontWeight: view === 'all' ? 600 : undefined }}
        >
          All ({counts.all})
        </button>
        <span className="bk-table__sep"> | </span>
        <button
          type="button"
          className={`button-link${view === 'trash' ? ' is-current' : ''}`}
          onClick={() => setView('trash')}
          style={{ fontWeight: view === 'trash' ? 600 : undefined }}
        >
          Trash ({counts.trash})
        </button>
      </p>
      <p className="bk-muted">
        {view === 'trash'
          ? 'Post types in the trash are hidden from the admin menu and the website. Restore one to switch it back on; its entries have been kept.'
          : 'Create your own types of content for this site. Deactivate one to hide it from the admin menu and the website without deleting anything.'}
      </p>
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}
      <AdminDataTable
        rows={rows}
        columns={columns}
        getRowId={(r) => r.id}
        loading={loading}
        defaultPageSize={10}
        emptyTitle={view === 'trash' ? 'The trash is empty.' : 'No custom post types yet. Select Add post type to create one, such as Products or Events.'}
      />
    </div>
  );
}
