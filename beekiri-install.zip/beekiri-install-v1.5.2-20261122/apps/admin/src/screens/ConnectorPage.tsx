import { CONNECTOR_COMING_SOON } from '../lib/features';
import { ConnectorProviderPage } from './ConnectorProviderPage';
import { PlaceholderScreen } from './PlaceholderScreen';

/** Connector: the Beekiri agent — connection, balance and spend on one page. */
export function ConnectorPage() {
  if (CONNECTOR_COMING_SOON) {
    return (
      <PlaceholderScreen
        title="Connector"
        phase="Coming soon"
        note="Beekiri, your AI assistant for this site, is on its way. You’ll find it here when it’s ready."
      />
    );
  }
  return <ConnectorProviderPage />;
}
