import { useState } from 'react';
import { Check, Copy, DownloadSimple } from '@phosphor-icons/react';
import './recovery-codes.css';

/**
 * Recovery codes, shown once: right after two-step sign-in is set up or new codes are made.
 * `dark` on the sign-in page, `light` in the admin.
 */
export function RecoveryCodes({ codes, variant = 'light', site }: { codes: string[]; variant?: 'light' | 'dark'; site?: string }) {
  const [copied, setCopied] = useState(false);
  const text = codes.join('\n');
  const where = site || window.location.host;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      window.prompt('Copy your recovery codes:', codes.join('  '));
    }
  };

  const download = () => {
    const body = `Recovery codes for ${where}\nEach code signs you in once if you lose your authenticator app.\n\n${text}\n`;
    const url = URL.createObjectURL(new Blob([body], { type: 'text/plain' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `recovery-codes-${where.replace(/[^a-z0-9.-]+/gi, '-')}.txt`;
    a.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <div className={`bk-recovery is-${variant}`}>
      <ol className="bk-recovery__list">
        {codes.map((c) => (
          <li key={c}>
            <code>{c}</code>
          </li>
        ))}
      </ol>
      <div className="bk-recovery__actions">
        <button type="button" className="bk-recovery__btn" onClick={() => void copy()}>
          {copied ? <Check size={14} weight="bold" aria-hidden /> : <Copy size={14} aria-hidden />}
          {copied ? 'Copied' : 'Copy'}
        </button>
        <button type="button" className="bk-recovery__btn" onClick={download}>
          <DownloadSimple size={14} aria-hidden />
          Download
        </button>
      </div>
    </div>
  );
}
