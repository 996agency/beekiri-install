import { FormEvent, useEffect, useRef, useState } from 'react';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth, type SignedIn } from '../auth/AuthContext';
import { api, ApiError } from '../api/client';
import { HumanCheck, type CaptchaProvider, type HumanCheckHandle } from '../components/HumanCheck';
import { useAdminEntry } from '../lib/AdminEntryContext';
import { clearIdleSignOut, wasIdleSignOut } from '../lib/idle-session';
import { AuthShell } from './AuthShell';
import { RecoveryCodes } from './RecoveryCodes';
import { ResetPasswordScreen } from './ResetPasswordScreen';
import { LostPasswordScreen } from './LostPasswordScreen';

/** `redirect_to` must stay on this site: a single-slash path, never `//host` or a scheme. */
function localPath(raw: string | null, fallback: string): string {
  const v = (raw || '').trim();
  if (!/^\/(?![\/\\])/.test(v)) return fallback;
  try {
    return new URL(v, window.location.origin).origin === window.location.origin ? v : fallback;
  } catch {
    return fallback;
  }
}

type Setup = { secret: string; qrSvg: string; issuer: string; account: string };

/**
 * password → (code | set-up) → (recovery codes) → signed in.
 * `codes`: the account just set up two-step sign-in here; `low`: a recovery code was used.
 */
type Step =
  | { kind: 'password' }
  | { kind: 'code'; challenge: string }
  | { kind: 'setup'; challenge: string; setup: Setup | null }
  | { kind: 'codes'; result: SignedIn }
  | { kind: 'low'; result: SignedIn };

/** Server error codes the sign-in screens act on. */
const codeOf = (err: unknown) => (err instanceof ApiError ? ((err.body as { code?: string } | null)?.code ?? '') : '');

export function LoginScreen() {
  const auth = useAuth();
  const entry = useAdminEntry();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const action = params.get('action');
  const [idleFlag] = useState(wasIdleSignOut);
  const idleSignedOut = params.get('reason') === 'idle' || idleFlag;
  const [step, setStep] = useState<Step>({ kind: 'password' });
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [code, setCode] = useState('');
  const [useRecovery, setUseRecovery] = useState(false);
  const [trustBrowser, setTrustBrowser] = useState(true);
  const [human, setHuman] = useState<{ provider: CaptchaProvider; siteKey: string } | null>(null);
  const humanRef = useRef<HumanCheckHandle>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let live = true;
    api<{ humanCheck: { provider: CaptchaProvider; siteKey: string } | null }>('/api/auth/sign-in-options')
      .then((o) => live && setHuman(o.humanCheck))
      .catch(() => undefined);
    return () => {
      live = false;
    };
  }, []);

  if (action === 'lostpassword') return <LostPasswordScreen />;
  if (action === 'rp' || action === 'reset') return <ResetPasswordScreen />;

  const goIn = () => {
    clearIdleSignOut();
    navigate(localPath(params.get('redirect_to'), entry.basePath), { replace: true });
  };

  // Already signed in (and not in the middle of showing new recovery codes).
  if (auth.authenticated && step.kind !== 'codes' && step.kind !== 'low') {
    return <Navigate to={localPath(params.get('redirect_to'), entry.basePath)} replace />;
  }

  const backToPassword = (message?: string) => {
    setStep({ kind: 'password' });
    setCode('');
    setUseRecovery(false);
    setPassword('');
    setError(message ?? null);
    humanRef.current?.reset();
  };

  const onPassword = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const humanToken = human ? await humanRef.current?.getToken() : '';
      if (human && !humanToken) {
        setError('Complete the security check to continue.');
        return;
      }
      const res = await auth.login(login, password, remember, humanToken || undefined);
      if (res.done) {
        goIn();
        return;
      }
      setCode('');
      if (res.mode === 'verify') {
        setStep({ kind: 'code', challenge: res.challenge });
      } else {
        setStep({ kind: 'setup', challenge: res.challenge, setup: null });
        const setup = await api<Setup>('/api/auth/login/two-factor/setup', { json: { challenge: res.challenge } });
        setStep({ kind: 'setup', challenge: res.challenge, setup });
      }
    } catch (err) {
      if (codeOf(err) === 'human_check') {
        const body = (err as ApiError).body as { provider?: CaptchaProvider; siteKey?: string } | null;
        if (body?.provider && body.siteKey) setHuman({ provider: body.provider, siteKey: body.siteKey });
      }
      humanRef.current?.reset();
      setError(err instanceof ApiError ? err.message : 'Couldn’t sign you in. Check your connection and try again.');
    } finally {
      setBusy(false);
    }
  };

  const onCode = async (e: FormEvent) => {
    e.preventDefault();
    if (step.kind !== 'code' && step.kind !== 'setup') return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<SignedIn>('/api/auth/login/two-factor', {
        json: { challenge: step.challenge, code: code.trim(), trustBrowser },
      });
      if (res.recoveryCodes?.length) {
        setStep({ kind: 'codes', result: res });
        return;
      }
      if (res.recoveryCodesLeft !== undefined && res.recoveryCodesLeft <= 3) {
        setStep({ kind: 'low', result: res });
        return;
      }
      auth.signedIn(res);
      goIn();
    } catch (err) {
      if (codeOf(err) === 'challenge_expired') {
        backToPassword(err instanceof ApiError ? err.message : 'Your sign-in timed out. Enter your password again to continue.');
        return;
      }
      setCode('');
      setError(err instanceof ApiError ? err.message : 'Couldn’t check the code. Check your connection and try again.');
    } finally {
      setBusy(false);
    }
  };

  const finish = (result: SignedIn) => {
    auth.signedIn(result);
    goIn();
  };

  const notice = (
    <>
      {error ? (
        <div className="bk-auth__alert" role="alert">
          {error}
        </div>
      ) : null}
    </>
  );

  if (step.kind === 'codes') {
    return (
      <AuthShell
        title="Save your recovery codes"
        subtitle="If you lose your phone, each of these codes signs you in once. Keep them somewhere safe, like a password manager."
        brandTo={entry.path}
        documentTitle="Recovery codes — Beekiri"
      >
        <RecoveryCodes codes={step.result.recoveryCodes ?? []} variant="dark" />
        <div className="bk-auth__actions">
          <button type="button" className="bk-install__btn bk-install__btn--primary" onClick={() => finish(step.result)}>
            I’ve saved them, continue
          </button>
        </div>
      </AuthShell>
    );
  }

  if (step.kind === 'low') {
    const left = step.result.recoveryCodesLeft ?? 0;
    return (
      <AuthShell
        title="You’re running low on recovery codes"
        subtitle={
          left === 0
            ? 'That was your last recovery code. Create new ones now in Your profile → Two-step sign-in.'
            : `You have ${left} recovery code${left === 1 ? '' : 's'} left. Create new ones in Your profile → Two-step sign-in.`
        }
        brandTo={entry.path}
        documentTitle="Recovery codes — Beekiri"
      >
        <div className="bk-auth__actions">
          <button type="button" className="bk-install__btn bk-install__btn--primary" onClick={() => finish(step.result)}>
            Continue
          </button>
        </div>
      </AuthShell>
    );
  }

  if (step.kind === 'code') {
    return (
      <AuthShell
        title="Two-step sign-in"
        subtitle={
          useRecovery
            ? 'Enter one of the recovery codes you saved when you set up two-step sign-in. Each code works once.'
            : 'Open your authenticator app and enter the 6-digit code for this site.'
        }
        brandTo={entry.path}
        documentTitle="Two-step sign-in — Beekiri"
      >
        {notice}
        <form onSubmit={(e) => void onCode(e)}>
          <div className="bk-install__field">
            <label htmlFor="two_factor_code">{useRecovery ? 'Recovery code' : 'Code'}</label>
            <input
              key={useRecovery ? 'recovery' : 'app'}
              className={`regular-text${useRecovery ? '' : ' bk-auth__code'}`}
              type="text"
              id="two_factor_code"
              autoFocus
              required
              autoComplete={useRecovery ? 'off' : 'one-time-code'}
              inputMode={useRecovery ? 'text' : 'numeric'}
              pattern={useRecovery ? undefined : '[0-9 ]{6,7}'}
              maxLength={useRecovery ? 32 : 7}
              placeholder={useRecovery ? 'xxxx-xxxx-xxxx' : '123 456'}
              value={code}
              onChange={(e) => setCode(useRecovery ? e.target.value : e.target.value.replace(/[^0-9 ]/g, ''))}
            />
          </div>
          <label className="bk-install__check">
            <input type="checkbox" checked={trustBrowser} onChange={(e) => setTrustBrowser(e.target.checked)} />
            <span>Don’t ask again on this browser for 30 days</span>
          </label>
          <div className="bk-auth__actions">
            <button type="submit" className="bk-install__btn bk-install__btn--primary" disabled={busy}>
              {busy ? 'Checking…' : 'Sign in'}
            </button>
            <button
              type="button"
              className="bk-auth__link bk-auth__linkbtn"
              onClick={() => {
                setUseRecovery((v) => !v);
                setCode('');
                setError(null);
              }}
            >
              {useRecovery ? 'Use the code from my app' : 'Lost your phone? Use a recovery code'}
            </button>
            <button type="button" className="bk-auth__link bk-auth__linkbtn" onClick={() => backToPassword()}>
              Sign in as someone else
            </button>
          </div>
        </form>
      </AuthShell>
    );
  }

  if (step.kind === 'setup') {
    const setup = step.setup;
    return (
      <AuthShell
        title="Set up two-step sign-in"
        subtitle="For extra security, accounts with your role confirm each sign-in with a code from an authenticator app, such as Google Authenticator, Microsoft Authenticator, 1Password or Authy."
        brandTo={entry.path}
        documentTitle="Set up two-step sign-in — Beekiri"
      >
        {notice}
        {!setup ? (
          <p className="bk-auth__muted">Preparing your code…</p>
        ) : (
          <form onSubmit={(e) => void onCode(e)}>
            <ol className="bk-auth__steps">
              <li>Open your authenticator app and scan this code to add your account.</li>
            </ol>
            <div className="bk-auth__qr">
              <img src={`data:image/svg+xml;charset=utf-8,${encodeURIComponent(setup.qrSvg)}`} alt="QR code for your authenticator app" width={184} height={184} />
            </div>
            <p className="bk-auth__muted">
              Can’t scan it? Enter this key in the app instead:
              <br />
              <code className="bk-auth__key">{setup.secret}</code>
            </p>
            <ol className="bk-auth__steps" start={2}>
              <li>Enter the 6-digit code the app shows for {setup.issuer}.</li>
            </ol>
            <div className="bk-install__field">
              <label htmlFor="two_factor_code">Code</label>
              <input
                className="regular-text bk-auth__code"
                type="text"
                id="two_factor_code"
                required
                autoComplete="one-time-code"
                inputMode="numeric"
                pattern="[0-9 ]{6,7}"
                maxLength={7}
                placeholder="123 456"
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/[^0-9 ]/g, ''))}
              />
            </div>
            <div className="bk-auth__actions">
              <button type="submit" className="bk-install__btn bk-install__btn--primary" disabled={busy}>
                {busy ? 'Checking…' : 'Turn on and sign in'}
              </button>
              <button type="button" className="bk-auth__link bk-auth__linkbtn" onClick={() => backToPassword()}>
                Cancel
              </button>
            </div>
          </form>
        )}
      </AuthShell>
    );
  }

  return (
    <AuthShell
      title="Welcome back to Beekiri"
      subtitle="Sign in to manage your website."
      brandTo={entry.path}
      documentTitle="Sign in — Beekiri"
    >
      {idleSignedOut ? (
        <div className="bk-auth__ok" role="status">
          For your security, you were signed out after 20 minutes without activity. Sign in again to continue
          where you left off.
        </div>
      ) : null}
      {notice}

      <form onSubmit={(e) => void onPassword(e)}>
        <div className="bk-install__field">
          <label htmlFor="user_login">Email or username</label>
          <input
            className="regular-text"
            type="text"
            id="user_login"
            autoComplete="username"
            required
            placeholder="you@example.com"
            value={login}
            onChange={(e) => setLogin(e.target.value)}
          />
        </div>
        <div className="bk-install__field">
          <label htmlFor="user_pass">Password</label>
          <div className="bk-auth__pw">
            <input
              className="regular-text"
              type={showPw ? 'text' : 'password'}
              id="user_pass"
              autoComplete="current-password"
              required
              placeholder="Your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              type="button"
              className="bk-auth__pw-toggle"
              onClick={() => setShowPw((v) => !v)}
            >
              {showPw ? 'Hide' : 'Show'}
            </button>
          </div>
        </div>
        <label className="bk-install__check">
          <input
            type="checkbox"
            checked={remember}
            onChange={(e) => setRemember(e.target.checked)}
          />
          <span>Keep me signed in</span>
        </label>
        {human ? (
          <div className="bk-auth__human">
            <HumanCheck ref={humanRef} provider={human.provider} siteKey={human.siteKey} theme="dark" action="login" onError={setError} />
          </div>
        ) : null}

        <div className="bk-auth__actions">
          <button
            type="submit"
            className="bk-install__btn bk-install__btn--primary"
            disabled={busy}
          >
            {busy ? 'Signing in…' : 'Sign in'}
          </button>
          <Link to={`${entry.basePath}/lost-password`} className="bk-auth__link">
            Forgot your password?
          </Link>
        </div>
      </form>
    </AuthShell>
  );
}
