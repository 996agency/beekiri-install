import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { api } from '../../api/client';
import { AdminDataTable, type AdminTableColumn } from '../../components/AdminDataTable';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { SuccessNotice } from '../../components/SuccessNotice';
import { shopError, type ShopApiKey, type ShopApiPermission } from './api';

const PERMISSIONS: { id: ShopApiPermission; label: string; help: string }[] = [
  {
    id: 'catalog',
    label: 'Products only',
    help: 'Reads published products, categories and tags. Use it for an app or another website that shows your products.',
  },
  {
    id: 'read',
    label: 'Read',
    help: 'Reads products, orders, customers and coupons. Nothing can be changed with this key.',
  },
  {
    id: 'read_write',
    label: 'Read and write',
    help: 'Reads and changes products, stock, orders and coupons. Keep this key on a server, never in an app or a web page.',
  },
];
const PERMISSION_LABEL = Object.fromEntries(PERMISSIONS.map((p) => [p.id, p.label])) as Record<ShopApiPermission, string>;

/** What developers can reach, for the reference table (see docs/shopping/REST-API.md). */
const ENDPOINTS: { method: string; path: string; what: string; needs: ShopApiPermission }[] = [
  { method: 'GET', path: '/', what: 'Shop name, currency and this key', needs: 'catalog' },
  { method: 'GET', path: '/products', what: 'List products (search, category, tag, SKU, changed since…)', needs: 'catalog' },
  { method: 'GET', path: '/products/{id or slug}', what: 'One product with its photos and variants', needs: 'catalog' },
  { method: 'GET', path: '/categories', what: 'Product categories', needs: 'catalog' },
  { method: 'GET', path: '/tags', what: 'Product tags', needs: 'catalog' },
  { method: 'POST', path: '/products', what: 'Create a product', needs: 'read_write' },
  { method: 'PATCH', path: '/products/{id}', what: 'Change a product: price, stock, text, photos…', needs: 'read_write' },
  { method: 'PATCH', path: '/products/{id}/variants/{variantId}', what: 'Change one variant (stock, price)', needs: 'read_write' },
  { method: 'DELETE', path: '/products/{id}', what: 'Move a product to the trash (?force=true deletes it)', needs: 'read_write' },
  { method: 'GET', path: '/orders', what: 'List orders (status, customer, dates…)', needs: 'read' },
  { method: 'GET', path: '/orders/{id}', what: 'One order with its items and notes', needs: 'read' },
  { method: 'PATCH', path: '/orders/{id}', what: 'Change the status or the customer details', needs: 'read_write' },
  { method: 'POST', path: '/orders/{id}/fulfillment', what: 'Packed, shipped (with tracking) or delivered', needs: 'read_write' },
  { method: 'POST', path: '/orders/{id}/notes', what: 'Add a note to an order', needs: 'read_write' },
  { method: 'GET', path: '/customers', what: 'List customers', needs: 'read' },
  { method: 'GET', path: '/customers/{id}', what: 'One customer', needs: 'read' },
  { method: 'GET', path: '/coupons', what: 'List coupons', needs: 'read' },
  { method: 'GET', path: '/coupons/{id}', what: 'One coupon', needs: 'read' },
  { method: 'POST', path: '/coupons', what: 'Create a coupon', needs: 'read_write' },
  { method: 'PATCH', path: '/coupons/{id}', what: 'Change a coupon', needs: 'read_write' },
  { method: 'DELETE', path: '/coupons/{id}', what: 'Delete a coupon', needs: 'read_write' },
];

function dateTime(iso: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function Row({ label, htmlFor, children, help }: { label: ReactNode; htmlFor?: string; children: ReactNode; help?: ReactNode }) {
  return (
    <tr>
      <th scope="row">{htmlFor ? <label htmlFor={htmlFor}>{label}</label> : label}</th>
      <td>
        {children}
        {help ? <p className="description">{help}</p> : null}
      </td>
    </tr>
  );
}

/** Monospace value with a Copy button (the same look as the Stripe address under Payments). */
function CopyField({ value, label }: { value: string; label: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard unavailable — the value is still visible to select */
    }
  };
  return (
    <span className="bk-shop-settings__code" aria-label={label}>
      <span className="bk-shop-api__value">{value}</span>
      <button type="button" className="button" onClick={() => void copy()}>
        {copied ? 'Copied' : 'Copy'}
      </button>
    </span>
  );
}

/**
 * Shop → Settings → REST API: keys that let apps, other websites and stock or accounting tools
 * use the shop (/api/shop/v1). A key acts as the person who created it, narrowed by its permission.
 */
export function ShopApiKeysTab() {
  const [keys, setKeys] = useState<ShopApiKey[] | null>(null);
  const [name, setName] = useState('');
  const [permission, setPermission] = useState<ShopApiPermission>('catalog');
  const [created, setCreated] = useState<{ name: string; token: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const baseUrl = `${window.location.origin}/api/shop/v1`;

  const load = useCallback(async () => {
    try {
      const res = await api<{ keys: ShopApiKey[] }>('/api/shop/api-keys');
      setKeys(res.keys);
    } catch (e) {
      setError(shopError(e));
      setKeys((k) => k ?? []);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const create = async () => {
    if (!name.trim()) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ key: ShopApiKey; token: string }>('/api/shop/api-keys', { method: 'POST', json: { name: name.trim(), permission } });
      setCreated({ name: res.key.name, token: res.token });
      setKeys((k) => [res.key, ...(k ?? [])]);
      setName('');
    } catch (e) {
      setError(shopError(e));
    } finally {
      setBusy(false);
    }
  };

  const revoke = async (key: ShopApiKey) => {
    const ok = await confirmDialog({
      title: 'Revoke API key',
      message: `“${key.name}” stops working right away, and anything that uses it loses access to your shop. This can't be undone.`,
      confirmLabel: 'Revoke key',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    setError(null);
    try {
      await api(`/api/shop/api-keys/${encodeURIComponent(key.id)}`, { method: 'DELETE' });
      setKeys((k) => (k ?? []).filter((x) => x.id !== key.id));
      setNotice(`“${key.name}” revoked.`);
    } catch (e) {
      setError(shopError(e));
    } finally {
      setBusy(false);
    }
  };

  const columns: AdminTableColumn<ShopApiKey>[] = [
    {
      key: 'name',
      header: 'Description',
      render: (k) => (
        <>
          <span className="bk-table__primary">{k.name}</span>
          <div className="bk-table__row-actions">
            <button type="button" className="button-link is-danger" disabled={busy} onClick={() => void revoke(k)}>
              Revoke
            </button>
          </div>
        </>
      ),
    },
    {
      key: 'permission',
      header: 'Permissions',
      render: (k) => <span className={`bk-table__badge${k.permission === 'read_write' ? ' is-accent' : ''}`}>{PERMISSION_LABEL[k.permission] ?? k.permission}</span>,
    },
    { key: 'key', header: 'Key', render: (k) => <code>{k.preview}</code> },
    { key: 'by', header: 'Created by', render: (k) => k.createdBy },
    { key: 'used', header: 'Last used', render: (k) => (k.lastUsedAt ? dateTime(k.lastUsedAt) : <span className="bk-table__muted">Never</span>) },
    { key: 'created', header: 'Created', render: (k) => dateTime(k.createdAt) },
  ];

  const endpointColumns: AdminTableColumn<(typeof ENDPOINTS)[number]>[] = [
    { key: 'call', header: 'Request', render: (e) => <code>{`${e.method} ${e.path}`}</code> },
    { key: 'what', header: 'What it does', render: (e) => e.what },
    { key: 'needs', header: 'Key needed', render: (e) => (e.needs === 'catalog' ? 'Any key' : PERMISSION_LABEL[e.needs]) },
  ];

  const selected = PERMISSIONS.find((p) => p.id === permission)!;

  return (
    <div className="bk-stack">
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      {created ? (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Your new key</h2>
          </div>
          <div className="bk-panel__body">
            <p className="bk-shop-note is-info">Copy this key now and keep it somewhere safe. For your security it is shown only once.</p>
            <table className="form-table">
              <tbody>
                <Row label={created.name} help="Treat it like a password: anyone who has it can do what it allows.">
                  <CopyField value={created.token} label="New API key" />
                </Row>
              </tbody>
            </table>
            <p className="submit">
              <button type="button" className="button" onClick={() => setCreated(null)}>
                I have copied it
              </button>
            </p>
          </div>
        </div>
      ) : null}

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Add an API key</h2>
          <p className="bk-panel__lead">Lets an app, another website or a stock or accounting tool use your shop. A key works with your own access, limited by the permissions you choose.</p>
        </div>
        <div className="bk-panel__body">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void create();
            }}
          >
            <table className="form-table">
              <tbody>
                <Row label="Description" htmlFor="api-key-name" help="So you know later what the key is for.">
                  <input id="api-key-name" className="regular-text" type="text" maxLength={80} placeholder="For example: Mobile app" value={name} onChange={(e) => setName(e.target.value)} />
                </Row>
                <Row label="Permissions" help={selected.help}>
                  <div className="bk-tabs is-inline" role="tablist" aria-label="Permissions">
                    {PERMISSIONS.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        role="tab"
                        aria-selected={permission === p.id}
                        className={`bk-tabs__item${permission === p.id ? ' is-active' : ''}`}
                        onClick={() => setPermission(p.id)}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </Row>
              </tbody>
            </table>
            <p className="submit">
              <button type="submit" className="button button-primary" disabled={busy || !name.trim()}>
                {busy ? 'Creating…' : 'Create key'}
              </button>
            </p>
          </form>
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">API keys</h2>
        </div>
        <div className="bk-panel__body">
          <AdminDataTable
            rows={keys ?? []}
            columns={columns}
            getRowId={(k) => k.id}
            loading={keys === null}
            emptyTitle="No API keys yet. Add one above when an app or another website needs your products."
          />
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">For your developer</h2>
          <p className="bk-panel__lead">Share these details together with a key.</p>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <Row label="Address" help="Every request starts with this address.">
                <CopyField value={baseUrl} label="API address" />
              </Row>
              <Row label="Signing requests" help="Send the key with every request in this header. It works from servers, apps and other websites.">
                <code>Authorization: Bearer bk_shop_…</code>
              </Row>
              <Row label="Example" help="Lists your published products.">
                <CopyField value={`curl -H "Authorization: Bearer YOUR_KEY" ${baseUrl}/products`} label="Example request" />
              </Row>
              <Row label="Prices">
                Whole numbers in cents: 12.50 is sent as <code>1250</code>.
              </Row>
              <Row label="Limits">
                Lists come in pages of up to 100. Each key can send up to 300 requests a minute.
              </Row>
            </tbody>
          </table>
          <AdminDataTable rows={ENDPOINTS} columns={endpointColumns} getRowId={(e) => `${e.method} ${e.path}`} defaultPageSize={25} />
        </div>
      </div>
    </div>
  );
}
