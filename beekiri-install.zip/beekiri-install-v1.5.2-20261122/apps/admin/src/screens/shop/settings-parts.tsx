import { useEffect, useRef, useState, type ReactNode } from 'react';
import { ApiError } from '../../api/client';
import { moneyToInput, parseMoney, type ShopMeta } from './api';

/* Small controls shared by the Shop settings tabs. */

export const shortId = () => Math.random().toString(36).slice(2, 10);

export function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong. Try again.';
}

export function Check({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: ReactNode; disabled?: boolean }) {
  return (
    <label className="bk-check">
      <input type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <span className="bk-check__box" aria-hidden />
      <span className="bk-check__label">{label}</span>
    </label>
  );
}

export function Row({ label, htmlFor, children, help }: { label: ReactNode; htmlFor?: string; children: ReactNode; help?: ReactNode }) {
  return (
    <tr>
      <th scope="row">{htmlFor ? <label htmlFor={htmlFor}>{label}</label> : label}</th>
      <td>
        {children}
        {help ? <p className="description">{help}</p> : null}
      </td>
    </tr>
  );
}

/** CSS-only on/off switch (same semantics as a checkbox). */
export function Switch({ checked, onChange, disabled, label }: { checked: boolean; onChange: (v: boolean) => void; disabled?: boolean; label: string }) {
  return (
    <label className={`bk-shop-switch${disabled ? ' is-disabled' : ''}`}>
      <input type="checkbox" role="switch" aria-checked={checked} aria-label={label} checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <span className="bk-shop-switch__track" aria-hidden>
        <span className="bk-shop-switch__knob" />
      </span>
    </label>
  );
}

/** Text input for a money value; keeps the typed text until blur so "1." is not clobbered. */
export function MoneyInput({
  value,
  onChange,
  meta,
  currency,
  id,
  className,
  disabled,
}: {
  value: number | null;
  onChange: (minor: number | null) => void;
  meta: ShopMeta | null;
  currency: string;
  id?: string;
  className?: string;
  disabled?: boolean;
}) {
  const [text, setText] = useState(() => moneyToInput(value, currency, meta?.currencies));
  const lastValue = useRef(value);
  useEffect(() => {
    if (lastValue.current !== value) {
      lastValue.current = value;
      setText(moneyToInput(value, currency, meta?.currencies));
    }
  }, [value, currency, meta?.currencies]);
  return (
    <input
      id={id}
      className={`regular-text ${className ?? ''}`.trim()}
      type="text"
      inputMode="decimal"
      value={text}
      disabled={disabled}
      onChange={(e) => setText(e.target.value)}
      onBlur={() => {
        const minor = parseMoney(text, currency, meta?.currencies);
        lastValue.current = minor;
        onChange(minor);
        setText(moneyToInput(minor, currency, meta?.currencies));
      }}
    />
  );
}

/** Chosen countries as chips, and a search box whose suggestions open while typing or focused. */
export function CountryMultiSelect({
  value,
  onChange,
  countries,
  emptyLabel,
  id,
}: {
  value: string[];
  onChange: (codes: string[]) => void;
  countries: ShopMeta['countries'];
  emptyLabel?: string;
  id?: string;
}) {
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const nameOf = (code: string) => countries.find((c) => c.code === code)?.name ?? code;
  const q = query.trim().toLowerCase();
  const matches = countries
    .filter((c) => !value.includes(c.code))
    .filter((c) => !q || c.name.toLowerCase().includes(q) || c.code.toLowerCase() === q)
    .slice(0, 60);
  const add = (code: string) => {
    onChange([...value, code]);
    setQuery('');
  };
  return (
    <div className="bk-shop-countries">
      {value.length || emptyLabel ? (
        <div className="bk-shop-chips">
          {value.length === 0 && emptyLabel ? <span className="bk-muted">{emptyLabel}</span> : null}
          {value.map((code) => (
            <span key={code} className="bk-shop-chip">
              {nameOf(code)}
              <button type="button" aria-label={`Remove ${nameOf(code)}`} onClick={() => onChange(value.filter((c) => c !== code))}>
                ×
              </button>
            </span>
          ))}
        </div>
      ) : null}
      <div className="bk-shop-countries__search">
        <input
          id={id}
          className="regular-text"
          type="search"
          placeholder="Add a country…"
          autoComplete="off"
          value={query}
          role="combobox"
          aria-expanded={open}
          aria-autocomplete="list"
          onFocus={() => setOpen(true)}
          onBlur={() => setOpen(false)}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onKeyDown={(e) => {
            if (e.key === 'Escape') setOpen(false);
            if (e.key === 'Enter') {
              e.preventDefault();
              if (q && matches[0]) add(matches[0].code);
            }
          }}
        />
        {open ? (
          // Mouse down keeps the focus in the search box, so picking does not close the list first.
          <ul className="bk-shop-countries__list" role="listbox" onMouseDown={(e) => e.preventDefault()}>
            {matches.length === 0 ? <li className="bk-shop-countries__empty">No countries match.</li> : null}
            {matches.map((c) => (
              <li key={c.code} role="option" aria-selected={false}>
                <button type="button" tabIndex={-1} onClick={() => add(c.code)}>
                  {c.name} <span>{c.code}</span>
                </button>
              </li>
            ))}
          </ul>
        ) : null}
      </div>
    </div>
  );
}

export function CountrySelect({ value, onChange, countries, id, blankLabel }: { value: string; onChange: (code: string) => void; countries: ShopMeta['countries']; id?: string; blankLabel: string }) {
  return (
    <select id={id} value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="">{blankLabel}</option>
      {countries.map((c) => (
        <option key={c.code} value={c.code}>
          {c.name}
        </option>
      ))}
    </select>
  );
}

/** Monospace value with a Copy button (the same look as the Stripe address under Payments). */
export function CopyField({ value, label }: { value: string; label: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard unavailable — the value is still visible to select */
    }
  };
  return (
    <span className="bk-shop-settings__code" aria-label={label}>
      <span className="bk-shop-api__value">{value}</span>
      <button type="button" className="button" onClick={() => void copy()}>
        {copied ? 'Copied' : 'Copy'}
      </button>
    </span>
  );
}
