import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { api, apiUpload, ApiError } from '../../api/client';
import { AdminDataTable, type AdminTableColumn, type AdminTableFilter } from '../../components/AdminDataTable';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { SuccessNotice } from '../../components/SuccessNotice';
import { useAdminHref } from '../../lib/AdminEntryContext';
import {
  shopError,
  useShopMeta,
  type ShopImport,
  type ShopImportAction,
  type ShopImportCountKey,
  type ShopImportCouponRow,
  type ShopImportFileKind,
  type ShopImportIssue,
  type ShopImportOptions,
  type ShopImportOrderRow,
  type ShopImportProductRow,
  type ShopImportRowState,
} from './api';

/** Files go up in pieces (the server takes up to 8 MB at a time). */
const CHUNK = 4 * 1024 * 1024;
const WORKING = new Set(['preparing', 'publishing', 'discarding']);

const FILES: { kind: ShopImportFileKind; label: string; accept: string; choose: string; help: string }[] = [
  {
    kind: 'wxr',
    label: 'WordPress export',
    accept: '.xml',
    choose: 'Choose the .xml file',
    help: 'In WordPress, go to Tools → Export, choose All content and download the export file. It has your products, categories, coupons and orders.',
  },
  {
    kind: 'csv',
    label: 'Products file',
    accept: '.csv',
    choose: 'Choose the .csv file',
    help: 'Optional. In WordPress, go to Products → All Products → Export. Use it when you have no WordPress export, or together with it to add products the export is missing.',
  },
  {
    kind: 'photos',
    label: 'Photos',
    accept: '.zip',
    choose: 'Choose the .zip file',
    help: 'Optional. A ZIP of the wp-content/uploads folder of your old website. Without it, the photos are copied from your old website, so it has to be online.',
  },
];

const WEIGHT_UNITS: { id: ShopImportOptions['weightUnit']; label: string }[] = [
  { id: 'kg', label: 'Kilograms (kg)' },
  { id: 'g', label: 'Grams (g)' },
  { id: 'lbs', label: 'Pounds (lbs)' },
  { id: 'oz', label: 'Ounces (oz)' },
];
const SIZE_UNITS: { id: ShopImportOptions['sizeUnit']; label: string }[] = [
  { id: 'cm', label: 'Centimetres (cm)' },
  { id: 'm', label: 'Metres (m)' },
  { id: 'mm', label: 'Millimetres (mm)' },
  { id: 'in', label: 'Inches (in)' },
  { id: 'yd', label: 'Yards (yd)' },
];

const WOO_STATUS: Record<ShopImportProductRow['status'], string> = { publish: 'For sale', draft: 'Draft', private: 'Private', pending: 'Pending review' };
const ISSUE_KIND: Record<string, string> = {
  product: 'Product',
  photo: 'Photo',
  category: 'Category',
  categories: 'Category',
  tag: 'Tag',
  tags: 'Tag',
  coupon: 'Coupon',
  customer: 'Customer',
  order: 'Order',
};
const ACTION_TITLE: Record<ShopImportAction, string> = {
  analyze: 'Checking the files',
  prepare: 'Preparing the preview',
  publish: 'Publishing',
  discard: 'Discarding the import',
};

type Upload = { name: string; size: number; sent: number; error: string | null };
type ListKind = 'products' | 'orders' | 'coupons' | 'problems';

const plural = (n: number, one: string, many: string) => `${n.toLocaleString()} ${n === 1 ? one : many}`;

function bytes(n: number): string {
  if (n < 1024 * 1024) return `${Math.max(1, Math.round(n / 1024))} KB`;
  if (n < 1024 ** 3) return `${(n / 1024 ** 2).toFixed(1)} MB`;
  return `${(n / 1024 ** 3).toFixed(2)} GB`;
}

function dateTime(iso: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString(undefined, { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function hostOf(url: string | null): string {
  if (!url) return '';
  try {
    return new URL(url).host;
  } catch {
    return url;
  }
}

/** Which job an import is busy with (or last tried). */
function actionOf(job: ShopImport): ShopImportAction {
  if (job.status === 'preparing') return 'prepare';
  if (job.status === 'publishing') return 'publish';
  if (job.status === 'discarding') return 'discard';
  return job.progress.action ?? 'analyze';
}

const isWorking = (job: ShopImport) => job.running || WORKING.has(job.status);
/** Files can change until a preview is prepared (also when checking them failed). */
const filesOpen = (job: ShopImport) =>
  !job.running && (job.status === 'uploaded' || job.status === 'ready' || (job.status === 'failed' && job.progress.action === 'analyze'));

function Row({ label, htmlFor, children, help }: { label: ReactNode; htmlFor?: string; children: ReactNode; help?: ReactNode }) {
  return (
    <tr>
      <th scope="row">{htmlFor ? <label htmlFor={htmlFor}>{label}</label> : label}</th>
      <td>
        {children}
        {help ? <p className="description">{help}</p> : null}
      </td>
    </tr>
  );
}

function Check({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: ReactNode; disabled?: boolean }) {
  return (
    <label className="bk-check">
      <input type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <span className="bk-check__box" aria-hidden />
      <span className="bk-check__label">{label}</span>
    </label>
  );
}

function Bar({ label, done, total }: { label: string; done: number; total: number }) {
  const percent = total > 0 ? Math.min(100, Math.round((100 * done) / total)) : 0;
  return (
    <div className={`bk-shop-import__bar${total > 0 ? '' : ' is-waiting'}`} role="progressbar" aria-label={label} aria-valuemin={0} aria-valuemax={100} aria-valuenow={total > 0 ? percent : undefined}>
      <span style={total > 0 ? { width: `${percent}%` } : undefined} />
    </div>
  );
}

/** One piece of a file; a lost connection is tried again (the server ignores a piece it already has). */
async function sendPiece(id: string, makeForm: () => FormData) {
  for (let attempt = 1; ; attempt++) {
    try {
      return await apiUpload<{ received: number; done: boolean; import: ShopImport | null }>(`/api/shop/imports/${encodeURIComponent(id)}/files`, makeForm());
    } catch (e) {
      if (e instanceof ApiError && e.status === 413) {
        throw new Error('Your server did not accept the file. Ask your hosting provider to allow uploads of at least 5 MB per request.');
      }
      const retry = attempt < 4 && (!(e instanceof ApiError) || e.status >= 500 || e.status === 429);
      if (!retry) throw e;
      await new Promise((resolve) => window.setTimeout(resolve, 1500 * attempt));
    }
  }
}

/**
 * Shop → Settings → Import: brings a WooCommerce shop in from its export files. The products are
 * prepared as drafts first, so the shop can be previewed in the website's own design; then the
 * import is published (coupons, customers and orders too) or discarded without a trace.
 */
export function ShopImportTab() {
  const [imports, setImports] = useState<ShopImport[] | null>(null);
  const [job, setJob] = useState<ShopImport | null>(null);
  const [uploads, setUploads] = useState<Partial<Record<ShopImportFileKind, Upload>>>({});
  const [changes, setChanges] = useState<Partial<ShopImportOptions>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const inputs = useRef<Partial<Record<ShopImportFileKind, HTMLInputElement | null>>>({});
  /** Starting an import, shared by files chosen at the same time. */
  const creating = useRef<Promise<ShopImport> | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await api<{ imports: ShopImport[]; current: ShopImport | null }>('/api/shop/imports');
      setImports(res.imports);
      setJob((j) => res.current ?? (j ? (res.imports.find((i) => i.id === j.id && i.status === 'published') ?? null) : null));
    } catch (e) {
      setError(shopError(e));
      setImports((list) => list ?? []);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  /** The latest state of a running job; tells what happened once it stops. */
  const settle = useCallback(
    (prev: ShopImport, next: ShopImport) => {
      if (isWorking(prev) && !isWorking(next)) {
        if (next.status === 'ready') setChanges({});
        else if (next.status === 'prepared') setNotice('The preview is ready. Look at your shop, then publish or discard the import.');
        else if (next.status === 'published') {
          setNotice('Import published. The products, coupons, customers and orders are now in your shop.');
          void load();
        } else if (next.status === 'discarded') {
          setNotice('Import discarded. Everything it added was removed again.');
          setJob(null);
          setUploads({});
          void load();
          return;
        }
      }
      setJob(next);
    },
    [load],
  );

  const working = job ? isWorking(job) : false;
  useEffect(() => {
    if (!job || !working) return;
    let stopped = false;
    const timer = window.setTimeout(async () => {
      try {
        const next = await api<ShopImport>(`/api/shop/imports/${encodeURIComponent(job.id)}`);
        if (!stopped) settle(job, next);
      } catch (e) {
        if (!stopped) setError(shopError(e));
      }
    }, 1200);
    return () => {
      stopped = true;
      window.clearTimeout(timer);
    };
  }, [job, working, settle]);

  const uploading = Object.values(uploads).some((u) => u && !u.error && u.sent < u.size);

  const pickFile = async (kind: ShopImportFileKind, file: File) => {
    setError(null);
    setNotice(null);
    if (!file.size) {
      setUploads((u) => ({ ...u, [kind]: { name: file.name, size: 0, sent: 0, error: 'This file is empty. Export it again and choose the new file.' } }));
      return;
    }
    setUploads((u) => ({ ...u, [kind]: { name: file.name, size: file.size, sent: 0, error: null } }));
    try {
      let target = job && filesOpen(job) ? job : null;
      if (!target) {
        creating.current ??= api<ShopImport>('/api/shop/imports', { method: 'POST' }).finally(() => {
          creating.current = null;
        });
        target = await creating.current;
        setJob(target);
      }
      const id = target.id;
      let offset = 0;
      while (offset < file.size) {
        const start = offset;
        const res = await sendPiece(id, () => {
          const form = new FormData();
          form.append('kind', kind);
          form.append('name', file.name);
          form.append('offset', String(start));
          form.append('total', String(file.size));
          form.append('file', file.slice(start, start + CHUNK), file.name);
          return form;
        });
        offset = res.received;
        setUploads((u) => ({ ...u, [kind]: { name: file.name, size: file.size, sent: offset, error: null } }));
        if (res.done && res.import) {
          setJob(res.import);
          setChanges({});
        }
      }
      setUploads((u) => {
        const next = { ...u };
        delete next[kind];
        return next;
      });
    } catch (e) {
      setUploads((u) => ({ ...u, [kind]: { name: file.name, size: file.size, sent: 0, error: shopError(e) } }));
    }
  };

  const removeFile = async (kind: ShopImportFileKind) => {
    if (!job) return;
    setBusy(true);
    setError(null);
    try {
      setJob(await api<ShopImport>(`/api/shop/imports/${encodeURIComponent(job.id)}/files/${kind}`, { method: 'DELETE' }));
    } catch (e) {
      setError(shopError(e));
    } finally {
      setBusy(false);
    }
  };

  const run = async (step: 'check' | 'prepare' | 'publish' | 'discard', json: unknown = {}) => {
    if (!job) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      setJob(await api<ShopImport>(`/api/shop/imports/${encodeURIComponent(job.id)}/${step}`, { method: 'POST', json }));
    } catch (e) {
      setError(shopError(e));
    } finally {
      setBusy(false);
    }
  };

  const options: ShopImportOptions | null = job ? { ...job.options, ...changes } : null;
  const setOption = <K extends keyof ShopImportOptions>(key: K, value: ShopImportOptions[K]) => setChanges((c) => ({ ...c, [key]: value }));

  const publish = async () => {
    if (!job || !options) return;
    const counts = job.summary?.counts;
    const parts = [
      options.products
        ? options.productStatus === 'keep'
          ? 'The products that were for sale in WooCommerce go live in your shop.'
          : 'The imported products stay drafts, so you can publish them yourself.'
        : '',
      options.coupons && counts?.coupons ? `${plural(counts.coupons, 'coupon is', 'coupons are')} added.` : '',
      options.orders && counts?.orders ? `${plural(counts.orders, 'order is', 'orders are')} added, with their customers.` : '',
      'No e-mails are sent and stock levels do not change. You can edit or delete anything afterwards.',
    ];
    const ok = await confirmDialog({ title: 'Publish import', message: parts.filter(Boolean).join(' '), confirmLabel: 'Publish' });
    if (ok) await run('publish');
  };

  const discard = async () => {
    if (!job) return;
    const prepared = job.status === 'prepared' || (job.status === 'failed' && job.progress.action === 'prepare');
    const ok = await confirmDialog({
      title: 'Discard import',
      message: prepared
        ? 'The products, photos, categories and tags this import added are removed. Anything your shop already had stays as it is. This cannot be undone.'
        : 'The uploaded files are deleted. Your shop is not changed.',
      confirmLabel: 'Discard import',
      danger: true,
    });
    if (ok) await run('discard');
  };

  const startOver = () => {
    setJob(null);
    setUploads({});
    setChanges({});
    setNotice(null);
  };

  const history = useMemo(() => (imports ?? []).filter((i) => i.status === 'published' || i.status === 'discarded'), [imports]);

  const stage = !job
    ? 'files'
    : isWorking(job)
      ? 'working'
      : filesOpen(job)
        ? 'files'
        : job.status === 'prepared'
          ? 'preview'
          : job.status === 'failed'
            ? 'failed'
            : job.status === 'published'
              ? 'done'
              : 'files';

  return (
    <div className="bk-stack bk-shop-import">
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      {imports === null ? (
        <div className="bk-settings-panel__loading" role="status">
          <span className="bk-settings-panel__spinner" aria-hidden />
          <span>Loading…</span>
        </div>
      ) : null}

      {imports !== null && stage === 'files' ? (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Import from WooCommerce</h2>
            <p className="bk-panel__lead">
              Bring your products, photos, coupons, customers and orders over from WooCommerce. You see a preview of your shop first; nothing goes live until you publish.
            </p>
          </div>
          <div className="bk-panel__body">
            <table className="form-table">
              <tbody>
                {FILES.map((f) => {
                  const uploaded = job?.files.find((x) => x.kind === f.kind);
                  const upload = uploads[f.kind];
                  const open = !job || filesOpen(job);
                  return (
                    <Row key={f.kind} label={f.label} help={f.help}>
                      <input
                        ref={(el) => {
                          inputs.current[f.kind] = el;
                        }}
                        type="file"
                        accept={f.accept}
                        hidden
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          e.target.value = '';
                          if (file) void pickFile(f.kind, file);
                        }}
                      />
                      {upload && !upload.error ? (
                        <div className="bk-shop-import__file">
                          <span className="bk-shop-import__name">{upload.name}</span>
                          <span className="bk-muted">
                            {bytes(upload.sent)} of {bytes(upload.size)}
                          </span>
                          <Bar label={`Uploading ${upload.name}`} done={upload.sent} total={upload.size} />
                        </div>
                      ) : uploaded ? (
                        <div className="bk-shop-import__file">
                          <span className="bk-shop-import__name">{uploaded.name}</span>
                          <span className="bk-muted">{bytes(uploaded.size)}</span>
                          <span className="bk-shop-import__actions">
                            <button type="button" className="button-link" disabled={!open || busy || uploading} onClick={() => inputs.current[f.kind]?.click()}>
                              Replace
                            </button>
                            <button type="button" className="button-link is-danger" disabled={!open || busy || uploading} onClick={() => void removeFile(f.kind)}>
                              Remove
                            </button>
                          </span>
                        </div>
                      ) : (
                        <button type="button" className="button" disabled={!open || busy || uploading} onClick={() => inputs.current[f.kind]?.click()}>
                          {f.choose}
                        </button>
                      )}
                      {upload?.error ? <p className="bk-shop-note is-error bk-shop-import__error">{upload.error}</p> : null}
                    </Row>
                  );
                })}
              </tbody>
            </table>
            {job?.status === 'failed' && job.error ? <p className="bk-shop-note is-error">{job.error}</p> : null}
            <p className="submit">
              <button
                type="button"
                className={`button${job?.status === 'ready' ? '' : ' button-primary'}`}
                disabled={!job || busy || uploading || !job.files.some((f) => f.kind === 'wxr' || f.kind === 'csv')}
                onClick={() => void run('check')}
              >
                {job?.status === 'ready' ? 'Check the files again' : 'Check the files'}
              </button>
              {job ? (
                <button type="button" className="button-link is-danger" disabled={busy || uploading} onClick={() => void discard()}>
                  Cancel import
                </button>
              ) : null}
            </p>
          </div>
        </div>
      ) : null}

      {stage === 'files' && job?.status === 'ready' && job.summary && options ? (
        <>
          <SummaryPanel job={job} />
          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">What to import</h2>
            </div>
            <div className="bk-panel__body">
              <table className="form-table">
                <tbody>
                  <Row label="Bring in">
                    <div className="bk-shop-import__checks">
                      <Check
                        checked={options.products}
                        disabled={!job.summary.counts.products}
                        onChange={(v) => setOption('products', v)}
                        label="Products, with their photos, categories and tags"
                      />
                      <Check checked={options.coupons} disabled={!job.summary.counts.coupons} onChange={(v) => setOption('coupons', v)} label="Coupons" />
                      <Check checked={options.orders} disabled={!job.summary.counts.orders} onChange={(v) => setOption('orders', v)} label="Orders and customers" />
                    </div>
                  </Row>
                  <Row
                    label="After publishing"
                    help={
                      options.productStatus === 'keep'
                        ? 'Products that were for sale in WooCommerce go live; drafts and private products stay drafts.'
                        : 'Every imported product stays a draft, so you can check each one and publish it yourself.'
                    }
                  >
                    <div className="bk-tabs is-inline" role="tablist" aria-label="After publishing">
                      {(
                        [
                          ['keep', 'Same as in WooCommerce'],
                          ['draft', 'Keep all as drafts'],
                        ] as const
                      ).map(([id, label]) => (
                        <button
                          key={id}
                          type="button"
                          role="tab"
                          aria-selected={options.productStatus === id}
                          className={`bk-tabs__item${options.productStatus === id ? ' is-active' : ''}`}
                          onClick={() => setOption('productStatus', id)}
                        >
                          {label}
                        </button>
                      ))}
                    </div>
                  </Row>
                  <Row
                    label="Descriptions"
                    help="Removes WordPress shortcodes, old colours and fonts, so descriptions look like the rest of your website. Links to your old shop point to the new pages."
                  >
                    <Check checked={options.cleanDescriptions} onChange={(v) => setOption('cleanDescriptions', v)} label="Match my website's design" />
                  </Row>
                  <Row
                    label="Weight unit"
                    htmlFor="import-weight"
                    help={
                      job.summary.units.weight
                        ? `The products file uses ${job.summary.units.weight}.`
                        : 'The unit your WooCommerce shop used for weights (WooCommerce → Settings → Products).'
                    }
                  >
                    <select id="import-weight" value={options.weightUnit} onChange={(e) => setOption('weightUnit', e.target.value as ShopImportOptions['weightUnit'])}>
                      {WEIGHT_UNITS.map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.label}
                        </option>
                      ))}
                    </select>
                  </Row>
                  <Row
                    label="Size unit"
                    htmlFor="import-size"
                    help={
                      job.summary.units.size
                        ? `The products file uses ${job.summary.units.size}.`
                        : 'The unit your WooCommerce shop used for length, width and height.'
                    }
                  >
                    <select id="import-size" value={options.sizeUnit} onChange={(e) => setOption('sizeUnit', e.target.value as ShopImportOptions['sizeUnit'])}>
                      {SIZE_UNITS.map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.label}
                        </option>
                      ))}
                    </select>
                  </Row>
                </tbody>
              </table>
              <p className="submit">
                <button
                  type="button"
                  className="button button-primary"
                  disabled={busy || uploading || (!options.products && !options.coupons && !options.orders)}
                  onClick={() => void run('prepare', { options })}
                >
                  Prepare preview
                </button>
                <span className="bk-muted">Adds the products as drafts that only you can see. Your shop does not change until you publish.</span>
              </p>
            </div>
          </div>
        </>
      ) : null}

      {stage === 'working' && job ? (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">{ACTION_TITLE[actionOf(job)]}</h2>
          </div>
          <div className="bk-panel__body">
            <p aria-live="polite">{job.progress.step !== 'done' && job.progress.message ? job.progress.message : 'Starting…'}</p>
            <Bar
              label={ACTION_TITLE[actionOf(job)]}
              done={job.progress.step !== 'done' ? (job.progress.done ?? 0) : 0}
              total={job.progress.step !== 'done' ? (job.progress.total ?? 0) : 0}
            />
            <p className="bk-muted">This keeps going on the server if you leave this page. Large shops can take a while.</p>
          </div>
        </div>
      ) : null}

      {stage === 'preview' && job ? (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Preview ready</h2>
            <p className="bk-panel__lead">The products are in your shop as drafts that visitors cannot see yet.</p>
          </div>
          <div className="bk-panel__body">
            <ReportTable job={job} />
            <p className="submit">
              {job.previewUrl ? (
                <a className="button" href={job.previewUrl} target="_blank" rel="noreferrer">
                  Preview the shop
                </a>
              ) : null}
              <button type="button" className="button button-primary" disabled={busy} onClick={() => void publish()}>
                Publish import
              </button>
              <button type="button" className="button-link is-danger" disabled={busy} onClick={() => void discard()}>
                Discard import
              </button>
            </p>
            <p className="bk-muted">
              The preview opens your shop with the imported products, in your browser only. To go back to the normal shop, use Leave preview at the bottom of the
              page.
            </p>
          </div>
        </div>
      ) : null}

      {stage === 'failed' && job ? (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">The import stopped</h2>
          </div>
          <div className="bk-panel__body">
            <p className="bk-shop-note is-error">{job.error ?? 'Something went wrong while importing.'}</p>
            <p>
              {job.progress.action === 'publish'
                ? 'Part of the import is already published. Continue to finish it; whatever is done is not added twice.'
                : 'Continue where it stopped; whatever is done is not added twice. Or discard the import to remove everything it added.'}
            </p>
            <p className="submit">
              <button
                type="button"
                className="button button-primary"
                disabled={busy}
                onClick={() => void run(job.progress.action === 'publish' ? 'publish' : job.progress.action === 'discard' ? 'discard' : 'prepare')}
              >
                Continue
              </button>
              {job.progress.action !== 'publish' && job.progress.action !== 'discard' ? (
                <button type="button" className="button-link is-danger" disabled={busy} onClick={() => void discard()}>
                  Discard import
                </button>
              ) : null}
            </p>
          </div>
        </div>
      ) : null}

      {stage === 'done' && job ? (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Import published</h2>
            <p className="bk-panel__lead">
              {job.summary?.siteName ? `From ${job.summary.siteName}, ` : ''}published {dateTime(job.publishedAt)}.
            </p>
          </div>
          <div className="bk-panel__body">
            <ReportTable job={job} />
            <p className="submit">
              <button type="button" className="button" onClick={startOver}>
                Start a new import
              </button>
            </p>
          </div>
        </div>
      ) : null}

      {job && (stage === 'preview' || stage === 'failed' || stage === 'done') && job.summary ? <ImportLists job={job} /> : null}

      {history.length ? (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Earlier imports</h2>
          </div>
          <div className="bk-panel__body">
            <AdminDataTable
              rows={history}
              columns={historyColumns}
              getRowId={(i) => i.id}
              onRowClick={(i) => {
                if (i.status !== 'published' || (job && !['published'].includes(job.status))) return;
                setJob(i);
                setNotice(null);
              }}
              emptyTitle="No earlier imports."
            />
          </div>
        </div>
      ) : null}
    </div>
  );
}

const historyColumns: AdminTableColumn<ShopImport>[] = [
  { key: 'date', header: 'Started', render: (i) => <span className="bk-table__primary">{dateTime(i.createdAt)}</span> },
  {
    key: 'from',
    header: 'From',
    render: (i) => i.summary?.siteName || hostOf(i.summary?.siteUrl ?? null) || i.files.map((f) => f.name).join(', ') || '—',
  },
  { key: 'products', header: 'Products', render: (i) => (i.status === 'published' ? (i.report.created.products ?? 0).toLocaleString() : '—') },
  { key: 'orders', header: 'Orders', render: (i) => (i.status === 'published' ? (i.report.created.orders ?? 0).toLocaleString() : '—') },
  {
    key: 'result',
    header: 'Result',
    render: (i) => (i.status === 'published' ? <span className="bk-table__badge is-ok">Published</span> : <span className="bk-table__badge">Discarded</span>),
  },
];

/** What the files hold, and how this shop will take it. */
function SummaryPanel({ job }: { job: ShopImport }) {
  const s = job.summary!;
  const c = s.counts;
  const from = s.siteName ? `${s.siteName}${s.siteUrl ? ` (${hostOf(s.siteUrl)})` : ''}` : s.siteUrl ? hostOf(s.siteUrl) : 'WooCommerce products file';
  const otherCurrencies = s.currency.orders.filter((code) => code !== s.currency.shop);
  return (
    <div className="bk-panel">
      <div className="bk-panel__head">
        <h2 className="bk-panel__title">What the files have</h2>
      </div>
      <div className="bk-panel__body">
        <table className="form-table">
          <tbody>
            <Row label="From">{from}</Row>
            <Row
              label="Products"
              help={
                s.existing.products
                  ? `${plural(s.existing.products, 'product is', 'products are')} already in your shop (same SKU, or imported before). They are left as they are.`
                  : undefined
              }
            >
              {plural(c.products, 'product', 'products')}
              {c.variations ? `, with ${plural(c.variations, 'variation', 'variations')}` : ''}
            </Row>
            <Row label="Categories and tags" help={c.categories || c.tags ? 'Categories and tags with the same name as yours are shared, not doubled.' : undefined}>
              {plural(c.categories, 'category', 'categories')}, {plural(c.tags, 'tag', 'tags')}
            </Row>
            <Row
              label="Photos"
              help={
                s.photos.fromSite
                  ? `Your old website has to be online while the preview is prepared. To skip this, add a ZIP of its wp-content/uploads folder above.`
                  : undefined
              }
            >
              {!s.photos.total
                ? s.existing.products
                  ? 'No new photos'
                  : 'No photos'
                : s.photos.fromSite === 0
                  ? `${plural(s.photos.total, 'photo', 'photos')}, all in your ZIP`
                  : s.photos.inZip
                    ? `${plural(s.photos.total, 'photo', 'photos')}: ${s.photos.inZip.toLocaleString()} from your ZIP, ${s.photos.fromSite.toLocaleString()} copied from ${s.photos.hosts.join(', ') || 'your old website'}`
                    : `${plural(s.photos.total, 'photo', 'photos')}, copied from ${s.photos.hosts.join(', ') || 'your old website'}`}
            </Row>
            <Row
              label="Coupons"
              help={s.existing.coupons ? `${plural(s.existing.coupons, 'code is', 'codes are')} already used by your coupons; those stay as they are.` : undefined}
            >
              {c.coupons ? plural(c.coupons, 'coupon', 'coupons') : 'No coupons'}
            </Row>
            <Row
              label="Orders"
              help={
                c.orders ? (
                  <>
                    {s.orderNumbers === 'keep'
                      ? 'They keep their WooCommerce order numbers. '
                      : 'Your shop already uses some of these order numbers, so they get new numbers after your latest order; each order notes its WooCommerce number. '}
                    A WordPress export does not say which products were in an order, so imported orders show the customer, addresses, totals and notes.
                    {s.existing.orders ? ` ${plural(s.existing.orders, 'order was', 'orders were')} imported before and stay as they are; only new orders are added.` : ''}
                    {s.existing.customers ? ` ${plural(s.existing.customers, 'customer is', 'customers are')} already in your shop and get their orders added.` : ''}
                  </>
                ) : undefined
              }
            >
              {c.orders ? `${plural(c.orders, 'order', 'orders')} from ${plural(c.customers, 'customer', 'customers')}` : 'No orders'}
            </Row>
          </tbody>
        </table>
        {s.ordersWithoutDetails ? (
          <p className="bk-shop-note">
            {plural(s.ordersWithoutDetails, 'order is', 'orders are')} missing from the export: your WooCommerce shop keeps orders in its newer order storage, which the WordPress
            export leaves out. To bring them too, turn on compatibility mode in WooCommerce → Settings → Advanced → Features, wait until it has finished syncing, then
            export again and replace the file above.
          </p>
        ) : null}
        {otherCurrencies.length ? (
          <p className="bk-shop-note">
            Your WooCommerce orders are in {otherCurrencies.join(', ')} and this shop uses {s.currency.shop}. Orders keep their own currency. Product prices and coupon
            amounts are copied as they are, without converting them: to sell in {otherCurrencies[0]}, change the currency in the General tab first, then check the files
            again.
          </p>
        ) : null}
        {s.warnings.map((w) => (
          <p key={w} className="bk-shop-note">
            {w}
          </p>
        ))}
      </div>
    </div>
  );
}

/** Counts of what the import added, kept and left out. */
function ReportTable({ job }: { job: ShopImport }) {
  const { created, reused, skipped } = job.report;
  const published = job.status === 'published';
  const line = (key: ShopImportCountKey, one: string, many: string, addedWord: string) => {
    const parts = [];
    if (created[key]) parts.push(`${plural(created[key]!, one, many)} ${addedWord}`);
    if (reused[key]) parts.push(`${reused[key]!.toLocaleString()} already in your shop`);
    if (skipped[key]) parts.push(`${skipped[key]!.toLocaleString()} not imported`);
    return parts.length ? parts.join(', ') : null;
  };
  const rows: [string, string | null][] = [
    ['Products', line('products', 'product', 'products', published ? 'added' : 'added as drafts')],
    ['Variations', line('variations', 'variation', 'variations', 'added')],
    ['Photos', line('photos', 'photo', 'photos', 'added to Media')],
    ['Categories', line('categories', 'category', 'categories', 'added')],
    ['Tags', line('tags', 'tag', 'tags', 'added')],
    ['Coupons', line('coupons', 'coupon', 'coupons', 'added')],
    ['Customers', line('customers', 'customer', 'customers', 'added')],
    ['Orders', line('orders', 'order', 'orders', 'added')],
  ];
  const shown = rows.filter(([, text]) => text);
  return (
    <table className="form-table">
      <tbody>
        {shown.map(([label, text]) => (
          <Row key={label} label={label}>
            {text}
          </Row>
        ))}
        {job.status === 'prepared' && job.options.orders && job.summary?.counts.orders ? (
          <Row label="Orders">{plural(job.summary.counts.orders, 'order is', 'orders are')} added when you publish, with their customers.</Row>
        ) : null}
        {job.status === 'prepared' && job.options.coupons && job.summary?.counts.coupons ? (
          <Row label="Coupons">{plural(job.summary.counts.coupons, 'coupon is', 'coupons are')} added when you publish.</Row>
        ) : null}
        {job.report.issueCount ? (
          <Row label="Problems">{plural(job.report.issueCount, 'thing needs', 'things need')} a look; see Problems below.</Row>
        ) : null}
      </tbody>
    </table>
  );
}

/** The imported products, orders and coupons, and anything that needs a look. */
function ImportLists({ job }: { job: ShopImport }) {
  const meta = useShopMeta();
  const href = useAdminHref();
  const counts = job.summary!.counts;
  const tabs = (
    [
      ['products', 'Products', counts.products],
      ['orders', 'Orders', counts.orders],
      ['coupons', 'Coupons', counts.coupons],
      ['problems', 'Problems', job.report.issueCount],
    ] as [ListKind, string, number][]
  ).filter(([, , n]) => n > 0);
  const [tab, setTab] = useState<ListKind>(tabs[0]?.[0] ?? 'products');
  const [rows, setRows] = useState<{ key: string; rows: unknown[]; total: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const published = job.status === 'published';
  const key = `${job.id}|${job.status}|${tab}`;

  useEffect(() => {
    if (tab === 'problems') return;
    let cancelled = false;
    setError(null);
    api<{ rows: unknown[]; total: number }>(`/api/shop/imports/${encodeURIComponent(job.id)}/rows?kind=${tab}`)
      .then((res) => {
        if (!cancelled) setRows({ key, ...res });
      })
      .catch((e) => {
        if (!cancelled) setError(shopError(e));
      });
    return () => {
      cancelled = true;
    };
  }, [job.id, tab, key]);

  if (!tabs.length) return null;
  const loaded = rows?.key === key ? rows : null;

  const stateBadge = (state: ShopImportRowState, waiting: string) =>
    state === 'imported' ? (
      <span className="bk-table__badge is-ok">{published ? 'Imported' : 'In the preview'}</span>
    ) : state === 'kept' ? (
      <span className="bk-table__badge is-accent">Already in your shop</span>
    ) : state === 'issue' ? (
      <span className="bk-table__badge is-danger">Not imported</span>
    ) : (
      <span className="bk-table__badge">{waiting}</span>
    );
  /** Products not for sale in WooCommerce (or all, when chosen) stay drafts after publishing. */
  const productBadge = (p: ShopImportProductRow) => {
    if (p.state !== 'imported') return stateBadge(p.state, 'Left out');
    if (published) {
      const live = p.status === 'publish' && job.options.productStatus === 'keep';
      return <span className="bk-table__badge is-ok">{live ? 'Imported' : 'Imported as draft'}</span>;
    }
    return p.status === 'publish' ? <span className="bk-table__badge is-ok">In the preview</span> : <span className="bk-table__badge">Stays a draft</span>;
  };
  const withMessage = (badge: ReactNode, message: string | null) => (
    <>
      {badge}
      {message ? <div className="bk-table__muted">{message}</div> : null}
    </>
  );

  const search = (placeholder: string): AdminTableFilter[] => [{ key: 'q', label: 'Search', type: 'text', placeholder }];
  const matches = (values: Record<string, string>, ...fields: (string | null | undefined)[]) => {
    const q = (values.q ?? '').trim().toLowerCase();
    return !q || fields.some((f) => f && f.toLowerCase().includes(q));
  };

  const productColumns: AdminTableColumn<ShopImportProductRow>[] = [
    {
      key: 'name',
      header: 'Product',
      render: (p) => (
        <>
          <span className="bk-table__primary">{p.name}</span>
          {p.postId ? (
            <div className="bk-table__row-actions">
              <Link className="button-link" to={href(`shop/products/${p.postId}`)}>
                Edit
              </Link>
            </div>
          ) : null}
        </>
      ),
    },
    { key: 'sku', header: 'SKU', render: (p) => p.sku || <span className="bk-table__muted">—</span> },
    { key: 'price', header: 'Price', render: (p) => p.price || <span className="bk-table__muted">—</span> },
    { key: 'categories', header: 'Categories', render: (p) => p.categories || <span className="bk-table__muted">—</span> },
    { key: 'woo', header: 'In WooCommerce', render: (p) => WOO_STATUS[p.status] ?? p.status },
    { key: 'state', header: 'Import', render: (p) => withMessage(productBadge(p), p.message) },
  ];
  const orderColumns: AdminTableColumn<ShopImportOrderRow>[] = [
    {
      key: 'number',
      header: 'Order',
      render: (o) => (
        <>
          <span className="bk-table__primary">#{o.number}</span>
          {o.orderId ? (
            <div className="bk-table__row-actions">
              <Link className="button-link" to={href(`shop/orders/${o.orderId}`)}>
                View
              </Link>
            </div>
          ) : null}
        </>
      ),
    },
    { key: 'date', header: 'Date', render: (o) => dateTime(o.date) },
    {
      key: 'customer',
      header: 'Customer',
      render: (o) => (
        <>
          {o.customer || '—'}
          {o.email && o.email !== o.customer ? <div className="bk-table__muted">{o.email}</div> : null}
        </>
      ),
    },
    { key: 'status', header: 'Status', render: (o) => meta?.orderStatuses.find((s) => s.id === o.status)?.label ?? o.status },
    { key: 'total', header: 'Total', render: (o) => o.total },
    {
      key: 'state',
      header: 'Import',
      render: (o) => withMessage(stateBadge(o.state, published || !job.options.orders ? 'Left out' : 'Added when you publish'), o.message),
    },
  ];
  const couponColumns: AdminTableColumn<ShopImportCouponRow>[] = [
    { key: 'code', header: 'Code', render: (c) => <span className="bk-table__primary">{c.code}</span> },
    { key: 'amount', header: 'Discount', render: (c) => c.amount },
    { key: 'usage', header: 'Used', render: (c) => c.usage },
    { key: 'expires', header: 'Expires', render: (c) => (c.expires ? dateTime(c.expires) : <span className="bk-table__muted">Never</span>) },
    {
      key: 'state',
      header: 'Import',
      render: (c) => withMessage(stateBadge(c.state, published || !job.options.coupons ? 'Left out' : 'Added when you publish'), c.message),
    },
  ];
  const problemRows = job.report.issues.map((issue, i) => ({ ...issue, id: String(i) }));
  const problemColumns: AdminTableColumn<ShopImportIssue & { id: string }>[] = [
    { key: 'kind', header: 'Item', render: (p) => ISSUE_KIND[p.kind] ?? p.kind },
    { key: 'name', header: 'Name', render: (p) => <span className="bk-table__primary">{p.name}</span> },
    { key: 'message', header: 'What happened', render: (p) => p.message },
  ];

  return (
    <div className="bk-panel">
      <div className="bk-panel__head">
        <h2 className="bk-panel__title">{published ? 'Imported' : 'In this import'}</h2>
      </div>
      <div className="bk-panel__body">
        <div className="bk-tabs is-flush" role="tablist" aria-label="Lists">
          {tabs.map(([id, label, n]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={tab === id}
              className={`bk-tabs__item${tab === id ? ' is-active' : ''}`}
              onClick={() => setTab(id)}
            >
              {label} <span className="bk-tabs__count">{n.toLocaleString()}</span>
            </button>
          ))}
        </div>
        {error ? <p className="bk-shop-note is-error">{error}</p> : null}
        {tab === 'products' ? (
          <AdminDataTable
            rows={(loaded?.rows ?? []) as ShopImportProductRow[]}
            columns={productColumns}
            getRowId={(p) => p.id}
            loading={!loaded && !error}
            filters={search('Name, SKU or category')}
            filterFn={(p, v) => matches(v, p.name, p.sku, p.categories)}
            emptyTitle="No products in the files."
          />
        ) : tab === 'orders' ? (
          <AdminDataTable
            rows={(loaded?.rows ?? []) as ShopImportOrderRow[]}
            columns={orderColumns}
            getRowId={(o) => o.id}
            loading={!loaded && !error}
            filters={search('Number, name or e-mail')}
            filterFn={(o, v) => matches(v, o.number, o.customer, o.email)}
            emptyTitle="No orders in the files."
          />
        ) : tab === 'coupons' ? (
          <AdminDataTable
            rows={(loaded?.rows ?? []) as ShopImportCouponRow[]}
            columns={couponColumns}
            getRowId={(c) => c.id}
            loading={!loaded && !error}
            filters={search('Code')}
            filterFn={(c, v) => matches(v, c.code)}
            emptyTitle="No coupons in the files."
          />
        ) : (
          <>
            <AdminDataTable
              rows={problemRows}
              columns={problemColumns}
              getRowId={(p) => p.id}
              filters={search('Name or problem')}
              filterFn={(p, v) => matches(v, p.name, p.message)}
              emptyTitle="Nothing needs a look."
            />
            {job.report.issueCount > problemRows.length ? (
              <p className="bk-muted">
                Showing the first {problemRows.length} of {job.report.issueCount.toLocaleString()}.
              </p>
            ) : null}
          </>
        )}
      </div>
    </div>
  );
}
