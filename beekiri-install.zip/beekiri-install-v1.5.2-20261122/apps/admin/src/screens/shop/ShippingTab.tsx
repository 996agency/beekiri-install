import { useState, type FormEvent, type ReactNode } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AdminDataTable, type AdminTableColumn } from '../../components/AdminDataTable';
import { AdminModal } from '../../components/AdminModal';
import { formatMoney, type Courier, type ShippingMethod, type ShippingZone, type ShopMeta, type ShopSettings } from './api';
import { Check, CountryMultiSelect, MoneyInput, Row, shortId } from './settings-parts';
import { ShippingCouriers, useCouriers } from './ShippingCouriers';

/**
 * Shop → Settings → Shipping: zones and their shipping methods (saved with the other settings), and
 * courier connections (saved one by one). Sections and the zone or courier being edited live in the
 * address (?section=couriers, ?zone=…, ?courier=…).
 */

const METHOD_TYPES: { id: ShippingMethod['type']; label: string; title: string; help: string }[] = [
  { id: 'flat_rate', label: 'Flat rate', title: 'Standard delivery', help: 'A fixed price for delivery.' },
  { id: 'free_shipping', label: 'Free shipping', title: 'Free shipping', help: 'Free delivery, optionally only from a minimum order amount.' },
  { id: 'local_pickup', label: 'Local pickup', title: 'Pick up in store', help: 'Customers collect the order from you.' },
];
const typeLabel = (t: ShippingMethod['type']) => METHOD_TYPES.find((m) => m.id === t)?.label ?? t;

type Props = {
  /** null while the settings load. */
  settings: ShopSettings['shipping'] | null;
  storeCountry: string;
  meta: ShopMeta | null;
  currency: string;
  countries: ShopMeta['countries'];
  dirty: boolean;
  onChange: (p: Partial<ShopSettings['shipping']>) => void;
  onSave: () => void;
  saveBar: ReactNode;
};

export function ShippingTab(props: Props) {
  const [params, setParams] = useSearchParams();
  const section = params.get('section') === 'couriers' ? 'couriers' : 'zones';
  const couriers = useCouriers();
  const go = (patch: Record<string, string | null>) => {
    const next = new URLSearchParams(params);
    for (const [k, v] of Object.entries(patch)) {
      if (v === null) next.delete(k);
      else next.set(k, v);
    }
    setParams(next, { replace: false });
  };

  return (
    <div className="bk-stack">
      <nav className="bk-tabs" role="tablist" aria-label="Shipping sections">
        {(
          [
            ['zones', 'Shipping zones', props.settings?.zones.length ?? null],
            ['couriers', 'Couriers', couriers.data?.couriers.length ?? null],
          ] as const
        ).map(([id, label, count]) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={section === id}
            className={`bk-tabs__item${section === id ? ' is-active' : ''}`}
            onClick={() => go({ section: id === 'zones' ? null : id, zone: null, courier: null })}
          >
            {label}
            {count ? <span className="bk-tabs__count">{count}</span> : null}
          </button>
        ))}
      </nav>

      {section === 'couriers' ? (
        <>
          {props.dirty ? <p className="bk-shop-note">You have unsaved changes in Shipping zones. Go back there and save them before you leave this page.</p> : null}
          <ShippingCouriers couriers={couriers} openId={params.get('courier')} onOpen={(id) => go({ courier: id })} />
        </>
      ) : !props.settings ? (
        <div className="bk-settings-panel__loading" role="status">
          <span className="bk-settings-panel__spinner" aria-hidden />
          <span>Loading…</span>
        </div>
      ) : (
        <form
          className="bk-stack"
          onSubmit={(e: FormEvent) => {
            e.preventDefault();
            props.onSave();
          }}
        >
          <Zones {...props} settings={props.settings} couriers={couriers.data?.couriers ?? []} zoneId={params.get('zone')} onOpenZone={(id) => go({ zone: id })} onOpenCouriers={() => go({ section: 'couriers', zone: null })} />
          {props.saveBar}
        </form>
      )}
    </div>
  );
}

/* ── Zones ───────────────────────────────────────────────────────────── */

function regionsText(zone: ShippingZone, countries: ShopMeta['countries']): ReactNode {
  if (!zone.countries.length) return <span className="bk-table__muted">Everywhere else</span>;
  const names = zone.countries.map((c) => countries.find((x) => x.code === c)?.name ?? c);
  return names.length <= 3 ? names.join(', ') : `${names.slice(0, 3).join(', ')} and ${names.length - 3} more`;
}

function Zones({
  settings,
  storeCountry,
  meta,
  currency,
  countries,
  couriers,
  zoneId,
  onChange,
  onOpenZone,
  onOpenCouriers,
}: Props & { settings: ShopSettings['shipping']; couriers: Courier[]; zoneId: string | null; onOpenZone: (id: string | null) => void; onOpenCouriers: () => void }) {
  const zones = settings.zones;
  const zone = zoneId ? zones.find((z) => z.id === zoneId) : undefined;
  const money = (minor: number) => formatMoney(minor, meta, currency);
  const courierName = (id: string) => couriers.find((c) => c.id === id)?.name ?? '';
  const setZone = (id: string, patch: Partial<ShippingZone>) => onChange({ zones: zones.map((z) => (z.id === id ? { ...z, ...patch } : z)) });
  const move = (index: number, dir: -1 | 1) => {
    const next = [...zones];
    const j = index + dir;
    if (j < 0 || j >= next.length) return;
    [next[index], next[j]] = [next[j]!, next[index]!];
    onChange({ zones: next });
  };
  const addZone = () => {
    const first = zones.length === 0 && storeCountry;
    const id = shortId();
    onChange({
      zones: [
        ...zones,
        {
          id,
          name: first ? (countries.find((c) => c.code === storeCountry)?.name ?? 'Domestic') : `Zone ${zones.length + 1}`,
          countries: first ? [storeCountry] : [],
          methods: [],
        },
      ],
    });
    onOpenZone(id);
  };
  const removeZone = (id: string) => {
    onChange({ zones: zones.filter((z) => z.id !== id) });
    if (zoneId === id) onOpenZone(null);
  };

  const priceText = (m: ShippingMethod) =>
    m.type === 'free_shipping' ? (m.minAmount > 0 ? `Free from ${money(m.minAmount)}` : 'Free') : m.cost > 0 ? money(m.cost) : 'Free';

  if (zone) {
    return (
      <ZoneEditor
        zone={zone}
        countries={countries}
        couriers={couriers}
        meta={meta}
        currency={currency}
        priceText={priceText}
        courierName={courierName}
        onChange={(patch) => setZone(zone.id, patch)}
        onBack={() => onOpenZone(null)}
        onRemove={() => removeZone(zone.id)}
        onOpenCouriers={onOpenCouriers}
      />
    );
  }

  const columns: AdminTableColumn<ShippingZone>[] = [
    {
      key: 'name',
      header: 'Zone',
      render: (z) => {
        const index = zones.indexOf(z);
        return (
          <>
            <span className="bk-table__primary">{z.name.trim() || 'Untitled zone'}</span>
            <div className="bk-table__row-actions" onClick={(e) => e.stopPropagation()}>
              <button type="button" className="button-link" onClick={() => onOpenZone(z.id)}>
                Edit
              </button>
              {index > 0 ? (
                <>
                  <span className="bk-table__sep">|</span>
                  <button type="button" className="button-link" onClick={() => move(index, -1)}>
                    Move up
                  </button>
                </>
              ) : null}
              {index < zones.length - 1 ? (
                <>
                  <span className="bk-table__sep">|</span>
                  <button type="button" className="button-link" onClick={() => move(index, 1)}>
                    Move down
                  </button>
                </>
              ) : null}
              <span className="bk-table__sep">|</span>
              <button type="button" className="button-link is-danger" onClick={() => removeZone(z.id)}>
                Delete
              </button>
            </div>
          </>
        );
      },
    },
    { key: 'regions', header: 'Regions', render: (z) => regionsText(z, countries) },
    {
      key: 'methods',
      header: 'Shipping methods',
      render: (z) =>
        z.methods.length ? (
          <ul className="bk-shop-zone-methods">
            {z.methods.map((m) => (
              <li key={m.id} className={m.enabled ? '' : 'is-off'}>
                {m.title.trim() || typeLabel(m.type)} <span className="bk-table__muted">· {priceText(m)}</span>
                {m.courierId && courierName(m.courierId) ? <span className="bk-table__muted"> · {courierName(m.courierId)}</span> : null}
                {m.enabled ? null : <span className="bk-table__badge">Hidden</span>}
              </li>
            ))}
          </ul>
        ) : (
          <span className="bk-shop-zone-warn">No shipping methods yet</span>
        ),
    },
  ];

  return (
    <>
      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Shipping</h2>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <Row label="Shipping" help="When off, checkout skips the delivery address and shipping costs. Useful if you only sell services or downloads.">
                <Check checked={settings.enabled} onChange={(enabled) => onChange({ enabled })} label="Deliver orders and charge shipping" />
              </Row>
            </tbody>
          </table>
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Shipping zones</h2>
          <p className="bk-panel__lead">
            Customers see the shipping methods of the first zone that lists their country. A zone without countries covers everywhere else.
          </p>
        </div>
        <div className="bk-panel__body">
          {!settings.enabled ? <p className="bk-shop-note">Shipping is off, so these zones are not used at checkout.</p> : null}
          <AdminDataTable
            rows={zones}
            columns={columns}
            getRowId={(z) => z.id}
            onRowClick={(z) => onOpenZone(z.id)}
            emptyTitle="No shipping zones yet. Add one so customers can choose how their order is delivered."
            actions={
              <button type="button" className="button button-primary" onClick={addZone}>
                Add zone
              </button>
            }
          />
        </div>
      </div>
    </>
  );
}

function ZoneEditor({
  zone,
  countries,
  couriers,
  meta,
  currency,
  priceText,
  courierName,
  onChange,
  onBack,
  onRemove,
  onOpenCouriers,
}: {
  zone: ShippingZone;
  countries: ShopMeta['countries'];
  couriers: Courier[];
  meta: ShopMeta | null;
  currency: string;
  priceText: (m: ShippingMethod) => string;
  courierName: (id: string) => string;
  onChange: (patch: Partial<ShippingZone>) => void;
  onBack: () => void;
  onRemove: () => void;
  onOpenCouriers: () => void;
}) {
  const [editing, setEditing] = useState<{ method: ShippingMethod; isNew: boolean } | null>(null);
  const methods = zone.methods;
  const setMethods = (next: ShippingMethod[]) => onChange({ methods: next });
  const move = (index: number, dir: -1 | 1) => {
    const next = [...methods];
    const j = index + dir;
    if (j < 0 || j >= next.length) return;
    [next[index], next[j]] = [next[j]!, next[index]!];
    setMethods(next);
  };

  const columns: AdminTableColumn<ShippingMethod>[] = [
    {
      key: 'title',
      header: 'Method',
      render: (m) => {
        const index = methods.indexOf(m);
        return (
          <>
            <span className="bk-table__primary">{m.title.trim() || typeLabel(m.type)}</span>
            <div className="bk-table__row-actions" onClick={(e) => e.stopPropagation()}>
              <button type="button" className="button-link" onClick={() => setEditing({ method: m, isNew: false })}>
                Edit
              </button>
              {index > 0 ? (
                <>
                  <span className="bk-table__sep">|</span>
                  <button type="button" className="button-link" onClick={() => move(index, -1)}>
                    Move up
                  </button>
                </>
              ) : null}
              {index < methods.length - 1 ? (
                <>
                  <span className="bk-table__sep">|</span>
                  <button type="button" className="button-link" onClick={() => move(index, 1)}>
                    Move down
                  </button>
                </>
              ) : null}
              <span className="bk-table__sep">|</span>
              <button type="button" className="button-link is-danger" onClick={() => setMethods(methods.filter((x) => x.id !== m.id))}>
                Delete
              </button>
            </div>
          </>
        );
      },
    },
    { key: 'type', header: 'Type', render: (m) => typeLabel(m.type) },
    { key: 'price', header: 'Price', render: (m) => priceText(m) },
    {
      key: 'courier',
      header: 'Delivered by',
      render: (m) =>
        m.type === 'local_pickup' ? (
          <span className="bk-table__muted">Picked up</span>
        ) : m.courierId && courierName(m.courierId) ? (
          courierName(m.courierId)
        ) : (
          <span className="bk-table__muted">You</span>
        ),
    },
    {
      key: 'shown',
      header: 'At checkout',
      render: (m) => (m.enabled ? <span className="bk-table__badge is-ok">Shown</span> : <span className="bk-table__badge">Hidden</span>),
    },
  ];

  return (
    <>
      <p className="bk-shop-back">
        <button type="button" className="button-link" onClick={onBack}>
          ← All shipping zones
        </button>
      </p>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">{zone.name.trim() || 'Untitled zone'}</h2>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <Row label="Zone name" htmlFor="zone-name" help="Only you see it.">
                <input id="zone-name" className="regular-text" type="text" maxLength={80} value={zone.name} onChange={(e) => onChange({ name: e.target.value })} />
              </Row>
              <Row label="Regions" htmlFor="zone-regions" help="Customers in these countries get this zone’s shipping methods. Leave it empty to cover every country no other zone lists.">
                <CountryMultiSelect id="zone-regions" value={zone.countries} onChange={(c) => onChange({ countries: c })} countries={countries} emptyLabel="Everywhere else" />
              </Row>
            </tbody>
          </table>
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Shipping methods</h2>
          <p className="bk-panel__lead">What customers in this zone can choose at checkout, in this order.</p>
        </div>
        <div className="bk-panel__body">
          <AdminDataTable
            rows={methods}
            columns={columns}
            getRowId={(m) => m.id}
            onRowClick={(m) => setEditing({ method: m, isNew: false })}
            emptyTitle="No shipping methods yet, so customers in this zone can’t check out. Add one."
            actions={
              <button
                type="button"
                className="button button-primary"
                onClick={() =>
                  setEditing({
                    method: { id: shortId(), type: 'flat_rate', title: 'Standard delivery', cost: 0, minAmount: 0, enabled: true, courierId: couriers.length === 1 ? couriers[0]!.id : '' },
                    isNew: true,
                  })
                }
              >
                Add shipping method
              </button>
            }
          />
        </div>
      </div>

      <p className="bk-shop-zone-delete">
        <button type="button" className="button-link is-danger" onClick={onRemove}>
          Delete this zone
        </button>
      </p>

      {editing ? (
        <MethodModal
          initial={editing.method}
          isNew={editing.isNew}
          couriers={couriers}
          meta={meta}
          currency={currency}
          onClose={() => setEditing(null)}
          onOpenCouriers={onOpenCouriers}
          onDone={(m) => {
            setMethods(editing.isNew ? [...methods, m] : methods.map((x) => (x.id === m.id ? m : x)));
            setEditing(null);
          }}
          onDelete={() => {
            setMethods(methods.filter((x) => x.id !== editing.method.id));
            setEditing(null);
          }}
        />
      ) : null}
    </>
  );
}

function MethodModal({
  initial,
  isNew,
  couriers,
  meta,
  currency,
  onClose,
  onDone,
  onDelete,
  onOpenCouriers,
}: {
  initial: ShippingMethod;
  isNew: boolean;
  couriers: Courier[];
  meta: ShopMeta | null;
  currency: string;
  onClose: () => void;
  onDone: (m: ShippingMethod) => void;
  onDelete: () => void;
  onOpenCouriers: () => void;
}) {
  const [m, setM] = useState<ShippingMethod>(initial);
  const set = (patch: Partial<ShippingMethod>) => setM((cur) => ({ ...cur, ...patch }));
  const usable = couriers.filter((c) => c.enabled || c.id === m.courierId);
  const chosen = couriers.find((c) => c.id === m.courierId);
  return (
    <AdminModal
      title={isNew ? 'Add shipping method' : 'Edit shipping method'}
      onClose={onClose}
      footer={
        <>
          {!isNew ? (
            <button type="button" className="button-link is-danger" onClick={onDelete}>
              Delete method
            </button>
          ) : null}
          <span className="bk-modal__actions">
            <button type="button" className="button" onClick={onClose}>
              Cancel
            </button>
            <button type="button" className="button button-primary" onClick={() => onDone({ ...m, title: m.title.trim() || METHOD_TYPES.find((t) => t.id === m.type)!.title })}>
              {isNew ? 'Add method' : 'Done'}
            </button>
          </span>
        </>
      }
    >
      <table className="form-table">
        <tbody>
          <Row label="Type" help={METHOD_TYPES.find((t) => t.id === m.type)?.help}>
            <div className="bk-tabs is-inline" role="tablist" aria-label="Type">
              {METHOD_TYPES.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  role="tab"
                  aria-selected={m.type === t.id}
                  className={`bk-tabs__item${m.type === t.id ? ' is-active' : ''}`}
                  onClick={() => {
                    const keepTitle = m.title.trim() && !METHOD_TYPES.some((x) => x.title === m.title.trim());
                    set({ type: t.id, title: keepTitle ? m.title : t.title, courierId: t.id === 'local_pickup' ? '' : m.courierId });
                  }}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </Row>
          <Row label="Name" htmlFor="method-title" help="What customers see at checkout.">
            <input id="method-title" className="regular-text" type="text" maxLength={80} value={m.title} onChange={(e) => set({ title: e.target.value })} autoFocus={isNew} />
          </Row>
          {m.type === 'free_shipping' ? (
            <Row label="Minimum order" htmlFor="method-min" help="Free shipping appears once the products in the cart reach this amount (after discounts). Leave 0 to always offer it.">
              <MoneyInput id="method-min" value={m.minAmount} meta={meta} currency={currency} onChange={(minor) => set({ minAmount: minor ?? 0 })} />
            </Row>
          ) : (
            <Row label="Price" htmlFor="method-cost" help={m.type === 'local_pickup' ? 'Usually 0. Some shops charge for packing.' : 'Charged once per order.'}>
              <MoneyInput id="method-cost" value={m.cost} meta={meta} currency={currency} onChange={(minor) => set({ cost: minor ?? 0 })} />
            </Row>
          )}
          {m.type !== 'local_pickup' ? (
            <Row
              label="Delivered by"
              htmlFor="method-courier"
              help={
                usable.length === 0 ? (
                  <>
                    Connect a courier to send it these orders and keep customers up to date.{' '}
                    <button type="button" className="button-link" onClick={onOpenCouriers}>
                      Add a courier
                    </button>
                  </>
                ) : chosen?.config.create.enabled && chosen.config.create.auto ? (
                  `Orders with this method go to ${chosen.name} automatically when they are ready to ship.`
                ) : chosen?.config.create.enabled ? (
                  `You can send these orders to ${chosen.name} from the order page.`
                ) : chosen ? (
                  `${chosen.name} follows the parcel once you add its tracking number to the order.`
                ) : (
                  'You ship these orders yourself and add tracking details on the order page.'
                )
              }
            >
              <select id="method-courier" value={m.courierId} disabled={usable.length === 0} onChange={(e) => set({ courierId: e.target.value })}>
                <option value="">You (no courier connection)</option>
                {usable.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                    {c.enabled ? '' : ' (switched off)'}
                  </option>
                ))}
              </select>
            </Row>
          ) : null}
          <Row label="At checkout">
            <Check checked={m.enabled} onChange={(enabled) => set({ enabled })} label="Customers can choose this method" />
          </Row>
        </tbody>
      </table>
    </AdminModal>
  );
}
