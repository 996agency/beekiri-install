/**
 * Shopping extension — admin API types and helpers.
 * Mirrors apps/api/src/services/shop/*.service.ts response shapes.
 * Money is an integer in the currency's minor unit (cents); `formatMoney` renders it.
 */
import { useEffect, useState } from 'react';
import { api, ApiError } from '../../api/client';

/** Readable message for any failure (zod errors arrive as message[]). */
export function shopError(e: unknown): string {
  if (e instanceof ApiError) {
    const body = e.body as { message?: unknown } | undefined;
    if (Array.isArray(body?.message)) return (body!.message as unknown[]).map(String).join(' ');
    return e.message;
  }
  if (e instanceof Error) return e.message;
  return 'Something went wrong. Try again.';
}

/* ── Shared meta (GET /api/shop/meta) ─────────────────────────────────── */

export type MoneyFormat = {
  currency: string;
  position: 'left' | 'right' | 'left_space' | 'right_space';
  thousandSeparator: string;
  decimalSeparator: string;
  decimals: number | null;
};

export type CurrencyInfo = { code: string; symbol: string; name: string; decimals: number };

export type ShopMeta = {
  /** Published pages for the Terms / Privacy pickers. */
  pages: { id: string; title: string; slug: string }[];
  currency: string;
  money: MoneyFormat;
  currencies: CurrencyInfo[];
  countries: { code: string; name: string }[];
  orderStatuses: { id: OrderStatus; label: string }[];
  paymentMethods: { id: PaymentMethod; title: string }[];
  enabledPaymentMethods: PaymentMethod[];
  categoryTaxonomyId: string | null;
  tagTaxonomyId: string | null;
  orderNumberPrefix: string;
  lowStockThreshold: number;
  shopTitle: string;
  taxEnabled: boolean;
  shippingEnabled: boolean;
};

let metaCache: ShopMeta | null = null;
let metaInflight: Promise<ShopMeta> | null = null;

export function loadShopMeta(force = false): Promise<ShopMeta> {
  if (metaCache && !force) return Promise.resolve(metaCache);
  if (!metaInflight || force) {
    metaInflight = api<ShopMeta>('/api/shop/meta')
      .then((m) => {
        metaCache = m;
        return m;
      })
      .finally(() => {
        metaInflight = null;
      });
  }
  return metaInflight;
}

export function invalidateShopMeta() {
  metaCache = null;
}

/** Shared shop metadata; null until loaded. */
export function useShopMeta(): ShopMeta | null {
  const [meta, setMeta] = useState<ShopMeta | null>(metaCache);
  useEffect(() => {
    let cancelled = false;
    loadShopMeta()
      .then((m) => {
        if (!cancelled) setMeta(m);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);
  return meta;
}

/* ── Money ───────────────────────────────────────────────────────────── */

const DEFAULT_FORMAT: MoneyFormat = { currency: 'EUR', position: 'left', thousandSeparator: ',', decimalSeparator: '.', decimals: null };

export function currencyDecimals(code: string, currencies?: CurrencyInfo[]): number {
  const found = currencies?.find((c) => c.code === code);
  if (found) return found.decimals;
  return ['JPY', 'KRW'].includes(code) ? 0 : 2;
}

export function currencySymbol(code: string, currencies?: CurrencyInfo[]): string {
  return currencies?.find((c) => c.code === code)?.symbol ?? code;
}

/** 1999 → "€19.99" with the shop's format (safe on null). */
export function formatMoney(minor: number | null | undefined, meta: ShopMeta | null, currencyOverride?: string): string {
  const fmt = meta?.money ?? DEFAULT_FORMAT;
  const currency = currencyOverride ?? fmt.currency;
  const minorDecimals = currencyDecimals(currency, meta?.currencies);
  const decimals = fmt.decimals ?? minorDecimals;
  const amount = Number.isFinite(minor) ? Math.trunc(minor as number) : 0;
  const abs = Math.abs(amount) / 10 ** minorDecimals;
  const [intPart, frac] = abs.toFixed(decimals).split('.');
  const grouped = (intPart ?? '0').replace(/\B(?=(\d{3})+(?!\d))/g, fmt.thousandSeparator);
  const num = frac !== undefined && decimals > 0 ? `${grouped}${fmt.decimalSeparator}${frac}` : grouped;
  const symbol = currencySymbol(currency, meta?.currencies);
  const body =
    fmt.position === 'right' ? `${num}${symbol}` : fmt.position === 'left_space' ? `${symbol} ${num}` : fmt.position === 'right_space' ? `${num} ${symbol}` : `${symbol}${num}`;
  return amount < 0 ? `-${body}` : body;
}

/** "19.99" (input) → 1999; null for blank/invalid. */
export function parseMoney(input: string, currency: string, currencies?: CurrencyInfo[]): number | null {
  const raw = input.trim().replace(/\s/g, '');
  if (!raw) return null;
  const lastComma = raw.lastIndexOf(',');
  const lastDot = raw.lastIndexOf('.');
  const normalized = lastComma > lastDot ? raw.replace(/\./g, '').replace(',', '.') : raw.replace(/,/g, '');
  if (!/^-?\d*(\.\d*)?$/.test(normalized)) return null;
  const value = Number(normalized);
  if (!Number.isFinite(value)) return null;
  return Math.round(value * 10 ** currencyDecimals(currency, currencies));
}

/** 1999 → "19.99" for an input value. */
export function moneyToInput(minor: number | null | undefined, currency: string, currencies?: CurrencyInfo[]): string {
  if (minor === null || minor === undefined) return '';
  const d = currencyDecimals(currency, currencies);
  return (minor / 10 ** d).toFixed(d);
}

export function formatDate(iso: string | null | undefined, withTime = true): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return withTime
    ? d.toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
    : d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

/* ── Products ────────────────────────────────────────────────────────── */

export type MediaRef = { id: string; url: string; alt: string; width: number | null; height: number | null };
export type TermRef = { id: string; name: string; slug: string; parentId: string | null };
export type ProductType = 'simple' | 'variable';
export type StockStatus = 'instock' | 'outofstock' | 'onbackorder';
export type CatalogVisibility = 'visible' | 'catalog' | 'search' | 'hidden';

export type ProductListRow = {
  id: string;
  title: string;
  slug: string;
  status: 'draft' | 'publish' | 'trash' | 'auto-draft';
  path: string;
  image: MediaRef | null;
  type: ProductType;
  sku: string;
  regularPrice: number | null;
  salePrice: number | null;
  price: { min: number; max: number; onSale: boolean } | null;
  stockStatus: StockStatus;
  stockQty: number | null;
  manageStock: boolean;
  featured: boolean;
  totalSales: number;
  variantCount: number;
  categories: TermRef[];
  updatedAt: string;
  publishedAt: string | null;
};

export type ProductList = {
  items: ProductListRow[];
  total: number;
  page: number;
  perPage: number;
  pages: number;
  counts: { all: number; publish: number; draft: number; trash: number };
};

export type ProductAttribute = { name: string; options: string[]; visible: boolean; variation: boolean };

export type ProductVariant = {
  id?: string;
  sku: string;
  attributes: Record<string, string>;
  regularPrice: number | null;
  salePrice: number | null;
  saleFrom: string | null;
  saleTo: string | null;
  manageStock: boolean;
  stockQty: number | null;
  stockStatus: StockStatus;
  weight: number | null;
  imageId: string | null;
  image?: MediaRef | null;
  enabled: boolean;
  menuOrder: number;
};

export type ProductCommerce = {
  id: string;
  type: ProductType;
  sku: string;
  regularPrice: number | null;
  salePrice: number | null;
  saleFrom: string | null;
  saleTo: string | null;
  manageStock: boolean;
  stockQty: number | null;
  stockStatus: StockStatus;
  lowStockThreshold: number | null;
  soldIndividually: boolean;
  weight: number | null;
  length: number | null;
  width: number | null;
  height: number | null;
  virtual: boolean;
  taxable: boolean;
  galleryIds: string[];
  gallery: MediaRef[];
  attributes: ProductAttribute[];
  purchaseNote: string;
  featured: boolean;
  catalogVisibility: CatalogVisibility;
  totalSales: number;
};

export type Product = {
  id: string;
  title: string;
  slug: string;
  status: 'draft' | 'publish' | 'trash' | 'auto-draft';
  path: string;
  description: string;
  shortDescription: string;
  featuredImageId: string | null;
  image: MediaRef | null;
  seo: Record<string, unknown> | null;
  authorName: string | null;
  updatedByName: string | null;
  revisionCount: number;
  createdAt: string;
  updatedAt: string;
  publishedAt: string | null;
  commerce: ProductCommerce;
  variants: ProductVariant[];
  categoryTaxonomyId: string | null;
  tagTaxonomyId: string | null;
  categoryIds: string[];
  tagIds: string[];
  categories: TermRef[];
  tags: TermRef[];
};

/** PATCH /api/shop/products/:id body. */
export type ProductPatch = Partial<{
  title: string;
  slug: string;
  status: 'draft' | 'publish';
  description: string;
  shortDescription: string;
  featuredImageId: string;
  seo: Record<string, unknown> | null;
  commerce: Partial<Omit<ProductCommerce, 'id' | 'gallery' | 'totalSales'>>;
  variants: Omit<ProductVariant, 'image'>[];
  categoryIds: string[];
  tagIds: string[];
}>;

export type ProductLookupRow = { id: string; title: string; slug: string; status: string; sku: string; regularPrice: number | null; type: ProductType };

/* ── Terms (GET /api/fields/taxonomies/:id/terms) ─────────────────────── */

export type TermRow = TermRef & { description: string; menuOrder: number; count: number };
export type TermList = {
  taxonomy: { id: string; slug: string; singular: string; plural: string; hierarchical: boolean };
  terms: TermRow[];
};

/* ── Orders ──────────────────────────────────────────────────────────── */

export type OrderStatus = 'pending' | 'on-hold' | 'processing' | 'completed' | 'cancelled' | 'refunded' | 'failed';
export type PaymentStatus = 'unpaid' | 'paid' | 'partially_refunded' | 'refunded' | 'failed';
export type PaymentMethod = 'cod' | 'bank_transfer' | 'stripe';

export type Address = {
  firstName?: string;
  lastName?: string;
  company?: string;
  line1?: string;
  line2?: string;
  city?: string;
  state?: string;
  postcode?: string;
  country?: string;
};

export type OrderItem = {
  id: string;
  /** Internal ShopProduct id. */
  productId: string | null;
  /** Post id for the product editor link (null when the product was deleted). */
  postId: string | null;
  variantId: string | null;
  name: string;
  sku: string;
  qty: number;
  unitPrice: number;
  subtotal: number;
  total: number;
  taxTotal: number;
  attributes: Record<string, string>;
  imageUrl: string;
  virtual: boolean;
  formatted: { unitPrice: string; total: string };
};

export type OrderNote = {
  id: string;
  note: string;
  isCustomerNote: boolean;
  authorId: string | null;
  authorName: string;
  createdAt: string;
};

export type Order = {
  id: string;
  number: number;
  numberLabel: string;
  status: OrderStatus;
  statusLabel: string;
  currency: string;
  subtotal: number;
  discountTotal: number;
  shippingTotal: number;
  taxTotal: number;
  total: number;
  refundedTotal: number;
  formatted: { subtotal: string; discountTotal: string; shippingTotal: string; taxTotal: string; total: string; refundedTotal: string; net: string };
  couponCode: string | null;
  customerId: string | null;
  customerName: string;
  email: string;
  phone: string;
  billing: Address;
  shipping: Address;
  shipToDifferent: boolean;
  shippingMethod: { id: string; type: string; title: string; cost: number } | null;
  paymentMethod: PaymentMethod | string;
  paymentMethodTitle: string;
  paymentStatus: PaymentStatus;
  transactionId: string;
  paymentRef: Record<string, unknown>;
  customerNote: string;
  /** Custom checkout answers (Shop → Settings → Checkout → Fields). */
  customFields: { key: string; label: string; value: string }[];
  /** Shipping progress set from the order screen. */
  fulfillment: Fulfillment;
  /** Shopper-facing timeline (same data My account shows). */
  tracking: Tracking;
  accessToken: string;
  ipAddress: string;
  placedAt: string;
  paidAt: string | null;
  completedAt: string | null;
  updatedAt: string;
  items: OrderItem[];
  notes: OrderNote[];
};

export type OrderListRow = Omit<Order, 'items' | 'notes'> & { itemCount: number };

export type FulfillmentStatus = 'unfulfilled' | 'packed' | 'shipped' | 'delivered';
export type CourierStage = 'created' | 'in_transit' | 'out_for_delivery' | 'delivered' | 'problem' | 'returned';
export type CourierEvent = { at: string | null; text: string; place: string };
/** A parcel's link to a courier connection (Settings → Shipping → Couriers). */
export type CourierLink = {
  id: string;
  name: string;
  /** sending: waits to be sent automatically · following · done · failed: could not be sent */
  state: 'sending' | 'following' | 'done' | 'failed';
  shipmentId: string;
  labelUrl: string;
  stage: CourierStage | '';
  statusText: string;
  events: CourierEvent[];
  sentAt: string | null;
  checkedAt: string | null;
  nextCheckAt: string | null;
  error: string;
  failures: number;
};
export type Fulfillment = {
  status: FulfillmentStatus;
  carrier: string;
  trackingNumber: string;
  trackingUrl: string;
  packedAt: string | null;
  shippedAt: string | null;
  deliveredAt: string | null;
  courier: CourierLink | null;
};
export type TrackingStep = { id: string; label: string; state: 'done' | 'current' | 'upcoming'; at: string | null; detail: string };
export type Tracking = {
  steps: TrackingStep[];
  headline: string;
  percent: number;
  stopped: null | { label: string; tone: 'muted' | 'danger' };
  fulfillment: Omit<Fulfillment, 'courier'>;
  /** The courier's latest updates, newest first. */
  updates: CourierEvent[];
  virtual: boolean;
};

export type OrderList = {
  items: OrderListRow[];
  total: number;
  page: number;
  perPage: number;
  pages: number;
  counts: Record<string, number>;
  statuses: { id: OrderStatus; label: string }[];
};

export type CourierChoice = { id: string; name: string; sends: boolean; follows: boolean; trackingPage: boolean };

export type OrderDetail = {
  order: Order;
  customer: { id: string; email: string; name: string; ordersCount: number; totalSpent: number } | null;
  canRefundViaProvider: boolean;
  /** Connected couriers (switched on), and the one the order's shipping method uses. */
  couriers: CourierChoice[];
  suggestedCourierId: string;
};

/* ── Customers ───────────────────────────────────────────────────────── */

export type Customer = {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  name: string;
  phone: string;
  billing: Address;
  shipping: Address;
  ordersCount: number;
  totalSpent: number;
  lastOrderAt: string | null;
  /** Registered a My account login (otherwise guest checkouts only). */
  hasAccount: boolean;
  emailVerified: boolean;
  lastLoginAt: string | null;
  createdAt: string;
};

export type CustomerList = { items: Customer[]; total: number; page: number; perPage: number; pages: number };

/* ── Coupons ─────────────────────────────────────────────────────────── */

export type CouponType = 'percent' | 'fixed_cart' | 'fixed_product';

export type Coupon = {
  id: string;
  code: string;
  type: CouponType;
  /** percent: 12.5% = 1250; fixed: minor units */
  amount: number;
  description: string;
  minSpend: number | null;
  maxSpend: number | null;
  usageLimit: number | null;
  usageLimitPerEmail: number | null;
  usageCount: number;
  expiresAt: string | null;
  productIds: string[];
  excludeProductIds: string[];
  categoryIds: string[];
  freeShipping: boolean;
  active: boolean;
  createdAt: string;
  updatedAt: string;
};

export type CouponInput = Omit<Coupon, 'id' | 'usageCount' | 'createdAt' | 'updatedAt'>;

/* ── Reports (GET /api/shop/overview) ─────────────────────────────────── */

export type ReportRange = 'today' | '7d' | '30d' | '90d' | 'year';

export type ShopOverview = {
  range: ReportRange;
  currency: string;
  totals: {
    revenue: number;
    revenueFormatted: string;
    orders: number;
    averageOrder: number;
    averageOrderFormatted: string;
    itemsSold: number;
    newCustomers: number;
  };
  series: { date: string; revenue: number; orders: number }[];
  topProducts: { productId: string | null; postId: string | null; name: string; qty: number; revenue: number; revenueFormatted: string }[];
  statusCounts: { id: OrderStatus; label: string; count: number }[];
  stock: { lowStock: number; outOfStock: number; threshold: number };
  recentOrders: { id: string; number: number; numberLabel: string; status: OrderStatus; statusLabel: string; customerName: string; total: number; totalFormatted: string; placedAt: string }[];
};

/* ── Settings (GET/PUT /api/shop/settings) ────────────────────────────── */

export type ShippingMethod = {
  id: string;
  type: 'flat_rate' | 'free_shipping' | 'local_pickup';
  title: string;
  cost: number;
  minAmount: number;
  enabled: boolean;
  /** Courier connection that delivers it ('' = the shop ships it itself). */
  courierId: string;
};
export type ShippingZone = { id: string; name: string; countries: string[]; methods: ShippingMethod[] };
export type TaxRate = { id: string; country: string; state: string; rate: number; name: string; shipping: boolean };
export type EmailToggle = { enabled: boolean; subject: string };

export type CheckoutFieldType = 'text' | 'email' | 'tel' | 'textarea' | 'select' | 'checkbox';
export type CheckoutFieldSection = 'contact' | 'billing' | 'extra';
export type CheckoutField = {
  /** Built-ins: email, phone, billing.firstName … customerNote; custom ones: custom.<slug> */
  key: string;
  label: string;
  type: CheckoutFieldType;
  section: CheckoutFieldSection;
  enabled: boolean;
  required: boolean;
  placeholder: string;
  options: string[];
  width: 'full' | 'half';
  builtin: boolean;
  /** Always on + required (name, street, city, country, email). */
  locked: boolean;
};

export type ShopPageOptions = {
  shop: { columns: number; showSidebar: boolean; showSearch: boolean; showSort: boolean; showBreadcrumbs: boolean; showResultCount: boolean };
  product: { showBreadcrumbs: boolean; showRelated: boolean; showAdditionalInfo: boolean; showGalleryThumbs: boolean; showMeta: boolean };
  cart: { showCoupon: boolean; showContinueShopping: boolean };
  checkout: { showOrderSummaryImages: boolean };
};

export type ShopPageRow = {
  view: 'shop' | 'product' | 'cart' | 'checkout' | 'order-received' | 'account';
  id: string | null;
  title: string;
  path: string;
  status: string;
  customised: boolean;
  updatedAt: string | null;
};

export type ShopSettings = {
  general: {
    storeName: string;
    storeEmail: string;
    address: { line1: string; line2: string; city: string; state: string; postcode: string; country: string };
    sellTo: 'all' | 'specific';
    sellToCountries: string[];
    currency: string;
    currencyPosition: MoneyFormat['position'];
    thousandSeparator: string;
    decimalSeparator: string;
    decimals: number | null;
  };
  products: {
    shopTitle: string;
    shopDescription: string;
    perPage: number;
    defaultSort: 'menu_order' | 'newest' | 'price' | 'price-desc' | 'popularity' | 'title';
    placeholderImageId: string;
    hideOutOfStock: boolean;
    lowStockThreshold: number;
    showCategories: boolean;
    showSku: boolean;
    relatedCount: number;
  };
  tax: { enabled: boolean; pricesIncludeTax: boolean; rates: TaxRate[]; taxBasedOn: 'shipping' | 'billing' | 'store' };
  shipping: { enabled: boolean; zones: ShippingZone[] };
  payments: {
    cod: { enabled: boolean; title: string; description: string; instructions: string };
    bankTransfer: {
      enabled: boolean;
      title: string;
      description: string;
      instructions: string;
      accounts: { accountName: string; accountNumber: string; bankName: string; sortCode: string; iban: string; bic: string }[];
    };
    stripe: { enabled: boolean; title: string; description: string; mode: 'test' | 'live'; publishableKey: string; secretKey: string; webhookSecret: string };
  };
  checkout: {
    fields: CheckoutField[];
    termsPageId: string;
    termsRequired: boolean;
    privacyPageId: string;
    thankYouMessage: string;
  };
  emails: {
    fromName: string;
    adminEmail: string;
    newOrderAdmin: EmailToggle;
    orderReceived: EmailToggle;
    onHold: EmailToggle;
    processing: EmailToggle;
    completed: EmailToggle;
    cancelled: EmailToggle;
    refunded: EmailToggle;
    customerNote: EmailToggle;
    shipped: EmailToggle;
    delivered: EmailToggle;
    footerText: string;
    accentColor: string;
  };
  accounts: { enabled: boolean; allowRegistration: boolean; requireAccount: boolean; createAtCheckout: boolean };
  pages: ShopPageOptions;
  advanced: { orderNumberPrefix: string; orderNumberStart: number; holdStockMinutes: number; cartExpiryDays: number; removeDataOnUninstall: boolean };
};

export type ShopSettingsResponse = {
  settings: ShopSettings;
  meta: { currencies: CurrencyInfo[]; secretsPersist: boolean; stripeConfigured: boolean };
};

/* ── Status pill helper ──────────────────────────────────────────────── */

export const ORDER_STATUS_TONE: Record<OrderStatus, 'neutral' | 'warn' | 'info' | 'ok' | 'muted' | 'danger'> = {
  pending: 'warn',
  'on-hold': 'warn',
  processing: 'info',
  completed: 'ok',
  cancelled: 'muted',
  refunded: 'muted',
  failed: 'danger',
};

export function buildQuery(params: Record<string, string | number | undefined | null>): string {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && String(v) !== '') qs.set(k, String(v));
  }
  const s = qs.toString();
  return s ? `?${s}` : '';
}

/* ── REST API keys (GET /api/shop/api-keys) ───────────────────────────── */

export type ShopApiPermission = 'catalog' | 'read' | 'read_write';

export type ShopApiKey = {
  id: string;
  name: string;
  permission: ShopApiPermission;
  /** `bk_shop_…a1B2`: the full key is shown once, when it is created. */
  preview: string;
  createdById: string;
  createdBy: string;
  lastUsedAt: string | null;
  createdAt: string;
};

/* ── WooCommerce import (GET /api/shop/imports) ──────────────────────── */

export type ShopImportStatus = 'uploaded' | 'ready' | 'preparing' | 'prepared' | 'publishing' | 'published' | 'discarding' | 'discarded' | 'failed';
export type ShopImportFileKind = 'wxr' | 'csv' | 'photos';
export type ShopImportAction = 'analyze' | 'prepare' | 'publish' | 'discard';

export type ShopImportOptions = {
  products: boolean;
  coupons: boolean;
  /** Orders, with their customers. */
  orders: boolean;
  /** keep = products live in WooCommerce go live on Publish; draft = everything stays a draft. */
  productStatus: 'keep' | 'draft';
  cleanDescriptions: boolean;
  weightUnit: 'kg' | 'g' | 'lbs' | 'oz';
  sizeUnit: 'cm' | 'm' | 'mm' | 'in' | 'yd';
};

export type ShopImportCountKey = 'products' | 'variations' | 'categories' | 'tags' | 'photos' | 'coupons' | 'customers' | 'orders';

export type ShopImportSummary = {
  siteUrl: string | null;
  siteName: string | null;
  sources: ('wxr' | 'csv')[];
  counts: Record<ShopImportCountKey, number>;
  photos: { total: number; inZip: number; fromSite: number; hosts: string[] };
  /** What this shop already has (same SKU, coupon code, e-mail, or imported before). */
  existing: { products: number; coupons: number; customers: number; orders: number };
  orderNumbers: 'keep' | 'renumber';
  currency: { shop: string; orders: string[] };
  /** Orders the export only names (new order storage): they cannot be imported. */
  ordersWithoutDetails: number;
  warnings: string[];
  units: { weight: string | null; size: string | null };
};

export type ShopImportIssue = { kind: string; name: string; message: string };

export type ShopImport = {
  id: string;
  status: ShopImportStatus;
  /** A job (check, prepare, publish, discard) is running right now. */
  running: boolean;
  files: { kind: ShopImportFileKind; name: string; size: number }[];
  summary: ShopImportSummary | null;
  options: ShopImportOptions;
  progress: { action?: ShopImportAction; step?: string; done?: number; total?: number; message?: string };
  report: {
    created: Partial<Record<ShopImportCountKey, number>>;
    reused: Partial<Record<ShopImportCountKey, number>>;
    skipped: Partial<Record<ShopImportCountKey, number>>;
    /** The first 200; `issueCount` has them all. */
    issues: ShopImportIssue[];
    issueCount: number;
  };
  error: string | null;
  /** Opens the shop with this import's products (only while it waits to be published). */
  previewUrl: string | null;
  createdAt: string;
  preparedAt: string | null;
  publishedAt: string | null;
};

/** What happened (or will happen) to one row of the files. */
export type ShopImportRowState = 'new' | 'imported' | 'kept' | 'issue';

export type ShopImportProductRow = {
  id: string;
  name: string;
  sku: string;
  price: string;
  categories: string;
  photos: number;
  status: 'publish' | 'draft' | 'private' | 'pending';
  state: ShopImportRowState;
  message: string | null;
  postId: string | null;
};

export type ShopImportOrderRow = {
  id: string;
  number: string;
  date: string;
  customer: string;
  email: string;
  status: OrderStatus;
  total: string;
  state: ShopImportRowState;
  message: string | null;
  orderId: string | null;
};

export type ShopImportCouponRow = {
  id: string;
  code: string;
  amount: string;
  usage: string;
  expires: string | null;
  state: ShopImportRowState;
  message: string | null;
};

/* ── Couriers (Settings → Shipping → Couriers) ──────────────────────── */

export type CourierPreset = 'custom' | 'dhl';
export type CourierMeaning = 'in_transit' | 'out_for_delivery' | 'delivered' | 'problem' | 'returned' | 'ignore';
export type CourierRule = { match: 'is' | 'contains'; value: string; meaning: CourierMeaning };
export type CourierConfig = {
  baseUrl: string;
  auth: { type: 'none' | 'header' | 'bearer' | 'basic' | 'query'; name: string };
  headers: { name: string; value: string }[];
  trackingPage: string;
  create: {
    enabled: boolean;
    method: 'POST' | 'PUT';
    path: string;
    format: 'json' | 'form';
    body: string;
    trackingPath: string;
    idPath: string;
    labelPath: string;
    auto: boolean;
  };
  track: {
    enabled: boolean;
    method: 'GET' | 'POST';
    path: string;
    body: string;
    statusPath: string;
    textPath: string;
    eventsPath: string;
    eventTextPath: string;
    eventTimePath: string;
    eventPlacePath: string;
    everyMinutes: number;
  };
  push: { enabled: boolean; listPath: string; trackingPath: string; statusPath: string; textPath: string; timePath: string; placePath: string };
  rules: CourierRule[];
  dailyLimit: number;
};
export type Courier = {
  id: string;
  name: string;
  preset: CourierPreset;
  presetLabel: string;
  enabled: boolean;
  config: CourierConfig;
  hasSecret: boolean;
  secretHint: string;
  /** The saved key can't be read any more (the server's encryption secret changed). */
  unreadable: boolean;
  /** Path of the address the courier sends its updates to (add the site's own address in front). */
  pushPath: string;
  status: 'untested' | 'connected' | 'error';
  lastError: string;
  lastContactAt: string | null;
  /** Parcels it follows (or still has to send) right now. */
  following: number;
  /** Statuses the courier sent that no rule explains yet. */
  unmatched: string[];
  usedToday: number;
  createdAt: string;
  updatedAt: string;
};
export type CouriersResponse = {
  couriers: Courier[];
  presets: { id: CourierPreset; label: string; defaults: CourierConfig }[];
  placeholders: { key: string; label: string }[];
  keysPersist: boolean;
};
export type CourierTestResult =
  | { ok: true; httpStatus: number; status: string; text: string; meaning: CourierMeaning | null; events: CourierEvent[]; eventCount: number; answer: string }
  | { ok: false; httpStatus: number; error: string; answer: string };
export type CourierPreview = { method: string; url: string; body: string; orderLabel: string };

export const COURIER_MEANING_LABELS: Record<CourierMeaning, string> = {
  in_transit: 'On its way',
  out_for_delivery: 'Out for delivery',
  delivered: 'Delivered',
  problem: 'Delivery issue',
  returned: 'Returned to sender',
  ignore: 'Nothing changes',
};
