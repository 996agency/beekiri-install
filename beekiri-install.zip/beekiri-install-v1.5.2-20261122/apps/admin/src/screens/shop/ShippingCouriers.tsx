import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import { api } from '../../api/client';
import { AdminDataTable, type AdminTableColumn } from '../../components/AdminDataTable';
import { confirmDialog } from '../../components/ConfirmDialog';
import { ErrorNotice } from '../../components/ErrorNotice';
import { SuccessNotice } from '../../components/SuccessNotice';
import {
  COURIER_MEANING_LABELS,
  shopError,
  type Courier,
  type CourierConfig,
  type CourierMeaning,
  type CourierPreset,
  type CourierPreview,
  type CourierRule,
  type CouriersResponse,
  type CourierTestResult,
} from './api';
import { Check, CopyField, Row } from './settings-parts';

/**
 * Shop → Settings → Shipping → Couriers: connections to the companies that deliver the orders.
 * Each one is saved on its own (not with the shop settings), and its key never comes back.
 */

export function useCouriers() {
  const [data, setData] = useState<CouriersResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const reload = useCallback(async () => {
    try {
      setData(await api<CouriersResponse>('/api/shop/couriers'));
      setError(null);
    } catch (e) {
      setError(shopError(e));
    }
  }, []);
  useEffect(() => {
    void reload();
  }, [reload]);
  return { data, error, reload };
}
type CouriersState = ReturnType<typeof useCouriers>;

const CHECK_EVERY: { value: number; label: string }[] = [
  { value: 30, label: 'Every 30 minutes' },
  { value: 60, label: 'Every hour' },
  { value: 180, label: 'Every 3 hours' },
  { value: 360, label: 'Every 6 hours' },
  { value: 720, label: 'Every 12 hours' },
];
const everyText = (min: number) => CHECK_EVERY.find((c) => c.value === min)?.label.toLowerCase() ?? `every ${min} minutes`;

const AUTH_TYPES: { id: CourierConfig['auth']['type']; label: string; nameLabel: string; namePlaceholder: string; secretLabel: string }[] = [
  { id: 'header', label: 'Key in a header', nameLabel: 'Header name', namePlaceholder: 'e.g. X-Api-Key', secretLabel: 'API key' },
  { id: 'bearer', label: 'Bearer token', nameLabel: '', namePlaceholder: '', secretLabel: 'Token' },
  { id: 'basic', label: 'User name and password', nameLabel: 'User name', namePlaceholder: '', secretLabel: 'Password' },
  { id: 'query', label: 'Key in the address', nameLabel: 'Parameter name', namePlaceholder: 'e.g. api_key', secretLabel: 'API key' },
  { id: 'none', label: 'No key', nameLabel: '', namePlaceholder: '', secretLabel: '' },
];

const MEANINGS = Object.entries(COURIER_MEANING_LABELS) as [CourierMeaning, string][];

function dateTime(iso: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function doesText(c: Courier): string {
  const cfg = c.config;
  const parts: string[] = [];
  if (cfg.create.enabled) parts.push(cfg.create.auto ? 'Sends orders automatically' : 'Sends orders');
  if (cfg.track.enabled) parts.push(`Checks parcels ${everyText(cfg.track.everyMinutes)}`);
  if (cfg.push.enabled) parts.push('Receives updates');
  if (!parts.length) parts.push(cfg.trackingPage ? 'Tracking page only' : 'Nothing yet');
  return parts.join(' · ');
}

function StatusBadge({ c }: { c: Courier }) {
  if (!c.enabled) return <span className="bk-table__badge">Off</span>;
  if (c.status === 'error') return <span className="bk-table__badge is-danger">Needs attention</span>;
  if (c.status === 'connected') return <span className="bk-table__badge is-ok">Connected</span>;
  return <span className="bk-table__badge">Not used yet</span>;
}

export function ShippingCouriers({ couriers, openId, onOpen }: { couriers: CouriersState; openId: string | null; onOpen: (id: string | null) => void }) {
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const data = couriers.data;

  const remove = async (c: Courier) => {
    const ok = await confirmDialog({
      title: 'Delete courier',
      message: `${c.name} stops receiving orders, and its parcels are no longer followed. Orders keep their tracking numbers and history. This can't be undone.`,
      confirmLabel: 'Delete courier',
      danger: true,
    });
    if (!ok) return false;
    setBusy(true);
    setError(null);
    try {
      await api(`/api/shop/couriers/${encodeURIComponent(c.id)}`, { method: 'DELETE' });
      await couriers.reload();
      setNotice(`${c.name} deleted.`);
      return true;
    } catch (e) {
      setError(shopError(e));
      return false;
    } finally {
      setBusy(false);
    }
  };

  const notices = (
    <>
      {error || couriers.error ? <ErrorNotice message={(error || couriers.error)!} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}
    </>
  );

  if (openId && data) {
    const existing = openId === 'new' ? undefined : data.couriers.find((c) => c.id === openId);
    if (openId !== 'new' && !existing) {
      return (
        <>
          {notices}
          <p className="bk-shop-back">
            <button type="button" className="button-link" onClick={() => onOpen(null)}>
              ← All couriers
            </button>
          </p>
          <p className="bk-shop-note is-info">This courier is no longer connected.</p>
        </>
      );
    }
    return (
      <>
        {notices}
        <CourierEditor
          key={openId}
          data={data}
          existing={existing}
          onBack={() => onOpen(null)}
          onSaved={async (c, created, message) => {
            await couriers.reload();
            setNotice(message ?? (created ? `${c.name} connected.` : `${c.name} saved.`));
            if (created) onOpen(c.id);
          }}
          onDelete={async (c) => {
            if (await remove(c)) onOpen(null);
          }}
        />
      </>
    );
  }

  const columns: AdminTableColumn<Courier>[] = [
    {
      key: 'name',
      header: 'Courier',
      render: (c) => (
        <>
          <span className="bk-table__primary">{c.name}</span>
          {c.preset !== 'custom' ? <span className="bk-table__badge">{c.presetLabel}</span> : null}
          <div className="bk-table__row-actions" onClick={(e) => e.stopPropagation()}>
            <button type="button" className="button-link" onClick={() => onOpen(c.id)}>
              Edit
            </button>
            <span className="bk-table__sep">|</span>
            <button type="button" className="button-link is-danger" disabled={busy} onClick={() => void remove(c)}>
              Delete
            </button>
          </div>
        </>
      ),
    },
    { key: 'does', header: 'What it does', render: (c) => doesText(c) },
    {
      key: 'status',
      header: 'Status',
      render: (c) => (
        <>
          <StatusBadge c={c} />
          {c.enabled && c.status === 'error' && c.lastError ? <span className="bk-shop-courier-error">{c.lastError}</span> : null}
        </>
      ),
    },
    { key: 'parcels', header: 'Parcels followed', render: (c) => (c.following ? c.following : <span className="bk-table__muted">None</span>) },
    { key: 'contact', header: 'Last answer', render: (c) => (c.lastContactAt ? dateTime(c.lastContactAt) : <span className="bk-table__muted">Never</span>) },
  ];

  return (
    <>
      {notices}
      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Couriers</h2>
          <p className="bk-panel__lead">
            Connect the companies that deliver your orders. Beekiri can send them your orders, and it updates the order and tells your customer as the parcel moves.
          </p>
        </div>
        <div className="bk-panel__body">
          {data && !data.keysPersist ? (
            <p className="bk-shop-note">
              Courier keys saved here will be lost when the server restarts. Ask whoever manages your server to set CACHE_FLUSH_SECRET in apps/api/.env, then enter the keys again.
            </p>
          ) : null}
          <AdminDataTable
            rows={data?.couriers ?? []}
            columns={columns}
            getRowId={(c) => c.id}
            loading={!data && !couriers.error}
            onRowClick={(c) => onOpen(c.id)}
            emptyTitle="No couriers yet. Add DHL or your local courier to send orders and follow parcels automatically."
            actions={
              <button type="button" className="button button-primary" disabled={!data} onClick={() => onOpen('new')}>
                Add courier
              </button>
            }
          />
        </div>
      </div>
    </>
  );
}

/* ── Editor ──────────────────────────────────────────────────────────── */

type Form = { name: string; preset: CourierPreset; enabled: boolean; config: CourierConfig; secret: string };

function Field({ label, id, children, help, wide }: { label: string; id: string; children: ReactNode; help?: ReactNode; wide?: boolean }) {
  return (
    <div className={`bk-shop-field${wide ? ' is-wide' : ''}`}>
      <label htmlFor={id}>{label}</label>
      {children}
      {help ? <p className="description">{help}</p> : null}
    </div>
  );
}

function PathInput({ id, value, onChange, placeholder }: { id: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return <input id={id} type="text" className="bk-shop-mono" spellCheck={false} autoComplete="off" maxLength={200} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />;
}

function CourierEditor({
  data,
  existing,
  onBack,
  onSaved,
  onDelete,
}: {
  data: CouriersResponse;
  existing?: Courier;
  onBack: () => void;
  onSaved: (c: Courier, created: boolean, message?: string) => Promise<void>;
  onDelete: (c: Courier) => Promise<void>;
}) {
  const defaultsOf = useCallback((preset: CourierPreset) => data.presets.find((p) => p.id === preset)?.defaults ?? data.presets[0]!.defaults, [data.presets]);
  const initial: Form = useMemo(
    () =>
      existing
        ? { name: existing.name, preset: existing.preset, enabled: existing.enabled, config: existing.config, secret: '' }
        : { name: '', preset: 'custom', enabled: true, config: defaultsOf('custom'), secret: '' },
    [existing, defaultsOf],
  );
  const [form, setForm] = useState<Form>(initial);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tracking, setTracking] = useState('');
  const [testing, setTesting] = useState(false);
  const [test, setTest] = useState<CourierTestResult | null>(null);
  const [preview, setPreview] = useState<CourierPreview | null>(null);
  const [previewing, setPreviewing] = useState(false);
  const [copied, setCopied] = useState('');

  const cfg = form.config;
  const custom = form.preset === 'custom';
  const dirty = JSON.stringify(form) !== JSON.stringify(initial);
  const setCfg = (patch: Partial<CourierConfig>) => setForm((f) => ({ ...f, config: { ...f.config, ...patch } }));
  const setCreate = (patch: Partial<CourierConfig['create']>) => setCfg({ create: { ...cfg.create, ...patch } });
  const setTrack = (patch: Partial<CourierConfig['track']>) => setCfg({ track: { ...cfg.track, ...patch } });
  const setPush = (patch: Partial<CourierConfig['push']>) => setCfg({ push: { ...cfg.push, ...patch } });
  const auth = AUTH_TYPES.find((a) => a.id === cfg.auth.type) ?? AUTH_TYPES[0]!;

  const choosePreset = (preset: CourierPreset) => {
    if (preset === form.preset) return;
    const label = data.presets.find((p) => p.id === preset)?.label ?? '';
    setForm((f) => ({ ...f, preset, config: defaultsOf(preset), name: !f.name.trim() || data.presets.some((p) => p.label === f.name) ? (preset === 'custom' ? '' : label) : f.name }));
    setTest(null);
    setPreview(null);
  };

  const back = async () => {
    if (dirty && !(await confirmDialog({ title: 'Leave without saving?', message: 'Your changes to this courier will be lost.', confirmLabel: 'Leave', danger: true }))) return;
    onBack();
  };

  const save = async () => {
    setSaving(true);
    setError(null);
    try {
      const body = { name: form.name, preset: form.preset, enabled: form.enabled, config: form.config, secret: form.secret || undefined };
      const saved = existing
        ? await api<Courier>(`/api/shop/couriers/${encodeURIComponent(existing.id)}`, { method: 'PUT', json: body })
        : await api<Courier>('/api/shop/couriers', { method: 'POST', json: body });
      await onSaved(saved, !existing);
    } catch (e) {
      setError(shopError(e));
    } finally {
      setSaving(false);
    }
  };

  const newAddress = async () => {
    if (!existing) return;
    const ok = await confirmDialog({
      title: 'Make a new address',
      message: 'The current address stops working right away, so give the new one to the courier. Use this if the address was shared with someone else.',
      confirmLabel: 'Make a new address',
    });
    if (!ok) return;
    setError(null);
    try {
      const updated = await api<Courier>(`/api/shop/couriers/${encodeURIComponent(existing.id)}/push-address`, { method: 'POST' });
      await onSaved(updated, false, 'New address made. Give it to the courier.');
    } catch (e) {
      setError(shopError(e));
    }
  };

  const runTest = async () => {
    setTesting(true);
    setError(null);
    setTest(null);
    try {
      setTest(
        await api<CourierTestResult>('/api/shop/couriers/test', {
          method: 'POST',
          json: { id: existing?.id, preset: form.preset, config: form.config, secret: form.secret || undefined, trackingNumber: tracking },
        }),
      );
    } catch (e) {
      setError(shopError(e));
    } finally {
      setTesting(false);
    }
  };

  const runPreview = async () => {
    setPreviewing(true);
    setError(null);
    try {
      setPreview(await api<CourierPreview>('/api/shop/couriers/preview', { method: 'POST', json: { preset: form.preset, config: form.config } }));
    } catch (e) {
      setError(shopError(e));
      setPreview(null);
    } finally {
      setPreviewing(false);
    }
  };

  const copyPlaceholder = async (key: string) => {
    try {
      await navigator.clipboard.writeText(`{{${key}}}`);
      setCopied(key);
      window.setTimeout(() => setCopied(''), 1500);
    } catch {
      /* clipboard unavailable — the placeholder is still visible to select */
    }
  };

  const addRule = (rule: CourierRule) => setCfg({ rules: [...cfg.rules, rule] });
  const setRule = (i: number, patch: Partial<CourierRule>) => setCfg({ rules: cfg.rules.map((r, k) => (k === i ? { ...r, ...patch } : r)) });
  const moveRule = (i: number, dir: -1 | 1) => {
    const next = [...cfg.rules];
    const j = i + dir;
    if (j < 0 || j >= next.length) return;
    [next[i], next[j]] = [next[j]!, next[i]!];
    setCfg({ rules: next });
  };
  const unmatched = (existing?.unmatched ?? []).filter((v) => !cfg.rules.some((r) => r.value.trim().toLowerCase() === v.toLowerCase()));
  /** A new rule for a status the courier sent: the usual English words suggest what it means. */
  const ruleFor = (value: string): CourierRule => {
    const s = value.trim().toLowerCase();
    const known = defaultsOf('custom').rules.find((r) => (r.match === 'is' ? s === r.value.toLowerCase() : s.includes(r.value.toLowerCase())));
    return { match: 'is', value, meaning: known?.meaning ?? 'in_transit' };
  };
  const pushUrl = existing?.pushPath ? `${window.location.origin}${existing.pushPath}` : '';
  const secretPlaceholder = existing?.hasSecret ? `${existing.secretHint} (leave blank to keep it)` : form.preset === 'dhl' ? 'Paste your DHL API key' : 'Paste it here';

  return (
    <>
      <p className="bk-shop-back">
        <button type="button" className="button-link" onClick={() => void back()}>
          ← All couriers
        </button>
      </p>
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">{existing ? existing.name : 'Add a courier'}</h2>
        </div>
        <div className="bk-panel__body">
          {existing?.unreadable ? <p className="bk-shop-note is-error">{existing.lastError}</p> : null}
          {existing && !existing.unreadable && existing.enabled && existing.status === 'error' && existing.lastError ? (
            <p className="bk-shop-note is-error">The last request did not work: {existing.lastError}</p>
          ) : null}
          <table className="form-table">
            <tbody>
              {!existing ? (
                <Row label="Courier" help={custom ? 'Any courier with an API: you fill in its details from its API documentation.' : 'DHL is set up for you: you only need your API key.'}>
                  <div className="bk-tabs is-inline" role="tablist" aria-label="Courier">
                    {(['custom', 'dhl'] as const).map((p) => (
                      <button key={p} type="button" role="tab" aria-selected={form.preset === p} className={`bk-tabs__item${form.preset === p ? ' is-active' : ''}`} onClick={() => choosePreset(p)}>
                        {p === 'custom' ? 'Other courier' : 'DHL'}
                      </button>
                    ))}
                  </div>
                </Row>
              ) : null}
              <Row label="Name" htmlFor="courier-name" help="Customers see it next to the tracking number.">
                <input id="courier-name" className="regular-text" type="text" maxLength={80} placeholder={custom ? 'e.g. Cargo Express' : ''} value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
              </Row>
              <Row label="Status" help="When off, nothing is sent to this courier and its parcels are not checked.">
                <Check checked={form.enabled} onChange={(enabled) => setForm((f) => ({ ...f, enabled }))} label="Use this courier" />
              </Row>
            </tbody>
          </table>
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Connection</h2>
          {custom ? <p className="bk-panel__lead">From the courier’s API documentation, or ask the courier for these details.</p> : null}
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              {custom ? (
                <>
                  <Row label="API address" htmlFor="courier-base" help="Requests below add their path to it.">
                    <input id="courier-base" className="regular-text bk-shop-mono" type="url" spellCheck={false} placeholder="https://api.courier.com/v1" value={cfg.baseUrl} onChange={(e) => setCfg({ baseUrl: e.target.value })} />
                  </Row>
                  <Row label="Sign in with" htmlFor="courier-auth">
                    <select id="courier-auth" value={cfg.auth.type} onChange={(e) => setCfg({ auth: { ...cfg.auth, type: e.target.value as CourierConfig['auth']['type'] } })}>
                      {AUTH_TYPES.map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.label}
                        </option>
                      ))}
                    </select>
                  </Row>
                  {auth.nameLabel ? (
                    <Row label={auth.nameLabel} htmlFor="courier-auth-name">
                      <input id="courier-auth-name" className="regular-text" type="text" spellCheck={false} placeholder={auth.namePlaceholder} value={cfg.auth.name} onChange={(e) => setCfg({ auth: { ...cfg.auth, name: e.target.value } })} />
                    </Row>
                  ) : null}
                </>
              ) : null}
              {cfg.auth.type !== 'none' || !custom ? (
                <Row
                  label={custom ? auth.secretLabel : 'API key'}
                  htmlFor="courier-secret"
                  help={
                    custom ? (
                      'Stored encrypted and never shown again.'
                    ) : (
                      <>
                        Get a free key at developer.dhl.com: create an app with the “Shipment Tracking – Unified” API and copy its key. The free plan allows 250 checks a day. Stored encrypted.
                      </>
                    )
                  }
                >
                  <input
                    id="courier-secret"
                    className="regular-text"
                    type="password"
                    autoComplete="new-password"
                    spellCheck={false}
                    placeholder={secretPlaceholder}
                    value={form.secret}
                    onChange={(e) => setForm((f) => ({ ...f, secret: e.target.value }))}
                  />
                </Row>
              ) : null}
              {custom ? (
                <>
                  <Row label="Extra headers" help="Only if the courier asks for more, such as a client number or a language.">
                    <div className="bk-courier-list">
                      {cfg.headers.map((h, i) => (
                        <div key={i} className="bk-courier-line">
                          <input type="text" className="bk-shop-mono" aria-label="Header name" placeholder="Name" spellCheck={false} value={h.name} onChange={(e) => setCfg({ headers: cfg.headers.map((x, k) => (k === i ? { ...x, name: e.target.value } : x)) })} />
                          <input type="text" aria-label="Header value" placeholder="Value" spellCheck={false} value={h.value} onChange={(e) => setCfg({ headers: cfg.headers.map((x, k) => (k === i ? { ...x, value: e.target.value } : x)) })} />
                          <button type="button" className="button-link is-danger" onClick={() => setCfg({ headers: cfg.headers.filter((_, k) => k !== i) })}>
                            Remove
                          </button>
                        </div>
                      ))}
                      <button type="button" className="button" disabled={cfg.headers.length >= 10} onClick={() => setCfg({ headers: [...cfg.headers, { name: '', value: '' }] })}>
                        Add header
                      </button>
                    </div>
                  </Row>
                  <Row label="Requests a day" htmlFor="courier-limit" help="The most requests the courier allows a day. Leave 0 when there is no limit.">
                    <input
                      id="courier-limit"
                      className="regular-text bk-shop-settings__small"
                      type="number"
                      min={0}
                      max={1000000}
                      value={cfg.dailyLimit}
                      onChange={(e) => setCfg({ dailyLimit: Math.max(0, Math.min(1_000_000, Math.trunc(Number(e.target.value) || 0))) })}
                    />
                  </Row>
                </>
              ) : null}
              <Row label="Tracking page" htmlFor="courier-page" help="Customers get a “Track parcel” button with this link. Put {{tracking}} where the tracking number goes.">
                <input
                  id="courier-page"
                  className="regular-text bk-shop-mono"
                  type="url"
                  spellCheck={false}
                  placeholder="https://courier.com/track?number={{tracking}}"
                  value={cfg.trackingPage}
                  onChange={(e) => setCfg({ trackingPage: e.target.value })}
                />
              </Row>
            </tbody>
          </table>
        </div>
      </div>

      {custom ? (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Send orders</h2>
            <p className="bk-panel__lead">Creates the shipment in the courier’s system, so the courier gets a real order with the address, the items and the cash to collect.</p>
          </div>
          <div className="bk-panel__body">
            <table className="form-table">
              <tbody>
                <Row label="Orders">
                  <Check checked={cfg.create.enabled} onChange={(enabled) => setCreate({ enabled })} label="Send orders to this courier" />
                </Row>
                {cfg.create.enabled ? (
                  <>
                    <Row label="When" help="Card and bank transfer orders go once they are paid; cash on delivery orders go right away. Only orders whose shipping method is delivered by this courier.">
                      <Check checked={cfg.create.auto} onChange={(auto) => setCreate({ auto })} label="Send automatically when an order is ready to ship" />
                    </Row>
                    <Row label="Request" htmlFor="create-path" help="The path after the API address, or a full address.">
                      <div className="bk-courier-line">
                        <select aria-label="Method" value={cfg.create.method} onChange={(e) => setCreate({ method: e.target.value === 'PUT' ? 'PUT' : 'POST' })}>
                          <option value="POST">POST</option>
                          <option value="PUT">PUT</option>
                        </select>
                        <input id="create-path" type="text" className="bk-shop-mono" spellCheck={false} placeholder="/shipments" value={cfg.create.path} onChange={(e) => setCreate({ path: e.target.value })} />
                      </div>
                    </Row>
                    <Row label="Format">
                      <div className="bk-tabs is-inline" role="tablist" aria-label="Format">
                        {(
                          [
                            ['json', 'JSON'],
                            ['form', 'Form fields'],
                          ] as const
                        ).map(([id, label]) => (
                          <button key={id} type="button" role="tab" aria-selected={cfg.create.format === id} className={`bk-tabs__item${cfg.create.format === id ? ' is-active' : ''}`} onClick={() => setCreate({ format: id })}>
                            {label}
                          </button>
                        ))}
                      </div>
                    </Row>
                    <Row label="What to send" htmlFor="create-body">
                      <textarea id="create-body" className="bk-shop-mono bk-courier-code" spellCheck={false} rows={14} value={cfg.create.body} onChange={(e) => setCreate({ body: e.target.value })} />
                      <p className="description">
                        Write it the way the courier’s documentation shows, with placeholders like {'{{customer.name}}'} where the order’s details go. A value that is only a placeholder keeps its type (a number stays a number).
                      </p>
                      <details className="bk-courier-details">
                        <summary>Placeholders you can use</summary>
                        <p className="description">Click one to copy it.{copied ? ` Copied {{${copied}}}.` : ''}</p>
                        <AdminDataTable
                          rows={data.placeholders}
                          columns={[
                            { key: 'key', header: 'Placeholder', render: (p) => <code>{`{{${p.key}}}`}</code> },
                            { key: 'label', header: 'What it is', render: (p) => p.label },
                          ]}
                          getRowId={(p) => p.key}
                          onRowClick={(p) => void copyPlaceholder(p.key)}
                        />
                      </details>
                      <div className="bk-courier-preview">
                        <button type="button" className="button" disabled={previewing} onClick={() => void runPreview()}>
                          {previewing ? 'Preparing…' : 'Show what will be sent'}
                        </button>
                        {preview ? (
                          <>
                            <p className="description">{preview.orderLabel ? `For order ${preview.orderLabel}. Nothing was sent.` : 'For a sample order. Nothing was sent.'}</p>
                            <pre className="bk-courier-pre">{`${preview.method} ${preview.url}\n\n${preview.body}`}</pre>
                          </>
                        ) : null}
                      </div>
                    </Row>
                    <Row label="Read from the answer" help="Where the courier’s answer has each detail. Use dots between names and numbers for list items, e.g. data.parcels.0.number.">
                      <div className="bk-courier-grid">
                        <Field label="Tracking number" id="create-tracking">
                          <PathInput id="create-tracking" value={cfg.create.trackingPath} placeholder="e.g. trackingNumber" onChange={(trackingPath) => setCreate({ trackingPath })} />
                        </Field>
                        <Field label="Courier’s shipment ID" id="create-id">
                          <PathInput id="create-id" value={cfg.create.idPath} placeholder="optional" onChange={(idPath) => setCreate({ idPath })} />
                        </Field>
                        <Field label="Label link" id="create-label">
                          <PathInput id="create-label" value={cfg.create.labelPath} placeholder="optional" onChange={(labelPath) => setCreate({ labelPath })} />
                        </Field>
                      </div>
                    </Row>
                  </>
                ) : null}
              </tbody>
            </table>
          </div>
        </div>
      ) : null}

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Follow parcels</h2>
          <p className="bk-panel__lead">
            {custom
              ? 'Beekiri asks the courier where each parcel is, updates the order and emails the customer when it ships and when it is delivered.'
              : 'Create labels in your DHL account as usual. Add the tracking number to the order and choose DHL: Beekiri follows the parcel, updates the order and emails the customer when it ships and when it is delivered.'}
          </p>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              {custom ? (
                <Row label="Parcels">
                  <Check checked={cfg.track.enabled} onChange={(enabled) => setTrack({ enabled })} label="Ask the courier where parcels are" />
                </Row>
              ) : null}
              {cfg.track.enabled ? (
                <>
                  <Row label="Check" htmlFor="track-every" help="Delivered and returned parcels are no longer checked.">
                    <select id="track-every" value={cfg.track.everyMinutes} onChange={(e) => setTrack({ everyMinutes: Number(e.target.value) })}>
                      {CHECK_EVERY.map((c) => (
                        <option key={c.value} value={c.value}>
                          {c.label}
                        </option>
                      ))}
                    </select>
                  </Row>
                  {custom ? (
                    <>
                      <Row label="Request" htmlFor="track-path" help="Use {{tracking}} for the tracking number, or {{shipmentId}} for the courier’s own ID.">
                        <div className="bk-courier-line">
                          <select aria-label="Method" value={cfg.track.method} onChange={(e) => setTrack({ method: e.target.value === 'POST' ? 'POST' : 'GET' })}>
                            <option value="GET">GET</option>
                            <option value="POST">POST</option>
                          </select>
                          <input id="track-path" type="text" className="bk-shop-mono" spellCheck={false} placeholder="/shipments/{{tracking}}" value={cfg.track.path} onChange={(e) => setTrack({ path: e.target.value })} />
                        </div>
                      </Row>
                      {cfg.track.method === 'POST' ? (
                        <Row label="What to send" htmlFor="track-body">
                          <textarea id="track-body" className="bk-shop-mono bk-courier-code is-short" spellCheck={false} rows={4} placeholder={'{ "trackingNumber": "{{tracking}}" }'} value={cfg.track.body} onChange={(e) => setTrack({ body: e.target.value })} />
                        </Row>
                      ) : null}
                      <Row label="Read from the answer" help="Leave the status empty when the courier answers with the status alone. Separate alternatives with |, e.g. status.text|status.code.">
                        <div className="bk-courier-grid">
                          <Field label="Status" id="track-status">
                            <PathInput id="track-status" value={cfg.track.statusPath} placeholder="e.g. status" onChange={(statusPath) => setTrack({ statusPath })} />
                          </Field>
                          <Field label="Status as text" id="track-text">
                            <PathInput id="track-text" value={cfg.track.textPath} placeholder="optional" onChange={(textPath) => setTrack({ textPath })} />
                          </Field>
                          <Field label="List of updates" id="track-events">
                            <PathInput id="track-events" value={cfg.track.eventsPath} placeholder="optional, e.g. events" onChange={(eventsPath) => setTrack({ eventsPath })} />
                          </Field>
                        </div>
                        {cfg.track.eventsPath ? (
                          <div className="bk-courier-grid">
                            <Field label="In each update: text" id="track-ev-text">
                              <PathInput id="track-ev-text" value={cfg.track.eventTextPath} placeholder="e.g. description" onChange={(eventTextPath) => setTrack({ eventTextPath })} />
                            </Field>
                            <Field label="Time" id="track-ev-time">
                              <PathInput id="track-ev-time" value={cfg.track.eventTimePath} placeholder="e.g. date" onChange={(eventTimePath) => setTrack({ eventTimePath })} />
                            </Field>
                            <Field label="Place" id="track-ev-place">
                              <PathInput id="track-ev-place" value={cfg.track.eventPlacePath} placeholder="optional" onChange={(eventPlacePath) => setTrack({ eventPlacePath })} />
                            </Field>
                          </div>
                        ) : null}
                      </Row>
                    </>
                  ) : null}
                </>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>

      {custom ? (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Updates from the courier</h2>
            <p className="bk-panel__lead">Some couriers tell your shop themselves when a parcel moves. Use this if your courier offers it.</p>
          </div>
          <div className="bk-panel__body">
            <table className="form-table">
              <tbody>
                <Row label="Updates">
                  <Check checked={cfg.push.enabled} onChange={(enabled) => setPush({ enabled })} label="The courier sends status updates to my shop" />
                </Row>
                {cfg.push.enabled ? (
                  <>
                    <Row
                      label="Your address"
                      help={
                        pushUrl
                          ? 'Give this address to the courier (it may call it a webhook or callback address). It contains a secret part, so share it only with the courier.'
                          : 'Save the courier to get its address.'
                      }
                    >
                      {pushUrl ? (
                        <div className="bk-courier-address">
                          <CopyField value={pushUrl} label="Address for the courier’s updates" />
                          <button type="button" className="button-link" onClick={() => void newAddress()}>
                            Make a new address
                          </button>
                        </div>
                      ) : (
                        <span className="bk-table__muted">Appears after saving.</span>
                      )}
                    </Row>
                    <Row label="Read from each update" help="Where the courier’s message has each detail. When one message holds several updates, enter where the list is.">
                      <div className="bk-courier-grid">
                        <Field label="Tracking number" id="push-tracking">
                          <PathInput id="push-tracking" value={cfg.push.trackingPath} placeholder="e.g. trackingNumber" onChange={(trackingPath) => setPush({ trackingPath })} />
                        </Field>
                        <Field label="Status" id="push-status">
                          <PathInput id="push-status" value={cfg.push.statusPath} placeholder="e.g. status" onChange={(statusPath) => setPush({ statusPath })} />
                        </Field>
                        <Field label="Status as text" id="push-text">
                          <PathInput id="push-text" value={cfg.push.textPath} placeholder="optional" onChange={(textPath) => setPush({ textPath })} />
                        </Field>
                        <Field label="Time" id="push-time">
                          <PathInput id="push-time" value={cfg.push.timePath} placeholder="optional" onChange={(timePath) => setPush({ timePath })} />
                        </Field>
                        <Field label="Place" id="push-place">
                          <PathInput id="push-place" value={cfg.push.placePath} placeholder="optional" onChange={(placePath) => setPush({ placePath })} />
                        </Field>
                        <Field label="List of updates" id="push-list">
                          <PathInput id="push-list" value={cfg.push.listPath} placeholder="optional" onChange={(listPath) => setPush({ listPath })} />
                        </Field>
                      </div>
                    </Row>
                  </>
                ) : null}
              </tbody>
            </table>
          </div>
        </div>
      ) : null}

      {custom && (cfg.track.enabled || cfg.push.enabled) ? (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Courier statuses</h2>
            <p className="bk-panel__lead">What each status from the courier means for the order. The first rule that matches is used; capital letters don’t matter.</p>
          </div>
          <div className="bk-panel__body">
            {unmatched.length ? (
              <div className="bk-shop-note is-info">
                The courier sent these statuses and no rule explains them yet. Add a rule for each:
                <div className="bk-courier-unmatched">
                  {unmatched.map((v) => (
                    <button key={v} type="button" className="button" onClick={() => addRule(ruleFor(v))}>
                      + {v}
                    </button>
                  ))}
                </div>
              </div>
            ) : null}
            <div className="bk-courier-list">
              {cfg.rules.map((r, i) => (
                <div key={i} className="bk-courier-rule">
                  <span className="bk-courier-rule__word">When the status</span>
                  <select aria-label="How to compare" value={r.match} onChange={(e) => setRule(i, { match: e.target.value === 'is' ? 'is' : 'contains' })}>
                    <option value="contains">contains</option>
                    <option value="is">is exactly</option>
                  </select>
                  <input type="text" aria-label="Status" value={r.value} maxLength={120} placeholder="e.g. Delivered" onChange={(e) => setRule(i, { value: e.target.value })} />
                  <span className="bk-courier-rule__word">it means</span>
                  <select aria-label="Meaning" value={r.meaning} onChange={(e) => setRule(i, { meaning: e.target.value as CourierMeaning })}>
                    {MEANINGS.map(([id, label]) => (
                      <option key={id} value={id}>
                        {label}
                      </option>
                    ))}
                  </select>
                  <span className="bk-courier-rule__tools">
                    <button type="button" className="bk-shop-frow__arrow" aria-label="Move up" disabled={i === 0} onClick={() => moveRule(i, -1)}>
                      ▲
                    </button>
                    <button type="button" className="bk-shop-frow__arrow" aria-label="Move down" disabled={i === cfg.rules.length - 1} onClick={() => moveRule(i, 1)}>
                      ▼
                    </button>
                    <button type="button" className="button-link is-danger" onClick={() => setCfg({ rules: cfg.rules.filter((_, k) => k !== i) })}>
                      Remove
                    </button>
                  </span>
                </div>
              ))}
              <p>
                <button type="button" className="button" disabled={cfg.rules.length >= 60} onClick={() => addRule({ match: 'contains', value: '', meaning: 'in_transit' })}>
                  Add rule
                </button>
              </p>
            </div>
          </div>
        </div>
      ) : null}

      {cfg.track.enabled ? (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Check a parcel</h2>
            <p className="bk-panel__lead">Asks the courier about a real parcel with the settings above, before you save. Nothing changes on your orders.</p>
          </div>
          <div className="bk-panel__body">
            <form
              className="bk-courier-line"
              onSubmit={(e) => {
                e.preventDefault();
                if (tracking.trim()) void runTest();
              }}
            >
              <input type="text" className="regular-text" aria-label="Tracking number" placeholder="Tracking number" value={tracking} onChange={(e) => setTracking(e.target.value)} />
              <button type="submit" className="button" disabled={testing || !tracking.trim()}>
                {testing ? 'Checking…' : 'Check parcel'}
              </button>
            </form>
            {test ? <TestResult result={test} onAddRule={custom ? (value) => addRule(ruleFor(value)) : undefined} /> : null}
          </div>
        </div>
      ) : null}

      <div className="bk-shop-settings__save">
        <button type="button" className="button button-primary" disabled={saving || (!!existing && !dirty)} onClick={() => void save()}>
          {saving ? 'Saving…' : existing ? 'Save courier' : 'Connect courier'}
        </button>
        <button type="button" className="button" onClick={() => void back()}>
          Cancel
        </button>
        {existing ? (
          <button type="button" className="button-link is-danger bk-courier-delete" onClick={() => void onDelete(existing)}>
            Delete courier
          </button>
        ) : null}
        {dirty && existing ? <span className="bk-muted">You have unsaved changes.</span> : null}
      </div>
    </>
  );
}

function TestResult({ result, onAddRule }: { result: CourierTestResult; onAddRule?: (value: string) => void }) {
  if (!result.ok) {
    return (
      <div className="bk-courier-result">
        <p className="bk-shop-note is-error">{result.error}</p>
        {result.answer ? (
          <details className="bk-courier-details">
            <summary>The courier’s answer</summary>
            <pre className="bk-courier-pre">{result.answer}</pre>
          </details>
        ) : null}
      </div>
    );
  }
  return (
    <div className="bk-courier-result">
      <table className="form-table">
        <tbody>
          <Row label="Status">
            {result.status ? <code>{result.status}</code> : <span className="bk-table__muted">Not found in the answer. Check “Status” under Read from the answer.</span>}
          </Row>
          {result.status ? (
            <Row label="Means">
              {result.meaning ? (
                COURIER_MEANING_LABELS[result.meaning]
              ) : (
                <>
                  <span className="bk-table__badge is-accent">No rule yet</span>{' '}
                  {onAddRule ? (
                    <button type="button" className="button-link" onClick={() => onAddRule(result.status)}>
                      Add a rule for “{result.status}”
                    </button>
                  ) : null}
                </>
              )}
            </Row>
          ) : null}
          {result.text && result.text !== result.status ? <Row label="Text">{result.text}</Row> : null}
          <Row label="Updates">
            {result.eventCount ? (
              <ol className="bk-courier-events">
                {result.events.map((e, i) => (
                  <li key={i}>
                    <span className="bk-table__muted">{dateTime(e.at)}</span> {e.text}
                    {e.place ? <span className="bk-table__muted"> · {e.place}</span> : null}
                  </li>
                ))}
                {result.eventCount > result.events.length ? <li className="bk-table__muted">and {result.eventCount - result.events.length} more</li> : null}
              </ol>
            ) : (
              <span className="bk-table__muted">None found.</span>
            )}
          </Row>
        </tbody>
      </table>
      <details className="bk-courier-details">
        <summary>The courier’s answer</summary>
        <pre className="bk-courier-pre">{result.answer || '(empty)'}</pre>
      </details>
    </div>
  );
}
