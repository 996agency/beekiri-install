import { useEffect, useMemo, useRef, useState } from 'react';
import { api, ApiError } from '../api/client';
import { PageHeader } from '../components/PageHeader';
import { AnalyticsRankCard, formatDay, formatNumber, niceCeiling } from './analytics-ui';
import './analytics-page.css';
import './bee-cookies-panel.css';

type Category = {
  enabled: boolean;
  label: string;
  description: string;
};

export type BeeCookiesSettings = {
  enabled: boolean;
  position: 'bottom' | 'bottom-left' | 'bottom-right';
  bannerTitle: string;
  bannerMessage: string;
  acceptLabel: string;
  rejectLabel: string;
  preferencesLabel: string;
  saveLabel: string;
  privacyPolicyUrl: string;
  trackPageViews: boolean;
  categories: {
    essential: Category;
    functional: Category;
    analytics: Category;
    marketing: Category;
  };
};

type Range = 'today' | '7d' | '30d' | 'all';

type Analytics = {
  range: Range;
  consent: {
    decisions: number;
    uniqueVisitors: number;
    accepted: number;
    rejected: number;
    custom: number;
    consentRate: number;
    categories: { functional: number; analytics: number; marketing: number };
    devices: Record<string, number>;
    countries: { code: string; count: number }[];
    trend: { date: string; accepted: number; rejected: number; custom: number }[];
  };
};

type Props = {
  busy: boolean;
  onBusy: (busy: boolean) => void;
  onNotice: (message: string | null) => void;
  onError: (message: string | null) => void;
};

const RANGES: { value: Range; label: string }[] = [
  { value: 'today', label: 'Today' },
  { value: '7d', label: '7 days' },
  { value: '30d', label: '30 days' },
  { value: 'all', label: 'All time' },
];

const OPTIONAL: Array<keyof BeeCookiesSettings['categories']> = [
  'functional',
  'analytics',
  'marketing',
];

function titleCase(key: string) {
  return key ? key[0].toUpperCase() + key.slice(1) : key;
}

function flagEmoji(code: string) {
  return String.fromCodePoint(...[...code].map((c) => 127397 + c.charCodeAt(0)));
}

function countryLabel(code: string) {
  if (!code || code === 'Unknown' || code === 'XX') return { flag: '', name: 'Not detected' };
  if (!/^[A-Z]{2}$/.test(code)) return { flag: '', name: code };
  try {
    const name = new Intl.DisplayNames(['en'], { type: 'region' }).of(code);
    return { flag: flagEmoji(code), name: name || code };
  } catch {
    return { flag: flagEmoji(code), name: code };
  }
}

/** Accepted / custom / rejected split as one bar + legend. */
function Mix({ parts }: { parts: { key: string; n: number; tone: 'ok' | 'mid' | 'faint' }[] }) {
  const total = parts.reduce((sum, p) => sum + p.n, 0);
  if (!total) return <p className="bk-an__empty">No choices recorded in this period.</p>;
  return (
    <div className="bk-bee-mix">
      <div className="bk-bee-mix__bar" aria-hidden>
        {parts
          .filter((p) => p.n > 0)
          .map((p) => (
            <i key={p.key} className={`is-${p.tone}`} style={{ width: `${(p.n / total) * 100}%` }} />
          ))}
      </div>
      <ul className="bk-bee-mix__legend">
        {parts.map((p) => (
          <li key={p.key}>
            <i className={`is-${p.tone}`} aria-hidden />
            <span>{p.key}</span>
            <strong>{formatNumber(p.n)}</strong>
            <em>{Math.round((p.n / total) * 100)}%</em>
          </li>
        ))}
      </ul>
    </div>
  );
}

type Day = { date: string; accepted: number; rejected: number; custom: number };

/** Stacked daily bars: accepted (bottom) → custom → rejected, with a hover readout. */
function ConsentChart({ trend }: { trend: Day[] }) {
  const [hover, setHover] = useState<number | null>(null);
  const w = 960;
  const h = 220;
  const pad = { t: 12, r: 8, b: 28, l: 36 };
  const innerW = w - pad.l - pad.r;
  const innerH = h - pad.t - pad.b;
  const n = trend.length;
  const max = niceCeiling(Math.max(1, ...trend.map((d) => d.accepted + d.custom + d.rejected)));
  const slot = innerW / Math.max(1, n);
  const bw = Math.max(3, Math.min(28, slot * 0.62));
  const y = (v: number) => pad.t + innerH - (v / max) * innerH;
  const labelEvery = Math.max(1, Math.ceil(n / 8));
  const hd = hover !== null ? trend[hover] : null;
  if (!n) return <p className="bk-an__empty bk-bee-chart__empty">No choices recorded in this period.</p>;
  return (
    <div className="bk-bee-chart">
      <svg
        className="bk-an__svg bk-bee-chart__svg"
        viewBox={`0 0 ${w} ${h}`}
        preserveAspectRatio="none"
        role="img"
        aria-label="Consent decisions per day"
        onMouseLeave={() => setHover(null)}
      >
        {[0, 0.5, 1].map((f) => (
          <g key={f}>
            <line x1={pad.l} x2={w - pad.r} y1={y(max * f)} y2={y(max * f)} stroke="#f0f0f1" vectorEffect="non-scaling-stroke" />
            <text x={pad.l - 8} y={y(max * f) + 4} textAnchor="end" fontSize="11" fill="#8c8f94">
              {Math.round(max * f)}
            </text>
          </g>
        ))}
        {trend.map((d, i) => {
          const cx = pad.l + slot * i + slot / 2;
          const parts: [number, string][] = [
            [d.accepted, '#006199'],
            [d.custom, '#4a90d9'],
            [d.rejected, '#dcdcde'],
          ];
          let acc = 0;
          return (
            <g key={d.date} onMouseEnter={() => setHover(i)} opacity={hover === null || hover === i ? 1 : 0.45}>
              <rect x={cx - slot / 2} y={pad.t} width={slot} height={innerH} fill="transparent" />
              {parts.map(([v, color], k) => {
                if (!v) return null;
                const top = y(acc + v);
                const height = y(acc) - top;
                acc += v;
                return <rect key={k} x={cx - bw / 2} y={top} width={bw} height={Math.max(1, height)} rx={k === 2 || (k === 1 && !d.rejected) || (k === 0 && !d.custom && !d.rejected) ? 2 : 0} fill={color} />;
              })}
              {i % labelEvery === 0 ? (
                <text x={cx} y={h - 8} textAnchor="middle" fontSize="11" fill="#8c8f94">
                  {formatDay(d.date)}
                </text>
              ) : null}
            </g>
          );
        })}
      </svg>
      {hd ? (
        <div
          className="bk-an-trend__tip"
          style={{ left: `${((pad.l + slot * hover! + slot / 2) / w) * 100}%` }}
          data-side={hover! > n / 2 ? 'left' : 'right'}
        >
          <span>{formatDay(hd.date)}</span>
          <strong>{formatNumber(hd.accepted + hd.custom + hd.rejected)}</strong>
          <em>
            {hd.accepted} accepted · {hd.custom} custom · {hd.rejected} rejected
          </em>
        </div>
      ) : null}
    </div>
  );
}

/* ── Live preview: your homepage in a frame, with the real banner on it ───────────────────── */

type Device = 'desktop' | 'phone';
type PreviewView = 'banner' | 'prefs' | 'reopen';

const DEVICES: Record<Device, { label: string; w: number; h: number }> = {
  desktop: { label: 'Desktop', w: 1280, h: 800 },
  phone: { label: 'Phone', w: 390, h: 760 },
};

const VIEWS: { id: PreviewView; label: string }[] = [
  { id: 'banner', label: 'Banner' },
  { id: 'prefs', label: 'Preferences' },
  { id: 'reopen', label: 'After a choice' },
];

const PREVIEW_MESSAGE = 'beekiri:cookies-preview';

function Choice<T extends string>({ value, options, onChange, label }: { value: T; options: { id: T; label: string }[]; onChange: (v: T) => void; label: string }) {
  return (
    <div className="bk-tabs is-inline" role="tablist" aria-label={label}>
      {options.map((o) => (
        <button
          key={o.id}
          type="button"
          role="tab"
          aria-selected={value === o.id}
          className={`bk-tabs__item${value === o.id ? ' is-active' : ''}`}
          onClick={() => onChange(o.id)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

/**
 * The website's own banner, drawn on the homepage in a frame: same theme, fonts and position as
 * visitors get. The unsaved settings travel to the frame as you type; its buttons move the preview
 * on (Preferences opens the preferences, Accept shows what a visitor sees afterwards).
 */
function LivePreview({ settings }: { settings: BeeCookiesSettings }) {
  const [device, setDevice] = useState<Device>('desktop');
  const [view, setView] = useState<PreviewView>('banner');
  const [ready, setReady] = useState(false);
  const [width, setWidth] = useState(0);
  const stageRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) => setWidth(entry.contentRect.width));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const onMessage = (e: MessageEvent) => {
      if (e.origin !== window.location.origin || e.source !== frameRef.current?.contentWindow) return;
      const data = e.data as { type?: string; view?: PreviewView } | null;
      if (data?.type === `${PREVIEW_MESSAGE}-ready`) setReady(true);
      if (data?.type === `${PREVIEW_MESSAGE}-view` && data.view) setView(data.view);
    };
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, []);

  useEffect(() => {
    if (!ready) return;
    frameRef.current?.contentWindow?.postMessage({ type: PREVIEW_MESSAGE, config: settings, view }, window.location.origin);
  }, [ready, settings, view]);

  const dev = DEVICES[device];
  const scale = width ? Math.min(1, width / dev.w, device === 'phone' ? 600 / dev.h : 1) : 0;

  return (
    <div className="bk-bee-live">
      <div className="bk-bee-live__controls">
        <Choice label="Screen size" value={device} options={(Object.keys(DEVICES) as Device[]).map((id) => ({ id, label: DEVICES[id].label }))} onChange={setDevice} />
        <Choice label="What to show" value={view} options={VIEWS} onChange={setView} />
      </div>
      <div className="bk-bee-live__stage" ref={stageRef}>
        {scale ? (
          <div className="bk-bee-live__window" style={{ width: dev.w * scale }}>
            <div className="bk-bee-live__bar" aria-hidden>
              <i />
              <i />
              <i />
              <span>{window.location.host}</span>
            </div>
            <div className="bk-bee-live__viewport" style={{ height: dev.h * scale }}>
              <iframe
                ref={frameRef}
                title="Preview of the cookie banner on your website"
                src="/?beekiri-preview=cookies"
                style={{ width: dev.w, height: dev.h, transform: `scale(${scale})` }}
              />
              {!ready ? <div className="bk-bee-live__loading">Loading your website…</div> : null}
            </div>
          </div>
        ) : null}
      </div>
      <p className="description">
        {settings.enabled
          ? 'Your homepage with the banner exactly as visitors see it. Changes show as you type; save to publish them.'
          : 'The banner is turned off, so visitors don’t see it. This is how it will look once you turn it on.'}
      </p>
    </div>
  );
}

type LinkTarget = { id: string; label: string; path: string };

const POSITIONS: { id: BeeCookiesSettings['position']; label: string }[] = [
  { id: 'bottom-left', label: 'Bottom left' },
  { id: 'bottom', label: 'Bottom bar' },
  { id: 'bottom-right', label: 'Bottom right' },
];

const BUTTONS: { key: 'acceptLabel' | 'rejectLabel' | 'preferencesLabel' | 'saveLabel'; label: string; hint?: string }[] = [
  { key: 'acceptLabel', label: 'Accept button' },
  { key: 'rejectLabel', label: 'Reject button' },
  { key: 'preferencesLabel', label: 'Preferences button', hint: 'Also the title of the preferences window.' },
  { key: 'saveLabel', label: 'Save button', hint: 'In the preferences window.' },
];

export function BeeCookiesPanel({ busy, onBusy, onNotice, onError }: Props) {
  const [settings, setSettings] = useState<BeeCookiesSettings | null>(null);
  const [saved, setSaved] = useState<BeeCookiesSettings | null>(null);
  const [pane, setPane] = useState<'setup' | 'consent'>('setup');
  const [range, setRange] = useState<Range>('30d');
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [pages, setPages] = useState<LinkTarget[]>([]);
  const [customLink, setCustomLink] = useState(false);

  const loadSettings = async () => {
    const s = await api<BeeCookiesSettings>('/api/bee-cookies/settings');
    setSettings(s);
    setSaved(s);
  };

  const loadAnalytics = async (next = range) => {
    const data = await api<Analytics>(`/api/bee-cookies/analytics?range=${next}`);
    setAnalytics(data);
  };

  useEffect(() => {
    loadSettings().catch((e) =>
      onError(e instanceof ApiError ? e.message : 'Couldn’t load the cookie banner settings. Refresh the page to try again.'),
    );
    api<{ pages?: LinkTarget[] }>('/api/site/link-targets')
      .then((r) => setPages(r.pages ?? []))
      .catch(() => setPages([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (pane === 'setup') return;
    loadAnalytics(range).catch((e) =>
      onError(e instanceof ApiError ? e.message : 'Couldn’t load consent statistics. Refresh the page to try again.'),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pane, range]);

  const dirty = useMemo(() => Boolean(settings && saved && JSON.stringify(settings) !== JSON.stringify(saved)), [settings, saved]);

  const save = async () => {
    if (!settings) return;
    onBusy(true);
    onError(null);
    onNotice(null);
    try {
      const next = await api<BeeCookiesSettings>('/api/bee-cookies/settings', {
        method: 'PATCH',
        json: settings,
      });
      setSettings(next);
      setSaved(next);
      onNotice(next.enabled ? 'Cookie banner saved. Visitors see the new version now.' : 'Cookie banner saved. It is turned off.');
    } catch (err) {
      onError(err instanceof ApiError ? err.message : 'Couldn’t save the cookie banner. Try again.');
    } finally {
      onBusy(false);
    }
  };

  const header = (
    <PageHeader
      title="BeeCookies"
      actions={
        pane === 'setup' && settings ? (
          <>
            {dirty ? (
              <button type="button" className="button" disabled={busy} onClick={() => saved && setSettings(saved)}>
                Discard changes
              </button>
            ) : null}
            <button type="button" className="button button-primary" disabled={busy || !dirty} onClick={() => void save()}>
              {busy ? 'Saving…' : 'Save changes'}
            </button>
          </>
        ) : null
      }
    />
  );

  if (!settings || !saved) {
    return (
      <>
        {header}
        <div className="bk-settings-panel__loading" role="status">
          <span className="bk-settings-panel__spinner" aria-hidden />
          <span>Loading…</span>
        </div>
      </>
    );
  }

  const set = (patch: Partial<BeeCookiesSettings>) => setSettings({ ...settings, ...patch });
  const setCategory = (key: keyof BeeCookiesSettings['categories'], patch: Partial<Category>) =>
    setSettings({ ...settings, categories: { ...settings.categories, [key]: { ...settings.categories[key], ...patch } } });
  const linkIsPage = pages.some((p) => p.path === settings.privacyPolicyUrl);
  const linkMode = !settings.privacyPolicyUrl && !customLink ? 'none' : linkIsPage && !customLink ? settings.privacyPolicyUrl : 'custom';
  const c = analytics?.consent;

  return (
    <div className="bk-stack bk-bee">
      {header}
      <div className="bk-tabs" role="tablist" aria-label="BeeCookies sections">
        {(
          [
            ['setup', 'Cookie banner'],
            ['consent', 'Consent statistics'],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={pane === id}
            className={`bk-tabs__item${pane === id ? ' is-active' : ''}`}
            onClick={() => setPane(id)}
          >
            {label}
          </button>
        ))}
      </div>
      {pane === 'consent' ? (
        <div className="bk-bee__bar">
          <Choice label="Date range" value={range} options={RANGES.map((r) => ({ id: r.value, label: r.label }))} onChange={setRange} />
        </div>
      ) : null}

      {pane === 'setup' ? (
        <div className="bk-bee__setup">
          <div className="bk-stack">
            <div className="bk-panel">
              <div className="bk-panel__head">
                <h2 className="bk-panel__title">Banner</h2>
                <span className={`bk-bee__status${saved.enabled ? ' is-on' : ''}`}>
                  <i aria-hidden />
                  {saved.enabled ? 'Live on your website' : 'Turned off'}
                </span>
              </div>
              <div className="bk-panel__body">
                <p className="bk-bee__intro">
                  Asks visitors before optional cookies are used. Essential cookies are always on; analytics and marketing stay off until a
                  visitor accepts them. The choice is remembered for six months.
                </p>
                <table className="form-table">
                  <tbody>
                    <tr>
                      <th scope="row">Show banner</th>
                      <td>
                        <label className="bk-check">
                          <input type="checkbox" checked={settings.enabled} onChange={(e) => set({ enabled: e.target.checked })} />
                          <span className="bk-check__box" aria-hidden />
                          <span className="bk-check__label">Show the cookie banner on your website</span>
                        </label>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">Position</th>
                      <td>
                        <Choice label="Position" value={settings.position} options={POSITIONS} onChange={(position) => set({ position })} />
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div className="bk-panel">
              <div className="bk-panel__head">
                <h2 className="bk-panel__title">Text</h2>
              </div>
              <div className="bk-panel__body">
                <table className="form-table">
                  <tbody>
                    <tr>
                      <th scope="row">
                        <label htmlFor="bee-title">Title</label>
                      </th>
                      <td>
                        <input id="bee-title" className="regular-text" maxLength={120} value={settings.bannerTitle} onChange={(e) => set({ bannerTitle: e.target.value })} />
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">
                        <label htmlFor="bee-message">Message</label>
                      </th>
                      <td>
                        <textarea id="bee-message" className="regular-text" rows={5} maxLength={800} value={settings.bannerMessage} onChange={(e) => set({ bannerMessage: e.target.value })} />
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">
                        <label htmlFor="bee-privacy">Privacy policy</label>
                      </th>
                      <td>
                        <select
                          id="bee-privacy"
                          value={linkMode}
                          onChange={(e) => {
                            const v = e.target.value;
                            if (v === 'custom') {
                              setCustomLink(true);
                              return;
                            }
                            setCustomLink(false);
                            set({ privacyPolicyUrl: v === 'none' ? '' : v });
                          }}
                        >
                          <option value="none">No link</option>
                          {pages.map((p) => (
                            <option key={p.id} value={p.path}>
                              {p.label}
                            </option>
                          ))}
                          <option value="custom">Another address…</option>
                        </select>
                        {linkMode === 'custom' ? (
                          <input
                            className="regular-text bk-bee__below"
                            aria-label="Privacy policy address"
                            placeholder="https://example.com/privacy"
                            maxLength={500}
                            value={settings.privacyPolicyUrl}
                            onChange={(e) => set({ privacyPolicyUrl: e.target.value })}
                          />
                        ) : null}
                        <p className="description">Shown as a “Privacy policy” link under the message.</p>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div className="bk-panel">
              <div className="bk-panel__head">
                <h2 className="bk-panel__title">Buttons</h2>
              </div>
              <div className="bk-panel__body">
                <table className="form-table">
                  <tbody>
                    {BUTTONS.map((b) => (
                      <tr key={b.key}>
                        <th scope="row">
                          <label htmlFor={`bee-${b.key}`}>{b.label}</label>
                        </th>
                        <td>
                          <input id={`bee-${b.key}`} className="regular-text" maxLength={40} value={settings[b.key]} onChange={(e) => set({ [b.key]: e.target.value })} />
                          {b.hint ? <p className="description">{b.hint}</p> : null}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="bk-panel">
              <div className="bk-panel__head">
                <h2 className="bk-panel__title">Cookie categories</h2>
              </div>
              <div className="bk-panel__body">
                <p className="bk-bee__intro">Visitors turn these on or off in the preferences window. Rename them or change their descriptions to match your website.</p>
                <table className="form-table">
                  <tbody>
                    {(['essential', ...OPTIONAL] as const).map((key) => {
                      const cat = settings.categories[key];
                      const essential = key === 'essential';
                      return (
                        <tr key={key}>
                          <th scope="row">{titleCase(key)}</th>
                          <td>
                            <div className="bk-bee-cat">
                              {essential ? (
                                <span className="bk-table__badge">Always on</span>
                              ) : (
                                <label className="bk-check">
                                  <input type="checkbox" checked={cat.enabled} onChange={(e) => setCategory(key, { enabled: e.target.checked })} />
                                  <span className="bk-check__box" aria-hidden />
                                  <span className="bk-check__label">Ask visitors about this category</span>
                                </label>
                              )}
                              <input
                                className="regular-text"
                                aria-label={`${titleCase(key)} name`}
                                maxLength={80}
                                value={cat.label}
                                disabled={!essential && !cat.enabled}
                                onChange={(e) => setCategory(key, { label: e.target.value })}
                              />
                              <textarea
                                className="regular-text"
                                aria-label={`${titleCase(key)} description`}
                                rows={2}
                                maxLength={400}
                                value={cat.description}
                                disabled={!essential && !cat.enabled}
                                onChange={(e) => setCategory(key, { description: e.target.value })}
                              />
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="bk-panel">
              <div className="bk-panel__head">
                <h2 className="bk-panel__title">Analytics</h2>
              </div>
              <div className="bk-panel__body">
                <table className="form-table">
                  <tbody>
                    <tr>
                      <th scope="row">Visit counts</th>
                      <td>
                        <label className="bk-check">
                          <input type="checkbox" checked={settings.trackPageViews} onChange={(e) => set({ trackPageViews: e.target.checked })} />
                          <span className="bk-check__box" aria-hidden />
                          <span className="bk-check__label">Count visits in Analytics once a visitor accepts analytics cookies</span>
                        </label>
                        <p className="description">
                          Recorded by Beekiri on your own website and never shared. Page views, traffic sources and devices appear in Analytics.
                          IP addresses are not stored.
                        </p>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <aside className="bk-bee__aside">
            <div className="bk-panel">
              <div className="bk-panel__head">
                <h2 className="bk-panel__title">Live preview</h2>
              </div>
              <div className="bk-panel__body">
                <LivePreview settings={settings} />
              </div>
            </div>
          </aside>
        </div>
      ) : null}

      {pane === 'consent' ? (
        <div className="bk-stack">
          {!analytics ? (
            <div className="bk-an__kpis" aria-busy>
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="bk-an__kpi is-skeleton">
                  <span className="bk-an__skel" style={{ width: '40%' }} />
                  <span className="bk-an__skel is-big" />
                  <span className="bk-an__skel" style={{ width: '60%' }} />
                </div>
              ))}
            </div>
          ) : null}

          {c ? (
            <>
              <div className="bk-an__kpis">
                {[
                  { label: 'Visitors', value: formatNumber(c.uniqueVisitors), foot: 'Saw the banner and made a choice' },
                  { label: 'Decisions', value: formatNumber(c.decisions), foot: c.uniqueVisitors ? `${(c.decisions / c.uniqueVisitors).toFixed(1)} per visitor` : '—' },
                  { label: 'Accepted all', value: `${c.consentRate}%`, foot: `${formatNumber(c.accepted)} decisions`, tone: 'is-up' },
                  { label: 'Rejected optional', value: formatNumber(c.rejected), foot: c.decisions ? `${Math.round((c.rejected / c.decisions) * 100)}% of decisions` : '—' },
                ].map((k) => (
                  <div key={k.label} className="bk-an__kpi">
                    <span className="bk-an__kpi-label">{k.label}</span>
                    <strong className="bk-an__kpi-value">{k.value}</strong>
                    <div className="bk-an__kpi-foot">
                      <span>{k.foot}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bk-an__row">
                <section className="bk-an-trend">
                  <div className="bk-an-trend__head">
                    <div>
                      <h2>Decisions per day</h2>
                      <p>{RANGES.find((r) => r.value === range)?.label}</p>
                    </div>
                    <ul className="bk-bee-mix__legend is-compact" aria-hidden>
                      <li>
                        <i className="is-ok" />
                        Accepted
                      </li>
                      <li>
                        <i className="is-mid" />
                        Custom
                      </li>
                      <li>
                        <i className="is-faint" />
                        Rejected
                      </li>
                    </ul>
                  </div>
                  <ConsentChart trend={c.trend} />
                </section>

                <aside className="bk-an-live bk-bee-choices">
                  <div className="bk-an-live__head">
                    <span>Choices</span>
                  </div>
                  <strong className="bk-an-live__count">{c.consentRate}%</strong>
                  <span className="bk-an-live__label">of visitors accepted every category</span>
                  <Mix
                    parts={[
                      { key: 'Accepted all', n: c.accepted, tone: 'ok' },
                      { key: 'Custom', n: c.custom, tone: 'mid' },
                      { key: 'Rejected optional', n: c.rejected, tone: 'faint' },
                    ]}
                  />
                </aside>
              </div>

              <div className="bk-an__pair">
                <AnalyticsRankCard
                  ariaLabel="Optional categories"
                  tabs={[
                    {
                      id: 'categories',
                      label: 'Categories allowed',
                      dim: 'Category',
                      metric: 'Visitors',
                      noun: 'categories',
                      rows: [
                        { key: 'functional', label: 'Functional', n: c.categories.functional },
                        { key: 'analytics', label: 'Analytics', n: c.categories.analytics },
                        { key: 'marketing', label: 'Marketing', n: c.categories.marketing },
                      ],
                    },
                  ]}
                />
                <AnalyticsRankCard
                  ariaLabel="Devices"
                  tabs={[
                    {
                      id: 'devices',
                      label: 'Devices',
                      dim: 'Device',
                      metric: 'Decisions',
                      noun: 'devices',
                      rows: Object.entries(c.devices).map(([key, n]) => ({ key, label: titleCase(key), n })),
                    },
                  ]}
                />
                <AnalyticsRankCard
                  ariaLabel="Countries"
                  tabs={[
                    {
                      id: 'countries',
                      label: 'Countries',
                      dim: 'Country',
                      metric: 'Decisions',
                      noun: 'countries',
                      rows: c.countries.map((r) => {
                        const { flag, name } = countryLabel(r.code);
                        return { key: r.code, label: `${flag ? `${flag} ` : ''}${name}`, n: r.count };
                      }),
                    },
                  ]}
                />
              </div>
            </>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
