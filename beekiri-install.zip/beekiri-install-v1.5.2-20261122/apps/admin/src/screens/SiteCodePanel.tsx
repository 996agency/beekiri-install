import { useMemo, useRef, useState } from 'react';

export type SiteCodeFields = {
  customHeadHtml: string;
  customBodyHtml: string;
  customFooterHtml: string;
};

export type BusinessFields = {
  title: string;
  tagline: string;
  businessName: string;
  businessCategory: string;
  businessPhone: string;
  businessAddress: string;
  businessHours: string;
  businessImageUrl: string;
};

type PanelTab = 'head' | 'body' | 'footer' | 'business';

type CodeSlot = 'head' | 'body' | 'footer';

const TABS: { id: PanelTab; label: string }[] = [
  { id: 'head', label: 'Header editor' },
  { id: 'body', label: 'Body editor' },
  { id: 'footer', label: 'Footer editor' },
  { id: 'business', label: 'Google Business' },
];

const CODE_SLOTS: {
  id: CodeSlot;
  hint: string;
  placeholder: string;
}[] = [
  {
    id: 'head',
    hint: 'Added to the <head> of every page on your website. Beekiri already adds the title, description, favicon and basic social sharing tags (Open Graph and X/Twitter). Use this for site verification tags, canonical links, extra meta tags and structured data (JSON-LD).',
    placeholder:
      'Paste meta, link or script tags here, or click “Load SEO starter”.',
  },
  {
    id: 'body',
    hint: 'Added at the very start of the <body> on every page. Keep it short, for example the Google Tag Manager noscript tag. Larger scripts belong in the footer editor.',
    placeholder:
      '<!-- Google Tag Manager (noscript) -->\n<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-XXXX"\nheight="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>',
  },
  {
    id: 'footer',
    hint: 'Added at the end of every page, right before </body>. Give scripts defer or async so they don’t slow down the page.',
    placeholder: '<script src="https://example.com/widget.js" defer></script>',
  },
];

function fieldFor(slot: CodeSlot): keyof SiteCodeFields {
  if (slot === 'head') return 'customHeadHtml';
  if (slot === 'body') return 'customBodyHtml';
  return 'customFooterHtml';
}

/** Keep only what belongs inside <head> — drop doctype / html / head wrappers. */
export function extractHeadInner(html: string): string {
  const withHead = html.match(/<head\b[^>]*>([\s\S]*?)<\/head>/i);
  if (withHead) return withHead[1].replace(/^\s*\n/, '').replace(/\n\s*$/, '').trimEnd();
  return html
    .replace(/<!DOCTYPE[^>]*>/gi, '')
    .replace(/<\/?(?:html|head|body)\b[^>]*>/gi, '')
    .trim();
}

function escapeJson(s: string): string {
  return JSON.stringify(s);
}

function buildSeoStarter(ctx: BusinessFields, siteUrl: string): string {
  const name = (ctx.businessName || ctx.title || 'Example').trim() || 'Example';
  const title = (ctx.title || name).trim() || 'Example';
  const description =
    ctx.tagline.trim() ||
    `Professional website for ${name}. Fast, modern, and SEO-friendly.`;
  const url = (siteUrl || 'https://example.com').replace(/\/$/, '');
  const image = ctx.businessImageUrl.trim() || `${url}/images/og-cover.jpg`;
  const logo = ctx.businessImageUrl.trim() || `${url}/images/logo.png`;
  const phone = ctx.businessPhone.trim();
  const address = ctx.businessAddress.trim();

  const org: Record<string, unknown> = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    '@id': `${url}/#organization`,
    name,
    url: `${url}/`,
    logo,
    description,
  };
  if (phone) org.telephone = phone;
  if (address) {
    org.address = {
      '@type': 'PostalAddress',
      streetAddress: address,
    };
  }

  return `<!-- Beekiri already sets charset, viewport, <title>, default description, favicon,
     and base Open Graph / Twitter from Settings. Edit below for the best extras. -->

<!-- 1. Search Engine Indexing -->
<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">

<!-- 2. Canonical URL -->
<link rel="canonical" href="${url}/">

<!-- 3. Open Graph (Facebook, LinkedIn) — enrich / override image & details -->
<meta property="og:type" content="website">
<meta property="og:title" content=${escapeJson(`${title}`)}>
<meta property="og:description" content=${escapeJson(description)}>
<meta property="og:url" content="${url}/">
<meta property="og:site_name" content=${escapeJson(name)}>
<meta property="og:image" content=${escapeJson(image)}>
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content=${escapeJson(`${name} — website`)}>
<meta property="og:locale" content="en_US">

<!-- 4. Twitter / X Cards -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content=${escapeJson(title)}>
<meta name="twitter:description" content=${escapeJson(description)}>
<meta name="twitter:image" content=${escapeJson(image)}>

<!-- 5. Theme Color -->
<meta name="theme-color" content="#ffffff">

<!-- 6. Site verification (replace content values) -->
<meta name="google-site-verification" content="YOUR_GOOGLE_CODE">
<meta name="msvalidate.01" content="YOUR_BING_CODE">

<!-- 7. Preconnect (uncomment only origins you actually use) -->
<!--
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
-->

<!-- 8. Structured Data (Organization) -->
<script type="application/ld+json">
${JSON.stringify(org, null, 4)}
</script>
`;
}

function appendSnippet(current: string, snippet: string): string {
  const base = current.trimEnd();
  if (!base) return snippet;
  return `${base}\n\n${snippet}`;
}

function GoogleBusinessTab({
  business,
  onBusinessChange,
}: {
  business: BusinessFields;
  onBusinessChange: (patch: Partial<BusinessFields>) => void;
}) {
  const hostname =
    typeof window !== 'undefined' ? window.location.hostname : 'yoursite.com';

  return (
    <>
      <p className="bk-muted" style={{ marginTop: 0 }}>
        Add your local business details. They help Google understand your business, but they
        don’t create or manage your Google Business Profile listing.
      </p>
      <div className="bk-notice-soft" role="note">
        <p>
          To appear in Google Maps and local results, claim and verify your business on Google
          Business Profile, then keep the name, address and phone number here the same.{' '}
          <a
            href="https://www.google.com/business/"
            target="_blank"
            rel="noopener noreferrer"
          >
            Open Google Business Profile
          </a>
        </p>
      </div>

      <div className="bk-seo-layout">
        <div className="bk-seo-fields">
          <div className="bk-field">
            <label htmlFor="business_name">Business name</label>
            <input
              id="business_name"
              className="regular-text"
              type="text"
              value={business.businessName}
              placeholder={business.title || 'Your business'}
              onChange={(e) => onBusinessChange({ businessName: e.target.value })}
            />
          </div>
          <div className="bk-field">
            <label htmlFor="business_category">Category</label>
            <input
              id="business_category"
              className="regular-text"
              type="text"
              value={business.businessCategory}
              placeholder="Restaurant, salon, store…"
              onChange={(e) => onBusinessChange({ businessCategory: e.target.value })}
            />
          </div>
          <div className="bk-field">
            <label htmlFor="business_phone">Phone</label>
            <input
              id="business_phone"
              className="regular-text"
              type="text"
              value={business.businessPhone}
              placeholder="+1 555 0100"
              onChange={(e) => onBusinessChange({ businessPhone: e.target.value })}
            />
          </div>
          <div className="bk-field">
            <label htmlFor="business_address">Address</label>
            <textarea
              id="business_address"
              className="regular-text"
              rows={3}
              value={business.businessAddress}
              placeholder="123 Main Street, City"
              onChange={(e) => onBusinessChange({ businessAddress: e.target.value })}
            />
          </div>
          <div className="bk-field">
            <label htmlFor="business_hours">Hours</label>
            <input
              id="business_hours"
              className="regular-text"
              type="text"
              value={business.businessHours}
              placeholder="Mon–Fri 9:00–18:00"
              onChange={(e) => onBusinessChange({ businessHours: e.target.value })}
            />
          </div>
          <div className="bk-field">
            <label htmlFor="business_image">Business photo URL</label>
            <input
              id="business_image"
              className="regular-text"
              type="url"
              value={business.businessImageUrl}
              placeholder="https://…"
              onChange={(e) => onBusinessChange({ businessImageUrl: e.target.value })}
            />
            <p className="description">
              A cover photo for the listing preview. Paste the image’s web address.
            </p>
          </div>
        </div>

        <div className="bk-seo-preview-wrap">
          <p className="bk-seo-preview__label">Google Business preview</p>
          <div className="bk-gbp-preview">
            <div
              className={`bk-gbp-preview__cover${
                business.businessImageUrl.trim() ? ' has-image' : ''
              }`}
            >
              {business.businessImageUrl.trim() ? (
                <img src={business.businessImageUrl.trim()} alt="" />
              ) : (
                <span className="bk-gbp-preview__cover-placeholder">+</span>
              )}
            </div>
            <div className="bk-gbp-preview__body">
              <p className="bk-gbp-preview__name">
                {business.businessName.trim() || business.title.trim() || 'Your business'}
              </p>
              <p className="bk-gbp-preview__category">
                {business.businessCategory.trim() || 'Local business'}
              </p>
              <ul className="bk-gbp-preview__meta">
                <li>{business.businessAddress.trim() || 'Add your address'}</li>
                <li>{business.businessPhone.trim() || 'Add your phone number'}</li>
                <li>{business.businessHours.trim() || 'Add opening hours'}</li>
                <li className="bk-gbp-preview__website">{hostname}</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

type Props = {
  value: SiteCodeFields;
  onChange: (next: SiteCodeFields) => void;
  business: BusinessFields;
  onBusinessChange: (patch: Partial<BusinessFields>) => void;
};

export function SiteCodePanel({ value, onChange, business, onBusinessChange }: Props) {
  const [tab, setTab] = useState<PanelTab>('head');
  const gutterRef = useRef<HTMLDivElement>(null);
  const codeSlot = tab === 'business' ? null : CODE_SLOTS.find((s) => s.id === tab) ?? null;
  const field = codeSlot ? fieldFor(codeSlot.id) : null;
  const code = field ? value[field] : '';

  const siteUrl = useMemo(() => {
    if (typeof window === 'undefined') return '';
    return window.location.origin;
  }, []);

  const lineCount = Math.max(1, (code || ' ').split('\n').length);
  const hasBusiness =
    Boolean(business.businessName.trim()) ||
    Boolean(business.businessPhone.trim()) ||
    Boolean(business.businessAddress.trim());

  const setCode = (next: string) => {
    if (!codeSlot || !field) return;
    const cleaned = codeSlot.id === 'head' ? extractHeadInner(next) : next;
    onChange({ ...value, [field]: cleaned });
  };

  const insert = (snippet: string) => {
    setCode(appendSnippet(code, snippet));
  };

  return (
    <div className="bk-panel bk-site-code">
      <div className="bk-panel__head">
        <h2 className="bk-panel__title">SEO</h2>
      </div>
      <div className="bk-panel__body">
        <p className="bk-muted" style={{ marginTop: 0 }}>
          Code for search engines and tracking that runs on every page, plus your Google Business
          details. Header code is added to <code>&lt;head&gt;</code> before the page is sent, so
          search engines see it straight away.
        </p>

        <div className="bk-tabs" role="tablist" aria-label="SEO editors">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              role="tab"
              aria-selected={tab === t.id}
              className={`bk-tabs__item${tab === t.id ? ' is-active' : ''}`}
              onClick={() => setTab(t.id)}
            >
              {t.label}
              {t.id === 'business'
                ? hasBusiness
                  ? <span className="bk-site-code__dot" aria-label="Has details" />
                  : null
                : value[fieldFor(t.id)].trim()
                  ? <span className="bk-site-code__dot" aria-label="Has code" />
                  : null}
            </button>
          ))}
        </div>

        {tab === 'business' ? (
          <GoogleBusinessTab business={business} onBusinessChange={onBusinessChange} />
        ) : codeSlot ? (
          <>
            <div className="bk-notice-soft" role="note">
              <p>{codeSlot.hint}</p>
            </div>

            {tab === 'head' ? (
              <div className="bk-site-code__snippets" role="group" aria-label="SEO helpers">
                <button
                  type="button"
                  className="button button-primary"
                  onClick={() => setCode(buildSeoStarter(business, siteUrl))}
                >
                  Load SEO starter
                </button>
                <button
                  type="button"
                  className="button"
                  onClick={() =>
                    insert(
                      '<meta name="google-site-verification" content="YOUR_GOOGLE_CODE">\n',
                    )
                  }
                >
                  Google verification
                </button>
                <button
                  type="button"
                  className="button"
                  onClick={() =>
                    insert('<meta name="msvalidate.01" content="YOUR_BING_CODE">\n')
                  }
                >
                  Bing verification
                </button>
                <button
                  type="button"
                  className="button"
                  onClick={() => {
                    if (
                      code.trim() &&
                      !window.confirm('Clear all header code? The change applies when you click Save changes.')
                    ) {
                      return;
                    }
                    setCode('');
                  }}
                >
                  Clear
                </button>
              </div>
            ) : null}

            <div className={`bk-site-code__editor bk-site-code__editor--framed bk-site-code__frame--${tab}`}>
              <div className="bk-site-code__gutter" aria-hidden ref={gutterRef}>
                {Array.from({ length: lineCount }, (_, i) => (
                  <span key={i}>{i + 1}</span>
                ))}
              </div>
              <textarea
                id={`bk-site-code-${tab}`}
                className="bk-site-code__textarea"
                spellCheck={false}
                wrap="off"
                rows={18}
                value={code}
                placeholder={codeSlot.placeholder}
                onChange={(e) => setCode(e.target.value)}
                onPaste={(e) => {
                  if (tab !== 'head') return;
                  const text = e.clipboardData.getData('text');
                  if (!/<\/?head\b/i.test(text) && !/<!DOCTYPE/i.test(text)) return;
                  e.preventDefault();
                  setCode(extractHeadInner(text));
                }}
                onScroll={(e) => {
                  if (gutterRef.current) {
                    gutterRef.current.scrollTop = e.currentTarget.scrollTop;
                  }
                }}
                aria-label={`${TABS.find((t) => t.id === tab)?.label ?? 'Editor'}`}
              />
            </div>

            <p className="description">
              {tab === 'head'
                ? 'Paste only the tags that belong in <head> (meta, link, script, style, noscript), not a full HTML page. Up to 50,000 characters.'
                : 'Only paste code from sources you trust: scripts here run on every page of your website. Up to 50,000 characters per editor.'}
            </p>
          </>
        ) : null}
      </div>
    </div>
  );
}
