import { useAdminHref } from '../lib/AdminEntryContext';

const SECTIONS = [
  { id: 'overview', label: 'Overview' },
  { id: 'php-api', label: 'PHP field API' },
  { id: 'php-examples', label: 'PHP examples' },
  { id: 'react', label: 'React layouts' },
  { id: 'backend-fields', label: 'Backend Fields' },
  { id: 'folders', label: 'Layout folders' },
  { id: 'runtime', label: 'PHP vs React' },
  { id: 'helpers', label: 'Escaping helpers' },
] as const;

function Code({ children }: { children: string }) {
  return (
    <pre className="bk-instructions__code">
      <code>{children}</code>
    </pre>
  );
}

function Inline({ children }: { children: string }) {
  return <code className="bk-instructions__inline">{children}</code>;
}

export function InstructionsPanel() {
  const href = useAdminHref();
  return (
    <div className="bk-instructions">
      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Instructions</h2>
          <p className="bk-panel__lead">
            How to build theme layouts with Backend Fields, PHP (<Inline>get_bee_field</Inline>) and
            React.
          </p>
        </div>

        <div className="bk-panel__body">
          <div className="bk-instructions__body">
          <nav className="bk-instructions__toc" aria-label="Instructions sections">
            {SECTIONS.map((s) => (
              <a key={s.id} href={`#instr-${s.id}`} className="bk-instructions__toc-link">
                {s.label}
              </a>
            ))}
          </nav>

          <div className="bk-instructions__content">
            <section id="instr-overview" className="bk-instructions__section">
              <h3>Overview</h3>
              <p>
                Beekiri layouts live in the active theme. Each field group in{' '}
                <strong>Backend Fields</strong> has a matching layout folder. You add layouts to
                pages and posts in the page editor, and the website shows the PHP or React version,
                depending on the template type shown in <strong>Settings → Page editor</strong>.
              </p>
              <ol className="bk-instructions__steps">
                <li>
                  Create or edit a field group under <Inline>{href('fields')}</Inline>.
                </li>
                <li>
                  Save it. Beekiri creates the layout files in{' '}
                  <Inline>themes/…/layouts/&#123;slug&#125;/</Inline>.
                </li>
                <li>
                  Customize <Inline>&#123;slug&#125;.php</Inline> (recommended) and/or{' '}
                  <Inline>&#123;slug&#125;.tsx</Inline>.
                </li>
                <li>Add the layout to a page or post in the page editor.</li>
                <li>Publish, then check the page on your website.</li>
              </ol>
            </section>

            <section id="instr-php-api" className="bk-instructions__section">
              <h3>PHP field API</h3>
              <p>Use these helpers in layout templates.</p>
              <div className="bk-instructions__table-wrap">
                <table className="bk-instructions__table">
                  <thead>
                    <tr>
                      <th scope="col">Function</th>
                      <th scope="col">What it does</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <Inline>get_bee_field()</Inline>
                      </td>
                      <td>Return a field value (layout root or inside a row loop).</td>
                    </tr>
                    <tr>
                      <td>
                        <Inline>the_bee_field()</Inline>
                      </td>
                      <td>Print a field value, escaped for safe output.</td>
                    </tr>
                    <tr>
                      <td>
                        <Inline>get_bee_fields()</Inline>
                      </td>
                      <td>All root fields for this layout as an array.</td>
                    </tr>
                    <tr>
                      <td>
                        <Inline>have_bee_rows()</Inline>
                      </td>
                      <td>Start / continue a repeater, group, or flexible loop.</td>
                    </tr>
                    <tr>
                      <td>
                        <Inline>the_bee_row()</Inline>
                      </td>
                      <td>Advance to the next row inside a loop.</td>
                    </tr>
                    <tr>
                      <td>
                        <Inline>get_bee_row()</Inline>
                      </td>
                      <td>Current row array (without advancing).</td>
                    </tr>
                    <tr>
                      <td>
                        <Inline>get_bee_row_index()</Inline>
                      </td>
                      <td>1-based index of the current row.</td>
                    </tr>
                    <tr>
                      <td>
                        <Inline>get_bee_row_layout()</Inline>
                      </td>
                      <td>Flexible layout name for the current row.</td>
                    </tr>
                    <tr>
                      <td>
                        <Inline>reset_bee_rows()</Inline>
                      </td>
                      <td>Leave the current loop and return to the outer one.</td>
                    </tr>
                    <tr>
                      <td>
                        <Inline>bee_esc_html()</Inline>
                      </td>
                      <td>Sanitize rich HTML (strips scripts).</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </section>

            <section id="instr-php-examples" className="bk-instructions__section">
              <h3>PHP examples</h3>

              <p>
                Class names: one short class per field, <Inline>bk-&#123;field-name&#125;</Inline>{' '}
                (kebab-case). For example, the field <Inline>title</Inline> gets{' '}
                <Inline>bk-title</Inline>. Layouts created from Backend Fields always follow this pattern.
              </p>

              <h4>Text / title</h4>
              <Code>{`<?php $title = get_bee_field('title'); ?>
<?php if ($title) : ?>
  <h2 class="bk-title"><?php echo esc_html($title); ?></h2>
<?php endif; ?>`}</Code>

              <h4>Image (array return)</h4>
              <Code>{`<?php $image = get_bee_field('image'); ?>
<?php if ($image) : ?>
  <figure class="bk-image">
    <img
      src="<?php echo esc_url($image['url']); ?>"
      alt="<?php echo esc_attr($image['alt'] ?? ''); ?>"
      <?php if (!empty($image['width'])) : ?>
        width="<?php echo esc_attr($image['width']); ?>"
        height="<?php echo esc_attr($image['height']); ?>"
      <?php endif; ?>
      loading="lazy"
      decoding="async"
    />
  </figure>
<?php endif; ?>`}</Code>

              <h4>Repeater</h4>
              <Code>{`<?php if (have_bee_rows('items')) : ?>
  <ul class="bk-items">
    <?php while (have_bee_rows('items')) : the_bee_row(); ?>
      <li class="bk-item">
        <?php $label = get_bee_field('label'); ?>
        <?php if ($label) : ?>
          <span class="bk-label"><?php echo esc_html($label); ?></span>
        <?php endif; ?>
      </li>
    <?php endwhile; ?>
  </ul>
<?php endif; ?>`}</Code>

              <h4>Group</h4>
              <Code>{`<?php if (have_bee_rows('card')) : while (have_bee_rows('card')) : the_bee_row(); ?>
  <div class="bk-card">
    <?php the_bee_field('heading'); ?>
  </div>
<?php endwhile; endif; ?>`}</Code>

              <h4>Flexible content</h4>
              <Code>{`<?php if (have_bee_rows('sections')) : ?>
  <div class="bk-sections">
    <?php while (have_bee_rows('sections')) : the_bee_row(); ?>
      <?php if (get_bee_row_layout() === 'text') : ?>
        <div class="bk-text">
          <?php echo bee_esc_html(get_bee_field('body')); ?>
        </div>
      <?php elseif (get_bee_row_layout() === 'quote') : ?>
        <blockquote class="bk-quote"><?php echo esc_html(get_bee_field('quote')); ?></blockquote>
      <?php endif; ?>
    <?php endwhile; ?>
  </div>
<?php endif; ?>`}</Code>

              <h4>Echo helper</h4>
              <Code>{`<?php the_bee_field('title'); // prints the value ?>`}</Code>
            </section>

            <section id="instr-react" className="bk-instructions__section">
              <h3>React layouts</h3>
              <p>
                When <strong>Settings → Page editor</strong> shows React as the template type, the
                website renders <Inline>&#123;slug&#125;.tsx</Inline>. Props receive the same
                formatted values as <Inline>get_bee_field()</Inline> (via{' '}
                <Inline>POST /api/layouts/&#123;slug&#125;/fields</Inline>).
              </p>
              <Code>{`export default function Hero(props: {
  title?: string;
  image?: { url: string; alt: string; width: number; height: number } | null;
}) {
  return (
    <section className="hero section" data-layout="hero">
      {props.title ? <h2 className="bk-title">{props.title}</h2> : null}
      {props.image ? (
        <figure className="bk-image">
          <img src={props.image.url} alt={props.image.alt} />
        </figure>
      ) : null}
    </section>
  );
}`}</Code>
              <p>
                A layout can have both a <Inline>.php</Inline> and a <Inline>.tsx</Inline> file. The
                website uses the one that matches the site&apos;s template type.
              </p>
            </section>

            <section id="instr-backend-fields" className="bk-instructions__section">
              <h3>Backend Fields</h3>
              <p>
                Open <Inline>{href('fields')}</Inline> to manage field groups. Each active group can
                have a matching layout in the theme.
              </p>
              <ul>
                <li>
                  <strong>Title / key</strong> — the key becomes the layout slug, used for its folder
                  and file names (for example <Inline>group_hero</Inline> → <Inline>hero</Inline>).
                </li>
                <li>
                  <strong>Location</strong> — choose where the group applies: pages, posts or other
                  content types.
                </li>
                <li>
                  <strong>Fields</strong> — text, image, repeater, group, flexible content and
                  more. The return format sets what PHP and React receive (array, URL, ID, …).
                </li>
                <li>
                  <strong>Save</strong> — creates or updates the layout files in the theme.
                </li>
              </ul>
              <p>Related admin screens:</p>
              <ul>
                <li>
                  <Inline>{href('fields/post-types')}</Inline> — custom post types
                </li>
                <li>
                  <Inline>{href('fields/taxonomies')}</Inline> — taxonomies
                </li>
                <li>
                  <Inline>{href('fields/options-pages')}</Inline> — options pages
                </li>
              </ul>
            </section>

            <section id="instr-folders" className="bk-instructions__section">
              <h3>Layout folders</h3>
              <Code>{`themes/beekiri-child/layouts/{slug}/   — your overrides
themes/beekiri/layouts/{slug}/         — official parent

  {slug}.php          — PHP/HTML partial (recommended)
  {slug}.tsx          — React layout (optional)
  styles.scss         — source styles (gulp → styles.css)
  styles.css          — compiled CSS
  script.js           — client JS (no gulp — served live)
  {slug}.meta.json    — field definitions for the editor`}</Code>
              <p>
                <strong>Gulp</strong> only compiles <Inline>styles.scss</Inline>.{' '}
                <Inline>script.js</Inline> needs no build step: it is served as-is from{' '}
                <Inline>/api/layouts/&#123;slug&#125;/js</Inline> on pages that use the layout, so
                save it and hard-refresh the page to see your change.
              </p>
              <p>
                Beekiri keeps the layout files it creates in step with their field group. Before you
                customize one, read the note at the top of the file: it explains how to keep your changes.
              </p>
            </section>

            <section id="instr-runtime" className="bk-instructions__section">
              <h3>PHP vs React</h3>
              <p>
                <strong>Settings → Page editor</strong> shows which template type this site uses:
              </p>
              <ul>
                <li>
                  <strong>PHP</strong> (recommended) — the website runs{' '}
                  <Inline>&#123;slug&#125;.php</Inline>.
                </li>
                <li>
                  <strong>React</strong> — the website and the page editor preview render{' '}
                  <Inline>&#123;slug&#125;.tsx</Inline>.
                </li>
              </ul>
              <p>
                Pages use paths like <Inline>/about</Inline>. Single posts use{' '}
                <Inline>/blog/&#123;slug&#125;</Inline>. The blog index is{' '}
                <Inline>/blog</Inline>.
              </p>
            </section>

            <section id="instr-helpers" className="bk-instructions__section">
              <h3>Escaping helpers</h3>
              <p>
                Layout PHP also includes the common escaping helpers. Always escape values when you
                print them into HTML:
              </p>
              <div className="bk-instructions__table-wrap">
                <table className="bk-instructions__table">
                  <thead>
                    <tr>
                      <th scope="col">Helper</th>
                      <th scope="col">Use for</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <Inline>esc_html()</Inline>
                      </td>
                      <td>Plain text in HTML body</td>
                    </tr>
                    <tr>
                      <td>
                        <Inline>esc_attr()</Inline>
                      </td>
                      <td>HTML attributes</td>
                    </tr>
                    <tr>
                      <td>
                        <Inline>esc_url()</Inline>
                      </td>
                      <td>href / src URLs</td>
                    </tr>
                    <tr>
                      <td>
                        <Inline>bee_esc_html()</Inline>
                      </td>
                      <td>Rich text from the editor, with scripts removed</td>
                    </tr>
                    <tr>
                      <td>
                        <Inline>wp_get_attachment_image()</Inline>
                      </td>
                      <td>Image markup from a media ID</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <p className="bk-muted">
                Tip: start from the PHP file Beekiri creates for the layout, then customize it. Keep
                field names in sync with Backend Fields so <Inline>get_bee_field(&apos;name&apos;)</Inline>{' '}
                and <Inline>bk-name</Inline> stay aligned.
              </p>
            </section>
          </div>
          </div>
        </div>
      </div>
    </div>
  );
}
