import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { api, ApiError } from '../api/client';
import { ErrorNotice } from '../components/ErrorNotice';
import { SuccessNotice } from '../components/SuccessNotice';
import './email-settings-panel.css';

type Security = 'tls' | 'starttls' | 'none';

/** What the server tells the admin: never the password, only whether one is saved. */
type MailSettingsView = {
  enabled: boolean;
  host: string;
  port: number;
  security: Security;
  username: string;
  hasPassword: boolean;
  fromEmail: string;
  fromName: string;
  replyTo: string;
  /** Which mail server this site's emails leave through right now. */
  active: 'site' | 'server' | 'none';
  serverFrom: string;
  secretsPersist: boolean;
  testTo: string;
};

type Draft = Pick<MailSettingsView, 'enabled' | 'host' | 'port' | 'security' | 'username' | 'fromEmail' | 'fromName' | 'replyTo'>;

const draftOf = (v: MailSettingsView): Draft => ({
  enabled: v.enabled,
  host: v.host,
  port: v.port,
  security: v.security,
  username: v.username,
  fromEmail: v.fromEmail,
  fromName: v.fromName,
  replyTo: v.replyTo,
});

/** Quick fill for common mail providers (the account details stay the client's own). */
const PROVIDERS: { id: string; label: string; host: string; port: number; security: Security; hint: string }[] = [
  { id: 'gmail', label: 'Gmail / Google Workspace', host: 'smtp.gmail.com', port: 587, security: 'starttls', hint: 'Username: the full Gmail address. Password: an app password created in that Google account, not the normal password.' },
  { id: 'microsoft', label: 'Microsoft 365 / Outlook', host: 'smtp.office365.com', port: 587, security: 'starttls', hint: 'Username: the full email address. SMTP sign-in must be turned on for that mailbox in Microsoft 365.' },
  { id: 'hostinger', label: 'Hostinger', host: 'smtp.hostinger.com', port: 465, security: 'tls', hint: 'Username: the full email address. Password: the password of that mailbox.' },
  { id: 'brevo', label: 'Brevo', host: 'smtp-relay.brevo.com', port: 587, security: 'starttls', hint: 'Username and password: the SMTP login and key from Brevo → SMTP & API.' },
  { id: 'mailgun', label: 'Mailgun', host: 'smtp.mailgun.org', port: 587, security: 'starttls', hint: 'Username and password: the SMTP login details of your domain in Mailgun.' },
  { id: 'sendgrid', label: 'SendGrid', host: 'smtp.sendgrid.net', port: 587, security: 'starttls', hint: 'Username: the word apikey. Password: a SendGrid API key.' },
];

const message = (e: unknown, fallback: string) => (e instanceof ApiError ? e.message : fallback);

/**
 * Settings → Email: this site's own mail server. Forms, bookings, the shop and password emails
 * leave through it. The password is typed in, stored encrypted on the server and never shown again.
 */
export function EmailSettingsPanel() {
  const [saved, setSaved] = useState<MailSettingsView | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  /** Typed now: sent with the next save or test. Empty = keep the saved one. */
  const [password, setPassword] = useState('');
  const [removePassword, setRemovePassword] = useState(false);
  const [provider, setProvider] = useState('');
  const [busy, setBusy] = useState<'save' | 'test' | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    api<MailSettingsView>('/api/site/mail')
      .then((v) => {
        if (!live) return;
        setSaved(v);
        setDraft(draftOf(v));
      })
      .catch((e) => {
        if (live) setError(message(e, 'Couldn’t load the email settings. Refresh the page to try again.'));
      });
    return () => {
      live = false;
    };
  }, []);

  const dirty = useMemo(
    () => Boolean(saved && draft && (JSON.stringify(draft) !== JSON.stringify(draftOf(saved)) || password || removePassword)),
    [saved, draft, password, removePassword],
  );

  if (!draft || !saved) {
    return error ? (
      <div className="beekiri-notice is-error">
        <p>{error}</p>
      </div>
    ) : (
      <p className="bk-muted">Loading…</p>
    );
  }

  const set = (patch: Partial<Draft>) => setDraft({ ...draft, ...patch });
  /** The password travels only when it was typed (or is being removed). */
  const body = () => ({ ...draft, ...(password ? { password } : removePassword ? { password: '' } : {}) });

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setBusy('save');
    setError(null);
    setNotice(null);
    try {
      const v = await api<MailSettingsView>('/api/site/mail', { method: 'PUT', json: body() });
      setSaved(v);
      setDraft(draftOf(v));
      setPassword('');
      setRemovePassword(false);
      setNotice(v.active === 'site' ? `Email settings saved. This site now sends email through ${v.host}.` : 'Email settings saved.');
    } catch (err) {
      setError(message(err, 'Couldn’t save the email settings. Check the details and try again.'));
    } finally {
      setBusy(null);
    }
  };

  const test = async () => {
    setBusy('test');
    setError(null);
    setNotice(null);
    try {
      const res = await api<{ sentTo: string }>('/api/site/mail/test', { method: 'POST', json: body() });
      setNotice(`Test email sent to ${res.sentTo}. Check that inbox and the spam folder.${dirty ? ' These settings aren’t saved yet.' : ''}`);
    } catch (err) {
      setError(message(err, 'Couldn’t send the test email. Check the mail server details and try again.'));
    } finally {
      setBusy(null);
    }
  };

  const pickProvider = (id: string) => {
    setProvider(id);
    const p = PROVIDERS.find((x) => x.id === id);
    if (p) set({ host: p.host, port: p.port, security: p.security });
  };
  const hint = PROVIDERS.find((p) => p.id === provider)?.hint;
  const canTest = Boolean(draft.host.trim() && draft.fromEmail.trim());

  return (
    <form className="bk-stack bk-mail" onSubmit={(e) => void save(e)}>
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}

      <div className={`bk-mail__status is-${saved.active}`} role="status">
        <span className="bk-mail__dot" aria-hidden />
        {saved.active === 'site' ? (
          <span>
            Emails from this site are sent through <strong>{saved.host}</strong> as <strong>{saved.fromEmail}</strong>.
          </span>
        ) : saved.active === 'server' ? (
          <span>
            This site doesn’t have its own mail server yet, so its emails use the server’s default sender
            {saved.serverFrom ? (
              <>
                {' '}
                (<strong>{saved.serverFrom}</strong>)
              </>
            ) : null}
            .
          </span>
        ) : (
          <span>
            <strong>Email isn’t set up.</strong> Forms, bookings, the shop and password resets can’t send email until you add a mail server here.
          </span>
        )}
      </div>

      {!saved.secretsPersist ? (
        <div className="beekiri-notice is-warning">
          <p>The saved mail server password will be lost the next time the server restarts. Ask whoever manages your server to set CACHE_FLUSH_SECRET in apps/api/.env (for example with openssl rand -hex 32), then enter the password here again.</p>
        </div>
      ) : null}

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Mail server (SMTP)</h2>
          <p className="bk-panel__lead">The mail server this site sends its emails through. These settings belong to this site only and aren’t shared with your other sites.</p>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <tr>
                <th scope="row">Use this server</th>
                <td>
                  <label className="bk-mail__check">
                    <input type="checkbox" checked={draft.enabled} onChange={(e) => set({ enabled: e.target.checked })} />
                    <span>Send this site’s emails through the server below</span>
                  </label>
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="mail-provider">Provider</label>
                </th>
                <td>
                  <select id="mail-provider" value={provider} onChange={(e) => pickProvider(e.target.value)}>
                    <option value="">Other / fill in myself</option>
                    {PROVIDERS.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.label}
                      </option>
                    ))}
                  </select>
                  <p className="description">{hint ?? 'Picking one fills in the host, port and encryption. The account stays yours.'}</p>
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="mail-host">Host</label>
                </th>
                <td>
                  <input
                    id="mail-host"
                    className="regular-text"
                    value={draft.host}
                    placeholder="smtp.example.com"
                    autoComplete="off"
                    spellCheck={false}
                    onChange={(e) => {
                      set({ host: e.target.value });
                      setProvider('');
                    }}
                  />
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="mail-security">Encryption</label>
                </th>
                <td>
                  <div className="bk-mail__inline">
                    <select
                      id="mail-security"
                      value={draft.security}
                      onChange={(e) => {
                        const security = e.target.value as Security;
                        // The usual port for each; a custom port is kept.
                        const usual = [25, 465, 587].includes(draft.port);
                        set({ security, ...(usual ? { port: security === 'tls' ? 465 : security === 'starttls' ? 587 : 25 } : {}) });
                      }}
                    >
                      <option value="starttls">STARTTLS (port 587)</option>
                      <option value="tls">SSL/TLS (port 465)</option>
                      <option value="none">None</option>
                    </select>
                    <label htmlFor="mail-port">Port</label>
                    <input
                      id="mail-port"
                      className="small-text"
                      type="number"
                      min={1}
                      max={65535}
                      value={draft.port}
                      onChange={(e) => set({ port: Number(e.target.value) || 0 })}
                    />
                  </div>
                  {draft.security === 'none' ? (
                    <p className="description">Without encryption, a password can only be used if the mail server runs on this same server.</p>
                  ) : null}
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="mail-user">Username</label>
                </th>
                <td>
                  <input
                    id="mail-user"
                    className="regular-text"
                    value={draft.username}
                    autoComplete="off"
                    spellCheck={false}
                    onChange={(e) => set({ username: e.target.value })}
                  />
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="mail-pass">Password</label>
                </th>
                <td>
                  <input
                    id="mail-pass"
                    className="regular-text"
                    type="password"
                    value={password}
                    autoComplete="new-password"
                    placeholder={saved.hasPassword && !removePassword ? 'Saved. Type a new one to replace it' : ''}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setRemovePassword(false);
                    }}
                  />
                  <p className="description">
                    Stored encrypted on this server and never shown again.
                    {saved.hasPassword && !password ? (
                      <>
                        {' '}
                        <button type="button" className="button-link" onClick={() => setRemovePassword((v) => !v)}>
                          {removePassword ? 'Keep the saved password' : 'Remove the saved password'}
                        </button>
                      </>
                    ) : null}
                    {removePassword ? ' It will be removed when you save.' : ''}
                  </p>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="bk-panel">
        <div className="bk-panel__head">
          <h2 className="bk-panel__title">Sender</h2>
        </div>
        <div className="bk-panel__body">
          <table className="form-table">
            <tbody>
              <tr>
                <th scope="row">
                  <label htmlFor="mail-from">From address</label>
                </th>
                <td>
                  <input
                    id="mail-from"
                    className="regular-text"
                    type="email"
                    value={draft.fromEmail}
                    placeholder="hello@yourdomain.com"
                    onChange={(e) => set({ fromEmail: e.target.value })}
                  />
                  <p className="description">Use an address your mail server is allowed to send from, or emails may land in spam.</p>
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="mail-from-name">From name</label>
                </th>
                <td>
                  <input id="mail-from-name" className="regular-text" value={draft.fromName} maxLength={120} onChange={(e) => set({ fromName: e.target.value })} />
                  <p className="description">Shown as the sender, for example your business name.</p>
                </td>
              </tr>
              <tr>
                <th scope="row">
                  <label htmlFor="mail-reply">Reply-to address</label>
                </th>
                <td>
                  <input id="mail-reply" className="regular-text" type="email" value={draft.replyTo} onChange={(e) => set({ replyTo: e.target.value })} />
                  <p className="description">Optional. Where replies go when an email doesn’t set its own.</p>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <p className="submit bk-mail__actions">
        <button type="submit" className="button button-primary" disabled={busy !== null || !dirty}>
          {busy === 'save' ? 'Saving…' : 'Save changes'}
        </button>
        <button type="button" className="button" disabled={busy !== null || !canTest} onClick={() => void test()}>
          {busy === 'test' ? 'Sending…' : 'Send a test email'}
        </button>
        <span className="bk-muted">The test email goes to {saved.testTo} and uses the settings above, even if they aren’t saved yet.</span>
      </p>
    </form>
  );
}
