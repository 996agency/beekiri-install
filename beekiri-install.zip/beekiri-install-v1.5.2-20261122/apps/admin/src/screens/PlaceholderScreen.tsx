export function PlaceholderScreen({
  title,
  phase,
  note,
}: {
  title: string;
  phase: string;
  note?: string;
}) {
  return (
    <div className="wrap">
      <h1>{title}</h1>
      <div className="beekiri-notice is-info">
        <p>
          {phase ? (
            <>
              This page is coming in <strong>{phase}</strong>. Until then, you can use the rest of
              the admin as usual.
            </>
          ) : (
            'This page isn’t available yet.'
          )}
        </p>
        {note && <p>{note}</p>}
      </div>
    </div>
  );
}
