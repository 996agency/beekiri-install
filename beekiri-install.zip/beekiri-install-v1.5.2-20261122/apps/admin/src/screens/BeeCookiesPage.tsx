import { useState } from 'react';
import { SuccessNotice } from '../components/SuccessNotice';
import { BeeCookiesPanel } from './BeeCookiesPanel';
import { ErrorNotice } from '../components/ErrorNotice';

export function BeeCookiesPage() {
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  return (
    <div className="bk-stack">
      {notice ? <SuccessNotice message={notice} onDismiss={() => setNotice(null)} /> : null}
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      <BeeCookiesPanel
        busy={busy}
        onBusy={setBusy}
        onNotice={setNotice}
        onError={setError}
      />
    </div>
  );
}
