import { Fragment, useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowsClockwise, CalendarCheck, CheckCircle, MagnifyingGlass, Plus, ClipboardText, ShoppingCart, X, type Icon } from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { ErrorNotice } from '../components/ErrorNotice';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import { useCoreUpdate } from '../core/CoreUpdateContext';
import { useAdminHref } from '../lib/AdminEntryContext';
import { confirmDialog } from '../components/ConfirmDialog';
import { notifyExtensionsChanged } from '../lib/admin-events';
import './extensions.css';

type Extension = {
  slug: string;
  name: string;
  tagline: string;
  description: string[];
  features: string[];
  version: string;
  requires: string;
  author: string;
  category: string;
  icon: string;
  color: string;
  kind: 'built-in' | 'package';
  status: 'active' | 'inactive' | 'available' | 'coming-soon';
  settingsPath?: string;
  changelog: { version: string; notes: string[] }[];
  /** Install new versions by itself (installed extensions only). */
  autoUpdate: boolean;
};

/** A newer version Beekiri published for an installed extension. */
type UpdateOffer = { version: string; requires: string; notes: string[]; publishedAt: string | null; compatible: boolean };

type UpdateJob = {
  state: 'running' | 'restarting' | 'done' | 'error' | 'rolled-back';
  step?: string;
  progress?: number;
  message?: string;
  slug: string;
  name?: string;
  version: string;
  fromVersion?: string;
  auto?: boolean;
  startedAt?: string;
  finishedAt?: string;
};

type UpdatesView = {
  checkedAt: string | null;
  offers: Record<string, UpdateOffer>;
  job: UpdateJob | null;
  /** Why this server cannot install extension updates itself (null when it can). */
  blockedReason: string | null;
};

const ICONS: Record<string, Icon> = {
  cart: ShoppingCart,
  form: ClipboardText,
  calendar: CalendarCheck,
};

/** What each extension keeps in the database (for the uninstall prompts). */
const DATA_WORDS: Record<string, string> = {
  shopping: 'every product, order, customer and coupon',
  'bee-forms': 'every form, entry and uploaded file',
  'bee-bookings': 'every appointment, service and staff member',
};
const dataWords = (slug: string) => DATA_WORDS[slug] ?? 'all of its data';
const HIDE_WORDS: Record<string, string> = {
  shopping: 'The shop pages and the Shop menu are hidden',
  'bee-forms': 'Forms stop showing on the website and the Forms menu is hidden',
  'bee-bookings': 'The booking widget stops showing on the website and the Bookings menu is hidden',
};
const hideWords = (slug: string) => HIDE_WORDS[slug] ?? 'Its screens are hidden';

const isInstalled = (e: Extension) => e.status === 'active' || e.status === 'inactive';

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong. Try again.';
}

/** -1, 0 or 1 for dotted version strings (1.10.0 > 1.9.2). */
function compareVersions(a: string, b: string) {
  const pa = a.split('.').map((n) => parseInt(n, 10) || 0);
  const pb = b.split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

export function ExtensionIcon({ ext, size = 'md' }: { ext: Extension; size?: 'sm' | 'md' | 'lg' }) {
  const IconCmp = ICONS[ext.icon] ?? null;
  return (
    <span className={`bk-ext-icon is-${size}`} style={{ ['--ext-color' as string]: ext.color }} aria-hidden>
      {IconCmp ? <IconCmp weight="duotone" /> : <img src="/admin/icon-192.png" alt="" draggable={false} />}
    </span>
  );
}

function useExtensions() {
  const [list, setList] = useState<Extension[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    api<{ extensions: Extension[] }>('/api/extensions')
      .then((res) => setList(res.extensions))
      .catch((e) => setError(formatError(e)));
  }, []);
  return { list, error, setError, setList };
}

const isBusy = (job: UpdateJob | null | undefined) => job?.state === 'running' || job?.state === 'restarting';
/** How long a finished update keeps its message in the table. */
const RECENT_MS = 30 * 60_000;
const isRecent = (job: UpdateJob | null | undefined) => Boolean(job?.finishedAt && Date.now() - Date.parse(job.finishedAt) < RECENT_MS);
const UPDATED_KEY = 'bk-ext-updated';

/** New versions, the update in progress (followed through the restart) and the switches. */
function useExtensionUpdates({ onListChanged, onError }: { onListChanged: () => void; onError: (message: string) => void }) {
  const [view, setView] = useState<UpdatesView | null>(null);
  const [checking, setChecking] = useState(false);

  const load = useCallback(async (refresh = false) => {
    if (refresh) setChecking(true);
    try {
      setView(await api<UpdatesView>(`/api/extensions/updates${refresh ? '?refresh=1' : ''}`));
    } catch (e) {
      if (refresh) onError(formatError(e));
    } finally {
      setChecking(false);
    }
  }, [onError]);

  useEffect(() => {
    void load();
  }, [load]);

  const job = view?.job ?? null;
  const busy = isBusy(job);
  const startedAt = job?.startedAt;
  useEffect(() => {
    if (!busy) return;
    let stopped = false;
    const timer = window.setInterval(async () => {
      try {
        const res = await api<{ job: UpdateJob | null }>('/api/extensions/update-progress');
        if (stopped) return;
        setView((v) => (v ? { ...v, job: res.job } : v));
        if (!res.job || isBusy(res.job) || res.job.startedAt !== startedAt) return;
        if (res.job.state === 'done') {
          // The admin itself may have a new version too: load it fresh.
          try {
            sessionStorage.setItem(UPDATED_KEY, `${res.job.name ?? 'The extension'} was updated to ${res.job.version}.`);
          } catch {
            /* the message is a nicety */
          }
          window.location.reload();
        } else {
          onListChanged();
          void load();
        }
      } catch {
        // Beekiri is restarting on the new version: ask again in a moment.
      }
    }, 2000);
    return () => {
      stopped = true;
      window.clearInterval(timer);
    };
  }, [busy, startedAt, load, onListChanged]);

  const start = useCallback(
    async (ext: Extension) => {
      try {
        const res = await api<{ job: UpdateJob | null }>(`/api/extensions/${ext.slug}/update`, { method: 'POST', json: {} });
        setView((v) => (v ? { ...v, job: res.job } : v));
      } catch (e) {
        onError(formatError(e));
        void load();
      }
    },
    [load, onError],
  );

  return { view, job, busy, checking, refresh: () => load(true), start };
}

/** `?details=slug` opens the details window on either screen. */
function useDetails() {
  const [params, setParams] = useSearchParams();
  const slug = params.get('details');
  const open = useCallback(
    (s: string) => {
      const next = new URLSearchParams(params);
      next.set('details', s);
      setParams(next);
    },
    [params, setParams],
  );
  const close = useCallback(() => {
    const next = new URLSearchParams(params);
    next.delete('details');
    setParams(next);
  }, [params, setParams]);
  return { slug, open, close };
}

type ExtensionAction = 'install' | 'activate' | 'deactivate' | 'uninstall';

/** Runs one extension action against the API and hands the fresh list back. */
async function runExtensionAction(ext: Extension, action: ExtensionAction, deleteData = false) {
  const res = await api<{ extensions: Extension[] }>(`/api/extensions/${ext.slug}/${action}`, {
    method: 'POST',
    json: action === 'uninstall' ? { deleteData } : {},
  });
  notifyExtensionsChanged();
  return res.extensions;
}

function StatusAction({
  ext,
  onNavigate,
  onChange,
  onError,
}: {
  ext: Extension;
  onNavigate?: () => void;
  onChange?: (list: Extension[]) => void;
  onError?: (message: string) => void;
}) {
  const href = useAdminHref();
  const [busy, setBusy] = useState<ExtensionAction | null>(null);
  const run = async (action: ExtensionAction) => {
    let deleteData = false;
    if (action === 'uninstall') {
      const ok = await confirmDialog({
        title: `Uninstall ${ext.name}?`,
        message: `${ext.name} is removed from this site. In the next step you choose whether to keep or delete its data.`,
        confirmLabel: 'Uninstall',
        danger: true,
      });
      if (!ok) return;
      deleteData = await confirmDialog({
        title: 'Delete its data too?',
        message: `“Delete data” permanently removes ${dataWords(ext.slug)} created by ${ext.name}. This can’t be undone. “Keep data” keeps them in case you install it again.`,
        confirmLabel: 'Delete data',
        cancelLabel: 'Keep data',
        danger: true,
      });
    }
    if (action === 'deactivate') {
      const ok = await confirmDialog({
        title: `Deactivate ${ext.name}?`,
        message: `${hideWords(ext.slug)} until you activate it again. Nothing is deleted.`,
        confirmLabel: 'Deactivate',
      });
      if (!ok) return;
    }
    setBusy(action);
    try {
      onChange?.(await runExtensionAction(ext, action, deleteData));
    } catch (e) {
      onError?.(formatError(e));
    } finally {
      setBusy(null);
    }
  };
  if (ext.status === 'coming-soon') {
    return (
      <button type="button" className="button" disabled>
        Coming soon
      </button>
    );
  }
  if (ext.status === 'active') {
    return (
      <span className="bk-ext__action-row">
        {ext.settingsPath ? (
          <Link className="button button-primary" to={href(ext.settingsPath)} onClick={onNavigate}>
            Open {ext.name}
          </Link>
        ) : (
          <span className="bk-ext-active">
            <CheckCircle size={16} weight="fill" aria-hidden /> Active
          </span>
        )}
        {ext.kind === 'package' ? (
          <button type="button" className="button" disabled={busy !== null} onClick={() => void run('deactivate')}>
            {busy === 'deactivate' ? 'Deactivating…' : 'Deactivate'}
          </button>
        ) : null}
      </span>
    );
  }
  if (ext.status === 'inactive') {
    return (
      <span className="bk-ext__action-row">
        <button type="button" className="button button-primary" disabled={busy !== null} onClick={() => void run('activate')}>
          {busy === 'activate' ? 'Activating…' : 'Activate'}
        </button>
        <button type="button" className="button" disabled={busy !== null} onClick={() => void run('uninstall')}>
          {busy === 'uninstall' ? 'Uninstalling…' : 'Uninstall'}
        </button>
      </span>
    );
  }
  return (
    <button type="button" className="button button-primary" disabled={busy !== null} onClick={() => void run('install')}>
      {busy === 'install' ? 'Installing…' : 'Install now'}
    </button>
  );
}

function Badge({ ext }: { ext: Extension }) {
  if (ext.status === 'coming-soon') return <span className="bk-ext-badge is-soon">Coming soon</span>;
  if (ext.kind === 'built-in') return <span className="bk-ext-badge is-builtin">Built-in</span>;
  if (ext.status === 'active') return <span className="bk-ext-badge is-active">Active</span>;
  return null;
}

function Compatibility({ ext }: { ext: Extension }) {
  const { updates } = useCoreUpdate();
  const current = updates?.currentVersion ?? '1.0.0';
  const ok = compareVersions(current, ext.requires) >= 0;
  return ok ? (
    <span className="bk-ext-compat is-ok">
      <CheckCircle size={14} weight="fill" aria-hidden /> Compatible with your version of Beekiri
    </span>
  ) : (
    <span className="bk-ext-compat is-bad">Needs Beekiri {ext.requires} or newer (you have {current})</span>
  );
}

/** WordPress-style "View details": banner, tabs, and a facts sidebar. */
function DetailsModal({
  ext,
  offer,
  onUpdate,
  onClose,
  onChange,
  onError,
}: {
  ext: Extension;
  /** A newer version than the installed one, when there is one. */
  offer?: UpdateOffer;
  /** Shown as an Update now button when the update can be installed from here. */
  onUpdate?: () => void;
  onClose: () => void;
  onChange?: (list: Extension[]) => void;
  onError?: (message: string) => void;
}) {
  const [tab, setTab] = useState<'description' | 'changelog'>(offer ? 'changelog' : 'description');
  const { updates } = useCoreUpdate();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  return createPortal(
    <div
      className="bk-ext-modal"
      role="dialog"
      aria-modal="true"
      aria-label={`${ext.name} details`}
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="bk-ext-modal__panel">
        <button type="button" className="bk-ext-modal__close" aria-label="Close" onClick={onClose}>
          <X size={18} aria-hidden />
        </button>
        <div className="bk-ext-modal__banner" style={{ ['--ext-color' as string]: ext.color }}>
          <ExtensionIcon ext={ext} size="lg" />
          <div>
            <h2>{ext.name}</h2>
            <p>By {ext.author}</p>
          </div>
        </div>
        <div className="bk-tabs is-flush" role="tablist" aria-label="Extension details">
          {(['description', 'changelog'] as const).map((t) => (
            <button
              key={t}
              type="button"
              role="tab"
              aria-selected={tab === t}
              className={`bk-tabs__item${tab === t ? ' is-active' : ''}`}
              onClick={() => setTab(t)}
            >
              {t === 'description' ? 'Description' : 'Changelog'}
            </button>
          ))}
        </div>
        <div className="bk-ext-modal__body">
          <div className="bk-ext-modal__main">
            {tab === 'description' ? (
              <>
                <p className="bk-ext-modal__lead">{ext.tagline}</p>
                {ext.description.map((p) => (
                  <p key={p}>{p}</p>
                ))}
                <h3>What it adds</h3>
                <ul className="bk-ext-features">
                  {ext.features.map((f) => (
                    <li key={f}>
                      <CheckCircle size={15} weight="fill" aria-hidden /> {f}
                    </li>
                  ))}
                </ul>
              </>
            ) : (
              [...(offer ? [{ version: offer.version, notes: offer.notes, isNew: true }] : []), ...ext.changelog].map((c) => (
                <section key={c.version} className="bk-ext-changelog">
                  <h3>
                    {c.version}
                    {'isNew' in c ? <span className="bk-ext-badge is-new">New version</span> : null}
                  </h3>
                  <ul>
                    {c.notes.map((n) => (
                      <li key={n}>{n}</li>
                    ))}
                  </ul>
                </section>
              ))
            )}
          </div>
          <aside className="bk-ext-modal__facts">
            <dl>
              <dt>Version</dt>
              <dd>{ext.version}</dd>
              {offer ? (
                <>
                  <dt>New version</dt>
                  <dd>
                    {offer.version}
                    {offer.compatible ? null : ` (needs Beekiri ${offer.requires})`}
                  </dd>
                </>
              ) : null}
              <dt>Requires Beekiri</dt>
              <dd>{ext.requires} or newer</dd>
              <dt>Your Beekiri</dt>
              <dd>{updates?.currentVersion ?? '1.0.0'}</dd>
              <dt>Category</dt>
              <dd>{ext.category}</dd>
              <dt>Type</dt>
              <dd>{ext.kind === 'built-in' ? 'Built into Beekiri' : 'Beekiri extension'}</dd>
            </dl>
            <Compatibility ext={ext} />
            <div className="bk-ext-modal__action">
              {onUpdate ? (
                <button
                  type="button"
                  className="button button-primary bk-ext-modal__update"
                  onClick={() => {
                    onUpdate();
                    onClose();
                  }}
                >
                  Update to {offer?.version}
                </button>
              ) : null}
              <StatusAction ext={ext} onNavigate={onClose} onChange={onChange} onError={onError} />
            </div>
          </aside>
        </div>
      </div>
    </div>,
    document.body,
  );
}

function Shell({
  title,
  action,
  intro,
  children,
}: {
  title: string;
  action?: ReactNode;
  intro: string;
  children: ReactNode;
}) {
  return (
    <div className="wrap wrap--wide bk-ext">
      <PageHeader title={title} actions={action} />
      <p className="bk-muted bk-ext__intro">{intro}</p>
      {children}
    </div>
  );
}

/** Installed extensions — a WordPress Plugins-style table. */
export function ExtensionsPage() {
  const href = useAdminHref();
  const { list, error, setError, setList } = useExtensions();
  const details = useDetails();
  const [filter, setFilter] = useState<'all' | 'active' | 'inactive' | 'updates'>('all');
  const [query, setQuery] = useState('');
  const [toast, setToast] = useState<string | null>(null);
  const reloadList = useCallback(() => {
    api<{ extensions: Extension[] }>('/api/extensions')
      .then((res) => setList(res.extensions))
      .catch(() => undefined);
  }, [setList]);
  const updates = useExtensionUpdates({ onListChanged: reloadList, onError: setError });
  const offers = updates.view?.offers ?? {};

  // After an update the page reloads (the admin may be new too) and says how it went.
  useEffect(() => {
    try {
      const message = sessionStorage.getItem(UPDATED_KEY);
      if (message) {
        sessionStorage.removeItem(UPDATED_KEY);
        setToast(message);
      }
    } catch {
      /* no message */
    }
  }, []);

  const setAutoUpdate = async (ext: Extension, enabled: boolean) => {
    setList((prev) => prev?.map((e) => (e.slug === ext.slug ? { ...e, autoUpdate: enabled } : e)) ?? prev);
    try {
      await api(`/api/extensions/${ext.slug}/auto-update`, { method: 'POST', json: { enabled } });
      setToast(enabled ? `Automatic updates turned on for ${ext.name}.` : `Automatic updates turned off for ${ext.name}.`);
    } catch (e) {
      setList((prev) => prev?.map((x) => (x.slug === ext.slug ? { ...x, autoUpdate: !enabled } : x)) ?? prev);
      setError(formatError(e));
    }
  };

  const installed = useMemo(() => (list ?? []).filter(isInstalled), [list]);
  const counts = {
    all: installed.length,
    active: installed.filter((e) => e.status === 'active').length,
    inactive: installed.filter((e) => e.status === 'inactive').length,
    updates: installed.filter((e) => offers[e.slug]).length,
  };
  const rows = installed
    .filter((e) => filter === 'all' || (filter === 'updates' ? Boolean(offers[e.slug]) : e.status === filter))
    .filter((e) => {
      const q = query.trim().toLowerCase();
      return !q || `${e.name} ${e.tagline} ${e.category}`.toLowerCase().includes(q);
    });
  const open = list?.find((e) => e.slug === details.slug);
  const filters = (['all', 'active', 'inactive', 'updates'] as const).filter((f) => f !== 'updates' || counts.updates > 0);
  const canUpdate = (e: Extension) => Boolean(offers[e.slug]?.compatible && !updates.view?.blockedReason && !updates.busy);

  return (
    <Shell
      title="Extensions"
      intro="Extensions add bigger features to your site, like an online shop, forms or bookings. Every extension is made and published by Beekiri."
      action={
        <Link className="button button-primary bk-ext__add" to={href('extensions/new')}>
          <Plus size={14} weight="bold" aria-hidden /> Add New Extension
        </Link>
      }
    >
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      {toast ? <SuccessNotice message={toast} onDismiss={() => setToast(null)} /> : null}
      <div className="bk-ext__bar">
        <ul className="bk-ext__filters">
          {filters.map((f, i) => (
            <li key={f}>
              {i ? <span aria-hidden>|</span> : null}
              <button type="button" className={filter === f ? 'is-current' : ''} onClick={() => setFilter(f)}>
                {f === 'all' ? 'All' : f === 'active' ? 'Active' : f === 'inactive' ? 'Inactive' : 'Update available'} <span>({counts[f]})</span>
              </button>
            </li>
          ))}
        </ul>
        <div className="bk-ext__tools">
          <button type="button" className="button" disabled={updates.checking || updates.busy} onClick={() => void updates.refresh()}>
            {updates.checking ? 'Checking…' : 'Check for updates'}
          </button>
          <label className="bk-ext__search">
            <span className="screen-reader-text">Search installed extensions</span>
            <MagnifyingGlass size={15} aria-hidden />
            <input type="search" placeholder="Search installed extensions…" value={query} onChange={(e) => setQuery(e.target.value)} />
          </label>
        </div>
      </div>

      {!list ? (
        <p className="bk-muted">Loading…</p>
      ) : (
        <div className="bk-ext__table-wrap">
          <table className="bk-ext__table">
            <thead>
              <tr>
                <th scope="col">Extension</th>
                <th scope="col">Description</th>
                <th scope="col" className="bk-ext__auto">
                  Automatic updates
                </th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={3} className="bk-ext__empty">
                    {installed.length === 0 ? (
                      <>
                        <strong>No extensions installed yet.</strong>
                        <br />
                        <Link to={href('extensions/new')}>Browse Beekiri extensions</Link> to add a shop, forms, bookings and more.
                      </>
                    ) : (
                      <>
                        No installed extensions match your search. <Link to={href('extensions/new')}>Browse Beekiri extensions</Link>
                      </>
                    )}
                  </td>
                </tr>
              ) : (
                rows.map((e) => {
                  const offer = offers[e.slug];
                  const job = updates.job?.slug === e.slug ? updates.job : null;
                  const showJob = job && (isBusy(job) || (job.state !== 'done' && isRecent(job) && offer?.version === job.version));
                  const notice = Boolean(offer || showJob);
                  const rowClass = [e.status === 'active' ? 'is-active' : '', notice ? 'has-update' : ''].filter(Boolean).join(' ');
                  return (
                    <Fragment key={e.slug}>
                      <tr className={rowClass}>
                        <td className="bk-ext__name">
                          <div className="bk-ext__name-row">
                            <ExtensionIcon ext={e} size="sm" />
                            <strong>{e.name}</strong>
                          </div>
                          <div className="bk-ext__actions">
                            {e.status === 'active' && e.settingsPath ? <Link to={href(e.settingsPath)}>Settings</Link> : null}
                            {e.status === 'active' && e.settingsPath ? <span aria-hidden>|</span> : null}
                            <button type="button" onClick={() => details.open(e.slug)}>
                              View details
                            </button>
                            {e.kind === 'package' ? (
                              <>
                                <span aria-hidden>|</span>
                                <InlineExtensionAction ext={e} onChange={setList} onError={setError} />
                              </>
                            ) : null}
                            {e.kind === 'built-in' ? (
                              <>
                                <span aria-hidden>|</span>
                                <span className="bk-ext__locked" title="Built-in extensions come with Beekiri and are always on">
                                  Always on
                                </span>
                              </>
                            ) : null}
                          </div>
                        </td>
                        <td className="bk-ext__desc">
                          <p>{e.tagline}</p>
                          <p className="bk-ext__meta">
                            <Badge ext={e} />
                            Version {e.version} <span aria-hidden>|</span> By {e.author} <span aria-hidden>|</span>{' '}
                            <button type="button" onClick={() => details.open(e.slug)}>
                              View details
                            </button>
                          </p>
                        </td>
                        <td className="bk-ext__auto">
                          <span className="bk-ext__auto-label">Automatic updates</span>
                          {e.kind === 'built-in' ? (
                            <span className="bk-muted">Updated with Beekiri</span>
                          ) : (
                            <AutoUpdateSwitch ext={e} onChange={(enabled) => void setAutoUpdate(e, enabled)} />
                          )}
                        </td>
                      </tr>
                      {notice ? (
                        <tr className={`bk-ext__update-row${e.status === 'active' ? ' is-active' : ''}`}>
                          <td colSpan={3}>
                            <UpdateNotice
                              ext={e}
                              offer={offer}
                              job={showJob ? job : null}
                              blockedReason={updates.view?.blockedReason ?? null}
                              otherBusy={updates.busy && !job}
                              onDetails={() => details.open(e.slug)}
                              onUpdate={() => void updates.start(e)}
                            />
                          </td>
                        </tr>
                      ) : null}
                    </Fragment>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      )}
      {open ? (
        <DetailsModal
          ext={open}
          offer={isInstalled(open) ? offers[open.slug] : undefined}
          onUpdate={isInstalled(open) && canUpdate(open) ? () => void updates.start(open) : undefined}
          onClose={details.close}
          onChange={setList}
          onError={setError}
        />
      ) : null}
    </Shell>
  );
}

/** Automatic updates on/off for one installed extension. */
function AutoUpdateSwitch({ ext, onChange }: { ext: Extension; onChange: (enabled: boolean) => void }) {
  return (
    <label className="bk-ext-switch" title={ext.autoUpdate ? 'New versions are installed automatically at night.' : 'New versions wait for you to update them.'}>
      <input type="checkbox" role="switch" checked={ext.autoUpdate} aria-label={`Automatic updates for ${ext.name}`} onChange={(e) => onChange(e.target.checked)} />
      <span className="bk-ext-switch__track" aria-hidden>
        <span className="bk-ext-switch__knob" />
      </span>
      <span className="bk-ext-switch__text">{ext.autoUpdate ? 'On' : 'Off'}</span>
    </label>
  );
}

/** The line under an extension with a new version: what is new, update now, or how the update is going. */
function UpdateNotice({
  ext,
  offer,
  job,
  blockedReason,
  otherBusy,
  onDetails,
  onUpdate,
}: {
  ext: Extension;
  offer?: UpdateOffer;
  job: UpdateJob | null;
  blockedReason: string | null;
  otherBusy: boolean;
  onDetails: () => void;
  onUpdate: () => void;
}) {
  const href = useAdminHref();
  if (job && isBusy(job)) {
    return (
      <div className="beekiri-notice is-info bk-ext-update" role="status">
        <ArrowsClockwise size={16} className="bk-ext-update__spin" aria-hidden />
        <p>
          <strong>
            Updating {ext.name} to {job.version}
            {job.progress ? ` (${Math.min(99, job.progress)}%)` : ''}.
          </strong>{' '}
          {job.state === 'restarting' ? 'Restarting your site on the new version…' : job.message}
        </p>
      </div>
    );
  }
  if (job) {
    return (
      <div className="beekiri-notice is-error bk-ext-update" role="alert">
        <p>
          <strong>
            {ext.name} {job.version} could not be installed.
          </strong>{' '}
          {job.message}{' '}
          {offer?.compatible && !blockedReason && !otherBusy ? (
            <button type="button" className="button-link" onClick={onUpdate}>
              Try again
            </button>
          ) : null}
        </p>
      </div>
    );
  }
  if (!offer) return null;
  return (
    <div className="beekiri-notice is-info bk-ext-update">
      <p>
        <strong>
          {ext.name} {offer.version} is available.
        </strong>{' '}
        <button type="button" className="button-link" onClick={onDetails}>
          See what’s new
        </button>
        {!offer.compatible ? (
          <>
            . It needs Beekiri {offer.requires} or newer, so update Beekiri first in{' '}
            <Link to={href('settings?tab=core')}>Settings → Beekiri Core</Link>.
          </>
        ) : blockedReason ? (
          <>. {blockedReason}</>
        ) : (
          <>
            {' '}or{' '}
            <button type="button" className="button-link" disabled={otherBusy} onClick={onUpdate}>
              update now
            </button>
            .{ext.autoUpdate ? ' Otherwise it is installed automatically tonight.' : null}
            {otherBusy ? ' Another extension is being updated; this one can follow when it is done.' : null}
          </>
        )}
      </p>
    </div>
  );
}

/** Text links in the installed table: Deactivate / Activate | Uninstall. */
function InlineExtensionAction({
  ext,
  onChange,
  onError,
}: {
  ext: Extension;
  onChange: (list: Extension[]) => void;
  onError: (message: string) => void;
}) {
  const [busy, setBusy] = useState(false);
  const run = async (action: ExtensionAction) => {
    let deleteData = false;
    if (action === 'deactivate') {
      const ok = await confirmDialog({ title: `Deactivate ${ext.name}?`, message: `${hideWords(ext.slug)} until you activate it again. Nothing is deleted.`, confirmLabel: 'Deactivate' });
      if (!ok) return;
    }
    if (action === 'uninstall') {
      const ok = await confirmDialog({ title: `Uninstall ${ext.name}?`, message: `${ext.name} is removed from this site. In the next step you choose whether to keep or delete its data.`, confirmLabel: 'Uninstall', danger: true });
      if (!ok) return;
      deleteData = await confirmDialog({ title: 'Delete its data too?', message: `“Delete data” permanently removes ${dataWords(ext.slug)} created by ${ext.name}. This can’t be undone. “Keep data” keeps them in case you install it again.`, confirmLabel: 'Delete data', cancelLabel: 'Keep data', danger: true });
    }
    setBusy(true);
    try {
      onChange(await runExtensionAction(ext, action, deleteData));
    } catch (e) {
      onError(formatError(e));
    } finally {
      setBusy(false);
    }
  };
  if (ext.status === 'active') {
    return (
      <button type="button" disabled={busy} onClick={() => void run('deactivate')}>
        Deactivate
      </button>
    );
  }
  return (
    <>
      <button type="button" disabled={busy} onClick={() => void run('activate')}>
        Activate
      </button>
      <span aria-hidden>|</span>
      <button type="button" className="is-danger" disabled={busy} onClick={() => void run('uninstall')}>
        Uninstall
      </button>
    </>
  );
}

/** Add New — the Beekiri extension directory as a card grid. */
export function ExtensionsDirectoryPage() {
  const href = useAdminHref();
  const { list, error, setError, setList } = useExtensions();
  const details = useDetails();
  const [tab, setTab] = useState<'all' | 'coming-soon'>('all');
  const [category, setCategory] = useState('all');
  const [query, setQuery] = useState('');

  const categories = useMemo(() => [...new Set((list ?? []).map((e) => e.category))].sort(), [list]);
  const cards = (list ?? [])
    .filter((e) => tab === 'all' || e.status === 'coming-soon')
    .filter((e) => category === 'all' || e.category === category)
    .filter((e) => {
      const q = query.trim().toLowerCase();
      return !q || `${e.name} ${e.tagline} ${e.category} ${e.features.join(' ')}`.toLowerCase().includes(q);
    });
  const open = list?.find((e) => e.slug === details.slug);

  return (
    <Shell
      title="Add Extensions"
      intro="Add features to your site with extensions from Beekiri. New ones appear here as they are released."
      action={
        <Link className="button bk-ext__add" to={href('extensions')}>
          Installed extensions
        </Link>
      }
    >
      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}
      <div className="bk-tabs" role="tablist" aria-label="Extensions">
        {(['all', 'coming-soon'] as const).map((t) => (
          <button key={t} type="button" role="tab" aria-selected={tab === t} className={`bk-tabs__item${tab === t ? ' is-active' : ''}`} onClick={() => setTab(t)}>
            {t === 'all' ? 'All' : 'Coming soon'}
          </button>
        ))}
      </div>
      <div className="bk-ext__bar">
        <div className="bk-ext__tools">
          <select value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Category">
            <option value="all">All categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <label className="bk-ext__search">
            <span className="screen-reader-text">Search extensions</span>
            <MagnifyingGlass size={15} aria-hidden />
            <input type="search" placeholder="Search extensions…" value={query} onChange={(e) => setQuery(e.target.value)} />
          </label>
        </div>
      </div>

      {!list ? (
        <p className="bk-muted">Loading…</p>
      ) : cards.length === 0 ? (
        <p className="bk-muted">No extensions match your search.</p>
      ) : (
        <div className="bk-ext__grid">
          {cards.map((e) => (
            <article key={e.slug} className="bk-ext-card">
              <div className="bk-ext-card__top">
                <button type="button" className="bk-ext-card__icon-btn" onClick={() => details.open(e.slug)} aria-label={`${e.name} details`}>
                  <ExtensionIcon ext={e} />
                </button>
                <div className="bk-ext-card__head">
                  <h3>
                    <button type="button" onClick={() => details.open(e.slug)}>
                      {e.name}
                    </button>
                  </h3>
                  <p className="bk-ext-card__tagline">{e.tagline}</p>
                  <p className="bk-ext-card__by">
                    By <strong>{e.author}</strong>
                  </p>
                </div>
                <div className="bk-ext-card__cta">
                  <StatusAction ext={e} onChange={setList} onError={setError} />
                  <button type="button" className="bk-ext-card__more" onClick={() => details.open(e.slug)}>
                    More details
                  </button>
                </div>
              </div>
              <div className="bk-ext-card__foot">
                <span>
                  <Badge ext={e} /> {e.category} · Version {e.version}
                </span>
                <Compatibility ext={e} />
              </div>
            </article>
          ))}
        </div>
      )}
      {open ? <DetailsModal ext={open} onClose={details.close} onChange={setList} onError={setError} /> : null}
    </Shell>
  );
}
