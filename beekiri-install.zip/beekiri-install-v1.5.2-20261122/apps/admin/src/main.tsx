import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { App } from './App';
import { AuthProvider } from './auth/AuthContext';
import { CoreUpdateProvider } from './core/CoreUpdateContext';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <CoreUpdateProvider>
          <App />
        </CoreUpdateProvider>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>,
);
