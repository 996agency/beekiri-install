import { STATUS_CODES } from 'http';
import {
  ConnectionError,
  ForeignKeyConstraintError,
  UniqueConstraintError,
  ValidationError,
} from 'sequelize';

export type HttpErrorBody = string | Record<string, unknown>;

/**
 * Throw from services/controllers; the error middleware turns it into JSON.
 * String bodies become `{ statusCode, message, error }`; object bodies
 * (e.g. `{ message, code }`) are sent as-is so the admin can branch on `code`.
 */
export class HttpError extends Error {
  readonly status: number;
  readonly body: HttpErrorBody;

  constructor(status: number, body: HttpErrorBody, options?: { cause?: unknown }) {
    super(typeof body === 'string' ? body : String(body.message ?? STATUS_CODES[status]), options);
    this.name = 'HttpError';
    this.status = status;
    this.body = body;
  }

  toJSON(): Record<string, unknown> {
    if (typeof this.body === 'object') return this.body;
    return {
      message: this.body,
      error: STATUS_CODES[this.status] ?? 'Error',
      statusCode: this.status,
    };
  }
}

const make =
  (status: number, fallback: string) =>
  (body: HttpErrorBody = fallback) =>
    new HttpError(status, body);

export const BadRequest = make(400, 'Something in this request is not right. Check the details and try again.');
export const Unauthorized = make(401, 'Sign in to continue.');
export const PaymentRequired = make(402, 'Payment Required');
export const Forbidden = make(403, "You don't have permission to do that.");
export const NotFound = make(404, 'This item could not be found. It may have been deleted.');
export const Conflict = make(409, 'This clashes with something that already exists. Refresh the page and try again.');
export const PayloadTooLarge = make(413, 'This is too large to upload.');
export const UnprocessableEntity = make(422, 'Unprocessable Entity');
export const TooManyRequests = make(429, 'Too many attempts. Wait a few minutes and try again.');
export const InternalServerError = make(500, 'Something went wrong. Try again in a moment.');
export const BadGateway = make(502, 'A service this site relies on did not respond. Try again in a moment.');
export const ServiceUnavailable = make(503, 'This is not available right now. Try again in a moment.');

/**
 * Normalize anything thrown into an HttpError. Errors that already carry an HTTP
 * status pass through untouched, database errors become the matching 4xx/503, and
 * everything else becomes a 500 with `fallbackMessage` (the original is kept as
 * `cause` so it is logged, never sent to the client).
 */
export function toHttpError(error: unknown, fallbackMessage = 'Something went wrong. Try again in a moment.'): HttpError {
  if (error instanceof HttpError) return error;
  // UniqueConstraintError extends ValidationError, so it must be checked first.
  if (error instanceof UniqueConstraintError) {
    return new HttpError(409, 'That value is already in use.', { cause: error });
  }
  if (error instanceof ForeignKeyConstraintError) {
    return new HttpError(409, 'This item is still used by other content. Remove those links first, then try again.', { cause: error });
  }
  if (error instanceof ValidationError)
    return new HttpError(400, 'Some of the details are not valid. Check them and try again.', { cause: error });
  if (error instanceof ConnectionError) {
    return new HttpError(503, 'The site cannot reach its database right now. Try again in a moment.', {
      cause: error,
    });
  }
  return new HttpError(500, fallbackMessage, { cause: error });
}
