import type { ShopApiCaller } from '../services/shop/api-keys.service';
import type { AuthSessionContext } from './auth';

declare global {
  namespace Express {
    interface Request {
      /** Set by `requireAuth` once the session cookie, origin and CSRF token check out. */
      auth?: AuthSessionContext;
      /** Set by `requireShopApiKey` on /api/shop/v1: the key and the person it acts as. */
      shopApi?: ShopApiCaller;
    }
  }
}

export {};
