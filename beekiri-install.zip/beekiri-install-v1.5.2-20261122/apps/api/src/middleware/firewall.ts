import type { NextFunction, Request, Response } from 'express';
import { KNOWN_DEVICE_COOKIE, isKnownDevice } from '../lib/auth/known-device';
import { cameThroughCloudflare, ipKey, isLocalAddress, normalizeIp } from '../lib/security/ip';
import { isAttackTool, isCrawler, isStaticAsset, looksLikeInjection, probeKind } from '../lib/security/signatures';
import { resolveAdminBasePath } from '../lib/site/admin-base-cache';
import { CLIENT_IP_HEADER, INTERNAL_HEADER, INTERNAL_TOKEN } from '../lib/site/current-site';
import { User } from '../models';
import { shieldService, type SiteShield } from '../services/security/shield.service';
import { safeEqual } from '../utils/crypto';

/**
 * Beekiri Shield at the door: runs on every request (pages, admin, API, uploads) right after
 * the site is known, before anything expensive happens. See services/security/shield.service.ts.
 */

function isInternal(req: Request): boolean {
  const token = req.get(INTERNAL_HEADER);
  return Boolean(token && safeEqual(token, INTERNAL_TOKEN));
}

function cookie(req: Request, name: string): string | undefined {
  const header = req.headers.cookie;
  if (!header || header.length > 8192) return undefined;
  for (const part of header.split(';')) {
    const eq = part.indexOf('=');
    if (eq > 0 && part.slice(0, eq).trim() === name) {
      try {
        return decodeURIComponent(part.slice(eq + 1).trim());
      } catch {
        return undefined;
      }
    }
  }
  return undefined;
}

const hasSession = (req: Request) => /(?:^|;\s*)(?:__Host-)?beekiri_session=/.test(req.headers.cookie ?? '');
/** Signed with a shop REST API key (checked later; like the cookie above, only its presence counts here). */
const hasShopApiKey = (req: Request) => /^Bearer\s+bk_shop_/i.test(req.get('authorization') ?? '');

/** How much one request counts toward the flood limit. */
function requestWeight(req: Request, userAgent: string): number {
  if (isStaticAsset(req.path)) return 0.1;
  const purpose = `${req.get('sec-purpose') ?? ''} ${req.get('purpose') ?? ''}`.toLowerCase();
  if (req.get('next-router-prefetch') || purpose.includes('prefetch')) return 0.1;
  if (hasSession(req) || hasShopApiKey(req)) return 0.25;
  if (isCrawler(userAgent)) return 0.5;
  return 1;
}

type DenyKind = 'banned' | 'blocked' | 'direct' | 'attack' | 'probe' | 'flood';

const MESSAGES: Record<DenyKind, string> = {
  banned: 'Access from your network is paused for a short time because of unusual activity. Try again later.',
  blocked: 'Access to this site from your network is blocked. If you think this is a mistake, contact the site owner.',
  direct: 'Open this site at its usual web address.',
  attack: 'This request was blocked for security reasons. If you think this is a mistake, contact the site owner.',
  probe: 'Not found.',
  flood: 'Too many requests came from your network. Wait a few minutes and try again.',
};

function deny(req: Request, res: Response, kind: DenyKind, siteId: string | null, retryAfterSeconds?: number): void {
  if (kind !== 'probe') shieldService.countBlocked(siteId);
  const status = kind === 'probe' ? 404 : kind === 'flood' ? 429 : 403;
  res.setHeader('Cache-Control', 'no-store');
  if (retryAfterSeconds) res.setHeader('Retry-After', String(Math.max(1, Math.ceil(retryAfterSeconds))));
  const message = MESSAGES[kind];
  const wantsJson = req.path.startsWith('/api/') || (req.get('accept') ?? '').includes('application/json');
  if (wantsJson || kind === 'probe') {
    if (kind === 'probe') {
      res.status(status).type('text').send(message);
      return;
    }
    res.status(status).json({ statusCode: status, error: status === 429 ? 'Too Many Requests' : 'Forbidden', message, code: 'shield' });
    return;
  }
  res
    .status(status)
    .type('html')
    .send(
      `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Access paused</title>` +
        `<style>body{margin:0;min-height:100vh;display:grid;place-items:center;font:16px/1.5 system-ui,-apple-system,Segoe UI,sans-serif;background:#f6f7f9;color:#202734}main{max-width:440px;margin:24px;padding:32px;background:#fff;border:1px solid #e3e5ea;border-radius:8px}h1{font-size:20px;margin:0 0 8px}p{margin:0;color:#4a5160}</style>` +
        `</head><body><main><h1>${status === 429 ? 'Too many requests' : 'Access paused'}</h1><p>${message}</p></main></body></html>`,
    );
}

/* ── A banned browser that signed in to the admin before still gets in ──── */

const trusted = new Map<string, number>();
const lastLookup = new Map<string, number>();

/**
 * True when the browser carries a known-device cookie of a real account (see lib/auth/known-device):
 * it signed in successfully before, so an automatic ban of its network (an office sharing one
 * address with an infected computer, a few typos) must not lock the site's own people out.
 * At most one database lookup per address every 30 seconds.
 */
async function isTrustedBrowser(req: Request, ip: string): Promise<boolean> {
  const raw = cookie(req, KNOWN_DEVICE_COOKIE);
  if (!raw || raw.length > 200) return false;
  const now = Date.now();
  const hit = trusted.get(raw);
  if (hit && hit > now) return true;
  const key = ipKey(ip);
  const last = lastLookup.get(key);
  if (last && now - last < 30_000) return false;
  if (lastLookup.size > 10_000) lastLookup.clear();
  lastLookup.set(key, now);
  const userId = raw.split('.')[0] ?? '';
  if (!userId || userId.length > 64) return false;
  try {
    const user = await User.scope('withPassword').findByPk(userId, { attributes: ['id', 'passwordHash'] });
    if (!user || !isKnownDevice(raw, 'user', user.id, user.passwordHash)) return false;
    if (trusted.size > 1_000) trusted.clear();
    trusted.set(raw, now + 10 * 60_000);
    return true;
  } catch {
    return false;
  }
}

/* ── The checks ─────────────────────────────────────────────────────────── */

async function inspect(req: Request, res: Response, next: NextFunction, ip: string, siteId: string | null, shield: SiteShield): Promise<void> {
  const { options, allowed, blocked } = shield;
  if (allowed.has(ip)) return next();

  if (blocked.has(ip)) {
    void shieldService.logEvent(siteId, 'security.blocked_request', ip, { reason: 'blocked_list', path: req.path.slice(0, 300) }, null, true);
    return deny(req, res, 'blocked', siteId);
  }
  if (options.cloudflare.onlyCloudflare && !cameThroughCloudflare(req) && !isLocalAddress(ip)) {
    void shieldService.logEvent(siteId, 'security.direct_access', ip, { path: req.path.slice(0, 300) }, null, true);
    return deny(req, res, 'direct', siteId);
  }

  const ban = shieldService.activeBan(ip);
  if (ban) {
    if (await isTrustedBrowser(req, ip)) return next();
    return deny(req, res, 'banned', siteId, (ban.until - Date.now()) / 1000);
  }

  const level = options.shield.level;
  if (level === 'off') return next();
  const userAgent = req.get('user-agent') ?? '';
  const path = req.path;

  if (options.shield.blockAttackTools && isAttackTool(userAgent)) {
    shieldService.report(ip, 'attack_tool', { siteId, level, path });
    return deny(req, res, 'attack', siteId);
  }

  if (options.shield.blockProbes) {
    let probe = probeKind(path);
    // The site's admin may live at any address (even /wp-admin): never count it.
    if (probe) probe = probeKind(path, await resolveAdminBasePath().catch(() => undefined));
    if (probe) {
      const banned = shieldService.report(ip, probe, { siteId, level, path });
      return deny(req, res, banned ? 'banned' : 'probe', siteId);
    }
    if (looksLikeInjection(req.originalUrl)) {
      shieldService.report(ip, 'injection', { siteId, level, path });
      void shieldService.logEvent(siteId, 'security.injection_blocked', ip, { path: req.originalUrl.slice(0, 300) }, null, true);
      return deny(req, res, 'attack', siteId);
    }
  }

  if (options.shield.floodProtection && shieldService.countRequest(ip, requestWeight(req, userAgent), level)) {
    const b = shieldService.ban(ip, 'flood', siteId, { path });
    return deny(req, res, 'flood', siteId, (b.until - Date.now()) / 1000);
  }

  // What the rest of the site answers counts too: rate limits hit, pages that don't exist.
  res.once('finish', () => {
    if (res.statusCode === 429) shieldService.report(ip, 'rate_limited', { siteId, level });
    // A valid shop API key asking for a product that was deleted is not scanning.
    else if (res.statusCode === 404 && !isCrawler(userAgent) && !res.locals.shopApiKey) shieldService.report(ip, 'not_found', { siteId, level, path });
  });
  next();
}

export function firewall(req: Request, res: Response, next: NextFunction): void {
  const siteId = req.site?.id ?? null;
  // The website's own calls back to the API: the page request was checked at the door. Limits
  // those calls hit still count against the visitor they were made for.
  if (isInternal(req)) {
    const visitor = normalizeIp(req.get(CLIENT_IP_HEADER));
    if (visitor) res.once('finish', () => res.statusCode === 429 && shieldService.report(visitor, 'rate_limited', { siteId }));
    return next();
  }
  const ip = normalizeIp(req.ip);
  if (!ip) return next();
  let passed = false;
  const pass: NextFunction = (err?: unknown) => {
    passed = true;
    next(err);
  };
  const cached = shieldService.cachedSite(siteId);
  // A failing check never takes the site down: the request goes on unchecked.
  const run = (shield: SiteShield) =>
    inspect(req, res, pass, ip, siteId, shield).catch(() => {
      if (!passed && !res.headersSent) pass();
    });
  if (cached) {
    void run(cached);
    return;
  }
  shieldService.loadSite(siteId).then(run, () => pass());
}
