import type { Request } from 'express';
import baseRateLimit, { type Options } from 'express-rate-limit';
import { ipKey } from '../lib/security/ip';
import { CLIENT_IP_HEADER, INTERNAL_HEADER, INTERNAL_TOKEN } from '../lib/site/current-site';
import { safeEqual } from '../utils/crypto';

/**
 * Who a request counts against. The website renders pages by calling this API from the server
 * itself, so those calls carry the visitor's address (trusted only with the internal token);
 * otherwise every visitor would share one bucket and one busy visitor could empty the site for
 * all. An IPv6 visitor counts as their whole /64 network, which they could otherwise rotate through.
 */
export function visitorKey(req: Request): string {
  const internal = req.get(INTERNAL_HEADER);
  const forwarded = internal && safeEqual(internal, INTERNAL_TOKEN) ? req.get(CLIENT_IP_HEADER) : undefined;
  return ipKey(forwarded || req.ip || '');
}

const rateLimit = (options: Partial<Options>) =>
  baseRateLimit({ keyGenerator: (req) => visitorKey(req as Request), ...options });

const tooMany = (message: string) => ({ statusCode: 429, message, error: 'Too Many Requests' });

/** Coarse flood guard for the whole API (admin polling stays far below this). */
export const apiRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 1_200,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests in a short time. Wait a moment and try again.'),
});

/** Public BeeCookies consent posts. */
export const beeCookiesRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 30,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests in a short time. Wait a moment and try again.'),
});

/** Page-view posts — tight to blunt spam; real nav stays well under this. */
export const beeCookiesVisitRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests in a short time. Wait a moment and try again.'),
});

/** Live heartbeats (~every 30s). Caps scripted flooders. */
export const beeCookiesHeartbeatRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 12,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests in a short time. Wait a moment and try again.'),
});

/** Click batches for heatmaps (client flushes every few seconds). */
export const beeCookiesClicksRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 40,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests in a short time. Wait a moment and try again.'),
});

/** Public layout rendering: each call may spawn a PHP process. */
export const layoutRenderRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 120,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many page requests in a short time. Wait a moment and try again.'),
});

/** Unauthenticated auth endpoints (password reset, lost password). */
export const authRateLimit = rateLimit({
  windowMs: 15 * 60_000,
  limit: 30,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many attempts. Wait 15 minutes and try again.'),
});

/** Storefront cart changes (add / update / remove / coupon). */
export const shopCartRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 60,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many cart changes in a short time. Wait a moment and try again.'),
});

/**
 * Trying coupon codes: only codes that don't work count (8 per visitor per 15 minutes), so a shopper
 * with a real code is never slowed down but nobody can guess their way through the shop's codes.
 */
export const shopCouponRateLimit = rateLimit({
  windowMs: 15 * 60_000,
  limit: 8,
  skipSuccessfulRequests: true,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many coupon codes tried. Wait a few minutes and try again.'),
});

/** Placing orders: tight, each call may create an order and a payment session. */
export const shopCheckoutRateLimit = rateLimit({
  windowMs: 10 * 60_000,
  limit: 15,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many checkout attempts. Wait a few minutes and try again.'),
});

/** Payment-provider webhooks (signature-verified; the limit only blunts floods). */
export const shopWebhookRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 240,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many payment notifications in a short time. Try again in a moment.'),
});

/** Couriers' status messages (matched by the secret in their address; the limit only blunts floods). */
export const shopCourierWebhookRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 600,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many status updates in a short time. Try again in a moment.'),
});

/** Admin courier tests and "check now": each one calls the courier's system. */
export const shopCourierCallRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 30,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests to the courier in a short time. Wait a minute and try again.'),
});

/** Bee Forms submissions (each may store files and send mail). */
export const formsSubmitRateLimit = rateLimit({
  windowMs: 10 * 60_000,
  limit: 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many submissions. Wait a few minutes and try again.'),
});

/** Bee Forms public reads (form HTML, spam tokens). */
export const formsViewRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 120,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests in a short time. Wait a moment and try again.'),
});

/** Bee Bookings: booking and cancelling (each may send mail). */
export const bookingsSubmitRateLimit = rateLimit({
  windowMs: 10 * 60_000,
  limit: 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many booking attempts. Wait a few minutes and try again.'),
});

/** Bee Bookings public reads (services, free days and times, the customer's booking page). */
export const bookingsViewRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 180,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests in a short time. Wait a moment and try again.'),
});

/** Dynamic-content items for pages (products, posts, repeater rows). */
export const dynamicItemsRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 300,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests in a short time. Wait a moment and try again.'),
});

/** Storefront reads that may run PHP templates. */
export const shopViewRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 300,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests in a short time. Wait a moment and try again.'),
});

/**
 * Shop REST API, per key (a key used from several servers shares one allowance): 5 requests a
 * second on average, plenty for an app or a stock sync.
 */
export const shopApiRateLimit = rateLimit({
  windowMs: 60_000,
  limit: 300,
  keyGenerator: (req) => {
    const r = req as Request;
    return r.shopApi ? `shop-api-key:${r.shopApi.key.id}` : visitorKey(r);
  },
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('This API key sent too many requests in a short time. Wait a moment and try again.'),
});

/** Shop REST API keys that don't work: 30 per address per 15 minutes, so nobody can try keys. */
export const shopApiKeyFailRateLimit = rateLimit({
  windowMs: 15 * 60_000,
  limit: 30,
  skipSuccessfulRequests: true,
  requestWasSuccessful: (_req, res) => res.statusCode !== 401,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: tooMany('Too many requests with an API key that is not valid. Wait a few minutes and try again.'),
});
