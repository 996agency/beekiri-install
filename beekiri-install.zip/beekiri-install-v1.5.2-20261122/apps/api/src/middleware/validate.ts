import type { NextFunction, Request, Response } from 'express';
import { z, ZodError, type ZodIssue, type ZodTypeAny } from 'zod';
import { HttpError } from '../utils/http-error';

const TYPE_WORDS: Record<string, string> = {
  string: 'text',
  number: 'a number',
  integer: 'a whole number',
  boolean: 'yes or no',
  array: 'a list',
  object: 'a group of values',
  date: 'a date',
};

function isDefaultMessage(issue: ZodIssue): boolean {
  return z.defaultErrorMap(issue, { defaultError: '', data: undefined }).message === issue.message;
}

/** Messages in the same wording the admin UI already shows (class-validator style). */
function describe(issue: ZodIssue): string[] {
  const path = issue.path.join('.');
  const subject = path || 'value';
  if (!isDefaultMessage(issue) && issue.code !== 'unrecognized_keys') return [issue.message];

  switch (issue.code) {
    case 'unrecognized_keys':
      return issue.keys.map((k) => `property ${path ? `${path}.` : ''}${k} should not exist.`);
    case 'invalid_type':
      return [`${subject} must be ${TYPE_WORDS[issue.expected] ?? `a ${issue.expected}`}.`];
    case 'invalid_literal':
      return [`${subject} must be ${JSON.stringify(issue.expected)}.`];
    case 'invalid_enum_value':
      return [`${subject} must be one of: ${issue.options.join(', ')}.`];
    case 'invalid_string':
      if (issue.validation === 'email') return [`${subject} must be a valid email address.`];
      if (issue.validation === 'url') return [`${subject} must be a valid web address.`];
      if (issue.validation === 'regex') return [`${subject} is not in the right format.`];
      return [`${subject} is not valid.`];
    case 'too_small':
      if (issue.type === 'string')
        return [`${subject} must be at least ${issue.minimum} character${issue.minimum === 1 ? '' : 's'} long.`];
      if (issue.type === 'array')
        return [`${subject} must have at least ${issue.minimum} item${issue.minimum === 1 ? '' : 's'}.`];
      return [`${subject} must be at least ${issue.minimum}.`];
    case 'too_big':
      if (issue.type === 'string')
        return [`${subject} is too long (${issue.maximum} characters at most).`];
      if (issue.type === 'array')
        return [`${subject} can have at most ${issue.maximum} items.`];
      return [`${subject} must be ${issue.maximum} or less.`];
    case 'not_multiple_of':
      return [`${subject} must be a whole number.`];
    default:
      return [`${subject} is not valid.`];
  }
}

export function validationError(error: ZodError): HttpError {
  const message = [...new Set(error.issues.flatMap(describe))];
  return new HttpError(400, { statusCode: 400, message, error: 'Bad Request' });
}

export type RequestSchemas = { body?: ZodTypeAny; query?: ZodTypeAny; params?: ZodTypeAny };

/**
 * Parse + replace req.body / req.query / req.params; unknown body keys are rejected by the schemas.
 * The schemas stay attached to the middleware so the OpenAPI document can describe the route.
 */
export function validate(schemas: RequestSchemas) {
  const middleware = (req: Request, _res: Response, next: NextFunction) => {
    for (const part of ['params', 'query', 'body'] as const) {
      const schema = schemas[part];
      if (!schema) continue;
      const input = part === 'body' ? (req.body ?? {}) : req[part];
      const parsed = schema.safeParse(input);
      if (!parsed.success) return next(validationError(parsed.error));
      // Express 5 exposes req.query as a getter; redefine it with the parsed value.
      Object.defineProperty(req, part, { value: parsed.data, writable: true, configurable: true });
    }
    next();
  };
  return Object.assign(middleware, { schemas });
}
