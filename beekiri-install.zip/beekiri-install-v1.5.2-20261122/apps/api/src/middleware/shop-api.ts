import type { NextFunction, Request, Response } from 'express';
import type { CapabilitySlug } from '../lib/cms-types';
import { currentSiteId } from '../lib/site/current-site';
import type { ShopApiPermission } from '../lib/shop/constants';
import { shopApiKeysService } from '../services/shop/api-keys.service';
import { Forbidden, Unauthorized } from '../utils/http-error';

const WHERE_KEYS_ARE = 'Shop → Settings → REST API';

/** `Authorization: Bearer bk_shop_…` */
export function shopApiToken(req: Request): string {
  const match = /^Bearer\s+(\S+)\s*$/i.exec(req.get('authorization') ?? '');
  return match?.[1] ?? '';
}

/**
 * Every /api/shop/v1 request is signed with an API key; cookies are never read, so these routes
 * need no CSRF token and can be called from any server, app or website. The request then runs as
 * the key's creator, with the rights they have on this site right now.
 */
export async function requireShopApiKey(req: Request, res: Response, next: NextFunction) {
  try {
    const token = shopApiToken(req);
    if (!token) {
      throw Unauthorized(`This request needs a shop API key. Create one in ${WHERE_KEYS_ARE} and send it in the header "Authorization: Bearer <key>".`);
    }
    const siteId = currentSiteId();
    const caller = siteId ? await shopApiKeysService.authenticate(token, siteId) : null;
    if (!caller) throw Unauthorized('This API key is not valid. It may have been revoked, or it belongs to another website.');
    if (!caller.user.capabilities.includes('manage_shop')) {
      throw Forbidden('The person who created this API key can no longer manage the shop, so the key no longer works.');
    }
    req.auth = { sessionId: `shop-api-key:${caller.key.id}`, csrfToken: '', user: caller.user };
    req.shopApi = caller;
    // Beekiri Shield: a signed-in integration asking for a product that is gone is not scanning.
    res.locals.shopApiKey = caller.key.id;
    next();
  } catch (error) {
    next(error);
  }
}

const RANK: Record<ShopApiPermission, number> = { catalog: 0, read: 1, read_write: 2 };

const TOO_LOW: Record<ShopApiPermission, string> = {
  catalog: `This API key can only read published products and categories. Create a key with Read access in ${WHERE_KEYS_ARE}.`,
  read: `This API key can only read. Create a key with Read and write access in ${WHERE_KEYS_ARE}.`,
  read_write: '',
};

/** The key's own permission must reach `level` (catalog < read < read_write). */
export function shopApiAllows(level: ShopApiPermission) {
  const middleware = (req: Request, _res: Response, next: NextFunction) => {
    const permission = req.shopApi?.key.permission;
    if (!permission) return next(Unauthorized('This request needs a shop API key.'));
    if (RANK[permission] < RANK[level]) return next(Forbidden(TOO_LOW[permission]));
    next();
  };
  return Object.assign(middleware, { apiKeyPermission: level });
}

/** The key's creator must (still) have every listed right; kept on the handler for the OpenAPI document. */
export function shopApiCan(...required: CapabilitySlug[]) {
  const middleware = (req: Request, _res: Response, next: NextFunction) => {
    const user = req.auth?.user;
    if (!user || !required.every((c) => user.capabilities.includes(c))) {
      return next(Forbidden("The person who created this API key doesn't have permission to do that."));
    }
    next();
  };
  return Object.assign(middleware, { capabilities: required });
}
