import type { NextFunction, Request, Response } from 'express';
import { MulterError } from 'multer';
import { HttpError, toHttpError } from '../utils/http-error';
import { createLogger } from '../utils/logger';

const log = createLogger('http');

export function notFoundHandler(req: Request, res: Response) {
  res.status(404).json({
    message: `Cannot ${req.method} ${req.originalUrl.split('?')[0]}`,
    error: 'Not Found',
    statusCode: 404,
  });
}

/** Errors raised by body parsing and uploads, before a controller runs. */
function requestError(err: unknown): HttpError | null {
  const e = err as { type?: string; status?: number; statusCode?: number } | null;
  if (e?.type === 'entity.parse.failed')
    return new HttpError(400, 'The information sent could not be read. Refresh the page and try again.');
  if (e?.type === 'entity.too.large') return new HttpError(413, 'This is too much to save at once. Make it smaller and try again.');
  if (e?.type === 'encoding.unsupported' || e?.type === 'charset.unsupported') {
    return new HttpError(415, 'The information sent could not be read. Refresh the page and try again.');
  }

  if (err instanceof MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') return new HttpError(413, 'This file is too large. Choose a smaller file.');
    if (err.code === 'LIMIT_UNEXPECTED_FILE')
      return new HttpError(400, 'The file could not be uploaded. Refresh the page and try again.');
    return new HttpError(400, 'The upload could not be read. Try again, or choose another file.');
  }

  const status = e?.status ?? e?.statusCode;
  if (!(err instanceof HttpError) && typeof status === 'number' && status >= 400 && status < 500) {
    return new HttpError(status, (err as Error).message || 'Something in this request is not right. Check the details and try again.');
  }
  return null;
}

// Express needs the 4-arg signature to treat this as an error handler.
export function errorHandler(err: unknown, req: Request, res: Response, _next: NextFunction) {
  if (res.headersSent) {
    req.socket.destroy();
    return;
  }
  const http = requestError(err) ?? toHttpError(err);
  // Never leak internals (SQL, stack traces) to clients; they only go to the log.
  if (http.status >= 500)
    log.error(`${req.method} ${req.originalUrl} -> ${http.status}`, http.cause ?? http);
  res.status(http.status).json(http.toJSON());
}
