/**
 * Beekiri's own extensions (made and published by Beekiri, free). Features that ship with
 * Beekiri itself (BeeSEO, BeeCookies, analytics, translation…) are part of core, not
 * extensions. A public extension API for developers is planned (see README).
 */
import bookingsInfo from '../bookings/extension.json';
import formsInfo from '../forms/extension.json';
import shopInfo from '../shop/extension.json';

export type ExtensionKind = 'built-in' | 'package';
export type ExtensionStatus = 'active' | 'inactive' | 'available' | 'coming-soon';

export type ExtensionEntry = {
  slug: string;
  name: string;
  /** One line for lists and cards. */
  tagline: string;
  /** Paragraphs for the details view. */
  description: string[];
  features: string[];
  version: string;
  /** Minimum Beekiri core version. */
  requires: string;
  author: 'Beekiri';
  category: 'Commerce' | 'Marketing' | 'Analytics' | 'Content' | 'Performance' | 'Forms' | 'Bookings';
  /** Admin icon key (the admin maps it to an icon). */
  icon: 'cart' | 'form' | 'calendar';
  /** Brand color for the icon tile and banner. */
  color: string;
  kind: ExtensionKind;
  status: ExtensionStatus;
  /** Admin path of the extension's own screen. */
  settingsPath?: string;
  changelog: { version: string; notes: string[] }[];
};

/**
 * Each extension's description, version and changelog live in its own folder (extension.json),
 * so an extension update (scripts/extension-update.mjs) brings its new version number with it.
 * Order: as listed in Add Extensions.
 */
export const EXTENSION_CATALOG: ExtensionEntry[] = [formsInfo, bookingsInfo, shopInfo] as ExtensionEntry[];
