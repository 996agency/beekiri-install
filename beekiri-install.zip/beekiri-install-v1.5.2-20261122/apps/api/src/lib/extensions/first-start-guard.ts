/**
 * Imported first by server.ts, before any other module loads: if an extension update just
 * switched this server to a new version, any crash from here on (even a module failing to load)
 * puts the previous version back and starts again (see update-state.ts).
 */
import { guardAgainstCrashes } from './update-state';

if (process.env.BEEKIRI_SMOKE_TEST !== '1') guardAgainstCrashes();
