import { spawnSync } from 'child_process';
import { readdirSync, readFileSync, statSync, writeFileSync } from 'fs';
import { join, relative, sep } from 'path';
import { REPO_ROOT } from '../../config/paths';
import { RESTART_EXIT_CODE } from '../../utils/restart';

/**
 * The extension update in progress (or the last one), shared by scripts/extension-update.mjs,
 * the API and the server start: a JSON file next to the core update's .beekiri-update.json.
 */
export const EXTENSION_UPDATE_STATUS = join(REPO_ROOT, '.beekiri-extension-update.json');
export const EXTENSION_UPDATER = join(REPO_ROOT, 'scripts', 'extension-update.mjs');

/** After a new version starts, it has this long to prove itself before the previous build is removed. */
export const PROBATION_MS = 3 * 60_000;

export type ExtensionUpdateState = 'running' | 'restarting' | 'done' | 'error' | 'rolled-back';

export type ExtensionUpdateJob = {
  state: ExtensionUpdateState;
  step?: string;
  progress?: number;
  message?: string;
  detail?: string;
  slug: string;
  name?: string;
  version: string;
  fromVersion?: string;
  /** Started by the nightly automatic updates, not by a person. */
  auto?: boolean;
  actorId?: string | null;
  pid?: number;
  startedAt?: string;
  updatedAt?: string;
  finishedAt?: string;
  /** Builds switched to the new version, with where the previous ones are kept. */
  swap?: { live: string; previous: string }[];
  probationUntil?: string;
  /** Status code of key addresses just before the switch, checked again once the new version runs. */
  healthBefore?: Record<string, number>;
  healthChecked?: boolean;
  /** Set once the people who manage extensions were told how it ended. */
  notified?: boolean;
  /** Attempts per `slug@version`, so a version that fails is not retried every night. */
  history?: Record<string, { attempts: number; lastError?: string | null; lastAt?: string }>;
};

export function readUpdateJob(): ExtensionUpdateJob | null {
  try {
    const job = JSON.parse(readFileSync(EXTENSION_UPDATE_STATUS, 'utf8')) as ExtensionUpdateJob;
    return job && typeof job === 'object' && typeof job.slug === 'string' ? job : null;
  } catch {
    return null;
  }
}

export function writeUpdateJob(patch: Partial<ExtensionUpdateJob>, base?: ExtensionUpdateJob | null): ExtensionUpdateJob {
  const next = { ...(base === undefined ? readUpdateJob() : base), ...patch, updatedAt: new Date().toISOString() } as ExtensionUpdateJob;
  writeFileSync(EXTENSION_UPDATE_STATUS, JSON.stringify(next, null, 2));
  return next;
}

/** The updater reports at least this often (each build step is limited to 30 minutes). */
const UPDATER_SILENT_MAX_MS = 35 * 60_000;

/** Is the updater process of this job still running? */
export function updaterAlive(job: ExtensionUpdateJob | null): boolean {
  if (!job?.pid) return false;
  // After a restart another process can have the same number.
  if (Date.now() - Date.parse(job.updatedAt ?? '') > UPDATER_SILENT_MAX_MS) return false;
  try {
    process.kill(job.pid, 0);
    return true;
  } catch {
    return false;
  }
}

/** The new version is live but may still be swapped back (its previous builds are kept). */
export function canStillRollBack(job: ExtensionUpdateJob | null): boolean {
  if (!job?.swap?.length) return false;
  if (job.state === 'restarting') return true;
  return job.state === 'done' && Date.parse(job.probationUntil ?? '') > Date.now();
}

/**
 * The server could not start (or crashed right after starting) on a version an extension
 * update just switched on: put the previous version back. True when the server should start
 * again (it then runs the version that worked before).
 */
export function rollBackExtensionUpdate(): boolean {
  const job = readUpdateJob();
  if (!canStillRollBack(job)) return false;
  const res = spawnSync(process.execPath, [EXTENSION_UPDATER, '--rollback'], {
    cwd: REPO_ROOT,
    stdio: 'inherit',
    timeout: 2 * 60_000,
  });
  return res.status === 0 && readUpdateJob()?.state === 'rolled-back';
}

let crashGuard: ((error: Error) => void) | null = null;

/**
 * While a new version may still be swapped back (first start and the minutes after), a crash
 * puts the previous version back and starts the server again instead of leaving the site down.
 */
export function guardAgainstCrashes(): void {
  if (crashGuard || !canStillRollBack(readUpdateJob())) return;
  crashGuard = (error) => {
    console.error('Beekiri stopped right after an extension update:', error);
    process.exit(rollBackExtensionUpdate() ? RESTART_EXIT_CODE : 1);
  };
  process.on('uncaughtException', crashGuard);
}

export function stopGuardingAgainstCrashes(): void {
  if (crashGuard) process.off('uncaughtException', crashGuard);
  crashGuard = null;
}

/**
 * `BEEKIRI_SMOKE_TEST=1 node dist-staged/server.js` (run by the extension updater): load every
 * part of a freshly built server once, without connecting, migrating or listening. A module
 * that fails to load stops the update before the site ever runs it.
 */
export async function runSmokeTest(): Promise<void> {
  const { createApp } = await import('../../app');
  createApp();
  const distRoot = join(__dirname, '..', '..');
  const skip = (rel: string) =>
    rel === 'server.js' || rel === 'security-cli.js' || rel === 'db/cli.js' || rel.startsWith('db/migrations/');
  const files: string[] = [];
  const walk = (dir: string) => {
    for (const name of readdirSync(dir)) {
      const full = join(dir, name);
      if (statSync(full).isDirectory()) walk(full);
      else if (name.endsWith('.js')) files.push(full);
    }
  };
  walk(distRoot);
  for (const file of files.sort()) {
    if (skip(relative(distRoot, file).split(sep).join('/'))) continue;
    await import(file);
  }
}
