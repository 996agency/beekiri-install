import { z } from 'zod';

/**
 * Courier connections (Shop → Settings → Shipping → Couriers): how the shop talks to a courier's
 * system to send it orders and to follow parcels. One configurable connection works with most
 * couriers that have an API; a preset (DHL) fills in everything except the key. Pure; no I/O.
 */

export const COURIER_PRESETS = ['custom', 'dhl'] as const;
export type CourierPreset = (typeof COURIER_PRESETS)[number];

/** What a courier status means for the order. `ignore` leaves the order as it is. */
export const COURIER_MEANINGS = ['in_transit', 'out_for_delivery', 'delivered', 'problem', 'returned', 'ignore'] as const;
export type CourierMeaning = (typeof COURIER_MEANINGS)[number];
/** Where a parcel is, as kept on the order (`created`: the courier has it on file, not picked up yet). */
export type CourierStage = 'created' | Exclude<CourierMeaning, 'ignore'>;

export const COURIER_CHECK_MINUTES = [30, 60, 180, 360, 720] as const;

const path = z.string().trim().max(200).default('');
/** A path on the courier's address ("/shipments/{{tracking}}") or a full https:// address. */
const requestPath = (fallback: string) => z.string().trim().max(500).default(fallback);

export const courierRuleSchema = z
  .object({
    match: z.enum(['is', 'contains']).default('contains'),
    value: z.string().trim().min(1).max(120),
    meaning: z.enum(COURIER_MEANINGS),
  })
  .strict();
export type CourierRule = z.infer<typeof courierRuleSchema>;

/** First match wins, so the narrow phrases ("not delivered") come before the broad ones ("delivered"). */
export const DEFAULT_COURIER_RULES: CourierRule[] = [
  { match: 'contains', value: 'out for delivery', meaning: 'out_for_delivery' },
  { match: 'contains', value: 'not delivered', meaning: 'problem' },
  { match: 'contains', value: 'undeliver', meaning: 'problem' },
  { match: 'contains', value: 'fail', meaning: 'problem' },
  { match: 'contains', value: 'return', meaning: 'returned' },
  { match: 'contains', value: 'delivered', meaning: 'delivered' },
  { match: 'contains', value: 'transit', meaning: 'in_transit' },
  { match: 'contains', value: 'picked up', meaning: 'in_transit' },
  { match: 'contains', value: 'shipped', meaning: 'in_transit' },
];

export const DEFAULT_CREATE_BODY = JSON.stringify(
  {
    reference: '{{order.reference}}',
    receiver: {
      name: '{{customer.name}}',
      phone: '{{customer.phone}}',
      email: '{{customer.email}}',
      address: '{{address.line1}}',
      address2: '{{address.line2}}',
      city: '{{address.city}}',
      postcode: '{{address.postcode}}',
      country: '{{address.country}}',
    },
    contents: '{{items.summary}}',
    weightKg: '{{items.weightKg}}',
    cashOnDelivery: '{{cod.amount}}',
    note: '{{order.note}}',
  },
  null,
  2,
);

export const courierConfigSchema = z
  .object({
    /** The courier's API address, e.g. https://api.courier.com/v1 (requests add their path to it). */
    baseUrl: z.string().trim().max(300).default(''),
    auth: z
      .object({
        type: z.enum(['none', 'header', 'bearer', 'basic', 'query']).default('header'),
        /** Header name (header), parameter name (query) or user name (basic). */
        name: z.string().trim().max(120).default(''),
      })
      .strict()
      .default({}),
    /** Fixed extra headers some couriers ask for (client number, language…). Not secret. */
    headers: z
      .array(
        z
          .object({
            name: z.string().trim().min(1).max(80).regex(/^[A-Za-z0-9-]+$/, 'Use letters, numbers and dashes in header names.'),
            value: z.string().max(500),
          })
          .strict(),
      )
      .max(10)
      .default([]),
    /** The courier's public tracking page, with {{tracking}} where the number goes. */
    trackingPage: z.string().trim().max(500).default(''),
    /** Sending orders: create the shipment in the courier's system and read back the tracking number. */
    create: z
      .object({
        enabled: z.boolean().default(false),
        method: z.enum(['POST', 'PUT']).default('POST'),
        path: requestPath('/shipments'),
        format: z.enum(['json', 'form']).default('json'),
        body: z.string().max(20_000).default(DEFAULT_CREATE_BODY),
        trackingPath: path,
        idPath: path,
        labelPath: path,
        /** Send automatically when an order is ready to ship (only orders whose shipping method uses this courier). */
        auto: z.boolean().default(false),
      })
      .strict()
      .default({}),
    /** Following parcels: ask the courier where a parcel is. */
    track: z
      .object({
        enabled: z.boolean().default(true),
        method: z.enum(['GET', 'POST']).default('GET'),
        path: requestPath('/shipments/{{tracking}}'),
        body: z.string().max(5000).default(''),
        statusPath: path,
        textPath: path,
        eventsPath: path,
        eventTextPath: path,
        eventTimePath: path,
        eventPlacePath: path,
        everyMinutes: z
          .number()
          .int()
          .refine((n) => (COURIER_CHECK_MINUTES as readonly number[]).includes(n), 'Choose how often from the list.')
          .default(180),
      })
      .strict()
      .default({}),
    /** Status updates the courier sends to the shop's own address. */
    push: z
      .object({
        enabled: z.boolean().default(false),
        /** When one message holds several updates: where the list is. */
        listPath: path,
        trackingPath: path,
        statusPath: path,
        textPath: path,
        timePath: path,
        placePath: path,
      })
      .strict()
      .default({}),
    rules: z.array(courierRuleSchema).max(60).default(DEFAULT_COURIER_RULES),
    /** Most requests a day the courier allows (0 = no limit). */
    dailyLimit: z.number().int().min(0).max(1_000_000).default(0),
  })
  .strict();
export type CourierConfig = z.infer<typeof courierConfigSchema>;

type PresetDef = {
  label: string;
  /** Pause between two requests (DHL allows one every 5 seconds). */
  minGapMs: number;
  /** Everything the preset decides; the shop owner only sets the key and how often to check. */
  fixed: (cfg: CourierConfig) => CourierConfig;
};

export const COURIER_PRESET_DEFS: Record<CourierPreset, PresetDef> = {
  custom: { label: 'Other courier', minGapMs: 0, fixed: (cfg) => cfg },
  dhl: {
    label: 'DHL',
    minGapMs: 5_000,
    fixed: (cfg) => ({
      baseUrl: 'https://api-eu.dhl.com',
      auth: { type: 'header', name: 'DHL-API-Key' },
      headers: [],
      trackingPage: cfg.trackingPage || 'https://www.dhl.com/global-en/home/tracking.html?tracking-id={{tracking}}&submit=1',
      create: { ...courierConfigSchema.shape.create.parse({}), enabled: false, auto: false },
      track: {
        enabled: true,
        method: 'GET',
        path: '/track/shipments?trackingNumber={{tracking}}',
        body: '',
        statusPath: 'shipments.0.status.statusCode',
        textPath: 'shipments.0.status.description|shipments.0.status.status',
        eventsPath: 'shipments.0.events',
        eventTextPath: 'description|status',
        eventTimePath: 'timestamp',
        eventPlacePath: 'location.address.addressLocality',
        everyMinutes: cfg.track.everyMinutes,
      },
      push: { ...courierConfigSchema.shape.push.parse({}), enabled: false },
      rules: [
        { match: 'is', value: 'pre-transit', meaning: 'ignore' },
        { match: 'is', value: 'transit', meaning: 'in_transit' },
        { match: 'is', value: 'delivered', meaning: 'delivered' },
        { match: 'is', value: 'failure', meaning: 'problem' },
      ],
      dailyLimit: 250,
    }),
  },
};

/** The settings a connection actually runs with (a preset's fixed parts win over what is stored). */
export function effectiveConfig(preset: string, stored: unknown): CourierConfig {
  const parsed = courierConfigSchema.safeParse(stored && typeof stored === 'object' ? stored : {});
  const cfg = parsed.success ? parsed.data : courierConfigSchema.parse({});
  const def = COURIER_PRESET_DEFS[(COURIER_PRESETS as readonly string[]).includes(preset) ? (preset as CourierPreset) : 'custom'];
  return def.fixed(cfg);
}

export function presetGap(preset: string): number {
  return COURIER_PRESET_DEFS[preset as CourierPreset]?.minGapMs ?? 0;
}

/** Placeholders for "What to send", the request paths and the tracking page (shown in the admin). */
export const COURIER_PLACEHOLDERS: { key: string; label: string }[] = [
  { key: 'order.reference', label: 'Order number as customers see it, e.g. #1001' },
  { key: 'order.number', label: 'Order number without the prefix, e.g. 1001' },
  { key: 'order.date', label: 'Order date, e.g. 2026-11-19' },
  { key: 'order.total', label: 'Order total, e.g. 25.5' },
  { key: 'order.totalCents', label: 'Order total in cents, e.g. 2550' },
  { key: 'order.subtotal', label: 'Products total' },
  { key: 'order.shipping', label: 'Shipping cost paid by the customer' },
  { key: 'order.currency', label: 'Currency code, e.g. EUR' },
  { key: 'order.note', label: 'The customer’s order note' },
  { key: 'order.shippingMethod', label: 'Shipping method chosen at checkout' },
  { key: 'cod.amount', label: 'Cash to collect on delivery (0 when already paid)' },
  { key: 'cod.amountCents', label: 'Cash to collect, in cents' },
  { key: 'payment.cod', label: 'true for cash on delivery, otherwise false' },
  { key: 'payment.method', label: 'cod, bank_transfer or stripe' },
  { key: 'customer.name', label: 'Recipient’s full name' },
  { key: 'customer.firstName', label: 'Recipient’s first name' },
  { key: 'customer.lastName', label: 'Recipient’s last name' },
  { key: 'customer.company', label: 'Recipient’s company' },
  { key: 'customer.phone', label: 'Customer’s phone number' },
  { key: 'customer.email', label: 'Customer’s email address' },
  { key: 'address.line1', label: 'Street and house number' },
  { key: 'address.line2', label: 'Apartment, floor…' },
  { key: 'address.street', label: 'Both address lines together' },
  { key: 'address.city', label: 'Town or city' },
  { key: 'address.postcode', label: 'Postcode' },
  { key: 'address.state', label: 'State or county' },
  { key: 'address.country', label: 'Country code, e.g. MK' },
  { key: 'address.countryName', label: 'Country name, e.g. North Macedonia' },
  { key: 'items.count', label: 'Number of items' },
  { key: 'items.summary', label: 'Items, e.g. 2 × T-shirt, 1 × Cap' },
  { key: 'items.weightKg', label: 'Total weight in kg' },
  { key: 'items.weightGrams', label: 'Total weight in grams' },
  { key: 'store.name', label: 'Your store name (the sender)' },
  { key: 'store.email', label: 'Your store email' },
  { key: 'store.line1', label: 'Your store address' },
  { key: 'store.city', label: 'Your store’s town or city' },
  { key: 'store.postcode', label: 'Your store’s postcode' },
  { key: 'store.country', label: 'Your store’s country code' },
  { key: 'today', label: 'Today’s date, e.g. 2026-11-19' },
  { key: 'tracking', label: 'Tracking number (following parcels and the tracking page)' },
  { key: 'shipmentId', label: 'The courier’s own shipment ID (following parcels)' },
];
