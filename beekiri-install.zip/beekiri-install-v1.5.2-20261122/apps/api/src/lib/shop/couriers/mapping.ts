import { COURIER_PLACEHOLDERS, type CourierMeaning, type CourierRule } from './config';

/**
 * Reading a courier's answers and filling in what Beekiri sends: paths into JSON, {{placeholders}},
 * status rules and dates in the formats couriers use. Pure; no I/O.
 */

export type Vars = Record<string, string | number | boolean>;

export type CourierEvent = { at: string | null; text: string; place: string };

/* ── Reading answers ─────────────────────────────────────────────────── */

function readOne(data: unknown, path: string): unknown {
  if (!path) return data;
  const keys = path.replace(/\[(-?\d+)\]/g, '.$1').split('.').filter(Boolean);
  let cur: unknown = data;
  for (const k of keys) {
    if (cur === null || cur === undefined) return undefined;
    if (Array.isArray(cur)) {
      if (!/^-?\d+$/.test(k)) return undefined;
      const i = Number(k);
      cur = cur[i < 0 ? cur.length + i : i];
    } else if (typeof cur === 'object') {
      if (!Object.prototype.hasOwnProperty.call(cur, k)) return undefined;
      cur = (cur as Record<string, unknown>)[k];
    } else {
      return undefined;
    }
  }
  return cur;
}

const present = (v: unknown) => v !== undefined && v !== null && v !== '';

/**
 * Value at `a.b.0.c` (also `a.b[0].c`; -1 is the last item). `a|b` takes the first path that has a
 * value. An empty path is the whole answer.
 */
export function readPath(data: unknown, path: string): unknown {
  const alternatives = (path ?? '').split('|').map((p) => p.trim());
  for (const alt of alternatives) {
    const v = readOne(data, alt);
    if (present(v)) return v;
  }
  return undefined;
}

/** Readable text of a value: numbers and booleans as written, an object as its plain values joined. */
export function asText(v: unknown, max = 300): string {
  if (typeof v === 'string') return v.replace(/\s+/g, ' ').trim().slice(0, max);
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  if (v && typeof v === 'object' && !Array.isArray(v)) {
    const parts = Object.values(v as Record<string, unknown>)
      .filter((x) => typeof x === 'string' || typeof x === 'number')
      .map((x) => String(x).trim())
      .filter(Boolean);
    return parts.join(', ').slice(0, max);
  }
  return '';
}

/** ISO time from what couriers send: ISO, "2026-11-19 14:22", "19.11.2026 14:22", or seconds/ms since 1970. */
export function parseTime(v: unknown): string | null {
  const fromMs = (ms: number) => {
    const d = new Date(ms);
    return Number.isFinite(d.getTime()) && d.getFullYear() > 2000 && d.getFullYear() < 2100 ? d.toISOString() : null;
  };
  if (typeof v === 'number' && Number.isFinite(v)) return fromMs(v < 1e12 ? v * 1000 : v);
  if (typeof v !== 'string') return null;
  const s = v.trim();
  if (!s) return null;
  if (/^\d{10}(\d{3})?$/.test(s)) return fromMs(s.length === 10 ? Number(s) * 1000 : Number(s));
  // Day first with dots (or slashes when month-first makes no sense): common across Europe.
  const dayFirst = (m: RegExpMatchArray) =>
    fromMs(new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]), Number(m[4] ?? 0), Number(m[5] ?? 0), Number(m[6] ?? 0)).getTime());
  const dotted = s.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})\.?(?:[ T,]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
  if (dotted) return dayFirst(dotted);
  const iso = Date.parse(s.includes(' ') && /^\d{4}-\d{2}-\d{2} \d/.test(s) ? s.replace(' ', 'T') : s);
  if (Number.isFinite(iso)) return fromMs(iso);
  const slashed = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:[ T,]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
  if (slashed) return dayFirst(slashed);
  return null;
}

/** The meaning of a courier status by the shop owner's rules (first match wins); null = no rule. */
export function meaningOf(status: string, rules: CourierRule[]): CourierMeaning | null {
  const s = status.trim().toLowerCase();
  if (!s) return null;
  for (const rule of rules) {
    const value = rule.value.trim().toLowerCase();
    if (!value) continue;
    if (rule.match === 'is' ? s === value : s.includes(value)) return rule.meaning;
  }
  return null;
}

/** A list of updates from an answer, newest first (when they have times), at most `max`. */
export function readEvents(
  data: unknown,
  paths: { listPath: string; textPath: string; timePath: string; placePath: string },
  max = 30,
): CourierEvent[] {
  if (!paths.listPath) return [];
  const list = readPath(data, paths.listPath);
  if (!Array.isArray(list)) return [];
  const events = list
    .slice(0, 200)
    .map((item) => ({
      at: parseTime(readPath(item, paths.timePath)),
      text: asText(readPath(item, paths.textPath || '')),
      place: paths.placePath ? asText(readPath(item, paths.placePath), 120) : '',
    }))
    .filter((e) => e.text);
  if (events.every((e) => e.at)) events.sort((a, b) => Date.parse(b.at!) - Date.parse(a.at!));
  return events.slice(0, max);
}

/* ── Filling in what is sent ─────────────────────────────────────────── */

const PLACEHOLDER = /\{\{\s*([a-zA-Z][a-zA-Z0-9_.]*)\s*(\|\s*text\s*)?\}\}/g;
const KNOWN = new Set(COURIER_PLACEHOLDERS.map((p) => p.key));

/** Placeholders a template uses that Beekiri does not know (typos). */
export function unknownPlaceholders(text: string): string[] {
  const out = new Set<string>();
  for (const m of text.matchAll(PLACEHOLDER)) if (!KNOWN.has(m[1]!)) out.add(m[1]!);
  return [...out];
}

/** {{key}} → value in a piece of text; `encode` escapes values (e.g. for an address). Unknown keys become ''. */
export function fillText(text: string, vars: Vars, encode: (s: string) => string = (s) => s): string {
  return text.replace(PLACEHOLDER, (_m, key: string) => encode(key in vars ? String(vars[key]) : ''));
}

/**
 * A JSON template with its values filled in. A string that is exactly one placeholder takes the
 * value's own type (a number stays a number); `{{key|text}}` keeps it as text.
 */
export function fillJson(template: unknown, vars: Vars): unknown {
  if (typeof template === 'string') {
    const whole = template.match(/^\{\{\s*([a-zA-Z][a-zA-Z0-9_.]*)\s*(\|\s*text\s*)?\}\}$/);
    if (whole && !whole[2]) return whole[1]! in vars ? vars[whole[1]!] : '';
    return fillText(template, vars);
  }
  if (Array.isArray(template)) return template.map((v) => fillJson(v, vars));
  if (template && typeof template === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(template)) out[k] = fillJson(v, vars);
    return out;
  }
  return template;
}

export class TemplateError extends Error {}

const JSON_PROBLEMS: [RegExp, string][] = [
  [/end of JSON input/i, 'it ends too early, so a } or ] is missing at the end'],
  [/Expected double-quoted property name/i, 'a name is not in double quotes, or there is one comma too many'],
  [/Expected property name or '\}'/i, 'a name is not in double quotes'],
  [/Expected ':' after property name/i, 'a colon is missing after a name'],
  [/Expected ',' or '\}' after property value/i, 'a comma or a closing } is missing'],
  [/Expected ',' or '\]' after array element/i, 'a comma or a closing ] is missing'],
  [/non-whitespace character after JSON/i, 'there is something after the last closing bracket'],
  [/Bad control character/i, 'a value in quotes runs over a line break'],
];

/** Parses "What to send"; the error says what is wrong and where, in plain words. */
export function parseTemplate(body: string): unknown {
  if (!body.trim()) return {};
  try {
    return JSON.parse(body);
  } catch (error) {
    const raw = (error as Error).message;
    const where = raw.match(/\(line (\d+) column (\d+)\)/);
    const what =
      JSON_PROBLEMS.find(([re]) => re.test(raw))?.[1] ??
      (raw.match(/Unexpected token '?([^',\s]+)'?/) ? `there is an unexpected “${raw.match(/Unexpected token '?([^',\s]+)'?/)![1]}”` : 'the quotes, commas or brackets do not match');
    throw new TemplateError(`“What to send” is not valid${where ? ` at line ${where[1]}, column ${where[2]}` : ''}: ${what}.`);
  }
}

/** Request body from a template: JSON as is, or the template's top-level fields as a form. */
export function buildBody(template: string, format: 'json' | 'form', vars: Vars): { body: string; contentType: string } {
  const filled = fillJson(parseTemplate(template), vars);
  if (format === 'form') {
    const form = new URLSearchParams();
    if (filled && typeof filled === 'object' && !Array.isArray(filled)) {
      for (const [k, v] of Object.entries(filled)) {
        form.append(k, v !== null && typeof v === 'object' ? JSON.stringify(v) : v === undefined || v === null ? '' : String(v));
      }
    }
    return { body: form.toString(), contentType: 'application/x-www-form-urlencoded' };
  }
  return { body: JSON.stringify(filled), contentType: 'application/json' };
}

/* ── Order details for templates ─────────────────────────────────────── */

type Address = Partial<Record<'firstName' | 'lastName' | 'company' | 'line1' | 'line2' | 'city' | 'state' | 'postcode' | 'country', string>>;

export type OrderForCourier = {
  id: string;
  number: number;
  reference: string;
  placedAt: Date;
  currency: string;
  total: number;
  subtotal: number;
  shippingTotal: number;
  paymentMethod: string;
  paymentStatus: string;
  email: string;
  phone: string;
  billing: Address;
  shipping: Address | null;
  shipToDifferent: boolean;
  customerNote: string;
  shippingMethodTitle: string;
};

const day = (d: Date) => d.toISOString().slice(0, 10);

export function orderVariables(input: {
  order: OrderForCourier;
  items: { name: string; qty: number }[];
  weightGrams: number;
  /** Decimals of the order currency (2 for EUR, 0 for JPY). */
  decimals: number;
  store: { name: string; email: string; address: Address };
  countryName: (code: string) => string;
  now?: Date;
}): Vars {
  const { order, items, decimals, store } = input;
  const factor = 10 ** decimals;
  const major = (minor: number) => Number((minor / factor).toFixed(decimals));
  const to: Address = order.shipToDifferent && order.shipping && order.shipping.line1 ? order.shipping : order.billing;
  const s = (v: string | undefined) => (v ?? '').trim();
  const cod = order.paymentMethod === 'cod' && order.paymentStatus !== 'paid' ? order.total : 0;
  const count = items.reduce((a, i) => a + i.qty, 0);
  return {
    'order.reference': order.reference,
    'order.number': order.number,
    'order.id': order.id,
    'order.date': day(order.placedAt),
    'order.total': major(order.total),
    'order.totalCents': order.total,
    'order.subtotal': major(order.subtotal),
    'order.shipping': major(order.shippingTotal),
    'order.currency': order.currency,
    'order.note': s(order.customerNote),
    'order.shippingMethod': s(order.shippingMethodTitle),
    'cod.amount': major(cod),
    'cod.amountCents': cod,
    'payment.cod': order.paymentMethod === 'cod',
    'payment.method': order.paymentMethod,
    'customer.name': [s(to.firstName), s(to.lastName)].filter(Boolean).join(' '),
    'customer.firstName': s(to.firstName),
    'customer.lastName': s(to.lastName),
    'customer.company': s(to.company),
    'customer.phone': s(order.phone),
    'customer.email': s(order.email),
    'address.line1': s(to.line1),
    'address.line2': s(to.line2),
    'address.street': [s(to.line1), s(to.line2)].filter(Boolean).join(', '),
    'address.city': s(to.city),
    'address.postcode': s(to.postcode),
    'address.state': s(to.state),
    'address.country': s(to.country).toUpperCase(),
    'address.countryName': to.country ? input.countryName(to.country) : '',
    'items.count': count,
    'items.summary': items
      .map((i) => `${i.qty} × ${i.name}`)
      .join(', ')
      .slice(0, 300),
    'items.weightKg': Number((input.weightGrams / 1000).toFixed(3)),
    'items.weightGrams': input.weightGrams,
    'store.name': s(store.name),
    'store.email': s(store.email),
    'store.line1': s(store.address.line1),
    'store.city': s(store.address.city),
    'store.postcode': s(store.address.postcode),
    'store.country': s(store.address.country).toUpperCase(),
    today: day(input.now ?? new Date()),
  };
}

/** Made-up order for the "Preview" in the admin before there are real orders. */
export function sampleVariables(store: { name: string; email: string; address: Address }, currency: string, decimals: number): Vars {
  return orderVariables({
    order: {
      id: 'sample-order',
      number: 1001,
      reference: '#1001',
      placedAt: new Date(),
      currency,
      total: 2550 * 10 ** Math.max(0, decimals - 2),
      subtotal: 2250 * 10 ** Math.max(0, decimals - 2),
      shippingTotal: 300 * 10 ** Math.max(0, decimals - 2),
      paymentMethod: 'cod',
      paymentStatus: 'unpaid',
      email: 'ana@example.com',
      phone: '+389 70 123 456',
      billing: { firstName: 'Ana', lastName: 'Petrovska', company: '', line1: 'Partizanska 12', line2: 'Floor 3', city: 'Skopje', state: '', postcode: '1000', country: 'MK' },
      shipping: null,
      shipToDifferent: false,
      customerNote: 'Please call before delivery.',
      shippingMethodTitle: 'Standard delivery',
    },
    items: [
      { name: 'Linen shirt', qty: 2 },
      { name: 'Canvas tote', qty: 1 },
    ],
    weightGrams: 950,
    decimals,
    store,
    countryName: (code) => (code === 'MK' ? 'North Macedonia' : code),
  });
}
