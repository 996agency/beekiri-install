import { lookup as dnsLookup, type LookupAddress } from 'dns';
import { request as httpRequest, type IncomingMessage } from 'http';
import { request as httpsRequest } from 'https';
import { isIP, type LookupFunction } from 'net';
import { isPublicAddress } from '../../beequeen/remote-image';

/**
 * Requests to a courier's system, safely: the address comes from shop settings, so it must be
 * https and every connection must go to a public address (checked when connecting, so DNS can't
 * be switched in between). Answers are size-capped and time-limited; redirects are not followed.
 */

const TIMEOUT_MS = 15_000;
const MAX_BYTES = 2 * 1024 * 1024;

/** Test servers talk to a local mock courier; real sites never set this. */
export const allowPrivateCouriers = () => process.env.BEEKIRI_COURIER_ALLOW_PRIVATE === '1';

export type CourierErrorKind = 'address' | 'network' | 'timeout' | 'auth' | 'not_found' | 'rate_limit' | 'server' | 'rejected' | 'redirect';

export class CourierError extends Error {
  constructor(
    readonly kind: CourierErrorKind,
    message: string,
    readonly status = 0,
    /** The start of the courier's answer, for the admin's test results. */
    readonly answer = '',
  ) {
    super(message);
  }

  /** Nothing reached the courier (or it said it is busy), so sending again cannot create a second shipment. */
  get safeToResend(): boolean {
    return this.kind === 'network' || this.kind === 'rate_limit' || (this.kind === 'server' && this.status === 503);
  }

  /** Worth asking again later. */
  get temporary(): boolean {
    return this.kind === 'network' || this.kind === 'timeout' || this.kind === 'rate_limit' || this.kind === 'server';
  }
}

export type CourierAnswer = { status: number; data: unknown; text: string };

const publicLookup: LookupFunction = (hostname, options, callback) => {
  dnsLookup(hostname, { ...options, all: true }, (error, addresses) => {
    if (error) return callback(error, '', 0);
    const list = addresses as unknown as LookupAddress[];
    if (!list.length || list.some((a) => !isPublicAddress(a.address))) {
      return callback(Object.assign(new Error(`${hostname} is not a public address.`), { code: 'EPRIVATE' }), '', 0);
    }
    if ((options as { all?: boolean }).all) return (callback as unknown as (e: null, a: LookupAddress[]) => void)(null, list);
    return callback(null, list[0]!.address, list[0]!.family);
  });
};

/** The address a request goes to: the courier's API address plus a path, or a full address. */
export function courierUrl(baseUrl: string, path: string): URL {
  const raw = /^https?:\/\//i.test(path) ? path : `${baseUrl.replace(/\/+$/, '')}${path.startsWith('/') || path.startsWith('?') || !path ? '' : '/'}${path}`;
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new CourierError('address', 'The courier’s address is not complete. Enter it like https://api.courier.com/v1.');
  }
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' && allowPrivateCouriers())) {
    throw new CourierError('address', 'Use the courier’s secure address, starting with https://.');
  }
  if (url.username || url.password) throw new CourierError('address', 'Put the user name and password in the sign-in fields, not in the address.');
  assertPublicHost(url);
  return url;
}

/** An address written as numbers is never looked up, so it is checked here (the lookup checks names). */
function assertPublicHost(url: URL) {
  const host = url.hostname.replace(/^\[|\]$/g, '');
  if (!allowPrivateCouriers() && isIP(host) && !isPublicAddress(host)) {
    throw new CourierError('address', 'The courier’s address points to a private network. Use the address the courier gave you for its API.');
  }
}

/** The same error with the key taken out, wherever the courier repeated it. */
export function withoutSecret(error: CourierError, secret: string): CourierError {
  if (!secret || secret.length < 4) return error;
  const hide = (t: string) => t.split(secret).join('••••••••').split(encodeURIComponent(secret)).join('••••••••');
  return new CourierError(error.kind, hide(error.message), error.status, hide(error.answer));
}

/** The courier's own words from an error answer ("message", "error"…), if it gave any. */
function courierMessage(data: unknown, text: string): string {
  const pick = (v: unknown): string => (typeof v === 'string' ? v : v && typeof v === 'object' ? pick((v as Record<string, unknown>).message ?? (v as Record<string, unknown>).description) : '');
  if (data && typeof data === 'object') {
    const o = data as Record<string, unknown>;
    const found = pick(o.message) || pick(o.error) || pick(o.detail) || pick(o.title) || pick(Array.isArray(o.errors) ? o.errors[0] : '');
    if (found) return found.replace(/\s+/g, ' ').trim().slice(0, 240);
  }
  const plain = text.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
  return plain.length && plain.length <= 240 ? plain : '';
}

function describe(status: number, data: unknown, text: string): CourierError {
  const said = courierMessage(data, text);
  const answer = text.slice(0, 2000);
  const tail = said ? ` It said: “${said}”` : '';
  if (status === 401 || status === 403) {
    return new CourierError('auth', `The courier did not accept the key (${status}). Check the key and how it is sent.${tail}`, status, answer);
  }
  if (status === 404) return new CourierError('not_found', `The courier could not find it (404).${tail}`, status, answer);
  if (status === 429) return new CourierError('rate_limit', 'The courier is limiting requests right now. Beekiri tries again later.', status, answer);
  if (status >= 500) return new CourierError('server', `The courier’s system had a problem (${status}). Beekiri tries again later.${tail}`, status, answer);
  return new CourierError('rejected', `The courier refused the request (${status}).${tail}`, status, answer);
}

export async function courierRequest(input: {
  url: URL;
  method: string;
  headers: Record<string, string>;
  body?: string;
  timeoutMs?: number;
}): Promise<CourierAnswer> {
  const { url } = input;
  assertPublicHost(url);
  const send = url.protocol === 'http:' ? httpRequest : httpsRequest;
  const timeoutMs = input.timeoutMs ?? TIMEOUT_MS;
  const res = await new Promise<{ status: number; headers: IncomingMessage['headers']; body: Buffer }>((resolve, reject) => {
    const req = send(
      url,
      {
        method: input.method,
        ...(allowPrivateCouriers() ? {} : { lookup: publicLookup }),
        headers: {
          'user-agent': 'Beekiri/1.0 (+shop shipping)',
          accept: 'application/json, text/plain;q=0.8, */*;q=0.5',
          ...input.headers,
          ...(input.body !== undefined ? { 'content-length': String(Buffer.byteLength(input.body)) } : {}),
        },
      },
      (incoming) => {
        const chunks: Buffer[] = [];
        let size = 0;
        incoming.on('data', (chunk: Buffer) => {
          size += chunk.length;
          if (size > MAX_BYTES) {
            req.destroy(new CourierError('rejected', 'The courier’s answer was too large to read.'));
            return;
          }
          chunks.push(chunk);
        });
        incoming.on('end', () => resolve({ status: incoming.statusCode ?? 0, headers: incoming.headers, body: Buffer.concat(chunks) }));
        incoming.on('error', reject);
      },
    );
    const timer = setTimeout(() => req.destroy(new CourierError('timeout', 'The courier did not answer in time.')), timeoutMs);
    req.on('close', () => clearTimeout(timer));
    req.on('error', (error: NodeJS.ErrnoException) => {
      if (error instanceof CourierError) return reject(error);
      if (error.code === 'EPRIVATE') return reject(new CourierError('address', 'The courier’s address points to a private network. Use the address the courier gave you for its API.'));
      if (error.code === 'ENOTFOUND' || error.code === 'EAI_AGAIN') return reject(new CourierError('network', `Could not find ${url.hostname}. Check the courier’s address.`));
      if (/certificate|SSL|TLS/i.test(error.message)) return reject(new CourierError('network', `The secure connection to ${url.hostname} failed: ${error.message}`));
      return reject(new CourierError('network', `Could not reach ${url.hostname}: ${error.message}`));
    });
    if (input.body !== undefined) req.write(input.body);
    req.end();
  });

  const text = res.body.toString('utf8');
  let data: unknown = text;
  if (text.trim()) {
    try {
      data = JSON.parse(text);
    } catch {
      data = text.trim();
    }
  } else {
    data = null;
  }
  if (res.status >= 300 && res.status < 400) {
    const where = String(res.headers.location ?? '');
    throw new CourierError('redirect', `The courier sent Beekiri to another address${where ? ` (${where.slice(0, 200)})` : ''}. Use that address in the courier settings.`, res.status);
  }
  if (res.status < 200 || res.status >= 300) throw describe(res.status, data, text);
  return { status: res.status, data, text: text.slice(0, 20_000) };
}
