import type { ShopOrder } from '../../models';
import type { FulfillmentStatus } from './constants';
import type { CourierStage } from './couriers/config';
import type { CourierEvent } from './couriers/mapping';

/**
 * Order progress for shoppers (My account, order page, emails): one timeline built
 * from the order status, payment and fulfilment data. Pure; no I/O.
 */

/**
 * The parcel's link to a courier connection (Shop → Settings → Shipping → Couriers). Staff only:
 * shoppers get the stage and the courier's updates through `buildTracking`.
 */
export type CourierLink = {
  /** ShopCourier id */
  id: string;
  /** The courier's name when it was linked (kept if the connection is deleted later). */
  name: string;
  /**
   * sending: waits to be sent automatically · following: Beekiri follows the parcel ·
   * done: delivered, returned or no longer followed · failed: could not be sent, needs the shop owner
   */
  state: 'sending' | 'following' | 'done' | 'failed';
  /** The courier's own id for the shipment. */
  shipmentId: string;
  labelUrl: string;
  stage: CourierStage | '';
  /** The courier's latest status, as it wrote it. */
  statusText: string;
  /** Newest first. */
  events: CourierEvent[];
  sentAt: string | null;
  checkedAt: string | null;
  /** When the background checks look at it next (null: not at all). */
  nextCheckAt: string | null;
  error: string;
  /** Failed attempts in a row (the checks wait longer each time). */
  failures: number;
};

export type Fulfillment = {
  status: FulfillmentStatus;
  carrier: string;
  trackingNumber: string;
  trackingUrl: string;
  packedAt: string | null;
  shippedAt: string | null;
  deliveredAt: string | null;
  courier: CourierLink | null;
};

const COURIER_STATES = ['sending', 'following', 'done', 'failed'] as const;
const COURIER_STAGES = ['created', 'in_transit', 'out_for_delivery', 'delivered', 'problem', 'returned'] as const;

const str = (v: unknown) => (typeof v === 'string' ? v : '');
const date = (v: unknown) => (typeof v === 'string' && !Number.isNaN(Date.parse(v)) ? v : null);
const isObject = (v: unknown): v is Record<string, unknown> => Boolean(v) && typeof v === 'object' && !Array.isArray(v);

function parseCourier(raw: unknown): CourierLink | null {
  if (!isObject(raw) || !str(raw.id)) return null;
  const events = Array.isArray(raw.events)
    ? raw.events
        .filter(isObject)
        .slice(0, 30)
        .map((e) => ({ at: date(e.at), text: str(e.text).slice(0, 300), place: str(e.place).slice(0, 120) }))
        .filter((e) => e.text)
    : [];
  return {
    id: str(raw.id),
    name: str(raw.name),
    state: (COURIER_STATES as readonly string[]).includes(str(raw.state)) ? (raw.state as CourierLink['state']) : 'done',
    shipmentId: str(raw.shipmentId),
    labelUrl: /^https?:\/\//i.test(str(raw.labelUrl)) ? str(raw.labelUrl) : '',
    stage: (COURIER_STAGES as readonly string[]).includes(str(raw.stage)) ? (raw.stage as CourierStage) : '',
    statusText: str(raw.statusText).slice(0, 300),
    events,
    sentAt: date(raw.sentAt),
    checkedAt: date(raw.checkedAt),
    nextCheckAt: date(raw.nextCheckAt),
    error: str(raw.error).slice(0, 500),
    failures: Number.isInteger(raw.failures) ? Math.max(0, raw.failures as number) : 0,
  };
}

export function parseFulfillment(raw: unknown): Fulfillment {
  const o = isObject(raw) ? raw : {};
  const status = ['packed', 'shipped', 'delivered'].includes(String(o.status)) ? (o.status as FulfillmentStatus) : 'unfulfilled';
  return {
    status,
    carrier: str(o.carrier),
    trackingNumber: str(o.trackingNumber),
    trackingUrl: /^https?:\/\//i.test(str(o.trackingUrl)) ? str(o.trackingUrl) : '',
    packedAt: date(o.packedAt),
    shippedAt: date(o.shippedAt),
    deliveredAt: date(o.deliveredAt),
    courier: parseCourier(o.courier),
  };
}

export type TrackingStep = {
  id: 'placed' | 'paid' | 'packed' | 'shipped' | 'delivered';
  label: string;
  /** done | current | upcoming */
  state: 'done' | 'current' | 'upcoming';
  at: string | null;
  detail: string;
};

export type Tracking = {
  steps: TrackingStep[];
  /** Short line for lists ("On its way", "Delivered 4 Nov"). */
  headline: string;
  /** 0–100 for a progress bar. */
  percent: number;
  /** cancelled / refunded / failed end the timeline early. */
  stopped: null | { label: string; tone: 'muted' | 'danger' };
  /** Carrier, tracking number and link (not the courier connection's own details). */
  fulfillment: Omit<Fulfillment, 'courier'>;
  /** The courier's latest updates, newest first (empty when no courier connection follows the parcel). */
  updates: CourierEvent[];
  virtual: boolean;
};

const iso = (d: Date | string | null | undefined) => (d ? new Date(d).toISOString() : null);

export function buildTracking(
  order: Pick<ShopOrder, 'status' | 'paymentMethod' | 'paymentStatus' | 'placedAt' | 'paidAt' | 'completedAt' | 'fulfillment'>,
  opts: { virtual?: boolean } = {},
): Tracking {
  const f = parseFulfillment(order.fulfillment);
  const virtual = Boolean(opts.virtual);
  const completed = order.status === 'completed';
  const paid = order.paymentStatus === 'paid' || order.paymentStatus === 'partially_refunded' || order.paymentStatus === 'refunded';
  const cod = order.paymentMethod === 'cod';
  const delivered = f.status === 'delivered' || completed;
  const shipped = delivered || f.status === 'shipped';
  const packed = shipped || f.status === 'packed';

  const raw: Omit<TrackingStep, 'state'>[] = [
    { id: 'placed', label: 'Order placed', at: iso(order.placedAt), detail: '' },
    {
      id: 'paid',
      label: cod ? 'Pay on delivery' : 'Payment confirmed',
      at: paid ? iso(order.paidAt) : null,
      detail: cod ? 'Cash when your order arrives' : order.paymentMethod === 'bank_transfer' && !paid ? 'Waiting for your bank transfer' : '',
    },
  ];
  if (!virtual) {
    raw.push(
      { id: 'packed', label: 'Packed', at: f.packedAt, detail: '' },
      {
        id: 'shipped',
        label: 'Shipped',
        at: f.shippedAt,
        detail: [f.carrier, f.trackingNumber].filter(Boolean).join(' · '),
      },
      { id: 'delivered', label: 'Delivered', at: f.deliveredAt ?? (completed ? iso(order.completedAt) : null), detail: '' },
    );
  } else {
    raw.push({ id: 'delivered', label: 'Completed', at: completed ? iso(order.completedAt) : null, detail: '' });
  }

  const doneIds = new Set<string>(['placed']);
  if (paid || (cod && order.status !== 'pending')) doneIds.add('paid');
  if (packed) doneIds.add('packed');
  if (shipped) doneIds.add('shipped');
  if (delivered) doneIds.add('delivered');
  // COD is "paid" at the door: mark the step done once the order is delivered.
  if (cod && delivered) doneIds.add('paid');

  let currentSet = false;
  const steps: TrackingStep[] = raw.map((s) => {
    if (doneIds.has(s.id)) return { ...s, state: 'done' };
    if (!currentSet) {
      currentSet = true;
      return { ...s, state: 'current' };
    }
    return { ...s, state: 'upcoming' };
  });

  const stoppedMap: Record<string, Tracking['stopped']> = {
    cancelled: { label: 'Cancelled', tone: 'muted' },
    refunded: { label: 'Refunded', tone: 'muted' },
    failed: { label: 'Payment failed', tone: 'danger' },
  };
  const stopped = stoppedMap[order.status] ?? null;

  const doneCount = steps.filter((s) => s.state === 'done').length;
  const percent = stopped ? 0 : Math.round(((doneCount - 1) / Math.max(1, steps.length - 1)) * 100);

  const stage = f.courier?.stage ?? '';
  let headline: string;
  if (stopped) headline = stopped.label;
  else if (delivered) headline = virtual ? 'Completed' : 'Delivered';
  else if (shipped && stage === 'returned') headline = 'Returned to sender';
  else if (shipped && stage === 'problem') headline = 'Delivery issue';
  else if (shipped && stage === 'out_for_delivery') headline = 'Out for delivery';
  else if (shipped) headline = 'On its way';
  else if (packed) headline = 'Packed and ready to ship';
  else if (order.status === 'pending') headline = 'Waiting for payment';
  else if (order.status === 'on-hold') headline = 'Waiting for your payment';
  else headline = 'Being prepared';

  const { courier, ...parcel } = f;
  return { steps, headline, percent, stopped, fulfillment: parcel, updates: courier && !virtual ? courier.events.slice(0, 10) : [], virtual };
}
