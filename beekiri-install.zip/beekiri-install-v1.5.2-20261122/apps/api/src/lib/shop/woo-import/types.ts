/**
 * A WooCommerce shop as read from its export files, before anything is created in Beekiri.
 * Both readers (wxr.ts for the WordPress export, products-csv.ts for the WooCommerce products CSV)
 * produce this shape; the importer (services/shop/woo-import.service.ts) only works from it.
 * Prices stay as the decimal strings WooCommerce wrote; they become minor units on import.
 */

export type WooImage = {
  url: string;
  /** Path inside wp-content/uploads (2026/11/photo.webp), to find it in an uploads ZIP. */
  file: string | null;
  alt: string | null;
};

export type WooAttribute = {
  name: string;
  values: string[];
  /** Used to make variations. */
  variation: boolean;
  visible: boolean;
};

export type WooStockStatus = 'instock' | 'outofstock' | 'onbackorder';

export type WooVariation = {
  sourceId: string;
  sku: string | null;
  regularPrice: string | null;
  salePrice: string | null;
  saleFrom: string | null;
  saleTo: string | null;
  manageStock: boolean;
  stock: number | null;
  stockStatus: WooStockStatus;
  weight: string | null;
  /** Attribute name → option ('' = any option). */
  attributes: Record<string, string>;
  image: WooImage | null;
  description: string;
  enabled: boolean;
  menuOrder: number;
};

/** Grouped and external (affiliate) products are reported, not imported: a Beekiri shop sells its own products. */
export type WooProductType = 'simple' | 'variable';

export type WooProduct = {
  sourceId: string;
  type: WooProductType;
  name: string;
  slug: string;
  status: 'publish' | 'draft' | 'private' | 'pending';
  featured: boolean;
  /** WooCommerce "Catalog visibility": shop and search, shop only, search only, or hidden. */
  catalogVisibility: 'visible' | 'catalog' | 'search' | 'hidden';
  sku: string | null;
  regularPrice: string | null;
  salePrice: string | null;
  saleFrom: string | null;
  saleTo: string | null;
  manageStock: boolean;
  stock: number | null;
  stockStatus: WooStockStatus;
  backorders: boolean;
  weight: string | null;
  length: string | null;
  width: string | null;
  height: string | null;
  virtual: boolean;
  shortDescription: string;
  description: string;
  purchaseNote: string;
  /** Category slugs (see WooExport.categories). */
  categories: string[];
  tags: string[];
  /** Main photo first. */
  images: WooImage[];
  attributes: WooAttribute[];
  variations: WooVariation[];
  menuOrder: number;
  createdAt: string | null;
  totalSales: number;
};

export type WooCategory = { slug: string; name: string; parent: string | null; description: string };
export type WooTag = { slug: string; name: string };

export type WooCoupon = {
  sourceId: string;
  code: string;
  description: string;
  discountType: 'percent' | 'fixed_cart' | 'fixed_product';
  amount: string;
  expiresAt: string | null;
  usageLimit: number | null;
  usageLimitPerUser: number | null;
  usageCount: number;
  minimumAmount: string | null;
  maximumAmount: string | null;
  individualUse: boolean;
  freeShipping: boolean;
  excludeSaleItems: boolean;
  /** Source product ids the coupon is limited to / excludes. */
  productIds: string[];
  excludedProductIds: string[];
  emails: string[];
  active: boolean;
};

export type WooAddress = {
  firstName: string;
  lastName: string;
  company: string;
  address1: string;
  address2: string;
  city: string;
  state: string;
  postcode: string;
  country: string;
  email: string;
  phone: string;
};

export type WooOrderStatus = 'pending' | 'processing' | 'on-hold' | 'completed' | 'cancelled' | 'refunded' | 'failed';

export type WooOrder = {
  sourceId: string;
  number: string;
  status: WooOrderStatus;
  createdAt: string;
  paidAt: string | null;
  completedAt: string | null;
  currency: string | null;
  total: string;
  discount: string;
  shippingTotal: string;
  tax: string;
  refunded: string;
  pricesIncludeTax: boolean;
  paymentMethod: string;
  paymentMethodTitle: string;
  transactionId: string;
  customerNote: string;
  /** WordPress user id of a registered customer ('' or '0' for guests). */
  customerSourceId: string;
  billing: WooAddress;
  shipping: WooAddress;
  /** WordPress exports never carry the products in an order (WooCommerce keeps them in its own tables). */
  notes: { date: string; text: string; toCustomer: boolean }[];
};

export type WooExport = {
  /** Which files it was read from. */
  sources: ('wxr' | 'csv')[];
  siteUrl: string | null;
  siteName: string | null;
  products: WooProduct[];
  categories: WooCategory[];
  tags: WooTag[];
  coupons: WooCoupon[];
  orders: WooOrder[];
  /**
   * Orders the export only names (newer WooCommerce order storage keeps their details out of
   * WordPress's export unless compatibility mode is on).
   */
  ordersWithoutDetails: number;
  /** Things the reader could not use, in words for the shop owner. */
  warnings: string[];
};

export const emptyAddress = (): WooAddress => ({
  firstName: '',
  lastName: '',
  company: '',
  address1: '',
  address2: '',
  city: '',
  state: '',
  postcode: '',
  country: '',
  email: '',
  phone: '',
});

/** "pa_color" / "colour-name" → "Color" / "Colour name". */
export function attributeLabel(taxonomyOrName: string): string {
  const base = taxonomyOrName.replace(/^pa_/, '').replace(/[-_]+/g, ' ').trim();
  return base ? base.charAt(0).toUpperCase() + base.slice(1) : taxonomyOrName;
}
