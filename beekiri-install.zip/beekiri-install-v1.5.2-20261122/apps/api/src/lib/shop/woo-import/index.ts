import { readProductsCsv } from './products-csv';
import type { WooExport } from './types';
import { readWxr } from './wxr';

export type WooFile = { kind: 'wxr' | 'csv'; path: string };
export type WooUnits = { weight: string | null; size: string | null };

/**
 * Reads the uploaded WooCommerce files into one shop. With both files, the WordPress export
 * describes the products (it has their real addresses, sales and dates); the CSV only adds products
 * the export does not have.
 */
export async function readWooFiles(files: WooFile[]): Promise<WooExport & { units: WooUnits }> {
  return withoutDefaultCategory(await readBoth(files));
}

const UNCATEGORIZED = 'uncategorized';

/**
 * WooCommerce puts products without a category in its own "Uncategorized"; a Bee Shopping product
 * needs no category, so it stays behind (unless it was renamed or has subcategories).
 */
function withoutDefaultCategory<T extends WooExport>(data: T): T {
  const fallback = data.categories.find((c) => c.slug === UNCATEGORIZED && c.name.trim().toLowerCase() === UNCATEGORIZED);
  if (!fallback || data.categories.some((c) => c.parent === UNCATEGORIZED)) return data;
  return {
    ...data,
    categories: data.categories.filter((c) => c !== fallback),
    products: data.products.map((p) => (p.categories.includes(UNCATEGORIZED) ? { ...p, categories: p.categories.filter((slug) => slug !== UNCATEGORIZED) } : p)),
  };
}

async function readBoth(files: WooFile[]): Promise<WooExport & { units: WooUnits }> {
  const wxr = files.find((f) => f.kind === 'wxr');
  const csv = files.find((f) => f.kind === 'csv');
  const fromXml = wxr ? await readWxr(wxr.path) : null;
  const fromCsv = csv ? await readProductsCsv(csv.path) : null;
  if (!fromXml && !fromCsv) throw new Error('No WooCommerce file to read.');
  if (!fromXml) return fromCsv!;
  if (!fromCsv) return { ...fromXml, units: { weight: null, size: null } };

  const ids = new Set(fromXml.products.map((p) => p.sourceId));
  const skus = new Set(fromXml.products.map((p) => p.sku).filter(Boolean));
  const extra = fromCsv.products.filter((p) => !ids.has(p.sourceId) && !(p.sku && skus.has(p.sku)));
  const categories = new Map(fromXml.categories.map((c) => [c.slug, c]));
  for (const c of fromCsv.categories) if (!categories.has(c.slug)) categories.set(c.slug, c);
  const tags = new Map(fromXml.tags.map((t) => [t.slug, t]));
  for (const t of fromCsv.tags) if (!tags.has(t.slug)) tags.set(t.slug, t);

  return {
    ...fromXml,
    sources: ['wxr', 'csv'],
    products: [...fromXml.products, ...extra],
    categories: [...categories.values()],
    tags: [...tags.values()],
    warnings: [...fromXml.warnings, ...fromCsv.warnings],
    units: fromCsv.units,
  };
}

export type { WooExport } from './types';
