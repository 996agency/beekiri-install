import type { WooAttribute, WooVariation } from './types';

/**
 * WooCommerce lets one variation stand for "any" option of an attribute; a Beekiri variation always
 * names one option. Such a variation becomes one variation per option (the first keeps the source
 * id and SKU). Returns the variations and how many "any" choices were expanded.
 */
export function expandAny(
  attributes: WooAttribute[],
  variation: Omit<WooVariation, 'attributes'>,
  choice: Record<string, string>,
): { variations: WooVariation[]; expanded: number } {
  let combos: Record<string, string>[] = [choice];
  let expanded = 0;
  for (const a of attributes.filter((a) => a.variation)) {
    if ((choice[a.name] ?? '') !== '') continue;
    expanded += 1;
    combos = combos.flatMap((c) => a.values.map((value) => ({ ...c, [a.name]: value })));
  }
  return {
    variations: combos.map((attrs, i) => ({
      ...variation,
      sourceId: i ? `${variation.sourceId}:${i}` : variation.sourceId,
      sku: i && variation.sku ? `${variation.sku}-${i + 1}` : variation.sku,
      attributes: attrs,
    })),
    expanded,
  };
}
