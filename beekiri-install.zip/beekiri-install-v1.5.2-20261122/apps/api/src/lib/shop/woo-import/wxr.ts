import { createReadStream } from 'fs';
import { Parser } from 'htmlparser2';
import { phpStringList, phpUnserialize } from './php-unserialize';
import { expandAny } from './variations';
import {
  attributeLabel,
  emptyAddress,
  type WooAddress,
  type WooAttribute,
  type WooCategory,
  type WooCoupon,
  type WooExport,
  type WooImage,
  type WooOrder,
  type WooOrderStatus,
  type WooProduct,
  type WooStockStatus,
  type WooTag,
  type WooVariation,
} from './types';

/**
 * Reads a WordPress export file (Tools → Export → All content, "WXR"). The file is streamed and
 * only shop data is kept: products and variations, their photos, categories, tags, coupons and
 * orders. Entities are never expanded from outside the file, so a crafted export cannot read
 * anything from the server.
 */

type RawMeta = Map<string, string>;
type RawItem = {
  fields: Record<string, string>;
  categories: { domain: string; slug: string; name: string }[];
  meta: RawMeta;
  comments: { fields: Record<string, string>; meta: RawMeta }[];
};
type RawTerm = { taxonomy: string; slug: string; name: string; parent: string; description: string };
/** An attribute while reading: where variations keep its value, and its options by slug. */
type ParsedAttribute = WooAttribute & { metaKey: string; slugToName: Map<string, string>; position: number };

const SHOP_TYPES = new Set(['product', 'product_variation', 'shop_coupon', 'shop_order', 'shop_order_refund', 'shop_order_placehold', 'attachment']);

export class NotAnExportError extends Error {}

export async function readWxr(filePath: string): Promise<WooExport> {
  const { items, terms, channel } = await parse(filePath);
  return build(items, terms, channel);
}

async function parse(filePath: string) {
  const items: RawItem[] = [];
  const terms: RawTerm[] = [];
  const channel: Record<string, string> = {};
  const stack: string[] = [];
  let text = '';
  let item: RawItem | null = null;
  let comment: RawItem['comments'][number] | null = null;
  let term: RawTerm | null = null;
  let category: { domain: string; slug: string } | null = null;
  let metaKey: string | null = null;
  let metaValue = '';
  let isWxr = false;

  const parser = new Parser(
    {
      onopentag(name, attribs) {
        stack.push(name);
        text = '';
        if (name === 'item') item = { fields: {}, categories: [], meta: new Map(), comments: [] };
        else if (name === 'wp:comment' && item) comment = { fields: {}, meta: new Map() };
        else if (name === 'wp:term') term = { taxonomy: '', slug: '', name: '', parent: '', description: '' };
        else if (name === 'category' && item) category = { domain: attribs.domain ?? '', slug: attribs.nicename ?? '' };
        else if (name === 'wp:postmeta' || name === 'wp:commentmeta' || name === 'wp:termmeta') {
          metaKey = null;
          metaValue = '';
        } else if (name === 'wp:wxr_version') isWxr = true;
      },
      ontext(data) {
        text += data;
      },
      onclosetag(name) {
        stack.pop();
        const value = text;
        text = '';
        if (name === 'item') {
          if (item && SHOP_TYPES.has(item.fields['wp:post_type'] ?? '')) items.push(item);
          item = null;
          return;
        }
        if (item) {
          if (name === 'wp:meta_key') metaKey = value.trim();
          else if (name === 'wp:meta_value') metaValue = value;
          else if (comment) {
            if (name === 'wp:comment') {
              item.comments.push(comment);
              comment = null;
            } else if (name === 'wp:commentmeta') {
              if (metaKey) comment.meta.set(metaKey, metaValue);
            } else comment.fields[name] = value;
          } else if (name === 'category' && category) {
            item.categories.push({ ...category, name: value.trim() });
            category = null;
          } else if (name === 'wp:postmeta') {
            if (metaKey) item.meta.set(metaKey, metaValue);
          } else item.fields[name] = value;
          return;
        }
        if (term) {
          if (name === 'wp:term') {
            terms.push(term);
            term = null;
          } else if (name === 'wp:term_taxonomy') term.taxonomy = value.trim();
          else if (name === 'wp:term_slug') term.slug = value.trim();
          else if (name === 'wp:term_parent') term.parent = value.trim();
          else if (name === 'wp:term_name') term.name = value.trim();
          else if (name === 'wp:term_description') term.description = value;
          return;
        }
        if (stack.length === 2 && stack[1] === 'channel') channel[name] = value.trim();
      },
    },
    { xmlMode: true, recognizeCDATA: true, decodeEntities: true },
  );

  const stream = createReadStream(filePath, { encoding: 'utf8', highWaterMark: 1 << 20 });
  for await (const chunk of stream) parser.write(chunk as string);
  parser.end();
  if (!isWxr) throw new NotAnExportError('This is not a WordPress export file. In WordPress, go to Tools → Export, choose “All content” and upload the file it downloads.');
  return { items, terms, channel };
}

// ─── Building the shop from the raw items ─────────────────────────────────────

const yes = (v: string | undefined) => v === 'yes' || v === '1' || v === 'true';
const str = (v: string | undefined) => (v ?? '').trim();
const orNull = (v: string | undefined) => (str(v) === '' ? null : str(v));
const int = (v: string | undefined) => {
  const n = parseInt(str(v), 10);
  return Number.isFinite(n) ? n : null;
};

export function slugify(text: string): string {
  return text
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 190);
}

/** WordPress dates: the GMT column when it is set, else the local one (both "Y-m-d H:i:s"). */
function wpDate(gmt: string | undefined, local: string | undefined): string | null {
  for (const v of [gmt, local]) {
    const s = str(v);
    if (s && !s.startsWith('0000')) {
      const d = new Date(`${s.replace(' ', 'T')}Z`);
      if (!Number.isNaN(d.getTime())) return d.toISOString();
    }
  }
  return null;
}

/** A unix timestamp or a "Y-m-d H:i:s" text. */
function metaDate(v: string | undefined): string | null {
  const s = str(v);
  if (!s) return null;
  const d = /^\d{9,11}$/.test(s) ? new Date(Number(s) * 1000) : new Date(`${s.replace(' ', 'T')}${/[zZ]|[+-]\d\d:?\d\d$/.test(s) ? '' : 'Z'}`);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

export function uploadsPath(url: string): string | null {
  const m = /\/wp-content\/uploads\/(.+)$/.exec(url.split(/[?#]/)[0] ?? '');
  return m ? decodeURIComponent(m[1]) : null;
}

/** WordPress's sanitize_title for attribute names in variation meta keys ("Pack size" → "pack-size"). */
const sanitizeTitle = (text: string) => slugify(text);

function stockStatus(v: string | undefined): WooStockStatus {
  return v === 'outofstock' || v === 'onbackorder' ? v : 'instock';
}

function address(meta: RawMeta, prefix: '_billing_' | '_shipping_'): WooAddress {
  const a = emptyAddress();
  const get = (k: string) => str(meta.get(`${prefix}${k}`));
  a.firstName = get('first_name');
  a.lastName = get('last_name');
  a.company = get('company');
  a.address1 = get('address_1');
  a.address2 = get('address_2');
  a.city = get('city');
  a.state = get('state');
  a.postcode = get('postcode');
  a.country = get('country').toUpperCase();
  a.email = get('email').toLowerCase();
  a.phone = get('phone');
  return a;
}

const ORDER_STATUSES: Record<string, WooOrderStatus> = {
  'wc-pending': 'pending',
  'wc-processing': 'processing',
  'wc-on-hold': 'on-hold',
  'wc-completed': 'completed',
  'wc-cancelled': 'cancelled',
  'wc-refunded': 'refunded',
  'wc-failed': 'failed',
};

function build(items: RawItem[], rawTerms: RawTerm[], channel: Record<string, string>): WooExport {
  const warnings: string[] = [];
  const byType = (type: string) => items.filter((i) => i.fields['wp:post_type'] === type);

  // Terms by taxonomy and slug (categories, tags and global attribute values).
  const termName = new Map<string, string>();
  for (const t of rawTerms) termName.set(`${t.taxonomy}|${t.slug}`, t.name);
  for (const i of items) for (const c of i.categories) if (!termName.has(`${c.domain}|${c.slug}`)) termName.set(`${c.domain}|${c.slug}`, c.name);

  const categories = new Map<string, WooCategory>();
  for (const t of rawTerms.filter((t) => t.taxonomy === 'product_cat' && t.slug)) {
    categories.set(t.slug, { slug: t.slug, name: t.name || t.slug, parent: t.parent || null, description: t.description });
  }
  const tags = new Map<string, WooTag>();
  for (const t of rawTerms.filter((t) => t.taxonomy === 'product_tag' && t.slug)) tags.set(t.slug, { slug: t.slug, name: t.name || t.slug });

  const attachments = new Map<string, WooImage>();
  for (const a of byType('attachment')) {
    const url = str(a.fields['wp:attachment_url']) || str(a.fields.guid);
    if (!/^https?:\/\//i.test(url)) continue;
    attachments.set(str(a.fields['wp:post_id']), {
      url,
      file: str(a.meta.get('_wp_attached_file')) || uploadsPath(url),
      alt: str(a.meta.get('_wp_attachment_image_alt')) || str(a.fields.title) || null,
    });
  }
  const image = (id: string | undefined) => (id ? (attachments.get(str(id)) ?? null) : null);
  let missingPhotos = 0;

  // ── Products ──
  const variationsOf = new Map<string, RawItem[]>();
  for (const v of byType('product_variation')) {
    const parent = str(v.fields['wp:post_parent']);
    if (!variationsOf.has(parent)) variationsOf.set(parent, []);
    variationsOf.get(parent)!.push(v);
  }
  const products: WooProduct[] = [];
  const skippedTypes = new Map<string, number>();
  let expandedAny = 0;
  for (const p of byType('product')) {
    const status = str(p.fields['wp:status']);
    if (status === 'trash' || status === 'auto-draft') continue;
    const kind = p.categories.find((c) => c.domain === 'product_type')?.slug ?? 'simple';
    if (kind === 'grouped' || kind === 'external') {
      skippedTypes.set(kind, (skippedTypes.get(kind) ?? 0) + 1);
      continue;
    }
    const type = kind === 'variable' || kind.startsWith('variable-') ? 'variable' : 'simple';
    if (kind !== 'simple' && kind !== 'variable') skippedTypes.set(`as-${type}:${kind}`, (skippedTypes.get(`as-${type}:${kind}`) ?? 0) + 1);
    const m = (k: string) => p.meta.get(k);
    const id = str(p.fields['wp:post_id']);

    const visibility = new Set(p.categories.filter((c) => c.domain === 'product_visibility').map((c) => c.slug));
    const hideCatalog = visibility.has('exclude-from-catalog');
    const hideSearch = visibility.has('exclude-from-search');

    // Attributes: global ones (pa_*) take their values from the product's terms.
    const attributes: ParsedAttribute[] = [];
    const raw = phpUnserialize(m('_product_attributes') ?? '');
    const rawList = raw && typeof raw === 'object' ? (Array.isArray(raw) ? raw : Object.values(raw)) : [];
    for (const entry of rawList) {
      if (!entry || typeof entry !== 'object' || Array.isArray(entry)) continue;
      const e = entry as Record<string, unknown>;
      const key = String(e.name ?? '');
      if (!key) continue;
      const isTaxonomy = Number(e.is_taxonomy) === 1 || e.is_taxonomy === true;
      const slugToName = new Map<string, string>();
      let values: string[];
      if (isTaxonomy) {
        values = [];
        for (const c of p.categories.filter((c) => c.domain === key)) {
          const nameOf = termName.get(`${key}|${c.slug}`) || c.name || c.slug;
          slugToName.set(c.slug, nameOf);
          values.push(nameOf);
        }
      } else {
        values = String(e.value ?? '').split('|').map((v) => v.trim()).filter(Boolean);
        for (const v of values) slugToName.set(sanitizeTitle(v), v);
      }
      attributes.push({
        name: isTaxonomy ? attributeLabel(key) : key,
        values,
        variation: Number(e.is_variation) === 1 || e.is_variation === true,
        visible: Number(e.is_visible) === 1 || e.is_visible === true,
        metaKey: `attribute_${isTaxonomy ? key : sanitizeTitle(key)}`,
        slugToName,
        position: Number(e.position) || 0,
      });
    }
    attributes.sort((a, b) => a.position - b.position);

    const variations: WooVariation[] = [];
    if (type === 'variable') {
      for (const v of (variationsOf.get(id) ?? []).sort((a, b) => (int(a.fields['wp:menu_order']) ?? 0) - (int(b.fields['wp:menu_order']) ?? 0))) {
        const vs = str(v.fields['wp:status']);
        if (vs === 'trash') continue;
        const vm = (k: string) => v.meta.get(k);
        // One option per variation attribute; "any" ('') is expanded into every option below.
        const choice: Record<string, string> = {};
        for (const a of attributes.filter((a) => a.variation)) {
          const rawValue = str(vm(a.metaKey));
          if (!rawValue) {
            choice[a.name] = '';
            continue;
          }
          choice[a.name] = a.slugToName.get(rawValue) ?? a.values.find((x) => x.toLowerCase() === rawValue.toLowerCase()) ?? rawValue;
          if (!a.values.includes(choice[a.name])) a.values.push(choice[a.name]);
        }
        const base: Omit<WooVariation, 'attributes'> = {
          sourceId: str(v.fields['wp:post_id']),
          sku: orNull(vm('_sku')),
          regularPrice: orNull(vm('_regular_price')),
          salePrice: orNull(vm('_sale_price')),
          saleFrom: metaDate(vm('_sale_price_dates_from')),
          saleTo: metaDate(vm('_sale_price_dates_to')),
          manageStock: yes(vm('_manage_stock')),
          stock: int(vm('_stock')),
          stockStatus: stockStatus(vm('_stock_status')),
          weight: orNull(vm('_weight')),
          image: image(vm('_thumbnail_id')),
          description: str(vm('_variation_description')),
          enabled: vs !== 'private',
          menuOrder: int(v.fields['wp:menu_order']) ?? 0,
        };
        // A variation for "any colour" becomes one variation per colour.
        const expanded = expandAny(attributes, base, choice);
        expandedAny += expanded.expanded;
        variations.push(...expanded.variations);
      }
    }

    const images: WooImage[] = [];
    for (const imgId of [m('_thumbnail_id'), ...str(m('_product_image_gallery')).split(',')]) {
      if (!str(imgId)) continue;
      const img = image(imgId);
      if (img) {
        if (!images.some((x) => x.url === img.url)) images.push(img);
      } else missingPhotos += 1;
    }

    for (const c of p.categories.filter((c) => c.domain === 'product_cat')) {
      if (!categories.has(c.slug)) categories.set(c.slug, { slug: c.slug, name: c.name || c.slug, parent: null, description: '' });
    }
    for (const c of p.categories.filter((c) => c.domain === 'product_tag')) {
      if (!tags.has(c.slug)) tags.set(c.slug, { slug: c.slug, name: c.name || c.slug });
    }

    const name = str(p.fields.title) || `Product ${id}`;
    products.push({
      sourceId: id,
      type,
      name,
      slug: str(p.fields['wp:post_name']) || slugify(name) || `product-${id}`,
      status: status === 'publish' ? 'publish' : status === 'private' ? 'private' : status === 'pending' ? 'pending' : 'draft',
      featured: visibility.has('featured') || yes(m('_featured')),
      catalogVisibility: hideCatalog && hideSearch ? 'hidden' : hideCatalog ? 'search' : hideSearch ? 'catalog' : 'visible',
      sku: orNull(m('_sku')),
      regularPrice: orNull(m('_regular_price')),
      salePrice: orNull(m('_sale_price')),
      saleFrom: metaDate(m('_sale_price_dates_from')),
      saleTo: metaDate(m('_sale_price_dates_to')),
      manageStock: yes(m('_manage_stock')),
      stock: int(m('_stock')),
      stockStatus: stockStatus(m('_stock_status')),
      backorders: str(m('_backorders')) !== '' && str(m('_backorders')) !== 'no',
      weight: orNull(m('_weight')),
      length: orNull(m('_length')),
      width: orNull(m('_width')),
      height: orNull(m('_height')),
      virtual: yes(m('_virtual')),
      shortDescription: p.fields['excerpt:encoded'] ?? '',
      description: p.fields['content:encoded'] ?? '',
      purchaseNote: str(m('_purchase_note')),
      categories: p.categories.filter((c) => c.domain === 'product_cat').map((c) => c.slug),
      tags: p.categories.filter((c) => c.domain === 'product_tag').map((c) => c.slug),
      images,
      attributes: attributes.map(({ name: n, values, variation, visible }) => ({ name: n, values, variation, visible })),
      variations,
      menuOrder: int(p.fields['wp:menu_order']) ?? 0,
      createdAt: wpDate(p.fields['wp:post_date_gmt'], p.fields['wp:post_date']),
      totalSales: Math.max(0, int(m('total_sales')) ?? 0),
    });
  }
  if (skippedTypes.get('grouped')) warnings.push(`${skippedTypes.get('grouped')} grouped product(s) were left out: Bee Shopping has no grouped products. The products inside them are imported on their own.`);
  if (skippedTypes.get('external')) warnings.push(`${skippedTypes.get('external')} external (affiliate) product(s) were left out: Bee Shopping only sells its own products.`);
  for (const [key, n] of skippedTypes) {
    if (key.startsWith('as-')) {
      const [as, kind] = key.slice(3).split(':');
      warnings.push(`${n} “${kind}” product(s) come from a WooCommerce add-on Beekiri does not have; they are imported as ${as === 'variable' ? 'products with variations' : 'regular products'}.`);
    }
  }
  if (expandedAny) warnings.push(`${expandedAny} variation(s) were set for “any” option; each became one variation per option.`);
  if (missingPhotos) warnings.push(`${missingPhotos} product photo(s) are not in the export file (deleted from the media library), so they are skipped.`);

  // ── Coupons ──
  const coupons: WooCoupon[] = [];
  let skippedCoupons = 0;
  for (const c of byType('shop_coupon')) {
    const status = str(c.fields['wp:status']);
    if (status === 'trash') continue;
    const m = (k: string) => c.meta.get(k);
    const kind = str(m('discount_type')) || 'fixed_cart';
    const discountType = kind === 'percent' || kind === 'percent_product' ? 'percent' : kind === 'fixed_cart' || kind === 'fixed_product' ? kind : null;
    const code = str(c.fields.title);
    if (!discountType || !code) {
      skippedCoupons += 1;
      continue;
    }
    coupons.push({
      sourceId: str(c.fields['wp:post_id']),
      code,
      description: str(c.fields['excerpt:encoded']),
      discountType,
      amount: str(m('coupon_amount')) || '0',
      expiresAt: metaDate(m('date_expires')) ?? metaDate(m('expiry_date')),
      usageLimit: int(m('usage_limit')) || null,
      usageLimitPerUser: int(m('usage_limit_per_user')) || null,
      usageCount: Math.max(0, int(m('usage_count')) ?? 0),
      minimumAmount: orNull(m('minimum_amount')),
      maximumAmount: orNull(m('maximum_amount')),
      individualUse: yes(m('individual_use')),
      freeShipping: yes(m('free_shipping')),
      excludeSaleItems: yes(m('exclude_sale_items')),
      productIds: str(m('product_ids')).split(',').map((s) => s.trim()).filter(Boolean),
      excludedProductIds: str(m('exclude_product_ids')).split(',').map((s) => s.trim()).filter(Boolean),
      emails: phpStringList(m('customer_email')).map((e) => e.toLowerCase()),
      active: status === 'publish',
    });
  }
  if (skippedCoupons) warnings.push(`${skippedCoupons} coupon(s) of a kind Bee Shopping does not have (for example subscription sign-up fees) were left out.`);

  // ── Orders ──
  const refunds = new Map<string, number>();
  for (const r of byType('shop_order_refund')) {
    const parent = str(r.fields['wp:post_parent']);
    const amount = Number(str(r.meta.get('_refund_amount'))) || 0;
    refunds.set(parent, (refunds.get(parent) ?? 0) + amount);
  }
  const orders: WooOrder[] = [];
  const otherStatuses = new Set<string>();
  for (const o of byType('shop_order')) {
    const raw = str(o.fields['wp:status']);
    if (raw === 'trash' || raw === 'auto-draft' || raw === 'wc-checkout-draft' || raw === 'draft') continue;
    const status = ORDER_STATUSES[raw];
    if (!status) otherStatuses.add(raw.replace(/^wc-/, ''));
    const m = (k: string) => o.meta.get(k);
    const id = str(o.fields['wp:post_id']);
    const number = str(m('_order_number')) || id;
    const billing = address(o.meta, '_billing_');
    const shipping = address(o.meta, '_shipping_');
    orders.push({
      sourceId: id,
      number,
      status: status ?? 'processing',
      createdAt: wpDate(o.fields['wp:post_date_gmt'], o.fields['wp:post_date']) ?? new Date(0).toISOString(),
      paidAt: metaDate(m('_date_paid')) ?? metaDate(m('_paid_date')),
      completedAt: metaDate(m('_date_completed')) ?? metaDate(m('_completed_date')),
      currency: orNull(m('_order_currency'))?.toUpperCase() ?? null,
      total: str(m('_order_total')) || '0',
      discount: str(m('_cart_discount')) || '0',
      shippingTotal: str(m('_order_shipping')) || '0',
      tax: String((Number(str(m('_order_tax'))) || 0) + (Number(str(m('_order_shipping_tax'))) || 0)),
      refunded: String(refunds.get(id) ?? 0),
      pricesIncludeTax: yes(m('_prices_include_tax')),
      paymentMethod: str(m('_payment_method')),
      paymentMethodTitle: str(m('_payment_method_title')),
      transactionId: str(m('_transaction_id')),
      customerNote: str(o.fields['excerpt:encoded']),
      customerSourceId: str(m('_customer_user')),
      billing,
      shipping: shipping.address1 || shipping.city ? shipping : { ...billing },
      notes: o.comments
        .filter((c) => str(c.fields['wp:comment_type']) === 'order_note' && str(c.fields['wp:comment_content']))
        .map((c) => ({
          date: wpDate(c.fields['wp:comment_date_gmt'], c.fields['wp:comment_date']) ?? new Date(0).toISOString(),
          text: str(c.fields['wp:comment_content']),
          toCustomer: c.meta.get('is_customer_note') === '1',
        })),
    });
  }
  if (otherStatuses.size) warnings.push(`Orders with the status ${[...otherStatuses].map((s) => `“${s}”`).join(', ')} (from a WooCommerce add-on) are imported as “Processing”.`);

  const placeholders = byType('shop_order_placehold').length;

  return {
    sources: ['wxr'],
    siteUrl: str(channel['wp:base_site_url']) || str(channel.link) || null,
    siteName: str(channel.title) || null,
    products,
    categories: [...categories.values()],
    tags: [...tags.values()],
    coupons,
    orders,
    ordersWithoutDetails: placeholders,
    warnings,
  };
}
