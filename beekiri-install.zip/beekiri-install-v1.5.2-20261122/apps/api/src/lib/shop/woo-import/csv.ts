/**
 * CSV as WooCommerce writes it (RFC 4180): quoted fields with doubled quotes, line breaks inside
 * quotes, CRLF or LF rows, and a UTF-8 byte-order mark at the start.
 */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;
  let fieldStarted = false;
  let i = text.charCodeAt(0) === 0xfeff ? 1 : 0;

  const endField = () => {
    row.push(field);
    field = '';
    fieldStarted = false;
  };
  const endRow = () => {
    endField();
    if (!(row.length === 1 && row[0] === '')) rows.push(row);
    row = [];
  };

  for (; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          quoted = false;
        }
      } else {
        field += c;
      }
      continue;
    }
    if (c === '"' && !fieldStarted) {
      quoted = true;
      fieldStarted = true;
    } else if (c === ',') {
      endField();
    } else if (c === '\n' || c === '\r') {
      if (c === '\r' && text[i + 1] === '\n') i++;
      endRow();
    } else {
      field += c;
      fieldStarted = true;
    }
  }
  if (fieldStarted || field !== '' || row.length) endRow();
  return rows;
}

/** Rows as objects keyed by the header row (trimmed header names). */
export function csvRecords(text: string): { headers: string[]; records: Record<string, string>[] } {
  const [head = [], ...body] = parseCsv(text);
  const headers = head.map((h) => h.trim());
  const records = body.map((cells) => {
    const record: Record<string, string> = {};
    headers.forEach((h, i) => {
      if (h) record[h] = cells[i] ?? '';
    });
    return record;
  });
  return { headers, records };
}

/** WooCommerce list cells ("A, B\, C") → ["A", "B, C"]. */
export function wooList(cell: string | undefined): string[] {
  if (!cell?.trim()) return [];
  const out: string[] = [];
  let current = '';
  for (let i = 0; i < cell.length; i++) {
    const c = cell[i];
    if (c === '\\' && cell[i + 1] === ',') {
      current += ',';
      i++;
    } else if (c === ',') {
      out.push(current.trim());
      current = '';
    } else {
      current += c;
    }
  }
  out.push(current.trim());
  return out.filter(Boolean);
}

/**
 * A cell as WooCommerce meant it: its exporter writes line breaks as "\n" and puts an apostrophe
 * before values that start with =, +, - or @ (so spreadsheets do not run them).
 */
export function wooText(cell: string | undefined, multiline = false): string {
  let value = cell ?? '';
  if (/^'[=+\-@]/.test(value)) value = value.slice(1);
  return multiline ? value.replace(/\\n/g, '\n') : value;
}
