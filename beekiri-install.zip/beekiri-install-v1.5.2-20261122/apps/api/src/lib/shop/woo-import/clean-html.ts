import sanitizeHtml from 'sanitize-html';

/**
 * WooCommerce descriptions made to look like the rest of a Beekiri shop: plain, well-formed HTML
 * the theme styles itself. WordPress block comments, shortcodes (page-builder wrappers keep their
 * text), inline styles, classes and scripts go; WordPress's line breaks become paragraphs (it only
 * adds them when it shows a page); links to the old shop point at the same page on this site.
 */

const KNOWN_SHORTCODES = new Set([
  'gallery', 'caption', 'embed', 'video', 'audio', 'playlist', 'products', 'product', 'product_page',
  'product_category', 'add_to_cart', 'contact-form-7', 'wpforms', 'row', 'column', 'section', 'button',
  'icon', 'divider', 'spacer', 'tabs', 'tab', 'accordion', 'toggle', 'fusion_builder_container',
]);

/** Shortcodes go (page-builder wrappers keep their text); plain [brackets] in the text stay. */
export function stripShortcodes(html: string): string {
  const removed = new Set<string>();
  return html
    .replace(/\[([a-zA-Z][\w-]*)(\s[^\]]*)?\/?\]/g, (match, name: string, attrs?: string) => {
      if (!attrs && !/[_-]/.test(name) && !KNOWN_SHORTCODES.has(name.toLowerCase())) return match;
      removed.add(name.toLowerCase());
      return '';
    })
    .replace(/\[\/([a-zA-Z][\w-]*)\]/g, (match, name: string) => (removed.has(name.toLowerCase()) || /[_-]/.test(name) ? '' : match));
}

const BLOCK_START = /^<(p|div|ul|ol|li|table|thead|tbody|tr|h[1-6]|blockquote|pre|hr|figure|section|article|dl)[\s>/]/i;

/** WordPress's wpautop, simplified: blank lines make paragraphs, single line breaks <br>. */
export function autop(html: string): string {
  return html
    .replace(/\r\n?/g, '\n')
    .split(/\n\s*\n/)
    .map((chunk) => chunk.trim())
    .filter(Boolean)
    .map((chunk) => (BLOCK_START.test(chunk) ? chunk : `<p>${chunk.replace(/\n/g, '<br>\n')}</p>`))
    .join('\n');
}

export type CleanOptions = {
  /** The old shop's address (https://old.example): links to it become links on this site. */
  oldSiteUrl?: string | null;
  /** New address for an image in the description; null drops the image. */
  imageUrl?: (src: string) => string | null;
};

/** Old WooCommerce paths that live at another path in a Beekiri shop. */
function newPath(path: string): string {
  const category = /^\/product-category\/(.+?)\/?$/.exec(path);
  if (category) return `/shop/category/${category[1].split('/').pop()}`;
  return path.replace(/\/+$/, '') || '/';
}

export function cleanWooHtml(html: string, options: CleanOptions = {}): string {
  if (!html?.trim()) return '';
  let oldOrigin: string | null = null;
  try {
    oldOrigin = options.oldSiteUrl ? new URL(options.oldSiteUrl).origin : null;
  } catch {
    oldOrigin = null;
  }
  const withoutComments = html.replace(/<!--[\s\S]*?-->/g, '');
  const paragraphs = autop(stripShortcodes(withoutComments));

  const clean = sanitizeHtml(paragraphs, {
    allowedTags: [
      'p', 'br', 'strong', 'em', 'u', 's', 'ul', 'ol', 'li', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'a',
      'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'hr', 'sup', 'sub', 'img', 'figure', 'figcaption', 'div',
    ],
    allowedAttributes: {
      a: ['href', 'title'],
      img: ['src', 'alt', 'width', 'height'],
      td: ['colspan', 'rowspan'],
      th: ['colspan', 'rowspan'],
    },
    allowedSchemes: ['http', 'https', 'mailto', 'tel'],
    allowProtocolRelative: false,
    transformTags: {
      h1: 'h2',
      b: 'strong',
      i: 'em',
      a: (tagName, attribs) => {
        const href = attribs.href ?? '';
        if (oldOrigin && href) {
          try {
            const url = new URL(href, oldOrigin);
            if (url.origin === oldOrigin && !/\/wp-content\//.test(url.pathname)) {
              return { tagName, attribs: { ...attribs, href: `${newPath(url.pathname)}${url.search}${url.hash}` } };
            }
          } catch {
            /* keep the link as it is */
          }
        }
        return { tagName, attribs };
      },
      img: (tagName, attribs) => {
        const src = options.imageUrl ? options.imageUrl(attribs.src ?? '') : (attribs.src ?? '');
        // Dropped later by exclusiveFilter when it has no source.
        return { tagName, attribs: { ...attribs, src: src ?? '' } };
      },
    },
    exclusiveFilter: (frame) =>
      (frame.tag === 'img' && !frame.attribs.src) ||
      (['p', 'div', 'figure', 'li', 'strong', 'em'].includes(frame.tag) && !frame.text.trim() && !frame.mediaChildren?.length),
  });
  return clean.replace(/\n{3,}/g, '\n\n').trim();
}

/**
 * A short description as plain text: the shop shows it as text (blank lines become paragraphs).
 * Shortcodes and tags go, list items keep a bullet, entities become characters again.
 */
export function plainWooText(html: string): string {
  const marked = stripShortcodes(html.replace(/<!--[\s\S]*?-->/g, ''))
    .replace(/\r\n?/g, '\n')
    .replace(/<li\b[^>]*>/gi, '\n• ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|h[1-6]|ul|ol|blockquote|pre|tr|table|section|article|figure)\s*>/gi, '\n\n');
  // sanitize-html decodes every entity and escapes only &, < and > again: undo those three.
  const text = sanitizeHtml(marked, { allowedTags: [], allowedAttributes: {} })
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&');
  return text
    .split('\n')
    .map((line) => line.replace(/[ \t\u00a0]+/g, ' ').trim())
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/** Every image address used in a description (to bring the pictures in too). */
export function descriptionImages(html: string): string[] {
  const out = new Set<string>();
  for (const match of html.matchAll(/<img\b[^>]*\bsrc\s*=\s*["']([^"']+)["']/gi)) {
    if (/^https?:\/\//i.test(match[1])) out.add(match[1]);
  }
  return [...out];
}
