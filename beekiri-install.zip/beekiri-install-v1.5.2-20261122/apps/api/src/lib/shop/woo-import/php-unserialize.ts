/**
 * Reads PHP's serialize() format, which WordPress uses for some meta values (WooCommerce product
 * attributes, coupon e-mail lists). Data only: objects, references or anything malformed make the
 * whole value unreadable (undefined) — nothing is ever executed or instantiated.
 */
export type PhpValue = null | boolean | number | string | PhpValue[] | { [key: string]: PhpValue };

const MAX_DEPTH = 32;

class Malformed extends Error {}

export function phpUnserialize(input: string): PhpValue | undefined {
  // String lengths are counted in bytes, so read the UTF-8 bytes rather than characters.
  const buf = Buffer.from(input, 'utf8');
  let pos = 0;

  const fail = (): never => {
    throw new Malformed();
  };
  const expect = (literal: string) => {
    if (buf.toString('latin1', pos, pos + literal.length) !== literal) fail();
    pos += literal.length;
  };
  const readUntil = (char: string): string => {
    const end = buf.indexOf(char, pos, 'latin1');
    if (end < 0) fail();
    const out = buf.toString('utf8', pos, end);
    pos = end + 1;
    return out;
  };
  const count = (): number => {
    const n = Number(readUntil(':'));
    if (!Number.isInteger(n) || n < 0) fail();
    return n;
  };

  const value = (depth: number): PhpValue => {
    if (depth > MAX_DEPTH) fail();
    const type = String.fromCharCode(buf[pos] ?? 0);
    pos += 1;
    switch (type) {
      case 'N':
        expect(';');
        return null;
      case 'b':
        expect(':');
        return readUntil(';') === '1';
      case 'i': {
        expect(':');
        const n = Number(readUntil(';'));
        return Number.isFinite(n) ? n : fail();
      }
      case 'd': {
        expect(':');
        const n = Number(readUntil(';'));
        return Number.isFinite(n) ? n : 0;
      }
      case 's': {
        expect(':');
        const length = count();
        expect('"');
        if (pos + length > buf.length) fail();
        const text = buf.toString('utf8', pos, pos + length);
        pos += length;
        expect('";');
        return text;
      }
      case 'a': {
        expect(':');
        const size = count();
        expect('{');
        const entries: [string | number, PhpValue][] = [];
        for (let i = 0; i < size; i++) {
          const key = value(depth + 1);
          if (typeof key !== 'string' && typeof key !== 'number') fail();
          entries.push([key as string | number, value(depth + 1)]);
        }
        expect('}');
        // A PHP list (keys 0..n-1) becomes an array; anything else an object with string keys.
        if (entries.every(([key], i) => key === i)) return entries.map(([, v]) => v);
        const out: { [key: string]: PhpValue } = {};
        for (const [key, v] of entries) Object.defineProperty(out, String(key), { value: v, enumerable: true, writable: true, configurable: true });
        return out;
      }
      default:
        return fail();
    }
  };

  try {
    let result = value(0);
    if (pos !== buf.length) return undefined;
    // WordPress sometimes serializes a value twice.
    if (typeof result === 'string' && /^(a|s|i|b|d):\d*[:;]|^N;$/.test(result)) {
      const inner = phpUnserialize(result);
      if (inner !== undefined) result = inner;
    }
    return result;
  } catch {
    return undefined;
  }
}

/** A serialized list of strings (or one plain string) as an array; empty when unreadable. */
export function phpStringList(input: string | undefined): string[] {
  if (!input) return [];
  const value = phpUnserialize(input);
  if (value === undefined) return input.includes(':{') ? [] : [input];
  const list = Array.isArray(value) ? value : value && typeof value === 'object' ? Object.values(value) : [value];
  return list.filter((v): v is string | number => typeof v === 'string' || typeof v === 'number').map(String).filter(Boolean);
}
