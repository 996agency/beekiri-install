import { readFile } from 'fs/promises';
import { csvRecords, wooList, wooText } from './csv';
import type { WooAttribute, WooCategory, WooExport, WooImage, WooProduct, WooStockStatus, WooTag, WooVariation } from './types';
import { expandAny } from './variations';
import { NotAnExportError, slugify, uploadsPath } from './wxr';

/**
 * Reads the WooCommerce products CSV (Products → Export). Column names are WooCommerce's English
 * ones; a store whose admin runs in another language writes them translated, so the shop owner is
 * asked to export again in English instead of guessing.
 */

const REQUIRED = ['Type', 'Name'];

export async function readProductsCsv(filePath: string): Promise<WooExport & { units: { weight: string | null; size: string | null } }> {
  const { headers, records } = csvRecords(await readFile(filePath, 'utf8'));
  if (!REQUIRED.every((h) => headers.includes(h)) || !(headers.includes('ID') || headers.includes('SKU'))) {
    throw new NotAnExportError(
      'This is not a WooCommerce products CSV, or its column names are not in English. In WooCommerce, go to Products → Export with your WordPress profile language set to English, and upload the file it downloads.',
    );
  }
  const warnings: string[] = [];
  const col = (r: Record<string, string>, name: string) => (r[name] ?? '').trim();
  const headerLike = (re: RegExp) => headers.find((h) => re.test(h)) ?? null;
  const weightHeader = headerLike(/^Weight\b/i);
  const lengthHeader = headerLike(/^Length\b/i);
  const widthHeader = headerLike(/^Width\b/i);
  const heightHeader = headerLike(/^Height\b/i);
  const unitOf = (h: string | null) => (h ? (/\(([^)]+)\)/.exec(h)?.[1]?.trim().toLowerCase() ?? null) : null);
  const attributeNumbers = headers.map((h) => /^Attribute (\d+) name$/.exec(h)?.[1]).filter((n): n is string => Boolean(n));

  const num = (v: string) => (v === '' ? null : v);
  const int = (v: string) => {
    const n = parseInt(v, 10);
    return Number.isFinite(n) ? n : null;
  };
  const date = (v: string) => {
    if (!v) return null;
    const d = new Date(/T|Z/.test(v) ? v : `${v.replace(' ', 'T')}${v.includes(':') ? '' : 'T00:00:00'}Z`);
    return Number.isNaN(d.getTime()) ? null : d.toISOString();
  };
  const stockStatus = (v: string): WooStockStatus => (v === '0' ? 'outofstock' : v === 'backorder' || v === 'onbackorder' ? 'onbackorder' : 'instock');
  const imagesOf = (cell: string): WooImage[] =>
    wooList(cell)
      .filter((u) => /^https?:\/\//i.test(u))
      .map((url) => ({ url, file: uploadsPath(url), alt: null }));

  // Categories come as paths ("Clothing > Hoodies"); the same name under two parents stays apart.
  const categories = new Map<string, WooCategory>();
  const slugByPath = new Map<string, string>();
  const categorySlugs = (cell: string): string[] =>
    wooList(cell).map((path) => {
      const parts = path.split('>').map((p) => p.trim()).filter(Boolean);
      let parent: string | null = null;
      let key = '';
      for (const part of parts) {
        key = key ? `${key} > ${part}` : part;
        let slug = slugByPath.get(key);
        if (!slug) {
          slug = slugify(part) || 'category';
          if ([...slugByPath.values()].includes(slug)) slug = `${slug}-${parent ?? 'x'}`.slice(0, 190);
          slugByPath.set(key, slug);
          categories.set(slug, { slug, name: part, parent, description: '' });
        }
        parent = slug;
      }
      return parent ?? '';
    }).filter(Boolean);
  const tags = new Map<string, WooTag>();
  const tagSlugs = (cell: string) =>
    wooList(cell).map((name) => {
      const slug = slugify(name) || 'tag';
      if (!tags.has(slug)) tags.set(slug, { slug, name });
      return slug;
    });

  const attributesOf = (r: Record<string, string>): WooAttribute[] =>
    attributeNumbers
      .map((n) => ({
        name: col(r, `Attribute ${n} name`),
        values: wooList(r[`Attribute ${n} value(s)`]),
        visible: col(r, `Attribute ${n} visible`) !== '0',
        // The products CSV has no "used for variations" column: on a variable product, an attribute
        // whose values the variations name is one.
        variation: false,
      }))
      .filter((a) => a.name);

  const products: WooProduct[] = [];
  const bySourceId = new Map<string, WooProduct>();
  const bySku = new Map<string, WooProduct>();
  const variationRows: Record<string, string>[] = [];
  const skipped = { grouped: 0, external: 0 };

  for (const r of records) {
    const types = wooList(r.Type).map((t) => t.toLowerCase());
    if (types.includes('variation')) {
      variationRows.push(r);
      continue;
    }
    if (types.includes('grouped')) {
      skipped.grouped += 1;
      continue;
    }
    if (types.includes('external')) {
      skipped.external += 1;
      continue;
    }
    const name = wooText(r.Name).trim() || `Product ${col(r, 'ID')}`;
    const published = col(r, 'Published');
    const visibility = col(r, 'Visibility in catalog');
    const stock = int(col(r, 'Stock'));
    const product: WooProduct = {
      sourceId: col(r, 'ID') || col(r, 'SKU'),
      type: types.includes('variable') ? 'variable' : 'simple',
      name,
      slug: slugify(name) || `product-${col(r, 'ID')}`,
      // WooCommerce writes 1 for published, 0 for private and -1 for drafts.
      status: published === '1' ? 'publish' : published === '0' ? 'private' : 'draft',
      featured: col(r, 'Is featured?') === '1',
      catalogVisibility: visibility === 'catalog' || visibility === 'search' || visibility === 'hidden' ? visibility : 'visible',
      sku: num(wooText(r.SKU).trim()),
      regularPrice: num(col(r, 'Regular price')),
      salePrice: num(col(r, 'Sale price')),
      saleFrom: date(col(r, 'Date sale price starts')),
      saleTo: date(col(r, 'Date sale price ends')),
      manageStock: stock !== null,
      stock,
      stockStatus: stockStatus(col(r, 'In stock?')),
      backorders: ['1', 'notify', 'yes'].includes(col(r, 'Backorders allowed?')),
      weight: weightHeader ? num(col(r, weightHeader)) : null,
      length: lengthHeader ? num(col(r, lengthHeader)) : null,
      width: widthHeader ? num(col(r, widthHeader)) : null,
      height: heightHeader ? num(col(r, heightHeader)) : null,
      virtual: types.includes('virtual'),
      shortDescription: wooText(r['Short description'], true),
      description: wooText(r.Description, true),
      purchaseNote: wooText(r['Purchase note'], true),
      categories: categorySlugs(r.Categories ?? ''),
      tags: tagSlugs(r.Tags ?? ''),
      images: imagesOf(r.Images ?? ''),
      attributes: attributesOf(r),
      variations: [],
      menuOrder: int(col(r, 'Position')) ?? 0,
      createdAt: null,
      totalSales: 0,
    };
    products.push(product);
    if (product.sourceId) bySourceId.set(product.sourceId, product);
    if (product.sku) bySku.set(product.sku, product);
  }

  let orphans = 0;
  let expandedAny = 0;
  for (const r of variationRows) {
    const parentRef = col(r, 'Parent');
    const parent = parentRef.startsWith('id:') ? bySourceId.get(parentRef.slice(3)) : (bySku.get(parentRef) ?? bySourceId.get(parentRef));
    if (!parent || parent.type !== 'variable') {
      orphans += 1;
      continue;
    }
    const choice: Record<string, string> = {};
    for (const n of attributeNumbers) {
      const name = col(r, `Attribute ${n} name`);
      if (!name) continue;
      const value = wooList(r[`Attribute ${n} value(s)`])[0] ?? '';
      const attribute = parent.attributes.find((a) => a.name.toLowerCase() === name.toLowerCase());
      if (!attribute) continue;
      attribute.variation = true;
      const option = attribute.values.find((v) => v.toLowerCase() === value.toLowerCase()) ?? value;
      if (option && !attribute.values.includes(option)) attribute.values.push(option);
      choice[attribute.name] = option;
    }
    const stock = int(col(r, 'Stock'));
    const base: Omit<WooVariation, 'attributes'> = {
      sourceId: col(r, 'ID') || `${parent.sourceId}-${parent.variations.length + 1}`,
      sku: num(wooText(r.SKU).trim()),
      regularPrice: num(col(r, 'Regular price')),
      salePrice: num(col(r, 'Sale price')),
      saleFrom: date(col(r, 'Date sale price starts')),
      saleTo: date(col(r, 'Date sale price ends')),
      manageStock: stock !== null,
      stock,
      stockStatus: stockStatus(col(r, 'In stock?')),
      weight: weightHeader ? num(col(r, weightHeader)) : null,
      image: imagesOf(r.Images ?? '')[0] ?? null,
      description: wooText(r.Description, true),
      enabled: col(r, 'Published') !== '0' && col(r, 'Published') !== '-1',
      menuOrder: int(col(r, 'Position')) ?? 0,
    };
    const expanded = expandAny(parent.attributes, base, choice);
    expandedAny += expanded.expanded;
    parent.variations.push(...expanded.variations);
  }
  if (skipped.grouped) warnings.push(`${skipped.grouped} grouped product(s) were left out: Bee Shopping has no grouped products. The products inside them are imported on their own.`);
  if (skipped.external) warnings.push(`${skipped.external} external (affiliate) product(s) were left out: Bee Shopping only sells its own products.`);
  if (orphans) warnings.push(`${orphans} variation(s) belong to a product that is not in the file, so they are left out.`);
  if (expandedAny) warnings.push(`${expandedAny} variation(s) were set for “any” option; each became one variation per option.`);

  return {
    sources: ['csv'],
    siteUrl: null,
    siteName: null,
    products,
    categories: [...categories.values()],
    tags: [...tags.values()],
    coupons: [],
    orders: [],
    ordersWithoutDetails: 0,
    warnings,
    units: { weight: unitOf(weightHeader), size: unitOf(lengthHeader ?? widthHeader ?? heightHeader) },
  };
}
