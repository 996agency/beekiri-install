import { AsyncLocalStorage } from 'async_hooks';
import { literal, Op, type WhereOptions } from 'sequelize';
import { sequelize } from '../../db/sequelize';

/**
 * The preview of a shop import (Shop → Settings → Import → Preview): for one storefront request,
 * that import's products — still drafts — show as if they were published, and its categories
 * appear. Everyone else keeps seeing the shop as it is; the cart never sells a draft.
 */
export type ImportPreview = {
  importId: string;
  /** Its products that stay drafts after Publish (drafts or private in WooCommerce). */
  hiddenIds: string[];
};

const scope = new AsyncLocalStorage<ImportPreview>();

export function runWithImportPreview<T>(preview: ImportPreview, fn: () => T): T {
  return scope.run(preview, fn);
}

export function importPreviewId(): string | null {
  return scope.getStore()?.importId ?? null;
}

/** Post filter for products the shop shows (use instead of `status: 'publish'`). */
export function visibleProducts(): WhereOptions {
  const preview = scope.getStore();
  if (!preview) return { status: 'publish' };
  return {
    [Op.or]: [
      { status: 'publish' },
      {
        status: 'draft',
        id: {
          [Op.in]: literal(
            `(SELECT "targetId" FROM "ShopImportItem" WHERE "importId" = ${sequelize.escape(preview.importId)} AND "kind" = 'product' AND "created" = true)`,
          ),
          ...(preview.hiddenIds.length ? { [Op.notIn]: preview.hiddenIds } : {}),
        },
      },
    ],
  };
}

/**
 * Term filter that leaves out categories and tags an import created and has not published yet
 * (except during that import's own preview).
 */
export function visibleTerms(siteId: string): WhereOptions {
  const preview = importPreviewId();
  return {
    id: {
      [Op.notIn]: literal(
        `(SELECT i."targetId" FROM "ShopImportItem" i JOIN "ShopImport" s ON s."id" = i."importId"
          WHERE i."siteId" = ${sequelize.escape(siteId)} AND i."kind" IN ('category', 'tag') AND i."created" = true
            AND s."status" NOT IN ('published')${preview ? ` AND i."importId" <> ${sequelize.escape(preview)}` : ''})`,
      ),
    },
  };
}

/** Orders a shop import brought in: they keep the state they had in WooCommerce (no automatic cancelling). */
export function importedOrderIds() {
  return literal(`(SELECT "targetId" FROM "ShopImportItem" WHERE "kind" = 'order')`);
}
