import { isIP } from 'net';
import { createLogger } from '../../utils/logger';

const log = createLogger('security');

/**
 * The "are you human" check on sign-in and forms: Cloudflare Turnstile, or Google reCAPTCHA
 * (v2 "I'm not a robot" checkbox, or v3 which scores every visitor without asking anything).
 * All three are asked the same way: the token the visitor's browser got, plus the secret key.
 */

export const CAPTCHA_PROVIDERS = ['turnstile', 'recaptcha-v2', 'recaptcha-v3'] as const;
export type CaptchaProvider = (typeof CAPTCHA_PROVIDERS)[number];

const VERIFY_URL: Record<CaptchaProvider, string> = {
  turnstile: 'https://challenges.cloudflare.com/turnstile/v0/siteverify',
  'recaptcha-v2': 'https://www.google.com/recaptcha/api/siteverify',
  'recaptcha-v3': 'https://www.google.com/recaptcha/api/siteverify',
};

export const CAPTCHA_LABEL: Record<CaptchaProvider, string> = {
  turnstile: 'Cloudflare Turnstile',
  'recaptcha-v2': 'Google reCAPTCHA v2',
  'recaptcha-v3': 'Google reCAPTCHA v3',
};

type Answer = { success?: boolean; score?: number; 'error-codes'?: string[] };

async function ask(provider: CaptchaProvider, secret: string, token: string, remoteIp?: string): Promise<Answer | null> {
  try {
    const body = new URLSearchParams({ secret, response: token });
    if (remoteIp && isIP(remoteIp)) body.set('remoteip', remoteIp);
    const res = await fetch(VERIFY_URL[provider], { method: 'POST', body, signal: AbortSignal.timeout(8_000) });
    if (!res.ok) return null;
    return (await res.json()) as Answer;
  } catch (error) {
    log.warn(`Could not reach ${CAPTCHA_LABEL[provider]}: ${(error as Error).message}`);
    return null;
  }
}

const badSecret = (a: Answer) => Boolean(a['error-codes']?.some((c) => c.includes('secret')));

export type CaptchaResult = { ok: true } | { ok: false; reason: 'missing' | 'invalid' | 'unreachable' };

/**
 * Is the visitor's token genuine (and, for v3, human enough)? `unreachable` means the service
 * could not be asked (or our own secret key is wrong): callers let the visitor through then, so
 * an outage at Cloudflare or Google never locks anyone out of the site.
 */
export async function verifyCaptcha(
  provider: CaptchaProvider,
  secret: string,
  token: string | undefined,
  opts: { remoteIp?: string; minScore?: number } = {},
): Promise<CaptchaResult> {
  const value = (token ?? '').trim();
  if (!value) return { ok: false, reason: 'missing' };
  if (value.length > 4096) return { ok: false, reason: 'invalid' };
  const answer = await ask(provider, secret, value, opts.remoteIp);
  if (!answer) return { ok: false, reason: 'unreachable' };
  if (!answer.success) {
    if (badSecret(answer)) {
      log.warn(`${CAPTCHA_LABEL[provider]} refused the secret key saved in Settings → Security.`);
      return { ok: false, reason: 'unreachable' };
    }
    return { ok: false, reason: 'invalid' };
  }
  if (provider === 'recaptcha-v3' && typeof answer.score === 'number' && answer.score < (opts.minScore ?? 0.5)) {
    return { ok: false, reason: 'invalid' };
  }
  return { ok: true };
}

/** The settings test: like verifyCaptcha, but a wrong secret key is reported as such. */
export async function checkCaptchaKeys(provider: CaptchaProvider, secret: string, token: string): Promise<'ok' | 'bad-secret' | 'bad-token' | 'unreachable'> {
  const answer = await ask(provider, secret, token);
  if (!answer) return 'unreachable';
  if (answer.success) return 'ok';
  return badSecret(answer) ? 'bad-secret' : 'bad-token';
}
