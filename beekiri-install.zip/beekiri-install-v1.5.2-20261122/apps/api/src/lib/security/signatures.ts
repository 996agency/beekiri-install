/**
 * What attacks look like from the outside: the user agents of hacking tools, the addresses
 * scanners try on every site they find, and injection attempts in the URL. Kept conservative:
 * a real visitor, a search engine or a site owner must never match by accident.
 */

/** Vulnerability scanners and attack tools that announce themselves. */
const ATTACK_TOOLS =
  /\b(sqlmap|nikto|nmap|masscan|zgrab|nuclei|wpscan|dirbuster|gobuster|ffuf|feroxbuster|acunetix|netsparker|havij|w3af|jaeles|commix|openvas|arachni|skipfish|whatweb|wfuzz|dirb|xsstrike|joomscan|zmeu|morfeus|fimap|nessus|appscan|interactsh|hydra|medusa|metasploit|brutus)\b/i;

export function isAttackTool(userAgent: string): boolean {
  return Boolean(userAgent) && ATTACK_TOOLS.test(userAgent.slice(0, 512));
}

/** Search engines and link previews: their 404s and request rate are counted more leniently. */
const CRAWLERS =
  /\b(googlebot|google-inspectiontool|bingbot|duckduckbot|yandexbot|baiduspider|applebot|slurp|facebookexternalhit|twitterbot|linkedinbot|slackbot|discordbot|whatsapp|telegrambot|ahrefsbot|semrushbot|petalbot)\b/i;

export function isCrawler(userAgent: string): boolean {
  return Boolean(userAgent) && CRAWLERS.test(userAgent.slice(0, 512));
}

/**
 * Paths that only exist on other software (WordPress, phpMyAdmin, leaked config files…).
 * Beekiri serves none of them, so asking for one is scanning.
 */
const PROBE_PREFIXES = [
  '/wp-login.php',
  '/wp-admin',
  '/wp-content/',
  '/wp-includes/',
  '/wp-json/',
  '/wp-config',
  '/xmlrpc.php',
  '/.env',
  '/.git/',
  '/.git',
  '/.svn/',
  '/.hg/',
  '/.aws/',
  '/.ssh/',
  '/.docker',
  '/.htaccess',
  '/.htpasswd',
  '/.vscode/',
  '/.idea/',
  '/.ds_store',
  '/phpmyadmin',
  '/pma/',
  '/myadmin',
  '/adminer',
  '/phpinfo',
  '/info.php',
  '/config.php',
  '/configuration.php',
  '/setup.php',
  '/install.php',
  '/shell.php',
  '/cmd.php',
  '/eval-stdin.php',
  '/vendor/phpunit',
  '/cgi-bin/',
  '/server-status',
  '/boaform',
  '/actuator',
  '/solr/',
  '/manager/html',
  '/hnap1',
  '/telescope/',
  '/_ignition/',
  '/api/jsonws',
  '/administrator/index.php',
  '/sftp-config.json',
  '/docker-compose.yml',
  '/backup.sql',
  '/dump.sql',
  '/database.sql',
  '/db.sql',
  '/magento_version',
];

/**
 * 'probe' for a known scanner path, 'php_probe' for any other .php file, null otherwise.
 * `adminBase` is the site's own admin address: never counted, whatever it was renamed to.
 */
export function probeKind(path: string, adminBase?: string): 'probe' | 'php_probe' | null {
  const p = path.toLowerCase();
  if (adminBase && adminBase !== '/' && (p === adminBase.toLowerCase() || p.startsWith(`${adminBase.toLowerCase()}/`))) return null;
  if (p.startsWith('/api/') || p.startsWith('/.well-known/')) return null;
  if (PROBE_PREFIXES.some((prefix) => p === prefix || p.startsWith(prefix))) return 'probe';
  if (/\.php\d?$/.test(p)) return 'php_probe';
  return null;
}

/** Up to two rounds of %-decoding (scanners double-encode to slip past filters). */
function decoded(raw: string): string {
  let v = raw;
  for (let i = 0; i < 2; i += 1) {
    try {
      const next = decodeURIComponent(v.replace(/\+/g, ' '));
      if (next === v) break;
      v = next;
    } catch {
      break;
    }
  }
  return v;
}

const INJECTION: RegExp[] = [
  // ../../ path traversal
  /(?:\.\.[/\\]){2,}/,
  /\/etc\/(?:passwd|shadow)\b/i,
  // Log4Shell
  /\$\{(?:jndi|env|sys|lower|upper|::-)/i,
  // SQL injection
  /\bunion\b(?:\s|\/\*.*?\*\/)+(?:all\s+|distinct\s+)?select\b/i,
  /'\s*(?:or|and)\s+'?\d+'?\s*=\s*'?\d+/i,
  /\b(?:sleep|pg_sleep|benchmark)\s*\(\s*\d+\s*\)\s*(?:--|#|;|\))/i,
  /\binformation_schema\b/i,
  // Script injection
  /<\s*script\b/i,
  /\bon(?:error|load)\s*=\s*['"]?\s*(?:alert|prompt|confirm|eval)\s*\(/i,
  // PHP and shell tricks
  /\bphp:\/\/(?:input|filter)\b/i,
  /\bbase64_decode\s*\(/i,
  /\b(?:wget|curl)\s+(?:-\S+\s+)*https?:\/\//i,
  /[;|`]\s*(?:uname|whoami)\b/i,
];

/** The URL (path and query) carries an attack pattern. */
export function looksLikeInjection(originalUrl: string): boolean {
  const url = decoded(originalUrl.slice(0, 4096));
  return INJECTION.some((re) => re.test(url));
}

/** Pictures, scripts, fonts: cheap to serve, a page loads many of them. */
const STATIC_FILE = /\.(?:css|js|mjs|map|png|jpe?g|gif|webp|avif|svg|ico|woff2?|ttf|otf|eot|mp4|webm|mp3)$/i;

export function isStaticAsset(path: string): boolean {
  return (
    path.startsWith('/_next/static/') ||
    path.startsWith('/_next/image') ||
    path.startsWith('/uploads/') ||
    path.startsWith('/admin/assets/') ||
    STATIC_FILE.test(path)
  );
}
