import { CAPTCHA_PROVIDERS, type CaptchaProvider } from './captcha';
import { normalizeAddressRule } from './ip';

/**
 * Settings → Security, stored in SiteSettings.options.security. The bot-check secret key and the
 * Cloudflare API token are encrypted (lib/shop/secrets) and never leave the server.
 */

export const SHIELD_LEVELS = ['off', 'balanced', 'strict'] as const;
export type ShieldLevel = (typeof SHIELD_LEVELS)[number];

export const TWO_FACTOR_REQUIRE = ['off', 'admins', 'everyone'] as const;
export type TwoFactorRequire = (typeof TWO_FACTOR_REQUIRE)[number];

/** One address or network the owner listed (203.0.113.7, 203.0.113.0/24, 2001:db8::/48). */
export type AddressRule = { value: string; note: string; addedAt: string };

export type SecurityOptions = {
  shield: {
    level: ShieldLevel;
    /** sqlmap, nikto, wpscan… are refused on sight and their address banned. */
    blockAttackTools: boolean;
    /** Scans for /wp-login.php, /.env, /.git and injection attempts count against the address. */
    blockProbes: boolean;
    /** One address sending far more requests than a person could is banned for a while. */
    floodProtection: boolean;
    /** Tell the people who manage the site (bell) when an address is banned. */
    notify: boolean;
    blocked: AddressRule[];
    allowed: AddressRule[];
  };
  twoFactor: {
    /** Who must use two-step sign-in on this site. */
    require: TwoFactorRequire;
  };
  /** The "are you human" check: Cloudflare Turnstile or Google reCAPTCHA. */
  captcha: {
    provider: CaptchaProvider;
    siteKey: string;
    /** Encrypted. */
    secretKey: string;
    /** Admin sign-in and "forgot password". */
    signIn: boolean;
    /** Bee Forms on the website. */
    forms: boolean;
    /** reCAPTCHA v3 only: visitors scoring lower (0 = bot, 1 = human) are refused. */
    minScore: number;
  };
  cloudflare: {
    /** Refuse visitors that reach this server directly instead of through Cloudflare. */
    onlyCloudflare: boolean;
    api: {
      /** Encrypted API token (Zone → Firewall Services: Edit, Zone Settings: Edit). */
      token: string;
      zoneId: string;
      zoneName: string;
      /** Send Shield bans to Cloudflare, so the attacker is stopped before reaching this server. */
      edgeBans: boolean;
    };
  };
};

export const MAX_ADDRESS_RULES = 500;

export function defaultSecurityOptions(): SecurityOptions {
  return {
    shield: { level: 'balanced', blockAttackTools: true, blockProbes: true, floodProtection: true, notify: true, blocked: [], allowed: [] },
    twoFactor: { require: 'off' },
    captcha: { provider: 'turnstile', siteKey: '', secretKey: '', signIn: false, forms: false, minScore: 0.5 },
    cloudflare: {
      onlyCloudflare: false,
      api: { token: '', zoneId: '', zoneName: '', edgeBans: false },
    },
  };
}

const obj = (v: unknown): Record<string, unknown> =>
  v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : {};
const str = (v: unknown, max: number) => (typeof v === 'string' ? v.replace(/[\r\n\0]+/g, ' ').trim().slice(0, max) : '');
const bool = (v: unknown, fallback: boolean) => (typeof v === 'boolean' ? v : fallback);

/** Turnstile and reCAPTCHA keys are short tokens of letters, digits, `_` and `-`. */
export const KEY_RE = /^[A-Za-z0-9_-]{1,120}$/;
export const MIN_SCORES = [0.3, 0.5, 0.7, 0.9] as const;
export const ZONE_ID_RE = /^[a-f0-9]{32}$/;

function rules(raw: unknown): AddressRule[] {
  if (!Array.isArray(raw)) return [];
  const seen = new Set<string>();
  const out: AddressRule[] = [];
  for (const item of raw) {
    const o = obj(item);
    const value = normalizeAddressRule(str(o.value, 64));
    if (!value || seen.has(value)) continue;
    seen.add(value);
    out.push({ value, note: str(o.note, 120), addedAt: str(o.addedAt, 40) || new Date(0).toISOString() });
    if (out.length >= MAX_ADDRESS_RULES) break;
  }
  return out;
}

export function parseSecurityOptions(raw: unknown): SecurityOptions {
  const d = defaultSecurityOptions();
  const o = obj(raw);
  const shield = obj(o.shield);
  const twoFactor = obj(o.twoFactor);
  const cf = obj(o.cloudflare);
  // Saved before reCAPTCHA was offered: the Turnstile keys lived under cloudflare.turnstile.
  const cap = o.captcha !== undefined ? obj(o.captcha) : { provider: 'turnstile', ...obj(cf.turnstile) };
  const api = obj(cf.api);
  const siteKey = str(cap.siteKey, 120);
  const minScore = Number(cap.minScore);
  const zoneId = str(api.zoneId, 64).toLowerCase();
  return {
    shield: {
      level: SHIELD_LEVELS.includes(shield.level as ShieldLevel) ? (shield.level as ShieldLevel) : d.shield.level,
      blockAttackTools: bool(shield.blockAttackTools, d.shield.blockAttackTools),
      blockProbes: bool(shield.blockProbes, d.shield.blockProbes),
      floodProtection: bool(shield.floodProtection, d.shield.floodProtection),
      notify: bool(shield.notify, d.shield.notify),
      blocked: rules(shield.blocked),
      allowed: rules(shield.allowed),
    },
    twoFactor: {
      require: TWO_FACTOR_REQUIRE.includes(twoFactor.require as TwoFactorRequire)
        ? (twoFactor.require as TwoFactorRequire)
        : d.twoFactor.require,
    },
    captcha: {
      provider: CAPTCHA_PROVIDERS.includes(cap.provider as CaptchaProvider) ? (cap.provider as CaptchaProvider) : d.captcha.provider,
      siteKey: KEY_RE.test(siteKey) ? siteKey : '',
      secretKey: typeof cap.secretKey === 'string' ? cap.secretKey.slice(0, 2000) : '',
      signIn: bool(cap.signIn, false),
      forms: bool(cap.forms, false),
      minScore: (MIN_SCORES as readonly number[]).includes(minScore) ? minScore : d.captcha.minScore,
    },
    cloudflare: {
      onlyCloudflare: bool(cf.onlyCloudflare, false),
      api: {
        token: typeof api.token === 'string' ? api.token.slice(0, 2000) : '',
        zoneId: ZONE_ID_RE.test(zoneId) ? zoneId : '',
        zoneName: str(api.zoneName, 253),
        edgeBans: bool(api.edgeBans, false),
      },
    },
  };
}

/** What the browser needs to show the check for this purpose, or null when it is off (or keys are missing). */
export function captchaFor(options: SecurityOptions, purpose: 'signIn' | 'forms'): { provider: CaptchaProvider; siteKey: string } | null {
  const c = options.captcha;
  return c[purpose] && c.siteKey && c.secretKey ? { provider: c.provider, siteKey: c.siteKey } : null;
}
