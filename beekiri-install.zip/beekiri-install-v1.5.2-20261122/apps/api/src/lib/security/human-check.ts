import { shieldService } from '../../services/security/shield.service';
import { BadRequest } from '../../utils/http-error';
import { decryptSecret } from '../shop/secrets';
import { verifyCaptcha, type CaptchaProvider } from './captcha';
import { captchaFor } from './options';

/**
 * The field a form sends the check's answer in. Our scripts send `_bk_human`; the widgets' own
 * fields (Turnstile, reCAPTCHA v2) are read too, for a page that was cached before.
 */
export const HUMAN_FIELDS = ['_bk_human', 'cf-turnstile-response', 'g-recaptcha-response'] as const;

export type HumanCheck = { provider: CaptchaProvider; siteKey: string };

/** What the browser needs to show the check for this purpose on this site, or null when it is off. */
export async function humanCheckFor(siteId: string | null | undefined, purpose: 'signIn' | 'forms'): Promise<HumanCheck | null> {
  const { options } = await shieldService.loadSite(siteId);
  return captchaFor(options, purpose);
}

/** The first non-empty answer among the known fields of a form body. */
export function humanToken(body: Record<string, unknown>): string | undefined {
  for (const field of HUMAN_FIELDS) {
    const raw = body[field];
    const value = Array.isArray(raw) ? raw[0] : raw;
    if (typeof value === 'string' && value.trim()) return value;
  }
  return undefined;
}

/**
 * When the site uses a bot check for `purpose`, the request must carry an answer the service
 * confirms. Throws a 400 with `code: 'human_check'`, the service and the site key, so a page that
 * was cached before the check was switched on can still show it and try again. If the service
 * can't be reached the visitor goes through (an outage there must not lock everyone out).
 */
export async function requireHuman(
  siteId: string | null | undefined,
  purpose: 'signIn' | 'forms',
  token: unknown,
  ip?: string,
): Promise<void> {
  const { options } = await shieldService.loadSite(siteId);
  const check = captchaFor(options, purpose);
  if (!check) return;
  const secret = decryptSecret(options.captcha.secretKey);
  if (!secret) return;
  const value = Array.isArray(token) ? token[0] : token;
  const result = await verifyCaptcha(check.provider, secret, typeof value === 'string' ? value : undefined, {
    remoteIp: ip,
    minScore: options.captcha.minScore,
  });
  if (result.ok || result.reason === 'unreachable') return;
  throw BadRequest({
    message:
      result.reason === 'missing'
        ? 'Please complete the security check, then try again.'
        : check.provider === 'recaptcha-v3'
          ? 'The security check could not confirm you are a person. Please try again in a moment.'
          : 'The security check expired. Please try it again.',
    code: 'human_check',
    ...check,
  });
}
