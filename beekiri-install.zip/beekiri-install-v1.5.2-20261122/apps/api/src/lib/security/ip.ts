import type { NextFunction, Request, Response } from 'express';
import { BlockList, isIP } from 'net';
import { createLogger } from '../../utils/logger';

const log = createLogger('security');

/** A bare address: no `::ffff:` prefix, no zone id, no brackets. '' when it isn't one. */
export function normalizeIp(raw: string | undefined | null): string {
  let v = (raw ?? '').trim().replace(/^\[|\]$/g, '');
  if (v.toLowerCase().startsWith('::ffff:') && isIP(v.slice(7)) === 4) v = v.slice(7);
  v = v.split('%')[0] ?? '';
  return isIP(v) ? v.toLowerCase() : '';
}

/** The eight groups of an IPv6 address, each without leading zeros. */
function ipv6Groups(ip: string): string[] {
  const [a, b] = ip.includes('::') ? ip.split('::') : [ip, undefined];
  const left = a ? a.split(':') : [];
  const right = b !== undefined && b ? b.split(':') : [];
  // An IPv4 tail (::1.2.3.4) is two groups.
  const tail = right.length ? right : left;
  const last = tail[tail.length - 1] ?? '';
  if (isIP(last) === 4) {
    const [p, q, r, s] = last.split('.').map(Number);
    tail.splice(tail.length - 1, 1, ((p << 8) | q).toString(16), ((r << 8) | s).toString(16));
  }
  const fill = b === undefined ? [] : Array(Math.max(0, 8 - left.length - right.length)).fill('0');
  return [...left, ...fill, ...right].map((g) => (g || '0').replace(/^0+(?=.)/, ''));
}

/**
 * Who a visitor is for limits and bans: their address, or for IPv6 their whole /64 network
 * (one home or server gets a /64 and could otherwise rotate through billions of addresses).
 */
export function ipKey(ip: string): string {
  const v = normalizeIp(ip);
  if (!v) return 'unknown';
  if (isIP(v) !== 6) return v;
  return `${ipv6Groups(v).slice(0, 4).join(':')}::/64`;
}

const LOCAL = new BlockList();
for (const [net, prefix] of [
  ['127.0.0.0', 8],
  ['10.0.0.0', 8],
  ['172.16.0.0', 12],
  ['192.168.0.0', 16],
  ['169.254.0.0', 16],
  ['100.64.0.0', 10],
  ['0.0.0.0', 8],
] as const) {
  LOCAL.addSubnet(net, prefix, 'ipv4');
}
for (const [net, prefix] of [
  ['::1', 128],
  ['::', 128],
  ['fc00::', 7],
  ['fe80::', 10],
] as const) {
  LOCAL.addSubnet(net, prefix, 'ipv6');
}

/**
 * This machine or a private network. Such addresses are never banned: they are the server's
 * own calls, a proxy in front of it (then every visitor would share one address) or a LAN.
 */
export function isLocalAddress(ip: string): boolean {
  const v = normalizeIp(ip);
  if (!v) return true;
  return LOCAL.check(v, isIP(v) === 6 ? 'ipv6' : 'ipv4');
}

/**
 * `203.0.113.7`, `203.0.113.0/24`, `2001:db8::/48` in one canonical spelling, or '' when it
 * is not an address or network. Networks wider than /8 (IPv4) or /16 (IPv6) are refused: they
 * would cover a good part of the internet.
 */
export function normalizeAddressRule(raw: string): string {
  const v = raw.trim().toLowerCase();
  const [addr, prefixRaw, extra] = v.split('/');
  if (extra !== undefined) return '';
  const ip = normalizeIp(addr);
  if (!ip) return '';
  if (prefixRaw === undefined || prefixRaw === '') return ip;
  if (!/^\d{1,3}$/.test(prefixRaw)) return '';
  const prefix = Number(prefixRaw);
  const v6 = isIP(ip) === 6;
  if (v6 ? prefix < 16 || prefix > 128 : prefix < 8 || prefix > 32) return '';
  if ((v6 && prefix === 128) || (!v6 && prefix === 32)) return ip;
  return `${ip}/${prefix}`;
}

/** A set of addresses and networks to test visitors against. */
export class AddressList {
  private readonly list = new BlockList();
  readonly size: number;

  constructor(values: string[]) {
    let n = 0;
    for (const value of values) {
      const rule = normalizeAddressRule(value);
      if (!rule) continue;
      const [addr, prefix] = rule.split('/');
      const type = isIP(addr) === 6 ? 'ipv6' : 'ipv4';
      try {
        if (prefix) this.list.addSubnet(addr, Number(prefix), type);
        else this.list.addAddress(addr, type);
        n += 1;
      } catch {
        /* skipped: not a valid network for BlockList */
      }
    }
    this.size = n;
  }

  has(ip: string): boolean {
    const v = normalizeIp(ip);
    if (!v || !this.size) return false;
    return this.list.check(v, isIP(v) === 6 ? 'ipv6' : 'ipv4');
  }
}

/* ── Cloudflare ─────────────────────────────────────────────────────────── */

/** Cloudflare's published edge ranges (https://www.cloudflare.com/ips/), refreshed daily when in use. */
const CLOUDFLARE_DEFAULT = [
  '173.245.48.0/20',
  '103.21.244.0/22',
  '103.22.200.0/22',
  '103.31.4.0/22',
  '141.101.64.0/18',
  '108.162.192.0/18',
  '190.93.240.0/20',
  '188.114.96.0/20',
  '197.234.240.0/22',
  '198.41.128.0/17',
  '162.158.0.0/15',
  '104.16.0.0/13',
  '104.24.0.0/14',
  '172.64.0.0/13',
  '131.0.72.0/22',
  '2400:cb00::/32',
  '2606:4700::/32',
  '2803:f800::/32',
  '2405:b500::/32',
  '2405:8100::/32',
  '2a06:98c0::/29',
  '2c0f:f248::/32',
];

let cloudflare = new AddressList(CLOUDFLARE_DEFAULT);
let cloudflareCheckedAt = 0;
let cloudflareRefreshing = false;
const CLOUDFLARE_REFRESH_MS = 24 * 60 * 60 * 1000;

/** One of Cloudflare's own servers (the visitor reached us through Cloudflare). */
export function isCloudflareAddress(ip: string): boolean {
  return cloudflare.has(ip);
}

/** Fetch Cloudflare's current ranges at most once a day; the built-in list stays on any failure. */
export function refreshCloudflareRanges(): void {
  if (cloudflareRefreshing || Date.now() - cloudflareCheckedAt < CLOUDFLARE_REFRESH_MS) return;
  if (process.env.VITEST || process.env.NODE_ENV === 'test') return;
  cloudflareRefreshing = true;
  cloudflareCheckedAt = Date.now();
  void (async () => {
    try {
      const res = await fetch('https://api.cloudflare.com/client/v4/ips', { signal: AbortSignal.timeout(8_000) });
      const body = (await res.json()) as { success?: boolean; result?: { ipv4_cidrs?: unknown; ipv6_cidrs?: unknown } };
      const all = [body.result?.ipv4_cidrs, body.result?.ipv6_cidrs]
        .flatMap((x) => (Array.isArray(x) ? x : []))
        .filter((x): x is string => typeof x === 'string');
      const next = new AddressList(all);
      // A short or broken answer never replaces the known list.
      if (body.success && next.size >= 10) cloudflare = next;
    } catch (error) {
      log.warn(`Could not refresh Cloudflare's address list: ${(error as Error).message}`);
    } finally {
      cloudflareRefreshing = false;
    }
  })();
}

const viaCloudflare = new WeakSet<Request>();

/** The request came through one of Cloudflare's servers. */
export function cameThroughCloudflare(req: Request): boolean {
  return viaCloudflare.has(req);
}

/**
 * Behind Cloudflare every visitor would arrive from a Cloudflare server, so limits and bans
 * would hit Cloudflare instead of the visitor. When (and only when) the request really comes
 * from a Cloudflare address, the visitor's own address in CF-Connecting-IP becomes `req.ip`
 * for everything after this. Anyone else sending that header is ignored.
 */
export function cloudflareClientIp(req: Request, _res: Response, next: NextFunction): void {
  const peer = normalizeIp(req.ip);
  if (peer && isCloudflareAddress(peer)) {
    viaCloudflare.add(req);
    refreshCloudflareRanges();
    const real = normalizeIp(req.get('cf-connecting-ip'));
    if (real) Object.defineProperty(req, 'ip', { value: real, configurable: true, enumerable: true, writable: false });
  }
  next();
}
