import { isIP } from 'net';

/* ── Cloudflare API (zone settings, IP Access Rules) ────────────────────── */

const API = 'https://api.cloudflare.com/client/v4';

export class CloudflareApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
  }
}

type Envelope<T> = { success: boolean; result: T; errors?: { code: number; message: string }[] };

async function call<T>(token: string, path: string, init: RequestInit = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API}${path}`, {
      ...init,
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', ...(init.headers ?? {}) },
      signal: AbortSignal.timeout(10_000),
    });
  } catch {
    throw new CloudflareApiError('Could not reach Cloudflare. Check that this server can open https://api.cloudflare.com.', 0);
  }
  let body: Envelope<T> | null = null;
  try {
    body = (await res.json()) as Envelope<T>;
  } catch {
    /* not JSON */
  }
  if (!res.ok || !body?.success) {
    const first = body?.errors?.[0];
    if (res.status === 401 || res.status === 403 || first?.code === 10000 || first?.code === 9109) {
      throw new CloudflareApiError(
        'Cloudflare refused the API token for this. Check that it is active and has the permissions listed below.',
        res.status || 403,
      );
    }
    throw new CloudflareApiError(first?.message ? `Cloudflare answered: ${first.message}` : `Cloudflare answered with an error (${res.status}).`, res.status);
  }
  return body.result;
}

export type CloudflareZone = { id: string; name: string; status: string };

/** Is the token itself active? */
export async function verifyApiToken(token: string): Promise<boolean> {
  const result = await call<{ status?: string }>(token, '/user/tokens/verify');
  return result.status === 'active';
}

export async function listZones(token: string): Promise<CloudflareZone[]> {
  const zones = await call<CloudflareZone[]>(token, '/zones?per_page=50');
  return zones.map((z) => ({ id: z.id, name: z.name, status: z.status }));
}

export async function getZone(token: string, zoneId: string): Promise<CloudflareZone> {
  const z = await call<CloudflareZone>(token, `/zones/${encodeURIComponent(zoneId)}`);
  return { id: z.id, name: z.name, status: z.status };
}

/** The zone that serves `host` (example.com for shop.example.com), if the token can see it. */
export function zoneForHost(zones: CloudflareZone[], host: string): CloudflareZone | null {
  const h = host.toLowerCase().replace(/\.$/, '');
  return (
    zones
      .filter((z) => h === z.name || h.endsWith(`.${z.name}`))
      .sort((a, b) => b.name.length - a.name.length)[0] ?? null
  );
}

export type SecurityLevel = 'off' | 'essentially_off' | 'low' | 'medium' | 'high' | 'under_attack';

export async function getSecurityLevel(token: string, zoneId: string): Promise<SecurityLevel> {
  const r = await call<{ value: SecurityLevel }>(token, `/zones/${encodeURIComponent(zoneId)}/settings/security_level`);
  return r.value;
}

export async function setSecurityLevel(token: string, zoneId: string, value: SecurityLevel): Promise<SecurityLevel> {
  const r = await call<{ value: SecurityLevel }>(token, `/zones/${encodeURIComponent(zoneId)}/settings/security_level`, {
    method: 'PATCH',
    body: JSON.stringify({ value }),
  });
  return r.value;
}

/** Turns a Shield key (an address or an IPv6 /64) into Cloudflare's rule target. */
function ruleTarget(ipKey: string): { target: 'ip' | 'ip6' | 'ip_range'; value: string } | null {
  if (isIP(ipKey) === 4) return { target: 'ip', value: ipKey };
  if (isIP(ipKey) === 6) return { target: 'ip6', value: ipKey };
  // xxxx:xxxx:xxxx:xxxx::/64
  const m = /^([0-9a-f:]+)::\/64$/.exec(ipKey);
  if (m) return { target: 'ip_range', value: `${m[1]}::/64` };
  return null;
}

/** Blocks the address at Cloudflare's edge; returns the rule id. */
export async function createBlockRule(token: string, zoneId: string, ipKey: string, note: string): Promise<string | null> {
  const target = ruleTarget(ipKey);
  if (!target) return null;
  const r = await call<{ id: string }>(token, `/zones/${encodeURIComponent(zoneId)}/firewall/access_rules/rules`, {
    method: 'POST',
    body: JSON.stringify({ mode: 'block', configuration: target, notes: note.slice(0, 500) }),
  });
  return r.id;
}

export async function deleteBlockRule(token: string, zoneId: string, ruleId: string): Promise<void> {
  try {
    await call<unknown>(token, `/zones/${encodeURIComponent(zoneId)}/firewall/access_rules/rules/${encodeURIComponent(ruleId)}`, {
      method: 'DELETE',
    });
  } catch (error) {
    // Already gone (removed in the Cloudflare dashboard): nothing left to do.
    if (error instanceof CloudflareApiError && error.status === 404) return;
    throw error;
  }
}
