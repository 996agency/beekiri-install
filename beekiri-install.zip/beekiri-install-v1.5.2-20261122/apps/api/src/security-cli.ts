import { Op, col, fn, where } from 'sequelize';
import { closeDatabase, connectDatabase, databaseLabel } from './db/sequelize';
import { ipKey } from './lib/security/ip';
import { parseSecurityOptions } from './lib/security/options';
import { mergeSiteOptions, readOptions } from './lib/site/site-options';
import { AuditLog, SecurityBan, Session, SiteSettings, User, UserTwoFactor } from './models';

/**
 * Locked out? Run on the server (from the Beekiri folder):
 *
 *   npm run security -- reset-2fa you@example.com   turn off two-step sign-in for one account
 *   npm run security -- unban 203.0.113.7           lift a Beekiri Shield ban
 *   npm run security -- rescue                      lift every ban, switch off "Cloudflare only"
 *                                                   and the bot check on sign-in (all sites)
 *
 * Only someone who can run commands on the server can do this, which is the point: it is the
 * way back in when the admin itself can't be reached.
 */

const USAGE = 'Usage: npm run security -- reset-2fa <email or username> | unban <address> | rescue';

async function resetTwoFactor(login: string | undefined): Promise<void> {
  const value = (login ?? '').trim().toLowerCase();
  if (!value) throw new Error(USAGE);
  const users = await User.findAll({
    where: { [Op.or]: [where(fn('lower', col('email')), value), where(fn('lower', col('username')), value)] },
  });
  if (!users.length) {
    console.log(`No account matches "${login}".`);
    return;
  }
  for (const user of users) {
    const removed = await UserTwoFactor.destroy({ where: { userId: user.id } });
    await Session.destroy({ where: { userId: user.id } });
    await AuditLog.create({ siteId: user.siteId, userId: user.id, action: 'auth.two_factor_reset', meta: { for: user.id, username: user.username, from: 'command line' } });
    console.log(
      removed
        ? `Two-step sign-in is off for ${user.username} (${user.email}). Sign in with the password and set it up again.`
        : `${user.username} (${user.email}) did not have two-step sign-in.`,
    );
  }
}

async function unban(ip: string | undefined): Promise<void> {
  const value = (ip ?? '').trim().toLowerCase();
  if (!value) throw new Error(USAGE);
  // An IPv6 address is banned as its /64.
  const key = value.endsWith('/64') ? value : ipKey(value);
  const [count] = await SecurityBan.update({ until: new Date(), offenses: 0 }, { where: { ip: key, until: { [Op.gt]: new Date() } } });
  console.log(count ? `Lifted the ban on ${key}. The running site picks this up within a minute.` : `${key} is not banned.`);
}

async function rescue(): Promise<void> {
  const [bans] = await SecurityBan.update({ until: new Date(), offenses: 0 }, { where: { until: { [Op.gt]: new Date() } } });
  console.log(`Lifted ${bans} ban(s).`);
  for (const row of await SiteSettings.findAll()) {
    const options = readOptions(row.options);
    if (!options.security) continue;
    const security = parseSecurityOptions(options.security);
    security.cloudflare.onlyCloudflare = false;
    security.captcha.signIn = false;
    await row.update({ options: mergeSiteOptions(row.options, { security }) as never });
  }
  console.log('Switched off "Cloudflare only" and the bot check on sign-in on every site.');
  console.log('Restart Beekiri (or wait a minute) and sign in again.');
}

async function main(): Promise<void> {
  const [command, arg] = process.argv.slice(2);
  const commands: Record<string, () => Promise<void>> = {
    'reset-2fa': () => resetTwoFactor(arg),
    unban: () => unban(arg),
    rescue,
  };
  const run = command ? commands[command] : undefined;
  if (!run) throw new Error(USAGE);
  await connectDatabase({ attempts: 3 });
  console.log(`Database ${databaseLabel()}`);
  await run();
}

main()
  .catch((error) => {
    console.error((error as Error).message);
    process.exitCode = 1;
  })
  .finally(() => closeDatabase().catch(() => undefined));
