import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, jsonb, optionalDate, optionalText, text, type Json } from './_shared';
import type { Site } from './site.model';
import type { User } from './user.model';

/**
 * A connection to a courier's system (Shop → Settings → Shipping → Couriers): sends orders to the
 * courier and follows parcels. `config` holds the settings (see lib/shop/couriers/config.ts);
 * `credentials` the key and the address token, encrypted with this server's key.
 */
export class ShopCourier extends Model<InferAttributes<ShopCourier>, InferCreationAttributes<ShopCourier>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare name: string;
  /** custom | dhl */
  declare preset: CreationOptional<string>;
  declare enabled: CreationOptional<boolean>;
  declare config: CreationOptional<Json>;
  /** encrypted JSON { secret, pushToken } */
  declare credentials: CreationOptional<string>;
  /** untested | connected | error */
  declare status: CreationOptional<string>;
  declare lastError: CreationOptional<string>;
  /** Last time the courier answered properly. */
  declare lastContactAt: CreationOptional<Date | null>;
  /** { usage: { day, count }, unmatched: string[] } — kept by the background checks. */
  declare state: CreationOptional<Json>;
  declare createdById: CreationOptional<ForeignKey<User['id']> | null>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    ShopCourier.init(
      {
        id: idColumn(),
        siteId: text(),
        name: text({ defaultValue: '' }),
        preset: text({ defaultValue: 'custom' }),
        enabled: bool(true),
        config: jsonb({}),
        credentials: text({ defaultValue: '' }),
        status: text({ defaultValue: 'untested' }),
        lastError: text({ defaultValue: '' }),
        lastContactAt: optionalDate(),
        state: jsonb({}),
        createdById: optionalText(),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopCourier',
        modelName: 'ShopCourier',
        timestamps: true,
        indexes: [{ name: 'ShopCourier_siteId_idx', fields: ['siteId'] }],
      },
    );
  }
}
