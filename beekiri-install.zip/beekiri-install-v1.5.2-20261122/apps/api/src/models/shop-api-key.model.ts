import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, optionalDate, text } from './_shared';
import type { Site } from './site.model';
import type { User } from './user.model';

/**
 * A key for the shop REST API (/api/shop/v1). It acts as the person who created it, with their
 * rights on this site at the time of each request, narrowed by `permission`. Only a hash is kept.
 */
export class ShopApiKey extends Model<InferAttributes<ShopApiKey>, InferCreationAttributes<ShopApiKey>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare userId: ForeignKey<User['id']>;
  declare name: string;
  /** catalog (published products only) | read | read_write */
  declare permission: string;
  declare tokenHash: string;
  declare lastChars: string;
  declare lastUsedAt: CreationOptional<Date | null>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    ShopApiKey.init(
      {
        id: idColumn(),
        siteId: text(),
        userId: text(),
        name: text({ defaultValue: '' }),
        permission: text({ defaultValue: 'read' }),
        tokenHash: text(),
        lastChars: text({ defaultValue: '' }),
        lastUsedAt: optionalDate(),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopApiKey',
        modelName: 'ShopApiKey',
        timestamps: true,
        indexes: [
          { name: 'ShopApiKey_tokenHash_key', unique: true, fields: ['tokenHash'] },
          { name: 'ShopApiKey_siteId_idx', fields: ['siteId'] },
        ],
      },
    );
  }
}
