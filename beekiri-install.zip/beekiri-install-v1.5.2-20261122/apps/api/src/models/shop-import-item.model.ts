import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { bool, date, idColumn, text } from './_shared';
import type { ShopImport } from './shop-import.model';
import type { Site } from './site.model';

export type ShopImportItemKind = 'product' | 'category' | 'tag' | 'media' | 'folder' | 'coupon' | 'customer' | 'order';

/** One thing a shop import created (or reused): where it came from and the row it became. */
export class ShopImportItem extends Model<InferAttributes<ShopImportItem>, InferCreationAttributes<ShopImportItem>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare importId: ForeignKey<ShopImport['id']>;
  declare kind: ShopImportItemKind;
  declare sourceKey: string;
  declare targetId: string;
  declare created: CreationOptional<boolean>;
  declare createdAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    ShopImportItem.init(
      {
        id: idColumn(),
        siteId: text(),
        importId: text(),
        kind: text(),
        sourceKey: text(),
        targetId: text(),
        created: bool(true),
        createdAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopImportItem',
        modelName: 'ShopImportItem',
        timestamps: true,
        updatedAt: false,
        indexes: [
          { name: 'ShopImportItem_importId_kind_idx', fields: ['importId', 'kind'] },
          { name: 'ShopImportItem_source_idx', fields: ['siteId', 'kind', 'sourceKey'] },
          { name: 'ShopImportItem_target_idx', fields: ['siteId', 'kind', 'targetId'] },
        ],
      },
    );
  }
}
