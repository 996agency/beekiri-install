import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, jsonb, optionalDate, optionalText, text } from './_shared';
import type { Site } from './site.model';
import type { User } from './user.model';

export const SHOP_IMPORT_STATUSES = [
  'uploaded',
  'ready',
  'preparing',
  'prepared',
  'publishing',
  'published',
  'discarding',
  'discarded',
  'failed',
] as const;
export type ShopImportStatus = (typeof SHOP_IMPORT_STATUSES)[number];

export type ShopImportFile = { kind: 'wxr' | 'csv' | 'photos'; name: string; size: number };

/**
 * A WooCommerce shop brought in from its export files (Shop → Settings → Import). It is prepared
 * as a preview (products as drafts, categories hidden), then published or discarded. JSON payloads
 * are narrowed by services/shop/woo-import.service.ts.
 */
export class ShopImport extends Model<InferAttributes<ShopImport>, InferCreationAttributes<ShopImport>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  declare createdById: ForeignKey<User['id']> | null;
  declare status: CreationOptional<ShopImportStatus>;
  declare files: CreationOptional<ShopImportFile[]>;
  declare summary: CreationOptional<Record<string, unknown>>;
  declare options: CreationOptional<Record<string, unknown>>;
  declare progress: CreationOptional<Record<string, unknown>>;
  declare report: CreationOptional<Record<string, unknown>>;
  declare previewToken: CreationOptional<string | null>;
  declare hiddenIds: CreationOptional<string[]>;
  declare error: CreationOptional<string | null>;
  declare preparedAt: CreationOptional<Date | null>;
  declare publishedAt: CreationOptional<Date | null>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    ShopImport.init(
      {
        id: idColumn(),
        siteId: text(),
        createdById: optionalText(),
        status: text({ defaultValue: 'uploaded' }),
        files: jsonb([]),
        summary: jsonb({}),
        options: jsonb({}),
        progress: jsonb({}),
        report: jsonb({}),
        previewToken: optionalText(),
        hiddenIds: jsonb([]),
        error: optionalText(),
        preparedAt: optionalDate(),
        publishedAt: optionalDate(),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'ShopImport',
        modelName: 'ShopImport',
        timestamps: true,
        indexes: [
          { name: 'ShopImport_siteId_createdAt_idx', fields: ['siteId', 'createdAt'] },
          { name: 'ShopImport_previewToken_key', unique: true, fields: ['previewToken'] },
        ],
      },
    );
  }
}
