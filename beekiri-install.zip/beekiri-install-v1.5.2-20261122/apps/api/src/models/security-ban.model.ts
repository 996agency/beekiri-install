import {
  Model,
  type CreationOptional,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, int, optionalText, text } from './_shared';

/**
 * An address Beekiri Shield banned for a while. One row per address (an IPv6 visitor counts as
 * their /64); the row stays after the ban ends so a returning attacker is banned for longer.
 * The server keeps the live list in memory (services/security/shield.service.ts); this table
 * lets bans survive a restart.
 */
export class SecurityBan extends Model<InferAttributes<SecurityBan>, InferCreationAttributes<SecurityBan>> {
  declare id: CreationOptional<string>;
  /** The address (or `xxxx:xxxx:xxxx:xxxx::/64`). */
  declare ip: string;
  /** The site the attack came in on (bans apply to the whole server). */
  declare siteId: string | null;
  declare reason: string;
  /** Ban ends at this moment (in the past = not banned any more). */
  declare until: Date;
  /** How many times this address was banned within the last week: each ban lasts longer. */
  declare offenses: CreationOptional<number>;
  declare lastBannedAt: Date;
  /** Cloudflare IP Access Rule id when the ban was also sent to Cloudflare. */
  declare cfRuleId: string | null;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    SecurityBan.init(
      {
        id: idColumn(),
        ip: text(),
        siteId: optionalText(),
        reason: text(),
        until: date(),
        offenses: int(1),
        lastBannedAt: date(),
        cfRuleId: optionalText(),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'SecurityBan',
        modelName: 'SecurityBan',
        timestamps: true,
        indexes: [
          { name: 'SecurityBan_ip_key', unique: true, fields: ['ip'] },
          { name: 'SecurityBan_until_idx', fields: ['until'] },
        ],
      },
    );
  }
}
