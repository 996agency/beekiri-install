import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type NonAttribute,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, int, jsonb, optionalDate, optionalText, text, type Json } from './_shared';
import type { Site } from './site.model';
import type { User } from './user.model';

/** Content documents: pages and posts. */
export class Post extends Model<InferAttributes<Post>, InferCreationAttributes<Post>> {
  declare id: CreationOptional<string>;
  declare siteId: ForeignKey<Site['id']>;
  /** "page" | "post" (and later custom post type slugs) */
  declare type: CreationOptional<string>;
  declare title: string;
  declare slug: string;
  /** "draft" | "publish" */
  declare status: CreationOptional<string>;
  /** { version: 1, html: string, blocks?: [] } */
  declare content: CreationOptional<Json>;
  declare excerpt: CreationOptional<string>;
  /** Media library asset id for the featured image, or null. */
  declare featuredImageId: CreationOptional<string | null>;
  declare authorId: CreationOptional<string | null>;
  /** Last user who saved/updated this post. */
  declare updatedById: CreationOptional<string | null>;
  declare parentId: CreationOptional<string | null>;
  declare menuOrder: CreationOptional<number>;
  declare publishedAt: CreationOptional<Date | null>;
  /** Pages only: the client theme the page belongs to (only the active theme's pages are shown). */
  declare theme: CreationOptional<string | null>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  declare author?: NonAttribute<User | null>;
  declare updatedBy?: NonAttribute<User | null>;

  static initModel(sequelize: Sequelize) {
    Post.init(
      {
        id: idColumn(),
        siteId: text(),
        type: text({ defaultValue: 'page' }),
        title: text(),
        slug: text(),
        status: text({ defaultValue: 'draft' }),
        content: jsonb({ version: 1, html: '' }),
        excerpt: text({ defaultValue: '' }),
        featuredImageId: optionalText(),
        authorId: optionalText(),
        updatedById: optionalText(),
        parentId: optionalText(),
        menuOrder: int(0),
        publishedAt: optionalDate(),
        theme: optionalText(),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'Post',
        modelName: 'Post',
        timestamps: true,
        indexes: [
          // Unique (siteId, type, slug, COALESCE(theme, '')): an expression index, made by the
          // 20261106170000_theme_page_slugs migration (pages have their own addresses per theme).
          { name: 'Post_siteId_type_status_idx', fields: ['siteId', 'type', 'status'] },
          { name: 'Post_siteId_type_updatedAt_idx', fields: ['siteId', 'type', 'updatedAt'] },
          { name: 'Post_siteId_type_theme_idx', fields: ['siteId', 'type', 'theme'] },
        ],
      },
    );
  }
}
