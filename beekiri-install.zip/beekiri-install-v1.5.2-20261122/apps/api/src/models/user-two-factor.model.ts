import {
  Model,
  type CreationOptional,
  type ForeignKey,
  type InferAttributes,
  type InferCreationAttributes,
  type Sequelize,
} from 'sequelize';
import { date, idColumn, int, jsonb, optionalDate, text, type Json } from './_shared';
import type { User } from './user.model';

/**
 * Two-step sign-in for one account (an authenticator app). One row per account, shared by every
 * site of the network the account can open. The secret is encrypted (lib/shop/secrets); recovery
 * codes are stored as sha256 hashes only.
 */
export class UserTwoFactor extends Model<InferAttributes<UserTwoFactor>, InferCreationAttributes<UserTwoFactor>> {
  declare id: CreationOptional<string>;
  declare userId: ForeignKey<User['id']>;
  /** Encrypted base32 secret. While `enabledAt` is null it is a set-up in progress. */
  declare secret: string;
  /** null = not switched on yet (the person is still scanning the code). */
  declare enabledAt: Date | null;
  /** sha256 of each unused recovery code. */
  declare recoveryCodes: CreationOptional<Json>;
  /** The last 30-second step a code was accepted for: the same code never works twice. */
  declare lastStep: CreationOptional<number>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;

  static initModel(sequelize: Sequelize) {
    UserTwoFactor.init(
      {
        id: idColumn(),
        userId: text(),
        secret: text(),
        enabledAt: optionalDate(),
        recoveryCodes: jsonb([]),
        lastStep: int(0),
        createdAt: date(),
        updatedAt: date(),
      },
      {
        sequelize,
        tableName: 'UserTwoFactor',
        modelName: 'UserTwoFactor',
        timestamps: true,
        indexes: [{ name: 'UserTwoFactor_userId_key', unique: true, fields: ['userId'] }],
      },
    );
  }
}
