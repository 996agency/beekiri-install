// Beekiri needs every npm package its workspaces list, the dev ones too: it builds and migrates
// with them (tsup, vite, next, typescript, tsx). An update can bring new packages, and an install
// made with NODE_ENV=production (an update from Settings before 1.3.4) leaves the build tools out:
// install whatever is missing or changed, so nobody has to run `npm install` on the server.
// Used by `npm start` (at every start and restart), `npm run build`, `npm run db:migrate` and core
// updates (`--install` installs even when nothing seems to be missing).
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const API_DIR = join(dirname(fileURLToPath(import.meta.url)), '..');
const ROOT = join(API_DIR, '..', '..');
const TOOLS = [
  ['apps/admin/vendor/beeseo', 'tsup'],
  ['apps/admin', 'vite'],
  ['apps/web', 'next'],
  ['apps/api', 'typescript'],
  ['apps/api', 'tsx'],
];
/** What the installed packages were installed for (see dependencySpec). */
const STAMP = join(ROOT, 'node_modules', '.beekiri-dependencies.json');

const readJson = (file) => {
  try {
    return JSON.parse(readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
};

/**
 * npm, also where it is not on the PATH (hosting panels often start Node directly): the npm that
 * started this process, else the one installed with this Node, else whatever `npm` is.
 */
export function npmCommand() {
  const candidates = [
    process.env.npm_execpath,
    join(dirname(process.execPath), '..', 'lib', 'node_modules', 'npm', 'bin', 'npm-cli.js'),
    join(dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js'),
  ];
  const cli = candidates.find((path) => path && /npm-cli\.c?js$/.test(path) && existsSync(path));
  if (cli) return { command: process.execPath, args: [cli], shell: false };
  return process.platform === 'win32' ? { command: 'npm.cmd', args: [], shell: true } : { command: 'npm', args: [], shell: false };
}

/** Runs npm in the site folder with the output shown, like typing the command there. */
export function runNpm(args, options = {}) {
  const npm = npmCommand();
  return spawnSync(npm.command, [...npm.args, ...args], { cwd: ROOT, stdio: 'inherit', shell: npm.shell, ...options });
}

/** The site folder and every workspace folder in it (root package.json `workspaces`). */
function packageDirs() {
  const dirs = [ROOT];
  for (const pattern of readJson(join(ROOT, 'package.json'))?.workspaces ?? []) {
    if (!pattern.endsWith('/*')) {
      dirs.push(join(ROOT, pattern));
      continue;
    }
    const parent = join(ROOT, pattern.slice(0, -2));
    if (!existsSync(parent)) continue;
    for (const entry of readdirSync(parent, { withFileTypes: true })) {
      if (entry.isDirectory()) dirs.push(join(parent, entry.name));
    }
  }
  return dirs.filter((dir) => existsSync(join(dir, 'package.json')));
}

/**
 * Everything npm installs from: each package.json's dependency lists and the lock file. The
 * version numbers of Beekiri's own packages change with every release, so they are left out.
 */
function dependencySpec() {
  const hash = createHash('sha256');
  for (const dir of packageDirs()) {
    const pkg = readJson(join(dir, 'package.json')) ?? {};
    hash.update(
      JSON.stringify([
        dir.slice(ROOT.length),
        pkg.dependencies ?? {},
        pkg.devDependencies ?? {},
        pkg.optionalDependencies ?? {},
        pkg.overrides ?? {},
      ]),
    );
  }
  const packages = readJson(join(ROOT, 'package-lock.json'))?.packages ?? {};
  for (const [path, entry] of Object.entries(packages)) {
    if (path.includes('node_modules/')) continue;
    const { version: _version, ...rest } = entry ?? {};
    packages[path] = rest;
  }
  hash.update(JSON.stringify(packages));
  return hash.digest('hex');
}

/** Is `name` installed where Node looks for it from `dir` (its node_modules, then the folders above)? */
function installed(dir, name) {
  for (let at = dir; ; at = dirname(at)) {
    if (existsSync(join(at, 'node_modules', name, 'package.json'))) return true;
    if (dirname(at) === at) return false;
  }
}

/** Packages a workspace lists that are not installed. */
function missingPackages() {
  const missing = new Set();
  for (const dir of packageDirs()) {
    const pkg = readJson(join(dir, 'package.json')) ?? {};
    for (const name of Object.keys({ ...pkg.dependencies, ...pkg.devDependencies })) {
      if (!installed(dir, name)) missing.add(name);
    }
  }
  for (const [dir, tool] of TOOLS) {
    if (!installed(join(ROOT, dir), tool)) missing.add(tool);
  }
  return [...missing];
}

/**
 * Installs the packages when one is missing or the lists changed since the last install (a core
 * update, files copied over by hand). True when everything is in place.
 */
export function ensureDependencies({ force = false } = {}) {
  const spec = dependencySpec();
  const stamp = readJson(STAMP);
  const missing = missingPackages();
  const changed = Boolean(stamp) && stamp.spec !== spec;
  if (!force && !missing.length && !changed) {
    // First check on a site installed before this file kept a record: what is there is complete.
    if (!stamp) writeStamp(spec);
    return true;
  }
  const shown = missing.slice(0, 6).join(', ') + (missing.length > 6 ? ', …' : '');
  console.log(
    missing.length
      ? `\nInstalling the packages Beekiri needs (${shown} missing)…`
      : '\nInstalling the packages this version of Beekiri needs…',
  );
  // --include=dev: Beekiri builds itself on the server, also where NODE_ENV=production.
  const result = runNpm(['install', '--include=dev', '--prefer-offline', '--no-audit', '--no-fund']);
  if (result.status !== 0) {
    console.error(`\nInstalling the packages failed${result.error ? ` (${result.error.message})` : ''}.`);
    // Nothing is missing, only the lists changed (and npm cannot get the rest, e.g. offline):
    // Beekiri starts with what is installed and tries again next time.
    if (!force && !missing.length) {
      console.error('Starting with the packages already installed.\n');
      return true;
    }
    return false;
  }
  const stillMissing = missingPackages();
  if (stillMissing.length) {
    console.error(`\nThese packages are still missing after installing: ${stillMissing.join(', ')}.`);
    return false;
  }
  // Read again: npm may have tidied package-lock.json.
  writeStamp(dependencySpec());
  return true;
}

function writeStamp(spec) {
  try {
    writeFileSync(STAMP, `${JSON.stringify({ spec, installedAt: new Date().toISOString() }, null, 2)}\n`);
  } catch {
    /* no node_modules folder yet: the next check compares the packages themselves */
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  process.exit(ensureDependencies({ force: process.argv.includes('--install') }) ? 0 : 1);
}
