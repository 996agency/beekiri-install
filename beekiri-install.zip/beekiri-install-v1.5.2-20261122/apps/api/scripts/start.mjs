// `npm start`: install the packages and build what is missing, then run Beekiri and restart it
// when it asks to (after the setup wizard saves the database settings, or after an update).
// Every restart prepares again like a fresh `npm start`, with this file as it is on disk then
// (an update may have replaced it), so nobody has to run anything on the server. A site that
// uses Beekiri's own database (DB_BUILTIN=1) gets it started first and stopped on exit.
import { spawn, spawnSync } from 'node:child_process';
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ensureDependencies, runNpm } from './ensure-tools.mjs';

const SELF = fileURLToPath(import.meta.url);
const API_DIR = join(dirname(SELF), '..');
const ROOT = join(API_DIR, '..', '..');
/** Must match RESTART_EXIT_CODE in src/utils/restart.ts. */
const RESTART_EXIT_CODE = 75;

const SKIP_DIRS = new Set(['node_modules', 'dist', '.next', '.next-dev', 'dist-staged', 'dist-previous', '.next-staged', '.next-previous']);

/** Newest modification time among these files and folders (recursively). */
function newest(paths) {
  let latest = 0;
  for (const path of paths) {
    if (!existsSync(path)) continue;
    const stat = statSync(path);
    if (!stat.isDirectory()) {
      latest = Math.max(latest, stat.mtimeMs);
      continue;
    }
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      if (entry.isDirectory() && SKIP_DIRS.has(entry.name)) continue;
      latest = Math.max(latest, newest([join(path, entry.name)]));
    }
  }
  return latest;
}

const ADMIN = join(ROOT, 'apps/admin');
const WEB = join(ROOT, 'apps/web');
const BEESEO = join(ROOT, 'apps/admin/vendor/beeseo');
const builds = [
  {
    workspace: '@beekiri/beeseo',
    output: join(BEESEO, 'dist/index.js'),
    sources: ['src', 'package.json', 'tsup.config.ts'].map((p) => join(BEESEO, p)),
  },
  {
    workspace: '@beekiri/admin',
    output: join(ADMIN, 'dist/index.html'),
    sources: ['src', 'public', 'index.html', 'vite.config.ts', 'package.json'].map((p) => join(ADMIN, p)),
  },
  {
    workspace: '@beekiri/web',
    // Written only by a completed build (BUILD_ID also exists after a failed one).
    output: join(WEB, '.next/prerender-manifest.json'),
    sources: ['src', 'modules', 'public', 'next.config.ts', 'package.json'].map((p) => join(WEB, p)),
  },
  {
    workspace: '@beekiri/api',
    output: join(API_DIR, 'dist/server.js'),
    sources: ['src', 'package.json'].map((p) => join(API_DIR, p)),
  },
];

/**
 * A deploy package (Settings → Migration) arrives already built and says so in .beekiri-prebuilt.
 * Unzipping does not always keep file dates, so for that version the built files are trusted
 * instead of compared by date. A core update changes the version, and builds as usual.
 */
function prebuiltVersion() {
  try {
    return JSON.parse(readFileSync(join(ROOT, '.beekiri-prebuilt'), 'utf8')).version;
  } catch {
    return null;
  }
}
const prebuilt = prebuiltVersion() === JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8')).version;
const extensionUpdater = join(ROOT, 'scripts', 'extension-update.mjs');

/** Packages, an interrupted extension update, builds. 0 when Beekiri is ready to run. */
function prepare() {
  if (!ensureDependencies()) return 1;

  // An extension update the server stopped in the middle of (power cut, reboot): its files go
  // back first, so nothing half-updated is built below.
  if (existsSync(extensionUpdater)) {
    spawnSync(process.execPath, [extensionUpdater, '--recover'], { cwd: ROOT, stdio: 'inherit' });
  }

  for (const { workspace, output, sources } of builds) {
    const missing = !existsSync(output);
    if (!missing && (prebuilt || statSync(output).mtimeMs >= newest(sources))) continue;
    console.log(`\nBuilding ${workspace} (${missing ? 'first start' : 'code changed since the last build'})…`);
    const result = runNpm(['run', 'build', '-w', workspace]);
    if (result.status !== 0) return result.status ?? 1;
  }
  return 0;
}

// `node start.mjs --prepare`: what the launcher runs before each restart.
if (process.argv.includes('--prepare')) process.exit(prepare());

const prepared = prepare();
if (prepared !== 0) process.exit(prepared);

let child;
let preparing = null;
let stopping = false;
let database = null;

/** Before a restart: prepare with the newest copy of this file (in its own process). */
function prepareAgain() {
  return new Promise((resolve) => {
    preparing = spawn(process.execPath, [SELF, '--prepare'], { cwd: ROOT, stdio: 'inherit' });
    preparing.on('error', () => resolve(false));
    preparing.on('exit', (code) => resolve(code === 0));
  }).finally(() => {
    preparing = null;
  });
}

/** apps/api/.env as plain values (read again on every restart: the setup wizard writes it). */
function readEnv() {
  const file = join(API_DIR, '.env');
  if (!existsSync(file)) return {};
  const env = {};
  for (const line of readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)$/.exec(line);
    if (!m) continue;
    const raw = m[2].trim();
    const quoted = /^(['"`])(.*)\1$/.exec(raw);
    env[m[1]] = quoted ? quoted[2] : raw;
  }
  return env;
}

async function startDatabase() {
  const env = readEnv();
  if (database || env.DB_BUILTIN !== '1') return;
  const { startBuiltinDatabase } = await import('./builtin-db.mjs');
  try {
    database = await startBuiltinDatabase({
      port: Number(env.DB_PORT),
      password: env.DB_PASSWORD,
      log: (message) => console.log(message),
    });
  } catch (error) {
    console.error(`\nBeekiri's database could not start: ${error instanceof Error ? error.message : error}\n`);
    process.exit(1);
  }
}

/**
 * The server stopped while a version an extension update just switched to may still be swapped
 * back (scripts/extension-update.mjs keeps the previous build for a few minutes): put it back.
 * The server does this itself for errors it can catch; this also covers the ones it cannot.
 */
function rollBackExtensionUpdate() {
  const status = join(ROOT, '.beekiri-extension-update.json');
  if (!existsSync(status) || !existsSync(extensionUpdater)) return false;
  try {
    const job = JSON.parse(readFileSync(status, 'utf8'));
    const pending = job.state === 'restarting' || (job.state === 'done' && Date.parse(job.probationUntil ?? '') > Date.now());
    if (!pending || !job.swap?.length) return false;
    const res = spawnSync(process.execPath, [extensionUpdater, '--rollback'], { cwd: ROOT, stdio: 'inherit' });
    return res.status === 0 && JSON.parse(readFileSync(status, 'utf8')).state === 'rolled-back';
  } catch {
    return false;
  }
}

async function exit(code) {
  await database?.stop().catch(() => {});
  process.exit(code);
}

async function run({ restart = false } = {}) {
  await startDatabase();
  if (restart && !(await prepareAgain()) && !stopping) {
    console.error('\nBeekiri could not finish preparing the new version (see above). Starting with what is there.\n');
  }
  if (stopping) return exit(0);
  child = spawn(process.execPath, [join(API_DIR, 'dist/server.js')], {
    cwd: API_DIR,
    stdio: 'inherit',
    env: { ...process.env, NODE_ENV: process.env.NODE_ENV || 'production', BEEKIRI_SUPERVISED: '1' },
  });
  child.on('exit', (code, signal) => {
    if (!stopping && code === RESTART_EXIT_CODE) return void run({ restart: true });
    if (!stopping && rollBackExtensionUpdate()) {
      console.error('\nBeekiri stopped right after an extension update. The previous version was put back; starting again.\n');
      return void run();
    }
    void exit(code ?? (signal ? 1 : 0));
  });
}

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    stopping = true;
    preparing?.kill(signal);
    if (child) child.kill(signal);
    else void exit(0);
  });
}

void run();
