// Copies non-TypeScript runtime files into dist/ after `tsc` (or into the folder given, e.g.
// dist-staged when an extension update builds its new version next to the live one).
import { cpSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const outDir = process.argv[2] || 'dist';
const assets = ['lib/layouts/php/layout-runner.php', 'lib/forms/form.css', 'lib/bookings/booking.css'];

for (const rel of assets) {
  const to = join(root, outDir, rel);
  mkdirSync(dirname(to), { recursive: true });
  cpSync(join(root, 'src', rel), to);
}
