/**
 * The admin shows the website in a frame to preview something on it, for example the cookie
 * banner (`/?beekiri-preview=cookies`). Only true inside such a frame: opening that address on
 * its own is a normal visit.
 */
export function previewFrameKind(): string | null {
  if (typeof window === 'undefined' || window.parent === window) return null;
  try {
    return new URLSearchParams(window.location.search).get('beekiri-preview');
  } catch {
    return null;
  }
}
