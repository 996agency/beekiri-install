import { NextResponse, type NextRequest } from 'next/server';

/** Shop import preview (Shop → Settings → Import): which pages it covers and the cookie that turns it on. */
const SHOP_PREVIEW_PATH = /^\/(?:shop|product)(?:\/|$)/;
const SHOP_PREVIEW_COOKIE = 'bk_shop_import_preview';

/**
 * Keep public routes static (ISR / bfcache-friendly) by rewriting preview
 * queries onto an internal dynamic segment — admin preview URLs stay the same:
 * `/?preview=1&token=…` and `/about?preview=1&token=…`.
 */
export function middleware(request: NextRequest) {
  // Shop account email links (confirm email, reset password) carry their own `token`.
  if (request.nextUrl.pathname === '/account' || request.nextUrl.pathname.startsWith('/account/')) {
    return NextResponse.next();
  }
  // `?shop-preview=<code>` starts a shop import preview, `?shop-preview=exit` ends it; while it is
  // on, shop and product pages show the import's draft products (never cached, never public).
  const shopPreview = request.nextUrl.searchParams.get('shop-preview');
  if (shopPreview !== null) {
    const url = request.nextUrl.clone();
    url.searchParams.delete('shop-preview');
    const response = NextResponse.redirect(url);
    if (/^[A-Za-z0-9_-]{16,128}$/.test(shopPreview)) {
      response.cookies.set(SHOP_PREVIEW_COOKIE, shopPreview, {
        httpOnly: true,
        sameSite: 'lax',
        path: '/',
        maxAge: 24 * 60 * 60,
        secure: request.nextUrl.protocol === 'https:',
      });
    } else response.cookies.delete(SHOP_PREVIEW_COOKIE);
    return response;
  }
  const shopPreviewCode = request.cookies.get(SHOP_PREVIEW_COOKIE)?.value;
  if (shopPreviewCode && SHOP_PREVIEW_PATH.test(request.nextUrl.pathname) && /^[A-Za-z0-9_-]{16,128}$/.test(shopPreviewCode)) {
    const url = request.nextUrl.clone();
    url.pathname = `/bk-preview${url.pathname}`;
    url.searchParams.set('shopPreview', shopPreviewCode);
    return NextResponse.rewrite(url);
  }

  const preview = request.nextUrl.searchParams.get('preview');
  const token = request.nextUrl.searchParams.get('token');
  const wantPreview = preview === '1' || preview === 'true' || Boolean(token);
  if (!wantPreview) return NextResponse.next();

  const url = request.nextUrl.clone();
  const path = url.pathname === '/' ? '' : url.pathname;
  // Not "__preview": Next.js treats folders starting with "_" as private (never routed).
  url.pathname = `/bk-preview${path}`;
  return NextResponse.rewrite(url);
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|uploads|runtime|favicon|.*\\..*).*)'],
};
