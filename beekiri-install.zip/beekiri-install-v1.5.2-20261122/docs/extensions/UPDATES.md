# Extension updates

Beekiri's extensions (Bee Shopping, Bee Forms, Bee Bookings) can get new versions without a
Beekiri Core release. Sites see them in **Extensions**, where each installed extension has an
**Automatic updates** switch (on by default). With it on, the site installs the new version by
itself at night; with it off, the owner clicks **update now** in the extension's row.

New versions are packed on the publishing machine in **Beekiri-Store** (`~/Desktop/Beekiri-Store`,
not in git) and uploaded to the **Beekiri Hub** (996ai → Beekiri → Extensions). Sites read the
newest version of each from the Hub (`/api/beekiri/v1/extensions`).

This page is for the people who publish those updates.

## What an extension update may change

Only the extension's own files, listed in `scripts/extension-files.mjs` (for example
`apps/api/src/services/shop/`, `apps/admin/src/screens/shop/`, `apps/web/themes/beekiri/shop/`).
A site refuses a package that contains anything else.

Ship these in a **Beekiri Core release** instead:

- database changes (migrations) and model changes;
- new npm packages;
- changes to shared code: routes registration, the page editor, the Beekiri assistant's tool
  list, the admin menu, `catalog.ts`, other extensions;
- changes to `scripts/extension-files.mjs` itself (a new owned path only counts on sites that
  run a release containing it).

The extension's exported functions and types are used by core code (for example
`ordersService.sweepExpired`, `SHOP_EXTENSION_SLUG`). Keep them, or the update will not build
against the released core and packing stops.

## Publishing a new version

1. Make the change in this project, on `main`.
2. In the extension's `extension.json` (`apps/api/src/lib/<shop|forms|bookings>/extension.json`):
   raise `version`, add a `changelog` entry for it written for site owners, and set `requires` to
   the oldest Beekiri release it must work with (normally the newest release).
3. Commit (and push, so the next Beekiri release ships the same code).
4. In Beekiri-Store: `node pack.mjs extension <shopping|bee-forms|bee-bookings>`.
   `--requires 1.4.3` checks against more releases (every release from that one to the newest).
5. Upload `ready-to-upload/<slug>-<version>.zip` in 996ai → Beekiri → Extensions → **Upload a new
   version**, then **Publish version**. (Or `php artisan beekiri:extension-publish <zip>` on the Hub.)

`pack.mjs` refuses uncommitted extension files, a version that is not newer than the one the newest
release ships, a missing changelog entry, and a `requires` older than the first release with the
extension updater. It puts the extension's files into the code of every release from `requires` to
the newest and type-checks the server (and the admin and website when the update touches them), and
checks every npm package the files import is installed by that release.

The package carries `beekiri-extension.json` (version, `requires`, notes, the owned paths and every
file with its SHA-256) and `beekiri-extension.sig`: that description signed with the release key
(`~/.beekiri/release-signing-key.pem`, signed text `beekiri-extension:v1\n<slug>\n<version>\n<sha256>`).
The Hub checks the signature and every file when it is uploaded, but never signs anything itself:
sites trust only the release key, so nobody who gets into the Hub can push code to them.

On the Hub, a version can be hidden (sites that have not installed it don't get it; the version
before it is offered instead) or deleted. The page also shows how many sites report each version
(from their daily check-in) and how often each was downloaded.

The next Beekiri Core release always contains the newest extension code from `main`, so sites
that update the core get the extension version too.

## What a site does with it

`scripts/extension-update.mjs`, started by the API (Update now, or the hourly check between 1:00
and 5:00 server time, one extension at a time; `BEEKIRI_AUTO_UPDATE_HOURS=2-4` changes the
hours):

1. Downloads the ZIP from the Hub and unpacks it into a work folder.
2. Checks the release-key signature of its description, that every file is exactly the signed one
   (nothing changed, added or missing), the extension name and version, that the site's Beekiri is
   at least `requires`, and that every file belongs to the extension. Works out which files really
   change.
3. Saves a copy of those files in `backups/extension-<slug>-v<old>-<time>/` (with `update.log`).
4. Builds the new version next to the live one (`apps/api/dist-staged`, `apps/admin/dist-staged`,
   `apps/web/.next-staged`, only the parts that change). The site keeps serving the current build.
5. Loads every module of the new server once without starting it (`BEEKIRI_SMOKE_TEST=1`).
6. Records which key addresses answer (home page, admin, `/api/health`, `/shop` for Shopping),
   switches the builds (the old ones become `*-previous`) and restarts.
7. On the new version: if the server does not start, crashes within three minutes, or one of those
   addresses now fails, the previous build and files are put back and the server starts again.
   After three minutes the previous builds are removed.

Any failure before the switch puts the files back, so the site stays exactly as it was. A server
that stops in the middle (power cut) is tidied up at the next `npm start`. The owners get a
notification either way. A version that fails is retried automatically at most three times, once
a night; **update now** can always try again.

Sites only install updates when Beekiri runs with `npm start` (it restarts itself) in production
and the folder is not a git checkout. `BEEKIRI_EXTENSION_UPDATES=0` turns them off on a server.
On a network of sites, the code is shared: an extension updates automatically only when every
site that has it installed leaves its switch on.
