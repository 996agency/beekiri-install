# Bee Shopping — REST API (v1)

For developers who connect an app, another website, or a stock, accounting or shipping tool to
a Beekiri shop. Everything here is under `https://<your-site>/api/shop/v1`.

## 1. Keys

The shop owner creates keys in **Shop → Settings → REST API**. A key looks like
`bk_shop_…` (51 characters). It is shown once; Beekiri keeps only a hash of it.

Send it with every request:

```
Authorization: Bearer bk_shop_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

Each key has one of three permissions:

| Permission | Can do |
|---|---|
| **Products only** (`catalog`) | Read published products that are not hidden from the catalogue, categories and tags. Safe to ship inside an app or a web page. |
| **Read** (`read`) | Every read: products in any status, orders, customers, coupons. |
| **Read and write** (`read_write`) | Everything above, plus creating and changing products, stock, orders and coupons. Keep it on a server. |

A key acts as the person who created it, with the rights that person has on the site **at the
time of each request**. If they are removed from the site, or lose the right to manage the shop
(`manage_shop`), their keys stop working. Writes follow the same rules as the admin: an editor
key cannot do what that editor cannot do in the admin, descriptions are cleaned like in the
product editor, stock changes and order emails behave exactly as when the change is made by hand.

Keys only work on the site they were made on (multisite, staging and production each have
their own). Database copies between sites never carry keys.

## 2. Conventions

- **JSON** in and out. Send `Content-Type: application/json` with a body.
- **Money** is a whole number in the currency's smallest unit: with EUR, `1250` is €12.50.
  `GET /` returns `currency` and `currencyDecimals` (divide by 10^`currencyDecimals`).
- **Dates** are ISO 8601 in UTC (`2026-11-18T09:30:00.000Z`).
- **Lists** return `{ items, total, page, perPage, pages }` (coupons, categories and tags:
  `{ items }`). Use `page` (from 1) and `perPage` (1–100, default 20 for products, 25 for orders
  and customers).
- **Ids** are strings. Product ids are the same ids the admin shows in product links.
- **Errors** return a status code and `{ statusCode, message, error }`; validation errors carry
  a list of messages.

| Status | Meaning |
|---|---|
| 400 | The body or query is not valid (see `message`). |
| 401 | No key, or the key is not valid (revoked, or for another site). |
| 403 | The key's permission is too low, or its creator lacks the right. |
| 404 | Not found (or the shop extension is turned off). |
| 409 | Conflict, e.g. a coupon code already in use. |
| 429 | Too many requests: wait for `Retry-After` seconds. |

**Limits:** 300 requests per minute per key. Thirty requests with a key that does not work
within 15 minutes block that address for a while. The site's firewall (Beekiri Shield) also
counts requests per address, so spread large syncs over time instead of sending them all at once.

**From a browser:** the API answers any origin (CORS `*`, no cookies). Only put a
**Products only** key in front-end code.

## 3. Shop

`GET /` — any key

```json
{ "name": "Be Clothing", "url": "https://shop.example", "currency": "EUR", "currencyDecimals": 2,
  "apiVersion": "v1", "key": { "name": "Mobile app", "permission": "catalog" } }
```

## 4. Products

### List — `GET /products` (any key)

| Query | |
|---|---|
| `q` | Search in names and SKUs. |
| `sku` | SKU of the product or of one of its variants (case-insensitive). |
| `slug` | Exact slug. |
| `status` | `publish` (default), `draft`, `trash`, `any` (all but the trash). Products-only keys always get `publish`. |
| `category` | Category id or slug; sub-categories included. |
| `tag` | Tag id or slug. |
| `type` | `simple` or `variable`. |
| `stock` | `instock`, `outofstock`, `onbackorder`. |
| `featured` | `true` / `false`. |
| `updatedAfter` | ISO date: products whose content, price, stock or any variant changed since then (for syncing). |
| `sort` | `menu_order` (default, the shop's order), `newest`, `updated`, `title`, `price`, `price-desc`, `popularity`. |
| `page`, `perPage` | Pagination. |

### One product — `GET /products/{id or slug}` (any key)

```json
{
  "id": "cmw…", "name": "Oversized Tee", "slug": "oversized-tee", "status": "publish",
  "url": "https://shop.example/product/oversized-tee",
  "type": "variable", "sku": "TEE",
  "description": "<p>…</p>", "shortDescription": "<p>…</p>",
  "currency": "EUR", "price": 5200, "priceMax": 5600, "priceFormatted": "€52.00 – €56.00", "onSale": false,
  "regularPrice": null, "salePrice": null, "saleFrom": null, "saleTo": null,
  "inStock": true, "stockStatus": "instock", "manageStock": false, "stockQty": null,
  "soldIndividually": false, "virtual": false, "taxable": true, "featured": false,
  "weight": 200, "dimensions": { "length": null, "width": null, "height": null },
  "image": { "id": "…", "url": "https://shop.example/uploads/…webp", "alt": "", "width": 1200, "height": 1500 },
  "gallery": [],
  "categories": [{ "id": "…", "name": "T-shirts", "slug": "t-shirts" }],
  "tags": [],
  "attributes": [{ "name": "Size", "options": ["S", "M"], "visible": true, "variation": true }],
  "variants": [
    { "id": "…", "sku": "TEE-S", "attributes": { "Size": "S" }, "price": 5200, "onSale": false,
      "regularPrice": 5200, "salePrice": null, "saleFrom": null, "saleTo": null,
      "inStock": true, "stockStatus": "instock", "manageStock": true, "stockQty": 4,
      "weight": null, "image": null, "enabled": true, "menuOrder": 0 }
  ],
  "createdAt": "…", "updatedAt": "…", "publishedAt": "…"
}
```

- `price` is what a customer pays now (sale included); for variable products the lowest
  variant price, `priceMax` the highest.
- `inStock` says whether it can be bought now; `stockStatus` is the stored setting.
- `updatedAt` is the latest change to the product, its price and stock or any variant.
- With a **Read** or **Read and write** key the product also has `catalogVisibility`,
  `lowStockThreshold`, `purchaseNote` (sent to buyers after payment) and `totalSales`, and
  `variants` include disabled ones (`enabled: false`).
- Weight is in grams, dimensions in millimetres (as in the product editor).

### Create — `POST /products` (Read and write, `edit_products`)

Send at least `name`. New products are drafts unless `"status": "publish"`.

```bash
curl -X POST https://shop.example/api/shop/v1/products \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{ "name": "Mug", "status": "publish", "sku": "MUG-1", "regularPrice": 1200,
        "manageStock": true, "stockQty": 25, "categoryIds": ["…"] }'
```

If any detail is refused (for example a sale price above the regular price) nothing is created.

### Change — `PATCH /products/{id}` (Read and write, `edit_products`)

Send only what changes. Fields (all optional):

`name`, `slug`, `status` (`draft` / `publish`), `description` (HTML), `shortDescription`,
`type` (`simple` / `variable`), `sku`, `regularPrice`, `salePrice` (null removes it), `saleFrom`,
`saleTo`, `manageStock`, `stockQty`, `stockStatus`, `lowStockThreshold`, `soldIndividually`,
`virtual`, `taxable`, `featured`, `catalogVisibility` (`visible`, `catalog`, `search`, `hidden`),
`weight`, `length`, `width`, `height`, `imageId` (null removes it), `galleryIds`, `attributes`,
`variants`, `categoryIds`, `tagIds`, `purchaseNote`.

- `imageId` and `galleryIds` are ids from the site's Media library (upload photos there first).
- `categoryIds` / `tagIds` replace the product's categories / tags (ids from `GET /categories`, `GET /tags`).
- `variants` **replaces the whole list**: variants left out are deleted. Send `id` to keep an
  existing one. To change one variant, use the variant endpoint below instead.
- A sale price is checked against the stored regular price when only one of them is sent.

Stock of a simple product:

```bash
curl -X PATCH https://shop.example/api/shop/v1/products/$ID \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{ "manageStock": true, "stockQty": 12 }'
```

### Change one variant — `PATCH /products/{id}/variants/{variantId}` (Read and write)

Only this variant is written, so stock the shop just sold on the other variants is never
overwritten. Fields: `sku`, `attributes`, `regularPrice`, `salePrice`, `saleFrom`, `saleTo`,
`manageStock`, `stockQty`, `stockStatus`, `weight`, `imageId`, `enabled`, `menuOrder`.
Returns the whole product.

### Delete — `DELETE /products/{id}` (Read and write)

Moves it to the trash: `{ "id": "…", "trashed": true, "deleted": false }`.
`?force=true` deletes it for good.

## 5. Categories and tags — any key

`GET /categories` → `{ items: [{ id, name, slug, parentId, description, count, url, image }] }`
(`count` = published products; `parentId` builds the tree).

`GET /tags` → `{ items: [{ id, name, slug, description, count }] }`

## 6. Orders — Read, `edit_shop_orders`

### List — `GET /orders`

| Query | |
|---|---|
| `status` | `pending`, `on-hold`, `processing`, `completed`, `cancelled`, `refunded`, `failed` (or `all`). |
| `q` | Order number, email, name or address text, payment reference. |
| `customerId` | Orders of one customer. |
| `payment` | `stripe`, `bank_transfer`, `cod`. |
| `from`, `to` | Placed between these dates. |
| `page`, `perPage` | Pagination (newest first). |

### One order — `GET /orders/{id}`

```json
{
  "id": "…", "number": 1001, "numberLabel": "#1001", "status": "processing", "statusLabel": "Processing",
  "currency": "EUR", "subtotal": 2400, "discountTotal": 0, "shippingTotal": 300, "taxTotal": 0,
  "total": 2700, "refundedTotal": 0, "couponCode": null,
  "customerId": "…", "customerName": "Ana Berisha", "email": "ana@example.com", "phone": "",
  "billing": { "firstName": "Ana", "lastName": "Berisha", "line1": "…", "city": "…", "postcode": "…", "country": "XK" },
  "shipping": { … }, "shipToDifferent": false,
  "shippingMethod": { … }, "paymentMethod": "cod", "paymentMethodTitle": "Cash on delivery",
  "paymentStatus": "unpaid", "transactionId": "",
  "customerNote": "", "customFields": [{ "key": "gift", "label": "Gift wrap", "value": "Yes" }],
  "fulfillment": { "status": "unfulfilled", "carrier": "", "trackingNumber": "", "trackingUrl": "" },
  "items": [{ "id": "…", "productId": "…", "variantId": null, "name": "Mug", "sku": "MUG-1",
              "qty": 2, "unitPrice": 1200, "subtotal": 2400, "total": 2400, "taxTotal": 0,
              "attributes": {}, "image": "https://…", "virtual": false }],
  "notes": [{ "id": "…", "note": "…", "isCustomerNote": false, "author": "System", "createdAt": "…" }],
  "placedAt": "…", "paidAt": null, "completedAt": null, "updatedAt": "…"
}
```

`items[].productId` is the product id used by `/products` (null when the product was deleted).
`notes` are only in the single order.

### Change — `PATCH /orders/{id}` (Read and write)

`status` (with an optional `statusNote` added to the customer's email), `email`, `phone`,
`billing`, `shipping`, `customerNote`. Status changes behave as in the admin: stock is held or
released, the customer gets the status email.

### Fulfilment — `POST /orders/{id}/fulfillment` (Read and write)

`{ "status": "shipped", "carrier": "DHL", "trackingNumber": "…", "trackingUrl": "https://…", "notify": true }`
— `status` is `unfulfilled`, `packed`, `shipped` or `delivered` (delivered completes the order).
Add `"courierId": "…"` (a connection from Shop → Settings → Shipping → Couriers) to have that
courier follow the parcel and fill in its tracking link; `"courierId": ""` stops following it.
Orders then carry `fulfillment.courier` (state, stage, the courier's latest events).

### Note — `POST /orders/{id}/notes` (Read and write)

`{ "note": "Booked in accounting", "isCustomerNote": false }` — a customer note is emailed to
the customer.

## 7. Customers — Read, `edit_shop_orders`

`GET /customers?q=&page=&perPage=` and `GET /customers/{id}`:
`{ id, email, firstName, lastName, name, phone, billing, shipping, ordersCount, totalSpent,
lastOrderAt, hasAccount, emailVerified, lastLoginAt, createdAt }`.

## 8. Coupons — `edit_shop_orders`

`GET /coupons`, `GET /coupons/{id}` (Read); `POST /coupons`, `PATCH /coupons/{id}`,
`DELETE /coupons/{id}` (Read and write).

```json
{ "code": "SUMMER10", "type": "percent", "amount": 1000, "description": "",
  "minSpend": null, "maxSpend": null, "usageLimit": null, "usageLimitPerEmail": null,
  "expiresAt": null, "productIds": [], "excludeProductIds": [], "categoryIds": [],
  "freeShipping": false, "active": true }
```

`type` is `percent` (amount ×100: 10% = `1000`), `fixed_cart` or `fixed_product` (amount in
cents). Codes are stored in capitals.

## 9. Not in v1

Placing orders, refunds, uploading photos, and creating categories or tags go through the admin
for now. Webhooks (the shop calling you when something changes) are not available yet: poll
`GET /products?updatedAfter=…` and `GET /orders?from=…` instead.
