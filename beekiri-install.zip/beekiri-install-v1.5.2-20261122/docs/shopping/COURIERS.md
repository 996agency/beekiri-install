# Couriers — connecting DHL or your own courier

**Shop → Settings → Shipping → Couriers** connects the companies that deliver your orders. A
connected courier can:

- **receive your orders**: Beekiri creates the shipment in the courier's system (recipient,
  address, items, weight, the cash to collect for cash on delivery) and keeps the tracking
  number, the tracking link and the label link on the order;
- **keep everyone up to date**: Beekiri asks the courier where each parcel is, or the courier tells
  your shop itself. The order moves to **Shipped** when the courier has the parcel and to
  **Delivered** (order **Completed**, cash on delivery marked paid) when it arrives. The customer
  gets the "on its way" and "delivered" emails and sees the courier's latest updates on their
  order page.

You can connect several couriers and choose, per shipping method, which one delivers it
(**Shipping zones** → a zone → a method → **Delivered by**).

## DHL

1. Create a free key at developer.dhl.com: add an app with the **Shipment Tracking – Unified**
   API and copy its API key. The free plan allows 250 checks a day.
2. **Add courier** → **DHL** → paste the key → choose how often to check → **Connect courier**.
3. Create labels in your DHL account as usual. On the order, choose **DHL** as the carrier and
   enter the tracking number. Beekiri follows the parcel from there.

DHL is followed only (Beekiri does not create DHL shipments). Use **Check a parcel** with a recent
tracking number to see that the key works.

## Any other courier

Most couriers with an online system offer an API (sometimes called "integration", "web service"
or "API for e-shops"). Ask the courier for:

- the **API documentation** and the **API address** (for example `https://api.courier.mk/v1`);
- your **key**, token, or user name and password, and how it is sent;
- whether they can **send status updates** to your shop (often called a webhook or callback).

Then **Add courier** → **Other courier** and fill in:

| Setting | What to enter |
|---|---|
| Name | What customers see next to the tracking number, e.g. "Cargo Express". |
| API address | The address every request starts with. |
| Sign in with | How the key is sent: in a header (enter the header name, e.g. `X-Api-Key`), as a bearer token, as user name and password, or in the address (enter the parameter name). |
| Key / password | Stored encrypted; it is never shown again. Leave it blank later to keep it. |
| Extra headers | Only if the courier asks for more, such as a client number. |
| Requests a day | The courier's daily limit, if it has one (0 = none). |
| Tracking page | The courier's public tracking page with `{{tracking}}` where the number goes, e.g. `https://courier.mk/track?code={{tracking}}`. Customers get a **Track parcel** button. |

A courier without an API can still be added with only a **Tracking page**: customers then get the
right tracking link as soon as you enter a tracking number.

### Send orders

Turn on **Send orders to this courier**, then:

- **Request**: usually `POST` and the path from the documentation, e.g. `/shipments`.
- **Format**: JSON (most couriers) or form fields.
- **What to send**: copy the example from the courier's documentation and put placeholders where the
  order's details go. A value that is only a placeholder keeps its type (`"{{cod.amount}}"` becomes
  the number `25.5`); add `|text` to keep it as text (`"{{cod.amount|text}}"` → `"25.5"`).
- **Read from the answer**: where the courier's answer has the **tracking number** (and, if it
  gives them, its own shipment ID and a label link). Use dots between names and numbers for list
  items: `data.parcels.0.barcode`.
- **Send automatically when an order is ready to ship**: orders whose shipping method is delivered
  by this courier go by themselves — cash on delivery orders as soon as they are placed, card and
  bank transfer orders when they are paid. Without it you send each order with **Send to
  courier** on the order page.

**Show what will be sent** fills in your latest order (or a sample) without sending anything.

Example. If the documentation shows:

```json
POST /v1/shipments
{ "receiver": { "name": "…", "phone": "…", "address": "…", "city": "…", "zip": "…" },
  "cod_amount": 0, "reference": "…", "note": "…" }
→ { "success": true, "shipment": { "id": 9912, "barcode": "CE123456789MK", "label_pdf": "https://…" } }
```

enter as **What to send**:

```json
{
  "receiver": {
    "name": "{{customer.name}}",
    "phone": "{{customer.phone}}",
    "address": "{{address.street}}",
    "city": "{{address.city}}",
    "zip": "{{address.postcode}}"
  },
  "cod_amount": "{{cod.amount}}",
  "reference": "{{order.reference}}",
  "note": "{{order.note}}"
}
```

and under **Read from the answer**: tracking number `shipment.barcode`, shipment ID
`shipment.id`, label link `shipment.label_pdf`.

### Placeholders

| Placeholder | Value |
|---|---|
| `{{order.reference}}` / `{{order.number}}` | `#1001` / `1001` |
| `{{order.date}}`, `{{today}}` | `2026-11-19` |
| `{{order.total}}`, `{{order.totalCents}}` | `25.5`, `2550` |
| `{{order.subtotal}}`, `{{order.shipping}}`, `{{order.currency}}` | products total, shipping paid, `EUR` |
| `{{order.note}}`, `{{order.shippingMethod}}` | the customer's note, the chosen shipping method |
| `{{cod.amount}}`, `{{cod.amountCents}}` | cash to collect (0 when the order is already paid) |
| `{{payment.cod}}`, `{{payment.method}}` | `true` / `false`; `cod`, `bank_transfer`, `stripe` |
| `{{customer.name}}`, `.firstName`, `.lastName`, `.company`, `.phone`, `.email` | the recipient |
| `{{address.line1}}`, `.line2`, `.street`, `.city`, `.postcode`, `.state`, `.country`, `.countryName` | delivery address (`country` is the code, e.g. `MK`) |
| `{{items.count}}`, `{{items.summary}}` | `3`, `2 × T-shirt, 1 × Cap` |
| `{{items.weightKg}}`, `{{items.weightGrams}}` | from the products' weights |
| `{{store.name}}`, `.email`, `.line1`, `.city`, `.postcode`, `.country` | you, the sender |
| `{{tracking}}`, `{{shipmentId}}` | for following parcels and the tracking page |

### Follow parcels

Turn on **Ask the courier where parcels are** and fill in:

- **Request**: usually `GET` and a path with the tracking number, e.g. `/shipments/{{tracking}}`
  or `/track?barcode={{tracking}}`. Some couriers want `POST` with the number in the body.
- **Read from the answer**: where the **status** is (e.g. `shipment.status`); optionally a
  readable text, and the **list of updates** with, in each update, its text, time and place.
  Separate alternatives with `|`: `status.description|status.code`.
- **Check**: every 30 minutes to every 12 hours. Delivered and returned parcels are no longer
  checked.

### Updates from the courier

If the courier can call your shop when a parcel moves, turn on **The courier sends status
updates to my shop**, save, and give the courier the address shown there. It contains a secret
part: share it only with the courier. If it ever gets out, **Make a new address** replaces it (the
old one stops working).
Tell Beekiri where each message has the tracking number and the status; when one message holds
several updates, also where the list is.

### Courier statuses

Rules say what each status means: **On its way**, **Out for delivery**, **Delivered**,
**Delivery issue**, **Returned to sender** or **Nothing changes**. The first rule that matches is
used; capital letters don't matter. Statuses can be in any language, e.g. `Испорачано` →
Delivered, `Во транзит` → On its way.

When the courier sends a status no rule explains, the order stays where it is, and the courier's
settings show the status with a button to add a rule for it.

### Check a parcel

Enter a real tracking number and **Check parcel**: Beekiri asks the courier with the settings on
screen (before you save) and shows the status it found, what it means by your rules, the updates
and the courier's answer. Nothing changes on your orders.

## On the order page

The **Shipping** panel shows:

- **Send to courier** while the order is not shipped (pick the courier when you have several);
- which courier follows the parcel, its latest updates, **Check now**, the **Shipping label**, and
  **Stop following**;
- for an automatic send that did not work, the courier's answer and **Try again**.

To have a courier follow a parcel you sent another way, choose it as the **Carrier** and enter the
tracking number. "Another carrier" keeps a carrier name you type yourself.

## Good to know

- Couriers are reached only at secure (`https://`) public addresses.
- An automatic send is tried again (after 5 and 30 minutes) only when the courier could not be
  reached at all, so an order is never created twice at the courier. Otherwise you get a
  notification in the admin bell and send it from the order page after checking your courier
  account.
- Delivery problems and returned parcels also appear in the bell.
- Couriers whose system only accepts XML (SOAP) need a developer: Beekiri sends JSON or form
  fields.
