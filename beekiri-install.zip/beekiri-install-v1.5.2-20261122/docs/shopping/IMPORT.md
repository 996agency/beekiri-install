# Bee Shopping — Import from WooCommerce

For agencies moving a client from WooCommerce to Beekiri. The shop owner does it in
**Shop → Settings → Import**; nothing needs to be installed on the old WordPress site.

## 1. What to export from WordPress

| File | Where in WordPress | What it brings |
|---|---|---|
| **WordPress export** (`.xml`, recommended) | Tools → Export → All content | Products with variations, categories, tags, coupons, orders with customers and order notes. |
| **Products file** (`.csv`, optional) | Products → All Products → Export | Products only. Use it alone when there is no WordPress export, or with it to add products the export misses. Its header also tells the weight and size units. |
| **Photos** (`.zip`, optional) | A ZIP of `wp-content/uploads` | The product photos. Without it, photos are downloaded from the old site, which then has to be online. |

Files go up in 4 MB pieces (the WordPress export up to 1 GB, the CSV up to 200 MB, the ZIP up to
4 GB), so large shops work behind proxies with small upload limits. They are kept privately in
`uploads/.imports/<site>/<import>/` and are never served.

## 2. The steps

1. **Check the files** — reads them and shows what they hold: counts, the old shop, which
   products, coupons, customers and orders the shop already has, whether order numbers can stay,
   currency differences, and anything left out.
2. **Prepare preview** — brings the photos into Media (folder "WooCommerce import"), creates the
   categories and tags, and the products **as drafts**. New categories stay hidden from the shop.
3. **Preview the shop** — the link opens the real website, in the site's own design, with the
   imported products as if they were published. It is a cookie in that browser only (24 hours);
   visitors keep seeing the shop as it is, and the cart never sells a draft. "Leave preview" at
   the bottom of the page ends it.
4. **Publish** — products that were for sale in WooCommerce go live (or all stay drafts, if the
   owner chose so), then coupons, customers and orders are added: **no e-mails, no stock changes,
   no admin notifications**, no unpaid-order cancelling.
   Or **Discard** — everything the import created goes again (products, photos nobody else uses,
   categories and tags nothing else uses, the media folder when empty). What the shop already had
   is never touched.

Every row an import creates or reuses is recorded (`ShopImportItem`), so a job stopped by a
restart can **Continue** where it was, and nothing is ever imported twice.

## 3. Importing again

Exporting again later (for example right before switching the domain, to catch the latest
orders) is safe: only what is new comes in.

- Products: matched by an earlier import or by SKU — left as they are (prices and stock are not
  updated). A product deleted since comes back.
- Orders: matched by an earlier import, or by the same e-mail, date and total when the old shop's
  address changed between exports.
- Coupons: matched by an earlier import or by the code. Customers: by e-mail.

## 4. How things map

| WooCommerce | Bee Shopping |
|---|---|
| Simple and variable products (also "any" variations, expanded to one per option) | Simple and variable products |
| Grouped and external products | Left out (listed); the products inside a group come in on their own |
| Description | Cleaned to match the theme: shortcodes, inline styles and classes removed, links to the old shop pointed at the new pages, photos moved to Media (can be switched off) |
| Short description | Plain text (the shop shows it as text) |
| "Uncategorized" (never renamed) | Not imported; those products have no category |
| Weight and dimensions | Converted from the chosen units (taken from the CSV when present) |
| Coupons with allowed e-mails or "exclude sale items" | Imported switched off, with a note (Bee Shopping cannot check those rules) |
| Order numbers | Kept when they are free, otherwise numbered after the shop's latest order (the WooCommerce number is in the order notes) |
| Order and coupon amounts in another currency | Orders keep their currency; product prices are copied as numbers, not converted |

## 5. Limits

- **A WordPress export never says which products were in an order.** Imported orders show the
  customer, addresses, totals, payment and notes, not their items.
- **Shops on WooCommerce's newer order storage (HPOS)** export no orders at all, only
  placeholders; the check says how many. In WooCommerce → Settings → Advanced → Features, turn
  on compatibility mode, wait for the sync to finish, then export again.
- Customers come without passwords (WooCommerce passwords cannot be moved). When a customer
  registers in the shop with the same e-mail, the account takes over their imported orders.
- Reviews, subscriptions, bookings and add-on data are not imported.

## 6. For developers

- API: `/api/shop/imports` (needs `manage_shop` and `edit_products`) — see
  `apps/api/src/routes/shop.routes.ts`. Jobs run in the background; poll `GET /imports/:id`.
- Readers: `apps/api/src/lib/shop/woo-import/` (streamed XML without entity expansion, PHP
  `unserialize` for data only, RFC 4180 CSV). Service: `services/shop/woo-import.service.ts`.
- Preview: `?shop-preview=<code>` → `apps/web/src/middleware.ts` sets the cookie and serves the shop
  through `/bk-preview`; the API scopes one request with `lib/shop/import-preview.ts`.
- Tests: `test/woo-import.unit.test.ts` (readers, real fixtures in `test/fixtures/woo`) and
  `test/shop.woo-import.test.ts` (whole flow on a throwaway database).
