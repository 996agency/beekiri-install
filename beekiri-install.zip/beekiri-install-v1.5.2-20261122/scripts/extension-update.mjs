#!/usr/bin/env node
/**
 * Installs a new version of one Beekiri extension, started from Extensions (Update now, or the
 * nightly automatic update). Runs detached from the API, like scripts/core-update.mjs.
 *
 * The site keeps running the current version until the new one has been downloaded, verified,
 * built and test-loaded next to it. Only then are the builds swapped and Beekiri restarted.
 * Any failure before that puts the extension's files back, so the site stays exactly as it was.
 * If the new version then cannot start, the server runs `--rollback` and starts again on the
 * previous build (apps/api/src/lib/extensions/update-state.ts).
 *
 * Only the extension's own files (scripts/extension-files.mjs) can change: never the database,
 * shared code, settings, uploads or themes other than the extension's templates.
 *
 * Usage:
 *   node scripts/extension-update.mjs <slug> <version> <zipUrl>   install
 *   node scripts/extension-update.mjs --rollback                   previous version back (failed start)
 *   node scripts/extension-update.mjs --recover                    tidy up an update the server stopped midway
 */
import { spawnSync } from 'node:child_process';
import {
  appendFileSync,
  cpSync,
  existsSync,
  lstatSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  renameSync,
  rmdirSync,
  rmSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, relative, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  BUILDS,
  buildFor,
  compareVersions,
  EXTENSION_FILES,
  EXTENSION_MANIFEST,
  EXTENSION_SIGNATURE,
  extensionSigned,
  ownedBy,
  sha256Of,
  SLUG_RE,
  VERSION_RE,
} from './extension-files.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const STATUS = join(ROOT, '.beekiri-extension-update.json');
const CORE_STATUS = join(ROOT, '.beekiri-update.json');
const MAX_PACKAGE_BYTES = 60 * 1024 * 1024;
const BUILD_TIMEOUT_MS = 30 * 60 * 1000;
const STALE_MS = BUILD_TIMEOUT_MS + 5 * 60 * 1000;
const npm = 'npm';

const readJson = (file) => {
  try {
    return JSON.parse(readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
};
const readStatus = () => readJson(STATUS) ?? {};

function status(patch) {
  writeFileSync(STATUS, JSON.stringify({ ...readStatus(), updatedAt: new Date().toISOString(), ...patch }, null, 2));
}

const toPosix = (p) => p.split(sep).join('/');
const abs = (rel) => join(ROOT, ...rel.split('/'));

let logFile = null;
function log(line) {
  if (!logFile) return;
  try {
    appendFileSync(logFile, `[${new Date().toISOString()}] ${line}\n`);
  } catch {
    /* logging never stops an update */
  }
}

/** Every file under `rel` (a folder or one file), as forward-slash paths relative to `base`. */
function listFiles(base, rel) {
  const full = join(base, ...rel.split('/'));
  if (!existsSync(full)) return [];
  const stat = lstatSync(full);
  if (stat.isSymbolicLink()) throw new Error(`Links are not allowed in an extension update (${rel}).`);
  if (stat.isFile()) return [rel];
  if (!stat.isDirectory()) return [];
  const out = [];
  for (const name of readdirSync(full)) out.push(...listFiles(base, !rel ? name : rel.endsWith('/') ? `${rel}${name}` : `${rel}/${name}`));
  return out;
}

/** Remove now-empty folders from `rel`'s folder up to (not including) the owned folder. */
function pruneEmptyDirs(rel, ownedRoots) {
  let dir = rel.split('/').slice(0, -1).join('/');
  while (dir && !ownedRoots.includes(`${dir}/`)) {
    try {
      if (readdirSync(abs(dir)).length) return;
      rmdirSync(abs(dir));
    } catch {
      return;
    }
    dir = dir.split('/').slice(0, -1).join('/');
  }
}

/** Put the extension's files back as they were before this update (from the job's backup). */
function restoreSources(job) {
  const backup = job.backupDir;
  if (!backup || !Array.isArray(job.changes)) return;
  const roots = (job.paths ?? []).filter((p) => p.endsWith('/'));
  for (const change of job.changes) {
    const target = abs(change.path);
    if (change.kind === 'add') {
      rmSync(target, { force: true });
      pruneEmptyDirs(change.path, roots);
    } else {
      const saved = join(backup, 'files', ...change.path.split('/'));
      if (!existsSync(saved)) continue;
      mkdirSync(dirname(target), { recursive: true });
      cpSync(saved, target, { force: true, preserveTimestamps: true });
    }
  }
}

function removeStaged() {
  for (const b of BUILDS) rmSync(abs(b.staged), { recursive: true, force: true });
}

/** Put the builds that were live before the swap back in place. */
function swapBack(job) {
  for (const s of [...(job.swap ?? [])].reverse()) {
    const previous = abs(s.previous);
    if (!existsSync(previous)) continue;
    const live = abs(s.live);
    const failed = `${live}-failed`;
    rmSync(failed, { recursive: true, force: true });
    if (existsSync(live)) renameSync(live, failed);
    renameSync(previous, live);
    rmSync(failed, { recursive: true, force: true });
  }
}

/** `next build` edits the website's tsconfig and next-env.d.ts: the originals are kept in the backup. */
const WEB_CONFIG = ['apps/web/tsconfig.json', 'apps/web/next-env.d.ts'];
function restoreWebConfigFrom(backupDir) {
  for (const rel of WEB_CONFIG) {
    const saved = join(backupDir ?? '', 'web-config', ...rel.split('/'));
    if (backupDir && existsSync(saved)) cpSync(saved, abs(rel), { force: true, preserveTimestamps: true });
  }
}

function recordAttempt(error) {
  const job = readStatus();
  const key = `${job.slug}@${job.version}`;
  const history = { ...(job.history ?? {}) };
  const prev = history[key] ?? { attempts: 0 };
  history[key] = { attempts: (prev.attempts ?? 0) + 1, lastError: error ?? null, lastAt: new Date().toISOString() };
  return history;
}

// --rollback / --recover --------------------------------------------------------------------

if (process.argv[2] === '--rollback') {
  const job = readStatus();
  // Only while the previous builds are still kept: old files over a newer build would not start.
  const swap = Array.isArray(job.swap) ? job.swap : [];
  const canRollBack = swap.length > 0 && swap.every((s) => existsSync(abs(s.previous)));
  if ((job.state !== 'restarting' && job.state !== 'done') || !canRollBack) process.exit(0);
  logFile = job.logFile ?? null;
  log('The new version did not start: putting the previous version back.');
  try {
    swapBack(job);
    restoreSources(job);
    status({
      state: 'rolled-back',
      step: 'rolled-back',
      progress: 100,
      message: `It did not run properly on this server, so Beekiri put version ${job.fromVersion} back. Your site works as before.`,
      finishedAt: new Date().toISOString(),
      swap: [],
      notified: false,
      history: recordAttempt('did not start'),
    });
    process.exit(0);
  } catch (e) {
    log(`Rollback failed: ${e?.stack || e}`);
    status({ state: 'error', message: 'The previous version could not be put back automatically. Contact 996Agency.', detail: String(e?.message || e) });
    process.exit(1);
  }
}

if (process.argv[2] === '--recover') {
  const job = readStatus();
  const alive = (() => {
    // Never silent this long while it works (each build step has a 30-minute limit): a process
    // with the same number after a restart is not the updater.
    if (!job.pid || Date.now() - Date.parse(job.updatedAt ?? 0) > STALE_MS) return false;
    try {
      process.kill(job.pid, 0);
      return true;
    } catch {
      return false;
    }
  })();
  if (job.state === 'running' && !alive) {
    logFile = job.logFile ?? null;
    log('The updater stopped while the update was running: putting the extension files back.');
    // A build it started may still be running in its process group.
    if (job.pid && process.platform !== 'win32') {
      try {
        process.kill(-job.pid, 'SIGKILL');
      } catch {
        /* none left */
      }
    }
    if (job.sourcesApplied || job.changes) restoreSources(job);
    if (job.webConfigSaved) restoreWebConfigFrom(job.backupDir);
    removeStaged();
    status({
      state: 'error',
      step: 'interrupted',
      message: 'The update was stopped before it finished. Your site was not changed.',
      finishedAt: new Date().toISOString(),
      notified: false,
      history: recordAttempt('interrupted'),
    });
  }
  process.exit(0);
}

// Install ------------------------------------------------------------------------------------

const [slug, version, zipUrl] = process.argv.slice(2);
const owned = EXTENSION_FILES[slug];
let work = null;
let restoreOnFail = false;
let webConfigSaved = false;

function fail(message, detail, { count = true } = {}) {
  if (detail) log(`${message}\n${detail}`);
  else log(message);
  try {
    if (restoreOnFail) restoreSources(readStatus());
  } catch (e) {
    log(`Putting files back failed: ${e?.stack || e}`);
  }
  try {
    removeStaged();
    restoreWebConfig();
    if (work) rmSync(work, { recursive: true, force: true });
  } catch {
    /* best effort */
  }
  status({
    state: 'error',
    message,
    detail: detail ? String(detail).slice(-2000) : undefined,
    finishedAt: new Date().toISOString(),
    ...(count ? { history: recordAttempt(message) } : {}),
  });
  process.exit(1);
}

function run(cmd, args, label, opts = {}) {
  log(`$ ${cmd} ${args.join(' ')}${opts.cwd ? `  (in ${toPosix(relative(ROOT, opts.cwd))})` : ''}`);
  const res = spawnSync(cmd, args, {
    cwd: opts.cwd ?? ROOT,
    encoding: 'utf8',
    shell: process.platform === 'win32',
    env: { ...process.env, CI: '1', ...(opts.env ?? {}) },
    maxBuffer: 64 * 1024 * 1024,
    timeout: opts.timeout ?? BUILD_TIMEOUT_MS,
  });
  const output = `${res.stdout || ''}\n${res.stderr || ''}`.replace(/\x1b\[[0-9;]*m/g, '').trim();
  if (output) log(output.slice(-20000));
  if (res.status !== 0) {
    fail(opts.failMessage ?? `${label} failed.`, output || res.error?.message || `exit ${res.status}`);
  }
  return res;
}

function snapshotWebConfig() {
  const { backupDir } = readStatus();
  for (const rel of WEB_CONFIG) {
    if (!existsSync(abs(rel))) continue;
    const to = join(backupDir, 'web-config', ...rel.split('/'));
    mkdirSync(dirname(to), { recursive: true });
    cpSync(abs(rel), to, { preserveTimestamps: true });
  }
  webConfigSaved = true;
  status({ webConfigSaved: true });
}
function restoreWebConfig() {
  if (!webConfigSaved) return;
  restoreWebConfigFrom(readStatus().backupDir);
  webConfigSaved = false;
  status({ webConfigSaved: false });
}

function extract(zip, dest) {
  mkdirSync(dest, { recursive: true });
  const attempts =
    process.platform === 'win32'
      ? [
          ['tar', ['-xf', zip, '-C', dest]],
          ['powershell', ['-NoProfile', '-Command', `Expand-Archive -Force -Path '${zip}' -DestinationPath '${dest}'`]],
        ]
      : [
          ['unzip', ['-q', '-o', zip, '-d', dest]],
          ['tar', ['-xf', zip, '-C', dest]],
        ];
  for (const [cmd, args] of attempts) {
    const res = spawnSync(cmd, args, { encoding: 'utf8', shell: process.platform === 'win32' });
    if (res.status === 0) return;
  }
  fail('The download could not be unpacked. Your site was not changed.');
}

function packageRoot(dir) {
  if (existsSync(join(dir, EXTENSION_MANIFEST))) return dir;
  for (const name of readdirSync(dir)) {
    const sub = join(dir, name);
    if (lstatSync(sub).isDirectory() && existsSync(join(sub, EXTENSION_MANIFEST))) return sub;
  }
  return null;
}

async function download(url, label) {
  const res = await fetch(`${url}${url.includes('?') ? '&' : '?'}t=${Date.now()}`, {
    redirect: 'follow',
    headers: { 'User-Agent': 'Beekiri-CMS-Updater' },
    signal: AbortSignal.timeout(5 * 60 * 1000),
  });
  if (!res.ok) throw new Error(`${label}: HTTP ${res.status}`);
  const chunks = [];
  let received = 0;
  for await (const chunk of res.body) {
    received += chunk.length;
    if (received > MAX_PACKAGE_BYTES) throw new Error(`${label} is larger than expected.`);
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function main() {
  if (!owned || !SLUG_RE.test(slug ?? '') || !VERSION_RE.test(version ?? '') || !/^https?:\/\//.test(zipUrl ?? '')) {
    fail('This update is not for an extension Beekiri knows.');
  }
  const info = readJson(abs(owned.info));
  const name = info?.name ?? slug;
  const fromVersion = info?.version ?? '0.0.0';
  const coreVersion = readJson(join(ROOT, 'beekiri.manifest.json'))?.coreVersion ?? '0.0.0';
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupDir = join(ROOT, 'backups', `extension-${slug}-v${fromVersion}-${stamp}`);
  mkdirSync(backupDir, { recursive: true });
  logFile = join(backupDir, 'update.log');
  status({
    state: 'running',
    step: 'start',
    progress: 2,
    message: `Starting the update of ${name}…`,
    slug,
    name,
    version,
    fromVersion,
    pid: process.pid,
    backupDir,
    logFile,
    swap: [],
    changes: null,
    paths: null,
    sourcesApplied: false,
    webConfigSaved: false,
    detail: undefined,
    finishedAt: undefined,
  });
  log(`Updating ${name} from ${fromVersion} to ${version} (Beekiri ${coreVersion}).`);

  const core = readJson(CORE_STATUS);
  if (core?.state === 'running' && Date.now() - Date.parse(core.updatedAt ?? 0) < 15 * 60 * 1000) {
    fail('Beekiri itself is being updated right now. Try again once that is finished.', null, { count: false });
  }
  if (compareVersions(version, fromVersion) <= 0) fail(`${name} ${fromVersion} is already installed.`, null, { count: false });

  work = join(tmpdir(), `beekiri-extension-${slug}-${Date.now()}`);
  mkdirSync(work, { recursive: true });

  // 1. Download and unpack into a work folder (nothing on the site is touched yet).
  status({ step: 'download', progress: 8, message: `Downloading ${name} ${version}…` });
  let zip;
  try {
    zip = await download(zipUrl, 'The update package');
  } catch (e) {
    fail('It could not be downloaded. Check that the server can reach the internet. Your site was not changed.', e?.message);
  }
  const zipPath = join(work, 'extension.zip');
  writeFileSync(zipPath, zip);
  extract(zipPath, join(work, 'pkg'));
  const pkg = packageRoot(join(work, 'pkg'));
  if (!pkg) fail('The download is not a Beekiri extension. Your site was not changed.');

  // 2. Its description must be signed with the release key, and every file must be exactly the
  //    one that was signed: nothing changed, nothing added, nothing missing.
  status({ step: 'verify', progress: 18, message: 'Checking the update comes from Beekiri…' });
  let manifestBytes;
  let sig;
  try {
    manifestBytes = readFileSync(join(pkg, EXTENSION_MANIFEST));
    sig = JSON.parse(readFileSync(join(pkg, EXTENSION_SIGNATURE), 'utf8'));
  } catch {
    fail('It is not signed by Beekiri. Your site was not changed.');
  }
  const manifestSha = sha256Of(manifestBytes);
  if (sig?.slug !== slug || sig?.version !== version || sig?.sha256 !== manifestSha || !extensionSigned(slug, version, manifestSha, sig?.signature)) {
    fail('It is not signed by Beekiri, or it was changed on the way. Your site was not changed.');
  }
  let manifest;
  try {
    manifest = JSON.parse(manifestBytes.toString('utf8'));
  } catch {
    fail('The download does not describe itself. Your site was not changed.');
  }
  const signedFiles = manifest?.files && typeof manifest.files === 'object' ? manifest.files : {};
  let unpacked;
  try {
    unpacked = listFiles(pkg, '').filter((rel) => rel !== EXTENSION_MANIFEST && rel !== EXTENSION_SIGNATURE);
  } catch (e) {
    fail('The download contains something that is not allowed. Your site was not changed.', e?.message);
  }
  const unsigned = unpacked.filter((rel) => signedFiles[rel] !== sha256Of(readFileSync(join(pkg, ...rel.split('/')))));
  const missing = Object.keys(signedFiles).filter((rel) => !unpacked.includes(rel));
  if (unsigned.length || missing.length) {
    fail('It was changed after Beekiri signed it. Your site was not changed.', [...unsigned, ...missing].slice(0, 20).join('\n'));
  }

  // 3. The package may only hold this extension's own files, for this Beekiri version.
  status({ step: 'prepare', progress: 24, message: 'Preparing the update…' });
  if (manifest?.slug !== slug || manifest?.version !== version) fail('The download does not match the update that was offered. Your site was not changed.');
  if (!VERSION_RE.test(manifest.requires ?? '') || compareVersions(coreVersion, manifest.requires) < 0) {
    fail(`It needs Beekiri ${manifest.requires} or newer. Update Beekiri first in Settings → Beekiri Core.`);
  }
  const paths = Array.isArray(manifest.paths) ? manifest.paths : [];
  if (!paths.length || paths.some((p) => typeof p !== 'string' || !owned.paths.includes(p))) {
    fail('The download contains files that do not belong to the extension. Your site was not changed.');
  }
  const packageFiles = unpacked;
  const stray = packageFiles.filter((rel) => !ownedBy(paths, rel));
  if (stray.length) fail('The download contains files that do not belong to the extension. Your site was not changed.', stray.slice(0, 20).join('\n'));
  if (!packageFiles.includes(owned.info) || readJson(join(pkg, ...owned.info.split('/')))?.version !== version) {
    fail('The download does not say which version it is. Your site was not changed.');
  }

  // 4. Work out what really changes: only those files are touched, so nothing else is rebuilt.
  const changes = [];
  for (const p of paths) {
    const current = new Set(listFiles(ROOT, p.endsWith('/') ? p.slice(0, -1) : p));
    const incoming = packageFiles.filter((rel) => ownedBy([p], rel));
    for (const rel of incoming) {
      if (!current.has(rel)) changes.push({ path: rel, kind: 'add' });
      else if (sha256Of(readFileSync(abs(rel))) !== sha256Of(readFileSync(join(pkg, ...rel.split('/'))))) changes.push({ path: rel, kind: 'change' });
      current.delete(rel);
    }
    for (const rel of current) changes.push({ path: rel, kind: 'remove' });
  }
  const builds = BUILDS.filter((b) => changes.some((c) => buildFor(c.path) === b));
  log(`${changes.length} file(s) change; builds: ${builds.map((b) => b.app).join(', ') || 'none'}.`);

  // 5. Keep a copy of every file this update changes or removes.
  status({ step: 'backup', progress: 30, message: 'Saving a copy of the current version…', paths, changes });
  try {
    for (const c of changes) {
      if (c.kind === 'add') continue;
      const to = join(backupDir, 'files', ...c.path.split('/'));
      mkdirSync(dirname(to), { recursive: true });
      cpSync(abs(c.path), to, { preserveTimestamps: true });
    }
  } catch (e) {
    fail('A copy of the current version could not be saved (the server may be out of disk space). Your site was not changed.', e?.message);
  }

  const apply = (filter) => {
    for (const c of changes.filter(filter)) {
      const target = abs(c.path);
      if (c.kind === 'remove') {
        rmSync(target, { force: true });
        pruneEmptyDirs(c.path, paths.filter((p) => p.endsWith('/')));
      } else {
        mkdirSync(dirname(target), { recursive: true });
        cpSync(join(pkg, ...c.path.split('/')), target, { force: true });
      }
    }
  };

  // 6. Build the new version next to the live one. The site keeps serving the current build.
  removeStaged();
  if (builds.length) {
    restoreOnFail = true;
    status({ sourcesApplied: true });
    try {
      apply((c) => buildFor(c.path) !== null);
    } catch (e) {
      fail('The new files could not be put in place (the server may be out of disk space). Your site was not changed.', e?.message);
    }
    run(process.execPath, [join(ROOT, 'apps/api/scripts/ensure-tools.mjs')], 'Preparing the build tools', { failMessage: 'The tools to build it are missing on this server. Your site was not changed.' });
    const failMessage = 'It did not build on this server. Your site was not changed.';
    let n = 0;
    for (const b of builds) {
      n += 1;
      status({ step: 'build', progress: 34 + Math.round((n - 1) * (50 / builds.length)), message: `Building the new version (part ${n} of ${builds.length}). Your site keeps working meanwhile…` });
      if (b.app === 'api') {
        const cwd = join(ROOT, 'apps/api');
        run(npm, ['exec', '--no', '--', 'tsc', '-p', 'tsconfig.build.json', '--outDir', 'dist-staged'], 'Building', { cwd, failMessage });
        run(process.execPath, ['scripts/copy-assets.mjs', 'dist-staged'], 'Copying files', { cwd, failMessage });
      } else if (b.app === 'admin') {
        const cwd = join(ROOT, 'apps/admin');
        run(npm, ['exec', '--no', '--', 'tsc', '-b'], 'Checking', { cwd, failMessage });
        run(npm, ['exec', '--no', '--', 'vite', 'build', '--outDir', 'dist-staged', '--emptyOutDir', '--logLevel', 'warn'], 'Building', { cwd, failMessage });
        if (!existsSync(join(cwd, 'dist-staged', 'index.html'))) fail(failMessage, 'The admin build has no index.html.');
      } else if (b.app === 'web') {
        const cwd = join(ROOT, 'apps/web');
        snapshotWebConfig();
        run(npm, ['exec', '--no', '--', 'next', 'build'], 'Building', { cwd, failMessage, env: { NEXT_DIST_DIR: '.next-staged', NODE_ENV: 'production', NEXT_TELEMETRY_DISABLED: '1' } });
        restoreWebConfig();
        if (!existsSync(join(cwd, '.next-staged', 'BUILD_ID')) || !existsSync(join(cwd, '.next-staged', 'prerender-manifest.json'))) {
          fail(failMessage, 'The website build is incomplete.');
        }
      }
    }
  }

  // 7. Load every part of the new server once without starting it: an error here stops the update.
  if (builds.some((b) => b.app === 'api')) {
    status({ step: 'test', progress: 88, message: 'Testing the new version…' });
    const res = spawnSync(process.execPath, ['dist-staged/server.js'], {
      cwd: join(ROOT, 'apps/api'),
      encoding: 'utf8',
      env: { ...process.env, NODE_ENV: process.env.NODE_ENV || 'production', BEEKIRI_SMOKE_TEST: '1' },
      timeout: 3 * 60 * 1000,
      maxBuffer: 16 * 1024 * 1024,
    });
    const output = `${res.stdout || ''}\n${res.stderr || ''}`.trim();
    log(`Test start:\n${output.slice(-20000)}`);
    if (res.status !== 0 || !output.includes('BEEKIRI_SMOKE_OK')) {
      fail('It did not pass its test on this server. Your site was not changed.', output || res.error?.message);
    }
  }

  // 8. Switch: theme templates and other files read as they are, then the builds.
  status({ step: 'swap', progress: 94, message: 'Switching to the new version…' });
  restoreOnFail = true;
  status({ sourcesApplied: true });
  const swapped = [];
  try {
    apply((c) => buildFor(c.path) === null);
    for (const b of builds) {
      rmSync(abs(b.previous), { recursive: true, force: true });
      if (existsSync(abs(b.live))) renameSync(abs(b.live), abs(b.previous));
      swapped.push({ live: b.live, previous: b.previous });
      renameSync(abs(b.staged), abs(b.live));
    }
  } catch (e) {
    try {
      swapBack({ swap: swapped });
    } catch (e2) {
      log(`Switching back failed: ${e2?.stack || e2}`);
    }
    fail('The switch to the new version did not work. Your site was not changed.', e?.message);
  }
  rmSync(work, { recursive: true, force: true });

  // 9. The server restarts on the new build and confirms it (or puts the previous one back).
  if (builds.length) {
    status({
      state: 'restarting',
      step: 'restarting',
      progress: 97,
      message: `Restarting your site on ${name} ${version}…`,
      swap: swapped,
    });
  } else {
    status({
      state: 'done',
      step: 'done',
      progress: 100,
      message: `${name} was updated to ${version}.`,
      finishedAt: new Date().toISOString(),
      swap: [],
    });
  }
  log('Update applied.');
}

main().catch((e) => fail('The update stopped unexpectedly. Your site was not changed.', e?.stack || e?.message || e));
