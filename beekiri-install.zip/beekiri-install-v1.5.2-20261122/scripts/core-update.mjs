#!/usr/bin/env node
/**
 * In-place Beekiri Core update, started from Settings → Beekiri Core → Update.
 * Runs detached from the API (the API restarts while files change).
 *
 * Never touches: .env files, uploads, backups, the database contents (and database/), site-generated theme
 * layouts, child themes, installed (store) themes, node_modules (reinstalled), git history.
 * Only copies/overwrites core files; nothing on the site is deleted.
 * Retired core files are moved into the update backup.
 *
 * Then it installs the packages the new version needs, migrates and builds. The server watches
 * .beekiri-update.json and restarts itself on the new version once this reports `done`, so the
 * update goes live without anyone running a command on the server. If a step fails once files
 * were replaced, the previous files, packages and builds are put back (the server restarts onto
 * those builds), so a failed update leaves the site as it was.
 *
 * This file runs as the site has it before the update, so it only uses Node's own modules, and
 * every step after the files are in place runs the new version's scripts.
 *
 * Usage: node scripts/core-update.mjs <version> <zipUrl>
 */
import { spawnSync } from 'node:child_process';
import { createHash, createPublicKey, verify } from 'node:crypto';
import { setDefaultResultOrder } from 'node:dns';
import {
  cpSync,
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, relative, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');

// Downloads try IPv4 first: many servers have an IPv6 address without a working IPv6 route.
setDefaultResultOrder('ipv4first');

/**
 * 996agency's release signing keys (scripts/release-signing.mjs public). A package is applied
 * only when its .sig is signed by one of them, so a hijacked download link or GitHub account
 * cannot push code to every site.
 */
const RELEASE_KEYS = ['dL0loV7jwSJ1bKW62LZfLyO6kPiaxR55565WvqceXT0='];
const SPKI_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');

function releaseSigned(version, sha256, signatureB64) {
  const signature = Buffer.from(String(signatureB64 || ''), 'base64');
  if (signature.length !== 64) return false;
  const message = Buffer.from(`beekiri-core:v1\n${version}\n${sha256}`, 'utf8');
  return RELEASE_KEYS.some((b64) => {
    try {
      const key = createPublicKey({ key: Buffer.concat([SPKI_PREFIX, Buffer.from(b64, 'base64')]), format: 'der', type: 'spki' });
      return verify(null, message, key, signature);
    } catch {
      return false;
    }
  });
}
const STATUS = join(ROOT, '.beekiri-update.json');
const [version, zipUrl] = process.argv.slice(2);

const SKIP_TOP = new Set([
  '.git',
  'node_modules',
  'uploads',
  'backups',
  'releases',
  // Beekiri's own PostgreSQL (program + data), when the setup wizard installed it.
  'database',
  '.env',
  '.env.local',
  '.beekiri-update.json',
  '.beekiri-extension-update.json',
  '.turbo',
]);
const SKIP_ANYWHERE = new Set([
  'node_modules',
  '.next',
  '.next-dev',
  'dist',
  '.turbo',
  'uploads',
  // Builds an extension update keeps next to the live ones (scripts/extension-update.mjs).
  'dist-staged',
  'dist-previous',
  '.next-staged',
  '.next-previous',
]);
const SKIP_EXACT = new Set([
  'apps/api/.env',
  'apps/api/.env.local',
  'apps/api/.cache-epoch',
  'apps/admin/.env',
  'apps/web/.env',
]);

/** Core paths removed in later versions. Moved into the update backup, never deleted outright. */
const RETIRED = [
  'apps/api/nest-cli.json',
  'apps/api/prisma',
  'apps/api/src/main.ts',
  'apps/api/src/app.module.ts',
  ...['auth', 'common', 'fields', 'health', 'install', 'layouts', 'mail', 'media', 'pages', 'prisma', 'site', 'system', 'themes', 'users'].map(
    (dir) => `apps/api/src/${dir}`,
  ),
  '.env.example',
  'scripts/client-prep.sh',
  'scripts/setup-996-ssh.sh',
  'docs',
];

const startedAt = new Date().toISOString();
let fromVersion = '';
try {
  fromVersion = JSON.parse(readFileSync(join(ROOT, 'beekiri.manifest.json'), 'utf8')).coreVersion ?? '';
} catch {
  /* unknown */
}

function status(patch) {
  let prev = {};
  try {
    prev = JSON.parse(readFileSync(STATUS, 'utf8'));
  } catch {
    /* first write */
  }
  writeFileSync(
    STATUS,
    JSON.stringify(
      { ...prev, version, fromVersion, startedAt, updatedAt: new Date().toISOString(), ...patch },
      null,
      2,
    ),
  );
}

/** Set once core files start being replaced: a failure from then on puts the previous version back. */
let applied = null;
let buildStarted = false;
const INSTALLER = join(ROOT, 'apps', 'api', 'scripts', 'ensure-tools.mjs');

function fail(message, detail) {
  const finishedAt = new Date().toISOString();
  if (!applied) {
    status({ state: 'error', message, detail: detail ? String(detail).slice(-2000) : undefined, finishedAt });
    process.exit(1);
  }
  const outcome = restorePrevious();
  status({
    state: 'error',
    message:
      outcome === 'restored'
        ? `${message} Beekiri put the previous version back, so your site works as before.`
        : `${message} The previous version could not be put back completely. Contact 996Agency.`,
    detail: detail ? String(detail).slice(-2000) : undefined,
    restored: outcome === 'restored',
    // Builds were redone for the previous version: the server restarts onto them.
    restartRequired: outcome === 'restored' && buildStarted && process.env.NODE_ENV === 'production',
    finishedAt,
  });
  process.exit(1);
}

function exec(cmd, args, { shell = false } = {}) {
  return spawnSync(cmd, args, {
    cwd: ROOT,
    encoding: 'utf8',
    shell,
    env: { ...process.env, CI: '1' },
    maxBuffer: 64 * 1024 * 1024,
  });
}

function run(cmd, args, label, opts) {
  const res = exec(cmd, args, opts);
  if (res.status !== 0) {
    fail(`${label} failed.`, `${res.stderr || ''}\n${res.stdout || ''}`.trim() || res.error?.message);
  }
  return res;
}

/**
 * npm, also where it is not on the PATH (hosting panels often start Node directly): the npm that
 * started Beekiri, else the one installed with this Node, else whatever `npm` is.
 * Same as npmCommand() in apps/api/scripts/ensure-tools.mjs (kept here: see the note above).
 */
function npm(args) {
  const cli = [
    process.env.npm_execpath,
    join(dirname(process.execPath), '..', 'lib', 'node_modules', 'npm', 'bin', 'npm-cli.js'),
    join(dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js'),
  ].find((path) => path && /npm-cli\.c?js$/.test(path) && existsSync(path));
  if (cli) return [process.execPath, [cli, ...args], {}];
  if (process.platform === 'win32') return ['npm.cmd', args, { shell: true }];
  return ['npm', args, {}];
}

function runNpm(args, label) {
  const [cmd, cmdArgs, opts] = npm(args);
  return run(cmd, cmdArgs, label, opts);
}

/**
 * The update failed after core files were replaced: the files as they were (from the update's
 * backup), the packages they use and, when building had begun, their builds. 'restored' when the
 * site is exactly the previous version again.
 */
function restorePrevious() {
  const { backupDir, added } = applied;
  applied = null;
  status({ step: 'restore', message: 'The update did not work. Putting the previous version back…' });
  let complete = true;
  try {
    for (const name of readdirSync(backupDir)) {
      if (name === 'retired') continue;
      cpSync(join(backupDir, name), join(ROOT, name), { recursive: true, force: true, preserveTimestamps: true });
    }
    const retired = join(backupDir, 'retired');
    if (existsSync(retired)) cpSync(retired, ROOT, { recursive: true, force: true, preserveTimestamps: true });
  } catch {
    complete = false;
  }
  // Files and folders only the new version has (a folder goes as a whole).
  for (const rel of added) {
    try {
      rmSync(join(ROOT, rel), { recursive: true, force: true });
    } catch {
      complete = false;
    }
  }
  if (!complete) return 'incomplete';
  // The previous version's own installer puts its packages back (`npm start` checks again too).
  if (existsSync(INSTALLER) && exec(process.execPath, [INSTALLER]).status !== 0) return 'incomplete';
  if (buildStarted && process.env.NODE_ENV === 'production') {
    const [cmd, args, opts] = npm(['run', 'build']);
    if (exec(cmd, args, opts).status !== 0) return 'incomplete';
  }
  return 'restored';
}

function skip(rel) {
  const norm = rel.split(sep).join('/');
  const top = norm.split('/')[0];
  if (SKIP_TOP.has(top)) return true;
  if (SKIP_EXACT.has(norm)) return true;
  if (norm.split('/').some((part) => SKIP_ANYWHERE.has(part))) return true;
  // Child themes and site-generated layouts stay as the site built them.
  if (/^apps\/web\/themes\/[^/]+-child(\/|$)/.test(norm)) return true;
  if (/^apps\/web\/themes\/[^/]+\/(layouts|sites|cpts)\//.test(norm)) return true;
  // Core owns only the Beekiri parent theme; store themes, global layouts and theme backups
  // belong to the site.
  if (/^apps\/web\/themes\/(?!beekiri\/)[^/]+\//.test(norm)) return true;
  return false;
}

function extract(zip, dest) {
  mkdirSync(dest, { recursive: true });
  const attempts =
    process.platform === 'win32'
      ? [
          ['tar', ['-xf', zip, '-C', dest]],
          [
            'powershell',
            ['-NoProfile', '-Command', `Expand-Archive -Force -Path '${zip}' -DestinationPath '${dest}'`],
          ],
        ]
      : [
          ['unzip', ['-q', '-o', zip, '-d', dest]],
          ['tar', ['-xf', zip, '-C', dest]],
        ];
  for (const [cmd, args] of attempts) {
    const res = spawnSync(cmd, args, { encoding: 'utf8', shell: process.platform === 'win32' });
    if (res.status === 0) return;
  }
  fail('Could not unpack the update package.');
}

function packageRoot(dir) {
  if (existsSync(join(dir, 'beekiri.manifest.json'))) return dir;
  for (const name of readdirSync(dir)) {
    const sub = join(dir, name);
    if (statSync(sub).isDirectory() && existsSync(join(sub, 'beekiri.manifest.json'))) return sub;
  }
  return null;
}

async function main() {
  if (!version || !zipUrl) fail('Missing update version or package URL.');

  const work = join(tmpdir(), `beekiri-update-${Date.now()}`);
  mkdirSync(work, { recursive: true });

  // 1. Download (the pid lets the server see whether this updater is still at work)
  status({ state: 'running', step: 'download', progress: 5, message: 'Downloading update…', pid: process.pid });
  let zipPath = join(work, 'core.zip');
  try {
    const res = await fetch(`${zipUrl}${zipUrl.includes('?') ? '&' : '?'}t=${Date.now()}`, {
      redirect: 'follow',
      headers: { 'User-Agent': 'Beekiri-CMS-Updater' },
    });
    if (!res.ok) fail(`Download failed (HTTP ${res.status}).`);
    const total = Number(res.headers.get('content-length')) || 0;
    const chunks = [];
    let received = 0;
    for await (const chunk of res.body) {
      chunks.push(chunk);
      received += chunk.length;
      if (total) {
        status({ progress: 5 + Math.round((received / total) * 20), message: 'Downloading update…' });
      }
    }
    writeFileSync(zipPath, Buffer.concat(chunks));
  } catch (e) {
    fail('Could not download the update.', e?.message);
  }

  // 2. Verify the signature before anything is unpacked, then unpack.
  status({ step: 'verify', progress: 28, message: 'Verifying package…' });
  try {
    const sigUrl = `${zipUrl.split('?')[0]}.sig`;
    const res = await fetch(`${sigUrl}?t=${Date.now()}`, { redirect: 'follow', headers: { 'User-Agent': 'Beekiri-CMS-Updater' } });
    if (!res.ok) fail('The update has no 996agency signature, so it was not installed.');
    const sig = await res.json();
    const sha256 = createHash('sha256').update(readFileSync(zipPath)).digest('hex');
    if (sig.version !== version || sig.sha256 !== sha256 || !releaseSigned(version, sha256, sig.signature)) {
      fail('The update is not signed by 996agency (or was altered), so it was not installed. Nothing was changed.');
    }
  } catch (e) {
    fail('Could not verify the update signature. Nothing was changed.', e?.message);
  }
  extract(zipPath, join(work, 'pkg'));
  const pkg = packageRoot(join(work, 'pkg'));
  if (!pkg) fail('Update package is not a Beekiri Core package.');
  const pkgVersion = JSON.parse(readFileSync(join(pkg, 'beekiri.manifest.json'), 'utf8')).coreVersion;
  if (pkgVersion !== version) fail(`Package is v${pkgVersion}, expected v${version}.`);

  // 3. Backup current core files (code only; database and uploads are untouched). Dates are kept,
  //    so files put back after a failed update do not look changed to `npm start`.
  status({ step: 'backup', progress: 35, message: 'Backing up current core files…' });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupDir = join(ROOT, 'backups', `core-v${fromVersion || 'unknown'}-${stamp}`);
  try {
    mkdirSync(backupDir, { recursive: true });
    for (const name of readdirSync(ROOT)) {
      if (skip(name)) continue;
      cpSync(join(ROOT, name), join(backupDir, name), {
        recursive: true,
        preserveTimestamps: true,
        filter: (src) => !skip(relative(ROOT, src)),
      });
    }
  } catch (e) {
    fail('Backup failed. No files were changed.', e?.message);
  }

  // 4. Apply new core files (copy over; never delete site files). What the new version adds is
  //    noted, so a failure later can take it away again.
  status({ step: 'apply', progress: 50, message: 'Applying core files…', backupDir });
  applied = { backupDir, added: [] };
  try {
    cpSync(pkg, ROOT, {
      recursive: true,
      force: true,
      filter: (src) => {
        const rel = relative(pkg, src);
        if (!rel) return true;
        if (skip(rel)) return false;
        const insideAdded = applied.added.some((dir) => rel.startsWith(`${dir}${sep}`));
        if (!insideAdded && !existsSync(join(ROOT, rel))) applied.added.push(rel);
        return true;
      },
    });
  } catch (e) {
    fail('The new files could not be copied (the server may be out of disk space).', e?.message);
  }

  for (const rel of RETIRED) {
    const from = join(ROOT, rel);
    if (!existsSync(from) || existsSync(join(pkg, rel))) continue;
    try {
      const to = join(backupDir, 'retired', rel);
      mkdirSync(dirname(to), { recursive: true });
      renameSync(from, to);
    } catch {
      /* leftovers are harmless: the API build only compiles from its entry points */
    }
  }

  // 5. Packages: the new version's own installer, which also records what it installed (so
  //    `npm start` sees nothing is missing). --include=dev: this runs inside the live site
  //    (NODE_ENV=production), where npm would otherwise leave out the build tools the steps
  //    below need.
  status({ step: 'install', progress: 62, message: 'Installing what the new version needs…' });
  if (existsSync(INSTALLER)) run(process.execPath, [INSTALLER, '--install'], 'Installing the new version’s packages');
  else runNpm(['install', '--include=dev', '--prefer-offline', '--no-audit', '--no-fund'], 'Installing the new version’s packages');

  // 6. Database migrations (applies new migrations only; existing data is kept)
  status({ step: 'migrate', progress: 80, message: 'Updating database schema safely…' });
  runNpm(['run', 'db:migrate'], 'Database migration');

  // 7. Production builds (dev servers reload on their own)
  if (process.env.NODE_ENV === 'production') {
    status({ step: 'build', progress: 88, message: 'Building…' });
    buildStarted = true;
    runNpm(['run', 'build'], 'Build');
  }
  applied = null;

  rmSync(work, { recursive: true, force: true });

  // The dev watcher only reloads on content changes, so write a fresh stamp the API imports.
  if (process.env.NODE_ENV !== 'production') {
    status({ step: 'reload', progress: 95, message: 'Restarting Beekiri services…' });
    try {
      writeFileSync(
        join(ROOT, 'apps', 'api', 'src', 'core-build.ts'),
        `// Rewritten by scripts/core-update.mjs after each update so the dev server reloads.\nexport const CORE_BUILD = 'v${version}-${Date.now()}';\n`,
      );
    } catch {
      /* ignore */
    }
    await new Promise((r) => setTimeout(r, 8000));
  }

  status({
    state: 'done',
    step: 'done',
    progress: 100,
    message: `Beekiri Core v${version} is installed.`,
    restartRequired: process.env.NODE_ENV === 'production',
    finishedAt: new Date().toISOString(),
  });
}

main().catch((e) => fail('Update failed.', e?.stack || e?.message || e));
