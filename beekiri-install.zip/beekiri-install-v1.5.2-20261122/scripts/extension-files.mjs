/**
 * Which files belong to each Beekiri extension, for extension updates (scripts/extension-update.mjs
 * on a site; `node pack.mjs extension <slug>` in Beekiri-Store on the publishing machine).
 *
 * An extension update may only replace these paths. Anything else (shared code, database
 * migrations, models, npm packages) ships with a Beekiri Core release, so an extension update
 * can never change the database or code another feature relies on.
 *
 * A path ending in `/` is a folder (replaced as a whole: files the new version no longer has are
 * removed); any other path is one file. `info` is the extension's own description and version.
 */
import { createHash, createPublicKey, verify } from 'node:crypto';

export const EXTENSION_FILES = {
  shopping: {
    info: 'apps/api/src/lib/shop/extension.json',
    paths: [
      'apps/api/src/lib/shop/',
      'apps/api/src/services/shop/',
      'apps/api/src/controllers/shop/',
      'apps/api/src/routes/shop.routes.ts',
      'apps/api/src/validators/shop.schema.ts',
      'apps/api/src/middleware/shop.ts',
      'apps/api/src/lib/beequeen/shop.ts',
      'apps/admin/src/screens/shop/',
      'apps/admin/src/screens/dashboard/ShopWidget.tsx',
      'apps/web/src/app/shop/',
      'apps/web/src/components/ShopMain.tsx',
      'apps/web/src/components/ShopPageWrap.tsx',
      'apps/web/src/lib/shop.ts',
      'apps/web/themes/beekiri/shop/',
    ],
  },
  'bee-forms': {
    info: 'apps/api/src/lib/forms/extension.json',
    paths: [
      'apps/api/src/lib/forms/',
      'apps/api/src/services/forms/',
      'apps/api/src/controllers/forms.controller.ts',
      'apps/api/src/routes/forms.routes.ts',
      'apps/api/src/validators/forms.schema.ts',
      'apps/api/src/middleware/forms.ts',
      'apps/admin/src/screens/forms/',
      'apps/web/src/lib/forms.ts',
    ],
  },
  'bee-bookings': {
    info: 'apps/api/src/lib/bookings/extension.json',
    paths: [
      'apps/api/src/lib/bookings/',
      'apps/api/src/services/bookings/',
      'apps/api/src/controllers/bookings.controller.ts',
      'apps/api/src/routes/bookings.routes.ts',
      'apps/api/src/validators/bookings.schema.ts',
      'apps/api/src/middleware/bookings.ts',
      'apps/api/src/lib/beequeen/bookings.ts',
      'apps/admin/src/screens/bookings/',
      'apps/web/src/lib/bookings.ts',
    ],
  },
};

/** Files that are compiled into a build (the rest, like theme templates, are read as they are). */
export const BUILDS = [
  { app: 'api', prefix: 'apps/api/', live: 'apps/api/dist', staged: 'apps/api/dist-staged', previous: 'apps/api/dist-previous' },
  { app: 'admin', prefix: 'apps/admin/', live: 'apps/admin/dist', staged: 'apps/admin/dist-staged', previous: 'apps/admin/dist-previous' },
  { app: 'web', prefix: 'apps/web/src/', live: 'apps/web/.next', staged: 'apps/web/.next-staged', previous: 'apps/web/.next-previous' },
];

export const buildFor = (rel) => BUILDS.find((b) => rel.startsWith(b.prefix)) ?? null;

/** Is `rel` (a forward-slash path inside the package) one of these owned paths? */
export function ownedBy(paths, rel) {
  return paths.some((p) => (p.endsWith('/') ? rel.startsWith(p) && rel.length > p.length : rel === p));
}

/** -1, 0 or 1 for dotted version strings (1.10.0 > 1.9.2). */
export function compareVersions(a, b) {
  const pa = String(a).split('.').map((n) => parseInt(n, 10) || 0);
  const pb = String(b).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

export const SLUG_RE = /^[a-z][a-z0-9-]{0,40}$/;

/**
 * An extension package (made by `node pack.mjs extension <slug>` in Beekiri-Store) carries its own
 * description, with every file and its SHA-256, and the signature of that description.
 */
export const EXTENSION_MANIFEST = 'beekiri-extension.json';
export const EXTENSION_SIGNATURE = 'beekiri-extension.sig';
export const VERSION_RE = /^\d{1,4}\.\d{1,4}\.\d{1,6}$/;

/**
 * 996agency's release signing keys (same as scripts/core-update.mjs). The signed text names the
 * extension and the SHA-256 of its package description, so a core signature can never pass as an
 * extension one or the other way round. The Hub only stores packages: it cannot sign them.
 */
const RELEASE_KEYS = ['dL0loV7jwSJ1bKW62LZfLyO6kPiaxR55565WvqceXT0='];
const SPKI_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');

export const extensionSignedText = (slug, version, manifestSha256) => `beekiri-extension:v1\n${slug}\n${version}\n${manifestSha256}`;

export function extensionSigned(slug, version, sha256, signatureB64) {
  const signature = Buffer.from(String(signatureB64 || ''), 'base64');
  if (signature.length !== 64) return false;
  const message = Buffer.from(extensionSignedText(slug, version, sha256), 'utf8');
  return RELEASE_KEYS.some((b64) => {
    try {
      const key = createPublicKey({ key: Buffer.concat([SPKI_PREFIX, Buffer.from(b64, 'base64')]), format: 'der', type: 'spki' });
      return verify(null, message, key, signature);
    } catch {
      return false;
    }
  });
}

export const sha256Of = (buffer) => createHash('sha256').update(buffer).digest('hex');
