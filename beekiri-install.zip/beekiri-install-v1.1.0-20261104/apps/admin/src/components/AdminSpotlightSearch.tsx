import { FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CONNECTOR_COMING_SOON } from '../lib/features';
import { api } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { useAdminEntry } from '../lib/AdminEntryContext';
import { adminHref } from '../lib/admin-login';
import { POST_TYPES_CHANGED } from '../lib/admin-events';
import { canAccessSpotlightItem } from '../lib/admin-capabilities';
import { useActiveExtensions } from '../lib/extensions-state';

function spotlightTo(basePath: string, rel: string) {
  const [path, query] = rel.split('?');
  const full = adminHref(basePath, path || '');
  return query ? `${full}?${query}` : full;
}

type SearchItem = {
  id: string;
  label: string;
  path: string;
  to: string;
  keywords: string;
  /** Only listed while this extension is active. */
  extension?: string;
};

type SpotlightCpt = {
  slug: string;
  singular: string;
  plural: string;
  active?: boolean;
};

const SEARCH_ITEMS: SearchItem[] = [
  {
    id: 'shop',
    label: 'Shop',
    path: 'shop',
    to: 'shop',
    keywords: 'shop shopping store ecommerce sales overview revenue',
    extension: 'shopping',
  },
  {
    id: 'shop-products',
    label: 'Products',
    path: 'shop/products',
    to: 'shop/products',
    keywords: 'shop products catalog items stock price sku inventory',
    extension: 'shopping',
  },
  {
    id: 'shop-products-new',
    label: 'Add product',
    path: 'shop/products/new',
    to: 'shop/products/new',
    keywords: 'shop new product add create',
    extension: 'shopping',
  },
  {
    id: 'shop-categories',
    label: 'Product categories',
    path: 'shop/categories',
    to: 'shop/categories',
    keywords: 'shop product categories taxonomy',
    extension: 'shopping',
  },
  {
    id: 'shop-tags',
    label: 'Product tags',
    path: 'shop/tags',
    to: 'shop/tags',
    keywords: 'shop product tags',
    extension: 'shopping',
  },
  {
    id: 'shop-pages',
    label: 'Shop Editor',
    path: 'shop/pages',
    to: 'shop/pages',
    keywords: 'shop editor design pages storefront cart checkout layout',
    extension: 'shopping',
  },
  {
    id: 'shop-orders',
    label: 'Orders',
    path: 'shop/orders',
    to: 'shop/orders',
    keywords: 'shop orders sales invoices refunds fulfilment',
    extension: 'shopping',
  },
  {
    id: 'shop-customers',
    label: 'Customers',
    path: 'shop/customers',
    to: 'shop/customers',
    keywords: 'shop customers buyers',
    extension: 'shopping',
  },
  {
    id: 'shop-coupons',
    label: 'Coupons',
    path: 'shop/coupons',
    to: 'shop/coupons',
    keywords: 'shop coupons discount codes promotions',
    extension: 'shopping',
  },
  {
    id: 'shop-settings',
    label: 'Shop settings',
    path: 'shop/settings',
    to: 'shop/settings',
    keywords: 'shop settings payments stripe shipping tax currency emails checkout',
    extension: 'shopping',
  },
  {
    id: 'dashboard',
    label: 'Dashboard',
    path: '',
    to: '',
    keywords: 'dashboard home overview hive status',
  },
  {
    id: 'analytics',
    label: 'Analytics',
    path: 'analytics',
    to: 'analytics',
    keywords: 'analytics traffic users sessions google ga4 reports pages sources',
  },
  {
    id: 'posts',
    label: 'Posts',
    path: 'posts',
    to: 'posts',
    keywords: 'posts blog articles content',
  },
  {
    id: 'pages',
    label: 'Pages',
    path: 'pages',
    to: 'pages',
    keywords: 'pages content',
  },
  {
    id: 'media',
    label: 'Media',
    path: 'media',
    to: 'media',
    keywords: 'media library images uploads files',
  },
  {
    id: 'seo',
    label: 'SEO',
    path: 'seo',
    to: 'seo',
    keywords: 'seo search meta title description open graph social beeseo audit',
  },
  {
    id: 'connector',
    label: 'Connector',
    path: 'connector',
    to: 'connector',
    keywords: 'connector connections ai beequeen claude chatgpt openai gemini grok providers agents',
  },
  {
    id: 'extensions',
    label: 'Extensions',
    path: 'extensions',
    to: 'extensions',
    keywords: 'extensions plugins add-ons addons shopping shop store ecommerce',
  },
  {
    id: 'fields',
    label: 'Backend Fields',
    path: 'fields',
    to: 'fields',
    keywords: 'backend fields field groups custom fields',
  },
  {
    id: 'post-types',
    label: 'Post Types',
    path: 'fields/post-types',
    to: 'fields/post-types',
    keywords: 'post types cpt custom post type',
  },
  {
    id: 'taxonomies',
    label: 'Taxonomies',
    path: 'fields/taxonomies',
    to: 'fields/taxonomies',
    keywords: 'taxonomies categories tags',
  },
  {
    id: 'options-pages',
    label: 'Options Pages',
    path: 'fields/options-pages',
    to: 'fields/options-pages',
    keywords: 'options pages settings pages',
  },
  {
    id: 'fields-settings',
    label: 'Backend Fields Settings',
    path: 'fields/settings',
    to: 'fields/settings',
    keywords: 'fields settings',
  },
  {
    id: 'fields-tools',
    label: 'Backend Fields Tools',
    path: 'fields/tools',
    to: 'fields/tools',
    keywords: 'fields tools import export',
  },
  {
    id: 'users',
    label: 'Users',
    path: 'users',
    to: 'users',
    keywords: 'users accounts team members',
  },
  {
    id: 'user-permissions',
    label: 'User Permissions',
    path: 'users/permissions',
    to: 'users/permissions',
    keywords: 'permissions roles capabilities access privileges owner',
  },
  {
    id: 'appearance',
    label: 'Appearance',
    path: 'appearance',
    to: 'appearance',
    keywords: 'appearance themes design',
  },
  {
    id: 'header',
    label: 'Header',
    path: 'appearance/header',
    to: 'appearance/header',
    keywords: 'header chrome theme header',
  },
  {
    id: 'footer',
    label: 'Footer',
    path: 'appearance/footer',
    to: 'appearance/footer',
    keywords: 'footer chrome theme footer',
  },
  {
    id: 'templates',
    label: 'Templates',
    path: 'appearance/templates',
    to: 'appearance/templates',
    keywords: 'templates layouts',
  },
  {
    id: 'settings',
    label: 'Settings',
    path: 'settings',
    to: 'settings',
    keywords: 'settings site configuration',
  },
  {
    id: 'settings-core',
    label: 'Beekiri Core',
    path: 'settings?tab=core',
    to: 'settings?tab=core',
    keywords: 'beekiri core updates version system status',
  },
  {
    id: 'settings-general',
    label: 'General settings',
    path: 'settings?tab=general',
    to: 'settings?tab=general',
    keywords: 'general settings title tagline language timezone favicon',
  },
  {
    id: 'settings-reading',
    label: 'Reading settings',
    path: 'settings?tab=reading',
    to: 'settings?tab=reading',
    keywords: 'reading search engines index visibility blog public',
  },
  {
    id: 'settings-writing',
    label: 'Writing settings',
    path: 'settings?tab=writing',
    to: 'settings?tab=writing',
    keywords: 'writing settings',
  },
  {
    id: 'settings-page-editor',
    label: 'Page editor settings',
    path: 'settings?tab=page-editor',
    to: 'settings?tab=page-editor',
    keywords: 'page editor frontend php react runtime',
  },
  {
    id: 'settings-advanced',
    label: 'Advanced settings',
    path: 'settings?tab=advanced',
    to: 'settings?tab=advanced',
    keywords: 'advanced business hours phone address',
  },
  {
    id: 'settings-translation',
    label: 'Translation & languages',
    path: 'settings?tab=translation',
    to: 'settings?tab=translation',
    keywords: 'translation translate language languages multilingual switcher locale i18n',
  },
  {
    id: 'settings-permalinks',
    label: 'Permalinks & navigation',
    path: 'settings?tab=permalinks',
    to: 'settings?tab=permalinks',
    keywords:
      'permalinks permalink urls slugs navigation menu menus nav header links site menu front page',
  },
  {
    id: 'settings-media',
    label: 'Media settings',
    path: 'settings?tab=media',
    to: 'settings?tab=media',
    keywords: 'media settings image sizes optimization',
  },
  {
    id: 'analytics-bee-cookies',
    label: 'BeeCookies',
    path: 'analytics/cookies',
    to: 'analytics/cookies',
    keywords: 'beecookies cookies consent gdpr banner analytics privacy',
  },
  {
    id: 'settings-cache',
    label: 'Cache',
    path: 'settings?tab=cache',
    to: 'settings?tab=cache',
    keywords: 'cache flush clear pagespeed performance',
  },
  {
    id: 'settings-instructions',
    label: 'Instructions',
    path: 'settings?tab=instructions',
    to: 'settings?tab=instructions',
    keywords: 'instructions help docs guide',
  },
];

const ICON_SEARCH = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    <circle cx="11" cy="11" r="8" />
    <path d="m21 21-4.3-4.3" />
  </svg>
);

function isApplePlatform() {
  if (typeof navigator === 'undefined') return false;
  return /Mac|iPhone|iPad|iPod/i.test(navigator.platform || navigator.userAgent);
}

function matches(item: SearchItem, q: string) {
  if (!q) return true;
  const hay = `${item.label} ${item.path} ${item.keywords}`.toLowerCase();
  return hay.includes(q);
}

export function AdminSpotlightSearch() {
  const navigate = useNavigate();
  const auth = useAuth();
  const { basePath } = useAdminEntry();
  const caps = auth.user?.capabilities ?? [];
  const activeExtensions = useActiveExtensions();
  const canFields = caps.includes('manage_fields');
  const isOwner = auth.user?.isOwner ?? false;
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [cpts, setCpts] = useState<SpotlightCpt[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const apple = useMemo(() => isApplePlatform(), []);

  useEffect(() => {
    if (!canFields) {
      setCpts([]);
      return;
    }
    const load = () => {
      api<{ postTypes: SpotlightCpt[] }>('/api/fields/post-types')
        .then((res) => setCpts((res.postTypes ?? []).filter((p) => p.active !== false && p.slug !== 'product')))
        .catch(() => setCpts([]));
    };
    load();
    window.addEventListener(POST_TYPES_CHANGED, load);
    return () => window.removeEventListener(POST_TYPES_CHANGED, load);
  }, [canFields]);

  const items = useMemo(() => {
    let base = SEARCH_ITEMS.filter((item) => {
      if (item.extension && !activeExtensions.includes(item.extension)) return false;
      if (!canAccessSpotlightItem(caps, item.id)) return false;
      if (item.id === 'user-permissions' && !isOwner) return false;
      if (item.id === 'connector' && CONNECTOR_COMING_SOON) return false;
      return true;
    }).map((item) => {
      const to = spotlightTo(basePath, item.to);
      return { ...item, path: to, to };
    });
    if (auth.user?.id) {
      const profile = spotlightTo(basePath, `users/${auth.user.id}`);
      base = [
        ...base,
        {
          id: 'my-profile',
          label: 'Your profile',
          path: profile,
          to: profile,
          keywords: 'profile account me my user password email display name',
        },
      ];
    }
    const cptItems: SearchItem[] = cpts.map((c) => {
      const to = spotlightTo(basePath, `content/${c.slug}`);
      return {
        id: `cpt-${c.slug}`,
        label: c.plural,
        path: to,
        to,
        keywords: `${c.singular} ${c.plural} ${c.slug} cpt custom post type content`,
      };
    });
    return [...base, ...cptItems];
  }, [basePath, cpts, caps, canFields, isOwner, auth.user?.id, activeExtensions]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter((item) => matches(item, q));
  }, [query, items]);

  const close = () => {
    setOpen(false);
    setQuery('');
  };

  const go = (to: string) => {
    close();
    navigate(to);
  };

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const id = window.requestAnimationFrame(() => inputRef.current?.focus());
    return () => {
      document.body.style.overflow = prev;
      window.cancelAnimationFrame(id);
    };
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setOpen(true);
        setQuery('');
        return;
      }
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const first = filtered[0];
    if (first) go(first.to);
  };

  return (
    <>
      <button
        type="button"
        className="bk-admin-search__trigger bk-admin-search__trigger--icon"
        aria-label="Open search"
        onClick={() => {
          setOpen(true);
          setQuery('');
        }}
      >
        {ICON_SEARCH}
      </button>
      <button
        type="button"
        className="bk-admin-search__trigger bk-admin-search__trigger--full"
        aria-label="Open search"
        onClick={() => {
          setOpen(true);
          setQuery('');
        }}
      >
        {ICON_SEARCH}
        <span>Search</span>
        <span className="bk-admin-search__kbds" aria-hidden="true">
          {apple ? (
            <>
              <kbd>⌘</kbd>
              <kbd>K</kbd>
            </>
          ) : (
            <>
              <kbd>Ctrl</kbd>
              <kbd>K</kbd>
            </>
          )}
        </span>
      </button>

      {open ? (
        <div
          className="bk-admin-search"
          role="dialog"
          aria-modal="true"
          aria-labelledby="bk-admin-search-input"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) close();
          }}
        >
          <form className="bk-admin-search__panel" onSubmit={onSubmit}>
            <div className="bk-admin-search__head">
              {ICON_SEARCH}
              <input
                id="bk-admin-search-input"
                ref={inputRef}
                type="search"
                placeholder="Search admin…"
                autoComplete="off"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
              <kbd>esc</kbd>
            </div>
            <ul className="bk-admin-search__results">
              {filtered.map((item) => (
                <li key={item.id}>
                  <button type="button" onClick={() => go(item.to)}>
                    <span>{item.label}</span>
                    <code>{item.path}</code>
                  </button>
                </li>
              ))}
              {filtered.length === 0 ? (
                <li className="bk-admin-search__empty">No matches</li>
              ) : null}
            </ul>
          </form>
        </div>
      ) : null}
    </>
  );
}
