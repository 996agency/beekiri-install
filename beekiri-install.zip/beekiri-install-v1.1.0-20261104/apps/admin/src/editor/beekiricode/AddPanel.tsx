import { useMemo, useState, type DragEvent } from 'react';
import { Link } from 'react-router-dom';
import { ArrowSquareOut, MagnifyingGlass, PuzzlePiece, X } from '@phosphor-icons/react';
import { useAdminEntry } from '../../lib/AdminEntryContext';
import { adminHref } from '../../lib/admin-login';
import type { ElementKey, ThemeLayout } from './document';
import {
  ELEMENTS,
  ELEMENT_GROUPS,
  ELEMENT_MIME,
  encodePaletteDrag,
  setPaletteDrag,
  type PaletteDrag,
} from './nodeMeta';

type Props = {
  layouts: ThemeLayout[];
  /** GET /api/layouts progress — an empty list only means "none" once it is ready. */
  layoutsStatus: 'loading' | 'ready' | 'error';
  onReloadLayouts: () => void;
  /** Where a click will put the element, e.g. "inside Section". */
  insertHint: string;
  onAddElement: (key: ElementKey) => void;
  onAddLayout: (layout: ThemeLayout) => void;
  /** Editing a Shop page: offer the "Shop content" element. */
  shopPage?: boolean;
};

function startDrag(e: DragEvent, drag: PaletteDrag) {
  e.dataTransfer.setData(ELEMENT_MIME, encodePaletteDrag(drag));
  e.dataTransfer.effectAllowed = 'copy';
  setPaletteDrag(drag);
}

/** Explorer “Add” tab — basic elements plus the theme layouts synced from Backend Fields. */
export function AddPanel({
  layouts,
  layoutsStatus,
  onReloadLayouts,
  insertHint,
  onAddElement,
  onAddLayout,
  shopPage = false,
}: Props) {
  const [query, setQuery] = useState('');
  const q = query.trim().toLowerCase();
  const fieldsHref = adminHref(useAdminEntry().basePath, 'fields');

  const elementGroups = useMemo(
    () =>
      ELEMENT_GROUPS.map((g) => ({
        ...g,
        items: ELEMENTS.filter(
          (el) =>
            el.group === g.id &&
            (!el.shopOnly || shopPage) &&
            (!q || `${el.label} ${el.hint} ${el.keywords ?? ''}`.toLowerCase().includes(q)),
        ),
      })).filter((g) => g.items.length > 0),
    [q, shopPage],
  );

  const visibleLayouts = useMemo(
    () => layouts.filter((l) => !q || `${l.title} ${l.slug} ${l.key}`.toLowerCase().includes(q)),
    [layouts, q],
  );

  const nothing = elementGroups.length === 0 && visibleLayouts.length === 0;

  return (
    <div className="bk-add">
      <label className="bk-add__search">
        <MagnifyingGlass size={14} aria-hidden />
        <input
          type="search"
          value={query}
          placeholder="Search elements and layouts…"
          aria-label="Search elements and layouts"
          onChange={(e) => setQuery(e.target.value)}
        />
        {query ? (
          <button type="button" aria-label="Clear search" onClick={() => setQuery('')}>
            <X size={12} weight="bold" />
          </button>
        ) : null}
      </label>

      <div className="bk-add__scroll">
        {elementGroups.map((g) => (
          <section key={g.id} className="bk-add__group" aria-label={g.label}>
            <h3 className="bk-add__group-title">{g.label}</h3>
            <div className="bk-add__grid" role="list">
              {g.items.map((el) => (
                <button
                  key={el.key}
                  type="button"
                  role="listitem"
                  className="bk-add__tile"
                  draggable
                  title={`${el.label} — ${el.hint}. Click to add, or drag onto the page.`}
                  onClick={() => onAddElement(el.key)}
                  onDragStart={(e) => startDrag(e, { kind: 'element', key: el.key })}
                  onDragEnd={() => setPaletteDrag(null)}
                >
                  <span className="bk-add__tile-icon" aria-hidden>
                    <el.Icon size={18} weight="regular" />
                  </span>
                  <span className="bk-add__tile-label">{el.label}</span>
                  <span className="bk-add__tile-hint">{el.hint}</span>
                </button>
              ))}
            </div>
          </section>
        ))}

        {!q || visibleLayouts.length > 0 ? (
          <section className="bk-add__group bk-add__group--layouts" aria-label="Theme layouts">
            <div className="bk-add__group-head">
              <h3 className="bk-add__group-title">
                Theme layouts
                {layoutsStatus === 'ready' && layouts.length ? (
                  <span className="bk-add__count">{layouts.length}</span>
                ) : null}
              </h3>
              <Link to={fieldsHref} className="bk-add__group-link" title="Manage in Backend Fields">
                Backend Fields <ArrowSquareOut size={11} aria-hidden />
              </Link>
            </div>
            <p className="bk-add__group-note">
              Built from your field groups — each one renders its own PHP template and styles.
            </p>
            {layoutsStatus === 'loading' && layouts.length === 0 ? (
              <p className="bk-add__empty">Loading layouts…</p>
            ) : layoutsStatus === 'error' ? (
              <p className="bk-add__empty">
                Couldn’t load the theme layouts.{' '}
                <button type="button" className="bk-add__retry" onClick={onReloadLayouts}>
                  Try again
                </button>
              </p>
            ) : layouts.length === 0 ? (
              <p className="bk-add__empty">
                No layouts yet. Create a field group in Backend Fields and save — a folder appears
                under
                <code>themes/beekiri-child/layouts/</code> and shows up here.
              </p>
            ) : (
              <div className="bk-add__layouts" role="list">
                {visibleLayouts.map((layout) => (
                  <button
                    key={layout.slug}
                    type="button"
                    role="listitem"
                    className="bk-add__layout"
                    draggable
                    title={`${layout.title} (${layout.slug}). Click to add, or drag onto the page.`}
                    onClick={() => onAddLayout(layout)}
                    onDragStart={(e) => startDrag(e, { kind: 'layout', slug: layout.slug })}
                    onDragEnd={() => setPaletteDrag(null)}
                  >
                    <span className="bk-add__layout-icon" aria-hidden>
                      <PuzzlePiece size={16} weight="regular" />
                    </span>
                    <span className="bk-add__layout-text">
                      <span className="bk-add__layout-title">{layout.title}</span>
                      <span className="bk-add__layout-meta">
                        {layout.slug}
                        {layout.fields?.length
                          ? ` · ${layout.fields.length} field${layout.fields.length === 1 ? '' : 's'}`
                          : ''}
                      </span>
                    </span>
                  </button>
                ))}
              </div>
            )}
          </section>
        ) : null}

        {nothing ? <p className="bk-add__empty">Nothing matches “{query}”.</p> : null}
      </div>

      <p className="bk-add__foot">
        Click adds {insertHint}. Drag to place anywhere in Layers or on the page.
      </p>
    </div>
  );
}
