import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type DragEvent,
  type JSX,
  type MouseEvent,
  type ReactNode,
} from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowSquareOut,
  ArrowUUpLeft,
  ArrowUUpRight,
  CaretDown,
  CircleNotch,
  CloudArrowUp,
  Cursor,
  Desktop,
  DeviceMobile,
  DeviceTablet,
  Eye,
  GearSix,
  MagnifyingGlass,
  MagnifyingGlassMinus,
  MagnifyingGlassPlus,
  CornersOut,
  Plus,
  SquaresFour,
  X,
} from '@phosphor-icons/react';
import { hoverDeclarations, hoverTransition, sanitizeDeclarations, videoEmbedUrl } from '@beekiri/page-blocks';
import { api, apiUrl } from '../../api/client';
import {
  canAcceptChildren,
  createElement,
  createLayoutNode,
  duplicateNode,
  findParentId,
  insertTree,
  isBeekiriCodeDoc,
  moveNode,
  parseBeekiriCodeDoc,
  pruneMissingLayouts,
  removeNode,
  shiftNode,
  stripLayoutChromeStyles,
  type BeekiriCodeNode,
  type BeekiriCodePageDoc,
  type ElementKey,
  type MovePosition,
  type NodeTree,
  type ThemeLayout,
} from './document';
import { AddPanel } from './AddPanel';
import { CanvasViewport, ZOOM_MAX, ZOOM_MIN, type ViewportApi } from './CanvasViewport';
import { LayersTree } from './LayersTree';
import { LayoutPhpPreview } from './LayoutPhpPreview';
import { SelectionChrome } from './SelectionChrome';
import { SeoPanel } from './SeoPanel';
import type { SpacingFocus } from './inspector/BoxModel';
import {
  ELEMENT_MIME,
  TYPE_META,
  decodePaletteDrag,
  getPaletteDrag,
  nodeName,
  type PaletteDrag,
} from './nodeMeta';
import {
  EditorPresenceProvider,
  PeerAvatarStack,
  RemoteCursors,
  useEditorPresence,
} from './EditorPresence';
import { PageSettingsPanel } from './PageSettingsPanel';
import { PropertiesPanel } from './PropertiesPanel';
import { collectDocumentColors } from './inspector/css-values';
import {
  editTargetForViewMode,
  resolveStyleForBreakpoint,
} from './responsiveStyles';
import './beekiricode.css';
import { initialValue, typeDef } from '../../fields/acf-types';
import { usePageEditorChrome } from '../PageEditorChrome';

const BREAKPOINTS = [
  { id: 'desktop', label: 'Desktop', width: 1520, Icon: Desktop },
  { id: 'tablet', label: 'Tablet', width: 768, Icon: DeviceTablet },
  { id: 'mobile', label: 'Mobile', width: 375, Icon: DeviceMobile },
] as const;

type BreakpointId = (typeof BREAKPOINTS)[number]['id'];
type ExplorerTab = 'layers' | 'add' | 'properties' | 'page-settings' | 'seo';
type CanvasMode = 'select' | 'preview';
type ViewMode = 'multi' | BreakpointId;
type CanvasDrop = { id: string; position: MovePosition } | null;

const HISTORY_LIMIT = 100;
/** Edits closer together than this (typing, slider drags) share one undo step. */
const HISTORY_COALESCE_MS = 600;

const treeOf = (node: BeekiriCodeNode): NodeTree => ({ rootId: node.id, nodes: { [node.id]: node } });

const isMac = typeof navigator !== 'undefined' && /Mac|iPhone|iPad/.test(navigator.platform);
const MOD = isMac ? '⌘' : 'Ctrl';

const EXPLORER_TABS: { id: ExplorerTab; label: string; title: string }[] = [
  { id: 'layers', label: 'Layers', title: 'Page structure' },
  { id: 'add', label: 'Add', title: 'Elements and theme layouts' },
  { id: 'properties', label: 'Props', title: 'Properties of the selected element' },
  { id: 'page-settings', label: 'Page', title: 'Taxonomies and page settings' },
  { id: 'seo', label: 'SEO', title: 'Search, social and structured data' },
];

/** Heading / text / button content is edited in place on the canvas. */
function EditableText({
  tag,
  nodeId,
  nodeType,
  text,
  className,
  style,
  href,
  onCommit,
  onCancel,
}: {
  tag: keyof JSX.IntrinsicElements;
  nodeId: string;
  nodeType: string;
  text: string;
  className: string;
  style: CSSProperties;
  href?: string;
  onCommit: (text: string) => void;
  onCancel: () => void;
}) {
  const ref = useRef<HTMLElement | null>(null);
  const done = useRef(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    // Seed once; React never re-renders children into a live contenteditable.
    el.textContent = text;
    el.focus();
    const sel = window.getSelection();
    if (sel) {
      const range = document.createRange();
      range.selectNodeContents(el);
      sel.removeAllRanges();
      sel.addRange(range);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const finish = (cancel: boolean) => {
    if (done.current) return;
    done.current = true;
    if (cancel) onCancel();
    else onCommit((ref.current?.innerText ?? '').replace(/\n+$/, ''));
  };
  // Typed as an anchor so `href` is accepted; buttons are the only tag that passes one.
  const Tag = tag as 'a';
  return (
    <Tag
      ref={ref as never}
      className={`${className} is-editing`}
      style={style}
      href={href}
      data-node-id={nodeId}
      data-node-type={nodeType}
      contentEditable="plaintext-only"
      suppressContentEditableWarning
      spellCheck
      onClick={(e: MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
      }}
      onBlur={() => finish(false)}
      onKeyDown={(e) => {
        e.stopPropagation();
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          finish(false);
        }
        if (e.key === 'Escape') {
          e.preventDefault();
          finish(true);
        }
      }}
    />
  );
}

/** Reuse/reload one browser tab per page instead of opening extras. */
export function openOrReloadLiveView(href: string, pageId: string) {
  const name = `beekiri-view-${pageId}`;
  const win = window.open(href, name);
  if (!win) return;
  try {
    const next = new URL(href, window.location.href);
    if (win.location.href === 'about:blank') {
      win.location.replace(next.href);
    } else if (
      win.location.origin === next.origin &&
      win.location.pathname === next.pathname &&
      win.location.search === next.search
    ) {
      // Same URL after publish — force reload so updates appear.
      win.location.reload();
    } else {
      win.location.assign(next.href);
    }
    win.focus();
  } catch {
    /* cross-origin: named open() already focused that tab */
    try {
      win.focus();
    } catch {
      /* ignore */
    }
  }
}

type Props = {
  pageId: string;
  /** Content API base, e.g. `/api/pages` or `/api/content/book`. */
  apiBase: string;
  title: string;
  slug?: string;
  /** Public path including prefix (`/about` or `/blog/hello`). */
  publicPath?: string;
  permalinkBase?: string;
  isPublished?: boolean;
  doc: BeekiriCodePageDoc;
  onChange: (doc: BeekiriCodePageDoc) => void;
  busy?: boolean;
  isPublishing?: boolean;
  canPublish?: boolean;
  isDirty?: boolean;
  viewHref?: string | null;
  onSaveDraft: () => void;
  onPublish: () => void;
  onOpenSettings: () => void;
  onPreview?: () => void;
};

function cloneDoc(doc: BeekiriCodePageDoc): BeekiriCodePageDoc {
  return JSON.parse(JSON.stringify(doc)) as BeekiriCodePageDoc;
}

export function BeekiriCodeCanvas(props: Props) {
  return (
    <EditorPresenceProvider pageId={props.pageId}>
      <BeekiriCodeCanvasInner {...props} />
    </EditorPresenceProvider>
  );
}

function BeekiriCodeCanvasInner({
  pageId,
  apiBase,
  slug = '',
  publicPath,
  permalinkBase = '',
  isPublished = false,
  doc,
  onChange,
  busy,
  isPublishing = false,
  canPublish,
  isDirty,
  viewHref = null,
  onSaveDraft,
  onPublish,
  onOpenSettings,
  onPreview,
}: Props) {
  const chrome = usePageEditorChrome();
  const {
    remotePeers,
    reportCursor,
    reportSelection,
    broadcastDoc,
    subscribeRemoteDoc,
  } = useEditorPresence();
  const applyingRemoteRef = useRef(false);
  const docRef = useRef(doc);
  docRef.current = doc;
  const historyRef = useRef<{ past: BeekiriCodePageDoc[]; future: BeekiriCodePageDoc[]; stamp: number }>({
    past: [],
    future: [],
    stamp: 0,
  });
  const [history, setHistory] = useState({ canUndo: false, canRedo: false });
  const syncHistory = () => {
    const h = historyRef.current;
    setHistory({ canUndo: h.past.length > 0, canRedo: h.future.length > 0 });
  };

  /**
   * Apply a doc change. `history: 'coalesce'` is for continuous edits (typing,
   * slider drags) so a burst becomes one undo step; structural changes always
   * get their own step; `false` skips history (mount-time normalisation).
   */
  const commitDoc = useCallback(
    (next: BeekiriCodePageDoc, opts: { history?: boolean | 'coalesce' } = {}) => {
      const prev = docRef.current;
      if (!applyingRemoteRef.current && opts.history !== false && prev !== next) {
        const h = historyRef.current;
        const now = Date.now();
        const merge = opts.history === 'coalesce' && h.past.length > 0 && now - h.stamp < HISTORY_COALESCE_MS;
        if (!merge) {
          h.past.push(prev);
          if (h.past.length > HISTORY_LIMIT) h.past.shift();
        }
        // Only a run of coalescing edits keeps the window open.
        h.stamp = opts.history === 'coalesce' ? now : 0;
        h.future = [];
        syncHistory();
      }
      onChange(next);
      if (!applyingRemoteRef.current) broadcastDoc(next);
    },
    [onChange, broadcastDoc],
  );

  const undo = useCallback(() => {
    const h = historyRef.current;
    const prev = h.past.pop();
    if (!prev) return;
    h.future.push(docRef.current);
    h.stamp = 0;
    syncHistory();
    onChange(prev);
    broadcastDoc(prev);
    setSelectedId((id) => (id && prev.nodes[id] ? id : prev.rootId));
  }, [onChange, broadcastDoc]);

  const redo = useCallback(() => {
    const h = historyRef.current;
    const next = h.future.pop();
    if (!next) return;
    h.past.push(docRef.current);
    h.stamp = 0;
    syncHistory();
    onChange(next);
    broadcastDoc(next);
    setSelectedId((id) => (id && next.nodes[id] ? id : next.rootId));
  }, [onChange, broadcastDoc]);

  useEffect(() => {
    return subscribeRemoteDoc((ev) => {
      if (!isBeekiriCodeDoc(ev.doc)) return;
      const next = parseBeekiriCodeDoc(ev.doc);
      applyingRemoteRef.current = true;
      onChange(next);
      setSelectedId((prev) =>
        prev && next.nodes[prev] ? prev : next.rootId,
      );
      queueMicrotask(() => {
        applyingRemoteRef.current = false;
      });
    });
  }, [subscribeRemoteDoc, onChange]);

  const [selectedId, setSelectedId] = useState<string | null>(doc.rootId);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [explorerTab, setExplorerTab] = useState<ExplorerTab>('layers');
  const [layerQuery, setLayerQuery] = useState('');
  /** Heading / text / button being edited in place on the canvas. */
  const [editingTextId, setEditingTextId] = useState<string | null>(null);
  /** Drop indicator while dragging from the Add panel over the canvas. */
  const [canvasDrop, setCanvasDrop] = useState<CanvasDrop>(null);
  /** Spacing field hovered in Props → padding / margin overlay on the selected element. */
  const [spacingFocus, setSpacingFocus] = useState<SpacingFocus>(null);
  useEffect(() => setSpacingFocus(null), [selectedId, explorerTab]);

  /** Advanced → Custom CSS, scoped to each node the same way the publisher does it. */
  const customCssText = useMemo(
    () =>
      Object.values(doc.nodes)
        .map((n) => {
          const sel = `.bk-beekiricode__frame-canvas [data-node-id="${n.id}"]`;
          const out: string[] = [];
          const decls = sanitizeDeclarations(n.customCss);
          if (decls) out.push(`${sel}{${decls}}`);
          const hover = hoverDeclarations(n.hoverStyle);
          if (hover) {
            const transition = hoverTransition(n.hoverStyle, n.style);
            if (transition) out.push(`${sel}, ${sel} > section{transition:${transition}}`);
            // Inline styles outrank stylesheets — hover must be !important here.
            // Layout nodes paint on the PHP <section> inside the host.
            const important = hover.split(';').map((d) => `${d} !important`).join(';');
            const target = n.type === 'layout' ? `${sel} > section:hover` : `${sel}:hover`;
            out.push(`${target}{${important}}`);
          }
          return out.join('\n');
        })
        .filter(Boolean)
        .join('\n'),
    [doc.nodes],
  );
  const [canvasMode, setCanvasMode] = useState<CanvasMode>('select');
  /** Default: first breakpoint (Desktop 1520) only — closer zoom than multi. */
  const [viewMode, setViewMode] = useState<ViewMode>('desktop');
  const [viewportOpen, setViewportOpen] = useState(false);
  const [publishOpen, setPublishOpen] = useState(false);
  /** Current canvas scale (1 = 100%); owned by the viewport, mirrored here for the UI. */
  const [scale, setScale] = useState(0.55);
  const viewportApi = useRef<ViewportApi | null>(null);
  const [themeLayouts, setThemeLayouts] = useState<ThemeLayout[]>([]);
  /** Edit mode only: ghost-render nodes hidden on the current breakpoint. */
  const [showHidden, setShowHidden] = useState(false);
  const documentColors = useMemo(
    () =>
      collectDocumentColors(
        Object.values(doc.nodes).flatMap((n) => [
          n.style,
          n.stylesByBreakpoint?.tablet,
          n.stylesByBreakpoint?.mobile,
        ]),
      ),
    [doc.nodes],
  );
  const publishRef = useRef<HTMLDivElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);

  const [layoutsStatus, setLayoutsStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const layoutsReady = layoutsStatus === 'ready';
  const [layoutsFetch, setLayoutsFetch] = useState(0);
  const reloadLayouts = useCallback(() => setLayoutsFetch((n) => n + 1), []);

  useEffect(() => {
    let cancelled = false;
    setLayoutsStatus('loading');
    api<{ layouts: ThemeLayout[] }>('/api/layouts')
      .then((res) => {
        if (cancelled) return;
        setThemeLayouts(Array.isArray(res.layouts) ? res.layouts : []);
        setLayoutsStatus('ready');
      })
      .catch(() => {
        if (cancelled) return;
        // Don't prune on fetch failure — keep existing layout nodes.
        setThemeLayouts([]);
        setLayoutsStatus('error');
      });
    return () => {
      cancelled = true;
    };
  }, [layoutsFetch]);

  // Load layout script.js for layouts used on the canvas (same files as the public site).
  useEffect(() => {
    if (typeof document === 'undefined' || !themeLayouts.length) return;
    const used = new Set(
      Object.values(doc.nodes)
        .filter((n) => n.type === 'layout' && n.layoutSlug)
        .map((n) => n.layoutSlug as string),
    );
    for (const layout of themeLayouts) {
      if (!used.has(layout.slug) || !layout.jsUrl) continue;
      const id = `bk-layout-js-${layout.slug}`;
      if (document.getElementById(id)) continue;
      const script = document.createElement('script');
      script.id = id;
      script.src = apiUrl(layout.jsUrl);
      script.async = true;
      document.body.appendChild(script);
    }
  }, [doc.nodes, themeLayouts]);

  // Drop trashed/missing layouts from the canvas; sync field keys for remaining ones.
  useEffect(() => {
    if (!layoutsReady) return;
    const cleaned = stripLayoutChromeStyles(doc);
    let next = pruneMissingLayouts(
      cleaned,
      themeLayouts.map((l) => l.slug),
    );
    let changed = next !== doc;

    if (themeLayouts.length) {
      if (!changed) next = cloneDoc(next);
      for (const node of Object.values(next.nodes)) {
        if (node.type !== 'layout' || !node.layoutSlug) continue;
        const def = themeLayouts.find((l) => l.slug === node.layoutSlug);
        if (!def?.fields?.length) continue;
        const fields = { ...(node.layoutFields || {}) };
        for (const f of def.fields) {
          if (typeDef(f.type).noValue || f.name in fields) continue;
          fields[f.name] = initialValue(f);
          changed = true;
        }
        node.layoutFields = fields;
        if (def.title && node.layoutTitle !== def.title) {
          node.layoutTitle = def.title;
          changed = true;
        }
      }
    }
    if (changed || next !== doc) commitDoc(next, { history: false });
    // Only on mount / layout defs — not every doc keystroke.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [themeLayouts, layoutsReady]);

  const syncLabel = busy ? 'Saving…' : isDirty ? 'Draft' : 'Draft synced';
  const syncOk = !busy && !isDirty;

  /** Preview forces a single frame; multi only in select mode. */
  const effectiveViewMode: ViewMode =
    canvasMode === 'preview'
      ? viewMode === 'multi'
        ? 'desktop'
        : viewMode
      : viewMode;

  const visibleFrames = useMemo(() => {
    if (effectiveViewMode === 'multi') return [...BREAKPOINTS];
    return BREAKPOINTS.filter((b) => b.id === effectiveViewMode);
  }, [effectiveViewMode]);

  const activeBreakpoint =
    effectiveViewMode === 'multi'
      ? BREAKPOINTS[0]
      : BREAKPOINTS.find((b) => b.id === effectiveViewMode) ?? BREAKPOINTS[0];

  /** multi / desktop → default styles for all; tablet/mobile → overrides only */
  const styleEditTarget = editTargetForViewMode(
    canvasMode === 'preview' && viewMode === 'multi' ? 'desktop' : viewMode,
  );

  const FRAME_GAP = 40;
  const designWidth =
    visibleFrames.reduce((sum, bp) => sum + bp.width, 0) + FRAME_GAP * Math.max(0, visibleFrames.length - 1);
  const zoom = Math.round(scale * 100);

  useEffect(() => {
    const onDoc = (e: Event) => {
      const t = e.target as Node;
      if (publishRef.current && !publishRef.current.contains(t)) setPublishOpen(false);
      if (viewportRef.current && !viewportRef.current.contains(t)) setViewportOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);

  const updateNode = useCallback(
    (id: string, patch: Partial<BeekiriCodeNode>) => {
      const next = cloneDoc(doc);
      const node = next.nodes[id];
      if (!node) return;
      next.nodes[id] = { ...node, ...patch, id: node.id, type: node.type };
      // Property edits arrive per keystroke / slider tick — merge them into one undo step.
      commitDoc(next, { history: 'coalesce' });
    },
    [doc, commitDoc],
  );

  const removeSelected = useCallback(
    (id: string) => {
      if (id === doc.rootId) return;
      const parentId = findParentId(doc, id);
      const next = removeNode(doc, id);
      if (!next) return;
      commitDoc(next);
      setSelectedId(parentId && next.nodes[parentId] ? parentId : next.rootId);
    },
    [doc, commitDoc],
  );

  const moveLayer = useCallback(
    (dragId: string, targetId: string, position: MovePosition) => {
      const next = moveNode(doc, dragId, targetId, position);
      if (!next) return;
      commitDoc(next);
      setSelectedId(dragId);
    },
    [doc, commitDoc],
  );

  const insertTreeAt = useCallback(
    (tree: NodeTree, targetId: string, position: MovePosition) => {
      const next = insertTree(doc, tree, targetId, position);
      if (!next) return;
      commitDoc(next);
      setSelectedId(tree.rootId);
    },
    [doc, commitDoc],
  );

  /** Where a click in the Add panel lands: inside the selected box, else right after the selection. */
  const insertAnchor = useMemo(() => {
    const id = selectedId && doc.nodes[selectedId] ? selectedId : doc.rootId;
    const node = doc.nodes[id];
    const isRoot = id === doc.rootId;
    const position: MovePosition = canAcceptChildren(node, isRoot) ? 'inside' : 'after';
    return { id, position, label: nodeName(node, isRoot) };
  }, [doc, selectedId]);

  const addElement = useCallback(
    (key: ElementKey) => insertTreeAt(createElement(key), insertAnchor.id, insertAnchor.position),
    [insertTreeAt, insertAnchor],
  );

  const addThemeLayout = useCallback(
    (layout: ThemeLayout) =>
      insertTreeAt(treeOf(createLayoutNode(layout)), insertAnchor.id, insertAnchor.position),
    [insertTreeAt, insertAnchor],
  );

  const dropPalette = useCallback(
    (drag: PaletteDrag, targetId: string, position: MovePosition) => {
      if (drag.kind === 'element') {
        insertTreeAt(createElement(drag.key), targetId, position);
        return;
      }
      const layout = themeLayouts.find((l) => l.slug === drag.slug);
      if (layout) insertTreeAt(treeOf(createLayoutNode(layout)), targetId, position);
    },
    [insertTreeAt, themeLayouts],
  );

  const duplicateSelected = useCallback(
    (id: string) => {
      const next = duplicateNode(doc, id);
      if (!next) return;
      commitDoc(next);
      // The copy sits right after the original.
      const pid = findParentId(next, id);
      const sibs = pid ? next.nodes[pid].children : [];
      const copyId = sibs[sibs.indexOf(id) + 1];
      if (copyId) setSelectedId(copyId);
    },
    [doc, commitDoc],
  );

  const shiftSelected = useCallback(
    (id: string, delta: -1 | 1) => {
      const next = shiftNode(doc, id, delta);
      if (next) commitDoc(next);
    },
    [doc, commitDoc],
  );

  const renameNode = useCallback(
    (id: string, label: string) => updateNode(id, { label: label.trim() || undefined }),
    [updateNode],
  );

  const selectParent = useCallback(
    (id: string) => {
      const pid = findParentId(doc, id);
      if (pid) setSelectedId(pid);
    },
    [doc],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (
        t &&
        (t.tagName === 'INPUT' ||
          t.tagName === 'TEXTAREA' ||
          t.tagName === 'SELECT' ||
          t.isContentEditable)
      ) {
        return;
      }
      const mod = e.metaKey || e.ctrlKey;
      const key = e.key.toLowerCase();
      if (mod && key === 'z') {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
        return;
      }
      const hasSel = Boolean(selectedId && selectedId !== doc.rootId);
      if (mod && key === 'd' && hasSel) {
        e.preventDefault();
        duplicateSelected(selectedId as string);
        return;
      }
      if ((e.key === 'Delete' || e.key === 'Backspace') && hasSel) {
        e.preventDefault();
        removeSelected(selectedId as string);
        return;
      }
      if (e.key === 'Escape' && hasSel) {
        e.preventDefault();
        selectParent(selectedId as string);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selectedId, doc.rootId, removeSelected, duplicateSelected, selectParent, undo, redo]);

  /** Canvas click: select and jump to its properties. */
  const selectNode = (id: string) => {
    setSelectedId(id);
    setEditingTextId(null);
    setExplorerTab('properties');
    reportSelection(id);
  };

  /** Layers click: select without leaving the tree. */
  const selectOnly = (id: string) => {
    setSelectedId(id);
    setEditingTextId(null);
    reportSelection(id);
  };

  /** “+” on a selected box or an empty placeholder: pick something to put inside it. */
  const openAddFor = (id: string) => {
    setSelectedId(id);
    setExplorerTab('add');
  };

  useEffect(() => {
    reportSelection(selectedId);
  }, [selectedId, reportSelection]);

  const remotePeerOnNode = useCallback(
    (id: string) => remotePeers.find((p) => p.selectedNodeId === id) ?? null,
    [remotePeers],
  );

  const onFramePointer = useCallback(
    (e: MouseEvent<HTMLDivElement>, frame: BreakpointId) => {
      if (canvasMode !== 'select') return;
      const el = e.currentTarget;
      const rect = el.getBoundingClientRect();
      const scaleX = rect.width / el.offsetWidth || 1;
      const scaleY = rect.height / el.offsetHeight || 1;
      const x = (e.clientX - rect.left) / scaleX;
      const y = (e.clientY - rect.top) / scaleY;
      reportCursor({ x, y, frame });
    },
    [canvasMode, reportCursor],
  );

  const clearFramePointer = useCallback(() => {
    reportCursor(null);
  }, [reportCursor]);

  // A drag that ends anywhere (even outside the window) must clear the indicator.
  useEffect(() => {
    const clear = () => setCanvasDrop(null);
    window.addEventListener('dragend', clear);
    window.addEventListener('drop', clear);
    return () => {
      window.removeEventListener('dragend', clear);
      window.removeEventListener('drop', clear);
    };
  }, []);

  /** Top / bottom edge of a box drops beside it, the middle drops inside; leaves split in half. */
  const dropPositionFor = (node: BeekiriCodeNode, isRoot: boolean, e: DragEvent<Element>): MovePosition => {
    if (isRoot) return 'inside';
    const r = e.currentTarget.getBoundingClientRect();
    const y = (e.clientY - r.top) / Math.max(r.height, 1);
    if (canAcceptChildren(node, false)) return y < 0.2 ? 'before' : y > 0.8 ? 'after' : 'inside';
    return y < 0.5 ? 'before' : 'after';
  };

  const dragHandlers = (id: string, node: BeekiriCodeNode, isRoot: boolean) =>
    canvasMode !== 'select'
      ? {}
      : {
          onDragOver: (e: DragEvent<Element>) => {
            if (!getPaletteDrag()) return;
            e.preventDefault();
            e.stopPropagation();
            e.dataTransfer.dropEffect = 'copy';
            const position = dropPositionFor(node, isRoot, e);
            setCanvasDrop((d) => (d && d.id === id && d.position === position ? d : { id, position }));
          },
          onDragLeave: (e: DragEvent<Element>) => {
            if (e.currentTarget.contains(e.relatedTarget as Node | null)) return;
            setCanvasDrop((d) => (d?.id === id ? null : d));
          },
          onDrop: (e: DragEvent<Element>) => {
            const raw = e.dataTransfer.getData(ELEMENT_MIME);
            const drag = (raw && decodePaletteDrag(raw)) || getPaletteDrag();
            setCanvasDrop(null);
            if (!drag) return;
            e.preventDefault();
            e.stopPropagation();
            dropPalette(drag, id, dropPositionFor(node, isRoot, e));
          },
        };

  const renderNode = (
    id: string,
    frame: 'desktop' | 'tablet' | 'mobile',
  ): ReactNode => {
    const node = doc.nodes[id];
    if (!node) return null;
    const interactive = canvasMode === 'select';
    const isRoot = id === doc.rootId;
    const hiddenHere = node.hiddenOn?.includes(frame) ?? false;
    if (hiddenHere && !(interactive && showHidden)) return null;
    const peerOn = remotePeerOnNode(id);
    const drop = canvasDrop?.id === id ? canvasDrop.position : null;
    const isBox = canAcceptChildren(node, isRoot);
    const cls = [
      'bk-beekiricode__node',
      selectedId === id ? 'is-selected' : '',
      peerOn ? 'is-peer-selected' : '',
      hoveredId === id ? 'is-hovered' : '',
      hiddenHere ? 'is-bp-hidden' : '',
      drop ? `is-drop-${drop}` : '',
      isBox && node.children.length === 0 ? 'is-empty' : '',
    ]
      .filter(Boolean)
      .join(' ');
    const onSelect = (e: MouseEvent) => {
      // Links on the canvas must never navigate the admin.
      if (e.currentTarget instanceof HTMLAnchorElement) e.preventDefault();
      if (!interactive) return;
      e.stopPropagation();
      selectNode(id);
    };
    const resolved = resolveStyleForBreakpoint(node, frame);
    const peerStyle = peerOn
      ? ({ ['--peer-select' as string]: peerOn.color } as CSSProperties)
      : undefined;
    const style = { ...(resolved as CSSProperties), ...peerStyle };
    const authorClasses = (node.cssClass || '')
      .split(/\s+/)
      .map((c) => c.replace(/[^\w-]/g, ''))
      .filter(Boolean);
    const authorId = node.cssId?.replace(/[^\w-]/g, '') || undefined;
    const common = {
      className: [cls, ...authorClasses].join(' '),
      style,
      // Duplicate ids across the multi-breakpoint frames would be invalid — single frame only.
      id: visibleFrames.length === 1 ? authorId : undefined,
      'data-node-id': id,
      'data-node-type': node.type,
      onClick: onSelect,
      onMouseEnter: (e: MouseEvent) => {
        if (!interactive) return;
        e.stopPropagation();
        setHoveredId(id);
      },
      onMouseLeave: () => setHoveredId(null),
      ...dragHandlers(id, node, isRoot),
    };
    const key = `${frame}-${id}`;
    const kids = () => node.children.map((cid) => renderNode(cid, frame));
    const meta = TYPE_META[node.type];

    const placeholder = (title: string, hint: string) => (
      <div className="bk-beekiricode__placeholder bk-beekiricode__placeholder--media">
        <meta.Icon size={20} weight="regular" aria-hidden />
        <span>{title}</span>
        {interactive ? <small>{hint}</small> : null}
      </div>
    );

    if (node.type === 'image') {
      return (
        <div key={key} {...common}>
          {node.src ? (
            <img src={node.src} alt={node.alt || ''} style={{ width: '100%', display: 'block' }} draggable={false} />
          ) : (
            placeholder('Image', 'Pick one from the media library in Props → Content')
          )}
        </div>
      );
    }

    if (node.type === 'video') {
      const src = (node.src || '').trim();
      const embed = src ? videoEmbedUrl(src) : null;
      return (
        <div key={key} {...common}>
          {!src ? (
            placeholder('Video', 'Paste a YouTube, Vimeo or MP4 link in Props → Content')
          ) : embed ? (
            <iframe
              className="bk-beekiricode__media"
              src={embed}
              title={node.alt || 'Video'}
              loading="lazy"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : (
            <video className="bk-beekiricode__media" src={src} controls={!interactive} playsInline preload="metadata" />
          )}
          {/* iframes swallow pointer events — keep the element selectable while editing. */}
          {src && interactive ? <span className="bk-beekiricode__media-shield" aria-hidden /> : null}
        </div>
      );
    }

    if (node.type === 'list') {
      const Tag = (node.tag === 'ol' ? 'ol' : 'ul') as 'ul';
      const items = (node.text || '')
        .split('\n')
        .map((l) => l.trim())
        .filter(Boolean);
      return (
        <Tag
          key={key}
          {...common}
          onDoubleClick={(e) => {
            if (!interactive) return;
            e.stopPropagation();
            selectNode(id);
          }}
        >
          {items.length ? items.map((l, i) => <li key={i}>{l}</li>) : <li className="bk-beekiricode__ghost">List item</li>}
        </Tag>
      );
    }

    if (node.type === 'divider') return <hr key={key} {...common} />;
    if (node.type === 'spacer') return <div key={key} {...common} />;
    if (node.type === 'shop_content') {
      return (
        <div key={key} {...common} className={`${common.className ?? ''} bk-beekiricode__shop-slot`.trim()}>
          <span className="bk-beekiricode__shop-slot-label">Shop content</span>
          <span className="bk-beekiricode__shop-slot-hint">The live products, cart or checkout is shown here on the website.</span>
        </div>
      );
    }

    if (node.type === 'layout') {
      const slug = node.layoutSlug || 'layout';
      const layoutCls = [
        hiddenHere ? 'is-bp-hidden' : '',
        peerOn ? 'is-peer-selected' : '',
        drop ? `is-drop-${drop}` : '',
      ]
        .filter(Boolean)
        .join(' ');
      return (
        <LayoutPhpPreview
          key={key}
          slug={slug}
          fields={node.layoutFields || {}}
          selected={selectedId === id}
          hovered={hoveredId === id}
          interactive={interactive}
          style={resolved as CSSProperties}
          hostStyle={peerStyle}
          className={layoutCls || undefined}
          nodeId={id}
          hostProps={dragHandlers(id, node, false)}
          onSelect={onSelect}
          onHover={(e) => {
            if (!interactive) return;
            e.stopPropagation();
            setHoveredId(id);
          }}
          onLeave={() => setHoveredId(null)}
        />
      );
    }

    if (node.type === 'heading' || node.type === 'text' || node.type === 'button') {
      const Tag = (node.tag ||
        (node.type === 'heading' ? 'h2' : node.type === 'button' ? 'a' : 'p')) as keyof JSX.IntrinsicElements;
      const href = node.type === 'button' ? node.href || '#' : undefined;
      if (interactive && editingTextId === id) {
        return (
          <EditableText
            key={key}
            tag={Tag}
            nodeId={id}
            nodeType={node.type}
            text={node.text || ''}
            className={cls}
            style={style}
            href={href}
            onCommit={(t) => {
              setEditingTextId(null);
              if (t !== (node.text || '')) updateNode(id, { text: t });
            }}
            onCancel={() => setEditingTextId(null)}
          />
        );
      }
      return (
        <Tag
          key={key}
          {...common}
          href={href}
          onDoubleClick={(e) => {
            if (!interactive) return;
            e.stopPropagation();
            setSelectedId(id);
            setEditingTextId(id);
          }}
        >
          {node.text}
          {kids()}
        </Tag>
      );
    }

    const Tag = (node.tag || 'div') as keyof JSX.IntrinsicElements;
    return (
      <Tag key={key} {...common}>
        {kids()}
        {interactive && node.children.length === 0 ? (
          <div
            className="bk-beekiricode__placeholder bk-beekiricode__placeholder--box"
            role="button"
            tabIndex={-1}
            onClick={(e) => {
              e.stopPropagation();
              openAddFor(id);
            }}
          >
            <Plus size={14} weight="bold" aria-hidden />
            <span>{isRoot ? 'Empty page' : `Empty ${meta.label.toLowerCase()}`}</span>
            <small>Click to add elements, or drag them in from Add</small>
          </div>
        ) : null}
      </Tag>
    );
  };

  const pathLabel =
    publicPath ||
    chrome.publicPath ||
    (slug ? `${/\/posts\/?$/.test(chrome.listPath) ? '/blog/' : '/'}${slug}` : '/');
  const liveHref =
    isPublished && pathLabel && permalinkBase
      ? `${permalinkBase.replace(/\/$/, '')}${pathLabel.startsWith('/') ? pathLabel : `/${pathLabel}`}`
      : null;
  const slugPrefix = pathLabel.replace(/[^/]+$/, '') || '/';
  const selectedNode = selectedId ? doc.nodes[selectedId] ?? null : null;
  const isPageRoot = Boolean(selectedId && selectedId === doc.rootId);
  const selectedLayoutDef =
    selectedNode?.type === 'layout' && selectedNode.layoutSlug
      ? themeLayouts.find((l) => l.slug === selectedNode.layoutSlug)
      : undefined;

  return (
    <div className="bk-beekiricode">
      {/* Theme layout CSS — same sheets as the public site */}
      {themeLayouts.map((layout) => (
        <link
          key={layout.slug}
          rel="stylesheet"
          href={apiUrl(layout.cssUrl)}
        />
      ))}
      {customCssText ? <style>{customCssText}</style> : null}
      {/* ── Top toolbar (BeekiriCode) ─────────────────────────────── */}
      <header className="bk-beekiricode__toolbar">
        <Link
          to={chrome.listPath}
          className="bk-beekiricode__back"
          title={`Back to ${chrome.pluralLabel}`}
          aria-label={`Back to ${chrome.pluralLabel}`}
        >
          <ArrowLeft size={16} weight="regular" aria-hidden />
          <span>Back</span>
        </Link>
        <div className="bk-beekiricode__context">
          <label className="bk-beekiricode__nav-hint" htmlFor="bk-beekiricode-page-title">
            <span className="bk-beekiricode__nav-label">
              Editing {chrome.singularLabel}
            </span>
            <input
              id="bk-beekiricode-page-title"
              className="bk-beekiricode__title-input"
              type="text"
              value={chrome.title}
              onChange={(e) => chrome.onTitleChange(e.target.value)}
              placeholder={`Add ${chrome.singularLabel} name`}
              maxLength={200}
              aria-label={`${chrome.singularLabel} name`}
            />
          </label>
          {chrome.slugEditing ? (
            <span className="bk-beekiricode__permalink is-editing">
              <span className="bk-beekiricode__permalink-prefix" aria-hidden>
                {slugPrefix}
              </span>
              <input
                className="bk-beekiricode__slug-input"
                type="text"
                value={chrome.slug}
                onChange={(e) => chrome.onSlugChange(e.target.value)}
                onBlur={() => chrome.commitSlug()}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    chrome.commitSlug();
                  }
                  if (e.key === 'Escape') {
                    e.preventDefault();
                    chrome.cancelSlug();
                  }
                }}
                aria-label={`${chrome.singularLabel} slug`}
                autoFocus
              />
            </span>
          ) : (
            <span className={`bk-beekiricode__permalink${!isPublished ? ' is-draft' : ''}`}>
              <button
                type="button"
                className="bk-beekiricode__permalink-edit"
                title="Edit slug"
                onClick={() => chrome.setSlugEditing(true)}
              >
                <span className="bk-beekiricode__permalink-path">{pathLabel}</span>
                {!isPublished ? (
                  <span className="bk-beekiricode__permalink-badge">Draft</span>
                ) : null}
              </button>
              {liveHref ? (
                <a
                  className="bk-beekiricode__permalink-open"
                  href={liveHref}
                  target={`beekiri-view-${pageId}`}
                  rel="noreferrer"
                  title={`Open live ${chrome.singularLabel}`}
                  aria-label={`Open live ${chrome.singularLabel}`}
                  onClick={(e) => {
                    e.preventDefault();
                    openOrReloadLiveView(liveHref, pageId);
                  }}
                >
                  <ArrowSquareOut size={14} weight="regular" aria-hidden />
                </a>
              ) : null}
            </span>
          )}
        </div>
        <div className="bk-beekiricode__toolbar-spacer" />

        <PeerAvatarStack />

        <div className="bk-beekiricode__zoom-group" role="group" aria-label="History">
          <button
            type="button"
            className="bk-beekiricode__icon-btn"
            title={`Undo (${MOD}Z)`}
            aria-label="Undo"
            disabled={!history.canUndo}
            onClick={undo}
          >
            <ArrowUUpLeft size={16} weight="regular" aria-hidden />
          </button>
          <button
            type="button"
            className="bk-beekiricode__icon-btn"
            title={`Redo (${MOD}⇧Z)`}
            aria-label="Redo"
            disabled={!history.canRedo}
            onClick={redo}
          >
            <ArrowUUpRight size={16} weight="regular" aria-hidden />
          </button>
        </div>

        <div className="bk-beekiricode__zoom-group" role="group" aria-label="Zoom">
          <button
            type="button"
            className="bk-beekiricode__icon-btn"
            title={`Zoom out (${MOD}−)`}
            disabled={scale <= ZOOM_MIN + 0.001}
            onClick={() => viewportApi.current?.zoomBy(1 / 1.2)}
          >
            <MagnifyingGlassMinus size={16} weight="regular" aria-hidden />
          </button>
          <button
            type="button"
            className="bk-beekiricode__zoom"
            title="Zoom to 100% (Shift+0)"
            onClick={() => viewportApi.current?.zoomTo(1)}
          >
            {zoom}%
          </button>
          <button
            type="button"
            className="bk-beekiricode__icon-btn"
            title={`Zoom in (${MOD}+)`}
            disabled={scale >= ZOOM_MAX - 0.001}
            onClick={() => viewportApi.current?.zoomBy(1.2)}
          >
            <MagnifyingGlassPlus size={16} weight="regular" aria-hidden />
          </button>
          <button
            type="button"
            className="bk-beekiricode__icon-btn"
            title={`Fit to screen (${MOD}0)`}
            onClick={() => viewportApi.current?.fit()}
          >
            <CornersOut size={16} weight="regular" aria-hidden />
          </button>
        </div>

        <span className={`bk-beekiricode__sync${syncOk ? ' is-ok' : ''}`}>
          <span className="bk-beekiricode__sync-dot" aria-hidden />
          {syncLabel}
        </span>

        <div className="bk-beekiricode__publish" ref={publishRef}>
          {isPublished && !isDirty && !isPublishing && viewHref ? (
            <a
              className="bk-beekiricode__publish-main bk-beekiricode__publish-main--view"
              href={viewHref}
              target={`beekiri-view-${pageId}`}
              rel="noreferrer"
              title={`View live ${chrome.singularLabel}`}
              onClick={(e) => {
                e.preventDefault();
                openOrReloadLiveView(viewHref, pageId);
              }}
            >
              <ArrowSquareOut size={16} weight="regular" aria-hidden />
              View {chrome.singularLabel}
            </a>
          ) : (
            <button
              type="button"
              className={`bk-beekiricode__publish-main${isPublishing ? ' is-loading' : ''}`}
              disabled={busy || !canPublish}
              onClick={onPublish}
              aria-busy={isPublishing}
            >
              {isPublishing ? (
                <CircleNotch size={16} weight="bold" className="bk-beekiricode__spin" aria-hidden />
              ) : (
                <CloudArrowUp size={16} weight="regular" aria-hidden />
              )}
              {isPublishing ? 'Publishing…' : 'Publish'}
            </button>
          )}
          <button
            type="button"
            className="bk-beekiricode__publish-caret"
            aria-label="Publish options"
            aria-expanded={publishOpen}
            disabled={busy}
            onClick={() => setPublishOpen((v) => !v)}
          >
            <CaretDown size={12} weight="regular" aria-hidden />
          </button>
          {publishOpen ? (
            <div className="bk-beekiricode__menu" role="menu">
              <button
                type="button"
                className="bk-beekiricode__menu-item"
                role="menuitem"
                onClick={() => {
                  setPublishOpen(false);
                  onSaveDraft();
                }}
              >
                Save draft
              </button>
              <button
                type="button"
                className="bk-beekiricode__menu-item"
                role="menuitem"
                disabled={!onPreview}
                onClick={() => {
                  setPublishOpen(false);
                  onPreview?.();
                }}
              >
                <Eye size={16} weight="regular" aria-hidden /> Preview page
              </button>
              <button
                type="button"
                className="bk-beekiricode__menu-item"
                role="menuitem"
                onClick={() => {
                  setPublishOpen(false);
                  onOpenSettings();
                }}
              >
                Version history…
              </button>
            </div>
          ) : null}
        </div>

        <button
          type="button"
          className="bk-beekiricode__icon-btn"
          title="Page settings"
          onClick={onOpenSettings}
        >
          <GearSix size={16} weight="regular" aria-hidden />
        </button>
      </header>

      <div className="bk-beekiricode__workspace">
        {/* ── Left Explorer ──────────────────────────────────────────── */}
        <aside className="bk-beekiricode__explorer" aria-label="Explorer">
          <div className="bk-beekiricode__explorer-head">
            <span>Explorer</span>
            <span className="bk-beekiricode__explorer-count">
              {Object.keys(doc.nodes).length - 1} element{Object.keys(doc.nodes).length === 2 ? '' : 's'}
            </span>
          </div>
          <div
            className="bk-beekiricode__tabs bk-beekiricode__tabs--5"
            role="tablist"
            aria-label="Explorer tabs"
          >
            {EXPLORER_TABS.map(({ id, label, title }) => (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={explorerTab === id}
                className={`bk-beekiricode__tab${explorerTab === id ? ' is-active' : ''}`}
                title={title}
                onClick={() => setExplorerTab(id)}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="bk-beekiricode__explorer-body">
            {explorerTab === 'layers' ? (
              <div className="bk-beekiricode__layers">
                <label className="bk-beekiricode__search">
                  <MagnifyingGlass size={13} aria-hidden />
                  <input
                    type="search"
                    value={layerQuery}
                    placeholder="Search layers…"
                    aria-label="Search layers"
                    onChange={(e) => setLayerQuery(e.target.value)}
                  />
                  {layerQuery ? (
                    <button type="button" aria-label="Clear search" onClick={() => setLayerQuery('')}>
                      <X size={11} weight="bold" />
                    </button>
                  ) : null}
                </label>
                <LayersTree
                  doc={doc}
                  selectedId={selectedId}
                  hoveredId={hoveredId}
                  query={layerQuery}
                  onSelect={selectOnly}
                  onOpenProps={selectNode}
                  onHover={setHoveredId}
                  onRemove={removeSelected}
                  onMove={moveLayer}
                  onRename={renameNode}
                  onDropPalette={dropPalette}
                />
                <div className="bk-beekiricode__layers-foot">
                  <button
                    type="button"
                    className="bk-beekiricode__layers-add"
                    onClick={() => setExplorerTab('add')}
                  >
                    <Plus size={12} weight="bold" aria-hidden />
                    Add element
                  </button>
                  <span className="bk-beekiricode__layers-hint">
                    Double-click renames · {MOD}D duplicates · ⌫ deletes
                  </span>
                </div>
              </div>
            ) : null}

            {explorerTab === 'properties' ? (
              <div className="bk-beekiricode__props-tab">
                <PropertiesPanel
                  variant="embedded"
                  doc={doc}
                  node={selectedNode}
                  isPageRoot={isPageRoot}
                  editTarget={styleEditTarget}
                  layoutFieldDefs={selectedLayoutDef?.fields}
                  documentColors={documentColors}
                  showHidden={showHidden}
                  onShowHiddenChange={setShowHidden}
                  onSelectNode={(id) => setSelectedId(id)}
                  onSelectPage={() => {
                    setSelectedId(doc.rootId);
                    setExplorerTab('properties');
                  }}
                  onRename={(label) => selectedId && renameNode(selectedId, label)}
                  onDuplicate={() => selectedId && duplicateSelected(selectedId)}
                  onDelete={() => selectedId && removeSelected(selectedId)}
                  onAddInside={() => selectedId && openAddFor(selectedId)}
                  onSpacingFocus={setSpacingFocus}
                  parentNode={selectedId ? (() => {
                    const pid = findParentId(doc, selectedId);
                    return pid ? doc.nodes[pid] ?? null : null;
                  })() : null}
                  onUpdate={(patch) => {
                    if (!selectedId) return;
                    updateNode(selectedId, patch);
                  }}
                />
              </div>
            ) : null}

            {explorerTab === 'add' ? (
              <AddPanel
                shopPage={apiBase.includes('/shop_page')}
                layouts={themeLayouts}
                layoutsStatus={layoutsStatus}
                onReloadLayouts={reloadLayouts}
                insertHint={`${insertAnchor.position === 'inside' ? 'inside' : 'after'} “${insertAnchor.label}”`}
                onAddElement={addElement}
                onAddLayout={addThemeLayout}
              />
            ) : null}

            {explorerTab === 'page-settings' ? (
              <PageSettingsPanel pageId={pageId} apiBase={apiBase} />
            ) : null}

            {explorerTab === 'seo' ? (
              <SeoPanel
                seo={chrome.seo}
                onChange={chrome.setSeo}
                title={chrome.title}
                slug={chrome.slug}
                excerpt={chrome.excerpt}
                urlPrefix={`${permalinkBase.replace(/\/$/, '')}${slugPrefix}`}
                featuredImageId={chrome.featuredImageId}
                doc={doc}
                isPublished={isPublished}
                onOpenSettings={onOpenSettings}
              />
            ) : null}
          </div>
        </aside>

        {/* ── Canvas stage ───────────────────────────────────────────── */}
        <div className="bk-beekiricode__stage">
          <div className="bk-beekiricode__canvas-tools">
            <div className="bk-beekiricode__mode-pill" role="group" aria-label="Canvas mode">
              <button
                type="button"
                className={`bk-beekiricode__mode-btn${canvasMode === 'select' ? ' is-active' : ''}`}
                aria-pressed={canvasMode === 'select'}
                title="Select"
                onClick={() => {
                  setCanvasMode('select');
                }}
              >
                <Cursor size={16} weight="regular" aria-hidden />
              </button>
              <button
                type="button"
                className={`bk-beekiricode__mode-btn${canvasMode === 'preview' ? ' is-active' : ''}`}
                aria-pressed={canvasMode === 'preview'}
                title="Preview — single frame at 95%. Click again to re-center."
                onClick={() => {
                  if (viewMode === 'multi') setViewMode('desktop');
                  if (canvasMode === 'preview') {
                    // Already previewing: glide back to the preview position.
                    viewportApi.current?.fit(true);
                  } else {
                    setCanvasMode('preview');
                  }
                }}
              >
                <Eye size={16} weight="regular" aria-hidden />
              </button>
            </div>

            <div className="bk-beekiricode__viewport" ref={viewportRef}>
              <button
                type="button"
                className="bk-beekiricode__viewport-btn"
                aria-expanded={viewportOpen}
                onClick={() => setViewportOpen((v) => !v)}
              >
                <activeBreakpoint.Icon size={16} weight="regular" aria-hidden />
                {activeBreakpoint.label}
                <CaretDown size={12} weight="regular" aria-hidden />
              </button>
              <button
                type="button"
                className={`bk-beekiricode__viewport-multi${
                  viewMode === 'multi' && canvasMode !== 'preview' ? ' is-active' : ''
                }`}
                title="Show all breakpoints"
                aria-pressed={viewMode === 'multi' && canvasMode !== 'preview'}
                onClick={() => {
                  setCanvasMode('select');
                  setViewMode((m) => (m === 'multi' ? 'desktop' : 'multi'));
                }}
              >
                <SquaresFour size={16} weight="regular" aria-hidden />
              </button>
              {viewportOpen ? (
                <div className="bk-beekiricode__menu bk-beekiricode__menu--viewport" role="menu">
                  {BREAKPOINTS.map((bp) => (
                    <button
                      key={bp.id}
                      type="button"
                      role="menuitem"
                      className={`bk-beekiricode__menu-item${
                        effectiveViewMode === bp.id ? ' is-active' : ''
                      }`}
                      onClick={() => {
                        setViewMode(bp.id);
                        setCanvasMode('select');
                              setViewportOpen(false);
                      }}
                    >
                      <bp.Icon size={16} weight="regular" aria-hidden />
                      <span>{bp.label}</span>
                      <span className="bk-beekiricode__menu-meta">{bp.width}px</span>
                    </button>
                  ))}
                  <div className="bk-beekiricode__menu-sep" />
                  <button
                    type="button"
                    role="menuitem"
                    className={`bk-beekiricode__menu-item${
                      viewMode === 'multi' && canvasMode !== 'preview' ? ' is-active' : ''
                    }`}
                    onClick={() => {
                      setViewMode('multi');
                      setCanvasMode('select');
                          setViewportOpen(false);
                    }}
                  >
                    <SquaresFour size={16} weight="regular" aria-hidden />
                    All breakpoints
                  </button>
                </div>
              ) : null}
            </div>
          </div>

          <CanvasViewport
            ref={viewportApi}
            designWidth={designWidth}
            fitKey={`${effectiveViewMode}:${canvasMode}`}
            fitScale={canvasMode === 'preview' ? 0.95 : undefined}
            onScaleChange={setScale}
          >
            <div className="bk-beekiricode__frames" style={{ gap: FRAME_GAP }}>
              {visibleFrames.map((bp) => (
                <div key={bp.id} className="bk-beekiricode__frame" style={{ width: bp.width }}>
                  <div
                    className="bk-beekiricode__frame-label"
                    style={{ transform: `scale(${1 / scale})` }}
                  >
                    <bp.Icon size={12} weight="bold" aria-hidden />
                    {bp.label} · {bp.width}
                    {styleEditTarget === bp.id ? ` · editing ${bp.label.toLowerCase()} overrides` : null}
                    {styleEditTarget === 'base' && viewMode !== 'multi' ? ' · editing default styles' : null}
                  </div>
                  <div
                    className={`bk-beekiricode__frame-canvas${canvasMode === 'preview' ? ' is-preview' : ''}`}
                    style={{ width: bp.width, minHeight: 900 }}
                    onClick={() => {
                      if (canvasMode === 'select') selectNode(doc.rootId);
                    }}
                    onMouseMove={(e) => onFramePointer(e, bp.id)}
                    onMouseLeave={clearFramePointer}
                  >
                    {renderNode(doc.rootId, bp.id)}
                    {canvasMode === 'select' ? (
                      <>
                        <RemoteCursors frame={bp.id} />
                        <SelectionChrome
                          doc={doc}
                          selectedId={selectedId}
                          hoveredId={hoveredId}
                          scale={scale}
                          spacingFocus={spacingFocus}
                          onSelectParent={(pid) => setSelectedId(pid)}
                          onMove={shiftSelected}
                          onDuplicate={duplicateSelected}
                          onDelete={removeSelected}
                          onAddInside={openAddFor}
                        />
                      </>
                    ) : null}
                  </div>
                </div>
              ))}
            </div>
          </CanvasViewport>
        </div>
      </div>
    </div>
  );
}
