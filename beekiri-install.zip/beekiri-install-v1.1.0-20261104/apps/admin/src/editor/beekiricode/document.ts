import { initialRow, type BackendField } from '../../fields/acf-types';
/** BeekiriCode page tree stored on Beekiri pages (`content.beekiricode`). */

import type { BreakpointStyleBags } from './responsiveStyles';

export type BeekiriCodeNodeType =
  | 'section'
  | 'container'
  | 'heading'
  | 'text'
  | 'image'
  | 'button'
  | 'video'
  | 'list'
  | 'divider'
  | 'spacer'
  | 'layout'
  /** Shopping: where the live shop content (products, cart, checkout…) goes on a shop page. */
  | 'shop_content';

export type BeekiriCodeNode = {
  id: string;
  type: BeekiriCodeNodeType;
  /** Custom name shown in Layers / Props (editor only — never published). */
  label?: string;
  tag?: string;
  /** Lists keep one item per line. */
  text?: string;
  /** Image URL, or a YouTube / Vimeo / .mp4 URL for videos. */
  src?: string;
  /** Image alt text, or the video title. */
  alt?: string;
  href?: string;
  /** Buttons: open the link in a new tab. */
  newTab?: boolean;
  /** Theme layout slug from Backend Fields / layouts/{slug}/ */
  layoutSlug?: string;
  layoutTitle?: string;
  /** Field values for layout modules */
  /** Raw field values (strings, ids, rows, link objects) keyed by field name. */
  layoutFields?: Record<string, unknown>;
  /** Advanced: published as the element's id / extra classes / extra declarations. */
  cssId?: string;
  cssClass?: string;
  customCss?: string;
  /** Default styles — apply on desktop and as the base for all breakpoints. */
  style?: Record<string, string>;
  /** Styles applied while the pointer is over the element (every device). */
  hoverStyle?: Record<string, string>;
  /** Optional overrides — only tablet / mobile. */
  stylesByBreakpoint?: BreakpointStyleBags;
  /** Breakpoints where this node is display:none on the live site. */
  hiddenOn?: HiddenBreakpoint[];
  children: string[];
};

export type HiddenBreakpoint = 'desktop' | 'tablet' | 'mobile';

/** Theme layout from GET /api/layouts (Backend Fields → layouts/{slug}/). */
export type ThemeLayout = {
  slug: string;
  title: string;
  key: string;
  fields: BackendField[];
  cssUrl: string;
  jsUrl?: string;
};

/** Leftover scaffold keys from early layout nodes — strip so editor matches live PHP. */
const LAYOUT_CHROME_STYLE_KEYS = [
  'display',
  'flexDirection',
  'flexWrap',
  'alignItems',
  'justifyContent',
  'gap',
  'rowGap',
  'columnGap',
  'padding',
  'paddingTop',
  'paddingRight',
  'paddingBottom',
  'paddingLeft',
  'border',
  'borderWidth',
  'borderStyle',
  'borderColor',
  'borderRadius',
  'minHeight',
] as const;

/** Insert a synced theme layout (from GET /api/layouts) onto the canvas. */
export function createLayoutNode(layout: {
  slug: string;
  title: string;
  fields?: BackendField[];
}): BeekiriCodeNode {
  const fields = initialRow(layout.fields ?? []);
  return {
    id: createId('lay'),
    type: 'layout',
    tag: 'section',
    layoutSlug: layout.slug,
    layoutTitle: layout.title,
    layoutFields: fields,
    text: layout.title,
    // Theme PHP + SCSS own the box — no editor scaffold padding.
    style: {},
    children: [],
  };
}

/** The early placeholder look: dashed border and/or #fafafa fill. */
export function hasLayoutScaffoldStyle(style: Record<string, string> | undefined): boolean {
  if (!style) return false;
  const norm = (v: string | undefined) => (v ?? '').replace(/\s/g, '').toLowerCase();
  return (
    norm(style.border).includes('dashed') ||
    norm(style.borderStyle) === 'dashed' ||
    norm(style.background) === '#fafafa' ||
    norm(style.backgroundColor) === '#fafafa'
  );
}

/** Remove old dashed-box scaffold styles from layout nodes (mutates a clone). */
export function stripLayoutChromeStyles(doc: BeekiriCodePageDoc): BeekiriCodePageDoc {
  const next = cloneDoc(doc);
  let changed = false;
  for (const node of Object.values(next.nodes)) {
    // Only legacy scaffold bags — real Props edits (padding, border…) must survive.
    if (node.type !== 'layout' || !hasLayoutScaffoldStyle(node.style)) continue;
    const style = { ...node.style };
    for (const k of LAYOUT_CHROME_STYLE_KEYS) {
      if (k in style) {
        delete style[k];
        changed = true;
      }
    }
    if (
      style.background?.replace(/\s/g, '').toLowerCase() === '#fafafa' ||
      style.backgroundColor?.replace(/\s/g, '').toLowerCase() === '#fafafa'
    ) {
      delete style.background;
      delete style.backgroundColor;
      changed = true;
    }
    node.style = style;
  }
  return changed ? next : doc;
}

export type BeekiriCodePageDoc = {
  version: 1;
  rootId: string;
  nodes: Record<string, BeekiriCodeNode>;
};

export function createId(prefix = 'n'): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

export function emptyBeekiriCodeDoc(): BeekiriCodePageDoc {
  const rootId = createId('root');
  const heroId = createId('sec');
  const headingId = createId('h');
  const textId = createId('t');
  return {
    version: 1,
    rootId,
    nodes: {
      [rootId]: {
        id: rootId,
        type: 'section',
        // Theme already wraps pages in <main> — keep the tree as a plain div.
        tag: 'div',
        style: {
          minHeight: '100%',
          padding: '48px 24px',
          display: 'flex',
          flexDirection: 'column',
          gap: '24px',
          background: '#ffffff',
          color: '#111111',
        },
        children: [heroId],
      },
      [heroId]: {
        id: heroId,
        type: 'section',
        tag: 'section',
        style: {
          display: 'flex',
          flexDirection: 'column',
          gap: '12px',
          maxWidth: '720px',
        },
        children: [headingId, textId],
      },
      [headingId]: {
        id: headingId,
        type: 'heading',
        tag: 'h1',
        text: 'New section',
        style: {
          margin: '0',
          fontSize: '40px',
          fontWeight: '650',
          lineHeight: '1.15',
        },
        children: [],
      },
      [textId]: {
        id: textId,
        type: 'text',
        tag: 'p',
        text: 'Double-click text to edit. Use Add to drop modules onto the canvas.',
        style: {
          margin: '0',
          fontSize: '16px',
          lineHeight: '1.55',
          color: '#444444',
        },
        children: [],
      },
    },
  };
}

export function parseBeekiriCodeDoc(raw: unknown): BeekiriCodePageDoc {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return emptyBeekiriCodeDoc();
  const o = raw as Record<string, unknown>;
  if (o.version !== 1 || typeof o.rootId !== 'string' || !o.nodes || typeof o.nodes !== 'object') {
    return emptyBeekiriCodeDoc();
  }
  const nodes = o.nodes as Record<string, BeekiriCodeNode>;
  if (!nodes[o.rootId]) return emptyBeekiriCodeDoc();
  return { version: 1, rootId: o.rootId, nodes };
}

export function isBeekiriCodeDoc(raw: unknown): raw is BeekiriCodePageDoc {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return false;
  const o = raw as Record<string, unknown>;
  return o.version === 1 && typeof o.rootId === 'string' && !!o.nodes && typeof o.nodes === 'object';
}

export type ModuleDef = {
  type: BeekiriCodeNodeType;
  label: string;
  create: () => BeekiriCodeNode;
};

export const MODULES: ModuleDef[] = [
  {
    type: 'section',
    label: 'Section',
    create: () => ({
      id: createId('sec'),
      type: 'section',
      tag: 'section',
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: '16px',
        padding: '32px 24px',
      },
      children: [],
    }),
  },
  {
    type: 'container',
    label: 'Container',
    create: () => ({
      id: createId('box'),
      type: 'container',
      tag: 'div',
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: '12px',
        padding: '16px',
      },
      children: [],
    }),
  },
  {
    type: 'heading',
    label: 'Heading',
    create: () => ({
      id: createId('h'),
      type: 'heading',
      tag: 'h2',
      text: 'Heading',
      style: { margin: '0', fontSize: '28px', fontWeight: '650', lineHeight: '1.2' },
      children: [],
    }),
  },
  {
    type: 'text',
    label: 'Text',
    create: () => ({
      id: createId('t'),
      type: 'text',
      tag: 'p',
      text: 'Paragraph text',
      style: { margin: '0', fontSize: '16px', lineHeight: '1.55' },
      children: [],
    }),
  },
  {
    type: 'image',
    label: 'Image',
    create: () => ({
      id: createId('img'),
      type: 'image',
      tag: 'img',
      src: '',
      alt: '',
      style: { display: 'block', width: '100%', maxWidth: '640px', height: 'auto' },
      children: [],
    }),
  },
  {
    type: 'button',
    label: 'Button',
    create: () => ({
      id: createId('btn'),
      type: 'button',
      tag: 'a',
      text: 'Button',
      href: '#',
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '10px 18px',
        background: '#111111',
        color: '#ffffff',
        textDecoration: 'none',
        borderRadius: '6px',
        fontWeight: '600',
        fontSize: '14px',
        width: 'fit-content',
      },
      children: [],
    }),
  },
  {
    type: 'list',
    label: 'List',
    create: () => ({
      id: createId('list'),
      type: 'list',
      tag: 'ul',
      text: 'First item\nSecond item\nThird item',
      style: { margin: '0', paddingLeft: '22px', fontSize: '16px', lineHeight: '1.7' },
      children: [],
    }),
  },
  {
    type: 'video',
    label: 'Video',
    create: () => ({
      id: createId('vid'),
      type: 'video',
      tag: 'div',
      src: '',
      alt: '',
      style: { width: '100%', aspectRatio: '16 / 9' },
      children: [],
    }),
  },
  {
    type: 'divider',
    label: 'Divider',
    create: () => ({
      id: createId('hr'),
      type: 'divider',
      tag: 'hr',
      style: {
        width: '100%',
        borderTopWidth: '1px',
        borderTopStyle: 'solid',
        borderTopColor: '#E4E4E7',
      },
      children: [],
    }),
  },
  {
    type: 'spacer',
    label: 'Spacer',
    create: () => ({
      id: createId('sp'),
      type: 'spacer',
      tag: 'div',
      style: { height: '48px' },
      children: [],
    }),
  },
  {
    type: 'shop_content',
    label: 'Shop content',
    create: () => ({
      id: createId('shop'),
      type: 'shop_content',
      tag: 'div',
      style: {},
      children: [],
    }),
  },
];

/** Fresh node with the default content and styles for `type`. */
export function createNodeOfType(type: BeekiriCodeNodeType): BeekiriCodeNode {
  const def = MODULES.find((m) => m.type === type) ?? MODULES[0];
  return def.create();
}

/** A detached subtree ready to insert into a doc. */
export type NodeTree = { rootId: string; nodes: Record<string, BeekiriCodeNode> };

/** Everything the Add panel can drop onto the page (presets may create several nodes). */
export type ElementKey =
  | 'section'
  | 'container'
  | 'columns-2'
  | 'columns-3'
  | 'spacer'
  | 'divider'
  | 'heading'
  | 'text'
  | 'button'
  | 'list'
  | 'image'
  | 'video'
  | 'shop_content';

/** Equal-width grid that stacks to one column on mobile. */
function createColumns(count: number): NodeTree {
  const cols: BeekiriCodeNode[] = Array.from({ length: count }, () => ({
    id: createId('col'),
    type: 'container',
    tag: 'div',
    label: 'Column',
    style: { display: 'flex', flexDirection: 'column', gap: '12px', minWidth: '0' },
    children: [],
  }));
  const row: BeekiriCodeNode = {
    id: createId('row'),
    type: 'container',
    tag: 'div',
    label: 'Columns',
    style: {
      display: 'grid',
      gridTemplateColumns: `repeat(${count}, minmax(0, 1fr))`,
      gap: '24px',
      width: '100%',
    },
    stylesByBreakpoint: { mobile: { gridTemplateColumns: 'minmax(0, 1fr)' } },
    children: cols.map((c) => c.id),
  };
  return { rootId: row.id, nodes: Object.fromEntries([row, ...cols].map((n) => [n.id, n])) };
}

export function createElement(key: ElementKey): NodeTree {
  if (key === 'columns-2') return createColumns(2);
  if (key === 'columns-3') return createColumns(3);
  const node = createNodeOfType(key);
  return { rootId: node.id, nodes: { [node.id]: node } };
}

const TEXT_TYPES: BeekiriCodeNodeType[] = ['heading', 'text', 'button', 'list'];
const BOX_TYPES: BeekiriCodeNodeType[] = ['section', 'container'];

/** Types a node can switch to without losing its content. */
export function convertibleTypes(type: BeekiriCodeNodeType): BeekiriCodeNodeType[] {
  if (TEXT_TYPES.includes(type)) return TEXT_TYPES;
  if (BOX_TYPES.includes(type)) return BOX_TYPES;
  return [type];
}

/** Patch that turns `node` into `to`, keeping its text, link and styles. */
export function convertNode(node: BeekiriCodeNode, to: BeekiriCodeNodeType): Partial<BeekiriCodeNode> {
  const def = createNodeOfType(to);
  return {
    type: to,
    tag: def.tag,
    text: node.text ?? def.text,
    href: to === 'button' ? node.href || def.href : node.href,
  };
}

export { renderBeekiriCodeHtml } from '@beekiri/page-blocks';

function cloneDoc(doc: BeekiriCodePageDoc): BeekiriCodePageDoc {
  return JSON.parse(JSON.stringify(doc)) as BeekiriCodePageDoc;
}

export function findParentId(doc: BeekiriCodePageDoc, nodeId: string): string | null {
  for (const [id, node] of Object.entries(doc.nodes)) {
    if (node.children.includes(nodeId)) return id;
  }
  return null;
}

function collectDescendants(doc: BeekiriCodePageDoc, id: string, out: Set<string>) {
  const node = doc.nodes[id];
  if (!node) return;
  for (const child of node.children) {
    out.add(child);
    collectDescendants(doc, child, out);
  }
}

/** Remove a node and its descendants. Root cannot be removed. */
export function removeNode(doc: BeekiriCodePageDoc, nodeId: string): BeekiriCodePageDoc | null {
  if (nodeId === doc.rootId) return null;
  const parentId = findParentId(doc, nodeId);
  if (!parentId || !doc.nodes[parentId]) return null;

  const next = cloneDoc(doc);
  const parent = next.nodes[parentId];
  parent.children = parent.children.filter((id) => id !== nodeId);

  const doomed = new Set<string>([nodeId]);
  collectDescendants(next, nodeId, doomed);
  for (const id of doomed) delete next.nodes[id];
  return next;
}

/**
 * Drop layout modules whose theme slug is gone (trashed / deleted Backend Fields).
 * Call only after GET /api/layouts succeeded so an empty catalog is trusted.
 */
export function pruneMissingLayouts(
  doc: BeekiriCodePageDoc,
  availableSlugs: Iterable<string>,
): BeekiriCodePageDoc {
  const ok = new Set(
    [...availableSlugs].map((s) => s.trim()).filter(Boolean),
  );
  const missing = Object.values(doc.nodes).filter(
    (n) => n.type === 'layout' && n.layoutSlug && !ok.has(n.layoutSlug),
  );
  if (!missing.length) return doc;
  let next = doc;
  for (const node of missing) {
    const removed = removeNode(next, node.id);
    if (removed) next = removed;
  }
  return next;
}

export type MovePosition = 'before' | 'after' | 'inside';

/**
 * Move `dragId` relative to `targetId`.
 * - before/after: sibling of target
 * - inside: append as last child of target (section/container/root only)
 */
export function moveNode(
  doc: BeekiriCodePageDoc,
  dragId: string,
  targetId: string,
  position: MovePosition,
): BeekiriCodePageDoc | null {
  if (dragId === targetId) return null;
  if (dragId === doc.rootId) return null;

  const descendants = new Set<string>();
  collectDescendants(doc, dragId, descendants);
  if (descendants.has(targetId)) return null;

  const fromParentId = findParentId(doc, dragId);
  if (!fromParentId) return null;

  const next = cloneDoc(doc);
  const fromParent = next.nodes[fromParentId];
  if (!fromParent) return null;
  fromParent.children = fromParent.children.filter((id) => id !== dragId);

  if (position === 'inside') {
    const target = next.nodes[targetId];
    if (!target) return null;
    if (
      target.type !== 'section' &&
      target.type !== 'container' &&
      targetId !== next.rootId
    ) {
      return null;
    }
    target.children = [...target.children, dragId];
    return next;
  }

  const toParentId = findParentId(next, targetId);
  if (!toParentId) return null;
  const toParent = next.nodes[toParentId];
  if (!toParent) return null;
  const idx = toParent.children.indexOf(targetId);
  if (idx < 0) return null;
  const insertAt = position === 'before' ? idx : idx + 1;
  toParent.children = [
    ...toParent.children.slice(0, insertAt),
    dragId,
    ...toParent.children.slice(insertAt),
  ];
  return next;
}

export function canAcceptChildren(node: BeekiriCodeNode | undefined, isRoot: boolean): boolean {
  if (!node) return false;
  return isRoot || node.type === 'section' || node.type === 'container';
}

/**
 * Insert a detached subtree relative to `targetId`.
 * - inside: append to target (must accept children)
 * - before/after: sibling of target
 */
export function insertTree(
  doc: BeekiriCodePageDoc,
  tree: NodeTree,
  targetId: string,
  position: MovePosition,
): BeekiriCodePageDoc | null {
  if (!doc.nodes[targetId]) return null;
  const next = cloneDoc(doc);
  for (const [id, node] of Object.entries(tree.nodes)) next.nodes[id] = node;

  if (position === 'inside') {
    const target = next.nodes[targetId];
    if (!canAcceptChildren(target, targetId === next.rootId)) return null;
    target.children = [...target.children, tree.rootId];
    return next;
  }
  const parentId = findParentId(next, targetId);
  if (!parentId) return null;
  const parent = next.nodes[parentId];
  const idx = parent.children.indexOf(targetId);
  if (idx < 0) return null;
  const at = position === 'before' ? idx : idx + 1;
  parent.children = [...parent.children.slice(0, at), tree.rootId, ...parent.children.slice(at)];
  return next;
}

/** Deep copy of a node (new ids throughout), placed right after the original. */
export function duplicateNode(doc: BeekiriCodePageDoc, nodeId: string): BeekiriCodePageDoc | null {
  if (nodeId === doc.rootId || !doc.nodes[nodeId]) return null;
  const nodes: Record<string, BeekiriCodeNode> = {};
  const copy = (id: string): string => {
    const src = doc.nodes[id];
    const prefix = id.replace(/_[^_]*$/, '') || 'n';
    const nid = createId(prefix);
    nodes[nid] = { ...JSON.parse(JSON.stringify(src)), id: nid, children: src.children.map(copy) };
    return nid;
  };
  const rootId = copy(nodeId);
  return insertTree(doc, { rootId, nodes }, nodeId, 'after');
}

/** Move a node one step up/down among its siblings. */
export function shiftNode(doc: BeekiriCodePageDoc, nodeId: string, delta: -1 | 1): BeekiriCodePageDoc | null {
  const parentId = findParentId(doc, nodeId);
  if (!parentId) return null;
  const siblings = doc.nodes[parentId].children;
  const idx = siblings.indexOf(nodeId);
  const to = idx + delta;
  if (idx < 0 || to < 0 || to >= siblings.length) return null;
  return moveNode(doc, nodeId, siblings[to], delta < 0 ? 'before' : 'after');
}
