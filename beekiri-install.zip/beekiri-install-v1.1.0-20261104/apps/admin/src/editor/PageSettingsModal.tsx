import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowCounterClockwise,
  ArrowSquareOut,
  CaretLeft,
  CaretRight,
  Check,
  ClockCounterClockwise,
  CopySimple,
  GearSix,
  Image as ImageIcon,
  MagnifyingGlass,
  Trash,
  X,
} from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { confirmDialog } from '../components/ConfirmDialog';
import type { PageRevisionRow, PageRow } from '../screens/PagesPage';
import { usePageEditorChrome } from './PageEditorChrome';
import { MediaPicker, useMediaItem, type MediaItem } from './beekiricode/inspector/MediaPicker';
import { formatRelative, textFromBeekiriCode, wordStats } from './pageStats';
import './beekiricanva.css';

function formatDate(iso: string | null) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString(undefined, {
      dateStyle: 'medium',
      timeStyle: 'short',
    });
  } catch {
    return iso;
  }
}

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

function initials(name: string | null | undefined) {
  const parts = (name || '?').trim().split(/\s+/).filter(Boolean);
  return ((parts[0]?.[0] ?? '?') + (parts[1]?.[0] ?? '')).toUpperCase();
}

const REVISIONS_PER_PAGE = 6;
const EXCERPT_MAX = 2000;
/** Search engines cut descriptions around here. */
const SNIPPET_CHARS = 160;

type Tab = 'general' | 'revisions';

/** Page settings: details, URL, status, featured image, excerpt and revision history. */
export function PageSettingsModal() {
  const chrome = usePageEditorChrome();
  const { settingsOpen, closeSettings } = chrome;

  const [tab, setTab] = useState<Tab>('general');
  const [revisions, setRevisions] = useState<PageRevisionRow[]>([]);
  const [revisionsLoading, setRevisionsLoading] = useState(false);
  const [revisionsError, setRevisionsError] = useState<string | null>(null);
  const [restoringId, setRestoringId] = useState<string | null>(null);
  const [revisionPage, setRevisionPage] = useState(0);
  const [featuredPickerOpen, setFeaturedPickerOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const featured = useMediaItem(chrome.featuredImageId ?? '');
  const titleRef = useRef<HTMLInputElement>(null);

  const stats = useMemo(
    () => wordStats(textFromBeekiriCode(chrome.beekiricodeData)),
    [chrome.beekiricodeData],
  );

  const loadRevisions = useCallback(async () => {
    if (!chrome.pageId) return;
    setRevisionsLoading(true);
    setRevisionsError(null);
    try {
      const res = await api<{ revisions: PageRevisionRow[] }>(
        `${chrome.apiBase}/${chrome.pageId}/revisions`,
      );
      setRevisions(res.revisions);
      setRevisionPage(0);
    } catch (e) {
      setRevisionsError(formatError(e));
      setRevisions([]);
      setRevisionPage(0);
    } finally {
      setRevisionsLoading(false);
    }
  }, [chrome.pageId, chrome.apiBase]);

  useEffect(() => {
    if (!settingsOpen) return;
    setTab('general');
    void loadRevisions();
    // Focus the title so the modal is keyboard-ready.
    requestAnimationFrame(() => titleRef.current?.focus());
  }, [settingsOpen, loadRevisions]);

  useEffect(() => {
    if (!settingsOpen) return;
    const onKey = (e: KeyboardEvent) => {
      // The media picker handles its own Escape.
      if (e.key !== 'Escape' || featuredPickerOpen) return;
      closeSettings();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [settingsOpen, closeSettings, featuredPickerOpen]);

  const revisionPageCount = Math.max(1, Math.ceil(revisions.length / REVISIONS_PER_PAGE));
  const safeRevisionPage = Math.min(revisionPage, revisionPageCount - 1);
  const revisionSlice = useMemo(() => {
    const start = safeRevisionPage * REVISIONS_PER_PAGE;
    return revisions.slice(start, start + REVISIONS_PER_PAGE);
  }, [revisions, safeRevisionPage]);

  const onRestore = async (revisionId: string) => {
    if (!chrome.pageId || chrome.busy || restoringId) return;
    const ok = await confirmDialog({
      title: 'Restore revision',
      message: 'Restore this revision? Your current version will be saved as a revision first.',
      confirmLabel: 'Restore',
    });
    if (!ok) return;
    setRestoringId(revisionId);
    setRevisionsError(null);
    try {
      const page = await api<PageRow>(
        `${chrome.apiBase}/${chrome.pageId}/revisions/${revisionId}/restore`,
        { method: 'POST' },
      );
      chrome.applyRestoredPage(page);
      await loadRevisions();
      closeSettings();
    } catch (e) {
      setRevisionsError(formatError(e));
    } finally {
      setRestoringId(null);
    }
  };

  if (!settingsOpen) return null;

  const label = chrome.singularLabel;
  const isLive = chrome.pageStatus === 'publish';
  const visibility = chrome.visibility === 'auto-draft' ? 'draft' : chrome.visibility;
  const statusChanged = (visibility === 'publish') !== isLive;
  const editedBy = chrome.updatedByName || chrome.authorName;
  const revisionCount = Math.max(chrome.revisionCount, revisions.length);
  const urlPrefix = `${chrome.permalinkBase.replace(/\/$/, '')}${
    chrome.publicPath.replace(/[^/]+$/, '') || '/'
  }`;
  const fullUrl = `${urlPrefix}${chrome.slug}`;
  const displayHost = urlPrefix.replace(/^https?:\/\//, '');
  const snippet =
    chrome.excerpt.trim() ||
    'Add an excerpt to control the description shown in search results and link previews.';

  const copyUrl = async () => {
    try {
      await navigator.clipboard.writeText(fullUrl);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    } catch {
      /* clipboard blocked — ignore */
    }
  };

  return (
    <>
      <div
        className="bk-psm"
        role="dialog"
        aria-modal="true"
        aria-labelledby="bk-psm-title"
        onMouseDown={(e) => {
          if (e.target === e.currentTarget) closeSettings();
        }}
      >
        <div className="bk-psm__panel">
          {/* ── Header ───────────────────────────────────────────── */}
          <header className="bk-psm__head">
            <span className="bk-psm__head-icon" aria-hidden>
              <GearSix size={16} weight="regular" />
            </span>
            <div className="bk-psm__head-text">
              <h2 id="bk-psm-title">{chrome.title.trim() || `Untitled ${label}`}</h2>
              <p>
                <span className={`bk-psm__pill${isLive ? ' is-live' : ''}`}>
                  <span aria-hidden />
                  {isLive
                    ? 'Published'
                    : chrome.pageStatus === 'auto-draft'
                      ? 'New draft'
                      : 'Draft'}
                </span>
                Edited {formatRelative(chrome.updatedAt)}
                {editedBy ? ` by ${editedBy}` : ''}
              </p>
            </div>
            <button
              type="button"
              className="bk-psm__icon-btn"
              onClick={closeSettings}
              aria-label="Close"
              title="Close (Esc)"
            >
              <X size={16} weight="bold" />
            </button>
          </header>

          <nav className="bk-psm__tabs" role="tablist" aria-label="Settings sections">
            <button
              type="button"
              role="tab"
              aria-selected={tab === 'general'}
              className={tab === 'general' ? 'is-active' : ''}
              onClick={() => setTab('general')}
            >
              General
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={tab === 'revisions'}
              className={tab === 'revisions' ? 'is-active' : ''}
              onClick={() => setTab('revisions')}
            >
              Revisions
              {revisionCount > 0 ? <span className="bk-psm__count">{revisionCount}</span> : null}
            </button>
          </nav>

          {/* ── Body ─────────────────────────────────────────────── */}
          <div className="bk-psm__body">
            {tab === 'general' ? (
              <div className="bk-psm__grid">
                <div className="bk-psm__col">
                  <section className="bk-psm__card">
                    <h3 className="bk-psm__card-title">Basics</h3>
                    <label className="bk-psm__field">
                      <span className="bk-psm__label">Title</span>
                      <input
                        ref={titleRef}
                        className="bk-psm__input"
                        type="text"
                        maxLength={200}
                        value={chrome.title}
                        onChange={(e) => chrome.onTitleChange(e.target.value)}
                        placeholder={`Name this ${label}`}
                      />
                    </label>

                    <div className="bk-psm__field">
                      <label className="bk-psm__label" htmlFor="bk-psm-slug">
                        URL
                      </label>
                      <div className="bk-psm__url">
                        <span className="bk-psm__url-prefix" title={urlPrefix}>
                          {displayHost}
                        </span>
                        <input
                          id="bk-psm-slug"
                          className="bk-psm__url-input"
                          type="text"
                          value={chrome.slug}
                          onChange={(e) => chrome.onSlugChange(e.target.value)}
                          onBlur={() => chrome.commitSlug()}
                          spellCheck={false}
                          aria-label={`${label} slug`}
                        />
                        <button
                          type="button"
                          className="bk-psm__url-btn"
                          onClick={() => void copyUrl()}
                          title="Copy link"
                        >
                          {copied ? <Check size={13} weight="bold" /> : <CopySimple size={13} />}
                        </button>
                        {isLive ? (
                          <a
                            className="bk-psm__url-btn"
                            href={fullUrl}
                            target="_blank"
                            rel="noreferrer"
                            title={`Open live ${label}`}
                          >
                            <ArrowSquareOut size={13} />
                          </a>
                        ) : null}
                      </div>
                      <span className="bk-psm__hint">
                        Lowercase letters, numbers and dashes. Changing it breaks old links.
                      </span>
                    </div>

                    <div className="bk-psm__field">
                      <span className="bk-psm__label">Status</span>
                      <div className="bk-psm__seg" role="radiogroup" aria-label="Status">
                        <button
                          type="button"
                          role="radio"
                          aria-checked={visibility === 'draft'}
                          className={visibility === 'draft' ? 'is-active' : ''}
                          disabled={!chrome.canPublish && visibility === 'publish'}
                          onClick={() => chrome.setVisibility('draft')}
                        >
                          <span className="bk-psm__dot" aria-hidden />
                          Draft
                        </button>
                        <button
                          type="button"
                          role="radio"
                          aria-checked={visibility === 'publish'}
                          className={visibility === 'publish' ? 'is-active is-live' : ''}
                          disabled={!chrome.canPublish}
                          title={
                            chrome.canPublish
                              ? undefined
                              : `You can't publish ${chrome.pluralLabel.toLowerCase()}`
                          }
                          onClick={() => chrome.setVisibility('publish')}
                        >
                          <span className="bk-psm__dot is-live" aria-hidden />
                          Published
                        </button>
                      </div>
                      {statusChanged ? (
                        <span className="bk-psm__hint is-warn">
                          {visibility === 'publish'
                            ? `Click “Save changes” to publish this ${label}.`
                            : `Click “Save changes” to take this ${label} offline.`}
                        </span>
                      ) : null}
                    </div>
                  </section>

                  <section className="bk-psm__card">
                    <div className="bk-psm__card-head">
                      <h3 className="bk-psm__card-title">Excerpt</h3>
                      <span className="bk-psm__counter">
                        {chrome.excerpt.length}/{EXCERPT_MAX}
                      </span>
                    </div>
                    <textarea
                      className="bk-psm__input bk-psm__textarea"
                      rows={3}
                      maxLength={EXCERPT_MAX}
                      value={chrome.excerpt}
                      onChange={(e) => chrome.setExcerpt(e.target.value)}
                      placeholder="A short summary for listings, search results and social shares (optional)"
                    />
                    <div className="bk-psm__serp" aria-label="Search result preview">
                      <span className="bk-psm__serp-label">
                        <MagnifyingGlass size={11} weight="bold" aria-hidden /> Search preview
                      </span>
                      <span className="bk-psm__serp-url">
                        {fullUrl.replace(/^https?:\/\//, '')}
                      </span>
                      <span className="bk-psm__serp-title">
                        {chrome.title.trim() || `Untitled ${label}`}
                      </span>
                      <span
                        className={`bk-psm__serp-desc${chrome.excerpt.trim() ? '' : ' is-empty'}`}
                      >
                        {snippet.length > SNIPPET_CHARS
                          ? `${snippet.slice(0, SNIPPET_CHARS).trimEnd()}…`
                          : snippet}
                      </span>
                    </div>
                  </section>
                </div>

                <div className="bk-psm__col">
                  <section className="bk-psm__card">
                    <h3 className="bk-psm__card-title">Featured image</h3>
                    {featured?.url ? (
                      <div className="bk-psm__featured">
                        <button
                          type="button"
                          className="bk-psm__featured-img"
                          onClick={() => setFeaturedPickerOpen(true)}
                          title="Replace image"
                        >
                          <img src={featured.url} alt={featured.alt || 'Featured image'} />
                        </button>
                        <div className="bk-psm__featured-actions">
                          <button
                            type="button"
                            className="bk-psm__btn is-ghost"
                            onClick={() => setFeaturedPickerOpen(true)}
                          >
                            Replace
                          </button>
                          <button
                            type="button"
                            className="bk-psm__btn is-ghost is-danger"
                            onClick={() => chrome.setFeaturedImageId(null)}
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button
                        type="button"
                        className="bk-psm__dropzone"
                        onClick={() => setFeaturedPickerOpen(true)}
                      >
                        <ImageIcon size={22} aria-hidden />
                        <strong>Choose featured image</strong>
                        <span>Used for social previews and post listings</span>
                      </button>
                    )}
                  </section>

                  <section className="bk-psm__card">
                    <h3 className="bk-psm__card-title">Overview</h3>
                    <div className="bk-psm__stats">
                      <div>
                        <strong>{stats.words.toLocaleString()}</strong>
                        <span>words</span>
                      </div>
                      <div>
                        <strong>
                          {stats.words ? Math.max(1, Math.ceil(stats.words / 200)) : 0}
                        </strong>
                        <span>min read</span>
                      </div>
                      <div>
                        <strong>{revisionCount}</strong>
                        <span>revisions</span>
                      </div>
                    </div>
                    <dl className="bk-psm__meta">
                      <div>
                        <dt>Author</dt>
                        <dd>
                          <span className="bk-psm__avatar" aria-hidden>
                            {initials(chrome.authorName)}
                          </span>
                          {chrome.authorName || '—'}
                        </dd>
                      </div>
                      <div>
                        <dt>Last edited</dt>
                        <dd title={formatDate(chrome.updatedAt)}>
                          {formatRelative(chrome.updatedAt)}
                          {editedBy ? ` · ${editedBy}` : ''}
                        </dd>
                      </div>
                      <div>
                        <dt>Published</dt>
                        <dd>{chrome.publishedAt ? formatDate(chrome.publishedAt) : 'Not yet'}</dd>
                      </div>
                      <div>
                        <dt>Created</dt>
                        <dd>{formatDate(chrome.createdAt)}</dd>
                      </div>
                    </dl>
                  </section>

                  {chrome.canDelete ? (
                    <section className="bk-psm__card is-danger">
                      <div className="bk-psm__danger">
                        <div>
                          <h3 className="bk-psm__card-title">Delete {label}</h3>
                          <p>Removes it from the site permanently.</p>
                        </div>
                        <button
                          type="button"
                          className="bk-psm__btn is-danger"
                          disabled={chrome.busy}
                          onClick={chrome.onDelete}
                        >
                          <Trash size={13} weight="bold" aria-hidden />
                          Delete
                        </button>
                      </div>
                    </section>
                  ) : null}
                </div>
              </div>
            ) : (
              <div className="bk-psm__revisions">
                <p className="bk-psm__intro">
                  <ClockCounterClockwise size={14} aria-hidden />
                  Every save keeps the previous version here. Restoring saves your current version
                  first, so nothing is lost.
                </p>
                {revisionsError ? (
                  <p className="bk-psm__alert" role="alert">
                    {revisionsError}
                  </p>
                ) : null}
                {revisionsLoading ? (
                  <ul className="bk-psm__timeline" aria-busy>
                    {[0, 1, 2].map((i) => (
                      <li key={i} className="bk-psm__rev is-skeleton">
                        <span className="bk-psm__avatar" />
                        <span className="bk-psm__skel" />
                      </li>
                    ))}
                  </ul>
                ) : revisions.length === 0 ? (
                  <div className="bk-psm__empty">
                    <ClockCounterClockwise size={22} aria-hidden />
                    <strong>No revisions yet</strong>
                    <span>Save or publish to start the history.</span>
                  </div>
                ) : (
                  <>
                    <ul className="bk-psm__timeline">
                      {revisionSlice.map((rev, i) => {
                        const latest = safeRevisionPage === 0 && i === 0;
                        return (
                          <li key={rev.id} className="bk-psm__rev">
                            <span className="bk-psm__avatar" aria-hidden>
                              {initials(rev.authorName)}
                            </span>
                            <div className="bk-psm__rev-meta">
                              <strong title={formatDate(rev.createdAt)}>
                                {formatRelative(rev.createdAt)}
                                {latest ? <span className="bk-psm__tag">Latest</span> : null}
                              </strong>
                              <span>
                                {rev.authorName || 'Unknown'} · {formatDate(rev.createdAt)}
                                {rev.title && rev.title !== chrome.title ? ` · “${rev.title}”` : ''}
                              </span>
                            </div>
                            <button
                              type="button"
                              className="bk-psm__btn is-ghost"
                              disabled={Boolean(restoringId) || chrome.busy}
                              onClick={() => void onRestore(rev.id)}
                            >
                              <ArrowCounterClockwise size={12} weight="bold" aria-hidden />
                              {restoringId === rev.id ? 'Restoring…' : 'Restore'}
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                    {revisions.length > REVISIONS_PER_PAGE ? (
                      <div className="bk-psm__pager">
                        <span>
                          {safeRevisionPage * REVISIONS_PER_PAGE + 1}–
                          {Math.min((safeRevisionPage + 1) * REVISIONS_PER_PAGE, revisions.length)}{' '}
                          of {revisions.length}
                        </span>
                        <div>
                          <button
                            type="button"
                            className="bk-psm__icon-btn"
                            aria-label="Newer revisions"
                            disabled={safeRevisionPage <= 0}
                            onClick={() => setRevisionPage(Math.max(0, safeRevisionPage - 1))}
                          >
                            <CaretLeft size={13} weight="bold" />
                          </button>
                          <button
                            type="button"
                            className="bk-psm__icon-btn"
                            aria-label="Older revisions"
                            disabled={safeRevisionPage >= revisionPageCount - 1}
                            onClick={() =>
                              setRevisionPage(Math.min(revisionPageCount - 1, safeRevisionPage + 1))
                            }
                          >
                            <CaretRight size={13} weight="bold" />
                          </button>
                        </div>
                      </div>
                    ) : null}
                  </>
                )}
              </div>
            )}
          </div>

          {/* ── Footer ───────────────────────────────────────────── */}
          <footer className="bk-psm__foot">
            <span className={`bk-psm__state${chrome.isDirty ? ' is-dirty' : ''}`}>
              <span aria-hidden />
              {chrome.busy ? 'Saving…' : chrome.isDirty ? 'Unsaved changes' : 'All changes saved'}
            </span>
            <div className="bk-psm__foot-actions">
              <button type="button" className="bk-psm__btn is-ghost" onClick={closeSettings}>
                Close
              </button>
              <button
                type="button"
                className="bk-psm__btn is-primary"
                disabled={chrome.busy || !chrome.isDirty}
                onClick={() => {
                  chrome.update();
                  closeSettings();
                }}
              >
                {chrome.busy
                  ? 'Saving…'
                  : visibility === 'publish' && !isLive
                    ? 'Publish'
                    : 'Save changes'}
              </button>
            </div>
          </footer>
        </div>
      </div>
      <MediaPicker
        open={featuredPickerOpen}
        title="Featured image"
        kind="image"
        selected={chrome.featuredImageId ? [chrome.featuredImageId] : []}
        onClose={() => setFeaturedPickerOpen(false)}
        onSelect={(items: MediaItem[]) => {
          chrome.setFeaturedImageId(items[0]?.id ?? null);
          setFeaturedPickerOpen(false);
        }}
      />
    </>
  );
}
