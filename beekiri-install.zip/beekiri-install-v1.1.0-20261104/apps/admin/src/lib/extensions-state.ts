import { useEffect, useState } from 'react';
import { api } from '../api/client';
import { EXTENSIONS_CHANGED } from './admin-events';

/** Active extension slugs, shared by the sidebar, Spotlight and route guards. */

let cached: string[] | null = null;
let inflight: Promise<string[]> | null = null;
const listeners = new Set<() => void>();

export function loadActiveExtensions(force = false): Promise<string[]> {
  if (cached && !force) return Promise.resolve(cached);
  if (!inflight || force) {
    inflight = api<{ active: string[] }>('/api/extensions/active')
      .then((res) => {
        cached = res.active ?? [];
        listeners.forEach((l) => l());
        return cached;
      })
      .catch(() => {
        cached = cached ?? [];
        return cached;
      })
      .finally(() => {
        inflight = null;
      });
  }
  return inflight;
}

/** Active slugs plus whether the first load has completed (route guards must wait for it). */
export function useActiveExtensionsState(): { active: string[]; loaded: boolean } {
  const [state, setState] = useState<{ active: string[]; loaded: boolean }>({ active: cached ?? [], loaded: cached !== null });
  useEffect(() => {
    let cancelled = false;
    const sync = () => {
      if (!cancelled && cached) setState({ active: cached, loaded: true });
    };
    listeners.add(sync);
    loadActiveExtensions().then(sync);
    const refresh = () => void loadActiveExtensions(true);
    window.addEventListener(EXTENSIONS_CHANGED, refresh);
    return () => {
      cancelled = true;
      listeners.delete(sync);
      window.removeEventListener(EXTENSIONS_CHANGED, refresh);
    };
  }, []);
  return state;
}

export function useActiveExtensions(): string[] {
  const [active, setActive] = useState<string[]>(cached ?? []);
  useEffect(() => {
    let cancelled = false;
    const sync = () => {
      if (!cancelled && cached) setActive(cached);
    };
    listeners.add(sync);
    loadActiveExtensions().then(sync);
    const refresh = () => void loadActiveExtensions(true);
    window.addEventListener(EXTENSIONS_CHANGED, refresh);
    return () => {
      cancelled = true;
      listeners.delete(sync);
      window.removeEventListener(EXTENSIONS_CHANGED, refresh);
    };
  }, []);
  return active;
}

export function useExtensionActive(slug: string): boolean {
  return useActiveExtensions().includes(slug);
}

export const SHOPPING_EXTENSION = 'shopping';
