import { useState } from 'react';
import './analytics-page.css';

/** Shared building blocks for Analytics, Heatmap and BeeCookies (one visual language). */

export const RANK_PREVIEW = 5;

export function niceCeiling(n: number) {
  if (n <= 2) return 2;
  if (n <= 4) return 4;
  if (n <= 6) return 6;
  if (n <= 8) return 8;
  if (n <= 10) return 10;
  const pow = Math.pow(10, Math.floor(Math.log10(n)));
  return Math.ceil(n / pow) * pow;
}

export function formatDay(date: string) {
  const d = new Date(/^\d{4}-\d{2}-\d{2}$/.test(date) ? `${date}T00:00:00` : date);
  if (Number.isNaN(d.getTime())) return date;
  return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
}

export function formatNumber(n: number) {
  return Intl.NumberFormat('en-GB').format(n);
}

export function compactNumber(n: number) {
  return Intl.NumberFormat('en-GB', { notation: 'compact', maximumFractionDigits: 1 }).format(n);
}

/** Catmull-Rom → cubic Bézier so the line bends gently instead of zig-zagging. */
export function smoothPath(points: { x: number; y: number }[]) {
  if (points.length < 2) return '';
  if (points.length === 2) return `M${points[0]!.x} ${points[0]!.y} L${points[1]!.x} ${points[1]!.y}`;
  let d = `M${points[0]!.x} ${points[0]!.y}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[Math.max(0, i - 1)]!;
    const p1 = points[i]!;
    const p2 = points[i + 1]!;
    const p3 = points[Math.min(points.length - 1, i + 2)]!;
    const c1x = p1.x + (p2.x - p0.x) / 6;
    const c1y = p1.y + (p2.y - p0.y) / 6;
    const c2x = p2.x - (p3.x - p1.x) / 6;
    const c2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C${c1x} ${c1y} ${c2x} ${c2y} ${p2.x} ${p2.y}`;
  }
  return d;
}

/** Tiny line for KPI cards and the live card. */
export function Sparkline({ values, color = '#ff9508', height = 32 }: { values: number[]; color?: string; height?: number }) {
  const w = 120;
  const h = height;
  if (values.length < 2) return <svg className="bk-an-spark" viewBox={`0 0 ${w} ${h}`} aria-hidden />;
  const max = Math.max(1, ...values);
  const pts = values.map((v, i) => ({ x: (w * i) / (values.length - 1), y: h - 3 - (v / max) * (h - 6) }));
  const line = smoothPath(pts);
  return (
    <svg className="bk-an-spark" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" aria-hidden>
      <path d={`${line} L${w} ${h} L0 ${h} Z`} fill={color} fillOpacity="0.12" />
      <path d={line} fill="none" stroke={color} strokeWidth="1.8" strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

export type RankRow = { key: string; label: string; n: number; share?: string };

export type RankTab = {
  id: string;
  label: string;
  dim: string;
  metric: string;
  noun: string;
  rows: RankRow[];
  empty?: string;
};

export function AnalyticsRankCard({
  tabs,
  ariaLabel,
}: {
  tabs: RankTab[];
  ariaLabel: string;
}) {
  const [tabId, setTabId] = useState(tabs[0]?.id ?? '');
  const [expanded, setExpanded] = useState(false);
  const active = tabs.find((t) => t.id === tabId) ?? tabs[0];
  if (!active) return null;
  const rows = active.rows;
  const total = rows.reduce((sum, r) => sum + r.n, 0);
  const visible = expanded ? rows : rows.slice(0, RANK_PREVIEW);
  const hidden = Math.max(0, rows.length - RANK_PREVIEW);

  return (
    <section className="bk-an-pages">
      <div className="bk-an-pages__tabs" role="tablist" aria-label={ariaLabel}>
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={active.id === t.id}
            className={active.id === t.id ? 'is-active' : undefined}
            onClick={() => {
              setTabId(t.id);
              setExpanded(false);
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="bk-an-pages__cols" aria-hidden>
        <span>{active.dim}</span>
        <span>
          {active.metric} · Share
        </span>
      </div>

      {rows.length ? (
        <ul className="bk-an-pages__list" role="tabpanel">
          {visible.map((r) => {
            const share =
              r.share ??
              (total > 0 ? `${Math.round((r.n / total) * 100)}%` : '0%');
            return (
              <li key={r.key}>
                <span
                  className="bk-an-pages__bar"
                  style={{ width: `${rows[0] && rows[0].n > 0 ? Math.max(2, Math.round((r.n / rows[0].n) * 100)) : 0}%` }}
                  aria-hidden
                />
                <span className="bk-an-pages__label">{r.label}</span>
                <span className="bk-an-pages__meta">
                  <b>{formatNumber(r.n)}</b>
                  <em>{share}</em>
                </span>
              </li>
            );
          })}
        </ul>
      ) : (
        <p className="bk-an__empty bk-an-pages__empty">
          {active.empty ?? 'No data in this range.'}
        </p>
      )}

      {hidden > 0 ? (
        <button
          type="button"
          className="bk-an-pages__more"
          onClick={() => setExpanded((v) => !v)}
        >
          {expanded ? 'Show less' : `View all ${rows.length} ${active.noun}`}
        </button>
      ) : null}
    </section>
  );
}
