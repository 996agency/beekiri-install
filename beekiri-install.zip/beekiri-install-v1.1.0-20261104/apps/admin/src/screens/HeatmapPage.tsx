import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import { PageHeader } from '../components/PageHeader';
import { useAdminHref } from '../lib/AdminEntryContext';
import { formatNumber } from './analytics-ui';
import './analytics-page.css';
import './heatmap-page.css';
import { ErrorNotice } from '../components/ErrorNotice';

type Range = 'today' | '7d' | '30d' | '90d' | 'all';

type HeatmapPayload = {
  range: Range;
  tracking: { enabled: boolean; pageViews: boolean };
  path: string;
  total: number;
  pages: { path: string; clicks: number; users: number }[];
  points: { x: number; y: number; n: number }[];
  generatedAt: string;
};

const RANGES: { value: Range; label: string }[] = [
  { value: 'today', label: 'Today' },
  { value: '7d', label: '7 days' },
  { value: '30d', label: '30 days' },
  { value: '90d', label: '90 days' },
  { value: 'all', label: 'All time' },
];

function pageLabel(path: string) {
  if (!path || path === '/') return 'Home';
  return path;
}

/** 256-step palette: transparent blue → cyan → green → yellow → orange → red. */
const PALETTE = (() => {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 1;
  const g = c.getContext('2d');
  if (!g) return null;
  const grad = g.createLinearGradient(0, 0, 256, 0);
  grad.addColorStop(0.0, 'rgba(0, 0, 255, 0)');
  grad.addColorStop(0.25, 'rgb(0, 97, 153)');
  grad.addColorStop(0.45, 'rgb(183, 216, 148)');
  grad.addColorStop(0.65, 'rgb(255, 230, 0)');
  grad.addColorStop(0.85, 'rgb(255, 140, 0)');
  grad.addColorStop(1.0, 'rgb(255, 30, 0)');
  g.fillStyle = grad;
  g.fillRect(0, 0, 256, 1);
  return g.getImageData(0, 0, 256, 1).data;
})();

/**
 * Real heatmap: every click adds a soft alpha disc to an offscreen canvas, then
 * the accumulated alpha is mapped through PALETTE — so overlapping clicks glow.
 */
function HeatCanvas({
  points,
  width,
  height,
  opacity,
}: {
  points: HeatmapPayload['points'];
  width: number;
  height: number;
  opacity: number;
}) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas || !PALETTE || width < 10) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height);
    const max = Math.max(1, ...points.map((p) => p.n));
    const radius = Math.max(18, Math.min(42, width / 32));
    for (const p of points) {
      const x = (p.x / 100) * width;
      const y = (p.y / 100) * height;
      const g = ctx.createRadialGradient(x, y, 0, x, y, radius);
      const a = 0.18 + 0.82 * (p.n / max);
      g.addColorStop(0, `rgba(0,0,0,${a})`);
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g;
      ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2);
    }
    const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const d = img.data;
    for (let i = 0; i < d.length; i += 4) {
      const alpha = d[i + 3]!;
      if (!alpha) continue;
      const o = alpha * 4;
      d[i] = PALETTE[o]!;
      d[i + 1] = PALETTE[o + 1]!;
      d[i + 2] = PALETTE[o + 2]!;
      d[i + 3] = Math.min(235, alpha * 1.4);
    }
    ctx.putImageData(img, 0, 0);
  }, [points, width, height]);

  return <canvas ref={ref} className="bk-hm__canvas" style={{ width, height, opacity }} aria-hidden />;
}

export function HeatmapPage() {
  const href = useAdminHref();
  const [range, setRange] = useState<Range>('30d');
  const [path, setPath] = useState<string | null>(null);
  const [data, setData] = useState<HeatmapPayload | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [frameH, setFrameH] = useState(900);
  const [frameW, setFrameW] = useState(0);
  const [query, setQuery] = useState('');
  const [showHeat, setShowHeat] = useState(true);
  const [opacity, setOpacity] = useState(0.75);
  const [loading, setLoading] = useState(true);
  const frameRef = useRef<HTMLIFrameElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    setError(null);
    setLoading(true);
    const q = new URLSearchParams({ range });
    if (path) q.set('path', path);
    api<HeatmapPayload>(`/api/analytics/heatmap?${q}`)
      .then((payload) => {
        if (cancelled) return;
        setData(payload);
        if (!path) setPath(payload.path);
      })
      .catch((e) => {
        if (cancelled) return;
        setData(null);
        setError(e instanceof ApiError ? e.message : 'Could not load heatmap.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [range, path]);

  // The heat canvas follows the preview width.
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setFrameW(el.clientWidth));
    ro.observe(el);
    setFrameW(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  const trackingOff = data && (!data.tracking.enabled || !data.tracking.pageViews);

  const previewSrc = useMemo(() => {
    const p = path || data?.path || '/';
    return p.startsWith('/') ? p : `/${p}`;
  }, [path, data?.path]);

  const pages = useMemo(() => {
    const q = query.trim().toLowerCase();
    const all = data?.pages ?? [];
    return q ? all.filter((p) => pageLabel(p.path).toLowerCase().includes(q)) : all;
  }, [data?.pages, query]);

  const topClicks = Math.max(1, ...(data?.pages ?? []).map((p) => p.clicks));
  const current = data?.pages.find((p) => p.path === path) ?? null;
  const currentShare = current && data?.total ? Math.round((current.clicks / data.total) * 100) : 0;
  const pointsReady = Boolean(data && path === data.path);

  const measureFrame = () => {
    const frame = frameRef.current;
    try {
      const doc = frame?.contentDocument;
      if (!doc) return;
      const h = Math.max(doc.documentElement?.scrollHeight ?? 0, doc.body?.scrollHeight ?? 0, 600);
      setFrameH(Math.min(Math.max(h, 600), 8_000));
    } catch {
      /* cross-origin — keep default */
    }
  };

  return (
    <div className="bk-an bk-hm">
      <PageHeader
        title="Heatmap"
        actions={
          <div className="bk-an__tools">
            <div className="bk-an__seg" role="group" aria-label="Date range">
              {RANGES.map((r) => (
                <button
                  key={r.value}
                  type="button"
                  className={range === r.value ? 'is-active' : ''}
                  onClick={() => setRange(r.value)}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>
        }
      />

      {error ? <ErrorNotice message={error} onDismiss={() => setError(null)} /> : null}

      {trackingOff ? (
        <p className="bk-an__banner">
          Clicks are recorded only after a visitor accepts analytics cookies.{' '}
          <Link to={href('analytics/cookies')}>Turn on BeeCookies</Link> to collect heatmaps.
        </p>
      ) : null}

      <div className="bk-an__kpis bk-hm__kpis">
        <div className="bk-an__kpi">
          <span className="bk-an__kpi-label">Total clicks</span>
          <strong className="bk-an__kpi-value">{data ? formatNumber(data.total) : '—'}</strong>
          <div className="bk-an__kpi-foot">
            <span>Across all tracked pages</span>
          </div>
        </div>
        <div className="bk-an__kpi">
          <span className="bk-an__kpi-label">Pages with clicks</span>
          <strong className="bk-an__kpi-value">{data ? formatNumber(data.pages.length) : '—'}</strong>
          <div className="bk-an__kpi-foot">
            <span>{RANGES.find((r) => r.value === range)?.label}</span>
          </div>
        </div>
        <div className="bk-an__kpi">
          <span className="bk-an__kpi-label">This page</span>
          <strong className="bk-an__kpi-value">{current ? formatNumber(current.clicks) : '—'}</strong>
          <div className="bk-an__kpi-foot">
            <span>{current ? `${currentShare}% of all clicks` : 'Pick a page'}</span>
          </div>
        </div>
        <div className="bk-an__kpi">
          <span className="bk-an__kpi-label">Visitors who clicked</span>
          <strong className="bk-an__kpi-value">{current ? formatNumber(current.users) : '—'}</strong>
          <div className="bk-an__kpi-foot">
            <span>
              {current && current.users
                ? `${(current.clicks / current.users).toFixed(1)} clicks per visitor`
                : 'On this page'}
            </span>
          </div>
        </div>
      </div>

      <div className="bk-hm__layout">
        <aside className="bk-an-pages bk-hm__pages">
          <div className="bk-hm__pages-head">
            <h2>Pages</h2>
            <span>{data ? `${formatNumber(data.pages.length)} tracked` : ''}</span>
          </div>
          <label className="bk-hm__search">
            <svg width="13" height="13" viewBox="0 0 256 256" aria-hidden>
              <path
                fill="currentColor"
                d="m229.66 218.34-50.07-50.06a88.11 88.11 0 1 0-11.31 11.31l50.06 50.07a8 8 0 0 0 11.32-11.32ZM40 112a72 72 0 1 1 72 72 72.08 72.08 0 0 1-72-72Z"
              />
            </svg>
            <input
              type="search"
              placeholder="Search pages…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search pages"
            />
          </label>
          <div className="bk-an-pages__cols" aria-hidden>
            <span>Page</span>
            <span>Clicks</span>
          </div>
          {!data ? (
            <p className="bk-an__empty bk-an-pages__empty">Loading…</p>
          ) : data.pages.length === 0 ? (
            <p className="bk-an__empty bk-an-pages__empty">
              No clicks yet. Open the public site, accept analytics cookies and click around — heat
              appears here.
            </p>
          ) : pages.length === 0 ? (
            <p className="bk-an__empty bk-an-pages__empty">No pages match “{query}”.</p>
          ) : (
            <ul className="bk-an-pages__list bk-hm__list">
              {pages.map((p) => (
                <li key={p.path} className={path === p.path ? 'is-active' : undefined}>
                  <button type="button" onClick={() => setPath(p.path)}>
                    <span
                      className="bk-an-pages__bar"
                      style={{ width: `${Math.max(2, Math.round((p.clicks / topClicks) * 100))}%` }}
                      aria-hidden
                    />
                    <span className="bk-an-pages__label">{pageLabel(p.path)}</span>
                    <span className="bk-an-pages__meta">
                      <b>{formatNumber(p.clicks)}</b>
                      <em>{formatNumber(p.users)} users</em>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </aside>

        <section className="bk-hm__preview">
          <div className="bk-hm__toolbar">
            <div className="bk-hm__title">
              <h2>{pageLabel(previewSrc)}</h2>
              <span>
                {pointsReady && data ? `${formatNumber(data.points.length)} hot spots` : 'Loading…'}
              </span>
            </div>
            <div className="bk-hm__controls">
              <label className="bk-hm__toggle">
                <input type="checkbox" checked={showHeat} onChange={(e) => setShowHeat(e.target.checked)} />
                <span className="bk-hm__switch" aria-hidden />
                Heat
              </label>
              <label className="bk-hm__opacity" title="Heat intensity">
                <input
                  type="range"
                  min={0.2}
                  max={1}
                  step={0.05}
                  value={opacity}
                  disabled={!showHeat}
                  onChange={(e) => setOpacity(Number(e.target.value))}
                  aria-label="Heat opacity"
                />
              </label>
              <a className="button" href={previewSrc} target="_blank" rel="noreferrer">
                Open page
              </a>
            </div>
          </div>

          <div className="bk-hm__stage">
            <div ref={wrapRef} className="bk-hm__frame-wrap" style={{ height: frameH }}>
              <iframe
                ref={frameRef}
                className="bk-hm__frame"
                title={`Heatmap preview ${previewSrc}`}
                src={previewSrc}
                onLoad={measureFrame}
              />
              {showHeat && pointsReady && data ? (
                <HeatCanvas points={data.points} width={frameW} height={frameH} opacity={opacity} />
              ) : null}
              {pointsReady && data && data.points.length === 0 ? (
                <p className="bk-hm__empty">No clicks on this page in the selected range.</p>
              ) : null}
              {loading ? <span className="bk-hm__loading" aria-hidden /> : null}
            </div>
          </div>

          <div className="bk-hm__legend" aria-hidden>
            <span>Fewer clicks</span>
            <i />
            <span>More clicks</span>
          </div>
        </section>
      </div>
    </div>
  );
}
