import { FormEvent, useEffect, useState } from 'react';
import { api, ApiError } from '../api/client';
import { AnalyticsRankCard, formatDay, formatNumber, niceCeiling } from './analytics-ui';
import './analytics-page.css';
import './bee-cookies-panel.css';

type Category = {
  enabled: boolean;
  label: string;
  description: string;
};

export type BeeCookiesSettings = {
  enabled: boolean;
  position: 'bottom' | 'bottom-left' | 'bottom-right';
  bannerTitle: string;
  bannerMessage: string;
  acceptLabel: string;
  rejectLabel: string;
  preferencesLabel: string;
  saveLabel: string;
  privacyPolicyUrl: string;
  trackPageViews: boolean;
  categories: {
    essential: Category;
    functional: Category;
    analytics: Category;
    marketing: Category;
  };
};

type Range = 'today' | '7d' | '30d' | 'all';

type Analytics = {
  range: Range;
  consent: {
    decisions: number;
    uniqueVisitors: number;
    accepted: number;
    rejected: number;
    custom: number;
    consentRate: number;
    categories: { functional: number; analytics: number; marketing: number };
    devices: Record<string, number>;
    countries: { code: string; count: number }[];
    trend: { date: string; accepted: number; rejected: number; custom: number }[];
  };
};

type Props = {
  busy: boolean;
  onBusy: (busy: boolean) => void;
  onNotice: (message: string | null) => void;
  onError: (message: string | null) => void;
};

const RANGES: { value: Range; label: string }[] = [
  { value: 'today', label: 'Today' },
  { value: '7d', label: '7 days' },
  { value: '30d', label: '30 days' },
  { value: 'all', label: 'All' },
];

const OPTIONAL: Array<keyof BeeCookiesSettings['categories']> = [
  'functional',
  'analytics',
  'marketing',
];

function titleCase(key: string) {
  return key ? key[0].toUpperCase() + key.slice(1) : key;
}

function flagEmoji(code: string) {
  return String.fromCodePoint(...[...code].map((c) => 127397 + c.charCodeAt(0)));
}

function countryLabel(code: string) {
  if (!code || code === 'Unknown' || code === 'XX') return { flag: '', name: 'Not detected' };
  if (!/^[A-Z]{2}$/.test(code)) return { flag: '', name: code };
  try {
    const name = new Intl.DisplayNames(['en'], { type: 'region' }).of(code);
    return { flag: flagEmoji(code), name: name || code };
  } catch {
    return { flag: flagEmoji(code), name: code };
  }
}

/** Accepted / custom / rejected split as one bar + legend. */
function Mix({ parts }: { parts: { key: string; n: number; tone: 'ok' | 'mid' | 'faint' }[] }) {
  const total = parts.reduce((sum, p) => sum + p.n, 0);
  if (!total) return <p className="bk-an__empty">No decisions in this range.</p>;
  return (
    <div className="bk-bee-mix">
      <div className="bk-bee-mix__bar" aria-hidden>
        {parts
          .filter((p) => p.n > 0)
          .map((p) => (
            <i key={p.key} className={`is-${p.tone}`} style={{ width: `${(p.n / total) * 100}%` }} />
          ))}
      </div>
      <ul className="bk-bee-mix__legend">
        {parts.map((p) => (
          <li key={p.key}>
            <i className={`is-${p.tone}`} aria-hidden />
            <span>{p.key}</span>
            <strong>{formatNumber(p.n)}</strong>
            <em>{Math.round((p.n / total) * 100)}%</em>
          </li>
        ))}
      </ul>
    </div>
  );
}

type Day = { date: string; accepted: number; rejected: number; custom: number };

/** Stacked daily bars: accepted (bottom) → custom → rejected, with a hover readout. */
function ConsentChart({ trend }: { trend: Day[] }) {
  const [hover, setHover] = useState<number | null>(null);
  const w = 960;
  const h = 220;
  const pad = { t: 12, r: 8, b: 28, l: 36 };
  const innerW = w - pad.l - pad.r;
  const innerH = h - pad.t - pad.b;
  const n = trend.length;
  const max = niceCeiling(Math.max(1, ...trend.map((d) => d.accepted + d.custom + d.rejected)));
  const slot = innerW / Math.max(1, n);
  const bw = Math.max(3, Math.min(28, slot * 0.62));
  const y = (v: number) => pad.t + innerH - (v / max) * innerH;
  const labelEvery = Math.max(1, Math.ceil(n / 8));
  const hd = hover !== null ? trend[hover] : null;
  if (!n) return <p className="bk-an__empty bk-bee-chart__empty">No consent decisions in this range.</p>;
  return (
    <div className="bk-bee-chart">
      <svg
        className="bk-an__svg bk-bee-chart__svg"
        viewBox={`0 0 ${w} ${h}`}
        preserveAspectRatio="none"
        role="img"
        aria-label="Consent decisions per day"
        onMouseLeave={() => setHover(null)}
      >
        {[0, 0.5, 1].map((f) => (
          <g key={f}>
            <line x1={pad.l} x2={w - pad.r} y1={y(max * f)} y2={y(max * f)} stroke="#f0f0f1" vectorEffect="non-scaling-stroke" />
            <text x={pad.l - 8} y={y(max * f) + 4} textAnchor="end" fontSize="11" fill="#8c8f94">
              {Math.round(max * f)}
            </text>
          </g>
        ))}
        {trend.map((d, i) => {
          const cx = pad.l + slot * i + slot / 2;
          const parts: [number, string][] = [
            [d.accepted, '#ff9508'],
            [d.custom, '#ffc980'],
            [d.rejected, '#dcdcde'],
          ];
          let acc = 0;
          return (
            <g key={d.date} onMouseEnter={() => setHover(i)} opacity={hover === null || hover === i ? 1 : 0.45}>
              <rect x={cx - slot / 2} y={pad.t} width={slot} height={innerH} fill="transparent" />
              {parts.map(([v, color], k) => {
                if (!v) return null;
                const top = y(acc + v);
                const height = y(acc) - top;
                acc += v;
                return <rect key={k} x={cx - bw / 2} y={top} width={bw} height={Math.max(1, height)} rx={k === 2 || (k === 1 && !d.rejected) || (k === 0 && !d.custom && !d.rejected) ? 2 : 0} fill={color} />;
              })}
              {i % labelEvery === 0 ? (
                <text x={cx} y={h - 8} textAnchor="middle" fontSize="11" fill="#8c8f94">
                  {formatDay(d.date)}
                </text>
              ) : null}
            </g>
          );
        })}
      </svg>
      {hd ? (
        <div
          className="bk-an-trend__tip"
          style={{ left: `${((pad.l + slot * hover! + slot / 2) / w) * 100}%` }}
          data-side={hover! > n / 2 ? 'left' : 'right'}
        >
          <span>{formatDay(hd.date)}</span>
          <strong>{formatNumber(hd.accepted + hd.custom + hd.rejected)}</strong>
          <em>
            {hd.accepted} accepted · {hd.custom} custom · {hd.rejected} rejected
          </em>
        </div>
      ) : null}
    </div>
  );
}

/** What the public banner will look like with the current (unsaved) settings. */
function BannerPreview({ settings }: { settings: BeeCookiesSettings }) {
  const corner = settings.position !== 'bottom';
  return (
    <div className={`bk-bee-preview is-${settings.position}${settings.enabled ? '' : ' is-off'}`}>
      <div className="bk-bee-preview__page" aria-hidden>
        <span />
        <span />
        <span />
      </div>
      <div className={`bk-bee-preview__banner${corner ? ' is-card' : ''}`}>
        <strong>{settings.bannerTitle || 'Cookies'}</strong>
        <p>
          {settings.bannerMessage || 'We use cookies to improve your experience.'}
          {settings.privacyPolicyUrl ? <u> Privacy policy</u> : null}
        </p>
        <div className="bk-bee-preview__actions">
          <span className="is-ghost">{settings.preferencesLabel || 'Preferences'}</span>
          <span className="is-ghost">{settings.rejectLabel || 'Reject'}</span>
          <span className="is-primary">{settings.acceptLabel || 'Accept'}</span>
        </div>
      </div>
      {!settings.enabled ? <em className="bk-bee-preview__off">Banner is turned off</em> : null}
    </div>
  );
}

export function BeeCookiesPanel({ busy, onBusy, onNotice, onError }: Props) {
  const [settings, setSettings] = useState<BeeCookiesSettings | null>(null);
  const [pane, setPane] = useState<'setup' | 'consent'>('setup');
  const [range, setRange] = useState<Range>('30d');
  const [analytics, setAnalytics] = useState<Analytics | null>(null);

  const loadSettings = async () => {
    const s = await api<BeeCookiesSettings>('/api/bee-cookies/settings');
    setSettings(s);
  };

  const loadAnalytics = async (next = range) => {
    const data = await api<Analytics>(`/api/bee-cookies/analytics?range=${next}`);
    setAnalytics(data);
  };

  useEffect(() => {
    loadSettings().catch((e) =>
      onError(e instanceof ApiError ? e.message : 'Could not load BeeCookies.'),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (pane === 'setup') return;
    loadAnalytics(range).catch((e) =>
      onError(e instanceof ApiError ? e.message : 'Could not load analytics.'),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pane, range]);

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    onBusy(true);
    onError(null);
    onNotice(null);
    try {
      const saved = await api<BeeCookiesSettings>('/api/bee-cookies/settings', {
        method: 'PATCH',
        json: settings,
      });
      setSettings(saved);
      onNotice('BeeCookies saved.');
    } catch (err) {
      onError(err instanceof ApiError ? err.message : 'Save failed');
    } finally {
      onBusy(false);
    }
  };

  if (!settings) {
    return (
      <div className="bk-settings-panel__loading" role="status">
        <span className="bk-settings-panel__spinner" aria-hidden />
        <span>Loading…</span>
      </div>
    );
  }

  const c = analytics?.consent;

  return (
    <div className="bk-stack bk-bee">
      <div className="bk-bee__bar">
        <div className="bk-an__seg" role="tablist" aria-label="BeeCookies sections">
          {(
            [
              ['setup', 'Setup'],
              ['consent', 'Consent'],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={pane === id}
              className={pane === id ? 'is-active' : ''}
              onClick={() => setPane(id)}
            >
              {label}
            </button>
          ))}
        </div>
        {pane === 'consent' ? (
          <div className="bk-an__seg" role="group" aria-label="Date range">
            {RANGES.map((r) => (
              <button
                key={r.value}
                type="button"
                className={range === r.value ? 'is-active' : ''}
                onClick={() => setRange(r.value)}
              >
                {r.label}
              </button>
            ))}
          </div>
        ) : (
          <span className={`bk-bee__status${settings.enabled ? ' is-on' : ''}`}>
            <i aria-hidden />
            {settings.enabled ? 'Banner live on the site' : 'Banner turned off'}
          </span>
        )}
      </div>

      {pane === 'setup' ? (
        <div className="bk-bee__setup">
        <form className="bk-stack" onSubmit={(e) => void save(e)}>
          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">BeeCookies</h2>
            </div>
            <div className="bk-panel__body">
              <p className="bk-muted" style={{ marginTop: 0 }}>
                Ask visitors for cookie consent before optional cookies run. Essential cookies
                (your visitors&apos; choice) stay on. Analytics and marketing stay off until
                accepted.
              </p>
              <table className="form-table">
                <tbody>
                  <tr>
                    <th scope="row">Status</th>
                    <td>
                      <label className="bk-check">
                        <input
                          type="checkbox"
                          checked={settings.enabled}
                          onChange={(e) => setSettings({ ...settings, enabled: e.target.checked })}
                        />
                        <span className="bk-check__box" aria-hidden />
                        <span className="bk-check__label">Show the consent banner on the public site</span>
                      </label>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="bee-title">Banner title</label>
                    </th>
                    <td>
                      <input
                        id="bee-title"
                        className="regular-text"
                        value={settings.bannerTitle}
                        onChange={(e) => setSettings({ ...settings, bannerTitle: e.target.value })}
                      />
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="bee-message">Message</label>
                    </th>
                    <td>
                      <textarea
                        id="bee-message"
                        className="large-text"
                        rows={4}
                        value={settings.bannerMessage}
                        onChange={(e) => setSettings({ ...settings, bannerMessage: e.target.value })}
                      />
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">Buttons</th>
                    <td className="bk-bee-inline">
                      <label>
                        Accept
                        <input
                          className="regular-text"
                          value={settings.acceptLabel}
                          onChange={(e) => setSettings({ ...settings, acceptLabel: e.target.value })}
                        />
                      </label>
                      <label>
                        Reject
                        <input
                          className="regular-text"
                          value={settings.rejectLabel}
                          onChange={(e) => setSettings({ ...settings, rejectLabel: e.target.value })}
                        />
                      </label>
                      <label>
                        Preferences
                        <input
                          className="regular-text"
                          value={settings.preferencesLabel}
                          onChange={(e) =>
                            setSettings({ ...settings, preferencesLabel: e.target.value })
                          }
                        />
                      </label>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="bee-position">Position</label>
                    </th>
                    <td>
                      <select
                        id="bee-position"
                        value={settings.position}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            position: e.target.value as BeeCookiesSettings['position'],
                          })
                        }
                      >
                        <option value="bottom">Bottom bar</option>
                        <option value="bottom-left">Bottom left</option>
                        <option value="bottom-right">Bottom right</option>
                      </select>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="bee-privacy">Privacy policy URL</label>
                    </th>
                    <td>
                      <input
                        id="bee-privacy"
                        className="regular-text"
                        placeholder="/privacy"
                        value={settings.privacyPolicyUrl}
                        onChange={(e) =>
                          setSettings({ ...settings, privacyPolicyUrl: e.target.value })
                        }
                      />
                      <p className="description">Optional. Shown as a link on the banner.</p>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">Analytics</th>
                    <td>
                      <label className="bk-check">
                        <input
                          type="checkbox"
                          checked={settings.trackPageViews}
                          onChange={(e) =>
                            setSettings({ ...settings, trackPageViews: e.target.checked })
                          }
                        />
                        <span className="bk-check__box" aria-hidden />
                        <span className="bk-check__label">
                          Feed Analytics Overview after analytics cookies are accepted
                        </span>
                      </label>
                      <p className="description">
                        First-party only. Page views, sources, and devices show under Analytics →
                        Overview. IP addresses are not stored.
                      </p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Categories</h2>
            </div>
            <div className="bk-panel__body">
              <table className="form-table">
                <tbody>
                  <tr>
                    <th scope="row">{settings.categories.essential.label}</th>
                    <td>
                      <p className="description" style={{ marginTop: 0 }}>
                        Always on. Stores the visitor&apos;s cookie choice.
                      </p>
                      <input
                        className="regular-text"
                        value={settings.categories.essential.description}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            categories: {
                              ...settings.categories,
                              essential: {
                                ...settings.categories.essential,
                                description: e.target.value,
                              },
                            },
                          })
                        }
                      />
                    </td>
                  </tr>
                  {OPTIONAL.map((key) => {
                    const cat = settings.categories[key];
                    return (
                      <tr key={key}>
                        <th scope="row">{cat.label}</th>
                        <td>
                          <label className="bk-check">
                            <input
                              type="checkbox"
                              checked={cat.enabled}
                              onChange={(e) =>
                                setSettings({
                                  ...settings,
                                  categories: {
                                    ...settings.categories,
                                    [key]: { ...cat, enabled: e.target.checked },
                                  },
                                })
                              }
                            />
                            <span className="bk-check__box" aria-hidden />
                            <span className="bk-check__label">Offer this category</span>
                          </label>
                          <input
                            className="regular-text"
                            style={{ marginTop: 8 }}
                            value={cat.description}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                categories: {
                                  ...settings.categories,
                                  [key]: { ...cat, description: e.target.value },
                                },
                              })
                            }
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <p className="submit">
                <button type="submit" className="button button-primary" disabled={busy}>
                  {busy ? 'Saving…' : 'Save changes'}
                </button>
              </p>
            </div>
          </div>
        </form>
        <aside className="bk-bee__aside">
          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Live preview</h2>
            </div>
            <div className="bk-panel__body">
              <BannerPreview settings={settings} />
              <p className="description">Updates as you type. Save to publish the changes.</p>
            </div>
          </div>
        </aside>
        </div>
      ) : null}

      {pane === 'consent' ? (
        <div className="bk-stack">
          {!analytics ? (
            <div className="bk-an__kpis" aria-busy>
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="bk-an__kpi is-skeleton">
                  <span className="bk-an__skel" style={{ width: '40%' }} />
                  <span className="bk-an__skel is-big" />
                  <span className="bk-an__skel" style={{ width: '60%' }} />
                </div>
              ))}
            </div>
          ) : null}

          {c ? (
            <>
              <div className="bk-an__kpis">
                {[
                  { label: 'Visitors', value: formatNumber(c.uniqueVisitors), foot: 'Saw the banner and chose' },
                  { label: 'Decisions', value: formatNumber(c.decisions), foot: c.uniqueVisitors ? `${(c.decisions / c.uniqueVisitors).toFixed(1)} per visitor` : '—' },
                  { label: 'Accepted all', value: `${c.consentRate}%`, foot: `${formatNumber(c.accepted)} decisions`, tone: 'is-up' },
                  { label: 'Rejected optional', value: formatNumber(c.rejected), foot: c.decisions ? `${Math.round((c.rejected / c.decisions) * 100)}% of decisions` : '—' },
                ].map((k) => (
                  <div key={k.label} className="bk-an__kpi">
                    <span className="bk-an__kpi-label">{k.label}</span>
                    <strong className="bk-an__kpi-value">{k.value}</strong>
                    <div className="bk-an__kpi-foot">
                      <span>{k.foot}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bk-an__row">
                <section className="bk-an-trend">
                  <div className="bk-an-trend__head">
                    <div>
                      <h2>Decisions per day</h2>
                      <p>{RANGES.find((r) => r.value === range)?.label}</p>
                    </div>
                    <ul className="bk-bee-mix__legend is-compact" aria-hidden>
                      <li>
                        <i className="is-ok" />
                        Accepted
                      </li>
                      <li>
                        <i className="is-mid" />
                        Custom
                      </li>
                      <li>
                        <i className="is-faint" />
                        Rejected
                      </li>
                    </ul>
                  </div>
                  <ConsentChart trend={c.trend} />
                </section>

                <aside className="bk-an-live bk-bee-choices">
                  <div className="bk-an-live__head">
                    <span>Choices</span>
                  </div>
                  <strong className="bk-an-live__count">{c.consentRate}%</strong>
                  <span className="bk-an-live__label">of visitors accepted every category</span>
                  <Mix
                    parts={[
                      { key: 'Accepted all', n: c.accepted, tone: 'ok' },
                      { key: 'Custom', n: c.custom, tone: 'mid' },
                      { key: 'Rejected optional', n: c.rejected, tone: 'faint' },
                    ]}
                  />
                </aside>
              </div>

              <div className="bk-an__pair">
                <AnalyticsRankCard
                  ariaLabel="Optional categories"
                  tabs={[
                    {
                      id: 'categories',
                      label: 'Categories allowed',
                      dim: 'Category',
                      metric: 'Visitors',
                      noun: 'categories',
                      rows: [
                        { key: 'functional', label: 'Functional', n: c.categories.functional },
                        { key: 'analytics', label: 'Analytics', n: c.categories.analytics },
                        { key: 'marketing', label: 'Marketing', n: c.categories.marketing },
                      ],
                    },
                  ]}
                />
                <AnalyticsRankCard
                  ariaLabel="Devices"
                  tabs={[
                    {
                      id: 'devices',
                      label: 'Devices',
                      dim: 'Device',
                      metric: 'Decisions',
                      noun: 'devices',
                      rows: Object.entries(c.devices).map(([key, n]) => ({ key, label: titleCase(key), n })),
                    },
                  ]}
                />
                <AnalyticsRankCard
                  ariaLabel="Countries"
                  tabs={[
                    {
                      id: 'countries',
                      label: 'Countries',
                      dim: 'Country',
                      metric: 'Decisions',
                      noun: 'countries',
                      rows: c.countries.map((r) => {
                        const { flag, name } = countryLabel(r.code);
                        return { key: r.code, label: `${flag ? `${flag} ` : ''}${name}`, n: r.count };
                      }),
                    },
                  ]}
                />
              </div>
            </>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
