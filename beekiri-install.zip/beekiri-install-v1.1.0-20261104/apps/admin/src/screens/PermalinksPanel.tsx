import { useEffect, useMemo, useRef, useState, type DragEvent, type ReactNode } from 'react';
import {
  ArrowLineLeft,
  ArrowLineRight,
  ArrowSquareOut,
  CaretDown,
  CaretRight,
  Check,
  DotsSixVertical,
  Eye,
  EyeSlash,
  FileText,
  House,
  LinkSimple,
  MagnifyingGlass,
  Newspaper,
  Plus,
  Translate,
  Trash,
} from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { SITE_URL as LIVE } from '../config';
import './permalinks-panel.css';

export type MenuItem = {
  id: string;
  label: string;
  path: string;
  enabled: boolean;
  source?: 'home' | 'page' | 'post' | 'taxonomy' | 'custom' | 'languages';
  refId?: string;
  children?: MenuItem[];
};

export type PermalinkStructure = 'plain' | 'postname' | 'dayname' | 'custom';

type LinkTarget = {
  id: string;
  label: string;
  path: string;
  source: 'home' | 'page' | 'post' | 'taxonomy' | 'custom';
  kind?: string;
};

type LinkTargetsResponse = {
  system: LinkTarget[];
  pages: LinkTarget[];
  posts: LinkTarget[];
  taxonomies: LinkTarget[];
};

type Props = {
  siteTitle: string;
  permalinkStructure: PermalinkStructure;
  permalinkCustom: string;
  menuItems: MenuItem[];
  busy: boolean;
  onSave: (data: {
    permalinkStructure: PermalinkStructure;
    permalinkCustom: string;
    menuItems: MenuItem[];
    frontPageId?: string;
    frontPageSlug?: string;
  }) => void;
};

type SourceTab = 'pages' | 'posts' | 'custom' | 'languages';

/** Settings → Translation switcher; the site expands it into one link per language. */
const LANGUAGE_PATH = '#bk-lang';
type DropPos = 'before' | 'after' | 'inside';

/** Menus deeper than this are hard to use on phones. */
const MAX_DEPTH = 3;

/* ── Tree helpers ───────────────────────────────────────────────────────── */

function uid() {
  return `item-${Math.random().toString(36).slice(2, 9)}`;
}

function toSlug(label: string): string {
  return label
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .replace(/-{2,}/g, '-');
}

function cleanPath(path: string): string {
  let p = path.trim();
  if (!p || p === '/') return '/';
  if (/^https?:\/\//i.test(p) || p.startsWith('#') || /^(mailto|tel):/i.test(p)) return p;
  if (!p.startsWith('/')) p = `/${p}`;
  return p.replace(/\/+$/, '') || '/';
}

const isExternal = (p: string) => /^(https?:|mailto:|tel:)/i.test(p);
const isFront = (item: MenuItem) => cleanPath(item.path || '/') === '/';

/** The URL a custom item gets when its path follows its label + parent. */
function autoPath(label: string, parentPath: string | null): string {
  const slug = toSlug(label) || 'link';
  const base = parentPath && cleanPath(parentPath) !== '/' && !isExternal(parentPath) ? cleanPath(parentPath) : '';
  return cleanPath(`${base}/${slug}`);
}

type Located = { item: MenuItem; parent: MenuItem | null; siblings: MenuItem[]; index: number; depth: number };

function locate(items: MenuItem[], id: string, parent: MenuItem | null = null, depth = 0): Located | null {
  for (let i = 0; i < items.length; i++) {
    const item = items[i]!;
    if (item.id === id) return { item, parent, siblings: items, index: i, depth };
    const hit = item.children?.length ? locate(item.children, id, item, depth + 1) : null;
    if (hit) return hit;
  }
  return null;
}

function mapTree(items: MenuItem[], fn: (item: MenuItem) => MenuItem): MenuItem[] {
  return items.map((item) => {
    const next = fn(item);
    return next.children?.length ? { ...next, children: mapTree(next.children, fn) } : next;
  });
}

function removeById(items: MenuItem[], id: string): { tree: MenuItem[]; removed: MenuItem | null } {
  let removed: MenuItem | null = null;
  const walk = (list: MenuItem[]): MenuItem[] =>
    list
      .filter((item) => {
        if (item.id === id) {
          removed = item;
          return false;
        }
        return true;
      })
      .map((item) => (item.children?.length ? { ...item, children: walk(item.children) } : item));
  return { tree: walk(items), removed };
}

function insertAt(items: MenuItem[], parentId: string | null, index: number, node: MenuItem): MenuItem[] {
  if (parentId === null) {
    const copy = [...items];
    copy.splice(Math.max(0, Math.min(index, copy.length)), 0, node);
    return copy;
  }
  return items.map((item) => {
    if (item.id === parentId) {
      const kids = [...(item.children ?? [])];
      kids.splice(Math.max(0, Math.min(index, kids.length)), 0, node);
      return { ...item, children: kids };
    }
    return item.children?.length ? { ...item, children: insertAt(item.children, parentId, index, node) } : item;
  });
}

function depthOf(item: MenuItem): number {
  return 1 + Math.max(0, ...(item.children ?? []).map(depthOf));
}

function count(items: MenuItem[]): number {
  return items.reduce((n, i) => n + 1 + count(i.children ?? []), 0);
}

/**
 * Custom links whose URL was derived from the old parent follow the move
 * (e.g. /services/seo → /about/seo). Page/post links and hand-edited URLs keep theirs.
 */
function rebase(node: MenuItem, oldParentPath: string | null, newParentPath: string | null): MenuItem {
  const followed = (node.source === 'custom' || !node.source) && cleanPath(node.path) === autoPath(node.label, oldParentPath);
  const path = followed ? autoPath(node.label, newParentPath) : node.path;
  return {
    ...node,
    path,
    children: node.children?.map((c) => rebase(c, node.path, path)),
  };
}

/** Move `id` relative to `targetId`; returns null when not allowed. */
function moveNode(items: MenuItem[], id: string, targetId: string, pos: DropPos): MenuItem[] | null {
  if (id === targetId) return null;
  const from = locate(items, id);
  const to = locate(items, targetId);
  if (!from || !to) return null;
  if (locate(from.item.children ?? [], targetId)) return null; // into own subtree
  const newParent = pos === 'inside' ? to.item : to.parent;
  const newDepth = pos === 'inside' ? to.depth + 1 : to.depth;
  if (newDepth + depthOf(from.item) > MAX_DEPTH) return null;
  if (isFront(from.item) && newParent) return null; // front page stays top-level
  const { tree, removed } = removeById(items, id);
  if (!removed) return null;
  const node = rebase(removed, from.parent?.path ?? null, newParent?.path ?? null);
  if (pos === 'inside') return insertAt(tree, to.item.id, (to.item.children ?? []).length, node);
  const after = locate(tree, targetId)!;
  return insertAt(tree, after.parent?.id ?? null, after.index + (pos === 'after' ? 1 : 0), node);
}

function fullUrl(path: string) {
  if (isExternal(path)) return path;
  return `${LIVE.replace(/\/$/, '')}${path.startsWith('/') ? path : `/${path}`}`;
}

const SOURCE_ICON = {
  home: House,
  page: FileText,
  post: Newspaper,
  taxonomy: LinkSimple,
  custom: LinkSimple,
  languages: Translate,
} as const;

const SOURCE_LABEL = { home: 'Home', page: 'Page', post: 'Post', taxonomy: 'Term', custom: 'Link', languages: 'Languages' } as const;

/* ── Component ──────────────────────────────────────────────────────────── */

export function PermalinksPanel({
  siteTitle,
  permalinkStructure,
  permalinkCustom,
  menuItems: initialMenu,
  busy,
  onSave,
}: Props) {
  const [menu, setMenu] = useState<MenuItem[]>(initialMenu);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const [tab, setTab] = useState<SourceTab>('pages');
  const [targets, setTargets] = useState<LinkTargetsResponse | null>(null);
  const [targetsError, setTargetsError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const [customLabel, setCustomLabel] = useState('');
  const [customUrl, setCustomUrl] = useState('');
  const [drag, setDrag] = useState<{ id: string } | null>(null);
  const [hint, setHint] = useState<{ id: string; pos: DropPos } | null>(null);
  const [flash, setFlash] = useState<string | null>(null);
  /** Remember the slug before an item was promoted to `/` so Save can wire the CMS page. */
  const frontSlugById = useRef<Record<string, string>>({});
  const savedJson = useRef(JSON.stringify(initialMenu));

  const dirty = JSON.stringify(menu) !== savedJson.current;

  useEffect(() => {
    api<LinkTargetsResponse>('/api/site/link-targets')
      .then(setTargets)
      .catch((e) => setTargetsError(e instanceof ApiError ? e.message : 'Could not load your content.'));
  }, []);

  // Leaving with unsaved menu edits asks first.
  useEffect(() => {
    if (!dirty) return;
    const onBefore = (e: BeforeUnloadEvent) => {
      e.preventDefault();
    };
    window.addEventListener('beforeunload', onBefore);
    return () => window.removeEventListener('beforeunload', onBefore);
  }, [dirty]);

  const linked = useMemo(() => {
    const ids = new Set<string>();
    const walk = (list: MenuItem[]) =>
      list.forEach((i) => {
        if (i.refId) ids.add(`${i.source}:${i.refId}`);
        if (i.children) walk(i.children);
      });
    walk(menu);
    // The home link has no page id — any item served at `/` counts as linking it.
    if (menu.some(isFront)) ids.add('home:home');
    return ids;
  }, [menu]);

  const selected = selectedId ? locate(menu, selectedId) : null;

  const pulse = (id: string) => {
    setFlash(id);
    window.setTimeout(() => setFlash((f) => (f === id ? null : f)), 900);
  };

  /** New items land inside the selected item (if it has room), otherwise at the end of the top level. */
  const addItems = (nodes: MenuItem[]) => {
    if (!nodes.length) return;
    const target = selected && selected.depth + 1 < MAX_DEPTH ? selected.item : null;
    let next = menu;
    for (const n of nodes) {
      const node = target ? { ...n, path: n.source === 'custom' ? autoPath(n.label, target.path) : n.path } : n;
      next = target ? insertAt(next, target.id, (target.children ?? []).length + 99, node) : [...next, node];
    }
    setMenu(next);
    if (target) setCollapsed((c) => ({ ...c, [target.id]: false }));
    pulse(nodes[nodes.length - 1]!.id);
  };

  const addTargets = (list: LinkTarget[]) =>
    addItems(
      list.map((t) => ({
        id: uid(),
        label: t.label,
        path: cleanPath(t.path),
        enabled: true,
        source: t.source,
        refId: t.id,
      })),
    );

  const addCustom = () => {
    const label = customLabel.trim();
    if (!label) return;
    const url = customUrl.trim();
    addItems([
      {
        id: uid(),
        label,
        path: url ? cleanPath(url) : autoPath(label, null),
        enabled: true,
        source: 'custom',
      },
    ]);
    setCustomLabel('');
    setCustomUrl('');
  };

  const update = (id: string, patch: Partial<MenuItem>) =>
    setMenu(mapTree(menu, (i) => (i.id === id ? { ...i, ...patch } : i)));

  const onLabel = (loc: Located, label: string) => {
    const follows =
      (loc.item.source === 'custom' || !loc.item.source) &&
      !isFront(loc.item) &&
      cleanPath(loc.item.path) === autoPath(loc.item.label, loc.parent?.path ?? null);
    update(loc.item.id, follows ? { label, path: autoPath(label, loc.parent?.path ?? null) } : { label });
  };

  const remove = (id: string) => {
    const loc = locate(menu, id);
    if (!loc || isFront(loc.item)) return;
    setMenu(removeById(menu, id).tree);
    setSelectedId(null);
  };

  const setFront = (id: string) => {
    const loc = locate(menu, id);
    if (!loc || loc.parent) return;
    const prev = cleanPath(loc.item.path || '/');
    const slug = (prev !== '/' ? prev.replace(/^\//, '').split('/')[0] : '') || toSlug(loc.item.label);
    if (slug) frontSlugById.current[id] = slug;
    setMenu(
      menu.map((item) => {
        if (item.id === id) return { ...item, path: '/', source: item.source === 'custom' ? 'home' : item.source || 'home' };
        if (isFront(item)) {
          return { ...item, path: cleanPath(`/${toSlug(item.label) || 'page'}`), source: item.source === 'home' ? 'page' : item.source };
        }
        return item;
      }),
    );
  };

  const shift = (id: string, dir: -1 | 1) => {
    const loc = locate(menu, id);
    if (!loc) return;
    const target = loc.siblings[loc.index + dir];
    if (!target) return;
    const next = moveNode(menu, id, target.id, dir < 0 ? 'before' : 'after');
    if (next) setMenu(next);
  };

  const indent = (id: string) => {
    const loc = locate(menu, id);
    const prev = loc ? loc.siblings[loc.index - 1] : null;
    if (!loc || !prev) return;
    const next = moveNode(menu, id, prev.id, 'inside');
    if (next) {
      setMenu(next);
      setCollapsed((c) => ({ ...c, [prev.id]: false }));
    }
  };

  const outdent = (id: string) => {
    const loc = locate(menu, id);
    if (!loc?.parent) return;
    const next = moveNode(menu, id, loc.parent.id, 'after');
    if (next) setMenu(next);
  };

  const save = () => {
    const front = menu.find(isFront);
    const frontPageSlug = front
      ? frontSlugById.current[front.id] ||
        toSlug(front.label) ||
        (front.path && front.path !== '/' ? front.path.replace(/^\//, '').split('/').filter(Boolean)[0] : '') ||
        undefined
      : undefined;
    onSave({
      permalinkStructure,
      permalinkCustom,
      menuItems: menu,
      frontPageId: front?.refId || undefined,
      frontPageSlug: frontPageSlug || undefined,
    });
    savedJson.current = JSON.stringify(menu);
  };

  /* ── Drag & drop ──────────────────────────────────────────────────────── */

  const resolvePos = (e: DragEvent<HTMLElement>, targetId: string): DropPos | null => {
    if (!drag || drag.id === targetId) return null;
    const r = e.currentTarget.getBoundingClientRect();
    const y = (e.clientY - r.top) / Math.max(1, r.height);
    const x = e.clientX - r.left;
    const pos: DropPos = y < 0.3 ? 'before' : y > 0.7 && x < 60 ? 'after' : y > 0.5 && x >= 60 ? 'inside' : y > 0.7 ? 'after' : 'inside';
    return moveNode(menu, drag.id, targetId, pos) ? pos : null;
  };

  const rowDrag = (id: string) => ({
    draggable: true,
    onDragStart: (e: DragEvent<HTMLElement>) => {
      e.dataTransfer.setData('text/plain', id);
      e.dataTransfer.effectAllowed = 'move';
      setDrag({ id });
    },
    onDragEnd: () => {
      setDrag(null);
      setHint(null);
    },
    onDragOver: (e: DragEvent<HTMLElement>) => {
      const pos = resolvePos(e, id);
      if (!pos) {
        if (hint?.id === id) setHint(null);
        return;
      }
      e.preventDefault();
      if (hint?.id !== id || hint.pos !== pos) setHint({ id, pos });
    },
    onDrop: (e: DragEvent<HTMLElement>) => {
      e.preventDefault();
      const pos = resolvePos(e, id);
      if (drag && pos) {
        const next = moveNode(menu, drag.id, id, pos);
        if (next) {
          setMenu(next);
          if (pos === 'inside') setCollapsed((c) => ({ ...c, [id]: false }));
          pulse(drag.id);
        }
      }
      setDrag(null);
      setHint(null);
    },
  });

  /* ── Render ───────────────────────────────────────────────────────────── */

  const sourceList = (): LinkTarget[] => {
    if (!targets) return [];
    const q = query.trim().toLowerCase();
    const base =
      tab === 'pages'
        ? [...targets.system.filter((s) => s.path === '/'), ...targets.pages]
        : [...targets.system.filter((s) => s.path === '/blog'), ...targets.posts];
    return q ? base.filter((t) => `${t.label} ${t.path}`.toLowerCase().includes(q)) : base;
  };

  const renderRows = (items: MenuItem[], depth: number): ReactNode[] =>
    items.flatMap((item, index) => {
      const kids = item.children ?? [];
      const open = !collapsed[item.id];
      const Icon = SOURCE_ICON[item.source ?? 'custom'] ?? LinkSimple;
      const isSel = selectedId === item.id;
      const h = hint?.id === item.id ? hint.pos : null;
      const loc = { item, depth, index, siblings: items };
      const row = (
        <li
          key={item.id}
          className={[
            'bk-nav__row',
            isSel ? 'is-selected' : '',
            !item.enabled ? 'is-hidden' : '',
            drag?.id === item.id ? 'is-dragging' : '',
            flash === item.id ? 'is-flash' : '',
            depth > 0 ? 'is-nested' : '',
            h ? `is-drop-${h}` : '',
          ]
            .filter(Boolean)
            .join(' ')}
          style={{ ['--depth' as string]: depth }}
          {...rowDrag(item.id)}
        >
          <button
            type="button"
            className="bk-nav__row-main"
            onClick={() => setSelectedId(isSel ? null : item.id)}
            aria-expanded={isSel}
          >
            <span className="bk-nav__grip" aria-hidden>
              <DotsSixVertical size={14} weight="bold" />
            </span>
            <span
              className="bk-nav__caret"
              onClick={(e) => {
                if (!kids.length) return;
                e.stopPropagation();
                setCollapsed((c) => ({ ...c, [item.id]: open }));
              }}
            >
              {kids.length ? open ? <CaretDown size={11} weight="bold" /> : <CaretRight size={11} weight="bold" /> : null}
            </span>
            <span className={`bk-nav__icon is-${item.source ?? 'custom'}`} aria-hidden>
              <Icon size={14} />
            </span>
            <span className="bk-nav__text">
              <span className="bk-nav__label">{item.label || 'Untitled'}</span>
              <span className="bk-nav__path">
                {item.source === 'languages' ? 'Language switcher — one link per enabled language' : item.path || '/'}
              </span>
            </span>
            {isFront(item) ? <span className="bk-nav__badge is-front">Home page</span> : null}
            {!item.enabled ? <span className="bk-nav__badge">Hidden</span> : null}
            <span className="bk-nav__badge is-type">{SOURCE_LABEL[item.source ?? 'custom']}</span>
          </button>

          {isSel ? (
            <div className="bk-nav__editor" onClick={(e) => e.stopPropagation()}>
              <div className="bk-nav__fields">
                <label className="bk-field">
                  <span>Navigation label</span>
                  <input type="text" value={item.label} onChange={(e) => onLabel(locate(menu, item.id) ?? (loc as Located), e.target.value)} autoFocus />
                </label>
                {item.source === 'languages' ? null : (
                <label className="bk-field">
                  <span>URL</span>
                  <input
                    type="text"
                    value={item.path}
                    disabled={isFront(item)}
                    onChange={(e) => update(item.id, { path: cleanPath(e.target.value || '/'), source: item.source === 'page' || item.source === 'post' ? item.source : 'custom' })}
                    placeholder="/about or https://…"
                  />
                </label>
                )}
              </div>
              {item.source === 'languages' ? (
                <p className="bk-nav__note">
                  Use <code>{'{current}'}</code> in the label to show the active language. Languages are managed in
                  Settings → Translation.
                </p>
              ) : null}
              {item.source === 'page' || item.source === 'post' ? (
                <p className="bk-nav__note">
                  Linked to the {item.source} “{item.label}”. Editing the URL here only changes this menu link.
                </p>
              ) : null}
              <div className="bk-nav__editor-actions">
                <button type="button" className="bk-nav__chip" onClick={() => update(item.id, { enabled: !item.enabled })}>
                  {item.enabled ? <EyeSlash size={13} /> : <Eye size={13} />}
                  {item.enabled ? 'Hide from menu' : 'Show in menu'}
                </button>
                {depth === 0 && !isFront(item) ? (
                  <button type="button" className="bk-nav__chip" onClick={() => setFront(item.id)}>
                    <House size={13} /> Make home page
                  </button>
                ) : null}
                <button type="button" className="bk-nav__chip" disabled={index === 0} onClick={() => indent(item.id)} title="Nest under the item above">
                  <ArrowLineRight size={13} /> Indent
                </button>
                <button type="button" className="bk-nav__chip" disabled={depth === 0} onClick={() => outdent(item.id)} title="Move out one level">
                  <ArrowLineLeft size={13} /> Outdent
                </button>
                {!isExternal(item.path) && item.source !== 'languages' ? (
                  <a className="bk-nav__chip" href={fullUrl(item.path || '/')} target="_blank" rel="noreferrer">
                    <ArrowSquareOut size={13} /> Open
                  </a>
                ) : null}
                <button
                  type="button"
                  className="bk-nav__chip is-danger"
                  disabled={isFront(item)}
                  title={isFront(item) ? 'Make another item the home page first' : undefined}
                  onClick={() => remove(item.id)}
                >
                  <Trash size={13} /> Remove
                </button>
              </div>
            </div>
          ) : null}
        </li>
      );
      return [row, ...(kids.length && open ? renderRows(kids, depth + 1) : [])];
    });

  const list = tab === 'languages' ? [] : sourceList();
  const hasLanguageItem = (function has(items: MenuItem[]): boolean {
    return items.some((i) => i.source === 'languages' || has(i.children ?? []));
  })(menu);
  const pickable = list.filter((t) => !linked.has(`${t.source}:${t.id}`));
  const addLabel = selected && selected.depth + 1 < MAX_DEPTH ? `inside “${selected.item.label}”` : 'to the menu';

  return (
    <div className="bk-nav">
      <div className="bk-nav__bar">
        <div>
          <h2>Navigation</h2>
          <p>
            Build the main menu for {siteTitle || 'your site'}. Drag to reorder, drop onto an item to nest it (up to {MAX_DEPTH}{' '}
            levels).
          </p>
        </div>
        <div className="bk-nav__bar-actions">
          {dirty ? <span className="bk-nav__dirty">Unsaved changes</span> : <span className="bk-nav__saved"><Check size={12} weight="bold" /> Saved</span>}
          {dirty ? (
            <button type="button" className="button" onClick={() => { setMenu(JSON.parse(savedJson.current) as MenuItem[]); setSelectedId(null); }}>
              Discard
            </button>
          ) : null}
          <button type="button" className="button button-primary" disabled={busy || !dirty} onClick={save}>
            {busy ? 'Saving…' : 'Save menu'}
          </button>
        </div>
      </div>

      <div className="bk-nav__layout">
        {/* ── Sources ─────────────────────────────────────────────────── */}
        <aside className="bk-nav__sources">
          <div className="bk-nav__tabs" role="tablist">
            {(
              [
                ['pages', 'Pages'],
                ['posts', 'Posts'],
                ['custom', 'Custom link'],
                ['languages', 'Languages'],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={tab === id}
                className={tab === id ? 'is-active' : ''}
                onClick={() => {
                  setTab(id);
                  setPicked(new Set());
                  setQuery('');
                }}
              >
                {label}
              </button>
            ))}
          </div>

          {tab === 'languages' ? (
            <div className="bk-nav__custom">
              <p className="bk-nav__note">
                Adds a dropdown with every language enabled in Settings → Translation. Each link opens the page the
                visitor is on, in that language.
              </p>
              <p className="bk-nav__note">
                The label <code>{'{current}'}</code> shows the active language (e.g. Deutsch). Any other text works too.
              </p>
              <button
                type="button"
                className="button button-primary"
                disabled={hasLanguageItem}
                onClick={() =>
                  addItems([
                    { id: uid(), label: '{current}', path: LANGUAGE_PATH, enabled: true, source: 'languages' },
                  ])
                }
              >
                <Plus size={13} weight="bold" /> {hasLanguageItem ? 'Already in the menu' : `Add language switcher ${addLabel}`}
              </button>
            </div>
          ) : tab === 'custom' ? (
            <form
              className="bk-nav__custom"
              onSubmit={(e) => {
                e.preventDefault();
                addCustom();
              }}
            >
              <label className="bk-field">
                <span>Label</span>
                <input type="text" value={customLabel} onChange={(e) => setCustomLabel(e.target.value)} placeholder="Contact" />
              </label>
              <label className="bk-field">
                <span>URL</span>
                <input
                  type="text"
                  value={customUrl}
                  onChange={(e) => setCustomUrl(e.target.value)}
                  placeholder={customLabel ? autoPath(customLabel, selected && selected.depth + 1 < MAX_DEPTH ? selected.item.path : null) : '/contact or https://…'}
                />
              </label>
              <p className="bk-nav__note">Leave the URL empty to generate it from the label. External links work too.</p>
              <button type="submit" className="button button-primary" disabled={!customLabel.trim()}>
                <Plus size={13} weight="bold" /> Add {addLabel}
              </button>
            </form>
          ) : (
            <>
              <label className="bk-nav__search">
                <MagnifyingGlass size={13} aria-hidden />
                <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder={`Search ${tab}…`} />
              </label>
              <div className="bk-nav__source-list">
                {targetsError ? (
                  <p className="bk-nav__note">{targetsError}</p>
                ) : !targets ? (
                  <p className="bk-nav__note">Loading…</p>
                ) : list.length === 0 ? (
                  <p className="bk-nav__note">
                    {query ? `Nothing matches “${query}”.` : `No published ${tab} yet — publish one, or add a custom link.`}
                  </p>
                ) : (
                  list.map((t) => {
                    const inMenu = linked.has(`${t.source}:${t.id}`);
                    const key = `${t.source}:${t.id}`;
                    const on = picked.has(key);
                    return (
                      <label key={key} className={`bk-nav__source${inMenu ? ' is-in' : ''}${on ? ' is-on' : ''}`}>
                        <input
                          type="checkbox"
                          checked={on}
                          disabled={inMenu}
                          onChange={() =>
                            setPicked((p) => {
                              const n = new Set(p);
                              if (n.has(key)) n.delete(key);
                              else n.add(key);
                              return n;
                            })
                          }
                        />
                        <span className="bk-nav__source-box" aria-hidden>
                          {on || inMenu ? <Check size={10} weight="bold" /> : null}
                        </span>
                        <span className="bk-nav__source-text">
                          <span>{t.label}</span>
                          <em>{t.path}</em>
                        </span>
                        {inMenu ? <span className="bk-nav__badge">In menu</span> : null}
                      </label>
                    );
                  })
                )}
              </div>
              <div className="bk-nav__source-foot">
                <button
                  type="button"
                  className="bk-nav__link"
                  disabled={!pickable.length}
                  onClick={() => setPicked(picked.size === pickable.length ? new Set() : new Set(pickable.map((t) => `${t.source}:${t.id}`)))}
                >
                  {picked.size && picked.size === pickable.length ? 'Clear' : 'Select all'}
                </button>
                <button
                  type="button"
                  className="button button-primary"
                  disabled={!picked.size}
                  onClick={() => {
                    addTargets(list.filter((t) => picked.has(`${t.source}:${t.id}`)));
                    setPicked(new Set());
                  }}
                >
                  <Plus size={13} weight="bold" /> Add {picked.size || ''} {addLabel}
                </button>
              </div>
            </>
          )}
        </aside>

        {/* ── Structure ───────────────────────────────────────────────── */}
        <section className="bk-nav__structure">
          <div className="bk-nav__structure-head">
            <h3>Menu structure</h3>
            <span>
              {count(menu)} item{count(menu) === 1 ? '' : 's'}
            </span>
          </div>
          {menu.length ? (
            <ul className="bk-nav__tree" onDragLeave={(e) => !e.currentTarget.contains(e.relatedTarget as Node) && setHint(null)}>
              {renderRows(menu, 0)}
            </ul>
          ) : (
            <div className="bk-nav__empty">
              <strong>Your menu is empty</strong>
              <span>Pick pages on the left, or add a custom link.</span>
            </div>
          )}
          <p className="bk-nav__help">
            Click an item to edit it. Select an item first and new links are added inside it. Use ↑ ↓ on a selected row to
            reorder without dragging.
          </p>
          {selected ? (
            <KeyboardMoves onMove={(d) => shift(selected.item.id, d)} onIndent={() => indent(selected.item.id)} onOutdent={() => outdent(selected.item.id)} />
          ) : null}
        </section>
      </div>
    </div>
  );
}

/** Alt+arrows reorder / nest the selected item (when focus isn't in a text field). */
function KeyboardMoves({ onMove, onIndent, onOutdent }: { onMove: (d: -1 | 1) => void; onIndent: () => void; onOutdent: () => void }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA') return;
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        onMove(-1);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        onMove(1);
      } else if (e.key === 'ArrowRight' && e.altKey) {
        e.preventDefault();
        onIndent();
      } else if (e.key === 'ArrowLeft' && e.altKey) {
        e.preventDefault();
        onOutdent();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onMove, onIndent, onOutdent]);
  return null;
}
