import { Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { useCallback, useEffect, useState } from 'react';
import type { CapabilitySlug } from './cms-types';
import { api, ApiError } from './api/client';
import { useAuth } from './auth/AuthContext';
import { PageHeader } from './components/PageHeader';
import { SiteEnterCover } from './components/SiteEnterCover';
import {
  AdminEntryProvider,
  useAdminEntry,
  type AdminEntry,
} from './lib/AdminEntryContext';
import { canAccessSettings } from './lib/admin-capabilities';
import {
  DEFAULT_ADMIN_BASE_PATH,
  DEFAULT_ADMIN_LOGIN_SLUG,
  adminHref,
  adminLoginPath,
  normalizeAdminBasePath,
  normalizeAdminLoginSlug,
} from './lib/admin-login';
import { InstallWizard } from './screens/InstallWizard';
import { LoginScreen } from './screens/LoginScreen';
import { LostPasswordScreen } from './screens/LostPasswordScreen';
import { ResetPasswordScreen } from './screens/ResetPasswordScreen';
import { ApiUnavailable } from './screens/ApiUnavailable';
import { AdminShell } from './shell/AdminShell';
import { AnalyticsPage } from './screens/AnalyticsPage';
import { BeeCookiesPage } from './screens/BeeCookiesPage';
import { HeatmapPage } from './screens/HeatmapPage';
import { ConnectorPage } from './screens/ConnectorPage';
import { ExtensionsDirectoryPage, ExtensionsPage } from './screens/ExtensionsPage';
import { SeoPage } from './screens/SeoPage';
import { Dashboard } from './screens/Dashboard';
import { PlaceholderScreen } from './screens/PlaceholderScreen';
import { SettingsPage } from './screens/SettingsPage';
import { UserEditPage } from './screens/UserEditPage';
import { UsersPage } from './screens/UsersPage';
import { UserPermissionsPage } from './screens/UserPermissionsPage';
import { MediaPage } from './screens/MediaPage';
import { AppearancePage } from './screens/AppearancePage';
import { AppearanceHeaderPage } from './screens/AppearanceHeaderPage';
import { AppearanceFooterPage } from './screens/AppearanceFooterPage';
import { AppearanceTemplatesPage } from './screens/AppearanceTemplatesPage';
import { CptListPage, PagesPage, PostsPage } from './screens/PagesPage';
import {
  CptEditorPage,
  CptNewRedirect,
  PageEditorPage,
  PageNewRedirect,
  PostEditorPage,
  PostNewRedirect,
  ShopPageEditorPage,
} from './screens/PageEditorPage';
import { BackendFieldsPage } from './screens/BackendFieldsPage';
import { PostTypesPage } from './screens/fields/PostTypesPage';
import { TaxonomiesPage } from './screens/fields/TaxonomiesPage';
import { OptionsPagesPage } from './screens/fields/OptionsPagesPage';
import { FieldsSettingsPage } from './screens/fields/FieldsSettingsPage';
import { FieldsToolsPage } from './screens/fields/FieldsToolsPage';
import { FieldGroupEditPage } from './screens/fields/FieldGroupEditPage';
import { ShopOverviewPage } from './screens/shop/ShopOverviewPage';
import { ProductsPage } from './screens/shop/ProductsPage';
import { ProductEditPage, ProductNewRedirect } from './screens/shop/ProductEditPage';
import { ProductCategoriesPage, ProductTagsPage } from './screens/shop/ProductTermsPage';
import { OrdersPage } from './screens/shop/OrdersPage';
import { OrderDetailPage } from './screens/shop/OrderDetailPage';
import { CustomersPage } from './screens/shop/CustomersPage';
import { CouponEditPage, CouponsPage } from './screens/shop/CouponsPage';
import { ShopSettingsPage } from './screens/shop/ShopSettingsPage';
import { ShopPagesPage } from './screens/shop/ShopPagesPage';
import { useActiveExtensionsState, SHOPPING_EXTENSION } from './lib/extensions-state';
import { canAccessShop } from './lib/admin-capabilities';

/** Kill any .php / wp-* URL immediately — product has zero PHP routes. */
function StripLegacyPaths({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const path = location.pathname.toLowerCase();
  const entry = useAdminEntry();

  if (path.includes('.php') || path.startsWith('/wp-') || path === '/wp-admin') {
    const toAdmin = path.includes('admin') || path.includes('upload') || path.includes('edit');
    return <Navigate to={toAdmin ? entry.basePath : entry.path} replace />;
  }

  return <>{children}</>;
}

type InstallState = 'loading' | 'installed' | 'not_installed' | 'api_down';

type EntrySource = { adminBasePath?: string; adminLoginSlug?: string; adminLoginPath?: string };

/** The server writes the admin's own address into the page it serves at that address. */
function injectedEntry(): EntrySource {
  try {
    const raw = document
      .querySelector('meta[name="beekiri-admin-entry"]')
      ?.getAttribute('content');
    if (!raw) return {};
    const parsed = JSON.parse(raw) as { basePath?: unknown; loginSlug?: unknown };
    return {
      adminBasePath: typeof parsed.basePath === 'string' ? parsed.basePath : undefined,
      adminLoginSlug: typeof parsed.loginSlug === 'string' ? parsed.loginSlug : undefined,
    };
  } catch {
    return {};
  }
}

function entryFrom(s: EntrySource): AdminEntry {
  const basePath = normalizeAdminBasePath(s.adminBasePath ?? DEFAULT_ADMIN_BASE_PATH);
  const slug = normalizeAdminLoginSlug(s.adminLoginSlug ?? DEFAULT_ADMIN_LOGIN_SLUG);
  return { basePath, slug, path: s.adminLoginPath?.trim() || adminLoginPath(slug, basePath) };
}

/**
 * Fresh DB → /install.
 * Installed → custom admin login path or /admin (no separate preview landing on the admin host).
 * API down → never treat as “not installed” (would falsely force the installer).
 */
function Gate({ children }: { children: React.ReactNode }) {
  const auth = useAuth();
  const [state, setState] = useState<InstallState>('loading');
  const [apiDetail, setApiDetail] = useState<string | null>(null);
  const [entry, setEntry] = useState<AdminEntry>(() => entryFrom(injectedEntry()));
  const location = useLocation();

  const checkInstall = useCallback(() => {
    setState('loading');
    setApiDetail(null);
    api<{ installed: boolean }>('/api/install/status')
      .then((s) => {
        setState(s.installed ? 'installed' : 'not_installed');
      })
      .catch((e) => {
        setState('api_down');
        // Technical detail is DEV-only (collapsed on the downtime screen).
        // Never surface ports, paths, or CLI commands to clients.
        const raw =
          e instanceof ApiError
            ? e.message
            : e instanceof Error
              ? e.message
              : null;
        const looksTechnical =
          Boolean(raw) &&
          (/port\s*\d+/i.test(raw!) ||
            /pnpm|npx|npm |yarn |docker/i.test(raw!) ||
            /127\.0\.0\.1|localhost:\d+/i.test(raw!));
        setApiDetail(looksTechnical ? null : raw);
      });
  }, []);

  useEffect(() => {
    checkInstall();
  }, [checkInstall, location.pathname]);

  /** Soft-refresh admin base / login path after Settings save — no full Gate loading flash. */
  useEffect(() => {
    const onEntryChanged = (event: Event) => {
      const detail = (event as CustomEvent<EntrySource>).detail;
      if (detail) setEntry(entryFrom(detail));
    };
    window.addEventListener('beekiri:admin-entry-changed', onEntryChanged);
    return () => window.removeEventListener('beekiri:admin-entry-changed', onEntryChanged);
  }, []);

  if (auth.loading || state === 'loading') {
    return (
      <p
        style={{
          padding: 40,
          fontFamily:
            "'SF Pro Text', 'SF Pro Display', -apple-system, BlinkMacSystemFont, 'Helvetica Neue', Helvetica, Arial, sans-serif",
        }}
      >
        Loading…
      </p>
    );
  }

  if (state === 'api_down') {
    return (
      <ApiUnavailable
        detail={apiDetail}
        onRetry={checkInstall}
      />
    );
  }

  if (state === 'not_installed' && !location.pathname.startsWith('/admin/install')) {
    return <Navigate to="/admin/install" replace />;
  }

  if (state === 'installed' && location.pathname.startsWith('/admin/install')) {
    return <Navigate to={entry.basePath} replace />;
  }

  return <AdminEntryProvider value={entry}>{children}</AdminEntryProvider>;
}

function RequireAuth() {
  const auth = useAuth();
  const location = useLocation();
  const entry = useAdminEntry();
  if (auth.loading) return <p style={{ padding: 40 }}>Loading…</p>;
  if (!auth.authenticated) {
    const next = encodeURIComponent(location.pathname + location.search);
    return <Navigate to={`${entry.path}?redirect_to=${next}`} replace />;
  }
  return (
    <AdminShell>
      <Outlet />
    </AdminShell>
  );
}

/** Block a route tree unless the signed-in user has every listed capability. */
function RequireCapability({
  capability,
  redirectTo,
}: {
  capability: CapabilitySlug | CapabilitySlug[];
  /** When set, send unauthorized users here instead of an access-denied page. */
  redirectTo?: string;
}) {
  const auth = useAuth();
  const needed = Array.isArray(capability) ? capability : [capability];
  if (auth.loading) return <p style={{ padding: 40 }}>Loading…</p>;
  const caps = auth.user?.capabilities ?? [];
  const ok = needed.every((c) => caps.includes(c));
  if (!ok) {
    if (redirectTo) return <Navigate to={redirectTo} replace />;
    return (
      <div className="wrap">
        <PageHeader title="Access denied" />
        <div className="beekiri-notice is-error" role="alert">
          <p>You do not have permission to view this page.</p>
        </div>
      </div>
    );
  }
  return <Outlet />;
}

/** Shop screens: the Shopping extension must be active and the user needs a shop capability. */
function RequireShop({ capability }: { capability?: CapabilitySlug }) {
  const auth = useAuth();
  const entry = useAdminEntry();
  const extensions = useActiveExtensionsState();
  if (auth.loading || !extensions.loaded) return <p style={{ padding: 40 }}>Loading…</p>;
  const caps = auth.user?.capabilities ?? [];
  const active = extensions.active.includes(SHOPPING_EXTENSION);
  const ok = active && canAccessShop(caps) && (!capability || caps.includes(capability));
  if (!ok) return <Navigate to={entry.basePath} replace />;
  return <Outlet />;
}

function RequireSettingsAccess() {
  const auth = useAuth();
  const entry = useAdminEntry();
  if (auth.loading) return <p style={{ padding: 40 }}>Loading…</p>;
  if (!canAccessSettings(auth.user?.capabilities)) {
    return <Navigate to={entry.basePath} replace />;
  }
  return <Outlet />;
}

/** Site Owner only (e.g. User Permissions). */
function RequireOwner() {
  const auth = useAuth();
  const entry = useAdminEntry();
  if (auth.loading) return <p style={{ padding: 40 }}>Loading…</p>;
  if (!auth.user?.isOwner) return <Navigate to={entry.basePath} replace />;
  return <Outlet />;
}

/** Admin host root → dashboard when signed in, otherwise login. Public site lives on the web app. */
function HomeRedirect() {
  const auth = useAuth();
  const entry = useAdminEntry();
  if (auth.loading) return <p style={{ padding: 40 }}>Loading…</p>;
  if (auth.authenticated) return <Navigate to={entry.basePath} replace />;
  return <Navigate to={entry.path} replace />;
}

function AppRoutes() {
  const entry = useAdminEntry();
  const base = entry.basePath;
  const home = base;
  const defaultLogin = adminHref(base, DEFAULT_ADMIN_LOGIN_SLUG);
  const lostPassword = adminHref(base, 'lost-password');
  const lostPasswordAlt = adminHref(base, 'lostpassword');
  const resetPassword = adminHref(base, 'reset-password');

  return (
        <Routes>
          {/* Install always under /admin so first-time setup works before a custom base exists. */}
          <Route path="/admin/install/*" element={<InstallWizard />} />
          <Route path={entry.path} element={<LoginScreen />} />
          {entry.path !== defaultLogin ? (
            <Route
              path={defaultLogin}
              element={<PlaceholderScreen title="Not Found" phase="" />}
            />
          ) : null}
          {/* Legacy /admin/login when base moved away from /admin */}
          {base !== DEFAULT_ADMIN_BASE_PATH ? (
            <Route
              path="/admin/login"
              element={<PlaceholderScreen title="Not Found" phase="" />}
            />
          ) : null}
          <Route path={lostPassword} element={<LostPasswordScreen />} />
          <Route path={lostPasswordAlt} element={<Navigate to={lostPassword} replace />} />
          <Route path={resetPassword} element={<ResetPasswordScreen />} />

          <Route path="/" element={<HomeRedirect />} />

          <Route path={base} element={<RequireAuth />}>
            <Route index element={<Dashboard />} />
            <Route
              element={
                <RequireCapability capability="manage_options" redirectTo={home} />
              }
            >
              <Route path="analytics" element={<AnalyticsPage />} />
              <Route path="analytics/heatmap" element={<HeatmapPage />} />
              <Route path="analytics/cookies" element={<BeeCookiesPage />} />
              <Route path="seo" element={<SeoPage />} />
              <Route path="connector" element={<ConnectorPage />} />
              <Route path="extensions" element={<ExtensionsPage />} />
              <Route path="extensions/new" element={<ExtensionsDirectoryPage />} />
              {/* Setup lives on the Connector page now; old provider links land there. */}
              <Route path="connector/:providerId" element={<Navigate to=".." relative="path" replace />} />
            </Route>
            <Route element={<RequireSettingsAccess />}>
              <Route path="settings" element={<SettingsPage />} />
            </Route>
            {/* Shopping extension */}
            <Route element={<RequireShop />}>
              <Route path="shop" element={<ShopOverviewPage />} />
            </Route>
            <Route element={<RequireShop capability="edit_products" />}>
              <Route path="shop/products" element={<ProductsPage />} />
              <Route path="shop/products/new" element={<ProductNewRedirect />} />
              <Route path="shop/products/:id" element={<ProductEditPage />} />
              <Route path="shop/categories" element={<ProductCategoriesPage />} />
              <Route path="shop/tags" element={<ProductTagsPage />} />
              <Route path="shop/pages" element={<ShopPagesPage />} />
              <Route path="shop/pages/:id" element={<ShopPageEditorPage />} />
            </Route>
            <Route element={<RequireShop capability="edit_shop_orders" />}>
              <Route path="shop/orders" element={<OrdersPage />} />
              <Route path="shop/orders/:id" element={<OrderDetailPage />} />
              <Route path="shop/customers" element={<CustomersPage />} />
              <Route path="shop/coupons" element={<CouponsPage />} />
              <Route path="shop/coupons/new" element={<CouponEditPage key="new" />} />
              <Route path="shop/coupons/:id" element={<CouponEditPage />} />
            </Route>
            <Route element={<RequireShop capability="manage_shop" />}>
              <Route path="shop/settings" element={<ShopSettingsPage />} />
            </Route>
            <Route
              element={<RequireCapability capability="edit_posts" redirectTo={home} />}
            >
              <Route path="posts" element={<PostsPage />} />
              <Route path="posts/new" element={<PostNewRedirect />} />
              <Route path="posts/:id" element={<PostEditorPage />} />
              <Route path="content/:type" element={<CptListPage />} />
              <Route path="content/:type/new" element={<CptNewRedirect />} />
              <Route path="content/:type/:id" element={<CptEditorPage />} />
            </Route>
            <Route
              element={<RequireCapability capability="edit_pages" redirectTo={home} />}
            >
              <Route path="pages" element={<PagesPage />} />
              <Route path="pages/new" element={<PageNewRedirect />} />
              <Route path="pages/:id" element={<PageEditorPage />} />
            </Route>
            <Route
              element={<RequireCapability capability="upload_files" redirectTo={home} />}
            >
              <Route path="media" element={<MediaPage />} />
            </Route>
            <Route
              element={<RequireCapability capability="manage_fields" redirectTo={home} />}
            >
              <Route path="fields" element={<BackendFieldsPage />} />
              <Route path="fields/post-types" element={<PostTypesPage />} />
              <Route path="fields/post-types/:id" element={<PostTypesPage />} />
              <Route path="fields/taxonomies" element={<TaxonomiesPage />} />
              <Route path="fields/taxonomies/:id" element={<TaxonomiesPage />} />
              <Route path="fields/options-pages" element={<OptionsPagesPage />} />
              <Route path="fields/options-pages/:id" element={<OptionsPagesPage />} />
              <Route path="fields/settings" element={<FieldsSettingsPage />} />
              <Route path="fields/tools" element={<FieldsToolsPage />} />
              <Route path="fields/new" element={<FieldGroupEditPage key="new" />} />
              <Route path="fields/:id" element={<FieldGroupEditPage />} />
            </Route>
            <Route
              element={
                <RequireCapability capability="edit_theme_options" redirectTo={home} />
              }
            >
              <Route path="appearance" element={<AppearancePage />} />
              <Route path="appearance/header" element={<AppearanceHeaderPage />} />
              <Route path="appearance/footer" element={<AppearanceFooterPage />} />
              <Route path="appearance/templates" element={<AppearanceTemplatesPage />} />
            </Route>
            <Route
              element={<RequireCapability capability="list_users" redirectTo={home} />}
            >
              <Route path="users" element={<UsersPage />} />
              <Route path="users/new" element={<UserEditPage key="new" />} />
            </Route>
            <Route element={<RequireOwner />}>
              <Route path="users/permissions" element={<UserPermissionsPage />} />
            </Route>
            {/* Own profile (and permitted edits) — API enforces self-or-cap. */}
            <Route path="users/:id" element={<UserEditPage />} />
            <Route path="*" element={<PlaceholderScreen title="Not Found" phase="" />} />
          </Route>

          <Route path="*" element={<Navigate to={home} replace />} />
        </Routes>
  );
}

export function App() {
  return (
    <Gate>
      <SiteEnterCover />
      <StripLegacyPaths>
        <AppRoutes />
      </StripLegacyPaths>
    </Gate>
  );
}
