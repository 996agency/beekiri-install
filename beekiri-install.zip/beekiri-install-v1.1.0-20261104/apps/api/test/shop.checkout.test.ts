import type { Express } from 'express';
import request from 'supertest';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

/**
 * Shopping extension end to end: install → product → public cart → checkout (cash on
 * delivery) → order, stock, coupon, permissions, storefront guards, webhook rejection.
 * Throwaway database only: createdb beekiri_shop_test && TEST_DB_NAME=beekiri_shop_test npm test
 */
const TEST_DB_NAME = process.env.TEST_DB_NAME;
const ORIGIN = 'http://localhost';

const OWNER = {
  language: 'en_US',
  siteTitle: 'Shop Site',
  username: 'owner',
  password: 'Str0ng!Passw0rd',
  email: 'owner@example.com',
  blogPublic: true,
  frontendRuntime: 'php',
};

type Auth = { cookie: string; csrf: string; id: string };

describe.skipIf(!TEST_DB_NAME)('Shopping extension', () => {
  let app: Express;
  let db: typeof import('../src/db/sequelize');
  let clearRateLimits: () => void;
  let owner: Auth;
  let productId = '';
  let cartCookie = '';
  let orderToken = '';
  let orderId = '';

  const login = async (username: string, password: string): Promise<Auth> => {
    clearRateLimits();
    const res = await request(app).post('/api/auth/login').set('Origin', ORIGIN).send({ login: username, password });
    expect(res.status).toBe(201);
    const setCookie = ([] as string[]).concat(res.headers['set-cookie'] ?? []);
    return { cookie: setCookie[0]!.split(';')[0]!, csrf: res.body.csrfToken, id: res.body.user.id };
  };
  const as = (auth: Auth, req: request.Test) => req.set('Cookie', auth.cookie).set('Origin', ORIGIN).set('X-CSRF-Token', auth.csrf);
  /** A browser request from the storefront script. */
  const shopper = (req: request.Test) =>
    req.set('Origin', ORIGIN).set('X-Beekiri-Shop', '1').set('Cookie', cartCookie ? `beekiri_cart=${cartCookie}` : '');

  beforeAll(async () => {
    Object.assign(process.env, {
      NODE_ENV: 'test',
      DB_NAME: TEST_DB_NAME,
      APP_URL: ORIGIN,
      MEDIA_LOCAL_PATH: '/tmp/beekiri-test-uploads',
      BEEKIRI_SETUP_TOKEN_FILE: `/tmp/beekiri-test-setup-token-${process.pid}`,
    });
    const { runMigrations } = await import('../src/db/migrator');
    db = await import('../src/db/sequelize');
    const models = await import('../src/models');
    ({ clearRateLimits } = await import('../src/utils/rate-limit'));
    const { createApp } = await import('../src/app');
    await runMigrations();
    const tables = Object.values(db.sequelize.models)
      .map((m) => m.getTableName() as string)
      .filter((t) => t !== 'SequelizeMeta')
      .map((t) => `"${t}"`)
      .join(', ');
    await db.sequelize.query(`TRUNCATE ${tables} CASCADE`);
    await models.InstallationState.create({ id: 1, installed: false });
    clearRateLimits();
    app = createApp();
    const setupKey = (await import('../src/lib/setup-token')).ensureSetupToken();
    const install = await request(app).post('/api/install').set('X-Setup-Token', setupKey).send(OWNER);
    expect(install.status).toBe(201);
    const { seedRolesAndCapabilities } = await import('../src/services/install.service');
    const { refreshRoleCapabilityCache } = await import('../src/lib/auth/role-cache');
    await seedRolesAndCapabilities();
    await refreshRoleCapabilityCache();
    owner = await login(OWNER.username, OWNER.password);
  });

  afterAll(async () => {
    await db?.closeDatabase();
  });

  it('is hidden until installed, then installs the product post type and taxonomies', async () => {
    expect((await request(app).get('/api/shop/public/config')).status).toBe(404);
    const list = await as(owner, request(app).get('/api/extensions'));
    expect(list.body.extensions.find((e: { slug: string }) => e.slug === 'shopping').status).toBe('available');

    const installed = await as(owner, request(app).post('/api/extensions/shopping/install'));
    expect(installed.status).toBe(200);
    expect(installed.body.extensions.find((e: { slug: string }) => e.slug === 'shopping').status).toBe('active');

    const active = await as(owner, request(app).get('/api/extensions/active'));
    expect(active.body.active).toContain('shopping');

    const meta = await as(owner, request(app).get('/api/shop/meta'));
    expect(meta.status).toBe(200);
    expect(meta.body.categoryTaxonomyId).toBeTruthy();
    expect(meta.body.tagTaxonomyId).toBeTruthy();

    const types = await as(owner, request(app).get('/api/fields/post-types'));
    const product = types.body.postTypes.find((t: { slug: string }) => t.slug === 'product');
    expect(product).toBeTruthy();
    expect(product.showInMenu).toBe(false);

    // The shop owns the product type: it cannot be deleted while Shopping is installed.
    const del = await as(owner, request(app).delete(`/api/fields/post-types/${product.id}`));
    expect(del.status).toBe(400);
  });

  it('configures shipping and creates a published product with stock', async () => {
    const current = await as(owner, request(app).get('/api/shop/settings'));
    expect(current.status).toBe(200);
    const settings = current.body.settings;
    settings.shipping.zones = [
      { id: 'all', name: 'Everywhere', countries: [], methods: [{ id: 'std', type: 'flat_rate', title: 'Standard', cost: 500, minAmount: 0, enabled: true }] },
    ];
    settings.general.currency = 'EUR';
    // Checkout form: hide the company field, require the phone, add a custom select + checkbox.
    settings.checkout.fields = settings.checkout.fields.map((f: { key: string }) =>
      f.key === 'billing.company' ? { ...f, enabled: false } : f.key === 'phone' ? { ...f, required: true } : f,
    );
    settings.checkout.fields.push(
      { key: 'custom.delivery-slot', label: 'Delivery slot', type: 'select', section: 'extra', enabled: true, required: true, placeholder: '', options: ['Morning', 'Afternoon'], width: 'half', builtin: false, locked: false },
      { key: 'custom.gift', label: 'Gift wrap', type: 'checkbox', section: 'extra', enabled: true, required: false, placeholder: '', options: [], width: 'half', builtin: false, locked: false },
    );
    const saved = await as(owner, request(app).put('/api/shop/settings')).send(settings);
    expect(saved.status).toBe(200);
    expect(saved.body.settings.shipping.zones).toHaveLength(1);
    expect(saved.body.settings.checkout.fields.find((f: { key: string }) => f.key === 'billing.firstName').locked).toBe(true);
    expect(saved.body.settings.checkout.fields.some((f: { key: string }) => f.key === 'custom.delivery-slot')).toBe(true);

    // Shop Editor pages exist with the default document.
    const pages = await as(owner, request(app).get('/api/shop/pages'));
    expect(pages.status).toBe(200);
    expect(pages.body.pages.map((p: { view: string }) => p.view)).toEqual(['shop', 'product', 'cart', 'checkout', 'order-received', 'account']);
    expect(pages.body.pages.every((p: { customised: boolean }) => p.customised === false)).toBe(true);
    const pub = await request(app).get('/api/shop/public/pages/shop');
    expect(pub.status).toBe(200);
    expect(JSON.stringify(pub.body.beekiricode)).toContain('shop_content');

    const created = await as(owner, request(app).post('/api/shop/products')).send({ title: 'Hoodie' });
    expect(created.status).toBe(201);
    productId = created.body.id;
    expect(created.body.status).toBe('draft');

    const bad = await as(owner, request(app).patch(`/api/shop/products/${productId}`)).send({ commerce: { regularPrice: 1000, salePrice: 2000 } });
    expect(bad.status).toBe(400);

    const updated = await as(owner, request(app).patch(`/api/shop/products/${productId}`)).send({
      status: 'publish',
      description: '<p>Warm.</p><script>alert(1)</script>',
      commerce: { sku: 'HD-1', regularPrice: 2500, manageStock: true, stockQty: 3 },
    });
    expect(updated.status).toBe(200);
    expect(updated.body.status).toBe('publish');
    expect(updated.body.slug).toBe('hoodie');
    expect(updated.body.commerce.stockQty).toBe(3);
    expect(updated.body.path).toBe('/product/hoodie');

    const list = await as(owner, request(app).get('/api/shop/products?q=HD-1'));
    expect(list.body.items).toHaveLength(1);
    expect(list.body.items[0].stockStatus).toBe('instock');

    const coupon = await as(owner, request(app).post('/api/shop/coupons')).send({ code: 'ten', type: 'percent', amount: 1000 });
    expect(coupon.status).toBe(201);
    expect(coupon.body.code).toBe('TEN');
  });

  it('serves the public catalog and renders the shop template', async () => {
    const catalog = await request(app).get('/api/shop/public/catalog');
    expect(catalog.status).toBe(200);
    expect(catalog.body.items).toHaveLength(1);
    expect(catalog.body.items[0].price.formatted).toBe('€25.00');

    const single = await request(app).get('/api/shop/public/products/hoodie');
    expect(single.status).toBe(200);
    expect(single.body.product.inStock).toBe(true);
    // The owner holds unfiltered_html, so the script survives (same rule as pages).
    expect(single.body.product.description).toContain('Warm.');

    const view = await request(app).get('/api/shop/public/view/product?slug=hoodie');
    expect(view.status).toBe(200);
    expect(view.body.title).toBe('Hoodie');
    expect(view.body.html).toContain('data-shop-view="product"');
    expect(view.body.structured.priceDecimal).toBe('25.00');
  });

  it('rejects cart writes without the storefront header, then builds a cart with a coupon', async () => {
    const noHeader = await request(app).post('/api/shop/public/cart/items').set('Origin', ORIGIN).send({ productId, qty: 1 });
    expect(noHeader.status).toBe(403);
    const badOrigin = await request(app).post('/api/shop/public/cart/items').set('Origin', 'https://evil.example').set('X-Beekiri-Shop', '1').send({ productId, qty: 1 });
    expect(badOrigin.status).toBe(403);

    const add = await shopper(request(app).post('/api/shop/public/cart/items')).send({ productId, qty: 1 });
    expect(add.status).toBe(200);
    const setCookie = ([] as string[]).concat(add.headers['set-cookie'] ?? []);
    const cookie = setCookie.find((c) => c.startsWith('beekiri_cart='));
    expect(cookie).toBeTruthy();
    expect(cookie).toMatch(/HttpOnly/i);
    cartCookie = cookie!.split(';')[0]!.split('=')[1]!;
    expect(add.body.itemCount).toBe(1);
    expect(add.body.subtotal).toBe(2500);

    const tooMany = await shopper(request(app).post('/api/shop/public/cart/items')).send({ productId, qty: 5 });
    expect(tooMany.status).toBe(400);

    const coupon = await shopper(request(app).post('/api/shop/public/cart/coupon')).send({ code: 'ten' });
    expect(coupon.status).toBe(200);
    expect(coupon.body.coupon.code).toBe('TEN');
    expect(coupon.body.discountTotal).toBe(250);

    const config = await shopper(request(app).get('/api/shop/public/config'));
    expect(config.body.cartCount).toBe(1);
  });

  it('quotes shipping and places a cash-on-delivery order that holds stock', async () => {
    const quote = await shopper(request(app).post('/api/shop/public/checkout/shipping')).send({ country: 'XK', state: '', postcode: '' });
    expect(quote.status).toBe(200);
    expect(quote.body.shippingOptions.map((o: { id: string }) => o.id)).toEqual(['std']);
    expect(quote.body.cart.total).toBe(2500 - 250 + 500);

    const billing = { firstName: 'Ana', lastName: 'Test', company: 'Hidden Ltd', line1: '1 Main St', line2: '', city: 'Pristina', state: '', postcode: '10000', country: 'XK' };
    const base = { email: 'Ana@Example.com', billing, shipToDifferent: false, shippingMethodId: 'std', paymentMethod: 'cod', customerNote: 'Ring the bell', termsAccepted: true };
    // Configured rules: phone required, delivery slot required + limited to its options.
    const noPhone = await shopper(request(app).post('/api/shop/public/checkout')).send({ ...base, phone: '', extra: { 'custom.delivery-slot': 'Morning' } });
    expect(noPhone.status).toBe(400);
    expect(noPhone.body.message).toMatch(/Phone is required/);
    const badSlot = await shopper(request(app).post('/api/shop/public/checkout')).send({ ...base, phone: '+383 44 000 000', extra: { 'custom.delivery-slot': 'Midnight' } });
    expect(badSlot.status).toBe(400);
    const placed = await shopper(request(app).post('/api/shop/public/checkout')).send({
      ...base,
      phone: '+383 44 000 000',
      extra: { 'custom.delivery-slot': 'Afternoon', 'custom.gift': '1', 'custom.unknown': 'ignored' },
    });
    expect(placed.status).toBe(201);
    expect(placed.body.redirectUrl).toMatch(/^\/checkout\/order-received\//);
    orderToken = placed.body.token;
    orderId = placed.body.orderId;

    const pub = await request(app).get(`/api/shop/public/orders/${orderToken}`);
    expect(pub.status).toBe(200);
    expect(pub.body.status).toBe('processing');
    expect(pub.body.email).toBe('ana@example.com');
    expect(pub.body.totals.total).toBe('€27.50');
    expect(pub.body.items[0].name).toBe('Hoodie');
    expect(pub.body.billing.company).toBe(''); // hidden field is blanked
    expect([...pub.body.customFields].sort((a: { key: string }, b: { key: string }) => a.key.localeCompare(b.key))).toEqual([
      { key: 'custom.delivery-slot', label: 'Delivery slot', value: 'Afternoon' },
      { key: 'custom.gift', label: 'Gift wrap', value: 'Yes' },
    ]);
    expect((await request(app).get('/api/shop/public/orders/not-a-token')).status).toBe(404);

    const product = await as(owner, request(app).get(`/api/shop/products/${productId}`));
    expect(product.body.commerce.stockQty).toBe(2);
    expect(product.body.commerce.totalSales).toBe(1);

    const coupons = await as(owner, request(app).get('/api/shop/coupons'));
    expect(coupons.body.coupons[0].usageCount).toBe(1);

    const emptied = await shopper(request(app).get('/api/shop/public/cart'));
    expect(emptied.body.itemCount).toBe(0);

    const customers = await as(owner, request(app).get('/api/shop/customers'));
    expect(customers.body.items).toHaveLength(1);
    expect(customers.body.items[0].email).toBe('ana@example.com');
  });

  it('shows the order in the admin, cancelling restocks and refunds are validated', async () => {
    const list = await as(owner, request(app).get('/api/shop/orders?status=processing'));
    expect(list.body.items).toHaveLength(1);
    expect(list.body.items[0].id).toBe(orderId);
    expect(list.body.counts.processing).toBe(1);

    const detail = await as(owner, request(app).get(`/api/shop/orders/${orderId}`));
    expect(detail.body.order.items).toHaveLength(1);
    expect(detail.body.order.notes.length).toBeGreaterThan(0);
    expect(detail.body.canRefundViaProvider).toBe(false);

    const refundUnpaid = await as(owner, request(app).post(`/api/shop/orders/${orderId}/refund`)).send({ amount: 100 });
    expect(refundUnpaid.status).toBe(400);

    const note = await as(owner, request(app).post(`/api/shop/orders/${orderId}/notes`)).send({ note: 'Packed', isCustomerNote: false });
    expect(note.status).toBe(201);

    const cancelled = await as(owner, request(app).post(`/api/shop/orders/${orderId}/status`)).send({ status: 'cancelled' });
    expect(cancelled.status).toBe(200);
    expect(cancelled.body.order.status).toBe('cancelled');
    const product = await as(owner, request(app).get(`/api/shop/products/${productId}`));
    expect(product.body.commerce.stockQty).toBe(3);
    expect(product.body.commerce.totalSales).toBe(0);

    const reopened = await as(owner, request(app).post(`/api/shop/orders/${orderId}/status`)).send({ status: 'processing' });
    expect(reopened.status).toBe(200);
    expect((await as(owner, request(app).get(`/api/shop/products/${productId}`))).body.commerce.stockQty).toBe(2);

    const overview = await as(owner, request(app).get('/api/shop/overview?range=30d'));
    expect(overview.status).toBe(200);
    expect(overview.body.totals.orders).toBe(1);
  });

  it('enforces shop capabilities and rejects unsigned webhooks', async () => {
    const created = await as(owner, request(app).post('/api/users')).send({ username: 'viewer', email: 'viewer@example.com', password: 'viewer-S3cret!Pass', role: 'subscriber' });
    expect(created.status).toBe(201);
    const viewer = await login('viewer', 'viewer-S3cret!Pass');
    expect((await as(viewer, request(app).get('/api/shop/orders'))).status).toBe(403);
    expect((await as(viewer, request(app).get('/api/shop/products'))).status).toBe(403);
    expect((await as(viewer, request(app).get('/api/shop/settings'))).status).toBe(403);
    expect((await as(viewer, request(app).get('/api/shop/meta'))).status).toBe(403);
    expect((await as(viewer, request(app).post('/api/extensions/shopping/deactivate'))).status).toBe(403);

    const manager = await as(owner, request(app).post('/api/users')).send({ username: 'manager', email: 'manager@example.com', password: 'manager-S3cret!Pass', role: 'shop_manager' });
    expect(manager.status).toBe(201);
    const mgr = await login('manager', 'manager-S3cret!Pass');
    expect((await as(mgr, request(app).get('/api/shop/orders'))).status).toBe(200);
    expect((await as(mgr, request(app).get('/api/shop/settings'))).status).toBe(200);
    expect((await as(mgr, request(app).get('/api/pages'))).status).toBe(403);

    // No unfiltered_html: scripts are stripped from product descriptions a manager saves.
    const edited = await as(mgr, request(app).patch(`/api/shop/products/${productId}`)).send({ description: '<p>Cosy.</p><script>alert(1)</script>' });
    expect(edited.status).toBe(200);
    expect(edited.body.description).toContain('Cosy.');
    expect(edited.body.description).not.toContain('<script');

    const webhook = await request(app).post('/api/shop/webhooks/stripe').set('Stripe-Signature', 't=1,v1=bad').send({ id: 'evt_1', type: 'checkout.session.completed' });
    expect(webhook.status).toBe(400);
    // The raw body reached the handler (signature verification needs the exact bytes).
    expect(webhook.body.message).not.toMatch(/raw body/i);
  });

  it('deactivates cleanly: storefront and shop API answer 404, data stays', async () => {
    const off = await as(owner, request(app).post('/api/extensions/shopping/deactivate'));
    expect(off.status).toBe(200);
    expect((await request(app).get('/api/shop/public/config')).status).toBe(404);
    expect((await as(owner, request(app).get('/api/shop/orders'))).status).toBe(404);

    const on = await as(owner, request(app).post('/api/extensions/shopping/activate'));
    expect(on.status).toBe(200);
    const orders = await as(owner, request(app).get('/api/shop/orders'));
    expect(orders.body.items).toHaveLength(1);
  });
});
