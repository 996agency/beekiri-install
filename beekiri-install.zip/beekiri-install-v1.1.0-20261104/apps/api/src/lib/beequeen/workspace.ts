import { execFile } from 'child_process';
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { dirname, extname, join, relative, resolve, sep } from 'path';
import { pathToFileURL } from 'url';
import { promisify } from 'util';
import { compileString as compileSassString } from 'sass';
import { Op } from 'sequelize';

import { FieldGroup, MediaAsset, Post } from '../../models';
import { revalidatePublicPaths } from '../revalidate-public';
import { layoutSyncService } from '../../services/layout-sync.service';
import { fieldsService } from '../../services/fields.service';
import { pagesService } from '../../services/pages.service';
import { themesService } from '../../services/themes.service';
import { findPrimarySite } from '../../services/site-context';
import type { AuthUser } from '../../types/auth';
import { parseFields, toSlugKey, type BackendField } from '../fields/fields.types';
import { layoutPaths, layoutSlugFromTitle, resolveLayoutPaths, sanitizeLayoutSlug } from '../layouts/layout-paths';
import { readOptions } from '../site/site-options';
import { resolveClientThemeSlug, resolveThemesRoot, themeAncestry } from '../themes/theme-registry';

/**
 * Everything BeeQueen can touch: the client theme folder, Backend Fields groups
 * that sync into it, pages built from those layouts, and (read-only) media.
 * Core apps, the parent theme and other themes stay out of reach.
 */

const execFileAsync = promisify(execFile);

const TEXT_EXTENSIONS = new Set(['.php', '.tsx', '.scss', '.css', '.js', '.json', '.md', '.svg', '.txt']);
const WRITABLE_EXTENSIONS = new Set(['.php', '.tsx', '.scss', '.css', '.js', '.md']);
const MAX_READ_BYTES = 120_000;

export type WorkspaceLink = { kind: 'layout' | 'page' | 'file'; label: string; admin?: string; url?: string };

export type Workspace = {
  actor: AuthUser;
  /** Records what changed so the chat can link to it. */
  links: WorkspaceLink[];
};

type Runtime = 'php' | 'react';

async function context() {
  const active = await themesService.getActiveSlug();
  const theme = resolveClientThemeSlug(active);
  const site = await findPrimarySite();
  const runtime: Runtime = readOptions(site?.settings?.options).frontendRuntime === 'react' ? 'react' : 'php';
  return { active, theme, ancestry: themeAncestry(theme), runtime };
}

function addLink(ws: Workspace, link: WorkspaceLink) {
  const i = ws.links.findIndex((l) => l.kind === link.kind && l.label === link.label);
  if (i >= 0) ws.links[i] = link;
  else ws.links.push(link);
}

/** A theme-relative path, or an error when it climbs out of the theme. */
function themeRel(raw: string): string {
  const rel = raw.trim().replace(/^\/+/, '').replace(/\\/g, '/');
  if (!rel || rel.split('/').some((part) => part === '..' || part.startsWith('.'))) {
    throw new Error(`"${raw}" is not a path inside the theme.`);
  }
  return rel;
}

function inside(root: string, abs: string): boolean {
  return resolve(abs).startsWith(resolve(root) + sep);
}

function fieldSummary(fields: BackendField[], depth = 0): string[] {
  const pad = '  '.repeat(depth);
  const out: string[] = [];
  for (const f of fields) {
    const extra = [f.returnFormat ? `returns ${f.returnFormat}` : '', f.choices.length ? `choices: ${f.choices.join(' | ')}` : '']
      .filter(Boolean)
      .join(', ');
    out.push(`${pad}- ${f.name} (${f.type}) "${f.label}"${extra ? ` — ${extra}` : ''}`);
    if (f.subFields?.length) out.push(...fieldSummary(f.subFields, depth + 1));
    for (const l of f.layouts ?? []) {
      out.push(`${pad}  · row layout "${l.name}"`);
      out.push(...fieldSummary(l.subFields, depth + 2));
    }
  }
  return out;
}

// ─── Overview ─────────────────────────────────────────────────────────────────

export async function siteOverview(ws: Workspace): Promise<string> {
  const ctx = await context();
  const layouts = layoutSyncService.listPublic();
  const pages = await Post.findAll({
    where: { siteId: ws.actor.siteId, type: 'page', status: { [Op.notIn]: ['auto-draft', 'trash'] } },
    attributes: ['id', 'title', 'slug', 'status'],
    order: [['updatedAt', 'DESC']],
    limit: 60,
  });
  const lines = [
    `Active theme: ${ctx.active} · BeeQueen writes to: ${ctx.theme} (parents: ${ctx.ancestry.slice(1).join(', ') || 'none'})`,
    `Frontend runtime: ${ctx.runtime} (layout templates are ${ctx.runtime === 'php' ? '{slug}.php' : '{slug}.tsx'})`,
    '',
    `Layouts (${layouts.length}):`,
    ...(layouts.length
      ? layouts.flatMap((l) => [`• ${l.slug} — "${l.title}" [theme ${l.theme}]`, ...fieldSummary(l.fields, 1)])
      : ['(none yet)']),
    '',
    `Pages (${pages.length}):`,
    ...(pages.length ? pages.map((p) => `• ${p.id} — "${p.title}" /${p.slug} [${p.status}]`) : ['(none yet)']),
  ];
  return lines.join('\n');
}

// ─── Theme files ──────────────────────────────────────────────────────────────

export async function listThemeFiles(): Promise<string> {
  const ctx = await context();
  const root = resolveThemesRoot();
  const out: string[] = [];
  for (const theme of ctx.ancestry) {
    const base = join(root, theme);
    const files: string[] = [];
    const walk = (dir: string, depth: number) => {
      if (depth > 4 || files.length > 300) return;
      for (const entry of readdirSync(dir, { withFileTypes: true })) {
        if (entry.name.startsWith('.') || entry.name === 'node_modules') continue;
        const abs = join(dir, entry.name);
        if (entry.isDirectory()) walk(abs, depth + 1);
        else if (TEXT_EXTENSIONS.has(extname(entry.name))) files.push(relative(base, abs));
      }
    };
    if (existsSync(base)) walk(base, 0);
    out.push(`${theme}${theme === ctx.theme ? ' (writable)' : ' (read-only parent)'}:`, ...files.sort().map((f) => `  ${f}`));
  }
  return out.join('\n');
}

/** Child file first, then the parent's — the same lookup the site uses. */
export async function readThemeFile(rawPath: string): Promise<string> {
  const ctx = await context();
  const rel = themeRel(rawPath);
  if (!TEXT_EXTENSIONS.has(extname(rel))) throw new Error('Only text files (php, scss, css, js, json, md…) can be read.');
  const root = resolveThemesRoot();
  for (const theme of ctx.ancestry) {
    const abs = join(root, theme, rel);
    if (!existsSync(abs) || !statSync(abs).isFile()) continue;
    const body = readFileSync(abs, 'utf8');
    const clipped = body.length > MAX_READ_BYTES ? `${body.slice(0, MAX_READ_BYTES)}\n…(truncated)` : body;
    return `// ${theme}/${rel}\n${clipped}`;
  }
  throw new Error(`${rel} does not exist in ${ctx.ancestry.join(' or ')}.`);
}

/** Writes go to the client (child) theme only; layouts go through save_layout. */
export async function writeThemeFile(ws: Workspace, rawPath: string, content: string): Promise<string> {
  const ctx = await context();
  const rel = themeRel(rawPath);
  if (!WRITABLE_EXTENSIONS.has(extname(rel))) {
    throw new Error('Only .php, .tsx, .scss, .css, .js and .md theme files can be written.');
  }
  if (rel === 'theme.json' || rel.startsWith('layouts/')) {
    throw new Error('Use save_layout for layouts — it keeps Backend Fields and the theme in sync.');
  }
  const base = join(resolveThemesRoot(), ctx.theme);
  const abs = join(base, rel);
  if (!inside(base, abs)) throw new Error('That path is outside the theme.');
  mkdirSync(dirname(abs), { recursive: true });
  writeFileSync(abs, content, 'utf8');
  void revalidatePublicPaths(['/']);
  addLink(ws, { kind: 'file', label: `${ctx.theme}/${rel}`, admin: 'appearance' });
  return `Saved ${ctx.theme}/${rel} (${content.length} chars).`;
}

// ─── Layouts (Backend Fields ↔ theme) ─────────────────────────────────────────

export async function readLayout(rawSlug: string): Promise<string> {
  const slug = sanitizeLayoutSlug(rawSlug);
  if (!slug) throw new Error('Give a layout slug.');
  const ctx = await context();
  const paths = resolveLayoutPaths(slug, ctx.theme);
  if (!existsSync(paths.dir)) throw new Error(`No layout "${slug}". Call get_site_overview for the list.`);
  const read = (p: string) => (existsSync(p) ? readFileSync(p, 'utf8') : '(missing)');
  return [
    `Layout ${slug} in theme ${paths.themeSlug}`,
    `--- ${slug}.meta.json (Backend Fields definition)\n${read(paths.meta)}`,
    `--- ${ctx.runtime === 'php' ? `${slug}.php` : `${slug}.tsx`}\n${read(ctx.runtime === 'php' ? paths.php : paths.tsx)}`,
    `--- styles.scss\n${read(paths.scss)}`,
    `--- script.js\n${read(paths.js)}`,
  ].join('\n\n');
}

export type SaveLayoutInput = {
  title: string;
  description?: string;
  fields: Record<string, unknown>[];
  template: string;
  scss: string;
  js?: string;
};

/** Values that exercise a template once so PHP errors show up before a page uses it. */
function sampleValues(fields: BackendField[]): Record<string, unknown> {
  const row: Record<string, unknown> = {};
  for (const f of fields) {
    switch (f.type) {
      case 'repeater':
        row[f.name] = [sampleValues(f.subFields ?? []), sampleValues(f.subFields ?? [])];
        break;
      case 'group':
        row[f.name] = sampleValues(f.subFields ?? []);
        break;
      case 'flexible_content':
        row[f.name] = (f.layouts ?? []).map((l) => ({ acf_fc_layout: l.name, ...sampleValues(l.subFields) }));
        break;
      case 'image':
        row[f.name] = 'https://placehold.co/1200x800.png';
        break;
      case 'gallery':
        row[f.name] = ['https://placehold.co/800x600.png'];
        break;
      case 'link':
        row[f.name] = { title: 'Learn more', url: '/', target: '' };
        break;
      case 'url':
        row[f.name] = 'https://example.com';
        break;
      case 'true_false':
        row[f.name] = true;
        break;
      case 'number':
      case 'range':
        row[f.name] = 3;
        break;
      case 'select':
      case 'radio':
      case 'button_group':
      case 'checkbox': {
        const first = (f.choices[0] ?? '').split(':')[0].trim();
        row[f.name] = f.type === 'checkbox' || f.multiple ? [first] : first;
        break;
      }
      case 'message':
      case 'accordion':
      case 'tab':
        break;
      default:
        row[f.name] = `Sample ${f.label}`;
    }
  }
  return row;
}

/** Keep field ids stable across edits so saved values and the editor stay attached. */
function keepFieldIds(next: BackendField[], prev: BackendField[]): BackendField[] {
  const byName = new Map(prev.map((f) => [f.name, f]));
  return next.map((f) => {
    const old = byName.get(f.name);
    const merged: BackendField = old ? { ...f, id: old.id } : f;
    if (f.subFields) merged.subFields = keepFieldIds(f.subFields, old?.subFields ?? []);
    return merged;
  });
}

/** `php -l` on a scratch copy, so a broken draft is caught before it replaces a working template. */
async function lintPhp(source: string, slug: string): Promise<string | null> {
  const scratch = join(tmpdir(), `beequeen-${slug}-${Math.random().toString(36).slice(2, 8)}.php`);
  writeFileSync(scratch, source, 'utf8');
  try {
    await execFileAsync('php', ['-l', scratch], { timeout: 8000 });
    return null;
  } catch (e) {
    const err = e as { code?: string; stdout?: string; stderr?: string; message: string };
    if (err.code === 'ENOENT') return null; // No PHP CLI here; the render check reports it.
    const out = (err.stdout || err.stderr || err.message).split(scratch).join(`${slug}.php`);
    return `PHP syntax error: ${out.replace(/\s*Errors parsing.*$/s, '').trim()}`;
  } finally {
    rmSync(scratch, { force: true });
  }
}

/** Every field name a template reads, so typos against the field group surface early. */
function fieldNames(fields: BackendField[], into = new Set<string>()): Set<string> {
  for (const f of fields) {
    into.add(f.name);
    if (f.subFields) fieldNames(f.subFields, into);
    for (const l of f.layouts ?? []) fieldNames(l.subFields, into);
  }
  return into;
}

function unknownFieldReads(template: string, fields: BackendField[]): string[] {
  const known = fieldNames(fields);
  const read = [...template.matchAll(/(?:get_bee_field|the_bee_field|have_bee_rows)\(\s*['"]([A-Za-z0-9_]+)['"]/g)].map((m) => m[1]);
  return [...new Set(read.filter((name) => !known.has(name)))];
}

async function checkRender(slug: string, fields: BackendField[]): Promise<string[]> {
  const problems: string[] = [];
  const html = await layoutSyncService.renderPhpLayout(slug, sampleValues(fields));
  if (html == null) problems.push('The template did not render with sample values (PHP runtime error).');
  else if (/(Fatal error|Warning|Notice|Deprecated):/i.test(html)) {
    problems.push(`PHP printed an error while rendering sample values:\n${html.slice(0, 1500)}`);
  } else if (!html.includes(`data-layout="${slug}"`)) {
    problems.push(`The root element must carry data-layout="${slug}" so the site loads its CSS/JS.`);
  }
  return problems;
}

export async function saveLayout(ws: Workspace, input: SaveLayoutInput): Promise<string> {
  const ctx = await context();
  const title = input.title.trim();
  const slug = sanitizeLayoutSlug(layoutSlugFromTitle(title) || '');
  if (!slug) throw new Error('Give the layout a title made of letters or numbers.');
  // Backend Fields names folders after the group key for titles like this, so the slug would not match.
  if (slug.startsWith('group-')) throw new Error('Pick a layout title that does not start with "Group".');
  const fields = parseFields(input.fields);
  if (input.fields.length && fields.length < input.fields.length) {
    throw new Error('Some fields were dropped: every field needs a label and a snake_case name.');
  }

  // Check the draft before touching Backend Fields or the theme: a broken draft must
  // never replace a layout that live pages already render.
  const draftProblems: string[] = [];
  try {
    compileSassString(input.scss, {
      loadPaths: [layoutPaths(slug, ctx.theme).dir],
      url: pathToFileURL(layoutPaths(slug, ctx.theme).scss),
    });
  } catch (e) {
    draftProblems.push(`SCSS does not compile: ${(e as Error).message}`);
  }
  if (ctx.runtime === 'php') {
    const lint = await lintPhp(input.template, slug);
    if (lint) draftProblems.push(lint);
  }
  if (draftProblems.length) {
    throw new Error(
      `Nothing was saved — fix and call save_layout again:\n${draftProblems.map((p) => `- ${p}`).join('\n')}`,
    );
  }

  // Same slug → same Backend Fields group: update it instead of making a duplicate.
  const existingMeta = layoutPaths(slug, ctx.theme).meta;
  let existingKey: string | null = null;
  if (existsSync(existingMeta)) {
    try {
      existingKey = (JSON.parse(readFileSync(existingMeta, 'utf8')) as { key?: string }).key ?? null;
    } catch {
      existingKey = null;
    }
  }
  const key = existingKey ?? toSlugKey(title);
  const group = await FieldGroup.findOne({ where: { siteId: ws.actor.siteId, key, trashedAt: null } });

  const created = !group;
  if (group) {
    await fieldsService.update(ws.actor, group.id, {
      title,
      active: true,
      location: ['page'],
      fields: keepFieldIds(fields, parseFields(group.fields)),
      ...(input.description !== undefined ? { description: input.description } : {}),
    });
  } else {
    await fieldsService.create(ws.actor, {
      title,
      key,
      description: input.description ?? 'Built by BeeQueen.',
      active: true,
      location: ['page'],
      fields,
    });
  }

  // Backend Fields just synced the folder; now lay BeeQueen's own files over it.
  // No @beekiri-managed marker, so later field edits never overwrite this design.
  const paths = layoutPaths(slug, ctx.theme);
  mkdirSync(paths.dir, { recursive: true });
  const templatePath = ctx.runtime === 'php' ? paths.php : paths.tsx;
  writeFileSync(templatePath, input.template.replace(/^.*@beekiri-managed.*\n/m, ''), 'utf8');
  writeFileSync(paths.scss, input.scss.replace(/^.*@beekiri-managed.*\n/m, ''), 'utf8');
  if (input.js !== undefined) writeFileSync(paths.js, input.js.replace(/^.*@beekiri-managed.*\n/m, ''), 'utf8');

  const problems: string[] = [];
  try {
    layoutSyncService.compileSlug(slug);
  } catch (e) {
    problems.push(`SCSS did not compile: ${(e as Error).message}`);
  }
  const unknown = unknownFieldReads(input.template, fields);
  if (unknown.length) {
    problems.push(`The template reads ${unknown.join(', ')}, which ${unknown.length === 1 ? 'is' : 'are'} not in the field list.`);
  }
  if (ctx.runtime === 'php') problems.push(...(await checkRender(slug, fields)));
  // The site caches its layout list; refresh it so pages pick up this layout's CSS/JS right away.
  void revalidatePublicPaths(['/']);

  addLink(ws, { kind: 'layout', label: title, admin: 'fields' });
  const head = `${created ? 'Created' : 'Updated'} layout "${title}" (slug ${slug}) in ${ctx.theme}/layouts/${slug}/ and Backend Fields group ${key}.`;
  return problems.length
    ? `${head}\nPROBLEMS — fix and call save_layout again:\n${problems.map((p) => `- ${p}`).join('\n')}`
    : `${head}\nSCSS compiled and the template rendered cleanly with sample values.`;
}

// ─── Pages (BeekiriCode documents) ────────────────────────────────────────────

type DocNode = {
  id: string;
  type: string;
  tag?: string;
  text?: string;
  src?: string;
  alt?: string;
  href?: string;
  newTab?: boolean;
  layoutSlug?: string;
  layoutTitle?: string;
  layoutFields?: Record<string, unknown>;
  cssClass?: string;
  style?: Record<string, string>;
  children: string[];
};

type PageDoc = { version: 1; rootId: string; nodes: Record<string, DocNode> };

const ELEMENT_TAGS: Record<string, string> = {
  section: 'section',
  container: 'div',
  heading: 'h2',
  text: 'p',
  image: 'img',
  button: 'a',
  video: 'div',
  list: 'ul',
  divider: 'hr',
  spacer: 'div',
};

const rid = (prefix: string) => `${prefix}_${Math.random().toString(36).slice(2, 10)}`;

function styleBag(raw: unknown): Record<string, string> | undefined {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return undefined;
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    if (typeof v === 'string' || typeof v === 'number') {
      out[k.replace(/-([a-z])/g, (_, c: string) => c.toUpperCase())] = String(v);
    }
  }
  return Object.keys(out).length ? out : undefined;
}

/** Block specs from the model → BeekiriCode nodes, validating layouts as we go. */
function buildDoc(blocks: unknown[], layouts: Map<string, { title: string; fields: BackendField[] }>): PageDoc {
  const nodes: Record<string, DocNode> = {};
  const errors: string[] = [];

  const build = (raw: unknown, where: string): string | null => {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
      errors.push(`${where}: each block must be an object.`);
      return null;
    }
    const b = raw as Record<string, unknown>;
    const type = typeof b.type === 'string' ? b.type : '';
    if (type === 'layout') {
      const slug = sanitizeLayoutSlug(String(b.layout ?? b.slug ?? '')) ?? '';
      const layout = layouts.get(slug);
      if (!layout) {
        errors.push(`${where}: layout "${slug}" does not exist — create it with save_layout first.`);
        return null;
      }
      const values = b.fields && typeof b.fields === 'object' && !Array.isArray(b.fields) ? (b.fields as Record<string, unknown>) : {};
      const known = new Set(layout.fields.map((f) => f.name));
      const unknown = Object.keys(values).filter((k) => !known.has(k));
      if (unknown.length) {
        errors.push(`${where}: layout "${slug}" has no field(s) ${unknown.join(', ')} (it has ${[...known].join(', ') || 'none'}).`);
      }
      const id = rid('lay');
      nodes[id] = {
        id,
        type: 'layout',
        tag: 'section',
        layoutSlug: slug,
        layoutTitle: layout.title,
        layoutFields: values,
        text: layout.title,
        style: {},
        children: [],
      };
      return id;
    }
    if (!(type in ELEMENT_TAGS)) {
      errors.push(`${where}: unknown block type "${type}". Use layout, ${Object.keys(ELEMENT_TAGS).join(', ')}.`);
      return null;
    }
    const id = rid(type.slice(0, 3));
    const node: DocNode = {
      id,
      type,
      tag: typeof b.tag === 'string' && /^[a-z][a-z0-9]*$/.test(b.tag) ? b.tag : ELEMENT_TAGS[type],
      style: styleBag(b.style),
      children: [],
    };
    for (const k of ['text', 'src', 'alt', 'href', 'cssClass'] as const) {
      if (typeof b[k] === 'string') node[k] = b[k] as string;
    }
    if (typeof b.newTab === 'boolean') node.newTab = b.newTab;
    nodes[id] = node;
    if (Array.isArray(b.children)) {
      if (type !== 'section' && type !== 'container') {
        errors.push(`${where}: only section and container blocks can have children.`);
      } else {
        b.children.forEach((child, i) => {
          const cid = build(child, `${where}.children[${i}]`);
          if (cid) node.children.push(cid);
        });
      }
    }
    return id;
  };

  const rootId = rid('root');
  const children: string[] = [];
  blocks.forEach((block, i) => {
    const id = build(block, `blocks[${i}]`);
    if (id) children.push(id);
  });
  if (errors.length) throw new Error(`The page was not saved:\n${errors.map((e) => `- ${e}`).join('\n')}`);
  // The theme already wraps pages in <main>; layouts own their own spacing.
  nodes[rootId] = { id: rootId, type: 'section', tag: 'div', style: {}, children };
  return { version: 1, rootId, nodes };
}

/** BeekiriCode document → the same block shape save_page takes, for editing. */
function docToBlocks(doc: unknown): unknown[] {
  if (!doc || typeof doc !== 'object') return [];
  const d = doc as PageDoc;
  if (!d.nodes || !d.rootId || !d.nodes[d.rootId]) return [];
  const toBlock = (id: string): unknown => {
    const n = d.nodes[id];
    if (!n) return null;
    if (n.type === 'layout') return { type: 'layout', layout: n.layoutSlug, fields: n.layoutFields ?? {} };
    const out: Record<string, unknown> = { type: n.type };
    for (const k of ['tag', 'text', 'src', 'alt', 'href', 'newTab', 'cssClass'] as const) {
      if (n[k] !== undefined && n[k] !== '') out[k] = n[k];
    }
    if (n.style && Object.keys(n.style).length) out.style = n.style;
    if (n.children?.length) out.children = n.children.map(toBlock).filter(Boolean);
    return out;
  };
  return (d.nodes[d.rootId].children ?? []).map(toBlock).filter(Boolean);
}

export async function getPage(ws: Workspace, id: string): Promise<string> {
  const page = await pagesService.get(ws.actor, id, 'page');
  return JSON.stringify(
    { id: page.id, title: page.title, slug: page.slug, status: page.status, path: page.path, blocks: docToBlocks(page.beekiricode) },
    null,
    1,
  );
}

export type SavePageInput = {
  id?: string;
  title: string;
  slug?: string;
  status?: 'draft' | 'publish';
  blocks: unknown[];
};

export async function savePage(ws: Workspace, input: SavePageInput): Promise<string> {
  const layouts = new Map(layoutSyncService.listPublic().map((l) => [l.slug, { title: l.title, fields: l.fields }]));
  const doc = buildDoc(input.blocks, layouts);
  const body = {
    title: input.title.trim(),
    ...(input.slug ? { slug: input.slug } : {}),
    ...(input.status ? { status: input.status } : {}),
    beekiricode: doc as unknown as Record<string, unknown>,
  };
  const page = input.id
    ? await pagesService.update(ws.actor, input.id, body, 'page')
    : await pagesService.create(ws.actor, { ...body, status: input.status ?? 'draft' }, 'page');
  addLink(ws, { kind: 'page', label: page.title, admin: `pages/${page.id}`, url: page.status === 'publish' ? page.path : undefined });
  return `${input.id ? 'Updated' : 'Created'} page "${page.title}" (id ${page.id}, ${page.status}) at ${page.path} with ${input.blocks.length} top-level blocks.`;
}

// ─── Media (read-only) ────────────────────────────────────────────────────────

export async function listMedia(ws: Workspace, search?: string): Promise<string> {
  const rows = await MediaAsset.findAll({
    where: {
      siteId: ws.actor.siteId,
      mimeType: { [Op.like]: 'image/%' },
      ...(search ? { originalName: { [Op.iLike]: `%${search}%` } } : {}),
    },
    attributes: ['id', 'originalName', 'url', 'alt', 'width', 'height'],
    order: [['createdAt', 'DESC']],
    limit: 40,
  });
  if (!rows.length) return 'No images in the media library. Leave image fields empty — the user can pick images in the editor.';
  return rows
    .map((m) => `• ${m.id} — ${m.originalName} ${m.width ?? '?'}×${m.height ?? '?'}${m.alt ? ` alt="${m.alt}"` : ''} ${m.url}`)
    .join('\n');
}
