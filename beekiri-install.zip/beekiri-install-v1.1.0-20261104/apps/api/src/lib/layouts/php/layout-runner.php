<?php
/**
 * Beekiri layout runner — executes themes/.../layouts/{slug}/{slug}.php
 * with the Beekiri field API. Values arrive already formatted (field formatters),
 * so get_bee_field() returns the shapes layouts expect.
 *
 * Field API:
 *   get_bee_field() / the_bee_field() / get_bee_fields()
 *   have_bee_rows() / the_bee_row() / get_bee_row() / get_bee_row_index()
 *   get_bee_row_layout() / reset_bee_rows()
 *
 * Usage: php layout-runner.php <layout.php> <fields.json> <slug>
 *        php layout-runner.php <template.php> --stdin <slug> [prelude.php]   (JSON on stdin; the
 *        Shopping storefront uses this because its data outgrows a command-line argument)
 */
declare(strict_types=1);

$layoutPath = $argv[1] ?? '';
$fieldsJson = $argv[2] ?? '{}';
$slug = $argv[3] ?? 'layout';
$preludePath = $argv[4] ?? '';
if ($fieldsJson === '--stdin') {
  $fieldsJson = stream_get_contents(STDIN) ?: '{}';
}

if ($layoutPath === '' || !is_file($layoutPath)) {
  fwrite(STDERR, "Layout file not found.\n");
  exit(1);
}

$fields = json_decode($fieldsJson, true);
if (!is_array($fields)) {
  $fields = [];
}

/** @var array<int, array{name:string, rows:array, i:int}> */
$GLOBALS['__bk_loops'] = [];
$GLOBALS['__bk_fields'] = $fields;
$GLOBALS['__bk_slug'] = $slug;
$GLOBALS['__bk_media'] = [];

function __bk_is_list($v): bool {
  if (!is_array($v)) return false;
  if ($v === []) return true;
  return array_keys($v) === range(0, count($v) - 1);
}

/** Index every formatted image/file array so wp_get_attachment_*() can find it by ID. */
function __bk_index_media($v): void {
  if (!is_array($v)) return;
  if (isset($v['ID'], $v['url'], $v['mime_type']) && $v['ID'] !== '') {
    $GLOBALS['__bk_media'][(string) $v['ID']] = $v;
  }
  foreach ($v as $child) {
    if (is_array($child)) __bk_index_media($child);
  }
}
__bk_index_media($fields);

/** Values for the row currently being looped (or the layout's own fields). */
function __bk_ctx(): array {
  $loops = $GLOBALS['__bk_loops'];
  for ($k = count($loops) - 1; $k >= 0; $k--) {
    $l = $loops[$k];
    if ($l['i'] >= 0 && isset($l['rows'][$l['i']]) && is_array($l['rows'][$l['i']])) {
      return $l['rows'][$l['i']];
    }
  }
  return $GLOBALS['__bk_fields'];
}

/** Repeater / flexible → list of rows; group → single row. */
function __bk_rows($value): array {
  if (!is_array($value) || $value === []) return [];
  if (__bk_is_list($value)) {
    return array_values(array_filter($value, 'is_array'));
  }
  return [$value];
}

function __bk_to_string($v): string {
  if ($v === null || $v === false) return '';
  if ($v === true) return '1';
  if (is_array($v)) {
    if (isset($v['url']) && is_string($v['url'])) return $v['url'];
    if (isset($v['label']) && is_string($v['label'])) return $v['label'];
    return implode(', ', array_map('__bk_to_string', $v));
  }
  return (string) $v;
}

/* —— Beekiri field API (canonical) —— */

if (!function_exists('get_bee_field')) {
  /**
   * Layout / loop field value (root of the layout, or current bee_row).
   */
  function get_bee_field($selector = '', $format_value = true) {
    $ctx = __bk_ctx();
    return array_key_exists($selector, $ctx) ? $ctx[$selector] : null;
  }
}
if (!function_exists('the_bee_field')) {
  function the_bee_field($selector = '', $format_value = true) {
    echo __bk_to_string(get_bee_field($selector));
  }
}
if (!function_exists('get_bee_fields')) {
  function get_bee_fields($format_value = true) {
    return $GLOBALS['__bk_fields'];
  }
}

if (!function_exists('have_bee_rows')) {
  function have_bee_rows($selector, $post_id = false): bool {
    $loops = &$GLOBALS['__bk_loops'];

    // Continuing a loop already on the stack (drop any inner loop left open by `break`).
    for ($k = count($loops) - 1; $k >= 0; $k--) {
      if ($loops[$k]['name'] !== $selector) continue;
      if ($loops[$k]['i'] < 0 && $k !== count($loops) - 1) break;
      array_splice($loops, $k + 1);
      if ($loops[$k]['i'] + 1 < count($loops[$k]['rows'])) return true;
      array_pop($loops);
      return false;
    }

    $ctx = __bk_ctx();
    $rows = __bk_rows($ctx[$selector] ?? null);
    if (!$rows) return false;
    $loops[] = ['name' => (string) $selector, 'rows' => $rows, 'i' => -1];
    return true;
  }
}
if (!function_exists('the_bee_row')) {
  function the_bee_row($format = false) {
    $loops = &$GLOBALS['__bk_loops'];
    $n = count($loops);
    if (!$n) return false;
    $loops[$n - 1]['i']++;
    return $loops[$n - 1]['rows'][$loops[$n - 1]['i']] ?? false;
  }
}
if (!function_exists('get_bee_row')) {
  function get_bee_row($format = false) {
    $loops = $GLOBALS['__bk_loops'];
    $n = count($loops);
    if (!$n) return false;
    return $loops[$n - 1]['rows'][$loops[$n - 1]['i']] ?? false;
  }
}
if (!function_exists('get_bee_row_index')) {
  function get_bee_row_index(): int {
    $loops = $GLOBALS['__bk_loops'];
    $n = count($loops);
    return $n ? $loops[$n - 1]['i'] + 1 : 0;
  }
}
if (!function_exists('get_bee_row_layout')) {
  function get_bee_row_layout() {
    $row = get_bee_row();
    if (is_array($row)) {
      if (isset($row['bee_layout'])) return $row['bee_layout'];
      // Legacy flexible-row key from older imports.
      if (isset($row['acf_fc_layout'])) return $row['acf_fc_layout'];
    }
    // The layout file itself is a flexible row of the page.
    return $GLOBALS['__bk_slug'];
  }
}
if (!function_exists('reset_bee_rows')) {
  function reset_bee_rows(): bool {
    array_pop($GLOBALS['__bk_loops']);
    return true;
  }
}
if (!function_exists('bee_esc_html')) {
  function bee_esc_html($s) {
    return wp_kses_post($s);
  }
}

/* —— Legacy aliases → Bee API (existing templates keep working) —— */

if (!function_exists('get_field')) {
  function get_field($selector, $post_id = false, $format_value = true) {
    $f = $GLOBALS['__bk_fields'];
    return array_key_exists($selector, $f) ? $f[$selector] : null;
  }
}
if (!function_exists('the_field')) {
  function the_field($selector, $post_id = false, $format_value = true) {
    echo __bk_to_string(get_field($selector));
  }
}
if (!function_exists('get_fields')) {
  function get_fields($post_id = false, $format_value = true) {
    return get_bee_fields($format_value);
  }
}
if (!function_exists('get_sub_field')) {
  function get_sub_field($selector = '', $format_value = true) {
    return get_bee_field($selector, $format_value);
  }
}
if (!function_exists('the_sub_field')) {
  function the_sub_field($selector, $format_value = true) {
    the_bee_field($selector, $format_value);
  }
}
if (!function_exists('have_rows')) {
  function have_rows($selector, $post_id = false): bool {
    return have_bee_rows($selector, $post_id);
  }
}
if (!function_exists('the_row')) {
  function the_row($format = false) {
    return the_bee_row($format);
  }
}
if (!function_exists('get_row')) {
  function get_row($format = false) {
    return get_bee_row($format);
  }
}
if (!function_exists('get_row_index')) {
  function get_row_index(): int {
    return get_bee_row_index();
  }
}
if (!function_exists('get_row_layout')) {
  function get_row_layout() {
    return get_bee_row_layout();
  }
}
if (!function_exists('reset_rows')) {
  function reset_rows(): bool {
    return reset_bee_rows();
  }
}
if (!function_exists('acf_esc_html')) {
  function acf_esc_html($s) {
    return bee_esc_html($s);
  }
}

/* —— Common HTML helpers used in layout templates —— */

if (!function_exists('esc_html')) {
  function esc_html($s) {
    return htmlspecialchars(__bk_to_string($s), ENT_QUOTES, 'UTF-8');
  }
}
if (!function_exists('esc_attr')) {
  function esc_attr($s) {
    return htmlspecialchars(__bk_to_string($s), ENT_QUOTES, 'UTF-8');
  }
}
if (!function_exists('esc_textarea')) {
  function esc_textarea($s) {
    return htmlspecialchars(__bk_to_string($s), ENT_QUOTES, 'UTF-8');
  }
}
if (!function_exists('__bk_safe_url')) {
  /**
   * A URL a page may link to or load: http(s), mailto, tel, or relative. Browsers ignore
   * tabs, newlines and control characters inside a scheme ("java\tscript:"), so those
   * are removed before the scheme is checked. Returns null for anything else.
   */
  function __bk_safe_url(string $url): ?string {
    $url = trim($url);
    $probe = preg_replace('/[\x00-\x20\x7f]+/', '', $url) ?? '';
    if ($probe === '') return '';
    if (preg_match('/^([a-z][a-z0-9+.\-]*):/i', $probe, $m)) {
      return in_array(strtolower($m[1]), ['http', 'https', 'mailto', 'tel'], true) ? $url : null;
    }
    return $url;
  }
}
if (!function_exists('esc_url')) {
  function esc_url($s) {
    $u = __bk_safe_url(__bk_to_string($s));
    return $u === null ? '' : htmlspecialchars($u, ENT_QUOTES, 'UTF-8');
  }
}
if (!function_exists('esc_html__')) {
  function esc_html__($s, $domain = 'default') {
    return esc_html($s);
  }
}
if (!function_exists('esc_html_e')) {
  function esc_html_e($s, $domain = 'default') {
    echo esc_html($s);
  }
}
if (!function_exists('esc_attr_e')) {
  function esc_attr_e($s, $domain = 'default') {
    echo esc_attr($s);
  }
}
if (!function_exists('__')) {
  function __($s, $domain = 'default') {
    return $s;
  }
}
if (!function_exists('_e')) {
  function _e($s, $domain = 'default') {
    echo $s;
  }
}
if (!function_exists('__bk_kses')) {
  /**
   * Rich text that is safe to print: an allow-list of formatting tags and attributes,
   * parsed with the DOM (not regular expressions), so tricks like `<img/onerror=…>`,
   * unclosed `<script>` or "java&#x73;cript:" links cannot slip through. Unknown tags
   * keep their text; dangerous containers are dropped with their contents.
   */
  function __bk_kses(string $html): string {
    if ($html === '' || strpbrk($html, '<&') === false) return $html;
    if (!class_exists('DOMDocument')) {
      // No DOM extension: keep only plain formatting, with every attribute removed.
      $text = strip_tags($html, '<p><br><strong><b><em><i><u><s><ul><ol><li><h2><h3><h4><blockquote><code><pre>');
      return preg_replace('/<([a-z0-9]+)\b[^>]*>/i', '<$1>', $text) ?? '';
    }

    static $tags = [
      'a' => ['href', 'title', 'target', 'rel'], 'abbr' => ['title'], 'b' => [], 'blockquote' => ['cite'],
      'br' => [], 'caption' => [], 'cite' => [], 'code' => [], 'dd' => [], 'del' => [], 'div' => [],
      'dl' => [], 'dt' => [], 'em' => [], 'figcaption' => [], 'figure' => [], 'h1' => [], 'h2' => [],
      'h3' => [], 'h4' => [], 'h5' => [], 'h6' => [], 'hr' => [], 'i' => [],
      'img' => ['src', 'alt', 'width', 'height', 'loading', 'decoding'], 'ins' => [], 'kbd' => [],
      'li' => [], 'mark' => [], 'ol' => ['start', 'reversed', 'type'], 'p' => [], 'pre' => [], 'q' => ['cite'],
      's' => [], 'small' => [], 'span' => [], 'strong' => [], 'sub' => [], 'sup' => [], 'table' => [],
      'tbody' => [], 'td' => ['colspan', 'rowspan'], 'tfoot' => [], 'th' => ['colspan', 'rowspan', 'scope'],
      'thead' => [], 'time' => ['datetime'], 'tr' => [], 'u' => [], 'ul' => [],
    ];
    static $global = ['class', 'id', 'title', 'lang', 'dir', 'role', 'style'];
    static $drop = [
      'script', 'style', 'iframe', 'frame', 'frameset', 'object', 'embed', 'applet', 'noscript',
      'noembed', 'noframes', 'template', 'xmp', 'plaintext', 'textarea', 'title', 'select', 'option',
      'svg', 'math', 'base', 'link', 'meta', 'form', 'input', 'button', 'head',
    ];

    $doc = new DOMDocument();
    $previous = libxml_use_internal_errors(true);
    $doc->loadHTML(
      '<?xml encoding="utf-8" ?><html><body><div id="__bk_kses_root">' . $html . '</div></body></html>',
      LIBXML_NONET | LIBXML_COMPACT,
    );
    libxml_clear_errors();
    libxml_use_internal_errors($previous);
    $root = $doc->getElementById('__bk_kses_root');
    if (!$root) return '';

    $clean = function (DOMNode $parent) use (&$clean, $tags, $global, $drop): void {
      foreach (iterator_to_array($parent->childNodes) as $node) {
        if ($node instanceof DOMText) continue;
        if (!$node instanceof DOMElement) {
          $parent->removeChild($node); // comments, processing instructions, CDATA
          continue;
        }
        $name = strtolower($node->nodeName);
        if (in_array($name, $drop, true)) {
          $parent->removeChild($node);
          continue;
        }
        $clean($node);
        if (!isset($tags[$name])) {
          while ($node->firstChild) $parent->insertBefore($node->firstChild, $node);
          $parent->removeChild($node);
          continue;
        }
        foreach (iterator_to_array($node->attributes) as $attr) {
          $attrName = strtolower($attr->nodeName);
          $value = $attr->nodeValue ?? '';
          $keep = in_array($attrName, $tags[$name], true) || in_array($attrName, $global, true)
            || str_starts_with($attrName, 'aria-');
          if ($keep && ($attrName === 'href' || $attrName === 'src' || $attrName === 'cite')) {
            $safe = __bk_safe_url($value);
            $keep = $safe !== null;
            if ($keep) $value = $safe;
          }
          if ($keep && $attrName === 'style') {
            $keep = !preg_match('/expression|javascript|vbscript|behavior|binding|@import|url\s*\(/i', $value);
          }
          if ($keep && $attrName === 'target') {
            $keep = in_array($value, ['_blank', '_self'], true);
          }
          $node->removeAttribute($attr->nodeName);
          if ($keep) $node->setAttribute($attrName, $value);
        }
        if ($name === 'a' && $node->getAttribute('target') === '_blank') {
          $node->setAttribute('rel', 'noopener noreferrer');
        }
      }
    };
    $clean($root);

    $out = '';
    foreach ($root->childNodes as $child) $out .= $doc->saveHTML($child);
    return $out;
  }
}
if (!function_exists('wp_kses_post')) {
  function wp_kses_post($s) {
    return __bk_kses(__bk_to_string($s));
  }
}
if (!function_exists('wpautop')) {
  function wpautop($text) {
    $t = trim(str_replace(["\r\n", "\r"], "\n", (string) $text));
    if ($t === '') return '';
    if (preg_match('/^\s*<(p|div|h[1-6]|ul|ol|table|blockquote|figure|section|pre)[\s>]/i', $t)) return $t;
    $out = [];
    foreach (preg_split('/\n{2,}/', $t) as $block) {
      $out[] = '<p>' . str_replace("\n", "<br />\n", $block) . '</p>';
    }
    return implode("\n", $out);
  }
}
if (!function_exists('sanitize_title')) {
  function sanitize_title($s) {
    $s = strtolower(trim((string) $s));
    $s = preg_replace('/[^a-z0-9]+/', '-', $s) ?? '';
    return trim($s, '-');
  }
}
if (!function_exists('wp_trim_words')) {
  function wp_trim_words($text, $num_words = 55, $more = '&hellip;') {
    $words = preg_split('/\s+/', trim(strip_tags((string) $text))) ?: [];
    if (count($words) <= $num_words) return implode(' ', $words);
    return implode(' ', array_slice($words, 0, $num_words)) . $more;
  }
}
if (!function_exists('get_permalink')) {
  function get_permalink($post = 0) {
    if (is_array($post)) return $post['permalink'] ?? ($post['url'] ?? '');
    return '';
  }
}
if (!function_exists('get_the_title')) {
  function get_the_title($post = 0) {
    if (is_array($post)) return $post['post_title'] ?? '';
    return '';
  }
}
if (!function_exists('wp_get_attachment_url')) {
  function wp_get_attachment_url($id) {
    $m = $GLOBALS['__bk_media'][(string) $id] ?? null;
    return $m ? $m['url'] : false;
  }
}
if (!function_exists('wp_get_attachment_image_url')) {
  function wp_get_attachment_image_url($id, $size = 'thumbnail', $icon = false) {
    return wp_get_attachment_url($id);
  }
}
if (!function_exists('wp_get_attachment_image_src')) {
  function wp_get_attachment_image_src($id, $size = 'thumbnail', $icon = false) {
    $m = $GLOBALS['__bk_media'][(string) $id] ?? null;
    return $m ? [$m['url'], $m['width'] ?? 0, $m['height'] ?? 0, false] : false;
  }
}
if (!function_exists('wp_get_attachment_image')) {
  function wp_get_attachment_image($id, $size = 'thumbnail', $icon = false, $attr = '') {
    if (is_array($id)) $id = $id['ID'] ?? '';
    $m = $GLOBALS['__bk_media'][(string) $id] ?? null;
    if (!$m) return '';
    $a = is_array($attr) ? $attr : [];
    $a += [
      'src' => $m['url'],
      'alt' => $m['alt'] ?? '',
      'loading' => 'lazy',
      'decoding' => 'async',
    ];
    if (!empty($m['width'])) $a += ['width' => $m['width'], 'height' => $m['height']];
    $html = '<img';
    foreach ($a as $k => $v) {
      $html .= ' ' . esc_attr($k) . '="' . ($k === 'src' ? esc_url($v) : esc_attr($v)) . '"';
    }
    return $html . ' />';
  }
}
if (!function_exists('get_Section_Override')) {
  function get_Section_Override() {}
}

$args = $fields;
// One clean section class stack: {slug} section (field nodes use bk-{name}).
$classes = [$slug, 'section'];

// Optional shared helpers (e.g. themes/beekiri/shop/_helpers.php) loaded before the template.
if ($preludePath !== '' && is_file($preludePath)) {
  require_once $preludePath;
}

ob_start();
include $layoutPath;
echo ob_get_clean();
