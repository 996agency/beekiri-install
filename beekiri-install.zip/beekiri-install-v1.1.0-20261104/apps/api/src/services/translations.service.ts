import { revalidatePublicPaths } from '../lib/revalidate-public';
import { WORLD_LANGUAGES, normalizeLanguageCode } from '../lib/site/languages';
import { mergeSiteOptions, readOptions } from '../lib/site/site-options';
import {
  DEFAULT_TRANSLATIONS,
  parseTranslations,
  publicTranslations,
  type TranslationsOptions,
} from '../lib/site/translations';
import { createLogger } from '../utils/logger';
import { BadRequest, toHttpError } from '../utils/http-error';
import type { AutoTranslateInput, TranslationsInput } from '../validators/site.schema';
import { findPrimarySite, requirePrimarySite, saveSiteOptions } from './site-context';

const log = createLogger('translations');

/** How long the request router trusts its copy of the enabled languages. */
const ROUTING_TTL_MS = 5_000;

/** `primaryLanguage` is served unprefixed; every other enabled language under `/xx`. */
export type LanguageRouting = { primaryLanguage: string; prefixes: Map<string, string> };

class TranslationsService {
  private routing: { value: LanguageRouting; at: number } | null = null;

  private async load(): Promise<TranslationsOptions> {
    const site = await findPrimarySite();
    const opts = readOptions(site?.settings?.options).translations;
    return opts ?? parseTranslations(DEFAULT_TRANSLATIONS);
  }

  async getSettings() {
    try {
      return { ...(await this.load()), catalog: WORLD_LANGUAGES };
    } catch (error) {
      throw toHttpError(error, 'Could not load translations.');
    }
  }

  async updateSettings(body: TranslationsInput) {
    try {
      const site = await requirePrimarySite();
      const next = parseTranslations(body);
      await saveSiteOptions(site.id, mergeSiteOptions(site.settings?.options, { translations: next }));
      this.routing = null;
      void revalidatePublicPaths(['/']);
      return { ...next, catalog: WORLD_LANGUAGES };
    } catch (error) {
      throw toHttpError(error, 'Could not save translations.');
    }
  }

  async publicConfig(lang: string | undefined) {
    try {
      return publicTranslations(await this.load(), lang);
    } catch (error) {
      throw toHttpError(error, 'Could not load translations.');
    }
  }

  /** Language prefixes for the website router — cached, never throws. */
  async languageRouting(): Promise<LanguageRouting> {
    const now = Date.now();
    if (this.routing && now - this.routing.at < ROUTING_TTL_MS) return this.routing.value;
    let value: LanguageRouting = { primaryLanguage: 'en', prefixes: new Map() };
    try {
      const opts = await this.load();
      const prefixes = new Map<string, string>();
      for (const code of opts.languages) {
        if (code !== opts.primaryLanguage) prefixes.set(code.toLowerCase(), code);
      }
      value = { primaryLanguage: opts.primaryLanguage, prefixes };
    } catch (error) {
      log.warn(`Language routing unavailable: ${(error as Error).message}`);
      if (this.routing) value = this.routing.value;
    }
    this.routing = { value, at: now };
    return value;
  }

  /**
   * Machine suggestions from MyMemory (free, no key — the same service Lignum used).
   * Strings that fail come back missing; the editor keeps them for a manual pass.
   */
  async autoTranslate(body: AutoTranslateInput) {
    const from = normalizeLanguageCode(body.from);
    const to = normalizeLanguageCode(body.to);
    if (!from || !to || from === to) throw BadRequest('Pick two different languages.');

    const translations: Record<string, string> = {};
    let failed = 0;
    for (const text of body.texts) {
      // Numbers, prices and symbols read the same in every language.
      if (/^[\d\s.,:;%€$£+\-–—*/#@()[\]|★✓→←•·]+$/u.test(text)) {
        translations[text] = text;
        continue;
      }
      const result = await this.myMemory(text, from, to);
      if (result) translations[text] = result;
      else failed++;
    }
    return { translations, failed };
  }

  private async myMemory(text: string, from: string, to: string): Promise<string | null> {
    const url = new URL('https://api.mymemory.translated.net/get');
    url.searchParams.set('q', text);
    url.searchParams.set('langpair', `${from}|${to}`);
    try {
      const res = await fetch(url, {
        headers: { Accept: 'application/json' },
        signal: AbortSignal.timeout(15_000),
      });
      if (!res.ok) return null;
      const body = (await res.json()) as { responseData?: { translatedText?: unknown } };
      const out = body.responseData?.translatedText;
      if (typeof out !== 'string' || !out.trim()) return null;
      // Quota and error notices arrive as the "translation".
      if (/MYMEMORY WARNING|QUOTA|INVALID LANGUAGE PAIR/i.test(out)) return null;
      return out.replace(/<[^>]*>/g, '').trim() || null;
    } catch {
      return null;
    }
  }
}

export const translationsService = new TranslationsService();
