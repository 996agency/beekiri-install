import { Op } from 'sequelize';
import { refreshRoleCapabilityCache } from '../lib/auth/role-cache';
import {
  ALL_CAPABILITIES,
  CAPABILITY_CATALOG,
  diffCapabilities,
  isCapabilitySlug,
  listCachedRoles,
  resolveCapabilities,
  roleDefaults,
  roleLabel,
} from '../lib/auth/role-capabilities';
import type { CapabilitySlug, RoleSlug } from '../lib/cms-types';
import { parseDashboardLayout } from '../lib/users/dashboard-layout';
import { mergeProfileInput, normalizeProfileInput, parseProfile } from '../lib/users/users.profile';
import { AuditLog, Capability, Role, RoleCapability, Session, User, sequelize } from '../models';
import type { Json } from '../models/_shared';
import type { AuthUser } from '../types/auth';
import { hashPassword, passwordStrength, verifyPassword } from '../utils/crypto';
import { uniqueViolation } from '../utils/db-errors';
import { BadRequest, Conflict, Forbidden, NotFound, toHttpError } from '../utils/http-error';
import type {
  CreateUserInput,
  UpdateRoleInput,
  UpdateUserInput,
  UpdateUserPermissionsInput,
} from '../validators/users.schema';

const withRole = [{ model: Role, as: 'role' }];

/** Administrator accounts (and the administrator role) are only managed by administrators. */
function isAdministrator(actor: AuthUser): boolean {
  return actor.isOwner || actor.role === 'administrator';
}

function assertStrongPassword(password: string): void {
  if (passwordStrength(password) === 'weak') {
    throw BadRequest('Please choose a stronger password (longer, with mixed case, numbers or symbols).');
  }
}

type UserChanges = Partial<{
  username: string;
  email: string;
  displayName: string;
  roleId: string;
  profile: Json;
  passwordHash: string;
}>;

/** A friendly 409 for a duplicate username/email, otherwise the error unchanged. */
function duplicateUserError(error: unknown): unknown {
  const target = uniqueViolation(error);
  if (target === null) return error;
  if (target.includes('email')) return Conflict('That email is already registered on this site.');
  if (target.includes('username')) return Conflict('That username is already taken on this site.');
  return Conflict('Username or email is already in use on this site.');
}

export class UsersService {
  roles() {
    return listCachedRoles().map((r) => ({ slug: r.slug as RoleSlug, label: r.name }));
  }

  async rolesManage(actor: AuthUser) {
    try {
      if (!actor.isOwner) throw Forbidden('Only the site Owner can manage roles.');
      const roles = listCachedRoles();
      const users = await User.findAll({
        where: { siteId: actor.siteId },
        attributes: ['roleId'],
        raw: true,
      });
      const byRoleId = new Map<string, number>();
      for (const row of users as unknown as { roleId: string }[]) {
        byRoleId.set(row.roleId, (byRoleId.get(row.roleId) ?? 0) + 1);
      }
      const dbRoles = await Role.findAll();
      const idBySlug = new Map(dbRoles.map((r) => [r.slug, r.id]));
      return {
        catalog: CAPABILITY_CATALOG,
        roles: roles.map((r) => ({
          slug: r.slug,
          name: r.name,
          capabilities: r.capabilities,
          userCount: byRoleId.get(idBySlug.get(r.slug) ?? '') ?? 0,
          locked: r.slug === 'administrator',
        })),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load roles.');
    }
  }

  async updateRole(actor: AuthUser, slug: string, dto: UpdateRoleInput) {
    try {
      if (!actor.isOwner) throw Forbidden('Only the site Owner can manage roles.');
      const role = await Role.findOne({ where: { slug } });
      if (!role) throw NotFound('Role not found.');

      const nextName =
        dto.name !== undefined ? dto.name.trim().slice(0, 80) : role.name;
      if (!nextName) throw BadRequest('Role name cannot be empty.');

      let nextCaps: CapabilitySlug[] | null = null;
      if (dto.capabilities !== undefined) {
        nextCaps = dto.capabilities.filter(isCapabilitySlug) as CapabilitySlug[];
        if (!nextCaps.includes('read')) nextCaps.push('read');
        nextCaps = ALL_CAPABILITIES.filter((c) => nextCaps!.includes(c));
        // Administrator must keep the core admin set so the site stays manageable.
        if (slug === 'administrator') {
          for (const required of [
            'manage_options',
            'list_users',
            'edit_users',
            'create_users',
            'read',
          ] as CapabilitySlug[]) {
            if (!nextCaps.includes(required)) nextCaps.push(required);
          }
          nextCaps = ALL_CAPABILITIES.filter((c) => nextCaps!.includes(c));
        }
      }

      await sequelize.transaction(async (transaction) => {
        if (nextName !== role.name) {
          await role.update({ name: nextName }, { transaction });
        }
        if (nextCaps) {
          for (const cap of nextCaps) {
            await Capability.findOrCreate({
              where: { slug: cap },
              defaults: { slug: cap, name: cap },
              transaction,
            });
          }
          const caps = await Capability.findAll({
            where: { slug: nextCaps },
            transaction,
          });
          await RoleCapability.destroy({ where: { B: role.id }, transaction });
          if (caps.length) {
            await RoleCapability.bulkCreate(
              caps.map((c) => ({ A: c.id, B: role.id })),
              { transaction },
            );
          }
        }
      });

      await refreshRoleCapabilityCache();

      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'role.updated',
        meta: {
          slug,
          name: nextName,
          capabilities: nextCaps ?? roleDefaults(slug),
        },
      });

      return {
        slug: role.slug,
        name: roleLabel(role.slug),
        capabilities: roleDefaults(role.slug),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not update the role.');
    }
  }

  async list(actor: AuthUser) {
    try {
      const users = await User.findAll({
        where: { siteId: actor.siteId },
        include: withRole,
        order: [
          ['isOwner', 'DESC'],
          ['username', 'ASC'],
        ],
      });
      return { users: users.map((u) => this.serialize(u)) };
    } catch (error) {
      throw toHttpError(error, 'Could not load users.');
    }
  }

  async get(actor: AuthUser, id: string) {
    try {
      return this.serialize(await this.findForSite(actor, id));
    } catch (error) {
      throw toHttpError(error, 'Could not load the user.');
    }
  }

  async create(actor: AuthUser, dto: CreateUserInput) {
    try {
      const roleSlug = dto.role as RoleSlug;
      if (roleSlug === 'administrator' && !isAdministrator(actor)) {
        throw Forbidden('Only an administrator can create administrator accounts.');
      }
      assertStrongPassword(dto.password);
      const roleId = await this.resolveRoleId(roleSlug);
      const passwordHash = await hashPassword(dto.password);
      const profile = normalizeProfileInput({
        jobDescription: dto.jobDescription,
        customFields: dto.customFields,
      });

      const created = await User.create({
        siteId: actor.siteId,
        username: dto.username.trim(),
        email: dto.email.trim().toLowerCase(),
        displayName: dto.displayName?.trim() || dto.username,
        passwordHash,
        roleId,
        isOwner: false,
        profile,
      });

      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'user.created',
        meta: { targetUserId: created.id, username: created.username, role: roleSlug },
      });

      return this.serialize(await this.findForSite(actor, created.id));
    } catch (error) {
      throw toHttpError(duplicateUserError(error), 'Could not create the user.');
    }
  }

  async update(actor: AuthUser, id: string, dto: UpdateUserInput) {
    try {
      const existing = await this.findForSite(actor, id);
      const currentRole = (existing.role?.slug ?? 'subscriber') as RoleSlug;
      const canManageUsers = actor.capabilities.includes('edit_users');
      const isSelf = actor.id === existing.id;

      if (!isSelf && !canManageUsers) {
        throw Forbidden('Sorry, you are not allowed to do that.');
      }
      // Nobody changes their own role, whatever their capabilities: that is for the Owner
      // or another administrator to do.
      if (isSelf && dto.role !== undefined && dto.role !== currentRole) {
        throw Forbidden('You cannot change your own role.');
      }
      // The Owner account is only ever edited by the Owner.
      if (existing.isOwner && !isSelf) {
        throw Forbidden('Only the site owner can edit the owner account.');
      }
      // Administrator accounts, and promotion to administrator, are reserved for administrators.
      if (
        !isSelf &&
        !isAdministrator(actor) &&
        (currentRole === 'administrator' || dto.role === 'administrator')
      ) {
        throw Forbidden('Only an administrator can manage administrator accounts.');
      }

      const nextEmail = dto.email !== undefined ? dto.email.trim().toLowerCase() : existing.email;
      const changesCredentials = Boolean(dto.password) || nextEmail !== existing.email;
      // Changing your own email or password re-confirms the current password, so a stolen
      // session alone cannot be turned into a permanent takeover.
      if (isSelf && changesCredentials) {
        const withHash = await User.scope('withPassword').findByPk(existing.id);
        const ok =
          Boolean(dto.currentPassword) &&
          Boolean(withHash) &&
          (await verifyPassword(withHash!.passwordHash, dto.currentPassword!));
        if (!ok) {
          throw Forbidden('Enter your current password to change your email or password.');
        }
      }
      if (dto.password) assertStrongPassword(dto.password);

      const roleDto = !isSelf && canManageUsers ? dto.role : undefined;

      if (existing.isOwner && roleDto && roleDto !== 'administrator') {
        throw Forbidden('The site owner must remain an administrator.');
      }

      const nextRole = (existing.isOwner ? 'administrator' : (roleDto ?? currentRole)) as RoleSlug;
      if (currentRole === 'administrator' && nextRole !== 'administrator') {
        const remaining = await this.countAdministrators(actor.siteId, existing.id);
        if (remaining < 1) {
          throw BadRequest('You cannot remove the last administrator. Promote another user first.');
        }
        if (existing.id === actor.id) {
          throw Forbidden('You cannot demote your own administrator account.');
        }
      }

      const data: UserChanges = {};
      if (dto.username !== undefined) data.username = dto.username.trim();
      if (dto.email !== undefined) data.email = dto.email.trim().toLowerCase();
      if (dto.displayName !== undefined) data.displayName = dto.displayName.trim();
      if (roleDto !== undefined) data.roleId = await this.resolveRoleId(nextRole);
      if (dto.jobDescription !== undefined || dto.customFields !== undefined) {
        const current = parseProfile(existing.profile);
        data.profile = mergeProfileInput(current, {
          jobDescription: dto.jobDescription,
          customFields: dto.customFields,
        });
      }

      const passwordChanged = Boolean(dto.password);
      if (dto.password) data.passwordHash = await hashPassword(dto.password);

      await sequelize.transaction(async (transaction) => {
        await User.update(data, { where: { id: existing.id }, transaction });
        if (passwordChanged) await Session.destroy({ where: { userId: existing.id }, transaction });
      });
      const user = await this.findForSite(actor, existing.id);

      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'user.updated',
        meta: { targetUserId: user.id, passwordChanged, role: user.role?.slug },
      });

      return this.serialize(user);
    } catch (error) {
      throw toHttpError(duplicateUserError(error), 'Could not update the user.');
    }
  }

  async remove(actor: AuthUser, id: string) {
    try {
      if (actor.id === id) throw Forbidden('You cannot delete your own account.');

      const existing = await this.findForSite(actor, id);
      if (existing.isOwner) throw Forbidden('The site owner account cannot be deleted.');

      if (existing.role?.slug === 'administrator') {
        if (!isAdministrator(actor)) {
          throw Forbidden('Only an administrator can delete administrator accounts.');
        }
        const remaining = await this.countAdministrators(actor.siteId, existing.id);
        if (remaining < 1) {
          throw BadRequest('You cannot delete the last administrator. Promote another user first.');
        }
      }

      await sequelize.transaction(async (transaction) => {
        await Session.destroy({ where: { userId: existing.id }, transaction });
        await User.destroy({ where: { id: existing.id }, transaction });
      });

      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'user.deleted',
        meta: { targetUserId: existing.id, username: existing.username },
      });

      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not delete the user.');
    }
  }

  async getDashboardLayout(actor: AuthUser) {
    try {
      const user = await this.findForSite(actor, actor.id);
      return { layout: parseProfile(user.profile).dashboardLayout };
    } catch (error) {
      throw toHttpError(error, 'Could not load dashboard layout.');
    }
  }

  async setDashboardLayout(actor: AuthUser, layout: { id: string; span: number }[]) {
    try {
      const user = await this.findForSite(actor, actor.id);
      const parsed = parseDashboardLayout(layout);
      const current = parseProfile(user.profile);
      const profile = mergeProfileInput(current, { dashboardLayout: parsed });
      await User.update({ profile }, { where: { id: user.id } });
      return { layout: profile.dashboardLayout };
    } catch (error) {
      throw toHttpError(error, 'Could not save dashboard layout.');
    }
  }

  permissionsCatalog() {
    return { catalog: CAPABILITY_CATALOG };
  }

  async permissionsOverview(actor: AuthUser) {
    try {
      if (!actor.isOwner) throw Forbidden('Only the site Owner can manage user permissions.');
      const users = await User.findAll({
        where: { siteId: actor.siteId },
        include: withRole,
        order: [
          ['isOwner', 'DESC'],
          ['username', 'ASC'],
        ],
      });
      return {
        catalog: CAPABILITY_CATALOG,
        users: users.map((u) => this.serializePermissions(u)),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load user permissions.');
    }
  }

  async updatePermissions(actor: AuthUser, id: string, dto: UpdateUserPermissionsInput) {
    try {
      if (!actor.isOwner) throw Forbidden('Only the site Owner can manage user permissions.');
      const existing = await this.findForSite(actor, id);
      if (existing.isOwner) {
        throw Forbidden('The site owner always has full privileges and cannot be limited.');
      }

      const role = (existing.role?.slug ?? 'subscriber') as RoleSlug;
      const desired = (dto.capabilities ?? []).filter(isCapabilitySlug) as CapabilitySlug[];
      if (!desired.includes('read')) desired.push('read');
      const { grants, denies } = diffCapabilities(role, desired);
      const current = parseProfile(existing.profile);
      const profile = mergeProfileInput(current, {
        capabilityGrants: grants,
        capabilityDenies: denies,
      });

      await User.update({ profile }, { where: { id: existing.id } });

      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'user.permissions_updated',
        meta: { targetUserId: existing.id, grants, denies },
      });

      return this.serializePermissions(await this.findForSite(actor, existing.id));
    } catch (error) {
      throw toHttpError(error, 'Could not update user permissions.');
    }
  }

  private serializePermissions(user: User) {
    const role = (user.role?.slug ?? 'subscriber') as RoleSlug;
    const profile = parseProfile(user.profile);
    const capabilities = resolveCapabilities({
      role,
      isOwner: user.isOwner,
      grants: profile.capabilityGrants,
      denies: profile.capabilityDenies,
    });
    return {
      id: user.id,
      username: user.username,
      displayName: user.displayName,
      email: user.email,
      role,
      roleLabel: roleLabel(role),
      isOwner: user.isOwner,
      roleDefaults: roleDefaults(role),
      grants: profile.capabilityGrants,
      denies: profile.capabilityDenies,
      capabilities,
    };
  }

  private serialize(user: User) {
    const role = (user.role?.slug ?? 'subscriber') as RoleSlug;
    const profile = parseProfile(user.profile);
    return {
      id: user.id,
      username: user.username,
      email: user.email,
      displayName: user.displayName,
      role,
      roleLabel: roleLabel(role),
      isOwner: user.isOwner,
      jobDescription: profile.jobDescription,
      customFields: profile.customFields,
      createdAt: user.createdAt.toISOString(),
      updatedAt: user.updatedAt.toISOString(),
    };
  }

  private async findForSite(actor: AuthUser, id: string): Promise<User> {
    const user = await User.findOne({ where: { id, siteId: actor.siteId }, include: withRole });
    if (!user) throw NotFound('User not found.');
    return user;
  }

  private countAdministrators(siteId: string, excludeUserId?: string): Promise<number> {
    return User.count({
      where: { siteId, ...(excludeUserId ? { id: { [Op.ne]: excludeUserId } } : {}) },
      include: [{ model: Role, as: 'role', where: { slug: 'administrator' }, attributes: [] }],
    });
  }

  private async resolveRoleId(slug: RoleSlug): Promise<string> {
    const role = await Role.findOne({ where: { slug } });
    if (!role) throw BadRequest(`Unknown role “${slug}”.`);
    return role.id;
  }
}

export const usersService = new UsersService();
