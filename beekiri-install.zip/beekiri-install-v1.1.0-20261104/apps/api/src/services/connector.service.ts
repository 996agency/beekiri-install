import { mergeSiteOptions, readOptions } from '../lib/site/site-options';
import {
  anthropicKey,
  BEEQUEEN_KEY_PREFIX,
  beeQueenService,
  beeQueenServiceUrl,
  CONNECTOR_PROVIDER_CATALOG,
  CONNECTOR_PROVIDER_IDS,
  DEFAULT_EFFORT,
  isConnectorProviderId,
  maskApiKey,
  normalizeServiceUrl,
  parseConnector,
  type ConnectorOptions,
  type ConnectorProviderId,
} from '../lib/site/connector';
import { findClaudeCli } from '../lib/beequeen/claude-code';
import { beeQueenServiceClient } from '../lib/beequeen/service-client';
import { BadRequest, NotFound, toHttpError } from '../utils/http-error';
import type { UpdateConnectorInput } from '../validators/connector.schema';
import { requirePrimarySite, saveSiteOptions } from './site-context';

/** BeeQueen is ready with a BeeQueen site key — or, for the owner's own testing, an Anthropic key or Claude Code. */
function isConfigured(id: ConnectorProviderId, opts: ConnectorOptions) {
  if (id === 'beequeen') return Boolean(beeQueenService(opts) || anthropicKey(opts) || findClaudeCli());
  return Boolean(opts.providers[id]?.apiKey?.trim());
}

/** What BeeQueen runs on — shown on its setup page. */
function beeQueenKeySource(opts: ConnectorOptions): 'service' | 'claude' | 'env' | 'claude-code' | null {
  if (beeQueenService(opts)) return 'service';
  if (opts.providers.claude.apiKey.trim()) return 'claude';
  if ((process.env.ANTHROPIC_API_KEY ?? '').trim()) return 'env';
  // No key: local testing through Claude Code signed in on this machine.
  if (findClaudeCli()) return 'claude-code';
  return null;
}

async function siteConnector(): Promise<ConnectorOptions> {
  const site = await requirePrimarySite();
  return parseConnector(readOptions(site.settings?.options).connector);
}

function listPublic(opts: ConnectorOptions) {
  return {
    providers: CONNECTOR_PROVIDER_CATALOG.filter((p) => !p.hidden).map((p) => {
      const state = opts.providers[p.id];
      return {
        id: p.id,
        name: p.name,
        vendor: p.vendor,
        blurb: p.blurb,
        badge: p.badge,
        enabled: state?.enabled ?? false,
        configured: isConfigured(p.id, opts),
        defaultModel: state?.defaultModel ?? p.models[0]?.id ?? '',
        effort: state?.effort ?? DEFAULT_EFFORT,
      };
    }),
  };
}

function detailPublic(id: ConnectorProviderId, opts: ConnectorOptions) {
  const meta = CONNECTOR_PROVIDER_CATALOG.find((p) => p.id === id);
  if (!meta) throw NotFound('Provider not found.');
  const state = opts.providers[id];
  return {
    id: meta.id,
    name: meta.name,
    vendor: meta.vendor,
    blurb: meta.blurb,
    badge: meta.badge,
    docsUrl: meta.docsUrl,
    apiKeyLabel: meta.apiKeyLabel,
    apiKeyPlaceholder: meta.apiKeyPlaceholder,
    models: meta.models,
    enabled: state?.enabled ?? false,
    supportsEffort: Boolean(meta.supportsEffort),
    configured: isConfigured(id, opts),
    apiKeyMasked: maskApiKey(state?.apiKey ?? ''),
    keySource: id === 'beequeen' ? beeQueenKeySource(opts) : null,
    defaultModel: state?.defaultModel ?? meta.models[0]?.id ?? '',
    effort: state?.effort ?? DEFAULT_EFFORT,
    serviceUrl: id === 'beequeen' ? beeQueenServiceUrl(opts) : null,
  };
}

class ConnectorService {
  async get() {
    try {
      const site = await requirePrimarySite();
      const opts = parseConnector(readOptions(site.settings?.options).connector);
      return listPublic(opts);
    } catch (error) {
      throw toHttpError(error, 'Could not load Connector.');
    }
  }

  async getProvider(providerId: string) {
    try {
      if (!isConnectorProviderId(providerId) || CONNECTOR_PROVIDER_CATALOG.find((p) => p.id === providerId)?.hidden) {
        throw NotFound('Provider not found.');
      }
      const site = await requirePrimarySite();
      const opts = parseConnector(readOptions(site.settings?.options).connector);
      return detailPublic(providerId, opts);
    } catch (error) {
      throw toHttpError(error, 'Could not load provider.');
    }
  }

  async update(dto: UpdateConnectorInput) {
    try {
      const site = await requirePrimarySite();
      const current = parseConnector(readOptions(site.settings?.options).connector);
      const next: ConnectorOptions = {
        providers: { ...current.providers },
      };
      for (const id of CONNECTOR_PROVIDER_IDS) {
        next.providers[id] = { ...current.providers[id] };
      }

      const row = { ...next.providers[dto.providerId] };
      if (dto.enabled !== undefined) row.enabled = dto.enabled;
      if (dto.apiKey !== undefined) {
        const key = dto.apiKey.trim();
        if (dto.providerId === 'beequeen' && key && !key.startsWith(BEEQUEEN_KEY_PREFIX)) {
          throw BadRequest(`That is not a BeeQueen site key — it starts with ${BEEQUEEN_KEY_PREFIX}. Ask 996Agency for one.`);
        }
        row.apiKey = key;
      }
      if (dto.serviceUrl !== undefined && dto.providerId === 'beequeen') {
        const url = normalizeServiceUrl(dto.serviceUrl);
        if (!url) throw BadRequest('Enter the BeeQueen server address, e.g. https://996agency.com');
        row.serviceUrl = url;
      }
      if (dto.defaultModel !== undefined) {
        const allowed = CONNECTOR_PROVIDER_CATALOG.find((p) => p.id === dto.providerId)?.models ?? [];
        if (!allowed.some((m) => m.id === dto.defaultModel)) {
          throw BadRequest('That model is not available for this provider.');
        }
        row.defaultModel = dto.defaultModel;
      }
      if (dto.effort !== undefined) row.effort = dto.effort;
      next.providers[dto.providerId] = row;

      await saveSiteOptions(
        site.id,
        mergeSiteOptions(site.settings?.options, { connector: next }),
      );

      // List response when only toggling from the grid; detail when setup fields present.
      if (
        dto.apiKey !== undefined ||
        dto.defaultModel !== undefined ||
        dto.effort !== undefined ||
        dto.serviceUrl !== undefined
      ) {
        return detailPublic(dto.providerId, next);
      }
      return listPublic(next);
    } catch (error) {
      throw toHttpError(error, 'Could not update Connector.');
    }
  }

  /** This site's BeeQueen account from the service: credits, packs, requests, history. */
  async beeQueenAccount() {
    try {
      const conn = beeQueenService(await siteConnector());
      if (!conn) return { connected: false as const };
      return { connected: true as const, serviceUrl: conn.url, ...(await beeQueenServiceClient.account(conn)) };
    } catch (error) {
      throw toHttpError(error, 'Could not load the BeeQueen account.');
    }
  }

  /** Ask 996Agency for a pack; credits arrive when they approve it. */
  async requestBeeQueenPack(pack: string) {
    try {
      const conn = beeQueenService(await siteConnector());
      if (!conn) throw BadRequest('Add this site’s BeeQueen key first.');
      return { connected: true as const, serviceUrl: conn.url, ...(await beeQueenServiceClient.requestPack(conn, pack)) };
    } catch (error) {
      throw toHttpError(error, 'Could not request the pack.');
    }
  }
}

export const connectorService = new ConnectorService();
