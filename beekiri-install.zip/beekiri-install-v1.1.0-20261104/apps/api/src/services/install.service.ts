import { Op, type Transaction } from 'sequelize';
import { config } from '../config/env';
import { pingDatabase } from '../db/sequelize';
import { ROLE_CAPABILITIES, roleLabel } from '../lib/auth/role-capabilities';
import type { RoleSlug } from '../lib/cms-types';
import { FRONTEND_RUNTIMES, type SiteOptions } from '../lib/site/site-options';
import { DEFAULT_THEME_SLUG } from '../lib/themes/theme-registry';
import {
  AuditLog,
  Capability,
  InstallationState,
  Role,
  RoleCapability,
  Site,
  SiteSettings,
  User,
  sequelize,
} from '../models';
import { clearSetupToken } from '../lib/setup-token';
import { hashPassword, passwordStrength, randomToken } from '../utils/crypto';
import { Conflict, HttpError, ServiceUnavailable, toHttpError } from '../utils/http-error';
import { createLogger } from '../utils/logger';
import type { InstallInput } from '../validators/install.schema';

const STALE_LOCK_MS = 5 * 60 * 1000;
const log = createLogger('install');

/** Roles + capabilities (idempotent). */
export async function seedRolesAndCapabilities(transaction?: Transaction): Promise<void> {
  for (const [slug, caps] of Object.entries(ROLE_CAPABILITIES) as [RoleSlug, string[]][]) {
    const [role] = await Role.findOrCreate({
      where: { slug },
      defaults: { slug, name: roleLabel(slug) },
      transaction,
    });
    for (const cap of caps) {
      const [capability] = await Capability.findOrCreate({
        where: { slug: cap },
        defaults: { slug: cap, name: cap },
        transaction,
      });
      await RoleCapability.bulkCreate([{ A: capability.id, B: role.id }], {
        ignoreDuplicates: true,
        transaction,
      });
    }
  }
}

export class InstallService {
  async ensureInstallationRow(): Promise<void> {
    try {
      await InstallationState.findOrCreate({
        where: { id: 1 },
        defaults: { id: 1, installed: false },
      });
    } catch (error) {
      throw toHttpError(error, 'Could not read the installation state.');
    }
  }

  async getStatus() {
    if (!config.databaseConfigured) {
      return {
        installed: false,
        databaseConfigured: false,
        databaseOk: false,
        databaseMessage: 'Enter your database details to continue.',
        canInstall: false,
        frontendRuntimes: FRONTEND_RUNTIMES,
      };
    }
    try {
      let databaseOk = await pingDatabase();
      let databaseMessage = databaseOk
        ? 'Database connected.'
        : 'Cannot reach PostgreSQL. Check the DB_* settings in apps/api/.env, then retry.';

      let installed = false;
      if (databaseOk) {
        try {
          await InstallationState.findOrCreate({
            where: { id: 1 },
            defaults: { id: 1, installed: false },
          });
          const state = await InstallationState.findByPk(1);
          installed = Boolean(state?.installed);
          databaseMessage = installed
            ? 'Database connected. This site is already installed.'
            : 'Database connected. You can create this site.';
        } catch (error) {
          // This answer is public: the details go to the server log only.
          log.error('Install status: database check failed', error);
          databaseOk = false;
          databaseMessage =
            'The database answered with an error. See the server log, run "npm run db:migrate", then retry.';
        }
      }

      return {
        installed,
        databaseConfigured: true,
        databaseOk,
        databaseMessage,
        canInstall: databaseOk && !installed,
        frontendRuntimes: FRONTEND_RUNTIMES,
      };
    } catch (error) {
      throw toHttpError(error, 'Could not read the installation status.');
    }
  }

  async install(dto: InstallInput, meta: { ip?: string; userAgent?: string }) {
    await this.ensureInstallationRow();

    if (passwordStrength(dto.password) === 'weak') {
      throw Conflict({ message: 'Please choose a stronger password.', code: 'weak_password' });
    }

    const lockOwner = randomToken(16);
    try {
      const site = await sequelize.transaction(async (transaction) => {
        await this.claimInstallLock(lockOwner, transaction);
        await seedRolesAndCapabilities(transaction);

        const adminRole = await Role.findOne({ where: { slug: 'administrator' }, transaction });
        if (!adminRole) throw new Error('Administrator role is missing.');
        const passwordHash = await hashPassword(dto.password);

        const options: SiteOptions = {
          activeTheme: DEFAULT_THEME_SLUG,
          frontendRuntime: dto.frontendRuntime,
        };

        const created = await Site.create(
          { title: dto.siteTitle, language: dto.language },
          { transaction },
        );
        await SiteSettings.create(
          { siteId: created.id, blogPublic: dto.blogPublic, options },
          { transaction },
        );
        const owner = await User.create(
          {
            siteId: created.id,
            username: dto.username,
            email: dto.email.toLowerCase(),
            displayName: dto.username,
            passwordHash,
            isOwner: true,
            roleId: adminRole.id,
          },
          { transaction },
        );

        await InstallationState.update(
          { installed: true, installedAt: new Date(), lockedAt: null, lockOwner: null },
          { where: { id: 1 }, transaction },
        );

        await AuditLog.create(
          {
            siteId: created.id,
            userId: owner.id,
            action: 'site.installed',
            meta: {
              language: dto.language,
              blogPublic: dto.blogPublic,
              frontendRuntime: dto.frontendRuntime,
            },
            ip: meta.ip ?? null,
          },
          { transaction },
        );

        return created;
      });

      clearSetupToken();
      return { ok: true, siteTitle: site.title, username: dto.username };
    } catch (error) {
      // Release the lock if we held it and failed mid-way (recoverable).
      await InstallationState.update(
        { lockedAt: null, lockOwner: null },
        { where: { id: 1, lockOwner, installed: false } },
      ).catch(() => undefined);

      if (error instanceof HttpError && error.status === 409) throw error;
      throw ServiceUnavailable({
        message:
          error instanceof Error
            ? `Installation failed: ${error.message}. You may retry after fixing the issue.`
            : 'Installation failed. You may retry.',
        code: 'install_failed',
      });
    }
  }

  /** Serialize installers: claim the lock only if not installed and unlocked (or stale). */
  private async claimInstallLock(lockOwner: string, transaction: Transaction): Promise<void> {
    const [claimed] = await InstallationState.update(
      { lockedAt: new Date(), lockOwner },
      {
        where: {
          id: 1,
          installed: false,
          [Op.or]: [
            { lockedAt: null },
            { lockedAt: { [Op.lt]: new Date(Date.now() - STALE_LOCK_MS) } },
          ],
        },
        transaction,
      },
    );
    if (claimed > 0) return;

    const current = await InstallationState.findByPk(1, { transaction });
    if (current?.installed) {
      throw Conflict({ message: 'Already Installed', code: 'already_installed' });
    }
    throw Conflict({
      message: 'Another installation is in progress. Please wait and retry.',
      code: 'install_in_progress',
    });
  }
}

export const installService = new InstallService();
