import {
  capsAllowSettings,
} from '../lib/auth/role-capabilities';
import {
  DEFAULT_ADMIN_BASE_PATH,
  DEFAULT_ADMIN_LOGIN_SLUG,
  adminHref,
  adminLoginPath,
  normalizeAdminBasePath,
  normalizeAdminLoginSlug,
} from '../lib/site/admin-login';
import { bumpAdminBasePathCache } from '../lib/site/admin-base-cache';
import { listLinkTargets } from '../lib/site/link-targets';
import {
  DEFAULT_FAVICON_PATH,
  defaultMediaSettings,
  defaultMenuItems,
  mergeSiteOptions,
  parseMediaSettings,
  publicMenuItems,
  readOptions,
  resolveFaviconUrl,
} from '../lib/site/site-options';
import {
  DEFAULT_THEME_SLUG,
  getThemeManifest,
  resolveActiveChrome,
} from '../lib/themes/theme-registry';
import { Post, Site, SiteSettings, sequelize } from '../models';
import type { Json } from '../models/_shared';
import type { AuthUser } from '../types/auth';
import type { CapabilitySlug } from '../lib/cms-types';
import { BadRequest, Forbidden, toHttpError } from '../utils/http-error';
import type { UpdateSiteSettingsInput } from '../validators/site.schema';
import { pagesService } from './pages.service';
import { findPrimarySite, requirePrimarySite } from './site-context';

function normalizePublicPath(raw: string): string {
  let path = (raw || '/').split('?')[0]!.split('#')[0]!.trim() || '/';
  if (!path.startsWith('/')) path = `/${path}`;
  if (path.length > 1 && path.endsWith('/')) path = path.slice(0, -1);
  return path || '/';
}

function editHrefForPost(basePath: string, type: string, id: string): string {
  if (type === 'page') return adminHref(basePath, `pages/${id}`);
  if (type === 'post') return adminHref(basePath, `posts/${id}`);
  return adminHref(basePath, `content/${encodeURIComponent(type)}/${id}`);
}

type SitePatch = Partial<{ title: string; tagline: string; language: string }>;
type SettingsPatch = Partial<{
  blogPublic: boolean;
  timezone: string;
  dateFormat: string;
  timeFormat: string;
  options: Json;
}>;

function resolveActiveTheme(raw?: string): string {
  const slug = (raw ?? '').trim() || DEFAULT_THEME_SLUG;
  return getThemeManifest(slug) ? slug : DEFAULT_THEME_SLUG;
}

const runtimeOf = (opts: { frontendRuntime?: string }) =>
  opts.frontendRuntime === 'react' ? ('react' as const) : ('php' as const);

function slugFromLabel(label: string) {
  return label
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 180);
}

function serializeSettings(site: Site) {
  const settings = site.settings ?? null;
  const opts = readOptions(settings?.options);
  return {
    id: site.id,
    title: site.title,
    tagline: site.tagline,
    language: site.language,
    blogPublic: settings?.blogPublic ?? true,
    timezone: settings?.timezone ?? 'UTC',
    dateFormat: settings?.dateFormat ?? 'F j, Y',
    timeFormat: settings?.timeFormat ?? 'g:i a',
    businessName: opts.businessName ?? '',
    businessCategory: opts.businessCategory ?? '',
    businessPhone: opts.businessPhone ?? '',
    businessAddress: opts.businessAddress ?? '',
    businessHours: opts.businessHours ?? '',
    businessImageUrl: opts.businessImageUrl ?? '',
    faviconUrl: opts.faviconUrl ?? '',
    faviconResolved: resolveFaviconUrl(opts.faviconUrl),
    faviconDefault: DEFAULT_FAVICON_PATH,
    adminBasePath: normalizeAdminBasePath(opts.adminBasePath ?? DEFAULT_ADMIN_BASE_PATH),
    adminLoginSlug: normalizeAdminLoginSlug(opts.adminLoginSlug ?? DEFAULT_ADMIN_LOGIN_SLUG),
    adminLoginPath: adminLoginPath(opts.adminLoginSlug, opts.adminBasePath),
    permalinkStructure: opts.permalinkStructure ?? 'postname',
    permalinkCustom: opts.permalinkCustom ?? '/%postname%/',
    menuItems: opts.menuItems?.length ? opts.menuItems : defaultMenuItems(),
    frontPageId: opts.frontPageId ?? '',
    frontPageSlug: opts.frontPageSlug ?? '',
    media: opts.media ? parseMediaSettings(opts.media) : defaultMediaSettings(),
    activeTheme: resolveActiveTheme(opts.activeTheme),
    pageEditorStyle: 'beekiricode' as const,
    frontendRuntime: runtimeOf(opts),
    customHeadHtml: opts.customHeadHtml ?? '',
    customBodyHtml: opts.customBodyHtml ?? '',
    customFooterHtml: opts.customFooterHtml ?? '',
  };
}

/**
 * Which Settings tab each field belongs to. A user who was given one tab may only
 * change that tab's fields; the site-code slots inject HTML on every public page and
 * stay with full administrators.
 */
const SETTINGS_FIELD_CAPABILITY: Record<keyof UpdateSiteSettingsInput, CapabilitySlug> = {
  title: 'manage_settings_general',
  tagline: 'manage_settings_general',
  businessName: 'manage_settings_general',
  businessCategory: 'manage_settings_general',
  businessPhone: 'manage_settings_general',
  businessAddress: 'manage_settings_general',
  businessHours: 'manage_settings_general',
  businessImageUrl: 'manage_settings_general',
  faviconUrl: 'manage_settings_general',
  blogPublic: 'manage_settings_reading',
  frontPageId: 'manage_settings_reading',
  frontPageSlug: 'manage_settings_reading',
  menuItems: 'manage_settings_reading',
  dateFormat: 'manage_settings_writing',
  timeFormat: 'manage_settings_writing',
  pageEditorStyle: 'manage_settings_page_editor',
  frontendRuntime: 'manage_settings_page_editor',
  language: 'manage_settings_advanced',
  timezone: 'manage_settings_advanced',
  adminBasePath: 'manage_settings_advanced',
  adminLoginSlug: 'manage_settings_advanced',
  permalinkStructure: 'manage_settings_permalinks',
  permalinkCustom: 'manage_settings_permalinks',
  media: 'manage_settings_media',
  customHeadHtml: 'manage_options',
  customBodyHtml: 'manage_options',
  customFooterHtml: 'manage_options',
};

export class SiteService {
  /** Fields the actor sends but may not change (and that differ from what is stored) are refused. */
  private assertMayChangeFields(
    actor: AuthUser,
    body: UpdateSiteSettingsInput,
    current: Record<string, unknown>,
  ): void {
    if (actor.capabilities.includes('manage_options')) return;
    for (const key of Object.keys(body) as (keyof UpdateSiteSettingsInput)[]) {
      const value = body[key];
      if (value === undefined) continue;
      const required = SETTINGS_FIELD_CAPABILITY[key] ?? 'manage_options';
      if (actor.capabilities.includes(required)) continue;
      // The admin posts whole forms; untouched fields are fine, changed ones are not.
      if (JSON.stringify(value) === JSON.stringify(current[key] ?? '')) continue;
      throw Forbidden(`You are not allowed to change "${key}".`);
    }
  }

  async linkTargets() {
    try {
      const base = listLinkTargets();
      const site = await Site.findOne({ order: [['createdAt', 'ASC']] });
      if (!site) return base;
      const [pages, posts] = await Promise.all([
        pagesService.listPublishedTargets(site.id, 'page'),
        pagesService.listPublishedTargets(site.id, 'post'),
      ]);
      return { ...base, pages, posts };
    } catch (error) {
      throw toHttpError(error, 'Could not load link targets.');
    }
  }

  /** Lightweight preference for the page editor (editors + admins). */
  async pageEditor() {
    try {
      const site = await findPrimarySite();
      return {
        pageEditorStyle: 'beekiricode' as const,
        frontendRuntime: runtimeOf(readOptions(site?.settings?.options)),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load page editor settings.');
    }
  }

  /**
   * Floating front-end admin dock (Edit / Settings / Admin) for signed-in users.
   * Only returns items the actor may use; visitors get an empty list.
   */
  async adminDock(actor: AuthUser, rawPath: string) {
    try {
      const caps = actor.capabilities ?? [];
      const items: { id: string; label: string; href: string }[] = [];
      const path = normalizePublicPath(rawPath);
      const site = await findPrimarySite();
      const opts = readOptions(site?.settings?.options);
      const basePath = normalizeAdminBasePath(opts.adminBasePath ?? DEFAULT_ADMIN_BASE_PATH);

      const canEditPages = caps.includes('edit_pages');
      const canEditPosts = caps.includes('edit_posts');
      const canSettings = capsAllowSettings(caps);

      if ((canEditPages || canEditPosts) && site) {
        let row: Post | null = null;
        if (path === '/') {
          if (opts.frontPageId) {
            row = await Post.findOne({
              where: {
                siteId: site.id,
                type: 'page',
                id: opts.frontPageId,
                status: 'publish',
              },
            });
          }
          if (!row && opts.frontPageSlug) {
            row = await Post.findOne({
              where: {
                siteId: site.id,
                type: 'page',
                slug: opts.frontPageSlug,
                status: 'publish',
              },
            });
          }
        } else if (path.startsWith('/blog/')) {
          const slug = path.slice('/blog/'.length);
          if (slug && !slug.includes('/')) {
            row = await Post.findOne({
              where: { siteId: site.id, type: 'post', slug, status: 'publish' },
            });
          }
        } else {
          const parts = path.slice(1).split('/').filter(Boolean);
          if (parts.length === 1 && parts[0]) {
            row = await Post.findOne({
              where: { siteId: site.id, type: 'page', slug: parts[0], status: 'publish' },
            });
          } else if (parts.length === 2 && parts[0] && parts[1]) {
            row = await Post.findOne({
              where: {
                siteId: site.id,
                type: parts[0],
                slug: parts[1],
                status: 'publish',
              },
            });
          }
        }

        if (row) {
          const type = row.type || 'page';
          const allowed =
            (type === 'page' && canEditPages) ||
            (type === 'post' && canEditPosts) ||
            (type !== 'page' && type !== 'post' && canEditPosts);
          if (allowed) {
            items.push({
              id: 'edit',
              label: type === 'post' ? 'Edit post' : 'Edit page',
              href: editHrefForPost(basePath, type, row.id),
            });
          }
        }
      }

      if (canSettings) {
        items.push({
          id: 'settings',
          label: 'Settings',
          href: adminHref(basePath, 'settings'),
        });
      }

      if (caps.includes('read')) {
        items.push({ id: 'admin', label: 'Admin', href: adminHref(basePath) });
      }

      return { items };
    } catch (error) {
      throw toHttpError(error, 'Could not load admin shortcuts.');
    }
  }

  async publicSite() {
    try {
      const site = await findPrimarySite();
      if (!site) return { installed: false };
      const opts = readOptions(site.settings?.options);
      const theme = resolveActiveTheme(opts.activeTheme);
      return {
        installed: true,
        id: site.id,
        title: site.title,
        tagline: site.tagline,
        language: site.language,
        blogPublic: site.settings?.blogPublic ?? true,
        business: {
          name: (opts.businessName || site.title).trim(),
          category: opts.businessCategory ?? '',
          phone: opts.businessPhone ?? '',
          address: opts.businessAddress ?? '',
          hours: opts.businessHours ?? '',
          imageUrl: opts.businessImageUrl ?? '',
        },
        faviconUrl: resolveFaviconUrl(opts.faviconUrl),
        permalinkStructure: opts.permalinkStructure ?? 'postname',
        theme,
        header: resolveActiveChrome(theme, 'header', opts.activeHeader)?.slug ?? null,
        footer: resolveActiveChrome(theme, 'footer', opts.activeFooter)?.slug ?? null,
        frontendRuntime: runtimeOf(opts),
        frontPageId: opts.frontPageId ?? null,
        frontPageSlug: opts.frontPageSlug ?? null,
        menu: publicMenuItems(opts),
        customHeadHtml: opts.customHeadHtml ?? '',
        customBodyHtml: opts.customBodyHtml ?? '',
        customFooterHtml: opts.customFooterHtml ?? '',
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load the site.');
    }
  }

  async getSettings() {
    try {
      return serializeSettings(await requirePrimarySite());
    } catch (error) {
      throw toHttpError(error, 'Could not load site settings.');
    }
  }

  async updateSettings(actor: AuthUser, body: UpdateSiteSettingsInput) {
    try {
      const site = await requirePrimarySite();
      this.assertMayChangeFields(actor, body, serializeSettings(site));

      const currentRuntime = readOptions(site.settings?.options).frontendRuntime ?? 'php';
      if (body.frontendRuntime !== undefined && body.frontendRuntime !== currentRuntime) {
        throw BadRequest({
          message:
            `This site was installed with the ${currentRuntime.toUpperCase()} frontend. ` +
            'The frontend runtime is locked after install. To use a different one, install a new site into an empty database.',
          code: 'frontend_runtime_locked',
        });
      }

      const nextOptions = mergeSiteOptions(site.settings?.options, {
        businessName: body.businessName,
        businessCategory: body.businessCategory,
        businessPhone: body.businessPhone,
        businessAddress: body.businessAddress,
        businessHours: body.businessHours,
        businessImageUrl: body.businessImageUrl,
        faviconUrl: body.faviconUrl,
        adminBasePath:
          body.adminBasePath !== undefined
            ? normalizeAdminBasePath(body.adminBasePath)
            : undefined,
        adminLoginSlug:
          body.adminLoginSlug !== undefined
            ? normalizeAdminLoginSlug(body.adminLoginSlug)
            : undefined,
        permalinkStructure: body.permalinkStructure,
        permalinkCustom: body.permalinkCustom,
        menuItems: body.menuItems,
        frontPageId: body.frontPageId,
        frontPageSlug: body.frontPageSlug,
        media: body.media ? parseMediaSettings(body.media) : undefined,
        pageEditorStyle: body.pageEditorStyle,
        customHeadHtml: body.customHeadHtml,
        customBodyHtml: body.customBodyHtml,
        customFooterHtml: body.customFooterHtml,
      });

      // Keep the front-page pointer in sync with the menu item that owns `/`.
      if (body.menuItems?.length) {
        const front = body.menuItems.find((m) => ((m.path || '').trim() || '/') === '/');
        if (front?.refId) nextOptions.frontPageId = front.refId;
        if (body.frontPageSlug?.trim()) {
          nextOptions.frontPageSlug = body.frontPageSlug.trim();
        } else if (front?.label && !nextOptions.frontPageSlug) {
          nextOptions.frontPageSlug = slugFromLabel(front.label);
        }
      }

      await sequelize.transaction(async (transaction) => {
        const sitePatch: SitePatch = {};
        if (body.title !== undefined) sitePatch.title = body.title;
        if (body.tagline !== undefined) sitePatch.tagline = body.tagline;
        if (body.language !== undefined) sitePatch.language = body.language;
        await Site.update(sitePatch, { where: { id: site.id }, transaction });

        if (site.settings) {
          const patch: SettingsPatch = { options: nextOptions };
          if (body.blogPublic !== undefined) patch.blogPublic = body.blogPublic;
          if (body.timezone !== undefined) patch.timezone = body.timezone;
          if (body.dateFormat !== undefined) patch.dateFormat = body.dateFormat;
          if (body.timeFormat !== undefined) patch.timeFormat = body.timeFormat;
          await SiteSettings.update(patch, { where: { id: site.settings.id }, transaction });
        } else {
          await SiteSettings.create(
            {
              siteId: site.id,
              blogPublic: body.blogPublic ?? true,
              timezone: body.timezone ?? 'UTC',
              dateFormat: body.dateFormat ?? 'F j, Y',
              timeFormat: body.timeFormat ?? 'g:i a',
              options: nextOptions,
            },
            { transaction },
          );
        }
      });

      bumpAdminBasePathCache(nextOptions.adminBasePath);
      return serializeSettings(await requirePrimarySite());
    } catch (error) {
      throw toHttpError(error, 'Could not save site settings.');
    }
  }
}

export const siteService = new SiteService();
