import Anthropic from '@anthropic-ai/sdk';
import { betaZodTool } from '@anthropic-ai/sdk/helpers/beta/zod';

import { getSelfUrl } from '../config/runtime';
import { findClaudeCli, runClaudeCode } from '../lib/beequeen/claude-code';
import { openMcpRun } from '../lib/beequeen/mcp';
import { beeQueenTools, SYSTEM_PROMPT, type StepRunner } from '../lib/beequeen/tools';
import type { Workspace, WorkspaceLink } from '../lib/beequeen/workspace';
import { beeQueenServiceClient, type BeeQueenServiceConn } from '../lib/beequeen/service-client';
import { anthropicKey, beeQueenService, parseConnector } from '../lib/site/connector';
import { readOptions } from '../lib/site/site-options';
import type { AuthUser } from '../types/auth';
import { BadRequest, PaymentRequired, toHttpError } from '../utils/http-error';
import { createLogger } from '../utils/logger';
import type { ChatTurn, RunUsage } from './beequeen-chats.service';
import { requirePrimarySite } from './site-context';

const log = createLogger('beequeen');

/** Tool calls + replies per chat turn before BeeQueen stops and reports. */
const MAX_ITERATIONS = 40;

/** Room for thinking plus a full layout (template + SCSS) in one tool call. */
const MAX_TOKENS = 64000;

/**
 * Models that take the server-side refusal fallback (`fallbacks: "default"`) and
 * `display: "updates"` — their between-step notes arrive as thinking blocks.
 */
const AGENT_BETA_MODELS = new Set(['claude-opus-5-5', 'claude-sonnet-5-5', 'claude-fable-5-1']);

/** A progress block standing in for work a cut-off reply never finished. */
const INTERRUPTED_NOTE = 'This part of the response was interrupted before it finished.';

export type BeeQueenEvent =
  | { type: 'status'; text: string }
  | { type: 'note'; text: string }
  | { type: 'done'; reply: string; links: WorkspaceLink[]; model: string }
  | { type: 'error'; message: string; needsCredits?: boolean };

/**
 * `service`: the BeeQueen service (996Agency) — Claude calls relay through it and are paid
 *   from this site's BeeQueen credits.
 * `api`: the Claude API with the owner's own Anthropic key (testing without the service).
 * `claude-code`: no key — Claude Code signed in on this machine (owner's local testing).
 */
export type BeeQueenSetup = {
  engine: 'service' | 'api' | 'claude-code';
  apiKey: string;
  model: string;
  effort: string;
  service: BeeQueenServiceConn | null;
};

/** Short cache of the site's BeeQueen balance for the chat header. */
let balanceCache: { key: string; at: number; value: { balance: number; granted: number; currency: string } } | null = null;

function textOf(content: Anthropic.Beta.BetaContentBlock[]): string {
  return content
    .filter((b): b is Anthropic.Beta.BetaTextBlock => b.type === 'text')
    .map((b) => b.text)
    .join('\n')
    .trim();
}

/** Earlier chat turns (text only) → alternating messages that end before the new prompt. */
function historyMessages(history: ChatTurn[]): Anthropic.Beta.BetaMessageParam[] {
  const out: Anthropic.Beta.BetaMessageParam[] = [];
  for (const turn of history) {
    const text = turn.text.trim();
    if (!text) continue;
    const last = out[out.length - 1];
    if (last && last.role === turn.role) last.content = `${String(last.content)}\n\n${text}`;
    else out.push({ role: turn.role, content: text });
  }
  while (out.length && out[0].role !== 'user') out.shift();
  if (out.length && out[out.length - 1].role === 'user') out.pop();
  return out;
}

/** Claude Code takes one prompt, so earlier turns ride along as a transcript. */
function promptWithHistory(prompt: string, history: ChatTurn[]): string {
  const turns = historyMessages(history);
  if (!turns.length) return prompt.trim();
  const transcript = turns
    .map((t) => `${t.role === 'user' ? 'Owner' : 'BeeQueen'}: ${String(t.content)}`)
    .join('\n\n');
  return `Earlier in this conversation:\n\n${transcript}\n\n---\n\nOwner's new message:\n${prompt.trim()}`;
}

function emptyUsage(): RunUsage {
  return { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 };
}

function friendlyError(error: unknown): string {
  if (error instanceof Anthropic.APIUserAbortError) return 'Stopped.';
  if (error instanceof Anthropic.APIError && error.status === 402) {
    return 'This site has no BeeQueen credits left — request a pack under Connector → BeeQueen.';
  }
  if (error instanceof Anthropic.AuthenticationError) {
    return 'The key was rejected. Check it under Connector → BeeQueen.';
  }
  if (error instanceof Anthropic.PermissionDeniedError) {
    return 'This Anthropic key is not allowed to use that model. Pick another model under Connector → BeeQueen.';
  }
  if (error instanceof Anthropic.RateLimitError) {
    return 'Claude is rate limiting this key right now. Wait a minute and try again.';
  }
  if (error instanceof Anthropic.BadRequestError) return `Claude refused the request: ${error.message}`;
  if (error instanceof Anthropic.APIConnectionError) return 'Could not reach Claude — check the server’s internet connection.';
  if (error instanceof Anthropic.APIError) return `Claude error ${error.status ?? ''}: ${error.message}`.trim();
  if (error instanceof Error && error.name === 'AbortError') return 'Stopped.';
  return error instanceof Error ? error.message : 'BeeQueen could not complete that.';
}

class BeeQueenAgentService {
  /** Engine and settings, or why BeeQueen can't run. */
  async engine(): Promise<BeeQueenSetup> {
    const site = await requirePrimarySite();
    const connector = parseConnector(readOptions(site.settings?.options).connector);
    const { beequeen, claude } = connector.providers;
    // BeeQueen's own settings win; with only the Claude connector on, she runs on Claude's.
    const settings = beequeen.enabled ? beequeen : claude.enabled ? claude : null;
    if (!settings) throw BadRequest('BeeQueen is not switched on for this site yet.');
    const base = { model: settings.defaultModel, effort: settings.effort };
    const service = beeQueenService(connector);
    if (service) return { engine: 'service', apiKey: service.key, service, ...base };
    const key = anthropicKey(connector);
    if (key) return { engine: 'api', apiKey: key, service: null, ...base };
    if (findClaudeCli()) return { engine: 'claude-code', apiKey: '', service: null, ...base };
    throw BadRequest('Connect BeeQueen first: add this site’s BeeQueen key under Connector → BeeQueen.');
  }

  /** The site's BeeQueen credits (cached for a few seconds). */
  private async serviceBalance(conn: BeeQueenServiceConn, fresh = false) {
    if (!fresh && balanceCache && balanceCache.key === conn.key && Date.now() - balanceCache.at < 10_000) {
      return balanceCache.value;
    }
    const account = await beeQueenServiceClient.account(conn);
    balanceCache = {
      key: conn.key,
      at: Date.now(),
      value: { balance: account.balance, granted: account.granted ?? account.balance, currency: account.currency },
    };
    return balanceCache.value;
  }

  /** Throws a normal HTTP error before streaming starts when BeeQueen can't run — 402 when out of credits. */
  async prepare(): Promise<BeeQueenSetup> {
    try {
      const setup = await this.engine();
      if (setup.service) {
        const { balance } = await this.serviceBalance(setup.service, true);
        if (balance <= 0) {
          throw PaymentRequired('This site has no BeeQueen credits left — request a pack under Connector → BeeQueen.');
        }
      }
      return setup;
    } catch (error) {
      throw toHttpError(error, 'BeeQueen could not start.');
    }
  }

  /** What the chat widget needs: can BeeQueen run, on what, and the site's credits. */
  async status() {
    try {
      let engine: BeeQueenSetup | null = null;
      let reason = '';
      try {
        engine = await this.engine();
      } catch (error) {
        reason = error instanceof Error ? error.message : 'BeeQueen is not available.';
      }
      let credits: { enabled: true; balance: number; granted: number; currency: string } | { enabled: false } = {
        enabled: false,
      };
      if (engine?.service) {
        try {
          credits = { enabled: true, ...(await this.serviceBalance(engine.service)) };
        } catch (error) {
          reason = error instanceof Error ? error.message : 'The BeeQueen service is not reachable.';
        }
      }
      return {
        available: Boolean(engine) && !(engine?.service && !credits.enabled),
        reason,
        engine: engine?.engine ?? null,
        model: engine?.model ?? null,
        effort: engine?.effort ?? null,
        credits,
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load BeeQueen.');
    }
  }

  /** Credits one run used, as the BeeQueen service metered it. */
  async runCost(setup: BeeQueenSetup, runId: string) {
    if (!setup.service) return null;
    const cost = await beeQueenServiceClient.runCost(setup.service, runId);
    balanceCache = null;
    return cost;
  }

  /** Runs one chat turn; resolves with the tokens it used (for history and billing). */
  async run(
    actor: AuthUser,
    turn: { prompt: string; history: ChatTurn[]; runId: string },
    setup: BeeQueenSetup,
    emit: (event: BeeQueenEvent) => void,
    signal: AbortSignal,
  ): Promise<RunUsage> {
    const ws: Workspace = { actor, links: [] };
    const step: StepRunner = async (label, work) => {
      emit({ type: 'status', text: label });
      try {
        return await work();
      } catch (error) {
        // Workspace errors are written for the model to act on, so pass their text through.
        const message = toHttpError(error, error instanceof Error ? error.message : 'That step failed.').message;
        return `ERROR: ${message}`;
      }
    };
    const tools = beeQueenTools(ws, step);

    if (setup.engine === 'claude-code') {
      return this.runClaudeCode(ws, tools, turn, setup, emit, signal);
    }
    const usage = emptyUsage();

    // With the BeeQueen service, Claude calls relay through it and carry the run id it meters by.
    const client = new Anthropic({
      apiKey: setup.apiKey,
      timeout: 15 * 60 * 1000,
      maxRetries: 2,
      ...(setup.service
        ? { baseURL: `${setup.service.url}/api/beequeen`, defaultHeaders: { 'x-beequeen-run': turn.runId } }
        : {}),
    });
    const agentBetas = AGENT_BETA_MODELS.has(setup.model);

    // Streamed turns: long max-effort turns never sit on one idle HTTP response,
    // and progress notes reach the chat as soon as each block finishes.
    const runner = client.beta.messages.toolRunner(
      {
        model: setup.model,
        max_tokens: MAX_TOKENS,
        max_iterations: MAX_ITERATIONS,
        stream: true,
        thinking: agentBetas ? { type: 'adaptive', display: 'updates' } : { type: 'adaptive' },
        output_config: { effort: setup.effort as 'low' | 'medium' | 'high' | 'xhigh' | 'max' },
        cache_control: { type: 'ephemeral' },
        system: SYSTEM_PROMPT,
        tools: tools.map((t) =>
          betaZodTool({
            name: t.name,
            description: t.description,
            inputSchema: t.schema,
            run: (args) => t.run(args as never),
          }),
        ),
        messages: [...historyMessages(turn.history), { role: 'user', content: turn.prompt.trim() }],
        ...(agentBetas
          ? {
              betas: ['server-side-fallback-2026-07-01', 'thinking-display-updates-2026-08-18'],
              fallbacks: 'default' as const,
            }
          : {}),
      },
      { signal },
    );

    let last: Anthropic.Beta.BetaMessage | null = null;
    try {
      for await (const stream of runner) {
        stream.on('contentBlock', (block) => {
          // Under display "updates", any thinking block with text is a progress note.
          if (block.type !== 'thinking') return;
          const note = block.thinking.trim();
          if (note && note !== INTERRUPTED_NOTE) emit({ type: 'note', text: note });
        });
        const message = await stream.finalMessage();
        last = message;
        usage.inputTokens += message.usage.input_tokens ?? 0;
        usage.outputTokens += message.usage.output_tokens ?? 0;
        usage.cacheReadTokens += message.usage.cache_read_input_tokens ?? 0;
        usage.cacheWriteTokens += message.usage.cache_creation_input_tokens ?? 0;
        const text = textOf(message.content);
        if (text && message.stop_reason === 'tool_use') emit({ type: 'note', text });
      }
    } catch (error) {
      log.warn(`BeeQueen run failed: ${(error as Error).message}`);
      emit({
        type: 'error',
        message: friendlyError(error),
        needsCredits: error instanceof Anthropic.APIError && error.status === 402,
      });
      return usage;
    }

    if (!last) {
      emit({ type: 'error', message: 'Claude returned nothing.' });
      return usage;
    }
    let reply = textOf(last.content);
    if (last.stop_reason === 'refusal') {
      reply = reply || 'Claude declined this request.';
    } else if (last.stop_reason === 'tool_use') {
      reply = `${reply ? `${reply}\n\n` : ''}I hit my step limit for one message — say “continue” and I’ll pick up where I stopped.`;
    } else if (last.stop_reason === 'max_tokens') {
      reply = `${reply ? `${reply}\n\n` : ''}My answer got cut off — say “continue”.`;
    }
    emit({ type: 'done', reply: reply || 'Done.', links: ws.links, model: last.model });
    return usage;
  }

  /** Local test engine: Claude Code on this machine, with BeeQueen's tools served over MCP. */
  private async runClaudeCode(
    ws: Workspace,
    tools: ReturnType<typeof beeQueenTools>,
    turn: { prompt: string; history: ChatTurn[]; runId: string },
    setup: BeeQueenSetup,
    emit: (event: BeeQueenEvent) => void,
    signal: AbortSignal,
  ): Promise<RunUsage> {
    const self = getSelfUrl();
    if (!self) {
      emit({ type: 'error', message: 'The server address is not known yet — try again in a moment.' });
      return emptyUsage();
    }
    const mcp = openMcpRun(tools);
    try {
      const result = await runClaudeCode({
        prompt: promptWithHistory(turn.prompt, turn.history),
        systemPrompt: SYSTEM_PROMPT,
        model: setup.model,
        effort: setup.effort,
        mcpUrl: `${self.replace(/\/$/, '')}/api/connector/mcp`,
        mcpToken: mcp.token,
        signal,
        onEvent: (event) => emit(event),
      });
      if (result.ok) {
        emit({ type: 'done', reply: result.text, links: ws.links, model: result.model ?? setup.model });
      } else {
        log.warn(`BeeQueen (Claude Code) failed: ${result.text}`);
        emit({ type: 'error', message: result.text });
      }
      return result.usage ?? emptyUsage();
    } finally {
      mcp.close();
    }
  }
}

export const beeQueenAgentService = new BeeQueenAgentService();
