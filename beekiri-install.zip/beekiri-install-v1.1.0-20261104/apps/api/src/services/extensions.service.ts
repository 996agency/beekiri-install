import { EXTENSION_CATALOG, type ExtensionEntry, type ExtensionStatus } from '../lib/extensions/catalog';
import { mergeSiteOptions, readOptions, type ExtensionsOptions } from '../lib/site/site-options';
import { SHOP_EXTENSION_SLUG } from '../lib/shop/constants';
import { AuditLog } from '../models';
import type { AuthUser } from '../types/auth';
import { BadRequest, NotFound, toHttpError } from '../utils/http-error';
import { createLogger } from '../utils/logger';
import { shopInstallService } from './shop/shop-install.service';
import { findPrimarySite, requirePrimarySite, saveSiteOptions } from './site-context';

const log = createLogger('extensions');

/** Per-extension hooks run on install / activate / deactivate / uninstall. */
type ExtensionHooks = {
  install?: (actor: AuthUser) => Promise<void>;
  activate?: (actor: AuthUser) => Promise<void>;
  deactivate?: (actor: AuthUser) => Promise<void>;
  uninstall?: (actor: AuthUser, opts: { deleteData: boolean }) => Promise<void>;
};

const HOOKS: Record<string, ExtensionHooks> = {
  [SHOP_EXTENSION_SLUG]: {
    install: (actor) => shopInstallService.install(actor),
    activate: (actor) => shopInstallService.activate(actor),
    deactivate: (actor) => shopInstallService.deactivate(actor),
    uninstall: (actor, opts) => shopInstallService.uninstall(actor, opts),
  },
};

export type ExtensionDto = ExtensionEntry & { installedAt: string | null };

export class ExtensionsService {
  private entry(slug: string): ExtensionEntry {
    const entry = EXTENSION_CATALOG.find((e) => e.slug === slug);
    if (!entry) throw NotFound('Extension not found.');
    return entry;
  }

  /** Installed state from the site options (cheap, used by the admin shell and the website). */
  async readState(): Promise<ExtensionsOptions> {
    const site = await findPrimarySite();
    return readOptions(site?.settings?.options).extensions ?? {};
  }

  async isActive(slug: string): Promise<boolean> {
    try {
      return (await this.readState())[slug]?.active === true;
    } catch {
      return false;
    }
  }

  async activeSlugs(): Promise<string[]> {
    const state = await this.readState();
    return Object.keys(state).filter((slug) => state[slug]?.active);
  }

  private statusOf(entry: ExtensionEntry, state: ExtensionsOptions): ExtensionStatus {
    if (entry.status === 'coming-soon') return 'coming-soon';
    const s = state[entry.slug];
    if (!s) return 'available';
    return s.active ? 'active' : 'inactive';
  }

  async list(): Promise<{ publisher: 'Beekiri'; extensions: ExtensionDto[] }> {
    try {
      const state = await this.readState();
      return {
        publisher: 'Beekiri',
        extensions: EXTENSION_CATALOG.map((entry) => ({
          ...entry,
          status: this.statusOf(entry, state),
          installedAt: state[entry.slug]?.installedAt ?? null,
        })),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load extensions.');
    }
  }

  private async writeState(next: ExtensionsOptions) {
    const site = await requirePrimarySite();
    await saveSiteOptions(site.id, mergeSiteOptions(site.settings?.options, { extensions: next }));
  }

  private async audit(actor: AuthUser, action: string, slug: string, extra: Record<string, unknown> = {}) {
    await AuditLog.create({ siteId: actor.siteId, userId: actor.id, action, meta: { slug, ...extra } });
  }

  async install(actor: AuthUser, slug: string) {
    try {
      const entry = this.entry(slug);
      if (entry.status === 'coming-soon') throw BadRequest('This extension is not available yet.');
      const state = await this.readState();
      if (state[slug]) throw BadRequest('This extension is already installed.');
      await HOOKS[slug]?.install?.(actor);
      await HOOKS[slug]?.activate?.(actor);
      await this.writeState({ ...state, [slug]: { installedAt: new Date().toISOString(), active: true } });
      await this.audit(actor, 'extension.installed', slug);
      log.info(`Extension installed: ${slug}`);
      return this.list();
    } catch (error) {
      throw toHttpError(error, 'Could not install the extension.');
    }
  }

  async activate(actor: AuthUser, slug: string) {
    try {
      this.entry(slug);
      const state = await this.readState();
      const current = state[slug];
      if (!current) throw BadRequest('Install the extension first.');
      if (!current.active) {
        await HOOKS[slug]?.activate?.(actor);
        await this.writeState({ ...state, [slug]: { ...current, active: true } });
        await this.audit(actor, 'extension.activated', slug);
      }
      return this.list();
    } catch (error) {
      throw toHttpError(error, 'Could not activate the extension.');
    }
  }

  async deactivate(actor: AuthUser, slug: string) {
    try {
      this.entry(slug);
      const state = await this.readState();
      const current = state[slug];
      if (!current) throw BadRequest('This extension is not installed.');
      if (current.active) {
        await HOOKS[slug]?.deactivate?.(actor);
        await this.writeState({ ...state, [slug]: { ...current, active: false } });
        await this.audit(actor, 'extension.deactivated', slug);
      }
      return this.list();
    } catch (error) {
      throw toHttpError(error, 'Could not deactivate the extension.');
    }
  }

  async uninstall(actor: AuthUser, slug: string, opts: { deleteData: boolean }) {
    try {
      this.entry(slug);
      const state = await this.readState();
      if (!state[slug]) throw BadRequest('This extension is not installed.');
      if (state[slug]?.active) await HOOKS[slug]?.deactivate?.(actor);
      await HOOKS[slug]?.uninstall?.(actor, opts);
      const next = { ...state };
      delete next[slug];
      await this.writeState(next);
      await this.audit(actor, 'extension.uninstalled', slug, { deleteData: opts.deleteData });
      log.info(`Extension uninstalled: ${slug} (deleteData=${opts.deleteData})`);
      return this.list();
    } catch (error) {
      throw toHttpError(error, 'Could not uninstall the extension.');
    }
  }
}

export const extensionsService = new ExtensionsService();
