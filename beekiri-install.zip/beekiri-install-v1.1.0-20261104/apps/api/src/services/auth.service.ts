import { Op, col, fn, where } from 'sequelize';
import { config } from '../config/env';
import { resolveCapabilities } from '../lib/auth/role-capabilities';
import type { RoleSlug } from '../lib/cms-types';
import { resolveAdminBasePath } from '../lib/site/admin-base-cache';
import { parseProfile } from '../lib/users/users.profile';
import { AuditLog, PasswordResetToken, Role, Session, User, sequelize } from '../models';
import type { AuthSessionContext, AuthUser } from '../types/auth';
import {
  hashPassword,
  passwordStrength,
  randomToken,
  safeEqual,
  sha256,
  verifyPassword,
} from '../utils/crypto';
import { Forbidden, Unauthorized, toHttpError } from '../utils/http-error';
import { rateLimit } from '../utils/rate-limit';
import type { LoginInput, LostPasswordInput, ResetPasswordInput } from '../validators/auth.schema';
import { mailService, type MailService } from './mail.service';

/**
 * On https sites the cookie carries the `__Host-` prefix: browsers then refuse to accept
 * it from a sub-domain, from http://, or with a Domain/Path override, so a cookie planted
 * by another host on the same site cannot replace the real session.
 */
export const SESSION_COOKIE = config.auth.cookieSecure ? '__Host-beekiri_session' : 'beekiri_session';
export const CSRF_HEADER = 'x-csrf-token';

/** A session ends after a day without activity ("remember me": 7 days), and always after 7 days. */
const SESSION_IDLE_SECONDS = 24 * 60 * 60;
const SESSION_ABSOLUTE_SECONDS = 7 * 24 * 60 * 60;

const LOGIN_LIMIT = { max: 10, windowMs: 15 * 60 * 1000 };
/** Per account, across every source address: slows a distributed guess at one login. */
const LOGIN_ACCOUNT_LIMIT = { max: 30, windowMs: 15 * 60 * 1000 };
const RESET_LIMIT = { max: 5, windowMs: 15 * 60 * 1000 };
const RESET_TOKEN_TTL_MS = 60 * 60 * 1000;

type RequestMeta = { ip?: string; userAgent?: string };

type UserWithRole = {
  id: string;
  username: string;
  email: string;
  displayName: string;
  isOwner: boolean;
  siteId: string;
  profile?: unknown;
  role?: { slug: string } | null;
};

/** Case-insensitive match on username or email (same rule as the original login). */
function loginWhere(login: string) {
  return {
    [Op.or]: [
      where(fn('lower', col('username')), login.toLowerCase()),
      where(fn('lower', col('email')), login.toLowerCase()),
    ],
  };
}

let dummyHash: Promise<string> | null = null;

/** Unknown logins still pay for one argon2 verify so response time does not reveal accounts. */
async function burnPasswordCheck(password: string): Promise<false> {
  dummyHash ??= hashPassword(randomToken(16));
  await verifyPassword(await dummyHash, password);
  return false;
}

export class AuthService {
  constructor(private readonly mail: MailService = mailService) {}

  toAuthUser(user: UserWithRole): AuthUser {
    const role = (user.role?.slug ?? 'subscriber') as RoleSlug;
    const profile = parseProfile(user.profile);
    return {
      id: user.id,
      username: user.username,
      email: user.email,
      displayName: user.displayName,
      role,
      capabilities: resolveCapabilities({
        role,
        isOwner: user.isOwner,
        grants: profile.capabilityGrants,
        denies: profile.capabilityDenies,
      }),
      isOwner: user.isOwner,
      siteId: user.siteId,
    };
  }

  async login(dto: LoginInput, meta: RequestMeta) {
    try {
      const limit = rateLimit(
        `login:${meta.ip ?? 'unknown'}`,
        LOGIN_LIMIT.max,
        LOGIN_LIMIT.windowMs,
      );
      if (!limit.ok) throw Unauthorized('Too many login attempts. Please try again later.');

      const login = dto.login.trim();
      const accountLimit = rateLimit(
        `login-account:${login.toLowerCase()}`,
        LOGIN_ACCOUNT_LIMIT.max,
        LOGIN_ACCOUNT_LIMIT.windowMs,
      );
      if (!accountLimit.ok) {
        throw Unauthorized('Too many login attempts. Please try again later.');
      }
      const user = await User.scope('withPassword').findOne({
        where: loginWhere(login),
        include: [{ model: Role, as: 'role' }],
      });

      const ok = user
        ? await verifyPassword(user.passwordHash, dto.password)
        : await burnPasswordCheck(dto.password);
      if (!user || !ok) {
        await AuditLog.create({
          action: 'auth.login_failed',
          meta: { login },
          ip: meta.ip ?? null,
        });
        throw Unauthorized('Invalid username or password.');
      }

      const rawToken = randomToken(32);
      const csrfSecret = randomToken(24);
      const now = Date.now();
      const idleSeconds = this.idleSeconds(dto.remember);

      await Session.create({
        userId: user.id,
        tokenHash: sha256(rawToken),
        csrfSecret,
        lastSeenAt: new Date(now),
        idleExpiresAt: new Date(now + idleSeconds * 1000),
        absoluteExpiresAt: new Date(now + SESSION_ABSOLUTE_SECONDS * 1000),
        userAgent: meta.userAgent?.slice(0, 512) ?? null,
        ip: meta.ip ?? null,
      });

      await AuditLog.create({
        siteId: user.siteId,
        userId: user.id,
        action: 'auth.login',
        meta: { remember: Boolean(dto.remember) },
        ip: meta.ip ?? null,
      });

      return {
        cookieValue: rawToken,
        maxAgeSeconds: idleSeconds,
        csrfToken: csrfSecret,
        user: this.toAuthUser(user),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not log in.');
    }
  }

  async logout(rawToken: string | undefined, meta: { ip?: string }): Promise<void> {
    try {
      if (!rawToken) return;
      const session = await Session.findOne({ where: { tokenHash: sha256(rawToken) } });
      if (!session) return;
      await session.destroy();
      await AuditLog.create({ userId: session.userId, action: 'auth.logout', ip: meta.ip ?? null });
    } catch (error) {
      throw toHttpError(error, 'Could not log out.');
    }
  }

  async resolveSession(rawToken: string | undefined): Promise<AuthSessionContext | null> {
    try {
      if (!rawToken || rawToken.length > 256) return null;
      const session = await Session.findOne({
        where: { tokenHash: sha256(rawToken) },
        include: [{ model: User, as: 'user', include: [{ model: Role, as: 'role' }] }],
      });
      if (!session || !session.user) return null;

      const now = new Date();
      if (session.absoluteExpiresAt < now || session.idleExpiresAt < now) {
        await session.destroy().catch(() => undefined);
        return null;
      }

      await Session.update(
        {
          lastSeenAt: now,
          idleExpiresAt: new Date(now.getTime() + this.idleSeconds(false) * 1000),
        },
        { where: { id: session.id } },
      );

      return {
        sessionId: session.id,
        csrfToken: session.csrfSecret,
        user: this.toAuthUser(session.user),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not verify your session.');
    }
  }

  assertCsrf(session: AuthSessionContext, headerValue: string | undefined): void {
    if (!headerValue || !safeEqual(headerValue, session.csrfToken)) {
      throw Forbidden('Invalid CSRF token.');
    }
  }

  async requestPasswordReset(dto: LostPasswordInput, meta: { ip?: string; origin?: string }) {
    const generic = { message: 'If that account exists, a reset link has been sent.' };
    try {
      const limit = rateLimit(
        `reset:${meta.ip ?? 'unknown'}`,
        RESET_LIMIT.max,
        RESET_LIMIT.windowMs,
      );
      if (!limit.ok) return generic;

      const user = await User.findOne({ where: loginWhere(dto.userLogin.trim()) });
      // Always the same response (anti-enumeration).
      if (!user) return generic;

      const raw = randomToken(32);
      await PasswordResetToken.create({
        userId: user.id,
        tokenHash: sha256(raw),
        expiresAt: new Date(Date.now() + RESET_TOKEN_TTL_MS),
      });

      // The link always points at the configured site address. Only when APP_URL is unset
      // does an allow-listed browser Origin stand in (never the Host header: an attacker
      // could set that and have the victim's reset link mailed out pointing at their site).
      const base = (config.urls.app || meta.origin || '').replace(/\/$/, '');
      const adminBase = await resolveAdminBasePath();
      const link = `${base}${adminBase}/reset-password?key=${encodeURIComponent(raw)}`;
      const sent = await this.mail.sendMail({
        to: user.email,
        subject: 'Password Reset',
        text: `Someone requested a password reset for your account.\n\n${link}\n\nThis link expires in 1 hour.`,
      });

      await AuditLog.create({
        userId: user.id,
        siteId: user.siteId,
        action: 'auth.password_reset_requested',
        ip: meta.ip ?? null,
      });

      return {
        ...generic,
        ...(!config.isProduction && sent.mode === 'dev-sink' ? { devResetLink: link } : {}),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not send the password reset link.');
    }
  }

  async resetPassword(dto: ResetPasswordInput) {
    try {
      if (passwordStrength(dto.password) === 'weak') {
        throw Forbidden('Please choose a stronger password.');
      }
      const token = await PasswordResetToken.findOne({ where: { tokenHash: sha256(dto.token) } });
      if (!token || token.usedAt || token.expiresAt < new Date()) {
        throw Forbidden('Invalid or expired reset link.');
      }

      const passwordHash = await hashPassword(dto.password);
      await sequelize.transaction(async (transaction) => {
        await User.update({ passwordHash }, { where: { id: token.userId }, transaction });
        // Every outstanding link for this account is spent, not only the one used.
        await PasswordResetToken.update(
          { usedAt: new Date() },
          { where: { userId: token.userId, usedAt: null }, transaction },
        );
        await Session.destroy({ where: { userId: token.userId }, transaction });
      });

      return { message: 'Password updated. You can log in.' };
    } catch (error) {
      throw toHttpError(error, 'Could not reset the password.');
    }
  }

  private idleSeconds(remember?: boolean): number {
    return remember ? SESSION_ABSOLUTE_SECONDS : SESSION_IDLE_SECONDS;
  }
}

export const authService = new AuthService();
