import { randomBytes } from 'crypto';
import sanitizeHtml from 'sanitize-html';
import { Op } from 'sequelize';
import {
  contentKindConfig,
  type ContentKind,
  type ContentKindConfig,
} from '../lib/pages/content-kind';
import {
  contentFromBeekiricanva,
  contentFromBeekiriCode,
  contentFromHtml,
  parseContent,
  toSlug,
  type PageContentDoc,
} from '../lib/pages/pages.content';
import { readOptions } from '../lib/site/site-options';
import { EMPTY_SEO, seoForStorage, type PageSeo } from '../lib/pages/page-seo';
import { MediaAsset, Post, PostRevision, User } from '../models';
import type { Json } from '../models/_shared';
import type { AuthUser } from '../types/auth';
import { safeEqual } from '../utils/crypto';
import { uniqueViolation } from '../utils/db-errors';
import { BadRequest, Conflict, Forbidden, NotFound, toHttpError } from '../utils/http-error';
import type {
  CreatePageInput,
  PreviewPageInput,
  UpdatePageInput,
} from '../validators/pages.schema';
import { revalidatePublicPaths } from '../lib/revalidate-public';
import { SHOP_PAGE_KIND } from '../lib/shop/constants';
import { findPrimarySite } from './site-context';

const PREVIEW_TTL_MS = 24 * 60 * 60 * 1000;
const MAX_REVISIONS = 25;

/**
 * What an author or contributor may store as page HTML: ordinary markup, images and
 * media, but no scripts, event handlers, iframes or javascript: links. Editors and
 * administrators hold `unfiltered_html` and are stored as written.
 */
const SAFE_HTML: sanitizeHtml.IOptions = {
  allowedTags: [
    ...sanitizeHtml.defaults.allowedTags,
    'img', 'picture', 'source', 'figure', 'figcaption', 'span', 'section', 'article',
    'header', 'footer', 'nav', 'aside', 'main', 'video', 'audio', 'details', 'summary',
    'mark', 'small', 'sub', 'sup', 'u', 's', 'del', 'ins', 'time', 'address', 'wbr',
  ],
  allowedAttributes: {
    '*': [
      'class', 'id', 'style', 'title', 'lang', 'dir', 'role', 'aria-*', 'data-*',
      'width', 'height', 'loading', 'alt', 'src', 'srcset', 'sizes', 'href', 'target', 'rel',
      'name', 'type', 'media', 'controls', 'poster', 'muted', 'playsinline', 'loop', 'preload',
      'datetime', 'open', 'colspan', 'rowspan', 'scope', 'start', 'reversed',
    ],
  },
  allowedSchemes: ['http', 'https', 'mailto', 'tel'],
  allowedSchemesByTag: { img: ['http', 'https', 'data'] },
  allowProtocolRelative: true,
};

function storableHtml(actor: AuthUser, html: string): string {
  if (!html || actor.capabilities.includes('unfiltered_html')) return html;
  return sanitizeHtml(html, SAFE_HTML);
}

const LOOKS_LIKE_MARKUP = /<[a-z!/?]/i;

/** Every markup-looking string in an editor document (layout fields, rich text) is cleaned. */
function cleanDocStrings(value: unknown, depth = 0): unknown {
  if (depth > 64) return null;
  if (typeof value === 'string') {
    return LOOKS_LIKE_MARKUP.test(value) ? sanitizeHtml(value, SAFE_HTML) : value;
  }
  if (Array.isArray(value)) return value.map((v) => cleanDocStrings(v, depth + 1));
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(([k, v]) => [k, cleanDocStrings(v, depth + 1)]),
    );
  }
  return value;
}

/**
 * Editor documents carry layout field values (WYSIWYG and others) that templates print.
 * Without `unfiltered_html` they go through the same filter as page HTML.
 */
function storableDoc<T>(actor: AuthUser, doc: T): T {
  if (doc == null || actor.capabilities.includes('unfiltered_html')) return doc;
  return cleanDocStrings(doc) as T;
}

type PostStatus = 'auto-draft' | 'draft' | 'publish' | 'trash';

type PostPatch = Partial<{
  title: string;
  slug: string;
  status: string;
  content: Json;
  excerpt: string;
  featuredImageId: string | null;
  updatedById: string;
  publishedAt: Date;
}>;

function bodyBeekiriCode(body: { beekiricode?: unknown; instatic?: unknown }): unknown | undefined {
  if (body.beekiricode !== undefined) return body.beekiricode;
  if (body.instatic !== undefined) return body.instatic;
  return undefined;
}

function displayName(user: { displayName: string; username: string } | null | undefined) {
  return user?.displayName?.trim() || user?.username || null;
}

export class PagesService {
  private cfg(kind: ContentKind = 'page') {
    return contentKindConfig(kind);
  }

  /** SEO for the public site: stored settings plus resolved image URLs. */
  private async publicSeo(seo: PageSeo | null | undefined, featuredImageId: string | null) {
    const ids = [seo?.ogImageId, featuredImageId].filter((v): v is string => Boolean(v));
    const assets = ids.length ? await MediaAsset.findAll({ where: { id: ids } }) : [];
    const urlOf = (id?: string | null) => (id ? (assets.find((a) => a.id === id)?.url ?? '') : '');
    return {
      ...(seo ?? EMPTY_SEO),
      ogImageUrl: urlOf(seo?.ogImageId),
      featuredImageUrl: urlOf(featuredImageId),
    };
  }

  private serialize(row: Post) {
    const doc = parseContent(row.content);
    const kind: ContentKind = row.type || 'page';
    return {
      id: row.id,
      type: row.type,
      title: row.title,
      slug: row.slug,
      status: row.status as PostStatus,
      content: doc.html,
      beekiricanva: doc.beekiricanva,
      beekiricode: doc.beekiricode,
      /** @deprecated Alias of beekiricode */
      instatic: doc.beekiricode,
      excerpt: row.excerpt,
      featuredImageId: row.featuredImageId ?? null,
      seo: doc.seo ?? null,
      authorId: row.authorId,
      updatedById: row.updatedById,
      parentId: row.parentId ?? null,
      menuOrder: row.menuOrder,
      path: this.cfg(kind).pathOf(row.slug),
      publishedAt: row.publishedAt?.toISOString() ?? null,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    };
  }

  private async resolveUserName(userId: string | null | undefined) {
    if (!userId) return null;
    const user = await User.findByPk(userId, { attributes: ['displayName', 'username'] });
    return displayName(user);
  }

  private async withAuthor<
    T extends { id: string; authorId: string | null; updatedById?: string | null },
  >(data: T) {
    const [authorName, updatedByName, revisionCount] = await Promise.all([
      this.resolveUserName(data.authorId),
      this.resolveUserName(data.updatedById ?? data.authorId),
      PostRevision.count({ where: { postId: data.id } }),
    ]);
    return { ...data, authorName, updatedByName, revisionCount };
  }

  private contentChanged(a: unknown, b: unknown) {
    return JSON.stringify(a ?? null) !== JSON.stringify(b ?? null);
  }

  private shouldSnapshot(existing: Post, next: PostPatch) {
    // Skip empty auto-drafts that never held real content.
    if (existing.status === 'auto-draft' && !existing.title.trim() && !existing.excerpt.trim()) {
      const doc = parseContent(existing.content);
      const canvas = doc.beekiricanva as { content?: unknown } | null | undefined;
      const emptyCanvas =
        !canvas ||
        (typeof canvas === 'object' &&
          Array.isArray(canvas.content) &&
          canvas.content.length === 0);
      if (emptyCanvas && !doc.html.trim()) return false;
    }

    if (next.title !== undefined && next.title !== existing.title) return true;
    if (next.slug !== undefined && next.slug !== existing.slug) return true;
    if (next.excerpt !== undefined && next.excerpt !== existing.excerpt) return true;
    if (
      next.featuredImageId !== undefined &&
      next.featuredImageId !== (existing.featuredImageId ?? null)
    ) {
      return true;
    }
    if (next.status !== undefined && next.status !== existing.status) return true;
    return next.content !== undefined && this.contentChanged(next.content, existing.content);
  }

  private async createRevisionFrom(existing: Post) {
    await PostRevision.create({
      postId: existing.id,
      siteId: existing.siteId,
      title: existing.title,
      slug: existing.slug,
      status: existing.status,
      content: existing.content,
      excerpt: existing.excerpt,
      authorId: existing.updatedById ?? existing.authorId,
    });

    const old = await PostRevision.findAll({
      where: { postId: existing.id },
      order: [['createdAt', 'DESC']],
      attributes: ['id'],
      offset: MAX_REVISIONS,
    });
    if (old.length) {
      await PostRevision.destroy({ where: { id: { [Op.in]: old.map((r) => r.id) } } });
    }
  }

  private async uniqueSlug(
    siteId: string,
    base: string,
    kind: ContentKind = 'page',
    excludeId?: string,
  ) {
    const cfg = this.cfg(kind);
    const root = toSlug(base) || cfg.defaultSlugBase;
    let slug = root;
    for (let n = 2; ; n++) {
      const existing = await Post.findOne({
        where: {
          siteId,
          type: cfg.type,
          slug,
          ...(excludeId ? { id: { [Op.ne]: excludeId } } : {}),
        },
        attributes: ['id'],
      });
      if (!existing) return slug;
      slug = `${root}-${n}`;
      if (n >= 200) throw Conflict('Could not generate a unique slug.');
    }
  }

  /** The item, provided the actor created it or may edit other people's items. */
  private async findOwned(actor: AuthUser, id: string, kind: ContentKind) {
    const cfg = this.cfg(kind);
    const row = await Post.findOne({ where: { id, siteId: actor.siteId, type: cfg.type } });
    if (!row) throw NotFound(cfg.notFound);
    if (row.authorId !== actor.id && !actor.capabilities.includes(cfg.editOthersCap)) {
      throw Forbidden(`You can only work on your own ${cfg.labelPlural.toLowerCase()}.`);
    }
    return row;
  }

  /** Changing or removing something that is live needs the publish capability. */
  private assertMayChangePublished(actor: AuthUser, row: Post, cfg: ContentKindConfig): void {
    if (row.status === 'publish' && !actor.capabilities.includes(cfg.publishCap)) {
      throw Forbidden(
        `You cannot change a published ${cfg.label.toLowerCase()}. Ask an editor to unpublish it first.`,
      );
    }
  }

  /** Same access rule as PATCH, for the live-editing channel. */
  async assertEditable(actor: AuthUser, id: string, kind: ContentKind = 'page'): Promise<void> {
    try {
      await this.findOwned(actor, id, kind);
    } catch (error) {
      throw toHttpError(error, 'Could not open this item.');
    }
  }

  /** Static update (always bumps updatedAt) and return the fresh row. */
  private async applyUpdate(id: string, data: PostPatch, kind: ContentKind) {
    try {
      const [, rows] = await Post.update(data, { where: { id }, returning: true });
      return rows[0];
    } catch (e) {
      if (uniqueViolation(e) !== null) throw Conflict(this.cfg(kind).conflictSlug);
      throw e;
    }
  }

  async list(
    actor: AuthUser,
    kind: ContentKind = 'page',
    opts: { status?: 'all' | 'trash' } = {},
  ) {
    try {
      const cfg = this.cfg(kind);
      const trash = opts.status === 'trash';
      const [rows, counts] = await Promise.all([
        Post.findAll({
          where: {
            siteId: actor.siteId,
            type: cfg.type,
            status: trash ? 'trash' : { [Op.notIn]: ['auto-draft', 'trash'] },
          },
          order: [['updatedAt', 'DESC']],
        }),
        Post.findAll({
          where: {
            siteId: actor.siteId,
            type: cfg.type,
            status: { [Op.ne]: 'auto-draft' },
          },
          attributes: ['id', 'status'],
        }),
      ]);
      const trashed = counts.filter((r) => r.status === 'trash').length;
      return {
        [cfg.listKey]: rows.map((r) => this.serialize(r)),
        counts: { all: counts.length - trashed, trash: trashed },
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load content.');
    }
  }

  async get(actor: AuthUser, id: string, kind: ContentKind = 'page') {
    try {
      return await this.withAuthor(this.serialize(await this.findOwned(actor, id, kind)));
    } catch (error) {
      throw toHttpError(error, 'Could not load this item.');
    }
  }

  async create(actor: AuthUser, body: CreatePageInput, kind: ContentKind = 'page') {
    try {
      const cfg = this.cfg(kind);
      const autoDraft = body.autoDraft === true || body.status === 'auto-draft';
      const title = (body.title ?? '').trim();

      let status: PostStatus = 'draft';
      if (autoDraft) status = 'auto-draft';
      else if (body.status === 'publish') status = 'publish';

      if (status === 'publish' && !actor.capabilities.includes(cfg.publishCap)) {
        throw Forbidden(cfg.cannotPublish);
      }
      // Drafts may start untitled (Add New); publish still needs a title.
      if (status === 'publish' && !title) throw BadRequest('Title is required.');

      const slugBase = (
        body.slug?.trim() ||
        title ||
        (status === 'auto-draft' ? `auto-draft-${Date.now()}` : cfg.defaultSlugBase)
      ).trim();
      const slug = await this.uniqueSlug(actor.siteId, slugBase, kind);

      const canvasIn = storableDoc(actor, body.beekiricanva);
      const codeIn = storableDoc(actor, bodyBeekiriCode(body));
      let contentDoc: PageContentDoc;
      const html = storableHtml(actor, body.content ?? '');
      if (codeIn !== undefined) {
        contentDoc = contentFromBeekiriCode(codeIn, html, canvasIn ?? null);
      } else if (canvasIn !== undefined) {
        contentDoc = contentFromBeekiricanva(canvasIn, html, null);
      } else {
        contentDoc = contentFromHtml(html);
      }

      if (body.seo !== undefined) contentDoc.seo = seoForStorage(body.seo);

      try {
        const row = await Post.create({
          siteId: actor.siteId,
          type: cfg.type,
          title: title || '',
          slug,
          status,
          content: contentDoc,
          excerpt: (body.excerpt ?? '').trim(),
          featuredImageId: body.featuredImageId?.trim() || null,
          authorId: actor.id,
          updatedById: actor.id,
          publishedAt: status === 'publish' ? new Date() : null,
        });
        await this.bustPublicCache(row, kind);
        return await this.withAuthor(this.serialize(row));
      } catch (e) {
        if (uniqueViolation(e) !== null) throw Conflict(cfg.conflictSlug);
        throw e;
      }
    } catch (error) {
      throw toHttpError(error, 'Could not create this item.');
    }
  }

  async update(actor: AuthUser, id: string, body: UpdatePageInput, kind: ContentKind = 'page') {
    try {
      const cfg = this.cfg(kind);
      const existing = await this.findOwned(actor, id, kind);
      if (existing.status === 'trash') {
        throw BadRequest('Restore this item from trash before editing.');
      }
      this.assertMayChangePublished(actor, existing, cfg);
      const data: PostPatch = { updatedById: actor.id };

      if (body.title !== undefined) data.title = body.title.trim();

      // Shop pages are addressed by their fixed view slug (shop, cart, …): never rename them.
      if (kind === SHOP_PAGE_KIND) body = { ...body, slug: undefined };

      if (body.slug !== undefined) {
        const base =
          body.slug.trim() ||
          (data.title !== undefined ? data.title : existing.title) ||
          cfg.defaultSlugBase;
        data.slug = await this.uniqueSlug(actor.siteId, base, kind, id);
      } else if (
        body.title !== undefined &&
        existing.status === 'auto-draft' &&
        body.title.trim() &&
        existing.slug.startsWith('auto-draft-')
      ) {
        // First real title on an auto-draft refreshes the slug (WordPress permalink style).
        data.slug = await this.uniqueSlug(actor.siteId, body.title.trim(), kind, id);
      }

      const canvasIn = storableDoc(actor, body.beekiricanva);
      const codeIn = storableDoc(actor, bodyBeekiriCode(body));
      if (codeIn !== undefined || canvasIn !== undefined) {
        const existingDoc = parseContent(existing.content);
        const html =
          body.content !== undefined ? storableHtml(actor, body.content) : existingDoc.html;
        data.content =
          codeIn !== undefined
            ? contentFromBeekiriCode(
                codeIn,
                html,
                canvasIn !== undefined ? canvasIn : existingDoc.beekiricanva,
              )
            : contentFromBeekiricanva(canvasIn, html, existingDoc.beekiricode);
      } else if (body.content !== undefined) {
        const existingDoc = parseContent(existing.content);
        data.content = {
          ...contentFromHtml(storableHtml(actor, body.content)),
          beekiricanva: existingDoc.beekiricanva,
          beekiricode: existingDoc.beekiricode,
          version: existingDoc.beekiricanva || existingDoc.beekiricode ? 2 : 1,
          preview: null,
        };
      }

      if (body.excerpt !== undefined) data.excerpt = body.excerpt.trim();
      if (body.featuredImageId !== undefined) {
        data.featuredImageId = body.featuredImageId.trim() || null;
      }

      // SEO lives on the content doc: rebuilt docs above must keep it, and a
      // seo-only save must not drop the body.
      if (body.seo !== undefined || data.content !== undefined) {
        const prevDoc = parseContent(existing.content);
        const base = (data.content as PageContentDoc | undefined) ?? prevDoc;
        data.content = {
          ...base,
          seo: body.seo !== undefined ? seoForStorage(body.seo) : (prevDoc.seo ?? null),
        };
      }

      if (body.status !== undefined) {
        if (body.status === 'publish' && !actor.capabilities.includes(cfg.publishCap)) {
          throw Forbidden(cfg.cannotPublish);
        }
        data.status = body.status;
        if (body.status === 'publish' && !existing.publishedAt) data.publishedAt = new Date();
      } else if (existing.status === 'auto-draft') {
        // Saving an auto-draft without an explicit status promotes it to draft.
        data.status = 'draft';
      }

      if (this.shouldSnapshot(existing, data)) await this.createRevisionFrom(existing);
      const row = await this.applyUpdate(id, data, kind);
      await this.bustPublicCache(row, kind, existing.slug);
      return await this.withAuthor(this.serialize(row));
    } catch (error) {
      throw toHttpError(error, 'Could not save this item.');
    }
  }

  /** Drop Next.js ISR for this published page so View page matches the editor. */
  private async bustPublicCache(
    row: Post,
    kind: ContentKind,
    previousSlug?: string,
  ): Promise<void> {
    if (row.status !== 'publish') return;
    const cfg = this.cfg(kind);
    const paths = new Set<string>([cfg.pathOf(row.slug)]);
    if (previousSlug && previousSlug !== row.slug) paths.add(cfg.pathOf(previousSlug));
    try {
      const site = await findPrimarySite();
      const front = readOptions(site?.settings?.options).frontPageSlug?.trim();
      if (kind === 'page' && front && (front === row.slug || front === previousSlug)) {
        paths.add('/');
      }
    } catch {
      /* still revalidate the page path */
    }
    // Fire-and-forget — save response should not wait on Next.
    void revalidatePublicPaths([...paths]);
  }

  async listRevisions(actor: AuthUser, id: string, kind: ContentKind = 'page') {
    try {
      await this.findOwned(actor, id, kind);

      const rows = await PostRevision.findAll({
        where: { postId: id, siteId: actor.siteId },
        order: [['createdAt', 'DESC']],
        limit: MAX_REVISIONS,
      });

      const authorIds = [...new Set(rows.map((r) => r.authorId).filter(Boolean))] as string[];
      const users = authorIds.length
        ? await User.findAll({
            where: { id: { [Op.in]: authorIds } },
            attributes: ['id', 'displayName', 'username'],
          })
        : [];
      const nameById = new Map(users.map((u) => [u.id, displayName(u)]));

      return {
        revisions: rows.map((r) => ({
          id: r.id,
          title: r.title,
          slug: r.slug,
          status: r.status,
          authorId: r.authorId,
          authorName: r.authorId ? (nameById.get(r.authorId) ?? null) : null,
          createdAt: r.createdAt.toISOString(),
        })),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load revisions.');
    }
  }

  async restoreRevision(
    actor: AuthUser,
    id: string,
    revisionId: string,
    kind: ContentKind = 'page',
  ) {
    try {
      const cfg = this.cfg(kind);
      const existing = await this.findOwned(actor, id, kind);
      this.assertMayChangePublished(actor, existing, cfg);

      const revision = await PostRevision.findOne({
        where: { id: revisionId, postId: id, siteId: actor.siteId },
      });
      if (!revision) throw NotFound('Revision not found.');

      if (revision.status === 'publish' && !actor.capabilities.includes(cfg.publishCap)) {
        throw Forbidden(cfg.cannotRestorePublish);
      }

      await this.createRevisionFrom(existing);

      const row = await this.applyUpdate(
        id,
        {
          title: revision.title,
          slug: await this.uniqueSlug(
            actor.siteId,
            revision.slug || revision.title || cfg.defaultSlugBase,
            kind,
            id,
          ),
          status: revision.status === 'auto-draft' ? 'draft' : revision.status,
          content: revision.content,
          excerpt: revision.excerpt,
          updatedById: actor.id,
          ...(revision.status === 'publish' && !existing.publishedAt
            ? { publishedAt: new Date() }
            : {}),
        },
        kind,
      );
      await this.bustPublicCache(row, kind, existing.slug);
      return await this.withAuthor(this.serialize(row));
    } catch (error) {
      throw toHttpError(error, 'Could not restore the revision.');
    }
  }

  /** Move to trash, or permanently delete when already trashed / force. */
  async remove(
    actor: AuthUser,
    id: string,
    kind: ContentKind = 'page',
    opts: { force?: boolean } = {},
  ) {
    try {
      const cfg = this.cfg(kind);
      const existing = await this.findOwned(actor, id, kind);
      this.assertMayChangePublished(actor, existing, cfg);
      const wasPublish = existing.status === 'publish';
      const slug = existing.slug;

      if (opts.force || existing.status === 'trash') {
        await Post.destroy({ where: { id: existing.id } });
        if (wasPublish || existing.status === 'trash') {
          await this.revalidateSlugPaths(kind, slug);
        }
        return { ok: true, id: existing.id, title: existing.title, permanent: true as const };
      }

      await existing.update({ status: 'trash' });
      if (wasPublish) await this.revalidateSlugPaths(kind, slug);
      return {
        ok: true,
        id: existing.id,
        title: existing.title,
        permanent: false as const,
        label: cfg.label,
      };
    } catch (error) {
      throw toHttpError(error, 'Could not move this item to trash.');
    }
  }

  async restore(actor: AuthUser, id: string, kind: ContentKind = 'page') {
    try {
      const existing = await this.findOwned(actor, id, kind);
      if (existing.status !== 'trash') {
        throw BadRequest('That item is not in the trash.');
      }
      await existing.update({ status: 'draft' });
      return await this.withAuthor(this.serialize(await this.findOwned(actor, id, kind)));
    } catch (error) {
      throw toHttpError(error, 'Could not restore this item.');
    }
  }

  private async revalidateSlugPaths(kind: ContentKind, slug: string) {
    const cfg = this.cfg(kind);
    const paths = new Set<string>([cfg.pathOf(slug)]);
    try {
      const site = await findPrimarySite();
      const front = readOptions(site?.settings?.options).frontPageSlug?.trim();
      if (kind === 'page' && front && front === slug) paths.add('/');
    } catch {
      /* still revalidate the page path */
    }
    await revalidatePublicPaths([...paths]);
  }

  /** Published documents for menus / link picker. */
  async listPublishedTargets(siteId: string, kind: ContentKind = 'page') {
    try {
      const cfg = this.cfg(kind);
      const rows = await Post.findAll({
        where: { siteId, type: cfg.type, status: 'publish' },
        order: [['title', 'ASC']],
        attributes: ['id', 'title', 'slug'],
      });
      return rows.map((r) => ({
        id: r.id,
        label: r.title,
        path: cfg.pathOf(r.slug),
        source: cfg.kind,
      }));
    } catch (error) {
      throw toHttpError(error, 'Could not load published content.');
    }
  }

  async countForSite(siteId: string, kind: ContentKind = 'page') {
    try {
      const cfg = this.cfg(kind);
      return await Post.count({
        where: {
          siteId,
          type: cfg.type,
          status: { [Op.notIn]: ['auto-draft', 'trash'] },
        },
      });
    } catch (error) {
      throw toHttpError(error, 'Could not count content.');
    }
  }

  /**
   * WordPress-style preview: store the current editor state as a tokenized snapshot.
   * Published documents keep live content untouched; drafts are saved as draft.
   */
  async createPreview(
    actor: AuthUser,
    id: string,
    body: PreviewPageInput,
    kind: ContentKind = 'page',
  ) {
    try {
      const cfg = this.cfg(kind);
      const existing = await this.findOwned(actor, id, kind);

      const title = body.title !== undefined ? body.title.trim() : existing.title;
      const excerpt = body.excerpt !== undefined ? body.excerpt.trim() : existing.excerpt;
      const existingDoc = parseContent(existing.content);
      const canvasDoc = storableDoc(actor, body.beekiricanva) ?? existingDoc.beekiricanva;
      const codeBody = storableDoc(actor, bodyBeekiriCode(body));
      const codeDoc = codeBody !== undefined ? codeBody : existingDoc.beekiricode;
      const htmlDoc =
        codeBody !== undefined
          ? contentFromBeekiriCode(codeDoc, existingDoc.html, canvasDoc)
          : contentFromBeekiricanva(canvasDoc, existingDoc.html, existingDoc.beekiricode);

      let slug = existing.slug;
      if (body.slug !== undefined) {
        slug = await this.uniqueSlug(
          actor.siteId,
          body.slug.trim() || title || cfg.defaultSlugBase,
          kind,
          id,
        );
      } else if (
        existing.status === 'auto-draft' &&
        title &&
        existing.slug.startsWith('auto-draft-')
      ) {
        slug = await this.uniqueSlug(actor.siteId, title, kind, id);
      }

      const token = randomBytes(24).toString('hex');
      const expiresAt = new Date(Date.now() + PREVIEW_TTL_MS).toISOString();
      const preview = {
        token,
        expiresAt,
        title,
        excerpt,
        html: htmlDoc.html,
        beekiricanva: htmlDoc.beekiricanva,
        beekiricode: htmlDoc.beekiricode,
      };

      const isLive = existing.status === 'publish';
      // Published: keep the live body and only attach the preview snapshot.
      const nextDoc: PageContentDoc = isLive
        ? { ...existingDoc, preview }
        : { ...htmlDoc, seo: existingDoc.seo ?? null, preview };

      const data: PostPatch = { content: nextDoc, updatedById: actor.id };
      if (!isLive) {
        data.title = title;
        data.slug = slug;
        data.excerpt = excerpt;
        if (existing.status === 'auto-draft') data.status = 'draft';
        if (this.shouldSnapshot(existing, data)) await this.createRevisionFrom(existing);
      }

      const row = await this.applyUpdate(id, data, kind);
      const serialized = await this.withAuthor(this.serialize(row));
      return {
        [cfg.itemKey]: serialized,
        // Aliases so shared admin chrome can read either key.
        page: serialized,
        post: serialized,
        previewPath: `${serialized.path}?preview=1&token=${encodeURIComponent(token)}`,
        previewToken: token,
        expiresAt,
      };
    } catch (error) {
      throw toHttpError(error, 'Could not create a preview link.');
    }
  }

  /** Public archive listing (blog index). */
  async listPublishedPublic(kind: ContentKind = 'post') {
    try {
      const cfg = this.cfg(kind);
      const site = await findPrimarySite();
      if (!site) return { [cfg.listKey]: [] };
      const rows = await Post.findAll({
        where: { siteId: site.id, type: cfg.type, status: 'publish' },
        order: [
          ['publishedAt', 'DESC NULLS FIRST'],
          ['updatedAt', 'DESC'],
        ],
        attributes: ['title', 'slug', 'excerpt', 'content', 'publishedAt', 'updatedAt'],
      });
      return {
        [cfg.listKey]: rows.map((r) => {
          const seo = parseContent(r.content).seo;
          return {
            title: r.title,
            slug: r.slug,
            path: cfg.pathOf(r.slug),
            excerpt: r.excerpt,
            publishedAt: r.publishedAt?.toISOString() ?? null,
            updatedAt: r.updatedAt.toISOString(),
            /** Sitemap / robots hints from the page's SEO settings. */
            noindex: seo ? !seo.robotsIndex : false,
            excludeFromSitemap: seo?.excludeFromSitemap ?? false,
          };
        }),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load published posts.');
    }
  }

  /** Published page for `/`: frontPageId / frontPageSlug / menu `/` / slug `home`. */
  async getPublishedFrontPage(previewToken?: string) {
    try {
      const cfg = this.cfg('page');
      const site = await findPrimarySite();
      if (!site) throw NotFound(cfg.notFound);

      const opts = readOptions(site.settings?.options);
      const frontMenu = (opts.menuItems ?? []).find((m) => ((m.path || '/').trim() || '/') === '/');
      const pageById = (id?: string | null) =>
        id ? Post.findOne({ where: { siteId: site.id, type: 'page', id } }) : Promise.resolve(null);

      let row = (await pageById(opts.frontPageId)) ?? (await pageById(frontMenu?.refId));

      const slugCandidates = [
        opts.frontPageSlug,
        frontMenu?.label
          ? frontMenu.label
              .toLowerCase()
              .trim()
              .replace(/[^a-z0-9]+/g, '-')
              .replace(/^-+|-+$/g, '')
              .slice(0, 180)
          : '',
        'home',
        'index',
      ]
        .map((s) => toSlug(s || ''))
        .filter(Boolean);

      for (const slug of slugCandidates) {
        if (row) break;
        row = await Post.findOne({ where: { siteId: site.id, type: 'page', slug } });
      }

      if (!row) throw NotFound(cfg.notFound);
      return await this.getPublishedBySlug(row.slug, previewToken, 'page');
    } catch (error) {
      throw toHttpError(error, 'Could not load the front page.');
    }
  }

  async getPublishedBySlug(slug: string, previewToken?: string, kind: ContentKind = 'page') {
    try {
      const cfg = this.cfg(kind);
      const clean = toSlug(slug);
      if (!clean) throw NotFound(cfg.notFound);
      const site = await findPrimarySite();
      if (!site) throw NotFound(cfg.notFound);
      const row = await Post.findOne({ where: { siteId: site.id, type: cfg.type, slug: clean } });
      if (!row) throw NotFound(cfg.notFound);

      const doc = parseContent(row.content);
      const token = previewToken?.trim();
      if (token && doc.preview?.token && safeEqual(doc.preview.token, token)) {
        const exp = Date.parse(doc.preview.expiresAt);
        if (!Number.isFinite(exp) || exp < Date.now()) throw NotFound('Preview link has expired.');
        return {
          title: doc.preview.title || row.title,
          slug: row.slug,
          path: cfg.pathOf(row.slug),
          content: doc.preview.html,
          beekiricanva: doc.preview.beekiricanva,
          beekiricode: doc.preview.beekiricode,
          instatic: doc.preview.beekiricode,
          excerpt: doc.preview.excerpt,
          seo: await this.publicSeo(doc.seo, row.featuredImageId),
          publishedAt: row.publishedAt?.toISOString() ?? null,
          updatedAt: row.updatedAt.toISOString(),
          preview: true as const,
        };
      }

      if (row.status !== 'publish') throw NotFound(cfg.notFound);

      const data = this.serialize(row);
      return {
        title: data.title,
        slug: data.slug,
        path: data.path,
        content: data.content,
        beekiricanva: data.beekiricanva,
        beekiricode: data.beekiricode,
        instatic: data.beekiricode,
        excerpt: data.excerpt,
        seo: await this.publicSeo(doc.seo, row.featuredImageId),
        publishedAt: data.publishedAt,
        updatedAt: data.updatedAt,
        preview: false as const,
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load this page.');
    }
  }
}

export const pagesService = new PagesService();
