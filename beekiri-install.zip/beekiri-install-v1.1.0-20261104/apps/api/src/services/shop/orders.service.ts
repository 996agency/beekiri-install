import { Op, type Transaction, type WhereOptions } from 'sequelize';
import { config } from '../../config/env';
import {
  ORDER_STATUS_LABELS,
  ORDER_STATUSES,
  STOCK_HOLDING_STATUSES,
  type OrderStatus,
} from '../../lib/shop/constants';
import { orderNumberLabel, renderOrderEmail, type EmailKind, type EmailSite } from '../../lib/shop/emails';
import { formatMoney } from '../../lib/shop/money';
import { paymentProvider } from '../../lib/shop/payments';
import { stockStatusFor } from '../../lib/shop/pricing';
import { buildTracking, parseFulfillment } from '../../lib/shop/tracking';
import { moneyFormatOf, type ShopSettings } from '../../lib/shop/settings';
import {
  AuditLog,
  sequelize,
  ShopCoupon,
  ShopCustomer,
  ShopOrder,
  ShopOrderItem,
  ShopOrderNote,
  ShopProduct,
  ShopProductVariant,
  User,
} from '../../models';
import type { AuthUser } from '../../types/auth';
import { BadRequest, NotFound, toHttpError } from '../../utils/http-error';
import { createLogger } from '../../utils/logger';
import type { OrderListInput } from '../../validators/shop.schema';
import { mailService } from '../mail.service';
import { findPrimarySite } from '../site-context';
import { customersService } from './customers.service';
import { shopSettingsService } from './shop-settings.service';

const log = createLogger('shop-orders');

/** Orders in these states count towards product sales figures. */
const SALES_STATUSES: readonly string[] = ['processing', 'completed'];

export type OrderLineForStock = { productId: string | null; variantId: string | null; qty: number };

export function serializeOrderItem(i: ShopOrderItem, postIdOf?: Map<string, string>) {
  return {
    id: i.id,
    productId: i.productId ?? null,
    /** Post id of the product (admin link); null when the product was deleted. */
    postId: i.productId ? (postIdOf?.get(i.productId) ?? null) : null,
    variantId: i.variantId ?? null,
    name: i.name,
    sku: i.sku,
    qty: i.qty,
    unitPrice: i.unitPrice,
    subtotal: i.subtotal,
    total: i.total,
    taxTotal: i.taxTotal,
    attributes: (i.attributes ?? {}) as Record<string, string>,
    imageUrl: i.imageUrl,
    virtual: i.virtual,
  };
}

export function serializeOrder(o: ShopOrder, settings: ShopSettings, items: ShopOrderItem[] = [], notes: ShopOrderNote[] = [], authors = new Map<string, string>(), postIdOf?: Map<string, string>) {
  const fmt = { ...moneyFormatOf(settings), currency: o.currency || settings.general.currency };
  const money = (v: number) => formatMoney(v, fmt);
  const billing = (o.billing ?? {}) as Record<string, string>;
  return {
    id: o.id,
    number: o.number,
    numberLabel: orderNumberLabel(o, settings),
    status: o.status,
    statusLabel: ORDER_STATUS_LABELS[o.status as OrderStatus] ?? o.status,
    currency: o.currency,
    subtotal: o.subtotal,
    discountTotal: o.discountTotal,
    shippingTotal: o.shippingTotal,
    taxTotal: o.taxTotal,
    total: o.total,
    refundedTotal: o.refundedTotal,
    formatted: {
      subtotal: money(o.subtotal),
      discountTotal: money(o.discountTotal),
      shippingTotal: money(o.shippingTotal),
      taxTotal: money(o.taxTotal),
      total: money(o.total),
      refundedTotal: money(o.refundedTotal),
      net: money(o.total - o.refundedTotal),
    },
    couponCode: o.couponCode ?? null,
    customerId: o.customerId ?? null,
    customerName: [billing.firstName, billing.lastName].filter(Boolean).join(' ') || o.email,
    email: o.email,
    phone: o.phone,
    billing: o.billing,
    shipping: o.shipping,
    shipToDifferent: o.shipToDifferent,
    shippingMethod: o.shippingMethod,
    paymentMethod: o.paymentMethod,
    paymentMethodTitle: paymentTitle(o.paymentMethod, settings),
    paymentStatus: o.paymentStatus,
    transactionId: o.transactionId,
    paymentRef: o.paymentRef,
    customerNote: o.customerNote,
    customFields: customFieldRows(o),
    fulfillment: parseFulfillment(o.fulfillment),
    tracking: buildTracking(o, { virtual: items.length > 0 && items.every((i) => i.virtual) }),
    accessToken: o.accessToken,
    ipAddress: o.ipAddress,
    placedAt: o.placedAt.toISOString(),
    paidAt: o.paidAt ? new Date(o.paidAt).toISOString() : null,
    completedAt: o.completedAt ? new Date(o.completedAt).toISOString() : null,
    updatedAt: o.updatedAt.toISOString(),
    items: items.map((i) => ({ ...serializeOrderItem(i, postIdOf), formatted: { unitPrice: money(i.unitPrice), total: money(i.total) } })),
    notes: notes.map((n) => ({
      id: n.id,
      note: n.note,
      isCustomerNote: n.isCustomerNote,
      authorId: n.authorId ?? null,
      authorName: n.authorId ? (authors.get(n.authorId) ?? 'Staff') : 'System',
      createdAt: n.createdAt.toISOString(),
    })),
  };
}

/** Custom checkout answers as rows for screens and emails. */
export function customFieldRows(o: Pick<ShopOrder, 'customFields'>): { key: string; label: string; value: string }[] {
  const raw = o.customFields;
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return [];
  return Object.entries(raw as Record<string, { label?: string; value?: unknown }>).map(([key, v]) => ({
    key,
    label: String(v?.label ?? key),
    value: String(v?.value ?? ''),
  }));
}

export function paymentTitle(method: string, settings: ShopSettings): string {
  if (method === 'stripe') return settings.payments.stripe.title;
  if (method === 'cod') return settings.payments.cod.title;
  if (method === 'bank_transfer') return settings.payments.bankTransfer.title;
  return method;
}

export class OrdersService {
  private async audit(actor: AuthUser | null, siteId: string, action: string, meta: Record<string, unknown>) {
    await AuditLog.create({ siteId, userId: actor?.id ?? null, action, meta });
  }

  /* ── Stock ─────────────────────────────────────────────────────────── */

  /**
   * Take `qty` of every line out of stock inside `transaction`, locking the rows.
   * Throws a readable error when something is no longer available.
   */
  async reserveStock(lines: OrderLineForStock[], transaction: Transaction, labels: Map<string, string> = new Map()) {
    for (const line of lines) {
      if (!line.productId) continue;
      const product = await ShopProduct.findByPk(line.productId, { transaction, lock: transaction.LOCK.UPDATE });
      if (!product) throw BadRequest(`${labels.get(line.productId) ?? 'An item'} is no longer available.`);
      const name = labels.get(line.productId) ?? 'An item';
      const variant = line.variantId
        ? await ShopProductVariant.findOne({ where: { id: line.variantId, productId: product.id }, transaction, lock: transaction.LOCK.UPDATE })
        : null;
      if (line.variantId && (!variant || !variant.enabled)) throw BadRequest(`${name}: that option is no longer available.`);

      const target = variant?.manageStock ? variant : product.manageStock ? product : null;
      const status = (variant ?? product).stockStatus;
      if (!target) {
        if (status === 'outofstock') throw BadRequest(`${name} is out of stock.`);
        continue;
      }
      const have = target.stockQty ?? 0;
      const allowBackorder = target.stockStatus === 'onbackorder';
      if (have < line.qty && !allowBackorder) {
        throw BadRequest(have > 0 ? `Only ${have} of ${name} left in stock.` : `${name} is out of stock.`);
      }
      const next = have - line.qty;
      await this.setStock(target, next, stockStatusFor(next, allowBackorder), transaction);
    }
  }

  private async setStock(row: ShopProduct | ShopProductVariant, stockQty: number, stockStatus: string, transaction: Transaction) {
    if (row instanceof ShopProductVariant) await row.update({ stockQty, stockStatus }, { transaction });
    else await row.update({ stockQty, stockStatus }, { transaction });
  }

  /** Put the quantities back (cancelled / failed / refunded with restock). */
  async releaseStock(lines: OrderLineForStock[], transaction: Transaction) {
    for (const line of lines) {
      if (!line.productId) continue;
      const product = await ShopProduct.findByPk(line.productId, { transaction, lock: transaction.LOCK.UPDATE });
      if (!product) continue;
      const variant = line.variantId
        ? await ShopProductVariant.findOne({ where: { id: line.variantId, productId: product.id }, transaction, lock: transaction.LOCK.UPDATE })
        : null;
      const target = variant?.manageStock ? variant : product.manageStock ? product : null;
      if (!target) continue;
      const next = (target.stockQty ?? 0) + line.qty;
      await this.setStock(target, next, stockStatusFor(next, target.stockStatus === 'onbackorder'), transaction);
    }
  }

  private async adjustSales(items: ShopOrderItem[], direction: 1 | -1, transaction: Transaction) {
    for (const item of items) {
      if (!item.productId) continue;
      await ShopProduct.increment({ totalSales: direction * item.qty }, { where: { id: item.productId }, transaction });
    }
  }

  /* ── Status machine ────────────────────────────────────────────────── */

  /**
   * Move an order to `next`, keeping stock and sales counters consistent.
   * Must run inside `transaction`; emails are sent by the caller afterwards.
   */
  async transition(order: ShopOrder, next: OrderStatus, transaction: Transaction, opts: { restock?: boolean } = {}) {
    const prev = order.status;
    if (prev === next) return;
    const items = await ShopOrderItem.findAll({ where: { orderId: order.id }, transaction });
    const heldBefore = STOCK_HOLDING_STATUSES.includes(prev);
    const heldAfter = STOCK_HOLDING_STATUSES.includes(next);
    const restock = opts.restock ?? true;
    if (heldBefore && !heldAfter && restock) await this.releaseStock(items, transaction);
    if (!heldBefore && heldAfter) {
      const labels = new Map(items.map((i) => [i.productId ?? '', i.name]));
      await this.reserveStock(items, transaction, labels);
    }
    const soldBefore = SALES_STATUSES.includes(prev);
    const soldAfter = SALES_STATUSES.includes(next);
    if (!soldBefore && soldAfter) await this.adjustSales(items, 1, transaction);
    if (soldBefore && !soldAfter) await this.adjustSales(items, -1, transaction);

    const patch: Partial<ShopOrder> = { status: next };
    if (next === 'completed') {
      patch.completedAt = new Date();
      if (order.paymentStatus === 'unpaid') {
        patch.paymentStatus = 'paid';
        patch.paidAt = order.paidAt ?? new Date();
      }
    }
    if (next === 'processing' && order.paymentStatus === 'unpaid' && order.paymentMethod !== 'cod') {
      patch.paymentStatus = 'paid';
      patch.paidAt = order.paidAt ?? new Date();
    }
    if (next === 'refunded') {
      patch.paymentStatus = 'refunded';
      if (order.refundedTotal < order.total) patch.refundedTotal = order.total;
    }
    if (next === 'failed') patch.paymentStatus = 'failed';
    await order.update(patch, { transaction });
    await ShopOrderNote.create(
      { siteId: order.siteId, orderId: order.id, authorId: null, note: `Status changed from ${ORDER_STATUS_LABELS[prev as OrderStatus] ?? prev} to ${ORDER_STATUS_LABELS[next]}.`, isCustomerNote: false },
      { transaction },
    );
    if (order.customerId) await customersService.refreshStats(order.customerId, transaction);
  }

  /** Payment confirmed by a provider: idempotent. */
  async markPaid(orderId: string, ref: { transactionId?: string; paymentRef?: Record<string, unknown> }, transaction?: Transaction): Promise<ShopOrder | null> {
    const run = async (t: Transaction) => {
      const order = await ShopOrder.findByPk(orderId, { transaction: t, lock: t.LOCK.UPDATE });
      if (!order) return null;
      if (order.paymentStatus === 'paid' || order.paymentStatus === 'refunded' || order.paymentStatus === 'partially_refunded') return order;
      const items = await ShopOrderItem.findAll({ where: { orderId }, transaction: t });
      await order.update(
        {
          paymentStatus: 'paid',
          paidAt: new Date(),
          transactionId: ref.transactionId ?? order.transactionId,
          paymentRef: { ...((order.paymentRef as Record<string, unknown>) ?? {}), ...(ref.paymentRef ?? {}) },
        },
        { transaction: t },
      );
      const allVirtual = items.length > 0 && items.every((i) => i.virtual);
      await this.transition(order, allVirtual ? 'completed' : 'processing', t);
      return order;
    };
    return transaction ? run(transaction) : sequelize.transaction(run);
  }

  /* ── Emails ────────────────────────────────────────────────────────── */

  async emailSite(): Promise<EmailSite> {
    const site = await findPrimarySite();
    const url = (config.urls.app ?? '').replace(/\/+$/, '');
    return { title: site?.title?.trim() || 'Beekiri', url };
  }

  /** Fire-and-forget; never throws. */
  async sendEmail(kind: EmailKind, order: ShopOrder, extra: { note?: string; refundAmount?: number } = {}) {
    try {
      const settings = await shopSettingsService.get(order.siteId);
      const cfg = settings.emails[kind];
      if (!cfg?.enabled) return;
      const to = kind === 'newOrderAdmin' ? settings.emails.adminEmail || (await this.ownerEmail(order.siteId)) : order.email;
      if (!to) return;
      const items = await ShopOrderItem.findAll({ where: { orderId: order.id }, order: [['createdAt', 'ASC']] });
      const site = await this.emailSite();
      const rendered = renderOrderEmail(kind, order, items, settings, site, extra);
      await mailService.sendMail({ to, subject: rendered.subject, text: rendered.text, html: rendered.html });
    } catch (error) {
      log.warn(`Could not send ${kind} email for order ${order.id}: ${(error as Error).message}`);
    }
  }

  private async ownerEmail(siteId: string): Promise<string> {
    const owner = await User.findOne({ where: { siteId, isOwner: true }, attributes: ['email'] });
    return owner?.email ?? '';
  }

  /** Emails that follow a status change. */
  async notifyStatus(order: ShopOrder, next: OrderStatus, note?: string) {
    const map: Partial<Record<OrderStatus, EmailKind>> = {
      'on-hold': 'onHold',
      processing: 'processing',
      completed: 'completed',
      cancelled: 'cancelled',
      refunded: 'refunded',
    };
    const kind = map[next];
    if (kind) void this.sendEmail(kind, order, { note });
  }

  /* ── Admin ─────────────────────────────────────────────────────────── */

  async list(actor: AuthUser, query: OrderListInput) {
    try {
      const settings = await shopSettingsService.get(actor.siteId);
      const page = query.page ?? 1;
      const perPage = query.perPage ?? 25;
      const where: WhereOptions = { siteId: actor.siteId };
      if (query.status && query.status !== 'all') Object.assign(where, { status: query.status });
      if (query.payment) Object.assign(where, { paymentMethod: query.payment });
      if (query.customerId) Object.assign(where, { customerId: query.customerId });
      const range: Record<symbol, Date> = {};
      if (query.from && !Number.isNaN(Date.parse(query.from))) range[Op.gte] = new Date(query.from);
      if (query.to && !Number.isNaN(Date.parse(query.to))) range[Op.lte] = new Date(query.to);
      if (Object.getOwnPropertySymbols(range).length) Object.assign(where, { placedAt: range });
      const q = (query.q ?? '').trim();
      if (q) {
        const like = `%${q.replace(/[%_\\]/g, '\\$&')}%`;
        const ors: WhereOptions[] = [
          { email: { [Op.iLike]: like } },
          { transactionId: { [Op.iLike]: like } },
          sequelize.where(sequelize.cast(sequelize.col('ShopOrder.billing'), 'text'), { [Op.iLike]: like }),
        ];
        const num = Number(q.replace(/^#/, ''));
        if (Number.isInteger(num)) ors.push({ number: num });
        Object.assign(where, { [Op.or]: ors });
      }
      const { rows, count } = await ShopOrder.findAndCountAll({
        where,
        include: [{ model: ShopOrderItem, as: 'items' }],
        order: [['placedAt', 'DESC']],
        limit: perPage,
        offset: (page - 1) * perPage,
        distinct: true,
      });
      const statusCounts = await ShopOrder.findAll({ where: { siteId: actor.siteId }, attributes: ['status'] });
      const counts: Record<string, number> = { all: statusCounts.length };
      for (const s of ORDER_STATUSES) counts[s] = 0;
      for (const r of statusCounts) counts[r.status] = (counts[r.status] ?? 0) + 1;
      return {
        items: rows.map((o) => {
          const items = (o as ShopOrder & { items?: ShopOrderItem[] }).items ?? [];
          const dto = serializeOrder(o, settings, items);
          return { ...dto, itemCount: items.reduce((a, i) => a + i.qty, 0), items: undefined, notes: undefined };
        }),
        total: count,
        page,
        perPage,
        pages: Math.max(1, Math.ceil(count / perPage)),
        counts,
        statuses: ORDER_STATUSES.map((s) => ({ id: s, label: ORDER_STATUS_LABELS[s] })),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load orders.');
    }
  }

  private async load(siteId: string, id: string, transaction?: Transaction) {
    const order = await ShopOrder.findOne({ where: { id, siteId }, transaction, ...(transaction ? { lock: transaction.LOCK.UPDATE } : {}) });
    if (!order) throw NotFound('Order not found.');
    return order;
  }

  async get(actor: AuthUser, id: string) {
    try {
      const order = await this.load(actor.siteId, id);
      return this.detail(order);
    } catch (error) {
      throw toHttpError(error, 'Could not load the order.');
    }
  }

  async detail(order: ShopOrder) {
    const settings = await shopSettingsService.get(order.siteId);
    const [items, notes] = await Promise.all([
      ShopOrderItem.findAll({ where: { orderId: order.id }, order: [['createdAt', 'ASC']] }),
      ShopOrderNote.findAll({ where: { orderId: order.id }, order: [['createdAt', 'DESC']] }),
    ]);
    const authorIds = [...new Set(notes.map((n) => n.authorId).filter((v): v is string => Boolean(v)))];
    const users = authorIds.length ? await User.findAll({ where: { id: { [Op.in]: authorIds } }, attributes: ['id', 'displayName', 'username'] }) : [];
    const authors = new Map(users.map((u) => [u.id, u.displayName?.trim() || u.username]));
    const customer = order.customerId ? await ShopCustomer.findByPk(order.customerId) : null;
    const productIds = [...new Set(items.map((i) => i.productId).filter((v): v is string => Boolean(v)))];
    const products = productIds.length ? await ShopProduct.findAll({ where: { id: { [Op.in]: productIds } }, attributes: ['id', 'postId'] }) : [];
    const postIdOf = new Map(products.map((p) => [p.id, p.postId]));
    return {
      order: serializeOrder(order, settings, items, notes, authors, postIdOf),
      customer: customer
        ? { id: customer.id, email: customer.email, name: [customer.firstName, customer.lastName].filter(Boolean).join(' ') || customer.email, ordersCount: customer.ordersCount, totalSpent: customer.totalSpent }
        : null,
      canRefundViaProvider: order.paymentMethod === 'stripe' && order.paymentStatus !== 'unpaid' && Boolean((order.paymentRef as { paymentIntentId?: string })?.paymentIntentId),
    };
  }

  async setStatus(actor: AuthUser, id: string, next: OrderStatus, note?: string) {
    try {
      const order = await sequelize.transaction(async (t) => {
        const o = await this.load(actor.siteId, id, t);
        const prev = o.status;
        await this.transition(o, next, t);
        await this.audit(actor, actor.siteId, 'order.status_changed', { id, from: prev, to: next });
        return o;
      });
      this.notifyStatus(order, next, note?.trim() || undefined);
      return this.detail(order);
    } catch (error) {
      throw toHttpError(error, 'Could not change the order status.');
    }
  }

  async updateDetails(actor: AuthUser, id: string, body: { email?: string; phone?: string; billing?: Record<string, unknown>; shipping?: Record<string, unknown>; customerNote?: string }) {
    try {
      const order = await this.load(actor.siteId, id);
      const patch: Partial<ShopOrder> = {};
      if (body.email !== undefined) patch.email = body.email.trim().toLowerCase();
      if (body.phone !== undefined) patch.phone = body.phone.trim();
      if (body.billing !== undefined) patch.billing = body.billing;
      if (body.shipping !== undefined) patch.shipping = body.shipping;
      if (body.customerNote !== undefined) patch.customerNote = body.customerNote.trim();
      await order.update(patch);
      await this.audit(actor, actor.siteId, 'order.updated', { id });
      return this.detail(order);
    } catch (error) {
      throw toHttpError(error, 'Could not update the order.');
    }
  }

  async addNote(actor: AuthUser, id: string, note: string, isCustomerNote: boolean) {
    try {
      const order = await this.load(actor.siteId, id);
      await ShopOrderNote.create({ siteId: actor.siteId, orderId: id, authorId: actor.id, note: note.trim(), isCustomerNote });
      if (isCustomerNote) void this.sendEmail('customerNote', order, { note: note.trim() });
      return this.detail(order);
    } catch (error) {
      throw toHttpError(error, 'Could not add the note.');
    }
  }

  async removeNote(actor: AuthUser, id: string, noteId: string) {
    try {
      const order = await this.load(actor.siteId, id);
      await ShopOrderNote.destroy({ where: { id: noteId, orderId: id } });
      return this.detail(order);
    } catch (error) {
      throw toHttpError(error, 'Could not delete the note.');
    }
  }

  async refund(actor: AuthUser, id: string, input: { amount?: number; reason?: string; viaProvider?: boolean; restock?: boolean }) {
    try {
      const settings = await shopSettingsService.get(actor.siteId);
      const order = await this.load(actor.siteId, id);
      if (order.paymentStatus === 'unpaid' || order.paymentStatus === 'failed') {
        throw BadRequest('This order has not been paid, so there is nothing to refund. Cancel it instead.');
      }
      const remaining = order.total - order.refundedTotal;
      const amount = input.amount ?? remaining;
      if (amount <= 0 || amount > remaining) throw BadRequest(`Enter an amount between 1 and ${remaining} (minor units).`);

      let refundId = '';
      if (input.viaProvider) {
        const provider = paymentProvider(order.paymentMethod);
        if (!provider?.refund) throw BadRequest('This payment method cannot be refunded automatically. Refund it manually, then record it here.');
        const site = await this.emailSite();
        const items = await ShopOrderItem.findAll({ where: { orderId: id } });
        const result = await provider.refund(order, amount, { settings, appUrl: site.url, siteTitle: site.title, items }, input.reason);
        refundId = result.refundId;
      }
      const full = amount >= remaining;
      await sequelize.transaction(async (t) => {
        const o = await this.load(actor.siteId, id, t);
        await o.update(
          { refundedTotal: o.refundedTotal + amount, paymentStatus: full ? 'refunded' : 'partially_refunded' },
          { transaction: t },
        );
        await ShopOrderNote.create(
          {
            siteId: actor.siteId,
            orderId: id,
            authorId: actor.id,
            note: `Refunded ${formatMoney(amount, { ...moneyFormatOf(settings), currency: o.currency })}${refundId ? ` via ${o.paymentMethod} (${refundId})` : ' (recorded manually)'}${input.reason ? ` — ${input.reason.trim()}` : ''}.`,
            isCustomerNote: false,
          },
          { transaction: t },
        );
        if (full) await this.transition(o, 'refunded', t, { restock: input.restock ?? true });
        else if (o.customerId) await customersService.refreshStats(o.customerId, t);
      });
      await this.audit(actor, actor.siteId, 'order.refunded', { id, amount, refundId, full });
      const fresh = await this.load(actor.siteId, id);
      void this.sendEmail('refunded', fresh, { refundAmount: amount });
      return this.detail(fresh);
    } catch (error) {
      throw toHttpError(error, 'Could not refund the order.');
    }
  }

  /**
   * Packed → shipped (carrier + tracking) → delivered. Delivered completes the order;
   * shipped / delivered can email the customer.
   */
  async setFulfillment(
    actor: AuthUser,
    id: string,
    input: { status: 'unfulfilled' | 'packed' | 'shipped' | 'delivered'; carrier?: string; trackingNumber?: string; trackingUrl?: string; notify?: boolean },
  ) {
    try {
      const order = await sequelize.transaction(async (t) => {
        const o = await this.load(actor.siteId, id, t);
        if (['cancelled', 'refunded', 'failed'].includes(o.status)) throw BadRequest(`This order is ${o.status}; it cannot be shipped.`);
        if (o.status === 'pending' && input.status !== 'unfulfilled') throw BadRequest('This order is still waiting for payment.');
        const prev = parseFulfillment(o.fulfillment);
        const now = new Date().toISOString();
        const next = {
          ...prev,
          status: input.status,
          carrier: input.carrier !== undefined ? input.carrier.trim() : prev.carrier,
          trackingNumber: input.trackingNumber !== undefined ? input.trackingNumber.trim() : prev.trackingNumber,
          trackingUrl: input.trackingUrl !== undefined ? input.trackingUrl.trim() : prev.trackingUrl,
          packedAt: ['packed', 'shipped', 'delivered'].includes(input.status) ? (prev.packedAt ?? now) : null,
          shippedAt: ['shipped', 'delivered'].includes(input.status) ? (prev.shippedAt ?? now) : null,
          deliveredAt: input.status === 'delivered' ? (prev.deliveredAt ?? now) : null,
        };
        await o.update({ fulfillment: next }, { transaction: t });
        const labels = { unfulfilled: 'Not shipped', packed: 'Packed', shipped: 'Shipped', delivered: 'Delivered' } as const;
        const extra = input.status === 'shipped' && (next.carrier || next.trackingNumber) ? ` (${[next.carrier, next.trackingNumber].filter(Boolean).join(' ')})` : '';
        await ShopOrderNote.create(
          { siteId: o.siteId, orderId: o.id, authorId: actor.id, note: `Fulfilment: ${labels[input.status]}${extra}.`, isCustomerNote: false },
          { transaction: t },
        );
        if (input.status === 'delivered' && o.status !== 'completed') await this.transition(o, 'completed', t);
        if (input.status !== 'delivered' && o.status === 'on-hold' && input.status !== 'unfulfilled') {
          // Shipping an on-hold order means the payment arrived.
          await this.transition(o, 'processing', t);
        }
        await this.audit(actor, actor.siteId, 'order.fulfillment', { id, status: input.status });
        return o;
      });
      if (input.notify !== false && (input.status === 'shipped' || input.status === 'delivered')) {
        void this.sendEmail(input.status, order);
      }
      return this.detail(order);
    } catch (error) {
      throw toHttpError(error, 'Could not update the shipment.');
    }
  }

  async resendEmail(actor: AuthUser, id: string, kind: EmailKind) {
    try {
      const order = await this.load(actor.siteId, id);
      await this.sendEmail(kind, order);
      await this.audit(actor, actor.siteId, 'order.email_resent', { id, kind });
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not send the email.');
    }
  }

  /** Pending Stripe orders whose hold time passed: cancel + restock. */
  async sweepExpired(siteId?: string) {
    try {
      const settings = await shopSettingsService.get(siteId);
      const cutoff = new Date(Date.now() - settings.advanced.holdStockMinutes * 60_000);
      const stale = await ShopOrder.findAll({
        where: { status: 'pending', paymentStatus: 'unpaid', paymentMethod: 'stripe', placedAt: { [Op.lt]: cutoff }, ...(siteId ? { siteId } : {}) },
        limit: 50,
      });
      for (const order of stale) {
        await sequelize.transaction(async (t) => {
          const o = await ShopOrder.findByPk(order.id, { transaction: t, lock: t.LOCK.UPDATE });
          if (!o || o.status !== 'pending' || o.paymentStatus !== 'unpaid') return;
          await this.transition(o, 'cancelled', t);
          await ShopOrderNote.create({ siteId: o.siteId, orderId: o.id, authorId: null, note: 'Unpaid order expired and was cancelled automatically.', isCustomerNote: false }, { transaction: t });
        });
      }
      return stale.length;
    } catch (error) {
      log.warn(`Expired-order sweep failed: ${(error as Error).message}`);
      return 0;
    }
  }

  /** Coupon usage is counted when the order leaves "pending" the first time. */
  async countCouponUse(order: ShopOrder, transaction: Transaction) {
    if (!order.couponCode) return;
    await ShopCoupon.increment({ usageCount: 1 }, { where: { siteId: order.siteId, code: order.couponCode }, transaction });
  }
}

export const ordersService = new OrdersService();
