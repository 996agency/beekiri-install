import { Op, type Transaction } from 'sequelize';
import type { CouponRule } from '../../lib/shop/cart-totals';
import { AuditLog, ShopCoupon, ShopOrder } from '../../models';
import type { AuthUser } from '../../types/auth';
import { uniqueViolation } from '../../utils/db-errors';
import { BadRequest, Conflict, NotFound, toHttpError } from '../../utils/http-error';
import type { CouponInput, UpdateCouponInput } from '../../validators/shop.schema';

function ids(raw: unknown): string[] {
  return Array.isArray(raw) ? raw.map(String) : [];
}

export function serializeCoupon(row: ShopCoupon) {
  return {
    id: row.id,
    code: row.code,
    type: row.type,
    amount: row.amount,
    description: row.description,
    minSpend: row.minSpend ?? null,
    maxSpend: row.maxSpend ?? null,
    usageLimit: row.usageLimit ?? null,
    usageLimitPerEmail: row.usageLimitPerEmail ?? null,
    usageCount: row.usageCount,
    expiresAt: row.expiresAt ? new Date(row.expiresAt).toISOString() : null,
    productIds: ids(row.productIds),
    excludeProductIds: ids(row.excludeProductIds),
    categoryIds: ids(row.categoryIds),
    freeShipping: row.freeShipping,
    active: row.active,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export function couponRule(row: ShopCoupon): CouponRule {
  return {
    code: row.code,
    type: row.type as CouponRule['type'],
    amount: row.amount,
    minSpend: row.minSpend ?? null,
    maxSpend: row.maxSpend ?? null,
    productIds: ids(row.productIds),
    excludeProductIds: ids(row.excludeProductIds),
    categoryIds: ids(row.categoryIds),
    freeShipping: row.freeShipping,
  };
}

export const normalizeCode = (code: string) => code.trim().toUpperCase();

export class CouponsService {
  private async audit(actor: AuthUser, action: string, meta: Record<string, unknown>) {
    await AuditLog.create({ siteId: actor.siteId, userId: actor.id, action, meta });
  }

  async list(actor: AuthUser) {
    try {
      const rows = await ShopCoupon.findAll({ where: { siteId: actor.siteId }, order: [['createdAt', 'DESC']] });
      return { coupons: rows.map(serializeCoupon) };
    } catch (error) {
      throw toHttpError(error, 'Could not load coupons.');
    }
  }

  async get(actor: AuthUser, id: string) {
    const row = await ShopCoupon.findOne({ where: { id, siteId: actor.siteId } });
    if (!row) throw NotFound('Coupon not found.');
    return serializeCoupon(row);
  }

  private validate(input: Partial<CouponInput>) {
    if (input.type === 'percent' && input.amount !== undefined && input.amount > 10_000) {
      throw BadRequest('A percentage coupon cannot exceed 100%.');
    }
    if (input.minSpend != null && input.maxSpend != null && input.minSpend > input.maxSpend) {
      throw BadRequest('Minimum spend cannot be higher than maximum spend.');
    }
  }

  async create(actor: AuthUser, input: CouponInput) {
    try {
      this.validate(input);
      const row = await ShopCoupon.create({
        siteId: actor.siteId,
        code: normalizeCode(input.code),
        type: input.type,
        amount: input.amount,
        description: (input.description ?? '').trim(),
        minSpend: input.minSpend ?? null,
        maxSpend: input.maxSpend ?? null,
        usageLimit: input.usageLimit ?? null,
        usageLimitPerEmail: input.usageLimitPerEmail ?? null,
        expiresAt: input.expiresAt ? new Date(input.expiresAt) : null,
        productIds: input.productIds ?? [],
        excludeProductIds: input.excludeProductIds ?? [],
        categoryIds: input.categoryIds ?? [],
        freeShipping: input.freeShipping ?? false,
        active: input.active ?? true,
      });
      await this.audit(actor, 'coupon.created', { id: row.id, code: row.code });
      return serializeCoupon(row);
    } catch (error) {
      if (uniqueViolation(error)) throw Conflict('A coupon with that code already exists.');
      throw toHttpError(error, 'Could not create the coupon.');
    }
  }

  async update(actor: AuthUser, id: string, input: UpdateCouponInput) {
    try {
      const row = await ShopCoupon.findOne({ where: { id, siteId: actor.siteId } });
      if (!row) throw NotFound('Coupon not found.');
      this.validate({ ...serializeCoupon(row), ...input } as Partial<CouponInput>);
      const patch: Partial<ShopCoupon> = {};
      if (input.code !== undefined) patch.code = normalizeCode(input.code);
      if (input.type !== undefined) patch.type = input.type;
      if (input.amount !== undefined) patch.amount = input.amount;
      if (input.description !== undefined) patch.description = input.description.trim();
      if (input.minSpend !== undefined) patch.minSpend = input.minSpend;
      if (input.maxSpend !== undefined) patch.maxSpend = input.maxSpend;
      if (input.usageLimit !== undefined) patch.usageLimit = input.usageLimit;
      if (input.usageLimitPerEmail !== undefined) patch.usageLimitPerEmail = input.usageLimitPerEmail;
      if (input.expiresAt !== undefined) patch.expiresAt = input.expiresAt ? new Date(input.expiresAt) : null;
      if (input.productIds !== undefined) patch.productIds = input.productIds;
      if (input.excludeProductIds !== undefined) patch.excludeProductIds = input.excludeProductIds;
      if (input.categoryIds !== undefined) patch.categoryIds = input.categoryIds;
      if (input.freeShipping !== undefined) patch.freeShipping = input.freeShipping;
      if (input.active !== undefined) patch.active = input.active;
      await row.update(patch);
      await this.audit(actor, 'coupon.updated', { id: row.id, code: row.code });
      return serializeCoupon(row);
    } catch (error) {
      if (uniqueViolation(error)) throw Conflict('A coupon with that code already exists.');
      throw toHttpError(error, 'Could not update the coupon.');
    }
  }

  async remove(actor: AuthUser, id: string) {
    try {
      const row = await ShopCoupon.findOne({ where: { id, siteId: actor.siteId } });
      if (!row) throw NotFound('Coupon not found.');
      await row.destroy();
      await this.audit(actor, 'coupon.deleted', { id, code: row.code });
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not delete the coupon.');
    }
  }

  /**
   * A usable coupon for the storefront, or a reason it is not. Usage limits are
   * re-checked (with a row lock) when the order is placed.
   */
  async resolve(
    siteId: string,
    code: string,
    email: string | null,
    transaction?: Transaction,
  ): Promise<{ coupon: ShopCoupon; rule: CouponRule } | { error: string }> {
    const clean = normalizeCode(code);
    if (!clean) return { error: 'Enter a coupon code.' };
    const row = await ShopCoupon.findOne({
      where: { siteId, code: clean },
      transaction,
      ...(transaction ? { lock: transaction.LOCK.UPDATE } : {}),
    });
    if (!row || !row.active) return { error: 'That coupon code is not valid.' };
    if (row.expiresAt && new Date(row.expiresAt).getTime() < Date.now()) return { error: 'That coupon has expired.' };
    if (row.usageLimit !== null && row.usageCount >= row.usageLimit) return { error: 'That coupon has reached its usage limit.' };
    if (row.usageLimitPerEmail !== null && email) {
      const used = await ShopOrder.count({
        where: {
          siteId,
          couponCode: clean,
          email: email.toLowerCase(),
          status: { [Op.notIn]: ['cancelled', 'failed'] },
        },
        transaction,
      });
      if (used >= row.usageLimitPerEmail) return { error: 'You have already used this coupon.' };
    }
    return { coupon: row, rule: couponRule(row) };
  }
}

export const couponsService = new CouponsService();
