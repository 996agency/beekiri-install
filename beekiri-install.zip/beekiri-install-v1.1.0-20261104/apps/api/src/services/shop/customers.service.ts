import { Op, type Transaction, type WhereOptions } from 'sequelize';
import { ShopCustomer, ShopOrder } from '../../models';
import type { AuthUser } from '../../types/auth';
import { NotFound, toHttpError } from '../../utils/http-error';

export function serializeCustomer(row: ShopCustomer) {
  return {
    id: row.id,
    email: row.email,
    firstName: row.firstName,
    lastName: row.lastName,
    name: [row.firstName, row.lastName].filter(Boolean).join(' ') || row.email,
    phone: row.phone,
    billing: row.billing,
    shipping: row.shipping,
    ordersCount: row.ordersCount,
    totalSpent: row.totalSpent,
    lastOrderAt: row.lastOrderAt ? new Date(row.lastOrderAt).toISOString() : null,
    /** Registered shopper (My account) vs. guest checkouts only. */
    hasAccount: Boolean(row.passwordHash),
    emailVerified: Boolean(row.emailVerifiedAt),
    lastLoginAt: row.lastLoginAt ? new Date(row.lastLoginAt).toISOString() : null,
    createdAt: row.createdAt.toISOString(),
  };
}

export class CustomersService {
  /** Find-or-create by email and refresh the stored addresses (called when an order is placed). */
  async upsertFromOrder(
    siteId: string,
    data: {
      email: string;
      firstName: string;
      lastName: string;
      phone: string;
      billing: Record<string, unknown>;
      shipping: Record<string, unknown>;
    },
    transaction: Transaction,
    signedIn: ShopCustomer | null = null,
  ): Promise<ShopCustomer> {
    // Signed-in shoppers: the order belongs to their account whatever email they typed.
    if (signedIn) {
      const own = await ShopCustomer.findByPk(signedIn.id, { transaction, lock: transaction.LOCK.UPDATE });
      if (own) {
        const patch: Partial<ShopCustomer> = { phone: data.phone || own.phone, billing: data.billing, shipping: data.shipping };
        if (!own.firstName) patch.firstName = data.firstName;
        if (!own.lastName) patch.lastName = data.lastName;
        await own.update(patch, { transaction });
        return own;
      }
    }
    const email = data.email.trim().toLowerCase();
    const [row] = await ShopCustomer.findOrCreate({
      where: { siteId, email },
      defaults: { siteId, email, firstName: data.firstName, lastName: data.lastName, phone: data.phone, billing: data.billing, shipping: data.shipping },
      transaction,
    });
    // A guest using the email of a registered account must not change that account's saved details.
    if (!row.passwordHash) {
      await row.update(
        { firstName: data.firstName, lastName: data.lastName, phone: data.phone, billing: data.billing, shipping: data.shipping },
        { transaction },
      );
    }
    return row;
  }

  /** Recount orders + spend from non-cancelled orders. */
  async refreshStats(customerId: string, transaction?: Transaction) {
    const rows = await ShopOrder.findAll({
      where: { customerId, status: { [Op.notIn]: ['cancelled', 'failed', 'pending'] } },
      attributes: ['total', 'refundedTotal', 'placedAt'],
      transaction,
    });
    const totalSpent = rows.reduce((a, r) => a + r.total - r.refundedTotal, 0);
    const last = rows.reduce<Date | null>((acc, r) => (!acc || r.placedAt > acc ? r.placedAt : acc), null);
    await ShopCustomer.update(
      { ordersCount: rows.length, totalSpent, lastOrderAt: last },
      { where: { id: customerId }, transaction },
    );
  }

  async list(actor: AuthUser, query: { q?: string; page?: number; perPage?: number }) {
    try {
      const page = query.page ?? 1;
      const perPage = query.perPage ?? 25;
      const where: WhereOptions = { siteId: actor.siteId };
      const q = (query.q ?? '').trim();
      if (q) {
        const like = `%${q.replace(/[%_\\]/g, '\\$&')}%`;
        Object.assign(where, {
          [Op.or]: [{ email: { [Op.iLike]: like } }, { firstName: { [Op.iLike]: like } }, { lastName: { [Op.iLike]: like } }, { phone: { [Op.iLike]: like } }],
        });
      }
      const { rows, count } = await ShopCustomer.findAndCountAll({
        where,
        order: [['lastOrderAt', 'DESC NULLS LAST']],
        limit: perPage,
        offset: (page - 1) * perPage,
      });
      return { items: rows.map(serializeCustomer), total: count, page, perPage, pages: Math.max(1, Math.ceil(count / perPage)) };
    } catch (error) {
      throw toHttpError(error, 'Could not load customers.');
    }
  }

  async get(actor: AuthUser, id: string) {
    try {
      const row = await ShopCustomer.findOne({ where: { id, siteId: actor.siteId } });
      if (!row) throw NotFound('Customer not found.');
      return serializeCustomer(row);
    } catch (error) {
      throw toHttpError(error, 'Could not load the customer.');
    }
  }
}

export const customersService = new CustomersService();
