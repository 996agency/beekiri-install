import type Stripe from 'stripe';
import { config } from '../../config/env';
import type { Destination } from '../../lib/shop/cart-totals';
import { applyCheckoutFields, checkoutFieldsForTemplate } from '../../lib/shop/checkout-fields';
import { COUNTRIES } from '../../lib/shop/countries';
import { addressLines, orderNumberLabel } from '../../lib/shop/emails';
import { formatMoney } from '../../lib/shop/money';
import { paymentProvider } from '../../lib/shop/payments';
import { constructStripeEvent, retrieveStripeSession } from '../../lib/shop/payments/stripe';
import { enabledPaymentMethods, moneyFormatOf, readSecret, type ShopSettings } from '../../lib/shop/settings';
import { ORDER_STATUS_LABELS, SHOP_PATHS, type OrderStatus } from '../../lib/shop/constants';
import { buildTracking } from '../../lib/shop/tracking';
import { Post, sequelize, ShopCart, ShopCustomer, ShopOrder, ShopOrderItem, ShopOrderNote, ShopPaymentEvent } from '../../models';
import { randomToken } from '../../utils/crypto';
import { BadRequest, NotFound, toHttpError, Unauthorized } from '../../utils/http-error';
import { createLogger } from '../../utils/logger';
import type { CheckoutAddress, CheckoutInput } from '../../validators/shop.schema';
import { findPrimarySite } from '../site-context';
import { accountsService } from './accounts.service';
import { cartService, type ResolvedCart } from './cart.service';
import { couponsService } from './coupons.service';
import { customersService } from './customers.service';
import { customFieldRows, ordersService, paymentTitle } from './orders.service';
import { shopSettingsService } from './shop-settings.service';

const log = createLogger('shop-checkout');

function destinationOf(input: CheckoutInput): Destination {
  const a = input.shipToDifferent && input.shipping ? input.shipping : input.billing;
  return { country: a.country, state: a.state, postcode: a.postcode };
}

export class CheckoutService {
  private appUrl() {
    return (config.urls.app ?? '').replace(/\/+$/, '');
  }

  private async siteTitle() {
    return (await findPrimarySite())?.title?.trim() || 'Beekiri';
  }

  /** Everything the checkout page needs to render (public). */
  async page(cart: ShopCart, settings: ShopSettings, destination: Destination | null, customer: ShopCustomer | null = null) {
    const resolved = await cartService.resolve(cart, settings);
    const options = cartService.shippingOptions(resolved, settings, destination);
    const preferred = cartService.estimate(cart, settings).methodId;
    const chosen = options.find((o) => o.id === preferred) ?? options[0] ?? null;
    const totals = cartService.totals(resolved, settings, destination, chosen);
    const money = (v: number) => formatMoney(v, moneyFormatOf(settings));
    const termsPage = settings.checkout.termsPageId ? await Post.findOne({ where: { id: settings.checkout.termsPageId, siteId: cart.siteId, status: 'publish' }, attributes: ['title', 'slug'] }) : null;
    const privacyPage = settings.checkout.privacyPageId ? await Post.findOne({ where: { id: settings.checkout.privacyPageId, siteId: cart.siteId, status: 'publish' }, attributes: ['title', 'slug'] }) : null;
    const storeCountry = settings.general.address.country;
    const allowed = settings.general.sellTo === 'specific' ? new Set(settings.general.sellToCountries) : null;
    return {
      cart: cartService.serialize(resolved, totals, settings),
      shippingOptions: options.map((o) => ({ ...o, formatted: o.cost === 0 ? 'Free' : money(o.cost) })),
      shippingRequired: totals.needsShipping,
      shippingUnavailable: totals.needsShipping && options.length === 0 && destination !== null,
      paymentMethods: enabledPaymentMethods(settings),
      countries: COUNTRIES.filter((c) => !allowed || allowed.has(c.code)),
      defaultCountry: storeCountry || '',
      preferredShippingMethodId: preferred,
      account: {
        enabled: settings.accounts.enabled,
        signedIn: Boolean(customer),
        requireAccount: settings.accounts.enabled && settings.accounts.requireAccount,
        createAtCheckout: settings.accounts.enabled && settings.accounts.allowRegistration && settings.accounts.createAtCheckout && !customer,
        customer: customer ? accountsService.serialize(customer) : null,
      },
      fields: { ...checkoutFieldsForTemplate(settings), termsRequired: settings.checkout.termsRequired && Boolean(termsPage) },
      termsPage: termsPage ? { title: termsPage.title, path: `/${termsPage.slug}` } : null,
      privacyPage: privacyPage ? { title: privacyPage.title, path: `/${privacyPage.slug}` } : null,
    };
  }

  /** Place the order: lock stock, number it, create rows, then hand over to the payment provider. */
  async placeOrder(
    cart: ShopCart,
    input: CheckoutInput,
    meta: { ip?: string; userAgent?: string },
    signedIn: ShopCustomer | null = null,
  ): Promise<{ orderId: string; number: number; numberLabel: string; token: string; redirectUrl: string; session?: { token: string; maxAgeMs: number } }> {
    try {
      const settings = await shopSettingsService.get(cart.siteId);
      await ordersService.sweepExpired(cart.siteId);
      let customerAccount = signedIn;
      let newSession: { token: string; maxAgeMs: number } | undefined;
      if (settings.accounts.enabled && settings.accounts.requireAccount && !customerAccount && !input.createAccount) {
        throw Unauthorized('Please sign in or create an account to place your order.');
      }

      const methods = enabledPaymentMethods(settings);
      if (!methods.some((m) => m.id === input.paymentMethod)) throw BadRequest('That payment method is not available.');
      // "Create an account" at checkout: registered before the order so it is linked to it.
      if (!customerAccount && input.createAccount) {
        if (!input.accountPassword) throw BadRequest('Choose a password for your new account.');
        const created = await accountsService.register(
          cart.siteId,
          { email: input.email, password: input.accountPassword, firstName: input.billing.firstName, lastName: input.billing.lastName, remember: true },
          meta,
        );
        customerAccount = created.customer;
        newSession = { token: created.token, maxAgeMs: created.maxAgeMs };
      }
      const applied = applyCheckoutFields(settings, input);
      if (applied.errors.length) throw BadRequest(applied.errors.join(' '));
      if (settings.checkout.termsRequired && settings.checkout.termsPageId && !input.termsAccepted) {
        throw BadRequest('Please accept the terms and conditions.');
      }
      if (settings.general.sellTo === 'specific') {
        const allowed = new Set(settings.general.sellToCountries);
        const dest = destinationOf(input);
        if (!allowed.has(dest.country) || !allowed.has(input.billing.country)) throw BadRequest('We do not sell to that country.');
      }

      const email = input.email.trim().toLowerCase();
      const resolved: ResolvedCart = await cartService.resolve(cart, settings, { email });
      if (!resolved.lines.length) throw BadRequest('Your cart is empty.');
      if (resolved.couponError) throw BadRequest(resolved.couponError);

      const destination = destinationOf(input);
      const options = cartService.shippingOptions(resolved, settings, destination);
      let shipping = null as (typeof options)[number] | null;
      const needsShipping = resolved.lines.some((l) => !l.virtual) && settings.shipping.enabled;
      if (needsShipping) {
        if (!options.length) throw BadRequest('We cannot ship to that address.');
        shipping = options.find((o) => o.id === input.shippingMethodId) ?? null;
        if (!shipping) throw BadRequest('Choose a shipping method.');
      }
      const totals = cartService.totals(resolved, settings, destination, shipping);
      if (totals.couponError) throw BadRequest(totals.couponError);
      if (totals.total <= 0 && input.paymentMethod === 'stripe') throw BadRequest('Free orders cannot be paid by card; choose another method.');

      const billingAddress = applied.billing as CheckoutAddress;
      const shippingAddress: CheckoutAddress = (applied.shipping as CheckoutAddress | undefined) ?? billingAddress;
      const provider = paymentProvider(input.paymentMethod);
      if (!provider) throw BadRequest('Unknown payment method.');

      const order = await sequelize.transaction(async (t) => {
        // Re-check coupon limits under lock and count the use.
        if (resolved.coupon) {
          const check = await couponsService.resolve(cart.siteId, resolved.coupon.code, email, t);
          if ('error' in check) throw BadRequest(check.error);
        }
        const labels = new Map(resolved.lines.map((l) => [l.commerceId, l.name]));
        await ordersService.reserveStock(
          resolved.lines.map((l) => ({ productId: l.commerceId, variantId: l.variantId, qty: l.qty })),
          t,
          labels,
        );

        const settingsRow = await shopSettingsService.lockRow(cart.siteId, t);
        const number = Math.max(settingsRow.nextOrderNumber, settings.advanced.orderNumberStart);
        await settingsRow.update({ nextOrderNumber: number + 1 }, { transaction: t });

        const customer = await customersService.upsertFromOrder(
          cart.siteId,
          { email, firstName: billingAddress.firstName, lastName: billingAddress.lastName, phone: applied.phone, billing: billingAddress, shipping: shippingAddress },
          t,
          customerAccount,
        );

        const initialStatus: OrderStatus = input.paymentMethod === 'stripe' ? 'pending' : input.paymentMethod === 'bank_transfer' ? 'on-hold' : 'processing';
        const row = await ShopOrder.create(
          {
            siteId: cart.siteId,
            number,
            status: 'pending',
            currency: settings.general.currency,
            subtotal: totals.subtotal,
            discountTotal: totals.discountTotal,
            shippingTotal: totals.shippingTotal,
            taxTotal: totals.taxTotal,
            total: totals.total,
            couponCode: totals.coupon?.code ?? null,
            customerId: customer.id,
            email,
            phone: applied.phone,
            billing: billingAddress,
            shipping: shippingAddress,
            shipToDifferent: input.shipToDifferent && Boolean(applied.shipping),
            shippingMethod: totals.shipping ? { ...totals.shipping } : null,
            paymentMethod: input.paymentMethod,
            paymentStatus: 'unpaid',
            customerNote: applied.customerNote,
            customFields: applied.customFields,
            accessToken: randomToken(32),
            ipAddress: (meta.ip ?? '').slice(0, 64),
            userAgent: (meta.userAgent ?? '').slice(0, 300),
            cartId: cart.id,
            placedAt: new Date(),
          },
          { transaction: t },
        );
        for (const line of totals.lines) {
          await ShopOrderItem.create(
            {
              siteId: cart.siteId,
              orderId: row.id,
              productId: line.commerceId,
              variantId: line.variantId,
              name: line.name,
              sku: line.sku,
              qty: line.qty,
              unitPrice: line.unitPrice,
              subtotal: line.subtotal,
              total: line.total,
              taxTotal: line.taxTotal,
              attributes: line.attributes,
              imageUrl: line.imageUrl,
              virtual: line.virtual,
            },
            { transaction: t },
          );
        }
        await ShopOrderNote.create({ siteId: cart.siteId, orderId: row.id, authorId: null, note: `Order placed via ${paymentTitle(input.paymentMethod, settings)}.`, isCustomerNote: false }, { transaction: t });
        if (initialStatus !== 'pending') {
          // Offline methods: the order is real immediately (stock stays held, sales counted).
          await ordersService.transition(row, initialStatus, t);
          await ordersService.countCouponUse(row, t);
        }
        return row;
      });

      // Hand over to the provider outside the transaction (network call).
      const items = await ShopOrderItem.findAll({ where: { orderId: order.id } });
      let start;
      try {
        start = await provider.start(order, { settings, appUrl: this.appUrl(), siteTitle: await this.siteTitle(), items });
      } catch (error) {
        log.warn(`Payment start failed for order ${order.id}: ${(error as Error).message}`);
        await sequelize.transaction(async (t) => {
          const o = await ShopOrder.findByPk(order.id, { transaction: t, lock: t.LOCK.UPDATE });
          if (o) {
            await ordersService.transition(o, 'failed', t);
            await ShopOrderNote.create({ siteId: o.siteId, orderId: o.id, authorId: null, note: `Payment could not be started: ${(error as Error).message}`, isCustomerNote: false }, { transaction: t });
          }
        });
        throw BadRequest('The payment could not be started. Please try again or choose another payment method.');
      }
      await order.update({ paymentRef: { ...((order.paymentRef as Record<string, unknown>) ?? {}), ...start.ref } });
      await cartService.clear(cart);

      if (start.kind === 'offline') {
        void ordersService.sendEmail(order.paymentMethod === 'bank_transfer' ? 'onHold' : 'orderReceived', order);
        void ordersService.sendEmail('newOrderAdmin', order);
      }
      return {
        orderId: order.id,
        number: order.number,
        numberLabel: orderNumberLabel(order, settings),
        token: order.accessToken,
        redirectUrl: start.kind === 'redirect' ? start.url : `${SHOP_PATHS.orderReceived(order.accessToken)}`,
        session: newSession,
      };
    } catch (error) {
      throw toHttpError(error, 'Could not place the order.');
    }
  }

  /** Public order view by its unguessable token (thank-you page, email link). */
  async orderByToken(siteId: string, token: string) {
    try {
      if (!token || token.length > 200) throw NotFound('Order not found.');
      const order = await ShopOrder.findOne({ where: { siteId, accessToken: token } });
      if (!order) throw NotFound('Order not found.');
      const settings = await shopSettingsService.get(siteId);
      const items = await ShopOrderItem.findAll({ where: { orderId: order.id }, order: [['createdAt', 'ASC']] });
      const fmt = { ...moneyFormatOf(settings), currency: order.currency };
      const money = (v: number) => formatMoney(v, fmt);
      const method = order.shippingMethod as { title?: string } | null;
      const bank = order.paymentMethod === 'bank_transfer' && order.paymentStatus === 'unpaid' ? settings.payments.bankTransfer : null;
      return {
        id: order.id,
        number: order.number,
        numberLabel: orderNumberLabel(order, settings),
        status: order.status,
        statusLabel: ORDER_STATUS_LABELS[order.status as OrderStatus] ?? order.status,
        paymentStatus: order.paymentStatus,
        paymentMethod: order.paymentMethod,
        paymentMethodTitle: paymentTitle(order.paymentMethod, settings),
        paymentInstructions: order.paymentMethod === 'cod' ? settings.payments.cod.instructions : bank?.instructions ?? '',
        bankAccounts: bank?.accounts ?? [],
        email: order.email,
        phone: order.phone,
        placedAt: order.placedAt.toISOString(),
        billing: order.billing,
        shipping: order.shipToDifferent ? order.shipping : null,
        billingLines: addressLines(order.billing as Record<string, string>),
        shippingLines: order.shipToDifferent ? addressLines(order.shipping as Record<string, string>) : [],
        shippingMethodTitle: method?.title ?? '',
        customerNote: order.customerNote,
        customFields: customFieldRows(order),
        couponCode: order.couponCode,
        items: items.map((i) => ({
          name: i.name,
          sku: i.sku,
          qty: i.qty,
          attributes: i.attributes,
          imageUrl: i.imageUrl,
          total: i.total,
          formatted: { unitPrice: money(i.unitPrice), total: money(i.total) },
        })),
        totals: {
          subtotal: money(order.subtotal),
          discountTotal: order.discountTotal ? `-${money(order.discountTotal)}` : '',
          shippingTotal: order.shippingMethod ? money(order.shippingTotal) : '',
          taxTotal: order.taxTotal ? money(order.taxTotal) : '',
          taxIncluded: settings.tax.enabled && settings.tax.pricesIncludeTax,
          total: money(order.total),
          refundedTotal: order.refundedTotal ? money(order.refundedTotal) : '',
        },
        thankYouMessage: settings.checkout.thankYouMessage,
        path: SHOP_PATHS.orderReceived(order.accessToken),
        tracking: buildTracking(order, { virtual: items.length > 0 && items.every((i) => i.virtual) }),
        shippingMethodTitleLine: method?.title ?? '',
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load the order.');
    }
  }

  /**
   * Called by the thank-you page right after Stripe redirects back. Looks the session
   * up server-side so a shopper sees "paid" even if the webhook has not arrived yet.
   */
  async confirm(siteId: string, token: string, sessionId?: string) {
    try {
      const order = await ShopOrder.findOne({ where: { siteId, accessToken: token } });
      if (!order) throw NotFound('Order not found.');
      if (order.paymentMethod !== 'stripe' || order.paymentStatus !== 'unpaid') return { paid: order.paymentStatus !== 'unpaid', status: order.status };
      const settings = await shopSettingsService.get(siteId);
      const ref = (order.paymentRef ?? {}) as { sessionId?: string };
      const sid = ref.sessionId || sessionId;
      if (!sid || (sessionId && ref.sessionId && sessionId !== ref.sessionId)) return { paid: false, status: order.status };
      const session = await retrieveStripeSession(settings, sid);
      if (session.orderId && session.orderId !== order.id) return { paid: false, status: order.status };
      if (session.paymentStatus === 'paid' && this.amountMatches(order, session.amountTotal, session.currency)) {
        await this.settlePaid(order.id, { transactionId: session.paymentIntentId ?? session.id, paymentRef: { sessionId: session.id, paymentIntentId: session.paymentIntentId } });
      }
      const fresh = await ShopOrder.findByPk(order.id);
      return { paid: fresh?.paymentStatus === 'paid', status: fresh?.status ?? order.status };
    } catch (error) {
      throw toHttpError(error, 'Could not confirm the payment.');
    }
  }

  private amountMatches(order: ShopOrder, amount: number | null, currency: string | null) {
    if (amount === null || currency === null) return false;
    if (currency.toLowerCase() !== order.currency.toLowerCase()) {
      log.warn(`Stripe currency mismatch for order ${order.id}: ${currency} vs ${order.currency}`);
      return false;
    }
    if (amount !== order.total) {
      log.warn(`Stripe amount mismatch for order ${order.id}: ${amount} vs ${order.total}`);
      return false;
    }
    return true;
  }

  /** Mark paid + count the coupon + emails (idempotent). */
  private async settlePaid(orderId: string, ref: { transactionId?: string; paymentRef?: Record<string, unknown> }) {
    const before = await ShopOrder.findByPk(orderId);
    if (!before || before.paymentStatus === 'paid') return;
    await sequelize.transaction(async (t) => {
      const order = await ordersService.markPaid(orderId, ref, t);
      if (order) await ordersService.countCouponUse(order, t);
    });
    const after = await ShopOrder.findByPk(orderId);
    if (after && before.paymentStatus === 'unpaid' && after.paymentStatus === 'paid') {
      void ordersService.sendEmail(after.status === 'completed' ? 'completed' : 'processing', after);
      void ordersService.sendEmail('newOrderAdmin', after);
    }
  }

  /** Stripe webhook: verify, dedupe, apply. */
  async handleStripeWebhook(siteId: string, rawBody: Buffer, signature: string) {
    const settings = await shopSettingsService.get(siteId);
    if (!readSecret(settings, 'payments.stripe.webhookSecret')) throw BadRequest('Stripe webhooks are not configured.');
    let event: Stripe.Event;
    try {
      event = constructStripeEvent(settings, rawBody, signature);
    } catch (error) {
      throw BadRequest(`Invalid Stripe signature: ${(error as Error).message}`);
    }

    const [, created] = await ShopPaymentEvent.findOrCreate({
      where: { provider: 'stripe', eventId: event.id },
      defaults: { siteId, provider: 'stripe', eventId: event.id, type: event.type, orderId: null, payload: { type: event.type, livemode: event.livemode } },
    });
    if (!created) return { received: true, duplicate: true };

    const object = event.data.object as unknown as Record<string, unknown>;
    const sessionOrderId = (object.metadata as { orderId?: string } | undefined)?.orderId ?? (object.client_reference_id as string | undefined) ?? null;

    switch (event.type) {
      case 'checkout.session.completed':
      case 'checkout.session.async_payment_succeeded': {
        const session = event.data.object as Stripe.Checkout.Session;
        if (!sessionOrderId) break;
        const order = await ShopOrder.findOne({ where: { id: sessionOrderId, siteId } });
        if (!order) break;
        await ShopPaymentEvent.update({ orderId: order.id }, { where: { provider: 'stripe', eventId: event.id } });
        if (session.payment_status === 'paid' && this.amountMatches(order, session.amount_total ?? null, session.currency ?? null)) {
          const pi = typeof session.payment_intent === 'string' ? session.payment_intent : session.payment_intent?.id ?? null;
          await this.settlePaid(order.id, { transactionId: pi ?? session.id, paymentRef: { sessionId: session.id, paymentIntentId: pi } });
        }
        break;
      }
      case 'checkout.session.async_payment_failed': {
        if (!sessionOrderId) break;
        await sequelize.transaction(async (t) => {
          const o = await ShopOrder.findOne({ where: { id: sessionOrderId, siteId }, transaction: t, lock: t.LOCK.UPDATE });
          if (o && o.paymentStatus === 'unpaid') await ordersService.transition(o, 'failed', t);
        });
        break;
      }
      case 'checkout.session.expired': {
        if (!sessionOrderId) break;
        await sequelize.transaction(async (t) => {
          const o = await ShopOrder.findOne({ where: { id: sessionOrderId, siteId }, transaction: t, lock: t.LOCK.UPDATE });
          if (o && o.status === 'pending' && o.paymentStatus === 'unpaid') {
            await ordersService.transition(o, 'cancelled', t);
            await ShopOrderNote.create({ siteId, orderId: o.id, authorId: null, note: 'Stripe checkout session expired.', isCustomerNote: false }, { transaction: t });
          }
        });
        break;
      }
      case 'charge.refunded': {
        const charge = event.data.object as Stripe.Charge;
        const pi = typeof charge.payment_intent === 'string' ? charge.payment_intent : charge.payment_intent?.id;
        if (!pi) break;
        const order = await ShopOrder.findOne({
          where: { siteId, paymentMethod: 'stripe', 'paymentRef.paymentIntentId': pi } as never,
        });
        if (!order) break;
        const refunded = charge.amount_refunded ?? 0;
        if (refunded > order.refundedTotal) {
          const full = refunded >= order.total;
          await sequelize.transaction(async (t) => {
            const o = await ShopOrder.findByPk(order.id, { transaction: t, lock: t.LOCK.UPDATE });
            if (!o) return;
            await o.update({ refundedTotal: refunded, paymentStatus: full ? 'refunded' : 'partially_refunded' }, { transaction: t });
            await ShopOrderNote.create({ siteId, orderId: o.id, authorId: null, note: `Stripe reported a refund (${refunded} minor units total).`, isCustomerNote: false }, { transaction: t });
            if (full && o.status !== 'refunded') await ordersService.transition(o, 'refunded', t);
          });
        }
        break;
      }
      default:
        break;
    }
    return { received: true, duplicate: false };
  }
}

export const checkoutService = new CheckoutService();
