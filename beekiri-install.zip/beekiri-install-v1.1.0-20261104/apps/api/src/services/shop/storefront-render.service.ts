import { spawn } from 'child_process';
import { existsSync, readFileSync, statSync, writeFileSync } from 'fs';
import { dirname, join } from 'path';
import { compile as compileSass } from 'sass';
import { config } from '../../config/env';
import { resolveLayoutRunnerPath } from '../../lib/layouts/php/runner-path';
import { minifyJs } from '../../lib/minify-assets';
import { ACCOUNT_PATH, CART_COOKIE, SHOP_PATHS } from '../../lib/shop/constants';
import { COUNTRIES } from '../../lib/shop/countries';
import type { ShopCustomer } from '../../models';
import { accountsService } from './accounts.service';
import { minorToDecimal } from '../../lib/shop/money';
import { enabledPaymentMethods, type ShopSettings } from '../../lib/shop/settings';
import { resolveThemePath, themeAncestry, resolveThemesRoot } from '../../lib/themes/theme-registry';
import { NotFound, toHttpError } from '../../utils/http-error';
import { createLogger } from '../../utils/logger';
import type { ViewInput } from '../../validators/shop.schema';
import { findPrimarySite } from '../site-context';
import { themesService } from '../themes.service';
import { cartService } from './cart.service';
import { catalogService, type PublicProduct } from './catalog.service';
import { checkoutService } from './checkout.service';
import { shopSettingsService } from './shop-settings.service';

const log = createLogger('shop-storefront');

export const SHOP_VIEWS = ['shop', 'category', 'product', 'cart', 'checkout', 'order-received', 'account'] as const;

const ACCOUNT_SECTIONS = ['dashboard', 'orders', 'order', 'details', 'addresses', 'login', 'register', 'forgot', 'reset', 'verify'] as const;
type AccountSection = (typeof ACCOUNT_SECTIONS)[number];
const PUBLIC_SECTIONS: readonly AccountSection[] = ['login', 'register', 'forgot', 'reset', 'verify'];
export type ShopView = (typeof SHOP_VIEWS)[number];

const SORTS = [
  { id: 'menu_order', label: 'Default sorting' },
  { id: 'popularity', label: 'Sort by popularity' },
  { id: 'newest', label: 'Sort by latest' },
  { id: 'price', label: 'Sort by price: low to high' },
  { id: 'price-desc', label: 'Sort by price: high to low' },
  { id: 'title', label: 'Sort by name' },
];

export type RenderedView = {
  view: ShopView;
  html: string;
  title: string;
  description: string;
  image: string;
  noindex: boolean;
  path: string;
  status: number;
  cssUrl: string;
  jsUrl: string;
  /** Product pages: data for JSON-LD on the website. */
  structured?: {
    name: string;
    sku: string;
    description: string;
    image: string;
    currency: string;
    price: number | null;
    priceDecimal: string;
    inStock: boolean;
  } | null;
};

type Ctx = { siteId: string; settings: ShopSettings; cartToken?: string; query: ViewInput; customer: ShopCustomer | null };

/**
 * Renders the storefront pages with the active theme's `shop/*.php` templates
 * (child theme first, then Beekiri). Data is built here; templates only print it.
 */
export class StorefrontRenderService {
  private async theme(): Promise<string> {
    return themesService.getActiveSlug().catch(() => 'beekiri-child');
  }

  /** Absolute path of `shop/{rel}` in the first theme that has it. */
  async resolve(rel: string): Promise<string | null> {
    return resolveThemePath(await this.theme(), `shop/${rel}`);
  }

  /** Theme shop folders, child first (for partial lookups inside PHP). */
  private async shopDirs(): Promise<string[]> {
    const root = resolveThemesRoot();
    return themeAncestry(await this.theme())
      .map((slug) => join(root, slug, 'shop'))
      .filter((dir) => existsSync(dir));
  }

  private assetVersion(file: string): string {
    try {
      return String(Math.floor(statSync(file).mtimeMs));
    } catch {
      return '0';
    }
  }

  async assetUrls(): Promise<{ cssUrl: string; jsUrl: string }> {
    const scss = (await this.resolve('styles.scss')) ?? (await this.resolve('styles.css'));
    const js = await this.resolve('script.js');
    return {
      cssUrl: `/api/shop/public/assets/styles.css?v=${scss ? this.assetVersion(scss) : '0'}`,
      jsUrl: `/api/shop/public/assets/script.js?v=${js ? this.assetVersion(js) : '0'}`,
    };
  }

  /** styles.css (compiled from styles.scss when newer) or script.js (minified). */
  async readAsset(file: 'styles.css' | 'script.js'): Promise<{ body: string; contentType: string }> {
    try {
      if (file === 'script.js') {
        const js = await this.resolve('script.js');
        if (!js) throw NotFound('Asset not found');
        return { body: minifyJs(readFileSync(js, 'utf8')), contentType: 'application/javascript; charset=utf-8' };
      }
      const scss = await this.resolve('styles.scss');
      if (scss) {
        const dir = dirname(scss);
        const css = join(dir, 'styles.css');
        const min = join(dir, 'styles.min.css');
        const stale = !existsSync(min) || statSync(scss).mtimeMs > statSync(min).mtimeMs;
        if (stale) {
          try {
            const expanded = compileSass(scss, { style: 'expanded', charset: false });
            writeFileSync(css, `/* Compiled from styles.scss — do not edit */\n${expanded.css}`, 'utf8');
            const compressed = compileSass(scss, { style: 'compressed', charset: false });
            writeFileSync(min, compressed.css, 'utf8');
          } catch (error) {
            log.warn(`Shop SCSS compile failed: ${(error as Error).message}`);
          }
        }
        const target = existsSync(min) ? min : css;
        if (existsSync(target)) return { body: readFileSync(target, 'utf8'), contentType: 'text/css; charset=utf-8' };
      }
      const css = await this.resolve('styles.css');
      if (!css) throw NotFound('Asset not found');
      return { body: readFileSync(css, 'utf8'), contentType: 'text/css; charset=utf-8' };
    } catch (error) {
      throw toHttpError(error, 'Could not read the shop asset.');
    }
  }

  private async runPhp(template: string, data: Record<string, unknown>, slug: string): Promise<string | null> {
    const runner = resolveLayoutRunnerPath();
    if (!runner) {
      log.warn('layout-runner.php not found — cannot render shop templates.');
      return null;
    }
    const prelude = (await this.resolve('_helpers.php')) ?? '';
    return new Promise((resolve) => {
      const child = spawn('php', [runner, template, '--stdin', slug, prelude], { env: process.env });
      const out: Buffer[] = [];
      const err: Buffer[] = [];
      const timer = setTimeout(() => child.kill('SIGKILL'), 10_000);
      child.stdout.on('data', (b: Buffer) => out.push(b));
      child.stderr.on('data', (b: Buffer) => err.push(b));
      child.on('error', (e) => {
        clearTimeout(timer);
        log.warn(`PHP failed to start: ${e.message}`);
        resolve(null);
      });
      child.on('close', (code) => {
        clearTimeout(timer);
        if (code !== 0) {
          log.warn(`Shop template ${slug} exited ${code}: ${Buffer.concat(err).toString('utf8').slice(0, 500)}`);
          resolve(null);
          return;
        }
        resolve(Buffer.concat(out).toString('utf8'));
      });
      child.stdin.on('error', () => undefined);
      child.stdin.end(JSON.stringify(data));
    });
  }

  private fallback(view: ShopView): string {
    return `<section class="bk-shop__fallback"><p>The shop template "${view}" could not be rendered. Check that PHP is installed and that <code>themes/beekiri/shop/${view}.php</code> exists.</p></section>`;
  }

  private async common(ctx: Ctx, view: ShopView) {
    const site = await findPrimarySite();
    const dirs = await this.shopDirs();
    return {
      view,
      site: { title: site?.title?.trim() || 'Beekiri', tagline: site?.tagline ?? '', url: (config.urls.app ?? '').replace(/\/+$/, '') },
      shop: {
        title: ctx.settings.products.shopTitle,
        description: ctx.settings.products.shopDescription,
        path: SHOP_PATHS.shop,
        cart_path: SHOP_PATHS.cart,
        checkout_path: SHOP_PATHS.checkout,
        currency: ctx.settings.general.currency,
        show_sku: ctx.settings.products.showSku,
        show_categories: ctx.settings.products.showCategories,
        prices_include_tax: ctx.settings.tax.enabled && ctx.settings.tax.pricesIncludeTax,
        /** Shop → Shop Editor display options for this page. */
        options: view === 'account' ? {} : (ctx.settings.pages[view === 'category' ? 'shop' : view === 'order-received' ? 'checkout' : view] ?? {}),
        account_path: ACCOUNT_PATH,
        accounts_enabled: ctx.settings.accounts.enabled,
      },
      /** Signed-in shopper (null for guests). */
      account: ctx.customer ? { name: ctx.customer.firstName || ctx.customer.email, email: ctx.customer.email, verified: Boolean(ctx.customer.emailVerifiedAt) } : null,
      __shop_dirs: dirs,
    };
  }

  private async cart(ctx: Ctx) {
    const cart = await cartService.find(ctx.siteId, ctx.cartToken);
    if (!cart) return null;
    return cart;
  }

  async render(view: ShopView, query: ViewInput, cartToken?: string, customer: ShopCustomer | null = null): Promise<RenderedView> {
    try {
      const site = await findPrimarySite();
      if (!site) throw NotFound('Site not found.');
      const settings = await shopSettingsService.get(site.id);
      const ctx: Ctx = { siteId: site.id, settings, cartToken, query, customer };
      const assets = await this.assetUrls();
      const base = { ...(await this.common(ctx, view)) };
      let data: Record<string, unknown> = base;
      let title = settings.products.shopTitle;
      let description = settings.products.shopDescription;
      let image = '';
      let noindex = false;
      let path: string = SHOP_PATHS.shop;
      let status = 200;
      let structured: RenderedView['structured'] = null;

      switch (view) {
        case 'shop':
        case 'category': {
          const list = await catalogService.list(site.id, { ...query, category: view === 'category' ? query.slug : query.category }, settings);
          const categories = settings.products.showCategories ? await catalogService.categories(site.id) : [];
          const basePath = list.category ? list.category.path : SHOP_PATHS.shop;
          const qs = (page: number) => {
            const params = new URLSearchParams();
            if (list.query) params.set('q', list.query);
            if (query.sort) params.set('sort', query.sort);
            if (page > 1) params.set('page', String(page));
            const str = params.toString();
            return str ? `${basePath}?${str}` : basePath;
          };
          data = {
            ...base,
            products: list.items,
            categories,
            category: list.category,
            query: list.query,
            sort: list.sort,
            sorts: SORTS,
            pagination: {
              page: list.page,
              pages: list.pages,
              total: list.total,
              per_page: list.perPage,
              prev_url: list.page > 1 ? qs(list.page - 1) : '',
              next_url: list.page < list.pages ? qs(list.page + 1) : '',
              links: Array.from({ length: list.pages }, (_, i) => ({ page: i + 1, url: qs(i + 1), current: i + 1 === list.page })),
            },
            base_path: basePath,
          };
          title = list.category ? list.category.name : settings.products.shopTitle;
          description = list.category?.description || settings.products.shopDescription;
          path = basePath;
          break;
        }
        case 'product': {
          const result = await catalogService.bySlug(site.id, query.slug ?? '', settings);
          const p = result.product;
          data = {
            ...base,
            product: p,
            related: result.related,
            breadcrumbs: [
              { label: settings.products.shopTitle, url: SHOP_PATHS.shop },
              ...p.categories.slice(0, 1).map((c) => ({ label: c.name, url: c.path })),
              { label: p.title, url: p.path },
            ],
            variants_json: JSON.stringify(p.variants),
          };
          const seo = (p.seo ?? {}) as { metaTitle?: string; metaDescription?: string; robotsIndex?: boolean };
          title = seo.metaTitle?.trim() || p.title;
          description = seo.metaDescription?.trim() || p.shortDescription || stripHtml(p.description).slice(0, 160);
          image = p.image?.url ?? '';
          noindex = seo.robotsIndex === false;
          path = p.path;
          structured = {
            name: p.title,
            sku: p.sku,
            description,
            image,
            currency: settings.general.currency,
            price: p.price?.min ?? null,
            priceDecimal: p.price ? minorToDecimal(p.price.min, settings.general.currency) : '',
            inStock: p.inStock,
          };
          break;
        }
        case 'cart': {
          const cart = await this.cart(ctx);
          const view = cart ? await cartService.view(cart, settings) : emptyCartView(settings);
          const allowed = settings.general.sellTo === 'specific' ? new Set(settings.general.sellToCountries) : null;
          data = { ...base, cart: view, countries: COUNTRIES.filter((c) => !allowed || allowed.has(c.code)) };
          title = 'Cart';
          noindex = true;
          path = SHOP_PATHS.cart;
          break;
        }
        case 'checkout': {
          const cart = await this.cart(ctx);
          const page = cart ? await checkoutService.page(cart, settings, null, ctx.customer) : null;
          data = {
            ...base,
            checkout: page,
            cart: page?.cart ?? emptyCartView(settings),
            payment_methods: page?.paymentMethods ?? enabledPaymentMethods(settings),
            cancelled: query.cancelled === '1',
          };
          title = 'Checkout';
          noindex = true;
          path = SHOP_PATHS.checkout;
          break;
        }
        case 'account': {
          if (!settings.accounts.enabled) throw NotFound('Customer accounts are turned off.');
          let section = (ACCOUNT_SECTIONS as readonly string[]).includes(query.section ?? '') ? (query.section as AccountSection) : 'dashboard';
          if (!ctx.customer && !PUBLIC_SECTIONS.includes(section)) section = 'login';
          if (ctx.customer && (section === 'login' || section === 'register')) section = 'dashboard';
          if (section === 'register' && !settings.accounts.allowRegistration) section = 'login';
          const me = ctx.customer ? accountsService.serialize(ctx.customer) : null;
          const accountData: Record<string, unknown> = {
            section,
            customer: me,
            allow_registration: settings.accounts.allowRegistration,
            token: query.token ?? '',
            nav: [
              { id: 'dashboard', label: 'Dashboard', url: ACCOUNT_PATH },
              { id: 'orders', label: 'Orders', url: `${ACCOUNT_PATH}/orders` },
              { id: 'addresses', label: 'Addresses', url: `${ACCOUNT_PATH}/addresses` },
              { id: 'details', label: 'Account details', url: `${ACCOUNT_PATH}/details` },
            ],
          };
          if (ctx.customer && (section === 'dashboard' || section === 'orders')) {
            const list = await accountsService.orders(ctx.customer, section === 'orders' ? (query.page ?? 1) : 1, section === 'orders' ? 10 : 3);
            accountData.orders = list;
            if (section === 'orders' && list.pages > 1) {
              accountData.pagination = {
                page: list.page,
                pages: list.pages,
                total: list.total,
                prev_url: list.page > 1 ? `${ACCOUNT_PATH}/orders?page=${list.page - 1}` : '',
                next_url: list.page < list.pages ? `${ACCOUNT_PATH}/orders?page=${list.page + 1}` : '',
                links: Array.from({ length: list.pages }, (_, i) => ({ page: i + 1, url: `${ACCOUNT_PATH}/orders?page=${i + 1}`, current: i + 1 === list.page })),
              };
            }
          }
          if (ctx.customer && section === 'order') {
            const order = await accountsService.order(ctx.customer, query.number ?? 0);
            accountData.order = await checkoutService.orderByToken(site.id, order.accessToken);
          }
          if (section === 'addresses') accountData.countries = COUNTRIES;
          data = { ...base, account_page: accountData };
          title = section === 'login' ? 'Sign in' : section === 'register' ? 'Create an account' : section === 'order' ? `Order #${query.number ?? ''}` : 'My account';
          noindex = true;
          path = ACCOUNT_PATH;
          break;
        }
        case 'order-received': {
          const token = query.token ?? '';
          const order = await checkoutService.orderByToken(site.id, token);
          data = {
            ...base,
            order,
            confirm_token: order.paymentMethod === 'stripe' && order.paymentStatus === 'unpaid' ? token : '',
            session_id: query.session_id ?? '',
          };
          title = `Order ${order.numberLabel}`;
          noindex = true;
          path = order.path;
          break;
        }
      }

      const template = await this.resolve(`${view}.php`);
      let html = template ? await this.runPhp(template, data, view) : null;
      if (html === null || !html.trim()) {
        html = this.fallback(view);
        status = template ? 500 : 404;
      }
      return { view, html, title, description, image, noindex, path, status, structured, ...assets };
    } catch (error) {
      throw toHttpError(error, 'Could not render the shop page.');
    }
  }
}

function stripHtml(html: string): string {
  return html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function emptyCartView(settings: ShopSettings) {
  return {
    token: null,
    items: [] as unknown[],
    itemCount: 0,
    currency: settings.general.currency,
    subtotal: 0,
    discountTotal: 0,
    shippingTotal: 0,
    taxTotal: 0,
    total: 0,
    needsShipping: false,
    pricesIncludeTax: settings.tax.enabled && settings.tax.pricesIncludeTax,
    shipping: null,
    coupon: null,
    couponError: null,
    formatted: { subtotal: '', discountTotal: '', shippingTotal: '', taxTotal: '', total: '' },
    messages: [] as string[],
  };
}

export { CART_COOKIE };
export type { PublicProduct };
export const storefrontRenderService = new StorefrontRenderService();
