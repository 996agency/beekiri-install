import { Op } from 'sequelize';
import { ORDER_STATUS_LABELS, ORDER_STATUSES } from '../../lib/shop/constants';
import { formatMoney } from '../../lib/shop/money';
import { moneyFormatOf } from '../../lib/shop/settings';
import { ShopCustomer, ShopOrder, ShopOrderItem, ShopProduct, ShopProductVariant } from '../../models';
import type { AuthUser } from '../../types/auth';
import { toHttpError } from '../../utils/http-error';
import { shopSettingsService } from './shop-settings.service';

export type ReportRange = 'today' | '7d' | '30d' | '90d' | 'year';

/** Orders that count as sales. */
const SOLD: readonly string[] = ['processing', 'completed'];

function rangeStart(range: ReportRange): Date {
  const now = new Date();
  const d = new Date(now);
  d.setHours(0, 0, 0, 0);
  switch (range) {
    case 'today':
      return d;
    case '7d':
      d.setDate(d.getDate() - 6);
      return d;
    case '30d':
      d.setDate(d.getDate() - 29);
      return d;
    case '90d':
      d.setDate(d.getDate() - 89);
      return d;
    case 'year':
      d.setFullYear(d.getFullYear() - 1);
      return d;
  }
}

export class ReportsService {
  async overview(actor: AuthUser, range: ReportRange = '30d') {
    try {
      const siteId = actor.siteId;
      const settings = await shopSettingsService.get(siteId);
      const money = (v: number) => formatMoney(v, moneyFormatOf(settings));
      const since = rangeStart(range);
      const orders = await ShopOrder.findAll({
        where: { siteId, placedAt: { [Op.gte]: since }, status: { [Op.in]: SOLD as string[] } },
        attributes: ['id', 'total', 'refundedTotal', 'placedAt', 'status'],
      });
      const revenue = orders.reduce((a, o) => a + o.total - o.refundedTotal, 0);
      const count = orders.length;

      // Daily series (local days).
      const days = new Map<string, { revenue: number; orders: number }>();
      const cursor = new Date(since);
      const today = new Date();
      while (cursor <= today) {
        days.set(cursor.toISOString().slice(0, 10), { revenue: 0, orders: 0 });
        cursor.setDate(cursor.getDate() + 1);
      }
      for (const o of orders) {
        const key = new Date(o.placedAt).toISOString().slice(0, 10);
        const bucket = days.get(key) ?? { revenue: 0, orders: 0 };
        bucket.revenue += o.total - o.refundedTotal;
        bucket.orders += 1;
        days.set(key, bucket);
      }

      const items = orders.length
        ? await ShopOrderItem.findAll({ where: { orderId: { [Op.in]: orders.map((o) => o.id) } }, attributes: ['productId', 'name', 'qty', 'total'] })
        : [];
      const byProduct = new Map<string, { productId: string | null; name: string; qty: number; revenue: number }>();
      for (const i of items) {
        const key = i.productId ?? `name:${i.name}`;
        const cur = byProduct.get(key) ?? { productId: i.productId ?? null, name: i.name, qty: 0, revenue: 0 };
        cur.qty += i.qty;
        cur.revenue += i.total;
        byProduct.set(key, cur);
      }
      const topProducts = [...byProduct.values()].sort((a, b) => b.revenue - a.revenue).slice(0, 5);
      const postIds = topProducts.map((p) => p.productId).filter((v): v is string => Boolean(v));
      const commerce = postIds.length ? await ShopProduct.findAll({ where: { id: { [Op.in]: postIds } }, attributes: ['id', 'postId'] }) : [];
      const postIdOf = new Map(commerce.map((c) => [c.id, c.postId]));

      const statusRows = await ShopOrder.findAll({ where: { siteId }, attributes: ['status'] });
      const statusCounts = Object.fromEntries(ORDER_STATUSES.map((s) => [s, 0])) as Record<string, number>;
      for (const r of statusRows) statusCounts[r.status] = (statusCounts[r.status] ?? 0) + 1;

      const [customers, lowStockProducts, lowStockVariants, outOfStock] = await Promise.all([
        ShopCustomer.count({ where: { siteId, createdAt: { [Op.gte]: since } } }),
        ShopProduct.count({ where: { siteId, manageStock: true, stockQty: { [Op.lte]: settings.products.lowStockThreshold, [Op.gt]: 0 } } }),
        ShopProductVariant.count({ where: { siteId, manageStock: true, stockQty: { [Op.lte]: settings.products.lowStockThreshold, [Op.gt]: 0 } } }),
        ShopProduct.count({ where: { siteId, stockStatus: 'outofstock' } }),
      ]);

      const recent = await ShopOrder.findAll({ where: { siteId }, order: [['placedAt', 'DESC']], limit: 8 });

      return {
        range,
        currency: settings.general.currency,
        totals: {
          revenue,
          revenueFormatted: money(revenue),
          orders: count,
          averageOrder: count ? Math.round(revenue / count) : 0,
          averageOrderFormatted: money(count ? Math.round(revenue / count) : 0),
          itemsSold: items.reduce((a, i) => a + i.qty, 0),
          newCustomers: customers,
        },
        series: [...days.entries()].map(([date, v]) => ({ date, revenue: v.revenue, orders: v.orders })),
        topProducts: topProducts.map((p) => ({ ...p, postId: p.productId ? (postIdOf.get(p.productId) ?? null) : null, revenueFormatted: money(p.revenue) })),
        statusCounts: ORDER_STATUSES.map((s) => ({ id: s, label: ORDER_STATUS_LABELS[s], count: statusCounts[s] ?? 0 })),
        stock: { lowStock: lowStockProducts + lowStockVariants, outOfStock, threshold: settings.products.lowStockThreshold },
        recentOrders: recent.map((o) => {
          const b = (o.billing ?? {}) as Record<string, string>;
          return {
            id: o.id,
            number: o.number,
            numberLabel: `${settings.advanced.orderNumberPrefix}${o.number}`,
            status: o.status,
            statusLabel: ORDER_STATUS_LABELS[o.status as keyof typeof ORDER_STATUS_LABELS] ?? o.status,
            customerName: [b.firstName, b.lastName].filter(Boolean).join(' ') || o.email,
            total: o.total,
            totalFormatted: money(o.total),
            placedAt: o.placedAt.toISOString(),
          };
        }),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load the shop overview.');
    }
  }
}

export const reportsService = new ReportsService();
