import { randomBytes } from 'crypto';
import {
  availableShippingMethods,
  computeTotals,
  type CartLine,
  type CartTotals,
  type CouponRule,
  type Destination,
  type ShippingChoice,
} from '../../lib/shop/cart-totals';
import { formatMoney } from '../../lib/shop/money';
import { availableQty, effectivePrice } from '../../lib/shop/pricing';
import { moneyFormatOf, type ShopSettings } from '../../lib/shop/settings';
import { ShopCart } from '../../models';
import { BadRequest, NotFound, toHttpError } from '../../utils/http-error';
import { catalogService } from './catalog.service';
import { couponsService } from './coupons.service';
import { shopSettingsService } from './shop-settings.service';

export type CartItemRef = { productId: string; variantId: string | null; qty: number };

export const lineKey = (productId: string, variantId: string | null) => `${productId}:${variantId ?? ''}`;

function parseItems(raw: unknown): CartItemRef[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((i): i is Record<string, unknown> => Boolean(i) && typeof i === 'object')
    .map((i) => ({
      productId: String(i.productId ?? ''),
      variantId: i.variantId ? String(i.variantId) : null,
      qty: Math.max(0, Math.min(999, Math.trunc(Number(i.qty) || 0))),
    }))
    .filter((i) => i.productId && i.qty > 0);
}

export type ResolvedCart = {
  cart: ShopCart;
  lines: CartLine[];
  /** Per-line purchase limits (Infinity when not tracked). */
  maxQty: Map<string, number>;
  messages: string[];
  coupon: CouponRule | null;
  couponError: string | null;
  changed: boolean;
};

export class CartService {
  newToken() {
    return randomBytes(24).toString('base64url');
  }

  async expiryDate(settings: ShopSettings) {
    return new Date(Date.now() + settings.advanced.cartExpiryDays * 24 * 60 * 60 * 1000);
  }

  /** The cart behind a cookie token (null when missing / expired / foreign). */
  async find(siteId: string, token: string | undefined): Promise<ShopCart | null> {
    if (!token || token.length > 64 || !/^[A-Za-z0-9_-]+$/.test(token)) return null;
    const cart = await ShopCart.findOne({ where: { id: token, siteId } });
    if (!cart) return null;
    if (cart.expiresAt.getTime() < Date.now()) {
      await cart.destroy();
      return null;
    }
    return cart;
  }

  async getOrCreate(siteId: string, token: string | undefined, settings: ShopSettings): Promise<{ cart: ShopCart; created: boolean }> {
    const existing = await this.find(siteId, token);
    if (existing) return { cart: existing, created: false };
    const cart = await ShopCart.create({ id: this.newToken(), siteId, items: [], expiresAt: await this.expiryDate(settings) });
    return { cart, created: true };
  }

  /**
   * Turn stored refs into priced lines using live product data. Items that are no
   * longer purchasable are dropped and quantities capped; the cart is saved if it changed.
   */
  async resolve(cart: ShopCart, settings: ShopSettings, opts: { email?: string | null } = {}): Promise<ResolvedCart> {
    const refs = parseItems(cart.items);
    const products = await catalogService.purchasable(cart.siteId, [...new Set(refs.map((r) => r.productId))]);
    const byId = new Map(products.map((p) => [p.post.id, p]));
    const lines: CartLine[] = [];
    const maxQty = new Map<string, number>();
    const messages: string[] = [];
    const kept: CartItemRef[] = [];

    for (const ref of refs) {
      const p = byId.get(ref.productId);
      if (!p) {
        messages.push('An item that is no longer available was removed from your cart.');
        continue;
      }
      const name = p.post.title;
      const isVariable = p.commerce.type === 'variable';
      const variant = ref.variantId ? (p.commerce.variants ?? []).find((v) => v.id === ref.variantId && v.enabled) : null;
      if (isVariable && !variant) {
        messages.push(`${name}: the selected option is no longer available and was removed.`);
        continue;
      }
      if (p.commerce.catalogVisibility === 'hidden' && !variant && p.commerce.type === 'simple') {
        // hidden products stay purchasable by direct link; nothing to do
      }
      const priced = variant ?? p.commerce;
      const price = effectivePrice(priced);
      if (price.price === null) {
        messages.push(`${name} cannot be purchased right now and was removed.`);
        continue;
      }
      const stockRow = variant?.manageStock ? variant : p.commerce.manageStock ? p.commerce : variant ?? p.commerce;
      const available = availableQty(stockRow);
      let qty = ref.qty;
      if (available <= 0) {
        messages.push(`${name} is out of stock and was removed from your cart.`);
        continue;
      }
      if (p.commerce.soldIndividually && qty > 1) {
        qty = 1;
        messages.push(`${name} can only be bought once per order.`);
      }
      if (qty > available) {
        qty = available;
        messages.push(`Only ${available} of ${name} are available; the quantity was adjusted.`);
      }
      const key = lineKey(ref.productId, variant?.id ?? null);
      const imageId = variant?.imageId ?? p.post.featuredImageId ?? null;
      lines.push({
        key,
        productId: ref.productId,
        commerceId: p.commerce.id,
        variantId: variant?.id ?? null,
        name,
        sku: variant?.sku || p.commerce.sku,
        qty,
        unitPrice: price.price,
        regularPrice: price.regular,
        taxable: p.commerce.taxable,
        virtual: p.commerce.virtual,
        weight: variant?.weight ?? p.commerce.weight ?? null,
        imageUrl: imageId ? (p.media.get(imageId)?.url ?? '') : '',
        attributes: (variant?.attributes ?? {}) as Record<string, string>,
        categoryIds: p.categories.map((c) => c.id),
        path: `/product/${p.post.slug}`,
      });
      maxQty.set(key, p.commerce.soldIndividually ? 1 : available);
      kept.push({ productId: ref.productId, variantId: variant?.id ?? null, qty });
    }

    let coupon: CouponRule | null = null;
    let couponError: string | null = null;
    if (cart.couponCode) {
      const result = await couponsService.resolve(cart.siteId, cart.couponCode, opts.email ?? cart.email ?? null);
      if ('error' in result) {
        couponError = result.error;
        messages.push(`Coupon ${cart.couponCode} was removed: ${result.error}`);
      } else coupon = result.rule;
    }

    const changed =
      JSON.stringify(kept) !== JSON.stringify(refs) || (cart.couponCode !== null && couponError !== null);
    if (changed) {
      await cart.update({ items: kept, couponCode: couponError ? null : cart.couponCode, expiresAt: await this.expiryDate(settings) });
    }
    return { cart, lines, maxQty, messages, coupon, couponError, changed };
  }

  totals(resolved: ResolvedCart, settings: ShopSettings, destination: Destination | null, shipping: ShippingChoice | null): CartTotals {
    return computeTotals({ lines: resolved.lines, coupon: resolved.coupon, shipping, destination, settings });
  }

  /** Shipping options for a destination, cheapest first; null when nothing ships. */
  shippingOptions(resolved: ResolvedCart, settings: ShopSettings, destination: Destination | null): ShippingChoice[] {
    const base = computeTotals({ lines: resolved.lines, coupon: resolved.coupon, shipping: null, destination, settings });
    if (!base.needsShipping) return [];
    const options = availableShippingMethods(settings, destination, base.subtotal - base.discountTotal);
    return options.sort((a, b) => a.cost - b.cost);
  }

  /** What the storefront renders. */
  serialize(resolved: ResolvedCart, totals: CartTotals, settings: ShopSettings) {
    const fmt = moneyFormatOf(settings);
    const money = (v: number) => formatMoney(v, fmt);
    return {
      token: resolved.cart.id,
      items: totals.lines.map((l) => ({
        key: l.key,
        productId: l.productId,
        variantId: l.variantId,
        name: l.name,
        sku: l.sku,
        path: l.path,
        imageUrl: l.imageUrl,
        attributes: l.attributes,
        qty: l.qty,
        maxQty: Number.isFinite(resolved.maxQty.get(l.key) ?? Infinity) ? resolved.maxQty.get(l.key) : null,
        unitPrice: l.unitPrice,
        regularPrice: l.regularPrice,
        onSale: l.regularPrice !== null && l.unitPrice < l.regularPrice,
        subtotal: l.subtotal,
        discount: l.discount,
        total: l.total,
        virtual: l.virtual,
        formatted: { unitPrice: money(l.unitPrice), regularPrice: l.regularPrice !== null ? money(l.regularPrice) : '', subtotal: money(l.subtotal), total: money(l.total) },
      })),
      itemCount: totals.itemCount,
      currency: settings.general.currency,
      subtotal: totals.subtotal,
      discountTotal: totals.discountTotal,
      shippingTotal: totals.shippingTotal,
      taxTotal: totals.taxTotal,
      total: totals.total,
      needsShipping: totals.needsShipping,
      pricesIncludeTax: totals.pricesIncludeTax,
      shipping: totals.shipping ? { ...totals.shipping, formatted: money(totals.shipping.cost) } : null,
      coupon: totals.coupon ? { ...totals.coupon, formatted: money(totals.coupon.amount) } : null,
      couponError: totals.couponError ?? resolved.couponError,
      formatted: {
        subtotal: money(totals.subtotal),
        discountTotal: money(totals.discountTotal),
        shippingTotal: money(totals.shippingTotal),
        taxTotal: money(totals.taxTotal),
        total: money(totals.total),
      },
      messages: resolved.messages,
    };
  }

  /** Resolve + totals + serialize in one go (no destination: shipping shown as "calculated at checkout"). */
  /** Shipping estimate saved on the cart (or the store's country). */
  estimate(cart: ShopCart, settings: ShopSettings): { destination: Destination | null; methodId: string | null } {
    const meta = (cart.meta && typeof cart.meta === 'object' ? cart.meta : {}) as Record<string, unknown>;
    const country = typeof meta.country === 'string' && /^[A-Z]{2}$/.test(meta.country) ? meta.country : settings.general.address.country;
    return {
      destination: country ? { country, state: String(meta.state ?? ''), postcode: String(meta.postcode ?? '') } : null,
      methodId: typeof meta.shippingMethodId === 'string' ? meta.shippingMethodId : null,
    };
  }

  async view(cart: ShopCart, settings?: ShopSettings) {
    const s = settings ?? (await shopSettingsService.get(cart.siteId));
    const resolved = await this.resolve(cart, s);
    const { destination, methodId } = this.estimate(cart, s);
    const options = destination ? this.shippingOptions(resolved, s, destination) : [];
    const chosen = options.find((o) => o.id === methodId) ?? options[0] ?? null;
    const totals = this.totals(resolved, s, destination, chosen);
    const money = (v: number) => formatMoney(v, moneyFormatOf(s));
    return {
      ...this.serialize(resolved, totals, s),
      estimate: {
        country: destination?.country ?? '',
        state: destination?.state ?? '',
        postcode: destination?.postcode ?? '',
        options: options.map((o) => ({ ...o, formatted: o.cost === 0 ? 'Free' : money(o.cost), selected: o.id === chosen?.id })),
      },
    };
  }

  /** Cart page: pick a country / shipping method for the estimate (re-checked at checkout). */
  async setShipping(cart: ShopCart, input: { country: string; state: string; postcode: string; shippingMethodId?: string }, settings: ShopSettings) {
    await cart.update({
      meta: {
        country: input.country,
        state: input.state.slice(0, 100),
        postcode: input.postcode.slice(0, 32),
        shippingMethodId: input.shippingMethodId ? input.shippingMethodId.slice(0, 80) : null,
      },
    });
    return this.view(cart, settings);
  }

  async add(cart: ShopCart, input: { productId: string; variantId?: string | null; qty: number }, settings: ShopSettings) {
    try {
      const [p] = await catalogService.purchasable(cart.siteId, [input.productId]);
      if (!p) throw NotFound('Product not found.');
      const isVariable = p.commerce.type === 'variable';
      const variantId = input.variantId ?? null;
      if (isVariable && !variantId) throw BadRequest('Choose the product options first.');
      const variant = variantId ? (p.commerce.variants ?? []).find((v) => v.id === variantId && v.enabled) : null;
      if (variantId && !variant) throw BadRequest('That option is not available.');
      const priced = variant ?? p.commerce;
      if (effectivePrice(priced).price === null) throw BadRequest('This product cannot be purchased right now.');
      const stockRow = variant?.manageStock ? variant : p.commerce.manageStock ? p.commerce : variant ?? p.commerce;
      const available = availableQty(stockRow);
      if (available <= 0) throw BadRequest(`${p.post.title} is out of stock.`);

      const items = parseItems(cart.items);
      const key = lineKey(input.productId, variant?.id ?? null);
      const existing = items.find((i) => lineKey(i.productId, i.variantId) === key);
      const wanted = (existing?.qty ?? 0) + input.qty;
      if (p.commerce.soldIndividually && wanted > 1) throw BadRequest(`${p.post.title} can only be bought once per order.`);
      if (wanted > available) {
        throw BadRequest(available === 1 ? `Only 1 of ${p.post.title} is available.` : `Only ${available} of ${p.post.title} are available.`);
      }
      if (existing) existing.qty = wanted;
      else items.push({ productId: input.productId, variantId: variant?.id ?? null, qty: input.qty });
      await cart.update({ items, expiresAt: await this.expiryDate(settings) });
      return this.view(cart, settings);
    } catch (error) {
      throw toHttpError(error, 'Could not add this item to the cart.');
    }
  }

  async setQty(cart: ShopCart, key: string, qty: number, settings: ShopSettings) {
    try {
      const items = parseItems(cart.items);
      const idx = items.findIndex((i) => lineKey(i.productId, i.variantId) === key);
      if (idx === -1) throw NotFound('That item is not in your cart.');
      if (qty <= 0) items.splice(idx, 1);
      else {
        const resolved = await this.resolve(cart, settings);
        const max = resolved.maxQty.get(key) ?? Infinity;
        if (qty > max) throw BadRequest(max === 1 ? 'Only 1 is available.' : `Only ${max} are available.`);
        items[idx]!.qty = qty;
      }
      await cart.update({ items, expiresAt: await this.expiryDate(settings) });
      return this.view(cart, settings);
    } catch (error) {
      throw toHttpError(error, 'Could not update the cart.');
    }
  }

  async applyCoupon(cart: ShopCart, code: string, settings: ShopSettings) {
    try {
      const result = await couponsService.resolve(cart.siteId, code, cart.email ?? null);
      if ('error' in result) throw BadRequest(result.error);
      await cart.update({ couponCode: result.coupon.code });
      const view = await this.view(cart, settings);
      if (view.couponError) {
        await cart.update({ couponCode: null });
        throw BadRequest(view.couponError);
      }
      return view;
    } catch (error) {
      throw toHttpError(error, 'Could not apply the coupon.');
    }
  }

  async removeCoupon(cart: ShopCart, settings: ShopSettings) {
    await cart.update({ couponCode: null });
    return this.view(cart, settings);
  }

  async clear(cart: ShopCart) {
    await cart.update({ items: [], couponCode: null });
  }
}

export const cartService = new CartService();
