import type { Transaction } from 'sequelize';
import { contentFromBeekiriCode, parseContent } from '../../lib/pages/pages.content';
import { revalidatePublicPaths } from '../../lib/revalidate-public';
import {
  SHOP_PAGE_KIND,
  SHOP_PAGE_PATHS,
  SHOP_PAGE_TITLES,
  SHOP_PAGE_VIEWS,
  SHOP_PATHS,
  type ShopPageView,
} from '../../lib/shop/constants';
import { AuditLog, Post } from '../../models';
import type { AuthUser } from '../../types/auth';
import { NotFound, toHttpError } from '../../utils/http-error';
import { createId } from '../../utils/ids';

/**
 * Shop → Shop Editor: one BeekiriCode document per storefront page. The document
 * wraps a "Shop content" block; the website swaps that block for the live
 * products / cart / checkout markup, so designers can build around it freely.
 */

/** A root wrapper with just the shop-content block — what every page starts from. */
export function defaultShopPageDoc() {
  const rootId = createId();
  const slotId = createId();
  return {
    version: 1,
    rootId,
    nodes: {
      [rootId]: { id: rootId, type: 'section', tag: 'div', style: {}, children: [slotId] },
      [slotId]: { id: slotId, type: 'shop_content', tag: 'div', style: {}, children: [] },
    },
  };
}

export function isShopPageView(v: string): v is ShopPageView {
  return (SHOP_PAGE_VIEWS as readonly string[]).includes(v);
}

export class ShopPagesService {
  /** Make sure every storefront page has its row (idempotent). */
  async ensurePages(siteId: string, transaction?: Transaction) {
    for (const view of SHOP_PAGE_VIEWS) {
      const [row, created] = await Post.findOrCreate({
        where: { siteId, type: SHOP_PAGE_KIND, slug: view },
        defaults: {
          siteId,
          type: SHOP_PAGE_KIND,
          title: SHOP_PAGE_TITLES[view],
          slug: view,
          status: 'publish',
          content: contentFromBeekiriCode(defaultShopPageDoc()),
          excerpt: '',
          featuredImageId: null,
          authorId: null,
          updatedById: null,
          publishedAt: new Date(),
        },
        transaction,
      });
      if (!created && row.status === 'trash') await row.update({ status: 'publish' }, { transaction });
    }
  }

  async list(actor: AuthUser) {
    try {
      await this.ensurePages(actor.siteId);
      const rows = await Post.findAll({ where: { siteId: actor.siteId, type: SHOP_PAGE_KIND } });
      return {
        pages: SHOP_PAGE_VIEWS.map((view) => {
          const row = rows.find((r) => r.slug === view);
          const doc = row ? parseContent(row.content).beekiricode : null;
          const nodes = doc && typeof doc === 'object' ? Object.keys((doc as { nodes?: Record<string, unknown> }).nodes ?? {}).length : 0;
          return {
            view,
            id: row?.id ?? null,
            title: row?.title ?? SHOP_PAGE_TITLES[view],
            path: SHOP_PAGE_PATHS[view],
            status: row?.status ?? 'publish',
            /** More than the default wrapper + slot means the page was customised. */
            customised: nodes > 2,
            updatedAt: row?.updatedAt?.toISOString() ?? null,
          };
        }),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load the shop pages.');
    }
  }

  /** Back to the plain template (keeps a revision through the normal content path is not needed: the document is tiny). */
  async reset(actor: AuthUser, view: string) {
    try {
      if (!isShopPageView(view)) throw NotFound('Shop page not found.');
      await this.ensurePages(actor.siteId);
      const row = await Post.findOne({ where: { siteId: actor.siteId, type: SHOP_PAGE_KIND, slug: view } });
      if (!row) throw NotFound('Shop page not found.');
      await row.update({
        title: SHOP_PAGE_TITLES[view],
        status: 'publish',
        content: contentFromBeekiriCode(defaultShopPageDoc()),
        updatedById: actor.id,
      });
      await AuditLog.create({ siteId: actor.siteId, userId: actor.id, action: 'shop.page_reset', meta: { view } });
      void revalidatePublicPaths([view === 'product' ? SHOP_PATHS.shop : SHOP_PAGE_PATHS[view]]);
      return this.list(actor);
    } catch (error) {
      throw toHttpError(error, 'Could not reset the shop page.');
    }
  }

  /** Published document for the website (null → render the plain template). */
  async publicDoc(siteId: string, view: string) {
    if (!isShopPageView(view)) throw NotFound('Shop page not found.');
    const row = await Post.findOne({ where: { siteId, type: SHOP_PAGE_KIND, slug: view, status: 'publish' } });
    if (!row) return { view, beekiricode: null, title: SHOP_PAGE_TITLES[view] };
    const doc = parseContent(row.content);
    return { view, beekiricode: doc.beekiricode ?? null, title: row.title, seo: doc.seo ?? null };
  }
}

export const shopPagesService = new ShopPagesService();
