import { Op, type WhereOptions } from 'sequelize';
import { parseContent } from '../../lib/pages/pages.content';
import { PRODUCT_CATEGORY_TAXONOMY, PRODUCT_KIND, PRODUCT_TAG_TAXONOMY, SHOP_PATHS } from '../../lib/shop/constants';
import { formatMoney } from '../../lib/shop/money';
import { availableQty, effectivePrice, priceRange } from '../../lib/shop/pricing';
import { moneyFormatOf, type ShopSettings } from '../../lib/shop/settings';
import { Post, ShopProduct, ShopProductVariant, Taxonomy, Term, TermRelationship } from '../../models';
import { NotFound, toHttpError } from '../../utils/http-error';
import type { CatalogInput } from '../../validators/shop.schema';
import { loadMedia, loadTermsForPosts, type MediaRef, type TermRef } from './products.service';
import { shopSettingsService } from './shop-settings.service';

type PostWithCommerce = Post & { shopProduct?: (ShopProduct & { variants?: ShopProductVariant[] }) | null };

export type PublicPrice = {
  min: number;
  max: number;
  regular: number | null;
  onSale: boolean;
  formatted: string;
  regularFormatted: string;
  /** "€10.00 – €25.00" for variable products */
  rangeFormatted: string;
};

export type PublicCategory = {
  id: string;
  name: string;
  slug: string;
  parentId: string | null;
  path: string;
  count: number;
  description: string;
  /** Featured image of the category's first product (or a subcategory's), for category tiles. */
  image: MediaRef | null;
};

export type PublicProduct = {
  id: string;
  slug: string;
  path: string;
  title: string;
  shortDescription: string;
  description: string;
  image: MediaRef | null;
  gallery: MediaRef[];
  type: string;
  sku: string;
  featured: boolean;
  inStock: boolean;
  stockStatus: string;
  stockQty: number | null;
  soldIndividually: boolean;
  virtual: boolean;
  price: PublicPrice | null;
  categories: (TermRef & { path: string })[];
  tags: TermRef[];
  attributes: { name: string; options: string[]; variation: boolean }[];
  variants: {
    id: string;
    sku: string;
    attributes: Record<string, string>;
    price: PublicPrice | null;
    inStock: boolean;
    stockQty: number | null;
    image: MediaRef | null;
  }[];
  purchaseNote: string;
  weight: number | null;
  dimensions: { length: number | null; width: number | null; height: number | null };
  publishedAt: string | null;
  seo: unknown;
};

function toPrice(p: { min: number; max: number; onSale: boolean; regular?: number | null } | null, settings: ShopSettings): PublicPrice | null {
  if (!p) return null;
  const fmt = moneyFormatOf(settings);
  const regular = p.regular ?? null;
  return {
    min: p.min,
    max: p.max,
    regular,
    onSale: p.onSale,
    formatted: formatMoney(p.min, fmt),
    regularFormatted: regular !== null ? formatMoney(regular, fmt) : '',
    rangeFormatted: p.min === p.max ? formatMoney(p.min, fmt) : `${formatMoney(p.min, fmt)} – ${formatMoney(p.max, fmt)}`,
  };
}

export class CatalogService {
  private async taxonomyIds(siteId: string) {
    const rows = await Taxonomy.findAll({
      where: { siteId, slug: { [Op.in]: [PRODUCT_CATEGORY_TAXONOMY, PRODUCT_TAG_TAXONOMY] } },
    });
    return {
      category: rows.find((r) => r.slug === PRODUCT_CATEGORY_TAXONOMY)?.id ?? null,
      tag: rows.find((r) => r.slug === PRODUCT_TAG_TAXONOMY)?.id ?? null,
    };
  }

  /** Category tree with published-product counts. */
  async categories(siteId: string): Promise<PublicCategory[]> {
    const { category } = await this.taxonomyIds(siteId);
    if (!category) return [];
    const terms = await Term.findAll({
      where: { siteId, taxonomyId: category },
      order: [
        ['menuOrder', 'ASC'],
        ['name', 'ASC'],
      ],
    });
    if (!terms.length) return [];
    const links = await TermRelationship.findAll({
      where: { termId: { [Op.in]: terms.map((t) => t.id) } },
      include: [
        {
          model: Post,
          as: 'post',
          attributes: ['id', 'status', 'type', 'featuredImageId', 'menuOrder', 'title'],
          where: { status: 'publish', type: PRODUCT_KIND },
        },
      ],
    });
    const counts = new Map<string, number>();
    const firstImage = new Map<string, { imageId: string; order: number; title: string }>();
    for (const l of links) {
      counts.set(l.termId, (counts.get(l.termId) ?? 0) + 1);
      const post = (l as TermRelationship & { post?: Post }).post;
      if (!post?.featuredImageId) continue;
      const seen = firstImage.get(l.termId);
      const order = post.menuOrder ?? 0;
      if (!seen || order < seen.order || (order === seen.order && post.title.localeCompare(seen.title) < 0)) {
        firstImage.set(l.termId, { imageId: post.featuredImageId, order, title: post.title });
      }
    }
    // A parent with no products of its own borrows the image of its first child that has one.
    const imageIdOf = (id: string, depth = 0): string | null => {
      const own = firstImage.get(id)?.imageId;
      if (own || depth > 4) return own ?? null;
      for (const child of terms.filter((t) => t.parentId === id)) {
        const found = imageIdOf(child.id, depth + 1);
        if (found) return found;
      }
      return null;
    };
    const media = await loadMedia(siteId, terms.map((t) => imageIdOf(t.id)));
    return terms.map((t) => ({
      id: t.id,
      name: t.name,
      slug: t.slug,
      parentId: t.parentId ?? null,
      path: SHOP_PATHS.category(t.slug),
      count: counts.get(t.id) ?? 0,
      description: t.description,
      image: media.get(imageIdOf(t.id) ?? '') ?? null,
    }));
  }

  /** A category and every descendant id (for archive filtering). */
  private async categoryWithChildren(siteId: string, slug: string) {
    const { category } = await this.taxonomyIds(siteId);
    if (!category) return null;
    const term = await Term.findOne({ where: { siteId, taxonomyId: category, slug } });
    if (!term) return null;
    const all = await Term.findAll({ where: { siteId, taxonomyId: category }, attributes: ['id', 'parentId'] });
    const ids = new Set<string>([term.id]);
    let grew = true;
    while (grew) {
      grew = false;
      for (const t of all) {
        if (t.parentId && ids.has(t.parentId) && !ids.has(t.id)) {
          ids.add(t.id);
          grew = true;
        }
      }
    }
    return { term, ids: [...ids] };
  }

  private serialize(post: PostWithCommerce, settings: ShopSettings, media: Map<string, MediaRef>, terms: Record<string, TermRef[]>, full: boolean): PublicProduct {
    const c = post.shopProduct ?? null;
    const variants = (c?.variants ?? []).filter((v) => v.enabled);
    const isVariable = c?.type === 'variable';
    const doc = parseContent(post.content);
    const galleryIds = Array.isArray(c?.galleryIds) ? (c!.galleryIds as unknown[]).map(String) : [];
    const basePrice = c ? effectivePrice(c) : null;
    const price = isVariable
      ? (() => {
          const r = priceRange(variants);
          return r ? toPrice({ ...r, regular: null }, settings) : null;
        })()
      : basePrice && basePrice.price !== null
        ? toPrice({ min: basePrice.price, max: basePrice.price, onSale: basePrice.onSale, regular: basePrice.regular }, settings)
        : null;
    const inStock = isVariable ? variants.some((v) => availableQty(v) > 0) : c ? availableQty(c) > 0 : false;
    const attributes = Array.isArray(c?.attributes)
      ? (c!.attributes as Record<string, unknown>[])
          .filter((a) => a && typeof a === 'object' && (a.visible !== false || a.variation === true))
          .map((a) => ({
            name: String(a.name ?? ''),
            options: Array.isArray(a.options) ? a.options.map(String) : [],
            variation: a.variation === true,
          }))
      : [];
    return {
      id: post.id,
      slug: post.slug,
      path: SHOP_PATHS.product(post.slug),
      title: post.title,
      shortDescription: post.excerpt,
      description: full ? doc.html : '',
      image: post.featuredImageId ? (media.get(post.featuredImageId) ?? null) : null,
      gallery: full ? galleryIds.map((id) => media.get(id)).filter((m): m is MediaRef => Boolean(m)) : [],
      type: c?.type ?? 'simple',
      sku: c?.sku ?? '',
      featured: c?.featured ?? false,
      inStock,
      stockStatus: !inStock ? 'outofstock' : (c?.stockStatus ?? 'instock'),
      stockQty: c?.manageStock && !isVariable ? (c.stockQty ?? 0) : null,
      soldIndividually: c?.soldIndividually ?? false,
      virtual: c?.virtual ?? false,
      price,
      categories: (terms[PRODUCT_CATEGORY_TAXONOMY] ?? []).map((t) => ({ ...t, path: SHOP_PATHS.category(t.slug) })),
      tags: terms[PRODUCT_TAG_TAXONOMY] ?? [],
      attributes,
      variants: full
        ? variants.map((v) => {
            const p = effectivePrice(v);
            return {
              id: v.id,
              sku: v.sku,
              attributes: (v.attributes ?? {}) as Record<string, string>,
              price: p.price !== null ? toPrice({ min: p.price, max: p.price, onSale: p.onSale, regular: p.regular }, settings) : null,
              inStock: availableQty(v) > 0,
              stockQty: v.manageStock ? (v.stockQty ?? 0) : null,
              image: v.imageId ? (media.get(v.imageId) ?? null) : null,
            };
          })
        : [],
      purchaseNote: full ? (c?.purchaseNote ?? '') : '',
      weight: c?.weight ?? null,
      dimensions: { length: c?.length ?? null, width: c?.width ?? null, height: c?.height ?? null },
      publishedAt: post.publishedAt?.toISOString() ?? null,
      seo: full ? (doc.seo ?? null) : null,
    };
  }

  async list(siteId: string, query: CatalogInput, settingsIn?: ShopSettings) {
    try {
      const settings = settingsIn ?? (await shopSettingsService.get(siteId));
      const perPage = query.perPage ?? settings.products.perPage;
      const page = query.page ?? 1;
      const where: WhereOptions = { siteId, type: PRODUCT_KIND, status: 'publish' };
      const q = (query.q ?? '').trim();
      if (q) Object.assign(where, { title: { [Op.iLike]: `%${q.replace(/[%_\\]/g, '\\$&')}%` } });

      let category: PublicCategory | null = null;
      if (query.category) {
        const found = await this.categoryWithChildren(siteId, query.category);
        if (!found) throw NotFound('Category not found.');
        const links = await TermRelationship.findAll({ where: { termId: { [Op.in]: found.ids } }, attributes: ['postId'] });
        Object.assign(where, { id: { [Op.in]: [...new Set(links.map((l) => l.postId))] } });
        category = {
          id: found.term.id,
          name: found.term.name,
          slug: found.term.slug,
          parentId: found.term.parentId ?? null,
          path: SHOP_PATHS.category(found.term.slug),
          count: 0,
          description: found.term.description,
          image: null,
        };
      }
      if (query.tag) {
        const { tag } = await this.taxonomyIds(siteId);
        const term = tag ? await Term.findOne({ where: { siteId, taxonomyId: tag, slug: query.tag } }) : null;
        const links = term ? await TermRelationship.findAll({ where: { termId: term.id }, attributes: ['postId'] }) : [];
        const ids = links.map((l) => l.postId);
        const current = (where as { id?: { [Op.in]: string[] } }).id;
        Object.assign(where, { id: { [Op.in]: current ? current[Op.in].filter((id) => ids.includes(id)) : ids } });
      }

      const commerceWhere: WhereOptions = {
        catalogVisibility: { [Op.in]: q ? ['visible', 'search'] : ['visible', 'catalog'] },
      };
      if (query.featured === '1' || query.featured === 'true') Object.assign(commerceWhere, { featured: true });
      if (settings.products.hideOutOfStock) Object.assign(commerceWhere, { stockStatus: { [Op.ne]: 'outofstock' } });

      const sort = query.sort ?? settings.products.defaultSort;
      const order =
        sort === 'newest'
          ? [['publishedAt', 'DESC']]
          : sort === 'title'
            ? [['title', 'ASC']]
            : sort === 'price'
              ? [[{ model: ShopProduct, as: 'shopProduct' }, 'regularPrice', 'ASC NULLS LAST']]
              : sort === 'price-desc'
                ? [[{ model: ShopProduct, as: 'shopProduct' }, 'regularPrice', 'DESC NULLS LAST']]
                : sort === 'popularity'
                  ? [[{ model: ShopProduct, as: 'shopProduct' }, 'totalSales', 'DESC']]
                  : [
                      ['menuOrder', 'ASC'],
                      ['publishedAt', 'DESC'],
                    ];

      const { rows, count } = await Post.findAndCountAll({
        where,
        include: [
          {
            model: ShopProduct,
            as: 'shopProduct',
            required: true,
            where: commerceWhere,
            include: [{ model: ShopProductVariant, as: 'variants' }],
          },
        ],
        order: order as never,
        limit: perPage,
        offset: (page - 1) * perPage,
        distinct: true,
      });
      const [media, terms] = await Promise.all([
        loadMedia(siteId, rows.map((r) => r.featuredImageId)),
        loadTermsForPosts(siteId, rows.map((r) => r.id)),
      ]);
      return {
        items: rows.map((r) => this.serialize(r as PostWithCommerce, settings, media, terms.get(r.id) ?? {}, false)),
        total: count,
        page,
        perPage,
        pages: Math.max(1, Math.ceil(count / perPage)),
        sort,
        query: q,
        category,
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load products.');
    }
  }

  async bySlug(siteId: string, slug: string, settingsIn?: ShopSettings) {
    try {
      const settings = settingsIn ?? (await shopSettingsService.get(siteId));
      const post = (await Post.findOne({
        where: { siteId, type: PRODUCT_KIND, status: 'publish', slug },
        include: [
          {
            model: ShopProduct,
            as: 'shopProduct',
            required: true,
            where: { catalogVisibility: { [Op.ne]: 'hidden' } },
            include: [{ model: ShopProductVariant, as: 'variants' }],
          },
        ],
      })) as PostWithCommerce | null;
      if (!post) throw NotFound('Product not found.');
      const c = post.shopProduct!;
      const galleryIds = Array.isArray(c.galleryIds) ? (c.galleryIds as unknown[]).map(String) : [];
      const [media, terms] = await Promise.all([
        loadMedia(siteId, [post.featuredImageId, ...galleryIds, ...(c.variants ?? []).map((v) => v.imageId)]),
        loadTermsForPosts(siteId, [post.id]),
      ]);
      const product = this.serialize(post, settings, media, terms.get(post.id) ?? {}, true);
      const related = await this.related(siteId, product, settings);
      return { product, related };
    } catch (error) {
      throw toHttpError(error, 'Could not load this product.');
    }
  }

  /** Products sharing a category (falls back to newest). */
  private async related(siteId: string, product: PublicProduct, settings: ShopSettings): Promise<PublicProduct[]> {
    const limit = settings.products.relatedCount;
    if (!limit) return [];
    let ids: string[] | null = null;
    if (product.categories.length) {
      const links = await TermRelationship.findAll({
        where: { termId: { [Op.in]: product.categories.map((c) => c.id) } },
        attributes: ['postId'],
      });
      ids = [...new Set(links.map((l) => l.postId))].filter((id) => id !== product.id);
    }
    const where: WhereOptions = { siteId, type: PRODUCT_KIND, status: 'publish', id: { [Op.ne]: product.id } };
    if (ids?.length) Object.assign(where, { id: { [Op.in]: ids } });
    const rows = await Post.findAll({
      where,
      include: [
        {
          model: ShopProduct,
          as: 'shopProduct',
          required: true,
          where: { catalogVisibility: { [Op.in]: ['visible', 'catalog'] } },
          include: [{ model: ShopProductVariant, as: 'variants' }],
        },
      ],
      order: [['publishedAt', 'DESC']],
      limit,
    });
    const [media, terms] = await Promise.all([
      loadMedia(siteId, rows.map((r) => r.featuredImageId)),
      loadTermsForPosts(siteId, rows.map((r) => r.id)),
    ]);
    return rows.map((r) => this.serialize(r as PostWithCommerce, settings, media, terms.get(r.id) ?? {}, false));
  }

  /** Purchasable rows for the cart/checkout engine (published, visible or hidden alike). */
  async purchasable(siteId: string, productIds: string[]) {
    if (!productIds.length) return [];
    const rows = (await Post.findAll({
      where: { siteId, type: PRODUCT_KIND, status: 'publish', id: { [Op.in]: productIds } },
      include: [
        { model: ShopProduct, as: 'shopProduct', required: true, include: [{ model: ShopProductVariant, as: 'variants' }] },
      ],
    })) as PostWithCommerce[];
    const media = await loadMedia(siteId, rows.flatMap((r) => [r.featuredImageId, ...(r.shopProduct?.variants ?? []).map((v) => v.imageId)]));
    const terms = await loadTermsForPosts(siteId, rows.map((r) => r.id));
    return rows.map((r) => ({ post: r, commerce: r.shopProduct!, media, categories: terms.get(r.id)?.[PRODUCT_CATEGORY_TAXONOMY] ?? [] }));
  }
}

export const catalogService = new CatalogService();
