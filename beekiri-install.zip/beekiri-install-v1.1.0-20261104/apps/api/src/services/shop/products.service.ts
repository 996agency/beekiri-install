import { Op, type Transaction, type WhereOptions } from 'sequelize';
import { getPostTaxonomies, setPostTaxonomies } from '../../lib/pages/page-taxonomies';
import { revalidatePublicPaths } from '../../lib/revalidate-public';
import {
  PRODUCT_CATEGORY_TAXONOMY,
  PRODUCT_KIND,
  PRODUCT_TAG_TAXONOMY,
  SHOP_PATHS,
} from '../../lib/shop/constants';
import { availableQty, effectivePrice, priceRange } from '../../lib/shop/pricing';
import {
  AuditLog,
  MediaAsset,
  Post,
  sequelize,
  ShopProduct,
  ShopProductVariant,
  Taxonomy,
  Term,
  TermRelationship,
} from '../../models';
import type { AuthUser } from '../../types/auth';
import { BadRequest, NotFound, toHttpError } from '../../utils/http-error';
import type {
  CreateProductInput,
  ProductCommerceInput,
  ProductListInput,
  ProductVariantInput,
  UpdateProductInput,
} from '../../validators/shop.schema';
import { pagesService } from '../pages.service';

export type MediaRef = { id: string; url: string; alt: string; width: number | null; height: number | null };
export type TermRef = { id: string; name: string; slug: string; parentId: string | null };

export type ProductAttribute = { name: string; options: string[]; visible: boolean; variation: boolean };

function parseAttributes(raw: unknown): ProductAttribute[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((a): a is Record<string, unknown> => Boolean(a) && typeof a === 'object')
    .map((a) => ({
      name: String(a.name ?? '').trim(),
      options: Array.isArray(a.options) ? a.options.map((o) => String(o).trim()).filter(Boolean) : [],
      visible: a.visible !== false,
      variation: a.variation === true,
    }))
    .filter((a) => a.name);
}

function iso(d: Date | null | undefined) {
  return d ? new Date(d).toISOString() : null;
}

function dateOrNull(v: string | null | undefined): Date | null | undefined {
  if (v === undefined) return undefined;
  if (v === null || v === '') return null;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function serializeVariant(v: ShopProductVariant, media: Map<string, MediaRef>) {
  return {
    id: v.id,
    sku: v.sku,
    attributes: (v.attributes && typeof v.attributes === 'object' ? v.attributes : {}) as Record<string, string>,
    regularPrice: v.regularPrice ?? null,
    salePrice: v.salePrice ?? null,
    saleFrom: iso(v.saleFrom),
    saleTo: iso(v.saleTo),
    manageStock: v.manageStock,
    stockQty: v.stockQty ?? null,
    stockStatus: v.stockStatus,
    weight: v.weight ?? null,
    imageId: v.imageId ?? null,
    image: v.imageId ? (media.get(v.imageId) ?? null) : null,
    enabled: v.enabled,
    menuOrder: v.menuOrder,
  };
}

export async function loadMedia(siteId: string, ids: (string | null | undefined)[]): Promise<Map<string, MediaRef>> {
  const clean = [...new Set(ids.filter((v): v is string => Boolean(v)))];
  if (!clean.length) return new Map();
  const rows = await MediaAsset.findAll({ where: { siteId, id: { [Op.in]: clean } } });
  return new Map(
    rows.map((m) => [m.id, { id: m.id, url: m.url, alt: m.alt, width: m.width, height: m.height }]),
  );
}

/** Terms attached to a set of posts, grouped by post then taxonomy slug. */
export async function loadTermsForPosts(siteId: string, postIds: string[]) {
  const out = new Map<string, Record<string, TermRef[]>>();
  if (!postIds.length) return out;
  const links = await TermRelationship.findAll({ where: { postId: { [Op.in]: postIds } } });
  const termIds = [...new Set(links.map((l) => l.termId))];
  if (!termIds.length) return out;
  const terms = await Term.findAll({ where: { siteId, id: { [Op.in]: termIds } } });
  const taxonomies = await Taxonomy.findAll({
    where: { siteId, id: { [Op.in]: [...new Set(terms.map((t) => t.taxonomyId))] } },
  });
  const taxSlug = new Map(taxonomies.map((t) => [t.id, t.slug]));
  const termById = new Map(terms.map((t) => [t.id, t]));
  for (const link of links) {
    const term = termById.get(link.termId);
    if (!term) continue;
    const slug = taxSlug.get(term.taxonomyId) ?? '';
    const bucket = out.get(link.postId) ?? {};
    (bucket[slug] ??= []).push({ id: term.id, name: term.name, slug: term.slug, parentId: term.parentId ?? null });
    out.set(link.postId, bucket);
  }
  return out;
}

export class ProductsService {
  private async audit(actor: AuthUser, action: string, meta: Record<string, unknown>) {
    await AuditLog.create({ siteId: actor.siteId, userId: actor.id, action, meta });
  }

  private async ensureCommerce(siteId: string, postId: string, transaction?: Transaction) {
    const [row] = await ShopProduct.findOrCreate({
      where: { postId },
      defaults: { siteId, postId },
      transaction,
    });
    return row;
  }

  private bust(slugs: string[]) {
    void revalidatePublicPaths([SHOP_PATHS.shop, ...slugs.map((s) => SHOP_PATHS.product(s))]);
  }

  /** Paginated admin list (WooCommerce "All products"). */
  async list(actor: AuthUser, query: ProductListInput) {
    try {
      const siteId = actor.siteId;
      const page = query.page ?? 1;
      const perPage = query.perPage ?? 20;
      const status = query.status ?? 'all';
      const where: WhereOptions = {
        siteId,
        type: PRODUCT_KIND,
        status:
          status === 'trash'
            ? 'trash'
            : status === 'all'
              ? { [Op.notIn]: ['auto-draft', 'trash'] }
              : status,
      };
      const q = (query.q ?? '').trim();
      const commerceWhere: WhereOptions = {};
      if (query.stock) Object.assign(commerceWhere, { stockStatus: query.stock });
      if (query.type) Object.assign(commerceWhere, { type: query.type });

      let postIdFilter: string[] | null = null;
      if (query.category) {
        const term = await Term.findOne({
          where: { siteId, [Op.or]: [{ id: query.category }, { slug: query.category }] },
        });
        const links = term ? await TermRelationship.findAll({ where: { termId: term.id } }) : [];
        postIdFilter = links.map((l) => l.postId);
      }
      if (q) {
        const like = `%${q.replace(/[%_\\]/g, '\\$&')}%`;
        const skuHits = await ShopProduct.findAll({
          where: { siteId, sku: { [Op.iLike]: like } },
          attributes: ['postId'],
        });
        const variantHits = await ShopProductVariant.findAll({
          where: { siteId, sku: { [Op.iLike]: like } },
          include: [{ model: ShopProduct, as: 'product', attributes: ['postId'] }],
        });
        const skuPostIds = [
          ...skuHits.map((r) => r.postId),
          ...variantHits.map((v) => (v as ShopProductVariant & { product?: ShopProduct }).product?.postId).filter(Boolean),
        ] as string[];
        Object.assign(where, { [Op.or]: [{ title: { [Op.iLike]: like } }, { id: { [Op.in]: skuPostIds } }] });
      }
      if (postIdFilter) Object.assign(where, { id: { [Op.in]: postIdFilter } });

      const sort = query.sort ?? 'updated';
      const order =
        sort === 'title'
          ? [['title', 'ASC']]
          : sort === 'price'
            ? [[{ model: ShopProduct, as: 'shopProduct' }, 'regularPrice', 'ASC NULLS LAST']]
            : sort === 'price-desc'
              ? [[{ model: ShopProduct, as: 'shopProduct' }, 'regularPrice', 'DESC NULLS LAST']]
              : sort === 'sku'
                ? [[{ model: ShopProduct, as: 'shopProduct' }, 'sku', 'ASC']]
                : sort === 'stock'
                  ? [[{ model: ShopProduct, as: 'shopProduct' }, 'stockQty', 'ASC NULLS LAST']]
                  : [['updatedAt', 'DESC']];

      const { rows, count } = await Post.findAndCountAll({
        where,
        include: [
          {
            model: ShopProduct,
            as: 'shopProduct',
            required: Object.keys(commerceWhere).length > 0,
            where: Object.keys(commerceWhere).length ? commerceWhere : undefined,
            include: [{ model: ShopProductVariant, as: 'variants' }],
          },
        ],
        order: order as never,
        limit: perPage,
        offset: (page - 1) * perPage,
        distinct: true,
      });

      const [media, terms, counts] = await Promise.all([
        loadMedia(siteId, rows.map((r) => r.featuredImageId)),
        loadTermsForPosts(siteId, rows.map((r) => r.id)),
        Post.findAll({
          where: { siteId, type: PRODUCT_KIND, status: { [Op.ne]: 'auto-draft' } },
          attributes: ['status'],
        }),
      ]);
      const tally = { all: 0, publish: 0, draft: 0, trash: 0 };
      for (const c of counts) {
        if (c.status === 'trash') tally.trash++;
        else {
          tally.all++;
          if (c.status === 'publish') tally.publish++;
          else tally.draft++;
        }
      }

      const items = rows.map((post) => {
        const commerce = (post as Post & { shopProduct?: ShopProduct & { variants?: ShopProductVariant[] } }).shopProduct;
        const variants = (commerce?.variants ?? []).filter((v) => v.enabled);
        const isVariable = commerce?.type === 'variable';
        const price = isVariable
          ? priceRange(variants)
          : commerce
            ? (() => {
                const p = effectivePrice(commerce);
                return p.price === null ? null : { min: p.price, max: p.price, onSale: p.onSale };
              })()
            : null;
        const stockQty = isVariable
          ? variants.reduce<number | null>((acc, v) => (v.manageStock ? (acc ?? 0) + (v.stockQty ?? 0) : acc), null)
          : commerce?.manageStock
            ? (commerce.stockQty ?? 0)
            : null;
        const inStock = isVariable
          ? variants.some((v) => availableQty(v) > 0)
          : commerce
            ? availableQty(commerce) > 0
            : false;
        return {
          id: post.id,
          title: post.title,
          slug: post.slug,
          status: post.status,
          path: SHOP_PATHS.product(post.slug),
          image: post.featuredImageId ? (media.get(post.featuredImageId) ?? null) : null,
          type: commerce?.type ?? 'simple',
          sku: commerce?.sku ?? '',
          regularPrice: commerce?.regularPrice ?? null,
          salePrice: commerce?.salePrice ?? null,
          price,
          stockStatus: inStock ? (commerce?.stockStatus === 'onbackorder' ? 'onbackorder' : 'instock') : 'outofstock',
          stockQty,
          manageStock: commerce?.manageStock ?? false,
          featured: commerce?.featured ?? false,
          totalSales: commerce?.totalSales ?? 0,
          variantCount: variants.length,
          categories: terms.get(post.id)?.[PRODUCT_CATEGORY_TAXONOMY] ?? [],
          updatedAt: post.updatedAt.toISOString(),
          publishedAt: iso(post.publishedAt),
        };
      });

      return { items, total: count, page, perPage, pages: Math.max(1, Math.ceil(count / perPage)), counts: tally };
    } catch (error) {
      throw toHttpError(error, 'Could not load products.');
    }
  }

  /** Full editor payload. */
  async get(actor: AuthUser, id: string) {
    try {
      const page = await pagesService.get(actor, id, PRODUCT_KIND);
      const commerce = await this.ensureCommerce(actor.siteId, id);
      const variants = await ShopProductVariant.findAll({
        where: { productId: commerce.id },
        order: [
          ['menuOrder', 'ASC'],
          ['createdAt', 'ASC'],
        ],
      });
      const galleryIds = Array.isArray(commerce.galleryIds) ? commerce.galleryIds.map(String) : [];
      const media = await loadMedia(actor.siteId, [
        page.featuredImageId,
        ...galleryIds,
        ...variants.map((v) => v.imageId),
      ]);
      const taxonomies = await getPostTaxonomies(id, actor.siteId, PRODUCT_KIND);
      const pick = (slug: string) => taxonomies.taxonomies.find((t) => t.slug === slug);
      const cats = pick(PRODUCT_CATEGORY_TAXONOMY);
      const tags = pick(PRODUCT_TAG_TAXONOMY);
      return {
        id: page.id,
        title: page.title,
        slug: page.slug,
        status: page.status,
        path: SHOP_PATHS.product(page.slug),
        description: page.content,
        shortDescription: page.excerpt,
        featuredImageId: page.featuredImageId,
        image: page.featuredImageId ? (media.get(page.featuredImageId) ?? null) : null,
        seo: page.seo,
        authorName: page.authorName,
        updatedByName: page.updatedByName,
        revisionCount: page.revisionCount,
        createdAt: page.createdAt,
        updatedAt: page.updatedAt,
        publishedAt: page.publishedAt,
        commerce: {
          id: commerce.id,
          type: commerce.type,
          sku: commerce.sku,
          regularPrice: commerce.regularPrice ?? null,
          salePrice: commerce.salePrice ?? null,
          saleFrom: iso(commerce.saleFrom),
          saleTo: iso(commerce.saleTo),
          manageStock: commerce.manageStock,
          stockQty: commerce.stockQty ?? null,
          stockStatus: commerce.stockStatus,
          lowStockThreshold: commerce.lowStockThreshold ?? null,
          soldIndividually: commerce.soldIndividually,
          weight: commerce.weight ?? null,
          length: commerce.length ?? null,
          width: commerce.width ?? null,
          height: commerce.height ?? null,
          virtual: commerce.virtual,
          taxable: commerce.taxable,
          galleryIds,
          gallery: galleryIds.map((gid) => media.get(gid)).filter((m): m is MediaRef => Boolean(m)),
          attributes: parseAttributes(commerce.attributes),
          purchaseNote: commerce.purchaseNote,
          featured: commerce.featured,
          catalogVisibility: commerce.catalogVisibility,
          totalSales: commerce.totalSales,
        },
        variants: variants.map((v) => serializeVariant(v, media)),
        categoryTaxonomyId: cats?.id ?? null,
        tagTaxonomyId: tags?.id ?? null,
        categoryIds: cats?.selectedTermIds ?? [],
        tagIds: tags?.selectedTermIds ?? [],
        categories: (cats?.terms ?? []).map((t) => ({ id: t.id, name: t.name, slug: t.slug, parentId: t.parentId })),
        tags: (tags?.terms ?? []).map((t) => ({ id: t.id, name: t.name, slug: t.slug, parentId: t.parentId })),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load this product.');
    }
  }

  async create(actor: AuthUser, body: CreateProductInput) {
    try {
      const page = await pagesService.create(
        actor,
        { title: body.title ?? '', status: body.status ?? 'draft' },
        PRODUCT_KIND,
      );
      await this.ensureCommerce(actor.siteId, page.id);
      await this.audit(actor, 'product.created', { id: page.id });
      return this.get(actor, page.id);
    } catch (error) {
      throw toHttpError(error, 'Could not create the product.');
    }
  }

  private validateCommerce(c: ProductCommerceInput, variants: ProductVariantInput[] | undefined, type: string) {
    if (c.salePrice != null && c.regularPrice != null && c.salePrice >= c.regularPrice) {
      throw BadRequest('The sale price must be lower than the regular price.');
    }
    if (c.saleFrom && c.saleTo && new Date(c.saleFrom) > new Date(c.saleTo)) {
      throw BadRequest('The sale end date must be after the start date.');
    }
    if (type === 'variable') {
      const attrs = c.attributes ?? [];
      const variationAttrs = attrs.filter((a) => a.variation);
      if (!variationAttrs.length) {
        throw BadRequest('A variable product needs at least one attribute marked "Used for variations".');
      }
      for (const v of variants ?? []) {
        if (v.salePrice != null && v.regularPrice != null && v.salePrice >= v.regularPrice) {
          throw BadRequest('A variation sale price must be lower than its regular price.');
        }
        for (const [name, value] of Object.entries(v.attributes)) {
          const attr = variationAttrs.find((a) => a.name === name);
          if (!attr) throw BadRequest(`Variation attribute "${name}" is not a variation attribute.`);
          if (value && !attr.options.includes(value)) {
            throw BadRequest(`"${value}" is not an option of attribute "${name}".`);
          }
        }
      }
    }
  }

  private async syncVariants(siteId: string, productId: string, incoming: ProductVariantInput[], transaction: Transaction) {
    const existing = await ShopProductVariant.findAll({ where: { productId }, transaction });
    const keep = new Set<string>();
    for (const [index, v] of incoming.entries()) {
      const data = {
        siteId,
        productId,
        sku: (v.sku ?? '').trim(),
        attributes: v.attributes,
        regularPrice: v.regularPrice ?? null,
        salePrice: v.salePrice ?? null,
        saleFrom: dateOrNull(v.saleFrom) ?? null,
        saleTo: dateOrNull(v.saleTo) ?? null,
        manageStock: v.manageStock,
        stockQty: v.manageStock ? (v.stockQty ?? 0) : null,
        stockStatus: v.stockStatus,
        weight: v.weight ?? null,
        imageId: v.imageId ?? null,
        enabled: v.enabled,
        menuOrder: v.menuOrder ?? index,
      };
      const row = v.id ? existing.find((e) => e.id === v.id) : undefined;
      if (row) {
        await row.update(data, { transaction });
        keep.add(row.id);
      } else {
        const created = await ShopProductVariant.create(data, { transaction });
        keep.add(created.id);
      }
    }
    for (const row of existing) {
      if (!keep.has(row.id)) await row.destroy({ transaction });
    }
  }

  async update(actor: AuthUser, id: string, body: UpdateProductInput) {
    try {
      const existing = await Post.findOne({ where: { id, siteId: actor.siteId, type: PRODUCT_KIND } });
      if (!existing) throw NotFound('Product not found.');
      const previousSlug = existing.slug;

      const pagePatch: Record<string, unknown> = {};
      if (body.title !== undefined) pagePatch.title = body.title;
      if (body.slug !== undefined) pagePatch.slug = body.slug;
      if (body.status !== undefined) pagePatch.status = body.status;
      if (body.description !== undefined) pagePatch.content = body.description;
      if (body.shortDescription !== undefined) pagePatch.excerpt = body.shortDescription;
      if (body.featuredImageId !== undefined) pagePatch.featuredImageId = body.featuredImageId;
      if (body.seo !== undefined) pagePatch.seo = body.seo;
      if (body.status === 'publish' && !(body.title ?? existing.title).trim()) {
        throw BadRequest('Give the product a name before publishing.');
      }
      if (Object.keys(pagePatch).length) {
        await pagesService.update(actor, id, pagePatch, PRODUCT_KIND);
      }

      const commerce = await this.ensureCommerce(actor.siteId, id);
      const type = body.commerce?.type ?? commerce.type;
      if (body.commerce) this.validateCommerce(body.commerce, body.variants, type);

      await sequelize.transaction(async (transaction) => {
        if (body.commerce) {
          const c = body.commerce;
          const patch: Partial<ShopProduct> = {};
          if (c.type !== undefined) patch.type = c.type;
          if (c.sku !== undefined) patch.sku = c.sku.trim();
          if (c.regularPrice !== undefined) patch.regularPrice = c.regularPrice;
          if (c.salePrice !== undefined) patch.salePrice = c.salePrice;
          if (c.saleFrom !== undefined) patch.saleFrom = dateOrNull(c.saleFrom) ?? null;
          if (c.saleTo !== undefined) patch.saleTo = dateOrNull(c.saleTo) ?? null;
          if (c.manageStock !== undefined) patch.manageStock = c.manageStock;
          if (c.stockQty !== undefined) patch.stockQty = c.stockQty;
          if (c.stockStatus !== undefined) patch.stockStatus = c.stockStatus;
          if (c.lowStockThreshold !== undefined) patch.lowStockThreshold = c.lowStockThreshold;
          if (c.soldIndividually !== undefined) patch.soldIndividually = c.soldIndividually;
          if (c.weight !== undefined) patch.weight = c.weight;
          if (c.length !== undefined) patch.length = c.length;
          if (c.width !== undefined) patch.width = c.width;
          if (c.height !== undefined) patch.height = c.height;
          if (c.virtual !== undefined) patch.virtual = c.virtual;
          if (c.taxable !== undefined) patch.taxable = c.taxable;
          if (c.galleryIds !== undefined) patch.galleryIds = c.galleryIds;
          if (c.attributes !== undefined) patch.attributes = c.attributes;
          if (c.purchaseNote !== undefined) patch.purchaseNote = c.purchaseNote.trim();
          if (c.featured !== undefined) patch.featured = c.featured;
          if (c.catalogVisibility !== undefined) patch.catalogVisibility = c.catalogVisibility;
          const manage = patch.manageStock ?? commerce.manageStock;
          if (!manage) patch.stockQty = null;
          else if ((patch.stockQty ?? commerce.stockQty) == null) patch.stockQty = 0;
          await commerce.update(patch, { transaction });
        }
        if (body.variants !== undefined) {
          await this.syncVariants(actor.siteId, commerce.id, type === 'variable' ? body.variants : [], transaction);
        }
      });

      if (body.categoryIds !== undefined || body.tagIds !== undefined) {
        const taxonomies = await Taxonomy.findAll({
          where: { siteId: actor.siteId, slug: { [Op.in]: [PRODUCT_CATEGORY_TAXONOMY, PRODUCT_TAG_TAXONOMY] } },
        });
        const assignments: { taxonomyId: string; termIds: string[] }[] = [];
        for (const tax of taxonomies) {
          if (tax.slug === PRODUCT_CATEGORY_TAXONOMY && body.categoryIds !== undefined) {
            assignments.push({ taxonomyId: tax.id, termIds: body.categoryIds });
          }
          if (tax.slug === PRODUCT_TAG_TAXONOMY && body.tagIds !== undefined) {
            assignments.push({ taxonomyId: tax.id, termIds: body.tagIds });
          }
        }
        if (assignments.length) await setPostTaxonomies(id, actor.siteId, PRODUCT_KIND, assignments);
      }

      const fresh = await this.get(actor, id);
      this.bust([fresh.slug, previousSlug]);
      await this.audit(actor, 'product.updated', { id, title: fresh.title });
      return fresh;
    } catch (error) {
      throw toHttpError(error, 'Could not save the product.');
    }
  }

  async remove(actor: AuthUser, id: string, opts: { force?: boolean } = {}) {
    try {
      const row = await Post.findOne({ where: { id, siteId: actor.siteId, type: PRODUCT_KIND } });
      const result = await pagesService.remove(actor, id, PRODUCT_KIND, opts);
      if (row) this.bust([row.slug]);
      await this.audit(actor, result.permanent ? 'product.deleted' : 'product.trashed', { id });
      return result;
    } catch (error) {
      throw toHttpError(error, 'Could not delete the product.');
    }
  }

  async restore(actor: AuthUser, id: string) {
    try {
      await pagesService.restore(actor, id, PRODUCT_KIND);
      await this.audit(actor, 'product.restored', { id });
      return this.get(actor, id);
    } catch (error) {
      throw toHttpError(error, 'Could not restore the product.');
    }
  }

  async bulk(actor: AuthUser, ids: string[], action: 'publish' | 'draft' | 'trash' | 'restore' | 'delete') {
    const done: string[] = [];
    const failed: { id: string; message: string }[] = [];
    for (const id of ids) {
      try {
        if (action === 'publish' || action === 'draft') {
          await pagesService.update(actor, id, { status: action }, PRODUCT_KIND);
        } else if (action === 'trash') await pagesService.remove(actor, id, PRODUCT_KIND);
        else if (action === 'delete') await pagesService.remove(actor, id, PRODUCT_KIND, { force: true });
        else await pagesService.restore(actor, id, PRODUCT_KIND);
        done.push(id);
      } catch (e) {
        failed.push({ id, message: (e as Error).message });
      }
    }
    await this.audit(actor, `product.bulk_${action}`, { ids: done });
    void revalidatePublicPaths([SHOP_PATHS.shop]);
    return { done, failed };
  }

  async duplicate(actor: AuthUser, id: string) {
    try {
      const source = await this.get(actor, id);
      const copy = await pagesService.create(
        actor,
        {
          title: `${source.title || 'Product'} (copy)`,
          status: 'draft',
          content: source.description,
          excerpt: source.shortDescription,
          featuredImageId: source.featuredImageId ?? '',
        },
        PRODUCT_KIND,
      );
      const { id: _id, totalSales: _sales, gallery: _gallery, ...commerce } = source.commerce;
      const commerceInput = {
        ...commerce,
        sku: commerce.sku ? `${commerce.sku}-copy` : '',
      } as unknown as ProductCommerceInput;
      const variantInput = source.variants.map(({ id: _vid, image: _img, ...v }) => ({
        ...v,
        sku: v.sku ? `${v.sku}-copy` : '',
      })) as unknown as ProductVariantInput[];
      await this.update(actor, copy.id, {
        commerce: commerceInput,
        variants: variantInput,
        categoryIds: source.categoryIds,
        tagIds: source.tagIds,
      });
      await this.audit(actor, 'product.duplicated', { from: id, id: copy.id });
      return this.get(actor, copy.id);
    } catch (error) {
      throw toHttpError(error, 'Could not duplicate the product.');
    }
  }

  /** Small rows for pickers (coupon restrictions, related products). */
  async lookup(actor: AuthUser, opts: { q?: string; ids?: string[] }) {
    try {
      const where: WhereOptions = { siteId: actor.siteId, type: PRODUCT_KIND, status: { [Op.notIn]: ['auto-draft', 'trash'] } };
      if (opts.ids?.length) Object.assign(where, { id: { [Op.in]: opts.ids.slice(0, 200) } });
      else if (opts.q) Object.assign(where, { title: { [Op.iLike]: `%${opts.q.replace(/[%_\\]/g, '\\$&')}%` } });
      const rows = await Post.findAll({
        where,
        include: [{ model: ShopProduct, as: 'shopProduct', attributes: ['sku', 'regularPrice', 'type'] }],
        order: [['title', 'ASC']],
        limit: 50,
      });
      return {
        items: rows.map((r) => {
          const c = (r as Post & { shopProduct?: ShopProduct }).shopProduct;
          return { id: r.id, title: r.title, slug: r.slug, status: r.status, sku: c?.sku ?? '', regularPrice: c?.regularPrice ?? null, type: c?.type ?? 'simple' };
        }),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not search products.');
    }
  }
}

export const productsService = new ProductsService();
