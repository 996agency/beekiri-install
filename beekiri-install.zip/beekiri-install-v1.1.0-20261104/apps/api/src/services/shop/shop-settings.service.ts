import type { Transaction } from 'sequelize';
import { CURRENCIES } from '../../lib/shop/money';
import { secretsPersist } from '../../lib/shop/secrets';
import {
  defaultShopSettings,
  maskShopSettings,
  parseShopSettings,
  readSecret,
  storableShopSettings,
  type ShopSettings,
} from '../../lib/shop/settings';
import { AuditLog, ShopSetting } from '../../models';
import type { AuthUser } from '../../types/auth';
import { toHttpError } from '../../utils/http-error';
import { findPrimarySite } from '../site-context';

export class ShopSettingsService {
  /** Parsed settings for the primary site (defaults when the row is missing). */
  async get(siteId?: string, transaction?: Transaction): Promise<ShopSettings> {
    const id = siteId ?? (await findPrimarySite())?.id;
    if (!id) return defaultShopSettings();
    const row = await ShopSetting.findOne({ where: { siteId: id }, transaction });
    return parseShopSettings(row?.data);
  }

  /** Settings row, locked for update (order numbers). */
  async lockRow(siteId: string, transaction: Transaction): Promise<ShopSetting> {
    const [row] = await ShopSetting.findOrCreate({
      where: { siteId },
      defaults: { siteId, data: defaultShopSettings(), nextOrderNumber: 1 },
      transaction,
      lock: transaction.LOCK.UPDATE,
    });
    return row;
  }

  /** For the admin screen: secrets masked + environment hints. */
  async getForAdmin(actor: AuthUser) {
    try {
      const settings = await this.get(actor.siteId);
      return {
        settings: maskShopSettings(settings),
        meta: {
          currencies: CURRENCIES,
          secretsPersist: secretsPersist(),
          stripeConfigured: Boolean(readSecret(settings, 'payments.stripe.secretKey')),
        },
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load the shop settings.');
    }
  }

  async update(actor: AuthUser, incoming: ShopSettings, ip?: string) {
    try {
      const current = await this.get(actor.siteId);
      const next = storableShopSettings(incoming, current);
      const [row] = await ShopSetting.findOrCreate({
        where: { siteId: actor.siteId },
        defaults: { siteId: actor.siteId, data: next, nextOrderNumber: next.advanced.orderNumberStart },
      });
      const nextOrderNumber = Math.max(row.nextOrderNumber, next.advanced.orderNumberStart);
      await row.update({ data: next, nextOrderNumber });
      await AuditLog.create({
        siteId: actor.siteId,
        userId: actor.id,
        action: 'shop.settings_updated',
        meta: { sections: Object.keys(incoming) },
        ip: ip ?? null,
      });
      return this.getForAdmin(actor);
    } catch (error) {
      throw toHttpError(error, 'Could not save the shop settings.');
    }
  }
}

export const shopSettingsService = new ShopSettingsService();
