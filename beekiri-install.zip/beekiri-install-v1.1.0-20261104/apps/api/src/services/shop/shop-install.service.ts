import { Op } from 'sequelize';
import { revalidatePublicPaths } from '../../lib/revalidate-public';
import {
  PRODUCT_CATEGORY_TAXONOMY,
  PRODUCT_KIND,
  PRODUCT_TAG_TAXONOMY,
  SHOP_PAGE_KIND,
  SHOP_PATHS,
} from '../../lib/shop/constants';
import { defaultShopSettings, parseShopSettings } from '../../lib/shop/settings';
import {
  Post,
  PostType,
  sequelize,
  ShopCart,
  ShopCoupon,
  ShopCustomer,
  ShopOrder,
  ShopPaymentEvent,
  ShopProduct,
  ShopSetting,
  Taxonomy,
  Term,
} from '../../models';
import type { AuthUser } from '../../types/auth';
import { toHttpError } from '../../utils/http-error';
import { createLogger } from '../../utils/logger';
import { shopPagesService } from './shop-pages.service';

const log = createLogger('shop');

/**
 * What installing / activating Shopping does to the site: the `product` post type,
 * the product category + tag taxonomies and a settings row. Nothing here is
 * destructive except `uninstall({ deleteData: true })`.
 */
export class ShopInstallService {
  /** Idempotent: safe to call on every activate. */
  async ensureStructure(siteId: string): Promise<void> {
    await sequelize.transaction(async (transaction) => {
      const [postType] = await PostType.findOrCreate({
        where: { siteId, slug: PRODUCT_KIND },
        defaults: {
          siteId,
          slug: PRODUCT_KIND,
          singular: 'Product',
          plural: 'Products',
          description: 'Items for sale (Shopping extension).',
          public: true,
          hierarchical: false,
          hasArchive: false,
          showInMenu: false,
          supports: ['title', 'editor', 'excerpt', 'thumbnail'],
          active: true,
          menuOrder: 0,
          menuIcon: 'ShoppingBag',
          archiveDesign: 'grid',
          singleDesign: 'default',
        },
        transaction,
      });
      if (!postType.active || !postType.public) {
        await postType.update({ active: true, public: true }, { transaction });
      }

      await Taxonomy.findOrCreate({
        where: { siteId, slug: PRODUCT_CATEGORY_TAXONOMY },
        defaults: {
          siteId,
          slug: PRODUCT_CATEGORY_TAXONOMY,
          singular: 'Product category',
          plural: 'Product categories',
          description: 'Organise products into categories (Shopping extension).',
          hierarchical: true,
          public: true,
          objectTypes: [PRODUCT_KIND],
          active: true,
          menuOrder: 50,
        },
        transaction,
      });
      await Taxonomy.findOrCreate({
        where: { siteId, slug: PRODUCT_TAG_TAXONOMY },
        defaults: {
          siteId,
          slug: PRODUCT_TAG_TAXONOMY,
          singular: 'Product tag',
          plural: 'Product tags',
          description: 'Free-form product tags (Shopping extension).',
          hierarchical: false,
          public: true,
          objectTypes: [PRODUCT_KIND],
          active: true,
          menuOrder: 51,
        },
        transaction,
      });
      // Make sure both taxonomies target products even if someone edited them.
      const taxonomies = await Taxonomy.findAll({
        where: { siteId, slug: { [Op.in]: [PRODUCT_CATEGORY_TAXONOMY, PRODUCT_TAG_TAXONOMY] } },
        transaction,
      });
      for (const tax of taxonomies) {
        const types = Array.isArray(tax.objectTypes) ? tax.objectTypes.map(String) : [];
        if (!types.includes(PRODUCT_KIND) || !tax.active) {
          await tax.update(
            { objectTypes: [...new Set([...types, PRODUCT_KIND])], active: true },
            { transaction },
          );
        }
      }

      const [settings] = await ShopSetting.findOrCreate({
        where: { siteId },
        defaults: { siteId, data: defaultShopSettings(), nextOrderNumber: 1 },
        transaction,
      });
      const parsed = parseShopSettings(settings.data);
      if (settings.nextOrderNumber < parsed.advanced.orderNumberStart) {
        await settings.update({ nextOrderNumber: parsed.advanced.orderNumberStart }, { transaction });
      }
      await shopPagesService.ensurePages(siteId, transaction);
    });
  }

  async install(actor: AuthUser): Promise<void> {
    try {
      await this.ensureStructure(actor.siteId);
      log.info('Shopping structure created (product post type, taxonomies, settings).');
    } catch (error) {
      throw toHttpError(error, 'Could not set up the shop.');
    }
  }

  async activate(actor: AuthUser): Promise<void> {
    try {
      await this.ensureStructure(actor.siteId);
      await PostType.update({ active: true }, { where: { siteId: actor.siteId, slug: PRODUCT_KIND } });
      void revalidatePublicPaths([SHOP_PATHS.shop, SHOP_PATHS.cart, SHOP_PATHS.checkout, '/']);
    } catch (error) {
      throw toHttpError(error, 'Could not activate the shop.');
    }
  }

  /** Hides the storefront and the admin screens; keeps every row. */
  async deactivate(actor: AuthUser): Promise<void> {
    try {
      await PostType.update({ active: false }, { where: { siteId: actor.siteId, slug: PRODUCT_KIND } });
      void revalidatePublicPaths([SHOP_PATHS.shop, SHOP_PATHS.cart, SHOP_PATHS.checkout, '/']);
    } catch (error) {
      throw toHttpError(error, 'Could not deactivate the shop.');
    }
  }

  /** With deleteData: products, orders, customers, coupons, carts and settings are removed. */
  async uninstall(actor: AuthUser, opts: { deleteData: boolean }): Promise<void> {
    try {
      const siteId = actor.siteId;
      // Settings → Advanced → "Remove data on uninstall" also triggers the clean-up.
      const row = await ShopSetting.findOne({ where: { siteId } });
      const deleteData = opts.deleteData || parseShopSettings(row?.data).advanced.removeDataOnUninstall;
      if (!deleteData) return;
      await sequelize.transaction(async (transaction) => {
        await ShopPaymentEvent.destroy({ where: { siteId }, transaction });
        await ShopOrder.destroy({ where: { siteId }, transaction }); // items + notes cascade
        await ShopCustomer.destroy({ where: { siteId }, transaction });
        await ShopCoupon.destroy({ where: { siteId }, transaction });
        await ShopCart.destroy({ where: { siteId }, transaction });
        await ShopProduct.destroy({ where: { siteId }, transaction }); // variants cascade
        await Post.destroy({ where: { siteId, type: PRODUCT_KIND }, transaction });
        await Post.destroy({ where: { siteId, type: SHOP_PAGE_KIND }, transaction });
        const taxonomies = await Taxonomy.findAll({
          where: { siteId, slug: { [Op.in]: [PRODUCT_CATEGORY_TAXONOMY, PRODUCT_TAG_TAXONOMY] } },
          transaction,
        });
        for (const tax of taxonomies) {
          await Term.destroy({ where: { taxonomyId: tax.id }, transaction });
          await tax.destroy({ transaction });
        }
        await PostType.destroy({ where: { siteId, slug: PRODUCT_KIND }, transaction });
        await ShopSetting.destroy({ where: { siteId }, transaction });
      });
      log.warn('Shopping data removed on uninstall.');
    } catch (error) {
      throw toHttpError(error, 'Could not remove the shop data.');
    }
  }
}

export const shopInstallService = new ShopInstallService();
