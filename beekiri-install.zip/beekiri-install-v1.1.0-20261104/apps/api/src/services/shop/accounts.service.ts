import { Op } from 'sequelize';
import { config } from '../../config/env';
import { ACCOUNT_PATH, SHOP_PATHS } from '../../lib/shop/constants';
import { renderAccountEmail } from '../../lib/shop/emails';
import { formatMoney } from '../../lib/shop/money';
import { moneyFormatOf } from '../../lib/shop/settings';
import { buildTracking } from '../../lib/shop/tracking';
import { sequelize, ShopCustomer, ShopCustomerSession, ShopCustomerToken, ShopOrder, ShopOrderItem } from '../../models';
import { hashPassword, passwordStrength, randomToken, sha256, verifyPassword } from '../../utils/crypto';
import { BadRequest, Conflict, Forbidden, NotFound, TooManyRequests, Unauthorized, toHttpError } from '../../utils/http-error';
import { createLogger } from '../../utils/logger';
import { rateLimit } from '../../utils/rate-limit';
import { mailService } from '../mail.service';
import { findPrimarySite } from '../site-context';
import { orderNumberLabel } from '../../lib/shop/emails';
import { paymentTitle } from './orders.service';
import { shopSettingsService } from './shop-settings.service';

/**
 * Shopper accounts (My account). Separate from admin users: a shopper is a
 * ShopCustomer row with a password. Order history and saved addresses are only
 * shown after the email is verified, because guest orders are linked by email and
 * anyone could register with someone else's address.
 */

const log = createLogger('shop-accounts');

const SESSION_DAYS = 30;
const SESSION_SHORT_HOURS = 24;
const VERIFY_TTL_MS = 48 * 60 * 60 * 1000;
const RESET_TTL_MS = 60 * 60 * 1000;
const LOGIN_LIMIT = { max: 10, windowMs: 15 * 60 * 1000 };
const LOGIN_ACCOUNT_LIMIT = { max: 30, windowMs: 15 * 60 * 1000 };
const REGISTER_LIMIT = { max: 8, windowMs: 60 * 60 * 1000 };
const MAIL_LIMIT = { max: 5, windowMs: 15 * 60 * 1000 };

/** Unknown emails still pay for one argon2 verify so timing does not reveal accounts. */
let dummyHash: Promise<string> | null = null;
const dummy = () => (dummyHash ??= hashPassword('not-a-real-password-beekiri'));

type Meta = { ip?: string; userAgent?: string };
export type AddressInput = Partial<Record<'firstName' | 'lastName' | 'company' | 'line1' | 'line2' | 'city' | 'state' | 'postcode' | 'country' | 'phone', string>>;

function cleanAddress(a: AddressInput | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  for (const k of ['firstName', 'lastName', 'company', 'line1', 'line2', 'city', 'state', 'postcode', 'country', 'phone'] as const) {
    out[k] = String(a?.[k] ?? '').trim().slice(0, 200);
  }
  out.country = out.country.toUpperCase().slice(0, 2);
  return out;
}

function assertPassword(password: string) {
  if (password.length < 8) throw BadRequest('Use at least 8 characters for your password.');
  if (passwordStrength(password) === 'weak') throw BadRequest('That password is too easy to guess. Mix letters, numbers and symbols.');
}

function appUrl() {
  return (config.urls.app ?? '').replace(/\/+$/, '');
}

export class AccountsService {
  /** Customer rows resolved from an admin session (this request only). */
  private staffRows = new WeakSet<ShopCustomer>();

  isStaff(customer: ShopCustomer): boolean {
    return this.staffRows.has(customer);
  }

  /**
   * Admin users (Owner, administrators, shop managers…) are signed in to the shop with
   * the same login: their customer record is the one with their admin email. Their email
   * is trusted (staff accounts are created by the site), so it counts as verified.
   */
  async forStaff(user: { siteId: string; email: string; displayName: string; username: string }): Promise<ShopCustomer | null> {
    const email = user.email.trim().toLowerCase();
    if (!email) return null;
    const [first, ...rest] = (user.displayName || user.username || '').trim().split(/\s+/);
    const [row] = await ShopCustomer.findOrCreate({
      where: { siteId: user.siteId, email },
      defaults: { siteId: user.siteId, email, firstName: first ?? '', lastName: rest.join(' '), emailVerifiedAt: new Date() },
    });
    const patch: Partial<ShopCustomer> = {};
    if (!row.emailVerifiedAt) patch.emailVerifiedAt = new Date();
    if (!row.firstName && first) patch.firstName = first;
    if (!row.lastName && rest.length) patch.lastName = rest.join(' ');
    if (Object.keys(patch).length) await row.update(patch);
    this.staffRows.add(row);
    return row;
  }

  /* ── Sessions ─────────────────────────────────────────────────────── */

  private async createSession(customer: ShopCustomer, remember: boolean, meta: Meta) {
    const token = randomToken(32);
    const ms = remember ? SESSION_DAYS * 24 * 3600_000 : SESSION_SHORT_HOURS * 3600_000;
    await ShopCustomerSession.create({
      siteId: customer.siteId,
      customerId: customer.id,
      tokenHash: sha256(token),
      expiresAt: new Date(Date.now() + ms),
      userAgent: (meta.userAgent ?? '').slice(0, 300),
      ip: (meta.ip ?? '').slice(0, 64),
    });
    await customer.update({ lastLoginAt: new Date() });
    return { token, maxAgeMs: ms };
  }

  /** The signed-in shopper behind a cookie token, or null. */
  async resolve(siteId: string, token: string | undefined): Promise<ShopCustomer | null> {
    if (!token || token.length > 100 || !/^[A-Za-z0-9_-]+$/.test(token)) return null;
    const session = await ShopCustomerSession.findOne({ where: { tokenHash: sha256(token), siteId } });
    if (!session) return null;
    if (session.expiresAt.getTime() < Date.now()) {
      await session.destroy();
      return null;
    }
    const customer = await ShopCustomer.findOne({ where: { id: session.customerId, siteId } });
    if (!customer?.passwordHash) return null;
    // Touch at most every 5 minutes.
    if (Date.now() - session.lastSeenAt.getTime() > 5 * 60_000) await session.update({ lastSeenAt: new Date() });
    return customer;
  }

  async logout(token: string | undefined) {
    if (!token) return;
    await ShopCustomerSession.destroy({ where: { tokenHash: sha256(token) } });
  }

  /* ── Register / login ─────────────────────────────────────────────── */

  async register(
    siteId: string,
    input: { email: string; password: string; firstName: string; lastName: string; remember?: boolean },
    meta: Meta,
  ) {
    try {
      const settings = await shopSettingsService.get(siteId);
      if (!settings.accounts.enabled || !settings.accounts.allowRegistration) throw Forbidden('Registration is closed.');
      if (!rateLimit(`shop-register:${meta.ip ?? 'unknown'}`, REGISTER_LIMIT.max, REGISTER_LIMIT.windowMs).ok) {
        throw TooManyRequests('Too many sign-ups from this address. Please try again later.');
      }
      const email = input.email.trim().toLowerCase();
      assertPassword(input.password);
      const passwordHash = await hashPassword(input.password);
      const customer = await sequelize.transaction(async (t) => {
        const existing = await ShopCustomer.findOne({ where: { siteId, email }, transaction: t, lock: t.LOCK.UPDATE });
        if (existing?.passwordHash) throw Conflict('An account with this email already exists. Sign in or reset your password.');
        if (existing) {
          // A guest who ordered before: the account is created, but past orders stay hidden until verified.
          await existing.update(
            { passwordHash, firstName: input.firstName.trim() || existing.firstName, lastName: input.lastName.trim() || existing.lastName, emailVerifiedAt: null },
            { transaction: t },
          );
          return existing;
        }
        return ShopCustomer.create(
          { siteId, email, firstName: input.firstName.trim(), lastName: input.lastName.trim(), passwordHash },
          { transaction: t },
        );
      });
      void this.sendVerify(customer);
      const session = await this.createSession(customer, Boolean(input.remember), meta);
      return { customer, ...session };
    } catch (error) {
      throw toHttpError(error, 'Could not create the account.');
    }
  }

  async login(siteId: string, input: { email: string; password: string; remember?: boolean }, meta: Meta) {
    try {
      const settings = await shopSettingsService.get(siteId);
      if (!settings.accounts.enabled) throw Forbidden('Customer accounts are turned off.');
      const email = input.email.trim().toLowerCase();
      if (!rateLimit(`shop-login:${meta.ip ?? 'unknown'}`, LOGIN_LIMIT.max, LOGIN_LIMIT.windowMs).ok ||
          !rateLimit(`shop-login-acct:${email}`, LOGIN_ACCOUNT_LIMIT.max, LOGIN_ACCOUNT_LIMIT.windowMs).ok) {
        throw TooManyRequests('Too many sign-in attempts. Please try again in a few minutes.');
      }
      const customer = await ShopCustomer.findOne({ where: { siteId, email } });
      const ok = customer?.passwordHash
        ? await verifyPassword(customer.passwordHash, input.password)
        : (await verifyPassword(await dummy(), input.password), false);
      if (!customer || !ok) throw Unauthorized('The email or password is not correct.');
      const session = await this.createSession(customer, Boolean(input.remember), meta);
      return { customer, ...session };
    } catch (error) {
      throw toHttpError(error, 'Could not sign in.');
    }
  }

  /* ── Email links ──────────────────────────────────────────────────── */

  private async issueToken(customer: ShopCustomer, kind: 'verify' | 'reset') {
    await ShopCustomerToken.update({ usedAt: new Date() }, { where: { customerId: customer.id, kind, usedAt: null } });
    const token = randomToken(32);
    await ShopCustomerToken.create({
      siteId: customer.siteId,
      customerId: customer.id,
      kind,
      tokenHash: sha256(token),
      expiresAt: new Date(Date.now() + (kind === 'verify' ? VERIFY_TTL_MS : RESET_TTL_MS)),
    });
    return token;
  }

  private async mail(customer: ShopCustomer, kind: 'verify' | 'reset', token: string) {
    try {
      const settings = await shopSettingsService.get(customer.siteId);
      const site = await findPrimarySite();
      const link = `${appUrl()}${ACCOUNT_PATH}/${kind === 'verify' ? 'verify' : 'reset'}?token=${encodeURIComponent(token)}`;
      const rendered = renderAccountEmail(kind, settings, { title: site?.title?.trim() || 'Beekiri', url: appUrl() }, { name: customer.firstName, link });
      await mailService.sendMail({ to: customer.email, subject: rendered.subject, text: rendered.text, html: rendered.html });
    } catch (error) {
      log.warn(`Could not send ${kind} email: ${(error as Error).message}`);
    }
  }

  async sendVerify(customer: ShopCustomer) {
    if (customer.emailVerifiedAt) return;
    const token = await this.issueToken(customer, 'verify');
    await this.mail(customer, 'verify', token);
  }

  async resendVerify(customer: ShopCustomer, meta: Meta) {
    if (!rateLimit(`shop-mail:${customer.id}`, MAIL_LIMIT.max, MAIL_LIMIT.windowMs).ok || !rateLimit(`shop-mail-ip:${meta.ip}`, MAIL_LIMIT.max * 2, MAIL_LIMIT.windowMs).ok) {
      throw TooManyRequests('Please wait a few minutes before asking for another email.');
    }
    await this.sendVerify(customer);
    return { ok: true };
  }

  private async consume(siteId: string, token: string, kind: 'verify' | 'reset') {
    if (!token || token.length > 100) throw BadRequest('This link is not valid.');
    const row = await ShopCustomerToken.findOne({ where: { siteId, kind, tokenHash: sha256(token) } });
    if (!row || row.usedAt || row.expiresAt.getTime() < Date.now()) {
      throw BadRequest(kind === 'verify' ? 'This confirmation link has expired. Sign in and ask for a new one.' : 'This reset link has expired. Ask for a new one.');
    }
    await row.update({ usedAt: new Date() });
    const customer = await ShopCustomer.findOne({ where: { id: row.customerId, siteId } });
    if (!customer) throw BadRequest('This link is not valid.');
    return customer;
  }

  async verify(siteId: string, token: string) {
    try {
      const customer = await this.consume(siteId, token, 'verify');
      await customer.update({ emailVerifiedAt: new Date() });
      return { ok: true, email: customer.email };
    } catch (error) {
      throw toHttpError(error, 'Could not confirm the email address.');
    }
  }

  /** Always answers ok, so it cannot be used to discover accounts. */
  async forgotPassword(siteId: string, email: string, meta: Meta) {
    try {
      if (!rateLimit(`shop-forgot:${meta.ip ?? 'unknown'}`, MAIL_LIMIT.max, MAIL_LIMIT.windowMs).ok) {
        throw TooManyRequests('Please wait a few minutes before asking for another email.');
      }
      const customer = await ShopCustomer.findOne({ where: { siteId, email: email.trim().toLowerCase() } });
      if (customer?.passwordHash && rateLimit(`shop-mail:${customer.id}`, MAIL_LIMIT.max, MAIL_LIMIT.windowMs).ok) {
        const token = await this.issueToken(customer, 'reset');
        void this.mail(customer, 'reset', token);
      }
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not send the reset email.');
    }
  }

  async resetPassword(siteId: string, token: string, password: string) {
    try {
      assertPassword(password);
      const customer = await this.consume(siteId, token, 'reset');
      // Getting the link proves the shopper owns the mailbox.
      await customer.update({ passwordHash: await hashPassword(password), emailVerifiedAt: customer.emailVerifiedAt ?? new Date() });
      await ShopCustomerSession.destroy({ where: { customerId: customer.id } });
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not reset the password.');
    }
  }

  async changePassword(customer: ShopCustomer, current: string, next: string, keepToken: string | undefined) {
    try {
      if (this.isStaff(customer)) throw BadRequest('You are signed in with your Beekiri admin account. Change its password in the admin (Users → Your profile).');
      if (!customer.passwordHash || !(await verifyPassword(customer.passwordHash, current))) {
        throw BadRequest('Your current password is not correct.');
      }
      assertPassword(next);
      await customer.update({ passwordHash: await hashPassword(next) });
      // Sign out every other device.
      await ShopCustomerSession.destroy({
        where: { customerId: customer.id, ...(keepToken ? { tokenHash: { [Op.ne]: sha256(keepToken) } } : {}) },
      });
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not change the password.');
    }
  }

  /* ── Profile ──────────────────────────────────────────────────────── */

  serialize(customer: ShopCustomer) {
    const verified = Boolean(customer.emailVerifiedAt);
    return {
      id: customer.id,
      email: customer.email,
      firstName: customer.firstName,
      lastName: customer.lastName,
      name: [customer.firstName, customer.lastName].filter(Boolean).join(' ') || customer.email,
      verified,
      /** Signed in through the Beekiri admin (same login). */
      staff: this.isStaff(customer),
      // Saved data may come from guest orders: only shown to the verified owner.
      phone: verified ? customer.phone : '',
      billing: verified ? cleanAddress(customer.billing as AddressInput) : cleanAddress({}),
      shipping: verified ? cleanAddress(customer.shipping as AddressInput) : cleanAddress({}),
      ordersCount: verified ? customer.ordersCount : 0,
      memberSince: customer.createdAt.toISOString(),
    };
  }

  async updateDetails(customer: ShopCustomer, input: { firstName?: string; lastName?: string; phone?: string }) {
    try {
      const patch: Partial<ShopCustomer> = {};
      if (input.firstName !== undefined) patch.firstName = input.firstName.trim().slice(0, 80);
      if (input.lastName !== undefined) patch.lastName = input.lastName.trim().slice(0, 80);
      if (input.phone !== undefined) patch.phone = input.phone.trim().slice(0, 40);
      await customer.update(patch);
      return this.serialize(customer);
    } catch (error) {
      throw toHttpError(error, 'Could not save your details.');
    }
  }

  async updateAddresses(customer: ShopCustomer, input: { billing?: AddressInput; shipping?: AddressInput }) {
    try {
      if (!customer.emailVerifiedAt) throw Forbidden('Confirm your email address first.');
      const patch: Partial<ShopCustomer> = {};
      if (input.billing) patch.billing = cleanAddress(input.billing);
      if (input.shipping) patch.shipping = cleanAddress(input.shipping);
      await customer.update(patch);
      return this.serialize(customer);
    } catch (error) {
      throw toHttpError(error, 'Could not save your addresses.');
    }
  }

  /* ── Orders ───────────────────────────────────────────────────────── */

  private async orderSummary(order: ShopOrder, items: ShopOrderItem[]) {
    const settings = await shopSettingsService.get(order.siteId);
    const fmt = { ...moneyFormatOf(settings), currency: order.currency };
    const virtual = items.length > 0 && items.every((i) => i.virtual);
    const tracking = buildTracking(order, { virtual });
    return {
      id: order.id,
      number: order.number,
      numberLabel: orderNumberLabel(order, settings),
      status: order.status,
      placedAt: order.placedAt.toISOString(),
      total: formatMoney(order.total, fmt),
      itemCount: items.reduce((a, i) => a + i.qty, 0),
      paymentMethodTitle: paymentTitle(order.paymentMethod, settings),
      tracking,
      path: `${ACCOUNT_PATH}/orders/${order.number}`,
      receiptPath: SHOP_PATHS.orderReceived(order.accessToken),
      items: items.slice(0, 4).map((i) => ({ name: i.name, qty: i.qty, imageUrl: i.imageUrl })),
    };
  }

  async orders(customer: ShopCustomer, page = 1, perPage = 10) {
    try {
      if (!customer.emailVerifiedAt) return { verified: false, items: [], total: 0, page: 1, pages: 1 };
      const { rows, count } = await ShopOrder.findAndCountAll({
        where: { siteId: customer.siteId, customerId: customer.id },
        include: [{ model: ShopOrderItem, as: 'items' }],
        order: [['placedAt', 'DESC']],
        limit: perPage,
        offset: (page - 1) * perPage,
        distinct: true,
      });
      const items = await Promise.all(rows.map((o) => this.orderSummary(o, (o as ShopOrder & { items?: ShopOrderItem[] }).items ?? [])));
      return { verified: true, items, total: count, page, pages: Math.max(1, Math.ceil(count / perPage)) };
    } catch (error) {
      throw toHttpError(error, 'Could not load your orders.');
    }
  }

  /** One of the shopper's own orders, by its number. */
  async order(customer: ShopCustomer, number: number) {
    try {
      if (!customer.emailVerifiedAt) throw Forbidden('Confirm your email address to see your orders.');
      const order = await ShopOrder.findOne({ where: { siteId: customer.siteId, customerId: customer.id, number } });
      if (!order) throw NotFound('Order not found.');
      return order;
    } catch (error) {
      throw toHttpError(error, 'Could not load the order.');
    }
  }
}

export const accountsService = new AccountsService();
