import type { WorkspaceLink } from '../lib/beequeen/workspace';
import { BeeQueenChat, BeeQueenMessage } from '../models';
import type { BeeQueenMessageState } from '../models/beequeen-chat.model';
import type { AuthUser } from '../types/auth';
import { NotFound, toHttpError } from '../utils/http-error';

/** Earlier turns sent back to the model with each new message. */
const HISTORY_TURNS = 30;

export type ChatTurn = { role: 'user' | 'assistant'; text: string };

export type RunUsage = {
  inputTokens: number;
  outputTokens: number;
  cacheReadTokens: number;
  cacheWriteTokens: number;
  /** USD cost of the run (Claude Code reports its own estimate; billed runs are priced by Beekiri). */
  costUsd?: number;
  /** Credits charged when pay-as-you-go is on. */
  credits?: number;
};

export type AssistantRecord = {
  text: string;
  state: BeeQueenMessageState;
  steps: { kind: 'status' | 'note'; text: string }[];
  links: WorkspaceLink[];
  model?: string | null;
  usage?: RunUsage | null;
};

function serializeMessage(m: BeeQueenMessage) {
  return {
    id: m.id,
    role: m.role,
    text: m.text,
    steps: m.steps,
    links: m.links,
    state: m.state,
    model: m.model,
    credits: (m.usage as { credits?: number } | null)?.credits ?? undefined,
    createdAt: m.createdAt.toISOString(),
  };
}

function titleFrom(prompt: string): string {
  const line = prompt.trim().split('\n')[0] ?? '';
  return line.length > 70 ? `${line.slice(0, 70).trimEnd()}…` : line || 'New chat';
}

class BeeQueenChatsService {
  private async findOwned(actor: AuthUser, id: string) {
    const chat = await BeeQueenChat.findOne({ where: { id, siteId: actor.siteId, userId: actor.id } });
    if (!chat) throw NotFound('Chat not found.');
    return chat;
  }

  async list(actor: AuthUser) {
    try {
      const chats = await BeeQueenChat.findAll({
        where: { siteId: actor.siteId, userId: actor.id },
        order: [['updatedAt', 'DESC']],
        limit: 100,
      });
      return {
        chats: chats.map((c) => ({ id: c.id, title: c.title, updatedAt: c.updatedAt.toISOString() })),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load your BeeQueen chats.');
    }
  }

  async get(actor: AuthUser, id: string) {
    try {
      const chat = await this.findOwned(actor, id);
      const messages = await BeeQueenMessage.findAll({ where: { chatId: chat.id }, order: [['createdAt', 'ASC']] });
      return { id: chat.id, title: chat.title, messages: messages.map(serializeMessage) };
    } catch (error) {
      throw toHttpError(error, 'Could not open this chat.');
    }
  }

  async remove(actor: AuthUser, id: string) {
    try {
      const chat = await this.findOwned(actor, id);
      await chat.destroy();
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not delete this chat.');
    }
  }

  /**
   * Opens a turn: continues the user's chat (or starts one), stores the prompt, and
   * returns the earlier turns the model should see.
   */
  async beginTurn(actor: AuthUser, chatId: string | undefined, prompt: string) {
    try {
      const chat = chatId
        ? await this.findOwned(actor, chatId)
        : await BeeQueenChat.create({ siteId: actor.siteId, userId: actor.id, title: titleFrom(prompt) });
      const earlier = await BeeQueenMessage.findAll({
        where: { chatId: chat.id },
        order: [['createdAt', 'DESC']],
        limit: HISTORY_TURNS,
      });
      const history: ChatTurn[] = earlier
        .reverse()
        .filter((m) => m.role === 'user' || (m.state === 'done' && m.text))
        .map((m) => {
          const links = Array.isArray(m.links) ? (m.links as WorkspaceLink[]) : [];
          const saved = links.map((l) => `${l.kind} "${l.label}"${l.admin ? ` (${l.admin})` : ''}`);
          return {
            role: m.role,
            text: saved.length ? `${m.text}\n\n[Saved: ${saved.join('; ')}]` : m.text,
          };
        });
      await BeeQueenMessage.create({ chatId: chat.id, role: 'user', text: prompt.trim() });
      chat.changed('updatedAt', true);
      await chat.save();
      return { chat: { id: chat.id, title: chat.title }, history };
    } catch (error) {
      throw toHttpError(error, 'Could not start this chat turn.');
    }
  }

  /** Stores BeeQueen's side of the turn — also when it failed or was stopped. */
  async finishTurn(chatId: string, record: AssistantRecord) {
    await BeeQueenMessage.create({
      chatId,
      role: 'assistant',
      text: record.text,
      state: record.state,
      steps: record.steps,
      links: record.links,
      model: record.model ?? null,
      usage: record.usage ?? null,
    });
    await BeeQueenChat.update({ updatedAt: new Date() }, { where: { id: chatId } });
  }
}

export const beeQueenChatsService = new BeeQueenChatsService();
