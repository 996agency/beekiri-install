import { RESERVED_CONTENT_SLUGS } from '../lib/pages/content-kind';
import {
  PRODUCT_CATEGORY_TAXONOMY,
  PRODUCT_KIND,
  PRODUCT_TAG_TAXONOMY,
  SHOP_EXTENSION_SLUG,
} from '../lib/shop/constants';
import { extensionsService } from './extensions.service';
import { removeCptThemeTemplates, syncCptThemeTemplates } from '../lib/site/cpt-theme-sync';
import { mergeSiteOptions, readOptions } from '../lib/site/site-options';
import { AuditLog, OptionsPage, PostType, SiteSettings, Taxonomy } from '../models';
import type { AuthUser } from '../types/auth';
import { uniqueViolation } from '../utils/db-errors';
import { BadRequest, Conflict, NotFound, toHttpError } from '../utils/http-error';
import { themesService } from './themes.service';
import type {
  CreateOptionsPageInput,
  CreatePostTypeInput,
  CreateTaxonomyInput,
  FieldsSettingsInput,
  UpdateOptionsPageInput,
  UpdatePostTypeInput,
  UpdateTaxonomyInput,
} from '../validators/structure.schema';

const DEFAULT_SUPPORTS = ['title', 'editor'];
const BY_MENU_ORDER: [string, string][] = [
  ['menuOrder', 'ASC'],
  ['createdAt', 'ASC'],
];

function parseStringArray(raw: unknown, fallback: string[] = []): string[] {
  if (!Array.isArray(raw)) return fallback;
  return raw
    .filter((v): v is string => typeof v === 'string')
    .map((v) => v.trim())
    .filter(Boolean)
    .slice(0, 40);
}

/** A friendly 409 for a duplicate slug, otherwise the error unchanged. */
function duplicateSlugError(error: unknown, label: string): unknown {
  return uniqueViolation(error) !== null
    ? Conflict(`A ${label} with this slug already exists.`)
    : error;
}

/** Copy only the keys the client actually sent, transformed. */
function pick<T extends object>(
  dto: T,
  map: { [K in keyof T]?: (v: NonNullable<T[K]>) => unknown },
) {
  const out: Record<string, unknown> = {};
  for (const key of Object.keys(map) as (keyof T)[]) {
    const value = dto[key];
    if (value !== undefined) out[key as string] = map[key]!(value as NonNullable<T[typeof key]>);
  }
  return out;
}

const trim = (v: string) => v.trim();
const lowerTrim = (v: string) => v.trim().toLowerCase();
const same = <V>(v: V) => v;

function serializePostType(row: PostType) {
  return {
    id: row.id,
    slug: row.slug,
    singular: row.singular,
    plural: row.plural,
    description: row.description,
    public: row.public,
    hierarchical: row.hierarchical,
    hasArchive: row.hasArchive,
    showInMenu: row.showInMenu,
    supports: parseStringArray(row.supports, DEFAULT_SUPPORTS),
    active: row.active,
    menuOrder: row.menuOrder,
    menuIcon: row.menuIcon || 'Cube',
    archiveDesign: row.archiveDesign || 'list',
    singleDesign: row.singleDesign || 'default',
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function serializeTaxonomy(row: Taxonomy) {
  return {
    id: row.id,
    slug: row.slug,
    singular: row.singular,
    plural: row.plural,
    description: row.description,
    hierarchical: row.hierarchical,
    public: row.public,
    objectTypes: parseStringArray(row.objectTypes, ['post']),
    active: row.active,
    menuOrder: row.menuOrder,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function serializeOptionsPage(row: OptionsPage) {
  return {
    id: row.id,
    title: row.title,
    slug: row.slug,
    menuTitle: row.menuTitle || row.title,
    description: row.description,
    parentSlug: row.parentSlug,
    active: row.active,
    menuOrder: row.menuOrder,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export class StructureService {
  /* Post types */

  async listPostTypes(actor: AuthUser) {
    try {
      const rows = await PostType.findAll({
        where: { siteId: actor.siteId },
        order: BY_MENU_ORDER,
      });
      return { postTypes: rows.map(serializePostType) };
    } catch (error) {
      throw toHttpError(error, 'Could not load post types.');
    }
  }

  async createPostType(actor: AuthUser, dto: CreatePostTypeInput) {
    try {
      const slug = lowerTrim(dto.slug);
      if (RESERVED_CONTENT_SLUGS.has(slug)) {
        throw BadRequest('That slug is reserved. Choose a different post type slug.');
      }
      const row = await PostType.create({
        siteId: actor.siteId,
        slug,
        singular: dto.singular.trim(),
        plural: dto.plural.trim(),
        description: (dto.description ?? '').trim(),
        public: dto.public ?? true,
        hierarchical: dto.hierarchical ?? false,
        hasArchive: dto.hasArchive ?? true,
        showInMenu: dto.showInMenu ?? true,
        supports: parseStringArray(dto.supports, DEFAULT_SUPPORTS),
        active: dto.active ?? true,
        menuOrder: await this.nextMenuOrder(PostType, actor.siteId),
        menuIcon: (dto.menuIcon ?? 'Cube').trim() || 'Cube',
        archiveDesign: dto.archiveDesign ?? 'list',
        singleDesign: dto.singleDesign ?? 'default',
      });
      const activeTheme = await themesService.getActiveSlug().catch(() => null);
      await syncCptThemeTemplates(serializePostType(row), activeTheme);
      await this.audit(actor, 'post_type.created', { id: row.id, slug: row.slug });
      return serializePostType(row);
    } catch (error) {
      throw toHttpError(duplicateSlugError(error, 'post type'), 'Could not create the post type.');
    }
  }

  async updatePostType(actor: AuthUser, id: string, dto: UpdatePostTypeInput) {
    try {
      const existing = await PostType.findOne({ where: { id, siteId: actor.siteId } });
      if (!existing) throw NotFound('Post type not found.');
      if (dto.slug !== undefined && RESERVED_CONTENT_SLUGS.has(lowerTrim(dto.slug))) {
        throw BadRequest('That slug is reserved. Choose a different post type slug.');
      }
      if (existing.slug === PRODUCT_KIND && (await this.shopOwnsProducts())) {
        // Shopping manages this type: its slug, visibility and activity stay as the shop needs them.
        if (dto.slug !== undefined && lowerTrim(dto.slug) !== PRODUCT_KIND) {
          throw BadRequest('The product post type belongs to Shopping and cannot be renamed.');
        }
        if (dto.active === false || dto.public === false) {
          throw BadRequest('Deactivate Shopping from Extensions instead of hiding the product post type.');
        }
      }
      const previousSlug = existing.slug;
      const data = pick(dto, {
        slug: lowerTrim,
        singular: trim,
        plural: trim,
        description: trim,
        public: same,
        hierarchical: same,
        hasArchive: same,
        showInMenu: same,
        supports: (v) => parseStringArray(v, DEFAULT_SUPPORTS),
        active: same,
        menuIcon: trim,
        archiveDesign: same,
        singleDesign: same,
      });
      const [, [row]] = await PostType.update(data, {
        where: { id: existing.id },
        returning: true,
      });
      const activeTheme = await themesService.getActiveSlug().catch(() => null);
      if (row.slug !== previousSlug) {
        await removeCptThemeTemplates(previousSlug, undefined, activeTheme);
      }
      await syncCptThemeTemplates(serializePostType(row), activeTheme);
      await this.audit(actor, 'post_type.updated', { id: row.id, slug: row.slug });
      return serializePostType(row);
    } catch (error) {
      throw toHttpError(duplicateSlugError(error, 'post type'), 'Could not update the post type.');
    }
  }

  async removePostType(actor: AuthUser, id: string) {
    try {
      const existing = await PostType.findOne({ where: { id, siteId: actor.siteId } });
      if (!existing) throw NotFound('Post type not found.');
      if (existing.slug === PRODUCT_KIND && (await this.shopOwnsProducts())) {
        throw BadRequest('The product post type belongs to Shopping. Uninstall Shopping from Extensions to remove it.');
      }
      const slug = existing.slug;
      await existing.destroy();
      const activeTheme = await themesService.getActiveSlug().catch(() => null);
      await removeCptThemeTemplates(slug, undefined, activeTheme);
      await this.audit(actor, 'post_type.deleted', { id: existing.id, slug });
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not delete the post type.');
    }
  }

  /** True while the Shopping extension is installed (active or not). */
  private async shopOwnsProducts(): Promise<boolean> {
    const state = await extensionsService.readState().catch(() => ({}));
    return Boolean((state as Record<string, unknown>)[SHOP_EXTENSION_SLUG]);
  }

  /* Taxonomies */

  async listTaxonomies(actor: AuthUser) {
    try {
      const rows = await Taxonomy.findAll({
        where: { siteId: actor.siteId },
        order: BY_MENU_ORDER,
      });
      return { taxonomies: rows.map(serializeTaxonomy) };
    } catch (error) {
      throw toHttpError(error, 'Could not load taxonomies.');
    }
  }

  async createTaxonomy(actor: AuthUser, dto: CreateTaxonomyInput) {
    try {
      const row = await Taxonomy.create({
        siteId: actor.siteId,
        slug: lowerTrim(dto.slug),
        singular: dto.singular.trim(),
        plural: dto.plural.trim(),
        description: (dto.description ?? '').trim(),
        hierarchical: dto.hierarchical ?? true,
        public: dto.public ?? true,
        objectTypes: parseStringArray(dto.objectTypes, ['post']),
        active: dto.active ?? true,
        menuOrder: await this.nextMenuOrder(Taxonomy, actor.siteId),
      });
      await this.audit(actor, 'taxonomy.created', { id: row.id, slug: row.slug });
      return serializeTaxonomy(row);
    } catch (error) {
      throw toHttpError(duplicateSlugError(error, 'taxonomy'), 'Could not create the taxonomy.');
    }
  }

  async updateTaxonomy(actor: AuthUser, id: string, dto: UpdateTaxonomyInput) {
    try {
      const existing = await Taxonomy.findOne({ where: { id, siteId: actor.siteId } });
      if (!existing) throw NotFound('Taxonomy not found.');
      const data = pick(dto, {
        slug: lowerTrim,
        singular: trim,
        plural: trim,
        description: trim,
        hierarchical: same,
        public: same,
        objectTypes: (v) => parseStringArray(v, ['post']),
        active: same,
      });
      const [, [row]] = await Taxonomy.update(data, {
        where: { id: existing.id },
        returning: true,
      });
      await this.audit(actor, 'taxonomy.updated', { id: row.id, slug: row.slug });
      return serializeTaxonomy(row);
    } catch (error) {
      throw toHttpError(duplicateSlugError(error, 'taxonomy'), 'Could not update the taxonomy.');
    }
  }

  async removeTaxonomy(actor: AuthUser, id: string) {
    try {
      const existing = await Taxonomy.findOne({ where: { id, siteId: actor.siteId } });
      if (!existing) throw NotFound('Taxonomy not found.');
      if (
        (existing.slug === PRODUCT_CATEGORY_TAXONOMY || existing.slug === PRODUCT_TAG_TAXONOMY) &&
        (await this.shopOwnsProducts())
      ) {
        throw BadRequest('This taxonomy belongs to Shopping. Uninstall Shopping from Extensions to remove it.');
      }
      await existing.destroy();
      await this.audit(actor, 'taxonomy.deleted', { id: existing.id, slug: existing.slug });
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not delete the taxonomy.');
    }
  }

  /* Options pages */

  async listOptionsPages(actor: AuthUser) {
    try {
      const rows = await OptionsPage.findAll({
        where: { siteId: actor.siteId },
        order: BY_MENU_ORDER,
      });
      return { optionsPages: rows.map(serializeOptionsPage) };
    } catch (error) {
      throw toHttpError(error, 'Could not load options pages.');
    }
  }

  async createOptionsPage(actor: AuthUser, dto: CreateOptionsPageInput) {
    try {
      const row = await OptionsPage.create({
        siteId: actor.siteId,
        title: dto.title.trim(),
        slug: lowerTrim(dto.slug),
        menuTitle: (dto.menuTitle ?? dto.title).trim(),
        description: (dto.description ?? '').trim(),
        parentSlug: lowerTrim(dto.parentSlug ?? ''),
        active: dto.active ?? true,
        menuOrder: await this.nextMenuOrder(OptionsPage, actor.siteId),
      });
      await this.audit(actor, 'options_page.created', { id: row.id, slug: row.slug });
      return serializeOptionsPage(row);
    } catch (error) {
      throw toHttpError(
        duplicateSlugError(error, 'options page'),
        'Could not create the options page.',
      );
    }
  }

  async updateOptionsPage(actor: AuthUser, id: string, dto: UpdateOptionsPageInput) {
    try {
      const existing = await OptionsPage.findOne({ where: { id, siteId: actor.siteId } });
      if (!existing) throw NotFound('Options page not found.');
      const data = pick(dto, {
        title: trim,
        slug: lowerTrim,
        menuTitle: trim,
        description: trim,
        parentSlug: lowerTrim,
        active: same,
      });
      const [, [row]] = await OptionsPage.update(data, {
        where: { id: existing.id },
        returning: true,
      });
      await this.audit(actor, 'options_page.updated', { id: row.id, slug: row.slug });
      return serializeOptionsPage(row);
    } catch (error) {
      throw toHttpError(
        duplicateSlugError(error, 'options page'),
        'Could not update the options page.',
      );
    }
  }

  async removeOptionsPage(actor: AuthUser, id: string) {
    try {
      const existing = await OptionsPage.findOne({ where: { id, siteId: actor.siteId } });
      if (!existing) throw NotFound('Options page not found.');
      await existing.destroy();
      await this.audit(actor, 'options_page.deleted', { id: existing.id, slug: existing.slug });
      return { ok: true };
    } catch (error) {
      throw toHttpError(error, 'Could not delete the options page.');
    }
  }

  /* Settings (stored in site options) */

  async getSettings(actor: AuthUser) {
    try {
      const settings = await SiteSettings.findOne({ where: { siteId: actor.siteId } });
      const fields =
        (readOptions(settings?.options).backendFields as Record<string, unknown> | undefined) ?? {};
      return {
        showAdminBar: fields.showAdminBar !== false,
        exportFormat: fields.exportFormat === 'php' ? 'php' : 'json',
        deleteWithContent: Boolean(fields.deleteWithContent),
      };
    } catch (error) {
      throw toHttpError(error, 'Could not load Backend Fields settings.');
    }
  }

  async updateSettings(actor: AuthUser, dto: FieldsSettingsInput) {
    try {
      const settings = await SiteSettings.findOne({ where: { siteId: actor.siteId } });
      if (!settings) throw NotFound('Site settings not found.');
      const prev =
        (readOptions(settings.options).backendFields as Record<string, unknown> | undefined) ?? {};
      const next = {
        ...prev,
        ...pick(dto, { showAdminBar: same, exportFormat: same, deleteWithContent: same }),
      };
      const options = mergeSiteOptions(settings.options, { backendFields: next });
      await SiteSettings.update({ options }, { where: { id: settings.id } });
      return await this.getSettings(actor);
    } catch (error) {
      throw toHttpError(error, 'Could not save Backend Fields settings.');
    }
  }

  private async audit(
    actor: AuthUser,
    action: string,
    meta: Record<string, unknown>,
  ): Promise<void> {
    await AuditLog.create({ siteId: actor.siteId, userId: actor.id, action, meta });
  }

  private async nextMenuOrder(
    model: typeof PostType | typeof Taxonomy | typeof OptionsPage,
    siteId: string,
  ): Promise<number> {
    const max = await (model as typeof PostType).max<number | null, PostType>('menuOrder', {
      where: { siteId },
    });
    return (max ?? -1) + 1;
  }
}

export const structureService = new StructureService();
