import type { ComponentType } from 'react';
import { getI18n, type I18n } from '../lib/i18n';
import type { SiteMenuItem } from '../lib/site-menu';

import { API_URL as API } from '@/lib/env';

type ChromeKind = 'header' | 'footer';

type ChromeRender = {
  kind: ChromeKind;
  theme: string;
  slug: string | null;
  runtime: 'php' | 'react';
  path: string | null;
  html: string | null;
  cssUrl: string | null;
  jsUrl: string | null;
  data: Record<string, unknown>;
};

export type ChromeSite = {
  title?: string;
  tagline?: string;
  blogPublic?: boolean;
  menu?: SiteMenuItem[];
};

async function getChrome(kind: ChromeKind): Promise<ChromeRender | null> {
  try {
    const res = await fetch(`${API}/api/themes/chrome/${kind}/render`, {
      next: { revalidate: 30 },
    });
    if (!res.ok) return null;
    return (await res.json()) as ChromeRender;
  } catch {
    return null;
  }
}

type ChromeMenuRow = { id?: string; label?: string; url?: string; children?: ChromeMenuRow[] };

/** API menu rows (`url`, as PHP templates expect) → React `SiteMenuItem` (`path`). */
function toMenuItems(rows: unknown, i18n: I18n): SiteMenuItem[] {
  if (!Array.isArray(rows)) return [];
  const current = i18n.languages.find((l) => l.code === i18n.language);
  return (rows as ChromeMenuRow[]).map((row, i) => {
    const url = row.url || '/';
    const label = row.label ?? '';
    // Language switcher item: `#bk-lang` (active language) / `#bk-lang=xx`.
    const lang = url === '#bk-lang' ? i18n.language : url.startsWith('#bk-lang=') ? url.slice(9) : null;
    return {
      id: row.id || `menu-${i}`,
      label: lang
        ? label.replace('{current}', current?.native ?? i18n.language.toUpperCase())
        : i18n.t(label),
      path: lang ? i18n.switchUrl(lang) : i18n.href(url),
      children: row.children?.length ? toMenuItems(row.children, i18n) : undefined,
    };
  });
}

function absolute(url: string): string {
  return url.startsWith('http') ? url : `${API}${url}`;
}

async function loadReactChrome(
  chrome: ChromeRender,
): Promise<ComponentType<Record<string, unknown>> | null> {
  if (!chrome.path || !chrome.slug) return null;
  const themes = [chrome.theme, chrome.theme === 'beekiri' ? null : 'beekiri'].filter(
    (value, index, all): value is string => Boolean(value) && all.indexOf(value) === index,
  );
  const candidates = [chrome.slug, chrome.kind];
  for (const theme of themes) {
    for (const file of candidates) {
      try {
        const mod = (await import(
          /* webpackMode: "lazy" */
          `../../themes/${theme}/${chrome.path}/${file}.tsx`
        )) as { default?: ComponentType<Record<string, unknown>> };
        if (mod.default) return mod.default;
      } catch {
        // try the parent theme / next entry name
      }
    }
  }
  console.error(
    `[beekiri] No React ${chrome.kind} at themes/${chrome.theme}/${chrome.path}/{${candidates.join(',')}}.tsx`,
  );
  return null;
}

/**
 * Active theme header / footer. The runtime chosen at install decides the source:
 * PHP → `{slug}.php` rendered by the API; React → `{slug}.tsx` rendered here.
 */
export async function SiteChrome({ kind, site }: { kind: ChromeKind; site: ChromeSite | null }) {
  const chrome = await getChrome(kind);
  if (!chrome?.slug) return null;
  const i18n = await getI18n();

  const stylesheet = chrome.cssUrl ? (
    <link rel="stylesheet" href={absolute(chrome.cssUrl)} precedence="beekiri-chrome" />
  ) : null;

  if (chrome.runtime === 'php') {
    if (!chrome.html) return null;
    return (
      <>
        {stylesheet}
        {/*
          PHP HTML is static markup. Theme script.js may tweak aria-current /
          hidden before React hydrates — suppress so that does not throw.
        */}
        <div
          data-bk-chrome={kind}
          style={{ display: 'contents' }}
          suppressHydrationWarning
          dangerouslySetInnerHTML={{ __html: i18n.html(chrome.html) }}
        />
        {chrome.jsUrl ? (
          // Native script — defer so it runs after paint, not during hydrate.
          <script src={absolute(chrome.jsUrl)} defer suppressHydrationWarning />
        ) : null}
      </>
    );
  }

  const Component = await loadReactChrome(chrome);
  if (!Component) return null;
  const { data } = chrome;
  return (
    <>
      {stylesheet}
      <Component
        {...data}
        siteTitle={i18n.t(site?.title?.trim() || (data.site_title as string) || 'Beekiri')}
        tagline={i18n.t(site?.tagline ?? (data.site_tagline as string) ?? '')}
        blogPublic={site?.blogPublic ?? (data.blog_public as boolean) ?? true}
        menu={
          Array.isArray(data.menu) && data.menu.length
            ? toMenuItems(data.menu, i18n)
            : (site?.menu ?? [])
        }
        year={data.year}
      />
    </>
  );
}
