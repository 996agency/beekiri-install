#!/usr/bin/env bash
# Pack install ZIP and publish to the public beekiri-install GitHub Releases repo.
# Keeps ONLY the current version on GitHub (replaces older release assets / main ZIPs).
# Usage: pnpm publish:release
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

RELEASE_REPO="${BEEKIRI_INSTALL_REPO:-996agency/beekiri-install}"
CORE_REPO="${BEEKIRI_CORE_REPO:-996agency/Beekiri}"
version="$(node -p "require('./package.json').version")"
tag="v${version}"
stable_zip="${ROOT}/releases/beekiri-install-v${version}.zip"
latest_zip="${ROOT}/releases/beekiri-install.zip"

echo "→ Building install ZIP for ${tag}…"
bash "${ROOT}/scripts/pack-release.sh"

if [[ ! -f "$stable_zip" ]]; then
  echo "Missing ${stable_zip}"
  exit 1
fi

if ! gh repo view "$RELEASE_REPO" >/dev/null 2>&1; then
  echo "→ Creating public repo ${RELEASE_REPO}…"
  gh repo create "$RELEASE_REPO" \
    --public \
    --description "Public Beekiri CMS install ZIPs (releases only — unzip → START_HERE.txt → /install)" \
    --add-readme
fi

notes="$(cat <<EOF
## Beekiri Core ${tag}

Install ZIP for new sites and updates.

1. Download **beekiri-install.zip** (or **beekiri-install-v${version}.zip**)
2. Unzip → follow \`START_HERE.txt\`
3. \`pnpm install\` → configure \`.env\` → \`pnpm db:migrate\` → start apps
4. Open **ADMIN_URL** → **/install** (first run only)

Existing sites: pull/update carefully, then confirm **Settings → Beekiri Core**.

Content, media, and \`.env\` stay on the site — this package does not overwrite them automatically.
EOF
)"

# --- GitHub Releases: keep latest only ---
echo "→ Removing older releases on ${RELEASE_REPO} (keep ${tag} only)…"
while read -r old_tag; do
  [[ -z "$old_tag" || "$old_tag" == "$tag" ]] && continue
  echo "  delete release ${old_tag}"
  gh release delete "$old_tag" --repo "$RELEASE_REPO" --yes --cleanup-tag 2>/dev/null \
    || gh release delete "$old_tag" --repo "$RELEASE_REPO" --yes \
    || true
done < <(gh release list --repo "$RELEASE_REPO" --limit 50 --json tagName --jq '.[].tagName' 2>/dev/null || true)

if gh release view "$tag" --repo "$RELEASE_REPO" >/dev/null 2>&1; then
  echo "→ Release ${tag} exists — uploading assets…"
  gh release upload "$tag" "$stable_zip" "$latest_zip" --repo "$RELEASE_REPO" --clobber
  gh release edit "$tag" --repo "$RELEASE_REPO" --title "Beekiri Core ${tag}" --notes "$notes"
else
  echo "→ Creating release ${tag} on ${RELEASE_REPO}…"
  gh release create "$tag" "$stable_zip" "$latest_zip" \
    --repo "$RELEASE_REPO" \
    --title "Beekiri Core ${tag}" \
    --notes "$notes"
fi

# --- Main branch via Contents API (ZIP git push often fails on large binaries) ---
echo "→ Updating main branch assets (latest only)…"
python3 - "$RELEASE_REPO" "$version" "$stable_zip" "$latest_zip" <<'PY'
import base64, json, subprocess, sys
from pathlib import Path

repo, version, stable_zip, latest_zip = sys.argv[1:5]
files = {
    f"beekiri-install-v{version}.zip": Path(stable_zip),
    "beekiri-install.zip": Path(latest_zip),
}
readme = f"""# Beekiri install packages

Public **install ZIP** releases for Beekiri CMS under **996agency**.

## License — proprietary

**Not open source.** Copyright © 2026 996agency. All rights reserved. See LICENSE.

## Download

**Latest ZIP (v{version}):** https://github.com/{repo}/raw/main/beekiri-install.zip

**Releases:** https://github.com/{repo}/releases

1. Unzip → read `LICENSE` and `START_HERE.txt`
2. Configure `.env`, migrate, start apps
3. Open admin URL → **/install** once (new sites only)
"""
latest = {
    "version": version,
    "tag": f"v{version}",
    "name": f"Beekiri Core v{version}",
    "releaseUrl": f"https://github.com/{repo}/releases/tag/v{version}",
    "downloadUrl": f"https://github.com/{repo}/raw/main/beekiri-install.zip",
    "publishedAt": None,
}

names = subprocess.check_output(
    ["gh", "api", f"repos/{repo}/contents/", "--jq", ".[].name"], text=True
).strip().splitlines()

for name in names:
    if name.startswith("beekiri-install") and name.endswith(".zip") and name not in files:
        meta = json.loads(subprocess.check_output(["gh", "api", f"repos/{repo}/contents/{name}"], text=True))
        subprocess.check_call([
            "gh", "api", "-X", "DELETE", f"repos/{repo}/contents/{name}",
            "-f", f"message=Remove old install ZIP {name}",
            "-f", f"sha={meta['sha']}",
        ])

def put(path: str, raw: bytes, message: str) -> None:
    payload = {"message": message, "content": base64.b64encode(raw).decode("ascii")}
    probe = subprocess.run(["gh", "api", f"repos/{repo}/contents/{path}"], capture_output=True, text=True)
    if probe.returncode == 0:
        payload["sha"] = json.loads(probe.stdout)["sha"]
    res = subprocess.run(
        ["gh", "api", "-X", "PUT", f"repos/{repo}/contents/{path}", "--input", "-"],
        input=json.dumps(payload).encode(),
        capture_output=True,
    )
    if res.returncode != 0:
        sys.stderr.write(res.stderr.decode() or res.stdout.decode())
        raise SystemExit(res.returncode)
    print(f"  put {path}")

put("README.md", readme.encode(), f"Update README for Beekiri install v{version}")
put("latest.json", (json.dumps(latest, indent=2) + "\n").encode(), f"Channel pointer v{version}")
for path, fp in files.items():
    put(path, fp.read_bytes(), f"Release Beekiri install v{version} ({path})")
print("→ Main branch updated")
PY

# Optional: also tag/release on core repo when we have write access
if gh api "repos/${CORE_REPO}" --jq '.permissions.push' 2>/dev/null | grep -q true; then
  core_notes="$(cat <<EOF
## Beekiri Core ${tag}

See install packages: https://github.com/${RELEASE_REPO}/releases/tag/${tag}
EOF
)"
  if gh release view "$tag" --repo "$CORE_REPO" >/dev/null 2>&1; then
    gh release edit "$tag" --repo "$CORE_REPO" --title "Beekiri Core ${tag}" --notes "$core_notes"
  else
    gh release create "$tag" --repo "$CORE_REPO" --title "Beekiri Core ${tag}" --notes "$core_notes" || true
  fi
fi

echo
echo "Published: https://github.com/${RELEASE_REPO}/releases/tag/${tag}"
echo "Latest ZIP: https://github.com/${RELEASE_REPO}/raw/main/beekiri-install.zip"
