#!/usr/bin/env tsx
/**
 * Environment doctor — actionable checks for local Beekiri CMS setup (no Docker).
 */
import { existsSync, accessSync, constants } from 'fs';
import { resolve } from 'path';
import { execSync } from 'child_process';

const root = resolve(__dirname, '..');
let failures = 0;

function ok(msg: string) {
  console.log(`✓ ${msg}`);
}
function fail(msg: string, hint?: string) {
  failures += 1;
  console.error(`✗ ${msg}`);
  if (hint) console.error(`  → ${hint}`);
}
function info(msg: string) {
  console.log(`· ${msg}`);
}

function loadEnv() {
  const envPath = resolve(root, '.env');
  if (!existsSync(envPath)) return {};
  const text = require('fs').readFileSync(envPath, 'utf8') as string;
  const out: Record<string, string> = {};
  for (const line of text.split('\n')) {
    const t = line.trim();
    if (!t || t.startsWith('#')) continue;
    const i = t.indexOf('=');
    if (i < 0) continue;
    const k = t.slice(0, i).trim();
    let v = t.slice(i + 1).trim();
    if (
      (v.startsWith('"') && v.endsWith('"')) ||
      (v.startsWith("'") && v.endsWith("'"))
    ) {
      v = v.slice(1, -1);
    }
    out[k] = v;
  }
  return out;
}

async function main() {
  console.log('Beekiri CMS doctor\n');

  try {
    const node = process.versions.node;
    const major = Number(node.split('.')[0]);
    if (major >= 20) ok(`Node.js ${node}`);
    else fail(`Node.js ${node}`, 'Install Node.js 20+ LTS');
  } catch {
    fail('Node.js not found');
  }

  try {
    const pnpm = execSync('pnpm -v', { encoding: 'utf8' }).trim();
    ok(`pnpm ${pnpm}`);
  } catch {
    fail('pnpm not found', 'npm i -g pnpm@9');
  }

  const env = { ...process.env, ...loadEnv() };
  if (!existsSync(resolve(root, '.env'))) {
    fail('.env missing', 'cp .env.example .env and edit DATABASE_URL / secrets');
  } else {
    ok('.env present');
  }

  for (const key of ['DATABASE_URL', 'SESSION_SECRET', 'ADMIN_URL', 'API_URL', 'APP_URL']) {
    if (!env[key]) fail(`Missing ${key}`, `Set ${key} in .env`);
    else if (
      (key === 'SESSION_SECRET' || key === 'CSRF_SECRET') &&
      String(env[key]).length < 32
    ) {
      fail(`${key} too short`, 'Use openssl rand -hex 32');
    } else ok(`${key} set`);
  }

  try {
    execSync('psql --version', { stdio: 'pipe' });
    ok('psql client available');
  } catch {
    fail(
      'psql not found',
      'Install PostgreSQL natively (macOS: brew install postgresql@16; Windows: postgresql.org installer; Linux: apt/dnf)',
    );
  }

  const databaseUrl = env.DATABASE_URL;
  if (databaseUrl) {
    // psql does not accept Prisma-only query params like schema=
    const psqlUrl = databaseUrl.replace(/\?.*$/, '');
    try {
      execSync(`psql "${psqlUrl}" -v ON_ERROR_STOP=1 -c "SELECT 1"`, {
        stdio: 'pipe',
      });
      ok('DATABASE_URL reachable');
      try {
        const hasMig = execSync(
          `psql "${psqlUrl}" -tAc "SELECT COUNT(*) FROM _prisma_migrations"`,
          { encoding: 'utf8' },
        ).trim();
        if (Number(hasMig) > 0) ok(`Prisma migrations applied (${hasMig})`);
        else info('No migrations applied yet — run pnpm db:migrate');
      } catch {
        info('No migration tables yet — run pnpm db:migrate');
      }
    } catch (e) {
      fail(
        'Cannot connect with DATABASE_URL',
        e instanceof Error
          ? `${e.message}. Start Postgres (brew services start postgresql@16) and create DB (createdb beekiri_cms).`
          : 'Check DATABASE_URL',
      );
    }
  }

  const upload = resolve(root, env.MEDIA_LOCAL_PATH || './apps/admin/uploads');
  try {
    if (!existsSync(upload)) {
      require('fs').mkdirSync(upload, { recursive: true });
    }
    accessSync(upload, constants.W_OK);
    ok(`Media path writable: ${upload}`);
  } catch {
    fail(`Media path not writable: ${upload}`);
  }

  info(`ADMIN_URL=${env.ADMIN_URL}`);
  info(`API_URL=${env.API_URL}`);
  info(`APP_URL=${env.APP_URL}`);

  // LocalWP conflict guard
  const blockedPorts = new Set(['80', '443', '4000']);
  const portFromUrl = (u?: string) => {
    if (!u) return null;
    try {
      const p = new URL(u).port;
      return p || (u.startsWith('https') ? '443' : '80');
    } catch {
      return null;
    }
  };
  for (const [name, u] of [
    ['ADMIN_URL', env.ADMIN_URL],
    ['API_URL', env.API_URL],
    ['APP_URL', env.APP_URL],
  ] as const) {
    const p = portFromUrl(u);
    if (p && blockedPorts.has(p)) {
      fail(
        `${name} uses port ${p}`,
        'Conflicts with LocalWP (Local by Flywheel). Use 8787 (admin), 8788 (api), 8789 (web).',
      );
    }
  }
  if (env.PORT && blockedPorts.has(String(env.PORT))) {
    fail(
      `PORT=${env.PORT} conflicts with LocalWP`,
      'Set PORT=8788 (never 4000 while Local is installed).',
    );
  } else if (env.PORT) {
    ok(`API PORT=${env.PORT} (LocalWP-safe)`);
  }

  console.log('');
  if (failures) {
    console.error(`Doctor found ${failures} issue(s).`);
    process.exit(1);
  }
  console.log('All checks passed.');
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
