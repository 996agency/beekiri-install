#!/usr/bin/env tsx
/**
 * Reset this Beekiri site so the installer runs again (e.g. to pick a different frontend).
 *
 *   pnpm reset            → explains what will happen, changes nothing
 *   pnpm reset --yes      → backs up, then resets
 *
 * Nothing is deleted:
 *   - the full database is dumped to backups/<timestamp>/database.sql (pg_dump) first
 *   - the uploads folder is moved to backups/<timestamp>/uploads
 *   - code, themes, and layout files are not touched
 * Then every table except _prisma_migrations is emptied, so /install starts fresh.
 *
 * Restore: psql "<DATABASE_URL without ?schema>" -f backups/<timestamp>/database.sql
 *          (into an empty database) and move the uploads folder back.
 */
import { execFileSync } from 'child_process';
import { existsSync, mkdirSync, readdirSync, readFileSync, renameSync } from 'fs';
import { isAbsolute, relative, resolve } from 'path';

const root = resolve(__dirname, '..');

function loadEnv(): Record<string, string> {
  const envPath = resolve(root, '.env');
  if (!existsSync(envPath)) return {};
  const out: Record<string, string> = {};
  for (const line of readFileSync(envPath, 'utf8').split('\n')) {
    const t = line.trim();
    if (!t || t.startsWith('#')) continue;
    const i = t.indexOf('=');
    if (i < 0) continue;
    const key = t.slice(0, i).trim();
    let value = t.slice(i + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    out[key] = value;
  }
  return out;
}

function fail(message: string, hint?: string): never {
  console.error(`✗ ${message}`);
  if (hint) console.error(`  → ${hint}`);
  process.exit(1);
}

function timestamp(): string {
  return new Date().toISOString().replace(/[:.]/g, '-').replace('T', '_').slice(0, 19);
}

/** libpq rejects Prisma's `?schema=` parameter — split it off. */
function parseDatabaseUrl(raw: string): { conn: string; schema: string; label: string } {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    fail('DATABASE_URL is not a valid URL.');
  }
  if (!/^postgres(ql)?:$/.test(url.protocol)) {
    fail('pnpm reset supports PostgreSQL only.', `DATABASE_URL uses ${url.protocol}`);
  }
  const schema = url.searchParams.get('schema') || 'public';
  url.search = '';
  const label = `${url.hostname}:${url.port || '5432'}${url.pathname}`;
  return { conn: url.toString(), schema, label };
}

function run(cmd: string, args: string[]): string {
  return execFileSync(cmd, args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
}

function main() {
  const confirmed = process.argv.includes('--yes') || process.argv.includes('-y');
  const env = { ...loadEnv(), ...process.env } as Record<string, string | undefined>;
  const databaseUrl = env.DATABASE_URL;
  if (!databaseUrl) fail('DATABASE_URL is not set.', 'Add it to .env at the repo root.');

  const { conn, schema, label } = parseDatabaseUrl(databaseUrl);
  const mediaRaw = env.MEDIA_LOCAL_PATH || './apps/admin/uploads';
  const uploadsDir = isAbsolute(mediaRaw) ? mediaRaw : resolve(root, mediaRaw);
  const stamp = timestamp();
  const backupDir = resolve(root, 'backups', stamp);
  const rel = (p: string) => relative(root, p) || '.';

  if (!confirmed) {
    console.log(`Beekiri reset — dry run (nothing changed)

  Database   ${label} (schema "${schema}")
  Uploads    ${rel(uploadsDir)}
  Backup to  ${rel(backupDir)}/

Running "pnpm reset --yes" will:
  1. Dump the full database to ${rel(backupDir)}/database.sql
  2. Move the uploads folder to ${rel(backupDir)}/uploads
  3. Empty every table (except _prisma_migrations) so the installer runs again

Code, themes, and layout files are not touched.`);
    return;
  }

  for (const bin of ['pg_dump', 'psql']) {
    try {
      run(bin, ['--version']);
    } catch {
      fail(`${bin} is not installed or not on PATH.`, 'Install PostgreSQL client tools.');
    }
  }

  mkdirSync(backupDir, { recursive: true });

  const dumpFile = resolve(backupDir, 'database.sql');
  console.log(`· Backing up database → ${rel(dumpFile)}`);
  try {
    run('pg_dump', ['--no-owner', '--no-privileges', '--file', dumpFile, conn]);
  } catch (e) {
    fail('pg_dump failed — nothing was reset.', (e as { stderr?: string }).stderr?.trim());
  }
  console.log('✓ Database backed up');

  if (existsSync(uploadsDir) && readdirSync(uploadsDir).length > 0) {
    const uploadsBackup = resolve(backupDir, 'uploads');
    console.log(`· Moving uploads → ${rel(uploadsBackup)}`);
    renameSync(uploadsDir, uploadsBackup);
    mkdirSync(uploadsDir, { recursive: true });
    console.log('✓ Uploads backed up');
  } else {
    console.log('· Uploads folder empty — nothing to move');
  }

  const tables = run('psql', [
    conn,
    '-At',
    '-v',
    'ON_ERROR_STOP=1',
    '-c',
    `SELECT format('%I.%I', schemaname, tablename) FROM pg_tables WHERE schemaname = '${schema.replace(/'/g, "''")}' AND tablename <> '_prisma_migrations' ORDER BY tablename`,
  ])
    .split('\n')
    .map((t) => t.trim())
    .filter(Boolean);

  if (tables.length) {
    console.log(`· Emptying ${tables.length} tables`);
    try {
      run('psql', [
        conn,
        '-v',
        'ON_ERROR_STOP=1',
        '-c',
        `TRUNCATE TABLE ${tables.join(', ')} RESTART IDENTITY CASCADE`,
      ]);
    } catch (e) {
      fail(
        'Emptying tables failed. Your backup is safe.',
        `${(e as { stderr?: string }).stderr?.trim() ?? ''}\n  Backup: ${rel(backupDir)}`,
      );
    }
  }

  console.log(`✓ Site reset

Backup:  ${rel(backupDir)}/
Next:    restart "pnpm dev" if it is running, then open
         http://127.0.0.1:8787/install and choose your frontend.`);
}

main();
