#!/usr/bin/env bash
# Build a client install ZIP (source + INSTALL.md, no secrets / node_modules).
# Usage: pnpm pack:release
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

version="$(node -p "require('./package.json').version" 2>/dev/null || echo '0.1.0')"
stamp="$(date +%Y%m%d)"
# Stable name used on GitHub Releases (latest/download/…)
stable_name="beekiri-install-v${version}"
dated_name="${stable_name}-${stamp}"
out_dir="${ROOT}/releases"
stage="${out_dir}/${dated_name}"

mkdir -p "$out_dir"
rm -rf "$stage"
mkdir -p "$stage"

echo "Packing ${dated_name} from ${ROOT}…"

if ! command -v rsync >/dev/null 2>&1; then
  echo "rsync is required to build the install ZIP."
  exit 1
fi

# Always pack this project folder only (do not use parent Desktop git root).
rsync -a \
  --exclude node_modules \
  --exclude .git \
  --exclude .turbo \
  --exclude dist \
  --exclude .next \
  --exclude .next-dev \
  --exclude coverage \
  --exclude uploads \
  --exclude releases \
  --exclude backups \
  --exclude .beekiri-update.json \
  --exclude 'apps/api/.cache-epoch' \
  --exclude .env \
  --exclude .env.local \
  --exclude 'apps/api/.env' \
  --exclude 'apps/api/.env.local' \
  --exclude '*.log' \
  --exclude .DS_Store \
  --exclude playwright-report \
  --exclude test-results \
  --exclude '*.tsbuildinfo' \
  --exclude Instatic-main \
  --exclude 'apps/web/acf-extended-pro' \
  --exclude 'apps/web/advanced-custom-fields-pro' \
  "$ROOT/" "$stage/"

cp -f "$ROOT/INSTALL.md" "$stage/INSTALL.md"
cp -f "$ROOT/.env.example" "$stage/.env.example"
cp -f "$ROOT/LICENSE" "$stage/LICENSE"
mkdir -p "$stage/docs"
[[ -f "$ROOT/docs/CLIENT_SETUP.md" ]] && cp -f "$ROOT/docs/CLIENT_SETUP.md" "$stage/docs/CLIENT_SETUP.md"

rm -f "$stage/.env" "$stage/.env.local" "$stage/apps/api/.env" "$stage/apps/api/.env.local"

cat > "$stage/START_HERE.txt" <<EOF
Beekiri install package (v${version})
=====================================

LICENSE: Proprietary — 996agency. All rights reserved.
This ZIP is NOT open source. Do not modify, redistribute, or rebrand
Beekiri without written permission. See LICENSE in this package.

1. Read LICENSE and INSTALL.md
2. Install Node.js 20+ and pnpm 9+
3. Create an empty PostgreSQL database
4. pnpm install
5. cp .env.example .env   → edit DATABASE_URL, URLs, secrets
6. pnpm db:migrate
7. pnpm doctor
8. Start the apps (see INSTALL.md)
9. Open ADMIN_URL → complete /install once

Do not commit or share your .env file.

Public install ZIPs (licensed):
https://github.com/996agency/beekiri-install
EOF

archive="${out_dir}/${stable_name}.zip"
dated_archive="${out_dir}/${dated_name}.zip"
rm -f "$archive" "$dated_archive" "${out_dir}/${dated_name}.tar.gz"

(
  cd "$out_dir"
  if command -v zip >/dev/null 2>&1; then
    zip -rq "${dated_name}.zip" "$dated_name"
    cp -f "${dated_name}.zip" "${stable_name}.zip"
    # Predictable latest asset name for /releases/latest/download/beekiri-install.zip
    cp -f "${dated_name}.zip" "beekiri-install.zip"
    echo
    echo "Created: ${dated_archive}"
    echo "Created: ${archive}"
    echo "Created: ${out_dir}/beekiri-install.zip"
  else
    tar -czf "${dated_name}.tar.gz" "$dated_name"
    echo
    echo "Created: ${out_dir}/${dated_name}.tar.gz"
  fi
)

rm -rf "$stage"

# Keep only the current version locally (GitHub is the archive of record).
find "$out_dir" -maxdepth 1 \( -name 'beekiri-install*.zip' -o -name 'beekiri-install*.tar.gz' \) \
  ! -name "beekiri-install-v${version}.zip" ! -name 'beekiri-install.zip' -delete 2>/dev/null || true
find "$out_dir" -maxdepth 1 -type d -name 'beekiri-install-v*' -exec rm -rf {} + 2>/dev/null || true

echo "Send that archive to the client. They follow START_HERE.txt / INSTALL.md"
echo
echo "Publish to the public install repo:"
echo "  pnpm publish:release"
echo
echo "Latest ZIP URL (after publish):"
echo "  https://github.com/996agency/beekiri-install/raw/main/beekiri-install.zip"
