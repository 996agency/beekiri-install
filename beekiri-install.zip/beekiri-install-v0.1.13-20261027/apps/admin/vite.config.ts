import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// Admin port 8787 — avoid LocalWP (80/443/4000) and common Next 3000.
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const apiTarget = env.API_URL || process.env.API_URL || 'http://127.0.0.1:8788';

  return {
    plugins: [react()],
    server: {
      host: '127.0.0.1',
      port: 8787,
      strictPort: true,
      fs: {
        // Allow shared web modules (page-blocks / beekiricanva)
        allow: ['../..', '../web/modules'],
      },
      proxy: {
        '/api': {
          target: apiTarget,
          changeOrigin: true,
          configure(proxy) {
            proxy.on('error', (_err, _req, res) => {
              const r = res as import('http').ServerResponse | undefined;
              if (r && !r.headersSent) {
                r.writeHead(502, { 'Content-Type': 'application/json' });
                r.end(
                  JSON.stringify({
                    // Client-safe copy — never expose ports or CLI to the browser UI.
                    message:
                      'This site is temporarily unavailable. Please try again in a moment — your content is safe.',
                    code: 'api_unreachable',
                  }),
                );
              }
            });
          },
        },
        '/uploads': {
          target: apiTarget,
          changeOrigin: true,
        },
      },
    },
  };
});
