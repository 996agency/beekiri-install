import { useCallback, useEffect, useRef, useState } from 'react';
import { api, ApiError } from '../api/client';

type UpdateJob = {
  state?: 'running' | 'done' | 'error';
  step?: string;
  progress?: number;
  message?: string;
  detail?: string;
  version?: string;
  restartRequired?: boolean;
  updatedAt?: string;
};

type Progress = { currentVersion: string; job: UpdateJob | null };

const POLL_MS = 1200;

export function CoreUpdateRunner({ latestVersion }: { latestVersion: string }) {
  const [job, setJob] = useState<UpdateJob | null>(null);
  const [restarting, setRestarting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [starting, setStarting] = useState(false);
  const timer = useRef<number | null>(null);

  const stop = () => {
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = null;
  };

  const poll = useCallback(async () => {
    try {
      const p = await api<Progress>('/api/system/updates/progress');
      setRestarting(false);
      setJob(p.job);
      if (p.job?.state === 'error') {
        setError(p.job.message ?? 'Update failed.');
        return;
      }
      if (p.job?.state === 'done' && p.job.version && p.currentVersion === p.job.version) {
        window.setTimeout(() => window.location.reload(), 1500);
        return;
      }
      if (p.job?.state === 'done' && p.job.restartRequired) return;
    } catch {
      // API restarts while core files change.
      setRestarting(true);
    }
    timer.current = window.setTimeout(() => void poll(), POLL_MS);
  }, []);

  useEffect(() => {
    void api<Progress>('/api/system/updates/progress')
      .then((p) => {
        if (p.job?.state === 'running') {
          setJob(p.job);
          void poll();
        }
      })
      .catch(() => undefined);
    return stop;
  }, [poll]);

  const start = async () => {
    if (
      !window.confirm(
        `Update Beekiri Core to v${latestVersion}?\n\nYour pages, media, users, settings and database stay as they are. Current core files are backed up first.`,
      )
    ) {
      return;
    }
    setError(null);
    setStarting(true);
    try {
      await api('/api/system/updates/apply', { method: 'POST' });
      setJob({ state: 'running', progress: 1, message: 'Starting update…' });
      stop();
      void poll();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Could not start the update.');
    } finally {
      setStarting(false);
    }
  };

  const running = job?.state === 'running' || (job?.state === 'done' && !job.restartRequired);
  const pct = Math.max(0, Math.min(100, job?.progress ?? 0));
  const label = restarting
    ? 'Restarting Beekiri services…'
    : job?.state === 'done'
      ? job.restartRequired
        ? `v${job.version} is installed. Restart Beekiri to finish.`
        : `v${job.version} is installed. Reloading…`
      : (job?.message ?? '');

  if (job && job.state !== 'error') {
    return (
      <div className="bk-core-update" role="status" aria-live="polite">
        <div className="bk-core-update__label">
          <span>{label}</span>
          <span>{pct}%</span>
        </div>
        <div
          className="bk-core-update__bar"
          role="progressbar"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={pct}
        >
          <span style={{ width: `${pct}%` }} />
        </div>
        {running ? (
          <p className="bk-muted" style={{ margin: '8px 0 0' }}>
            Keep this page open. Your content and database are not affected.
          </p>
        ) : null}
      </div>
    );
  }

  return (
    <>
      <button
        type="button"
        className="button button-primary"
        disabled={starting}
        onClick={() => void start()}
      >
        {starting ? 'Starting…' : `Update to v${latestVersion}`}
      </button>
      {error ? (
        <div className="beekiri-notice is-error" style={{ marginTop: 12, width: '100%' }}>
          <p style={{ margin: 0 }}>{error}</p>
          {job?.detail ? (
            <pre style={{ margin: '8px 0 0', whiteSpace: 'pre-wrap', fontSize: 11 }}>{job.detail}</pre>
          ) : null}
        </div>
      ) : null}
    </>
  );
}
