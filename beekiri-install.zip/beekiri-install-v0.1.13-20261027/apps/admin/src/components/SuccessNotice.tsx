import { useEffect, useRef } from 'react';

const DISMISS_MS = 4000;

/** Fixed bottom-right success toast; auto-hides after 4s. */
export function SuccessNotice({
  message,
  onDismiss,
}: {
  message: string;
  onDismiss: () => void;
}) {
  const onDismissRef = useRef(onDismiss);
  onDismissRef.current = onDismiss;

  useEffect(() => {
    const t = window.setTimeout(() => onDismissRef.current(), DISMISS_MS);
    return () => window.clearTimeout(t);
  }, [message]);

  return (
    <div className="beekiri-notice is-success bk-toast-notice" role="status">
      <p>{message}</p>
    </div>
  );
}
