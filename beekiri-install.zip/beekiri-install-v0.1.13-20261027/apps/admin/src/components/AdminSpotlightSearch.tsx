import { FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';

type SearchItem = {
  id: string;
  label: string;
  path: string;
  to: string;
  keywords: string;
};

const SEARCH_ITEMS: SearchItem[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    path: '/admin',
    to: '/admin',
    keywords: 'dashboard home overview hive status',
  },
  {
    id: 'posts',
    label: 'Posts',
    path: '/admin/posts',
    to: '/admin/posts',
    keywords: 'posts blog articles content',
  },
  {
    id: 'pages',
    label: 'Pages',
    path: '/admin/pages',
    to: '/admin/pages',
    keywords: 'pages content',
  },
  {
    id: 'media',
    label: 'Media',
    path: '/admin/media',
    to: '/admin/media',
    keywords: 'media library images uploads files',
  },
  {
    id: 'fields',
    label: 'Backend Fields',
    path: '/admin/fields',
    to: '/admin/fields',
    keywords: 'backend fields acf field groups custom fields',
  },
  {
    id: 'post-types',
    label: 'Post Types',
    path: '/admin/fields/post-types',
    to: '/admin/fields/post-types',
    keywords: 'post types cpt custom post type',
  },
  {
    id: 'taxonomies',
    label: 'Taxonomies',
    path: '/admin/fields/taxonomies',
    to: '/admin/fields/taxonomies',
    keywords: 'taxonomies categories tags',
  },
  {
    id: 'options-pages',
    label: 'Options Pages',
    path: '/admin/fields/options-pages',
    to: '/admin/fields/options-pages',
    keywords: 'options pages settings pages',
  },
  {
    id: 'fields-settings',
    label: 'Backend Fields Settings',
    path: '/admin/fields/settings',
    to: '/admin/fields/settings',
    keywords: 'fields settings',
  },
  {
    id: 'fields-tools',
    label: 'Backend Fields Tools',
    path: '/admin/fields/tools',
    to: '/admin/fields/tools',
    keywords: 'fields tools import export',
  },
  {
    id: 'users',
    label: 'Users',
    path: '/admin/users',
    to: '/admin/users',
    keywords: 'users accounts team members',
  },
  {
    id: 'appearance',
    label: 'Appearance',
    path: '/admin/appearance',
    to: '/admin/appearance',
    keywords: 'appearance themes design',
  },
  {
    id: 'header',
    label: 'Header',
    path: '/admin/appearance/header',
    to: '/admin/appearance/header',
    keywords: 'header chrome theme header',
  },
  {
    id: 'footer',
    label: 'Footer',
    path: '/admin/appearance/footer',
    to: '/admin/appearance/footer',
    keywords: 'footer chrome theme footer',
  },
  {
    id: 'templates',
    label: 'Templates',
    path: '/admin/appearance/templates',
    to: '/admin/appearance/templates',
    keywords: 'templates layouts',
  },
  {
    id: 'settings',
    label: 'Settings',
    path: '/admin/settings',
    to: '/admin/settings',
    keywords: 'settings site configuration',
  },
  {
    id: 'settings-core',
    label: 'Beekiri Core',
    path: '/admin/settings?tab=core',
    to: '/admin/settings?tab=core',
    keywords: 'beekiri core updates version system status',
  },
  {
    id: 'settings-general',
    label: 'General settings',
    path: '/admin/settings?tab=general',
    to: '/admin/settings?tab=general',
    keywords: 'general settings title tagline language timezone favicon',
  },
  {
    id: 'settings-reading',
    label: 'Reading settings',
    path: '/admin/settings?tab=reading',
    to: '/admin/settings?tab=reading',
    keywords: 'reading search engines index visibility blog public',
  },
  {
    id: 'settings-writing',
    label: 'Writing settings',
    path: '/admin/settings?tab=writing',
    to: '/admin/settings?tab=writing',
    keywords: 'writing settings',
  },
  {
    id: 'settings-page-editor',
    label: 'Page editor settings',
    path: '/admin/settings?tab=page-editor',
    to: '/admin/settings?tab=page-editor',
    keywords: 'page editor frontend php react runtime',
  },
  {
    id: 'settings-advanced',
    label: 'Advanced settings',
    path: '/admin/settings?tab=advanced',
    to: '/admin/settings?tab=advanced',
    keywords: 'advanced business hours phone address',
  },
  {
    id: 'settings-permalinks',
    label: 'Permalinks & navigation',
    path: '/admin/settings?tab=permalinks',
    to: '/admin/settings?tab=permalinks',
    keywords:
      'permalinks permalink urls slugs navigation menu menus nav header links site menu front page',
  },
  {
    id: 'settings-media',
    label: 'Media settings',
    path: '/admin/settings?tab=media',
    to: '/admin/settings?tab=media',
    keywords: 'media settings image sizes optimization',
  },
  {
    id: 'settings-cache',
    label: 'Cache',
    path: '/admin/settings?tab=cache',
    to: '/admin/settings?tab=cache',
    keywords: 'cache flush clear pagespeed performance',
  },
  {
    id: 'settings-instructions',
    label: 'Instructions',
    path: '/admin/settings?tab=instructions',
    to: '/admin/settings?tab=instructions',
    keywords: 'instructions help docs guide',
  },
];

const ICON_SEARCH = (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    <circle cx="11" cy="11" r="8" />
    <path d="m21 21-4.3-4.3" />
  </svg>
);

function isApplePlatform() {
  if (typeof navigator === 'undefined') return false;
  return /Mac|iPhone|iPad|iPod/i.test(navigator.platform || navigator.userAgent);
}

function matches(item: SearchItem, q: string) {
  if (!q) return true;
  const hay = `${item.label} ${item.path} ${item.keywords}`.toLowerCase();
  return hay.includes(q);
}

export function AdminSpotlightSearch() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const apple = useMemo(() => isApplePlatform(), []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return SEARCH_ITEMS.filter((item) => matches(item, q));
  }, [query]);

  const close = () => {
    setOpen(false);
    setQuery('');
  };

  const go = (to: string) => {
    close();
    navigate(to);
  };

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const id = window.requestAnimationFrame(() => inputRef.current?.focus());
    return () => {
      document.body.style.overflow = prev;
      window.cancelAnimationFrame(id);
    };
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setOpen(true);
        setQuery('');
        return;
      }
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const first = filtered[0];
    if (first) go(first.to);
  };

  return (
    <>
      <button
        type="button"
        className="bk-admin-search__trigger bk-admin-search__trigger--icon"
        aria-label="Open search"
        onClick={() => {
          setOpen(true);
          setQuery('');
        }}
      >
        {ICON_SEARCH}
      </button>
      <button
        type="button"
        className="bk-admin-search__trigger bk-admin-search__trigger--full"
        aria-label="Open search"
        onClick={() => {
          setOpen(true);
          setQuery('');
        }}
      >
        {ICON_SEARCH}
        <span>Search</span>
        <span className="bk-admin-search__kbds" aria-hidden="true">
          {apple ? (
            <>
              <kbd>⌘</kbd>
              <kbd>K</kbd>
            </>
          ) : (
            <>
              <kbd>Ctrl</kbd>
              <kbd>K</kbd>
            </>
          )}
        </span>
      </button>

      {open ? (
        <div
          className="bk-admin-search"
          role="dialog"
          aria-modal="true"
          aria-labelledby="bk-admin-search-input"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) close();
          }}
        >
          <form className="bk-admin-search__panel" onSubmit={onSubmit}>
            <div className="bk-admin-search__head">
              {ICON_SEARCH}
              <input
                id="bk-admin-search-input"
                ref={inputRef}
                type="search"
                placeholder="Search admin…"
                autoComplete="off"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
              <kbd>esc</kbd>
            </div>
            <ul className="bk-admin-search__results">
              {filtered.map((item) => (
                <li key={item.id}>
                  <button type="button" onClick={() => go(item.to)}>
                    <span>{item.label}</span>
                    <code>{item.path}</code>
                  </button>
                </li>
              ))}
              {filtered.length === 0 ? (
                <li className="bk-admin-search__empty">No matches</li>
              ) : null}
            </ul>
          </form>
        </div>
      ) : null}
    </>
  );
}
