/** Admin config so Pages and Posts share the same list/editor UX. */

export type ContentKind = 'page' | 'post';

export type ContentKindConfig = {
  kind: ContentKind;
  apiBase: '/api/pages' | '/api/posts';
  listPath: '/admin/pages' | '/admin/posts';
  listKey: 'pages' | 'posts';
  itemKey: 'page' | 'post';
  editCap: 'edit_pages' | 'edit_posts';
  publishCap: 'publish_pages' | 'publish_posts';
  deleteCap: 'delete_pages' | 'delete_posts';
  label: string;
  labelLower: string;
  labelPlural: string;
  pathPrefix: string;
  blurb: string;
  emptyTitle: string;
  emptyFilteredTitle: string;
};

export const CONTENT_KINDS: Record<ContentKind, ContentKindConfig> = {
  page: {
    kind: 'page',
    apiBase: '/api/pages',
    listPath: '/admin/pages',
    listKey: 'pages',
    itemKey: 'page',
    editCap: 'edit_pages',
    publishCap: 'publish_pages',
    deleteCap: 'delete_pages',
    label: 'Page',
    labelLower: 'page',
    labelPlural: 'Pages',
    pathPrefix: '/',
    blurb: 'Create and publish pages for your site.',
    emptyTitle: 'No pages yet. Click Add new to start.',
    emptyFilteredTitle: 'No pages match these filters.',
  },
  post: {
    kind: 'post',
    apiBase: '/api/posts',
    listPath: '/admin/posts',
    listKey: 'posts',
    itemKey: 'post',
    editCap: 'edit_posts',
    publishCap: 'publish_posts',
    deleteCap: 'delete_posts',
    label: 'Post',
    labelLower: 'post',
    labelPlural: 'Posts',
    pathPrefix: '/blog/',
    blurb: 'Create and publish single blog posts.',
    emptyTitle: 'No posts yet. Click Add new to start.',
    emptyFilteredTitle: 'No posts match these filters.',
  },
};

export function contentKindConfig(kind: ContentKind): ContentKindConfig {
  return CONTENT_KINDS[kind];
}
