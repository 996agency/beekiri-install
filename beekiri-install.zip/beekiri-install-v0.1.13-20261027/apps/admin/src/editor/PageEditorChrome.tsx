import { createContext, useContext, type ReactNode } from 'react';
import type { Data } from '@beekiri/beekiricanva';
import type { BeekiriCodePageDoc } from './beekiricode/document';
import type { PageRow } from '../screens/PagesPage';

export type PageEditorChromeValue = {
  title: string;
  onTitleChange: (value: string) => void;
  slug: string;
  slugEditing: boolean;
  setSlugEditing: (v: boolean) => void;
  onSlugChange: (value: string) => void;
  commitSlug: () => void;
  cancelSlug: () => void;
  permalinkBase: string;
  /** Public path including prefix, e.g. `/about` or `/blog/hello`. */
  publicPath: string;
  pageStatus: 'auto-draft' | 'draft' | 'publish';
  visibility: 'auto-draft' | 'draft' | 'publish';
  setVisibility: (v: 'draft' | 'publish') => void;
  excerpt: string;
  setExcerpt: (v: string) => void;
  updatedAt: string | null;
  publishedAt: string | null;
  createdAt: string | null;
  authorName: string | null;
  updatedByName: string | null;
  revisionCount: number;
  parentId: string | null;
  pageId: string;
  apiBase: '/api/pages' | '/api/posts';
  listPath: '/admin/pages' | '/admin/posts';
  singularLabel: string;
  pluralLabel: string;
  /** Legacy field kept for older chrome consumers; prefer beekiricodeData. */
  beekiricanvaData: Data;
  beekiricodeData: BeekiriCodePageDoc;
  isPublished: boolean;
  busy: boolean;
  canPublish: boolean;
  canDelete: boolean;
  viewHref: string | null;
  /** True when editor fields differ from last saved page. */
  isDirty: boolean;
  fullscreen: boolean;
  toggleFullscreen: () => void;
  settingsOpen: boolean;
  openSettings: () => void;
  closeSettings: () => void;
  /** Open a front-end preview link of current unsaved edits (does not publish). */
  previewChanges: () => void;
  saveDraft: () => void;
  publish: () => void;
  update: () => void;
  switchToDraft: () => void;
  onDelete: () => void;
  /** Apply a restored page payload into the editor. */
  applyRestoredPage: (page: PageRow) => void;
};

const PageEditorChromeContext = createContext<PageEditorChromeValue | null>(null);

export function PageEditorChromeProvider({
  value,
  children,
}: {
  value: PageEditorChromeValue;
  children: ReactNode;
}) {
  return (
    <PageEditorChromeContext.Provider value={value}>
      {children}
    </PageEditorChromeContext.Provider>
  );
}

export function usePageEditorChrome() {
  const ctx = useContext(PageEditorChromeContext);
  if (!ctx) {
    throw new Error('usePageEditorChrome must be used within PageEditorChromeProvider');
  }
  return ctx;
}
