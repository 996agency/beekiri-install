import { useEffect, useMemo, useState, type CSSProperties, type MouseEvent } from 'react';
import { api } from '../../api/client';
import { hasLayoutScaffoldStyle } from './document';

type Props = {
  slug: string;
  fields: Record<string, unknown>;
  selected?: boolean;
  hovered?: boolean;
  interactive?: boolean;
  onSelect: (e: MouseEvent) => void;
  onHover: (e: MouseEvent) => void;
  onLeave: () => void;
  /** Properties-panel overrides — applied onto the PHP <section>, not a padded wrapper. */
  style?: CSSProperties;
  /** Extra host class (e.g. hidden-on-breakpoint ghost). */
  className?: string;
};

/** Old editor chrome that must not inflate layout boxes vs the live site. */
const CHROME_STYLE_KEYS = new Set([
  'display',
  'flexDirection',
  'flexWrap',
  'alignItems',
  'justifyContent',
  'gap',
  'rowGap',
  'columnGap',
  'padding',
  'paddingTop',
  'paddingRight',
  'paddingBottom',
  'paddingLeft',
  'border',
  'borderWidth',
  'borderStyle',
  'borderColor',
  'borderRadius',
  'minHeight',
]);

function camelToKebab(s: string) {
  return s.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`);
}

/** Keep real overrides; drop chrome only from legacy scaffold bags. */
function layoutOverrideDecls(style: CSSProperties | undefined): string {
  if (!style) return '';
  const scaffold = hasLayoutScaffoldStyle(style as Record<string, string>);
  return Object.entries(style)
    .filter(([k, v]) => {
      if (v == null || v === '') return false;
      if (scaffold && CHROME_STYLE_KEYS.has(k)) return false;
      // Drop old dashed-placeholder gray fill
      if (
        (k === 'background' || k === 'backgroundColor') &&
        String(v).replace(/\s/g, '').toLowerCase() === '#fafafa'
      ) {
        return false;
      }
      return true;
    })
    .map(([k, v]) => `${camelToKebab(k)}:${String(v)}`)
    .join(';');
}

/** Put Properties styles on the PHP root <section>, matching public output. */
function injectSectionStyle(html: string, decls: string): string {
  if (!decls.trim()) return html;
  return html.replace(/<section\b([^>]*)>/i, (_full, attrs: string) => {
    if (/\sstyle\s*=/.test(attrs)) {
      return `<section${attrs.replace(
        /style\s*=\s*(["'])([\s\S]*?)\1/i,
        (_m, q, existing) => `style=${q}${existing};${decls}${q}`,
      )}>`;
    }
    return `<section${attrs} style="${decls}">`;
  });
}

/** Renders themes/.../layouts/{slug} via the API (PHP or React — same as the public site). */
export function LayoutPhpPreview({
  slug,
  fields,
  selected,
  hovered,
  interactive,
  onSelect,
  onHover,
  onLeave,
  style,
  className,
}: Props) {
  const [html, setHtml] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const fieldsKey = JSON.stringify(fields);
  const overrideDecls = useMemo(() => layoutOverrideDecls(style), [style]);

  useEffect(() => {
    let cancelled = false;
    setError(null);
    api<{ html: string }>(`/api/layouts/${encodeURIComponent(slug)}/render`, {
      method: 'POST',
      json: { fields: JSON.parse(fieldsKey) as Record<string, unknown> },
    })
      .then((res) => {
        if (!cancelled) setHtml(res.html || '');
      })
      .catch((e) => {
        if (!cancelled) {
          setHtml('');
          setError(e instanceof Error ? e.message : 'Failed to render layout PHP');
        }
      });
    return () => {
      cancelled = true;
    };
  }, [slug, fieldsKey]);

  const hostCls = [
    'bk-beekiricode__layout-host',
    'bk-beekiricode__node',
    selected ? 'is-selected' : '',
    hovered ? 'is-hovered' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  const handlers = interactive
    ? {
        onClick: onSelect,
        onMouseEnter: onHover,
        onMouseLeave: onLeave,
      }
    : {};

  if (error) {
    return (
      <div className={hostCls} data-layout={slug} {...handlers}>
        <p className="bk-beekiricode__layout-hint">{error}</p>
      </div>
    );
  }

  if (!html) {
    return (
      <div className={hostCls} data-layout={slug} {...handlers}>
        <p className="bk-beekiricode__layout-hint">Loading {slug}…</p>
      </div>
    );
  }

  return (
    <div
      className={hostCls}
      data-layout={slug}
      {...handlers}
      dangerouslySetInnerHTML={{ __html: injectSectionStyle(html, overrideDecls) }}
    />
  );
}
