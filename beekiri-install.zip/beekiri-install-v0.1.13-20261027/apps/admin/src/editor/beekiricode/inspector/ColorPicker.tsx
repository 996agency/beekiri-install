import { useCallback, useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { Eyedropper, Plus, X } from '@phosphor-icons/react';
import { Popover } from './Popover';
import {
  formatColor,
  hsvToRgb,
  parseColor,
  rgbToHsv,
  toHex,
  type HSVA,
  type RGBA,
} from './css-values';

const PALETTES: { name: string; colors: string[] }[] = [
  { name: 'Sunshine', colors: ['#FFF4CC', '#FFE38A', '#FFC93C', '#FF9F1C', '#F26B1D', '#B8420F'] },
  { name: 'Ocean', colors: ['#E0F2FE', '#7DD3FC', '#38BDF8', '#0284C7', '#075985', '#0C2D48'] },
  { name: 'Neutral', colors: ['#FFFFFF', '#F4F4F5', '#A1A1AA', '#52525B', '#27272A', '#000000'] },
];

const SWATCH_KEY = 'bk-insp-swatches';

function loadSwatches(): string[] {
  try {
    const raw = localStorage.getItem(SWATCH_KEY);
    const arr = raw ? (JSON.parse(raw) as unknown) : [];
    return Array.isArray(arr) ? arr.filter((x): x is string => typeof x === 'string') : [];
  } catch {
    return [];
  }
}

type EyeDropperCtor = new () => { open: () => Promise<{ sRGBHex: string }> };

/* ── Field: swatch + hex + alpha ────────────────────────────────────────── */

export function ColorField({
  value,
  onChange,
  documentColors = [],
  placeholder = 'None',
}: {
  value: string;
  onChange: (v: string) => void;
  documentColors?: string[];
  placeholder?: string;
}) {
  const anchorRef = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const parsed = parseColor(value);
  const [hexDraft, setHexDraft] = useState('');
  const [alphaDraft, setAlphaDraft] = useState('');

  useEffect(() => {
    setHexDraft(parsed ? toHex(parsed).slice(1) : '');
    setAlphaDraft(parsed ? String(Math.round(parsed.a * 100)) : '');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  const commitHex = () => {
    const h = hexDraft.trim().replace(/^#/, '');
    if (!h) {
      if (value) onChange('');
      return;
    }
    const c = parseColor(`#${h}`);
    if (!c) {
      setHexDraft(parsed ? toHex(parsed).slice(1) : '');
      return;
    }
    onChange(formatColor({ ...c, a: parsed?.a ?? 1 }));
  };

  const commitAlpha = () => {
    const n = Number(alphaDraft.replace('%', ''));
    if (!parsed || !Number.isFinite(n)) {
      setAlphaDraft(parsed ? String(Math.round(parsed.a * 100)) : '');
      return;
    }
    onChange(formatColor({ ...parsed, a: Math.min(100, Math.max(0, n)) / 100 }));
  };

  const close = useCallback(() => setOpen(false), []);

  return (
    <div className={`bk-insp-color${open ? ' is-open' : ''}`} ref={anchorRef}>
      <button
        type="button"
        className="bk-insp-color__swatch"
        onClick={() => setOpen((o) => !o)}
        aria-label="Open color picker"
      >
        <span className="bk-insp-checker" />
        <span className="bk-insp-color__fill" style={{ background: parsed ? formatColor(parsed) : 'transparent' }} />
        {!parsed ? <span className="bk-insp-color__none" /> : null}
      </button>
      <input
        className="bk-insp-color__hex"
        value={hexDraft}
        placeholder={value && !parsed ? value : placeholder}
        spellCheck={false}
        maxLength={7}
        onChange={(e) => setHexDraft(e.target.value)}
        onBlur={commitHex}
        onKeyDown={(e) => {
          if (e.key !== 'Enter') return;
          commitHex();
          (e.target as HTMLInputElement).blur();
        }}
      />
      <span className="bk-insp-color__sep" />
      <input
        className="bk-insp-color__alpha"
        value={alphaDraft}
        placeholder="—"
        disabled={!parsed}
        onChange={(e) => setAlphaDraft(e.target.value)}
        onBlur={commitAlpha}
        onKeyDown={(e) => {
          if (e.key !== 'Enter') return;
          commitAlpha();
          (e.target as HTMLInputElement).blur();
        }}
      />
      <span className="bk-insp-color__pct">%</span>
      {value ? (
        <button type="button" className="bk-insp-color__clear" onClick={() => onChange('')} aria-label="Clear color">
          <X size={11} weight="bold" />
        </button>
      ) : null}
      <Popover anchorRef={anchorRef} open={open} onClose={close} width={256}>
        <ColorPickerPanel value={value} onChange={onChange} documentColors={documentColors} onClose={close} />
      </Popover>
    </div>
  );
}

/* ── Picker panel ───────────────────────────────────────────────────────── */

function useDrag(onPoint: (x: number, y: number, rect: DOMRect) => void) {
  return (e: ReactPointerEvent<HTMLElement>) => {
    const el = e.currentTarget;
    const rect = el.getBoundingClientRect();
    const at = (ev: { clientX: number; clientY: number }) =>
      onPoint(
        Math.min(1, Math.max(0, (ev.clientX - rect.left) / rect.width)),
        Math.min(1, Math.max(0, (ev.clientY - rect.top) / rect.height)),
        rect,
      );
    e.preventDefault();
    el.setPointerCapture(e.pointerId);
    at(e);
    const move = (ev: PointerEvent) => at(ev);
    const up = () => {
      el.removeEventListener('pointermove', move);
      el.removeEventListener('pointerup', up);
    };
    el.addEventListener('pointermove', move);
    el.addEventListener('pointerup', up);
  };
}

export function ColorPickerPanel({
  value,
  onChange,
  documentColors,
  onClose,
}: {
  value: string;
  onChange: (v: string) => void;
  documentColors: string[];
  onClose: () => void;
}) {
  const initial = parseColor(value) ?? { r: 0, g: 0, b: 0, a: 1 };
  // Keep HSV locally so hue survives when saturation/value hit 0.
  const [hsv, setHsv] = useState<HSVA>(() => rgbToHsv(initial));
  const lastEmitted = useRef<string>(value);
  const [swatches, setSwatches] = useState<string[]>(loadSwatches);

  useEffect(() => {
    if (value === lastEmitted.current) return;
    const c = parseColor(value);
    if (c) setHsv(rgbToHsv(c));
    lastEmitted.current = value;
  }, [value]);

  const rgb = useMemo(() => hsvToRgb(hsv), [hsv]);

  const emit = (next: HSVA) => {
    setHsv(next);
    const out = formatColor(hsvToRgb(next));
    lastEmitted.current = out;
    onChange(out);
  };

  const setRgb = (c: RGBA) => emit(rgbToHsv(c));

  const onSV = useDrag((x, y) => emit({ ...hsv, s: x, v: 1 - y }));
  const onHue = useDrag((x) => emit({ ...hsv, h: Math.min(359.9, x * 360) }));
  const onAlpha = useDrag((x) => emit({ ...hsv, a: Math.round(x * 100) / 100 }));

  const EyeDropperApi = (window as unknown as { EyeDropper?: EyeDropperCtor }).EyeDropper;
  const pickFromScreen = async () => {
    if (!EyeDropperApi) return;
    try {
      const res = await new EyeDropperApi().open();
      const c = parseColor(res.sRGBHex);
      if (c) setRgb({ ...c, a: hsv.a });
    } catch {
      /* cancelled */
    }
  };

  const addSwatch = () => {
    const c = formatColor(rgb);
    const next = [c, ...swatches.filter((s) => s !== c)].slice(0, 14);
    setSwatches(next);
    try {
      localStorage.setItem(SWATCH_KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
  };

  const docSwatches = [...new Set([...swatches, ...documentColors])].slice(0, 14);
  const hueColor = formatColor(hsvToRgb({ h: hsv.h, s: 1, v: 1, a: 1 }));
  const solid = toHex(rgb);

  return (
    <div className="bk-insp-cp">
      <div className="bk-insp-cp__head">
        <span className="bk-insp-cp__tab is-active">Custom</span>
        <button type="button" className="bk-insp-icon-btn" onClick={onClose} aria-label="Close">
          <X size={12} weight="bold" />
        </button>
      </div>

      <div className="bk-insp-cp__sv" style={{ background: hueColor }} onPointerDown={onSV}>
        <div className="bk-insp-cp__sv-white" />
        <div className="bk-insp-cp__sv-black" />
        <span
          className="bk-insp-cp__thumb"
          style={{ left: `${hsv.s * 100}%`, top: `${(1 - hsv.v) * 100}%`, background: solid }}
        />
      </div>

      <div className="bk-insp-cp__bars">
        <button
          type="button"
          className="bk-insp-icon-btn bk-insp-cp__dropper"
          onClick={pickFromScreen}
          disabled={!EyeDropperApi}
          title={EyeDropperApi ? 'Pick from screen' : 'Eyedropper not supported in this browser'}
        >
          <Eyedropper size={15} />
        </button>
        <div className="bk-insp-cp__tracks">
          <div className="bk-insp-cp__track is-hue" onPointerDown={onHue}>
            <span className="bk-insp-cp__knob" style={{ left: `${(hsv.h / 360) * 100}%`, background: hueColor }} />
          </div>
          <div className="bk-insp-cp__track is-alpha" onPointerDown={onAlpha}>
            <span className="bk-insp-checker" />
            <span
              className="bk-insp-cp__alpha-fill"
              style={{ background: `linear-gradient(90deg, transparent, ${solid})` }}
            />
            <span className="bk-insp-cp__knob" style={{ left: `${hsv.a * 100}%`, background: formatColor(rgb) }} />
          </div>
        </div>
      </div>

      <div className="bk-insp-cp__inputs">
        <ChannelInput label="Hex" wide value={solid.slice(1)} onCommit={(v) => {
          const c = parseColor(`#${v.replace(/^#/, '')}`);
          if (c) setRgb({ ...c, a: hsv.a });
        }} />
        <ChannelInput label="R" value={String(Math.round(rgb.r))} onCommit={(v) => setRgb({ ...rgb, r: clamp255(v) })} />
        <ChannelInput label="G" value={String(Math.round(rgb.g))} onCommit={(v) => setRgb({ ...rgb, g: clamp255(v) })} />
        <ChannelInput label="B" value={String(Math.round(rgb.b))} onCommit={(v) => setRgb({ ...rgb, b: clamp255(v) })} />
        <ChannelInput
          label="A"
          value={String(Math.round(hsv.a * 100))}
          onCommit={(v) => emit({ ...hsv, a: Math.min(100, Math.max(0, Number(v) || 0)) / 100 })}
        />
      </div>

      <div className="bk-insp-cp__group">
        <div className="bk-insp-cp__group-head">
          <span>Document</span>
          <button type="button" className="bk-insp-icon-btn" onClick={addSwatch} aria-label="Save current color">
            <Plus size={12} weight="bold" />
          </button>
        </div>
        <div className="bk-insp-cp__swatches">
          {docSwatches.length === 0 ? <span className="bk-insp-cp__empty">No saved colors yet</span> : null}
          {docSwatches.map((c) => (
            <Swatch key={c} color={c} onPick={() => {
              const p = parseColor(c);
              if (p) setRgb(p);
            }} />
          ))}
        </div>
      </div>

      <div className="bk-insp-cp__group">
        <div className="bk-insp-cp__group-head">
          <span>Color Palette</span>
        </div>
        {PALETTES.map((p) => (
          <div key={p.name} className="bk-insp-cp__palette">
            <span className="bk-insp-cp__palette-name">{p.name}</span>
            <div className="bk-insp-cp__palette-row">
              {p.colors.map((c) => (
                <Swatch key={c} color={c} flat onPick={() => {
                  const parsed = parseColor(c);
                  if (parsed) setRgb(parsed);
                }} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const clamp255 = (v: string) => Math.min(255, Math.max(0, Math.round(Number(v) || 0)));

function Swatch({ color, onPick, flat }: { color: string; onPick: () => void; flat?: boolean }) {
  return (
    <button type="button" className={`bk-insp-cp__swatch${flat ? ' is-flat' : ''}`} onClick={onPick} title={color}>
      <span className="bk-insp-checker" />
      <span className="bk-insp-cp__swatch-fill" style={{ background: color }} />
    </button>
  );
}

function ChannelInput({
  label,
  value,
  onCommit,
  wide,
}: {
  label: string;
  value: string;
  onCommit: (v: string) => void;
  wide?: boolean;
}) {
  const [draft, setDraft] = useState(value);
  useEffect(() => setDraft(value), [value]);
  return (
    <label className={`bk-insp-cp__ch${wide ? ' is-wide' : ''}`}>
      <input
        value={draft}
        spellCheck={false}
        onChange={(e) => setDraft(e.target.value)}
        onFocus={(e) => e.target.select()}
        onBlur={() => draft !== value && onCommit(draft)}
        onKeyDown={(e) => {
          if (e.key !== 'Enter') return;
          if (draft !== value) onCommit(draft);
          (e.target as HTMLInputElement).blur();
        }}
      />
      <span>{label}</span>
    </label>
  );
}
