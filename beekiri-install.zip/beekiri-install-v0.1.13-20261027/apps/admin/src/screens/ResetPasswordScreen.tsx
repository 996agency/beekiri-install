import { FormEvent, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import { passwordStrength } from '../util/password';
import { AuthShell } from './AuthShell';

export function ResetPasswordScreen() {
  const [params] = useSearchParams();
  const token = params.get('key') ?? params.get('token') ?? '';
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const strength = passwordStrength(password);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ message: string }>('/api/auth/reset-password', {
        json: { token, password },
      });
      setMessage(res.message);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Reset failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell title="New password" subtitle="Choose a strong password for your account.">
      {error ? (
        <div className="bk-auth__alert" role="alert">
          {error}
        </div>
      ) : null}

      {message ? (
        <div className="bk-auth__actions">
          <div className="bk-auth__ok" role="status">
            {message}
          </div>
          <Link to="/login" className="bk-install__btn bk-install__btn--primary">
            Sign in
          </Link>
        </div>
      ) : (
        <form onSubmit={onSubmit}>
          <div className="bk-install__field">
            <label htmlFor="pass1">Password</label>
            <div className="bk-install__pw">
              <input
                id="pass1"
                type={showPw ? 'text' : 'password'}
                required
                minLength={8}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <button
                type="button"
                className="bk-install__pw-toggle"
                onClick={() => setShowPw((v) => !v)}
              >
                {showPw ? 'Hide' : 'Show'}
              </button>
            </div>
          </div>
          <div className="bk-install__meta">
            <span className={`bk-install__strength ${strength}`}>
              {password ? `Strength · ${strength}` : 'Use at least 8 characters'}
            </span>
          </div>
          <div className="bk-auth__actions">
            <button
              type="submit"
              className="bk-install__btn bk-install__btn--primary"
              disabled={busy || strength === 'weak' || !token}
            >
              {busy ? 'Saving…' : 'Save password'}
            </button>
            <Link to="/login" className="bk-install__btn bk-install__btn--ghost">
              Back to sign in
            </Link>
          </div>
        </form>
      )}
    </AuthShell>
  );
}
