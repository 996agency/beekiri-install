import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import type { RoleSlug } from '../cms-types';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import {
  AdminDataTable,
  hasActiveAdminFilters,
  type AdminTableColumn,
  type AdminTableFilter,
} from '../components/AdminDataTable';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import { generatePassword, passwordStrength } from '../util/password';

const EMPTY_FILTERS = { username: '', name: '', role: '' };

type RoleOption = { slug: RoleSlug; label: string };

type CustomField = { id: string; label: string; value: string };

type SiteUser = {
  id: string;
  username: string;
  email: string;
  displayName: string;
  role: RoleSlug;
  roleLabel: string;
  isOwner: boolean;
  jobDescription?: string;
  customFields?: CustomField[];
  createdAt: string;
  updatedAt: string;
};

type Mode = { kind: 'list' } | { kind: 'create' } | { kind: 'edit'; user: SiteUser };

const EMPTY_FORM = {
  username: '',
  email: '',
  displayName: '',
  password: '',
  role: 'subscriber' as RoleSlug,
  jobDescription: '',
  customFields: [] as CustomField[],
};

function newCustomField(): CustomField {
  return {
    id: `cf-${Math.random().toString(36).slice(2, 9)}`,
    label: '',
    value: '',
  };
}

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

export function UsersPage() {
  const auth = useAuth();
  const [users, setUsers] = useState<SiteUser[]>([]);
  const [roles, setRoles] = useState<RoleOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [mode, setMode] = useState<Mode>({ kind: 'list' });
  const [form, setForm] = useState(EMPTY_FORM);
  const [showPw, setShowPw] = useState(false);
  const [filterValues, setFilterValues] = useState(EMPTY_FILTERS);

  const canCreate = auth.user?.capabilities.includes('create_users') ?? false;
  const canEdit = auth.user?.capabilities.includes('edit_users') ?? false;
  const canDelete = auth.user?.capabilities.includes('delete_users') ?? false;

  const load = useCallback(async () => {
    setError(null);
    const [listRes, rolesRes] = await Promise.all([
      api<{ users: SiteUser[] }>('/api/users'),
      api<{ roles: RoleOption[] }>('/api/users/roles'),
    ]);
    setUsers(listRes.users);
    setRoles(rolesRes.roles);
  }, []);

  useEffect(() => {
    setLoading(true);
    load()
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [load]);

  const openCreate = () => {
    setNotice(null);
    setError(null);
    setForm({ ...EMPTY_FORM, password: generatePassword(16), customFields: [] });
    setShowPw(true);
    setMode({ kind: 'create' });
  };

  const openEdit = (user: SiteUser) => {
    setNotice(null);
    setError(null);
    setForm({
      username: user.username,
      email: user.email,
      displayName: user.displayName,
      password: '',
      role: user.role,
      jobDescription: user.jobDescription ?? '',
      customFields: (user.customFields ?? []).map((f) => ({ ...f })),
    });
    setShowPw(false);
    setMode({ kind: 'edit', user });
  };

  const backToList = () => {
    setMode({ kind: 'list' });
    setForm(EMPTY_FORM);
    setShowPw(false);
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const profilePayload = {
        jobDescription: form.jobDescription.trim(),
        customFields: form.customFields
          .map((f) => ({
            id: f.id,
            label: f.label.trim(),
            value: f.value.trim(),
          }))
          .filter((f) => f.label),
      };
      if (mode.kind === 'create') {
        await api('/api/users', {
          method: 'POST',
          json: {
            username: form.username.trim(),
            email: form.email.trim(),
            displayName: form.displayName.trim() || form.username.trim(),
            password: form.password,
            role: form.role,
            ...profilePayload,
          },
        });
        setNotice(`User “${form.username.trim()}” created.`);
      } else if (mode.kind === 'edit') {
        const payload: Record<string, unknown> = {
          username: form.username.trim(),
          email: form.email.trim(),
          displayName: form.displayName.trim() || form.username.trim(),
          role: form.role,
          ...profilePayload,
        };
        if (form.password.trim()) payload.password = form.password.trim();
        await api(`/api/users/${mode.user.id}`, {
          method: 'PATCH',
          json: payload,
        });
        if (form.password.trim() && mode.user.id === auth.user?.id) {
          setNotice(
            `User “${form.username.trim()}” updated. Your password changed — you may need to sign in again.`,
          );
        } else {
          setNotice(`User “${form.username.trim()}” updated.`);
        }
      }
      await load();
      backToList();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const onDelete = async (user: SiteUser) => {
    if (user.id === auth.user?.id) return;
    if (user.isOwner) return;
    const ok = window.confirm(
      `Delete user “${user.username}”? They will lose access immediately. This cannot be undone.`,
    );
    if (!ok) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await api(`/api/users/${user.id}`, { method: 'DELETE' });
      setNotice(`User “${user.username}” deleted.`);
      if (mode.kind === 'edit' && mode.user.id === user.id) backToList();
      await load();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const strength = form.password ? passwordStrength(form.password) : null;

  const tableFilters: AdminTableFilter[] = useMemo(
    () => [
      {
        key: 'username',
        label: 'Username',
        type: 'text',
        placeholder: 'Filter username…',
      },
      {
        key: 'name',
        label: 'Name',
        type: 'text',
        placeholder: 'Filter name…',
      },
      {
        key: 'role',
        label: 'Role',
        type: 'select',
        allLabel: 'All roles',
        options: roles.map((r) => ({ value: r.slug, label: r.label })),
      },
    ],
    [roles],
  );

  const columns: AdminTableColumn<SiteUser>[] = useMemo(
    () => [
      {
        key: 'username',
        header: 'Username',
        render: (user) => {
          const isYou = user.id === auth.user?.id;
          return (
            <>
              <strong className="bk-table__primary">{user.username}</strong>
              {isYou ? <span className="bk-table__badge">You</span> : null}
              {user.isOwner ? (
                <span className="bk-table__badge is-accent">Owner</span>
              ) : null}
              <div className="bk-table__row-actions">
                {canEdit ? (
                  <button type="button" className="button-link" onClick={() => openEdit(user)}>
                    Edit
                  </button>
                ) : null}
                {canDelete && !isYou && !user.isOwner ? (
                  <>
                    {canEdit ? <span className="bk-table__sep">|</span> : null}
                    <button
                      type="button"
                      className="button-link is-danger"
                      disabled={busy}
                      onClick={() => onDelete(user)}
                    >
                      Delete
                    </button>
                  </>
                ) : null}
              </div>
            </>
          );
        },
      },
      {
        key: 'name',
        header: 'Name',
        render: (user) => user.displayName,
      },
      {
        key: 'email',
        header: 'Email',
        render: (user) => <a href={`mailto:${user.email}`}>{user.email}</a>,
      },
      {
        key: 'role',
        header: 'Role',
        render: (user) => user.roleLabel,
      },
    ],
    [auth.user?.id, busy, canDelete, canEdit],
  );

  const filterUsers = useCallback((row: SiteUser, values: Record<string, string>) => {
    const username = values.username?.trim().toLowerCase() ?? '';
    const name = values.name?.trim().toLowerCase() ?? '';
    const role = values.role?.trim() ?? '';
    if (username && !row.username.toLowerCase().includes(username)) return false;
    if (name && !row.displayName.toLowerCase().includes(name)) return false;
    if (role && row.role !== role) return false;
    return true;
  }, []);

  if (mode.kind !== 'list') {
    const editing = mode.kind === 'edit' ? mode.user : null;
    const formId = 'user-form';
    return (
      <div className="wrap wrap--wide">
        <PageHeader
          title={editing ? 'Edit user' : 'Add new user'}
          actions={
            <>
              <button
                type="submit"
                form={formId}
                className="button button-primary"
                disabled={busy}
              >
                {busy ? 'Saving…' : editing ? 'Update user' : 'Add user'}
              </button>
              <button type="button" className="button" disabled={busy} onClick={backToList}>
                Cancel
              </button>
            </>
          }
        />
        <p className="bk-muted">
          {editing ? (
            <>
              Updating <strong>{editing.username}</strong>
              {editing.isOwner ? ' · site owner' : ''}.
            </>
          ) : (
            'Create an account for someone who needs access to this site.'
          )}
        </p>

        {error ? (
          <div className="beekiri-notice is-error" role="alert">
            <p>{error}</p>
          </div>
        ) : null}

        <form id={formId} className="bk-panel" onSubmit={onSubmit}>
          <div className="bk-panel__body">
            <table className="form-table">
              <tbody>
                <tr>
                  <th scope="row">
                    <label htmlFor="user_username">Username</label>
                  </th>
                  <td>
                    <input
                      id="user_username"
                      className="regular-text"
                      type="text"
                      autoComplete="off"
                      required
                      minLength={3}
                      maxLength={60}
                      value={form.username}
                      onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))}
                    />
                    <p className="description">Letters, numbers, and . - _ only.</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="user_email">Email</label>
                  </th>
                  <td>
                    <input
                      id="user_email"
                      className="regular-text"
                      type="email"
                      autoComplete="off"
                      required
                      value={form.email}
                      onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="user_display">Display name</label>
                  </th>
                  <td>
                    <input
                      id="user_display"
                      className="regular-text"
                      type="text"
                      autoComplete="off"
                      maxLength={120}
                      value={form.displayName}
                      placeholder={form.username || 'Shown publicly'}
                      onChange={(e) => setForm((f) => ({ ...f, displayName: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="user_job">Job description</label>
                  </th>
                  <td>
                    <textarea
                      id="user_job"
                      rows={3}
                      maxLength={2000}
                      value={form.jobDescription}
                      placeholder="Optional — role, team, or what this person does"
                      onChange={(e) =>
                        setForm((f) => ({ ...f, jobDescription: e.target.value }))
                      }
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <span id="user_custom_label">Custom fields</span>
                  </th>
                  <td>
                    <div className="bk-user-custom" aria-labelledby="user_custom_label">
                      {form.customFields.map((field, index) => (
                        <div key={field.id} className="bk-user-custom__row">
                          <input
                            className="regular-text"
                            type="text"
                            maxLength={80}
                            placeholder="Label"
                            aria-label={`Custom field ${index + 1} label`}
                            value={field.label}
                            onChange={(e) => {
                              const label = e.target.value;
                              setForm((f) => ({
                                ...f,
                                customFields: f.customFields.map((row) =>
                                  row.id === field.id ? { ...row, label } : row,
                                ),
                              }));
                            }}
                          />
                          <input
                            className="regular-text"
                            type="text"
                            maxLength={500}
                            placeholder="Value"
                            aria-label={`Custom field ${index + 1} value`}
                            value={field.value}
                            onChange={(e) => {
                              const value = e.target.value;
                              setForm((f) => ({
                                ...f,
                                customFields: f.customFields.map((row) =>
                                  row.id === field.id ? { ...row, value } : row,
                                ),
                              }));
                            }}
                          />
                          <button
                            type="button"
                            className="button-link is-danger"
                            aria-label={`Remove custom field ${index + 1}`}
                            onClick={() =>
                              setForm((f) => ({
                                ...f,
                                customFields: f.customFields.filter((row) => row.id !== field.id),
                              }))
                            }
                          >
                            Remove
                          </button>
                        </div>
                      ))}
                      <button
                        type="button"
                        className="button"
                        onClick={() =>
                          setForm((f) => ({
                            ...f,
                            customFields: [...f.customFields, newCustomField()],
                          }))
                        }
                      >
                        + Add field
                      </button>
                      <p className="description">
                        Optional extras for this user only — department, phone, notes, etc.
                      </p>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="user_role">Role</label>
                  </th>
                  <td>
                    <select
                      id="user_role"
                      value={form.role}
                      disabled={Boolean(editing?.isOwner)}
                      onChange={(e) =>
                        setForm((f) => ({ ...f, role: e.target.value as RoleSlug }))
                      }
                    >
                      {roles.map((r) => (
                        <option key={r.slug} value={r.slug}>
                          {r.label}
                        </option>
                      ))}
                    </select>
                    {editing?.isOwner ? (
                      <p className="description">The site owner stays an administrator.</p>
                    ) : (
                      <p className="description">
                        Administrators can manage settings and users. Editors manage content.
                      </p>
                    )}
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="user_password">
                      {editing ? 'New password' : 'Password'}
                    </label>
                  </th>
                  <td>
                    <div className="bk-user-pw">
                      <input
                        id="user_password"
                        className="regular-text"
                        type={showPw ? 'text' : 'password'}
                        autoComplete="new-password"
                        required={!editing}
                        minLength={editing && !form.password ? undefined : 8}
                        value={form.password}
                        placeholder={editing ? 'Leave blank to keep current password' : ''}
                        onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
                      />
                      <button
                        type="button"
                        className="button"
                        onClick={() => setShowPw((v) => !v)}
                      >
                        {showPw ? 'Hide' : 'Show'}
                      </button>
                      <button
                        type="button"
                        className="button"
                        onClick={() => {
                          setForm((f) => ({ ...f, password: generatePassword(16) }));
                          setShowPw(true);
                        }}
                      >
                        Generate
                      </button>
                    </div>
                    {strength ? (
                      <p className={`bk-pw-strength is-${strength}`}>Strength: {strength}</p>
                    ) : editing ? (
                      <p className="description">Leave blank to keep the current password.</p>
                    ) : null}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </form>
      </div>
    );
  }

  const canClearFilters = hasActiveAdminFilters(filterValues);

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Users"
        actions={
          <>
            {canClearFilters ? (
              <button
                type="button"
                className="button"
                onClick={() => setFilterValues(EMPTY_FILTERS)}
              >
                Clear filters
              </button>
            ) : null}
            {canCreate ? (
              <button type="button" className="button button-primary" onClick={openCreate}>
                Add user
              </button>
            ) : null}
          </>
        }
      />
      <p className="bk-muted">
        People who can sign in to this Beekiri site. {users.length} total.
      </p>

      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}

      <AdminDataTable
        rows={users}
        columns={columns}
        getRowId={(u) => u.id}
        filters={tableFilters}
        filterValues={filterValues}
        onFilterChange={(values) =>
          setFilterValues({
            username: values.username ?? '',
            name: values.name ?? '',
            role: values.role ?? '',
          })
        }
        filterFn={filterUsers}
        loading={loading}
        defaultPageSize={10}
        pageSizeOptions={[10, 25, 50]}
        emptyTitle="No users yet. Add the first account to get started."
        emptyFilteredTitle="No users match these filters."
      />
    </div>
  );
}
