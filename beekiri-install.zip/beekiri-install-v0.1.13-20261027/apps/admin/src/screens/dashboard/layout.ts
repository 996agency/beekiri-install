import {
  DEFAULT_LAYOUT,
  SPAN_STEPS,
  STORAGE_KEY,
  WIDGET_META,
  type LayoutItem,
  type WidgetId,
  type WidgetSpan,
} from './types';

function isWidgetId(v: unknown): v is WidgetId {
  return typeof v === 'string' && v in WIDGET_META;
}

function isSpan(v: unknown): v is WidgetSpan {
  return typeof v === 'number' && (SPAN_STEPS as number[]).includes(v);
}

export function nudgeSpan(current: WidgetSpan, delta: -1 | 1): WidgetSpan {
  const i = SPAN_STEPS.indexOf(current);
  const next = Math.max(0, Math.min(SPAN_STEPS.length - 1, (i < 0 ? 1 : i) + delta));
  return SPAN_STEPS[next]!;
}

export function loadLayout(): LayoutItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [...DEFAULT_LAYOUT];
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [...DEFAULT_LAYOUT];
    const items: LayoutItem[] = [];
    const seen = new Set<string>();
    for (const row of parsed) {
      if (!row || typeof row !== 'object') continue;
      const id = (row as { id?: unknown }).id;
      const span = (row as { span?: unknown }).span;
      if (!isWidgetId(id) || seen.has(id)) continue;
      items.push({ id, span: isSpan(span) ? span : WIDGET_META[id].defaultSpan });
      seen.add(id);
    }
    return items.length ? items : [...DEFAULT_LAYOUT];
  } catch {
    return [...DEFAULT_LAYOUT];
  }
}

export function saveLayout(items: LayoutItem[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}

export function availableWidgets(layout: LayoutItem[]): WidgetId[] {
  const active = new Set(layout.map((i) => i.id));
  return (Object.keys(WIDGET_META) as WidgetId[]).filter((id) => !active.has(id));
}

export function formatRelative(iso: string | null | undefined): string {
  if (!iso) return '—';
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return '—';
  const diff = Date.now() - t;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 48) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
  if (n < 1024 * 1024 * 1024) return `${Math.round(n / (1024 * 1024))} MB`;
  return `${(n / (1024 * 1024 * 1024)).toFixed(1)} GB`;
}

export function humanAction(action: string): string {
  return action.replace(/[._]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}
