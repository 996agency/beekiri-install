import { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import '../styles/wp/install.css';
import './login-auth.css';
import { BrandMark } from '../components/BrandMark';
import { MeshGradientCanvas } from '../components/MeshGradientCanvas';

const SITE = import.meta.env.VITE_APP_URL ?? 'http://127.0.0.1:8789';

type Props = {
  title: string;
  subtitle: string;
  children: ReactNode;
  brandTo?: string;
};

/** Shared full-bleed split auth layout (login / forgot / reset). */
export function AuthShell({ title, subtitle, children, brandTo = '/login' }: Props) {
  return (
    <div className="bk-auth">
      <div className="bk-auth__frame">
        <aside className="bk-auth__visual" aria-hidden="true">
          <MeshGradientCanvas className="bk-auth__canvas" />
          <div className="bk-auth__quotes">
            <h2>Publish clearly. Manage calmly.</h2>
            <p>One workspace for pages, media, and the sites you grow.</p>
            <p className="bk-auth__credit">Beekiri — proprietary CMS by 996agency</p>
          </div>
        </aside>

        <main className="bk-auth__panel">
          <div className="bk-auth__panel-inner">
            <Link className="bk-auth__brand" to={brandTo} title="Beekiri">
              <BrandMark size={36} />
              <span className="bk-auth__brand-name">Beekiri</span>
            </Link>

            <h1 className="bk-auth__title">{title}</h1>
            <p className="bk-auth__subtitle">{subtitle}</p>

            {children}

            <p className="bk-auth__footer">
              <a href={SITE}>← Back to site</a>
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}
