import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../styles/wp/install.css';
import { api, ApiError } from '../api/client';
import { BrandMark } from '../components/BrandMark';
import { generatePassword, passwordStrength } from '../util/password';

type Status = {
  installed: boolean;
  databaseOk: boolean;
  databaseMessage: string;
  canInstall: boolean;
  frontendRuntimes?: FrontendOption[];
};

type FrontendRuntime = 'php' | 'react';

type FrontendOption = {
  id: string;
  label: string;
  available: boolean;
};

const FRONTEND_DETAILS: Record<string, { tagline: string; detail: string }> = {
  php: {
    tagline: 'Recommended',
    detail:
      'Theme templates are .php files (header, footer, layouts) using the Bee field API — familiar to WordPress developers.',
  },
  react: {
    tagline: 'Components',
    detail: 'Theme templates are React .tsx components rendered by the Next.js frontend.',
  },
  vue: {
    tagline: 'Coming soon',
    detail: 'Vue single-file component themes are on the roadmap.',
  },
};

const DEFAULT_FRONTENDS: FrontendOption[] = [
  { id: 'php', label: 'PHP', available: true },
  { id: 'react', label: 'React', available: true },
  { id: 'vue', label: 'Vue', available: false },
];

type Step = 'language' | 'welcome' | 'frontend' | 'setup' | 'success';

const STEP_ORDER: Step[] = ['language', 'welcome', 'frontend', 'setup', 'success'];

export function InstallWizard() {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>('language');
  const [status, setStatus] = useState<Status | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const [language, setLanguage] = useState('en_US');
  const [siteTitle, setSiteTitle] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [email, setEmail] = useState('');
  const [blogPublic, setBlogPublic] = useState(true);
  const [frontendRuntime, setFrontendRuntime] = useState<FrontendRuntime>('php');
  const frontends = status?.frontendRuntimes?.length ? status.frontendRuntimes : DEFAULT_FRONTENDS;
  const frontendLabel = frontends.find((f) => f.id === frontendRuntime)?.label ?? 'PHP';

  const refreshStatus = async () => {
    const s = await api<Status>('/api/install/status');
    setStatus(s);
    if (s.installed) navigate('/login', { replace: true });
  };

  useEffect(() => {
    refreshStatus().catch((e) =>
      setError(
        e instanceof ApiError
          ? e.message
          : e instanceof Error
            ? e.message
            : 'This site is temporarily unavailable. Please try again in a moment — your content is safe.',
      ),
    );
  }, []);

  const strength = passwordStrength(password);
  const stepIndex = STEP_ORDER.indexOf(step);

  const runInstall = async () => {
    setBusy(true);
    setError(null);
    try {
      await api('/api/install', {
        json: { language, siteTitle, username, password, email, blogPublic, frontendRuntime },
      });
      setStep('success');
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Installation failed');
    } finally {
      setBusy(false);
    }
  };

  const titles: Record<Step, { title: string; subtitle: string }> = {
    language: {
      title: 'Choose a language',
      subtitle: 'Pick the default language for this site’s admin workspace.',
    },
    welcome: {
      title: 'Set up this site',
      subtitle:
        'Every new Beekiri site starts here — on your machine or a client server. Publish pages, manage media, and launch in about a minute.',
    },
    frontend: {
      title: 'Choose your frontend',
      subtitle:
        'How should this site’s theme be built? The CMS stays the same either way — this only decides the language of your theme templates.',
    },
    setup: {
      title: 'Create your site',
      subtitle:
        'Name the site and create the owner account for this client. No default password is ever shipped.',
    },
    success: {
      title: 'Site ready',
      subtitle: `This Beekiri site is installed with the ${frontendLabel} frontend. Sign in with the owner username to open the dashboard.`,
    },
  };

  return (
    <div className="bk-install">
      <div className="bk-install__shell">
        <header className="bk-install__brand">
          <a
            href="/"
            className="bk-install__mark"
            title="Beekiri"
            onClick={(e) => e.preventDefault()}
          >
            <BrandMark size={64} />
          </a>
          <p className="bk-install__product">Beekiri</p>
        </header>

        <main className="bk-install__card">
          <ul className="bk-install__steps" aria-hidden="true">
            {STEP_ORDER.map((s, i) => (
              <li
                key={s}
                className={i < stepIndex ? 'is-done' : i === stepIndex ? 'is-active' : undefined}
              />
            ))}
          </ul>

          <h1 className="bk-install__title">{titles[step].title}</h1>
          <p className="bk-install__subtitle">{titles[step].subtitle}</p>

          {error && (
            <div className="bk-install__alert" role="alert">
              {error}
            </div>
          )}

          {step === 'language' && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setStep('welcome');
              }}
            >
              <div className="bk-install__field">
                <label htmlFor="language">Language</label>
                <select
                  id="language"
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                >
                  <option value="en_US">English (United States)</option>
                  <option value="en_GB">English (UK)</option>
                  <option value="de_DE">Deutsch</option>
                  <option value="fr_FR">Français</option>
                  <option value="es_ES">Español</option>
                </select>
              </div>
              <div className="bk-install__actions">
                <button type="submit" className="bk-install__btn bk-install__btn--primary">
                  Continue
                </button>
              </div>
            </form>
          )}

          {step === 'welcome' && (
            <div>
              <div
                className={`bk-install__status ${
                  status?.databaseOk ? 'is-ok' : status ? 'is-bad' : ''
                }`}
              >
                <span className="bk-install__status-dot" />
                <span>
                  <strong style={{ color: '#1d1d1f', fontWeight: 600 }}>Database</strong>
                  <br />
                  {status?.databaseMessage ?? 'Checking connection…'}
                </span>
              </div>

              {!status?.databaseOk && status && (
                <div className="bk-install__alert" role="alert">
                  The server cannot reach the database. Set <code>DATABASE_URL</code> in the
                  environment (or <code>.env</code>), run migrations, then retry. Database
                  credentials are never collected in this browser wizard.
                </div>
              )}

              <div className="bk-install__actions bk-install__actions--spread">
                <button
                  type="button"
                  className="bk-install__btn bk-install__btn--ghost"
                  onClick={() => setStep('language')}
                >
                  Back
                </button>
                <div style={{ display: 'flex', gap: 10 }}>
                  {!status?.databaseOk && (
                    <button
                      type="button"
                      className="bk-install__btn bk-install__btn--secondary"
                      onClick={() => void refreshStatus()}
                    >
                      Retry
                    </button>
                  )}
                  <button
                    type="button"
                    className="bk-install__btn bk-install__btn--primary"
                    disabled={!status?.canInstall}
                    onClick={() => setStep('frontend')}
                  >
                    Continue
                  </button>
                </div>
              </div>
            </div>
          )}

          {step === 'frontend' && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setStep('setup');
              }}
            >
              <div className="bk-install__choices" role="radiogroup" aria-label="Frontend">
                {frontends.map((option) => {
                  const details = FRONTEND_DETAILS[option.id];
                  const selected = option.available && option.id === frontendRuntime;
                  return (
                    <label
                      key={option.id}
                      className={`bk-install__choice${selected ? ' is-selected' : ''}${
                        option.available ? '' : ' is-disabled'
                      }`}
                    >
                      <input
                        type="radio"
                        name="frontendRuntime"
                        value={option.id}
                        checked={selected}
                        disabled={!option.available}
                        onChange={() => setFrontendRuntime(option.id as FrontendRuntime)}
                      />
                      <span className="bk-install__choice-body">
                        <span className="bk-install__choice-head">
                          <strong>{option.label}</strong>
                          {details ? (
                            <span className="bk-install__choice-tag">
                              {option.available ? details.tagline : 'Coming soon'}
                            </span>
                          ) : null}
                        </span>
                        {details ? (
                          <span className="bk-install__choice-detail">{details.detail}</span>
                        ) : null}
                      </span>
                    </label>
                  );
                })}
              </div>

              <p className="bk-install__note">
                This choice is permanent for this site. To switch later, reset the site (
                <code>pnpm reset</code> — your database and uploads are backed up first) and run the
                installer again.
              </p>

              <div className="bk-install__actions bk-install__actions--spread">
                <button
                  type="button"
                  className="bk-install__btn bk-install__btn--ghost"
                  onClick={() => setStep('welcome')}
                >
                  Back
                </button>
                <button type="submit" className="bk-install__btn bk-install__btn--primary">
                  Continue with {frontendLabel}
                </button>
              </div>
            </form>
          )}

          {step === 'setup' && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                void runInstall();
              }}
            >
              <div className="bk-install__field">
                <label htmlFor="weblog_title">Site title</label>
                <input
                  id="weblog_title"
                  required
                  autoComplete="organization"
                  value={siteTitle}
                  onChange={(e) => setSiteTitle(e.target.value)}
                />
              </div>
              <div className="bk-install__field">
                <label htmlFor="user_login">Username</label>
                <input
                  id="user_login"
                  autoComplete="username"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>
              <div className="bk-install__field">
                <label htmlFor="pass1">Password</label>
                <div className="bk-install__pw">
                  <input
                    id="pass1"
                    type={showPw ? 'text' : 'password'}
                    autoComplete="new-password"
                    required
                    minLength={8}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    className="bk-install__pw-toggle"
                    onClick={() => setShowPw((v) => !v)}
                  >
                    {showPw ? 'Hide' : 'Show'}
                  </button>
                </div>
              </div>
              <div className="bk-install__meta">
                <span className={`bk-install__strength ${strength}`}>
                  {password ? `Strength · ${strength}` : 'Use at least 8 characters'}
                </span>
                <button
                  type="button"
                  className="bk-install__linkish"
                  onClick={() => setPassword(generatePassword())}
                >
                  Generate
                </button>
              </div>
              <div className="bk-install__field">
                <label htmlFor="admin_email">Email</label>
                <input
                  id="admin_email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <label className="bk-install__check">
                <input
                  type="checkbox"
                  checked={blogPublic}
                  onChange={(e) => setBlogPublic(e.target.checked)}
                />
                <span>Allow search engines to index this site</span>
              </label>
              <div className="bk-install__actions bk-install__actions--spread">
                <button
                  type="button"
                  className="bk-install__btn bk-install__btn--ghost"
                  onClick={() => setStep('frontend')}
                >
                  Back
                </button>
                <button
                  type="submit"
                  className="bk-install__btn bk-install__btn--primary"
                  disabled={busy || (password.length > 0 && strength === 'weak')}
                >
                  {busy ? 'Installing…' : 'Install'}
                </button>
              </div>
            </form>
          )}

          {step === 'success' && (
            <div className="bk-install__success">
              <div className="bk-install__success-icon" aria-hidden="true">
                ✓
              </div>
              <div className="bk-install__actions" style={{ justifyContent: 'center' }}>
                <Link to="/login" className="bk-install__btn bk-install__btn--primary">
                  Sign in
                </Link>
              </div>
            </div>
          )}
        </main>

        <p className="bk-install__footer">Beekiri · First-run installer for every new site</p>
      </div>
    </div>
  );
}
