import { useEffect, useRef, useState } from 'react';
import { api, ApiError } from '../api/client';

export type MenuItem = {
  id: string;
  label: string;
  path: string;
  enabled: boolean;
  source?: 'home' | 'page' | 'post' | 'taxonomy' | 'custom';
  refId?: string;
  children?: MenuItem[];
};

export type PermalinkStructure = 'plain' | 'postname' | 'dayname' | 'custom';

type LinkTarget = {
  id: string;
  label: string;
  path: string;
  source: 'home' | 'page' | 'post' | 'taxonomy' | 'custom';
  kind?: string;
};

type LinkTargetsResponse = {
  system: LinkTarget[];
  pages: LinkTarget[];
  posts: LinkTarget[];
  taxonomies: LinkTarget[];
};

type Props = {
  siteTitle: string;
  permalinkStructure: PermalinkStructure;
  permalinkCustom: string;
  menuItems: MenuItem[];
  busy: boolean;
  onSave: (data: {
    permalinkStructure: PermalinkStructure;
    permalinkCustom: string;
    menuItems: MenuItem[];
    frontPageId?: string;
    frontPageSlug?: string;
  }) => void;
};

type PickerTab = 'pages' | 'posts' | 'taxonomies' | 'custom';

type PickerMode =
  | { kind: 'root'; index: number }
  | { kind: 'child'; parentId: string };

const LIVE = import.meta.env.VITE_APP_URL ?? 'http://127.0.0.1:8789';

function uid() {
  return `item-${Math.random().toString(36).slice(2, 9)}`;
}

function toSlug(label: string): string {
  return label
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .replace(/-{2,}/g, '-');
}

function cleanPath(path: string): string {
  let p = path.trim();
  if (!p || p === '/') return '/';
  if (/^https?:\/\//i.test(p)) return p;
  if (!p.startsWith('/')) p = `/${p}`;
  return p.replace(/\/+$/, '') || '/';
}

function parentPrefix(parentPath: string): string {
  const p = cleanPath(parentPath);
  return p === '/' ? '' : p;
}

function childPath(parentPath: string, slug: string): string {
  const base = parentPrefix(parentPath);
  const s = toSlug(slug) || 'item';
  return cleanPath(`${base}/${s}`);
}

function findItem(items: MenuItem[], id: string): MenuItem | null {
  for (const item of items) {
    if (item.id === id) return item;
    if (item.children?.length) {
      const hit = findItem(item.children, id);
      if (hit) return hit;
    }
  }
  return null;
}

function findParentPath(items: MenuItem[], id: string, parentPath?: string): string | null {
  for (const item of items) {
    if (item.id === id) return parentPath ?? null;
    if (item.children?.length) {
      const hit = findParentPath(item.children, id, cleanPath(item.path || '/'));
      if (hit !== null) return hit;
    }
  }
  return null;
}

/** Which top-level root owns this item (itself if root). */
function findRootId(items: MenuItem[], id: string): string | null {
  for (const item of items) {
    if (item.id === id) return item.id;
    if (item.children?.length && findItem(item.children, id)) return item.id;
  }
  return null;
}

function mapTree(items: MenuItem[], id: string, fn: (item: MenuItem) => MenuItem): MenuItem[] {
  return items.map((item) => {
    if (item.id === id) return fn(item);
    if (item.children?.length) {
      return { ...item, children: mapTree(item.children, id, fn) };
    }
    return item;
  });
}

function removeFromTree(items: MenuItem[], id: string): MenuItem[] {
  return items
    .filter((item) => item.id !== id)
    .map((item) =>
      item.children?.length
        ? { ...item, children: removeFromTree(item.children, id) }
        : item,
    );
}

function countNodes(items: MenuItem[]): number {
  return items.reduce((n, item) => n + 1 + countNodes(item.children ?? []), 0);
}

function moveInSiblings(items: MenuItem[], id: string, dir: -1 | 1): MenuItem[] | null {
  const index = items.findIndex((i) => i.id === id);
  if (index >= 0) {
    const next = index + dir;
    if (next < 0 || next >= items.length) return items;
    const copy = [...items];
    const tmp = copy[index];
    copy[index] = copy[next];
    copy[next] = tmp;
    return copy;
  }
  let changed = false;
  const mapped = items.map((item) => {
    if (!item.children?.length) return item;
    const kids = moveInSiblings(item.children, id, dir);
    if (kids && kids !== item.children) {
      changed = true;
      return { ...item, children: kids };
    }
    return item;
  });
  return changed ? mapped : null;
}

function siblingInfo(
  items: MenuItem[],
  id: string,
): { index: number; length: number; isRoot: boolean } | null {
  const index = items.findIndex((i) => i.id === id);
  if (index >= 0) return { index, length: items.length, isRoot: true };
  for (const item of items) {
    if (!item.children?.length) continue;
    const nested = siblingInfo(item.children, id);
    if (nested) return { ...nested, isRoot: false };
  }
  return null;
}

function isFrontPageItem(item: MenuItem): boolean {
  return cleanPath(item.path || '/') === '/';
}

/** Promote one top-level item to `/`; demote the previous front page to a slug path. */
function assignFrontPage(items: MenuItem[], id: string): MenuItem[] {
  if (!items.some((m) => m.id === id)) return items;
  return items.map((item) => {
    if (item.id === id) {
      return { ...item, path: '/', source: item.source === 'custom' ? 'home' : item.source || 'home' };
    }
    if (isFrontPageItem(item)) {
      const slug = toSlug(item.label) || 'page';
      return {
        ...item,
        path: cleanPath(`/${slug}`),
        source: item.source === 'home' ? 'page' : item.source,
      };
    }
    return item;
  });
}

function fullUrl(path: string) {
  if (/^https?:\/\//i.test(path)) return path;
  return `${LIVE.replace(/\/$/, '')}${path.startsWith('/') ? path : `/${path}`}`;
}

export function PermalinksPanel({
  siteTitle,
  permalinkStructure,
  permalinkCustom,
  menuItems: initialMenu,
  busy,
  onSave,
}: Props) {
  const [structure] = useState<PermalinkStructure>(permalinkStructure);
  const [customStruct] = useState(permalinkCustom);
  const [menu, setMenu] = useState<MenuItem[]>(initialMenu);
  const [rootId, setRootId] = useState(initialMenu[0]?.id ?? '');
  const [activeId, setActiveId] = useState(initialMenu[0]?.id ?? '');

  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerMode, setPickerMode] = useState<PickerMode>({ kind: 'root', index: 0 });
  const [pickerTab, setPickerTab] = useState<PickerTab>('pages');
  const [targets, setTargets] = useState<LinkTargetsResponse | null>(null);
  const [targetsError, setTargetsError] = useState<string | null>(null);
  const [customLabel, setCustomLabel] = useState('');
  const [customPath, setCustomPath] = useState('/');
  const [pathManual, setPathManual] = useState(false);
  const [parentPathForPicker, setParentPathForPicker] = useState('/');
  /** Remember slug before an item was promoted to `/` so Save can wire the CMS page. */
  const frontSlugById = useRef<Record<string, string>>({});

  const active = findItem(menu, activeId) ?? menu[0] ?? null;
  const focusedRoot = menu.find((m) => m.id === rootId) ?? menu[0] ?? null;

  useEffect(() => {
    if (!pickerOpen) return;
    setTargetsError(null);
    api<LinkTargetsResponse>('/api/site/link-targets')
      .then(setTargets)
      .catch((e) =>
        setTargetsError(e instanceof ApiError ? e.message : 'Could not load content'),
      );
  }, [pickerOpen]);

  const saveMenu = () => {
    const front = menu.find((m) => isFrontPageItem(m));
    const frontPageSlug = front
      ? frontSlugById.current[front.id] ||
        toSlug(front.label) ||
        (front.path && front.path !== '/'
          ? front.path.replace(/^\//, '').split('/').filter(Boolean)[0]
          : '') ||
        undefined
      : undefined;
    onSave({
      permalinkStructure: structure,
      permalinkCustom: customStruct,
      menuItems: menu,
      frontPageId: front?.refId || undefined,
      frontPageSlug: frontPageSlug || undefined,
    });
  };

  const updateActive = (patch: Partial<MenuItem>) => {
    if (!active) return;
    setMenu(mapTree(menu, active.id, (item) => ({ ...item, ...patch })));
  };

  const selectItem = (id: string) => {
    setActiveId(id);
    const root = findRootId(menu, id);
    if (root) setRootId(root);
  };

  const selectRoot = (id: string) => {
    setRootId(id);
    setActiveId(id);
  };

  const openRootPicker = (index: number) => {
    setPickerMode({ kind: 'root', index });
    setPickerTab('custom');
    setCustomLabel('');
    setCustomPath('/');
    setPathManual(false);
    setParentPathForPicker('/');
    setPickerOpen(true);
  };

  const openChildPicker = (parentId: string) => {
    const parent = findItem(menu, parentId);
    const prefix = parent ? cleanPath(parent.path || '/') : '/';
    setPickerMode({ kind: 'child', parentId });
    setPickerTab('custom');
    setCustomLabel('');
    setCustomPath(prefix === '/' ? '/' : `${prefix}/`);
    setPathManual(false);
    setParentPathForPicker(prefix);
    setPickerOpen(true);
  };

  const onCustomLabelChange = (label: string) => {
    setCustomLabel(label);
    if (pathManual) return;
    const slug = toSlug(label);
    if (pickerMode.kind === 'child') {
      setCustomPath(
        slug ? childPath(parentPathForPicker, slug) : `${parentPrefix(parentPathForPicker)}/`,
      );
    } else {
      setCustomPath(slug ? `/${slug}` : '/');
    }
  };

  const insertItem = (item: MenuItem) => {
    if (pickerMode.kind === 'root') {
      const next = [...menu];
      next.splice(pickerMode.index, 0, item);
      setMenu(next);
      setRootId(item.id);
    } else {
      setMenu(
        mapTree(menu, pickerMode.parentId, (parent) => ({
          ...parent,
          children: [...(parent.children ?? []), item],
        })),
      );
      const root = findRootId(menu, pickerMode.parentId) ?? pickerMode.parentId;
      setRootId(root);
    }
    setActiveId(item.id);
    setPickerOpen(false);
  };

  const pickTarget = (t: LinkTarget) => {
    const path =
      pickerMode.kind === 'child' ? childPath(parentPathForPicker, t.label) : cleanPath(t.path);
    insertItem({
      id: uid(),
      label: t.label,
      path,
      enabled: true,
      source: t.source,
      refId: t.id,
    });
  };

  const pickCustom = () => {
    const label = customLabel.trim() || 'Custom link';
    let path = customPath.trim();
    if (!path || path === `${parentPrefix(parentPathForPicker)}/`) {
      path =
        pickerMode.kind === 'child'
          ? childPath(parentPathForPicker, label)
          : `/${toSlug(label) || 'link'}`;
    }
    path = cleanPath(path);
    insertItem({
      id: uid(),
      label,
      path,
      enabled: true,
      source: 'custom',
    });
  };

  const onActiveLabelChange = (label: string) => {
    if (!active) return;
    const prevSlugPath =
      active.source === 'custom' || !active.source
        ? cleanPath(
            findParentPath(menu, active.id)
              ? childPath(findParentPath(menu, active.id)!, toSlug(active.label))
              : `/${toSlug(active.label) || 'link'}`,
          )
        : null;
    const pathWasAuto = prevSlugPath && cleanPath(active.path) === prevSlugPath;
    if (pathWasAuto) {
      const parent = findParentPath(menu, active.id);
      const nextPath = parent ? childPath(parent, label) : `/${toSlug(label) || 'link'}`;
      updateActive({ label, path: nextPath, source: 'custom' });
    } else {
      updateActive({ label });
    }
  };

  const removeActive = () => {
    if (!active || countNodes(menu) <= 1) return;
    const next = removeFromTree(menu, active.id);
    setMenu(next);
    const nextRoot = next.find((m) => m.id === rootId) ?? next[0];
    setRootId(nextRoot?.id ?? '');
    setActiveId(nextRoot?.id ?? '');
  };

  const moveActive = (dir: -1 | 1) => {
    if (!active) return;
    const moved = moveInSiblings(menu, active.id, dir);
    if (moved) setMenu(moved);
  };

  const moveRoot = (id: string, dir: -1 | 1) => {
    const moved = moveInSiblings(menu, id, dir);
    if (moved) {
      setMenu(moved);
      setRootId(id);
      setActiveId(id);
    }
  };

  const setActiveAsFrontPage = () => {
    if (!active) return;
    if (!menu.some((m) => m.id === active.id)) return;
    const prev = cleanPath(active.path || '/');
    const slugFromPath =
      prev !== '/'
        ? prev.replace(/^\//, '').split('/').filter(Boolean)[0] || ''
        : '';
    const slug = slugFromPath || toSlug(active.label) || '';
    if (slug) frontSlugById.current[active.id] = slug;
    setMenu(assignFrontPage(menu, active.id));
  };

  const activeSiblings = active ? siblingInfo(menu, active.id) : null;
  const activeIsFront = active ? isFrontPageItem(active) : false;
  const activeIsTopLevel = Boolean(active && menu.some((m) => m.id === active.id));

  const listForTab = (): LinkTarget[] => {
    if (!targets) return [];
    if (pickerTab === 'pages')
      return [...targets.system.filter((s) => s.path === '/'), ...targets.pages];
    if (pickerTab === 'posts')
      return [...targets.system.filter((s) => s.path === '/blog'), ...targets.posts];
    return targets.taxonomies;
  };

  const emptyCopy: Record<Exclude<PickerTab, 'custom'>, string> = {
    pages: 'No pages yet. Create pages under Pages, or add a custom link.',
    posts: 'No posts yet. Create posts under Posts, or add a custom link.',
    taxonomies: 'No categories or tags yet. They’ll show up here when you create them.',
  };

  const renderBranch = (items: MenuItem[], parentId: string, parentLabel: string, depth: number) => (
    <ul className={`bk-menu-branch${depth > 0 ? ' is-nested' : ''}`}>
      {items.map((item) => {
        const kids = item.children ?? [];
        const isActive = activeId === item.id;
        return (
          <li key={item.id} className="bk-menu-branch__item">
            <button
              type="button"
              className={`bk-menu-card${!item.enabled ? ' is-off' : ''}${
                isActive ? ' is-active' : ''
              }`}
              onClick={() => selectItem(item.id)}
            >
              <span className="bk-menu-card__body">
                <span className="bk-menu-card__title">{item.label || 'Untitled'}</span>
                <span className="bk-menu-card__sub">
                  {item.path || '/'}
                  {!item.enabled ? ' · Hidden' : ''}
                </span>
              </span>
            </button>

            {kids.length > 0 ? (
              <div className="bk-menu-branch__nest">
                {renderBranch(kids, item.id, item.label || 'item', depth + 1)}
              </div>
            ) : null}
          </li>
        );
      })}
      <li className="bk-menu-branch__item is-add">
        <button
          type="button"
          className="bk-menu-branch__add"
          onClick={() => openChildPicker(parentId)}
        >
          + Add under “{parentLabel}”
        </button>
      </li>
    </ul>
  );

  const rootKids = focusedRoot?.children ?? [];

  return (
    <div className="bk-stack bk-permalinks">
      <section className="bk-panel">
        <div className="bk-panel__head">
          <div>
            <h2 className="bk-panel__title">Link map</h2>
            <p className="bk-muted" style={{ margin: '4px 0 0', fontWeight: 300 }}>
              Top row is the main menu for {siteTitle || 'your site'}. Reorder with ← →, and mark
              one item as the front page (URL <code>/</code>).
            </p>
          </div>
          <button
            type="button"
            className="button button-primary"
            disabled={busy}
            onClick={saveMenu}
          >
            {busy ? 'Saving…' : 'Save menu'}
          </button>
        </div>

        <div className="bk-panel__body">
          <div className="bk-menu-canvas">
            <div className="bk-menu-main">
              <p className="bk-menu-main__label">Main menu</p>
              <div className="bk-menu-tabs" role="tablist" aria-label="Main menu items">
                {menu.map((item, index) => (
                  <div
                    key={item.id}
                    className={`bk-menu-tab-group${focusedRoot?.id === item.id ? ' is-active' : ''}`}
                  >
                    <button
                      type="button"
                      role="tab"
                      aria-selected={focusedRoot?.id === item.id}
                      className={`bk-menu-tab${focusedRoot?.id === item.id ? ' is-active' : ''}${
                        !item.enabled ? ' is-off' : ''
                      }`}
                      onClick={() => selectRoot(item.id)}
                    >
                      <span className="bk-menu-tab__label">{item.label || 'Untitled'}</span>
                      {isFrontPageItem(item) ? (
                        <span className="bk-menu-tab__front">Front page</span>
                      ) : null}
                      {(item.children?.length ?? 0) > 0 ? (
                        <span className="bk-menu-tab__count">{item.children!.length}</span>
                      ) : null}
                    </button>
                    {focusedRoot?.id === item.id ? (
                      <span className="bk-menu-tab__move">
                        <button
                          type="button"
                          className="bk-menu-tab__move-btn"
                          aria-label={`Move ${item.label || 'item'} left`}
                          title="Move left"
                          disabled={index === 0}
                          onClick={() => moveRoot(item.id, -1)}
                        >
                          ←
                        </button>
                        <button
                          type="button"
                          className="bk-menu-tab__move-btn"
                          aria-label={`Move ${item.label || 'item'} right`}
                          title="Move right"
                          disabled={index >= menu.length - 1}
                          onClick={() => moveRoot(item.id, 1)}
                        >
                          →
                        </button>
                      </span>
                    ) : null}
                  </div>
                ))}
                <button
                  type="button"
                  className="bk-menu-tab is-add"
                  onClick={() => openRootPicker(menu.length)}
                  aria-label="Add main menu item"
                >
                  + Add
                </button>
              </div>
            </div>

            <div className="bk-menu-workspace">
              <div className="bk-menu-flow">
                {focusedRoot ? (
                  <>
                    <button
                      type="button"
                      className={`bk-menu-card bk-menu-card--root${
                        !focusedRoot.enabled ? ' is-off' : ''
                      }${activeId === focusedRoot.id ? ' is-active' : ''}`}
                      onClick={() => selectItem(focusedRoot.id)}
                    >
                      <span className="bk-menu-card__body">
                        <span className="bk-menu-card__title">
                          {focusedRoot.label || 'Untitled'}
                          {isFrontPageItem(focusedRoot) ? (
                            <span className="bk-menu-card__front">Front page</span>
                          ) : null}
                        </span>
                        <span className="bk-menu-card__sub">
                          {fullUrl(focusedRoot.path || '/')}
                        </span>
                      </span>
                    </button>

                    {renderBranch(
                      rootKids,
                      focusedRoot.id,
                      focusedRoot.label || 'item',
                      0,
                    )}
                  </>
                ) : (
                  <p className="bk-muted">Add a main menu item to get started.</p>
                )}
              </div>

              {active ? (
                <aside className="bk-flow-side">
                  <p className="bk-flow-side__label">Edit item</p>
                  <div className="bk-field">
                    <label htmlFor="flow_label">Label</label>
                    <input
                      id="flow_label"
                      type="text"
                      value={active.label}
                      onChange={(e) => onActiveLabelChange(e.target.value)}
                    />
                  </div>
                  <div className="bk-field">
                    <label htmlFor="flow_path">URL path</label>
                    <input
                      id="flow_path"
                      type="text"
                      value={active.path}
                      onChange={(e) =>
                        updateActive({
                          path: cleanPath(e.target.value || '/'),
                          source: 'custom',
                        })
                      }
                      placeholder="/about/team"
                    />
                    <p className="description">
                      Auto-fills from the label. Nested items become{' '}
                      <code>/parent/slug</code>.
                    </p>
                  </div>
                  <label className="bk-check" style={{ marginTop: 4 }}>
                    <input
                      type="checkbox"
                      checked={active.enabled}
                      onChange={(e) => updateActive({ enabled: e.target.checked })}
                    />
                    <span className="bk-check__box" aria-hidden />
                    <span className="bk-check__label">Show in public menu</span>
                  </label>
                  {activeIsTopLevel ? (
                    <label className="bk-check" style={{ marginTop: 8 }}>
                      <input
                        type="checkbox"
                        checked={activeIsFront}
                        onChange={(e) => {
                          if (e.target.checked) setActiveAsFrontPage();
                        }}
                        disabled={activeIsFront}
                      />
                      <span className="bk-check__box" aria-hidden />
                      <span className="bk-check__label">
                        {activeIsFront ? 'Front page of the site' : 'Set as front page'}
                      </span>
                    </label>
                  ) : null}
                  {activeIsFront ? (
                    <p className="description" style={{ marginTop: 6 }}>
                      This page is served at <code>/</code> (home).
                    </p>
                  ) : null}
                  <button
                    type="button"
                    className="button button-primary"
                    style={{ width: '100%' }}
                    onClick={() => openChildPicker(active.id)}
                  >
                    Add under “{active.label || 'this'}”
                  </button>
                  <div className="bk-flow-side__actions">
                    <button
                      type="button"
                      className="button"
                      onClick={() => moveActive(-1)}
                      disabled={!activeSiblings || activeSiblings.index <= 0}
                    >
                      {activeIsTopLevel ? 'Move left' : 'Move up'}
                    </button>
                    <button
                      type="button"
                      className="button"
                      onClick={() => moveActive(1)}
                      disabled={
                        !activeSiblings ||
                        activeSiblings.index >= activeSiblings.length - 1
                      }
                    >
                      {activeIsTopLevel ? 'Move right' : 'Move down'}
                    </button>
                    <button
                      type="button"
                      className="button"
                      onClick={removeActive}
                      disabled={countNodes(menu) <= 1 || activeIsFront}
                      title={
                        activeIsFront
                          ? 'Set another front page before removing this one'
                          : undefined
                      }
                    >
                      Remove
                    </button>
                  </div>
                </aside>
              ) : null}
            </div>
          </div>
        </div>
      </section>

      {pickerOpen ? (
        <div
          className="bk-picker"
          role="dialog"
          aria-modal="true"
          aria-labelledby="bk-picker-title"
          onClick={(e) => {
            if (e.target === e.currentTarget) setPickerOpen(false);
          }}
        >
          <div className="bk-picker__panel">
            <div className="bk-picker__head">
              <h3 id="bk-picker-title">
                {pickerMode.kind === 'child'
                  ? `Add under “${findItem(menu, pickerMode.parentId)?.label ?? 'parent'}”`
                  : 'Add to main menu'}
              </h3>
              <button
                type="button"
                className="button"
                onClick={() => setPickerOpen(false)}
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            <div className="bk-picker__tabs" role="tablist">
              {(
                [
                  ['pages', 'Pages'],
                  ['posts', 'Posts'],
                  ['taxonomies', 'Taxonomies'],
                  ['custom', 'Custom link'],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  role="tab"
                  aria-selected={pickerTab === id}
                  className={`bk-picker__tab${pickerTab === id ? ' is-active' : ''}`}
                  onClick={() => setPickerTab(id)}
                >
                  {label}
                </button>
              ))}
            </div>

            <div className="bk-picker__body">
              {pickerTab === 'custom' ? (
                <div className="bk-picker__custom">
                  <div className="bk-field">
                    <label htmlFor="picker_custom_label">Label</label>
                    <input
                      id="picker_custom_label"
                      type="text"
                      value={customLabel}
                      onChange={(e) => onCustomLabelChange(e.target.value)}
                      placeholder={pickerMode.kind === 'child' ? 'Team' : 'About'}
                      autoFocus
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          pickCustom();
                        }
                      }}
                    />
                  </div>
                  <div className="bk-field">
                    <label htmlFor="picker_custom_path">URL path</label>
                    <input
                      id="picker_custom_path"
                      type="text"
                      value={customPath}
                      onChange={(e) => {
                        setPathManual(true);
                        setCustomPath(e.target.value);
                      }}
                      placeholder={
                        pickerMode.kind === 'child'
                          ? `${parentPrefix(parentPathForPicker) || ''}/team`
                          : '/about'
                      }
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          pickCustom();
                        }
                      }}
                    />
                    <p className="description">
                      {pickerMode.kind === 'child'
                        ? `Fills as ${parentPrefix(parentPathForPicker) || ''}/your-slug from the label.`
                        : 'Fills as /your-slug from the label. Edit anytime to override.'}
                    </p>
                  </div>
                  <button
                    type="button"
                    className="button button-primary"
                    onClick={pickCustom}
                  >
                    Add custom link
                  </button>
                </div>
              ) : (
                <>
                  {targetsError ? (
                    <p className="bk-muted">{targetsError}</p>
                  ) : !targets ? (
                    <p className="bk-muted">Loading…</p>
                  ) : listForTab().length === 0 ? (
                    <div className="bk-picker__empty">
                      <p>{emptyCopy[pickerTab]}</p>
                      <button
                        type="button"
                        className="button button-primary"
                        onClick={() => setPickerTab('custom')}
                      >
                        Add custom link instead
                      </button>
                    </div>
                  ) : (
                    <ul className="bk-picker__list">
                      {listForTab().map((t) => (
                        <li key={`${t.source}-${t.id}`}>
                          <button
                            type="button"
                            className="bk-picker__item"
                            onClick={() => pickTarget(t)}
                          >
                            <span className="bk-picker__item-label">{t.label}</span>
                            <span className="bk-picker__item-path">{t.path}</span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
