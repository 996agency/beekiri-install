import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import {
  AdminDataTable,
  type AdminTableColumn,
} from '../components/AdminDataTable';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import type { FieldGroup } from './fields/FieldGroupEditPage';

type LocationOption = { value: string; label: string };

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

export function BackendFieldsPage() {
  const [groups, setGroups] = useState<FieldGroup[]>([]);
  const [locations, setLocations] = useState<LocationOption[]>([
    { value: 'post', label: 'Posts' },
    { value: 'page', label: 'Pages' },
    { value: 'user', label: 'Users' },
    { value: 'media', label: 'Media' },
  ]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const n = (location.state as { notice?: string } | null)?.notice;
    if (n) setNotice(n);
  }, [location.key, location.state]);

  const load = useCallback(async () => {
    setError(null);
    const [res, meta] = await Promise.all([
      api<{ groups: FieldGroup[] }>('/api/fields'),
      api<{ locations: LocationOption[] }>('/api/fields/meta'),
    ]);
    setGroups(res.groups);
    if (meta.locations?.length) setLocations(meta.locations);
  }, []);

  useEffect(() => {
    setLoading(true);
    load()
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [load]);

  const onDelete = async (group: FieldGroup) => {
    const ok = window.confirm(
      `Delete field group “${group.title}”? This does not delete content values already saved on posts.`,
    );
    if (!ok) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await api(`/api/fields/${group.id}`, { method: 'DELETE' });
      setNotice(`Field group “${group.title}” deleted.`);
      await load();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const columns: AdminTableColumn<FieldGroup>[] = useMemo(
    () => [
      {
        key: 'title',
        header: 'Group',
        render: (group) => (
          <>
            <Link className="bk-table__primary" to={`/admin/fields/${group.id}`}>
              <strong>{group.title}</strong>
            </Link>
            {!group.active ? <span className="bk-table__badge">Inactive</span> : null}
            <div className="bk-table__row-actions">
              <Link className="button-link" to={`/admin/fields/${group.id}`}>
                Edit
              </Link>
              <span className="bk-table__sep">|</span>
              <button
                type="button"
                className="button-link is-danger"
                disabled={busy}
                onClick={() => onDelete(group)}
              >
                Delete
              </button>
            </div>
          </>
        ),
      },
      {
        key: 'key',
        header: 'Key',
        render: (group) => <code>{group.key}</code>,
      },
      {
        key: 'fields',
        header: 'Fields',
        render: (group) => group.fieldCount,
      },
      {
        key: 'location',
        header: 'Location',
        render: (group) =>
          group.location.length
            ? group.location
                .map((v) => locations.find((o) => o.value === v)?.label ?? v)
                .join(', ')
            : '—',
      },
    ],
    [busy, locations],
  );

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Field Groups"
        actions={
          <button type="button" className="button button-primary" onClick={() => navigate('/admin/fields/new')}>
            Add New
          </button>
        }
      />
      <p className="bk-muted">
        Define reusable field groups for pages, posts, and other content. {groups.length} group
        {groups.length === 1 ? '' : 's'}.
      </p>

      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}

      <AdminDataTable
        rows={groups}
        columns={columns}
        getRowId={(g) => g.id}
        loading={loading}
        defaultPageSize={10}
        pageSizeOptions={[10, 25, 50]}
        emptyTitle="No field groups yet. Add one to start collecting custom data."
      />
    </div>
  );
}
