import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import {
  AdminDataTable,
  hasActiveAdminFilters,
  type AdminTableColumn,
  type AdminTableFilter,
} from '../components/AdminDataTable';
import { PageHeader } from '../components/PageHeader';
import { SuccessNotice } from '../components/SuccessNotice';
import {
  contentKindConfig,
  type ContentKind,
  type ContentKindConfig,
} from '../content/contentKind';

export type PageRow = {
  id: string;
  title: string;
  slug: string;
  status: 'auto-draft' | 'draft' | 'publish';
  content: string;
  beekiricanva?: unknown | null;
  /** BeekiriCode page tree (preferred). */
  beekiricode?: unknown | null;
  /** @deprecated Legacy key — read via beekiricode when present. */
  instatic?: unknown | null;
  excerpt: string;
  authorId?: string | null;
  authorName?: string | null;
  updatedById?: string | null;
  updatedByName?: string | null;
  revisionCount?: number;
  parentId?: string | null;
  path: string;
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
};

export type PageRevisionRow = {
  id: string;
  title: string;
  slug: string;
  status: string;
  authorId: string | null;
  authorName: string | null;
  createdAt: string;
};

const EMPTY_FILTERS = { title: '', status: '' };
const LIVE_SITE = import.meta.env.VITE_APP_URL ?? 'http://127.0.0.1:8789';

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

function displayTitle(row: PageRow) {
  const t = row.title.trim();
  return t || '(no title)';
}

function ContentListPage({ kind }: { kind: ContentKind }) {
  const cfg = contentKindConfig(kind);
  const auth = useAuth();
  const navigate = useNavigate();
  const canEdit = auth.user?.capabilities.includes(cfg.editCap) ?? false;
  const canDelete = auth.user?.capabilities.includes(cfg.deleteCap) ?? false;

  const [rows, setRows] = useState<PageRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [filterValues, setFilterValues] = useState(EMPTY_FILTERS);

  const load = useCallback(async () => {
    const res = await api<Record<string, PageRow[]>>(cfg.apiBase);
    setRows(res[cfg.listKey] ?? []);
  }, [cfg.apiBase, cfg.listKey]);

  useEffect(() => {
    if (!canEdit) {
      setLoading(false);
      return;
    }
    setLoading(true);
    load()
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [canEdit, load]);

  const addNew = async () => {
    if (!canEdit || creating) return;
    setCreating(true);
    setError(null);
    try {
      const row = await api<PageRow>(cfg.apiBase, {
        method: 'POST',
        json: { autoDraft: true, status: 'auto-draft' },
      });
      navigate(`${cfg.listPath}/${row.id}`);
    } catch (e) {
      setError(formatError(e));
      setCreating(false);
    }
  };

  const onDelete = async (row: PageRow) => {
    if (!canDelete) return;
    if (
      !window.confirm(
        `Move “${displayTitle(row)}” to trash? This deletes the ${cfg.labelLower}.`,
      )
    ) {
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await api(`${cfg.apiBase}/${row.id}`, { method: 'DELETE' });
      setNotice(`${cfg.label} “${displayTitle(row)}” deleted.`);
      await load();
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const filters: AdminTableFilter[] = useMemo(
    () => [
      { key: 'title', label: 'Title', type: 'text', placeholder: 'Search title…' },
      {
        key: 'status',
        label: 'Status',
        type: 'select',
        allLabel: 'All statuses',
        options: [
          { value: 'publish', label: 'Published' },
          { value: 'draft', label: 'Draft' },
        ],
      },
    ],
    [],
  );

  const columns: AdminTableColumn<PageRow>[] = useMemo(
    () => [
      {
        key: 'title',
        header: 'Title',
        render: (row) => (
          <>
            <strong className="bk-table__primary">{displayTitle(row)}</strong>
            {row.status === 'draft' ? (
              <span className="bk-table__badge">Draft</span>
            ) : row.status === 'publish' ? (
              <span className="bk-table__badge is-accent">Published</span>
            ) : null}
            <div className="bk-table__row-actions" onClick={(e) => e.stopPropagation()}>
              {canEdit ? (
                <Link className="button-link" to={`${cfg.listPath}/${row.id}`}>
                  Edit
                </Link>
              ) : null}
              {canEdit && canDelete ? <span className="bk-table__sep">|</span> : null}
              {canDelete ? (
                <button
                  type="button"
                  className="button-link is-danger"
                  disabled={busy}
                  onClick={() => void onDelete(row)}
                >
                  Delete
                </button>
              ) : null}
              {row.status === 'publish' ? (
                <>
                  <span className="bk-table__sep">|</span>
                  <a
                    className="button-link"
                    href={`${LIVE_SITE}${row.path}`}
                    target="_blank"
                    rel="noreferrer"
                  >
                    View
                  </a>
                </>
              ) : null}
            </div>
          </>
        ),
      },
      {
        key: 'slug',
        header: 'Slug',
        render: (row) => <code>{row.slug}</code>,
      },
      {
        key: 'updated',
        header: 'Last updated',
        render: (row) => formatDate(row.updatedAt),
      },
    ],
    [busy, canDelete, canEdit, cfg.listPath],
  );

  if (!canEdit) {
    return (
      <div className="wrap wrap--wide">
        <PageHeader title={cfg.labelPlural} />
        <div className="beekiri-notice is-info">
          <p>
            You need the {cfg.editCap} capability to manage {cfg.labelPlural.toLowerCase()}.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title={cfg.labelPlural}
        actions={
          <>
            {hasActiveAdminFilters(filterValues) ? (
              <button
                type="button"
                className="button"
                onClick={() => setFilterValues(EMPTY_FILTERS)}
              >
                Clear filters
              </button>
            ) : null}
            <button
              type="button"
              className="button button-primary"
              disabled={creating}
              onClick={() => void addNew()}
            >
              {creating ? 'Creating…' : 'Add new'}
            </button>
          </>
        }
      />
      <p className="bk-muted">
        {cfg.blurb} {rows.length} total.
      </p>

      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}

      <AdminDataTable
        rows={rows}
        columns={columns}
        getRowId={(row) => row.id}
        filters={filters}
        filterValues={filterValues}
        onFilterChange={(values) => setFilterValues({ ...EMPTY_FILTERS, ...values })}
        filterFn={(row, values) => {
          const q = values.title.trim().toLowerCase();
          const title = displayTitle(row).toLowerCase();
          if (q && !title.includes(q) && !row.slug.toLowerCase().includes(q)) {
            return false;
          }
          if (values.status && row.status !== values.status) return false;
          return true;
        }}
        loading={loading}
        emptyTitle={cfg.emptyTitle}
        emptyFilteredTitle={cfg.emptyFilteredTitle}
      />
    </div>
  );
}

export function PagesPage() {
  return <ContentListPage kind="page" />;
}

export function PostsPage() {
  return <ContentListPage kind="post" />;
}

export type { ContentKindConfig };
