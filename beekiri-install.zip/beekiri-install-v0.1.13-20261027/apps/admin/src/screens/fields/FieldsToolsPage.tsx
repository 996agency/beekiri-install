import { useCallback, useEffect, useState } from 'react';
import { api, ApiError } from '../../api/client';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';

type Snapshot = {
  groups: number;
  postTypes: number;
  taxonomies: number;
  optionsPages: number;
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

export function FieldsToolsPage() {
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(async () => {
    const [groups, postTypes, taxonomies, optionsPages] = await Promise.all([
      api<{ groups: unknown[] }>('/api/fields'),
      api<{ postTypes: unknown[] }>('/api/fields/post-types'),
      api<{ taxonomies: unknown[] }>('/api/fields/taxonomies'),
      api<{ optionsPages: unknown[] }>('/api/fields/options-pages'),
    ]);
    setSnap({
      groups: groups.groups.length,
      postTypes: postTypes.postTypes.length,
      taxonomies: taxonomies.taxonomies.length,
      optionsPages: optionsPages.optionsPages.length,
    });
  }, []);

  useEffect(() => {
    load().catch((e) => setError(formatError(e)));
  }, [load]);

  const exportJson = async () => {
    setError(null);
    setNotice(null);
    try {
      const [groups, postTypes, taxonomies, optionsPages, settings] = await Promise.all([
        api('/api/fields'),
        api('/api/fields/post-types'),
        api('/api/fields/taxonomies'),
        api('/api/fields/options-pages'),
        api('/api/fields/settings'),
      ]);
      const blob = new Blob(
        [
          JSON.stringify(
            {
              exportedAt: new Date().toISOString(),
              groups,
              postTypes,
              taxonomies,
              optionsPages,
              settings,
            },
            null,
            2,
          ),
        ],
        { type: 'application/json' },
      );
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `beekiri-backend-fields-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setNotice('Export downloaded.');
    } catch (e) {
      setError(formatError(e));
    }
  };

  return (
    <div className="wrap wrap--wide">
      <PageHeader title="Tools" />
      <p className="bk-muted">Export and inspect your Backend Fields configuration.</p>

      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}

      <div className="bk-stack">
        <section className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Overview</h2>
          </div>
          <div className="bk-panel__body">
            <ul className="bk-rows">
              <li className="bk-row">
                <span className="bk-row__label">Field groups</span>
                <span className="bk-row__value">{snap?.groups ?? '…'}</span>
              </li>
              <li className="bk-row">
                <span className="bk-row__label">Post types</span>
                <span className="bk-row__value">{snap?.postTypes ?? '…'}</span>
              </li>
              <li className="bk-row">
                <span className="bk-row__label">Taxonomies</span>
                <span className="bk-row__value">{snap?.taxonomies ?? '…'}</span>
              </li>
              <li className="bk-row">
                <span className="bk-row__label">Options pages</span>
                <span className="bk-row__value">{snap?.optionsPages ?? '…'}</span>
              </li>
            </ul>
          </div>
        </section>

        <section className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Export</h2>
          </div>
          <div className="bk-panel__body">
            <p className="bk-muted" style={{ marginTop: 0 }}>
              Download a JSON snapshot of all field groups, post types, taxonomies, options pages,
              and module settings.
            </p>
            <button type="button" className="button button-primary" onClick={() => void exportJson()}>
              Export JSON
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}
