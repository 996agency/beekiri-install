import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { api, ApiError } from '../../api/client';
import { AdminDataTable, type AdminTableColumn } from '../../components/AdminDataTable';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';

type Taxonomy = {
  id: string;
  slug: string;
  singular: string;
  plural: string;
  description: string;
  hierarchical: boolean;
  public: boolean;
  objectTypes: string[];
  active: boolean;
};

type PostTypeOpt = { slug: string; plural: string; active: boolean };

type Mode = { kind: 'list' } | { kind: 'create' } | { kind: 'edit'; row: Taxonomy };

const BUILTIN_OBJECTS = [
  { slug: 'post', plural: 'Posts' },
  { slug: 'page', plural: 'Pages' },
];

const EMPTY = {
  slug: '',
  singular: '',
  plural: '',
  description: '',
  hierarchical: true,
  public: true,
  objectTypes: ['post'] as string[],
  active: true,
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

function toSlug(v: string) {
  return v
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
}

export function TaxonomiesPage() {
  const [rows, setRows] = useState<Taxonomy[]>([]);
  const [postTypes, setPostTypes] = useState<PostTypeOpt[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [mode, setMode] = useState<Mode>({ kind: 'list' });
  const [form, setForm] = useState(EMPTY);

  const objectOptions = useMemo(() => {
    const custom = postTypes
      .filter((p) => p.active)
      .map((p) => ({ slug: p.slug, plural: p.plural }));
    const seen = new Set(BUILTIN_OBJECTS.map((o) => o.slug));
    return [...BUILTIN_OBJECTS, ...custom.filter((c) => !seen.has(c.slug))];
  }, [postTypes]);

  const load = useCallback(async () => {
    const [tax, pts] = await Promise.all([
      api<{ taxonomies: Taxonomy[] }>('/api/fields/taxonomies'),
      api<{ postTypes: PostTypeOpt[] }>('/api/fields/post-types'),
    ]);
    setRows(tax.taxonomies);
    setPostTypes(pts.postTypes);
  }, []);

  useEffect(() => {
    setLoading(true);
    load()
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [load]);

  const openCreate = () => {
    setForm(EMPTY);
    setError(null);
    setNotice(null);
    setMode({ kind: 'create' });
  };

  const openEdit = (row: Taxonomy) => {
    setForm({
      slug: row.slug,
      singular: row.singular,
      plural: row.plural,
      description: row.description,
      hierarchical: row.hierarchical,
      public: row.public,
      objectTypes: [...row.objectTypes],
      active: row.active,
    });
    setError(null);
    setNotice(null);
    setMode({ kind: 'edit', row });
  };

  const back = () => {
    setMode({ kind: 'list' });
    setForm(EMPTY);
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const payload = {
        ...form,
        slug: form.slug.trim().toLowerCase(),
        singular: form.singular.trim(),
        plural: form.plural.trim(),
        description: form.description.trim(),
      };
      if (mode.kind === 'create') {
        await api('/api/fields/taxonomies', { method: 'POST', json: payload });
        setNotice(`Taxonomy “${payload.plural}” created.`);
      } else if (mode.kind === 'edit') {
        await api(`/api/fields/taxonomies/${mode.row.id}`, {
          method: 'PATCH',
          json: payload,
        });
        setNotice(`Taxonomy “${payload.plural}” updated.`);
      }
      await load();
      back();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const onDelete = async (row: Taxonomy) => {
    if (!window.confirm(`Delete taxonomy “${row.plural}”?`)) return;
    setBusy(true);
    try {
      await api(`/api/fields/taxonomies/${row.id}`, { method: 'DELETE' });
      setNotice(`Taxonomy “${row.plural}” deleted.`);
      await load();
      if (mode.kind === 'edit' && mode.row.id === row.id) back();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const columns: AdminTableColumn<Taxonomy>[] = useMemo(
    () => [
      {
        key: 'plural',
        header: 'Taxonomy',
        render: (row) => (
          <>
            <strong className="bk-table__primary">{row.plural}</strong>
            {!row.active ? <span className="bk-table__badge">Inactive</span> : null}
            <div className="bk-table__row-actions">
              <button type="button" className="button-link" onClick={() => openEdit(row)}>
                Edit
              </button>
              <span className="bk-table__sep">|</span>
              <button
                type="button"
                className="button-link is-danger"
                disabled={busy}
                onClick={() => onDelete(row)}
              >
                Delete
              </button>
            </div>
          </>
        ),
      },
      { key: 'slug', header: 'Slug', render: (row) => <code>{row.slug}</code> },
      {
        key: 'objects',
        header: 'Attached to',
        render: (row) =>
          row.objectTypes
            .map((s) => objectOptions.find((o) => o.slug === s)?.plural ?? s)
            .join(', ') || '—',
      },
      {
        key: 'kind',
        header: 'Type',
        render: (row) => (row.hierarchical ? 'Hierarchical' : 'Flat'),
      },
    ],
    [busy, objectOptions],
  );

  if (mode.kind !== 'list') {
    const formId = 'taxonomy-form';
    return (
      <div className="wrap wrap--wide">
        <PageHeader
          title={mode.kind === 'edit' ? 'Edit taxonomy' : 'Add taxonomy'}
          actions={
            <>
              <button type="submit" form={formId} className="button button-primary" disabled={busy}>
                {busy ? 'Saving…' : mode.kind === 'edit' ? 'Update' : 'Add taxonomy'}
              </button>
              <button type="button" className="button" disabled={busy} onClick={back}>
                Cancel
              </button>
            </>
          }
        />
        <p className="bk-muted">
          Create categories, tags, or custom taxonomies and attach them to posts or your custom post
          types.
        </p>
        {error ? (
          <div className="beekiri-notice is-error" role="alert">
            <p>{error}</p>
          </div>
        ) : null}
        <form id={formId} className="bk-panel" onSubmit={onSubmit}>
          <div className="bk-panel__body">
            <table className="form-table">
              <tbody>
                <tr>
                  <th scope="row">
                    <label htmlFor="tx_singular">Singular name</label>
                  </th>
                  <td>
                    <input
                      id="tx_singular"
                      className="regular-text"
                      required
                      value={form.singular}
                      onChange={(e) => {
                        const singular = e.target.value;
                        setForm((f) => ({
                          ...f,
                          singular,
                          plural: f.plural || `${singular}s`,
                          slug:
                            mode.kind === 'create' && (!f.slug || f.slug === toSlug(f.singular))
                              ? toSlug(singular)
                              : f.slug,
                        }));
                      }}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="tx_plural">Plural name</label>
                  </th>
                  <td>
                    <input
                      id="tx_plural"
                      className="regular-text"
                      required
                      value={form.plural}
                      onChange={(e) => setForm((f) => ({ ...f, plural: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="tx_slug">Slug</label>
                  </th>
                  <td>
                    <input
                      id="tx_slug"
                      className="regular-text"
                      required
                      value={form.slug}
                      onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="tx_desc">Description</label>
                  </th>
                  <td>
                    <textarea
                      id="tx_desc"
                      rows={2}
                      value={form.description}
                      onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">Attach to</th>
                  <td>
                    <div className="bk-fields-locations">
                      {objectOptions.map((opt) => (
                        <label key={opt.slug} className="bk-check">
                          <input
                            type="checkbox"
                            checked={form.objectTypes.includes(opt.slug)}
                            onChange={() =>
                              setForm((f) => ({
                                ...f,
                                objectTypes: f.objectTypes.includes(opt.slug)
                                  ? f.objectTypes.filter((s) => s !== opt.slug)
                                  : [...f.objectTypes, opt.slug],
                              }))
                            }
                          />
                          <span className="bk-check__box" aria-hidden />
                          <span className="bk-check__label">{opt.plural}</span>
                        </label>
                      ))}
                    </div>
                    <p className="description">
                      Choose posts, pages, or custom post types this taxonomy applies to.
                    </p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">Options</th>
                  <td>
                    <div className="bk-fields-locations">
                      {(
                        [
                          ['hierarchical', 'Hierarchical (like categories)'],
                          ['public', 'Public'],
                          ['active', 'Active'],
                        ] as const
                      ).map(([key, label]) => (
                        <label key={key} className="bk-check">
                          <input
                            type="checkbox"
                            checked={form[key]}
                            onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.checked }))}
                          />
                          <span className="bk-check__box" aria-hidden />
                          <span className="bk-check__label">{label}</span>
                        </label>
                      ))}
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Taxonomies"
        actions={
          <button type="button" className="button button-primary" onClick={openCreate}>
            Add taxonomy
          </button>
        }
      />
      <p className="bk-muted">
        Organize content with categories, tags, or custom taxonomies. {rows.length} registered.
      </p>
      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}
      <AdminDataTable
        rows={rows}
        columns={columns}
        getRowId={(r) => r.id}
        loading={loading}
        defaultPageSize={10}
        emptyTitle="No taxonomies yet. Add Brands, Topics, or any classification you need."
      />
    </div>
  );
}
