import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { api, ApiError } from '../../api/client';
import { AdminDataTable, type AdminTableColumn } from '../../components/AdminDataTable';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';

type PostType = {
  id: string;
  slug: string;
  singular: string;
  plural: string;
  description: string;
  public: boolean;
  hierarchical: boolean;
  hasArchive: boolean;
  showInMenu: boolean;
  supports: string[];
  active: boolean;
};

type Mode = { kind: 'list' } | { kind: 'create' } | { kind: 'edit'; row: PostType };

const SUPPORT_OPTIONS = [
  { value: 'title', label: 'Title' },
  { value: 'editor', label: 'Editor' },
  { value: 'thumbnail', label: 'Featured image' },
  { value: 'excerpt', label: 'Excerpt' },
  { value: 'custom-fields', label: 'Custom fields' },
];

const EMPTY = {
  slug: '',
  singular: '',
  plural: '',
  description: '',
  public: true,
  hierarchical: false,
  hasArchive: true,
  showInMenu: true,
  supports: ['title', 'editor'] as string[],
  active: true,
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

function toSlug(v: string) {
  return v
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
}

export function PostTypesPage() {
  const [rows, setRows] = useState<PostType[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [mode, setMode] = useState<Mode>({ kind: 'list' });
  const [form, setForm] = useState(EMPTY);

  const load = useCallback(async () => {
    const res = await api<{ postTypes: PostType[] }>('/api/fields/post-types');
    setRows(res.postTypes);
  }, []);

  useEffect(() => {
    setLoading(true);
    load()
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [load]);

  const openCreate = () => {
    setForm(EMPTY);
    setError(null);
    setNotice(null);
    setMode({ kind: 'create' });
  };

  const openEdit = (row: PostType) => {
    setForm({
      slug: row.slug,
      singular: row.singular,
      plural: row.plural,
      description: row.description,
      public: row.public,
      hierarchical: row.hierarchical,
      hasArchive: row.hasArchive,
      showInMenu: row.showInMenu,
      supports: [...row.supports],
      active: row.active,
    });
    setError(null);
    setNotice(null);
    setMode({ kind: 'edit', row });
  };

  const back = () => {
    setMode({ kind: 'list' });
    setForm(EMPTY);
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const payload = {
        ...form,
        slug: form.slug.trim().toLowerCase(),
        singular: form.singular.trim(),
        plural: form.plural.trim(),
        description: form.description.trim(),
      };
      if (mode.kind === 'create') {
        await api('/api/fields/post-types', { method: 'POST', json: payload });
        setNotice(`Post type “${payload.plural}” created.`);
      } else if (mode.kind === 'edit') {
        await api(`/api/fields/post-types/${mode.row.id}`, {
          method: 'PATCH',
          json: payload,
        });
        setNotice(`Post type “${payload.plural}” updated.`);
      }
      await load();
      back();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const onDelete = async (row: PostType) => {
    if (!window.confirm(`Delete post type “${row.plural}”?`)) return;
    setBusy(true);
    try {
      await api(`/api/fields/post-types/${row.id}`, { method: 'DELETE' });
      setNotice(`Post type “${row.plural}” deleted.`);
      await load();
      if (mode.kind === 'edit' && mode.row.id === row.id) back();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const columns: AdminTableColumn<PostType>[] = useMemo(
    () => [
      {
        key: 'plural',
        header: 'Post type',
        render: (row) => (
          <>
            <strong className="bk-table__primary">{row.plural}</strong>
            {!row.active ? <span className="bk-table__badge">Inactive</span> : null}
            <div className="bk-table__row-actions">
              <button type="button" className="button-link" onClick={() => openEdit(row)}>
                Edit
              </button>
              <span className="bk-table__sep">|</span>
              <button
                type="button"
                className="button-link is-danger"
                disabled={busy}
                onClick={() => onDelete(row)}
              >
                Delete
              </button>
            </div>
          </>
        ),
      },
      { key: 'slug', header: 'Slug', render: (row) => <code>{row.slug}</code> },
      {
        key: 'kind',
        header: 'Type',
        render: (row) => (row.hierarchical ? 'Hierarchical' : 'Flat'),
      },
    ],
    [busy],
  );

  if (mode.kind !== 'list') {
    const formId = 'post-type-form';
    return (
      <div className="wrap wrap--wide">
        <PageHeader
          title={mode.kind === 'edit' ? 'Edit post type' : 'Add post type'}
          actions={
            <>
              <button type="submit" form={formId} className="button button-primary" disabled={busy}>
                {busy ? 'Saving…' : mode.kind === 'edit' ? 'Update' : 'Add post type'}
              </button>
              <button type="button" className="button" disabled={busy} onClick={back}>
                Cancel
              </button>
            </>
          }
        />
        <p className="bk-muted">
          Register a custom content type — like Products, Events, or Team members — then attach
          field groups to it.
        </p>
        {error ? (
          <div className="beekiri-notice is-error" role="alert">
            <p>{error}</p>
          </div>
        ) : null}
        <form id={formId} className="bk-panel" onSubmit={onSubmit}>
          <div className="bk-panel__body">
            <table className="form-table">
              <tbody>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_singular">Singular name</label>
                  </th>
                  <td>
                    <input
                      id="pt_singular"
                      className="regular-text"
                      required
                      value={form.singular}
                      onChange={(e) => {
                        const singular = e.target.value;
                        setForm((f) => ({
                          ...f,
                          singular,
                          plural: f.plural || `${singular}s`,
                          slug:
                            mode.kind === 'create' && (!f.slug || f.slug === toSlug(f.singular))
                              ? toSlug(singular)
                              : f.slug,
                        }));
                      }}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_plural">Plural name</label>
                  </th>
                  <td>
                    <input
                      id="pt_plural"
                      className="regular-text"
                      required
                      value={form.plural}
                      onChange={(e) => setForm((f) => ({ ...f, plural: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_slug">Slug</label>
                  </th>
                  <td>
                    <input
                      id="pt_slug"
                      className="regular-text"
                      required
                      value={form.slug}
                      onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))}
                    />
                    <p className="description">Used in URLs and field group locations.</p>
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="pt_desc">Description</label>
                  </th>
                  <td>
                    <textarea
                      id="pt_desc"
                      rows={2}
                      value={form.description}
                      onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">Supports</th>
                  <td>
                    <div className="bk-fields-locations">
                      {SUPPORT_OPTIONS.map((opt) => (
                        <label key={opt.value} className="bk-check">
                          <input
                            type="checkbox"
                            checked={form.supports.includes(opt.value)}
                            onChange={() =>
                              setForm((f) => ({
                                ...f,
                                supports: f.supports.includes(opt.value)
                                  ? f.supports.filter((s) => s !== opt.value)
                                  : [...f.supports, opt.value],
                              }))
                            }
                          />
                          <span className="bk-check__box" aria-hidden />
                          <span className="bk-check__label">{opt.label}</span>
                        </label>
                      ))}
                    </div>
                  </td>
                </tr>
                <tr>
                  <th scope="row">Options</th>
                  <td>
                    <div className="bk-fields-locations">
                      {(
                        [
                          ['public', 'Public'],
                          ['hierarchical', 'Hierarchical (like pages)'],
                          ['hasArchive', 'Has archive'],
                          ['showInMenu', 'Show in admin menu'],
                          ['active', 'Active'],
                        ] as const
                      ).map(([key, label]) => (
                        <label key={key} className="bk-check">
                          <input
                            type="checkbox"
                            checked={form[key]}
                            onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.checked }))}
                          />
                          <span className="bk-check__box" aria-hidden />
                          <span className="bk-check__label">{label}</span>
                        </label>
                      ))}
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Post Types"
        actions={
          <button type="button" className="button button-primary" onClick={openCreate}>
            Add post type
          </button>
        }
      />
      <p className="bk-muted">
        Register custom content types for your site. {rows.length}{' '}
        registered.
      </p>
      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}
      <AdminDataTable
        rows={rows}
        columns={columns}
        getRowId={(r) => r.id}
        loading={loading}
        defaultPageSize={10}
        emptyTitle="No custom post types yet. Add one to create Products, Events, and more."
      />
    </div>
  );
}
