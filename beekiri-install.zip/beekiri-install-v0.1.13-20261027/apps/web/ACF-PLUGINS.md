# ACF Pro / ACFE in `apps/web`

The folders `advanced-custom-fields-pro` and `acf-extended-pro` are **WordPress plugins**. They only run inside WordPress (e.g. LocalWP AUK sites). Beekiri’s Next.js app does not load or execute them.

| WordPress (AUK) | Beekiri |
| --- | --- |
| ACF field groups UI | Backend Fields → `/admin/fields` |
| Flexible layouts + clone groups | Field groups synced to theme layouts |
| `layouts/{slug}/{slug}.php` | Same path under `themes/beekiri/layouts/` |
| Field helpers in PHP | Beekiri `get_bee_field()` / `have_bee_rows()` (legacy `get_sub_field` aliases kept) |
| ACFE modal “Add Section” | BeekiriCode Explorer → **Layouts** tab |

Keep working in Backend Fields + PHP layout folders. Do not expect the WP plugin UIs at `http://127.0.0.1:8787/admin/fields`.
