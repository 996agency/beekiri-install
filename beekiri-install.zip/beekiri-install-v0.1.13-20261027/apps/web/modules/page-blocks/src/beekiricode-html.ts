/**
 * AUK-style public HTML for BeekiriCode page trees.
 * Semantic sections only — no inline <style>, no hashed classes, no nested <main>.
 * Theme layout SCSS (layouts/{slug}/styles.css) owns the look.
 */

export type BeekiriCodePublishNode = {
  id: string;
  type: string;
  tag?: string;
  text?: string;
  src?: string;
  alt?: string;
  href?: string;
  layoutSlug?: string;
  layoutTitle?: string;
  layoutFields?: Record<string, unknown>;
  style?: Record<string, string>;
  stylesByBreakpoint?: { tablet?: Record<string, string>; mobile?: Record<string, string> };
  hiddenOn?: ('desktop' | 'tablet' | 'mobile')[];
  children: string[];
};

export type BeekiriCodePublishDoc = {
  version: 1;
  rootId: string;
  nodes: Record<string, BeekiriCodePublishNode>;
};

function escapeHtml(s: string) {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escapeAttr(s: string) {
  return escapeHtml(s).replace(/'/g, '&#39;');
}

function camelToKebab(s: string) {
  return s.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`);
}

/** Values go into a <style> block — strip anything that could close a rule or the tag. */
function cssValue(v: string): string {
  return v.trim().replace(/[{}<>;]/g, '');
}

function styleBagToCss(bag: Record<string, string> | undefined): string {
  if (!bag) return '';
  return Object.entries(bag)
    .filter(([k, v]) => /^[a-zA-Z]+$/.test(k) && typeof v === 'string' && v.trim() !== '')
    .map(([k, v]) => `${camelToKebab(k)}:${cssValue(v)}`)
    .filter((d) => !d.endsWith(':'))
    .join(';');
}

/** Same breakpoints as the editor frames (Desktop / Tablet 768 / Mobile 375). */
const MQ_TABLET = '(max-width: 1024px)';
const MQ_MOBILE = '(max-width: 767px)';
const MQ_ONLY = {
  desktop: '(min-width: 1025px)',
  tablet: '(min-width: 768px) and (max-width: 1024px)',
  mobile: '(max-width: 767px)',
} as const;

type CssSink = {
  base: string[];
  tablet: string[];
  mobile: string[];
  hide: Record<keyof typeof MQ_ONLY, string[]>;
};

const newSink = (): CssSink => ({
  base: [],
  tablet: [],
  mobile: [],
  hide: { desktop: [], tablet: [], mobile: [] },
});

function sinkToCss(s: CssSink): string {
  const out = [...s.base];
  if (s.tablet.length) out.push(`@media ${MQ_TABLET}{${s.tablet.join('')}}`);
  if (s.mobile.length) out.push(`@media ${MQ_MOBILE}{${s.mobile.join('')}}`);
  for (const bp of Object.keys(MQ_ONLY) as (keyof typeof MQ_ONLY)[]) {
    if (s.hide[bp].length) {
      out.push(`@media ${MQ_ONLY[bp]}{${s.hide[bp].join(',')}{display:none!important}}`);
    }
  }
  return out.join('\n');
}

/**
 * Collect Props styles for a node into the page stylesheet.
 * Returns the `data-bk` hook to put on the element ('' when it has no styles).
 */
function collectNodeCss(
  node: BeekiriCodePublishNode,
  sink: CssSink,
  clean: (bag: Record<string, string> | undefined) => Record<string, string> | undefined = (b) => b,
): string {
  const id = node.id.replace(/[^\w-]/g, '');
  if (!id) return '';
  const sel = `#main [data-bk="${id}"]`;
  const base = styleBagToCss(clean(node.style));
  const tablet = styleBagToCss(clean(node.stylesByBreakpoint?.tablet));
  const mobile = styleBagToCss(clean(node.stylesByBreakpoint?.mobile));
  const hidden = (node.hiddenOn ?? []).filter((bp) => bp in MQ_ONLY);
  if (!base && !tablet && !mobile && !hidden.length) return '';
  if (base) sink.base.push(`${sel}{${base}}`);
  if (tablet) sink.tablet.push(`${sel}{${tablet}}`);
  if (mobile) sink.mobile.push(`${sel}{${mobile}}`);
  for (const bp of hidden) sink.hide[bp].push(sel);
  return ` data-bk="${id}"`;
}

/** Drop leftover editor scaffold chrome so public HTML matches theme PHP. */
const LAYOUT_CHROME_KEYS = new Set([
  'display',
  'flexDirection',
  'flexWrap',
  'alignItems',
  'justifyContent',
  'gap',
  'rowGap',
  'columnGap',
  'padding',
  'paddingTop',
  'paddingRight',
  'paddingBottom',
  'paddingLeft',
  'border',
  'borderWidth',
  'borderStyle',
  'borderColor',
  'borderRadius',
  'minHeight',
]);

/** Early placeholder look (dashed border / #fafafa) — never real Props edits. */
function isLayoutScaffold(bag: Record<string, string> | undefined): boolean {
  if (!bag) return false;
  const norm = (v: string | undefined) => (v ?? '').replace(/\s/g, '').toLowerCase();
  return (
    norm(bag.border).includes('dashed') ||
    norm(bag.borderStyle) === 'dashed' ||
    norm(bag.background) === '#fafafa' ||
    norm(bag.backgroundColor) === '#fafafa'
  );
}

function cleanLayoutBag(bag: Record<string, string> | undefined): Record<string, string> | undefined {
  if (!bag || !isLayoutScaffold(bag)) return bag;
  const cleaned: Record<string, string> = {};
  for (const [k, v] of Object.entries(bag)) {
    if (LAYOUT_CHROME_KEYS.has(k)) continue;
    if ((k === 'background' || k === 'backgroundColor') && v.replace(/\s/g, '').toLowerCase() === '#fafafa') {
      continue;
    }
    cleaned[k] = v;
  }
  return cleaned;
}

/** Put the data-bk hook on the layout's root <section>. */
function injectSectionAttr(html: string, attr: string): string {
  if (!attr) return html;
  return html.replace(/<section\b/i, `<section${attr}`);
}

function isImageField(name: string, value: string) {
  if (/^(image|img|photo|thumbnail|logo)$/i.test(name)) return true;
  return /^(https?:\/\/|\/uploads\/|data:image\/)/i.test(value);
}

function renderLayoutFields(fields: Record<string, unknown> | undefined): string {
  if (!fields) return '';
  const parts: string[] = [];
  for (const [name, raw] of Object.entries(fields)) {
    // Only plain values here; nested ACF values (rows, links, ids) need the PHP layout.
    if (typeof raw !== 'string' && typeof raw !== 'number') continue;
    const v = String(raw).trim();
    if (!v) continue;
    if (isImageField(name, v)) {
      parts.push(
        `<figure class="bk-layout__field bk-layout__field--${escapeAttr(name)}"><img src="${escapeAttr(v)}" alt="" loading="lazy" decoding="async" /></figure>`,
      );
      continue;
    }
    if (name === 'title') {
      parts.push(
        `<div class="bk-layout__field bk-layout__field--title">${escapeHtml(v)}</div>`,
      );
      continue;
    }
    parts.push(
      `<div class="bk-layout__field bk-layout__field--${escapeAttr(name)}">${escapeHtml(v)}</div>`,
    );
  }
  return parts.join('');
}

function fallbackLayoutHtml(node: BeekiriCodePublishNode): string {
  const slug = (node.layoutSlug || '').trim() || 'layout';
  const fieldHtml = renderLayoutFields(node.layoutFields);
  const inner =
    fieldHtml ||
    `<p class="bk-layout__label">${escapeHtml(node.layoutTitle || slug)}</p>`;
  return [
    `<section class="${escapeAttr(slug)} section bk-layout bk-layout--${escapeAttr(slug)}" data-layout="${escapeAttr(slug)}">`,
    `<div class="wrapper"><div class="inner">${inner}</div></div>`,
    `</section>`,
  ].join('');
}

export type LayoutPhpRenderer = (
  slug: string,
  fields: Record<string, unknown>,
) => Promise<string | null>;

/**
 * Publish markup shaped like AgencyUK flexible layouts.
 * When `renderLayoutPhp` is provided, layout nodes run themes/.../{slug}.php.
 */
export function renderBeekiriCodeHtml(doc: BeekiriCodePublishDoc): string {
  // Sync path (no PHP) — used by admin publish payload; public site uses async.
  const root = doc?.nodes?.[doc.rootId];
  if (!root) return '';
  return (root.children || []).map((id) => walkSync(doc, id)).join('');
}

function walkSync(doc: BeekiriCodePublishDoc, id: string): string {
  const node = doc.nodes[id];
  if (!node) return '';

  if (node.type === 'image') {
    const src = (node.src || '').trim();
    if (!src) return '';
    return `<img class="bk-image" src="${escapeAttr(src)}" alt="${escapeAttr(node.alt || '')}" loading="lazy" decoding="async" />`;
  }

  if (node.type === 'layout') {
    return fallbackLayoutHtml(node);
  }

  if (node.type === 'heading') {
    const tag = node.tag && /^h[1-6]$/i.test(node.tag) ? node.tag.toLowerCase() : 'h2';
    const kids = (node.children || []).map((cid) => walkSync(doc, cid)).join('');
    return `<${tag} class="bk-heading">${escapeHtml(node.text || '')}${kids}</${tag}>`;
  }

  if (node.type === 'text') {
    const kids = (node.children || []).map((cid) => walkSync(doc, cid)).join('');
    return `<p class="bk-text">${escapeHtml(node.text || '')}${kids}</p>`;
  }

  if (node.type === 'button') {
    const href = escapeAttr(node.href || '#');
    return `<a class="bk-button" href="${href}">${escapeHtml(node.text || 'Button')}</a>`;
  }

  if (node.type === 'container') {
    const kids = (node.children || []).map((cid) => walkSync(doc, cid)).join('');
    return `<div class="bk-container">${kids}</div>`;
  }

  const kids = (node.children || []).map((cid) => walkSync(doc, cid)).join('');
  return `<section class="bk-section">${kids}</section>`;
}

const BOX_TAGS = new Set(['section', 'div', 'article', 'aside', 'header', 'footer', 'nav']);

/**
 * Public HTML + page stylesheet. Layouts run their PHP templates; Props styles
 * (incl. tablet/mobile overrides and hide-on-breakpoint) become CSS for <head>.
 */
export async function renderBeekiriCodePage(
  doc: BeekiriCodePublishDoc,
  renderLayoutPhp?: LayoutPhpRenderer,
): Promise<{ html: string; css: string }> {
  if (!doc?.rootId || !doc.nodes?.[doc.rootId]) return { html: '', css: '' };
  const sink = newSink();

  const walk = async (id: string): Promise<string> => {
    const node = doc.nodes[id];
    if (!node) return '';
    const kidsHtml = async () => (await Promise.all((node.children || []).map(walk))).join('');

    if (node.type === 'layout') {
      const slug = (node.layoutSlug || '').trim() || 'layout';
      const attr = collectNodeCss(node, sink, cleanLayoutBag);
      if (renderLayoutPhp) {
        try {
          const html = await renderLayoutPhp(slug, node.layoutFields || {});
          if (html && html.trim()) return injectSectionAttr(html, attr);
        } catch {
          /* fall through */
        }
      }
      return injectSectionAttr(fallbackLayoutHtml(node), attr);
    }

    if (node.type === 'image') {
      const src = (node.src || '').trim();
      if (!src) return '';
      const attr = collectNodeCss(node, sink);
      return `<img class="bk-image"${attr} src="${escapeAttr(src)}" alt="${escapeAttr(node.alt || '')}" loading="lazy" decoding="async" />`;
    }

    const attr = collectNodeCss(node, sink);

    if (node.type === 'heading') {
      const tag = node.tag && /^h[1-6]$/i.test(node.tag) ? node.tag.toLowerCase() : 'h2';
      return `<${tag} class="bk-heading"${attr}>${escapeHtml(node.text || '')}${await kidsHtml()}</${tag}>`;
    }

    if (node.type === 'text') {
      return `<p class="bk-text"${attr}>${escapeHtml(node.text || '')}${await kidsHtml()}</p>`;
    }

    if (node.type === 'button') {
      const href = escapeAttr(node.href || '#');
      return `<a class="bk-button"${attr} href="${href}">${escapeHtml(node.text || 'Button')}</a>`;
    }

    const tag = node.tag && BOX_TAGS.has(node.tag) ? node.tag : node.type === 'container' ? 'div' : 'section';
    const cls = node.type === 'container' ? 'bk-container' : 'bk-section';
    return `<${tag} class="${cls}"${attr}>${await kidsHtml()}</${tag}>`;
  };

  const root = doc.nodes[doc.rootId];
  const kids = (await Promise.all((root.children || []).map(walk))).join('');
  // Page (root) styles land on a .bk-page wrapper only when there are any.
  const rootAttr = collectNodeCss({ ...root, hiddenOn: undefined }, sink);
  const html = rootAttr ? `<div class="bk-page"${rootAttr}>${kids}</div>` : kids;
  return { html, css: sinkToCss(sink) };
}

/** HTML only (styles dropped) — prefer renderBeekiriCodePage for the public site. */
export async function renderBeekiriCodeHtmlAsync(
  doc: BeekiriCodePublishDoc,
  renderLayoutPhp?: LayoutPhpRenderer,
): Promise<string> {
  return (await renderBeekiriCodePage(doc, renderLayoutPhp)).html;
}

export function isBeekiriCodePublishDoc(raw: unknown): raw is BeekiriCodePublishDoc {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return false;
  const o = raw as Record<string, unknown>;
  return (
    o.version === 1 &&
    typeof o.rootId === 'string' &&
    !!o.nodes &&
    typeof o.nodes === 'object' &&
    !Array.isArray(o.nodes)
  );
}
