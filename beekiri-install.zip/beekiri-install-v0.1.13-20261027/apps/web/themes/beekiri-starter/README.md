# Deprecated stub

The official starter theme is **`apps/web/themes/beekiri`**.
