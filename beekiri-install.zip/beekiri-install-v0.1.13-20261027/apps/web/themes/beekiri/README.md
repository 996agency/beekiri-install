# Beekiri

Official starter theme for Beekiri CMS.

- Semantic landmarks (`header` / `main` / `footer` / `nav`)
- Theme **header** and **footer** under `header/` and `footer/`
- Layout sections under `layouts/` (created when you add Backend Fields)
- This install uses the **PHP** frontend — templates are `.php` files
- WCAG 2.2 AA focus styles and reduced-motion support
- Orange Beekiri accent aligned with the admin brand
- Public rendering is hosted by `apps/web` (Next.js App Router)

Activate from **Appearance → Themes** in the admin.
