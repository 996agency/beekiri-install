const { src, dest, watch, series, parallel } = require('gulp');
const sass = require('gulp-sass')(require('sass'));
const path = require('path');
const { Transform } = require('stream');

const ROOT = __dirname;
// Relative globs — absolute path.join globs often miss FS events on macOS/chokidar
const SCSS_GLOB = '*/styles.scss';

function renameMin() {
  return new Transform({
    objectMode: true,
    transform(file, _enc, cb) {
      if (file.path) {
        file.path = file.path.replace(/styles\.css$/, 'styles.min.css');
      }
      cb(null, file);
    },
  });
}

function stylesExpanded() {
  return src(SCSS_GLOB, { cwd: ROOT, base: ROOT })
    .pipe(
      sass({
        outputStyle: 'expanded',
        sourceMap: false,
      }).on('error', sass.logError),
    )
    .pipe(dest(ROOT));
}

function stylesMin() {
  return src(SCSS_GLOB, { cwd: ROOT, base: ROOT })
    .pipe(
      sass({
        outputStyle: 'compressed',
        sourceMap: false,
      }).on('error', sass.logError),
    )
    .pipe(renameMin())
    .pipe(dest(ROOT));
}

const styles = parallel(stylesExpanded, stylesMin);

function stylesWatch() {
  // Event-driven only (no polling). Compiles when you save a styles.scss — nothing else.
  watch(
    SCSS_GLOB,
    {
      cwd: ROOT,
      events: ['change', 'add'],
      ignoreInitial: true,
      usePolling: false,
      awaitWriteFinish: {
        stabilityThreshold: 150,
        pollInterval: 50,
      },
    },
    styles,
  );
}

exports.styles = styles;
exports.watch = series(styles, stylesWatch);
exports.default = styles;
