# Layouts (theme: beekiri)

Folder-per-layout (synced from Backend Fields). Only the installed frontend’s
template is written — PHP sites get `{slug}.php`, React sites get `{slug}.tsx`.
To switch frontend, reset the site (`pnpm reset`) and run the installer again.

```
layouts/{slug}/
  {slug}.php          — PHP/HTML partial (PHP frontend)
  {slug}.tsx          — React component (React frontend)
  styles.scss         — source styles
  styles.css          — compiled CSS
  styles.min.css      — minified (optional)
  script.js           — client behaviour
  {slug}.meta.json    — field definitions for the editor
```

PHP templates use `get_bee_field()`, `have_bee_rows()` / `the_bee_row()`,
`get_bee_row_layout()`. Legacy `get_sub_field` aliases still work. React layouts get the same values from
`POST /api/layouts/{slug}/fields`.
Files marked `@beekiri-managed` regenerate on field-group save — remove the marker to keep edits.
