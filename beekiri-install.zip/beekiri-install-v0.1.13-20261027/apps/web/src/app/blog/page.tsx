import type { Metadata } from 'next';

export const revalidate = 30;

const API = process.env.API_URL ?? 'http://127.0.0.1:8788';

type PublicPost = {
  title: string;
  slug: string;
  path: string;
  excerpt: string;
  publishedAt: string | null;
};

async function listPublishedPosts(): Promise<PublicPost[]> {
  try {
    // Public archive: pull from link-targets-style listing via a lightweight public endpoint.
    // Until a dedicated archive API exists, reuse site public menu is not enough —
    // fetch published posts through the posts public index when available.
    const res = await fetch(`${API}/api/posts/public`, { next: { revalidate: 30 } });
    if (!res.ok) return [];
    const data = (await res.json()) as { posts?: PublicPost[] };
    return data.posts ?? [];
  } catch {
    return [];
  }
}

export const metadata: Metadata = {
  title: 'Blog',
  description: 'Latest posts',
};

export default async function BlogIndexPage() {
  const posts = await listPublishedPosts();

  return (
    <main id="main" className="bk-main">
      <h1>Blog</h1>
      <p className="bk-lead">Single posts from your site.</p>
      {posts.length === 0 ? (
        <p className="bk-muted">No published posts yet.</p>
      ) : (
        <ul className="bk-blog-list">
          {posts.map((post) => (
            <li key={post.slug}>
              <a href={post.path || `/blog/${post.slug}`}>
                <strong>{post.title || '(no title)'}</strong>
              </a>
              {post.excerpt ? <p>{post.excerpt}</p> : null}
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
