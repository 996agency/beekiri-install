import { NextResponse } from 'next/server';
import { renderLayoutReact } from '../../../../../lib/render-layout';

export const dynamic = 'force-dynamic';

type Body = {
  fields?: Record<string, unknown>;
  theme?: string;
};

/**
 * React layout render for the Nest API / editor when frontendRuntime is `react`.
 * Body: { fields, theme? } → { slug, html }
 */
export async function POST(
  req: Request,
  ctx: { params: Promise<{ slug: string }> },
) {
  const { slug: raw } = await ctx.params;
  const slug = (raw || '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '');
  if (!slug) {
    return NextResponse.json({ error: 'Invalid layout slug.' }, { status: 400 });
  }

  let body: Body = {};
  try {
    body = (await req.json()) as Body;
  } catch {
    body = {};
  }

  const theme = (body.theme || 'beekiri').trim() || 'beekiri';
  const html = await renderLayoutReact(slug, body.fields ?? {}, theme);
  if (html == null) {
    return NextResponse.json(
      { error: `React layout not found: ${theme}/layouts/${slug}/${slug}.tsx` },
      { status: 404 },
    );
  }
  return NextResponse.json({ slug, html });
}
