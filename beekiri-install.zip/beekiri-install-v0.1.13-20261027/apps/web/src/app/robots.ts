import type { MetadataRoute } from 'next';

const API = process.env.API_URL ?? 'http://127.0.0.1:8788';
const HOST = (process.env.APP_URL ?? 'http://127.0.0.1:8789').replace(/\/$/, '');

export default async function robots(): Promise<MetadataRoute.Robots> {
  let blogPublic = true;
  try {
    const res = await fetch(`${API}/api/site/public`, {
      next: { revalidate: 60 },
    });
    if (res.ok) {
      const data = (await res.json()) as { blogPublic?: boolean; installed?: boolean };
      if (data.installed === false) blogPublic = false;
      else if (data.blogPublic === false) blogPublic = false;
    }
  } catch {
    // Fail open for crawlers if API is briefly down during generation.
    blogPublic = true;
  }

  if (!blogPublic) {
    return {
      rules: [{ userAgent: '*', disallow: '/' }],
    };
  }

  return {
    rules: [{ userAgent: '*', allow: '/' }],
    sitemap: `${HOST}/sitemap.xml`,
  };
}
