import type { MetadataRoute } from 'next';

const SITE = (process.env.APP_URL ?? 'http://127.0.0.1:8789').replace(/\/$/, '');

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    {
      url: SITE,
      lastModified: new Date(),
      changeFrequency: 'weekly',
      priority: 1,
    },
  ];
}
