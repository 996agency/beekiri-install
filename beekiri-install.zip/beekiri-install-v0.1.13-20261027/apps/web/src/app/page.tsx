import type { Metadata } from 'next';
import { PageBody, resolveBeekiriCodePage } from '../components/PageBody';

export const revalidate = 30;

const API = process.env.API_URL ?? 'http://127.0.0.1:8788';

type PublicPage = {
  title: string;
  slug: string;
  path: string;
  content: string;
  beekiricanva?: unknown | null;
  beekiricode?: unknown | null;
  instatic?: unknown | null;
  excerpt: string;
};

type SitePublic = {
  installed?: boolean;
  title?: string;
  tagline?: string;
  frontPageSlug?: string | null;
};

async function getSite(): Promise<SitePublic | null> {
  try {
    const res = await fetch(`${API}/api/site/public`, { next: { revalidate: 30 } });
    if (!res.ok) return null;
    return (await res.json()) as SitePublic;
  } catch {
    return null;
  }
}

async function getFrontPage(): Promise<PublicPage | null> {
  try {
    const res = await fetch(`${API}/api/pages/public/front`, { next: { revalidate: 30 } });
    if (res.status === 404) return null;
    if (!res.ok) return null;
    return (await res.json()) as PublicPage;
  } catch {
    return null;
  }
}

function FallbackHome({ site }: { site: SitePublic | null }) {
  const title = site?.installed ? site.title || 'Beekiri' : 'Beekiri';
  const lead = site?.installed
    ? site.tagline || 'Set a front page in Admin → Settings → Permalinks, then publish that page.'
    : 'Your site is almost ready. Open the Beekiri installer to finish setup.';

  return (
    <main id="main" className="bk-main">
      <h1>{title}</h1>
      <p className="bk-lead">{lead}</p>
    </main>
  );
}

export async function generateMetadata(): Promise<Metadata> {
  const page = await getFrontPage();
  if (!page) {
    const site = await getSite();
    return {
      title: site?.title?.trim() || 'Beekiri',
      description: site?.tagline?.trim() || 'Published with Beekiri.',
    };
  }
  return {
    title: page.title,
    description: (page.excerpt || '').trim() || `${page.title} — published with Beekiri.`,
  };
}

export default async function HomePage() {
  const [site, page] = await Promise.all([getSite(), getFrontPage()]);

  if (!page) {
    return <FallbackHome site={site} />;
  }

  const codeDoc = page.beekiricode ?? page.instatic;
  const codePage = codeDoc ? await resolveBeekiriCodePage(codeDoc) : null;

  return (
    <>
      {codePage?.cssHrefs.map((href) => (
        <link key={href} rel="stylesheet" href={href} precedence="beekiri-layouts" />
      ))}
      {codePage?.css ? (
        <style href={`bk-page-${page.slug}`} precedence="beekiri-page">
          {codePage.css}
        </style>
      ) : null}
      {codePage?.jsHrefs.map((href) => (
        <script key={href} src={href} defer />
      ))}
      {codePage ? (
        <main
          id="main"
          className="bk-main"
          dangerouslySetInnerHTML={{ __html: codePage.html }}
        />
      ) : (
        <main id="main" className="bk-main">
          <h1>{page.title}</h1>
          <PageBody content={page.content} beekiricanva={page.beekiricanva} beekiricode={null} />
        </main>
      )}
    </>
  );
}
