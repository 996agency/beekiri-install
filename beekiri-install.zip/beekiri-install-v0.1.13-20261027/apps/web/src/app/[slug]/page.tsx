import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { PageBody, resolveBeekiriCodePage } from '../../components/PageBody';

export const revalidate = 30;

const API = process.env.API_URL ?? 'http://127.0.0.1:8788';

type PublicPage = {
  title: string;
  slug: string;
  path: string;
  content: string;
  beekiricanva?: unknown | null;
  beekiricode?: unknown | null;
  instatic?: unknown | null;
  excerpt: string;
};

async function getPage(slug: string): Promise<PublicPage | null> {
  try {
    const res = await fetch(`${API}/api/pages/public/${encodeURIComponent(slug)}`, {
      next: { revalidate: 30 },
    });
    if (res.status === 404) return null;
    if (!res.ok) return null;
    return (await res.json()) as PublicPage;
  } catch {
    return null;
  }
}

type Props = {
  params: Promise<{ slug: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const page = await getPage(slug);
  if (!page) return { title: 'Not found' };
  const description = (page.excerpt || '').trim() || `${page.title} — published with Beekiri.`;
  return { title: page.title, description };
}

export default async function ContentPage({ params }: Props) {
  const { slug } = await params;
  const page = await getPage(slug);
  if (!page) notFound();
  const codeDoc = page.beekiricode ?? page.instatic;
  const codePage = codeDoc ? await resolveBeekiriCodePage(codeDoc) : null;

  return (
    <>
      {codePage?.cssHrefs.map((href) => (
        <link key={href} rel="stylesheet" href={href} precedence="beekiri-layouts" />
      ))}
      {codePage?.css ? (
        <style href={`bk-page-${page.slug}`} precedence="beekiri-page">
          {codePage.css}
        </style>
      ) : null}
      {codePage?.jsHrefs.map((href) => (
        <script key={href} src={href} defer />
      ))}
      {codePage ? (
        <main
          id="main"
          className="bk-main"
          dangerouslySetInnerHTML={{ __html: codePage.html }}
        />
      ) : (
        <main id="main" className="bk-main">
          <h1>{page.title}</h1>
          <PageBody content={page.content} beekiricanva={page.beekiricanva} beekiricode={null} />
        </main>
      )}
    </>
  );
}
