import type { Metadata, Viewport } from 'next';
import './globals.css';
import { SiteChrome, type ChromeSite } from '../components/SiteChrome';
import type { SiteMenuItem } from '../lib/site-menu';

const SITE_URL = process.env.APP_URL ?? 'http://127.0.0.1:8789';
const API = process.env.API_URL ?? 'http://127.0.0.1:8788';
const DEFAULT_FAVICON = '/beekiri-logo.png';

const FALLBACK_META = {
  favicon: DEFAULT_FAVICON,
  title: 'Beekiri',
  tagline: '',
  theme: 'beekiri',
  site: null,
} satisfies PublicMeta;

type PublicMeta = {
  favicon: string;
  title: string;
  tagline: string;
  theme: string;
  site: ChromeSite | null;
};

async function getPublicMeta(): Promise<PublicMeta> {
  try {
    const res = await fetch(`${API}/api/site/public`, {
      next: { revalidate: 30 },
    });
    if (!res.ok) {
      return FALLBACK_META;
    }
    const data = (await res.json()) as ChromeSite & {
      installed?: boolean;
      faviconUrl?: string;
      theme?: string;
      menu?: SiteMenuItem[];
    };
    const favicon = (data.faviconUrl ?? '').trim() || DEFAULT_FAVICON;
    const title = (data.title ?? '').trim() || 'Beekiri';
    const tagline = (data.tagline ?? '').trim();
    const theme = (data.theme ?? '').trim() || 'beekiri';
    const site: ChromeSite | null = data.installed
      ? { title, tagline, blogPublic: data.blogPublic, menu: data.menu }
      : null;
    return { favicon, title, tagline, theme, site };
  } catch {
    return FALLBACK_META;
  }
}

export async function generateMetadata(): Promise<Metadata> {
  const { favicon, title, tagline } = await getPublicMeta();
  const description =
    tagline ||
    'Beekiri helps you publish pages, manage media, and grow your website with a fast, secure content management system.';

  return {
    metadataBase: new URL(SITE_URL),
    title: {
      default: title,
      template: `%s · ${title}`,
    },
    description,
    applicationName: title,
    authors: [{ name: '996agency' }],
    generator: 'Beekiri CMS',
    referrer: 'origin-when-cross-origin',
    keywords: ['Beekiri', 'CMS', 'content management', 'website', title],
    robots: {
      index: true,
      follow: true,
    },
    icons: {
      // One source of truth: site favicon (Settings → General), default beekiri-logo.png.
      icon: [{ url: favicon }],
      shortcut: [{ url: favicon }],
      apple: [{ url: favicon }],
    },
    openGraph: {
      type: 'website',
      locale: 'en_US',
      siteName: title,
      title,
      description,
      url: SITE_URL,
    },
    twitter: {
      card: 'summary',
      title,
      description,
    },
    manifest: '/site.webmanifest',
    other: {
      // Helps some crawlers / assistive tech when dynamic content lacks labels
      'format-detection': 'telephone=no',
    },
  };
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#ffffff',
  colorScheme: 'light',
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const { theme, site } = await getPublicMeta();
  return (
    <html lang="en" data-theme={theme}>
      <body>
        <a className="bk-skip" href="#main">
          Skip to main content
        </a>
        <div className="bk-shell">
          <SiteChrome kind="header" site={site} />
          {children}
          <SiteChrome kind="footer" site={site} />
        </div>
        {/* Native script (no next/script client runtime) — soft nav without React router. */}
        <script src="/runtime/site-nav.js" defer />
      </body>
    </html>
  );
}
