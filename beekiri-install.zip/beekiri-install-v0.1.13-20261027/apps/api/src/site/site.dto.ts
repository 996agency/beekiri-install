import { ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsBoolean,
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  MinLength,
  ValidateIf,
  ValidateNested,
} from 'class-validator';

export class MenuItemDto {
  @IsString()
  @MaxLength(64)
  id!: string;

  @IsString()
  @MaxLength(80)
  label!: string;

  @IsString()
  @MaxLength(200)
  path!: string;

  @IsBoolean()
  enabled!: boolean;

  @IsOptional()
  @IsString()
  @MaxLength(32)
  source?: string;

  @IsOptional()
  @IsString()
  @MaxLength(64)
  refId?: string;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => MenuItemDto)
  children?: MenuItemDto[];
}

export class MediaFolderDto {
  @IsString()
  @MaxLength(64)
  id!: string;

  @IsString()
  @MaxLength(80)
  name!: string;

  @IsString()
  @MaxLength(80)
  slug!: string;

  /** null = top-level. Optional for older saved settings. */
  @IsOptional()
  @ValidateIf((_, v) => v !== null && v !== undefined)
  @IsString()
  @MaxLength(64)
  parentId?: string | null;
}

export class MediaSettingsDto {
  @IsOptional()
  @IsBoolean()
  convertToWebp?: boolean;

  @IsOptional()
  @IsBoolean()
  webpLossless?: boolean;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(100)
  webpQuality?: number;

  @IsOptional()
  @IsInt()
  @Min(320)
  @Max(7680)
  maxWidth?: number;

  @IsOptional()
  @IsInt()
  @Min(320)
  @Max(7680)
  maxHeight?: number;

  @IsOptional()
  @IsBoolean()
  stripMetadata?: boolean;

  @IsOptional()
  @IsBoolean()
  keepOriginal?: boolean;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => MediaFolderDto)
  folders?: MediaFolderDto[];
}

export class UpdateSiteSettingsDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(200)
  title?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(300)
  tagline?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(32)
  language?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  blogPublic?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(64)
  timezone?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(32)
  dateFormat?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(32)
  timeFormat?: string;

  @ApiPropertyOptional({ description: 'Google Business / local listing name' })
  @IsOptional()
  @IsString()
  @MaxLength(200)
  businessName?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(120)
  businessCategory?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(64)
  businessPhone?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(500)
  businessAddress?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(200)
  businessHours?: string;

  @ApiPropertyOptional({ description: 'Cover photo URL for local listing preview' })
  @IsOptional()
  @IsString()
  @MaxLength(2000)
  businessImageUrl?: string;

  @ApiPropertyOptional({
    description: 'Site favicon URL or path. Leave empty to use /beekiri-logo.png',
  })
  @IsOptional()
  @IsString()
  @MaxLength(2000)
  faviconUrl?: string;

  @ApiPropertyOptional({ enum: ['plain', 'postname', 'dayname', 'custom'] })
  @IsOptional()
  @IsIn(['plain', 'postname', 'dayname', 'custom'])
  permalinkStructure?: 'plain' | 'postname' | 'dayname' | 'custom';

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(120)
  permalinkCustom?: string;

  @ApiPropertyOptional({ type: [MenuItemDto] })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => MenuItemDto)
  menuItems?: MenuItemDto[];

  @ApiPropertyOptional({ description: 'Published page id for the site front page (`/`)' })
  @IsOptional()
  @IsString()
  @MaxLength(64)
  frontPageId?: string;

  @ApiPropertyOptional({ description: 'Fallback page slug for the site front page' })
  @IsOptional()
  @IsString()
  @MaxLength(180)
  frontPageSlug?: string;

  @ApiPropertyOptional({ type: MediaSettingsDto })
  @IsOptional()
  @ValidateNested()
  @Type(() => MediaSettingsDto)
  media?: MediaSettingsDto;

  @ApiPropertyOptional({
    enum: ['beekiricode'],
    description: 'Page editor style — BeekiriCode only',
  })
  @IsOptional()
  @IsIn(['beekiricode'])
  pageEditorStyle?: 'beekiricode';

  @ApiPropertyOptional({
    enum: ['react', 'php'],
    description:
      'Read-only after install. Sending a different value than the installed runtime returns 400 (frontend_runtime_locked).',
  })
  @IsOptional()
  @IsIn(['react', 'php'])
  frontendRuntime?: 'react' | 'php';
}
