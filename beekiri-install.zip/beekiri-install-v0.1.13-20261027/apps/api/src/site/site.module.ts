import { Module } from '@nestjs/common';
import { SiteController } from './site.controller';
import { AuthModule } from '../auth/auth.module';
import { LayoutsModule } from '../layouts/layouts.module';
import { PagesModule } from '../pages/pages.module';
import { DashboardService } from './dashboard.service';

@Module({
  imports: [AuthModule, PagesModule, LayoutsModule],
  controllers: [SiteController],
  providers: [DashboardService],
})
export class SiteModule {}
