import {
  ConflictException,
  Injectable,
  ServiceUnavailableException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { ROLE_CAPABILITIES } from '../auth/role-capabilities';
import type { RoleSlug } from '../cms-types';
import { PrismaService } from '../prisma/prisma.service';
import { hashPassword, passwordStrength, randomToken } from '../common/crypto.util';
import { FRONTEND_RUNTIMES, type SiteOptions } from '../site/site-options';
import { DEFAULT_THEME_SLUG } from '../themes/theme-registry';
import { InstallDto } from './install.dto';

@Injectable()
export class InstallService {
  constructor(private readonly prisma: PrismaService) {}

  async ensureInstallationRow() {
    await this.prisma.installationState.upsert({
      where: { id: 1 },
      create: { id: 1, installed: false },
      update: {},
    });
  }

  async getStatus() {
    await this.ensureInstallationRow();
    let databaseOk = false;
    let databaseMessage =
      'Cannot reach PostgreSQL. Set DATABASE_URL on the server environment, then retry.';
    try {
      await this.prisma.$queryRaw`SELECT 1`;
      databaseOk = true;
      databaseMessage = 'Database connected.';
    } catch (e) {
      databaseMessage =
        e instanceof Error
          ? `Database error: ${e.message}. Configure DATABASE_URL in the server environment (this installer never collects database credentials in the browser).`
          : databaseMessage;
    }

    const state = await this.prisma.installationState.findUnique({ where: { id: 1 } });
    const installed = Boolean(state?.installed);
    if (databaseOk) {
      databaseMessage = installed
        ? 'Database connected. This site is already installed.'
        : 'Database connected. You can create this site.';
    }

    return {
      installed,
      databaseOk,
      databaseMessage,
      canInstall: databaseOk && !installed,
      frontendRuntimes: FRONTEND_RUNTIMES,
    };
  }

  async install(dto: InstallDto, meta: { ip?: string; userAgent?: string }) {
    await this.ensureInstallationRow();

    if (passwordStrength(dto.password) === 'weak') {
      throw new ConflictException({
        message: 'Please choose a stronger password.',
        code: 'weak_password',
      });
    }

    const lockOwner = randomToken(16);

    try {
      const result = await this.prisma.$transaction(async (tx) => {
        // Serialize installers: claim lock only if not installed and unlocked (or stale lock)
        const staleBefore = new Date(Date.now() - 5 * 60 * 1000);
        const claimed = await tx.installationState.updateMany({
          where: {
            id: 1,
            installed: false,
            OR: [{ lockedAt: null }, { lockedAt: { lt: staleBefore } }],
          },
          data: { lockedAt: new Date(), lockOwner },
        });

        if (claimed.count === 0) {
          const current = await tx.installationState.findUnique({ where: { id: 1 } });
          if (current?.installed) {
            throw new ConflictException({
              message: 'Already Installed',
              code: 'already_installed',
            });
          }
          throw new ConflictException({
            message: 'Another installation is in progress. Please wait and retry.',
            code: 'install_in_progress',
          });
        }

        // Seed roles & capabilities
        for (const [slug, caps] of Object.entries(ROLE_CAPABILITIES) as [
          RoleSlug,
          (typeof ROLE_CAPABILITIES)[RoleSlug],
        ][]) {
          const role = await tx.role.upsert({
            where: { slug },
            create: { slug, name: slug.charAt(0).toUpperCase() + slug.slice(1) },
            update: {},
          });
          for (const cap of caps) {
            const capability = await tx.capability.upsert({
              where: { slug: cap },
              create: { slug: cap, name: cap },
              update: {},
            });
            await tx.role.update({
              where: { id: role.id },
              data: { capabilities: { connect: { id: capability.id } } },
            });
          }
        }

        const adminRole = await tx.role.findUniqueOrThrow({ where: { slug: 'administrator' } });
        const passwordHash = await hashPassword(dto.password);

        const options: SiteOptions = {
          activeTheme: DEFAULT_THEME_SLUG,
          frontendRuntime: dto.frontendRuntime,
        };

        const site = await tx.site.create({
          data: {
            title: dto.siteTitle,
            language: dto.language,
            settings: {
              create: {
                blogPublic: dto.blogPublic,
                options: options as Prisma.InputJsonValue,
              },
            },
            users: {
              create: {
                username: dto.username,
                email: dto.email.toLowerCase(),
                displayName: dto.username,
                passwordHash,
                isOwner: true,
                roleId: adminRole.id,
              },
            },
          },
          include: { users: true, settings: true },
        });

        await tx.installationState.update({
          where: { id: 1 },
          data: {
            installed: true,
            installedAt: new Date(),
            lockedAt: null,
            lockOwner: null,
          },
        });

        await tx.auditLog.create({
          data: {
            siteId: site.id,
            userId: site.users[0]?.id,
            action: 'site.installed',
            meta: {
              language: dto.language,
              blogPublic: dto.blogPublic,
              frontendRuntime: dto.frontendRuntime,
            },
            ip: meta.ip,
          },
        });

        return site;
      });

      return {
        ok: true,
        siteTitle: result.title,
        username: dto.username,
      };
    } catch (e) {
      // Release lock if we held it and failed mid-way (recoverable)
      await this.prisma.installationState
        .updateMany({
          where: { id: 1, lockOwner, installed: false },
          data: { lockedAt: null, lockOwner: null },
        })
        .catch(() => undefined);

      if (e instanceof ConflictException) throw e;
      throw new ServiceUnavailableException({
        message:
          e instanceof Error
            ? `Installation failed: ${e.message}. You may retry after fixing the issue.`
            : 'Installation failed. You may retry.',
        code: 'install_failed',
      });
    }
  }
}
