import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from './prisma/prisma.module';
import { HealthModule } from './health/health.module';
import { InstallModule } from './install/install.module';
import { AuthModule } from './auth/auth.module';
import { SiteModule } from './site/site.module';
import { MailModule } from './mail/mail.module';
import { SystemModule } from './system/system.module';
import { UsersModule } from './users/users.module';
import { MediaModule } from './media/media.module';
import { FieldsModule } from './fields/fields.module';
import { LayoutsModule } from './layouts/layouts.module';
import { ThemesModule } from './themes/themes.module';
import { PagesModule } from './pages/pages.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    MailModule,
    HealthModule,
    InstallModule,
    AuthModule,
    SiteModule,
    SystemModule,
    UsersModule,
    MediaModule,
    FieldsModule,
    LayoutsModule,
    ThemesModule,
    PagesModule,
  ],
})
export class AppModule {}
