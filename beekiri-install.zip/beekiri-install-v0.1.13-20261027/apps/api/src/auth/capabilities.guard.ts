import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import type { CapabilitySlug } from '../cms-types';
import { CAPABILITIES_KEY } from './capabilities.decorator';
import type { AuthedRequest } from './auth.guard';

@Injectable()
export class CapabilitiesGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<CapabilitySlug[] | undefined>(
      CAPABILITIES_KEY,
      [context.getHandler(), context.getClass()],
    );
    if (!required?.length) return true;
    const req = context.switchToHttp().getRequest<AuthedRequest>();
    const user = req.auth?.user;
    if (!user) throw new ForbiddenException('Sorry, you are not allowed to do that.');
    const ok = required.every((c) => user.capabilities.includes(c));
    if (!ok) throw new ForbiddenException('Sorry, you are not allowed to do that.');
    return true;
  }
}
