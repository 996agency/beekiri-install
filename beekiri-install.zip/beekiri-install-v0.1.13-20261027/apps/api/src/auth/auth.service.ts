import {
  ForbiddenException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { ROLE_CAPABILITIES } from './role-capabilities';
import type { CapabilitySlug, RoleSlug } from '../cms-types';
import { PrismaService } from '../prisma/prisma.service';
import { MailService } from '../mail/mail.service';
import {
  hashPassword,
  passwordStrength,
  randomToken,
  sha256,
  verifyPassword,
} from '../common/crypto.util';
import { rateLimit } from '../common/rate-limit';
import type { AuthSessionContext, AuthUser } from './auth.types';
import { LoginDto, LostPasswordDto, ResetPasswordDto } from './auth.dto';

const COOKIE_NAME = 'beekiri_session';
const CSRF_HEADER = 'x-csrf-token';

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly mail: MailService,
  ) {}

  cookieName() {
    return COOKIE_NAME;
  }

  csrfHeader() {
    return CSRF_HEADER;
  }

  private idleSeconds(remember?: boolean) {
    if (remember) return Number(process.env.SESSION_ABSOLUTE_SECONDS ?? 604800);
    return Number(process.env.SESSION_IDLE_SECONDS ?? 86400);
  }

  private absoluteSeconds() {
    return Number(process.env.SESSION_ABSOLUTE_SECONDS ?? 604800);
  }

  toAuthUser(user: {
    id: string;
    username: string;
    email: string;
    displayName: string;
    isOwner: boolean;
    siteId: string;
    role: { slug: string };
  }): AuthUser {
    const role = user.role.slug as RoleSlug;
    return {
      id: user.id,
      username: user.username,
      email: user.email,
      displayName: user.displayName,
      role,
      capabilities: ROLE_CAPABILITIES[role] ?? (['read'] as CapabilitySlug[]),
      isOwner: user.isOwner,
      siteId: user.siteId,
    };
  }

  async login(
    dto: LoginDto,
    meta: { ip?: string; userAgent?: string },
  ): Promise<{ cookieValue: string; maxAge: number; csrfToken: string; user: AuthUser }> {
    const rl = rateLimit(`login:${meta.ip ?? 'unknown'}`, 10, 15 * 60 * 1000);
    if (!rl.ok) {
      throw new UnauthorizedException('Too many login attempts. Please try again later.');
    }

    const login = dto.login.trim();
    const user = await this.prisma.user.findFirst({
      where: {
        OR: [
          { username: { equals: login, mode: 'insensitive' } },
          { email: { equals: login.toLowerCase(), mode: 'insensitive' } },
        ],
      },
      include: { role: true },
    });

    const ok = user ? await verifyPassword(user.passwordHash, dto.password) : false;
    if (!user || !ok) {
      await this.prisma.auditLog.create({
        data: {
          action: 'auth.login_failed',
          meta: { login },
          ip: meta.ip,
        },
      });
      throw new UnauthorizedException('Invalid username or password.');
    }

    const rawToken = randomToken(32);
    const csrfSecret = randomToken(24);
    const now = Date.now();
    const idle = this.idleSeconds(dto.remember);
    const absolute = this.absoluteSeconds();

    await this.prisma.session.create({
      data: {
        userId: user.id,
        tokenHash: sha256(rawToken),
        csrfSecret,
        lastSeenAt: new Date(),
        idleExpiresAt: new Date(now + idle * 1000),
        absoluteExpiresAt: new Date(now + absolute * 1000),
        userAgent: meta.userAgent,
        ip: meta.ip,
      },
    });

    await this.prisma.auditLog.create({
      data: {
        siteId: user.siteId,
        userId: user.id,
        action: 'auth.login',
        meta: { remember: Boolean(dto.remember) },
        ip: meta.ip,
      },
    });

    const authUser = this.toAuthUser(user);
    return {
      cookieValue: rawToken,
      maxAge: idle,
      csrfToken: csrfSecret,
      user: authUser,
    };
  }

  async logout(rawToken: string | undefined, meta: { ip?: string }) {
    if (!rawToken) return;
    const session = await this.prisma.session.findUnique({
      where: { tokenHash: sha256(rawToken) },
    });
    if (session) {
      await this.prisma.session.delete({ where: { id: session.id } });
      await this.prisma.auditLog.create({
        data: {
          userId: session.userId,
          action: 'auth.logout',
          ip: meta.ip,
        },
      });
    }
  }

  async resolveSession(rawToken: string | undefined): Promise<AuthSessionContext | null> {
    if (!rawToken) return null;
    const session = await this.prisma.session.findUnique({
      where: { tokenHash: sha256(rawToken) },
      include: { user: { include: { role: true } } },
    });
    if (!session) return null;

    const now = new Date();
    if (session.absoluteExpiresAt < now || session.idleExpiresAt < now) {
      await this.prisma.session.delete({ where: { id: session.id } }).catch(() => undefined);
      return null;
    }

    const idle = this.idleSeconds(false);
    await this.prisma.session.update({
      where: { id: session.id },
      data: {
        lastSeenAt: now,
        idleExpiresAt: new Date(Date.now() + idle * 1000),
      },
    });

    return {
      sessionId: session.id,
      csrfToken: session.csrfSecret,
      user: this.toAuthUser(session.user),
    };
  }

  assertCsrf(session: AuthSessionContext, headerValue: string | undefined) {
    if (!headerValue || headerValue !== session.csrfToken) {
      throw new ForbiddenException('Invalid CSRF token.');
    }
  }

  assertOrigin(origin: string | undefined, referer: string | undefined) {
    const allowed = [process.env.ADMIN_URL, process.env.APP_URL].filter(Boolean) as string[];
    if (!origin && !referer) return;
    const candidate = origin ?? referer;
    if (!candidate) return;
    const ok = allowed.some((a) => candidate.startsWith(a));
    if (!ok) {
      throw new ForbiddenException('Invalid request origin.');
    }
  }

  async requestPasswordReset(dto: LostPasswordDto, meta: { ip?: string }) {
    const rl = rateLimit(`reset:${meta.ip ?? 'unknown'}`, 5, 15 * 60 * 1000);
    if (!rl.ok) {
      return { message: 'If that account exists, a reset link has been sent.' };
    }

    const login = dto.userLogin.trim();
    const user = await this.prisma.user.findFirst({
      where: {
        OR: [
          { username: { equals: login, mode: 'insensitive' } },
          { email: { equals: login.toLowerCase(), mode: 'insensitive' } },
        ],
      },
    });

    // Always same response (anti-enumeration)
    const generic = { message: 'If that account exists, a reset link has been sent.' };
    if (!user) return generic;

    const raw = randomToken(32);
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000);
    await this.prisma.passwordResetToken.create({
      data: {
        userId: user.id,
        tokenHash: sha256(raw),
        expiresAt,
      },
    });

    const adminUrl = process.env.ADMIN_URL ?? 'http://127.0.0.1:8787';
    const link = `${adminUrl}/reset-password?key=${encodeURIComponent(raw)}`;
    const send = await this.mail.sendMail({
      to: user.email,
      subject: 'Password Reset',
      text: `Someone requested a password reset for your account.\n\n${link}\n\nThis link expires in 1 hour.`,
    });

    await this.prisma.auditLog.create({
      data: {
        userId: user.id,
        siteId: user.siteId,
        action: 'auth.password_reset_requested',
        ip: meta.ip,
      },
    });

    const isDev = (process.env.NODE_ENV ?? 'development') !== 'production';
    return {
      ...generic,
      ...(isDev && send.mode === 'dev-sink' ? { devResetLink: link } : {}),
    };
  }

  async resetPassword(dto: ResetPasswordDto) {
    if (passwordStrength(dto.password) === 'weak') {
      throw new ForbiddenException('Please choose a stronger password.');
    }
    const token = await this.prisma.passwordResetToken.findUnique({
      where: { tokenHash: sha256(dto.token) },
    });
    if (!token || token.usedAt || token.expiresAt < new Date()) {
      throw new ForbiddenException('Invalid or expired reset link.');
    }

    const passwordHash = await hashPassword(dto.password);
    await this.prisma.$transaction([
      this.prisma.user.update({
        where: { id: token.userId },
        data: { passwordHash },
      }),
      this.prisma.passwordResetToken.update({
        where: { id: token.id },
        data: { usedAt: new Date() },
      }),
      this.prisma.session.deleteMany({ where: { userId: token.userId } }),
    ]);

    return { message: 'Password updated. You can log in.' };
  }

  requireCapability(user: AuthUser, capability: CapabilitySlug) {
    if (!user.capabilities.includes(capability)) {
      throw new ForbiddenException('Sorry, you are not allowed to do that.');
    }
  }
}
