import type { CapabilitySlug, RoleSlug } from '../cms-types';

/** WordPress-equivalent capability sets (independent implementation). */
export const ROLE_CAPABILITIES: Record<RoleSlug, CapabilitySlug[]> = {
  administrator: [
    'manage_options',
    'edit_users',
    'list_users',
    'create_users',
    'delete_users',
    'edit_posts',
    'edit_others_posts',
    'publish_posts',
    'delete_posts',
    'edit_pages',
    'edit_others_pages',
    'publish_pages',
    'delete_pages',
    'upload_files',
    'moderate_comments',
    'manage_categories',
    'edit_theme_options',
    'read',
  ],
  editor: [
    'edit_posts',
    'edit_others_posts',
    'publish_posts',
    'delete_posts',
    'edit_pages',
    'edit_others_pages',
    'publish_pages',
    'delete_pages',
    'upload_files',
    'moderate_comments',
    'manage_categories',
    'read',
  ],
  author: ['edit_posts', 'publish_posts', 'delete_posts', 'upload_files', 'read'],
  contributor: ['edit_posts', 'read'],
  subscriber: ['read'],
};

export function roleHasCapability(role: RoleSlug, capability: CapabilitySlug): boolean {
  return ROLE_CAPABILITIES[role]?.includes(capability) ?? false;
}

export function assertCapability(
  role: RoleSlug,
  capability: CapabilitySlug,
): asserts role is RoleSlug {
  if (!roleHasCapability(role, capability)) {
    throw new Error(`Missing capability: ${capability}`);
  }
}
