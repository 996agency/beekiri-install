import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { AuthGuard, type AuthedRequest } from '../auth/auth.guard';
import { CapabilitiesGuard } from '../auth/capabilities.guard';
import { RequireCapabilities } from '../auth/capabilities.decorator';
import {
  CreatePageDto,
  PagePresenceDto,
  PreviewPageDto,
  UpdatePageDto,
} from './pages.dto';
import { PagesService } from './pages.service';
import {
  heartbeatPresence,
  leavePresence,
  listPresence,
} from './pages.presence';

@ApiTags('pages')
@Controller('pages')
export class PagesController {
  constructor(private readonly pages: PagesService) {}

  /** Site home page (`/`) — resolved from Settings → Permalinks front page. */
  @Get('public/front')
  publicFront(
    @Query('preview') preview?: string,
    @Query('token') token?: string,
  ) {
    const wantPreview =
      preview === '1' || preview === 'true' || Boolean(token?.trim());
    return this.pages.getPublishedFrontPage(
      wantPreview ? token : undefined,
    );
  }

  /** Public published page by slug (front-end). Optional tokenized preview. */
  @Get('public/:slug')
  publicBySlug(
    @Param('slug') slug: string,
    @Query('preview') preview?: string,
    @Query('token') token?: string,
  ) {
    const wantPreview =
      preview === '1' || preview === 'true' || Boolean(token?.trim());
    return this.pages.getPublishedBySlug(
      slug,
      wantPreview ? token : undefined,
    );
  }

  @Get()
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_pages')
  list(@Req() req: AuthedRequest) {
    return this.pages.list(req.auth!.user);
  }

  /** Nested routes before `@Get(':id')` so they are not shadowed. */
  @Get(':id/revisions')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_pages')
  listRevisions(@Req() req: AuthedRequest, @Param('id') id: string) {
    return this.pages.listRevisions(req.auth!.user, id);
  }

  @Post(':id/revisions/:revisionId/restore')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_pages')
  restoreRevision(
    @Req() req: AuthedRequest,
    @Param('id') id: string,
    @Param('revisionId') revisionId: string,
  ) {
    return this.pages.restoreRevision(req.auth!.user, id, revisionId);
  }

  /** Snapshot current edits for a front-end preview link (does not publish). */
  @Post(':id/preview')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_pages')
  preview(
    @Req() req: AuthedRequest,
    @Param('id') id: string,
    @Body() body: PreviewPageDto,
  ) {
    return this.pages.createPreview(req.auth!.user, id, body);
  }

  /** Who’s currently editing this page (BeekiriCode toolbar avatar stack). */
  @Get(':id/presence')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_pages')
  getPresence(@Param('id') id: string) {
    return { peers: listPresence(id) };
  }

  @Post(':id/presence')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_pages')
  async postPresence(
    @Req() req: AuthedRequest,
    @Param('id') id: string,
    @Body() body: PagePresenceDto,
  ) {
    // Ensure the page exists for this site.
    await this.pages.get(req.auth!.user, id);
    const user = req.auth!.user;
    const peers = heartbeatPresence({
      pageId: id,
      userId: user.id,
      name: user.displayName?.trim() || user.username,
      clientId: body.clientId,
    });
    return { peers };
  }

  @Delete(':id/presence')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_pages')
  deletePresence(
    @Param('id') id: string,
    @Query('clientId') clientId?: string,
  ) {
    if (clientId?.trim()) leavePresence(id, clientId.trim());
    return { ok: true };
  }

  @Get(':id')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_pages')
  get(@Req() req: AuthedRequest, @Param('id') id: string) {
    return this.pages.get(req.auth!.user, id);
  }

  @Post()
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_pages')
  create(@Req() req: AuthedRequest, @Body() body: CreatePageDto) {
    return this.pages.create(req.auth!.user, body);
  }

  @Patch(':id')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_pages')
  update(
    @Req() req: AuthedRequest,
    @Param('id') id: string,
    @Body() body: UpdatePageDto,
  ) {
    return this.pages.update(req.auth!.user, id, body);
  }

  @Delete(':id')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('delete_pages')
  remove(@Req() req: AuthedRequest, @Param('id') id: string) {
    return this.pages.remove(req.auth!.user, id);
  }
}
