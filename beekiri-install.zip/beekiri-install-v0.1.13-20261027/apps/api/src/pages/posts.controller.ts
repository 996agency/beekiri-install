import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { AuthGuard, type AuthedRequest } from '../auth/auth.guard';
import { CapabilitiesGuard } from '../auth/capabilities.guard';
import { RequireCapabilities } from '../auth/capabilities.decorator';
import {
  CreatePageDto,
  PagePresenceDto,
  PreviewPageDto,
  UpdatePageDto,
} from './pages.dto';
import { PagesService } from './pages.service';
import {
  heartbeatPresence,
  leavePresence,
  listPresence,
} from './pages.presence';

const KIND = 'post' as const;

@ApiTags('posts')
@Controller('posts')
export class PostsController {
  constructor(private readonly pages: PagesService) {}

  /** Public blog archive — published posts only. */
  @Get('public')
  publicList() {
    return this.pages.listPublishedPublic(KIND);
  }

  /** Public published post by slug (front-end). Optional tokenized preview. */
  @Get('public/:slug')
  publicBySlug(
    @Param('slug') slug: string,
    @Query('preview') preview?: string,
    @Query('token') token?: string,
  ) {
    const wantPreview =
      preview === '1' || preview === 'true' || Boolean(token?.trim());
    return this.pages.getPublishedBySlug(
      slug,
      wantPreview ? token : undefined,
      KIND,
    );
  }

  @Get()
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_posts')
  list(@Req() req: AuthedRequest) {
    return this.pages.list(req.auth!.user, KIND);
  }

  @Get(':id/revisions')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_posts')
  listRevisions(@Req() req: AuthedRequest, @Param('id') id: string) {
    return this.pages.listRevisions(req.auth!.user, id, KIND);
  }

  @Post(':id/revisions/:revisionId/restore')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_posts')
  restoreRevision(
    @Req() req: AuthedRequest,
    @Param('id') id: string,
    @Param('revisionId') revisionId: string,
  ) {
    return this.pages.restoreRevision(req.auth!.user, id, revisionId, KIND);
  }

  @Post(':id/preview')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_posts')
  preview(
    @Req() req: AuthedRequest,
    @Param('id') id: string,
    @Body() body: PreviewPageDto,
  ) {
    return this.pages.createPreview(req.auth!.user, id, body, KIND);
  }

  @Get(':id/presence')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_posts')
  getPresence(@Param('id') id: string) {
    return { peers: listPresence(id) };
  }

  @Post(':id/presence')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_posts')
  async postPresence(
    @Req() req: AuthedRequest,
    @Param('id') id: string,
    @Body() body: PagePresenceDto,
  ) {
    await this.pages.get(req.auth!.user, id, KIND);
    const user = req.auth!.user;
    const peers = heartbeatPresence({
      pageId: id,
      userId: user.id,
      name: user.displayName?.trim() || user.username,
      clientId: body.clientId,
    });
    return { peers };
  }

  @Delete(':id/presence')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_posts')
  deletePresence(
    @Param('id') id: string,
    @Query('clientId') clientId?: string,
  ) {
    if (clientId?.trim()) leavePresence(id, clientId.trim());
    return { ok: true };
  }

  @Get(':id')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_posts')
  get(@Req() req: AuthedRequest, @Param('id') id: string) {
    return this.pages.get(req.auth!.user, id, KIND);
  }

  @Post()
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_posts')
  create(@Req() req: AuthedRequest, @Body() body: CreatePageDto) {
    return this.pages.create(req.auth!.user, body, KIND);
  }

  @Patch(':id')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_posts')
  update(
    @Req() req: AuthedRequest,
    @Param('id') id: string,
    @Body() body: UpdatePageDto,
  ) {
    return this.pages.update(req.auth!.user, id, body, KIND);
  }

  @Delete(':id')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('delete_posts')
  remove(@Req() req: AuthedRequest, @Param('id') id: string) {
    return this.pages.remove(req.auth!.user, id, KIND);
  }
}
