/** Shared page/post document kinds on the Prisma `Post` model. */

export type ContentKind = 'page' | 'post';

export type ContentKindConfig = {
  kind: ContentKind;
  type: 'page' | 'post';
  publishCap: 'publish_pages' | 'publish_posts';
  listKey: 'pages' | 'posts';
  itemKey: 'page' | 'post';
  label: string;
  labelPlural: string;
  notFound: string;
  conflictSlug: string;
  cannotPublish: string;
  cannotRestorePublish: string;
  defaultSlugBase: string;
  pathOf: (slug: string) => string;
};

export const CONTENT_KINDS: Record<ContentKind, ContentKindConfig> = {
  page: {
    kind: 'page',
    type: 'page',
    publishCap: 'publish_pages',
    listKey: 'pages',
    itemKey: 'page',
    label: 'Page',
    labelPlural: 'Pages',
    notFound: 'Page not found.',
    conflictSlug: 'A page with that slug already exists.',
    cannotPublish: 'You cannot publish pages.',
    cannotRestorePublish: 'You cannot restore a published revision.',
    defaultSlugBase: 'page',
    pathOf: (slug) => `/${slug}`,
  },
  post: {
    kind: 'post',
    type: 'post',
    publishCap: 'publish_posts',
    listKey: 'posts',
    itemKey: 'post',
    label: 'Post',
    labelPlural: 'Posts',
    notFound: 'Post not found.',
    conflictSlug: 'A post with that slug already exists.',
    cannotPublish: 'You cannot publish posts.',
    cannotRestorePublish: 'You cannot restore a published revision.',
    defaultSlugBase: 'post',
    pathOf: (slug) => `/blog/${slug}`,
  },
};

export function contentKindConfig(kind: ContentKind = 'page'): ContentKindConfig {
  return CONTENT_KINDS[kind] ?? CONTENT_KINDS.page;
}
