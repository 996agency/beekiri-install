import {
  IsBoolean,
  IsIn,
  IsObject,
  IsOptional,
  IsString,
  MaxLength,
} from 'class-validator';

export class CreatePageDto {
  @IsOptional()
  @IsString()
  @MaxLength(200)
  title?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  slug?: string;

  @IsOptional()
  @IsIn(['auto-draft', 'draft', 'publish'])
  status?: 'auto-draft' | 'draft' | 'publish';

  @IsOptional()
  @IsString()
  @MaxLength(200_000)
  content?: string;

  /** Visual editor document. */
  @IsOptional()
  @IsObject()
  beekiricanva?: Record<string, unknown>;

  /** BeekiriCode page tree document. */
  @IsOptional()
  @IsObject()
  beekiricode?: Record<string, unknown>;

  /** @deprecated Alias for beekiricode */
  @IsOptional()
  @IsObject()
  instatic?: Record<string, unknown>;

  @IsOptional()
  @IsString()
  @MaxLength(2000)
  excerpt?: string;

  /** WordPress-style: create empty auto-draft immediately. */
  @IsOptional()
  @IsBoolean()
  autoDraft?: boolean;
}

export class UpdatePageDto {
  @IsOptional()
  @IsString()
  @MaxLength(200)
  title?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  slug?: string;

  @IsOptional()
  @IsIn(['auto-draft', 'draft', 'publish'])
  status?: 'auto-draft' | 'draft' | 'publish';

  @IsOptional()
  @IsString()
  @MaxLength(200_000)
  content?: string;

  /** Visual editor document. */
  @IsOptional()
  @IsObject()
  beekiricanva?: Record<string, unknown>;

  /** BeekiriCode page tree document. */
  @IsOptional()
  @IsObject()
  beekiricode?: Record<string, unknown>;

  /** @deprecated Alias for beekiricode */
  @IsOptional()
  @IsObject()
  instatic?: Record<string, unknown>;

  @IsOptional()
  @IsString()
  @MaxLength(2000)
  excerpt?: string;
}

/** Heartbeat while editing a page in BeekiriCode (live presence stack). */
export class PagePresenceDto {
  @IsString()
  @MaxLength(80)
  clientId!: string;
}

/** Save a preview snapshot without publishing / updating the live page. */
export class PreviewPageDto {
  @IsOptional()
  @IsString()
  @MaxLength(200)
  title?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  slug?: string;

  @IsOptional()
  @IsObject()
  beekiricanva?: Record<string, unknown>;

  @IsOptional()
  @IsObject()
  beekiricode?: Record<string, unknown>;

  /** @deprecated Alias for beekiricode */
  @IsOptional()
  @IsObject()
  instatic?: Record<string, unknown>;

  @IsOptional()
  @IsString()
  @MaxLength(2000)
  excerpt?: string;
}
