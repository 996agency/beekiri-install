import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { PagesController } from './pages.controller';
import { PostsController } from './posts.controller';
import { PagesService } from './pages.service';

@Module({
  imports: [AuthModule],
  controllers: [PagesController, PostsController],
  providers: [PagesService],
  exports: [PagesService],
})
export class PagesModule {}
