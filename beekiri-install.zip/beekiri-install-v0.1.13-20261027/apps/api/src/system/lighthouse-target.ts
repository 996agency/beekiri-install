import { spawn, type ChildProcess } from 'child_process';
import { existsSync } from 'fs';
import { join } from 'path';
import { findRepoRoot } from '../media/media.paths';

async function sleep(ms: number) {
  await new Promise((r) => setTimeout(r, ms));
}

async function waitForUrl(url: string, timeoutMs: number) {
  const start = Date.now();
  let lastErr = '';
  while (Date.now() - start < timeoutMs) {
    try {
      const res = await fetch(url, { redirect: 'manual' });
      if (res.status > 0) return;
    } catch (e) {
      lastErr = e instanceof Error ? e.message : String(e);
    }
    await sleep(400);
  }
  throw new Error(`Timed out waiting for ${url}${lastErr ? ` (${lastErr})` : ''}`);
}

function run(
  command: string,
  args: string[],
  cwd: string,
  env: NodeJS.ProcessEnv,
): Promise<void> {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd,
      env,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let stderr = '';
    child.stderr?.on('data', (buf: Buffer) => {
      stderr += buf.toString();
    });
    child.on('error', reject);
    child.on('exit', (code) => {
      if (code === 0) resolve();
      else reject(new Error(`${command} ${args.join(' ')} failed (${code}): ${stderr.slice(-800)}`));
    });
  });
}

export type LighthouseTarget = {
  url: string;
  /** Tear down ephemeral production server (if any). */
  cleanup: () => Promise<void>;
  mode: 'production-ephemeral' | 'configured' | 'app-url';
};

/**
 * Prefer a production Next.js target for accurate Performance scores.
 * `next dev` can never score 100 (HMR + unminified bundles).
 */
export async function resolveLighthouseTarget(): Promise<LighthouseTarget> {
  const configured = (process.env.LIGHTHOUSE_URL ?? '').trim().replace(/\/$/, '');
  if (configured) {
    return {
      url: configured,
      mode: 'configured',
      cleanup: async () => undefined,
    };
  }

  // Opt into auditing live APP_URL (usually next dev) — scores will be poor.
  if (process.env.LIGHTHOUSE_USE_APP_URL === '1') {
    const url = (process.env.APP_URL ?? 'http://127.0.0.1:8789').replace(/\/$/, '');
    return { url, mode: 'app-url', cleanup: async () => undefined };
  }

  const root = findRepoRoot();
  const webDir = join(root, 'apps/web');
  const port = Number(process.env.LIGHTHOUSE_PORT ?? 8790);
  const url = `http://127.0.0.1:${port}`;
  const env: NodeJS.ProcessEnv = {
    ...process.env,
    NODE_ENV: 'production',
    NEXT_DIST_DIR: '.next',
    PORT: String(port),
    APP_URL: url,
  };

  if (!existsSync(join(webDir, '.next', 'BUILD_ID'))) {
    await run('pnpm', ['exec', 'next', 'build'], webDir, env);
  }

  let child: ChildProcess | null = spawn(
    'pnpm',
    ['exec', 'next', 'start', '-H', '127.0.0.1', '-p', String(port)],
    { cwd: webDir, env, stdio: ['ignore', 'pipe', 'pipe'] },
  );

  const cleanup = async () => {
    if (!child) return;
    const proc = child;
    child = null;
    try {
      proc.kill('SIGTERM');
    } catch {
      /* ignore */
    }
    await sleep(300);
    try {
      if (!proc.killed) proc.kill('SIGKILL');
    } catch {
      /* ignore */
    }
  };

  try {
    await waitForUrl(url, 90_000);
  } catch (e) {
    await cleanup();
    throw e;
  }

  return { url, mode: 'production-ephemeral', cleanup };
}
