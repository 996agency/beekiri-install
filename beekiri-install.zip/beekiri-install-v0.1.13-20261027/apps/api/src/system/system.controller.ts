import { Controller, Get, Post, Query, UseGuards } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { AuthGuard } from '../auth/auth.guard';
import { CapabilitiesGuard } from '../auth/capabilities.guard';
import { RequireCapabilities } from '../auth/capabilities.decorator';
import { SystemService } from './system.service';

@ApiTags('system')
@Controller('system')
export class SystemController {
  constructor(private readonly system: SystemService) {}

  @Get('version')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  version() {
    return this.system.getVersionInfo();
  }

  @Get('status')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  status() {
    return this.system.getStatus();
  }

  @Get('updates')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  updates() {
    return this.system.checkUpdates();
  }

  /** Download and apply the latest core in place (database, .env and uploads are kept). */
  @Post('updates/apply')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  applyUpdate() {
    return this.system.startCoreUpdate();
  }

  @Get('updates/progress')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  updateProgress() {
    return this.system.getUpdateProgress();
  }

  /** Live Lighthouse scores for the public site (cached ~5 minutes). */
  @Get('lighthouse')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  lighthouse(@Query('refresh') refresh?: string) {
    return this.system.getLighthouseScores({
      force: refresh === '1' || refresh === 'true',
    });
  }

  /**
   * Full cache flush — busts theme/layout asset URLs, Next.js ISR,
   * Lighthouse cache, and the production web build used for hive scores.
   */
  @Post('cache/flush')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  flushCache() {
    return this.system.flushCache();
  }
}
