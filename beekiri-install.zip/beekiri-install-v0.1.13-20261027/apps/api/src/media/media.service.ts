import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { createId } from './media.id';
import { mkdir, unlink, writeFile } from 'fs/promises';
import { dirname, extname, join } from 'path';
import sharp from 'sharp';
import { PrismaService } from '../prisma/prisma.service';
import {
  defaultMediaSettings,
  parseMediaSettings,
  readOptions,
  type MediaSettingsOption,
} from '../site/site-options';
import { resolveUploadsRoot } from './media.paths';

const ALLOWED_MIME = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
  'image/gif',
  'image/svg+xml',
  'image/x-icon',
  'image/vnd.microsoft.icon',
]);

/** Non-image uploads (ACF File fields). Extension comes from this map, never the client filename. */
const FILE_EXT: Record<string, string> = {
  'application/pdf': '.pdf',
  'application/zip': '.zip',
  'text/plain': '.txt',
  'text/csv': '.csv',
  'application/msword': '.doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
  'application/vnd.ms-excel': '.xls',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx',
  'application/vnd.ms-powerpoint': '.ppt',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': '.pptx',
  'video/mp4': '.mp4',
  'video/webm': '.webm',
  'audio/mpeg': '.mp3',
  'audio/wav': '.wav',
};

for (const mime of Object.keys(FILE_EXT)) ALLOWED_MIME.add(mime);

const PASS_THROUGH = new Set([
  'image/svg+xml',
  'image/x-icon',
  'image/vnd.microsoft.icon',
]);

export type UploadPurpose = 'media' | 'favicon';

export type UploadInput = {
  buffer: Buffer;
  filename: string;
  mimeType: string;
  folderId?: string | null;
  alt?: string;
  purpose?: UploadPurpose;
  uploadedById?: string | null;
};

function sanitizeBaseName(name: string): string {
  const base = name.replace(/\.[^.]+$/, '').toLowerCase();
  const cleaned = base.replace(/[^a-z0-9._-]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
  return cleaned.slice(0, 80) || 'file';
}

function extForMime(mime: string, original: string): string {
  if (mime === 'image/jpeg') return '.jpg';
  if (mime === 'image/png') return '.png';
  if (mime === 'image/webp') return '.webp';
  if (mime === 'image/gif') return '.gif';
  if (mime === 'image/svg+xml') return '.svg';
  if (mime === 'image/x-icon' || mime === 'image/vnd.microsoft.icon') return '.ico';
  if (FILE_EXT[mime]) return FILE_EXT[mime];
  const e = extname(original).toLowerCase();
  return e || '.bin';
}

@Injectable()
export class MediaService {
  constructor(private readonly prisma: PrismaService) {}

  private async siteAndMediaSettings() {
    const site = await this.prisma.site.findFirst({
      include: { settings: true },
      orderBy: { createdAt: 'asc' },
    });
    if (!site) throw new NotFoundException('Site not found');
    const opts = readOptions(site.settings?.options);
    const media = opts.media ? parseMediaSettings(opts.media) : defaultMediaSettings();
    return { site, media };
  }

  private serialize(row: {
    id: string;
    filename: string;
    originalName: string;
    mimeType: string;
    size: number;
    width: number | null;
    height: number | null;
    url: string;
    folderId: string | null;
    alt: string;
    createdAt: Date;
    updatedAt: Date;
  }) {
    return {
      id: row.id,
      filename: row.filename,
      originalName: row.originalName,
      mimeType: row.mimeType,
      size: row.size,
      width: row.width,
      height: row.height,
      url: row.url,
      folderId: row.folderId,
      alt: row.alt,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    };
  }

  async list(folderId?: string | null) {
    const { site, media } = await this.siteAndMediaSettings();
    const where =
      folderId === undefined
        ? { siteId: site.id }
        : folderId === '' || folderId === 'null'
          ? { siteId: site.id, folderId: null }
          : { siteId: site.id, folderId };
    const rows = await this.prisma.mediaAsset.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });
    return {
      items: rows.map((r) => this.serialize(r)),
      folders: media.folders,
    };
  }

  async upload(input: UploadInput) {
    const mime = (input.mimeType || '').toLowerCase().split(';')[0].trim();
    if (!ALLOWED_MIME.has(mime)) {
      throw new BadRequestException(
        'Unsupported file type. Use an image (JPEG, PNG, WebP, GIF, SVG, ICO), PDF, Office document, ZIP, CSV/TXT, MP4/WebM or MP3/WAV.',
      );
    }
    if (!input.buffer?.length) {
      throw new BadRequestException('Empty file.');
    }
    if (input.buffer.length > 20 * 1024 * 1024) {
      throw new BadRequestException('File too large (max 20 MB).');
    }

    const { site, media } = await this.siteAndMediaSettings();
    const purpose: UploadPurpose = input.purpose === 'favicon' ? 'favicon' : 'media';

    if (input.folderId) {
      const ok = media.folders.some((f) => f.id === input.folderId);
      if (!ok) throw new BadRequestException('Unknown media folder.');
    }

    const processed = await this.processBuffer(input.buffer, mime, purpose, media);
    const now = new Date();
    const yyyy = String(now.getFullYear());
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const id = createId();
    const base = sanitizeBaseName(input.filename);
    const filename = `${base}-${id}${processed.ext}`;
    const storagePath = join(yyyy, mm, filename);
    const abs = join(resolveUploadsRoot(), storagePath);
    await mkdir(dirname(abs), { recursive: true });
    await writeFile(abs, processed.buffer);

    const url = `/uploads/${yyyy}/${mm}/${filename}`;
    const row = await this.prisma.mediaAsset.create({
      data: {
        siteId: site.id,
        filename,
        originalName: input.filename.slice(0, 255),
        mimeType: processed.mimeType,
        size: processed.buffer.length,
        width: processed.width,
        height: processed.height,
        url,
        storagePath: storagePath.replace(/\\/g, '/'),
        folderId: input.folderId || null,
        alt: (input.alt ?? '').slice(0, 500),
        uploadedById: input.uploadedById || null,
      },
    });

    return { item: this.serialize(row) };
  }

  private async processBuffer(
    buffer: Buffer,
    mime: string,
    purpose: UploadPurpose,
    media: MediaSettingsOption,
  ): Promise<{
    buffer: Buffer;
    mimeType: string;
    ext: string;
    width: number | null;
    height: number | null;
  }> {
    if (PASS_THROUGH.has(mime) || FILE_EXT[mime]) {
      return {
        buffer,
        mimeType: mime,
        ext: extForMime(mime, ''),
        width: null,
        height: null,
      };
    }

    let pipeline = sharp(buffer, { animated: mime === 'image/gif' }).rotate();
    const meta = await pipeline.metadata();
    let width = meta.width ?? null;
    let height = meta.height ?? null;

    const maxW = purpose === 'favicon' ? 512 : media.maxWidth;
    const maxH = purpose === 'favicon' ? 512 : media.maxHeight;
    if (width && height && (width > maxW || height > maxH)) {
      pipeline = pipeline.resize({
        width: maxW,
        height: maxH,
        fit: 'inside',
        withoutEnlargement: true,
      });
    }

    // Re-encoding via sharp strips EXIF/IPTC when stripMetadata is on (default).
    void media.stripMetadata;

    // Favicons stay as PNG — browsers prefer PNG/ICO over WebP for tab icons.
    if (purpose === 'favicon') {
      const out = await pipeline.png({ compressionLevel: 9 }).toBuffer({ resolveWithObject: true });
      return {
        buffer: out.data,
        mimeType: 'image/png',
        ext: '.png',
        width: out.info.width,
        height: out.info.height,
      };
    }

    if (media.convertToWebp) {
      const out = await pipeline
        .webp(
          media.webpLossless
            ? { lossless: true }
            : { quality: media.webpQuality, effort: 4 },
        )
        .toBuffer({ resolveWithObject: true });
      return {
        buffer: out.data,
        mimeType: 'image/webp',
        ext: '.webp',
        width: out.info.width,
        height: out.info.height,
      };
    }

    const out = await pipeline.toBuffer({ resolveWithObject: true });
    return {
      buffer: out.data,
      mimeType: mime,
      ext: extForMime(mime, ''),
      width: out.info.width ?? width,
      height: out.info.height ?? height,
    };
  }

  async update(id: string, data: { alt?: string; folderId?: string | null }) {
    const { site, media } = await this.siteAndMediaSettings();
    const existing = await this.prisma.mediaAsset.findFirst({
      where: { id, siteId: site.id },
    });
    if (!existing) throw new NotFoundException('Media not found');

    if (data.folderId !== undefined && data.folderId !== null && data.folderId !== '') {
      const ok = media.folders.some((f) => f.id === data.folderId);
      if (!ok) throw new BadRequestException('Unknown media folder.');
    }

    const row = await this.prisma.mediaAsset.update({
      where: { id },
      data: {
        alt: data.alt !== undefined ? data.alt.slice(0, 500) : undefined,
        folderId:
          data.folderId === undefined
            ? undefined
            : data.folderId === null || data.folderId === ''
              ? null
              : data.folderId,
      },
    });
    return { item: this.serialize(row) };
  }

  async remove(id: string) {
    const { site } = await this.siteAndMediaSettings();
    const existing = await this.prisma.mediaAsset.findFirst({
      where: { id, siteId: site.id },
    });
    if (!existing) throw new NotFoundException('Media not found');

    await this.prisma.mediaAsset.delete({ where: { id } });
    try {
      await unlink(join(resolveUploadsRoot(), existing.storagePath));
    } catch {
      // File may already be gone — DB row is the source of truth for the library.
    }
    return { ok: true };
  }

  async bulkMove(ids: string[], folderId: string | null | undefined) {
    const { site, media } = await this.siteAndMediaSettings();
    const uniqueIds = [...new Set(ids.map((id) => id.trim()).filter(Boolean))].slice(0, 200);
    if (!uniqueIds.length) throw new BadRequestException('No media selected.');

    let nextFolder: string | null = null;
    if (folderId !== undefined && folderId !== null && folderId !== '') {
      const ok = media.folders.some((f) => f.id === folderId);
      if (!ok) throw new BadRequestException('Unknown media folder.');
      nextFolder = folderId;
    }

    const result = await this.prisma.mediaAsset.updateMany({
      where: { siteId: site.id, id: { in: uniqueIds } },
      data: { folderId: nextFolder },
    });
    return { ok: true, updated: result.count };
  }

  async bulkRemove(ids: string[]) {
    const { site } = await this.siteAndMediaSettings();
    const uniqueIds = [...new Set(ids.map((id) => id.trim()).filter(Boolean))].slice(0, 200);
    if (!uniqueIds.length) throw new BadRequestException('No media selected.');

    const rows = await this.prisma.mediaAsset.findMany({
      where: { siteId: site.id, id: { in: uniqueIds } },
    });
    await this.prisma.mediaAsset.deleteMany({
      where: { siteId: site.id, id: { in: rows.map((r) => r.id) } },
    });
    for (const row of rows) {
      try {
        await unlink(join(resolveUploadsRoot(), row.storagePath));
      } catch {
        /* file may already be gone */
      }
    }
    return { ok: true, deleted: rows.length };
  }
}
