import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiConsumes, ApiTags } from '@nestjs/swagger';
import type { MultipartFile } from '@fastify/multipart';
import { AuthGuard, type AuthedRequest } from '../auth/auth.guard';
import { CapabilitiesGuard } from '../auth/capabilities.guard';
import { RequireCapabilities } from '../auth/capabilities.decorator';
import { BulkDeleteMediaDto, BulkMediaDto, UpdateMediaDto } from './media.dto';
import { MediaService, type UploadPurpose } from './media.service';

function fieldValue(
  fields: MultipartFile['fields'] | undefined,
  key: string,
): string | undefined {
  if (!fields) return undefined;
  const raw = fields[key];
  if (!raw) return undefined;
  const part = Array.isArray(raw) ? raw[0] : raw;
  if (part && typeof part === 'object' && 'value' in part) {
    return String((part as { value: unknown }).value);
  }
  return undefined;
}

@ApiTags('media')
@Controller('media')
@UseGuards(AuthGuard, CapabilitiesGuard)
export class MediaController {
  constructor(private readonly media: MediaService) {}

  @Get()
  @RequireCapabilities('upload_files')
  list(@Query('folderId') folderId?: string) {
    return this.media.list(folderId);
  }

  @Post('upload')
  @RequireCapabilities('upload_files')
  @ApiConsumes('multipart/form-data')
  async upload(
    @Req() req: AuthedRequest,
    @Query('purpose') purposeQ?: UploadPurpose,
    @Query('folderId') folderIdQ?: string,
    @Query('alt') altQ?: string,
  ) {
    const file = (await req.file()) as MultipartFile | undefined;
    if (!file) throw new BadRequestException('No file uploaded. Use field name "file".');

    const buffer = await file.toBuffer();
    const purposeRaw = purposeQ || fieldValue(file.fields, 'purpose');
    const folderId = folderIdQ || fieldValue(file.fields, 'folderId') || null;
    const alt = altQ || fieldValue(file.fields, 'alt');

    return this.media.upload({
      buffer,
      filename: file.filename || 'upload',
      mimeType: file.mimetype || 'application/octet-stream',
      folderId,
      alt,
      purpose: purposeRaw === 'favicon' ? 'favicon' : 'media',
      uploadedById: req.auth?.user.id ?? null,
    });
  }

  @Post('bulk-move')
  @RequireCapabilities('upload_files')
  bulkMove(@Body() body: BulkMediaDto) {
    return this.media.bulkMove(body.ids, body.folderId);
  }

  @Post('bulk-delete')
  @RequireCapabilities('upload_files')
  bulkDelete(@Body() body: BulkDeleteMediaDto) {
    return this.media.bulkRemove(body.ids);
  }

  @Patch(':id')
  @RequireCapabilities('upload_files')
  update(@Param('id') id: string, @Body() body: UpdateMediaDto) {
    return this.media.update(id, body);
  }

  @Delete(':id')
  @RequireCapabilities('upload_files')
  remove(@Param('id') id: string) {
    return this.media.remove(id);
  }
}
