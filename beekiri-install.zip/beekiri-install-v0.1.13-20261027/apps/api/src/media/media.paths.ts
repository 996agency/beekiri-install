import { existsSync } from 'fs';
import { dirname, isAbsolute, join, resolve } from 'path';

/** Walk up until pnpm-workspace.yaml so MEDIA_LOCAL_PATH is stable from api or root cwd. */
export function findRepoRoot(start = process.cwd()): string {
  let dir = start;
  for (;;) {
    if (existsSync(join(dir, 'pnpm-workspace.yaml'))) return dir;
    const parent = dirname(dir);
    if (parent === dir) return start;
    dir = parent;
  }
}

export function resolveUploadsRoot(): string {
  // Media library files live under the admin app by default.
  const raw = process.env.MEDIA_LOCAL_PATH || './apps/admin/uploads';
  if (isAbsolute(raw)) return raw;
  return resolve(findRepoRoot(), raw);
}
