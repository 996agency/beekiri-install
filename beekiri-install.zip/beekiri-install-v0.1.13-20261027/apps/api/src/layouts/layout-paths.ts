import { join } from 'path';
import {
  DEFAULT_THEME_SLUG,
  resolveThemeDir,
  resolveThemesRoot,
  sanitizeThemeSlug,
} from '../themes/theme-registry';

/**
 * Layouts live inside the theme package (AUK / ACF-style):
 * apps/web/themes/{theme}/layouts/{slug}/
 *   {slug}.php | {slug}.tsx
 *   styles.scss → styles.css (or styles.min.css)
 *   script.js
 *   {slug}.meta.json
 */
export function resolveLayoutsRoot(themeSlug: string = DEFAULT_THEME_SLUG): string {
  const clean = sanitizeThemeSlug(themeSlug) || DEFAULT_THEME_SLUG;
  const themeDir = resolveThemeDir(clean) ?? join(resolveThemesRoot(), clean);
  return join(themeDir, 'layouts');
}

/** `group_hero` → `hero`, `M7-Text-And-Media-Cards` key → slug. */
export function layoutSlugFromGroupKey(key: string): string {
  const raw = key
    .trim()
    .toLowerCase()
    .replace(/^group_/, '')
    .replace(/[^a-z0-9_]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .replace(/_{2,}/g, '_')
    .slice(0, 48);
  return raw || `layout_${Math.random().toString(36).slice(2, 8)}`;
}

/** Title → folder slug like AUK `sanitize_title` (m7-text-and-media-cards). */
export function layoutSlugFromTitle(title: string): string {
  const raw = title
    .trim()
    .toLowerCase()
    .replace(/^layout\s*:?\s*/i, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .replace(/-{2,}/g, '-')
    .slice(0, 64);
  return raw || layoutSlugFromGroupKey(title);
}

export function sanitizeLayoutSlug(raw: string): string | null {
  const slug = raw
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
  return slug || null;
}

export function layoutPaths(slug: string, themeSlug: string = DEFAULT_THEME_SLUG) {
  const root = resolveLayoutsRoot(themeSlug);
  const dir = join(root, slug);
  return {
    root,
    dir,
    themeSlug: sanitizeThemeSlug(themeSlug) || DEFAULT_THEME_SLUG,
    tsx: join(dir, `${slug}.tsx`),
    php: join(dir, `${slug}.php`),
    scss: join(dir, 'styles.scss'),
    css: join(dir, 'styles.css'),
    cssMin: join(dir, 'styles.min.css'),
    js: join(dir, 'script.js'),
    meta: join(dir, `${slug}.meta.json`),
  };
}
