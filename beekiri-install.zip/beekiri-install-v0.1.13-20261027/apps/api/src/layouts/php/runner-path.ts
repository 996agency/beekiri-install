import { existsSync } from 'fs';
import { join } from 'path';

/** Locate layout-runner.php for both `nest start` (src) and compiled dist builds. */
export function resolveLayoutRunnerPath(): string | null {
  const candidates = [
    join(__dirname, 'layout-runner.php'),
    join(__dirname, '..', 'php', 'layout-runner.php'),
    join(__dirname, '..', 'layouts', 'php', 'layout-runner.php'),
    join(process.cwd(), 'apps/api/src/layouts/php/layout-runner.php'),
    join(process.cwd(), 'src/layouts/php/layout-runner.php'),
  ];
  return candidates.find((p) => existsSync(p)) ?? null;
}
