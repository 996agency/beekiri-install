import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { PrismaModule } from '../prisma/prisma.module';
import { ThemesModule } from '../themes/themes.module';
import { LayoutSyncService } from './layout-sync.service';
import { LayoutsController } from './layouts.controller';

@Module({
  imports: [PrismaModule, AuthModule, ThemesModule],
  controllers: [LayoutsController],
  providers: [LayoutSyncService],
  exports: [LayoutSyncService],
})
export class LayoutsModule {}
