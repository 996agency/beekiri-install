import {
  Body,
  Controller,
  Get,
  Header,
  NotFoundException,
  Param,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { AuthGuard, type AuthedRequest } from '../auth/auth.guard';
import { CapabilitiesGuard } from '../auth/capabilities.guard';
import { RequireCapabilities } from '../auth/capabilities.decorator';
import { LayoutSyncService } from './layout-sync.service';
import { sanitizeLayoutSlug } from './layout-paths';

@ApiTags('layouts')
@Controller('layouts')
export class LayoutsController {
  constructor(private readonly layouts: LayoutSyncService) {}

  /** Public — editor + frontend load available page layouts. */
  @Get()
  list() {
    return { layouts: this.layouts.listPublic() };
  }

  @Get(':slug/css')
  @Header('Content-Type', 'text/css; charset=utf-8')
  // URLs are versioned (`?v=`) by listPublic — safe to cache hard for Perf.
  @Header('Cache-Control', 'public, max-age=31536000, immutable')
  @Header('Access-Control-Allow-Origin', '*')
  css(@Param('slug') slug: string) {
    const clean = sanitizeLayoutSlug(slug);
    if (!clean) throw new NotFoundException('Layout not found.');
    const css = this.layouts.readCss(clean);
    if (css == null) throw new NotFoundException('Layout CSS not found.');
    return css;
  }

  @Get(':slug/js')
  @Header('Content-Type', 'application/javascript; charset=utf-8')
  @Header('Cache-Control', 'public, max-age=31536000, immutable')
  @Header('Access-Control-Allow-Origin', '*')
  js(@Param('slug') slug: string) {
    const clean = sanitizeLayoutSlug(slug);
    if (!clean) throw new NotFoundException('Layout not found.');
    const js = this.layouts.readJs(clean);
    if (js == null) throw new NotFoundException('Layout script not found.');
    return js;
  }

  /**
   * Public — render layouts/{slug}/{slug}.php or .tsx (Settings → frontend runtime).
   * Editor canvas + public pages use this so template edits show up.
   * Body/query `runtime: 'php' | 'react'` forces one engine (avoids proxy loops).
   */
  @Get(':slug/render')
  @Header('Cache-Control', 'no-store')
  async renderGet(
    @Param('slug') slug: string,
    @Query('fields') fieldsRaw?: string,
    @Query('runtime') runtimeRaw?: string,
  ) {
    const clean = sanitizeLayoutSlug(slug);
    if (!clean) throw new NotFoundException('Layout not found.');
    let fields: Record<string, unknown> = {};
    if (fieldsRaw) {
      try {
        const parsed = JSON.parse(fieldsRaw) as unknown;
        if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
          fields = parsed as Record<string, unknown>;
        }
      } catch {
        /* ignore bad json */
      }
    }
    const force =
      runtimeRaw === 'php' || runtimeRaw === 'react' ? runtimeRaw : undefined;
    const html = await this.layouts.renderLayout(clean, fields, force);
    if (html == null) throw new NotFoundException('Layout not found.');
    return { slug: clean, html };
  }

  @Post(':slug/render')
  @Header('Cache-Control', 'no-store')
  async renderPost(
    @Param('slug') slug: string,
    @Body() body: { fields?: Record<string, unknown>; runtime?: 'php' | 'react' },
  ) {
    const clean = sanitizeLayoutSlug(slug);
    if (!clean) throw new NotFoundException('Layout not found.');
    const force =
      body?.runtime === 'php' || body?.runtime === 'react' ? body.runtime : undefined;
    const html = await this.layouts.renderLayout(clean, body?.fields ?? {}, force);
    if (html == null) throw new NotFoundException('Layout not found.');
    return { slug: clean, html };
  }

  /** Public — formatted field values (what get_bee_field() returns) for React layouts. */
  @Post(':slug/fields')
  @Header('Cache-Control', 'no-store')
  async formatFields(
    @Param('slug') slug: string,
    @Body() body: { fields?: Record<string, unknown> },
  ) {
    const clean = sanitizeLayoutSlug(slug);
    if (!clean) throw new NotFoundException('Layout not found.');
    const fields = await this.layouts.formatLayoutFields(clean, body?.fields ?? {});
    return { slug: clean, fields };
  }

  @Post('sync')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  async syncAll(@Req() _req: AuthedRequest) {
    const count = await this.layouts.syncAllActive();
    return { ok: true, synced: count, layouts: this.layouts.listPublic() };
  }

  @Post(':slug/compile')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  compile(@Param('slug') slug: string) {
    const ok = this.layouts.compileSlug(slug);
    if (!ok) throw new NotFoundException('Layout SCSS not found.');
    return { ok: true, slug: sanitizeLayoutSlug(slug) };
  }
}
