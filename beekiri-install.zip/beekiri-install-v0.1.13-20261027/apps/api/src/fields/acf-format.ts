import {
  NO_VALUE_TYPES,
  parseChoice,
  type BackendField,
  type FlexibleLayout,
} from './fields.types';

/**
 * Format stored values → what get_bee_field() / get_sub_field() return in PHP layouts.
 *
 * Raw storage (same idea as ACF post meta):
 *   image/file → media id · gallery → id[] · post_object/relationship/user → id | id[]
 *   true_false → boolean · date_picker → Ymd · date_time_picker → Y-m-d H:i:s · time_picker → H:i:s
 *   repeater → row[] · group → object · flexible_content → { acf_fc_layout, ... }[]
 */

export type MediaRow = {
  id: string;
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  width: number | null;
  height: number | null;
  url: string;
  alt: string;
};

export type PostRow = {
  id: string;
  type: string;
  title: string;
  slug: string;
  status: string;
  excerpt: string;
  publishedAt: Date | null;
};

export type UserRow = {
  id: string;
  username: string;
  displayName: string;
};

export type FormatLookups = {
  media(ids: string[]): Promise<MediaRow[]>;
  posts(ids: string[]): Promise<PostRow[]>;
  users(ids: string[]): Promise<UserRow[]>;
};

type Refs = { media: Set<string>; posts: Set<string>; users: Set<string> };

type Maps = {
  media: Map<string, MediaRow>;
  posts: Map<string, PostRow>;
  users: Map<string, UserRow>;
};

const isObj = (v: unknown): v is Record<string, unknown> =>
  !!v && typeof v === 'object' && !Array.isArray(v);

const idList = (v: unknown): string[] => {
  if (Array.isArray(v)) return v.flatMap(idList);
  if (typeof v === 'string' && v.trim()) return [v.trim()];
  if (typeof v === 'number') return [String(v)];
  if (isObj(v) && (typeof v.id === 'string' || typeof v.ID === 'string')) {
    return [String(v.id ?? v.ID)];
  }
  return [];
};

const looksLikeUrl = (s: string) => /^(https?:)?\/\//.test(s) || s.startsWith('/');

function layoutFor(field: BackendField, name: unknown): FlexibleLayout | undefined {
  return field.layouts?.find((l) => l.name === name);
}

/* —— pass 1: collect ids to resolve in one query per table —— */

function collect(defs: BackendField[], values: Record<string, unknown>, refs: Refs) {
  for (const f of defs) {
    const v = values[f.name];
    if (v == null) continue;
    switch (f.type) {
      case 'image':
      case 'file':
      case 'gallery':
        idList(v).filter((id) => !looksLikeUrl(id)).forEach((id) => refs.media.add(id));
        break;
      case 'post_object':
      case 'page_link':
      case 'relationship':
        idList(v).filter((id) => !looksLikeUrl(id)).forEach((id) => refs.posts.add(id));
        break;
      case 'link':
        break;
      case 'user':
        idList(v).forEach((id) => refs.users.add(id));
        break;
      case 'group':
        if (isObj(v)) collect(f.subFields ?? [], v, refs);
        break;
      case 'repeater':
        if (Array.isArray(v)) v.forEach((row) => isObj(row) && collect(f.subFields ?? [], row, refs));
        break;
      case 'flexible_content':
        if (Array.isArray(v)) {
          for (const row of v) {
            if (!isObj(row)) continue;
            const layout = layoutFor(f, row.acf_fc_layout);
            if (layout) collect(layout.subFields, row, refs);
          }
        }
        break;
      default:
        break;
    }
  }
}

/* —— PHP date() subset (ACF return formats) —— */

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const DAYS = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

function parseStoredDate(raw: string): Date | null {
  const s = raw.trim();
  let m = s.match(/^(\d{4})(\d{2})(\d{2})$/);
  if (m) return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  m = s.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/);
  if (m) {
    return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4] ?? 0), Number(m[5] ?? 0), Number(m[6] ?? 0));
  }
  m = s.match(/^(\d{2}):(\d{2})(?::(\d{2}))?$/);
  if (m) return new Date(1970, 0, 1, Number(m[1]), Number(m[2]), Number(m[3] ?? 0));
  return null;
}

export function phpDate(format: string, d: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  const day = d.getDate();
  const suffix = day % 10 === 1 && day !== 11 ? 'st' : day % 10 === 2 && day !== 12 ? 'nd' : day % 10 === 3 && day !== 13 ? 'rd' : 'th';
  const h = d.getHours();
  const g = h % 12 || 12;
  let out = '';
  for (let i = 0; i < format.length; i++) {
    const c = format[i];
    if (c === '\\') {
      out += format[++i] ?? '';
      continue;
    }
    switch (c) {
      case 'd': out += pad(day); break;
      case 'j': out += day; break;
      case 'D': out += DAYS[d.getDay()].slice(0, 3); break;
      case 'l': out += DAYS[d.getDay()]; break;
      case 'N': out += d.getDay() || 7; break;
      case 'w': out += d.getDay(); break;
      case 'S': out += suffix; break;
      case 'F': out += MONTHS[d.getMonth()]; break;
      case 'M': out += MONTHS[d.getMonth()].slice(0, 3); break;
      case 'm': out += pad(d.getMonth() + 1); break;
      case 'n': out += d.getMonth() + 1; break;
      case 'Y': out += d.getFullYear(); break;
      case 'y': out += String(d.getFullYear()).slice(-2); break;
      case 'a': out += h < 12 ? 'am' : 'pm'; break;
      case 'A': out += h < 12 ? 'AM' : 'PM'; break;
      case 'g': out += g; break;
      case 'G': out += h; break;
      case 'h': out += pad(g); break;
      case 'H': out += pad(h); break;
      case 'i': out += pad(d.getMinutes()); break;
      case 's': out += pad(d.getSeconds()); break;
      case 'U': out += Math.floor(d.getTime() / 1000); break;
      default: out += c;
    }
  }
  return out;
}

/* —— text helpers —— */

const escHtml = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/** Minimal wpautop: blank-line separated blocks → <p>, single newlines → <br />. */
export function wpautop(text: string): string {
  const t = text.replace(/\r\n?/g, '\n').trim();
  if (!t) return '';
  if (/^\s*<(p|div|h[1-6]|ul|ol|table|blockquote|figure|section|pre)[\s>]/i.test(t)) return t;
  return t
    .split(/\n{2,}/)
    .map((block) => `<p>${block.replace(/\n/g, '<br />\n')}</p>`)
    .join('\n');
}

function oembedHtml(url: string): string {
  const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{6,})/);
  if (yt) {
    return `<iframe width="640" height="360" src="https://www.youtube.com/embed/${yt[1]}?feature=oembed" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen title="YouTube video"></iframe>`;
  }
  const vimeo = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  if (vimeo) {
    return `<iframe src="https://player.vimeo.com/video/${vimeo[1]}" width="640" height="360" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen title="Vimeo video"></iframe>`;
  }
  if (/^https?:\/\//.test(url)) return `<a href="${escHtml(url)}">${escHtml(url)}</a>`;
  return '';
}

/* —— entity shapes (match ACF / WP arrays) —— */

function mediaArray(m: MediaRow, kind: 'image' | 'file') {
  const [type, subtype] = m.mimeType.split('/');
  const base = {
    ID: m.id,
    id: m.id,
    title: m.originalName.replace(/\.[^.]+$/, ''),
    filename: m.filename,
    filesize: m.size,
    url: m.url,
    link: m.url,
    alt: m.alt,
    author: '',
    description: '',
    caption: '',
    name: m.filename.replace(/\.[^.]+$/, ''),
    mime_type: m.mimeType,
    type: type || kind,
    subtype: subtype || '',
    icon: '',
  };
  if (kind === 'file') return base;
  const w = m.width ?? 0;
  const h = m.height ?? 0;
  const sizes: Record<string, string | number> = {};
  for (const s of ['thumbnail', 'medium', 'medium_large', 'large', '1536x1536', '2048x2048']) {
    sizes[s] = m.url;
    sizes[`${s}-width`] = w;
    sizes[`${s}-height`] = h;
  }
  return { ...base, width: w, height: h, sizes };
}

function urlOnlyMedia(url: string, kind: 'image' | 'file') {
  const filename = url.split('/').pop() || url;
  return mediaArray(
    { id: '', filename, originalName: filename, mimeType: kind === 'image' ? 'image/*' : '', size: 0, width: null, height: null, url, alt: '' },
    kind,
  );
}

function permalink(p: PostRow) {
  return `/${p.slug}`;
}

function postObject(p: PostRow) {
  return {
    ID: p.id,
    id: p.id,
    post_title: p.title,
    post_name: p.slug,
    post_type: p.type,
    post_status: p.status,
    post_excerpt: p.excerpt,
    post_date: p.publishedAt ? phpDate('Y-m-d H:i:s', p.publishedAt) : '',
    permalink: permalink(p),
    url: permalink(p),
  };
}

function userArray(u: UserRow) {
  return {
    ID: u.id,
    id: u.id,
    user_login: u.username,
    user_nicename: u.username,
    display_name: u.displayName,
    nickname: u.displayName,
  };
}

/* —— pass 2: format —— */

function formatChoice(f: BackendField, v: string) {
  const choice = f.choices.map(parseChoice).find((c) => c.value === v) ?? { value: v, label: v };
  if (f.returnFormat === 'label') return choice.label;
  if (f.returnFormat === 'array') return choice;
  return choice.value;
}

function formatOne(f: BackendField, raw: unknown, maps: Maps): unknown {
  const empty = raw == null || raw === '' || (Array.isArray(raw) && raw.length === 0);
  const fallback = empty && f.defaultValue !== '' ? f.defaultValue : raw;

  switch (f.type) {
    case 'text':
    case 'email':
    case 'url':
    case 'password':
    case 'color_picker':
      return typeof fallback === 'string' ? fallback : fallback == null ? '' : String(fallback);

    case 'textarea': {
      const s = typeof fallback === 'string' ? fallback : '';
      if (f.newLines === 'wpautop') return wpautop(s);
      if (f.newLines === 'br') return s.replace(/\r?\n/g, '<br />\n');
      return s;
    }

    case 'wysiwyg':
      return wpautop(typeof fallback === 'string' ? fallback : '');

    case 'oembed':
      return typeof raw === 'string' && raw.trim() ? oembedHtml(raw.trim()) : '';

    case 'number':
    case 'range': {
      if (fallback === '' || fallback == null) return '';
      const n = Number(fallback);
      return Number.isFinite(n) ? n : '';
    }

    case 'true_false':
      if (raw == null || raw === '') return f.defaultValue === '1' || f.defaultValue === 'true';
      return raw === true || raw === 1 || raw === '1' || raw === 'true';

    case 'select':
    case 'checkbox':
    case 'radio':
    case 'button_group': {
      const multi = f.type === 'checkbox' || (f.type === 'select' && f.multiple);
      const vals = (Array.isArray(fallback) ? fallback : typeof fallback === 'string' && fallback !== '' ? [fallback] : [])
        .filter((x): x is string => typeof x === 'string');
      if (multi) return vals.map((v) => formatChoice(f, v));
      return vals.length ? formatChoice(f, vals[0]) : null;
    }

    case 'image':
    case 'file': {
      const [id] = idList(raw);
      if (!id) return null;
      const row = maps.media.get(id);
      const kind = f.type;
      if (f.returnFormat === 'id') return row ? row.id : null;
      if (f.returnFormat === 'url') return row ? row.url : looksLikeUrl(id) ? id : null;
      if (row) return mediaArray(row, kind);
      return looksLikeUrl(id) ? urlOnlyMedia(id, kind) : null;
    }

    case 'gallery': {
      const ids = idList(raw);
      const out: unknown[] = [];
      for (const id of ids) {
        const row = maps.media.get(id);
        if (f.returnFormat === 'id') { if (row) out.push(row.id); continue; }
        if (f.returnFormat === 'url') { const u = row?.url ?? (looksLikeUrl(id) ? id : ''); if (u) out.push(u); continue; }
        if (row) out.push(mediaArray(row, 'image'));
        else if (looksLikeUrl(id)) out.push(urlOnlyMedia(id, 'image'));
      }
      return out;
    }

    case 'link': {
      const link = isObj(raw)
        ? { title: String(raw.title ?? ''), url: String(raw.url ?? ''), target: String(raw.target ?? '') }
        : typeof raw === 'string' && raw
          ? { title: '', url: raw, target: '' }
          : null;
      if (!link || !link.url) return f.returnFormat === 'url' ? '' : null;
      return f.returnFormat === 'url' ? link.url : link;
    }

    case 'post_object':
    case 'relationship':
    case 'page_link': {
      const ids = idList(raw);
      const multi = f.type === 'relationship' || Boolean(f.multiple);
      const out = ids
        .map((id) => {
          if (f.type === 'page_link') {
            if (looksLikeUrl(id)) return id;
            const p = maps.posts.get(id);
            return p ? permalink(p) : null;
          }
          const p = maps.posts.get(id);
          if (!p) return null;
          return f.returnFormat === 'id' ? p.id : postObject(p);
        })
        .filter((x) => x != null);
      if (multi) return out;
      return out[0] ?? null;
    }

    case 'user': {
      const ids = idList(raw);
      const out = ids
        .map((id) => maps.users.get(id))
        .filter((u): u is UserRow => !!u)
        .map((u) => (f.returnFormat === 'id' ? u.id : userArray(u)));
      return f.multiple ? out : out[0] ?? null;
    }

    case 'date_picker':
    case 'date_time_picker':
    case 'time_picker': {
      if (typeof fallback !== 'string' || !fallback.trim()) return '';
      const d = parseStoredDate(fallback);
      if (!d) return fallback;
      const def = f.type === 'date_picker' ? 'd/m/Y' : f.type === 'time_picker' ? 'g:i a' : 'd/m/Y g:i a';
      return phpDate(f.returnFormat || def, d);
    }

    case 'group':
      return formatFieldValues(f.subFields ?? [], isObj(raw) ? raw : {}, maps);

    case 'repeater':
      if (!Array.isArray(raw)) return [];
      return raw.filter(isObj).map((row) => formatFieldValues(f.subFields ?? [], row, maps));

    case 'flexible_content':
      if (!Array.isArray(raw)) return [];
      return raw.filter(isObj).flatMap((row) => {
        const layout = layoutFor(f, row.acf_fc_layout);
        if (!layout) return [];
        return [{ acf_fc_layout: layout.name, ...formatFieldValues(layout.subFields, row, maps) }];
      });

    default:
      return raw;
  }
}

function formatFieldValues(defs: BackendField[], values: Record<string, unknown>, maps: Maps) {
  const out: Record<string, unknown> = {};
  // Keep unknown keys (e.g. values for fields removed from the group) like ACF does.
  for (const [k, v] of Object.entries(values)) {
    if (k !== 'acf_fc_layout') out[k] = v;
  }
  for (const f of defs) {
    if (NO_VALUE_TYPES.has(f.type)) continue;
    out[f.name] = formatOne(f, values[f.name], maps);
  }
  return out;
}

export async function formatValues(
  defs: BackendField[],
  values: Record<string, unknown>,
  lookups: FormatLookups,
): Promise<Record<string, unknown>> {
  const refs: Refs = { media: new Set(), posts: new Set(), users: new Set() };
  collect(defs, values, refs);
  const [media, posts, users] = await Promise.all([
    refs.media.size ? lookups.media([...refs.media]) : Promise.resolve([]),
    refs.posts.size ? lookups.posts([...refs.posts]) : Promise.resolve([]),
    refs.users.size ? lookups.users([...refs.users]) : Promise.resolve([]),
  ]);
  const maps: Maps = {
    media: new Map(media.map((m) => [m.id, m])),
    posts: new Map(posts.map((p) => [p.id, p])),
    users: new Map(users.map((u) => [u.id, u])),
  };
  return formatFieldValues(defs, values, maps);
}
