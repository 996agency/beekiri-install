import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { LayoutsModule } from '../layouts/layouts.module';
import { FieldsController } from './fields.controller';
import { FieldsService } from './fields.service';
import { StructureService } from './structure.service';

@Module({
  imports: [AuthModule, LayoutsModule],
  controllers: [FieldsController],
  providers: [FieldsService, StructureService],
  exports: [FieldsService, StructureService],
})
export class FieldsModule {}
