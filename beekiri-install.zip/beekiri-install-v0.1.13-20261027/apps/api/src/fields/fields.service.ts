import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import type { AuthUser } from '../auth/auth.types';
import { LayoutSyncService } from '../layouts/layout-sync.service';
import type { CreateFieldGroupDto, UpdateFieldGroupDto } from './fields.dto';
import {
  parseFields,
  parseLocation,
  toSlugKey,
  type BackendField,
} from './fields.types';

@Injectable()
export class FieldsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly layouts: LayoutSyncService,
  ) {}

  private serialize(group: {
    id: string;
    title: string;
    key: string;
    description: string;
    active: boolean;
    location: unknown;
    fields: unknown;
    menuOrder: number;
    createdAt: Date;
    updatedAt: Date;
  }) {
    return {
      id: group.id,
      title: group.title,
      key: group.key,
      description: group.description,
      active: group.active,
      location: parseLocation(group.location),
      fields: parseFields(group.fields),
      menuOrder: group.menuOrder,
      fieldCount: parseFields(group.fields).length,
      createdAt: group.createdAt.toISOString(),
      updatedAt: group.updatedAt.toISOString(),
    };
  }

  private mapUnique(e: unknown): never {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
      throw new ConflictException('A field group with this key already exists.');
    }
    throw e;
  }

  async list(actor: AuthUser) {
    const groups = await this.prisma.fieldGroup.findMany({
      where: { siteId: actor.siteId },
      orderBy: [{ menuOrder: 'asc' }, { createdAt: 'asc' }],
    });
    return { groups: groups.map((g) => this.serialize(g)) };
  }

  async get(actor: AuthUser, id: string) {
    const group = await this.prisma.fieldGroup.findFirst({
      where: { id, siteId: actor.siteId },
    });
    if (!group) throw new NotFoundException('Field group not found.');
    return this.serialize(group);
  }

  async create(actor: AuthUser, dto: CreateFieldGroupDto) {
    const title = dto.title.trim();
    const key = (dto.key?.trim() || toSlugKey(title)).slice(0, 60);
    const fields = parseFields(dto.fields ?? []);
    const location = parseLocation(dto.location ?? ['post', 'page']);
    const maxOrder = await this.prisma.fieldGroup.aggregate({
      where: { siteId: actor.siteId },
      _max: { menuOrder: true },
    });

    try {
      const group = await this.prisma.fieldGroup.create({
        data: {
          siteId: actor.siteId,
          title,
          key,
          description: (dto.description ?? '').trim(),
          active: dto.active ?? true,
          location,
          fields,
          menuOrder: (maxOrder._max.menuOrder ?? -1) + 1,
        },
      });

      await this.prisma.auditLog.create({
        data: {
          siteId: actor.siteId,
          userId: actor.id,
          action: 'field_group.created',
          meta: { groupId: group.id, key: group.key },
        },
      });

      await this.layouts.syncGroupForSite(group);
      return this.serialize(group);
    } catch (e) {
      this.mapUnique(e);
    }
  }

  async update(actor: AuthUser, id: string, dto: UpdateFieldGroupDto) {
    const existing = await this.prisma.fieldGroup.findFirst({
      where: { id, siteId: actor.siteId },
    });
    if (!existing) throw new NotFoundException('Field group not found.');

    const data: Prisma.FieldGroupUpdateInput = {};
    if (dto.title !== undefined) data.title = dto.title.trim();
    if (dto.key !== undefined) data.key = dto.key.trim();
    if (dto.description !== undefined) data.description = dto.description.trim();
    if (dto.active !== undefined) data.active = dto.active;
    if (dto.location !== undefined) data.location = parseLocation(dto.location);
    if (dto.fields !== undefined) data.fields = parseFields(dto.fields);

    try {
      const group = await this.prisma.fieldGroup.update({
        where: { id: existing.id },
        data,
      });

      await this.prisma.auditLog.create({
        data: {
          siteId: actor.siteId,
          userId: actor.id,
          action: 'field_group.updated',
          meta: { groupId: group.id, key: group.key },
        },
      });

      if (existing.key !== group.key) {
        this.layouts.removeByGroupKey(existing.key);
      }
      if (group.active) {
        await this.layouts.syncGroupForSite(group);
      } else {
        this.layouts.removeByGroupKey(group.key);
      }
      return this.serialize(group);
    } catch (e) {
      this.mapUnique(e);
    }
  }

  async remove(actor: AuthUser, id: string) {
    const existing = await this.prisma.fieldGroup.findFirst({
      where: { id, siteId: actor.siteId },
    });
    if (!existing) throw new NotFoundException('Field group not found.');

    await this.prisma.fieldGroup.delete({ where: { id: existing.id } });

    await this.prisma.auditLog.create({
      data: {
        siteId: actor.siteId,
        userId: actor.id,
        action: 'field_group.deleted',
        meta: { groupId: existing.id, key: existing.key },
      },
    });

    this.layouts.removeByGroupKey(existing.key);
    return { ok: true };
  }

  /** Exported for typing consumers / future post editors. */
  async lookupPosts(actor: AuthUser, opts: { types: string[]; q: string; ids: string[] }) {
    const types = opts.types.filter((t) => /^[a-z][a-z0-9_-]*$/.test(t)).slice(0, 20);
    const ids = opts.ids.filter(Boolean).slice(0, 100);
    const q = opts.q.trim().slice(0, 100);
    const posts = await this.prisma.post.findMany({
      where: {
        siteId: actor.siteId,
        status: { not: 'trash' },
        ...(ids.length ? { id: { in: ids } } : {}),
        ...(types.length ? { type: { in: types } } : {}),
        ...(q ? { title: { contains: q, mode: 'insensitive' as const } } : {}),
      },
      select: { id: true, title: true, slug: true, type: true, status: true },
      orderBy: [{ type: 'asc' }, { title: 'asc' }],
      take: ids.length ? ids.length : 50,
    });
    return { items: posts };
  }

  async lookupUsers(actor: AuthUser, opts: { q: string; ids: string[]; roles: string[] }) {
    const ids = opts.ids.filter(Boolean).slice(0, 100);
    const roles = opts.roles.filter((r) => /^[a-z][a-z0-9_-]*$/.test(r)).slice(0, 20);
    const q = opts.q.trim().slice(0, 100);
    const users = await this.prisma.user.findMany({
      where: {
        siteId: actor.siteId,
        ...(ids.length ? { id: { in: ids } } : {}),
        ...(roles.length ? { role: { slug: { in: roles } } } : {}),
        ...(q
          ? {
              OR: [
                { displayName: { contains: q, mode: 'insensitive' as const } },
                { username: { contains: q, mode: 'insensitive' as const } },
              ],
            }
          : {}),
      },
      select: { id: true, username: true, displayName: true },
      orderBy: { displayName: 'asc' },
      take: ids.length ? ids.length : 50,
    });
    return { items: users };
  }

  normalizePayload(fields: BackendField[], location: string[]) {
    return { fields: parseFields(fields), location: parseLocation(location) };
  }
}
