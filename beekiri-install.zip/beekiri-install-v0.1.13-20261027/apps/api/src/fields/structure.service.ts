import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import type { AuthUser } from '../auth/auth.types';
import { readOptions, mergeSiteOptions } from '../site/site-options';
import type {
  CreateOptionsPageDto,
  CreatePostTypeDto,
  CreateTaxonomyDto,
  FieldsSettingsDto,
  UpdateOptionsPageDto,
  UpdatePostTypeDto,
  UpdateTaxonomyDto,
} from './structure.dto';

const DEFAULT_SUPPORTS = ['title', 'editor'];

function parseStringArray(raw: unknown, fallback: string[] = []): string[] {
  if (!Array.isArray(raw)) return fallback;
  return raw
    .filter((v): v is string => typeof v === 'string')
    .map((v) => v.trim())
    .filter(Boolean)
    .slice(0, 40);
}

@Injectable()
export class StructureService {
  constructor(private readonly prisma: PrismaService) {}

  private mapUnique(e: unknown, label: string): never {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
      throw new ConflictException(`A ${label} with this slug already exists.`);
    }
    throw e;
  }

  /* —— Post types —— */

  private serializePostType(row: {
    id: string;
    slug: string;
    singular: string;
    plural: string;
    description: string;
    public: boolean;
    hierarchical: boolean;
    hasArchive: boolean;
    showInMenu: boolean;
    supports: unknown;
    active: boolean;
    menuOrder: number;
    createdAt: Date;
    updatedAt: Date;
  }) {
    return {
      id: row.id,
      slug: row.slug,
      singular: row.singular,
      plural: row.plural,
      description: row.description,
      public: row.public,
      hierarchical: row.hierarchical,
      hasArchive: row.hasArchive,
      showInMenu: row.showInMenu,
      supports: parseStringArray(row.supports, DEFAULT_SUPPORTS),
      active: row.active,
      menuOrder: row.menuOrder,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    };
  }

  async listPostTypes(actor: AuthUser) {
    const rows = await this.prisma.postType.findMany({
      where: { siteId: actor.siteId },
      orderBy: [{ menuOrder: 'asc' }, { createdAt: 'asc' }],
    });
    return { postTypes: rows.map((r) => this.serializePostType(r)) };
  }

  async createPostType(actor: AuthUser, dto: CreatePostTypeDto) {
    const maxOrder = await this.prisma.postType.aggregate({
      where: { siteId: actor.siteId },
      _max: { menuOrder: true },
    });
    try {
      const row = await this.prisma.postType.create({
        data: {
          siteId: actor.siteId,
          slug: dto.slug.trim().toLowerCase(),
          singular: dto.singular.trim(),
          plural: dto.plural.trim(),
          description: (dto.description ?? '').trim(),
          public: dto.public ?? true,
          hierarchical: dto.hierarchical ?? false,
          hasArchive: dto.hasArchive ?? true,
          showInMenu: dto.showInMenu ?? true,
          supports: parseStringArray(dto.supports, DEFAULT_SUPPORTS),
          active: dto.active ?? true,
          menuOrder: (maxOrder._max.menuOrder ?? -1) + 1,
        },
      });
      await this.audit(actor, 'post_type.created', { id: row.id, slug: row.slug });
      return this.serializePostType(row);
    } catch (e) {
      this.mapUnique(e, 'post type');
    }
  }

  async updatePostType(actor: AuthUser, id: string, dto: UpdatePostTypeDto) {
    const existing = await this.prisma.postType.findFirst({
      where: { id, siteId: actor.siteId },
    });
    if (!existing) throw new NotFoundException('Post type not found.');
    const data: Prisma.PostTypeUpdateInput = {};
    if (dto.slug !== undefined) data.slug = dto.slug.trim().toLowerCase();
    if (dto.singular !== undefined) data.singular = dto.singular.trim();
    if (dto.plural !== undefined) data.plural = dto.plural.trim();
    if (dto.description !== undefined) data.description = dto.description.trim();
    if (dto.public !== undefined) data.public = dto.public;
    if (dto.hierarchical !== undefined) data.hierarchical = dto.hierarchical;
    if (dto.hasArchive !== undefined) data.hasArchive = dto.hasArchive;
    if (dto.showInMenu !== undefined) data.showInMenu = dto.showInMenu;
    if (dto.supports !== undefined) data.supports = parseStringArray(dto.supports, DEFAULT_SUPPORTS);
    if (dto.active !== undefined) data.active = dto.active;
    try {
      const row = await this.prisma.postType.update({ where: { id: existing.id }, data });
      await this.audit(actor, 'post_type.updated', { id: row.id, slug: row.slug });
      return this.serializePostType(row);
    } catch (e) {
      this.mapUnique(e, 'post type');
    }
  }

  async removePostType(actor: AuthUser, id: string) {
    const existing = await this.prisma.postType.findFirst({
      where: { id, siteId: actor.siteId },
    });
    if (!existing) throw new NotFoundException('Post type not found.');
    await this.prisma.postType.delete({ where: { id: existing.id } });
    await this.audit(actor, 'post_type.deleted', { id: existing.id, slug: existing.slug });
    return { ok: true };
  }

  /* —— Taxonomies —— */

  private serializeTaxonomy(row: {
    id: string;
    slug: string;
    singular: string;
    plural: string;
    description: string;
    hierarchical: boolean;
    public: boolean;
    objectTypes: unknown;
    active: boolean;
    menuOrder: number;
    createdAt: Date;
    updatedAt: Date;
  }) {
    return {
      id: row.id,
      slug: row.slug,
      singular: row.singular,
      plural: row.plural,
      description: row.description,
      hierarchical: row.hierarchical,
      public: row.public,
      objectTypes: parseStringArray(row.objectTypes, ['post']),
      active: row.active,
      menuOrder: row.menuOrder,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    };
  }

  async listTaxonomies(actor: AuthUser) {
    const rows = await this.prisma.taxonomy.findMany({
      where: { siteId: actor.siteId },
      orderBy: [{ menuOrder: 'asc' }, { createdAt: 'asc' }],
    });
    return { taxonomies: rows.map((r) => this.serializeTaxonomy(r)) };
  }

  async createTaxonomy(actor: AuthUser, dto: CreateTaxonomyDto) {
    const maxOrder = await this.prisma.taxonomy.aggregate({
      where: { siteId: actor.siteId },
      _max: { menuOrder: true },
    });
    try {
      const row = await this.prisma.taxonomy.create({
        data: {
          siteId: actor.siteId,
          slug: dto.slug.trim().toLowerCase(),
          singular: dto.singular.trim(),
          plural: dto.plural.trim(),
          description: (dto.description ?? '').trim(),
          hierarchical: dto.hierarchical ?? true,
          public: dto.public ?? true,
          objectTypes: parseStringArray(dto.objectTypes, ['post']),
          active: dto.active ?? true,
          menuOrder: (maxOrder._max.menuOrder ?? -1) + 1,
        },
      });
      await this.audit(actor, 'taxonomy.created', { id: row.id, slug: row.slug });
      return this.serializeTaxonomy(row);
    } catch (e) {
      this.mapUnique(e, 'taxonomy');
    }
  }

  async updateTaxonomy(actor: AuthUser, id: string, dto: UpdateTaxonomyDto) {
    const existing = await this.prisma.taxonomy.findFirst({
      where: { id, siteId: actor.siteId },
    });
    if (!existing) throw new NotFoundException('Taxonomy not found.');
    const data: Prisma.TaxonomyUpdateInput = {};
    if (dto.slug !== undefined) data.slug = dto.slug.trim().toLowerCase();
    if (dto.singular !== undefined) data.singular = dto.singular.trim();
    if (dto.plural !== undefined) data.plural = dto.plural.trim();
    if (dto.description !== undefined) data.description = dto.description.trim();
    if (dto.hierarchical !== undefined) data.hierarchical = dto.hierarchical;
    if (dto.public !== undefined) data.public = dto.public;
    if (dto.objectTypes !== undefined) {
      data.objectTypes = parseStringArray(dto.objectTypes, ['post']);
    }
    if (dto.active !== undefined) data.active = dto.active;
    try {
      const row = await this.prisma.taxonomy.update({ where: { id: existing.id }, data });
      await this.audit(actor, 'taxonomy.updated', { id: row.id, slug: row.slug });
      return this.serializeTaxonomy(row);
    } catch (e) {
      this.mapUnique(e, 'taxonomy');
    }
  }

  async removeTaxonomy(actor: AuthUser, id: string) {
    const existing = await this.prisma.taxonomy.findFirst({
      where: { id, siteId: actor.siteId },
    });
    if (!existing) throw new NotFoundException('Taxonomy not found.');
    await this.prisma.taxonomy.delete({ where: { id: existing.id } });
    await this.audit(actor, 'taxonomy.deleted', { id: existing.id, slug: existing.slug });
    return { ok: true };
  }

  /* —— Options pages —— */

  private serializeOptionsPage(row: {
    id: string;
    title: string;
    slug: string;
    menuTitle: string;
    description: string;
    parentSlug: string;
    active: boolean;
    menuOrder: number;
    createdAt: Date;
    updatedAt: Date;
  }) {
    return {
      id: row.id,
      title: row.title,
      slug: row.slug,
      menuTitle: row.menuTitle || row.title,
      description: row.description,
      parentSlug: row.parentSlug,
      active: row.active,
      menuOrder: row.menuOrder,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    };
  }

  async listOptionsPages(actor: AuthUser) {
    const rows = await this.prisma.optionsPage.findMany({
      where: { siteId: actor.siteId },
      orderBy: [{ menuOrder: 'asc' }, { createdAt: 'asc' }],
    });
    return { optionsPages: rows.map((r) => this.serializeOptionsPage(r)) };
  }

  async createOptionsPage(actor: AuthUser, dto: CreateOptionsPageDto) {
    const maxOrder = await this.prisma.optionsPage.aggregate({
      where: { siteId: actor.siteId },
      _max: { menuOrder: true },
    });
    try {
      const row = await this.prisma.optionsPage.create({
        data: {
          siteId: actor.siteId,
          title: dto.title.trim(),
          slug: dto.slug.trim().toLowerCase(),
          menuTitle: (dto.menuTitle ?? dto.title).trim(),
          description: (dto.description ?? '').trim(),
          parentSlug: (dto.parentSlug ?? '').trim().toLowerCase(),
          active: dto.active ?? true,
          menuOrder: (maxOrder._max.menuOrder ?? -1) + 1,
        },
      });
      await this.audit(actor, 'options_page.created', { id: row.id, slug: row.slug });
      return this.serializeOptionsPage(row);
    } catch (e) {
      this.mapUnique(e, 'options page');
    }
  }

  async updateOptionsPage(actor: AuthUser, id: string, dto: UpdateOptionsPageDto) {
    const existing = await this.prisma.optionsPage.findFirst({
      where: { id, siteId: actor.siteId },
    });
    if (!existing) throw new NotFoundException('Options page not found.');
    const data: Prisma.OptionsPageUpdateInput = {};
    if (dto.title !== undefined) data.title = dto.title.trim();
    if (dto.slug !== undefined) data.slug = dto.slug.trim().toLowerCase();
    if (dto.menuTitle !== undefined) data.menuTitle = dto.menuTitle.trim();
    if (dto.description !== undefined) data.description = dto.description.trim();
    if (dto.parentSlug !== undefined) data.parentSlug = dto.parentSlug.trim().toLowerCase();
    if (dto.active !== undefined) data.active = dto.active;
    try {
      const row = await this.prisma.optionsPage.update({ where: { id: existing.id }, data });
      await this.audit(actor, 'options_page.updated', { id: row.id, slug: row.slug });
      return this.serializeOptionsPage(row);
    } catch (e) {
      this.mapUnique(e, 'options page');
    }
  }

  async removeOptionsPage(actor: AuthUser, id: string) {
    const existing = await this.prisma.optionsPage.findFirst({
      where: { id, siteId: actor.siteId },
    });
    if (!existing) throw new NotFoundException('Options page not found.');
    await this.prisma.optionsPage.delete({ where: { id: existing.id } });
    await this.audit(actor, 'options_page.deleted', { id: existing.id, slug: existing.slug });
    return { ok: true };
  }

  /* —— Settings (stored in site options) —— */

  async getSettings(actor: AuthUser) {
    const site = await this.prisma.site.findFirst({
      where: { id: actor.siteId },
      include: { settings: true },
    });
    const opts = readOptions(site?.settings?.options);
    const fields = (opts.backendFields as Record<string, unknown> | undefined) ?? {};
    return {
      showAdminBar: fields.showAdminBar !== false,
      exportFormat: fields.exportFormat === 'php' ? 'php' : 'json',
      deleteWithContent: Boolean(fields.deleteWithContent),
    };
  }

  async updateSettings(actor: AuthUser, dto: FieldsSettingsDto) {
    const site = await this.prisma.site.findFirst({
      where: { id: actor.siteId },
      include: { settings: true },
    });
    if (!site?.settings) throw new NotFoundException('Site settings not found.');
    const current = readOptions(site.settings.options);
    const prev = (current.backendFields as Record<string, unknown> | undefined) ?? {};
    const next = {
      ...prev,
      ...(dto.showAdminBar !== undefined ? { showAdminBar: dto.showAdminBar } : {}),
      ...(dto.exportFormat !== undefined ? { exportFormat: dto.exportFormat } : {}),
      ...(dto.deleteWithContent !== undefined
        ? { deleteWithContent: dto.deleteWithContent }
        : {}),
    };
    const options = mergeSiteOptions(site.settings.options, { backendFields: next });
    await this.prisma.siteSettings.update({
      where: { id: site.settings.id },
      data: { options },
    });
    return this.getSettings(actor);
  }

  private async audit(actor: AuthUser, action: string, meta: Record<string, unknown>) {
    await this.prisma.auditLog.create({
      data: {
        siteId: actor.siteId,
        userId: actor.id,
        action,
        meta: meta as Prisma.InputJsonValue,
      },
    });
  }
}
