import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  ArrayUnique,
  IsArray,
  IsBoolean,
  IsIn,
  IsOptional,
  IsString,
  Matches,
  MaxLength,
  MinLength,
} from 'class-validator';

const SLUG = /^[a-z][a-z0-9_-]*$/;

export class CreatePostTypeDto {
  @ApiProperty({ example: 'product' })
  @IsString()
  @MinLength(1)
  @MaxLength(40)
  @Matches(SLUG, { message: 'Slug must start with a letter and use a-z, 0-9, _, -' })
  slug!: string;

  @ApiProperty({ example: 'Product' })
  @IsString()
  @MinLength(1)
  @MaxLength(80)
  singular!: string;

  @ApiProperty({ example: 'Products' })
  @IsString()
  @MinLength(1)
  @MaxLength(80)
  plural!: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(500)
  description?: string;

  @ApiPropertyOptional({ default: true })
  @IsOptional()
  @IsBoolean()
  public?: boolean;

  @ApiPropertyOptional({ default: false })
  @IsOptional()
  @IsBoolean()
  hierarchical?: boolean;

  @ApiPropertyOptional({ default: true })
  @IsOptional()
  @IsBoolean()
  hasArchive?: boolean;

  @ApiPropertyOptional({ default: true })
  @IsOptional()
  @IsBoolean()
  showInMenu?: boolean;

  @ApiPropertyOptional({ type: [String] })
  @IsOptional()
  @IsArray()
  @ArrayUnique()
  @IsString({ each: true })
  supports?: string[];

  @ApiPropertyOptional({ default: true })
  @IsOptional()
  @IsBoolean()
  active?: boolean;
}

export class UpdatePostTypeDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(40)
  @Matches(SLUG)
  slug?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(80)
  singular?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(80)
  plural?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(500)
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  public?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  hierarchical?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  hasArchive?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  showInMenu?: boolean;

  @ApiPropertyOptional({ type: [String] })
  @IsOptional()
  @IsArray()
  @ArrayUnique()
  @IsString({ each: true })
  supports?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  active?: boolean;
}

export class CreateTaxonomyDto {
  @ApiProperty({ example: 'brand' })
  @IsString()
  @MinLength(1)
  @MaxLength(40)
  @Matches(SLUG)
  slug!: string;

  @ApiProperty({ example: 'Brand' })
  @IsString()
  @MinLength(1)
  @MaxLength(80)
  singular!: string;

  @ApiProperty({ example: 'Brands' })
  @IsString()
  @MinLength(1)
  @MaxLength(80)
  plural!: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(500)
  description?: string;

  @ApiPropertyOptional({ default: true })
  @IsOptional()
  @IsBoolean()
  hierarchical?: boolean;

  @ApiPropertyOptional({ default: true })
  @IsOptional()
  @IsBoolean()
  public?: boolean;

  @ApiPropertyOptional({ type: [String], example: ['post', 'product'] })
  @IsOptional()
  @IsArray()
  @ArrayUnique()
  @IsString({ each: true })
  objectTypes?: string[];

  @ApiPropertyOptional({ default: true })
  @IsOptional()
  @IsBoolean()
  active?: boolean;
}

export class UpdateTaxonomyDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(40)
  @Matches(SLUG)
  slug?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(80)
  singular?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(80)
  plural?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(500)
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  hierarchical?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  public?: boolean;

  @ApiPropertyOptional({ type: [String] })
  @IsOptional()
  @IsArray()
  @ArrayUnique()
  @IsString({ each: true })
  objectTypes?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  active?: boolean;
}

export class CreateOptionsPageDto {
  @ApiProperty({ example: 'Site options' })
  @IsString()
  @MinLength(1)
  @MaxLength(120)
  title!: string;

  @ApiProperty({ example: 'site-options' })
  @IsString()
  @MinLength(1)
  @MaxLength(60)
  @Matches(SLUG)
  slug!: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(80)
  menuTitle?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(500)
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(60)
  parentSlug?: string;

  @ApiPropertyOptional({ default: true })
  @IsOptional()
  @IsBoolean()
  active?: boolean;
}

export class UpdateOptionsPageDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(120)
  title?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(60)
  @Matches(SLUG)
  slug?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(80)
  menuTitle?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(500)
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(60)
  parentSlug?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  active?: boolean;
}

export class FieldsSettingsDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  showAdminBar?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsIn(['php', 'json'])
  exportFormat?: 'php' | 'json';

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  deleteWithContent?: boolean;
}
