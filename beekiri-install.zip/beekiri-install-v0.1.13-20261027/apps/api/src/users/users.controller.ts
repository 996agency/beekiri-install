import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { AuthGuard, type AuthedRequest } from '../auth/auth.guard';
import { CapabilitiesGuard } from '../auth/capabilities.guard';
import { RequireCapabilities } from '../auth/capabilities.decorator';
import { CreateUserDto, UpdateUserDto } from './users.dto';
import { UsersService } from './users.service';

@ApiTags('users')
@Controller('users')
@UseGuards(AuthGuard, CapabilitiesGuard)
export class UsersController {
  constructor(private readonly users: UsersService) {}

  @Get('roles')
  @RequireCapabilities('list_users')
  roles() {
    return { roles: this.users.roles() };
  }

  @Get()
  @RequireCapabilities('list_users')
  list(@Req() req: AuthedRequest) {
    return this.users.list(req.auth!.user);
  }

  @Get(':id')
  @RequireCapabilities('list_users')
  get(@Req() req: AuthedRequest, @Param('id') id: string) {
    return this.users.get(req.auth!.user, id);
  }

  @Post()
  @RequireCapabilities('create_users')
  create(@Req() req: AuthedRequest, @Body() body: CreateUserDto) {
    return this.users.create(req.auth!.user, body);
  }

  @Patch(':id')
  @RequireCapabilities('edit_users')
  update(
    @Req() req: AuthedRequest,
    @Param('id') id: string,
    @Body() body: UpdateUserDto,
  ) {
    return this.users.update(req.auth!.user, id, body);
  }

  @Delete(':id')
  @RequireCapabilities('delete_users')
  remove(@Req() req: AuthedRequest, @Param('id') id: string) {
    return this.users.remove(req.auth!.user, id);
  }
}
