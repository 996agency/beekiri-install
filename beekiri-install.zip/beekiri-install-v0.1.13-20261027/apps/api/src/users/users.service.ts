import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import type { RoleSlug } from '../cms-types';
import { PrismaService } from '../prisma/prisma.service';
import { hashPassword } from '../common/crypto.util';
import type { AuthUser } from '../auth/auth.types';
import type { CreateUserDto, UpdateUserDto } from './users.dto';
import { normalizeProfileInput, parseProfile } from './users.profile';

const ROLE_LABELS: Record<RoleSlug, string> = {
  administrator: 'Administrator',
  editor: 'Editor',
  author: 'Author',
  contributor: 'Contributor',
  subscriber: 'Subscriber',
};

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  private serialize(user: {
    id: string;
    username: string;
    email: string;
    displayName: string;
    isOwner: boolean;
    profile?: unknown;
    createdAt: Date;
    updatedAt: Date;
    role: { slug: string; name: string };
  }) {
    const role = user.role.slug as RoleSlug;
    const profile = parseProfile(user.profile);
    return {
      id: user.id,
      username: user.username,
      email: user.email,
      displayName: user.displayName,
      role,
      roleLabel: ROLE_LABELS[role] ?? user.role.name,
      isOwner: user.isOwner,
      jobDescription: profile.jobDescription,
      customFields: profile.customFields,
      createdAt: user.createdAt.toISOString(),
      updatedAt: user.updatedAt.toISOString(),
    };
  }

  roles() {
    return (Object.keys(ROLE_LABELS) as RoleSlug[]).map((slug) => ({
      slug,
      label: ROLE_LABELS[slug],
    }));
  }

  async list(actor: AuthUser) {
    const users = await this.prisma.user.findMany({
      where: { siteId: actor.siteId },
      include: { role: true },
      orderBy: [{ isOwner: 'desc' }, { username: 'asc' }],
    });
    return { users: users.map((u) => this.serialize(u)) };
  }

  async get(actor: AuthUser, id: string) {
    const user = await this.prisma.user.findFirst({
      where: { id, siteId: actor.siteId },
      include: { role: true },
    });
    if (!user) throw new NotFoundException('User not found.');
    return this.serialize(user);
  }

  private async countAdministrators(siteId: string, excludeUserId?: string) {
    return this.prisma.user.count({
      where: {
        siteId,
        role: { slug: 'administrator' },
        ...(excludeUserId ? { id: { not: excludeUserId } } : {}),
      },
    });
  }

  private async resolveRoleId(slug: RoleSlug) {
    const role = await this.prisma.role.findUnique({ where: { slug } });
    if (!role) {
      throw new BadRequestException(`Unknown role “${slug}”.`);
    }
    return role.id;
  }

  private mapUniqueError(e: unknown): never {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
      const target = Array.isArray(e.meta?.target) ? e.meta.target.join(',') : String(e.meta?.target ?? '');
      if (target.includes('email')) {
        throw new ConflictException('That email is already registered on this site.');
      }
      if (target.includes('username')) {
        throw new ConflictException('That username is already taken on this site.');
      }
      throw new ConflictException('Username or email is already in use on this site.');
    }
    throw e;
  }

  async create(actor: AuthUser, dto: CreateUserDto) {
    const roleSlug = dto.role as RoleSlug;
    const roleId = await this.resolveRoleId(roleSlug);
    const passwordHash = await hashPassword(dto.password);
    const displayName = dto.displayName?.trim() || dto.username;
    const profile = normalizeProfileInput({
      jobDescription: dto.jobDescription,
      customFields: dto.customFields,
    });

    try {
      const user = await this.prisma.user.create({
        data: {
          siteId: actor.siteId,
          username: dto.username.trim(),
          email: dto.email.trim().toLowerCase(),
          displayName,
          passwordHash,
          roleId,
          isOwner: false,
          profile,
        },
        include: { role: true },
      });

      await this.prisma.auditLog.create({
        data: {
          siteId: actor.siteId,
          userId: actor.id,
          action: 'user.created',
          meta: { targetUserId: user.id, username: user.username, role: roleSlug },
        },
      });

      return this.serialize(user);
    } catch (e) {
      this.mapUniqueError(e);
    }
  }

  async update(actor: AuthUser, id: string, dto: UpdateUserDto) {
    const existing = await this.prisma.user.findFirst({
      where: { id, siteId: actor.siteId },
      include: { role: true },
    });
    if (!existing) throw new NotFoundException('User not found.');

    if (existing.isOwner && dto.role && dto.role !== 'administrator') {
      throw new ForbiddenException('The site owner must remain an administrator.');
    }

    const nextRole = (
      existing.isOwner ? 'administrator' : (dto.role ?? existing.role.slug)
    ) as RoleSlug;
    const wasAdmin = existing.role.slug === 'administrator';
    const willBeAdmin = nextRole === 'administrator';

    if (wasAdmin && !willBeAdmin) {
      const remaining = await this.countAdministrators(actor.siteId, existing.id);
      if (remaining < 1) {
        throw new BadRequestException(
          'You cannot remove the last administrator. Promote another user first.',
        );
      }
      if (existing.id === actor.id) {
        throw new ForbiddenException('You cannot demote your own administrator account.');
      }
    }

    const data: Prisma.UserUpdateInput = {};
    if (dto.username !== undefined) data.username = dto.username.trim();
    if (dto.email !== undefined) data.email = dto.email.trim().toLowerCase();
    if (dto.displayName !== undefined) data.displayName = dto.displayName.trim();
    if (dto.role !== undefined) {
      const roleId = await this.resolveRoleId(nextRole);
      data.role = { connect: { id: roleId } };
    }
    if (dto.jobDescription !== undefined || dto.customFields !== undefined) {
      const current = parseProfile(existing.profile);
      data.profile = normalizeProfileInput({
        jobDescription:
          dto.jobDescription !== undefined ? dto.jobDescription : current.jobDescription,
        customFields:
          dto.customFields !== undefined ? dto.customFields : current.customFields,
      });
    }

    let passwordChanged = false;
    if (dto.password && dto.password.length > 0) {
      data.passwordHash = await hashPassword(dto.password);
      passwordChanged = true;
    }

    try {
      const user = await this.prisma.user.update({
        where: { id: existing.id },
        data,
        include: { role: true },
      });

      if (passwordChanged) {
        await this.prisma.session.deleteMany({ where: { userId: user.id } });
      }

      await this.prisma.auditLog.create({
        data: {
          siteId: actor.siteId,
          userId: actor.id,
          action: 'user.updated',
          meta: {
            targetUserId: user.id,
            passwordChanged,
            role: user.role.slug,
          },
        },
      });

      return this.serialize(user);
    } catch (e) {
      this.mapUniqueError(e);
    }
  }

  async remove(actor: AuthUser, id: string) {
    if (actor.id === id) {
      throw new ForbiddenException('You cannot delete your own account.');
    }

    const existing = await this.prisma.user.findFirst({
      where: { id, siteId: actor.siteId },
      include: { role: true },
    });
    if (!existing) throw new NotFoundException('User not found.');

    if (existing.isOwner) {
      throw new ForbiddenException('The site owner account cannot be deleted.');
    }

    if (existing.role.slug === 'administrator') {
      const remaining = await this.countAdministrators(actor.siteId, existing.id);
      if (remaining < 1) {
        throw new BadRequestException(
          'You cannot delete the last administrator. Promote another user first.',
        );
      }
    }

    await this.prisma.session.deleteMany({ where: { userId: existing.id } });
    await this.prisma.user.delete({ where: { id: existing.id } });

    await this.prisma.auditLog.create({
      data: {
        siteId: actor.siteId,
        userId: actor.id,
        action: 'user.deleted',
        meta: { targetUserId: existing.id, username: existing.username },
      },
    });

    return { ok: true };
  }
}
