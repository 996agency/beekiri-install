export type UserCustomField = {
  id: string;
  label: string;
  value: string;
};

export type UserProfile = {
  jobDescription: string;
  customFields: UserCustomField[];
};

export function emptyProfile(): UserProfile {
  return { jobDescription: '', customFields: [] };
}

export function parseProfile(raw: unknown): UserProfile {
  if (!raw || typeof raw !== 'object') return emptyProfile();
  const o = raw as Record<string, unknown>;
  const jobDescription = typeof o.jobDescription === 'string' ? o.jobDescription : '';
  const customFields: UserCustomField[] = [];
  if (Array.isArray(o.customFields)) {
    for (const row of o.customFields) {
      if (!row || typeof row !== 'object') continue;
      const r = row as Record<string, unknown>;
      const id = typeof r.id === 'string' ? r.id : '';
      const label = typeof r.label === 'string' ? r.label.trim() : '';
      const value = typeof r.value === 'string' ? r.value : '';
      if (!id || !label) continue;
      customFields.push({
        id,
        label: label.slice(0, 80),
        value: value.slice(0, 500),
      });
    }
  }
  return {
    jobDescription: jobDescription.slice(0, 2000),
    customFields: customFields.slice(0, 20),
  };
}

export function normalizeProfileInput(input: {
  jobDescription?: string;
  customFields?: { id?: string; label?: string; value?: string }[];
}): UserProfile {
  const customFields: UserCustomField[] = [];
  for (const row of input.customFields ?? []) {
    const label = (row.label ?? '').trim();
    if (!label) continue;
    customFields.push({
      id: (row.id ?? '').trim() || `cf-${Math.random().toString(36).slice(2, 9)}`,
      label: label.slice(0, 80),
      value: (row.value ?? '').slice(0, 500),
    });
  }
  return {
    jobDescription: (input.jobDescription ?? '').trim().slice(0, 2000),
    customFields: customFields.slice(0, 20),
  };
}
