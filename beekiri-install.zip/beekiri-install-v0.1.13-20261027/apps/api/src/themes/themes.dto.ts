import { IsString, MinLength } from 'class-validator';

export class ThemeSlugDto {
  @IsString()
  @MinLength(1)
  slug!: string;
}
