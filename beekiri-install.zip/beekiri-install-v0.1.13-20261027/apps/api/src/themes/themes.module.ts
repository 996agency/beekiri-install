import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { ThemesController } from './themes.controller';
import { ThemesService } from './themes.service';
import { ThemeChromeService } from './theme-chrome.service';

@Module({
  imports: [AuthModule],
  controllers: [ThemesController],
  providers: [ThemesService, ThemeChromeService],
  exports: [ThemesService, ThemeChromeService],
})
export class ThemesModule {}
