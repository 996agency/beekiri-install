import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import AdmZip from 'adm-zip';
import { existsSync, mkdirSync, rmSync, writeFileSync } from 'fs';
import { basename, dirname, join, relative, sep } from 'path';
import { PrismaService } from '../prisma/prisma.service';
import { mergeSiteOptions, readOptions } from '../site/site-options';
import {
  BUILTIN_THEME_SLUGS,
  DEFAULT_THEME_SLUG,
  getThemeManifest,
  listThemeManifests,
  resolveThemeDir,
  resolveThemeFile,
  resolveThemesRoot,
  sanitizeThemeSlug,
  type ThemeManifest,
} from './theme-registry';

export type ThemeListItem = ThemeManifest & {
  active: boolean;
  deletable: boolean;
  screenshotUrl: string;
};

@Injectable()
export class ThemesService {
  constructor(private readonly prisma: PrismaService) {}

  private async getSite() {
    const site = await this.prisma.site.findFirst({
      include: { settings: true },
      orderBy: { createdAt: 'asc' },
    });
    if (!site) throw new NotFoundException('Site not found');
    return site;
  }

  private async setActiveSlug(slug: string) {
    const site = await this.getSite();
    const nextOptions = mergeSiteOptions(site.settings?.options, {
      activeTheme: slug,
    });

    await this.prisma.site.update({
      where: { id: site.id },
      data: {
        settings: {
          upsert: {
            create: {
              options: nextOptions as Prisma.InputJsonValue,
            },
            update: {
              options: nextOptions as Prisma.InputJsonValue,
            },
          },
        },
      },
    });
  }

  async getActiveSlug(): Promise<string> {
    const site = await this.prisma.site.findFirst({
      include: { settings: true },
      orderBy: { createdAt: 'asc' },
    });
    if (!site) return DEFAULT_THEME_SLUG;
    const opts = readOptions(site.settings?.options);
    const slug = (opts.activeTheme ?? '').trim() || DEFAULT_THEME_SLUG;
    return getThemeManifest(slug) ? slug : DEFAULT_THEME_SLUG;
  }

  async list(): Promise<{ themes: ThemeListItem[]; active: string }> {
    const active = await this.getActiveSlug();
    const themes = listThemeManifests().map((theme) => ({
      ...theme,
      active: theme.slug === active,
      deletable: !theme.builtin,
      screenshotUrl: `/api/themes/${encodeURIComponent(theme.slug)}/screenshot`,
    }));
    return { themes, active };
  }

  async activate(slug: string): Promise<{ themes: ThemeListItem[]; active: string }> {
    const theme = getThemeManifest(slug);
    if (!theme) throw new BadRequestException('Theme not found.');
    await this.setActiveSlug(theme.slug);
    return this.list();
  }

  /** Deactivate current theme → fall back to the Beekiri starter. */
  async deactivate(slug: string): Promise<{ themes: ThemeListItem[]; active: string }> {
    const theme = getThemeManifest(slug);
    if (!theme) throw new BadRequestException('Theme not found.');

    const active = await this.getActiveSlug();
    if (theme.slug !== active) {
      throw new BadRequestException('Only the active theme can be deactivated.');
    }
    if (theme.slug === DEFAULT_THEME_SLUG) {
      throw new BadRequestException('The Beekiri starter theme stays available as the default.');
    }

    await this.setActiveSlug(DEFAULT_THEME_SLUG);
    return this.list();
  }

  async remove(slug: string): Promise<{ themes: ThemeListItem[]; active: string }> {
    const theme = getThemeManifest(slug);
    if (!theme) throw new BadRequestException('Theme not found.');
    if (theme.builtin || BUILTIN_THEME_SLUGS.has(theme.slug)) {
      throw new BadRequestException('Built-in themes cannot be deleted.');
    }

    const dir = resolveThemeDir(theme.slug);
    if (!dir) throw new BadRequestException('Theme files were not found on disk.');

    const active = await this.getActiveSlug();
    if (active === theme.slug) {
      await this.setActiveSlug(DEFAULT_THEME_SLUG);
    }

    rmSync(dir, { recursive: true, force: true });
    return this.list();
  }

  async uploadZip(
    buffer: Buffer,
    originalName: string,
  ): Promise<{ themes: ThemeListItem[]; active: string; installed: string }> {
    if (!buffer?.length) throw new BadRequestException('Empty upload.');
    if (!/\.zip$/i.test(originalName || '')) {
      throw new BadRequestException('Upload a .zip theme package.');
    }

    let zip: AdmZip;
    try {
      zip = new AdmZip(buffer);
    } catch {
      throw new BadRequestException('Could not read that ZIP file.');
    }

    const entries = zip.getEntries().filter((e) => !e.isDirectory);
    if (!entries.length) throw new BadRequestException('ZIP is empty.');

    const manifestEntry =
      entries.find((e) => /(^|\/)theme\.json$/i.test(e.entryName.replace(/\\/g, '/'))) ?? null;
    if (!manifestEntry) {
      throw new BadRequestException('theme.json is required inside the ZIP.');
    }

    let manifestRaw: Partial<ThemeManifest>;
    try {
      manifestRaw = JSON.parse(manifestEntry.getData().toString('utf8')) as Partial<ThemeManifest>;
    } catch {
      throw new BadRequestException('theme.json is not valid JSON.');
    }

    const folderHint = dirname(manifestEntry.entryName.replace(/\\/g, '/'));
    const fromName = basename(originalName, '.zip');
    const slug = sanitizeThemeSlug(
      (typeof manifestRaw.slug === 'string' && manifestRaw.slug) ||
        (folderHint && folderHint !== '.' ? basename(folderHint) : fromName),
    );
    if (!slug) throw new BadRequestException('Could not determine a theme slug.');
    if (BUILTIN_THEME_SLUGS.has(slug)) {
      throw new BadRequestException('That slug is reserved for a built-in theme.');
    }

    const name = typeof manifestRaw.name === 'string' ? manifestRaw.name.trim() : '';
    if (!name) throw new BadRequestException('theme.json must include a name.');

    const root = resolveThemesRoot();
    mkdirSync(root, { recursive: true });
    const target = join(root, slug);
    if (existsSync(target)) {
      rmSync(target, { recursive: true, force: true });
    }
    mkdirSync(target, { recursive: true });

    const prefix = folderHint === '.' ? '' : `${folderHint}/`;
    for (const entry of entries) {
      const normalized = entry.entryName.replace(/\\/g, '/');
      if (normalized.includes('..')) continue;
      if (prefix && !normalized.startsWith(prefix)) continue;
      const rel = prefix ? normalized.slice(prefix.length) : normalized;
      if (!rel || rel.endsWith('/')) continue;
      const dest = join(target, rel);
      const relCheck = relative(target, dest);
      if (relCheck.startsWith('..') || relCheck.includes(`..${sep}`)) continue;
      mkdirSync(dirname(dest), { recursive: true });
      writeFileSync(dest, entry.getData());
    }

    // Ensure theme.json slug matches folder
    const ensured = {
      ...manifestRaw,
      slug,
      name,
    };
    writeFileSync(join(target, 'theme.json'), `${JSON.stringify(ensured, null, 2)}\n`, 'utf8');

    if (!getThemeManifest(slug)) {
      rmSync(target, { recursive: true, force: true });
      throw new BadRequestException('Theme installed but could not be read. Check theme.json.');
    }

    const listed = await this.list();
    return { ...listed, installed: slug };
  }

  resolveScreenshotPath(slug: string): string | null {
    const theme = getThemeManifest(slug);
    if (!theme) return null;
    const file = theme.screenshot || 'screenshot.svg';
    return resolveThemeFile(theme.slug, file);
  }
}
