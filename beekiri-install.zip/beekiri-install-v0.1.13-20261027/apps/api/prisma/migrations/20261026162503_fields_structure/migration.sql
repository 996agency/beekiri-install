-- CreateTable
CREATE TABLE "PostType" (
    "id" TEXT NOT NULL,
    "siteId" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "singular" TEXT NOT NULL,
    "plural" TEXT NOT NULL,
    "description" TEXT NOT NULL DEFAULT '',
    "public" BOOLEAN NOT NULL DEFAULT true,
    "hierarchical" BOOLEAN NOT NULL DEFAULT false,
    "hasArchive" BOOLEAN NOT NULL DEFAULT true,
    "showInMenu" BOOLEAN NOT NULL DEFAULT true,
    "supports" JSONB NOT NULL DEFAULT '["title","editor"]',
    "active" BOOLEAN NOT NULL DEFAULT true,
    "menuOrder" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PostType_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Taxonomy" (
    "id" TEXT NOT NULL,
    "siteId" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "singular" TEXT NOT NULL,
    "plural" TEXT NOT NULL,
    "description" TEXT NOT NULL DEFAULT '',
    "hierarchical" BOOLEAN NOT NULL DEFAULT true,
    "public" BOOLEAN NOT NULL DEFAULT true,
    "objectTypes" JSONB NOT NULL DEFAULT '["post"]',
    "active" BOOLEAN NOT NULL DEFAULT true,
    "menuOrder" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Taxonomy_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "OptionsPage" (
    "id" TEXT NOT NULL,
    "siteId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "menuTitle" TEXT NOT NULL DEFAULT '',
    "description" TEXT NOT NULL DEFAULT '',
    "parentSlug" TEXT NOT NULL DEFAULT '',
    "active" BOOLEAN NOT NULL DEFAULT true,
    "menuOrder" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "OptionsPage_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "PostType_siteId_idx" ON "PostType"("siteId");

-- CreateIndex
CREATE UNIQUE INDEX "PostType_siteId_slug_key" ON "PostType"("siteId", "slug");

-- CreateIndex
CREATE INDEX "Taxonomy_siteId_idx" ON "Taxonomy"("siteId");

-- CreateIndex
CREATE UNIQUE INDEX "Taxonomy_siteId_slug_key" ON "Taxonomy"("siteId", "slug");

-- CreateIndex
CREATE INDEX "OptionsPage_siteId_idx" ON "OptionsPage"("siteId");

-- CreateIndex
CREATE UNIQUE INDEX "OptionsPage_siteId_slug_key" ON "OptionsPage"("siteId", "slug");

-- AddForeignKey
ALTER TABLE "PostType" ADD CONSTRAINT "PostType_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES "Site"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Taxonomy" ADD CONSTRAINT "Taxonomy_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES "Site"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "OptionsPage" ADD CONSTRAINT "OptionsPage_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES "Site"("id") ON DELETE CASCADE ON UPDATE CASCADE;
