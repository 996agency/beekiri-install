-- CreateTable
CREATE TABLE "Post" (
    "id" TEXT NOT NULL,
    "siteId" TEXT NOT NULL,
    "type" TEXT NOT NULL DEFAULT 'page',
    "title" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'draft',
    "content" JSONB NOT NULL DEFAULT '{"version":1,"html":""}',
    "excerpt" TEXT NOT NULL DEFAULT '',
    "authorId" TEXT,
    "parentId" TEXT,
    "menuOrder" INTEGER NOT NULL DEFAULT 0,
    "publishedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Post_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Post_siteId_type_status_idx" ON "Post"("siteId", "type", "status");

-- CreateIndex
CREATE INDEX "Post_siteId_type_updatedAt_idx" ON "Post"("siteId", "type", "updatedAt");

-- CreateIndex
CREATE UNIQUE INDEX "Post_siteId_type_slug_key" ON "Post"("siteId", "type", "slug");

-- AddForeignKey
ALTER TABLE "Post" ADD CONSTRAINT "Post_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES "Site"("id") ON DELETE CASCADE ON UPDATE CASCADE;
