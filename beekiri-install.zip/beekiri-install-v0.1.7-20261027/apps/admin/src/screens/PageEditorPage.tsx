import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { emptyBeekiricanvaData } from '@beekiri/page-blocks';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { SuccessNotice } from '../components/SuccessNotice';
import { PageEditorChromeProvider } from '../editor/PageEditorChrome';
import { PageSettingsModal } from '../editor/PageSettingsModal';
import { BeekiriCodeCanvas } from '../editor/beekiricode/BeekiriCodeCanvas';
import {
  emptyBeekiriCodeDoc,
  parseBeekiriCodeDoc,
  renderBeekiriCodeHtml,
  type BeekiriCodePageDoc,
} from '../editor/beekiricode/document';
import type { PageRow } from './PagesPage';

const LIVE_SITE = import.meta.env.VITE_APP_URL ?? 'http://127.0.0.1:8789';

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

function toSlug(v: string) {
  return v
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 180);
}

/** Prefer beekiricode; fall back to legacy instatic key. */
function docFromPage(row: PageRow): BeekiriCodePageDoc {
  return parseBeekiriCodeDoc(row.beekiricode ?? row.instatic);
}

type SavedSnapshot = {
  title: string;
  slug: string;
  excerpt: string;
  status: string;
  beekiricodeJson: string;
};

function snapshotFrom(
  title: string,
  slug: string,
  excerpt: string,
  status: string,
  doc: BeekiriCodePageDoc,
): SavedSnapshot {
  return {
    title,
    slug,
    excerpt,
    status,
    beekiricodeJson: JSON.stringify(doc),
  };
}

export function PageEditorPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const auth = useAuth();
  const canEdit = auth.user?.capabilities.includes('edit_pages') ?? false;
  const canPublish = auth.user?.capabilities.includes('publish_pages') ?? false;
  const canDelete = auth.user?.capabilities.includes('delete_pages') ?? false;

  const [page, setPage] = useState<PageRow | null>(null);
  const [title, setTitle] = useState('');
  const [slug, setSlug] = useState('');
  const [slugEditing, setSlugEditing] = useState(false);
  const [slugTouched, setSlugTouched] = useState(false);
  const [status, setStatus] = useState<'auto-draft' | 'draft' | 'publish'>('draft');
  const [excerpt, setExcerpt] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [beekiricodeData, setBeekiricodeData] = useState<BeekiriCodePageDoc>(() =>
    emptyBeekiriCodeDoc(),
  );
  const [canvasKey, setCanvasKey] = useState(0);
  const beekiricodeRef = useRef<BeekiriCodePageDoc>(emptyBeekiriCodeDoc());
  const savedRef = useRef<SavedSnapshot | null>(null);

  const applySaved = useCallback((row: PageRow, doc: BeekiriCodePageDoc) => {
    setPage(row);
    setTitle(row.title);
    setSlug(row.slug);
    setStatus(row.status === 'auto-draft' ? 'draft' : row.status);
    setExcerpt(row.excerpt);
    beekiricodeRef.current = doc;
    setBeekiricodeData(doc);
    savedRef.current = snapshotFrom(
      row.title,
      row.slug,
      row.excerpt,
      row.status === 'auto-draft' ? 'draft' : row.status,
      doc,
    );
  }, []);

  const load = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setError(null);
    try {
      const row = await api<PageRow>(`/api/pages/${id}`);
      applySaved(row, docFromPage(row));
      setSlugTouched(!row.slug.startsWith('auto-draft-'));
    } catch (e) {
      setError(formatError(e));
      setPage(null);
    } finally {
      setLoading(false);
    }
  }, [id, applySaved]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (!fullscreen && !settingsOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      if (settingsOpen) setSettingsOpen(false);
      else if (fullscreen) setFullscreen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [fullscreen, settingsOpen]);

  const onTitleChange = (value: string) => {
    setTitle(value);
    if (!slugTouched || slug.startsWith('auto-draft-')) {
      const next = toSlug(value);
      if (next) setSlug(next);
    }
  };

  const onBeekiriCodeChange = useCallback((data: BeekiriCodePageDoc) => {
    beekiricodeRef.current = data;
    setBeekiricodeData(data);
  }, []);

  const isDirty = useMemo(() => {
    const saved = savedRef.current;
    if (!saved) return false;
    return (
      title !== saved.title ||
      slug !== saved.slug ||
      excerpt !== saved.excerpt ||
      status !== saved.status ||
      JSON.stringify(beekiricodeData) !== saved.beekiricodeJson
    );
  }, [title, slug, excerpt, status, beekiricodeData]);

  const save = async (nextStatus?: 'draft' | 'publish') => {
    if (!id || !canEdit || busy) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const resolvedStatus = nextStatus ?? (status === 'publish' ? 'publish' : 'draft');
      if (resolvedStatus === 'publish' && !canPublish) {
        setError('You do not have permission to publish pages.');
        setBusy(false);
        return;
      }
      const updated = await api<PageRow>(`/api/pages/${id}`, {
        method: 'PATCH',
        json: {
          title,
          slug: slug || toSlug(title) || undefined,
          status: resolvedStatus,
          excerpt,
          beekiricode: beekiricodeRef.current,
          content: renderBeekiriCodeHtml(beekiricodeRef.current),
        },
      });
      applySaved(updated, docFromPage(updated));
      setSlugTouched(true);
      setSlugEditing(false);
      setNotice(
        resolvedStatus === 'publish' ? 'Page published.' : 'Page saved as draft.',
      );
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const previewChanges = async () => {
    if (!id || !canEdit || busy || !isDirty) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const result = await api<{
        page: PageRow;
        previewPath: string;
      }>(`/api/pages/${id}/preview`, {
        method: 'POST',
        json: {
          title,
          slug: slug || toSlug(title) || undefined,
          excerpt,
          beekiricode: beekiricodeRef.current,
        },
      });

      if (result.page.status !== 'publish') {
        applySaved(result.page, docFromPage(result.page));
        setSlugTouched(true);
        setSlugEditing(false);
      } else {
        setPage(result.page);
      }

      const href = `${LIVE_SITE.replace(/\/$/, '')}${result.previewPath}`;
      window.open(href, '_blank', 'noopener,noreferrer');
    } catch (e) {
      setError(formatError(e));
    } finally {
      setBusy(false);
    }
  };

  const onDelete = async () => {
    if (!id || !canDelete || !page) return;
    if (!window.confirm('Delete this page permanently?')) return;
    setBusy(true);
    try {
      await api(`/api/pages/${id}`, { method: 'DELETE' });
      navigate('/admin/pages');
    } catch (e) {
      setError(formatError(e));
      setBusy(false);
    }
  };

  if (!canEdit) {
    return (
      <div className="wrap wrap--wide">
        <div className="beekiri-notice is-info">
          <p>You need the edit_pages capability to edit pages.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="wrap wrap--wide wrap--page-editor">
        <p className="bk-muted">Loading page…</p>
      </div>
    );
  }

  if (!page) {
    return (
      <div className="wrap wrap--wide wrap--page-editor">
        <div className="beekiri-notice is-error" role="alert">
          <p>{error || 'Page not found.'}</p>
        </div>
        <p>
          <Link to="/admin/pages">← Back to Pages</Link>
        </p>
      </div>
    );
  }

  const permalinkBase = LIVE_SITE.replace(/\/$/, '');
  const isPublished = page.status === 'publish';

  const chrome = {
    title,
    onTitleChange,
    slug,
    slugEditing,
    setSlugEditing,
    onSlugChange: (value: string) => {
      setSlugTouched(true);
      setSlug(toSlug(value) || value);
    },
    commitSlug: () => {
      setSlugTouched(true);
      setSlugEditing(false);
    },
    cancelSlug: () => {
      setSlug(page.slug);
      setSlugEditing(false);
    },
    permalinkBase,
    pageStatus: page.status,
    visibility: status,
    setVisibility: setStatus,
    excerpt,
    setExcerpt,
    updatedAt: page.updatedAt,
    publishedAt: page.publishedAt,
    createdAt: page.createdAt,
    authorName: page.authorName ?? null,
    updatedByName: page.updatedByName ?? page.authorName ?? null,
    revisionCount: page.revisionCount ?? 0,
    parentId: page.parentId ?? null,
    pageId: page.id,
    beekiricanvaData: emptyBeekiricanvaData,
    beekiricodeData,
    isPublished,
    busy,
    canPublish,
    canDelete,
    viewHref: isPublished ? `${permalinkBase}/${page.slug}` : null,
    isDirty,
    fullscreen,
    toggleFullscreen: () => setFullscreen((v) => !v),
    settingsOpen,
    openSettings: () => setSettingsOpen(true),
    closeSettings: () => setSettingsOpen(false),
    previewChanges: () => void previewChanges(),
    saveDraft: () => void save('draft'),
    publish: () => void save('publish'),
    update: () => void save(status === 'publish' ? 'publish' : 'draft'),
    switchToDraft: () => void save('draft'),
    onDelete: () => void onDelete(),
    applyRestoredPage: (row: PageRow) => {
      applySaved(row, docFromPage(row));
      setSlugTouched(true);
      setSlugEditing(false);
      setCanvasKey((k) => k + 1);
      setNotice('Revision restored.');
    },
  };

  return (
    <div className="wrap wrap--wide wrap--page-editor">
      <PageEditorChromeProvider value={chrome}>
        <div className="bk-page-editor is-fullscreen">
          {error ? (
            <div className="beekiri-notice is-error" role="alert">
              <p>{error}</p>
            </div>
          ) : null}
          {notice ? (
            <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
          ) : null}

          <div className="bk-page-editor__main bk-page-editor__main--full bk-page-editor__main--beekiricode">
            <BeekiriCodeCanvas
              key={`${page.id}-${canvasKey}-beekiricode`}
              pageId={page.id}
              title={title || 'Untitled'}
              slug={slug}
              permalinkBase={permalinkBase}
              isPublished={isPublished}
              doc={beekiricodeData}
              onChange={onBeekiriCodeChange}
              busy={busy}
              canPublish={canPublish}
              isDirty={isDirty}
              onSaveDraft={() => void save('draft')}
              onPublish={() => void save('publish')}
              onOpenSettings={() => setSettingsOpen(true)}
              onPreview={() => void previewChanges()}
            />
            <PageSettingsModal />
          </div>
        </div>
      </PageEditorChromeProvider>
    </div>
  );
}

/** `/admin/pages/new` — create auto-draft then open editor. */
export function PageNewRedirect() {
  const navigate = useNavigate();
  const auth = useAuth();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (!auth.user?.capabilities.includes('edit_pages')) {
          setError('You need the edit_pages capability to create pages.');
          return;
        }
        const created = await api<PageRow>('/api/pages', {
          method: 'POST',
          json: { title: 'Auto Draft', status: 'auto-draft' },
        });
        if (!cancelled) navigate(`/admin/pages/${created.id}`, { replace: true });
      } catch (e) {
        if (!cancelled) setError(formatError(e));
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [auth.user, navigate]);

  if (error) {
    return (
      <div className="wrap wrap--wide">
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
        <p>
          <Link to="/admin/pages">← Back to Pages</Link>
        </p>
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide">
      <p className="bk-muted">Creating page…</p>
    </div>
  );
}
