import { useEffect, useState, type DragEvent } from 'react';
import { Link } from 'react-router-dom';
import { Plus, SquaresFour, X } from '@phosphor-icons/react';
import { api } from '../api/client';
import {
  availableWidgets,
  formatBytes,
  formatRelative,
  humanAction,
  loadLayout,
  nudgeSpan,
  saveLayout,
} from './dashboard/layout';
import {
  DEFAULT_LAYOUT,
  SPAN_STEPS,
  WIDGET_META,
  type DashboardOverview,
  type DashboardRange,
  type LayoutItem,
  type WidgetId,
  type WidgetSpan,
} from './dashboard/types';
import './dashboard/dashboard.css';

const RANGES: { value: DashboardRange; label: string }[] = [
  { value: 'today', label: 'Today' },
  { value: '7d', label: '7d' },
  { value: '30d', label: '30d' },
  { value: 'all', label: 'All' },
];

function StackedBar({
  segments,
  total,
}: {
  segments: { label: string; value: number; color: string }[];
  total: number;
}) {
  const safe = total > 0 ? total : 1;
  return (
    <div className="bk-dash__fill">
      <div className="bk-dash__bar" aria-hidden>
        {segments.map((s) =>
          s.value > 0 ? (
            <span
              key={s.label}
              className="bk-dash__bar-seg"
              style={{ width: `${(s.value / safe) * 100}%`, background: s.color }}
            />
          ) : null,
        )}
      </div>
      <ul className="bk-dash__legend">
        {segments.map((s) => (
          <li key={s.label}>
            <span className="bk-dash__legend-swatch" style={{ background: s.color }} />
            {s.label} <strong>{formatBytes(s.value)}</strong>
          </li>
        ))}
      </ul>
    </div>
  );
}

function WidgetChrome({
  id,
  span,
  editing,
  onRemove,
  onResize,
  children,
}: {
  id: WidgetId;
  span: WidgetSpan;
  editing: boolean;
  onRemove: () => void;
  onResize: (span: WidgetSpan) => void;
  children: React.ReactNode;
}) {
  const meta = WIDGET_META[id];
  const step = SPAN_STEPS.indexOf(span);
  const canNarrow = step > 0;
  const canWiden = step >= 0 && step < SPAN_STEPS.length - 1;
  return (
    <section className="bk-dash__widget" style={{ ['--tint' as string]: meta.tint }}>
      <div className="bk-dash__widget-head">
        <h3 className="bk-dash__widget-title">
          <span className="bk-dash__dot" aria-hidden />
          {meta.title}
        </h3>
        {editing ? (
          <div className="bk-dash__widget-tools">
            <div className="bk-dash__width" role="group" aria-label="Card width">
              <button
                type="button"
                className="bk-dash__width-btn"
                disabled={!canNarrow}
                title="Make narrower"
                aria-label="Make card narrower"
                onClick={(e) => {
                  e.stopPropagation();
                  onResize(nudgeSpan(span, -1));
                }}
              >
                −
              </button>
              <span className="bk-dash__width-label">{span}/12</span>
              <button
                type="button"
                className="bk-dash__width-btn"
                disabled={!canWiden}
                title="Make wider"
                aria-label="Make card wider"
                onClick={(e) => {
                  e.stopPropagation();
                  onResize(nudgeSpan(span, 1));
                }}
              >
                +
              </button>
            </div>
            <button type="button" className="bk-dash__remove" onClick={onRemove}>
              Remove
            </button>
          </div>
        ) : null}
      </div>
      {children}
      {editing ? (
        <>
          <button
            type="button"
            className="bk-dash__resize bk-dash__resize--left"
            disabled={!canNarrow}
            aria-label="Make card narrower"
            title="Narrower"
            onClick={(e) => {
              e.stopPropagation();
              onResize(nudgeSpan(span, -1));
            }}
          />
          <button
            type="button"
            className="bk-dash__resize bk-dash__resize--right"
            disabled={!canWiden}
            aria-label="Make card wider"
            title="Wider"
            onClick={(e) => {
              e.stopPropagation();
              onResize(nudgeSpan(span, 1));
            }}
          />
        </>
      ) : null}
    </section>
  );
}

function renderWidget(
  id: WidgetId,
  data: DashboardOverview | null,
  editing: boolean,
  span: WidgetSpan,
  onRemove: () => void,
  onResize: (span: WidgetSpan) => void,
) {
  const d = data;
  const chrome = {
    id,
    span,
    editing,
    onRemove,
    onResize,
  };
  switch (id) {
    case 'storage': {
      const s = d?.storage;
      return (
        <WidgetChrome {...chrome}>
          <p className="bk-dash__stat">{s?.totalLabel ?? '—'}</p>
          <p className="bk-dash__sub">
            used · {s?.dialect === 'sqlite' ? 'SQLite' : 'Postgres'} · self-hosted
          </p>
          <StackedBar
            total={s?.totalBytes ?? 0}
            segments={[
              { label: 'Images', value: s?.imageBytes ?? 0, color: '#e8a07a' },
              { label: 'Videos', value: s?.videoBytes ?? 0, color: '#7c6af0' },
              { label: 'Documents', value: s?.documentBytes ?? 0, color: '#ff6b9d' },
              { label: 'Database', value: s?.databaseBytes ?? 0, color: '#2271b1' },
            ]}
          />
        </WidgetChrome>
      );
    }
    case 'pages': {
      const p = d?.pages;
      return (
        <WidgetChrome {...chrome}>
          <p className="bk-dash__stat">{p?.published ?? 0}</p>
          <p className="bk-dash__sub">
            Published
            {(p?.publishedThisWeek ?? 0) > 0 ? ` +${p!.publishedThisWeek} this week` : null}
          </p>
          <p className="bk-dash__meta">
            {p?.drafts ?? 0} drafts · {p?.scheduled ?? 0} scheduled
          </p>
        </WidgetChrome>
      );
    }
    case 'posts': {
      const p = d?.posts;
      return (
        <WidgetChrome {...chrome}>
          <p className="bk-dash__stat">{p?.total ?? 0}</p>
          <p className="bk-dash__sub">Total · {p?.categories ?? 0} categories</p>
          <div className="bk-dash__fill">
            <div
              className="bk-dash__bar"
              style={{
                background: 'transparent',
                borderTop: '1px dashed rgba(0,0,0,0.12)',
                height: 0,
              }}
            />
          </div>
        </WidgetChrome>
      );
    }
    case 'media': {
      const m = d?.media;
      const tiles = m?.previews?.slice(0, 8) ?? [];
      while (tiles.length < 8) {
        tiles.push({ id: `empty-${tiles.length}`, url: '', mimeType: '' });
      }
      return (
        <WidgetChrome {...chrome}>
          <p className="bk-dash__stat">{m?.files ?? 0}</p>
          <p className="bk-dash__sub">files · {m?.bytesLabel ?? '0 B'}</p>
          <div className="bk-dash__fill">
            <div className="bk-dash__media-grid">
              {tiles.map((t) =>
                t.url ? (
                  <img key={t.id} src={t.url} alt="" loading="lazy" />
                ) : (
                  <span key={t.id} />
                ),
              )}
            </div>
          </div>
        </WidgetChrome>
      );
    }
    case 'status': {
      const s = d?.status;
      return (
        <WidgetChrome {...chrome}>
          <ul className="bk-dash__status-list">
            <li>
              <span>
                <i className="bk-dash__pulse is-ok" />
                Site
              </span>
              <em>Live</em>
            </li>
            <li>
              <span>
                <i className="bk-dash__pulse is-ok" />
                Publish
              </span>
              <em>{formatRelative(s?.lastPublishAt)}</em>
            </li>
            <li>
              <span>
                <i className="bk-dash__pulse is-ok" />
                Updated
              </span>
              <em>{formatRelative(s?.lastUpdateAt)}</em>
            </li>
            <li>
              <span>
                <i className={`bk-dash__pulse ${(s?.fieldGroups ?? 0) > 0 ? 'is-ok' : 'is-warn'}`} />
                Fields
              </span>
              <em>{s?.fieldGroups ?? 0} groups</em>
            </li>
          </ul>
        </WidgetChrome>
      );
    }
    case 'activity': {
      const rows = d?.activity ?? [];
      return (
        <WidgetChrome {...chrome}>
          {rows.length === 0 ? (
            <p className="bk-dash__empty">No activity in this range.</p>
          ) : (
            <ul className="bk-dash__feed">
              {rows.map((row) => (
                <li key={row.id}>
                  <span className="bk-dash__feed-body">
                    <em>{row.actor}</em> · {humanAction(row.action)}
                  </span>
                  <span className="bk-dash__feed-time">{formatRelative(row.at)}</span>
                </li>
              ))}
            </ul>
          )}
        </WidgetChrome>
      );
    }
    case 'publish': {
      const rows = d?.publishLineup ?? [];
      return (
        <WidgetChrome {...chrome}>
          {rows.length === 0 ? (
            <p className="bk-dash__empty">No drafts waiting to publish.</p>
          ) : (
            <ul className="bk-dash__feed bk-dash__lineup">
              {rows.map((row) => (
                <li key={row.id}>
                  <Link to={`/admin/pages/${row.id}`}>
                    <span className="bk-dash__feed-body">{row.title}</span>
                  </Link>
                  <span className="bk-dash__feed-time">{formatRelative(row.updatedAt)}</span>
                </li>
              ))}
            </ul>
          )}
        </WidgetChrome>
      );
    }
    case 'fields':
      return (
        <WidgetChrome {...chrome}>
          <p className="bk-dash__stat">{d?.fieldGroups ?? 0}</p>
          <p className="bk-dash__sub">Backend field groups</p>
          <p className="bk-dash__meta">
            <Link to="/admin/fields" className="button-link">
              Manage fields
            </Link>
          </p>
        </WidgetChrome>
      );
    case 'users':
      return (
        <WidgetChrome {...chrome}>
          <p className="bk-dash__stat">{d?.users ?? 0}</p>
          <p className="bk-dash__sub">People with admin access</p>
          <p className="bk-dash__meta">
            <Link to="/admin/users" className="button-link">
              Manage users
            </Link>
          </p>
        </WidgetChrome>
      );
    default:
      return null;
  }
}

export function Dashboard() {
  const [range, setRange] = useState<DashboardRange>('today');
  const [data, setData] = useState<DashboardOverview | null>(null);
  const [layout, setLayout] = useState<LayoutItem[]>(() => loadLayout());
  const [editing, setEditing] = useState(false);
  const [libraryOpen, setLibraryOpen] = useState(false);
  const [dragId, setDragId] = useState<WidgetId | null>(null);

  useEffect(() => {
    let cancelled = false;
    api<DashboardOverview>(`/api/site/dashboard?range=${range}`)
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch(() => {
        if (!cancelled) setData(null);
      });
    return () => {
      cancelled = true;
    };
  }, [range]);

  function updateLayout(next: LayoutItem[]) {
    setLayout(next);
    saveLayout(next);
  }

  function removeWidget(id: WidgetId) {
    updateLayout(layout.filter((i) => i.id !== id));
  }

  function resizeWidget(id: WidgetId, span: WidgetSpan) {
    updateLayout(layout.map((i) => (i.id === id ? { ...i, span } : i)));
  }

  function addWidget(id: WidgetId) {
    if (layout.some((i) => i.id === id)) return;
    updateLayout([...layout, { id, span: WIDGET_META[id].defaultSpan }]);
  }

  function onDragStart(id: WidgetId, e: DragEvent) {
    if (!editing) {
      e.preventDefault();
      return;
    }
    setDragId(id);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', id);
  }

  function onDrop(targetId: WidgetId, e: DragEvent) {
    e.preventDefault();
    const source = (e.dataTransfer.getData('text/plain') || dragId) as WidgetId | null;
    setDragId(null);
    if (!source || source === targetId) return;
    const from = layout.findIndex((i) => i.id === source);
    const to = layout.findIndex((i) => i.id === targetId);
    if (from < 0 || to < 0) return;
    const next = [...layout];
    const [item] = next.splice(from, 1);
    next.splice(to, 0, item);
    updateLayout(next);
  }

  const unused = availableWidgets(layout);
  const countLabel = String(layout.length).padStart(2, '0');

  return (
    <div className={`bk-dash${editing ? ' is-editing' : ''}`}>
      <header className="bk-dash__header">
        <div className="bk-dash__title-row">
          <h1>Overview</h1>
          <span className="bk-dash__count">{countLabel} blocks</span>
        </div>
        <div className="bk-dash__actions">
          <div className="bk-dash__ranges" role="tablist" aria-label="Time range">
            {RANGES.map((r) => (
              <button
                key={r.value}
                type="button"
                role="tab"
                aria-selected={range === r.value}
                className={range === r.value ? 'is-active' : undefined}
                onClick={() => setRange(r.value)}
              >
                {r.label}
              </button>
            ))}
          </div>
          <button
            type="button"
            className={`bk-dash__btn${editing ? ' is-active' : ''}`}
            onClick={() => {
              setEditing((v) => !v);
              if (editing) setLibraryOpen(false);
            }}
          >
            <SquaresFour size={13} weight="bold" aria-hidden />
            {editing ? 'Done' : 'Customize'}
          </button>
          <button
            type="button"
            className="bk-dash__btn bk-dash__btn--ghost"
            onClick={() => {
              setLibraryOpen(true);
              setEditing(true);
            }}
          >
            <Plus size={13} weight="bold" aria-hidden />
            Add block
          </button>
        </div>
      </header>

      <div className="bk-dash__grid">
        {layout.map((item) => (
          <div
            key={item.id}
            className={`bk-dash__cell${dragId === item.id ? ' is-dragging' : ''}`}
            data-span={item.span}
            draggable={editing}
            onDragStart={(e) => onDragStart(item.id, e)}
            onDragOver={(e) => {
              if (editing) e.preventDefault();
            }}
            onDrop={(e) => onDrop(item.id, e)}
            onDragEnd={() => setDragId(null)}
          >
            {renderWidget(
              item.id,
              data,
              editing,
              item.span,
              () => removeWidget(item.id),
              (span) => resizeWidget(item.id, span),
            )}
          </div>
        ))}
      </div>

      {editing && !libraryOpen && dragId === null ? (
        <div className="bk-dash__fab" role="status">
          <span>
            <strong>Customize mode</strong> — drag to reorder, − / + to resize width.
          </span>
          <button type="button" className="bk-dash__btn" onClick={() => setLibraryOpen(true)}>
            <Plus size={12} weight="bold" aria-hidden /> Add block
          </button>
          <button type="button" className="bk-dash__btn bk-dash__btn--ghost" onClick={() => setEditing(false)}>
            Done
          </button>
        </div>
      ) : null}

      {libraryOpen ? (
        <div className="bk-dash__library" role="dialog" aria-label="Block library">
          <div className="bk-dash__library-head">
            <h2>Add block</h2>
            <button type="button" className="bk-dash__btn bk-dash__btn--ghost" onClick={() => setLibraryOpen(false)}>
              <X size={14} weight="bold" aria-hidden /> Close
            </button>
          </div>
          <div className="bk-dash__library-body">
            {unused.length === 0 ? (
              <p className="bk-dash__library-empty">All blocks are already on your overview.</p>
            ) : (
              unused.map((id) => (
                <button
                  key={id}
                  type="button"
                  className="bk-dash__library-item"
                  onClick={() => {
                    addWidget(id);
                    setLibraryOpen(false);
                  }}
                >
                  <strong>{WIDGET_META[id].title}</strong>
                  <span>{WIDGET_META[id].description}</span>
                </button>
              ))
            )}
            <button
              type="button"
              className="bk-dash__library-item"
              onClick={() => {
                updateLayout([...DEFAULT_LAYOUT]);
                setLibraryOpen(false);
              }}
            >
              <strong>Reset layout</strong>
              <span>Restore the default Overview blocks</span>
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
