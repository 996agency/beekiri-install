import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { api, ApiError } from '../../api/client';
import { AdminDataTable, type AdminTableColumn } from '../../components/AdminDataTable';
import { PageHeader } from '../../components/PageHeader';
import { SuccessNotice } from '../../components/SuccessNotice';

type OptionsPage = {
  id: string;
  title: string;
  slug: string;
  menuTitle: string;
  description: string;
  parentSlug: string;
  active: boolean;
};

type Mode = { kind: 'list' } | { kind: 'create' } | { kind: 'edit'; row: OptionsPage };

const EMPTY = {
  title: '',
  slug: '',
  menuTitle: '',
  description: '',
  parentSlug: '',
  active: true,
};

function formatError(e: unknown) {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return 'Something went wrong.';
}

function toSlug(v: string) {
  return v
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
}

export function OptionsPagesPage() {
  const [rows, setRows] = useState<OptionsPage[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [mode, setMode] = useState<Mode>({ kind: 'list' });
  const [form, setForm] = useState(EMPTY);

  const load = useCallback(async () => {
    const res = await api<{ optionsPages: OptionsPage[] }>('/api/fields/options-pages');
    setRows(res.optionsPages);
  }, []);

  useEffect(() => {
    setLoading(true);
    load()
      .catch((e) => setError(formatError(e)))
      .finally(() => setLoading(false));
  }, [load]);

  const openCreate = () => {
    setForm(EMPTY);
    setError(null);
    setNotice(null);
    setMode({ kind: 'create' });
  };

  const openEdit = (row: OptionsPage) => {
    setForm({
      title: row.title,
      slug: row.slug,
      menuTitle: row.menuTitle,
      description: row.description,
      parentSlug: row.parentSlug,
      active: row.active,
    });
    setError(null);
    setNotice(null);
    setMode({ kind: 'edit', row });
  };

  const back = () => {
    setMode({ kind: 'list' });
    setForm(EMPTY);
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const payload = {
        title: form.title.trim(),
        slug: form.slug.trim().toLowerCase(),
        menuTitle: (form.menuTitle || form.title).trim(),
        description: form.description.trim(),
        parentSlug: form.parentSlug.trim().toLowerCase(),
        active: form.active,
      };
      if (mode.kind === 'create') {
        await api('/api/fields/options-pages', { method: 'POST', json: payload });
        setNotice(`Options page “${payload.title}” created.`);
      } else if (mode.kind === 'edit') {
        await api(`/api/fields/options-pages/${mode.row.id}`, {
          method: 'PATCH',
          json: payload,
        });
        setNotice(`Options page “${payload.title}” updated.`);
      }
      await load();
      back();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const onDelete = async (row: OptionsPage) => {
    if (!window.confirm(`Delete options page “${row.title}”?`)) return;
    setBusy(true);
    try {
      await api(`/api/fields/options-pages/${row.id}`, { method: 'DELETE' });
      setNotice(`Options page “${row.title}” deleted.`);
      await load();
      if (mode.kind === 'edit' && mode.row.id === row.id) back();
    } catch (err) {
      setError(formatError(err));
    } finally {
      setBusy(false);
    }
  };

  const columns: AdminTableColumn<OptionsPage>[] = useMemo(
    () => [
      {
        key: 'title',
        header: 'Options page',
        render: (row) => (
          <>
            <strong className="bk-table__primary">{row.title}</strong>
            {!row.active ? <span className="bk-table__badge">Inactive</span> : null}
            <div className="bk-table__row-actions">
              <button type="button" className="button-link" onClick={() => openEdit(row)}>
                Edit
              </button>
              <span className="bk-table__sep">|</span>
              <button
                type="button"
                className="button-link is-danger"
                disabled={busy}
                onClick={() => onDelete(row)}
              >
                Delete
              </button>
            </div>
          </>
        ),
      },
      { key: 'slug', header: 'Slug', render: (row) => <code>{row.slug}</code> },
      {
        key: 'parent',
        header: 'Parent',
        render: (row) => row.parentSlug || '—',
      },
    ],
    [busy],
  );

  if (mode.kind !== 'list') {
    const formId = 'options-page-form';
    const parents = rows.filter((r) => mode.kind !== 'edit' || r.id !== mode.row.id);
    return (
      <div className="wrap wrap--wide">
        <PageHeader
          title={mode.kind === 'edit' ? 'Edit options page' : 'Add options page'}
          actions={
            <>
              <button type="submit" form={formId} className="button button-primary" disabled={busy}>
                {busy ? 'Saving…' : mode.kind === 'edit' ? 'Update' : 'Add page'}
              </button>
              <button type="button" className="button" disabled={busy} onClick={back}>
                Cancel
              </button>
            </>
          }
        />
        <p className="bk-muted">
          Site-wide settings screens you can attach field groups to — same idea as ACF Options
          Pages.
        </p>
        {error ? (
          <div className="beekiri-notice is-error" role="alert">
            <p>{error}</p>
          </div>
        ) : null}
        <form id={formId} className="bk-panel" onSubmit={onSubmit}>
          <div className="bk-panel__body">
            <table className="form-table">
              <tbody>
                <tr>
                  <th scope="row">
                    <label htmlFor="op_title">Page title</label>
                  </th>
                  <td>
                    <input
                      id="op_title"
                      className="regular-text"
                      required
                      value={form.title}
                      onChange={(e) => {
                        const title = e.target.value;
                        setForm((f) => ({
                          ...f,
                          title,
                          menuTitle: f.menuTitle || title,
                          slug:
                            mode.kind === 'create' && (!f.slug || f.slug === toSlug(f.title))
                              ? toSlug(title)
                              : f.slug,
                        }));
                      }}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="op_menu">Menu title</label>
                  </th>
                  <td>
                    <input
                      id="op_menu"
                      className="regular-text"
                      value={form.menuTitle}
                      onChange={(e) => setForm((f) => ({ ...f, menuTitle: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="op_slug">Slug</label>
                  </th>
                  <td>
                    <input
                      id="op_slug"
                      className="regular-text"
                      required
                      value={form.slug}
                      onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="op_parent">Parent page</label>
                  </th>
                  <td>
                    <select
                      id="op_parent"
                      value={form.parentSlug}
                      onChange={(e) => setForm((f) => ({ ...f, parentSlug: e.target.value }))}
                    >
                      <option value="">None (top level)</option>
                      {parents.map((p) => (
                        <option key={p.id} value={p.slug}>
                          {p.title}
                        </option>
                      ))}
                    </select>
                  </td>
                </tr>
                <tr>
                  <th scope="row">
                    <label htmlFor="op_desc">Description</label>
                  </th>
                  <td>
                    <textarea
                      id="op_desc"
                      rows={2}
                      value={form.description}
                      onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                    />
                  </td>
                </tr>
                <tr>
                  <th scope="row">Status</th>
                  <td>
                    <label className="bk-check">
                      <input
                        type="checkbox"
                        checked={form.active}
                        onChange={(e) => setForm((f) => ({ ...f, active: e.target.checked }))}
                      />
                      <span className="bk-check__box" aria-hidden />
                      <span className="bk-check__label">Active</span>
                    </label>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="wrap wrap--wide">
      <PageHeader
        title="Options Pages"
        actions={
          <button type="button" className="button button-primary" onClick={openCreate}>
            Add options page
          </button>
        }
      />
      <p className="bk-muted">
        Global options screens for site-wide fields. {rows.length} page{rows.length === 1 ? '' : 's'}.
      </p>
      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}
      <AdminDataTable
        rows={rows}
        columns={columns}
        getRowId={(r) => r.id}
        loading={loading}
        defaultPageSize={10}
        emptyTitle="No options pages yet. Add Site options, Theme settings, and more."
      />
    </div>
  );
}
