import { ChangeEvent, FormEvent, useEffect, useRef, useState } from 'react';
import { api, apiUpload, ApiError } from '../api/client';
import { SuccessNotice } from '../components/SuccessNotice';
import { useCoreUpdate } from '../core/CoreUpdateContext';
import { MediaSettings, MediaSettingsPanel } from './MediaSettingsPanel';
import {
  MenuItem,
  PermalinkStructure,
  PermalinksPanel,
} from './PermalinksPanel';

type Tab =
  | 'core'
  | 'general'
  | 'reading'
  | 'writing'
  | 'page-editor'
  | 'advanced'
  | 'permalinks'
  | 'media';

type FrontendRuntime = 'react' | 'php';

type SiteSettings = {
  id: string;
  title: string;
  tagline: string;
  language: string;
  blogPublic: boolean;
  timezone: string;
  dateFormat: string;
  timeFormat: string;
  businessName: string;
  businessCategory: string;
  businessPhone: string;
  businessAddress: string;
  businessHours: string;
  businessImageUrl: string;
  faviconUrl: string;
  faviconResolved?: string;
  faviconDefault?: string;
  permalinkStructure: PermalinkStructure;
  permalinkCustom: string;
  menuItems: MenuItem[];
  media: MediaSettings;
  pageEditorStyle: 'beekiricode';
  frontendRuntime: FrontendRuntime;
};

type SystemStatus = {
  api: { ok: boolean; label: string };
  database: { ok: boolean; label: string };
  uptimeSeconds: number;
  nodeVersion: string;
  environment: string;
  coreVersion: string;
  channel: string;
  checkedAt: string;
  frontend?: string;
  admin?: string;
  apiStack?: string;
  databaseEngine?: string;
};

const TABS: { id: Tab; label: string }[] = [
  { id: 'core', label: 'Beekiri Core' },
  { id: 'general', label: 'General' },
  { id: 'reading', label: 'Reading' },
  { id: 'writing', label: 'Writing' },
  { id: 'page-editor', label: 'Page editor' },
  { id: 'advanced', label: 'Advanced' },
  { id: 'permalinks', label: 'Permalinks' },
  { id: 'media', label: 'Media' },
];

function formatUptime(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  if (m < 60) return `${m}m ${s}s`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  if (h < 24) return `${h}h ${rm}m`;
  const d = Math.floor(h / 24);
  return `${d}d ${h % 24}h`;
}

function StatusValue({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span className={`bk-status ${ok ? 'is-ok' : 'is-down'}`}>
      <span className="bk-status__dot" aria-hidden />
      {label}
    </span>
  );
}

export function SettingsPage() {
  const coreUpdate = useCoreUpdate();
  const faviconFileRef = useRef<HTMLInputElement>(null);
  const [tab, setTab] = useState<Tab>('core');
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [busy, setBusy] = useState(false);
  const [faviconUploading, setFaviconUploading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const updates = coreUpdate.updates;
  const updateAvailable = coreUpdate.updateAvailable;
  const updateCount = coreUpdate.updateCount;

  const loadSettings = async () => {
    const s = await api<SiteSettings>('/api/site/settings');
    setSettings({
      ...s,
      businessName: s.businessName ?? '',
      businessCategory: s.businessCategory ?? '',
      businessPhone: s.businessPhone ?? '',
      businessAddress: s.businessAddress ?? '',
      businessHours: s.businessHours ?? '',
      businessImageUrl: s.businessImageUrl ?? '',
      faviconUrl: s.faviconUrl ?? '',
      faviconResolved: s.faviconResolved ?? '/beekiri-logo.png',
      faviconDefault: s.faviconDefault ?? '/beekiri-logo.png',
      permalinkStructure: s.permalinkStructure ?? 'postname',
      permalinkCustom: s.permalinkCustom ?? '/%postname%/',
      pageEditorStyle: 'beekiricode',
      frontendRuntime: s.frontendRuntime === 'react' ? 'react' : 'php',
      menuItems: s.menuItems?.length
        ? s.menuItems
        : [
            { id: 'home', label: 'Home', path: '/', enabled: true },
            { id: 'blog', label: 'Blog', path: '/blog', enabled: true },
            { id: 'about', label: 'About', path: '/about', enabled: false },            { id: 'contact', label: 'Contact', path: '/contact', enabled: false },
          ],
      media: s.media
        ? {
            ...s.media,
            folders: (s.media.folders ?? []).map((f) => ({
              ...f,
              parentId: f.parentId ?? null,
            })),
          }
        : {
            convertToWebp: true,
            webpLossless: true,
            webpQuality: 100,
            maxWidth: 1920,
            maxHeight: 1920,
            stripMetadata: true,
            keepOriginal: false,
            folders: [
              { id: 'general', name: 'General', slug: 'general', parentId: null },
              { id: 'heroes', name: 'Heroes', slug: 'heroes', parentId: null },
              { id: 'blog', name: 'Blog', slug: 'blog', parentId: null },
            ],
          },
    });
  };

  const loadCore = async () => {
    const s = await api<SystemStatus>('/api/system/status');
    setStatus(s);
  };

  useEffect(() => {
    setError(null);
    setNotice(null);
    if (tab === 'core') {
      loadCore().catch((e) =>
        setError(e instanceof ApiError ? e.message : 'Could not load core status'),
      );
      void coreUpdate.refresh();
    } else {
      loadSettings().catch((e) =>
        setError(e instanceof ApiError ? e.message : 'Could not load settings'),
      );
    }
  }, [tab]);

  const refreshStatus = async () => {
    setRefreshing(true);
    setError(null);
    try {
      await loadCore();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Could not refresh status');
    } finally {
      setRefreshing(false);
    }
  };

  const saveSettings = async (e: FormEvent, patch: Partial<SiteSettings>) => {
    e.preventDefault();
    if (!settings) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const saved = await api<SiteSettings>('/api/site/settings', {
        method: 'PATCH',
        json: patch,
      });
      setSettings(saved);
      setNotice('Settings saved.');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Save failed');
    } finally {
      setBusy(false);
    }
  };

  const checkUpdates = async () => {
    setError(null);
    setNotice(null);
    const u = await coreUpdate.refresh();
    if (!u) {
      setError('Update check failed');
      return;
    }
    if (!u.updateAvailable) setNotice(null);
  };

  return (
    <div className={`wrap${tab === 'permalinks' ? ' is-full' : ''}`}>
      <h1>
        Settings
        {updateCount > 0 ? (
          <span className="bk-count" aria-label={`${updateCount} update available`}>
            +{updateCount}
          </span>
        ) : null}
      </h1>

      <nav className="bk-tabs" aria-label="Settings sections">
        {TABS.map(({ id, label }) => (
          <button
            key={id}
            type="button"
            className={`bk-tabs__item${tab === id ? ' is-active' : ''}`}
            onClick={() => setTab(id)}
          >
            {label}
            {id === 'core' && updateCount > 0 ? (
              <span className="bk-count">+{updateCount}</span>
            ) : null}
          </button>
        ))}
      </nav>

      {error && (
        <div className="beekiri-notice is-error">
          <p>{error}</p>
        </div>
      )}
      {notice ? (
        <SuccessNotice message={notice} onDismiss={() => setNotice(null)} />
      ) : null}

      {tab === 'general' && settings && (
        <form
          className="bk-stack"
          onSubmit={(e) =>
            void saveSettings(e, {
              title: settings.title,
              tagline: settings.tagline,
              businessName: settings.businessName,
              businessCategory: settings.businessCategory,
              businessPhone: settings.businessPhone,
              businessAddress: settings.businessAddress,
              businessHours: settings.businessHours,
              businessImageUrl: settings.businessImageUrl,
              faviconUrl: settings.faviconUrl.trim(),
            })
          }
        >
          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Site</h2>
            </div>
            <div className="bk-panel__body">
              <table className="form-table">
                <tbody>
                  <tr>
                    <th scope="row">
                      <label htmlFor="blogname">Site title</label>
                    </th>
                    <td>
                      <input
                        id="blogname"
                        className="regular-text"
                        value={settings.title}
                        onChange={(e) => setSettings({ ...settings, title: e.target.value })}
                        required
                      />
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="blogdescription">Tagline</label>
                    </th>
                    <td>
                      <input
                        id="blogdescription"
                        className="regular-text"
                        value={settings.tagline}
                        onChange={(e) => setSettings({ ...settings, tagline: e.target.value })}
                      />
                      <p className="description">Shown on the public landing page.</p>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="site_favicon">Favicon</label>
                    </th>
                    <td>
                      <div className="bk-favicon-field">
                        <img
                          className="bk-favicon-field__preview"
                          src={
                            settings.faviconUrl.trim() ||
                            settings.faviconDefault ||
                            '/beekiri-logo.png'
                          }
                          alt=""
                          width={32}
                          height={32}
                        />
                        <div className="bk-favicon-field__inputs">
                          <div className="bk-favicon-field__row">
                            <input
                              id="site_favicon"
                              className="regular-text"
                              type="text"
                              placeholder="/beekiri-logo.png or https://…"
                              value={settings.faviconUrl}
                              onChange={(e) =>
                                setSettings({ ...settings, faviconUrl: e.target.value })
                              }
                            />
                            <button
                              type="button"
                              className="button"
                              disabled={faviconUploading || busy}
                              onClick={() => faviconFileRef.current?.click()}
                            >
                              {faviconUploading ? 'Uploading…' : 'Upload'}
                            </button>
                            <input
                              ref={faviconFileRef}
                              type="file"
                              accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml,image/x-icon,.ico"
                              hidden
                              onChange={async (e: ChangeEvent<HTMLInputElement>) => {
                                const file = e.target.files?.[0];
                                if (!file) return;
                                setFaviconUploading(true);
                                setError(null);
                                setNotice(null);
                                try {
                                  const form = new FormData();
                                  form.append('file', file);
                                  form.append('purpose', 'favicon');
                                  const res = await apiUpload<{ item: { url: string } }>(
                                    '/api/media/upload?purpose=favicon',
                                    form,
                                  );
                                  setSettings({ ...settings, faviconUrl: res.item.url });
                                  setNotice(
                                    'Favicon uploaded. Click Save changes to apply it to the site.',
                                  );
                                } catch (err) {
                                  setError(
                                    err instanceof ApiError
                                      ? err.message
                                      : err instanceof Error
                                        ? err.message
                                        : 'Upload failed.',
                                  );
                                } finally {
                                  setFaviconUploading(false);
                                  if (faviconFileRef.current) faviconFileRef.current.value = '';
                                }
                              }}
                            />
                          </div>
                          <p className="description">
                            Browser tab icon for this client site. Upload a file (saved to Media) or
                            paste a URL / path. Leave blank for the Beekiri default (
                            <code>/beekiri-logo.png</code>).
                          </p>
                          {settings.faviconUrl.trim() ? (
                            <button
                              type="button"
                              className="button"
                              onClick={() => setSettings({ ...settings, faviconUrl: '' })}
                            >
                              Reset to default
                            </button>
                          ) : null}
                        </div>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Google Business</h2>
            </div>
            <div className="bk-panel__body">
              <p className="bk-muted" style={{ marginTop: 0 }}>
                Add local business details for your website. This helps Google understand your
                business — it does not create or manage your Google Business Profile listing.
              </p>
              <div className="bk-notice-soft" role="note">
                <p>
                  To appear in Google Maps and local results, claim and verify your business at
                  Google Business Profile — then keep name, address, and phone in sync here.{' '}
                  <a
                    href="https://www.google.com/business/"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Open Google Business Profile
                  </a>
                </p>
              </div>

              <div className="bk-seo-layout">
                <div className="bk-seo-fields">
                  <div className="bk-field">
                    <label htmlFor="business_name">Business name</label>
                    <input
                      id="business_name"
                      type="text"
                      value={settings.businessName}
                      placeholder={settings.title || 'Your business'}
                      onChange={(e) =>
                        setSettings({ ...settings, businessName: e.target.value })
                      }
                    />
                  </div>
                  <div className="bk-field">
                    <label htmlFor="business_category">Category</label>
                    <input
                      id="business_category"
                      type="text"
                      value={settings.businessCategory}
                      placeholder="Restaurant, salon, store…"
                      onChange={(e) =>
                        setSettings({ ...settings, businessCategory: e.target.value })
                      }
                    />
                  </div>
                  <div className="bk-field">
                    <label htmlFor="business_phone">Phone</label>
                    <input
                      id="business_phone"
                      type="text"
                      value={settings.businessPhone}
                      placeholder="+1 555 0100"
                      onChange={(e) =>
                        setSettings({ ...settings, businessPhone: e.target.value })
                      }
                    />
                  </div>
                  <div className="bk-field">
                    <label htmlFor="business_address">Address</label>
                    <textarea
                      id="business_address"
                      rows={3}
                      value={settings.businessAddress}
                      placeholder="123 Main Street, City"
                      onChange={(e) =>
                        setSettings({ ...settings, businessAddress: e.target.value })
                      }
                    />
                  </div>
                  <div className="bk-field">
                    <label htmlFor="business_hours">Hours</label>
                    <input
                      id="business_hours"
                      type="text"
                      value={settings.businessHours}
                      placeholder="Mon–Fri 9:00–18:00"
                      onChange={(e) =>
                        setSettings({ ...settings, businessHours: e.target.value })
                      }
                    />
                  </div>
                  <div className="bk-field">
                    <label htmlFor="business_image">Business photo URL</label>
                    <input
                      id="business_image"
                      type="url"
                      value={settings.businessImageUrl}
                      placeholder="https://…"
                      onChange={(e) =>
                        setSettings({ ...settings, businessImageUrl: e.target.value })
                      }
                    />
                    <p className="description">
                      Cover-style photo for the listing preview. Media library upload comes next.
                    </p>
                  </div>
                </div>

                <div className="bk-seo-preview-wrap">
                  <p className="bk-seo-preview__label">Google Business preview</p>
                  <div className="bk-gbp-preview">
                    <div
                      className={`bk-gbp-preview__cover${
                        settings.businessImageUrl.trim() ? ' has-image' : ''
                      }`}
                    >
                      {settings.businessImageUrl.trim() ? (
                        <img src={settings.businessImageUrl.trim()} alt="" />
                      ) : (
                        <span className="bk-gbp-preview__cover-placeholder">+</span>
                      )}
                    </div>
                    <div className="bk-gbp-preview__body">
                      <p className="bk-gbp-preview__name">
                        {settings.businessName.trim() ||
                          settings.title.trim() ||
                          'Your business'}
                      </p>
                      <p className="bk-gbp-preview__category">
                        {settings.businessCategory.trim() || 'Local business'}
                      </p>
                      <ul className="bk-gbp-preview__meta">
                        <li>
                          {settings.businessAddress.trim() || 'Add your address'}
                        </li>
                        <li>
                          {settings.businessPhone.trim() || 'Add your phone number'}
                        </li>
                        <li>
                          {settings.businessHours.trim() || 'Add opening hours'}
                        </li>
                        <li className="bk-gbp-preview__website">
                          {typeof window !== 'undefined'
                            ? window.location.hostname
                            : 'yoursite.com'}
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <p className="submit" style={{ margin: 0 }}>
            <button type="submit" className="button button-primary" disabled={busy}>
              {busy ? 'Saving…' : 'Save changes'}
            </button>
          </p>
        </form>
      )}

      {tab === 'reading' && settings && (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Reading</h2>
          </div>
          <div className="bk-panel__body">
            <form
              onSubmit={(e) => void saveSettings(e, { blogPublic: settings.blogPublic })}
            >
              <table className="form-table">
                <tbody>
                  <tr>
                    <th scope="row">Search visibility</th>
                    <td>
                      <label className="bk-check">
                        <input
                          type="checkbox"
                          checked={settings.blogPublic}
                          onChange={(e) =>
                            setSettings({ ...settings, blogPublic: e.target.checked })
                          }
                        />
                        <span className="bk-check__box" aria-hidden />
                        <span className="bk-check__label">
                          Allow search engines to index this site
                        </span>
                      </label>
                      <div className="bk-help" style={{ marginTop: 12 }}>
                        <p style={{ margin: 0 }}>
                          <strong>Checked (recommended for live sites):</strong> Google, Bing, and
                          other search engines can find and list your pages.
                        </p>
                        <p style={{ margin: '8px 0 0' }}>
                          <strong>Unchecked:</strong> Beekiri tells crawlers not to index the site
                          (useful while you build or for private staging). Your site still works —
                          visitors can open links — it just stays out of search results as much as
                          crawlers respect the request.
                        </p>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
              <p className="submit">
                <button type="submit" className="button button-primary" disabled={busy}>
                  {busy ? 'Saving…' : 'Save changes'}
                </button>
              </p>
            </form>
          </div>
        </div>
      )}

      {tab === 'page-editor' && settings && (
        <form
          className="bk-stack"
          onSubmit={(e) =>
            void saveSettings(e, {
              pageEditorStyle: 'beekiricode',
              frontendRuntime: settings.frontendRuntime,
            })
          }
        >
          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Frontend layouts</h2>
            </div>
            <div className="bk-panel__body">
              <p className="bk-muted" style={{ marginTop: 0, marginBottom: 16 }}>
                How Backend Fields write layout files into the active theme. Admin stays on
                Beekiri either way.
              </p>
              <div className="bk-choice-grid" role="radiogroup" aria-label="Frontend layouts">
                {(
                  [
                    {
                      id: 'php' as const,
                      title: 'PHP / HTML',
                      blurb:
                        'AUK-style layouts (default). Folder per field group under themes/…/layouts/.',
                      files: [
                        'layouts/hero/hero.php',
                        'styles.scss',
                        'script.js',
                      ],
                    },
                    {
                      id: 'react' as const,
                      title: 'React',
                      blurb: 'Next theme components from field groups.',
                      files: [
                        'layouts/hero/hero.tsx',
                        'styles.scss',
                        'script.js',
                      ],
                    },
                  ] as const
                ).map((opt) => {
                  const selected = settings.frontendRuntime === opt.id;
                  return (
                    <label
                      key={opt.id}
                      className={`bk-choice-card${selected ? ' is-selected' : ''}`}
                    >
                      <input
                        type="radio"
                        name="frontend_runtime"
                        value={opt.id}
                        checked={selected}
                        onChange={() =>
                          setSettings({ ...settings, frontendRuntime: opt.id })
                        }
                      />
                      <span className="bk-choice-card__radio" aria-hidden />
                      <span className="bk-choice-card__body">
                        <span className="bk-choice-card__title">{opt.title}</span>
                        <span className="bk-choice-card__blurb">{opt.blurb}</span>
                        <span className="bk-choice-card__files">
                          {opt.files.map((f) => (
                            <code key={f}>{f}</code>
                          ))}
                        </span>
                      </span>
                    </label>
                  );
                })}
              </div>
              <p className="submit" style={{ marginBottom: 0 }}>
                <button type="submit" className="button button-primary" disabled={busy}>
                  {busy ? 'Saving…' : 'Save changes'}
                </button>
              </p>
            </div>
          </div>
        </form>
      )}

      {tab === 'writing' && settings && (
        <div className="bk-panel">
          <div className="bk-panel__head">
            <h2 className="bk-panel__title">Writing</h2>
          </div>
          <div className="bk-panel__body">
            <form
              onSubmit={(e) =>
                void saveSettings(e, {
                  dateFormat: settings.dateFormat,
                  timeFormat: settings.timeFormat,
                })
              }
            >
              <table className="form-table">
                <tbody>
                  <tr>
                    <th scope="row">
                      <label htmlFor="date_format">Date format</label>
                    </th>
                    <td>
                      <input
                        id="date_format"
                        className="regular-text"
                        value={settings.dateFormat}
                        onChange={(e) =>
                          setSettings({ ...settings, dateFormat: e.target.value })
                        }
                      />
                      <p className="description">Used when dates are shown in admin and themes.</p>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <label htmlFor="time_format">Time format</label>
                    </th>
                    <td>
                      <input
                        id="time_format"
                        className="regular-text"
                        value={settings.timeFormat}
                        onChange={(e) =>
                          setSettings({ ...settings, timeFormat: e.target.value })
                        }
                      />
                    </td>
                  </tr>
                </tbody>
              </table>
              <p className="submit">
                <button type="submit" className="button button-primary" disabled={busy}>
                  {busy ? 'Saving…' : 'Save changes'}
                </button>
              </p>
            </form>
          </div>
        </div>
      )}

      {tab === 'advanced' && settings && (
        <div className="bk-stack">
          <div className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Advanced</h2>
            </div>
            <div className="bk-panel__body">
              <form
                onSubmit={(e) =>
                  void saveSettings(e, {
                    language: settings.language,
                    timezone: settings.timezone,
                  })
                }
              >
                <table className="form-table">
                  <tbody>
                    <tr>
                      <th scope="row">
                        <label htmlFor="site_language">Site language</label>
                      </th>
                      <td>
                        <select
                          id="site_language"
                          value={settings.language}
                          onChange={(e) =>
                            setSettings({ ...settings, language: e.target.value })
                          }
                        >
                          <option value="en_US">English (United States)</option>
                          <option value="en_GB">English (UK)</option>
                          <option value="sq">Albanian</option>
                          <option value="de_DE">German</option>
                          <option value="fr_FR">French</option>
                          <option value="it_IT">Italian</option>
                        </select>
                      </td>
                    </tr>
                    <tr>
                      <th scope="row">
                        <label htmlFor="timezone_string">Timezone</label>
                      </th>
                      <td>
                        <select
                          id="timezone_string"
                          value={settings.timezone}
                          onChange={(e) =>
                            setSettings({ ...settings, timezone: e.target.value })
                          }
                        >
                          <option value="UTC">UTC</option>
                          <option value="Europe/London">Europe/London</option>
                          <option value="Europe/Berlin">Europe/Berlin</option>
                          <option value="Europe/Tirane">Europe/Tirane</option>
                          <option value="America/New_York">America/New_York</option>
                          <option value="America/Los_Angeles">America/Los_Angeles</option>
                        </select>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <p className="submit">
                  <button type="submit" className="button button-primary" disabled={busy}>
                    {busy ? 'Saving…' : 'Save changes'}
                  </button>
                </p>
              </form>
            </div>
          </div>
          <div className="bk-help">
            <strong>Tip:</strong> Changing language or timezone does not rewrite your content. It
            only affects how the admin and public site format dates and labels going forward.
          </div>
        </div>
      )}

      {tab === 'permalinks' && settings && (
        <PermalinksPanel
          key={`permalinks-${settings.id}-${settings.menuItems.map((m) => m.id).join('.')}`}
          siteTitle={settings.title}
          permalinkStructure={settings.permalinkStructure}
          permalinkCustom={settings.permalinkCustom}
          menuItems={settings.menuItems}
          busy={busy}
          onSave={(data) => {
            void (async () => {
              setBusy(true);
              setError(null);
              setNotice(null);
              try {
                const saved = await api<SiteSettings>('/api/site/settings', {
                  method: 'PATCH',
                  json: data,
                });
                setSettings({
                  ...settings,
                  ...saved,
                  menuItems: saved.menuItems?.length ? saved.menuItems : data.menuItems,
                  permalinkStructure: saved.permalinkStructure ?? data.permalinkStructure,
                  permalinkCustom: saved.permalinkCustom ?? data.permalinkCustom,
                });
                setNotice('Permalinks and menu saved.');
              } catch (err) {
                setError(err instanceof ApiError ? err.message : 'Save failed');
              } finally {
                setBusy(false);
              }
            })();
          }}
        />
      )}

      {tab === 'media' && settings && (
        <MediaSettingsPanel
          key={`media-${settings.id}-${settings.media.folders.map((f) => f.id).join('.')}`}
          media={settings.media}
          busy={busy}
          onSave={(media) => {
            void (async () => {
              setBusy(true);
              setError(null);
              setNotice(null);
              try {
                const saved = await api<SiteSettings>('/api/site/settings', {
                  method: 'PATCH',
                  json: { media },
                });
                setSettings({
                  ...settings,
                  media: saved.media ?? media,
                });
                setNotice('Media settings saved.');
              } catch (err) {
                setError(err instanceof ApiError ? err.message : 'Save failed');
              } finally {
                setBusy(false);
              }
            })();
          }}
        />
      )}

      {tab === 'core' && status && (
        <div className="bk-stack">
          {updateAvailable && updates?.latestVersion ? (
            <div className="beekiri-notice is-update" role="status">
              <p>
                You have a new update — Beekiri Core{' '}
                <strong>v{updates.latestVersion}</strong> is available. You are on{' '}
                <strong>v{updates.currentVersion}</strong>.
              </p>
            </div>
          ) : null}

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Status</h2>
              <button
                type="button"
                className="button button-primary"
                onClick={() => void refreshStatus()}
                disabled={refreshing}
              >
                {refreshing ? 'Refreshing…' : 'Refresh'}
              </button>
            </div>
            <div className="bk-panel__body">
              <ul className="bk-rows">
                <li className="bk-row">
                  <span className="bk-row__label">API server</span>
                  <span className="bk-row__value">
                    <StatusValue ok={status.api.ok} label={status.api.label} />
                    {status.apiStack ? (
                      <span className="bk-muted"> · {status.apiStack}</span>
                    ) : null}
                  </span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Frontend</span>
                  <span className="bk-row__value">{status.frontend ?? '—'}</span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Admin</span>
                  <span className="bk-row__value">{status.admin ?? '—'}</span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Database</span>
                  <span className="bk-row__value">
                    <StatusValue ok={status.database.ok} label={status.database.label} />
                    {status.databaseEngine ? (
                      <span className="bk-muted"> · {status.databaseEngine}</span>
                    ) : null}
                  </span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Uptime</span>
                  <span className="bk-row__value">{formatUptime(status.uptimeSeconds)}</span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Environment</span>
                  <span className="bk-row__value">{status.environment}</span>
                </li>
              </ul>
            </div>
          </section>

          <section className="bk-panel">
            <div className="bk-panel__head">
              <h2 className="bk-panel__title">Version</h2>
              {updateAvailable ? <span className="bk-count">+{updateCount}</span> : null}
            </div>
            <div className="bk-panel__body">
              <ul className="bk-rows">
                <li className="bk-row">
                  <span className="bk-row__label">Beekiri Core</span>
                  <span className="bk-row__value">
                    <strong>v{status.coreVersion}</strong>
                    <span className="bk-badge">{status.channel}</span>
                    {updateAvailable && updates?.latestVersion ? (
                      <span className="bk-badge is-update">
                        → v{updates.latestVersion}
                      </span>
                    ) : null}
                  </span>
                </li>
                <li className="bk-row">
                  <span className="bk-row__label">Node.js</span>
                  <span className="bk-row__value">{status.nodeVersion}</span>
                </li>
              </ul>

              <div className="bk-actions">
                <button
                  type="button"
                  className="button button-primary"
                  onClick={() => void checkUpdates()}
                  disabled={coreUpdate.checking}
                >
                  {coreUpdate.checking ? 'Checking…' : 'Check for updates'}
                </button>
              </div>

              {updates && !updateAvailable ? (
                <div className="bk-help">
                  <p style={{ margin: 0 }}>
                    <strong>You&apos;re up to date</strong> — Beekiri Core v{updates.currentVersion}.
                  </p>
                  <p className="bk-muted" style={{ margin: '8px 0 0' }}>
                    When a new version is ready, you&apos;ll see a <strong>+1</strong> on Settings.
                    Just click <strong>Check for updates</strong>, then <strong>Update</strong> —
                    your site content stays as it is.
                  </p>
                </div>
              ) : null}

              {updates && updateAvailable ? (
                <div className="bk-help" style={{ marginTop: 14 }}>
                  <p style={{ margin: 0 }}>
                    <strong>Update available</strong> — Beekiri Core v{updates.latestVersion}{' '}
                    (you&apos;re on v{updates.currentVersion}).
                  </p>
                  <p className="bk-muted" style={{ margin: '8px 0 0' }}>
                    Click <strong>Update</strong> below. Your pages, media, and settings stay on
                    this site — nothing to install by hand.
                  </p>
                  <div
                    className="bk-actions"
                    style={{ marginTop: 12, paddingTop: 0, borderTop: 'none' }}
                  >
                    {updates.downloadUrl ? (
                      <a
                        className="button button-primary"
                        href={updates.downloadUrl}
                        target="_blank"
                        rel="noreferrer"
                      >
                        Update to v{updates.latestVersion}
                      </a>
                    ) : null}
                    {updates.releaseUrl ? (
                      <a
                        className="button"
                        href={updates.releaseUrl}
                        target="_blank"
                        rel="noreferrer"
                      >
                        What&apos;s new
                      </a>
                    ) : null}
                  </div>
                </div>
              ) : null}
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
