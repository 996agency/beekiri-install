import { useEffect, useMemo, useRef, useState } from 'react';
import { api } from '../../api/client';
import { useAuth } from '../../auth/AuthContext';

export type PresencePeer = {
  userId: string;
  name: string;
  color: string;
  clientId: string;
};

type Props = {
  pageId: string;
};

function peerColor(userId: string): string {
  let hash = 0;
  for (let i = 0; i < userId.length; i++) {
    hash = (hash * 31 + userId.charCodeAt(i)) | 0;
  }
  const hue = ((hash % 360) + 360) % 360;
  return `hsl(${hue} 70% 45%)`;
}

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  if (parts.length === 1) return parts[0]!.slice(0, 1).toUpperCase();
  return `${parts[0]!.slice(0, 1)}${parts[1]!.slice(0, 1)}`.toUpperCase();
}

function clientIdForTab(): string {
  const key = 'bk-beekiricode-presence-client';
  try {
    const existing = sessionStorage.getItem(key);
    if (existing) return existing;
    const id = `c_${Math.random().toString(36).slice(2, 12)}`;
    sessionStorage.setItem(key, id);
    return id;
  } catch {
    return `c_${Math.random().toString(36).slice(2, 12)}`;
  }
}

/**
 * Live “who’s editing” stack — same idea as Instatic PeerAvatarStack.
 * Heartbeats this tab into the page presence room so 2–3 editors see each other.
 */
export function PeerAvatarStack({ pageId }: Props) {
  const auth = useAuth();
  const clientId = useMemo(() => clientIdForTab(), []);
  const [peers, setPeers] = useState<PresencePeer[]>([]);
  const leaveSent = useRef(false);

  useEffect(() => {
    if (!pageId || !auth.user) return;
    leaveSent.current = false;
    let cancelled = false;

    const beat = async () => {
      try {
        const res = await api<{ peers: PresencePeer[] }>(
          `/api/pages/${pageId}/presence`,
          {
            method: 'POST',
            json: { clientId },
          },
        );
        if (!cancelled) setPeers(res.peers ?? []);
      } catch {
        /* presence is best-effort */
      }
    };

    void beat();
    const timer = window.setInterval(() => void beat(), 4000);

    const onLeave = () => {
      if (leaveSent.current) return;
      leaveSent.current = true;
      void api(
        `/api/pages/${pageId}/presence?clientId=${encodeURIComponent(clientId)}`,
        { method: 'DELETE' },
      ).catch(() => undefined);
    };

    window.addEventListener('pagehide', onLeave);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
      window.removeEventListener('pagehide', onLeave);
      onLeave();
    };
  }, [pageId, clientId, auth.user]);

  const me = auth.user;
  const stack = useMemo(() => {
    const list: PresencePeer[] = peers.map((p) => ({ ...p }));
    if (me) {
      const self: PresencePeer = {
        userId: me.id,
        name: me.displayName?.trim() || me.username,
        color: peerColor(me.id),
        clientId,
      };
      if (!list.some((p) => p.userId === me.id)) list.unshift(self);
      else {
        // Put me first for stable “you + others” reading.
        const idx = list.findIndex((p) => p.userId === me.id);
        if (idx > 0) {
          const [mine] = list.splice(idx, 1);
          if (mine) list.unshift(mine);
        }
      }
    }
    return list.slice(0, 5);
  }, [peers, me, clientId]);

  if (stack.length === 0) return null;

  const label =
    stack.length === 1
      ? `${stack[0]!.name} (you)`
      : `${stack.length} editing — ${stack.map((p) => p.name).join(', ')}`;

  return (
    <div
      className="bk-beekiricode__peer-stack"
      role="group"
      aria-label={label}
      title={label}
    >
      {stack.map((peer) => {
        const isMe = me?.id === peer.userId;
        return (
          <span
            key={peer.userId}
            className="bk-beekiricode__peer-avatar"
            style={{ ['--peer-color' as string]: peer.color }}
            title={isMe ? `${peer.name} (you)` : peer.name}
          >
            <span className="bk-beekiricode__peer-initials" aria-hidden>
              {initials(peer.name)}
            </span>
          </span>
        );
      })}
    </div>
  );
}
