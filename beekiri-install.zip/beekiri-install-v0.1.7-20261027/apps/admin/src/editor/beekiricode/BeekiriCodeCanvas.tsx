import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type JSX,
  type MouseEvent,
  type ReactNode,
} from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowSquareOut,
  CaretDown,
  CloudArrowUp,
  Code,
  Cursor,
  Desktop,
  DeviceMobile,
  DeviceTablet,
  Eye,
  GearSix,
  MagnifyingGlassMinus,
  MagnifyingGlassPlus,
  SquaresFour,
  Trash,
} from '@phosphor-icons/react';
import { api, apiUrl } from '../../api/client';
import {
  createLayoutNode,
  findParentId,
  moveNode,
  removeNode,
  stripLayoutChromeStyles,
  type BeekiriCodeNode,
  type BeekiriCodePageDoc,
  type MovePosition,
} from './document';
import { LayersTree } from './LayersTree';
import { LayoutPhpPreview } from './LayoutPhpPreview';
import { PeerAvatarStack } from './PeerAvatarStack';
import { PropertiesPanel } from './PropertiesPanel';
import { collectDocumentColors } from './inspector/css-values';
import {
  editTargetForViewMode,
  resolveStyleForBreakpoint,
} from './responsiveStyles';
import './beekiricode.css';
import { initialValue, typeDef, type BackendField } from '../../fields/acf-types';

type ThemeLayout = {
  slug: string;
  title: string;
  key: string;
  fields: BackendField[];
  cssUrl: string;
};

const BREAKPOINTS = [
  { id: 'desktop', label: 'Desktop', width: 1520, Icon: Desktop },
  { id: 'tablet', label: 'Tablet', width: 768, Icon: DeviceTablet },
  { id: 'mobile', label: 'Mobile', width: 375, Icon: DeviceMobile },
] as const;

type BreakpointId = (typeof BREAKPOINTS)[number]['id'];
type ExplorerTab = 'layers' | 'layouts' | 'properties';
type CanvasMode = 'select' | 'preview' | 'code';
type ViewMode = 'multi' | BreakpointId;

type Props = {
  pageId: string;
  title: string;
  slug?: string;
  permalinkBase?: string;
  isPublished?: boolean;
  doc: BeekiriCodePageDoc;
  onChange: (doc: BeekiriCodePageDoc) => void;
  busy?: boolean;
  canPublish?: boolean;
  isDirty?: boolean;
  onSaveDraft: () => void;
  onPublish: () => void;
  onOpenSettings: () => void;
  onPreview?: () => void;
};

function cloneDoc(doc: BeekiriCodePageDoc): BeekiriCodePageDoc {
  return JSON.parse(JSON.stringify(doc)) as BeekiriCodePageDoc;
}

export function BeekiriCodeCanvas({
  pageId,
  title,
  slug = '',
  permalinkBase = '',
  isPublished = false,
  doc,
  onChange,
  busy,
  canPublish,
  isDirty,
  onSaveDraft,
  onPublish,
  onOpenSettings,
  onPreview,
}: Props) {
  const [selectedId, setSelectedId] = useState<string | null>(doc.rootId);
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [explorerTab, setExplorerTab] = useState<ExplorerTab>('layers');
  const [canvasMode, setCanvasMode] = useState<CanvasMode>('select');
  /** Default: first breakpoint (Desktop 1520) only — closer zoom than multi. */
  const [viewMode, setViewMode] = useState<ViewMode>('desktop');
  const [viewportOpen, setViewportOpen] = useState(false);
  const [publishOpen, setPublishOpen] = useState(false);
  const [zoomOverride, setZoomOverride] = useState<number | null>(null);
  const [themeLayouts, setThemeLayouts] = useState<ThemeLayout[]>([]);
  /** Edit mode only: ghost-render nodes hidden on the current breakpoint. */
  const [showHidden, setShowHidden] = useState(false);
  const documentColors = useMemo(
    () =>
      collectDocumentColors(
        Object.values(doc.nodes).flatMap((n) => [
          n.style,
          n.stylesByBreakpoint?.tablet,
          n.stylesByBreakpoint?.mobile,
        ]),
      ),
    [doc.nodes],
  );
  const publishRef = useRef<HTMLDivElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    api<{ layouts: ThemeLayout[] }>('/api/layouts')
      .then((res) => {
        if (!cancelled) setThemeLayouts(Array.isArray(res.layouts) ? res.layouts : []);
      })
      .catch(() => {
        if (!cancelled) setThemeLayouts([]);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Strip old scaffold padding on layouts + sync field keys from Backend Fields.
  useEffect(() => {
    const cleaned = stripLayoutChromeStyles(doc);
    let next = cleaned;
    let changed = cleaned !== doc;

    if (themeLayouts.length) {
      if (!changed) next = cloneDoc(doc);
      for (const node of Object.values(next.nodes)) {
        if (node.type !== 'layout' || !node.layoutSlug) continue;
        const def = themeLayouts.find((l) => l.slug === node.layoutSlug);
        if (!def?.fields?.length) continue;
        const fields = { ...(node.layoutFields || {}) };
        for (const f of def.fields) {
          if (typeDef(f.type).noValue || f.name in fields) continue;
          fields[f.name] = initialValue(f);
          changed = true;
        }
        node.layoutFields = fields;
        if (def.title && node.layoutTitle !== def.title) {
          node.layoutTitle = def.title;
          changed = true;
        }
      }
    }
    if (changed) onChange(next);
    // Only on mount / layout defs — not every doc keystroke.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [themeLayouts]);

  const syncLabel = busy ? 'Saving…' : isDirty ? 'Draft' : 'Draft synced';
  const syncOk = !busy && !isDirty;

  /** Preview / live = single first screen; multi only when explicitly chosen. */
  const effectiveViewMode: ViewMode =
    canvasMode === 'preview'
      ? viewMode === 'multi'
        ? 'desktop'
        : viewMode
      : viewMode;

  const visibleFrames = useMemo(() => {
    if (effectiveViewMode === 'multi') return [...BREAKPOINTS];
    return BREAKPOINTS.filter((b) => b.id === effectiveViewMode);
  }, [effectiveViewMode]);

  const activeBreakpoint =
    effectiveViewMode === 'multi'
      ? BREAKPOINTS[0]
      : BREAKPOINTS.find((b) => b.id === effectiveViewMode) ?? BREAKPOINTS[0];

  /** multi / desktop → default styles for all; tablet/mobile → overrides only */
  const styleEditTarget = editTargetForViewMode(
    canvasMode === 'preview' && viewMode === 'multi' ? 'desktop' : viewMode,
  );

  const zoom =
    zoomOverride ?? (canvasMode === 'preview' ? 90 : 85);

  useEffect(() => {
    const onDoc = (e: Event) => {
      const t = e.target as Node;
      if (publishRef.current && !publishRef.current.contains(t)) setPublishOpen(false);
      if (viewportRef.current && !viewportRef.current.contains(t)) setViewportOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);

  const updateNode = useCallback(
    (id: string, patch: Partial<BeekiriCodeNode>) => {
      const next = cloneDoc(doc);
      const node = next.nodes[id];
      if (!node) return;
      next.nodes[id] = { ...node, ...patch, id: node.id, type: node.type };
      onChange(next);
    },
    [doc, onChange],
  );

  const removeSelected = useCallback(
    (id: string) => {
      if (id === doc.rootId) return;
      const parentId = findParentId(doc, id);
      const next = removeNode(doc, id);
      if (!next) return;
      onChange(next);
      setSelectedId(parentId && next.nodes[parentId] ? parentId : next.rootId);
    },
    [doc, onChange],
  );

  const moveLayer = useCallback(
    (dragId: string, targetId: string, position: MovePosition) => {
      const next = moveNode(doc, dragId, targetId, position);
      if (!next) return;
      onChange(next);
      setSelectedId(dragId);
    },
    [doc, onChange],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (canvasMode !== 'select') return;
      const t = e.target as HTMLElement | null;
      if (
        t &&
        (t.tagName === 'INPUT' ||
          t.tagName === 'TEXTAREA' ||
          t.tagName === 'SELECT' ||
          t.isContentEditable)
      ) {
        return;
      }
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedId && selectedId !== doc.rootId) {
        e.preventDefault();
        removeSelected(selectedId);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [canvasMode, selectedId, doc.rootId, removeSelected]);

  const nestNode = useCallback(
    (node: BeekiriCodeNode) => {
      const next = cloneDoc(doc);
      next.nodes[node.id] = node;
      const parentId = selectedId && next.nodes[selectedId] ? selectedId : next.rootId;
      const parent = next.nodes[parentId];
      if (!parent) return;
      const nestTarget =
        parent.type === 'section' || parent.type === 'container'
          ? parent
          : (() => {
              const pid = findParentId(next, parentId);
              return pid ? next.nodes[pid] : next.nodes[next.rootId];
            })();
      if (!nestTarget) return;
      nestTarget.children = [...nestTarget.children, node.id];
      onChange(next);
      setSelectedId(node.id);
      setExplorerTab('layers');
    },
    [doc, onChange, selectedId],
  );

  const addThemeLayout = useCallback(
    (layout: ThemeLayout) => {
      nestNode(createLayoutNode(layout));
    },
    [nestNode],
  );

  const selectNode = (id: string) => {
    setSelectedId(id);
    setExplorerTab('properties');
  };

  const renderNode = (
    id: string,
    frame: 'desktop' | 'tablet' | 'mobile',
  ): ReactNode => {
    const node = doc.nodes[id];
    if (!node) return null;
    const interactive = canvasMode === 'select';
    const hiddenHere = node.hiddenOn?.includes(frame) ?? false;
    if (hiddenHere && !(interactive && showHidden)) return null;
    const selectedCls = selectedId === id ? ' is-selected' : '';
    const hoverCls = `${hoveredId === id ? ' is-hovered' : ''}${hiddenHere ? ' is-bp-hidden' : ''}`;
    const onSelect = (e: MouseEvent) => {
      if (!interactive) return;
      e.stopPropagation();
      selectNode(id);
    };
    const resolved = resolveStyleForBreakpoint(node, frame);
    const common = {
      className: `bk-beekiricode__node${selectedCls}${hoverCls}`,
      style: resolved as CSSProperties,
      onClick: onSelect,
      onMouseEnter: (e: MouseEvent) => {
        if (!interactive) return;
        e.stopPropagation();
        setHoveredId(id);
      },
      onMouseLeave: () => setHoveredId(null),
    };

    if (node.type === 'image') {
      return (
        <div key={`${frame}-${id}`} {...common}>
          {node.src ? (
            <img src={node.src} alt={node.alt || ''} style={{ width: '100%', display: 'block' }} />
          ) : (
            <div className="bk-beekiricode__empty-img">Image — set URL in Properties</div>
          )}
        </div>
      );
    }

    if (node.type === 'layout') {
      const slug = node.layoutSlug || 'layout';
      return (
        <LayoutPhpPreview
          key={`${frame}-${id}`}
          slug={slug}
          fields={node.layoutFields || {}}
          selected={selectedId === id}
          hovered={hoveredId === id}
          interactive={interactive}
          style={resolved as CSSProperties}
          className={hiddenHere ? 'is-bp-hidden' : undefined}
          onSelect={onSelect}
          onHover={(e) => {
            if (!interactive) return;
            e.stopPropagation();
            setHoveredId(id);
          }}
          onLeave={() => setHoveredId(null)}
        />
      );
    }

    if (node.type === 'heading' || node.type === 'text' || node.type === 'button') {
      const Tag = (node.tag ||
        (node.type === 'heading' ? 'h2' : node.type === 'button' ? 'a' : 'p')) as keyof JSX.IntrinsicElements;
      return (
        <Tag
          key={`${frame}-${id}`}
          {...common}
          href={node.type === 'button' ? node.href || '#' : undefined}
          onDoubleClick={(e) => {
            if (!interactive) return;
            e.stopPropagation();
            const next = window.prompt('Edit text', node.text || '');
            if (next !== null) updateNode(id, { text: next });
          }}
        >
          {node.text}
          {node.children.map((cid) => renderNode(cid, frame))}
        </Tag>
      );
    }

    const Tag = (node.tag || 'div') as keyof JSX.IntrinsicElements;
    return (
      <Tag key={`${frame}-${id}`} {...common}>
        {node.children.map((cid) => renderNode(cid, frame))}
      </Tag>
    );
  };

  const scale = zoom / 100;
  const pageLabel = title.trim() || 'Untitled';
  const pathLabel = slug ? `/${slug}` : '/';
  const liveHref =
    isPublished && slug && permalinkBase
      ? `${permalinkBase.replace(/\/$/, '')}/${slug}`
      : null;
  const selectedNode = selectedId ? doc.nodes[selectedId] ?? null : null;
  const isPageRoot = Boolean(selectedId && selectedId === doc.rootId);
  const selectedLayoutDef =
    selectedNode?.type === 'layout' && selectedNode.layoutSlug
      ? themeLayouts.find((l) => l.slug === selectedNode.layoutSlug)
      : undefined;

  return (
    <div className="bk-beekiricode">
      {/* Theme layout CSS — same sheets as the public site */}
      {themeLayouts.map((layout) => (
        <link
          key={layout.slug}
          rel="stylesheet"
          href={apiUrl(layout.cssUrl)}
        />
      ))}
      {/* ── Top toolbar (BeekiriCode) ─────────────────────────────── */}
      <header className="bk-beekiricode__toolbar">
        <Link
          to="/admin/pages"
          className="bk-beekiricode__back"
          title="Back to Pages"
          aria-label="Back to Pages"
        >
          <ArrowLeft size={16} weight="regular" aria-hidden />
          <span>Back</span>
        </Link>
        <div className="bk-beekiricode__context">
          <span className="bk-beekiricode__nav-hint">
            Editing page <strong>{pageLabel}</strong>
          </span>
          {liveHref ? (
            <a
              className="bk-beekiricode__permalink"
              href={liveHref}
              target="_blank"
              rel="noreferrer"
              title={`Open live page ${pathLabel}`}
            >
              <span className="bk-beekiricode__permalink-path">{pathLabel}</span>
              <ArrowSquareOut size={14} weight="regular" aria-hidden />
            </a>
          ) : (
            <span
              className="bk-beekiricode__permalink is-draft"
              title="Publish the page to open the live permalink"
            >
              <span className="bk-beekiricode__permalink-path">{pathLabel}</span>
              <span className="bk-beekiricode__permalink-badge">Draft</span>
            </span>
          )}
        </div>
        <div className="bk-beekiricode__toolbar-spacer" />

        <PeerAvatarStack pageId={pageId} />

        <div className="bk-beekiricode__zoom-group">
          <button
            type="button"
            className="bk-beekiricode__icon-btn"
            title="Zoom out"
            onClick={() => setZoomOverride(Math.max(30, zoom - 10))}
          >
            <MagnifyingGlassMinus size={16} weight="regular" aria-hidden />
          </button>
          <span className="bk-beekiricode__zoom">{zoom}%</span>
          <button
            type="button"
            className="bk-beekiricode__icon-btn"
            title="Zoom in"
            onClick={() => setZoomOverride(Math.min(120, zoom + 10))}
          >
            <MagnifyingGlassPlus size={16} weight="regular" aria-hidden />
          </button>
        </div>

        <span className={`bk-beekiricode__sync${syncOk ? ' is-ok' : ''}`}>
          <span className="bk-beekiricode__sync-dot" aria-hidden />
          {syncLabel}
        </span>

        <div className="bk-beekiricode__publish" ref={publishRef}>
          <button
            type="button"
            className="bk-beekiricode__publish-main"
            disabled={busy || !canPublish}
            onClick={onPublish}
          >
            <CloudArrowUp size={16} weight="regular" aria-hidden />
            Publish
          </button>
          <button
            type="button"
            className="bk-beekiricode__publish-caret"
            aria-label="Publish options"
            aria-expanded={publishOpen}
            disabled={busy}
            onClick={() => setPublishOpen((v) => !v)}
          >
            <CaretDown size={12} weight="regular" aria-hidden />
          </button>
          {publishOpen ? (
            <div className="bk-beekiricode__menu" role="menu">
              <button
                type="button"
                className="bk-beekiricode__menu-item"
                role="menuitem"
                onClick={() => {
                  setPublishOpen(false);
                  onSaveDraft();
                }}
              >
                Save draft
              </button>
              <button
                type="button"
                className="bk-beekiricode__menu-item"
                role="menuitem"
                disabled={!onPreview}
                onClick={() => {
                  setPublishOpen(false);
                  onPreview?.();
                }}
              >
                <Eye size={16} weight="regular" aria-hidden /> Preview page
              </button>
              <button
                type="button"
                className="bk-beekiricode__menu-item"
                role="menuitem"
                onClick={() => {
                  setPublishOpen(false);
                  onOpenSettings();
                }}
              >
                Version history…
              </button>
            </div>
          ) : null}
        </div>

        <button
          type="button"
          className="bk-beekiricode__icon-btn"
          title="Page settings"
          onClick={onOpenSettings}
        >
          <GearSix size={16} weight="regular" aria-hidden />
        </button>
      </header>

      <div className="bk-beekiricode__workspace">
        {/* ── Left Explorer ──────────────────────────────────────────── */}
        <aside className="bk-beekiricode__explorer" aria-label="Explorer">
          <div className="bk-beekiricode__explorer-head">
            <span>Explorer</span>
          </div>
          <div
            className="bk-beekiricode__tabs bk-beekiricode__tabs--3"
            role="tablist"
            aria-label="Explorer tabs"
          >
            {(
              [
                ['layers', 'Layers'],
                ['layouts', 'Layouts'],
                ['properties', 'Props'],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={explorerTab === id}
                className={`bk-beekiricode__tab${explorerTab === id ? ' is-active' : ''}`}
                onClick={() => setExplorerTab(id)}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="bk-beekiricode__explorer-body">
            {explorerTab === 'layers' ? (
              <div className="bk-beekiricode__layers">
                <input
                  className="bk-beekiricode__search"
                  placeholder="Search layers…"
                  aria-label="Search layers"
                  onChange={() => {
                    /* visual parity for now */
                  }}
                />
                <LayersTree
                  doc={doc}
                  selectedId={selectedId}
                  onSelect={selectNode}
                  onRemove={removeSelected}
                  onMove={moveLayer}
                />
                {selectedId && selectedId !== doc.rootId ? (
                  <div className="bk-beekiricode__layers-actions">
                    <button
                      type="button"
                      className="bk-beekiricode__layers-remove"
                      onClick={() => removeSelected(selectedId)}
                    >
                      <Trash size={14} weight="bold" aria-hidden />
                      Remove selected
                    </button>
                    <span className="bk-beekiricode__layers-hint">
                      Drag layers to reorder · Delete key removes
                    </span>
                  </div>
                ) : (
                  <p className="bk-beekiricode__layers-hint">
                    Drag layers to reorder. Select a layer to remove it.
                  </p>
                )}
              </div>
            ) : null}

            {explorerTab === 'properties' ? (
              <div className="bk-beekiricode__props-tab">
                <PropertiesPanel
                  variant="embedded"
                  node={selectedNode}
                  isPageRoot={isPageRoot}
                  editTarget={styleEditTarget}
                  layoutFieldDefs={selectedLayoutDef?.fields}
                  documentColors={documentColors}
                  showHidden={showHidden}
                  onShowHiddenChange={setShowHidden}
                  onSelectPage={() => {
                    setSelectedId(doc.rootId);
                    setExplorerTab('properties');
                  }}
                  onUpdate={(patch) => {
                    if (!selectedId) return;
                    updateNode(selectedId, patch);
                  }}
                />
              </div>
            ) : null}

            {explorerTab === 'layouts' ? (
              <div className="bk-beekiricode__add-grid">
                <p className="bk-beekiricode__add-hint">
                  Layouts (Backend Fields → layouts/)
                </p>
                {themeLayouts.length === 0 ? (
                  <p className="bk-beekiricode__add-empty">
                    No layouts yet. Create a field group in Backend Fields and save — a folder appears under themes/beekiri/layouts/.
                  </p>
                ) : (
                  themeLayouts.map((layout) => (
                    <button
                      key={layout.slug}
                      type="button"
                      className="bk-beekiricode__module"
                      onClick={() => addThemeLayout(layout)}
                      title={layout.key}
                    >
                      {layout.title}
                    </button>
                  ))
                )}
              </div>
            ) : null}
          </div>
        </aside>

        {/* ── Canvas stage ───────────────────────────────────────────── */}
        <div className="bk-beekiricode__stage">
          <div className="bk-beekiricode__canvas-tools">
            <div className="bk-beekiricode__mode-pill" role="group" aria-label="Canvas mode">
              <button
                type="button"
                className={`bk-beekiricode__mode-btn${canvasMode === 'select' ? ' is-active' : ''}`}
                aria-pressed={canvasMode === 'select'}
                title="Select"
                onClick={() => {
                  setCanvasMode('select');
                  setZoomOverride(null);
                }}
              >
                <Cursor size={16} weight="regular" aria-hidden />
              </button>
              <button
                type="button"
                className={`bk-beekiricode__mode-btn${canvasMode === 'preview' ? ' is-active' : ''}`}
                aria-pressed={canvasMode === 'preview'}
                title="Preview — Desktop only, zoomed in"
                onClick={() => {
                  setCanvasMode('preview');
                  if (viewMode === 'multi') setViewMode('desktop');
                  setZoomOverride(null);
                }}
              >
                <Eye size={16} weight="regular" aria-hidden />
              </button>
              <span className="bk-beekiricode__mode-sep" aria-hidden />
              <button
                type="button"
                className={`bk-beekiricode__mode-btn${canvasMode === 'code' ? ' is-active' : ''}`}
                aria-pressed={canvasMode === 'code'}
                title="Code"
                onClick={() => setCanvasMode('code')}
              >
                <Code size={16} weight="regular" aria-hidden />
              </button>
            </div>

            <div className="bk-beekiricode__viewport" ref={viewportRef}>
              <button
                type="button"
                className="bk-beekiricode__viewport-btn"
                aria-expanded={viewportOpen}
                onClick={() => setViewportOpen((v) => !v)}
              >
                <activeBreakpoint.Icon size={16} weight="regular" aria-hidden />
                {activeBreakpoint.label}
                <CaretDown size={12} weight="regular" aria-hidden />
              </button>
              <button
                type="button"
                className={`bk-beekiricode__viewport-multi${
                  viewMode === 'multi' && canvasMode !== 'preview' ? ' is-active' : ''
                }`}
                title="Show all breakpoints"
                aria-pressed={viewMode === 'multi' && canvasMode !== 'preview'}
                onClick={() => {
                  setCanvasMode('select');
                  setViewMode((m) => (m === 'multi' ? 'desktop' : 'multi'));
                  setZoomOverride(null);
                }}
              >
                <SquaresFour size={16} weight="regular" aria-hidden />
              </button>
              {viewportOpen ? (
                <div className="bk-beekiricode__menu bk-beekiricode__menu--viewport" role="menu">
                  {BREAKPOINTS.map((bp) => (
                    <button
                      key={bp.id}
                      type="button"
                      role="menuitem"
                      className={`bk-beekiricode__menu-item${
                        effectiveViewMode === bp.id ? ' is-active' : ''
                      }`}
                      onClick={() => {
                        setViewMode(bp.id);
                        setCanvasMode('select');
                        setZoomOverride(null);
                        setViewportOpen(false);
                      }}
                    >
                      <bp.Icon size={16} weight="regular" aria-hidden />
                      <span>{bp.label}</span>
                      <span className="bk-beekiricode__menu-meta">{bp.width}px</span>
                    </button>
                  ))}
                  <div className="bk-beekiricode__menu-sep" />
                  <button
                    type="button"
                    role="menuitem"
                    className={`bk-beekiricode__menu-item${
                      viewMode === 'multi' && canvasMode !== 'preview' ? ' is-active' : ''
                    }`}
                    onClick={() => {
                      setViewMode('multi');
                      setCanvasMode('select');
                      setZoomOverride(null);
                      setViewportOpen(false);
                    }}
                  >
                    <SquaresFour size={16} weight="regular" aria-hidden />
                    All breakpoints
                  </button>
                </div>
              ) : null}
            </div>
          </div>

          {canvasMode === 'code' ? (
            <pre className="bk-beekiricode__code">
              {JSON.stringify(doc, null, 2)}
            </pre>
          ) : (
            <div
              className={`bk-beekiricode__frames-scroll${
                visibleFrames.length === 1 ? ' is-single' : ''
              }`}
            >
              <div
                className="bk-beekiricode__frames"
                style={{
                  transform: `scale(${scale})`,
                  transformOrigin: visibleFrames.length === 1 ? 'top center' : 'top left',
                }}
              >
                {visibleFrames.map((bp) => (
                  <div key={bp.id} className="bk-beekiricode__frame">
                    <div className="bk-beekiricode__frame-label">
                      {bp.label} · {bp.width}
                      {styleEditTarget === bp.id ? ' · editing overrides' : null}
                      {styleEditTarget === 'base' && viewMode !== 'multi'
                        ? ' · editing default'
                        : null}
                    </div>
                    <div className="bk-beekiricode__frame-chrome" style={{ width: bp.width }}>
                      <div
                        className={`bk-beekiricode__frame-canvas${
                          canvasMode === 'preview' ? ' is-preview' : ''
                        }`}
                        style={{ width: bp.width, minHeight: 900 }}
                        onClick={() => {
                          if (canvasMode === 'select') selectNode(doc.rootId);
                        }}
                      >
                        {renderNode(doc.rootId, bp.id)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
