import { useEffect } from 'react';
import { api } from '../api/client';

const DEFAULT_FAVICON = '/beekiri-logo.png';

function applyFavicon(href: string) {
  const url = href.trim() || DEFAULT_FAVICON;
  const links = document.querySelectorAll<HTMLLinkElement>('link[rel*="icon"]');
  if (links.length === 0) {
    const link = document.createElement('link');
    link.rel = 'icon';
    link.type = 'image/png';
    link.href = url;
    document.head.appendChild(link);
    return;
  }
  for (const link of links) {
    link.href = url;
    if (!link.type) link.type = 'image/png';
  }
}

/** Keeps admin tab favicon in sync with Settings → General (default: Beekiri logo). */
export function SiteFavicon() {
  useEffect(() => {
    applyFavicon(DEFAULT_FAVICON);
    let cancelled = false;
    api<{ faviconResolved?: string; faviconUrl?: string }>('/api/site/settings')
      .then((s) => {
        if (cancelled) return;
        applyFavicon(s.faviconResolved || s.faviconUrl || DEFAULT_FAVICON);
      })
      .catch(() => {
        /* keep default */
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return null;
}
