import type { CSSProperties, ReactNode } from 'react';
import type { Config, Field } from '@beekiri/beekiricanva';
import type { BeekiriBlocks } from './config';

export type LayoutFieldDef = {
  id: string;
  type: string;
  label: string;
  name: string;
  required?: boolean;
  instructions?: string;
  choices?: string[];
  defaultValue?: string;
};

export type LayoutDef = {
  slug: string;
  title: string;
  key: string;
  fields: LayoutFieldDef[];
  cssUrl: string;
  componentName: string;
};

function fieldToBeekiri(field: LayoutFieldDef): Field {
  const label = field.label || field.name;
  switch (field.type) {
    case 'textarea':
      return { type: 'textarea', label };
    case 'number':
      return { type: 'number', label };
    case 'email':
    case 'url':
      return { type: 'text', label, placeholder: field.type === 'url' ? 'https://…' : undefined };
    case 'date':
      return { type: 'text', label, placeholder: 'YYYY-MM-DD' };
    case 'image':
      // Admin swaps this for the media picker via metadata.beekiriKind.
      return {
        type: 'text',
        label,
        metadata: { beekiriKind: 'image' },
      };
    case 'select':
      return {
        type: 'select',
        label,
        options: (field.choices?.length ? field.choices : ['Option']).map((c) => ({
          label: c,
          value: c,
        })),
      };
    case 'true_false':
      return {
        type: 'radio',
        label,
        options: [
          { label: 'Yes', value: 'true' },
          { label: 'No', value: 'false' },
        ],
      };
    default:
      return { type: 'text', label };
  }
}

function looksLikeImageUrl(value: string) {
  return (
    /^https?:\/\//i.test(value) ||
    value.startsWith('/') ||
    value.startsWith('data:image') ||
    /\.(png|jpe?g|gif|webp|svg|avif)(\?|$)/i.test(value)
  );
}

function LayoutRender({
  slug,
  fields,
  props,
}: {
  slug: string;
  fields: LayoutFieldDef[];
  props: Record<string, unknown>;
}) {
  return (
    <section
      className={`bk-layout bk-layout--${slug}`}
      data-layout={slug}
      style={{ boxSizing: 'border-box', width: '100%' } satisfies CSSProperties}
    >
      {fields.length === 0 ? (
        <div className="bk-layout__placeholder">Add fields to this layout in Backend Fields.</div>
      ) : (
        fields.map((f) => {
          const value = props[f.name];
          if (value == null || value === '' || value === false) return null;

          if (f.type === 'image' && typeof value === 'string' && looksLikeImageUrl(value)) {
            return (
              <div key={f.name} className={`bk-layout__field bk-layout__field--${f.name} bk-layout__field--image`}>
                {/* Explicit dimensions avoid CLS; CSS can still scale with max-width */}
                <img
                  src={value}
                  alt=""
                  width={1200}
                  height={675}
                  loading="lazy"
                  decoding="async"
                  style={{ maxWidth: '100%', height: 'auto', display: 'block' }}
                />
              </div>
            );
          }

          const text =
            typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean'
              ? String(value)
              : (value as ReactNode);
          return (
            <div key={f.name} className={`bk-layout__field bk-layout__field--${f.name}`}>
              {text}
            </div>
          );
        })
      )}
    </section>
  );
}

/** Merge theme layouts (from Backend Fields) into the Beekiricanva config. */
export function withLayouts(
  base: Config<BeekiriBlocks>,
  layouts: LayoutDef[],
): Config {
  if (!layouts.length) return base as Config;

  const components: Config['components'] = { ...(base.components || {}) };
  const layoutNames: string[] = [];

  for (const layout of layouts) {
    const name = layout.componentName || toComponentName(layout.slug);
    layoutNames.push(name);
    const fields: Record<string, Field> = {};
    const defaultProps: Record<string, string> = {};
    for (const f of layout.fields) {
      fields[f.name] = fieldToBeekiri(f);
      defaultProps[f.name] =
        f.defaultValue ||
        (f.type === 'true_false' ? 'false' : f.type === 'select' ? f.choices?.[0] || '' : '');
    }
    components[name] = {
      label: layout.title || name,
      fields,
      defaultProps,
      render: (props) => (
        <LayoutRender slug={layout.slug} fields={layout.fields} props={props as Record<string, unknown>} />
      ),
    };
  }

  return {
    ...base,
    categories: {
      ...(base.categories || {}),
      layouts: {
        title: 'Layouts',
        components: layoutNames,
      },
    },
    components,
  };
}

export function toComponentName(slug: string): string {
  return (
    slug
      .split(/[_-]+/)
      .filter(Boolean)
      .map((p) => p.charAt(0).toUpperCase() + p.slice(1))
      .join('') || 'Layout'
  );
}

/** Inject layout CSS once per slug into document head. */
export function ensureLayoutStyles(layouts: LayoutDef[], apiBase: string) {
  if (typeof document === 'undefined') return;
  for (const layout of layouts) {
    const id = `bk-layout-css-${layout.slug}`;
    if (document.getElementById(id)) continue;
    const link = document.createElement('link');
    link.id = id;
    link.rel = 'stylesheet';
    link.href = layout.cssUrl.startsWith('http')
      ? layout.cssUrl
      : `${apiBase.replace(/\/$/, '')}${layout.cssUrl}`;
    document.head.appendChild(link);
  }
}
