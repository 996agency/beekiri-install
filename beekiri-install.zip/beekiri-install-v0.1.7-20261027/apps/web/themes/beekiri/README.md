# Beekiri

Official starter theme for Beekiri CMS.

- Semantic landmarks (`header` / `main` / `footer` / `nav`)
- WCAG 2.2 AA focus styles and reduced-motion support
- Orange Beekiri accent aligned with the admin brand
- Public rendering is hosted by `apps/web` (Next.js App Router)

Activate from **Appearance → Themes** in the admin.
