# Layouts (AUK / ACF-style)

Synced from **Backend Fields** (`/admin/fields`) when Frontend runtime is PHP (default).

```
layouts/{slug}/
  {slug}.php          — PHP partial (get_sub_field style)
  styles.scss         — edit styles here
  styles.css          — compiled
  styles.min.css      — compiled min
  script.js           — optional JS
  {slug}.meta.json    — field defs for BeekiriCode Layouts tab
```

Same shape as AgencyUK themes: one folder per flexible layout, PHP templates like WordPress ACF.

> Note: Dropping `advanced-custom-fields-pro` / `acf-extended-pro` into `apps/web/` does **not** run them — those are WordPress plugins. Beekiri’s Backend Fields + this sync is the equivalent for field groups and layout folders.
