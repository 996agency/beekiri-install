/* @beekiri-managed — remove this line to keep your custom file */
/*
 * Hero Layout
 */
(function ($) {
  // hero
})(typeof jQuery !== 'undefined' ? jQuery : null);
