<section class="<?php echo esc_attr(implode(' ', $classes)); ?>" data-layout="hero" <?php get_Section_Override(); ?>>
  <div class="wrapper">
    <div class="inner">
      <?php $title = get_sub_field('title'); ?>
      <?php if ($title) : ?>
        <div class="bk-layout__field bk-layout__field--title"><?php echo esc_html($title); ?></div>
      <?php endif; ?>

      <?php
      $image = get_sub_field('image');
      $image_url = is_array($image) && !empty($image['url'])
        ? $image['url']
        : (is_string($image) ? $image : '');
      ?>
      <?php if ($image_url) : ?>
        <figure class="bk-layout__field bk-layout__field--image">
          <img
            src="<?php echo esc_url($image_url); ?>"
            alt="<?php echo esc_attr(is_array($image) && !empty($image['alt']) ? $image['alt'] : ''); ?>"
            loading="lazy"
            decoding="async"
          />
        </figure>
      <?php endif; ?>
    </div>
  </div>
</section>