import { Render } from '@beekiri/beekiricanva/rsc';
import {
  isBeekiricanvaData,
  beekiricanvaConfig,
  withLayouts,
  renderBeekiriCodePage,
  isBeekiriCodePublishDoc,
  type LayoutDef,
} from '@beekiri/page-blocks';
import '@beekiri/page-blocks/blocks.css';

const API = process.env.API_URL ?? 'http://127.0.0.1:8788';

async function renderLayoutPhp(
  slug: string,
  fields: Record<string, unknown>,
): Promise<string | null> {
  try {
    const res = await fetch(`${API.replace(/\/$/, '')}/api/layouts/${encodeURIComponent(slug)}/render`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fields }),
      cache: 'no-store',
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { html?: string };
    return typeof data.html === 'string' ? data.html : null;
  } catch {
    return null;
  }
}

type Props = {
  content: string;
  beekiricanva?: unknown | null;
  /** BeekiriCode page tree — preferred source for public HTML. */
  beekiricode?: unknown | null;
  /** @deprecated Alias for beekiricode */
  instatic?: unknown | null;
};

async function getLayouts(): Promise<LayoutDef[]> {
  try {
    const res = await fetch(`${API}/api/layouts`, { next: { revalidate: 30 } });
    if (!res.ok) return [];
    const data = (await res.json()) as { layouts?: LayoutDef[] };
    return data.layouts ?? [];
  } catch {
    return [];
  }
}

function layoutCssHref(layout: LayoutDef): string {
  return layout.cssUrl.startsWith('http')
    ? layout.cssUrl
    : `${API.replace(/\/$/, '')}${layout.cssUrl}`;
}

function layoutStylesheet(layout: LayoutDef) {
  // `precedence` makes React/Next hoist the stylesheet into <head>.
  return (
    <link
      key={layout.slug}
      rel="stylesheet"
      href={layoutCssHref(layout)}
      precedence="beekiri-layouts"
    />
  );
}

/** Resolve BeekiriCode → AUK HTML + layout stylesheet hrefs + page CSS for <head>. */
export async function resolveBeekiriCodePage(beekiricode: unknown): Promise<{
  html: string;
  css: string;
  cssHrefs: string[];
} | null> {
  if (!isBeekiriCodePublishDoc(beekiricode)) return null;
  const { html, css } = await renderBeekiriCodePage(beekiricode, renderLayoutPhp);
  if (!html.trim()) return { html: '', css: '', cssHrefs: [] };
  const layouts = await getLayouts();
  const used = new Set(
    [...html.matchAll(/data-layout="([^"]+)"/g)].map((m) => m[1]),
  );
  return {
    html,
    css,
    cssHrefs: layouts.filter((l) => used.has(l.slug)).map(layoutCssHref),
  };
}

/** Public page body — server Render only (no editor JS bundle). */
export async function PageBody({ content, beekiricanva, beekiricode, instatic }: Props) {
  const layouts = await getLayouts();
  const config = withLayouts(beekiricanvaConfig, layouts);
  const codeDoc = beekiricode ?? instatic;

  // BeekiriCode is handled by the page shell (sections inject into <main>).
  if (isBeekiriCodePublishDoc(codeDoc)) {
    return null;
  }

  const styleLinks = layouts.map(layoutStylesheet);

  if (isBeekiricanvaData(beekiricanva) && beekiricanva.content.length > 0) {
    return (
      <div className="bk-page-body">
        {styleLinks}
        <Render config={config} data={beekiricanva} />
      </div>
    );
  }

  if (content.trim() && /<[a-z][\s\S]*>/i.test(content)) {
    return (
      <div
        className="bk-page-body"
        dangerouslySetInnerHTML={{ __html: content }}
      />
    );
  }

  if (content.trim()) {
    return (
      <div className="bk-page-body">
        <p>{content}</p>
      </div>
    );
  }

  if (isBeekiricanvaData(beekiricanva)) {
    return (
      <div className="bk-page-body">
        {styleLinks}
        <Render config={config} data={beekiricanva} />
      </div>
    );
  }

  return null;
}
