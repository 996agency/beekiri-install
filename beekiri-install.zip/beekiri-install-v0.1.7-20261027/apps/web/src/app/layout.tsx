import type { Metadata, Viewport } from 'next';
import './globals.css';

const SITE_URL = process.env.APP_URL ?? 'http://127.0.0.1:8789';
const API = process.env.API_URL ?? 'http://127.0.0.1:8788';
const DEFAULT_FAVICON = '/beekiri-logo.png';

async function getPublicMeta(): Promise<{
  favicon: string;
  title: string;
  tagline: string;
  theme: string;
}> {
  try {
    const res = await fetch(`${API}/api/site/public`, {
      next: { revalidate: 60 },
    });
    if (!res.ok) {
      return { favicon: DEFAULT_FAVICON, title: 'Beekiri', tagline: '', theme: 'beekiri' };
    }
    const data = (await res.json()) as {
      faviconUrl?: string;
      title?: string;
      tagline?: string;
      theme?: string;
    };
    const favicon = (data.faviconUrl ?? '').trim() || DEFAULT_FAVICON;
    const title = (data.title ?? '').trim() || 'Beekiri';
    const tagline = (data.tagline ?? '').trim();
    const theme = (data.theme ?? '').trim() || 'beekiri';
    return { favicon, title, tagline, theme };
  } catch {
    return { favicon: DEFAULT_FAVICON, title: 'Beekiri', tagline: '', theme: 'beekiri' };
  }
}

export async function generateMetadata(): Promise<Metadata> {
  const { favicon, title, tagline } = await getPublicMeta();
  const description =
    tagline ||
    'Beekiri helps you publish pages, manage media, and grow your website with a fast, secure content management system.';

  return {
    metadataBase: new URL(SITE_URL),
    title: {
      default: title,
      template: `%s · ${title}`,
    },
    description,
    applicationName: title,
    authors: [{ name: '996agency' }],
    generator: 'Beekiri CMS',
    referrer: 'origin-when-cross-origin',
    keywords: ['Beekiri', 'CMS', 'content management', 'website', title],
    robots: {
      index: true,
      follow: true,
    },
    icons: {
      icon: [
        { url: favicon },
        { url: '/favicon.svg', type: 'image/svg+xml' },
        { url: '/favicon-32.png', sizes: '32x32', type: 'image/png' },
      ],
      shortcut: [{ url: favicon }],
      apple: [{ url: '/apple-touch-icon.png', sizes: '180x180' }],
    },
    openGraph: {
      type: 'website',
      locale: 'en_US',
      siteName: title,
      title,
      description,
      url: SITE_URL,
    },
    twitter: {
      card: 'summary',
      title,
      description,
    },
    manifest: '/site.webmanifest',
    other: {
      // Helps some crawlers / assistive tech when dynamic content lacks labels
      'format-detection': 'telephone=no',
    },
  };
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#ff9500',
  colorScheme: 'light',
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const { theme } = await getPublicMeta();
  return (
    <html lang="en" data-theme={theme}>
      <body>
        <a className="bk-skip" href="#main">
          Skip to main content
        </a>
        {children}
      </body>
    </html>
  );
}
