import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { BrandIcon } from '../../components/BrandIcon';
import { PageBody, resolveBeekiriCodePage } from '../../components/PageBody';

const API = process.env.API_URL ?? 'http://127.0.0.1:8788';
const ADMIN = process.env.ADMIN_URL ?? 'http://127.0.0.1:8787';

type PublicPage = {
  title: string;
  slug: string;
  path: string;
  content: string;
  beekiricanva?: unknown | null;
  beekiricode?: unknown | null;
  instatic?: unknown | null;
  excerpt: string;
  preview?: boolean;
};

type SitePublic = {
  installed?: boolean;
  title?: string;
};

async function getSite(): Promise<SitePublic | null> {
  try {
    const res = await fetch(`${API}/api/site/public`, { next: { revalidate: 60 } });
    if (!res.ok) return null;
    return (await res.json()) as SitePublic;
  } catch {
    return null;
  }
}

async function getPage(
  slug: string,
  preview?: { token: string },
): Promise<PublicPage | null> {
  try {
    const qs =
      preview?.token
        ? `?preview=1&token=${encodeURIComponent(preview.token)}`
        : '';
    const res = await fetch(
      `${API}/api/pages/public/${encodeURIComponent(slug)}${qs}`,
      // Preview: always fresh. Published: short ISR so bfcache / Perf stay healthy.
      preview?.token
        ? { cache: 'no-store' }
        : { next: { revalidate: 30 } },
    );
    if (res.status === 404) return null;
    if (!res.ok) return null;
    return (await res.json()) as PublicPage;
  } catch {
    return null;
  }
}

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

function firstParam(
  value: string | string[] | undefined,
): string | undefined {
  if (Array.isArray(value)) return value[0];
  return value;
}

export async function generateMetadata({ params, searchParams }: Props): Promise<Metadata> {
  const { slug } = await params;
  const sp = await searchParams;
  const token = firstParam(sp.token);
  const wantPreview =
    firstParam(sp.preview) === '1' ||
    firstParam(sp.preview) === 'true' ||
    Boolean(token);
  const page = await getPage(
    slug,
    wantPreview && token ? { token } : undefined,
  );
  if (!page) return { title: 'Not found' };
  const description =
    (page.excerpt || '').trim() ||
    `${page.title} — published with Beekiri.`;
  return {
    title: page.preview ? `${page.title} (Preview)` : page.title,
    description,
    robots: page.preview ? { index: false, follow: false } : undefined,
  };
}

export default async function ContentPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const sp = await searchParams;
  const token = firstParam(sp.token);
  const wantPreview =
    firstParam(sp.preview) === '1' ||
    firstParam(sp.preview) === 'true' ||
    Boolean(token);

  const [site, page] = await Promise.all([
    getSite(),
    getPage(slug, wantPreview && token ? { token } : undefined),
  ]);
  if (!page) notFound();

  const siteTitle = site?.title?.trim() || 'Beekiri';
  const codeDoc = page.beekiricode ?? page.instatic;
  const codePage = codeDoc ? await resolveBeekiriCodePage(codeDoc) : null;

  return (
    <>
      {/* `precedence` hoists these into <head> (not the body shell). */}
      {codePage?.cssHrefs.map((href) => (
        <link
          key={href}
          rel="stylesheet"
          href={href}
          precedence="beekiri-layouts"
        />
      ))}
      {/* Props styles — hoisted after layout CSS so page edits win over theme defaults. */}
      {codePage?.css ? (
        <style href={`bk-page-${page.slug}`} precedence="beekiri-page">
          {codePage.css}
        </style>
      ) : null}
      <div className="bk-shell">
        <header className="bk-header">
          <div className="bk-header__inner">
            <a className="bk-brand" href="/">
              <BrandIcon />
              <span>{siteTitle}</span>
            </a>
            <nav aria-label="Primary">
              <a className="bk-btn bk-btn--ghost" href={ADMIN}>
                Open admin
              </a>
            </nav>
          </div>
        </header>

        {codePage ? (
          <main
            id="main"
            className="bk-main"
            dangerouslySetInnerHTML={{
              __html:
                (page.preview
                  ? `<p class="bk-preview-banner">Preview — this is not the live published page.</p>`
                  : '') + codePage.html,
            }}
          />
        ) : (
          <main id="main" className="bk-main">
            {page.preview ? (
              <p className="bk-preview-banner">
                Preview — this is not the live published page.
              </p>
            ) : null}
            <h1>{page.title}</h1>
            <PageBody
              content={page.content}
              beekiricanva={page.beekiricanva}
              beekiricode={null}
            />
          </main>
        )}

        <footer className="bk-footer">
          <div className="bk-footer__inner">
            <p>
              <span>Powered by Beekiri</span>
            </p>
          </div>
        </footer>
      </div>
    </>
  );
}
