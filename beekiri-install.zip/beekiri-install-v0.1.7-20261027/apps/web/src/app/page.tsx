import { BrandIcon } from '../components/BrandIcon';

const API = process.env.API_URL ?? 'http://127.0.0.1:8788';
const ADMIN = process.env.ADMIN_URL ?? 'http://127.0.0.1:8787';

type SitePublic = {
  installed: boolean;
  title?: string;
  tagline?: string;
  blogPublic?: boolean;
  theme?: string;
};

async function getSite(): Promise<
  { ok: true; site: SitePublic } | { ok: false; reason: 'unreachable' | 'error' }
> {
  try {
    const res = await fetch(`${API}/api/site/public`, {
      // Allow bfcache + ISR — avoid no-store (blocks back/forward cache).
      next: { revalidate: 60 },
    });
    if (!res.ok) return { ok: false, reason: 'error' };
    const site = (await res.json()) as SitePublic;
    return { ok: true, site };
  } catch {
    return { ok: false, reason: 'unreachable' };
  }
}

export default async function HomePage() {
  const result = await getSite();

  if (!result.ok) {
    return (
      <div className="bk-down">
        <main id="main" className="bk-down__card" tabIndex={-1}>
          <p className="bk-down__brand">Beekiri</p>
          <h1>We&apos;ll be back as soon as possible</h1>
          <p>
            We&apos;re doing a quick update behind the scenes. Nothing is lost — please check back
            in a moment.
          </p>
        </main>
      </div>
    );
  }

  const { site } = result;
  const title = site.installed ? site.title || 'Beekiri' : 'Beekiri';
  const lead = site.installed
    ? site.tagline || 'Welcome to your Beekiri site.'
    : 'Your site is almost ready. Open the Beekiri installer to finish setup.';
  const ctaHref = ADMIN;
  const ctaLabel = site.installed ? 'Open admin' : 'Start installer';

  return (
    <div className="bk-shell">
      <header className="bk-header">
        <div className="bk-header__inner">
          <a className="bk-brand" href="/">
            <BrandIcon />
            <span>{title}</span>
          </a>
          <nav aria-label="Primary">
            <a className="bk-btn bk-btn--ghost" href={ctaHref}>
              {ctaLabel}
            </a>
          </nav>
        </div>
      </header>

      <main id="main" className="bk-main">
        <h1>{title}</h1>
        <p className="bk-lead">{lead}</p>
        <div className="bk-actions">
          <a className="bk-btn bk-btn--primary" href={ctaHref}>
            {ctaLabel}
          </a>
        </div>
      </main>

      <footer className="bk-footer">
        <div className="bk-footer__inner">
          <p>
            <span>Powered by Beekiri</span>
            {site.blogPublic === false ? (
              <>
                {' '}
                · <span>Search engines are asked not to index this site</span>
              </>
            ) : null}
          </p>
        </div>
      </footer>
    </div>
  );
}
