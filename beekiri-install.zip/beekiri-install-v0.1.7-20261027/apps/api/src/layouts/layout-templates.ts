import type { BackendField } from '../fields/fields.types';

export type LayoutMeta = {
  key: string;
  slug: string;
  title: string;
  active: boolean;
  location: string[];
  fields: BackendField[];
  updatedAt: string;
};

const MANAGED = '/* @beekiri-managed — remove this line to keep your custom file */';

/** Missing or marked → safe to regenerate. */
export function isManagedSource(src: string | null): boolean {
  if (src == null || src.trim() === '') return true;
  return src.includes('@beekiri-managed');
}

const ind = (text: string, n: number) =>
  text
    .split('\n')
    .map((l) => (l ? ' '.repeat(n) + l : ''))
    .join('\n');

const cls = (f: BackendField) => `bk-layout__field bk-layout__field--${f.name}`;
const isHeading = (f: BackendField) => /(^|_)(title|heading|headline)($|_)/.test(f.name);

/** One ACF field → PHP/HTML (get_sub_field works at the layout root and inside have_rows loops). */
function phpField(f: BackendField): string {
  const n = f.name;
  const v = `$${n}`;
  const get = `<?php ${v} = get_sub_field('${n}'); ?>`;
  const rf = f.returnFormat;

  switch (f.type) {
    case 'message':
    case 'accordion':
    case 'tab':
      return '';

    case 'image':
      if (rf === 'id') {
        return `${get}
<?php if (${v}) : ?>
  <figure class="${cls(f)}"><?php echo wp_get_attachment_image(${v}, 'large'); ?></figure>
<?php endif; ?>`;
      }
      if (rf === 'url') {
        return `${get}
<?php if (${v}) : ?>
  <figure class="${cls(f)}"><img src="<?php echo esc_url(${v}); ?>" alt="" loading="lazy" decoding="async" /></figure>
<?php endif; ?>`;
      }
      return `${get}
<?php if (${v}) : ?>
  <figure class="${cls(f)}">
    <img
      src="<?php echo esc_url(${v}['url']); ?>"
      alt="<?php echo esc_attr(${v}['alt']); ?>"
      <?php if (!empty(${v}['width'])) : ?>width="<?php echo esc_attr(${v}['width']); ?>" height="<?php echo esc_attr(${v}['height']); ?>"<?php endif; ?>
      loading="lazy"
      decoding="async"
    />
  </figure>
<?php endif; ?>`;

    case 'file':
      if (rf === 'id' || rf === 'url') {
        const url = rf === 'id' ? `wp_get_attachment_url(${v})` : v;
        return `${get}
<?php if (${v}) : ?>
  <a class="${cls(f)}" href="<?php echo esc_url(${url}); ?>" download>Download</a>
<?php endif; ?>`;
      }
      return `${get}
<?php if (${v}) : ?>
  <a class="${cls(f)}" href="<?php echo esc_url(${v}['url']); ?>" download><?php echo esc_html(${v}['title'] ?: ${v}['filename']); ?></a>
<?php endif; ?>`;

    case 'gallery': {
      const img =
        rf === 'id'
          ? `<?php echo wp_get_attachment_image($image, 'large'); ?>`
          : rf === 'url'
            ? `<img src="<?php echo esc_url($image); ?>" alt="" loading="lazy" decoding="async" />`
            : `<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" loading="lazy" decoding="async" />`;
      return `${get}
<?php if (${v}) : ?>
  <ul class="${cls(f)} bk-layout__gallery">
    <?php foreach (${v} as $image) : ?>
      <li><figure>${img}</figure></li>
    <?php endforeach; ?>
  </ul>
<?php endif; ?>`;
    }

    case 'textarea':
    case 'wysiwyg':
      return `${get}
<?php if (${v}) : ?>
  <div class="${cls(f)} body"><?php echo wp_kses_post(${v}); ?></div>
<?php endif; ?>`;

    case 'oembed':
      return `${get}
<?php if (${v}) : ?>
  <div class="${cls(f)} embed"><?php echo ${v}; ?></div>
<?php endif; ?>`;

    case 'email':
      return `${get}
<?php if (${v}) : ?>
  <a class="${cls(f)}" href="mailto:<?php echo esc_attr(${v}); ?>"><?php echo esc_html(${v}); ?></a>
<?php endif; ?>`;

    case 'url':
    case 'page_link':
      if (f.type === 'page_link' && f.multiple) {
        return `${get}
<?php if (${v}) : ?>
  <ul class="${cls(f)}">
    <?php foreach (${v} as $url) : ?>
      <li><a href="<?php echo esc_url($url); ?>"><?php echo esc_html($url); ?></a></li>
    <?php endforeach; ?>
  </ul>
<?php endif; ?>`;
      }
      return `${get}
<?php if (${v}) : ?>
  <a class="${cls(f)}" href="<?php echo esc_url(${v}); ?>"><?php echo esc_html(${v}); ?></a>
<?php endif; ?>`;

    case 'link':
      if (rf === 'url') {
        return `${get}
<?php if (${v}) : ?>
  <a class="${cls(f)} button" href="<?php echo esc_url(${v}); ?>"><?php echo esc_html(${v}); ?></a>
<?php endif; ?>`;
      }
      return `${get}
<?php if (${v}) :
  $${n}_target = ${v}['target'] ?: '_self';
?>
  <a class="${cls(f)} button" href="<?php echo esc_url(${v}['url']); ?>" target="<?php echo esc_attr($${n}_target); ?>"><?php echo esc_html(${v}['title'] ?: ${v}['url']); ?></a>
<?php endif; ?>`;

    case 'true_false':
      return `<?php if (get_sub_field('${n}')) : ?>
  <div class="${cls(f)} is-on"><?php /* ${n} is enabled */ ?></div>
<?php endif; ?>`;

    case 'checkbox':
    case 'select':
      if (f.type === 'checkbox' || f.multiple) {
        const item = rf === 'array' ? `$item['label']` : '$item';
        return `${get}
<?php if (${v}) : ?>
  <ul class="${cls(f)}">
    <?php foreach (${v} as $item) : ?>
      <li><?php echo esc_html(${item}); ?></li>
    <?php endforeach; ?>
  </ul>
<?php endif; ?>`;
      }
      return phpSingleChoice(f);
    case 'radio':
    case 'button_group':
      return phpSingleChoice(f);

    case 'post_object':
    case 'relationship': {
      const multi = f.type === 'relationship' || f.multiple;
      if (rf === 'id') {
        return `${get}
<?php if (${v}) : ?>
  <div class="${cls(f)}" data-ids="<?php echo esc_attr(implode(',', (array) ${v})); ?>"></div>
<?php endif; ?>`;
      }
      if (multi) {
        return `${get}
<?php if (${v}) : ?>
  <ul class="${cls(f)}">
    <?php foreach (${v} as $post_item) : ?>
      <li><a href="<?php echo esc_url(get_permalink($post_item)); ?>"><?php echo esc_html(get_the_title($post_item)); ?></a></li>
    <?php endforeach; ?>
  </ul>
<?php endif; ?>`;
      }
      return `${get}
<?php if (${v}) : ?>
  <a class="${cls(f)}" href="<?php echo esc_url(get_permalink(${v})); ?>"><?php echo esc_html(get_the_title(${v})); ?></a>
<?php endif; ?>`;
    }

    case 'user': {
      const name = rf === 'id' ? '$user' : `$user['display_name']`;
      return `${get}
<?php if (${v}) : ?>
  <ul class="${cls(f)}">
    <?php foreach (${f.multiple ? v : `array(${v})`} as $user) : ?>
      <li><?php echo esc_html(${name}); ?></li>
    <?php endforeach; ?>
  </ul>
<?php endif; ?>`;
    }

    case 'group':
      return `<?php if (have_rows('${n}')) : while (have_rows('${n}')) : the_row(); ?>
  <div class="${cls(f)} bk-layout__group">
${ind(phpFields(f.subFields ?? []), 4)}
  </div>
<?php endwhile; endif; ?>`;

    case 'repeater':
      return `<?php if (have_rows('${n}')) : ?>
  <ul class="${cls(f)} bk-layout__repeater">
    <?php while (have_rows('${n}')) : the_row(); ?>
      <li class="bk-layout__item">
${ind(phpFields(f.subFields ?? []), 8)}
      </li>
    <?php endwhile; ?>
  </ul>
<?php endif; ?>`;

    case 'flexible_content': {
      const layouts = f.layouts ?? [];
      if (!layouts.length) return '';
      const branches = layouts
        .map(
          (l, i) => `<?php ${i === 0 ? 'if' : 'elseif'} (get_row_layout() === '${l.name}') : ?>
  <div class="bk-layout__row bk-layout__row--${l.name}">
${ind(phpFields(l.subFields), 4)}
  </div>`,
        )
        .join('\n');
      return `<?php if (have_rows('${n}')) : ?>
  <div class="${cls(f)} bk-layout__flexible">
    <?php while (have_rows('${n}')) : the_row(); ?>
${ind(branches, 6)}
      <?php endif; ?>
    <?php endwhile; ?>
  </div>
<?php endif; ?>`;
    }

    default: {
      const tag = isHeading(f) ? 'h2' : 'p';
      return `${get}
<?php if (${v} !== null && ${v} !== '') : ?>
  <${tag} class="${cls(f)}"><?php echo esc_html(${v}); ?></${tag}>
<?php endif; ?>`;
    }
  }
}

function phpSingleChoice(f: BackendField): string {
  const v = `$${f.name}`;
  const out = f.returnFormat === 'array' ? `${v}['label']` : v;
  return `<?php ${v} = get_sub_field('${f.name}'); ?>
<?php if (${v}) : ?>
  <div class="${cls(f)}"><?php echo esc_html(${out}); ?></div>
<?php endif; ?>`;
}

function phpFields(fields: BackendField[]): string {
  return fields.map(phpField).filter(Boolean).join('\n\n');
}

/** AUK-style PHP section — ACF template API (get_sub_field / have_rows / the_row). */
export function renderPhp(meta: LayoutMeta): string {
  const body =
    meta.fields.length === 0
      ? `      <div class="bk-layout__placeholder">Add fields to this layout in Backend Fields.</div>`
      : ind(phpFields(meta.fields), 6);

  return `<?php
${MANAGED}
/**
 * ${meta.title}
 * Field group: ${meta.key} · slug: ${meta.slug}
 *
 * ACF Pro flexible layout partial: get_sub_field(), have_rows(), the_row(),
 * get_row_layout() work the same as in WordPress.
 */
$classes = array(
  '${meta.slug}',
  'section',
  'bk-layout',
  'bk-layout--${meta.slug}',
);
?>
<section class="<?php echo esc_attr(implode(' ', $classes)); ?>" data-layout="${meta.slug}" <?php get_Section_Override(); ?>>
  <div class="wrapper">
    <div class="inner">
${body}
    </div>
  </div>
</section>
`;
}

/** AUK-style SCSS stub (compiles to styles.css / styles.min.css). */
export function renderScss(meta: LayoutMeta): string {
  return `${MANAGED}
/*
 * ${meta.title} Layout
 */

.${meta.slug} {
  /* layout styles */
}

/*
 * ${meta.slug} Layout: Admin Preview
 */

.${meta.slug}.is-preview {
}
`;
}

export function renderScriptJs(meta: LayoutMeta): string {
  return `${MANAGED}
/*
 * ${meta.title} Layout
 */
(function ($) {
  // ${meta.slug}
})(typeof jQuery !== 'undefined' ? jQuery : null);
`;
}

/** Alias used by layout-sync.service */
export const renderJs = renderScriptJs;

const TSX_SHARED_TYPES = `export type AcfImage = {
  ID: string;
  url: string;
  alt: string;
  title: string;
  filename: string;
  width: number;
  height: number;
  mime_type: string;
  sizes: Record<string, string | number>;
};
export type AcfFile = { ID: string; url: string; title: string; filename: string; filesize: number; mime_type: string };
export type AcfLink = { title: string; url: string; target: string };
export type AcfPost = { ID: string; post_title: string; post_name: string; post_type: string; permalink: string };
export type AcfUser = { ID: string; user_login: string; display_name: string };
export type AcfChoice = { value: string; label: string };`;

function tsType(f: BackendField, depth = 0): string {
  const rf = f.returnFormat;
  switch (f.type) {
    case 'number':
    case 'range':
      return `number | ''`;
    case 'true_false':
      return 'boolean';
    case 'image':
      return rf === 'url' || rf === 'id' ? 'string | null' : 'AcfImage | null';
    case 'file':
      return rf === 'url' || rf === 'id' ? 'string | null' : 'AcfFile | null';
    case 'gallery':
      return rf === 'url' || rf === 'id' ? 'string[]' : 'AcfImage[]';
    case 'link':
      return rf === 'url' ? 'string' : 'AcfLink | null';
    case 'checkbox':
      return rf === 'array' ? 'AcfChoice[]' : 'string[]';
    case 'select':
      if (f.multiple) return rf === 'array' ? 'AcfChoice[]' : 'string[]';
      return rf === 'array' ? 'AcfChoice | null' : 'string | null';
    case 'radio':
    case 'button_group':
      return rf === 'array' ? 'AcfChoice | null' : 'string | null';
    case 'post_object': {
      const one = rf === 'id' ? 'string' : 'AcfPost';
      return f.multiple ? `${one}[]` : `${one} | null`;
    }
    case 'relationship':
      return rf === 'id' ? 'string[]' : 'AcfPost[]';
    case 'page_link':
      return f.multiple ? 'string[]' : 'string | null';
    case 'user': {
      const one = rf === 'id' ? 'string' : 'AcfUser';
      return f.multiple ? `${one}[]` : `${one} | null`;
    }
    case 'group':
      return tsObject(f.subFields ?? [], depth + 2);
    case 'repeater':
      return `Array<${tsObject(f.subFields ?? [], depth + 2)}>`;
    case 'flexible_content': {
      const ls = f.layouts ?? [];
      if (!ls.length) return 'Array<{ acf_fc_layout: string }>';
      const pad = ' '.repeat(depth + 4);
      return `Array<\n${ls
        .map((l) => `${pad}| ({ acf_fc_layout: '${l.name}' } & ${tsObject(l.subFields, depth + 4)})`)
        .join('\n')}\n${' '.repeat(depth + 2)}>`;
    }
    default:
      return 'string';
  }
}

function tsObject(fields: BackendField[], depth: number): string {
  const pad = ' '.repeat(depth + 2);
  const lines = fields
    .filter((f) => !['message', 'accordion', 'tab'].includes(f.type))
    .map((f) => `${pad}${f.name}?: ${tsType(f, depth)};`);
  if (!lines.length) return '{}';
  return `{\n${lines.join('\n')}\n${' '.repeat(depth)}}`;
}

/** One ACF field → JSX, reading from `src` (props or a loop row). */
function tsxField(f: BackendField, src: string, depth: number): string {
  const v = `${src}.${f.name}`;
  const c = cls(f);
  const rf = f.returnFormat;
  const loopVar = `row${depth}`;
  switch (f.type) {
    case 'message':
    case 'accordion':
    case 'tab':
      return '';
    case 'image':
      if (rf === 'url') return `{${v} ? <figure className="${c}"><img src={${v}} alt="" loading="lazy" decoding="async" /></figure> : null}`;
      if (rf === 'id') return `{/* ${f.name}: image id = {${v}} */}`;
      return `{${v} ? (
  <figure className="${c}">
    <img src={${v}.url} alt={${v}.alt} width={${v}.width || undefined} height={${v}.height || undefined} loading="lazy" decoding="async" />
  </figure>
) : null}`;
    case 'file':
      if (rf === 'id') return `{/* ${f.name}: file id = {${v}} */}`;
      if (rf === 'url') return `{${v} ? <a className="${c}" href={${v}} download>Download</a> : null}`;
      return `{${v} ? <a className="${c}" href={${v}.url} download>{${v}.title || ${v}.filename}</a> : null}`;
    case 'gallery': {
      const img =
        rf === 'url' || rf === 'id'
          ? `<img src={String(image)} alt="" loading="lazy" decoding="async" />`
          : `<img src={image.url} alt={image.alt} loading="lazy" decoding="async" />`;
      return `{${v}?.length ? (
  <ul className="${c} bk-layout__gallery">
    {${v}.map((image, i) => (
      <li key={i}><figure>${img}</figure></li>
    ))}
  </ul>
) : null}`;
    }
    case 'textarea':
    case 'wysiwyg':
      return `{${v} ? <div className="${c} body" dangerouslySetInnerHTML={{ __html: ${v} }} /> : null}`;
    case 'oembed':
      return `{${v} ? <div className="${c} embed" dangerouslySetInnerHTML={{ __html: ${v} }} /> : null}`;
    case 'email':
      return `{${v} ? <a className="${c}" href={\`mailto:\${${v}}\`}>{${v}}</a> : null}`;
    case 'url':
      return `{${v} ? <a className="${c}" href={${v}}>{${v}}</a> : null}`;
    case 'page_link':
      if (f.multiple) {
        return `{${v}?.length ? <ul className="${c}">{${v}.map((url) => <li key={url}><a href={url}>{url}</a></li>)}</ul> : null}`;
      }
      return `{${v} ? <a className="${c}" href={${v}}>{${v}}</a> : null}`;
    case 'link':
      if (rf === 'url') return `{${v} ? <a className="${c} button" href={${v}}>{${v}}</a> : null}`;
      return `{${v}?.url ? (
  <a className="${c} button" href={${v}.url} target={${v}.target || undefined}>{${v}.title || ${v}.url}</a>
) : null}`;
    case 'true_false':
      return `{${v} ? <div className="${c} is-on" /> : null}`;
    case 'checkbox':
    case 'select':
      if (f.type === 'checkbox' || f.multiple) {
        const label = rf === 'array' ? 'item.label' : 'item';
        return `{${v}?.length ? <ul className="${c}">{${v}.map((item, i) => <li key={i}>{${label}}</li>)}</ul> : null}`;
      }
      return `{${v} ? <div className="${c}">{${rf === 'array' ? `${v}.label` : v}}</div> : null}`;
    case 'radio':
    case 'button_group':
      return `{${v} ? <div className="${c}">{${rf === 'array' ? `${v}.label` : v}}</div> : null}`;
    case 'post_object':
    case 'relationship': {
      const multi = f.type === 'relationship' || f.multiple;
      if (rf === 'id') return `{/* ${f.name}: post id(s) */}`;
      if (multi) {
        return `{${v}?.length ? (
  <ul className="${c}">
    {${v}.map((p) => <li key={p.ID}><a href={p.permalink}>{p.post_title}</a></li>)}
  </ul>
) : null}`;
      }
      return `{${v} ? <a className="${c}" href={${v}.permalink}>{${v}.post_title}</a> : null}`;
    }
    case 'user':
      if (rf === 'id') return `{/* ${f.name}: user id(s) */}`;
      if (f.multiple) return `{${v}?.length ? <ul className="${c}">{${v}.map((u) => <li key={u.ID}>{u.display_name}</li>)}</ul> : null}`;
      return `{${v} ? <div className="${c}">{${v}.display_name}</div> : null}`;
    case 'group':
      return `{${v} ? (
  <div className="${c} bk-layout__group">
${ind(tsxFields(f.subFields ?? [], v, depth + 1), 4)}
  </div>
) : null}`;
    case 'repeater':
      return `{${v}?.length ? (
  <ul className="${c} bk-layout__repeater">
    {${v}.map((${loopVar}, i) => (
      <li className="bk-layout__item" key={i}>
${ind(tsxFields(f.subFields ?? [], loopVar, depth + 1), 8)}
      </li>
    ))}
  </ul>
) : null}`;
    case 'flexible_content': {
      const ls = f.layouts ?? [];
      if (!ls.length) return '';
      const branches = ls
        .map(
          (l) => `${loopVar}.acf_fc_layout === '${l.name}' ? (
  <div className="bk-layout__row bk-layout__row--${l.name}" key={i}>
${ind(tsxFields(l.subFields, loopVar, depth + 1), 4)}
  </div>
) :`,
        )
        .join('\n');
      return `{${v}?.length ? (
  <div className="${c} bk-layout__flexible">
    {${v}.map((${loopVar}, i) =>
${ind(branches, 6)}
      null,
    )}
  </div>
) : null}`;
    }
    default: {
      const tag = isHeading(f) ? 'h2' : 'p';
      return `{${v} != null && ${v} !== '' ? <${tag} className="${c}">{${v}}</${tag}> : null}`;
    }
  }
}

function tsxFields(fields: BackendField[], src: string, depth: number): string {
  const parts = fields.map((f) => tsxField(f, src, depth)).filter(Boolean);
  if (!parts.length) return 'null';
  return parts.length === 1 ? parts[0] : `<>\n${ind(parts.join('\n'), 2)}\n</>`;
}

/**
 * React layout. Props are ACF-formatted values (same shapes as get_field()):
 * POST /api/layouts/{slug}/fields { fields } returns them from raw editor values.
 */
export function renderTsx(meta: LayoutMeta): string {
  const component = pascal(meta.slug);
  const propsType = `${component}Props`;
  const body =
    meta.fields.length === 0
      ? `      <div className="bk-layout__placeholder">Add fields to this layout in Backend Fields.</div>`
      : ind(meta.fields.map((f) => tsxField(f, 'props', 0)).filter(Boolean).join('\n'), 6);

  return `${MANAGED}
/**
 * Layout: ${meta.title} (${meta.slug})
 * Generated from field group ${meta.key}
 * Props match ACF get_field() return values (POST /api/layouts/${meta.slug}/fields).
 * Remove the @beekiri-managed marker to keep your edits.
 */
${TSX_SHARED_TYPES}

export type ${propsType} = ${tsObject(meta.fields, 0)};

export default function ${component}(props: ${propsType}) {
  return (
    <section
      className={\`bk-layout bk-layout--${meta.slug} ${meta.slug} section\`}
      data-layout="${meta.slug}"
    >
      <div className="wrapper">
        <div className="inner">
${ind(body, 4)}
        </div>
      </div>
    </section>
  );
}
`;
}

export function renderMetaJson(meta: LayoutMeta): string {
  return `${JSON.stringify(meta, null, 2)}\n`;
}

function pascal(slug: string): string {
  return (
    slug
      .split(/[_-]+/)
      .filter(Boolean)
      .map((p) => p.charAt(0).toUpperCase() + p.slice(1))
      .join('') || 'Layout'
  );
}
