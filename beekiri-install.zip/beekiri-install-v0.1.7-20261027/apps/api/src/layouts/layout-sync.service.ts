import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { execFile } from 'child_process';
import {
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  renameSync,
  rmSync,
  statSync,
  unlinkSync,
  writeFileSync,
} from 'fs';
import { join } from 'path';
import { promisify } from 'util';
import { compile as compileSass } from 'sass';

const execFileAsync = promisify(execFile);
import { PrismaService } from '../prisma/prisma.service';
import { parseFields, parseLocation, type BackendField } from '../fields/fields.types';
import { formatValues, type FormatLookups } from '../fields/acf-format';
import { DEFAULT_THEME_SLUG } from '../themes/theme-registry';
import { ThemesService } from '../themes/themes.service';
import {
  layoutPaths,
  layoutSlugFromGroupKey,
  layoutSlugFromTitle,
  resolveLayoutsRoot,
  sanitizeLayoutSlug,
} from './layout-paths';
import { readOptions } from '../site/site-options';
import {
  isManagedSource,
  renderJs,
  renderMetaJson,
  renderPhp,
  renderScss,
  renderTsx,
  type LayoutMeta,
} from './layout-templates';

type FrontendRuntime = 'react' | 'php';

export type PublicLayout = {
  slug: string;
  title: string;
  key: string;
  fields: BackendField[];
  cssUrl: string;
  componentName: string;
  theme: string;
};

@Injectable()
export class LayoutSyncService implements OnModuleInit {
  private readonly log = new Logger(LayoutSyncService.name);
  private themeSlug = DEFAULT_THEME_SLUG;

  constructor(
    private readonly prisma: PrismaService,
    private readonly themes: ThemesService,
  ) {}

  async onModuleInit() {
    try {
      await this.refreshTheme();
      this.migrateFlatLayoutFiles();
      await this.syncAllActive();
    } catch (e) {
      this.log.warn(`Layout sync on boot skipped: ${(e as Error).message}`);
    }
  }

  private async refreshTheme() {
    try {
      this.themeSlug = await this.themes.getActiveSlug();
    } catch {
      this.themeSlug = DEFAULT_THEME_SLUG;
    }
  }

  /**
   * Old flat files: layouts/hero.php → layouts/hero/hero.php (+ styles, script, meta).
   */
  private migrateFlatLayoutFiles(themeSlug = this.themeSlug) {
    const root = resolveLayoutsRoot(themeSlug);
    if (!existsSync(root)) return;

    const names = readdirSync(root);
    const slugs = new Set<string>();
    for (const name of names) {
      const m = name.match(/^(.+)\.(php|tsx|scss|css|js|meta\.json)$/);
      if (!m) continue;
      if (name === 'README.md') continue;
      slugs.add(m[1].replace(/\.meta$/, ''));
    }
    // meta.json was named hero.meta.json → slug hero
    for (const name of names) {
      if (name.endsWith('.meta.json')) {
        slugs.add(name.replace(/\.meta\.json$/, ''));
      }
    }

    for (const slug of slugs) {
      const flatPhp = join(root, `${slug}.php`);
      const flatTsx = join(root, `${slug}.tsx`);
      const flatScss = join(root, `${slug}.scss`);
      const flatCss = join(root, `${slug}.css`);
      const flatJs = join(root, `${slug}.js`);
      const flatMeta = join(root, `${slug}.meta.json`);
      const anyFlat =
        existsSync(flatPhp) ||
        existsSync(flatTsx) ||
        existsSync(flatScss) ||
        existsSync(flatCss) ||
        existsSync(flatJs) ||
        existsSync(flatMeta);
      if (!anyFlat) continue;

      const dir = join(root, slug);
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });

      const move = (from: string, to: string) => {
        if (!existsSync(from)) return;
        if (existsSync(to)) {
          unlinkSync(from);
          return;
        }
        renameSync(from, to);
      };

      move(flatPhp, join(dir, `${slug}.php`));
      move(flatTsx, join(dir, `${slug}.tsx`));
      move(flatScss, join(dir, 'styles.scss'));
      move(flatCss, join(dir, 'styles.css'));
      move(flatJs, join(dir, 'script.js'));
      move(flatMeta, join(dir, `${slug}.meta.json`));
      this.log.log(`Migrated flat layout → layouts/${slug}/`);
    }
  }

  private ensureRoot(themeSlug = this.themeSlug) {
    const root = resolveLayoutsRoot(themeSlug);
    if (!existsSync(root)) mkdirSync(root, { recursive: true });
    const readme = join(root, 'README.md');
    if (!existsSync(readme) || isManagedSource(this.readIfExists(readme))) {
      writeFileSync(
        readme,
        `# Layouts (theme: ${themeSlug})

AUK / ACF-style folder-per-layout (synced from Backend Fields):

\`\`\`
layouts/{slug}/
  {slug}.php          — PHP/HTML partial (default frontend)
  {slug}.tsx          — React layout (when Frontend = React)
  styles.scss         — source styles
  styles.css          — compiled CSS
  styles.min.css      — minified (optional)
  script.js           — client behaviour
  {slug}.meta.json    — field definitions for the editor
\`\`\`

PHP templates use the ACF Pro API: \`get_sub_field()\`, \`get_field()\`, \`have_rows()\` / \`the_row()\`,
\`get_row_layout()\`, \`get_row_index()\` — values arrive formatted like ACF (image arrays, links, posts…).
React layouts get the same values from \`POST /api/layouts/{slug}/fields\`.
Files marked \`@beekiri-managed\` regenerate on field-group save — remove the marker to keep edits.
`,
        'utf8',
      );
    }
    return root;
  }

  private toMeta(group: {
    title: string;
    key: string;
    active: boolean;
    location: unknown;
    fields: unknown;
    updatedAt?: Date;
  }): LayoutMeta {
    // Prefer human title slug (AUK): "Hero" → hero, "M7-Text-And-Media-Cards" → m7-…
    const fromTitle = layoutSlugFromTitle(group.title);
    const slug =
      fromTitle && !fromTitle.startsWith('group-')
        ? fromTitle
        : layoutSlugFromGroupKey(group.key);
    return {
      slug,
      title: group.title,
      key: group.key,
      active: group.active,
      location: parseLocation(group.location),
      fields: parseFields(group.fields),
      updatedAt: (group.updatedAt ?? new Date()).toISOString(),
    };
  }

  private async resolveFrontendRuntime(): Promise<FrontendRuntime> {
    try {
      const site = await this.prisma.site.findFirst({
        include: { settings: true },
        orderBy: { createdAt: 'asc' },
      });
      const opts = readOptions(site?.settings?.options);
      // Default PHP (AUK / ACF workflow). Only React when explicitly set.
      return opts.frontendRuntime === 'react' ? 'react' : 'php';
    } catch {
      return 'php';
    }
  }

  private compileScss(scssPath: string, cssPath: string, cssMinPath?: string) {
    const expanded = compileSass(scssPath, { style: 'expanded' });
    const banner = `/* Compiled from styles.scss — do not edit */\n`;
    writeFileSync(cssPath, banner + expanded.css, 'utf8');
    if (cssMinPath) {
      try {
        const min = compileSass(scssPath, { style: 'compressed' });
        writeFileSync(cssMinPath, min.css, 'utf8');
      } catch {
        /* optional */
      }
    }
  }

  private readIfExists(path: string): string | null {
    try {
      return existsSync(path) ? readFileSync(path, 'utf8') : null;
    } catch {
      return null;
    }
  }

  /** Create or refresh layout folder for a field group (active theme). */
  syncGroup(
    group: {
      title: string;
      key: string;
      active: boolean;
      location: unknown;
      fields: unknown;
      updatedAt?: Date;
    },
    runtime: FrontendRuntime = 'php',
  ): LayoutMeta {
    this.ensureRoot();
    const meta = this.toMeta(group);
    const paths = layoutPaths(meta.slug, this.themeSlug);

    if (!existsSync(paths.dir)) {
      mkdirSync(paths.dir, { recursive: true });
    }

    writeFileSync(paths.meta, renderMetaJson(meta), 'utf8');

    if (runtime === 'php') {
      // AUK: scaffold PHP once; regenerate only while @beekiri-managed
      if (isManagedSource(this.readIfExists(paths.php))) {
        writeFileSync(paths.php, renderPhp(meta), 'utf8');
      }
      if (existsSync(paths.tsx) && isManagedSource(this.readIfExists(paths.tsx))) {
        unlinkSync(paths.tsx);
      }
    } else {
      if (isManagedSource(this.readIfExists(paths.tsx))) {
        writeFileSync(paths.tsx, renderTsx(meta), 'utf8');
      }
      if (existsSync(paths.php) && isManagedSource(this.readIfExists(paths.php))) {
        unlinkSync(paths.php);
      }
    }

    if (isManagedSource(this.readIfExists(paths.scss))) {
      writeFileSync(paths.scss, renderScss(meta), 'utf8');
    }
    if (isManagedSource(this.readIfExists(paths.js))) {
      writeFileSync(paths.js, renderJs(meta), 'utf8');
    }

    if (existsSync(paths.scss)) {
      try {
        this.compileScss(paths.scss, paths.css, paths.cssMin);
      } catch (e) {
        this.log.warn(`SCSS compile failed for ${meta.slug}: ${(e as Error).message}`);
        if (!existsSync(paths.css)) {
          writeFileSync(
            paths.css,
            `/* compile error */\n.${meta.slug} {}\n`,
            'utf8',
          );
        }
      }
    }

    this.log.log(
      `Synced layout ${this.themeSlug}/layouts/${meta.slug}/ (${runtime}) ← ${meta.key}`,
    );
    return meta;
  }

  removeByGroupKey(key: string) {
    const root = this.ensureRoot();
    let found: string | null = null;
    try {
      for (const entry of readdirSync(root, { withFileTypes: true })) {
        if (!entry.isDirectory()) continue;
        const metaPath = join(root, entry.name, `${entry.name}.meta.json`);
        if (!existsSync(metaPath)) continue;
        const meta = JSON.parse(readFileSync(metaPath, 'utf8')) as LayoutMeta;
        if (meta?.key === key) {
          found = meta.slug || entry.name;
          break;
        }
      }
    } catch {
      /* fall through */
    }
    this.removeBySlug(found || layoutSlugFromGroupKey(key));
  }

  removeBySlug(slug: string) {
    const clean = sanitizeLayoutSlug(slug);
    if (!clean) return;
    const paths = layoutPaths(clean, this.themeSlug);
    for (const file of [
      paths.tsx,
      paths.php,
      paths.scss,
      paths.css,
      paths.cssMin,
      paths.js,
      paths.meta,
    ]) {
      if (!existsSync(file)) continue;
      if (file === paths.meta || isManagedSource(this.readIfExists(file))) {
        unlinkSync(file);
      }
    }
    // Remove empty layout folder
    if (existsSync(paths.dir)) {
      try {
        const left = readdirSync(paths.dir);
        if (left.length === 0) {
          rmSync(paths.dir, { recursive: true });
        }
      } catch {
        /* ignore */
      }
    }
    this.log.log(`Removed managed layout files for ${this.themeSlug}/layouts/${clean}/`);
  }

  compileSlug(slug: string): boolean {
    const clean = sanitizeLayoutSlug(slug);
    if (!clean) return false;
    const paths = layoutPaths(clean, this.themeSlug);
    if (!existsSync(paths.scss)) return false;
    this.compileScss(paths.scss, paths.css, paths.cssMin);
    return true;
  }

  async syncAllActive() {
    await this.refreshTheme();
    this.ensureRoot();
    this.migrateFlatLayoutFiles();
    const runtime = await this.resolveFrontendRuntime();
    const groups = await this.prisma.fieldGroup.findMany({
      where: { active: true },
      orderBy: [{ menuOrder: 'asc' }, { createdAt: 'asc' }],
    });
    for (const g of groups) {
      this.syncGroup(g, runtime);
    }
    return groups.length;
  }

  async syncGroupForSite(group: {
    title: string;
    key: string;
    active: boolean;
    location: unknown;
    fields: unknown;
    updatedAt?: Date;
  }): Promise<LayoutMeta> {
    await this.refreshTheme();
    const runtime = await this.resolveFrontendRuntime();
    return this.syncGroup(group, runtime);
  }

  listPublic(): PublicLayout[] {
    const root = this.ensureRoot();
    const out: PublicLayout[] = [];

    for (const entry of readdirSync(root, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      if (entry.name.startsWith('group_') || entry.name.startsWith('.')) continue;
      const metaPath = join(root, entry.name, `${entry.name}.meta.json`);
      if (!existsSync(metaPath)) continue;
      try {
        const meta = JSON.parse(readFileSync(metaPath, 'utf8')) as LayoutMeta;
        if (!meta?.slug || meta.active === false) continue;
        const locs = Array.isArray(meta.location) ? meta.location : [];
        if (locs.length && !locs.includes('page')) continue;
        out.push({
          slug: meta.slug,
          title: meta.title || meta.slug,
          key: meta.key || meta.slug,
          fields: Array.isArray(meta.fields) ? meta.fields : [],
          cssUrl: `/api/layouts/${encodeURIComponent(meta.slug)}/css`,
          componentName: toComponentName(meta.slug),
          theme: this.themeSlug,
        });
      } catch {
        /* skip bad meta */
      }
    }

    return out.sort((a, b) => a.title.localeCompare(b.title));
  }

  private readMetaFields(slug: string): BackendField[] {
    const raw = this.readIfExists(layoutPaths(slug, this.themeSlug).meta);
    if (!raw) return [];
    try {
      return parseFields((JSON.parse(raw) as { fields?: unknown }).fields);
    } catch {
      return [];
    }
  }

  private readonly lookups: FormatLookups = {
    media: (ids) =>
      this.prisma.mediaAsset.findMany({
        where: { id: { in: ids } },
        select: {
          id: true,
          filename: true,
          originalName: true,
          mimeType: true,
          size: true,
          width: true,
          height: true,
          url: true,
          alt: true,
        },
      }),
    posts: (ids) =>
      this.prisma.post.findMany({
        where: { id: { in: ids }, status: { not: 'trash' } },
        select: {
          id: true,
          type: true,
          title: true,
          slug: true,
          status: true,
          excerpt: true,
          publishedAt: true,
        },
      }),
    users: (ids) =>
      this.prisma.user.findMany({
        where: { id: { in: ids } },
        select: { id: true, username: true, displayName: true },
      }),
  };

  /** Raw stored values → ACF get_field() shapes using the layout's meta.json definitions. */
  async formatLayoutFields(
    slug: string,
    raw: Record<string, unknown> = {},
  ): Promise<Record<string, unknown>> {
    const clean = sanitizeLayoutSlug(slug);
    if (!clean) return raw;
    const defs = this.readMetaFields(clean);
    try {
      return await formatValues(defs, raw ?? {}, this.lookups);
    } catch (e) {
      this.log.warn(`Field format failed for ${clean}: ${(e as Error).message}`);
      return raw;
    }
  }

  /**
   * Execute themes/.../layouts/{slug}/{slug}.php with field values (ACF-style).
   * Requires PHP CLI on PATH (Herd / php).
   */
  async renderPhpLayout(
    slug: string,
    fields: Record<string, unknown> = {},
  ): Promise<string | null> {
    const clean = sanitizeLayoutSlug(slug);
    if (!clean) return null;
    const paths = layoutPaths(clean, this.themeSlug);
    if (!existsSync(paths.php)) return null;

    const runner = join(__dirname, 'php', 'layout-runner.php');
    // Nest may compile to dist/ — also support src path next to this file in dev.
    const runnerCandidates = [
      runner,
      join(__dirname, '..', 'layouts', 'php', 'layout-runner.php'),
      join(process.cwd(), 'apps/api/src/layouts/php/layout-runner.php'),
      join(process.cwd(), 'src/layouts/php/layout-runner.php'),
    ];
    const runnerPath = runnerCandidates.find((p) => existsSync(p));
    if (!runnerPath) {
      this.log.warn('layout-runner.php not found — cannot render PHP layouts.');
      return null;
    }

    const fieldsJson = JSON.stringify(await this.formatLayoutFields(clean, fields ?? {}));
    try {
      const { stdout } = await execFileAsync(
        'php',
        [runnerPath, paths.php, fieldsJson, clean],
        {
          timeout: 8000,
          maxBuffer: 2 * 1024 * 1024,
          env: process.env,
        },
      );
      return typeof stdout === 'string' ? stdout : String(stdout);
    } catch (e) {
      this.log.warn(
        `PHP layout render failed for ${clean}: ${(e as Error).message}`,
      );
      return null;
    }
  }

  /**
   * Serve layout CSS. If styles.scss is newer than styles.css, recompile first
   * so saving SCSS + refreshing the page picks up changes without waiting on gulp.
   */
  readCss(slug: string): string | null {
    const clean = sanitizeLayoutSlug(slug);
    if (!clean) return null;
    const paths = layoutPaths(clean, this.themeSlug);

    if (existsSync(paths.scss)) {
      let stale = !existsSync(paths.css);
      if (!stale) {
        try {
          stale = statSync(paths.scss).mtimeMs > statSync(paths.css).mtimeMs;
        } catch {
          stale = true;
        }
      }
      if (stale) {
        try {
          this.compileScss(paths.scss, paths.css, paths.cssMin);
        } catch (e) {
          this.log.warn(`SCSS compile failed for ${clean}: ${(e as Error).message}`);
        }
      }
    }

    // Prefer expanded CSS (easier to debug); fall back to min.
    return this.readIfExists(paths.css) ?? this.readIfExists(paths.cssMin);
  }
}

function toComponentName(slug: string): string {
  return (
    slug
      .split(/[_-]+/)
      .filter(Boolean)
      .map((p) => p.charAt(0).toUpperCase() + p.slice(1))
      .join('') || 'Layout'
  );
}
