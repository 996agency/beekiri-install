import {
  Body,
  Controller,
  Get,
  Header,
  NotFoundException,
  Param,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { AuthGuard, type AuthedRequest } from '../auth/auth.guard';
import { CapabilitiesGuard } from '../auth/capabilities.guard';
import { RequireCapabilities } from '../auth/capabilities.decorator';
import { LayoutSyncService } from './layout-sync.service';
import { sanitizeLayoutSlug } from './layout-paths';

@ApiTags('layouts')
@Controller('layouts')
export class LayoutsController {
  constructor(private readonly layouts: LayoutSyncService) {}

  /** Public — editor + frontend load available page layouts. */
  @Get()
  list() {
    return { layouts: this.layouts.listPublic() };
  }

  @Get(':slug/css')
  @Header('Content-Type', 'text/css; charset=utf-8')
  // Bust browser/CDN caches when SCSS is edited in local/dev.
  @Header('Cache-Control', 'no-store, no-cache, must-revalidate')
  css(@Param('slug') slug: string) {
    const clean = sanitizeLayoutSlug(slug);
    if (!clean) throw new NotFoundException('Layout not found.');
    const css = this.layouts.readCss(clean);
    if (css == null) throw new NotFoundException('Layout CSS not found.');
    return css;
  }

  /**
   * Public — run layouts/{slug}/{slug}.php with field values.
   * Editor canvas + public pages use this so edits to the PHP file show up.
   */
  @Get(':slug/render')
  @Header('Cache-Control', 'no-store')
  async renderGet(
    @Param('slug') slug: string,
    @Query('fields') fieldsRaw?: string,
  ) {
    const clean = sanitizeLayoutSlug(slug);
    if (!clean) throw new NotFoundException('Layout not found.');
    let fields: Record<string, unknown> = {};
    if (fieldsRaw) {
      try {
        const parsed = JSON.parse(fieldsRaw) as unknown;
        if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
          fields = parsed as Record<string, unknown>;
        }
      } catch {
        /* ignore bad json */
      }
    }
    const html = await this.layouts.renderPhpLayout(clean, fields);
    if (html == null) throw new NotFoundException('Layout PHP not found.');
    return { slug: clean, html };
  }

  @Post(':slug/render')
  @Header('Cache-Control', 'no-store')
  async renderPost(
    @Param('slug') slug: string,
    @Body() body: { fields?: Record<string, unknown> },
  ) {
    const clean = sanitizeLayoutSlug(slug);
    if (!clean) throw new NotFoundException('Layout not found.');
    const html = await this.layouts.renderPhpLayout(clean, body?.fields ?? {});
    if (html == null) throw new NotFoundException('Layout PHP not found.');
    return { slug: clean, html };
  }

  /** Public — ACF-formatted field values (what get_field() returns) for React layouts. */
  @Post(':slug/fields')
  @Header('Cache-Control', 'no-store')
  async formatFields(
    @Param('slug') slug: string,
    @Body() body: { fields?: Record<string, unknown> },
  ) {
    const clean = sanitizeLayoutSlug(slug);
    if (!clean) throw new NotFoundException('Layout not found.');
    const fields = await this.layouts.formatLayoutFields(clean, body?.fields ?? {});
    return { slug: clean, fields };
  }

  @Post('sync')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  async syncAll(@Req() _req: AuthedRequest) {
    const count = await this.layouts.syncAllActive();
    return { ok: true, synced: count, layouts: this.layouts.listPublic() };
  }

  @Post(':slug/compile')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('manage_options')
  compile(@Param('slug') slug: string) {
    const ok = this.layouts.compileSlug(slug);
    if (!ok) throw new NotFoundException('Layout SCSS not found.');
    return { ok: true, slug: sanitizeLayoutSlug(slug) };
  }
}
