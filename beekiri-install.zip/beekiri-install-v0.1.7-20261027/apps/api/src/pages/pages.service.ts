import { randomBytes } from 'crypto';
import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import type { AuthUser } from '../auth/auth.types';
import { PrismaService } from '../prisma/prisma.service';
import {
  contentFromHtml,
  contentFromBeekiricanva,
  contentFromBeekiriCode,
  parseContent,
  toSlug,
  type PageContentDoc,
} from './pages.content';
import type { CreatePageDto, PreviewPageDto, UpdatePageDto } from './pages.dto';

const PREVIEW_TTL_MS = 24 * 60 * 60 * 1000;
const MAX_REVISIONS = 25;
const PAGE_TYPE = 'page';

function bodyBeekiriCode(
  body: { beekiricode?: unknown; instatic?: unknown },
): unknown | undefined {
  if (body.beekiricode !== undefined) return body.beekiricode;
  if (body.instatic !== undefined) return body.instatic;
  return undefined;
}

type PostRow = {
  id: string;
  siteId: string;
  type: string;
  title: string;
  slug: string;
  status: string;
  content: unknown;
  excerpt: string;
  authorId: string | null;
  updatedById: string | null;
  parentId: string | null;
  menuOrder: number;
  publishedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
};

@Injectable()
export class PagesService {
  constructor(private readonly prisma: PrismaService) {}

  private serialize(row: PostRow) {
    const doc = parseContent(row.content);
    return {
      id: row.id,
      type: row.type,
      title: row.title,
      slug: row.slug,
      status: row.status as 'auto-draft' | 'draft' | 'publish',
      content: doc.html,
      beekiricanva: doc.beekiricanva,
      beekiricode: doc.beekiricode,
      /** @deprecated Alias — same as beekiricode */
      instatic: doc.beekiricode,
      excerpt: row.excerpt,
      authorId: row.authorId,
      updatedById: row.updatedById,
      parentId: row.parentId ?? null,
      menuOrder: row.menuOrder,
      path: `/${row.slug}`,
      publishedAt: row.publishedAt?.toISOString() ?? null,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    };
  }

  private async resolveUserName(userId: string | null | undefined) {
    if (!userId) return null;
    const user = await this.prisma.user.findFirst({
      where: { id: userId },
      select: { displayName: true, username: true },
    });
    return user?.displayName?.trim() || user?.username || null;
  }

  private async withAuthor<
    T extends { authorId: string | null; updatedById?: string | null },
  >(data: T) {
    const [authorName, updatedByName, revisionCount] = await Promise.all([
      this.resolveUserName(data.authorId),
      this.resolveUserName(data.updatedById ?? data.authorId),
      'id' in data && typeof (data as { id?: unknown }).id === 'string'
        ? this.prisma.postRevision.count({
            where: { postId: (data as { id: string }).id },
          })
        : Promise.resolve(0),
    ]);
    return {
      ...data,
      authorName,
      updatedByName,
      revisionCount,
    };
  }

  private contentChanged(a: unknown, b: unknown) {
    return JSON.stringify(a ?? null) !== JSON.stringify(b ?? null);
  }

  private shouldSnapshot(existing: PostRow, next: Prisma.PostUpdateInput) {
    // Skip empty auto-drafts that never held real content.
    if (
      existing.status === 'auto-draft' &&
      !existing.title.trim() &&
      !existing.excerpt.trim()
    ) {
      const doc = parseContent(existing.content);
      const emptyCanvas =
        !doc.beekiricanva ||
        (typeof doc.beekiricanva === 'object' &&
          Array.isArray((doc.beekiricanva as { content?: unknown }).content) &&
          (doc.beekiricanva as { content: unknown[] }).content.length === 0);
      if (emptyCanvas && !doc.html.trim()) return false;
    }

    if (next.title !== undefined && next.title !== existing.title) return true;
    if (next.slug !== undefined && next.slug !== existing.slug) return true;
    if (next.excerpt !== undefined && next.excerpt !== existing.excerpt) return true;
    if (next.status !== undefined && next.status !== existing.status) return true;
    if (next.content !== undefined && this.contentChanged(next.content, existing.content)) {
      return true;
    }
    return false;
  }

  private async createRevisionFrom(existing: PostRow) {
    await this.prisma.postRevision.create({
      data: {
        postId: existing.id,
        siteId: existing.siteId,
        title: existing.title,
        slug: existing.slug,
        status: existing.status,
        content: existing.content as Prisma.InputJsonValue,
        excerpt: existing.excerpt,
        authorId: existing.updatedById ?? existing.authorId,
      },
    });

    const old = await this.prisma.postRevision.findMany({
      where: { postId: existing.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true },
      skip: MAX_REVISIONS,
    });
    if (old.length) {
      await this.prisma.postRevision.deleteMany({
        where: { id: { in: old.map((r) => r.id) } },
      });
    }
  }

  private async uniqueSlug(siteId: string, base: string, excludeId?: string) {
    let slug = toSlug(base) || 'page';
    let n = 2;
    for (;;) {
      const existing = await this.prisma.post.findFirst({
        where: {
          siteId,
          type: PAGE_TYPE,
          slug,
          ...(excludeId ? { NOT: { id: excludeId } } : {}),
        },
        select: { id: true },
      });
      if (!existing) return slug;
      slug = `${toSlug(base) || 'page'}-${n}`;
      n += 1;
      if (n > 200) throw new ConflictException('Could not generate a unique slug.');
    }
  }

  async list(actor: AuthUser) {
    const rows = await this.prisma.post.findMany({
      where: {
        siteId: actor.siteId,
        type: PAGE_TYPE,
        // Hide abandoned auto-drafts from the main list (WordPress-style).
        NOT: { status: 'auto-draft' },
      },
      orderBy: [{ updatedAt: 'desc' }],
    });
    return { pages: rows.map((r) => this.serialize(r)) };
  }

  async get(actor: AuthUser, id: string) {
    const row = await this.prisma.post.findFirst({
      where: { id, siteId: actor.siteId, type: PAGE_TYPE },
    });
    if (!row) throw new NotFoundException('Page not found.');
    return this.withAuthor(this.serialize(row));
  }

  async create(actor: AuthUser, body: CreatePageDto) {
    const autoDraft = body.autoDraft === true || body.status === 'auto-draft';
    const title = (body.title ?? '').trim();

    let status: 'auto-draft' | 'draft' | 'publish' = 'draft';
    if (autoDraft) status = 'auto-draft';
    else if (body.status === 'publish') status = 'publish';
    else if (body.status === 'draft') status = 'draft';

    if (status === 'publish' && !actor.capabilities.includes('publish_pages')) {
      throw new ForbiddenException('You cannot publish pages.');
    }
    if (!autoDraft && !title) {
      throw new BadRequestException('Title is required.');
    }

    const slugBase = (body.slug?.trim() || title || `auto-draft-${Date.now()}`).trim();
    const slug = await this.uniqueSlug(actor.siteId, slugBase);

    const canvasIn = body.beekiricanva;
    const codeIn = bodyBeekiriCode(body);
    let contentDoc: PageContentDoc;
    if (codeIn !== undefined) {
      contentDoc = contentFromBeekiriCode(codeIn, body.content ?? '', canvasIn ?? null);
    } else if (canvasIn !== undefined) {
      contentDoc = contentFromBeekiricanva(canvasIn, body.content ?? '', null);
    } else {
      contentDoc = contentFromHtml(body.content ?? '');
    }

    const row = await this.prisma.post.create({
      data: {
        siteId: actor.siteId,
        type: PAGE_TYPE,
        title: title || '',
        slug,
        status,
        content: contentDoc as Prisma.InputJsonValue,
        excerpt: (body.excerpt ?? '').trim(),
        authorId: actor.id,
        updatedById: actor.id,
        publishedAt: status === 'publish' ? new Date() : null,
      },
    });

    return this.withAuthor(this.serialize(row));
  }

  async update(actor: AuthUser, id: string, body: UpdatePageDto) {
    const existing = await this.prisma.post.findFirst({
      where: { id, siteId: actor.siteId, type: PAGE_TYPE },
    });
    if (!existing) throw new NotFoundException('Page not found.');

    const data: Prisma.PostUpdateInput = {
      updatedById: actor.id,
    };

    if (body.title !== undefined) {
      data.title = body.title.trim();
    }

    if (body.slug !== undefined) {
      const base =
        body.slug.trim() ||
        (typeof data.title === 'string' ? data.title : existing.title) ||
        'page';
      data.slug = await this.uniqueSlug(actor.siteId, base, id);
    } else if (
      body.title !== undefined &&
      existing.status === 'auto-draft' &&
      body.title.trim() &&
      existing.slug.startsWith('auto-draft-')
    ) {
      // First real title on an auto-draft → refresh slug like WordPress permalink.
      data.slug = await this.uniqueSlug(actor.siteId, body.title.trim(), id);
    }

    const canvasIn = body.beekiricanva;
    const codeIn = bodyBeekiriCode(body);
    if (codeIn !== undefined || canvasIn !== undefined) {
      const existingDoc = parseContent(existing.content);
      const html =
        body.content !== undefined ? body.content : existingDoc.html;
      if (codeIn !== undefined) {
        data.content = contentFromBeekiriCode(
          codeIn,
          html,
          canvasIn !== undefined ? canvasIn : existingDoc.beekiricanva,
        ) as Prisma.InputJsonValue;
      } else {
        data.content = contentFromBeekiricanva(
          canvasIn,
          html,
          existingDoc.beekiricode,
        ) as Prisma.InputJsonValue;
      }
    } else if (body.content !== undefined) {
      const existingDoc = parseContent(existing.content);
      data.content = {
        ...contentFromHtml(body.content),
        beekiricanva: existingDoc.beekiricanva,
        beekiricode: existingDoc.beekiricode,
        version: existingDoc.beekiricanva || existingDoc.beekiricode ? 2 : 1,
        preview: null,
      } as Prisma.InputJsonValue;
    }

    if (body.excerpt !== undefined) {
      data.excerpt = body.excerpt.trim();
    }

    if (body.status !== undefined) {
      if (body.status === 'publish' && !actor.capabilities.includes('publish_pages')) {
        throw new ForbiddenException('You cannot publish pages.');
      }
      data.status = body.status;
      if (body.status === 'publish' && !existing.publishedAt) {
        data.publishedAt = new Date();
      }
    } else if (existing.status === 'auto-draft') {
      // Saving an auto-draft without explicit status promotes it to draft.
      data.status = 'draft';
    }

    try {
      if (this.shouldSnapshot(existing, data)) {
        await this.createRevisionFrom(existing);
      }
      const row = await this.prisma.post.update({
        where: { id },
        data,
      });
      return this.withAuthor(this.serialize(row));
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
        throw new ConflictException('A page with that slug already exists.');
      }
      throw e;
    }
  }

  async listRevisions(actor: AuthUser, id: string) {
    const existing = await this.prisma.post.findFirst({
      where: { id, siteId: actor.siteId, type: PAGE_TYPE },
      select: { id: true },
    });
    if (!existing) throw new NotFoundException('Page not found.');

    const rows = await this.prisma.postRevision.findMany({
      where: { postId: id, siteId: actor.siteId },
      orderBy: { createdAt: 'desc' },
      take: MAX_REVISIONS,
    });

    const authorIds = [...new Set(rows.map((r) => r.authorId).filter(Boolean))] as string[];
    const users = authorIds.length
      ? await this.prisma.user.findMany({
          where: { id: { in: authorIds } },
          select: { id: true, displayName: true, username: true },
        })
      : [];
    const nameById = new Map(
      users.map((u) => [
        u.id,
        u.displayName?.trim() || u.username || null,
      ]),
    );

    return {
      revisions: rows.map((r) => ({
        id: r.id,
        title: r.title,
        slug: r.slug,
        status: r.status,
        authorId: r.authorId,
        authorName: r.authorId ? nameById.get(r.authorId) ?? null : null,
        createdAt: r.createdAt.toISOString(),
      })),
    };
  }

  async restoreRevision(actor: AuthUser, id: string, revisionId: string) {
    const existing = await this.prisma.post.findFirst({
      where: { id, siteId: actor.siteId, type: PAGE_TYPE },
    });
    if (!existing) throw new NotFoundException('Page not found.');

    const revision = await this.prisma.postRevision.findFirst({
      where: { id: revisionId, postId: id, siteId: actor.siteId },
    });
    if (!revision) throw new NotFoundException('Revision not found.');

    if (
      revision.status === 'publish' &&
      !actor.capabilities.includes('publish_pages')
    ) {
      throw new ForbiddenException('You cannot restore a published revision.');
    }

    await this.createRevisionFrom(existing);

    try {
      const row = await this.prisma.post.update({
        where: { id },
        data: {
          title: revision.title,
          slug: await this.uniqueSlug(actor.siteId, revision.slug || revision.title || 'page', id),
          status:
            revision.status === 'auto-draft' ? 'draft' : revision.status,
          content: revision.content as Prisma.InputJsonValue,
          excerpt: revision.excerpt,
          updatedById: actor.id,
          ...(revision.status === 'publish' && !existing.publishedAt
            ? { publishedAt: new Date() }
            : {}),
        },
      });
      return this.withAuthor(this.serialize(row));
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
        throw new ConflictException('A page with that slug already exists.');
      }
      throw e;
    }
  }

  async remove(actor: AuthUser, id: string) {
    const existing = await this.prisma.post.findFirst({
      where: { id, siteId: actor.siteId, type: PAGE_TYPE },
      select: { id: true, title: true },
    });
    if (!existing) throw new NotFoundException('Page not found.');
    await this.prisma.post.delete({ where: { id } });
    return { ok: true, id: existing.id, title: existing.title };
  }

  /** Published pages for menus / link picker. */
  async listPublishedTargets(siteId: string) {
    const rows = await this.prisma.post.findMany({
      where: { siteId, type: PAGE_TYPE, status: 'publish' },
      orderBy: [{ title: 'asc' }],
      select: { id: true, title: true, slug: true },
    });
    return rows.map((r) => ({
      id: r.id,
      label: r.title,
      path: `/${r.slug}`,
      source: 'page' as const,
    }));
  }

  async countForSite(siteId: string) {
    return this.prisma.post.count({
      where: { siteId, type: PAGE_TYPE, NOT: { status: 'auto-draft' } },
    });
  }

  /**
   * WordPress-style preview: store current editor state as a tokenized snapshot.
   * Published pages keep live content untouched; drafts are saved as draft.
   */
  async createPreview(actor: AuthUser, id: string, body: PreviewPageDto) {
    const existing = await this.prisma.post.findFirst({
      where: { id, siteId: actor.siteId, type: PAGE_TYPE },
    });
    if (!existing) throw new NotFoundException('Page not found.');

    const title =
      body.title !== undefined ? body.title.trim() : existing.title;
    const excerpt =
      body.excerpt !== undefined ? body.excerpt.trim() : existing.excerpt;
    const existingDoc = parseContent(existing.content);
    const canvasDoc = body.beekiricanva ?? existingDoc.beekiricanva;
    const codeBody = bodyBeekiriCode(body);
    const codeDoc = codeBody !== undefined ? codeBody : existingDoc.beekiricode;
    const htmlDoc =
      codeBody !== undefined
        ? contentFromBeekiriCode(codeDoc, existingDoc.html, canvasDoc)
        : contentFromBeekiricanva(canvasDoc, existingDoc.html, existingDoc.beekiricode);

    let slug = existing.slug;
    if (body.slug !== undefined) {
      const base = body.slug.trim() || title || 'page';
      slug = await this.uniqueSlug(actor.siteId, base, id);
    } else if (
      existing.status === 'auto-draft' &&
      title &&
      existing.slug.startsWith('auto-draft-')
    ) {
      slug = await this.uniqueSlug(actor.siteId, title, id);
    }

    const token = randomBytes(24).toString('hex');
    const expiresAt = new Date(Date.now() + PREVIEW_TTL_MS).toISOString();
    const preview = {
      token,
      expiresAt,
      title,
      excerpt,
      html: htmlDoc.html,
      beekiricanva: htmlDoc.beekiricanva,
      beekiricode: htmlDoc.beekiricode,
    };

    const isLive = existing.status === 'publish';
    let nextDoc: PageContentDoc;

    if (isLive) {
      // Keep published body; only attach preview snapshot.
      nextDoc = { ...existingDoc, preview };
    } else {
      nextDoc = {
        ...htmlDoc,
        preview,
      };
    }

    const data: Prisma.PostUpdateInput = {
      content: nextDoc as Prisma.InputJsonValue,
      updatedById: actor.id,
    };

    if (!isLive) {
      data.title = title;
      data.slug = slug;
      data.excerpt = excerpt;
      if (existing.status === 'auto-draft') {
        data.status = 'draft';
      }
      if (this.shouldSnapshot(existing, data)) {
        await this.createRevisionFrom(existing);
      }
    }

    try {
      const row = await this.prisma.post.update({
        where: { id },
        data,
      });
      const serialized = await this.withAuthor(this.serialize(row));
      const path = `/${serialized.slug}`;
      return {
        page: serialized,
        previewPath: `${path}?preview=1&token=${encodeURIComponent(token)}`,
        previewToken: token,
        expiresAt,
      };
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
        throw new ConflictException('A page with that slug already exists.');
      }
      throw e;
    }
  }

  async getPublishedBySlug(slug: string, previewToken?: string) {
    const clean = toSlug(slug);
    if (!clean) throw new NotFoundException('Page not found.');
    const site = await this.prisma.site.findFirst({ orderBy: { createdAt: 'asc' } });
    if (!site) throw new NotFoundException('Page not found.');
    const row = await this.prisma.post.findFirst({
      where: {
        siteId: site.id,
        type: PAGE_TYPE,
        slug: clean,
      },
    });
    if (!row) throw new NotFoundException('Page not found.');

    const doc = parseContent(row.content);
    const token = previewToken?.trim();
    if (token && doc.preview?.token === token) {
      const exp = Date.parse(doc.preview.expiresAt);
      if (!Number.isFinite(exp) || exp < Date.now()) {
        throw new NotFoundException('Preview link has expired.');
      }
      return {
        title: doc.preview.title || row.title,
        slug: row.slug,
        path: `/${row.slug}`,
        content: doc.preview.html,
        beekiricanva: doc.preview.beekiricanva,
        beekiricode: doc.preview.beekiricode,
        instatic: doc.preview.beekiricode,
        excerpt: doc.preview.excerpt,
        publishedAt: row.publishedAt?.toISOString() ?? null,
        updatedAt: row.updatedAt.toISOString(),
        preview: true as const,
      };
    }

    if (row.status !== 'publish') {
      throw new NotFoundException('Page not found.');
    }

    const data = this.serialize(row);
    return {
      title: data.title,
      slug: data.slug,
      path: data.path,
      content: data.content,
      beekiricanva: data.beekiricanva,
      beekiricode: data.beekiricode,
      instatic: data.beekiricode,
      excerpt: data.excerpt,
      publishedAt: data.publishedAt,
      updatedAt: data.updatedAt,
      preview: false as const,
    };
  }
}
