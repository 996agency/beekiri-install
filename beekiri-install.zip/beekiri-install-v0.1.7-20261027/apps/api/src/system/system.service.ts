import { Injectable, Logger } from '@nestjs/common';
import { readFileSync, existsSync } from 'fs';
import { createRequire } from 'module';
import { join } from 'path';
import { findRepoRoot } from '../media/media.paths';
import { PrismaService } from '../prisma/prisma.service';

const requireFromHere = createRequire(__filename);

export type LighthouseScores = {
  url: string;
  performance: number;
  accessibility: number;
  bestPractices: number;
  seo: number;
  checkedAt: string;
  source: 'lighthouse' | 'cached' | 'error';
  message: string;
  allHundred: boolean;
};

export type CoreManifest = {
  name: string;
  coreVersion: string;
  releaseRepo: string;
  minNode: string;
  channel: string;
  notes?: string;
};

export type UpdateCheck = {
  currentVersion: string;
  latestVersion: string | null;
  updateAvailable: boolean;
  updateCount: number;
  releaseUrl: string | null;
  downloadUrl: string | null;
  releaseName: string | null;
  publishedAt: string | null;
  checkedAt: string;
  source: 'github' | 'github-tags' | 'manifest-only' | 'error';
  message: string;
  updateSteps: string[];
};

export type SystemStatus = {
  api: { ok: boolean; label: string };
  database: { ok: boolean; label: string };
  uptimeSeconds: number;
  nodeVersion: string;
  environment: string;
  coreVersion: string;
  channel: string;
  checkedAt: string;
  /** Short labels for Status rows, e.g. "Next.js 15.5 · React 18.3". */
  frontend: string;
  admin: string;
  apiStack: string;
  databaseEngine: string;
};

@Injectable()
export class SystemService {
  private readonly logger = new Logger(SystemService.name);
  private lighthouseCache: { at: number; scores: LighthouseScores } | null = null;
  private lighthouseInFlight: Promise<LighthouseScores> | null = null;
  private readonly lighthouseTtlMs = 5 * 60 * 1000;

  constructor(private readonly prisma: PrismaService) {}

  getManifest(): CoreManifest {
    const candidates = [
      join(process.cwd(), 'beekiri.manifest.json'),
      join(process.cwd(), '..', '..', 'beekiri.manifest.json'),
      join(__dirname, '..', '..', '..', '..', 'beekiri.manifest.json'),
    ];
    for (const path of candidates) {
      if (existsSync(path)) {
        try {
          return JSON.parse(readFileSync(path, 'utf8')) as CoreManifest;
        } catch (e) {
          this.logger.warn(`Failed to read manifest at ${path}`);
        }
      }
    }
    return {
      name: 'beekiri-cms',
      coreVersion: process.env.BEEKIRI_CORE_VERSION ?? '0.1.7',
      releaseRepo: process.env.BEEKIRI_RELEASE_REPO ?? '996agency/beekiri-install',
      minNode: '20',
      channel: 'stable',
    };
  }

  getVersionInfo() {
    const manifest = this.getManifest();
    return {
      coreVersion: manifest.coreVersion,
      name: manifest.name,
      channel: manifest.channel,
      releaseRepo: manifest.releaseRepo,
      minNode: manifest.minNode,
      nodeVersion: process.version,
      notes: manifest.notes ?? null,
      environment: process.env.NODE_ENV ?? 'development',
    };
  }

  private readPkgVersion(pkgName: string): string {
    try {
      const pkg = requireFromHere(`${pkgName}/package.json`) as { version?: string };
      if (pkg.version) return pkg.version;
    } catch {
      /* fall through */
    }
    try {
      const root = findRepoRoot();
      const candidates = [
        join(root, 'node_modules', ...pkgName.split('/'), 'package.json'),
        join(root, 'apps/api/node_modules', ...pkgName.split('/'), 'package.json'),
        join(root, 'apps/web/node_modules', ...pkgName.split('/'), 'package.json'),
        join(root, 'apps/admin/node_modules', ...pkgName.split('/'), 'package.json'),
      ];
      for (const path of candidates) {
        if (!existsSync(path)) continue;
        const pkg = JSON.parse(readFileSync(path, 'utf8')) as { version?: string };
        if (pkg.version) return pkg.version;
      }
    } catch {
      /* ignore */
    }
    return '';
  }

  private shortVer(pkgName: string, fallback = ''): string {
    const v = this.readPkgVersion(pkgName) || fallback;
    if (!v) return '';
    // Keep major.minor (drop patch noise in Status)
    const m = v.replace(/^v/, '').match(/^(\d+\.\d+)/);
    return m?.[1] ?? v.replace(/^v/, '');
  }

  async getStatus(): Promise<SystemStatus> {
    const manifest = this.getManifest();
    let databaseOk = false;
    let databaseEngine = 'PostgreSQL';
    try {
      await this.prisma.$queryRaw`SELECT 1`;
      databaseOk = true;
      try {
        const rows = await this.prisma.$queryRaw<{ v: string }[]>`SELECT version() AS v`;
        const raw = rows?.[0]?.v ?? '';
        const m = raw.match(/PostgreSQL\s+([\d.]+)/i);
        databaseEngine = m ? `PostgreSQL ${m[1]}` : 'PostgreSQL';
      } catch {
        /* keep default */
      }
    } catch {
      databaseOk = false;
    }

    const next = this.shortVer('next');
    const react = this.shortVer('react');
    const vite = this.shortVer('vite');
    const nest = this.shortVer('@nestjs/core');
    const fastify = this.shortVer('fastify');

    const frontend = ['Next.js' + (next ? ` ${next}` : ''), react ? `React ${react}` : '']
      .filter(Boolean)
      .join(' · ');
    const admin = ['Vite' + (vite ? ` ${vite}` : ''), react ? `React ${react}` : '']
      .filter(Boolean)
      .join(' · ');
    const apiStack = [
      'NestJS' + (nest ? ` ${nest}` : ''),
      fastify ? `Fastify ${fastify}` : '',
    ]
      .filter(Boolean)
      .join(' · ');

    return {
      api: { ok: true, label: 'Running' },
      database: {
        ok: databaseOk,
        label: databaseOk ? 'Connected' : 'Unavailable',
      },
      uptimeSeconds: Math.floor(process.uptime()),
      nodeVersion: process.version,
      environment: process.env.NODE_ENV ?? 'development',
      coreVersion: manifest.coreVersion,
      channel: manifest.channel,
      checkedAt: new Date().toISOString(),
      frontend: frontend || 'Next.js',
      admin: admin || 'Vite',
      apiStack: apiStack || 'NestJS',
      databaseEngine,
    };
  }

  private compareSemver(a: string, b: string): number {
    const pa = a.replace(/^v/, '').split('.').map((n) => Number(n) || 0);
    const pb = b.replace(/^v/, '').split('.').map((n) => Number(n) || 0);
    const len = Math.max(pa.length, pb.length);
    for (let i = 0; i < len; i++) {
      const da = pa[i] ?? 0;
      const db = pb[i] ?? 0;
      if (da > db) return 1;
      if (da < db) return -1;
    }
    return 0;
  }

  private githubHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      Accept: 'application/vnd.github+json',
      'User-Agent': 'Beekiri-CMS-Update-Check',
    };
    const token = process.env.BEEKIRI_GITHUB_TOKEN || process.env.GITHUB_TOKEN;
    if (token) headers.Authorization = `Bearer ${token}`;
    return headers;
  }

  private downloadUrlFor(repo: string, version: string | null): string {
    // Stable public ZIP on main (always latest packaged install)
    if (!version) {
      return `https://github.com/${repo}/raw/main/beekiri-install.zip`;
    }
    return `https://github.com/${repo}/raw/main/beekiri-install-v${version}.zip`;
  }

  private buildResult(opts: {
    currentVersion: string;
    latestVersion: string | null;
    releaseUrl: string | null;
    downloadUrl: string | null;
    releaseName: string | null;
    publishedAt: string | null;
    checkedAt: string;
    source: UpdateCheck['source'];
    updateSteps: string[];
    fallbackMessage?: string;
  }): UpdateCheck {
    const updateAvailable = opts.latestVersion
      ? this.compareSemver(opts.latestVersion, opts.currentVersion) > 0
      : false;
    const updateCount = updateAvailable ? 1 : 0;

    let message = opts.fallbackMessage ?? `You're up to date (v${opts.currentVersion}).`;
    if (updateAvailable && opts.latestVersion) {
      message = `Update available — Beekiri Core v${opts.latestVersion} (you are on v${opts.currentVersion}). Click Update to continue.`;
    }

    return {
      currentVersion: opts.currentVersion,
      latestVersion: opts.latestVersion,
      updateAvailable,
      updateCount,
      releaseUrl: opts.releaseUrl,
      downloadUrl: opts.downloadUrl,
      releaseName: opts.releaseName,
      publishedAt: opts.publishedAt,
      checkedAt: opts.checkedAt,
      source: opts.source,
      message,
      updateSteps: opts.updateSteps,
    };
  }

  /** Prefer the highest semver among Releases AND tags (tags alone used to be ignored). */
  private async resolveLatestVersion(
    repo: string,
    headers: Record<string, string>,
  ): Promise<{
    latestVersion: string | null;
    releaseUrl: string | null;
    releaseName: string | null;
    publishedAt: string | null;
    source: UpdateCheck['source'];
  }> {
    const best: {
      latestVersion: string | null;
      releaseUrl: string | null;
      releaseName: string | null;
      publishedAt: string | null;
      source: UpdateCheck['source'];
    } = {
      latestVersion: null,
      releaseUrl: null,
      releaseName: null,
      publishedAt: null,
      source: 'manifest-only',
    };

    const consider = (
      verRaw: string | undefined | null,
      meta?: {
        url?: string | null;
        name?: string | null;
        publishedAt?: string | null;
        source?: UpdateCheck['source'];
      },
    ) => {
      const ver = (verRaw || '').replace(/^v/, '');
      if (!/^\d+\.\d+/.test(ver)) return;
      if (!best.latestVersion || this.compareSemver(ver, best.latestVersion) > 0) {
        best.latestVersion = ver;
        if (meta?.url) best.releaseUrl = meta.url;
        if (meta?.name) best.releaseName = meta.name;
        if (meta?.publishedAt) best.publishedAt = meta.publishedAt;
        if (meta?.source) best.source = meta.source;
      }
    };

    try {
      const releaseRes = await fetch(
        `https://api.github.com/repos/${repo}/releases/latest`,
        { headers },
      );
      if (releaseRes.ok) {
        const data = (await releaseRes.json()) as {
          tag_name?: string;
          name?: string;
          html_url?: string;
          published_at?: string;
        };
        consider(data.tag_name, {
          url: data.html_url,
          name: data.name ?? data.tag_name,
          publishedAt: data.published_at,
          source: 'github',
        });
      }

      // Also scan recent releases (latest endpoint can lag / miss if only tags exist)
      const listRes = await fetch(
        `https://api.github.com/repos/${repo}/releases?per_page=15`,
        { headers },
      );
      if (listRes.ok) {
        const list = (await listRes.json()) as {
          tag_name?: string;
          name?: string;
          html_url?: string;
          published_at?: string;
          draft?: boolean;
        }[];
        for (const item of list) {
          if (item.draft) continue;
          consider(item.tag_name, {
            url: item.html_url,
            name: item.name ?? item.tag_name,
            publishedAt: item.published_at,
            source: 'github',
          });
        }
      }
    } catch (e) {
      this.logger.warn(`Release list failed: ${e instanceof Error ? e.message : e}`);
    }

    try {
      const tagsRes = await fetch(
        `https://api.github.com/repos/${repo}/tags?per_page=30`,
        { headers },
      );
      if (tagsRes.ok) {
        const tags = (await tagsRes.json()) as { name?: string }[];
        for (const tag of tags) {
          const ver = (tag.name || '').replace(/^v/, '');
          const matchedRelease = Boolean(best.releaseUrl?.includes(ver));
          consider(tag.name, {
            url: tag.name
              ? `https://github.com/${repo}/releases/tag/${tag.name}`
              : null,
            name: tag.name,
            source: matchedRelease ? 'github' : 'github-tags',
          });
          // Tag alone (no matching Release URL) — prefer github-tags
          if (
            best.latestVersion &&
            ver === best.latestVersion &&
            !best.releaseUrl?.includes(ver)
          ) {
            best.source = 'github-tags';
            best.releaseUrl = `https://github.com/${repo}/releases/tag/v${ver}`;
            best.releaseName = `v${ver}`;
          }
        }
      }
    } catch (e) {
      this.logger.warn(`Tags list failed: ${e instanceof Error ? e.message : e}`);
    }

    // Fix source when newest came from tags beating an older Release
    if (best.latestVersion && best.releaseUrl) {
      const urlMissesVersion =
        !best.releaseUrl.includes(`v${best.latestVersion}`) &&
        !best.releaseUrl.includes(`/${best.latestVersion}`);
      if (urlMissesVersion) {
        best.source = 'github-tags';
        best.releaseUrl = `https://github.com/${repo}/releases/tag/v${best.latestVersion}`;
        best.releaseName = `v${best.latestVersion}`;
        best.publishedAt = null;
      }
    }

    return best;
  }

  async checkUpdates(): Promise<UpdateCheck> {
    const manifest = this.getManifest();
    const currentVersion = manifest.coreVersion;
    const repo = manifest.releaseRepo;
    const releasesPage = `https://github.com/${repo}/releases`;
    const zipLatest = `https://github.com/${repo}/raw/main/beekiri-install.zip`;
    const updateSteps = [
      'Click Check for updates.',
      'If a new version is available, click Update.',
      'Your content and settings stay on this site.',
    ];
    const checkedAt = new Date().toISOString();
    const headers = this.githubHeaders();

    try {
      const resolved = await this.resolveLatestVersion(repo, headers);
      if (!resolved.latestVersion) {
        return this.buildResult({
          currentVersion,
          latestVersion: null,
          releaseUrl: releasesPage,
          downloadUrl: zipLatest,
          releaseName: null,
          publishedAt: null,
          checkedAt,
          source: 'manifest-only',
          updateSteps,
          fallbackMessage: "You're on the current Beekiri Core.",
        });
      }

      return this.buildResult({
        currentVersion,
        latestVersion: resolved.latestVersion,
        releaseUrl: resolved.releaseUrl ?? releasesPage,
        downloadUrl: this.downloadUrlFor(repo, resolved.latestVersion),
        releaseName: resolved.releaseName,
        publishedAt: resolved.publishedAt,
        checkedAt,
        source: resolved.source,
        updateSteps,
      });
    } catch (e) {
      this.logger.warn(`Update check failed: ${e instanceof Error ? e.message : e}`);
      return this.buildResult({
        currentVersion,
        latestVersion: null,
        releaseUrl: releasesPage,
        downloadUrl: zipLatest,
        releaseName: null,
        publishedAt: null,
        checkedAt,
        source: 'error',
        updateSteps,
        fallbackMessage: 'Could not check for updates right now. Try again in a moment.',
      });
    }
  }

  private scorePct(value: number | null | undefined): number {
    if (typeof value !== 'number' || Number.isNaN(value)) return 0;
    return Math.round(value * 100);
  }

  async getLighthouseScores(opts?: { force?: boolean }): Promise<LighthouseScores> {
    const force = Boolean(opts?.force);
    const now = Date.now();
    if (
      !force &&
      this.lighthouseCache &&
      now - this.lighthouseCache.at < this.lighthouseTtlMs
    ) {
      return { ...this.lighthouseCache.scores, source: 'cached' };
    }
    if (this.lighthouseInFlight) return this.lighthouseInFlight;

    this.lighthouseInFlight = this.runLighthouse().finally(() => {
      this.lighthouseInFlight = null;
    });
    return this.lighthouseInFlight;
  }

  private async runLighthouse(): Promise<LighthouseScores> {
    const checkedAt = new Date().toISOString();
    let chrome: Awaited<ReturnType<typeof import('chrome-launcher')['launch']>> | null = null;
    let targetUrl = (process.env.APP_URL ?? 'http://127.0.0.1:8789').replace(/\/$/, '');
    let cleanup: (() => Promise<void>) | null = null;

    try {
      const { resolveLighthouseTarget } = await import('./lighthouse-target');
      const target = await resolveLighthouseTarget();
      targetUrl = target.url;
      cleanup = target.cleanup;

      const chromeLauncher = await import('chrome-launcher');
      const lighthouseMod = await import('lighthouse');
      const run =
        typeof lighthouseMod === 'function'
          ? lighthouseMod
          : (lighthouseMod as unknown as { default: typeof lighthouseMod }).default;

      chrome = await chromeLauncher.launch({
        chromeFlags: ['--headless', '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage'],
      });

      const result = await (
        run as unknown as (
          target: string,
          flags: Record<string, unknown>,
        ) => Promise<{ lhr: { categories: Record<string, { score: number | null }> } } | undefined>
      )(targetUrl, {
        port: chrome.port,
        output: 'json',
        logLevel: 'error',
        onlyCategories: ['performance', 'accessibility', 'best-practices', 'seo'],
      });

      if (!result?.lhr?.categories) {
        throw new Error('Lighthouse returned no categories');
      }

      const cats = result.lhr.categories;
      const performance = this.scorePct(cats.performance?.score);
      const accessibility = this.scorePct(cats.accessibility?.score);
      const bestPractices = this.scorePct(cats['best-practices']?.score);
      const seo = this.scorePct(cats.seo?.score);
      const allHundred =
        performance === 100 &&
        accessibility === 100 &&
        bestPractices === 100 &&
        seo === 100;

      const modeNote =
        target.mode === 'production-ephemeral'
          ? ' (production build)'
          : target.mode === 'configured'
            ? ' (LIGHTHOUSE_URL)'
            : ' (live APP_URL — use production for Performance 100)';

      const scores: LighthouseScores = {
        url: targetUrl,
        performance,
        accessibility,
        bestPractices,
        seo,
        checkedAt,
        source: 'lighthouse',
        message: allHundred
          ? `All Lighthouse categories are 100.${modeNote}`
          : `Lighthouse finished — improve any category below 100.${modeNote}`,
        allHundred,
      };
      this.lighthouseCache = { at: Date.now(), scores };
      return scores;
    } catch (e) {
      const message = e instanceof Error ? e.message : 'Lighthouse run failed';
      this.logger.warn(`Lighthouse audit failed: ${message}`);
      return {
        url: targetUrl,
        performance: 0,
        accessibility: 0,
        bestPractices: 0,
        seo: 0,
        checkedAt,
        source: 'error',
        message: `Could not run Lighthouse (${message}). Is Chrome installed?`,
        allHundred: false,
      };
    } finally {
      try {
        chrome?.kill();
      } catch {
        /* ignore */
      }
      try {
        await cleanup?.();
      } catch {
        /* ignore */
      }
    }
  }
}
