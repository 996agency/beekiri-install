import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  NotFoundException,
  Param,
  Post,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';
import { ApiConsumes, ApiTags } from '@nestjs/swagger';
import type { MultipartFile } from '@fastify/multipart';
import type { FastifyReply } from 'fastify';
import { createReadStream } from 'fs';
import { extname } from 'path';
import { AuthGuard, type AuthedRequest } from '../auth/auth.guard';
import { CapabilitiesGuard } from '../auth/capabilities.guard';
import { RequireCapabilities } from '../auth/capabilities.decorator';
import { ThemeSlugDto } from './themes.dto';
import { ThemesService } from './themes.service';

const MIME: Record<string, string> = {
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
};

@ApiTags('themes')
@Controller('themes')
export class ThemesController {
  constructor(private readonly themes: ThemesService) {}

  @Get()
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_theme_options')
  list() {
    return this.themes.list();
  }

  @Post('activate')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_theme_options')
  activate(@Body() body: ThemeSlugDto) {
    return this.themes.activate(body.slug);
  }

  @Post('deactivate')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_theme_options')
  deactivate(@Body() body: ThemeSlugDto) {
    return this.themes.deactivate(body.slug);
  }

  @Post('upload')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_theme_options')
  @ApiConsumes('multipart/form-data')
  async upload(@Req() req: AuthedRequest) {
    const file = (await req.file()) as MultipartFile | undefined;
    if (!file) throw new BadRequestException('No file uploaded. Use field name "file".');
    const buffer = await file.toBuffer();
    return this.themes.uploadZip(buffer, file.filename || 'theme.zip');
  }

  @Delete(':slug')
  @UseGuards(AuthGuard, CapabilitiesGuard)
  @RequireCapabilities('edit_theme_options')
  remove(@Param('slug') slug: string) {
    return this.themes.remove(slug);
  }

  /** Public screenshot for Appearance cards. */
  @Get(':slug/screenshot')
  async screenshot(@Param('slug') slug: string, @Res() res: FastifyReply) {
    const path = this.themes.resolveScreenshotPath(slug);
    if (!path) throw new NotFoundException('Screenshot not found');
    const type = MIME[extname(path).toLowerCase()] ?? 'application/octet-stream';
    res.header('Content-Type', type);
    res.header('Cache-Control', 'public, max-age=3600');
    return res.send(createReadStream(path));
  }
}
