import { existsSync, readFileSync, readdirSync } from 'fs';
import { join } from 'path';
import { findRepoRoot } from '../media/media.paths';

export const DEFAULT_THEME_SLUG = 'beekiri';

/** Themes that ship with the CMS — cannot be deleted. */
export const BUILTIN_THEME_SLUGS = new Set(['beekiri']);

export type ThemeManifest = {
  slug: string;
  name: string;
  version: string;
  description: string;
  author: string;
  tags: string[];
  requires?: string;
  screenshot?: string;
  stylesheet?: string;
  builtin: boolean;
};

/** Built-in fallback when the themes folder is missing. */
const BUILTIN: ThemeManifest[] = [
  {
    slug: 'beekiri',
    name: 'Beekiri',
    version: '1.0.0',
    description:
      'The official Beekiri starter theme — clean, accessible, and ready for your content.',
    author: '996agency',
    tags: ['starter', 'blog', 'business'],
    requires: '0.1.0',
    screenshot: 'screenshot.svg',
    stylesheet: 'style.css',
    builtin: true,
  },
];

export function resolveThemesRoot(): string {
  // Frontend themes live with the public web app.
  return join(findRepoRoot(), 'apps/web/themes');
}

export function sanitizeThemeSlug(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/[^a-z0-9-_]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
}

function readManifest(dir: string, slug: string): ThemeManifest | null {
  const file = join(dir, 'theme.json');
  if (!existsSync(file)) return null;
  try {
    const raw = JSON.parse(readFileSync(file, 'utf8')) as Partial<ThemeManifest>;
    const name = typeof raw.name === 'string' ? raw.name.trim() : '';
    if (!name) return null;
    const resolvedSlug =
      typeof raw.slug === 'string' && raw.slug.trim()
        ? sanitizeThemeSlug(raw.slug)
        : sanitizeThemeSlug(slug);
    if (!resolvedSlug) return null;
    return {
      slug: resolvedSlug,
      name,
      version: typeof raw.version === 'string' ? raw.version : '1.0.0',
      description: typeof raw.description === 'string' ? raw.description : '',
      author: typeof raw.author === 'string' ? raw.author : '',
      tags: Array.isArray(raw.tags)
        ? raw.tags.filter((t): t is string => typeof t === 'string')
        : [],
      requires: typeof raw.requires === 'string' ? raw.requires : undefined,
      screenshot: typeof raw.screenshot === 'string' ? raw.screenshot : 'screenshot.svg',
      stylesheet: typeof raw.stylesheet === 'string' ? raw.stylesheet : 'style.css',
      builtin: BUILTIN_THEME_SLUGS.has(resolvedSlug),
    };
  } catch {
    return null;
  }
}

export function listThemeManifests(): ThemeManifest[] {
  const root = resolveThemesRoot();
  const bySlug = new Map<string, ThemeManifest>();

  for (const theme of BUILTIN) bySlug.set(theme.slug, theme);

  if (existsSync(root)) {
    for (const entry of readdirSync(root, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      if (entry.name.startsWith('.') || entry.name === 'beekiri-starter') continue;
      const manifest = readManifest(join(root, entry.name), entry.name);
      if (!manifest) continue;
      // Prefer filesystem copy for builtins (local edits), keep builtin flag.
      bySlug.set(manifest.slug, {
        ...manifest,
        builtin: BUILTIN_THEME_SLUGS.has(manifest.slug),
      });
    }
  }

  return [...bySlug.values()].sort((a, b) => {
    if (a.slug === DEFAULT_THEME_SLUG) return -1;
    if (b.slug === DEFAULT_THEME_SLUG) return 1;
    return a.name.localeCompare(b.name);
  });
}

export function getThemeManifest(slug: string): ThemeManifest | null {
  return listThemeManifests().find((t) => t.slug === slug) ?? null;
}

export function resolveThemeFile(slug: string, file: string): string | null {
  if (!slug || !file || file.includes('..') || file.includes('/') || file.includes('\\')) {
    return null;
  }
  const abs = join(resolveThemesRoot(), slug, file);
  return existsSync(abs) ? abs : null;
}

export function resolveThemeDir(slug: string): string | null {
  const clean = sanitizeThemeSlug(slug);
  if (!clean) return null;
  const abs = join(resolveThemesRoot(), clean);
  return existsSync(abs) ? abs : null;
}
