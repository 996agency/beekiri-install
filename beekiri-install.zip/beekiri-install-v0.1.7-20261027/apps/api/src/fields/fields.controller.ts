import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { AuthGuard, type AuthedRequest } from '../auth/auth.guard';
import { CapabilitiesGuard } from '../auth/capabilities.guard';
import { RequireCapabilities } from '../auth/capabilities.decorator';
import { CreateFieldGroupDto, UpdateFieldGroupDto } from './fields.dto';
import { FieldsService } from './fields.service';
import { FIELD_TYPES, LOCATION_TARGETS } from './fields.types';
import { StructureService } from './structure.service';
import {
  CreateOptionsPageDto,
  CreatePostTypeDto,
  CreateTaxonomyDto,
  FieldsSettingsDto,
  UpdateOptionsPageDto,
  UpdatePostTypeDto,
  UpdateTaxonomyDto,
} from './structure.dto';

@ApiTags('fields')
@Controller('fields')
@UseGuards(AuthGuard, CapabilitiesGuard)
export class FieldsController {
  constructor(
    private readonly fields: FieldsService,
    private readonly structure: StructureService,
  ) {}

  @Get('meta')
  @RequireCapabilities('manage_options')
  async meta(@Req() req: AuthedRequest) {
    const { postTypes } = await this.structure.listPostTypes(req.auth!.user);
    const customLocations = postTypes
      .filter((p) => p.active)
      .map((p) => ({ value: p.slug, label: p.plural }));
    return {
      fieldTypes: FIELD_TYPES.map((type) => ({
        type,
        label: type.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
      })),
      locations: [
        ...LOCATION_TARGETS.map((value) => ({
          value,
          label:
            value === 'user'
              ? 'Users'
              : value === 'media'
                ? 'Media'
                : `${value[0].toUpperCase()}${value.slice(1)}s`,
        })),
        ...customLocations,
      ],
    };
  }

  /** Relational field pickers (post_object / page_link / relationship). */
  @Get('lookup/posts')
  @RequireCapabilities('edit_pages')
  lookupPosts(
    @Req() req: AuthedRequest,
    @Query('types') types?: string,
    @Query('q') q?: string,
    @Query('ids') ids?: string,
  ) {
    return this.fields.lookupPosts(req.auth!.user, {
      types: types ? types.split(',') : [],
      q: q ?? '',
      ids: ids ? ids.split(',') : [],
    });
  }

  /** User field picker. */
  @Get('lookup/users')
  @RequireCapabilities('edit_pages')
  lookupUsers(
    @Req() req: AuthedRequest,
    @Query('q') q?: string,
    @Query('ids') ids?: string,
    @Query('roles') roles?: string,
  ) {
    return this.fields.lookupUsers(req.auth!.user, {
      q: q ?? '',
      ids: ids ? ids.split(',') : [],
      roles: roles ? roles.split(',') : [],
    });
  }

  /* —— Structure: post types / taxonomies / options / settings —— */

  @Get('post-types')
  @RequireCapabilities('manage_options')
  listPostTypes(@Req() req: AuthedRequest) {
    return this.structure.listPostTypes(req.auth!.user);
  }

  @Post('post-types')
  @RequireCapabilities('manage_options')
  createPostType(@Req() req: AuthedRequest, @Body() body: CreatePostTypeDto) {
    return this.structure.createPostType(req.auth!.user, body);
  }

  @Patch('post-types/:id')
  @RequireCapabilities('manage_options')
  updatePostType(
    @Req() req: AuthedRequest,
    @Param('id') id: string,
    @Body() body: UpdatePostTypeDto,
  ) {
    return this.structure.updatePostType(req.auth!.user, id, body);
  }

  @Delete('post-types/:id')
  @RequireCapabilities('manage_options')
  removePostType(@Req() req: AuthedRequest, @Param('id') id: string) {
    return this.structure.removePostType(req.auth!.user, id);
  }

  @Get('taxonomies')
  @RequireCapabilities('manage_options')
  listTaxonomies(@Req() req: AuthedRequest) {
    return this.structure.listTaxonomies(req.auth!.user);
  }

  @Post('taxonomies')
  @RequireCapabilities('manage_options')
  createTaxonomy(@Req() req: AuthedRequest, @Body() body: CreateTaxonomyDto) {
    return this.structure.createTaxonomy(req.auth!.user, body);
  }

  @Patch('taxonomies/:id')
  @RequireCapabilities('manage_options')
  updateTaxonomy(
    @Req() req: AuthedRequest,
    @Param('id') id: string,
    @Body() body: UpdateTaxonomyDto,
  ) {
    return this.structure.updateTaxonomy(req.auth!.user, id, body);
  }

  @Delete('taxonomies/:id')
  @RequireCapabilities('manage_options')
  removeTaxonomy(@Req() req: AuthedRequest, @Param('id') id: string) {
    return this.structure.removeTaxonomy(req.auth!.user, id);
  }

  @Get('options-pages')
  @RequireCapabilities('manage_options')
  listOptionsPages(@Req() req: AuthedRequest) {
    return this.structure.listOptionsPages(req.auth!.user);
  }

  @Post('options-pages')
  @RequireCapabilities('manage_options')
  createOptionsPage(@Req() req: AuthedRequest, @Body() body: CreateOptionsPageDto) {
    return this.structure.createOptionsPage(req.auth!.user, body);
  }

  @Patch('options-pages/:id')
  @RequireCapabilities('manage_options')
  updateOptionsPage(
    @Req() req: AuthedRequest,
    @Param('id') id: string,
    @Body() body: UpdateOptionsPageDto,
  ) {
    return this.structure.updateOptionsPage(req.auth!.user, id, body);
  }

  @Delete('options-pages/:id')
  @RequireCapabilities('manage_options')
  removeOptionsPage(@Req() req: AuthedRequest, @Param('id') id: string) {
    return this.structure.removeOptionsPage(req.auth!.user, id);
  }

  @Get('settings')
  @RequireCapabilities('manage_options')
  getSettings(@Req() req: AuthedRequest) {
    return this.structure.getSettings(req.auth!.user);
  }

  @Patch('settings')
  @RequireCapabilities('manage_options')
  updateSettings(@Req() req: AuthedRequest, @Body() body: FieldsSettingsDto) {
    return this.structure.updateSettings(req.auth!.user, body);
  }

  /* —— Field groups —— */

  @Get()
  @RequireCapabilities('manage_options')
  list(@Req() req: AuthedRequest) {
    return this.fields.list(req.auth!.user);
  }

  @Get(':id')
  @RequireCapabilities('manage_options')
  get(@Req() req: AuthedRequest, @Param('id') id: string) {
    return this.fields.get(req.auth!.user, id);
  }

  @Post()
  @RequireCapabilities('manage_options')
  create(@Req() req: AuthedRequest, @Body() body: CreateFieldGroupDto) {
    return this.fields.create(req.auth!.user, body);
  }

  @Patch(':id')
  @RequireCapabilities('manage_options')
  update(
    @Req() req: AuthedRequest,
    @Param('id') id: string,
    @Body() body: UpdateFieldGroupDto,
  ) {
    return this.fields.update(req.auth!.user, id, body);
  }

  @Delete(':id')
  @RequireCapabilities('manage_options')
  remove(@Req() req: AuthedRequest, @Param('id') id: string) {
    return this.fields.remove(req.auth!.user, id);
  }
}
