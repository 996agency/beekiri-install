import { useEffect, useState } from 'react';
import { api } from '../api/client';

/**
 * The site's design brief: what the owner answered before Beekiri designed the site. Beekiri
 * follows it in every later request; the chat's questionnaire starts from it.
 */

export const FONT_STYLES = ['modern', 'classic', 'bold', 'friendly'] as const;
export type FontStyle = (typeof FONT_STYLES)[number];

export type DesignBrief = {
  business?: string;
  colors?: string[];
  mode?: 'light' | 'dark';
  fontStyle?: FontStyle;
  fonts?: string;
  feel?: string[];
  references?: string[];
  notes?: string;
  updatedAt?: string;
};

export type DesignBriefState = {
  brief: DesignBrief | null;
  /** The Beekiri starter theme is active: the place to design a whole site from scratch. */
  starter: boolean;
  siteTitle: string;
};

let cached: DesignBriefState | null = null;
const listeners = new Set<(state: DesignBriefState) => void>();

/** Fresh from the server (the theme may have changed since); the last answer shows meanwhile. */
export function loadDesignBrief(): Promise<DesignBriefState | null> {
  return api<DesignBriefState>('/api/connector/beequeen/brief')
    .then((state) => {
      cached = state;
      listeners.forEach((l) => l(state));
      return state;
    })
    .catch(() => cached);
}

/** The brief just sent with a message, before the server is asked again. */
export function rememberDesignBrief(brief: DesignBrief) {
  if (!cached) return;
  cached = { ...cached, brief: { ...brief, updatedAt: new Date().toISOString() } };
  const state = cached;
  listeners.forEach((l) => l(state));
}

export function useDesignBrief(): DesignBriefState | null {
  const [state, setState] = useState(cached);
  useEffect(() => {
    listeners.add(setState);
    void loadDesignBrief();
    return () => {
      listeners.delete(setState);
    };
  }, []);
  return state;
}
