/// <reference types="vite/client" />

/** The Beekiri version this admin was built with (root package.json, set in vite.config.ts). */
declare const __BEEKIRI_VERSION__: string;
