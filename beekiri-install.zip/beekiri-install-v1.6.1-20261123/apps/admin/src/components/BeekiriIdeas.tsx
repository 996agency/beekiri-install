import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { useLocation } from 'react-router-dom';
import {
  Article,
  CalendarCheck,
  CaretLeft,
  CaretRight,
  DeviceMobile,
  FileCsv,
  FolderSimple,
  ImageSquare,
  Layout,
  LinkSimple,
  PaintBrushBroad,
  PencilSimpleLine,
  Quotes,
  Sparkle,
  Tag,
  TextAa,
  UsersThree,
  type Icon,
} from '@phosphor-icons/react';
import { useAuth } from '../auth/AuthContext';
import type { CapabilitySlug } from '../cms-types';
import { useDesignBrief } from '../lib/design-brief';
import { BOOKINGS_EXTENSION, FORMS_EXTENSION, SHOPPING_EXTENSION, useActiveExtensions } from '../lib/extensions-state';

/** Where in the admin the chat was opened: ideas for that place come first. */
type Place = 'editor' | 'posts' | 'media' | 'shop' | 'forms' | 'bookings';

type Idea = {
  icon: Icon;
  title: string;
  hint: string;
  /** What goes into the input; one that ends in ": " or "about " waits for the owner to finish it. */
  prompt: string;
  place?: Place;
  /** Only while this extension is on. */
  extension?: string;
  /** Only for people who may do this (Beekiri would refuse otherwise). */
  can?: CapabilitySlug;
  /** true: only on the Beekiri starter theme; false: only on other themes. */
  starter?: boolean;
  /** Opens the design questions instead of filling the input. */
  questions?: true;
};

/** Whole site, in the order shown when no place comes first. */
const IDEAS: Idea[] = [
  {
    icon: PaintBrushBroad,
    title: 'Full website design',
    hint: 'A few questions, then your homepage',
    prompt: '',
    can: 'edit_theme_options',
    starter: true,
    questions: true,
  },
  {
    icon: Sparkle,
    title: 'Premium homepage',
    hint: 'A stronger first impression',
    prompt: 'Make the top of my homepage feel more premium: a stronger headline, a better photo and more breathing room.',
    starter: false,
  },
  {
    icon: UsersThree,
    title: 'About us page',
    hint: 'Your story, team and values',
    prompt: 'Create an About us page with our story, the people behind the business and what makes us different.',
  },
  {
    icon: Quotes,
    title: 'Testimonials',
    hint: 'Reviews you can add yourself',
    prompt: 'Add a testimonials section to my homepage with a quote, name and photo for each customer, set up so I can add new reviews in the admin.',
  },
  {
    icon: Tag,
    title: 'Pricing plans',
    hint: 'Three plans, side by side',
    prompt: 'Make a pricing section with three plans side by side, and highlight the middle one as the most popular.',
  },
  {
    icon: LinkSimple,
    title: 'Style from a link',
    hint: 'Paste a website you like',
    prompt: 'Restyle my homepage after this website, keeping my own text and photos: ',
  },
  {
    icon: DeviceMobile,
    title: 'Ready for phones',
    hint: 'Fix anything cramped',
    prompt: 'Check how my website looks on phones and fix anything that feels cramped, too small or out of place.',
    place: 'editor',
  },
  {
    icon: Article,
    title: 'Blog post',
    hint: 'You pick the topic',
    prompt: 'Write a blog post with a featured photo about ',
    place: 'posts',
    can: 'edit_posts',
  },
  {
    icon: PencilSimpleLine,
    title: 'Product descriptions',
    hint: 'For products without one',
    prompt: 'Write descriptions for the products that don’t have one yet, in a tone that fits our brand.',
    place: 'shop',
    extension: SHOPPING_EXTENSION,
    can: 'edit_products',
  },
  {
    icon: FileCsv,
    title: 'Export form entries',
    hint: 'Last 30 days, every form',
    prompt: 'Export all form entries from the last 30 days as a spreadsheet.',
    place: 'forms',
    extension: FORMS_EXTENSION,
    can: 'view_form_entries',
  },
  {
    icon: CalendarCheck,
    title: 'This week’s bookings',
    hint: 'Who is coming, day by day',
    prompt: 'Show me this week’s appointments, day by day.',
    place: 'bookings',
    extension: BOOKINGS_EXTENSION,
    can: 'manage_bookings',
  },
  {
    icon: FolderSimple,
    title: 'Tidy the media',
    hint: 'Photos sorted into folders',
    prompt: 'Sort the photos in the media library into folders by what they show.',
    place: 'media',
    can: 'upload_files',
  },
];

/** Section mode: Beekiri works on one element of the page. */
const SECTION_IDEAS: Idea[] = [
  {
    icon: TextAa,
    title: 'Sharper words',
    hint: 'Clearer, more confident',
    prompt: 'Rewrite the text so it sounds clearer and more confident.',
  },
  {
    icon: ImageSquare,
    title: 'Better photo',
    hint: 'From your media library',
    prompt: 'Swap the image for a better one from the media library.',
  },
  {
    icon: Layout,
    title: 'New layout',
    hint: 'Same content, fresh look',
    prompt: 'Give this a completely different layout, keeping the same content.',
  },
  {
    icon: DeviceMobile,
    title: 'Ready for phones',
    hint: 'Tidy on small screens',
    prompt: 'Make this look great on phones and tablets.',
  },
];

function placeOf(path: string): Place | null {
  if (/\/shop(\/|$)/.test(path)) return 'shop';
  if (/\/pages\/(?!new$)[^/]+$/.test(path)) return 'editor';
  if (/\/media(\/|$)/.test(path)) return 'media';
  if (/\/forms(\/|$)/.test(path)) return 'forms';
  if (/\/bookings(\/|$)/.test(path)) return 'bookings';
  if (/\/posts(\/|$)/.test(path)) return 'posts';
  return null;
}

const calm = () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

type Props = {
  /** An element is selected in the page editor. */
  section: boolean;
  disabled: boolean;
  onPick: (prompt: string) => void;
  /** The design questions (Full website design). */
  onQuestions: () => void;
};

/**
 * Ideas under the empty chat bar: one row of cards that scrolls sideways (trackpad, wheel, arrows).
 * Ideas for the screen the owner is on come first; shop, forms and bookings ideas only show while
 * that extension is on and the owner may do it.
 */
export function BeekiriIdeas({ section, disabled, onPick, onQuestions }: Props) {
  const auth = useAuth();
  const active = useActiveExtensions();
  const design = useDesignBrief();
  const { pathname } = useLocation();
  const railRef = useRef<HTMLDivElement>(null);
  /** More cards hidden before / after: the fade and the arrow show on that side. */
  const [edges, setEdges] = useState({ start: false, end: false });

  const place = section ? null : placeOf(pathname);
  // Until the theme is known, the ideas for every theme show.
  const starter = design ? design.starter : null;
  const allowed = (idea: Idea) =>
    (!idea.extension || active.includes(idea.extension)) &&
    (!idea.can || Boolean(auth.user?.isOwner || auth.user?.capabilities.includes(idea.can))) &&
    (idea.starter === undefined || (starter === null ? !idea.starter : idea.starter === starter));
  const ideas = section
    ? SECTION_IDEAS
    : [...IDEAS.filter((i) => i.place === place), ...IDEAS.filter((i) => i.place !== place)].filter(allowed);

  const measure = useCallback(() => {
    const el = railRef.current;
    if (!el) return;
    const max = el.scrollWidth - el.clientWidth;
    const start = el.scrollLeft > 2;
    const end = el.scrollLeft < max - 2;
    setEdges((prev) => (prev.start === start && prev.end === end ? prev : { start, end }));
  }, []);

  useLayoutEffect(() => {
    const el = railRef.current;
    if (!el) return;
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => observer.disconnect();
  }, [measure, ideas.length]);

  // A new place starts at the first card; the first few rise in.
  useLayoutEffect(() => {
    const el = railRef.current;
    if (!el) return;
    el.scrollLeft = 0;
    measure();
    if (calm()) return;
    const tween = gsap.fromTo(
      Array.from(el.children).slice(0, 5),
      { autoAlpha: 0, y: 8 },
      { autoAlpha: 1, y: 0, duration: 0.4, ease: 'power3.out', stagger: 0.04, clearProps: 'transform,opacity,visibility' },
    );
    return () => {
      tween.kill();
    };
  }, [measure, place, section]);

  // A mouse wheel moves the row sideways; at either end the wheel is left alone.
  useEffect(() => {
    const el = railRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      if (Math.abs(e.deltaY) <= Math.abs(e.deltaX)) return;
      const max = el.scrollWidth - el.clientWidth;
      if (max <= 0 || (e.deltaY < 0 && el.scrollLeft <= 0) || (e.deltaY > 0 && el.scrollLeft >= max - 1)) return;
      e.preventDefault();
      el.scrollLeft += e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY;
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, []);

  const scrollBy = (direction: 1 | -1) => {
    const el = railRef.current;
    if (el) el.scrollBy({ left: direction * el.clientWidth * 0.75, behavior: calm() ? 'auto' : 'smooth' });
  };

  return (
    <div className={`bk-bee-chat__ideas${edges.start ? ' has-start' : ''}${edges.end ? ' has-end' : ''}`}>
      <div className="bk-bee-chat__ideas-rail" ref={railRef} onScroll={measure} role="group" aria-label="Ideas to start from">
        {ideas.map(({ icon: IdeaIcon, title: plainTitle, hint: plainHint, prompt, questions }) => {
          // With a brief saved, the same card opens it to change.
          const title = questions && design?.brief ? 'Your design brief' : plainTitle;
          const hint = questions && design?.brief ? 'Change colours, fonts or examples' : plainHint;
          return (
            <button key={plainTitle} type="button" className="bk-bee-chat__idea" onClick={() => (questions ? onQuestions() : onPick(prompt))} disabled={disabled}>
              <span className="bk-bee-chat__idea-icon" aria-hidden>
                <IdeaIcon size={16} />
              </span>
              <span className="bk-bee-chat__idea-copy">
                <strong>{title}</strong>
                <small>{hint}</small>
              </span>
            </button>
          );
        })}
      </div>
      {/* Mouse only: the keyboard tabs through the cards, and the row follows. */}
      <button type="button" className="bk-bee-chat__ideas-nav is-prev" tabIndex={-1} aria-label="Previous ideas" onClick={() => scrollBy(-1)}>
        <CaretLeft size={13} weight="bold" aria-hidden />
      </button>
      <button type="button" className="bk-bee-chat__ideas-nav is-next" tabIndex={-1} aria-label="More ideas" onClick={() => scrollBy(1)}>
        <CaretRight size={13} weight="bold" aria-hidden />
      </button>
    </div>
  );
}
