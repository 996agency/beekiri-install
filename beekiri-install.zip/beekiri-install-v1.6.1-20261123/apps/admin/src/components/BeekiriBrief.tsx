import { useEffect, useLayoutEffect, useRef, useState, type KeyboardEvent, type ReactNode } from 'react';
import { gsap } from 'gsap';
import { ArrowLeft, Check, ImageSquare, Plus, WarningCircle, X } from '@phosphor-icons/react';
import type { ChatPicture } from '../lib/chat-pictures';
import { FONT_STYLES, useDesignBrief, type DesignBrief, type FontStyle } from '../lib/design-brief';

/**
 * The design questionnaire: before Beekiri designs a whole site, the owner says what the business
 * is, the colours, lettering and feel they want, and sites or pictures they like. The answers are
 * saved as the site's design brief, which every later Beekiri request follows.
 */

type Answers = {
  business: string;
  /** false: Beekiri picks the palette. */
  ownColors: boolean;
  colors: string[];
  mode: 'light' | 'dark' | '';
  fontStyle: FontStyle | '';
  fonts: string;
  feel: string[];
  references: string[];
  notes: string;
};

const LETTERING: Record<FontStyle, { label: string; hint: string; sample: string }> = {
  modern: { label: 'Modern & clean', hint: 'Crisp, simple letters', sample: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif' },
  classic: { label: 'Elegant & classic', hint: 'Refined serif headings', sample: 'Georgia, "Times New Roman", serif' },
  bold: { label: 'Bold & strong', hint: 'Heavy, confident headings', sample: 'Impact, "Arial Black", system-ui, sans-serif' },
  friendly: { label: 'Friendly & soft', hint: 'Rounded and warm', sample: 'ui-rounded, "SF Pro Rounded", "Nunito", system-ui, sans-serif' },
};

const FEELINGS = ['Premium', 'Minimal', 'Warm', 'Playful', 'Bold', 'Calm', 'Natural', 'Trustworthy'];
const MAX_FEEL = 4;

const COLOR_LABELS = ['Main colour', 'Accent', 'Extra colour', 'Extra colour'];
const START_COLORS = ['#1f3a5f', '#e0a458'];

const STEPS = ['Your business', 'Colours', 'Lettering and feel', 'Examples you like'];

function fromBrief(brief: DesignBrief | null): Answers {
  return {
    business: brief?.business ?? '',
    ownColors: Boolean(brief?.colors?.length),
    colors: brief?.colors?.length ? brief.colors : START_COLORS,
    mode: brief?.mode ?? '',
    fontStyle: brief?.fontStyle ?? '',
    fonts: brief?.fonts ?? '',
    feel: brief?.feel ?? [],
    references: brief?.references?.length ? brief.references : [''],
    notes: brief?.notes ?? '',
  };
}

/** "stripe.com" → "https://stripe.com"; '' when it is not a web address. */
function webAddress(raw: string): string {
  const text = raw.trim();
  if (!text) return '';
  const url = /^https?:\/\//i.test(text) ? text : `https://${text}`;
  try {
    const { hostname } = new URL(url);
    return hostname.includes('.') ? url : '';
  } catch {
    return '';
  }
}

function toBrief(a: Answers): DesignBrief {
  return {
    business: a.business.trim(),
    ...(a.ownColors ? { colors: a.colors } : {}),
    ...(a.mode ? { mode: a.mode } : {}),
    ...(a.fontStyle ? { fontStyle: a.fontStyle } : {}),
    fonts: a.fonts.trim(),
    feel: a.feel,
    references: a.references.map(webAddress).filter(Boolean),
    notes: a.notes.trim(),
  };
}

/** What the owner sees in their message (and what the saved chat keeps): the request and the answers. */
function requestText(brief: DesignBrief, again: boolean, pictures: number): string {
  const lines = [
    again
      ? 'I updated my design brief. Bring my website in line with it: the look (colours, fonts, buttons, header and footer) and the homepage.'
      : 'Design my whole website from my design brief: first the look (colours, fonts, buttons, header and footer), then the homepage.',
    '',
    `• Business: ${brief.business}`,
    `• Colours: ${brief.colors?.length ? brief.colors.join(', ') : 'Beekiri chooses'}${brief.mode ? ` · ${brief.mode} pages` : ''}`,
    `• Lettering: ${brief.fontStyle ? LETTERING[brief.fontStyle].label : 'Beekiri chooses'}${brief.fonts ? ` · ${brief.fonts}` : ''}`,
    ...(brief.feel?.length ? [`• Feel: ${brief.feel.join(', ')}`] : []),
    ...(brief.references?.length ? [`• Sites I like: ${brief.references.join(', ')}`] : []),
    ...(pictures ? [`• ${pictures === 1 ? 'A picture' : `${pictures} pictures`} of designs I like (attached)`] : []),
    ...(brief.notes ? [`• Also: ${brief.notes}`] : []),
  ];
  return lines.join('\n');
}

/** Unsent answers survive closing the chat (until the page reloads). */
let unsent: { answers: Answers; step: number } | null = null;

type Props = {
  pictures: ChatPicture[];
  attaching: boolean;
  /** Why a picture could not be added. */
  error: string;
  onAddPictures: () => void;
  onRemovePicture: (id: string) => void;
  onCancel: () => void;
  onSubmit: (prompt: string, brief: DesignBrief) => void;
};

export function BeekiriBrief({ pictures, attaching, error, onAddPictures, onRemovePicture, onCancel, onSubmit }: Props) {
  // Loaded already by the ideas row that opened the questions: earlier answers fill the fields.
  const brief = useDesignBrief()?.brief ?? null;
  const [answers, setAnswers] = useState<Answers>(() => unsent?.answers ?? fromBrief(brief));
  const [step, setStep] = useState(() => unsent?.step ?? 0);
  const bodyRef = useRef<HTMLDivElement>(null);
  const again = Boolean(brief?.updatedAt);

  useEffect(() => {
    unsent = { answers, step };
  }, [answers, step]);

  // Each step slides in; the first field takes the focus.
  useLayoutEffect(() => {
    const body = bodyRef.current;
    if (!body) return;
    body.scrollTop = 0;
    body.querySelector<HTMLElement>('textarea, input, button[aria-pressed]')?.focus({ preventScroll: true });
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const tween = gsap.fromTo(body.children, { autoAlpha: 0, y: 10 }, { autoAlpha: 1, y: 0, duration: 0.35, ease: 'power3.out', stagger: 0.04, clearProps: 'transform,opacity,visibility' });
    return () => {
      tween.kill();
    };
  }, [step]);

  const set = <K extends keyof Answers>(key: K, value: Answers[K]) => setAnswers((a) => ({ ...a, [key]: value }));
  const last = step === STEPS.length - 1;
  const ready = answers.business.trim().length >= 3;

  const next = () => {
    if (!ready) {
      setStep(0);
      return;
    }
    if (!last) {
      setStep((s) => s + 1);
      return;
    }
    const final = toBrief(answers);
    unsent = null;
    onSubmit(requestText(final, again, pictures.length), final);
  };

  // Enter in a one-line field goes on to the next step.
  const onFieldKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.nativeEvent.isComposing) {
      e.preventDefault();
      next();
    }
  };

  let body: ReactNode;
  if (step === 0) {
    body = (
      <>
        {again ? null : (
          <p className="bk-bee-chat__brief-intro">
            <strong>Four short questions, then Beekiri designs your website.</strong> Your answers become your site’s design brief: the colours, lettering
            and feel every page follows, now and whenever you ask for more.
          </p>
        )}
        <Question title="What does your business do, and who is it for?" hint="A sentence or two is enough. Beekiri writes your homepage from it.">
          <textarea
            className="bk-bee-chat__brief-input"
            rows={4}
            maxLength={800}
            value={answers.business}
            onChange={(e) => set('business', e.target.value)}
            placeholder="e.g. A family dental clinic in Tirana. We treat adults and children, and most people book online."
          />
        </Question>
      </>
    );
  } else if (step === 1) {
    body = (
      <>
        <Question title="Which colours do you want?" hint="Your logo colours are a good start.">
          <div className="bk-bee-chat__brief-choices" role="group" aria-label="Colours">
            <Choice pressed={!answers.ownColors} onClick={() => set('ownColors', false)}>
              Let Beekiri choose
            </Choice>
            <Choice pressed={answers.ownColors} onClick={() => set('ownColors', true)}>
              I have colours
            </Choice>
          </div>
          {answers.ownColors ? (
            <div className="bk-bee-chat__brief-colors">
              {answers.colors.map((color, i) => (
                <label key={i} className="bk-bee-chat__brief-color">
                  <input
                    type="color"
                    value={color}
                    onChange={(e) => set('colors', answers.colors.map((c, k) => (k === i ? e.target.value.toLowerCase() : c)))}
                    aria-label={COLOR_LABELS[i]}
                  />
                  <span>
                    <strong>{COLOR_LABELS[i]}</strong>
                    <small>{color.toUpperCase()}</small>
                  </span>
                  {i > 0 ? (
                    <button
                      type="button"
                      className="bk-bee-chat__brief-remove"
                      onClick={(e) => {
                        e.preventDefault();
                        set('colors', answers.colors.filter((_, k) => k !== i));
                      }}
                      aria-label={`Remove ${COLOR_LABELS[i].toLowerCase()}`}
                      title="Remove"
                    >
                      <X size={11} weight="bold" aria-hidden />
                    </button>
                  ) : null}
                </label>
              ))}
              {answers.colors.length < 4 ? (
                <button type="button" className="bk-bee-chat__brief-add" onClick={() => set('colors', [...answers.colors, '#6b7280'])}>
                  <Plus size={13} weight="bold" aria-hidden /> Add a colour
                </button>
              ) : null}
            </div>
          ) : null}
        </Question>
        <Question title="Light or dark pages?">
          <div className="bk-bee-chat__brief-choices" role="group" aria-label="Pages">
            <Choice pressed={answers.mode === 'light'} onClick={() => set('mode', 'light')}>
              Light
            </Choice>
            <Choice pressed={answers.mode === 'dark'} onClick={() => set('mode', 'dark')}>
              Dark
            </Choice>
            <Choice pressed={answers.mode === ''} onClick={() => set('mode', '')}>
              Beekiri chooses
            </Choice>
          </div>
        </Question>
      </>
    );
  } else if (step === 2) {
    body = (
      <>
        <Question title="Which lettering fits you?">
          <div className="bk-bee-chat__brief-fonts" role="group" aria-label="Lettering">
            {FONT_STYLES.map((style) => (
              <button
                key={style}
                type="button"
                className="bk-bee-chat__brief-font"
                aria-pressed={answers.fontStyle === style}
                onClick={() => set('fontStyle', answers.fontStyle === style ? '' : style)}
              >
                <span className={`bk-bee-chat__brief-sample is-${style}`} style={{ fontFamily: LETTERING[style].sample }} aria-hidden>
                  Aa
                </span>
                <strong>{LETTERING[style].label}</strong>
                <small>{LETTERING[style].hint}</small>
              </button>
            ))}
          </div>
          <input
            className="bk-bee-chat__brief-input"
            type="text"
            maxLength={200}
            value={answers.fonts}
            onChange={(e) => set('fonts', e.target.value)}
            onKeyDown={onFieldKey}
            placeholder="A font you like (optional), e.g. Playfair Display"
            aria-label="A font you like"
          />
        </Question>
        <Question title="How should it feel?" hint={`Pick up to ${MAX_FEEL}.`}>
          <div className="bk-bee-chat__brief-choices" role="group" aria-label="Feel">
            {FEELINGS.map((word) => {
              const on = answers.feel.includes(word);
              return (
                <Choice
                  key={word}
                  pressed={on}
                  disabled={!on && answers.feel.length >= MAX_FEEL}
                  onClick={() => set('feel', on ? answers.feel.filter((w) => w !== word) : [...answers.feel, word])}
                >
                  {word}
                </Choice>
              );
            })}
          </div>
        </Question>
      </>
    );
  } else {
    body = (
      <>
        <Question title="Websites you like" hint="Beekiri studies how they look and move, then designs your own. Nothing is copied.">
          <div className="bk-bee-chat__brief-links">
            {answers.references.map((link, i) => (
              <div key={i} className="bk-bee-chat__brief-link">
                <input
                  className="bk-bee-chat__brief-input"
                  type="url"
                  inputMode="url"
                  maxLength={500}
                  value={link}
                  onChange={(e) => set('references', answers.references.map((l, k) => (k === i ? e.target.value : l)))}
                  onKeyDown={onFieldKey}
                  placeholder="e.g. stripe.com"
                  aria-label={`Website you like ${i + 1}`}
                />
                {answers.references.length > 1 ? (
                  <button
                    type="button"
                    className="bk-bee-chat__icon-btn"
                    onClick={() => set('references', answers.references.filter((_, k) => k !== i))}
                    aria-label="Remove this website"
                    title="Remove"
                  >
                    <X size={14} aria-hidden />
                  </button>
                ) : null}
              </div>
            ))}
            {answers.references.length < 3 ? (
              <button type="button" className="bk-bee-chat__brief-add" onClick={() => set('references', [...answers.references, ''])}>
                <Plus size={13} weight="bold" aria-hidden /> Add another
              </button>
            ) : null}
          </div>
        </Question>
        <Question title="Pictures of designs you like" hint="Screenshots, a mockup, a photo of a menu or flyer. You can also paste or drop them here.">
          <div className="bk-bee-chat__brief-pics">
            {pictures.map((p) => (
              <span key={p.id} className="bk-bee-chat__pic">
                <img src={p.thumb} alt="Design you like" />
                <button type="button" onClick={() => onRemovePicture(p.id)} aria-label="Remove the picture" title="Remove">
                  <X size={10} weight="bold" aria-hidden />
                </button>
              </span>
            ))}
            {attaching ? <span className="bk-bee-chat__spinner" aria-hidden /> : null}
            <button type="button" className="bk-bee-chat__ghost-btn" onClick={onAddPictures} disabled={attaching}>
              <ImageSquare size={15} aria-hidden /> Add pictures
            </button>
          </div>
          {error ? (
            <div className="bk-bee-chat__error" role="alert">
              <WarningCircle size={16} weight="fill" aria-hidden />
              <span>{error}</span>
            </div>
          ) : null}
        </Question>
        <Question title="Anything else?" hint="Must-haves, things to avoid, what your customers ask most.">
          <textarea
            className="bk-bee-chat__brief-input"
            rows={3}
            maxLength={1500}
            value={answers.notes}
            onChange={(e) => set('notes', e.target.value)}
            placeholder="e.g. A booking button on every page. No pink."
          />
        </Question>
        <p className="bk-bee-chat__brief-note">
          Beekiri designs the look, the header and footer, then your homepage. It takes a few minutes, and you can keep working meanwhile. Every page you ask for later
          follows these answers.
        </p>
      </>
    );
  }

  return (
    <>
      <div className="bk-bee-chat__bar">
        <div className="bk-bee-chat__titles">
          <strong>{again ? 'Your design brief' : 'Design your website'}</strong>
          <span className="bk-bee-chat__engine">
            Step {step + 1} of {STEPS.length} · {STEPS[step]}
          </span>
        </div>
        <div className="bk-bee-chat__bar-actions">
          <button type="button" className="bk-bee-chat__icon-btn" onClick={onCancel} aria-label="Close the questions" title="Close (your answers are kept)">
            <X size={17} aria-hidden />
          </button>
        </div>
      </div>
      <div className="bk-bee-chat__brief" ref={bodyRef}>
        {body}
      </div>
      <div className="bk-bee-chat__brief-foot">
        {step > 0 ? (
          <button type="button" className="bk-bee-chat__ghost-btn" onClick={() => setStep((s) => s - 1)}>
            <ArrowLeft size={14} aria-hidden /> Back
          </button>
        ) : (
          <span />
        )}
        <span className="bk-bee-chat__brief-steps" aria-hidden>
          {STEPS.map((label, i) => (
            <span key={label} className={i <= step ? 'is-done' : ''} />
          ))}
        </span>
        <button type="button" className="bk-bee-chat__brief-next" onClick={next} disabled={!ready || attaching}>
          {last ? (
            <>
              <Check size={14} weight="bold" aria-hidden /> {again ? 'Save and restyle' : 'Start designing'}
            </>
          ) : (
            'Next'
          )}
        </button>
      </div>
    </>
  );
}

function Question({ title, hint, children }: { title: string; hint?: string; children: ReactNode }) {
  return (
    <fieldset className="bk-bee-chat__brief-q">
      <legend>{title}</legend>
      {hint ? <p>{hint}</p> : null}
      {children}
    </fieldset>
  );
}

function Choice({ pressed, disabled, onClick, children }: { pressed: boolean; disabled?: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button type="button" className="bk-bee-chat__brief-choice" aria-pressed={pressed} disabled={disabled} onClick={onClick}>
      {pressed ? <Check size={12} weight="bold" aria-hidden /> : null}
      {children}
    </button>
  );
}
