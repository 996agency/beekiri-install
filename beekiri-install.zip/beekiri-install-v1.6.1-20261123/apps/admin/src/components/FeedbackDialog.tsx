import { useState, type ReactNode } from 'react';
import { useLocation } from 'react-router-dom';
import { CheckCircle, Star } from '@phosphor-icons/react';
import { api, ApiError } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { AdminModal } from './AdminModal';
import './feedback-dialog.css';

/**
 * "Feedback" in the sidebar: the owner tells the Beekiri team what to improve. It goes to
 * feedback@beekiri.com through 996Agency (or the site's own email server).
 */

const FEEDBACK_EMAIL = 'feedback@beekiri.com';

type Topic = 'idea' | 'problem' | 'praise' | 'other';

const TOPICS: { id: Topic; label: string; placeholder: string }[] = [
  { id: 'idea', label: 'Idea', placeholder: 'What would make Beekiri better for you?' },
  { id: 'problem', label: 'Problem', placeholder: 'What happened, and what did you expect instead?' },
  { id: 'praise', label: 'Praise', placeholder: 'What do you like about Beekiri?' },
  { id: 'other', label: 'Other', placeholder: 'Tell us anything.' },
];

const RATINGS = ['Not good', 'Could be better', 'Okay', 'Good', 'Love it'];

function Row({ label, htmlFor, children, help }: { label: ReactNode; htmlFor?: string; children: ReactNode; help?: ReactNode }) {
  return (
    <tr>
      <th scope="row">{htmlFor ? <label htmlFor={htmlFor}>{label}</label> : label}</th>
      <td>
        {children}
        {help ? <p className="description">{help}</p> : null}
      </td>
    </tr>
  );
}

export function FeedbackDialog({ onClose }: { onClose: () => void }) {
  const auth = useAuth();
  const { pathname } = useLocation();
  const email = auth.user?.email ?? '';
  const [topic, setTopic] = useState<Topic>('idea');
  const [rating, setRating] = useState<number | null>(null);
  const [hover, setHover] = useState<number | null>(null);
  const [message, setMessage] = useState('');
  const [contact, setContact] = useState(true);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const ready = message.trim().length >= 3 && !sending;

  const send = async () => {
    if (!ready) return;
    setSending(true);
    setError('');
    try {
      await api('/api/site/feedback', {
        json: { topic, ...(rating ? { rating } : {}), message: message.trim(), contact: contact && Boolean(email), page: pathname.slice(0, 300) },
      });
      setSent(true);
    } catch (e) {
      setError(e instanceof ApiError && e.message ? e.message : `Your feedback could not be sent right now. Try again later, or email it to ${FEEDBACK_EMAIL}.`);
    } finally {
      setSending(false);
    }
  };

  if (sent) {
    return (
      <AdminModal
        title="Thank you"
        onClose={onClose}
        footer={
          <span className="bk-modal__actions">
            <button type="button" className="button button-primary" onClick={onClose} autoFocus>
              Close
            </button>
          </span>
        }
      >
        <div className="bk-feedback__sent">
          <CheckCircle size={40} weight="fill" aria-hidden />
          <p>
            <strong>Your feedback is on its way to the Beekiri team.</strong>
          </p>
          <p className="description">
            We read every message.{contact && email ? ` If we have a question, we’ll write to ${email}.` : ''}
          </p>
        </div>
      </AdminModal>
    );
  }

  const shown = hover ?? rating ?? 0;
  const current = TOPICS.find((t) => t.id === topic)!;

  return (
    <AdminModal
      title="Send feedback"
      onClose={onClose}
      footer={
        <>
          <span className="description">Goes to {FEEDBACK_EMAIL}</span>
          <span className="bk-modal__actions">
            <button type="button" className="button" onClick={onClose}>
              Cancel
            </button>
            <button type="button" className="button button-primary" onClick={() => void send()} disabled={!ready}>
              {sending ? 'Sending…' : 'Send feedback'}
            </button>
          </span>
        </>
      }
    >
      <p className="bk-feedback__intro">Tell us what to improve in Beekiri. Every message is read by the team that builds it.</p>
      {error ? (
        <div className="beekiri-notice is-error" role="alert">
          <p>{error}</p>
        </div>
      ) : null}
      <table className="form-table">
        <tbody>
          <Row label="About">
            <div className="bk-tabs is-inline" role="tablist" aria-label="What is it about?">
              {TOPICS.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  role="tab"
                  aria-selected={topic === t.id}
                  className={`bk-tabs__item${topic === t.id ? ' is-active' : ''}`}
                  onClick={() => setTopic(t.id)}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </Row>
          <Row label="Beekiri so far" help={rating ? RATINGS[rating - 1] : 'Optional'}>
            <div className="bk-feedback__stars" role="radiogroup" aria-label="How is Beekiri so far?" onMouseLeave={() => setHover(null)}>
              {RATINGS.map((label, i) => {
                const value = i + 1;
                return (
                  <button
                    key={value}
                    type="button"
                    role="radio"
                    aria-checked={rating === value}
                    aria-label={`${value} of 5: ${label}`}
                    title={label}
                    className={`bk-feedback__star${value <= shown ? ' is-on' : ''}`}
                    onMouseEnter={() => setHover(value)}
                    onClick={() => setRating(rating === value ? null : value)}
                  >
                    <Star size={22} weight={value <= shown ? 'fill' : 'regular'} aria-hidden />
                  </button>
                );
              })}
            </div>
          </Row>
          <Row label="Your feedback" htmlFor="bk-feedback-message">
            <textarea
              id="bk-feedback-message"
              rows={6}
              maxLength={4000}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder={current.placeholder}
              autoFocus
            />
          </Row>
          {email ? (
            <Row label="Reply">
              <label className="bk-check">
                <input type="checkbox" checked={contact} onChange={(e) => setContact(e.target.checked)} />
                <span className="bk-check__box" aria-hidden />
                <span className="bk-check__label">The Beekiri team may email me back at {email}</span>
              </label>
            </Row>
          ) : null}
        </tbody>
      </table>
    </AdminModal>
  );
}
