import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { keepOutOfCanvas } from './keep-out-of-canvas';

const adminDir = path.dirname(fileURLToPath(import.meta.url));
const srcDir = path.join(adminDir, 'src');
// The Beekiri version this admin is built with (every core update rebuilds it).
const { version } = JSON.parse(readFileSync(path.join(adminDir, '../../package.json'), 'utf8')) as { version: string };

// The admin is served by the Beekiri server at /admin (built files in production, this
// config as middleware in development), on the same address as the API and website.
export default defineConfig({
  base: '/admin/',
  plugins: [react()],
  define: { __BEEKIRI_VERSION__: JSON.stringify(version) },
  css: {
    // Admin styles stop at the page editor's canvas, so theme sections look as they do on the site.
    postcss: { plugins: [keepOutOfCanvas(srcDir)] },
  },
  server: {
    fs: {
      // Shared editor packages (page-blocks / beekiricanva) live in apps/web/modules.
      allow: ['../..', '../web/modules'],
    },
  },
});
