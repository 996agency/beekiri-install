<?php
/*
 * Beekiri — the frame around every blog post: title, date, reading time, the featured photo,
 * the post itself in a readable column, then older/newer and more posts. Colours and fonts come
 * from the site's design tokens (--bk-*), so it follows each site's look. A theme (or Beekiri)
 * makes its own design by adding blog/single.php to the client theme.
 */
$p = get_bee_field('post');
$older = get_bee_field('older');
$newer = get_bee_field('newer');
$related = get_bee_field('related');
$blog_url = get_bee_field('blog_url');
$topics = is_array($p) && !empty($p['categories']) ? $p['categories'] : array();
$image = is_array($p) && !empty($p['image']) ? $p['image'] : null;
$cards = is_array($related) ? array_slice($related, 0, 3) : array();
?>
<article class="bk-post">
  <header class="bk-post__head">
    <a class="bk-post__back" href="<?php echo esc_url($blog_url ? $blog_url : '/blog'); ?>"><span aria-hidden="true">←</span> All posts</a>
    <?php if (count($topics)) : ?>
      <p class="bk-post__topics">
        <?php foreach ($topics as $topic) : ?><span><?php echo esc_html($topic); ?></span><?php endforeach; ?>
      </p>
    <?php endif; ?>
    <h1 class="bk-post__title"><?php echo esc_html($p['title']); ?></h1>
    <p class="bk-post__meta">
      <?php if (!empty($p['date'])) : ?><time datetime="<?php echo esc_attr($p['date_iso']); ?>"><?php echo esc_html($p['date']); ?></time><?php endif; ?>
      <span><?php echo esc_html($p['reading_minutes']); ?> min read</span>
      <?php if (!empty($p['author'])) : ?><span><?php echo esc_html($p['author']); ?></span><?php endif; ?>
    </p>
  </header>

  <?php if ($image) : ?>
    <figure class="bk-post__cover">
      <img
        src="<?php echo esc_url($image['src']); ?>"
        <?php if (!empty($image['srcset'])) : ?>srcset="<?php echo esc_attr($image['srcset']); ?>" sizes="(min-width: 1180px) 1100px, 100vw"<?php endif; ?>
        alt="<?php echo esc_attr($image['alt']); ?>"
        <?php if (!empty($image['width'])) : ?>width="<?php echo esc_attr($image['width']); ?>" height="<?php echo esc_attr($image['height']); ?>"<?php endif; ?>
        loading="eager" fetchpriority="high" decoding="async"
      />
    </figure>
  <?php endif; ?>

  <div class="bk-post__body"><?php echo get_bee_field('body_marker'); ?></div>

  <?php if ($older || $newer) : ?>
    <nav class="bk-post__pager" aria-label="More posts">
      <?php if ($newer) : ?>
        <a class="bk-post__step" href="<?php echo esc_url($newer['path']); ?>"><small>Newer</small><strong><?php echo esc_html($newer['title']); ?></strong></a>
      <?php endif; ?>
      <?php if ($older) : ?>
        <a class="bk-post__step is-older" href="<?php echo esc_url($older['path']); ?>"><small>Older</small><strong><?php echo esc_html($older['title']); ?></strong></a>
      <?php endif; ?>
    </nav>
  <?php endif; ?>

  <?php if (count($cards)) : ?>
    <section class="bk-post__more" aria-labelledby="bk-post-more">
      <h2 id="bk-post-more">Keep reading</h2>
      <div class="bk-post__cards">
        <?php foreach ($cards as $card) : ?>
          <a class="bk-post__card" href="<?php echo esc_url($card['path']); ?>">
            <?php if (!empty($card['image'])) : ?>
              <img src="<?php echo esc_url($card['image']['src']); ?>" alt="" loading="lazy" decoding="async" width="640" height="400" />
            <?php else : ?>
              <span class="bk-post__card-blank" aria-hidden="true"></span>
            <?php endif; ?>
            <strong><?php echo esc_html($card['title']); ?></strong>
            <small><?php echo esc_html($card['date']); ?> · <?php echo esc_html($card['reading_minutes']); ?> min read</small>
          </a>
        <?php endforeach; ?>
      </div>
    </section>
  <?php endif; ?>
</article>
<style>
.bk-post {
  --bk-post-col: 720px;
  --bk-post-wide: 1100px;
  --bk-post-gutter: clamp(20px, 5vw, 40px);
  padding: clamp(40px, 7vw, 96px) 0 clamp(48px, 7vw, 96px);
  color: var(--bk-fg, #202734);
  font-family: var(--bk-font, system-ui, sans-serif);
}
.bk-post__head,
.bk-post__pager {
  box-sizing: content-box;
  max-width: var(--bk-post-col);
  margin: 0 auto;
  padding: 0 var(--bk-post-gutter);
}
.bk-post__back {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-height: 24px;
  color: var(--bk-muted, #50575e);
  font-size: 0.9375rem;
  text-decoration: none;
}
.bk-post__back:hover { color: var(--bk-fg, #202734); }
.bk-post__topics { display: flex; flex-wrap: wrap; gap: 8px; margin: 28px 0 0; }
.bk-post__topics span {
  padding: 4px 12px;
  border: 1px solid var(--bk-border, #c3c4c7);
  border-radius: 999px;
  color: var(--bk-muted, #50575e);
  font-size: 0.8125rem;
}
.bk-post__title {
  margin: 20px 0 0;
  font-family: var(--bk-font-heading, var(--bk-font, inherit));
  font-size: clamp(2.25rem, 1.6rem + 3vw, 3.75rem);
  line-height: 1.08;
  letter-spacing: -0.02em;
  text-wrap: balance;
  color: var(--bk-fg, #202734);
}
.bk-post__meta { display: flex; flex-wrap: wrap; gap: 6px 18px; margin: 20px 0 0; color: var(--bk-muted, #50575e); font-size: 0.9375rem; }
.bk-post__cover { box-sizing: content-box; max-width: var(--bk-post-wide); margin: clamp(32px, 5vw, 56px) auto 0; padding: 0 var(--bk-post-gutter); }
.bk-post__cover img {
  display: block;
  width: 100%;
  height: auto;
  aspect-ratio: 16 / 9;
  object-fit: cover;
  border-radius: var(--bk-radius, 12px);
  background: var(--bk-surface, #f6f7f7);
}
/* The post itself: text in a readable column; full-width sections (theme layouts) keep their width. */
.bk-post__body { margin-top: clamp(32px, 5vw, 56px); font-size: 1.125rem; line-height: 1.75; }
.bk-post__body > :not([data-layout]):not([style*="display:contents"]),
.bk-post__body > [style*="display:contents"] > :not([data-layout]) {
  box-sizing: border-box;
  max-width: calc(var(--bk-post-col) + 2 * var(--bk-post-gutter));
  margin-left: auto;
  margin-right: auto;
  padding-left: var(--bk-post-gutter);
  padding-right: var(--bk-post-gutter);
}
.bk-post__body :is(p, li) { color: var(--bk-fg, #202734); }
.bk-post__body :is(.bk-text, p) { margin-top: 0; margin-bottom: 1.25em; font-size: inherit; line-height: inherit; }
.bk-post__body :is(.bk-heading, h2, h3, h4) {
  margin-top: 2em;
  margin-bottom: 0.6em;
  font-family: var(--bk-font-heading, var(--bk-font, inherit));
  line-height: 1.2;
  letter-spacing: -0.015em;
  color: var(--bk-fg, #202734);
}
.bk-post__body h2 { font-size: clamp(1.5rem, 1.2rem + 1.2vw, 2rem); }
.bk-post__body h3 { font-size: 1.3rem; }
.bk-post__body :is(ul, ol) { margin: 0 0 1.25em; padding-left: 1.4em; }
.bk-post__body li + li { margin-top: 0.4em; }
.bk-post__body a:not([class]) { color: var(--bk-link, inherit); text-underline-offset: 0.2em; }
.bk-post__body img:not([data-layout] img) { max-width: 100%; height: auto; border-radius: var(--bk-radius, 12px); }
.bk-post__body .bk-accordion { margin: 0.5em auto 1.5em; }
.bk-post__body .bk-accordion__item { border-color: var(--bk-border, rgba(0, 0, 0, 0.12)); }
.bk-post__body .bk-accordion__body { color: var(--bk-muted, #50575e); }
.bk-post__body > [style*="display:contents"] > [data-layout],
.bk-post__body > [data-layout] { margin-top: clamp(40px, 6vw, 72px); }
.bk-post__pager {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
  margin-top: clamp(48px, 6vw, 72px);
  padding-top: 28px;
  border-top: 1px solid var(--bk-border, #c3c4c7);
}
.bk-post__step { display: flex; flex-direction: column; gap: 4px; min-height: 24px; color: var(--bk-fg, #202734); text-decoration: none; }
.bk-post__step.is-older { grid-column: 2; text-align: right; }
.bk-post__step small { color: var(--bk-muted, #50575e); font-size: 0.8125rem; }
.bk-post__step strong { font-weight: 500; line-height: 1.35; }
.bk-post__step:hover strong { color: var(--bk-link, inherit); }
.bk-post__more { box-sizing: content-box; max-width: var(--bk-post-wide); margin: clamp(56px, 8vw, 96px) auto 0; padding: 0 var(--bk-post-gutter); }
.bk-post__more h2 { margin: 0 0 24px; font-family: var(--bk-font-heading, var(--bk-font, inherit)); font-size: clamp(1.4rem, 1.2rem + 0.8vw, 1.75rem); color: var(--bk-fg, #202734); }
.bk-post__cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 24px; }
.bk-post__card { display: flex; flex-direction: column; gap: 8px; color: var(--bk-fg, #202734); text-decoration: none; }
.bk-post__card img,
.bk-post__card-blank {
  display: block;
  width: 100%;
  height: auto;
  aspect-ratio: 16 / 10;
  object-fit: cover;
  border-radius: var(--bk-radius, 12px);
  background: var(--bk-surface, #f6f7f7);
}
.bk-post__card strong { margin-top: 6px; font-weight: 500; line-height: 1.35; }
.bk-post__card small { color: var(--bk-muted, #50575e); font-size: 0.8125rem; }
.bk-post__card:hover strong { color: var(--bk-link, inherit); }
.bk-post a:focus-visible { outline: 2px solid var(--bk-focus, currentColor); outline-offset: 3px; border-radius: 4px; }
@media (max-width: 640px) {
  .bk-post__body { font-size: 1.0625rem; }
  .bk-post__pager { grid-template-columns: 1fr; }
  .bk-post__step.is-older { grid-column: 1; text-align: left; }
}
</style>
