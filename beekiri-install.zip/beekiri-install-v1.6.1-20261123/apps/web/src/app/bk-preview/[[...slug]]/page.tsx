import type { Metadata } from 'next';
import { LayoutStylesheets } from '../../../components/LayoutStylesheets';
import { notFound } from 'next/navigation';
import { BeekiriCodeMain } from '../../../components/BeekiriCodeMain';
import { layoutAssetsFor, PageBody, resolveBeekiriCodePage } from '../../../components/PageBody';
import { blogView } from '../../../lib/blog';
import { ShopMain } from '../../../components/ShopMain';
import { fetchShopView, type ShopViewData } from '../../../lib/shop';

import { API_URL as API } from '@/lib/env';
import { apiFetch } from '@/lib/api';

type PublicPage = {
  title: string;
  slug: string;
  content: string;
  beekiricanva?: unknown | null;
  beekiricode?: unknown | null;
  instatic?: unknown | null;
  excerpt: string;
  preview?: boolean;
};

type Props = {
  params: Promise<{ slug?: string[] }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

function firstParam(value: string | string[] | undefined): string | undefined {
  if (Array.isArray(value)) return value[0];
  return value;
}

/** Floating note that this is a private preview; it sits over the page, so the layout is the real one. */
function PreviewBadge() {
  return (
    <p className="bk-preview-banner" role="status">
      <span className="bk-preview-banner__dot" aria-hidden />
      <strong>Preview</strong>
      <span>Not live yet — only people with this link can see it</span>
    </p>
  );
}

/** Shop import preview (rewritten by middleware while its cookie is set): which shop view to show. */
function shopView(
  parts: string[],
  sp: Record<string, string | string[] | undefined>,
): { view: ShopViewData['view']; params: Record<string, string | string[] | undefined> } | null {
  const listing = { q: sp.q, sort: sp.sort, page: sp.page };
  if (parts[0] === 'shop' && parts.length === 1) return { view: 'shop', params: listing };
  if (parts[0] === 'shop' && parts[1] === 'category' && parts[2]) return { view: 'category', params: { slug: parts[2], ...listing } };
  if (parts[0] === 'product' && parts[1]) return { view: 'product', params: { slug: parts[1] } };
  return null;
}

async function loadShopPreview(parts: string[], sp: Record<string, string | string[] | undefined>, code: string) {
  const target = shopView(parts, sp);
  return target ? fetchShopView(target.view, target.params, { importPreview: code }) : null;
}

/** The note over a shop import preview, with the way out. */
function ShopPreviewBadge() {
  return (
    <p className="bk-preview-banner" role="status">
      <span className="bk-preview-banner__dot" aria-hidden />
      <strong>Preview</strong>
      <span>Imported products, not live yet</span>
      <a className="bk-preview-banner__exit" href="/shop?shop-preview=exit">
        Leave preview
      </a>
    </p>
  );
}

async function loadPage(slugParts: string[] | null, token: string): Promise<PublicPage | null> {
  try {
    const qs = `?preview=1&token=${encodeURIComponent(token)}`;
    let path: string;
    if (!slugParts?.length) {
      path = `/api/pages/public/front${qs}`;
    } else if (slugParts[0] === 'blog' && slugParts[1]) {
      path = `/api/posts/public/${encodeURIComponent(slugParts.slice(1).join('/'))}${qs}`;
    } else {
      path = `/api/pages/public/${encodeURIComponent(slugParts.join('/'))}${qs}`;
    }
    const res = await apiFetch(`${API}${path}`, { cache: 'no-store' });
    if (res.status === 404 || !res.ok) return null;
    return (await res.json()) as PublicPage;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params, searchParams }: Props): Promise<Metadata> {
  const { slug: parts } = await params;
  const sp = await searchParams;
  const shopCode = firstParam(sp.shopPreview);
  if (shopCode) {
    const data = await loadShopPreview(parts ?? [], sp, shopCode);
    return { title: data ? `${data.title} (Preview)` : 'Preview', robots: { index: false, follow: false } };
  }
  const token = firstParam(sp.token);
  if (!token) return { title: 'Preview', robots: { index: false, follow: false } };
  const page = await loadPage(parts?.length ? parts : null, token);
  if (!page) return { title: 'Preview', robots: { index: false, follow: false } };
  return {
    title: `${page.title} (Preview)`,
    description: (page.excerpt || '').trim() || undefined,
    robots: { index: false, follow: false },
  };
}

/** Dynamic preview surface — rewritten from `?preview=1&token=` public URLs. */
export default async function PreviewPage({ params, searchParams }: Props) {
  const { slug: parts } = await params;
  const sp = await searchParams;
  const shopCode = firstParam(sp.shopPreview);
  if (shopCode) {
    const data = await loadShopPreview(parts ?? [], sp, shopCode);
    if (!data) notFound();
    return (
      <>
        <ShopMain data={data} />
        <ShopPreviewBadge />
      </>
    );
  }
  const token = firstParam(sp.token);
  if (!token) notFound();
  const page = await loadPage(parts?.length ? parts : null, token);
  if (!page) notFound();

  const codeDoc = page.beekiricode ?? page.instatic;
  const codePage = codeDoc ? await resolveBeekiriCodePage(codeDoc) : null;
  // A post shows in the theme's post frame (title, date, photo, reading column), as it will live.
  const postSlug = parts?.[0] === 'blog' && parts[1] ? parts.slice(1).join('/') : null;
  const themed = postSlug ? await blogView('single', { slug: postSlug, token }, { fresh: true }) : null;
  const at = themed?.html && themed.marker ? themed.html.indexOf(themed.marker) : -1;
  const framed =
    themed?.html && themed.marker && at !== -1
      ? themed.html.slice(0, at) + (codePage?.html ?? page.content ?? '') + themed.html.slice(at + themed.marker.length)
      : null;
  const frame = framed ? await layoutAssetsFor(themed?.html ?? '') : { cssHrefs: [], jsHrefs: [] };
  const cssHrefs = [...new Set([...(codePage?.cssHrefs ?? []), ...frame.cssHrefs])];
  const jsHrefs = [...new Set([...(codePage?.jsHrefs ?? []), ...frame.jsHrefs])];

  return (
    <>
      <LayoutStylesheets hrefs={cssHrefs} />
      {codePage?.css ? (
        <style href={`bk-preview-${page.slug}`} precedence="beekiri-page">
          {codePage.css}
        </style>
      ) : null}
      {jsHrefs.map((href) => (
        <script key={href} src={href} defer />
      ))}
      {framed ? (
        <BeekiriCodeMain html={framed} className="bk-main bk-blog-view" before={<PreviewBadge />} />
      ) : codePage ? (
        <BeekiriCodeMain
          html={codePage.html}
          before={
            <PreviewBadge />
          }
        />
      ) : (
        <main id="main" className="bk-main">
          <PreviewBadge />
          <h1>{page.title}</h1>
          <PageBody content={page.content} beekiricanva={page.beekiricanva} beekiricode={null} />
        </main>
      )}
    </>
  );
}
