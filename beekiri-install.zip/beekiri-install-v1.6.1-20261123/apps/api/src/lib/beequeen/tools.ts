import * as z from 'zod/v4';

import type { CapabilitySlug } from '../cms-types';
import type { PreviewImage } from './preview';
import { normalizeSection, requestedLayouts, sectionInputSchema, type SectionScope, type SectionTree } from './section';
import {
  getPage,
  layoutExists,
  layoutSlugForTitle,
  listContentTypes,
  listEntries,
  listSiteSections,
  saveContentType,
  type SaveContentTypeInput,
  saveEntry,
  type SaveEntryInput,
  saveSiteSection,
  type SaveSiteSectionInput,
  listPosts,
  listMedia,
  listTaxonomies,
  saveTaxonomy,
  listThemeFiles,
  readLayout,
  readThemeFile,
  saveLayout,
  savePage,
  type SavePageInput,
  savePost,
  type SavePostInput,
  siteOverview,
  writeThemeFile,
  type SaveTaxonomyInput,
  type Workspace,
} from './workspace';
import { getProduct, importImage, listProducts, saveProduct, type ImportImageInput, type SaveProductInput } from './shop';
import { getBookingsSetup, saveBookingsSetup, type BookingsSetupInput } from './bookings';
import { referenceHost, studyReferenceSite } from './reference-site';
import { saveDesignBrief } from './design-brief';
import { addFont, type AddFontInput } from './fonts';
import { lookAtPage, type LookAtPageInput } from './page-look';
import { DESIGN_FONT_STYLES } from '../site/site-options';
import {
  createMediaFolder,
  exportAppointments,
  exportFormEntries,
  exportOrders,
  findAppointments,
  findFormEntries,
  findOrders,
  listForms,
  listMediaFolders,
  lookAtMedia,
  moveMedia,
  setFormEntriesStatus,
  setMediaAlt,
  type AppointmentFilter,
  type EntryFilter,
  type OrderFilter,
} from './admin';

/**
 * Beekiri's tools: what each one does on this site. How Claude should use them (the guidance it
 * reads, Beekiri's instructions and skills) lives at 996Agency and is added there to every call —
 * only a short line stays here. A new tool needs its guidance in 996Agency's brain (tools.json).
 */
/** What a tool hands back: text, or text plus a picture (section previews). */
export type ToolContent = { type: 'text'; text: string } | { type: 'image'; data: string; mediaType: PreviewImage['mediaType'] };
export type ToolResult = string | ToolContent[];

export type BeeQueenTool = {
  name: string;
  description: string;
  schema: z.ZodObject;
  run: (input: never) => Promise<ToolResult>;
};

/** Runs one tool step: reports it to the chat and turns failures into text the model can act on. */
export type StepRunner = (label: string, work: () => Promise<string>) => Promise<string>;

function tool<S extends z.ZodObject>(def: {
  name: string;
  description: string;
  schema: S;
  run: (input: z.infer<S>) => Promise<ToolResult>;
}): BeeQueenTool {
  return def as unknown as BeeQueenTool;
}

/** Tools in section mode: look things up, and replace the selected element. */
export function sectionTools(
  ws: Workspace,
  step: StepRunner,
  scope: SectionScope,
  state: { tree: SectionTree },
  onSection: (tree: SectionTree) => void,
  preview: () => Promise<PreviewImage>,
): BeeQueenTool[] {
  const all = beeQueenTools(ws, step);
  const lookups = all.filter((t) =>
    ['get_site_overview', 'list_theme_files', 'read_theme_file', 'read_layout', 'list_media', 'look_at_reference_site'].includes(t.name),
  );
  const saveLayoutTool = all.find((t) => t.name === 'save_layout')!;
  /** Layouts made in this run: create_layout may update these, never one that existed before. */
  const created = new Set<string>();
  return [
    ...lookups,
    tool({
      name: 'create_layout',
      description: 'Create a NEW theme layout for this element (a different design): writes its Backend Fields fields and theme…',
      schema: saveLayoutTool.schema,
      run: async (input) => {
        const title = String(input.title ?? '');
        const slug = layoutSlugForTitle(title);
        if (slug && !created.has(slug) && (await layoutExists(slug))) {
          return `ERROR: A layout "${slug}" already exists and other pages may use it, so it stays as it is. Pick a new title for your design (e.g. "${title.trim()} Split") and call create_layout again.`;
        }
        const result = await saveLayoutTool.run(input as never);
        if (slug && typeof result === 'string' && !result.startsWith('ERROR')) created.add(slug);
        return typeof result === 'string' && slug && created.has(slug)
          ? `${result}\nLayout slug: ${slug}. Now update_section with this element as type "layout", layoutSlug "${slug}" and its layoutFields.`
          : result;
      },
    }),
    tool({
      name: 'update_section',
      description: `Replace the selected element (id ${scope.nodeId}) with a new version.`,
      schema: sectionInputSchema,
      run: (input) =>
        step('Updating the section', async () => {
          const wanted = requestedLayouts(state.tree, input);
          const usable = new Set<string>();
          for (const slug of wanted) if (created.has(slug) || (await layoutExists(slug))) usable.add(slug);
          const tree = normalizeSection(state.tree, input, usable);
          state.tree = tree;
          onSection(tree);
          return `Applied in the editor (${Object.keys(tree.nodes).length} elements). Now call preview_section to check how it looks.`;
        }),
    }),
    tool({
      name: 'preview_section',
      description: 'A picture of the selected element (or the whole page) exactly as the editor renders it now, at desktop width…',
      schema: z.object({}),
      run: async () => {
        let shot: PreviewImage | null = null;
        const text = await step('Looking at the result', async () => {
          shot = await preview();
          return 'ok';
        });
        const image = shot as PreviewImage | null;
        if (!image) return text;
        const parts = [image, ...(image.more ?? [])];
        return [
          {
            type: 'text',
            text: `${scope.wholePage ? 'The page' : 'The element'} as it looks in the editor at desktop width${image.width ? ` (${image.width}×${image.height}px)` : ''}${parts.length > 1 ? `, in ${parts.length} parts from top to bottom` : ''}. Critique it honestly against the design standard, fix anything that is off, then preview again.`,
          },
          ...parts.map((p) => ({ type: 'image' as const, data: p.data, mediaType: p.mediaType })),
        ];
      },
    }),
  ];
}

export function beeQueenTools(ws: Workspace, step: StepRunner): BeeQueenTool[] {
  /**
   * Writing tools do exactly what the matching admin screen does, so they need that
   * screen's capability: `use_beequeen` alone only reads.
   */
  const needs = <T>(capability: CapabilitySlug, run: (input: T) => Promise<string>) =>
    (input: T) =>
      ws.actor.capabilities.includes(capability)
        ? run(input)
        : Promise.resolve(
            `ERROR: This account does not have the "${capability}" permission, which that change needs. Tell the owner what you wanted to do so they can grant it or make the change.`,
          );
  /** Site-wide changes: every one of these permissions. */
  const needsAll = <T>(capabilities: CapabilitySlug[], run: (input: T) => Promise<string>) =>
    (input: T) => {
      const missing = capabilities.filter((c) => !ws.actor.capabilities.includes(c));
      return missing.length
        ? Promise.resolve(
            `ERROR: This account does not have the "${missing.join('" and "')}" permission, which that change needs. Tell the owner what you wanted to do so they can grant it or make the change.`,
          )
        : run(input);
    };
  /** Reading theme code: either screen that edits it (Appearance or Backend Fields). */
  const needsAny = <T>(capabilities: CapabilitySlug[], run: (input: T) => Promise<string>) =>
    (input: T) =>
      capabilities.some((c) => ws.actor.capabilities.includes(c))
        ? run(input)
        : Promise.resolve(
            `ERROR: This account needs the "${capabilities.join('" or "')}" permission to read theme code. Tell the owner what you wanted to look at.`,
          );
  return [
    tool({
      name: 'get_site_overview',
      description: 'Active theme, frontend runtime, every layout with its fields, and the page list.',
      schema: z.object({}),
      run: () => step('Looking at your site', () => siteOverview(ws)),
    }),
    tool({
      name: 'list_theme_files',
      description: 'Text files in the client theme (writable) and its parent theme (read-only reference).',
      schema: z.object({}),
      run: () => step('Listing theme files', () => listThemeFiles()),
    }),
    tool({
      name: 'read_theme_file',
      description: 'Read a theme file by its theme-relative path (child theme first, then the parent).',
      schema: z.object({ path: z.string().describe('Theme-relative path') }),
      run: needsAny(['edit_theme_options', 'manage_fields'], ({ path }: { path: string }) => step(`Reading ${path}`, () => readThemeFile(path))),
    }),
    tool({
      name: 'write_theme_file',
      description: 'Write a file in the client theme (not layouts/ — use save_layout — and not theme.json).',
      schema: z.object({
        path: z.string().describe('Theme-relative path, e.g. "header/styles.scss"'),
        content: z.string().describe('Complete new file content'),
      }),
      run: needs('edit_theme_options', ({ path, content }) =>
        step(`Saving ${path}`, () => writeThemeFile(ws, path, content)),
      ),
    }),
    tool({
      name: 'read_layout',
      description: 'A layout’s Backend Fields definition, template, SCSS and script.',
      schema: z.object({ slug: z.string() }),
      run: needsAny(['edit_theme_options', 'manage_fields'], ({ slug }: { slug: string }) => step(`Reading layout ${slug}`, () => readLayout(slug))),
    }),
    tool({
      name: 'save_layout',
      description: 'Create or update a layout: writes the Backend Fields field group AND the theme files (template, styles.scss…',
      schema: z.object({
        title: z.string().describe('Human title, e.g. "About Hero". Determines the slug.'),
        description: z.string().optional().describe('One line shown in Backend Fields'),
        fields: z
          .array(
            z
              .object({
                type: z.string().describe('Field type, e.g. text, textarea, wysiwyg, image, link, repeater'),
                label: z.string(),
                name: z.string().describe('snake_case, unique in its level'),
                instructions: z.string().optional(),
                required: z.boolean().optional(),
                defaultValue: z.string().optional(),
                choices: z.array(z.string()).optional().describe('select/radio/checkbox: "value : Label"'),
                returnFormat: z.string().optional(),
                subFields: z
                  .array(z.record(z.string(), z.unknown()))
                  .optional()
                  .describe('repeater/group children — same shape as a field'),
              })
              .passthrough(),
          )
          .describe('Backend Fields definitions the template reads with get_bee_field()'),
        template: z.string().describe('Full layout template ({slug}.php on PHP sites, {slug}.tsx on React sites)'),
        scss: z.string().describe('Full styles.scss, scoped under .{slug}'),
        js: z.string().optional().describe('Full script.js, only if the section needs behaviour'),
      }),
      run: needs('manage_fields', (input) =>
        step(`Building layout “${input.title}”`, () =>
          saveLayout(ws, { ...input, fields: input.fields as Record<string, unknown>[] }),
        ),
      ),
    }),
    tool({
      name: 'get_page',
      description: 'A page’s title, slug, status and blocks — the shape save_page takes.',
      schema: z.object({ id: z.string(), kind: z.string().regex(/^[a-z0-9_-]{1,40}$/).optional() }),
      run: ({ id, kind }) => step(kind && kind !== 'page' ? 'Opening entry' : 'Opening page', () => getPage(ws, id, kind ?? 'page')),
    }),
    tool({
      name: 'list_posts',
      description: 'The blog posts (id, title, /blog path, status).',
      schema: z.object({}),
      run: () => step('Checking blog posts', () => listPosts(ws)),
    }),
    tool({
      name: 'save_post',
      description: 'Create a blog post (no id) or replace one (with id): title, slug, status, excerpt, featuredImageId (media…',
      schema: z.object({
        id: z.string().optional(),
        title: z.string(),
        slug: z.string().optional(),
        status: z.enum(['draft', 'publish']).optional().describe('Default draft'),
        excerpt: z.string().max(400).optional().describe('One or two sentences for cards and search results'),
        featuredImageId: z.string().optional(),
        topics: z.array(z.string().max(80)).max(10).optional(),
        blocks: z.array(z.record(z.string(), z.unknown())),
        removeConfirmed: z.boolean().optional().describe('Only when the user asked to remove the elements left out'),
      }),
      run: needs('edit_posts', (input: SavePostInput) => step(`Saving post “${input.title}”`, () => savePost(ws, input))),
    }),
    tool({
      name: 'save_page',
      description: 'Create a page (no id) or replace an existing page’s title/slug/status/blocks (with id).',
      schema: z.object({
        id: z.string().optional(),
        title: z.string(),
        slug: z.string().optional(),
        status: z.enum(['draft', 'publish']).optional().describe('Default draft'),
        blocks: z.array(z.record(z.string(), z.unknown())),
        removeConfirmed: z.boolean().optional().describe('Only when the user asked to remove the elements left out'),
      }),
      run: needs('edit_pages', (input: SavePageInput) => step(`Saving page “${input.title}”`, () => savePage(ws, input))),
    }),
    tool({
      name: 'import_image',
      description: 'Import a photo from a public https link (an image file, or an Unsplash photo page) into the media library.',
      schema: z.object({
        url: z.string().url(),
        alt: z.string().min(3).max(300),
        name: z.string().max(80).optional().describe('File name without extension, e.g. ellis-armchair'),
      }),
      run: needs('upload_files', (input: ImportImageInput) => step('Importing the photo', () => importImage(ws, input))),
    }),
    tool({
      name: 'list_products',
      description: 'Shop products (id, name, type, price, status), newest first; optional search by name.',
      schema: z.object({ search: z.string().max(80).optional() }),
      run: needs('edit_products', ({ search }: { search?: string }) => step('Checking the shop', () => listProducts(ws, search))),
    }),
    tool({
      name: 'get_product',
      description: 'One product in the shape save_product takes: descriptions, prices, categories, attributes and variations…',
      schema: z.object({ id: z.string() }),
      run: needs('edit_products', ({ id }: { id: string }) => step('Opening the product', () => getProduct(ws, id))),
    }),
    tool({
      name: 'save_product',
      description: 'Create a shop product (no id) or update one (with id; send variations back with their ids).',
      schema: z.object({
        id: z.string().optional(),
        title: z.string().min(1).max(200),
        status: z.enum(['draft', 'publish']).optional().describe('Default draft'),
        type: z.enum(['simple', 'variable']).optional(),
        shortDescription: z.string().max(1000).optional(),
        description: z.string().max(20000).optional(),
        featuredImageId: z.string().optional(),
        galleryIds: z.array(z.string()).max(20).optional(),
        categories: z.array(z.string().max(80)).max(10).optional(),
        sku: z.string().max(100).optional(),
        price: z.union([z.string().max(20), z.number()]).optional(),
        salePrice: z.union([z.string().max(20), z.number()]).optional(),
        manageStock: z.boolean().optional(),
        stockQty: z.number().int().min(0).max(1_000_000).optional(),
        attributes: z
          .array(z.object({ name: z.string().min(1).max(80), options: z.array(z.string().min(1).max(80)).min(1).max(50), variation: z.boolean().optional(), visible: z.boolean().optional() }))
          .max(10)
          .optional(),
        variations: z
          .array(
            z.object({
              id: z.string().optional(),
              attributes: z.record(z.string(), z.string()),
              price: z.union([z.string().max(20), z.number()]).optional(),
              salePrice: z.union([z.string().max(20), z.number()]).optional(),
              sku: z.string().max(100).optional(),
              manageStock: z.boolean().optional(),
              stockQty: z.number().int().min(0).max(1_000_000).optional(),
              imageId: z.string().optional(),
              enabled: z.boolean().optional(),
            }),
          )
          .max(100)
          .optional(),
      }),
      run: needs('edit_products', (input: SaveProductInput) => step(`Saving product “${input.title}”`, () => saveProduct(ws, input))),
    }),
    tool({
      name: 'list_taxonomies',
      description: 'Taxonomies on this site (id, slug, plural, which content types use them) and the content types you can attach…',
      schema: z.object({}),
      run: () => step('Checking taxonomies', () => listTaxonomies(ws)),
    }),
    tool({
      name: 'save_taxonomy',
      description: 'Create a taxonomy (no id) or update one (with id).',
      schema: z.object({
        id: z.string().optional(),
        slug: z.string().describe('lowercase, e.g. product_material'),
        singular: z.string(),
        plural: z.string(),
        description: z.string().optional(),
        hierarchical: z.boolean().optional().describe('true = like categories, false = like tags'),
        objectTypes: z.array(z.string()).min(1),
      }),
      run: needs('manage_fields', (input: SaveTaxonomyInput) =>
        step(`Saving taxonomy “${input.plural}”`, () => saveTaxonomy(ws, input)),
      ),
    }),
    tool({
      name: 'list_site_sections',
      description: 'Site sections (popups, banners, bars…): id, title, on/off and where they show.',
      schema: z.object({}),
      run: () => step('Checking site sections', () => listSiteSections(ws)),
    }),
    tool({
      name: 'save_site_section',
      description: 'Create (no id) or update (with id) a section that shows on every page or on the pages listed — a popup…',
      schema: z.object({
        id: z.string().optional(),
        title: z.string().min(1).max(120).describe('What the owner sees in the admin, e.g. "Spring offer popup"'),
        status: z.enum(['draft', 'publish']).optional(),
        position: z.enum(['top', 'bottom']).optional(),
        pages: z.union([z.literal('all'), z.array(z.string()).min(1).max(200)]).optional(),
        blocks: z.array(z.record(z.string(), z.unknown())),
        removeConfirmed: z.boolean().optional().describe('Only when the user asked to remove the elements left out'),
      }),
      run: needsAll(['edit_theme_options', 'edit_pages'], (input: SaveSiteSectionInput) =>
        step(`Saving site section “${input.title}”`, () => saveSiteSection(ws, input)),
      ),
    }),
    tool({
      name: 'list_content_types',
      description: 'Custom content types (id, slug, names, entries) — pages, posts and products are built in.',
      schema: z.object({}),
      run: () => step('Checking content types', () => listContentTypes(ws)),
    }),
    tool({
      name: 'save_content_type',
      description: 'Create (no id) or update (with id) a custom content type with its own admin menu.',
      schema: z.object({
        id: z.string().optional(),
        slug: z.string().regex(/^[a-z][a-z0-9-]{1,38}$/).describe('lowercase, e.g. team-member'),
        singular: z.string().min(1).max(60),
        plural: z.string().min(1).max(60),
        description: z.string().max(300).optional(),
        public: z.boolean().optional(),
        hasArchive: z.boolean().optional(),
        menuIcon: z.string().max(40).optional().describe('A Phosphor icon name, e.g. Users, Calendar, MapPin'),
      }),
      run: needs('manage_fields', (input: SaveContentTypeInput) =>
        step(`Saving content type “${input.plural}”`, () => saveContentType(ws, input)),
      ),
    }),
    tool({
      name: 'list_entries',
      description: 'The entries of a custom content type (id, title, status).',
      schema: z.object({ type: z.string().regex(/^[a-z0-9_-]{1,40}$/) }),
      run: ({ type }) => step('Checking entries', () => listEntries(ws, type)),
    }),
    tool({
      name: 'save_entry',
      description: 'Create (no id) or update (with id) an entry of a custom content type — blocks in the same shape as save_page…',
      schema: z.object({
        type: z.string().regex(/^[a-z0-9_-]{1,40}$/),
        id: z.string().optional(),
        title: z.string().min(1),
        slug: z.string().optional(),
        status: z.enum(['draft', 'publish']).optional().describe('Default draft'),
        blocks: z.array(z.record(z.string(), z.unknown())),
        removeConfirmed: z.boolean().optional(),
      }),
      run: needs('edit_posts', (input: SaveEntryInput) => step(`Saving “${input.title}”`, () => saveEntry(ws, input))),
    }),
    tool({
      name: 'get_bookings_setup',
      description: 'Bee Bookings as it is now: whether it is on, business hours and rules, services and staff (with ids), and how…',
      schema: z.object({}),
      run: needs('manage_bookings', () => step('Checking the bookings setup', () => getBookingsSetup(ws))),
    }),
    tool({
      name: 'save_bookings_setup',
      description: 'Set up appointment booking: add or update services, staff and settings (send ids from get_bookings_setup to…',
      schema: z.object({
        services: z
          .array(
            z.object({
              id: z.string().optional(),
              name: z.string().max(120),
              durationMin: z.number().int().min(5).max(1440).optional(),
              price: z.number().min(0).max(1_000_000).optional(),
              bufferMin: z.number().int().min(0).max(480).optional(),
              description: z.string().max(1000).optional(),
              active: z.boolean().optional(),
            }),
          )
          .max(50)
          .optional(),
        staff: z
          .array(
            z.object({
              id: z.string().optional(),
              name: z.string().max(120),
              email: z.string().max(200).optional(),
              phone: z.string().max(40).optional(),
              services: z.array(z.string().max(120)).max(50).optional().describe('Service names or ids this person does; omit or [] for all'),
              hours: z.record(z.string(), z.array(z.object({ from: z.string(), to: z.string() }))).nullable().optional().describe('Own weekly hours; null = the business hours'),
              daysOff: z.array(z.object({ from: z.string(), to: z.string().optional(), note: z.string().optional() })).max(100).optional(),
              active: z.boolean().optional(),
            }),
          )
          .max(50)
          .optional(),
        settings: z
          .object({
            hours: z.record(z.string(), z.array(z.object({ from: z.string(), to: z.string() }))).optional(),
            slotStep: z.number().int().optional().describe('Minutes between start times: 15, 30, 60…'),
            minNoticeHours: z.number().int().optional(),
            maxDaysAhead: z.number().int().optional(),
            closedDates: z.array(z.object({ from: z.string(), to: z.string().optional(), note: z.string().optional() })).max(100).optional().describe('Holidays, YYYY-MM-DD'),
            autoConfirm: z.boolean().optional(),
            notifyEmail: z.string().max(200).optional(),
            reminderHours: z.number().int().optional(),
            cancelHours: z.number().int().optional(),
            currency: z.string().max(3).optional(),
            location: z.string().max(300).optional(),
            confirmationNote: z.string().max(1000).optional(),
            timezone: z.string().max(64).optional(),
          })
          .optional(),
      }),
      run: needs('manage_bookings', (input: BookingsSetupInput) => step('Setting up bookings', () => saveBookingsSetup(ws, input))),
    }),
    tool({
      name: 'look_at_reference_site',
      description: 'Read a website the owner likes, as text (nothing from it runs): which libraries make its effects (GSAP…',
      schema: z.object({ url: z.string().min(4).max(2000), focus: z.string().max(120).optional() }),
      run: ({ url, focus }) => step(`Studying ${referenceHost(url)}`, () => studyReferenceSite(url, focus)),
    }),
    tool({
      name: 'look_at_page',
      description: 'See a page or blog post as visitors will: pictures of it on a computer (1440px wide) and on a phone.',
      schema: z.object({
        id: z.string().optional().describe('A page or post id'),
        kind: z.enum(['page', 'post']).optional().describe('With id: "post" for a blog post (default "page")'),
        path: z.string().max(300).optional().describe('A path on this site, e.g. "/"'),
      }),
      run: async (input: LookAtPageInput) => {
        let pictures: ToolContent[] = [];
        const text = await step('Looking at the page', async () => {
          pictures = await lookAtPage(ws, input);
          return 'ok';
        });
        return pictures.length ? pictures : text;
      },
    }),
    tool({
      name: 'add_font',
      description: 'Put a Google Font on the site itself (visitors never load anything from Google): downloads its .woff2 files…',
      schema: z.object({
        family: z.string().min(2).max(60),
        weights: z
          .array(z.number().int().min(100).max(900).multipleOf(100))
          .min(1)
          .max(6)
          .optional(),
        italic: z.boolean().optional().describe('Also the italic styles'),
      }),
      run: needs('edit_theme_options', (input: AddFontInput) => step(`Adding the font ${input.family}`, () => addFont(ws, input))),
    }),
    tool({
      name: 'save_design_brief',
      description: 'Update the site’s design brief (it goes into every later Beekiri request in this theme).',
      schema: z.object({
        colors: z
          .array(z.string().regex(/^#[0-9a-fA-F]{6}$/))
          .max(4)
          .optional()
          .describe('Main colour first, then the accent'),
        mode: z.enum(['light', 'dark']).optional(),
        fontStyle: z.enum(DESIGN_FONT_STYLES).optional(),
        fonts: z.string().max(200).optional(),
        feel: z.array(z.string().max(40)).max(8).optional(),
        notes: z.string().max(1500).optional(),
        decisions: z.string().max(2000).optional(),
      }),
      run: needs('edit_theme_options', (input: Record<string, unknown>) =>
        step('Updating the design brief', async () => {
          await saveDesignBrief(input, { merge: true });
          return 'Saved. Every later request in this theme follows the updated brief.';
        }),
      ),
    }),
    tool({
      name: 'list_media',
      description: 'Files in the media library, newest first, 50 a page (id, name, size, folder, alt, url): images by default, or…',
      schema: z.object({
        search: z.string().optional().describe('Part of the file name'),
        kind: z.enum(['image', 'video', 'document', 'all']).optional(),
        folder: z.string().optional().describe('A folder id from list_media_folders, or "none"'),
        page: z.number().int().min(1).optional(),
      }),
      run: (input) => step('Checking the media library', () => listMedia(ws, input)),
    }),
    tool({
      name: 'list_media_folders',
      description: 'The media library folders (id, path, number of files) and how many files are in no folder.',
      schema: z.object({}),
      run: needs('upload_files', () => step('Checking the media folders', () => listMediaFolders(ws))),
    }),
    tool({
      name: 'look_at_media',
      description: 'See up to 16 photos of the media library as small pictures, in the order of the ids, to tell what each shows…',
      schema: z.object({ ids: z.array(z.string()).min(1).max(16) }),
      run: async ({ ids }) => {
        if (!ws.actor.capabilities.includes('upload_files')) {
          return 'ERROR: This account does not have the "upload_files" permission, which the media library needs. Tell the owner what you wanted to do so they can grant it or make the change.';
        }
        let pictures: ToolResult = '';
        const text = await step(`Looking at ${ids.length} photo${ids.length === 1 ? '' : 's'}`, async () => {
          pictures = await lookAtMedia(ws, ids);
          return 'ok';
        });
        return text === 'ok' ? pictures : text;
      },
    }),
    tool({
      name: 'create_media_folder',
      description: 'Make a folder in the media library (an existing folder with that name at that level is reused).',
      schema: z.object({
        name: z.string().min(1).max(80),
        parentId: z.string().optional().describe('A folder id to make it inside; leave out for the top level'),
      }),
      run: needs('upload_files', ({ name, parentId }: { name: string; parentId?: string }) =>
        step(`Making the folder “${name}”`, () => createMediaFolder(ws, name, parentId ?? null)),
      ),
    }),
    tool({
      name: 'move_media',
      description: 'Move files into a media folder (folderId "none" takes them out of every folder).',
      schema: z.object({ ids: z.array(z.string()).min(1).max(500), folderId: z.string().describe('A folder id, or "none"') }),
      run: needs('upload_files', ({ ids, folderId }: { ids: string[]; folderId: string }) =>
        step(`Moving ${ids.length} file${ids.length === 1 ? '' : 's'}`, () => moveMedia(ws, ids, folderId === 'none' ? null : folderId)),
      ),
    }),
    tool({
      name: 'set_media_alt',
      description: 'Save the alt text of a photo: what it shows, for screen readers and search engines, in one short sentence in…',
      schema: z.object({ id: z.string(), alt: z.string().max(500) }),
      run: needs('upload_files', ({ id, alt }: { id: string; alt: string }) => step('Writing alt text', () => setMediaAlt(ws, id, alt))),
    }),
    tool({
      name: 'list_forms',
      description: 'The forms of the site (Bee Forms): id, title, number of entries and unread entries.',
      schema: z.object({}),
      run: needs('view_form_entries', () => step('Checking the forms', () => listForms(ws))),
    }),
    tool({
      name: 'find_form_entries',
      description: 'Find form entries: how many match, where they came from (channel / source) and the newest ones.',
      schema: entryFilterSchema.extend({ limit: z.number().int().min(1).max(50).optional() }),
      run: needs('view_form_entries', ({ limit, ...filter }: EntryFilter & { limit?: number }) =>
        step('Looking through form entries', () => findFormEntries(ws, filter, limit)),
      ),
    }),
    tool({
      name: 'export_form_entries',
      description: 'Put every matching form entry in a CSV file the owner downloads from the chat (all forms together, one column…',
      schema: entryFilterSchema.extend({ title: z.string().min(1).max(80) }),
      run: needs('view_form_entries', ({ title, ...filter }: EntryFilter & { title: string }) =>
        step('Preparing the export', () => exportFormEntries(ws, filter, title)),
      ),
    }),
    tool({
      name: 'set_form_entries_status',
      description: 'Mark form entries as read, unread, spam or trash (ids from find_form_entries; entries in the trash can be…',
      schema: z.object({ ids: z.array(z.string()).min(1).max(500), status: z.enum(['read', 'unread', 'spam', 'trash']) }),
      run: needs('view_form_entries', ({ ids, status }: { ids: string[]; status: 'read' | 'unread' | 'spam' | 'trash' }) =>
        step('Updating the entries', () => setFormEntriesStatus(ws, ids, status)),
      ),
    }),
    tool({
      name: 'find_orders',
      description: 'Find shop orders: how many match and the newest ones (number, date, status, customer, total).',
      schema: orderFilterSchema.extend({ limit: z.number().int().min(1).max(50).optional() }),
      run: needs('manage_shop', ({ limit, ...filter }: OrderFilter & { limit?: number }) => step('Looking through orders', () => findOrders(ws, filter, limit))),
    }),
    tool({
      name: 'export_orders',
      description: 'Put every matching order in a CSV file the owner downloads from the chat (items, totals, payment, shipping…',
      schema: orderFilterSchema.extend({ title: z.string().min(1).max(80) }),
      run: needs('manage_shop', ({ title, ...filter }: OrderFilter & { title: string }) => step('Preparing the export', () => exportOrders(ws, filter, title))),
    }),
    tool({
      name: 'find_appointments',
      description: 'Find appointments (Bee Bookings): how many match and the first ones (time in UTC, service, staff, status…',
      schema: appointmentFilterSchema.extend({ limit: z.number().int().min(1).max(50).optional() }),
      run: needs('manage_bookings', ({ limit, ...filter }: AppointmentFilter & { limit?: number }) =>
        step('Looking through appointments', () => findAppointments(ws, filter, limit)),
      ),
    }),
    tool({
      name: 'export_appointments',
      description: 'Put every matching appointment in a CSV file the owner downloads from the chat.',
      schema: appointmentFilterSchema.extend({ title: z.string().min(1).max(80) }),
      run: needs('manage_bookings', ({ title, ...filter }: AppointmentFilter & { title: string }) =>
        step('Preparing the export', () => exportAppointments(ws, filter, title)),
      ),
    }),
  ];
}

const dateText = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD').optional();
const entryFilterSchema = z.object({
  formId: z.string().optional(),
  status: z.enum(['inbox', 'all', 'unread', 'read', 'spam', 'trash']).optional(),
  search: z.string().max(200).optional(),
  source: z.string().max(100).optional(),
  from: dateText,
  to: dateText,
});
const orderFilterSchema = z.object({
  status: z.enum(['all', 'pending', 'on-hold', 'processing', 'completed', 'cancelled', 'refunded', 'failed']).optional(),
  search: z.string().max(200).optional(),
  from: dateText,
  to: dateText,
});
const appointmentFilterSchema = z.object({
  status: z.enum(['upcoming', 'past', 'pending', 'confirmed', 'completed', 'no_show', 'cancelled']).optional(),
  search: z.string().max(100).optional(),
  from: dateText,
  to: dateText,
});
