import * as cheerio from 'cheerio';
import { request as httpRequest, type IncomingMessage } from 'http';
import { request as httpsRequest } from 'https';
import { isIP } from 'net';
import type { Readable } from 'stream';
import { createBrotliDecompress, createGunzip, createInflate } from 'zlib';
import { isPublicAddress, publicLookup } from './remote-image';
import { untrusted } from './untrusted';

/**
 * A website the owner likes, read as text so Beekiri can learn how its effects are made: the page,
 * its stylesheets and its own scripts are downloaded (public addresses only, checked on every
 * connection; size-, time- and file-capped) and scanned for motion and design. Nothing from it
 * ever runs, here or in the chat, and Beekiri gets only the parts about how it moves and looks.
 */

const TIMEOUT_MS = 15_000;
const MAX_REDIRECTS = 5;
const PAGE_MAX = 3 * 1024 * 1024;
const FILE_MAX = 1.5 * 1024 * 1024;
const TOTAL_MAX = 10 * 1024 * 1024;
const MAX_STYLESHEETS = 6;
const MAX_SCRIPTS = 12;
const OUTPUT_MAX = 18_000;
const CACHE_MS = 10 * 60_000;
const UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36 Beekiri/1.0';

const PRIVATE = 'That link points to a private or local address. Beekiri only reads public websites.';
const TOO_BIG = 'That page is too big to read.';
const SLOW = 'That site took too long to answer.';

export type TextFetcher = (url: string, accept: string, max: number) => Promise<{ url: string; type: string; text: string }>;
type Asset = { url: string; text: string };
/** What was downloaded from a reference site, before it is described. */
export type ReferenceMaterials = {
  url: string;
  html: string;
  styleUrls: string[];
  scriptUrls: string[];
  styles: Asset[];
  scripts: Asset[];
  skipped: string[];
};

// ─── Downloading (text only, public addresses only) ──────────────────────────

function decoded(res: IncomingMessage): Readable {
  const encoding = String(res.headers['content-encoding'] ?? '').toLowerCase();
  if (encoding === 'gzip' || encoding === 'x-gzip') return res.pipe(createGunzip());
  if (encoding === 'br') return res.pipe(createBrotliDecompress());
  if (encoding === 'deflate') return res.pipe(createInflate());
  return res;
}

function get(url: URL, accept: string, max: number): Promise<{ status: number; location?: string; type: string; text?: string }> {
  return new Promise((resolve, reject) => {
    const send = url.protocol === 'http:' ? httpRequest : httpsRequest;
    const req = send(
      url,
      {
        method: 'GET',
        lookup: publicLookup,
        timeout: TIMEOUT_MS,
        headers: { 'user-agent': UA, accept, 'accept-language': 'en;q=0.9, *;q=0.5', 'accept-encoding': 'gzip, deflate, br' },
      },
      (res) => {
        const status = res.statusCode ?? 0;
        const type = String(res.headers['content-type'] ?? '').split(';')[0].trim().toLowerCase();
        if (status >= 300 && status < 400 && res.headers.location) {
          res.resume();
          return resolve({ status, location: res.headers.location, type });
        }
        if (status !== 200) {
          res.resume();
          return resolve({ status, type });
        }
        // Counted after decompression, so a small compressed file can't unpack into a huge one.
        const body = decoded(res);
        const chunks: Buffer[] = [];
        let size = 0;
        body.on('data', (chunk: Buffer) => {
          size += chunk.length;
          if (size > max) {
            res.destroy();
            reject(new Error(TOO_BIG));
          } else chunks.push(chunk);
        });
        body.on('end', () => resolve({ status, type, text: Buffer.concat(chunks).toString('utf8') }));
        body.on('error', reject);
      },
    );
    // A whole-request deadline (the socket timeout alone lets a slow drip go on for ever).
    const deadline = setTimeout(() => req.destroy(new Error(SLOW)), TIMEOUT_MS);
    req.on('close', () => clearTimeout(deadline));
    req.on('timeout', () => req.destroy(new Error(SLOW)));
    req.on('error', (e: NodeJS.ErrnoException) => reject(e.code === 'EPRIVATE' ? new Error(PRIVATE) : e));
    req.end();
  });
}

function parseLink(raw: string): URL {
  const text = raw.trim();
  try {
    return new URL(/^[a-z][a-z0-9+.-]*:/i.test(text) ? text : `https://${text}`);
  } catch {
    throw new Error('That is not a valid link. Send a full address such as https://example.com.');
  }
}

function checkLink(url: URL) {
  if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new Error('Only website links (https://…) can be read.');
  if (url.username || url.password) throw new Error('Links with a user name or password are not allowed.');
  const host = url.hostname.replace(/^\[|\]$/g, '');
  if (host === 'localhost' || (isIP(host) && !isPublicAddress(host))) throw new Error(PRIVATE);
}

function statusMessage(status: number): string {
  if ([401, 403, 429, 451, 503].includes(status)) {
    return `That site did not let Beekiri read it (it blocks automated visitors, HTTP ${status}). Ask the owner for a screenshot of it instead (the paperclip in the chat).`;
  }
  if (status === 404 || status === 410) return `That page was not found (HTTP ${status}). Check the link.`;
  return `That site answered with an error (HTTP ${status}). Try again later, or ask the owner for a screenshot.`;
}

/** Follows up to five redirects; every hop is checked again (public address, http or https). */
const fetchText: TextFetcher = async (raw, accept, max) => {
  let url = parseLink(raw);
  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    checkLink(url);
    const res = await get(url, accept, max);
    if (res.location) {
      url = new URL(res.location, url);
      continue;
    }
    if (res.text === undefined) throw new Error(statusMessage(res.status));
    return { url: url.href, type: res.type, text: res.text };
  }
  throw new Error('That link redirects too many times.');
};

// ─── What a page loads ───────────────────────────────────────────────────────

/** Libraries known by their file name, host or code: noted, not downloaded (unless `read`). */
type Library = { name: string; file?: RegExp; host?: RegExp; code?: RegExp; read?: boolean };
const LIBRARIES: Library[] = [
  // The core file only: plugins sit in the same folder and are matched by their own names below.
  { name: 'GSAP', file: /\bgsap(?:\.min)?\.js|\/gsap@[\d.]+\/?(?:\+esm)?$|TweenMax/i, code: /\bgsap\.(?:to|from|fromTo|timeline|set|registerPlugin)\(/ },
  { name: 'GSAP ScrollTrigger', file: /ScrollTrigger(?:\.min)?\.js/i, code: /\bScrollTrigger\b|scrollTrigger:\s*\{/ },
  { name: 'GSAP SplitText', file: /SplitText(?:\.min)?\.js/i, code: /\bnew SplitText\(/ },
  { name: 'GSAP ScrollSmoother', file: /ScrollSmoother/i, code: /\bScrollSmoother\.create\(/ },
  { name: 'Lenis (smooth scrolling)', file: /\/lenis(?:@[\d.]+)?\/|\blenis(?:\.min)?\.m?js|@studio-freight\/lenis/i, code: /\bnew Lenis\(|\blenis-smooth\b/ },
  { name: 'Locomotive Scroll', file: /locomotive-scroll/i, code: /\bLocomotiveScroll\b|data-scroll-container/ },
  { name: 'Three.js', file: /\/three(?:@[\d.]+)?\/|\bthree(?:\.module)?(?:\.min)?\.js/i, code: /\bnew THREE\.\w+|\bWebGLRenderer\b/ },
  { name: 'Lottie', file: /lottie(?:-web|-player)?(?:\.min)?\.js|@lottiefiles|dotlottie/i, code: /lottie\.loadAnimation|<lottie-player|<dotlottie-player/ },
  { name: 'Swiper (sliders)', file: /swiper(?:-bundle)?(?:\.min)?\.(?:js|css)|\/swiper@/i, code: /\bnew Swiper\(/ },
  { name: 'Splide (sliders)', file: /splide(?:\.min)?\.(?:js|css)|@splidejs/i, code: /\bnew Splide\(/ },
  { name: 'Slick (sliders)', file: /slick(?:\.min)?\.(?:js|css)/i },
  { name: 'Embla (carousel)', file: /embla-carousel/i, code: /\bEmblaCarousel\(/ },
  { name: 'AOS (animate on scroll)', file: /\baos(?:@[\d.]+)?\/|\baos(?:\.min)?\.(?:js|css)/i, code: /\bAOS\.init\(/ },
  { name: 'Animate.css', file: /animate(?:\.min)?\.css|animate\.css@/i },
  { name: 'anime.js', file: /anime(?:\.min)?\.js|animejs/i, code: /\banime\(\{/ },
  { name: 'Motion (Framer Motion / Motion One)', file: /framer-motion|\/motion@|motion\.dev/i, code: /\bwhileInView:|\bwhileHover:/ },
  // Builders: their files hold the site's own interactions, so they are noted and still read.
  { name: 'Framer (site builder)', host: /(?:^|\.)framerusercontent\.com$|(?:^|\.)framer\.com$/i, code: /data-framer-name/, read: true },
  { name: 'Webflow interactions', file: /\/webflow(?:\.[\w-]+)*\.js$/i, code: /data-w-id=|Webflow\.require\(['"]ix2/, read: true },
  { name: 'Barba.js (page transitions)', file: /barba(?:\.umd)?(?:\.min)?\.js|@barba\//i, code: /\bbarba\.init\(/ },
  { name: 'Swup (page transitions)', file: /swup(?:\.min)?\.js|\/swup@/i, code: /\bnew Swup\(/ },
  { name: 'Splitting.js', file: /splitting(?:\.min)?\.(?:js|css)/i, code: /\bSplitting\(\)/ },
  { name: 'SplitType', file: /split-type/i, code: /\bnew SplitType\(/ },
  { name: 'ScrollMagic', file: /scrollmagic/i, code: /\bScrollMagic\./ },
  { name: 'Rellax (parallax)', file: /rellax(?:\.min)?\.js/i, code: /\bnew Rellax\(/ },
  { name: 'Typed.js', file: /typed(?:\.umd)?(?:\.min)?\.js/i, code: /\bnew Typed\(/ },
  { name: 'PixiJS', file: /pixi(?:\.min)?\.js|\/pixi\.js@|@pixi\//i, code: /\bnew PIXI\.\w+/ },
  { name: 'p5.js', file: /\bp5(?:\.min)?\.js/i, code: /\bnew p5\(/ },
  { name: 'Matter.js (physics)', file: /matter(?:-js)?(?:\.min)?\.js/i, code: /\bMatter\.Engine\b/ },
  { name: 'Spline (3D scenes)', host: /(?:^|\.)spline\.design$/i, file: /@splinetool/i, code: /<spline-viewer/ },
  { name: 'Rive', file: /@rive-app|rive\.wasm/i, code: /\bnew rive\.Rive\(/ },
  { name: 'Alpine.js', file: /alpinejs|alpine(?:\.min)?\.js/i, code: /\bx-data=/ },
  { name: 'jQuery', file: /jquery(?:[-.][\d.]+)?(?:\.min)?\.js|\/jquery@/i },
];

/** Analytics, ads, chat widgets, consent banners and payments: never downloaded. */
const TRACKERS =
  /google-?analytics|googletagmanager|gtag\/js|doubleclick|googlesyndication|connect\.facebook|facebook\.net|fbevents|hotjar|clarity\.ms|segment\.(?:com|io)|intercom|hs-scripts|hs-analytics|hsforms|hubspot|cookiebot|onetrust|cookielaw|usercentrics|termly|recaptcha|hcaptcha|turnstile|stripe\.com|paypal|sentry|newrelic|nr-data|datadog|tiktok|snap\.licdn|licdn\.com|ads-twitter|platform\.twitter|pinimg|pinterest|yandex|mixpanel|amplitude|plausible|matomo|cloudflareinsights|crisp\.chat|tawk\.to|zendesk|zdassets|drift\.com|klaviyo|mailchimp|cdn\.shopify\.com\/shopifycloud|youtube\.com\/iframe_api|player\.vimeo/i;

/** Framework start-up code that never holds a site's own effects. */
const BOILERPLATE = /\/_next\/static\/chunks\/(?:framework|webpack|polyfills|main|main-app|react-refresh)[-.]|\/polyfills?[-.][\w]+\.js|\/runtime[-.][\w]+\.js/i;

/** File names are matched on the path only, so a library's own website isn't taken for the library. */
function libraryOf(url: string): Library | null {
  try {
    const u = new URL(url);
    const path = `${u.pathname}${u.search}`;
    return LIBRARIES.find((l) => l.file?.test(path) || l.host?.test(u.hostname)) ?? null;
  } catch {
    return null;
  }
}

function versionOf(url: string): string | null {
  return url.match(/@(\d+(?:\.\d+){0,2})(?![\w.])/)?.[1] ?? url.match(/\/(\d+\.\d+\.\d+)\//)?.[1] ?? null;
}

/** "www.example.co.uk" → "example.co.uk" (close enough to tell a site's own files from others'). */
function siteOf(host: string): string {
  const labels = host.toLowerCase().split('.');
  const take = labels.length > 2 && labels[labels.length - 1].length === 2 && labels[labels.length - 2].length <= 3 ? 3 : 2;
  return labels.slice(-take).join('.');
}

function sameSite(url: string, page: URL): boolean {
  try {
    return siteOf(new URL(url).hostname) === siteOf(page.hostname);
  } catch {
    return false;
  }
}

/** A site's own code: its own domain, or the builder that hosts it (Webflow, Framer, Squarespace…). */
function ownFile(url: string, page: URL): boolean {
  return sameSite(url, page) || /website-files\.com|webflow\.com|framerusercontent\.com|squarespace(?:-cdn)?\.com|parastorage\.com|wixstatic\.com|cdn\.jsdelivr\.net\/gh\//i.test(url);
}

/** Downloads the page, then its stylesheets and its own scripts (as text). */
export async function readReferenceSite(link: string, read: TextFetcher = fetchText): Promise<ReferenceMaterials> {
  const page = await read(link, 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.5', PAGE_MAX);
  if (page.type && !/html|xml/.test(page.type)) throw new Error(`That link is not a web page (it is ${page.type}). Send the address of the page itself.`);
  const pageUrl = new URL(page.url);
  const $ = cheerio.load(page.text);
  const base = (() => {
    try {
      return new URL($('base[href]').attr('href') ?? '', pageUrl);
    } catch {
      return pageUrl;
    }
  })();
  const absolute = (href: string | undefined) => {
    if (!href || /^(?:data|javascript|blob):/i.test(href.trim())) return null;
    try {
      const u = new URL(href.trim(), base);
      return u.protocol === 'https:' || u.protocol === 'http:' ? u.href : null;
    } catch {
      return null;
    }
  };
  const unique = (list: (string | null)[]) => [...new Set(list.filter((u): u is string => Boolean(u)))];

  const styleUrls = unique(
    $('link[href]')
      .filter((_, el) => /\bstylesheet\b/i.test($(el).attr('rel') ?? '') || ($(el).attr('rel') === 'preload' && $(el).attr('as') === 'style'))
      .map((_, el) => absolute($(el).attr('href')))
      .get(),
  );
  const scriptUrls = unique([
    ...$('script[src]').map((_, el) => absolute($(el).attr('src'))).get(),
    ...$('link[rel="modulepreload"][href]').map((_, el) => absolute($(el).attr('href'))).get(),
  ]);
  const styles: Asset[] = $('style')
    .map((_, el) => ({ url: '(in the page)', text: $(el).text() }))
    .get()
    .filter((s) => s.text.trim());
  const scripts: Asset[] = $('script:not([src])')
    .filter((_, el) => !/json|template|html|x-shader|text\/plain/i.test($(el).attr('type') ?? ''))
    .map((_, el) => ({ url: '(in the page)', text: $(el).text() }))
    .get()
    .filter((s) => s.text.trim());

  const skipped: string[] = [];
  let budget = TOTAL_MAX - page.text.length;
  const download = async (urls: string[], accept: string): Promise<Asset[]> => {
    const got = await Promise.allSettled(urls.map((url) => read(url, accept, FILE_MAX)));
    const out: Asset[] = [];
    got.forEach((r, i) => {
      if (r.status !== 'fulfilled') return void skipped.push(`${urls[i]} (could not be read)`);
      if (r.value.text.length > budget) return void skipped.push(`${urls[i]} (over the size limit)`);
      budget -= r.value.text.length;
      out.push({ url: r.value.url, text: r.value.text });
    });
    return out;
  };

  // A known library is only noted; a builder's runtime is read too (it holds the site's interactions).
  const library = (u: string) => {
    const lib = libraryOf(u);
    return Boolean(lib && !lib.read);
  };
  // Analytics and widgets from other companies; a site's own files are always its own.
  const tracker = (u: string) => TRACKERS.test(u) && !sameSite(u, pageUrl);
  const cssToRead = styleUrls.filter((u) => !/fonts\.googleapis\.com|use\.typekit\.net|fonts\.bunny\.net/i.test(u) && !library(u));
  if (cssToRead.length > MAX_STYLESHEETS) skipped.push(`${cssToRead.length - MAX_STYLESHEETS} more stylesheets (only the first ${MAX_STYLESHEETS} are read)`);
  styles.push(...(await download(cssToRead.slice(0, MAX_STYLESHEETS), 'text/css,*/*;q=0.1')));

  const trackers = scriptUrls.filter(tracker);
  if (trackers.length) skipped.push(`${trackers.length} analytics, ads or widget scripts (not about the design)`);
  // The site's own files first, and among them the ones named like where effects live.
  const priority = (u: string) =>
    (ownFile(u, pageUrl) ? 4 : 0) + (/anim|motion|gsap|scroll|hero|home|index|main|app|site|page|custom|script|global|theme|interaction|effect/i.test(u.split('/').pop() ?? '') ? 2 : 0) -
    (/vendor|polyfill|chunk-vendors|runtime|consent|cookie|i18n|locale|sentry|analytics|tracking/i.test(u) ? 3 : 0);
  const jsToRead = scriptUrls
    .filter((u) => !tracker(u) && !library(u) && !BOILERPLATE.test(u))
    .sort((a, b) => priority(b) - priority(a));
  if (jsToRead.length > MAX_SCRIPTS) skipped.push(`${jsToRead.length - MAX_SCRIPTS} more scripts (only the first ${MAX_SCRIPTS} are read)`);
  scripts.push(...(await download(jsToRead.slice(0, MAX_SCRIPTS), 'application/javascript,text/javascript,*/*;q=0.1')));

  return { url: page.url, html: page.text, styleUrls, scriptUrls, styles, scripts, skipped };
}

// ─── CSS: keyframes, animations, transitions, scroll-driven motion ──────────

type CssBlock = { prelude: string; body: string | null };

/** Top-level blocks of a stylesheet (comments and strings respected, nothing evaluated). */
function cssBlocks(css: string): CssBlock[] {
  const out: CssBlock[] = [];
  let i = 0;
  const skipString = (at: number) => {
    const quote = css[at];
    let j = at + 1;
    while (j < css.length && css[j] !== quote) j += css[j] === '\\' ? 2 : 1;
    return j + 1;
  };
  while (i < css.length) {
    const start = i;
    while (i < css.length && css[i] !== '{' && css[i] !== '}' && css[i] !== ';') i = css[i] === '"' || css[i] === "'" ? skipString(i) : i + 1;
    if (i >= css.length) break;
    if (css[i] !== '{') {
      if (css[i] === ';' && css.slice(start, i).trim().startsWith('@')) out.push({ prelude: css.slice(start, i).trim(), body: null });
      i++;
      continue;
    }
    let depth = 1;
    let j = i + 1;
    while (j < css.length && depth) {
      if (css[j] === '"' || css[j] === "'") {
        j = skipString(j);
        continue;
      }
      if (css[j] === '{') depth++;
      else if (css[j] === '}') depth--;
      j++;
    }
    out.push({ prelude: css.slice(start, i).trim(), body: css.slice(i + 1, j - 1) });
    i = j;
  }
  return out;
}

const compact = (s: string) =>
  s
    .replace(/\s+/g, ' ')
    .replace(/\s*([{};,>])\s*/g, '$1')
    .replace(/:\s+/g, ':')
    .trim();
const clip = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);

const MOTION_PROP = /^(?:-webkit-)?(?:animation(?:-[a-z-]+)?|transition(?:-[a-z-]+)?|will-change|view-timeline(?:-[a-z]+)?|scroll-timeline(?:-[a-z]+)?|view-transition-name|offset-path|offset-distance|scroll-behavior|scroll-snap-type)$/i;
const SHAPE_PROP = /^(?:-webkit-)?(?:transform|translate|rotate|scale|opacity|filter|clip-path|mask|mask-image|perspective|transform-origin|transform-style|backface-visibility)$/i;
const STATE = /:(?:hover|focus|focus-visible|focus-within|active|checked|target)\b|\.(?:is|has)-[\w-]+|\.(?:active|open|visible|show|in-view|inview|loaded|animated)\b|\[(?:data-state|aria-expanded|aria-current|data-active|open)/i;

type CssFinding = { kind: 'keyframes' | 'animation' | 'transition' | 'state' | 'scroll'; text: string; key: string };

function declarations(body: string): [string, string][] {
  return body
    .split(';')
    .map((d) => d.trim())
    .filter(Boolean)
    .map((d) => {
      const at = d.indexOf(':');
      return at > 0 ? ([d.slice(0, at).trim().toLowerCase(), d.slice(at + 1).trim()] as [string, string]) : null;
    })
    .filter((d): d is [string, string] => Boolean(d));
}

function readCss(css: string, found: CssFinding[], facts: { vars: Map<string, string>; fonts: Set<string>; reducedMotion: boolean }, context = '') {
  for (const block of cssBlocks(css.replace(/\/\*[\s\S]*?\*\//g, ''))) {
    if (block.body === null) continue;
    const prelude = compact(block.prelude);
    if (/^@(?:-webkit-)?keyframes\b/i.test(prelude)) {
      found.push({ kind: 'keyframes', key: prelude, text: `${prelude}{${clip(compact(block.body), 700)}}` });
      continue;
    }
    if (/^@font-face/i.test(prelude)) {
      const family = block.body.match(/font-family\s*:\s*([^;]+)/i)?.[1]?.replace(/["']/g, '').trim();
      if (family) facts.fonts.add(family);
      continue;
    }
    if (/^@(?:media|supports|layer|container|document|scope)\b/i.test(prelude)) {
      if (/prefers-reduced-motion/i.test(prelude)) facts.reducedMotion = true;
      readCss(block.body, found, facts, prelude);
      continue;
    }
    if (prelude.startsWith('@')) continue;
    const decls = declarations(block.body);
    if (/(^|,)\s*(?::root|html)\b/.test(prelude)) {
      for (const [name, value] of decls) {
        if (name.startsWith('--') && facts.vars.size < 60) facts.vars.set(name, clip(compact(value), 80));
      }
    }
    const motion = decls.filter(([p]) => MOTION_PROP.test(p));
    const shape = decls.filter(([p]) => SHAPE_PROP.test(p));
    const where = context ? `${context} ` : '';
    const selector = clip(prelude, 160);
    if (decls.some(([p]) => /^(?:animation-timeline|view-timeline|scroll-timeline)/.test(p))) {
      found.push({ kind: 'scroll', key: prelude, text: `${where}${selector}{${clip(decls.map(([p, v]) => `${p}:${compact(v)}`).join(';'), 400)}}` });
    } else if (decls.some(([p]) => /^(?:-webkit-)?animation(?:-name)?$/.test(p))) {
      found.push({ kind: 'animation', key: prelude, text: `${where}${selector}{${clip([...motion, ...shape].map(([p, v]) => `${p}:${compact(v)}`).join(';'), 300)}}` });
    } else if (STATE.test(prelude) && (shape.length || motion.length)) {
      found.push({ kind: 'state', key: prelude, text: `${where}${selector}{${clip(decls.map(([p, v]) => `${p}:${compact(v)}`).join(';'), 300)}}` });
    } else {
      const transition = decls.filter(([p, v]) => /^(?:-webkit-)?transition(?:-[a-z-]+)?$/.test(p) && !/^none$/i.test(v.trim()));
      if (transition.length) {
        found.push({ kind: 'transition', key: prelude, text: `${where}${selector}{${clip([...transition, ...shape].map(([p, v]) => `${p}:${compact(v)}`).join(';'), 240)}}` });
      }
    }
  }
}

// ─── JavaScript: where the motion is made ────────────────────────────────────

/** What marks animation code, with a weight; object keys and strings survive minifying. */
const JS_SIGNALS: [RegExp, number][] = [
  [/\bgsap\.(?:to|from|fromTo|timeline|set|quickTo|matchMedia|context|utils\.\w+)\(/g, 6],
  [/\bScrollTrigger\.(?:create|batch|refresh|matchMedia)\(|scrollTrigger:\s*\{/g, 6],
  [/\bnew (?:SplitText|SplitType)\(|\bSplitting\(/g, 5],
  [/\bnew (?:Lenis|LocomotiveScroll)\(|ScrollSmoother\.create\(/g, 5],
  [/\bnew THREE\.\w+|\bnew \w+\.(?:WebGLRenderer|ShaderMaterial|PerspectiveCamera)\(|gl_FragColor|gl_Position/g, 5],
  [/lottie\.loadAnimation\(/g, 5],
  [/ease:\s*["'](?:power\d|expo|circ|back|elastic|bounce|sine|quad|cubic|quart|quint|none|steps)[^"']*["']|scrub:\s*(?:!0|true|[\d.]+)|stagger:\s*[\d.{]|yPercent:|xPercent:|autoAlpha:/g, 4],
  [/\bwhileInView:|\bwhileHover:|\binitial:\s*\{\s*opacity|\btransition:\s*\{\s*(?:type|duration|ease|delay|stiffness)/g, 4],
  [/\.animate\(\s*\[|\bnew Animation\(|\bnew KeyframeEffect\(/g, 4],
  [/actionTypeId:\s*["'](?:TRANSFORM_\w+|STYLE_OPACITY|GENERAL_\w+)["']/g, 2],
  [/\bnew IntersectionObserver\(/g, 3],
  [/\brequestAnimationFrame\(/g, 2],
  [/addEventListener\(\s*["'](?:mousemove|pointermove|scroll|wheel)["']/g, 2],
  [/matchMedia\(\s*["']\(prefers-reduced-motion/g, 2],
];

type JsFinding = { file: string; text: string; weight: number };

function readJs(asset: Asset, found: JsFinding[]) {
  const code = asset.text;
  const hits: { at: number; weight: number }[] = [];
  for (const [re, weight] of JS_SIGNALS) {
    re.lastIndex = 0;
    for (let m = re.exec(code); m && hits.length < 400; m = re.exec(code)) hits.push({ at: m.index, weight });
  }
  if (!hits.length) return;
  hits.sort((a, b) => a.at - b.at);
  // Windows around the hits, merged where they overlap.
  const windows: { from: number; to: number; weight: number }[] = [];
  for (const hit of hits) {
    const from = Math.max(0, hit.at - 200);
    const to = Math.min(code.length, hit.at + 420);
    const last = windows[windows.length - 1];
    if (last && from <= last.to) {
      last.to = Math.max(last.to, to);
      last.weight += hit.weight;
    } else windows.push({ from, to, weight: hit.weight });
  }
  const file = asset.url === '(in the page)' ? 'inline script' : asset.url.split('/').pop()?.split('?')[0] || asset.url;
  for (const w of windows) {
    const text = code
      .slice(w.from, Math.min(w.to, w.from + 1100))
      // Long strings (SVG paths, base64, shaders over a line) say nothing about the motion.
      .replace(/(["'`])(?:(?!\1)[^\\\n]|\\.){160,}\1/g, '"…"')
      .replace(/\\[nt]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    // Sites bundle GSAP, Lenis and the like into their own files: the library's insides (private
    // `._names`) say little, the site's own calls on its elements (".hero", querySelector) a lot.
    const own = (text.match(/["'`][.#[][\w-]|querySelector(?:All)?\(|getElementsBy\w+\(/g) ?? []).length;
    const insides = (text.match(/(?:\.|[;{,]\s*)_[a-zA-Z$]/g) ?? []).length + (LIBRARY_INSIDES.test(text) ? 4 : 0);
    if (insides >= 4 && !own) continue;
    found.push({ file, text, weight: w.weight + own * 3 - insides * 2 });
  }
}

/** Words that only appear inside animation libraries, not in a site's use of them. */
const LIBRARY_INSIDES =
  /refreshPriority|immediateRender|isFromStart|_startAt|tweenScroll|scrubDuration|gsap-marker|matrix\(1, 0, 0, 1, 0, 0\)|SteppedEase|_isFlipped|scrollerProxy|ignoreMobileResize|onNativeScroll|debouncedNativeScrollReset|cleanUpClassName|getKeyframes\(|pseudoElement|setOptimisticLinkStatus|registerPlugin\(\w+\)\s*\{|\.prototype\.|__proto__/;

// ─── Description for Beekiri ─────────────────────────────────────────────────

const MOTION_WORDS =
  /reveal|fade|slide|parallax|marquee|ticker|split|stagger|anim|motion|magnetic|cursor|scroll|sticky|pin|loop|tilt|hover|glow|blob|gradient|wave|float|rotate|spin|zoom|scale|blur|mask|clip|typewriter|counter|lottie|canvas|webgl|three|swiper|carousel|slider/i;
const MOTION_DATA = /^data-(?:aos|scroll|anim|animate|animation|reveal|parallax|speed|lag|delay|duration|split|splitting|w-id|framer-appear|framer-name|motion|gsap|lenis|swiper|marquee|cursor|magnetic|sticky|stagger|ease|sal)/i;
const STOP_WORDS = new Set(['the', 'and', 'for', 'with', 'like', 'this', 'that', 'how', 'make', 'site', 'page', 'from', 'effect', 'animation']);

function focusWords(focus?: string): string[] {
  return (focus ?? '')
    .toLowerCase()
    .split(/[^a-z0-9-]+/)
    .filter((w) => w.length >= 3 && !STOP_WORDS.has(w));
}

/**
 * Items that mention what the owner asked about come first, then the strongest. `boost`: how much
 * a mention counts (scripts: a little, so library insides that say "scroll" don't jump ahead).
 */
function rank<T extends { text: string }>(items: T[], words: string[], score: (t: T) => number = () => 0, boost = 1000): T[] {
  const hit = (t: T) => (words.some((w) => t.text.toLowerCase().includes(w)) ? boost : 0);
  return [...items].sort((a, b) => hit(b) + score(b) - (hit(a) + score(a)));
}

function fill(lines: string[], budget: number): string {
  const out: string[] = [];
  let used = 0;
  for (const line of lines) {
    if (used + line.length + 1 > budget) {
      out.push(`…and ${lines.length - out.length} more`);
      break;
    }
    out.push(line);
    used += line.length + 1;
  }
  return out.join('\n');
}

export function describeReference(m: ReferenceMaterials, focus?: string): string {
  const $ = cheerio.load(m.html);
  const words = focusWords(focus);
  const title = clip($('title').first().text().replace(/\s+/g, ' ').trim(), 100);
  const description = clip(($('meta[name="description"]').attr('content') ?? '').replace(/\s+/g, ' ').trim(), 200);

  // Libraries: from the files the page loads and from its code.
  const libraries = new Map<string, string | null>();
  for (const url of [...m.scriptUrls, ...m.styleUrls]) {
    const lib = libraryOf(url);
    if (lib && !libraries.get(lib.name)) libraries.set(lib.name, versionOf(url));
  }
  const allCode = [m.html.slice(0, 400_000), ...m.scripts.map((s) => s.text)].join('\n');
  for (const lib of LIBRARIES) if (lib.code?.test(allCode) && !libraries.has(lib.name)) libraries.set(lib.name, null);

  // The page from top to bottom.
  const outline = $('header, nav, section, footer, main > div')
    .slice(0, 28)
    .map((_, el) => {
      const node = $(el);
      const cls = (node.attr('class') ?? '').split(/\s+/).filter(Boolean).slice(0, 3).join('.');
      const id = node.attr('id');
      const heading = node.find('h1, h2, h3').first().text().replace(/\s+/g, ' ').trim();
      return `<${(el as { tagName?: string }).tagName ?? 'div'}${id ? `#${id}` : ''}${cls ? `.${cls}` : ''}>${heading ? ` “${clip(heading, 70)}”` : ''}`;
    })
    .get();

  // Classes and data attributes that mark animated elements.
  const hooks = new Map<string, number>();
  $('body *')
    .slice(0, 6000)
    .each((_, el) => {
      const attribs = (el as { attribs?: Record<string, string> }).attribs ?? {};
      for (const token of (attribs.class ?? '').split(/\s+/)) if (token && MOTION_WORDS.test(token)) hooks.set(`.${token}`, (hooks.get(`.${token}`) ?? 0) + 1);
      for (const [name, value] of Object.entries(attribs)) {
        if (!MOTION_DATA.test(name)) continue;
        const key = value && value.length <= 40 && !/^data-(?:w-id|framer-appear|framer-name)/.test(name) ? `[${name}="${value}"]` : `[${name}]`;
        hooks.set(key, (hooks.get(key) ?? 0) + 1);
      }
    });
  const hookList = [...hooks.entries()].sort((a, b) => b[1] - a[1]).slice(0, 24).map(([k, n]) => `${k} ×${n}`);

  const facts = { vars: new Map<string, string>(), fonts: new Set<string>(), reducedMotion: false };
  const css: CssFinding[] = [];
  for (const sheet of m.styles) readCss(sheet.text, css, facts);
  for (const href of m.styleUrls) {
    const family = href.match(/fonts\.googleapis\.com\/css2?\?family=([^&]+)/)?.[1];
    if (family) for (const f of decodeURIComponent(family).split('|')) facts.fonts.add(`${f.split(':')[0].replace(/\+/g, ' ')} (Google Fonts)`);
  }
  const unique = (list: CssFinding[]) => [...new Map(list.map((f) => [f.key + f.text, f])).values()];
  const byKind = (kind: CssFinding['kind']) => rank(unique(css.filter((f) => f.kind === kind)), words).map((f) => f.text);
  const easings = new Map<string, number>();
  for (const f of css) for (const e of f.text.match(/cubic-bezier\([^)]+\)/g) ?? []) easings.set(e, (easings.get(e) ?? 0) + 1);

  const js: JsFinding[] = [];
  for (const script of m.scripts) readJs(script, js);
  const jsLines = rank(js, words, (f) => f.weight, 8)
    .slice(0, 40)
    .map((f) => `[${clip(f.file, 60)}] ${f.text}`);

  const vars = [...facts.vars.entries()]
    .sort((a, b) => Number(/ease|duration|delay|speed|color|colour|bg|accent|brand|primary|radius|font/i.test(b[0])) - Number(/ease|duration|delay|speed|color|colour|bg|accent|brand|primary|radius|font/i.test(a[0])))
    .slice(0, 30)
    .map(([k, v]) => `${k}:${v}`);

  const keyframes = byKind('keyframes');
  const animations = byKind('animation');
  const scroll = byKind('scroll');
  const states = byKind('state');
  const transitions = byKind('transition');
  const parts = [
    `Page: ${m.url}${title ? ` — “${title}”` : ''}${description ? `\nDescription: ${description}` : ''}`,
    `Libraries: ${libraries.size ? [...libraries.entries()].map(([n, v]) => (v ? `${n} ${v}` : n)).join(', ') : 'none found (plain CSS and JavaScript)'}`,
    outline.length ? `Page outline, top to bottom:\n${fill(outline, 1600)}` : '',
    hookList.length ? `Animated-element hooks in the HTML: ${hookList.join(', ')}` : '',
    facts.fonts.size ? `Fonts: ${[...facts.fonts].slice(0, 8).join(', ')}` : '',
    vars.length ? `Custom properties: ${vars.join('; ')}` : '',
    easings.size ? `Easings used: ${[...easings.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).map(([e, n]) => `${e} ×${n}`).join(', ')}` : '',
    `CSS motion: ${keyframes.length} @keyframes, ${animations.length} rules with animation, ${scroll.length} scroll-driven, ${states.length} hover/state changes, ${transitions.length} transitions; reduced motion ${facts.reducedMotion ? 'handled (@media prefers-reduced-motion)' : 'not handled in CSS'}.`,
    keyframes.length ? `@keyframes:\n${fill(keyframes, 3200)}` : '',
    animations.length ? `Elements with an animation:\n${fill(animations, 2600)}` : '',
    scroll.length ? `Scroll-driven CSS:\n${fill(scroll, 1200)}` : '',
    states.length ? `Hover and state changes:\n${fill(states, 2000)}` : '',
    transitions.length ? `Transitions:\n${fill(transitions, 1400)}` : '',
    jsLines.length
      ? `JavaScript that drives the motion (excerpts around animation code, ${words.length ? `“${focus}” first` : 'strongest first'}):\n${fill(jsLines, 6500)}`
      : 'JavaScript: no animation code found in the scripts that were read.',
  ].filter(Boolean);
  const body = clip(parts.join('\n\n'), OUTPUT_MAX);
  return [
    `Read ${m.url} as text: nothing from it was run.${focus ? ` Looked first for: ${clip(focus, 120)}.` : ''}`,
    'Use it to learn how the effects are made (libraries, timings, easings, structure), then build your own version for this site. Never load scripts, styles, fonts or images from that site, and never copy its text, photos, logos or whole files.',
    untrusted('reference site code', body),
    m.skipped.length ? `Not read: ${m.skipped.slice(0, 8).join('; ')}.` : '',
  ]
    .filter(Boolean)
    .join('\n');
}

// ─── The tool ────────────────────────────────────────────────────────────────

const cache = new Map<string, { at: number; materials: ReferenceMaterials }>();

/** "https://www.example.com/work" → "example.com" (for the step shown in the chat). */
export function referenceHost(link: string): string {
  try {
    return parseLink(link).hostname.replace(/^www\./, '');
  } catch {
    return 'the site';
  }
}

/** Reads a reference site (kept 10 minutes, so looking again with another focus is quick). */
export async function studyReferenceSite(link: string, focus?: string): Promise<string> {
  const key = parseLink(link).href;
  const now = Date.now();
  for (const [k, v] of cache) if (now - v.at > CACHE_MS) cache.delete(k);
  let materials = cache.get(key)?.materials;
  if (!materials) {
    materials = await readReferenceSite(key);
    if (cache.size >= 20) cache.delete(cache.keys().next().value as string);
    cache.set(key, { at: now, materials });
  }
  return describeReference(materials, focus);
}
