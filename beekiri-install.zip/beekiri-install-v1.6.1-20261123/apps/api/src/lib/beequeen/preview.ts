import { randomUUID } from 'crypto';

/**
 * Section previews: Beekiri asks the open editor for a picture of the element it just changed
 * (the canvas renders it exactly as the site will), so it can see and fix its own design. The
 * editor posts the image back to /api/connector/agent/preview; only the same user can answer.
 */

export type PreviewImage = {
  data: string;
  mediaType: 'image/jpeg' | 'image/png';
  width?: number;
  height?: number;
  /** A tall element (a whole page) comes in parts, top to bottom: these follow the first. */
  more?: Pick<PreviewImage, 'data' | 'mediaType'>[];
};

const MAX_BASE64 = 1_800_000;
const pending = new Map<string, { userId: string; resolve: (v: PreviewImage) => void; reject: (e: Error) => void }>();

export function requestPreview(userId: string, ask: (id: string) => void, timeoutMs = 25_000): Promise<PreviewImage> {
  const id = randomUUID();
  return new Promise<PreviewImage>((resolve, reject) => {
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(new Error('The editor did not send a preview in time (is the page still open?).'));
    }, timeoutMs);
    pending.set(id, {
      userId,
      resolve: (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      reject: (e) => {
        clearTimeout(timer);
        reject(e);
      },
    });
    ask(id);
  });
}

/** A JPEG or PNG data URL → the picture Claude is shown, or null when it can't be read (or is too large). */
export function readImageDataUrl(url: string): Pick<PreviewImage, 'data' | 'mediaType'> | null {
  const m = url.match(/^data:(image\/(?:jpeg|png));base64,([A-Za-z0-9+/=]+)$/);
  if (!m || m[2].length > MAX_BASE64) return null;
  return { data: m[2], mediaType: m[1] as PreviewImage['mediaType'] };
}

/** The editor's answer: a data URL, or why it couldn't take the picture. False when nothing was waiting. */
export function answerPreview(
  userId: string,
  id: string,
  answer: { image?: string; more?: string[]; error?: string; width?: number; height?: number },
): boolean {
  const waiting = pending.get(id);
  if (!waiting || waiting.userId !== userId) return false;
  pending.delete(id);
  if (answer.error || !answer.image) {
    waiting.reject(new Error(answer.error || 'The editor sent no picture.'));
    return true;
  }
  const image = readImageDataUrl(answer.image);
  const more = (answer.more ?? []).map(readImageDataUrl);
  if (!image || more.some((m) => !m)) {
    waiting.reject(new Error('The preview picture could not be read.'));
    return true;
  }
  waiting.resolve({ ...image, width: answer.width, height: answer.height, ...(more.length ? { more: more as PreviewImage['more'] } : {}) });
  return true;
}
