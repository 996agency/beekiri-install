import { randomBytes } from 'crypto';
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'fs';
import { join } from 'path';
import type { AuthUser } from '../../types/auth';
import { resolveUploadsRoot } from '../media/media.paths';

/**
 * Files Beekiri prepares for the person who asked (a CSV of form entries, orders, appointments).
 * They hold customers' details, so they are private: kept in a dot-folder of uploads (never
 * served), downloadable only by that person through /api/connector/exports/:id, gone after a day.
 */
const KEEP_MS = 24 * 60 * 60_000;
const ID = /^[a-f0-9]{32}$/;

type ExportMeta = { userId: string; siteId: string; filename: string; createdAt: string };

function folder(siteId: string): string {
  return join(resolveUploadsRoot(), '.exports', siteId.replace(/[^A-Za-z0-9_-]/g, ''));
}

/** Exports older than a day go (checked whenever a new one is made). */
function removeOld(dir: string) {
  for (const name of readdirSync(dir)) {
    const path = join(dir, name);
    try {
      if (Date.now() - statSync(path).mtimeMs > KEEP_MS) rmSync(path, { force: true });
    } catch {
      /* gone already */
    }
  }
}

export function saveExport(actor: AuthUser, filename: string, content: string): { id: string; url: string } {
  const dir = folder(actor.siteId);
  mkdirSync(dir, { recursive: true });
  removeOld(dir);
  const id = randomBytes(16).toString('hex');
  writeFileSync(join(dir, `${id}.csv`), content);
  const meta: ExportMeta = { userId: actor.id, siteId: actor.siteId, filename, createdAt: new Date().toISOString() };
  writeFileSync(join(dir, `${id}.json`), JSON.stringify(meta));
  return { id, url: `/api/connector/exports/${id}` };
}

/** The file of an export this person made, while it is kept; null otherwise. */
export function findExport(actor: AuthUser, id: string): { path: string; filename: string } | null {
  if (!ID.test(id)) return null;
  const dir = folder(actor.siteId);
  const path = join(dir, `${id}.csv`);
  try {
    const meta = JSON.parse(readFileSync(join(dir, `${id}.json`), 'utf8')) as ExportMeta;
    if (meta.userId !== actor.id || meta.siteId !== actor.siteId) return null;
    if (Date.now() - Date.parse(meta.createdAt) > KEEP_MS || !existsSync(path)) return null;
    return { path, filename: meta.filename };
  } catch {
    return null;
  }
}

/** "linkedin form entries" → "linkedin-form-entries-2026-11-22.csv" */
export function exportFilename(title: string): string {
  const base = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60) || 'export';
  return `${base}-${new Date().toISOString().slice(0, 10)}.csv`;
}
