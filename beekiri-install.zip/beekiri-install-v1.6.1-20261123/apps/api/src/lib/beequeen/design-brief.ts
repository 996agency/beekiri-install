import { findCurrentSite, saveSiteOptions } from '../../services/site-context';
import { themesService } from '../../services/themes.service';
import { mergeSiteOptions, parseDesignBrief, readOptions, type DesignBriefOption } from '../site/site-options';
import { DEFAULT_THEME_SLUG, PARENT_THEME_SLUG, resolveClientThemeSlug, writableThemeSlug } from '../themes/theme-registry';

/**
 * The design brief: what the owner answered before Beekiri designed their site (colours, fonts,
 * feel, sites they like). It is saved per client theme and goes with every Beekiri request in that
 * theme (996Agency turns it into instructions), so later pages, sections and popups keep the look.
 */

/** The theme the brief belongs to: the one Beekiri writes to. */
async function briefTheme(): Promise<{ theme: string; starter: boolean }> {
  const active = (await themesService.getActiveSlug()) || DEFAULT_THEME_SLUG;
  return {
    theme: writableThemeSlug(resolveClientThemeSlug(active)),
    starter: active === DEFAULT_THEME_SLUG || active === PARENT_THEME_SLUG,
  };
}

export async function readDesignBrief(): Promise<{ brief: DesignBriefOption | null; starter: boolean; siteTitle: string }> {
  const [{ theme, starter }, site] = await Promise.all([briefTheme(), findCurrentSite()]);
  const opts = readOptions(site?.settings?.options);
  return { brief: opts.designBriefs?.[theme] ?? null, starter, siteTitle: site?.title ?? '' };
}

/**
 * The owner's answers from the questionnaire replace the earlier ones (Beekiri's own notes stay);
 * `merge` (Beekiri's save_design_brief) changes only the fields it sends.
 */
export async function saveDesignBrief(input: Record<string, unknown>, how: { merge: boolean }): Promise<DesignBriefOption> {
  const [{ theme }, site] = await Promise.all([briefTheme(), findCurrentSite()]);
  if (!site) throw new Error('This site could not be found.');
  const opts = readOptions(site.settings?.options);
  const current = opts.designBriefs?.[theme];
  const sent = Object.fromEntries(Object.entries(input).filter(([, v]) => v !== undefined));
  const next = parseDesignBrief({
    ...(how.merge ? current : { decisions: current?.decisions }),
    ...sent,
    updatedAt: new Date().toISOString(),
  })!;
  await saveSiteOptions(site.id, mergeSiteOptions(site.settings?.options, { designBriefs: { ...opts.designBriefs, [theme]: next } }));
  return next;
}
