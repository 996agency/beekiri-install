import type { DesignBriefOption } from '../site/site-options';
import { siteLibVersions } from '../site-libs';
import type { SectionScope } from './section';

/**
 * What a Beekiri request is about, for 996Agency. Beekiri's instructions, skills and tool guidance
 * live at 996Agency (its "brain"), never in this code: the site sends only these facts with each
 * call, and the relay writes Claude's instructions from them. A call without them is refused.
 */

/** Put before the owner's words when pictures come with them; 996Agency says what the pictures are. */
export const PICTURES_MARKER = '[[beekiri:pictures]]';

export type BrainTask = 'agent' | 'alt_text' | 'seo';

export type BrainPicture = { kind: 'screenshot' | 'reference'; part?: number; parts?: number };

export type BrainContext = {
  v: 1;
  task: BrainTask;
  /** What this site has: the GSAP plugins its layouts can load. */
  site?: { gsapPlugins: string[] };
  /** The owner's design brief for the active theme. */
  brief?: DesignBriefOption;
  /** The element (or the whole page) selected in the editor. */
  scope?: Pick<SectionScope, 'pageTitle' | 'label' | 'nodeId' | 'viewport' | 'wholePage' | 'tree'>;
  /** The pictures sent with the message, in order. */
  pictures?: BrainPicture[];
};

/** A chat turn: the whole site, or one element (or page) in the editor. */
export function agentContext(scope: SectionScope | null, brief: DesignBriefOption | null, pictures: BrainPicture[] = []): BrainContext {
  return {
    v: 1,
    task: 'agent',
    site: { gsapPlugins: siteLibVersions()?.gsapPlugins ?? ['ScrollTrigger', 'SplitText', 'Flip'] },
    ...(brief ? { brief } : {}),
    ...(scope
      ? { scope: { pageTitle: scope.pageTitle, label: scope.label, nodeId: scope.nodeId, viewport: scope.viewport, wholePage: scope.wholePage, tree: scope.tree } }
      : {}),
    ...(pictures.length ? { pictures: pictures.map(({ kind, part, parts }) => ({ kind, ...(part ? { part } : {}), ...(parts ? { parts } : {}) })) } : {}),
  };
}

/** A ✦ helper (alt text, search listing). */
export function helperContext(task: Exclude<BrainTask, 'agent'>): BrainContext {
  return { v: 1, task };
}
