import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'fs';
import { join } from 'path';

import { findCurrentSite } from '../../services/site-context';
import { themesService } from '../../services/themes.service';
import { readOptions } from '../site/site-options';
import { resolveActiveChrome, resolveClientThemeSlug, resolveThemesRoot, themeAncestry, writableThemeSlug } from '../themes/theme-registry';
import { writeThemeFile, type Workspace } from './workspace';

/**
 * add_font: a Google Font, put on the site itself. The .woff2 files go next to the header's
 * styles (the header loads on every page and in the editor), and @font-face rules go at the top
 * of that stylesheet, where the site points url(name.woff2) at its own copy. Visitors never load
 * anything from Google.
 */

const GOOGLE_CSS = 'https://fonts.googleapis.com/css2';
/** Google only sends .woff2 to browsers it knows. */
const BROWSER_UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
/** Latin covers English and most European languages (Albanian ë and ç included); Latin Extended the rest. */
const SUBSETS = ['latin', 'latin-ext'];
const MAX_FONT_BYTES = 600_000;
const MAX_FILES = 12;
const STYLE_FILES = ['styles.scss', 'styles.css'];

export type AddFontInput = { family: string; weights?: number[]; italic?: boolean };

type Face = { subset: string; style: 'normal' | 'italic'; weight: string; url: string; range: string };

/** Google's stylesheet: one @font-face per subset, style and weight, each after a /* subset *\/ comment. */
function parseFaces(css: string): Face[] {
  const faces: Face[] = [];
  for (const m of css.matchAll(/\/\*\s*([a-z0-9-]+)\s*\*\/\s*@font-face\s*\{([^}]*)\}/gi)) {
    const body = m[2];
    const prop = (name: string) => body.match(new RegExp(`${name}\\s*:\\s*([^;]+);`, 'i'))?.[1].trim() ?? '';
    const url = body.match(/url\((https:\/\/fonts\.gstatic\.com\/[^)\s'"]+\.woff2)\)/i)?.[1];
    if (!url) continue;
    faces.push({
      subset: m[1].toLowerCase(),
      style: prop('font-style') === 'italic' ? 'italic' : 'normal',
      weight: prop('font-weight') || '400',
      url,
      range: prop('unicode-range'),
    });
  }
  return faces;
}

async function googleCss(family: string, axes: string): Promise<string | null> {
  const query = `family=${encodeURIComponent(family).replace(/%20/g, '+')}${axes ? `:${axes}` : ''}&display=swap`;
  const res = await fetch(`${GOOGLE_CSS}?${query}`, { headers: { 'User-Agent': BROWSER_UA }, signal: AbortSignal.timeout(15_000) });
  if (res.status === 400) return null;
  if (!res.ok) throw new Error(`Google Fonts did not answer (${res.status}). Try again in a moment.`);
  return res.text();
}

/**
 * Asks for every weight at once; a font that lacks one of them is asked weight by weight, and one
 * that has none of them in its regular weight only.
 */
async function fetchFaces(family: string, weights: number[], italic: boolean): Promise<Face[]> {
  const axes = (list: number[]) =>
    italic ? `ital,wght@${[0, 1].flatMap((i) => list.map((w) => `${i},${w}`)).join(';')}` : `wght@${list.join(';')}`;
  const all = await googleCss(family, axes(weights));
  if (all) return parseFaces(all);
  const faces: Face[] = [];
  for (const weight of weights) {
    const one = await googleCss(family, axes([weight]));
    if (one) faces.push(...parseFaces(one));
  }
  if (faces.length) return faces;
  const plain = await googleCss(family, '');
  if (!plain) throw new Error(`Google Fonts has no font called “${family}”. Check the name on fonts.google.com (e.g. "Playfair Display", "DM Sans").`);
  return parseFaces(plain);
}

/** Where the active header keeps its styles in the client theme (made from the parent's when missing). */
async function headerStyles(): Promise<{ theme: string; dir: string; rel: string; content: string; copied: boolean }> {
  const active = await themesService.getActiveSlug();
  const theme = writableThemeSlug(resolveClientThemeSlug(active));
  const site = await findCurrentSite();
  const header = resolveActiveChrome(theme, 'header', readOptions(site?.settings?.options).activeHeader);
  if (!header?.path) throw new Error('This theme has no header to load fonts from. Use system fonts instead.');
  const root = resolveThemesRoot();
  for (const slug of themeAncestry(theme)) {
    const file = STYLE_FILES.find((f) => existsSync(join(root, slug, header.path, f)));
    if (!file) continue;
    return {
      theme,
      dir: join(root, theme, header.path),
      rel: `${header.path}/${file}`,
      content: readFileSync(join(root, slug, header.path, file), 'utf8'),
      copied: slug !== theme,
    };
  }
  return { theme, dir: join(root, theme, header.path), rel: `${header.path}/styles.scss`, content: '', copied: false };
}

const fontSlug = (family: string) =>
  family
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 28)
    .replace(/-+$/, '');

/** The family's block in the stylesheet, replaced when the font is added again. */
const markers = (family: string) => [`/* Font: ${family} (added by Beekiri; the files are in this folder) */`, `/* End font: ${family} */`];

function withFontBlock(css: string, family: string, block: string): string {
  const [start, end] = markers(family);
  const from = css.indexOf(start);
  const to = from >= 0 ? css.indexOf(end, from) : -1;
  if (from >= 0 && to > from) return `${css.slice(0, from)}${block}${css.slice(to + end.length)}`;
  // Sass wants @use / @forward / @charset first: the fonts go right after them.
  const leading = [...css.matchAll(/^@(?:use|forward|charset)\b[^;]*;[^\S\n]*\n?/gm)].pop();
  const at = leading ? (leading.index ?? 0) + leading[0].length : 0;
  return `${css.slice(0, at)}${block}\n\n${css.slice(at).replace(/^\n+/, '')}`;
}

export async function addFont(ws: Workspace, input: AddFontInput): Promise<string> {
  const family = input.family.trim().replace(/\s+/g, ' ');
  if (!/^[A-Za-z0-9][A-Za-z0-9 ]{1,59}$/.test(family)) throw new Error('Give the font’s name as Google Fonts writes it, e.g. "Playfair Display".');
  const weights = [...new Set(input.weights?.length ? input.weights : [400, 600, 700])].sort((a, b) => a - b);
  const faces = (await fetchFaces(family, weights, input.italic === true)).filter((f) => SUBSETS.includes(f.subset));
  if (!faces.length) throw new Error(`“${family}” has no Latin letters on Google Fonts, so the site’s text can’t use it.`);

  // A variable font serves several weights from one file: one file, one @font-face with a weight range.
  const byUrl = new Map<string, Face[]>();
  for (const face of faces) byUrl.set(face.url, [...(byUrl.get(face.url) ?? []), face]);
  if (byUrl.size > MAX_FILES) throw new Error(`That is ${byUrl.size} font files. Ask for fewer weights (e.g. 400 and 700).`);

  const styles = await headerStyles();
  mkdirSync(styles.dir, { recursive: true });
  const slug = fontSlug(family);
  const rules: string[] = [];
  const names: string[] = [];
  for (const [url, group] of byUrl) {
    const { style, subset, range } = group[0];
    const numbers = group.flatMap((f) => f.weight.split(/\s+/).map(Number)).filter((n) => n > 0);
    const weight = numbers.length > 1 && Math.min(...numbers) !== Math.max(...numbers) ? `${Math.min(...numbers)} ${Math.max(...numbers)}` : String(numbers[0] ?? 400);
    const name = `${slug}${style === 'italic' ? '-italic' : ''}-${weight.replace(' ', '-')}-${subset}.woff2`;
    const res = await fetch(url, { headers: { 'User-Agent': BROWSER_UA }, signal: AbortSignal.timeout(20_000) });
    if (!res.ok) throw new Error(`A font file of “${family}” could not be downloaded (${res.status}). Try again in a moment.`);
    const file = Buffer.from(await res.arrayBuffer());
    if (file.length > MAX_FONT_BYTES || file.subarray(0, 4).toString('latin1') !== 'wOF2') {
      throw new Error(`A font file of “${family}” was not a web font Beekiri can use.`);
    }
    writeFileSync(join(styles.dir, name), file);
    names.push(name);
    rules.push(
      `@font-face {\n  font-family: '${family}';\n  font-style: ${style};\n  font-weight: ${weight};\n  font-display: swap;\n  src: url(${name}) format('woff2');${range ? `\n  unicode-range: ${range};` : ''}\n}`,
    );
  }

  const [start, end] = markers(family);
  await writeThemeFile(ws, styles.rel, withFontBlock(styles.content, family, `${start}\n${rules.join('\n')}\n${end}`));
  const got = [...new Set(faces.flatMap((f) => f.weight.split(/\s+/)))].sort().join(', ');
  return (
    `Added ${family} to the site (weights ${got}${faces.some((f) => f.style === 'italic') ? ', with italics' : ''}): ${names.length} font files in ${styles.theme}/${styles.rel.split('/')[0]}/ and @font-face rules at the top of ${styles.theme}/${styles.rel}, which loads on every page and in the editor.` +
    (styles.copied ? ` The client theme now has its own ${styles.rel} (a copy of the parent's), so change header styles there.` : '') +
    ` Use it with font-family: '${family}', followed by a fitting system fallback (e.g. Georgia, serif or system-ui, sans-serif) — for example in style.css as --bk-font or a heading font variable.`
  );
}
