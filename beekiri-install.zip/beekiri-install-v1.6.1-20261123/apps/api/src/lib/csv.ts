/**
 * CSV for spreadsheets: every cell quoted, and a value that starts like a formula gets a ' in
 * front, so an export of visitors' answers can never run a formula in Excel or Sheets.
 */
export function csvCell(value: unknown): string {
  const text = value == null ? '' : String(value);
  return `"${(/^[=+\-@\t\r]/.test(text) ? `'${text}` : text).replace(/"/g, '""')}"`;
}

/** A whole file: header row first; a BOM so Excel reads UTF-8, Windows line ends. */
export function toCsv(head: string[], rows: unknown[][]): string {
  return `﻿${[head, ...rows].map((row) => row.map(csvCell).join(',')).join('\r\n')}`;
}
